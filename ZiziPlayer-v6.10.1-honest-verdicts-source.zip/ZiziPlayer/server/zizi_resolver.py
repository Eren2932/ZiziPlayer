#!/usr/bin/env python3
"""
ZiziResolve 1.1 — резолвер аудио-потоков для ZiziPlayer.

Что нового против 1.0 (всё по логам с живого сервера):
  1. ПРОКСИ ТЯНЕТ ПО IPv4. В 1.0 httpx уходил в IPv6 (в логах mip=2a03:6f02::1:3f9d,
     ipbypass=yes, цепочка из 3 редиректов) — отсюда "дикая задержка" на старте.
  2. ОДИН ПЕРЕИСПОЛЬЗУЕМЫЙ HTTP-КЛИЕНТ вместо нового на каждый запрос:
     TLS-хендшейк к googlevideo делается один раз, а не при каждом нажатии.
  3. ГЕО-ОБХОД: geo_bypass + ZIZI_GEO (по умолчанию US) и ZIZI_PROXY —
     лечит "The uploader has not made this video available in your country".
  4. ЧЕСТНЫЕ КОДЫ ОШИБОК вместо универсального 502:
        451 — гео-блок          404 — трек снят/приватный
        403 — бот-чек           502 — всё остальное
     Приложение теперь может сказать пользователю правду, а не молча свайпнуть.
  5. НЕГАТИВНЫЙ КЭШ (ZIZI_NEG_TTL): в логах приложение долбило один мёртвый id
     четыре раза по 5 секунд. Теперь второй раз отвечаем мгновенно.
  6. /prefetch?ids=a,b,c — прогрев очереди в фоне. Главное лекарство от задержки:
     пока играет трек, следующие два уже отрезолвлены.
  7. /stream греет соединение сразу, отдаёт content-type по реальному mime.

Запуск: uvicorn zizi_resolver:app --host 0.0.0.0 --port 8080
"""

import os
import re
import time
import asyncio
import logging
from typing import Optional, Dict, Any, List

import httpx
from fastapi import FastAPI, HTTPException, Query, Header, Request
from fastapi.responses import JSONResponse, StreamingResponse
from yt_dlp import YoutubeDL

# ── Конфиг ───────────────────────────────────────────────────────────────────
API_TOKEN = os.environ.get("ZIZI_TOKEN", "")
CACHE_TTL = int(os.environ.get("ZIZI_CACHE_TTL", "10800"))    # 3 часа
NEG_TTL = int(os.environ.get("ZIZI_NEG_TTL", "600"))          # 10 мин на неудачи
PROXY_CHUNK = 256 * 1024                                      # было 64К — реже переключений
COOKIES_FILE = os.environ.get("ZIZI_COOKIES", "")
PO_PROVIDER = os.environ.get("ZIZI_POT_URL", "")
GEO_COUNTRY = os.environ.get("ZIZI_GEO", "US").strip().upper()  # "" = выключить обход
OUT_PROXY = os.environ.get("ZIZI_PROXY", "").strip()            # socks5h://127.0.0.1:1080
# Прокси только для резолва (1) или ещё и для проксирования байтов (по умолчанию да).
# Гео-блок проверяется при резолве; но ссылка чеканится под IP того, кто её попросил, поэтому
# по умолчанию поток тоже идёт через прокси — иначе googlevideo ответит 403.
STREAM_PROXY = os.environ.get("ZIZI_STREAM_PROXY", "1").lower() not in ("0", "false", "no")
CLIENTS = os.environ.get(
    "ZIZI_CLIENTS", "ios_music,ios,visionos,tv,android_vr,web_music"
).split(",")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("zizi")

app = FastAPI(title="ZiziResolve", version="1.1")

_cache: Dict[str, Dict[str, Any]] = {}
_neg: Dict[str, Dict[str, Any]] = {}
_locks: Dict[str, asyncio.Lock] = {}
_client: Optional[httpx.AsyncClient] = None


# ── HTTP-клиент: жёстко IPv4, keep-alive, переиспользуется ───────────────────
def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        transport = httpx.AsyncHTTPTransport(
            local_address="0.0.0.0",        # ← вот это и убирает IPv6-тормоза
            retries=1,
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32,
                                keepalive_expiry=60.0),
        )
        _client = httpx.AsyncClient(
            transport=transport,
            timeout=httpx.Timeout(15.0, connect=8.0, read=None),
            follow_redirects=True,
            proxy=(OUT_PROXY if (OUT_PROXY and STREAM_PROXY) else None),
            headers={"User-Agent": "Mozilla/5.0", "Accept": "*/*"},
        )
    return _client


@app.on_event("shutdown")
async def _shutdown():
    if _client and not _client.is_closed:
        await _client.aclose()


# ── Классификация ошибок yt-dlp ──────────────────────────────────────────────
def classify(msg: str) -> int:
    m = msg.lower()
    if "not available in your country" in m or "blocked it in your country" in m:
        return 451
    if "sign in to confirm" in m or "not a bot" in m or "login_required" in m:
        return 403
    if ("video is not available" in m or "video unavailable" in m
            or "private video" in m or "removed by the uploader" in m
            or "account associated" in m or "terminated" in m):
        return 404
    if "members-only" in m or "premium" in m:
        return 402
    return 502


def human(code: int) -> str:
    return {
        451: "трек заблокирован в регионе сервера",
        403: "YouTube требует вход (бот-чек)",
        404: "трек удалён или закрыт",
        402: "трек только для подписчиков/участников",
    }.get(code, "источник не отдал поток")


# ── Кэш ──────────────────────────────────────────────────────────────────────
def _cache_get(video_id: str) -> Optional[Dict[str, Any]]:
    item = _cache.get(video_id)
    if not item:
        return None
    if time.time() > item["cached_until"]:
        _cache.pop(video_id, None)
        return None
    return item


def _neg_get(video_id: str) -> Optional[Dict[str, Any]]:
    item = _neg.get(video_id)
    if not item:
        return None
    if time.time() > item["until"]:
        _neg.pop(video_id, None)
        return None
    return item


# ── yt-dlp ───────────────────────────────────────────────────────────────────
def _ydl_opts() -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        # m4a (itag 140) первым: Media3 его декодирует быстрее и он есть почти всегда
        "format": "bestaudio[ext=m4a]/bestaudio[acodec^=opus]/bestaudio/best",
        "source_address": "0.0.0.0",
        "socket_timeout": 15,
        "retries": 2,
        "extractor_retries": 1,
        "cachedir": "/opt/zizi/ytdlp-cache",   # кэш плееров = быстрее резолв
        "extractor_args": {
            "youtube": {
                "player_client": [c.strip() for c in CLIENTS if c.strip()],
                "player_skip": ["configs"],     # меньше лишних запросов
            }
        },
    }
    if GEO_COUNTRY:
        opts["geo_bypass"] = True
        opts["geo_bypass_country"] = GEO_COUNTRY
    if OUT_PROXY:
        opts["proxy"] = OUT_PROXY
    if COOKIES_FILE and os.path.exists(COOKIES_FILE):
        opts["cookiefile"] = COOKIES_FILE
    if PO_PROVIDER:
        opts["extractor_args"]["youtubepot-bgutilhttp"] = {"base_url": [PO_PROVIDER]}
    return opts


def _extract(video_id: str) -> Dict[str, Any]:
    url = f"https://www.youtube.com/watch?v={video_id}"
    with YoutubeDL(_ydl_opts()) as ydl:
        info = ydl.extract_info(url, download=False)

    audio = [f for f in info.get("formats", [])
             if f.get("acodec") not in (None, "none")
             and f.get("vcodec") in ("none", None)
             and f.get("url")]
    # m4a вперёд, потом по битрейту
    audio.sort(key=lambda f: (f.get("ext") == "m4a", f.get("abr") or 0), reverse=True)
    fmt = audio[0] if audio else {"url": info.get("url"), "abr": info.get("abr"),
                                  "ext": info.get("ext")}
    if not fmt.get("url"):
        raise RuntimeError("no audio url in extractor output")

    ext = (fmt.get("ext") or "webm").lower()
    ctype = "audio/mp4" if ext in ("m4a", "mp4") else "audio/webm"
    return {
        "id": video_id,
        "title": info.get("title"),
        "artist": info.get("artist") or info.get("uploader"),
        "duration": info.get("duration"),
        "url": fmt["url"],
        "mime": ext,
        "content_type": ctype,
        "abr": fmt.get("abr"),
        "filesize": fmt.get("filesize") or fmt.get("filesize_approx"),
        "resolved_at": int(time.time()),
        "cached_until": time.time() + CACHE_TTL,
    }


async def _resolve_cached(video_id: str) -> Dict[str, Any]:
    hit = _cache_get(video_id)
    if hit:
        return hit
    neg = _neg_get(video_id)
    if neg:
        raise HTTPException(status_code=neg["code"], detail=neg["detail"])

    lock = _locks.setdefault(video_id, asyncio.Lock())
    async with lock:
        hit = _cache_get(video_id)
        if hit:
            return hit
        neg = _neg_get(video_id)
        if neg:
            raise HTTPException(status_code=neg["code"], detail=neg["detail"])
        t0 = time.time()
        try:
            data = await asyncio.to_thread(_extract, video_id)
        except Exception as e:
            code = classify(str(e))
            detail = human(code)
            _neg[video_id] = {"code": code, "detail": detail, "until": time.time() + NEG_TTL}
            log.warning("resolve failed %s [%s] %.1fs: %s", video_id, code, time.time() - t0, e)
            raise HTTPException(status_code=code, detail=detail)
        log.info("resolved %s in %.1fs (%s, %skbps)", video_id, time.time() - t0,
                 data["mime"], data.get("abr"))
        _cache[video_id] = data
        return data


def _check_token(header: Optional[str], q_token: Optional[str]) -> None:
    if not API_TOKEN:
        return
    supplied = None
    if header and header.lower().startswith("bearer "):
        supplied = header[7:].strip()
    supplied = supplied or q_token
    if supplied != API_TOKEN:
        raise HTTPException(status_code=401, detail="bad token")


def _public(d: Dict[str, Any], cached: bool) -> Dict[str, Any]:
    out = {k: v for k, v in d.items() if k != "cached_until"}
    out["cached"] = cached
    return out


# ── Эндпоинты ────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"ok": True, "version": "1.1", "cache": len(_cache), "neg": len(_neg),
            "geo": GEO_COUNTRY or "off", "proxy": bool(OUT_PROXY), "stream_proxy": STREAM_PROXY,
            "clients": CLIENTS, "ts": int(time.time())}


@app.get("/resolve")
async def resolve(id: str = Query(..., min_length=5, max_length=32),
                  token: Optional[str] = Query(None),
                  authorization: Optional[str] = Header(None)):
    _check_token(authorization, token)
    had = _cache_get(id) is not None
    data = await _resolve_cached(id)
    return JSONResponse(_public(data, had))


@app.get("/prefetch")
async def prefetch(ids: str = Query(..., max_length=512),
                   token: Optional[str] = Query(None),
                   authorization: Optional[str] = Header(None)):
    """Прогрев очереди: приложение шлёт id следующих 2-3 треков.
    Отвечает сразу, резолвит в фоне."""
    _check_token(authorization, token)
    wanted: List[str] = [x for x in re.split(r"[,\s]+", ids) if 5 <= len(x) <= 32][:5]

    async def warm(vid: str):
        try:
            await _resolve_cached(vid)
        except Exception:
            pass

    for vid in wanted:
        if not _cache_get(vid) and not _neg_get(vid):
            asyncio.create_task(warm(vid))
    return {"queued": wanted, "cache": len(_cache)}


@app.get("/stream")
async def stream(request: Request,
                 id: str = Query(..., min_length=5, max_length=32),
                 token: Optional[str] = Query(None),
                 authorization: Optional[str] = Header(None)):
    _check_token(authorization, token)
    item = await _resolve_cached(id)

    headers = {}
    rng = request.headers.get("range")
    if rng:
        headers["Range"] = rng

    client = get_client()

    async def open_upstream(url: str):
        req = client.build_request("GET", url, headers=headers)
        return await client.send(req, stream=True)

    try:
        upstream = await open_upstream(item["url"])
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"upstream error: {e}")

    if upstream.status_code in (403, 410):
        await upstream.aclose()
        _cache.pop(id, None)
        item = await _resolve_cached(id)
        try:
            upstream = await open_upstream(item["url"])
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"refresh failed: {e}")

    async def body():
        try:
            async for chunk in upstream.aiter_bytes(PROXY_CHUNK):
                yield chunk
        finally:
            await upstream.aclose()

    passthrough = {}
    for h in ("content-length", "content-range", "content-type", "accept-ranges"):
        if h in upstream.headers:
            passthrough[h] = upstream.headers[h]
    passthrough.setdefault("accept-ranges", "bytes")
    passthrough["content-type"] = upstream.headers.get(
        "content-type", item.get("content_type", "audio/mp4"))

    return StreamingResponse(body(), status_code=upstream.status_code, headers=passthrough)
