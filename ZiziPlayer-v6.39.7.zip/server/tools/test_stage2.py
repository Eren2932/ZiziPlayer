#!/usr/bin/env python3
"""Real threads/process groups/SQLite, fixture metadata; no live YouTube or ASGI."""
import asyncio
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from zizi_scheduler import ExtractionScheduler, SchedulerBusy, SCHEDULER
from zizi_process import run_text, ProcessError
from zizi_extra import ExtraCatalog, ExtraError
from zizi_guard import ExtractGate, ExtractBusy
from zizi_versions import version_tags, rank_tracks
sys.path.insert(0, str(HERE / '_stub'))
import zizi_catalog as catalog


def wait_until(fn, timeout=2):
    deadline = time.monotonic()+timeout
    while not fn():
        if time.monotonic() >= deadline:
            raise AssertionError('condition timed out')
        time.sleep(.005)


def process_stopped(pid):
    """A dead Linux process can vanish during open OR read of /proc/pid/stat."""
    try:
        stat = Path('/proc/%s/stat' % pid).read_text()
    except (FileNotFoundError, ProcessLookupError):
        # ENOENT before open, or ESRCH after open when the process is reaped.
        return True
    # Field 2 (comm) is parenthesized and may contain spaces or parentheses.
    # The state is the first field after the LAST closing parenthesis.
    return stat.rsplit(')', 1)[1].split()[0] == 'Z'


class ProcessStateTests(unittest.TestCase):
    def test_missing_proc_entry_is_stopped(self):
        with patch.object(Path, 'read_text', side_effect=FileNotFoundError(2, 'gone')):
            self.assertTrue(process_stopped(123))

    def test_reaped_during_read_is_stopped(self):
        with patch.object(Path, 'read_text', side_effect=ProcessLookupError(3, 'gone')):
            self.assertTrue(process_stopped(123))

    def test_zombie_is_stopped(self):
        with patch.object(Path, 'read_text', return_value='123 (python) Z 1 123 123'):
            self.assertTrue(process_stopped(123))

    def test_live_states_are_not_stopped(self):
        for state in ('R', 'S', 'D', 'T', 't', 'I'):
            with self.subTest(state=state):
                with patch.object(Path, 'read_text', return_value=f'123 (python) {state} 1'):
                    self.assertFalse(process_stopped(123))

    def test_process_name_can_contain_spaces_and_parentheses(self):
        for state in ('S', 'Z'):
            with self.subTest(state=state):
                with patch.object(Path, 'read_text', return_value=f'123 (worker ) Z (name)) {state} 1'):
                    self.assertEqual(process_stopped(123), state == 'Z')

    def test_unrelated_io_errors_are_not_hidden(self):
        for error in (PermissionError(13, 'denied'), OSError(5, 'I/O error')):
            with self.subTest(error=type(error).__name__):
                with patch.object(Path, 'read_text', side_effect=error):
                    with self.assertRaises(type(error)):
                        process_stopped(123)


class SchedulerTests(unittest.TestCase):
    def test_one_slot_and_release_on_error(self):
        s = ExtractionScheduler()
        with self.assertRaises(ValueError):
            with s.acquire('playback', 0):
                with self.assertRaises(SchedulerBusy):
                    s.acquire('extra', 3, 0)
                raise ValueError()
        with s.acquire('extra', 3, 0):
            self.assertEqual(s.stats()['active'], 'extra')
        self.assertIsNone(s.stats()['active'])

    def test_priority_then_fifo(self):
        s = ExtractionScheduler()
        held = s.acquire('playback', 0)
        order, errors, threads = [], [], []
        def worker(kind, priority):
            try:
                with s.acquire(kind, priority, 2):
                    order.append(kind)
            except Exception as e:
                errors.append(e)
        for i, (kind, priority) in enumerate([('prefetch', 2), ('match', 1), ('play1', 0), ('play2', 0)]):
            t=threading.Thread(target=worker,args=(kind,priority)); t.start(); threads.append(t)
            wait_until(lambda: s.stats()['queued']==i+1)
        held.close()
        for t in threads: t.join(3)
        self.assertFalse(errors)
        self.assertEqual(order, ['play1', 'play2', 'match', 'prefetch'])

    def test_bounded_queue_and_timeout_cleanup(self):
        s = ExtractionScheduler(max_waiters=1)
        with s.acquire('playback', 0):
            token=s._register('match', 1)
            with self.assertRaises(SchedulerBusy): s.acquire('extra',3,0)
            s._remove(token)
            with self.assertRaises(SchedulerBusy): s.acquire('match',1,.02)
            self.assertEqual(s.stats()['queued'],0)

    def test_priority_inheritance(self):
        s=ExtractionScheduler(); promoted=[False]
        held=s.acquire('playback',0)
        a=s._register('prefetch', lambda: 0 if promoted[0] else 2)
        b=s._register('match',1)
        promoted[0]=True; held.close()
        with s._take(a): self.assertIsNone(s._take(b))
        with s._take(b): pass

    def test_nonforeground_does_not_preempt(self):
        s=ExtractionScheduler()
        with s.acquire('extra',3) as lease:
            with self.assertRaises(SchedulerBusy): s.acquire('prefetch',2,0)
            self.assertFalse(lease.cancel.is_set())

    def test_preemption_real_child_before_playback_slot(self):
        s=ExtractionScheduler(); errors=[]; outcome=[]
        with tempfile.TemporaryDirectory() as tmp:
            ready=Path(tmp)/'ready'
            code="import pathlib,time; pathlib.Path(%r).write_text('ready'); time.sleep(10)" % str(ready)
            def search():
                try:
                    with s.acquire('extra',3) as lease:
                        run_text([sys.executable,'-c',code],cancel=lease.cancel)
                except ProcessError as e: outcome.append(e.status)
                except Exception as e: errors.append(e)
            t=threading.Thread(target=search); t.start()
            wait_until(ready.exists)
            start=time.monotonic()
            with s.acquire('playback',0,2):
                self.assertEqual(outcome,[429])
            t.join(2)
            self.assertFalse(errors)
            self.assertFalse(t.is_alive())
            self.assertLess(time.monotonic()-start,2)
            self.assertEqual(s.stats()['preemptions'],1)

    def test_group_descendant_is_killed(self):
        with tempfile.TemporaryDirectory() as tmp:
            pidfile=Path(tmp)/'pid'
            code=("import subprocess,sys,pathlib,time; "
                  "p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)']); "
                  "pathlib.Path(%r).write_text(str(p.pid)); time.sleep(30)" % str(pidfile))
            with self.assertRaises(ProcessError):
                run_text([sys.executable,'-c',code],timeout=.3)
            self.assertTrue(pidfile.exists())
            pid=int(pidfile.read_text())
            wait_until(lambda: process_stopped(pid))


class AsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_waiter_leaves_no_ticket(self):
        s=ExtractionScheduler()
        with s.acquire('playback',0):
            task=asyncio.create_task(s.acquire_async('playback',0))
            await asyncio.sleep(.03); task.cancel()
            with self.assertRaises(asyncio.CancelledError): await task
            self.assertEqual(s.stats()['queued'],0)

    async def test_cancelled_http_does_not_release_running_thread(self):
        s=ExtractionScheduler(); started=threading.Event(); finish=threading.Event()
        def work():
            started.set(); finish.wait(3); return 42
        task=asyncio.create_task(s.run_async(work))
        try:
            for _ in range(200):
                if started.is_set(): break
                await asyncio.sleep(.005)
            self.assertTrue(started.is_set())
            task.cancel()
            with self.assertRaises(asyncio.CancelledError): await task
            with self.assertRaises(SchedulerBusy): s.acquire('extra',3,0)
        finally: finish.set()
        for _ in range(200):
            if s.stats()['active'] is None: break
            await asyncio.sleep(.005)
        self.assertIsNone(s.stats()['active'])

    async def test_thread_failure_releases(self):
        s=ExtractionScheduler()
        def fail(): raise ValueError('fixture')
        with self.assertRaises(ValueError): await s.run_async(fail)
        self.assertIsNone(s.stats()['active'])

    async def test_async_admission_does_not_block_event_loop(self):
        s=ExtractionScheduler()
        with s.acquire('playback',0):
            task=asyncio.create_task(s.acquire_async('playback',0,timeout=.1))
            start=time.monotonic(); await asyncio.sleep(.01)
            self.assertLess(time.monotonic()-start,.08)
            with self.assertRaises(SchedulerBusy): await task


class RankingTests(unittest.TestCase):
    def test_super_before_ultra_and_reverb(self):
        items=[{'title':'M Ultra Slowed'}, {'title':'M Super Slowed Reverb'}, {'title':'M Super Slowed'}]
        self.assertEqual([x['title'] for x in rank_tracks(items,'M Super Slowed')],
                         ['M Super Slowed','M Super Slowed Reverb','M Ultra Slowed'])

    def test_user_vps_fixture_keeps_five_ids_and_ranks_versions(self):
        items=json.loads((HERE/'fixtures/delirio-vps-search.json').read_text())
        result=rank_tracks(items,'MONTAGEM DELÍRIO Super Slowed')
        self.assertEqual(len(result),5)
        self.assertEqual([r['id'] for r in result], ['CKmaFXdlp0Y','ok3puARxi7I','X-r4nYoeo1k',
                                                   'g3xljuFm7oc','ms6BPZmquwE'])
        self.assertTrue(all(r['artist'] is None for r in result))

    def test_original_before_other_versions(self):
        result=rank_tracks([{'title':'M Sped Up'}, {'title':'M'}], 'M')
        self.assertEqual(result[0]['title'],'M')

    def test_orthography(self):
        for text in ['SUPER-SLOWED','Super_Slowed','Super Slowed']:
            self.assertEqual(version_tags(text),{'super_slowed'})

    def test_unknown_duration_kept_and_no_artist_fabrication(self):
        raw=json.dumps({'id':'abcdefghijk','title':'M Super Slowed','channel':'Uploader'})
        with tempfile.TemporaryDirectory() as tmp:
            svc=ExtraCatalog(tmp+'/x.db',ExtractGate(1,0),lambda *a,**kw:raw,enabled=lambda:True)
            item=svc.search('M Super Slowed')['items'][0]
            self.assertIsNone(item['artist']); self.assertEqual(item['uploader'],'Uploader')
            self.assertIsNone(item['dur']); self.assertEqual(item['version_match'],'exact')

    def test_playlist_order_not_reranked(self):
        raw='\n'.join(json.dumps({'id':v,'title':t}) for v,t in
                       [('abcdefghijk','M Ultra Slowed'),('12345678901','M Super Slowed')])
        with tempfile.TemporaryDirectory() as tmp:
            svc=ExtraCatalog(tmp+'/x.db',ExtractGate(1,0),lambda *a,**kw:raw,enabled=lambda:True)
            items=svc.playlist('PLabcdefghijklmnopqrstuv')['items']
            self.assertEqual(items[0]['id'],'abcdefghijk')

    def test_cached_page_available_during_playback(self):
        with tempfile.TemporaryDirectory() as tmp:
            svc=ExtraCatalog(tmp+'/x.db',ExtractGate(1,0),lambda *a,**kw:'',enabled=lambda:True)
            svc.search('test query')
            with SCHEDULER.acquire('playback',0):
                self.assertTrue(svc.search('test query')['cached'])
                with self.assertRaises(ExtraError) as error: svc.search('other query')
                self.assertEqual(error.exception.status,429)
                self.assertEqual(svc.stats()['runs'],1)
            self.assertFalse(svc.search('other query')['cached'])

    def test_preempted_extra_no_miss_no_cooldown(self):
        def fail(*a,**kw): raise ExtraError(429,'yielded',2)
        with tempfile.TemporaryDirectory() as tmp:
            svc=ExtraCatalog(tmp+'/x.db',ExtractGate(1,0),fail,enabled=lambda:True)
            with self.assertRaises(ExtraError): svc.search('test query')
            svc.runner=lambda *a,**kw:''
            self.assertFalse(svc.search('test query')['cached'])
            self.assertEqual(svc.stats()['failures'],0)


class MatchingTests(unittest.TestCase):
    def candidate(self, title='MONTAGEM DELÍRIO Super Slowed', dur=120):
        return dict(vid='abcdefghijk',title=title,uploader='ZXVREN - Topic',dur=dur)

    def test_hunt_stops_on_strong_first_result(self):
        with patch.object(catalog,'yt_search',return_value=[self.candidate()]) as search:
            result=catalog._hunt('MONTAGEM DELÍRIO Super Slowed','ZXVREN','ISRC',120)
            self.assertEqual(len(result),1); self.assertEqual(search.call_count,1)

    def test_weak_first_result_does_not_short_circuit(self):
        with patch.object(catalog,'yt_search',return_value=[self.candidate('unrelated',999)]) as search:
            catalog._hunt('MONTAGEM DELÍRIO Super Slowed','ZXVREN','ISRC',120)
            self.assertEqual(search.call_count,3)

    def test_super_ultra_not_match_even_same_duration(self):
        score=catalog.score(self.candidate('MONTAGEM DELÍRIO Ultra Slowed'),
                            'MONTAGEM DELÍRIO Super Slowed','ZXVREN',120)
        self.assertLess(score,catalog.WEAK)

    def test_upstream_failure_not_negative_cache(self):
        with patch.object(catalog,'cache_get',return_value=None), patch.object(catalog,'miss_get',return_value=None), \
             patch.object(catalog,'yt_search',side_effect=catalog.MatchUnavailable('failed')), \
             patch.object(catalog,'miss_put') as miss:
            with self.assertRaises(catalog.HTTPException) as error:
                catalog.match_track('Title','Artist',120)
            self.assertEqual(error.exception.status_code,503); miss.assert_not_called()

    def test_successful_empty_hunt_can_negative_cache(self):
        with patch.object(catalog,'cache_get',return_value=None), patch.object(catalog,'miss_get',return_value=None), \
             patch.object(catalog,'yt_search',return_value=[]), patch.object(catalog,'miss_put') as miss:
            with self.assertRaises(catalog.HTTPException) as error: catalog.match_track('Title','Artist',120)
            self.assertEqual(error.exception.status_code,404); miss.assert_called_once()

    def test_partial_failure_with_bad_candidates_not_negative_cache(self):
        with patch.object(catalog,'cache_get',return_value=None), patch.object(catalog,'miss_get',return_value=None), \
             patch.object(catalog,'yt_search',side_effect=[[self.candidate('random',999)],catalog.MatchUnavailable('failed')]), \
             patch.object(catalog,'miss_put') as miss:
            with self.assertRaises(catalog.HTTPException) as error: catalog.match_track('Title','Artist',120)
            self.assertEqual(error.exception.status_code,503); miss.assert_not_called()

    def test_parenthesized_versions_have_different_cache_keys(self):
        keys=[]
        with patch.object(catalog,'cache_get',side_effect=lambda key: keys.append(key) or 'abcdefghijk'):
            catalog.match_track('Song (Super Slowed)','Artist',120)
            catalog.match_track('Song (Ultra Slowed)','Artist',120)
        self.assertNotEqual(keys[0],keys[1])

    def test_match_uses_same_shared_gate_as_extra(self):
        with SCHEDULER.acquire('playback',0), patch.object(catalog,'run_text') as run:
            with self.assertRaises(ExtractBusy): catalog.yt_search('test',1,budget=.02)
            run.assert_not_called()

    def test_nonzero_exit_is_not_empty_search(self):
        with patch.object(catalog,'run_text',side_effect=ProcessError(502,'failed')):
            with self.assertRaises(catalog.MatchUnavailable): catalog.yt_search('test')
        self.assertIsNone(SCHEDULER.stats()['active'])

    def test_match_command_budget_and_no_config(self):
        with patch.object(catalog,'run_text',return_value='') as run:
            catalog.yt_search('test')
            args,kw=run.call_args
            self.assertIn('--ignore-config',args[0]); self.assertIn('--retries',args[0])
            self.assertLessEqual(kw['timeout'],5)

    def test_warm_match_has_background_priority(self):
        with patch.object(catalog,'dz_get',return_value={}), patch.object(catalog,'dz_track',return_value={
             'title':'Title','artist':'Artist','dur':120,'isrc':''}), patch.object(catalog,'match_track') as match:
            catalog._warm_one('123')
            self.assertFalse(match.call_args.kwargs['foreground'])

    def test_match_budget_stops_further_launches(self):
        times=iter([0,0,11])
        with patch.object(catalog.time,'monotonic',side_effect=lambda: next(times)), \
             patch.object(catalog,'yt_search',return_value=[]) as search:
            result=catalog._hunt('Title','Artist','ISRC',120)
        self.assertFalse(result.complete); self.assertEqual(search.call_count,1)


if __name__=='__main__': unittest.main(verbosity=2)
