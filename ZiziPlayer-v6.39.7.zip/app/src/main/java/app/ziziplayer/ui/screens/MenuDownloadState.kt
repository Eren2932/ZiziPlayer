package app.ziziplayer.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.RemoteUri
import app.ziziplayer.ui.MainViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal data class MenuDownloadState(val status: DownloadStatus, val checking: Boolean = false)

/** Live progress is memory-only; a cold storage index is NEVER checked during composition. */
@Composable
internal fun rememberMenuDownloadState(
    vm: MainViewModel,
    track: TrackEntity?,
    live: DownloadStatus?
): MenuDownloadState {
    if (track == null) return MenuDownloadState(DownloadStatus.None)
    if (!RemoteUri.isRemote(track.uri)) return MenuDownloadState(DownloadStatus.Local)
    if (live != null) return MenuDownloadState(live)
    var stored by remember(vm, track.id, track.uri) { mutableStateOf<DownloadStatus?>(null) }
    LaunchedEffect(vm, track.id, track.uri) {
        stored = try {
            withContext(Dispatchers.IO) { vm.downloadStatus(track) }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            DownloadStatus.Failed("Не удалось проверить скачанную копию")
        }
    }
    return MenuDownloadState(stored ?: DownloadStatus.None, checking = stored == null)
}
