package app.ziziplayer.ui

/** Layout decisions only: no Android, storage, player or network work. */
internal object MenuPresentation {
    fun quickColumns(availableWidthDp: Float, fontScale: Float): Int {
        val scale = if (fontScale.isFinite()) fontScale.coerceAtLeast(1f) else 1f
        return if (availableWidthDp / scale >= 320f) 4 else 2
    }

    // In landscape / large text the header scrolls too: actions must remain reachable.
    fun scrollHeader(screenHeightDp: Int, fontScale: Float): Boolean =
        screenHeightDp < 520 || fontScale > 1.3f
}
