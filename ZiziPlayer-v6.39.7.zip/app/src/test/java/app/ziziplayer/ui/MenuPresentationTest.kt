package app.ziziplayer.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MenuPresentationTest {
    @Test fun normalPhoneUsesFourActions() { assertEquals(4, MenuPresentation.quickColumns(358f, 1f)) }
    @Test fun narrowWindowUsesTwoActions() { assertEquals(2, MenuPresentation.quickColumns(280f, 1f)) }
    @Test fun largeTextUsesTwoActions() { assertEquals(2, MenuPresentation.quickColumns(358f, 1.5f)) }
    @Test fun tabletStillUsesFourActions() { assertEquals(4, MenuPresentation.quickColumns(680f, 1.5f)) }
    @Test fun boundaryIsStable() {
        assertEquals(2, MenuPresentation.quickColumns(319f, 1f))
        assertEquals(4, MenuPresentation.quickColumns(320f, 1f))
    }
    @Test fun invalidScaleHasSafeFallback() {
        assertEquals(4, MenuPresentation.quickColumns(358f, Float.NaN))
        assertEquals(4, MenuPresentation.quickColumns(358f, 0f))
    }
    @Test fun landscapeHeaderScrolls() { assertTrue(MenuPresentation.scrollHeader(400, 1f)) }
    @Test fun largeTextHeaderScrolls() { assertTrue(MenuPresentation.scrollHeader(800, 1.5f)) }
    @Test fun portraitHeaderStaysVisible() { assertFalse(MenuPresentation.scrollHeader(800, 1f)) }
}
