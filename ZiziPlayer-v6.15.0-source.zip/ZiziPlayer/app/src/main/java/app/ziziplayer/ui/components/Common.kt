package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import android.util.LruCache
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import kotlinx.coroutines.delay
// 6.14.0: компонент NowPlayingBadge читает палитру, а импорта не было — сборка падала здесь.
import app.ziziplayer.ui.theme.LocalPalette

/**
 * Custom seek bar. The stock Material slider fires a seek on every pixel of movement,
 * which is what made the play icon flicker; this one only reports the final value.
 */
@Composable
fun ZiziSlider(
    fraction: Float,
    accent: Color,
    inactive: Color,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var local by remember { mutableFloatStateOf(fraction) }
    var scrubbing by remember { mutableStateOf(false) }
    val shown = (if (scrubbing) local else fraction).coerceIn(0f, 1f)
    val density = LocalDensity.current

    Box(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            // ONE gesture detector.
            //
            // v4 attached a tap detector AND a horizontal drag detector to the same box. A short
            // finger movement satisfied both, so two different seeks were dispatched for a single
            // gesture - that is exactly the twitching when nudging the thumb a little. On top of
            // that the tap path used an absolute position while the drag path accumulated relative
            // deltas, so the two disagreed about where the finger actually was.
            //
            // Now a press, a drag and a tap are the same code path, always absolute, one seek.
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scrubbing = true
                    local = (down.position.x / widthPx).coerceIn(0f, 1f)
                    onScrubStart()
                    onScrub(local)
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val next = (change.position.x / widthPx).coerceIn(0f, 1f)
                        if (next != local) { local = next; onScrub(next) }
                        change.consume()
                    }
                    scrubbing = false
                    onScrubEnd(local)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            val trackHeight = with(density) { 5.dp.toPx() }
            val radius = trackHeight / 2f
            val centerY = size.height / 2f
            drawRoundRect(
                color = inactive,
                topLeft = Offset(0f, centerY - radius),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(radius, radius)
            )
            val filled = size.width * shown
            if (filled > 0.5f) {
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(filled, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val thumb = with(density) { (if (scrubbing) 9.dp else 7.dp).toPx() }
            // coerceIn throws when min > max, which happens the moment the bar is laid out
            // narrower than the thumb (a very small window, a 0 px first frame). A crash inside
            // the draw phase takes the whole screen down, so the bounds are ordered explicitly.
            val minX = thumb.coerceAtMost(size.width / 2f)
            val maxX = (size.width - thumb).coerceAtLeast(minX)
            drawCircle(color = accent, radius = thumb, center = Offset(filled.coerceIn(minX, maxX), centerY))
        }
    }
}

@Composable
fun PillChip(
    label: String,
    icon: ImageVector?,
    active: Boolean,
    palette: ChipColors,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val background = if (active) palette.activeBackground else palette.background
    val content = if (active) palette.activeContent else palette.content
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(19.dp))
            Box(Modifier.width(9.dp))
        }
        Text(label, color = content, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

data class ChipColors(
    val background: Color,
    val content: Color,
    val activeBackground: Color,
    val activeContent: Color
)

/** Little animated equaliser shown on the row that is currently playing. */
@Composable
fun EqualizerBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    // v3 read the animated values during composition, so this tiny widget recomposed 60 times a
    // second - and it never stopped, even on pause. Now the values are read inside the draw
    // lambda (draw-phase only) and the animation exists exclusively while something is playing.
    if (!playing) {
        Canvas(modifier) { drawEqualizerBars(color, 0.35f, 0.6f, 0.4f) }
        return
    }
    val transition = rememberInfiniteTransition(label = "eq")
    val a = transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "a")
    val b = transition.animateFloat(1f, 0.45f, infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "b")
    val c = transition.animateFloat(0.55f, 0.95f, infiniteRepeatable(tween(430), RepeatMode.Reverse), label = "c")
    Canvas(modifier) { drawEqualizerBars(color, a.value, b.value, c.value) }
}

private fun DrawScope.drawEqualizerBars(color: Color, first: Float, second: Float, third: Float) {
    // listOf(...) here allocated a list plus three boxed Floats on EVERY frame of the animation,
    // for every visible playing row. Sixty times a second, straight into the young generation.
    val barWidth = size.width / 5f
    val radius = CornerRadius(barWidth / 2f, barWidth / 2f)
    bar(color, 0f, first, barWidth, radius)
    bar(color, barWidth * 2f, second, barWidth, radius)
    bar(color, barWidth * 4f, third, barWidth, radius)
}

private fun DrawScope.bar(color: Color, x: Float, value: Float, width: Float, radius: CornerRadius) {
    val height = size.height * value
    drawRoundRect(
        color = color,
        topLeft = Offset(x, size.height - height),
        size = Size(width, height),
        cornerRadius = radius
    )
}

/**
 * Round icon button (v6.2).
 *
 * Three things were wrong before:
 *   - `RoundedCornerShape(percent = 50)` is only a circle when the box is square, and the ripple was
 *     clipped to it, so shuffle / repeat read as rounded SQUARES on press. Now: [CircleShape] plus an
 *     unbounded ripple that overshoots the bounds slightly, the way every system player does it.
 *   - there was no active state, so "shuffle on" was a tint change of a couple of percent contrast.
 *     [active] paints a soft circular wash behind the glyph.
 *   - repeat-one was distinguishable only by the tiny "1" inside the glyph. [activeDot] adds the
 *     indicator dot underneath.
 *
 * [active] and [activeDot] are trailing defaults, so every existing call site is untouched.
 */
@Composable
fun RoundIconButton(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: Int = 52,
    iconSize: Int = 24,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    activeDot: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(
                interactionSource = interaction,
                indication = ripple(bounded = false, radius = (size / 2 + 4).dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        if (active) {
            Box(
                Modifier
                    .matchParentSize()
                    .padding((size * 0.10f).dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.16f))
            )
        }
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize.dp))
        if (activeDot) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = (size * 0.13f).dp)
                    .size(3.5.dp)
                    .clip(CircleShape)
                    .background(tint)
            )
        }
    }
}

/**
 * Titles in a real library are 60 % metadata: "0_0 Slowed + Reverb", "pursuit (super slowed)",
 * "AUTOMOTIVO DO MAL V1 (Super Slowed)". The reference player renders that trailing modifier in a
 * dimmer colour, which is what makes a screen of long titles scannable instead of a wall of bold.
 *
 * The split point is cached by title string, so scrolling 3000 rows runs the regex once per unique
 * title for the whole session, never once per frame.
 */
private val DIM_TAIL = Regex(
    """[\s\-–—|(\[]*\b((?:super|ultra|mega)\s+)?(slowed|slow(?:ed)?\s*[&+]\s*reverb|sped\s*up|speed\s*up|nightcore|reverb|remix|bass\s*boosted?|extended\s*mix|instrumental|mashup|8d\s*audio|lo-?fi)\b.*$""",
    RegexOption.IGNORE_CASE
)

private val dimTailCache = LruCache<String, Int>(2048)

fun dimTailStart(title: String): Int {
    dimTailCache.get(title)?.let { return it }
    val at = DIM_TAIL.find(title)?.range?.first?.takeIf { it >= 3 } ?: -1
    dimTailCache.put(title, at)
    return at
}

@Composable
fun TrackTitle(
    title: String,
    color: Color,
    dim: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier
) {
    val split = remember(title) { dimTailStart(title) }
    // The style is built once per size instead of on every composition. Handing Text a fontSize
    // and a fontWeight separately makes it merge a fresh TextStyle each time it runs, and this
    // composable is the title of every row in a 3000 track library.
    val style = remember(fontSize, fontWeight) { TextStyle(fontSize = fontSize, fontWeight = fontWeight) }
    if (split < 0) {
        Text(
            text = title,
            color = color,
            style = style,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    } else {
        val annotated = remember(title, color, dim) {
            buildAnnotatedString {
                withStyle(SpanStyle(color = color)) { append(title.substring(0, split)) }
                withStyle(SpanStyle(color = dim)) { append(title.substring(split)) }
            }
        }
        Text(
            text = annotated,
            style = style,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    }
}

/**
 * The player title, scrolled instead of truncated.
 *
 * A 25 sp bold title on a 360 dp screen fits about 18 characters, so "KXNO1X, TREVOLX - MONTAGEM
 * ..." was simply unreadable in the one place the app is supposed to be showing it off. It now
 * travels sideways, once the reader has had time to start reading, and loops through a gap.
 *
 * Why this and not `basicMarquee`:
 *   - the text is measured ONCE with a TextMeasurer and painted with drawText, so the animation
 *     lives entirely in the draw phase - a scrolling title costs one repaint per frame and zero
 *     recompositions, which matters because this screen also repaints the backdrop every frame of
 *     a swipe;
 *   - `basicMarquee` restarts its own measurement pass and, on the foundation version this
 *     project builds against, still carries the experimental annotation.
 *
 * A title that fits is left alone - moving text that does not need to move is noise, and none of
 * the reference players do it.
 */
@Composable
fun MarqueeText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier,
    speedDpPerSecond: Float = 30f,
    startDelayMs: Long = 1500L,
    gap: Dp = 54.dp
) {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val style = remember(fontSize, fontWeight) { TextStyle(fontSize = fontSize, fontWeight = fontWeight) }
    // Measured with no width constraint at all, which is the point: this is the width the title
    // WANTS, not the width it was allowed, so the comparison below is exact.
    val layout = remember(text, style, measurer, density) {
        measurer.measure(
            text = AnnotatedString(text),
            style = style,
            softWrap = false,
            overflow = TextOverflow.Visible,
            maxLines = 1
        )
    }
    var containerWidth by remember { mutableIntStateOf(0) }
    val gapPx = with(density) { gap.roundToPx() }
    val distance = (layout.size.width + gapPx).toFloat()
    val scrolling = containerWidth > 0 && layout.size.width > containerWidth + 2
    val shift = remember { Animatable(0f) }
    val height = with(density) { layout.size.height.toDp() }

    LaunchedEffect(text, scrolling, distance) {
        shift.snapTo(0f)
        if (!scrolling) return@LaunchedEffect
        val speedPx = with(density) { speedDpPerSecond.dp.toPx() }.coerceAtLeast(1f)
        val duration = ((distance / speedPx) * 1000f).toInt().coerceIn(1500, 30_000)
        while (true) {
            delay(startDelayMs)
            shift.animateTo(distance, tween(duration, easing = LinearEasing))
            // The second copy is sitting exactly where the first one started, so the reset is
            // invisible: no rubber-band back, no flicker, the loop just continues.
            shift.snapTo(0f)
        }
    }

    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .clipToBounds()
            .onSizeChanged { containerWidth = it.width }
    ) {
        val offset = -shift.value
        drawText(layout, color = color, topLeft = Offset(offset, 0f))
        if (scrolling) drawText(layout, color = color, topLeft = Offset(offset + distance, 0f))
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}

/**
 * 6.13.0 — единый маркер «этот трек сейчас в плеере».
 *
 * Правило, которого раньше не было: СТРОКА показывает состояние, КНОПКА показывает действие.
 * Строки поиска рисовали статичный ▶ у играющего трека, а мини-плеер в этот же момент показывал
 * ⏸ (действие «поставить на паузу») — снаружи это выглядело как рассинхрон плеера.
 * Теперь у всех списков один маркер: полоски эквалайзера, живые пока играет и замершие на паузе.
 * Второй побочный выигрыш: на паузе маркер больше не исчезает, и место в списке не теряется.
 */
@Composable
fun NowPlayingBadge(
    current: Boolean,
    playing: Boolean,
    size: Dp,
    corner: Dp = 7.dp,
    barSize: Dp = size * 0.42f,
    modifier: Modifier = Modifier
) {
    if (!current) return
    val p = LocalPalette.current
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(Color.Black.copy(alpha = 0.46f)),
        contentAlignment = Alignment.Center
    ) {
        EqualizerBars(p.accent, playing, Modifier.size(barSize))
    }
}
