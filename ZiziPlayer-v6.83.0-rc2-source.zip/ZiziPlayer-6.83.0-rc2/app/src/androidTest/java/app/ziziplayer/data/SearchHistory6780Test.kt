package app.ziziplayer.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** Generated Room DAO/SQLite execution, including transaction rollback. Requires Android. */
class SearchHistory6780Test {
    private lateinit var db: ZiziDatabase
    private lateinit var dao: MusicDao
    @Before fun open() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), ZiziDatabase::class.java).build()
        dao = db.musicDao()
    }
    @After fun close() { db.close() }

    @Test fun committedQueryIsStoredInBothSurfacesAndDeduplicatesCyrillicCase() = runBlocking {
        dao.rememberSearchQuery("  МОНТАЖ  ")
        dao.rememberSearchQuery("монтаж")
        assertEquals(listOf("монтаж"), dao.searchQueryTexts())
        assertEquals("монтаж", dao.recentByKey("q:монтаж")?.title)
        assertEquals(1, dao.observeRecents().first().size)
    }
    @Test fun deletingARecentQueryAlsoRemovesAutocompleteHistory() = runBlocking {
        dao.rememberSearchQuery("montagem ranhura")
        dao.forgetSearchRecent("q:montagem ranhura")
        assertTrue(dao.searchQueryTexts().isEmpty())
        assertNull(dao.recentByKey("q:montagem ranhura"))
    }
    @Test fun clearingQueryHistoryPreservesRecentTracks() = runBlocking {
        dao.rememberSearchQuery("montagem")
        dao.rememberRecent(RecentEntity("t:one", RecentKind.TRACK, "One"))
        dao.clearSearchQueries()
        assertTrue(dao.searchQueryTexts().isEmpty())
        assertEquals(listOf("t:one"), dao.observeRecents().first().map { it.key })
    }
    @Test fun clearingAllRecentsAlsoClearsQueryHistory() = runBlocking {
        dao.rememberSearchQuery("montagem")
        dao.rememberRecent(RecentEntity("t:one", RecentKind.TRACK, "One"))
        dao.clearSearchRecents()
        assertTrue(dao.searchQueryTexts().isEmpty())
        assertTrue(dao.observeRecents().first().isEmpty())
    }
    @Test fun failedRecentInsertRollsBackHistoryInsert() = runBlocking {
        db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_recent BEFORE INSERT ON recents BEGIN SELECT RAISE(ABORT, 'test rollback'); END")
        var failed = false
        try { dao.rememberSearchQuery("montagem") } catch (_: Exception) { failed = true }
        assertTrue(failed)
        assertTrue(dao.searchQueryTexts().isEmpty())
        assertTrue(dao.observeRecents().first().isEmpty())
        db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_recent")
        dao.rememberSearchQuery("montagem")
        assertEquals(listOf("montagem"), dao.searchQueryTexts())
    }
    @Test fun shortQueryIsIgnoredAndHistoryRemainsBounded() = runBlocking {
        dao.rememberSearchQuery("m")
        assertTrue(dao.searchQueryTexts().isEmpty())
        for (i in 0..40) dao.rememberSearchQuery("montagem $i")
        assertEquals(20, dao.searchQueryTexts().size)
        assertEquals(30, dao.observeRecents().first().size)
    }
}
