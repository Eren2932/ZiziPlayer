package app.ziziplayer.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Actual generated Room DAO/SQLite tests. Run on Android, not the offline suite. */
class CollectionRemoval6770Test {
    private lateinit var db: ZiziDatabase
    private lateinit var dao: MusicDao
    @Before fun open() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), ZiziDatabase::class.java).build()
        dao = db.musicDao()
    }
    @After fun close() { db.close() }

    private suspend fun link(owned: Boolean, ids: List<String>): PlaylistLinkEntity {
        val playlist = dao.createPlaylist(PlaylistEntity(name = "Destination"))
        dao.addTracksToPlaylist(playlist, ids)
        return PlaylistLinkEntity("dz:album:1", playlist, "Album", owned, linkedAt = 1L).also { dao.linkCollection(it) }
    }

    @Test fun ownedRemovalCleansAllLinksAndMembership() = runBlocking {
        val expected = link(true, listOf("a", "b"))
        dao.linkCollection(expected.copy(collectionKey = "dz:album:2", owned = false))
        assertTrue(dao.removeLinkedCollection(expected, emptyList()))
        assertNull(dao.playlistById(expected.playlistId))
        assertNull(dao.collectionLink("dz:album:1"))
        assertNull(dao.collectionLink("dz:album:2"))
        assertTrue(dao.playlistTrackIds(expected.playlistId).isEmpty())
        assertFalse(dao.removeLinkedCollection(expected, emptyList()))
    }

    @Test fun nonOwnedRemovalPreservesOtherTracksAndOtherPlaylists() = runBlocking {
        val expected = link(false, listOf("a", "b", "keep"))
        val other = dao.createPlaylist(PlaylistEntity(name = "Other"))
        dao.addTracksToPlaylist(other, listOf("a", "b"))
        assertTrue(dao.removeLinkedCollection(expected, listOf("a", "b", "missing")))
        assertEquals(listOf("keep"), dao.playlistTrackIds(expected.playlistId))
        assertEquals(setOf("a", "b"), dao.playlistTrackIds(other).toSet())
        assertNull(dao.collectionLink(expected.collectionKey))
    }

    @Test fun staleConfirmationNeverRemovesReboundLink() = runBlocking {
        val expected = link(true, listOf("a"))
        val newer = expected.copy(linkedAt = 2L)
        dao.linkCollection(newer)
        assertFalse(dao.removeLinkedCollection(expected, emptyList()))
        assertEquals(newer, dao.collectionLink(expected.collectionKey))
        assertEquals(listOf("a"), dao.playlistTrackIds(expected.playlistId))
    }

    @Test fun unloadedNonOwnedSelectionCannotUnlink() = runBlocking {
        val expected = link(false, listOf("a"))
        var failed = false
        try { dao.removeLinkedCollection(expected, emptyList()) } catch (_: IllegalArgumentException) { failed = true }
        assertTrue(failed)
        assertEquals(expected, dao.collectionLink(expected.collectionKey))
        assertEquals(listOf("a"), dao.playlistTrackIds(expected.playlistId))
    }

    @Test fun chunkedRemovalRollsBackEarlierChunksOnSqlFailure() = runBlocking {
        val ids = (0..1200).map { "t$it" }
        val expected = link(false, ids)
        db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_delete BEFORE DELETE ON playlist_tracks WHEN OLD.trackId = 't700' BEGIN SELECT RAISE(ABORT, 'test rollback'); END")
        var failed = false
        try { dao.removeLinkedCollection(expected, ids) } catch (_: Exception) { failed = true }
        assertTrue(failed)
        assertEquals(ids.toSet(), dao.playlistTrackIds(expected.playlistId).toSet())
        assertEquals(expected, dao.collectionLink(expected.collectionKey))
        db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_delete")
        assertTrue(dao.removeLinkedCollection(expected, ids))
        assertTrue(dao.playlistTrackIds(expected.playlistId).isEmpty())
    }
}
