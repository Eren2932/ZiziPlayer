#!/usr/bin/env python3
"""Контракты 6.41.2 — исправление сборки 6.41.1.

Сборка #406 упала одной строкой компилятора:

    app/src/main/java/app/ziziplayer/ui/screens/LibraryScreen.kt:1212:45
    Unresolved reference 'LocalDensity'.

Тестов не падало ни одного: задача :app:compileDebugKotlin не дожила до них. Здесь
закреплено и само исправление, и то, из-за чего оно вообще стало возможным — проверка
импортов знала только объявления проекта и библиотечное имя пропускала молча.

Это НЕ сборка Android, не Compose-отрисовка и не исполнение Kotlin.
"""
import pathlib
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
TOOLS = ROOT / 'tools'


def read(rel):
    return (SRC / rel).read_text(encoding='utf-8')


class Mobile6412Contracts(unittest.TestCase):

    def test_the_regression_itself_is_fixed(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('import androidx.compose.ui.platform.LocalDensity', s)
        self.assertIn('LocalDensity.current.fontScale', s)
        # Звёздочка runtime остаётся и НЕ считается покрытием для ui.platform.
        self.assertIn('import androidx.compose.runtime.*', s)

    def test_every_composition_local_in_the_app_is_reachable(self):
        """Проверка импортов проходит по всему main и возвращает 0."""
        out = subprocess.run(
            [sys.executable, str(TOOLS / 'check_imports.py'), 'app/src/main'],
            cwd=ROOT, capture_output=True, text=True, check=False)
        self.assertEqual(0, out.returncode, out.stdout + out.stderr)
        self.assertIn('проблем: 0', out.stdout)

    def test_the_instrument_reproduces_this_very_failure(self):
        """Фикстура: composition local из ui.platform под одной звёздочкой runtime."""
        with tempfile.TemporaryDirectory(prefix='zizi-6412-') as work:
            pkg = pathlib.Path(work) / 'app/src/main/java/app/ziziplayer/ui'
            pkg.mkdir(parents=True)
            (pkg / 'Fixture.kt').write_text(
                'package app.ziziplayer.ui\n'
                'import androidx.compose.runtime.*\n'
                '@Composable fun Fixture() {\n'
                '    val scale = LocalDensity.current.fontScale\n'
                '}\n', encoding='utf-8')
            out = subprocess.run(
                [sys.executable, str(TOOLS / 'check_imports.py'), 'app/src/main'],
                cwd=work, capture_output=True, text=True, check=False)
        self.assertEqual(1, out.returncode, out.stdout + out.stderr)
        self.assertIn('LocalDensity', out.stdout)
        self.assertIn('androidx.compose.ui.platform', out.stdout)

    def test_guard_does_not_fire_on_a_correct_file(self):
        with tempfile.TemporaryDirectory(prefix='zizi-6412-') as work:
            pkg = pathlib.Path(work) / 'app/src/main/java/app/ziziplayer/ui'
            pkg.mkdir(parents=True)
            (pkg / 'Fixture.kt').write_text(
                'package app.ziziplayer.ui\n'
                'import androidx.compose.runtime.*\n'
                'import androidx.compose.ui.platform.LocalDensity\n'
                '@Composable fun Fixture() {\n'
                '    val scale = LocalDensity.current.fontScale\n'
                '}\n', encoding='utf-8')
            out = subprocess.run(
                [sys.executable, str(TOOLS / 'check_imports.py'), 'app/src/main'],
                cwd=work, capture_output=True, text=True, check=False)
        self.assertEqual(0, out.returncode, out.stdout + out.stderr)
        # Своё объявление с тем же именем тоже снимает подозрение.
        with tempfile.TemporaryDirectory(prefix='zizi-6412-') as work:
            pkg = pathlib.Path(work) / 'app/src/main/java/app/ziziplayer/ui'
            pkg.mkdir(parents=True)
            (pkg / 'Own.kt').write_text(
                'package app.ziziplayer.ui\n'
                'import androidx.compose.runtime.*\n'
                'val LocalDensity = staticCompositionLocalOf<Int> { 0 }\n'
                'fun use(): Int = LocalDensity.current\n', encoding='utf-8')
            out = subprocess.run(
                [sys.executable, str(TOOLS / 'check_imports.py'), 'app/src/main'],
                cwd=work, capture_output=True, text=True, check=False)
        self.assertEqual(0, out.returncode, out.stdout + out.stderr)

    def test_jvm_tests_do_not_depend_on_android_stubs(self):
        """6.41.1 впервые завела JVM-тесты на классах Media3."""
        gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
        self.assertIn('unitTests.isReturnDefaultValues = true', gradle)
        self.assertIn('testImplementation("junit:junit:4.13.2")', gradle)

    def test_build_identity_and_preflight_wiring(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
        self.assertIn('versionCode = 95', gradle)
        self.assertIn('versionName = "6.46.1"', gradle)
        self.assertIn('applicationId = "app.ziziplayer"', gradle)
        selftest = (TOOLS / 'check_selftest.py').read_text(encoding='utf-8')
        self.assertIn('test_mobile_6412_contracts.py', selftest)

    def test_nothing_from_6411_was_rolled_back(self):
        """Единственная правка кода — импорт: метр, поиск и капсула не тронуты."""
        lib = read('ui/screens/LibraryScreen.kt')
        self.assertIn('MINI_HEIGHT + 32.dp', lib)
        self.assertIn('ZiziSpectrum.publish', read('playback/dsp/ZiziAudioProcessor.kt'))
        self.assertIn('uiVisible && playbackActive', read('playback/dsp/ZiziSpectrum.kt'))
        self.assertTrue((ROOT / 'app/src/test/java/app/ziziplayer/playback/dsp/'
                         'ZiziAudioProcessorTest.kt').exists())
        self.assertTrue((ROOT / 'app/src/test/java/app/ziziplayer/playback/dsp/'
                         'PcmSpectrumChecks.java').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
