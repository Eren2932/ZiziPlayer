package app.ziziplayer.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.unit.dp

/**
 * Свои глифы транспорта (6.18.0).
 *
 * Почему не Material. `Icons.Rounded.Shuffle` и `Icons.Rounded.Repeat` — рисунок 2014 года:
 * ломаные под 45°, стыки «палками», плотность линий не совпадает с соседними кнопками. Рядом с
 * крупным круглым Play они читаются как чужие — ровно то, на что жаловался тестер.
 *
 * Здесь оба знака нарисованы обводкой, а не залитым контуром:
 *   - один вес линии (2.05 из 24) на весь набор, поэтому «перемешать» и «повторять» выглядят
 *     частями одного шрифта, а не иконками из разных пачек;
 *   - круглые торцы и стыки убирают острые углы — те самые «палки»;
 *   - shuffle построен на кубических кривых: линии перетекают друг в друга, а не пересекаются
 *     углом;
 *   - repeat — настоящее кольцо (дуга 300°) с разрывом сверху и стрелкой в разрыве, вместо
 *     скруглённого прямоугольника Material.
 *
 * Заливка не задаётся (fill = null): Icon красит вектор ColorFilter'ом, поэтому tint, акцент темы
 * и подсветка активного режима работают точно так же, как с любой иконкой Material.
 *
 * Векторы собираются один раз лениво: ImageVector неизменяем, а пересборка на каждой
 * рекомпозиции — это лишний VectorPainter на каждом кадре.
 */
object ZiziIcons {

    private const val STROKE = 2.05f

    private fun stroked(name: String, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
                pathBuilder = pathBuilder
            )
        }.build()

    /**
     * «Перемешать»: две S-образные линии меняются местами, обе со стрелкой вправо.
     * Кривые симметричны относительно центра, поэтому знак остаётся уравновешенным и в 23 dp.
     */
    val Shuffle: ImageVector by lazy {
        stroked("zizi_shuffle") {
            moveTo(3.4f, 7.6f)
            lineTo(6.2f, 7.6f)
            curveTo(9.8f, 7.6f, 11.4f, 16.4f, 15.0f, 16.4f)
            lineTo(19.0f, 16.4f)

            moveTo(3.4f, 16.4f)
            lineTo(6.2f, 16.4f)
            curveTo(9.8f, 16.4f, 11.4f, 7.6f, 15.0f, 7.6f)
            lineTo(19.0f, 7.6f)

            // Наконечники: вершина совпадает с концом линии, поэтому стык не виден.
            moveTo(16.6f, 5.2f); lineTo(19.4f, 7.6f); lineTo(16.6f, 10.0f)
            moveTo(16.6f, 14.0f); lineTo(19.4f, 16.4f); lineTo(16.6f, 18.8f)
        }
    }

    /** «Повторять»: кольцо с разрывом сверху и стрелкой, входящей в разрыв. */
    val Repeat: ImageVector by lazy { stroked("zizi_repeat") { ring() } }

    /** «Повторять один»: то же кольцо и «1» внутри — состояние видно без отдельного индикатора. */
    val RepeatOne: ImageVector by lazy {
        stroked("zizi_repeat_one") {
            ring()
            moveTo(10.4f, 10.7f); lineTo(12.0f, 9.2f); lineTo(12.0f, 15.2f)
        }
    }

    /**
     * Дуга 300° радиуса 7.4 вокруг центра (12, 12): от θ = −60° по часовой до θ = 240°.
     * Координаты посчитаны, а не подобраны на глаз, поэтому разрыв ровно по центру сверху, а
     * наконечник стоит по касательной к концу дуги, а не «примерно рядом».
     */
    private fun PathBuilder.ring() {
        moveTo(15.7f, 5.59f)
        // радиусы, поворот, длинная дуга, по часовой, конечная точка
        arcTo(7.4f, 7.4f, 0f, true, true, 8.3f, 5.59f)
        moveTo(5.11f, 5.31f); lineTo(8.3f, 5.59f); lineTo(6.95f, 8.49f)
    }
}
