"""Short-lived ticket for the realtime chat daemon (zizi-chat), Accounts 1.4.

The chat daemon never touches accounts.sqlite and never sees JWTs or cookies. The client first asks THIS
service (full session check: signature, revocation, disabled flag) for a ticket, then opens the WebSocket
with ``X-Zizi-Ticket: <ticket>``. The ticket is an HMAC-SHA256 envelope over a small JSON payload, valid
for 60 seconds. The shared secret lives only in the two env files (accounts.env, chat.env), never in the APK.

Wire format (must stay byte-identical with chat_server/chatlib.py):
    ticket = b64url(payload_json) + "." + b64url(HMAC_SHA256(secret, b"zizi-chat-ticket\\0" + b64url(payload_json)))
Payload keys: v=1, u=user id, n=display name (<=32), r=role, pr=profile revision, cr=account created (unix),
iat, exp, j=random id, dv=1 only for the developer (Accounts 1.5; older daemons ignore the key).

Accounts 1.5 also owns everything about the channel that is NOT a message: who the staff are, and the channel avatar.
The chat daemon stays blob-free; clients ask THIS service (`channel`, `channel_set`) and the daemon only nudges them
with a revision number when the avatar changes.

Staff kinds: ``dev`` (the developer, picked by ``ZIZI_DEV_EMAILS``, never by a flag a client can send) and ``mod``
(``users.role = 'admin'``, set with ``manage.py role``). The developer is always a chat moderator too.
"""
import base64
import hashlib
import hmac
import json
import re
import secrets
import unicodedata

from core import AuthError
import profiles

TICKET_SECONDS = 60
MIN_SECRET = 32
NAME_MAX = 32
AVATAR_BATCH = 4          # avatars are up to ~400 KB of base64 each: small batches keep one response under ~1.6 MB
UID_RE = re.compile(r'^[0-9a-f]{32}$')
CHANNEL = 'g'
CHANNEL_TITLE = 'Общий'
STAFF_MAX = 50
REV_MAX = 10 ** 9

SCHEMA = '''
CREATE TABLE IF NOT EXISTS chat_channel(
 ch TEXT PRIMARY KEY, avatar TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 0,
 by TEXT NOT NULL DEFAULT '', ts INTEGER NOT NULL DEFAULT 0);
'''


def ensure(accounts):
    with accounts.connection() as c:
        c.executescript(SCHEMA)


def parse_dev_emails(raw):
    """`ZIZI_DEV_EMAILS="a@x.org, b@y.org"` -> frozenset of lower-case addresses. Garbage entries are dropped."""
    out = set()
    for part in re.split(r'[,;\s]+', raw or ''):
        part = part.strip().lower()
        if part and '@' in part and len(part) <= 254:
            out.add(part)
    return frozenset(out)


def staff_kind(email, role, devs):
    """'dev' | 'mod' | ''. Only verified, enabled accounts get here (callers filter)."""
    if (email or '').strip().lower() in devs:
        return 'dev'
    return 'mod' if role == 'admin' else ''


def _b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')


def sign(secret, body):
    mac = hmac.new(secret.encode('utf-8'), b'zizi-chat-ticket\0' + body.encode('ascii'), hashlib.sha256).digest()
    return _b64(mac)


def display_name(raw, uid):
    """What other people see. Never an e-mail; falls back to a stable short handle."""
    text = unicodedata.normalize('NFC', raw or '')
    text = ''.join(ch if not unicodedata.category(ch).startswith('C') else ' ' for ch in text)
    text = ' '.join(text.split())[:NAME_MAX].strip()
    if text:
        return text
    return 'Zizi-' + hashlib.sha256(uid.encode('utf-8')).hexdigest()[:4]


def issue(accounts, user, secret, devs=frozenset()):
    """`user` is the dict returned by Accounts.authenticate()['user']. `devs`: see parse_dev_emails."""
    if not isinstance(secret, str) or len(secret) < MIN_SECRET:
        raise AuthError('chat_not_configured', 503)
    uid = user['id']
    with accounts.connection() as c:
        profile = c.execute('SELECT name, revision FROM account_profiles WHERE uid=?', (uid,)).fetchone()
        row = c.execute('SELECT role, created, verified, email FROM users WHERE id=? AND disabled=0', (uid,)).fetchone()
    if not row or not row['verified']:
        raise AuthError('forbidden', 403)
    now = accounts.now()
    kind = staff_kind(row['email'], row['role'], devs)
    payload = {'v': 1, 'u': uid, 'n': display_name(profile['name'] if profile else '', uid),
               'r': 'admin' if kind else row['role'],      # the developer moderates even before anybody ran manage.py
               'pr': int(profile['revision']) if profile else 0, 'cr': int(row['created']),
               'iat': now, 'exp': now + TICKET_SECONDS, 'j': secrets.token_hex(8)}
    if kind == 'dev':
        payload['dv'] = 1
    body = _b64(json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode('utf-8'))
    return {'ticket': body + '.' + sign(secret, body), 'exp': payload['exp'], 'me': uid, 'name': payload['n'],
            'kind': kind}


def avatars(accounts, payload):
    """Avatars of chat participants, for the client's local cache (Accounts 1.4.1).

    Request:  {"uids": [<=4 user ids], "known": {uid: revision the client already holds}}
    Response: {"items": [{"u": uid, "rev": profile revision, "a": base64 avatar}]}  ("a" is left out when the client's
    revision is current, so a refresh of an unchanged avatar costs ~60 bytes; "" means the user has no avatar).

    Any signed-in user may ask: the avatar is exactly what the chat shows next to the person's messages anyway, user ids
    are 128-bit random values that are only learned from the chat itself, and the caller is rate limited by the route.
    """
    if not isinstance(payload, dict) or not set(payload) <= {'uids', 'known'}:
        raise AuthError('bad_request', 400)
    uids = payload.get('uids')
    known = payload.get('known', {})
    if not isinstance(uids, list) or not 1 <= len(uids) <= AVATAR_BATCH or not isinstance(known, dict):
        raise AuthError('bad_request', 400)
    if not all(isinstance(u, str) and UID_RE.match(u) for u in uids):
        raise AuthError('bad_request', 400)
    uids = list(dict.fromkeys(uids))
    have = {k: v for k, v in known.items() if k in uids and isinstance(v, int) and not isinstance(v, bool)}
    marks = ','.join('?' * len(uids))
    with accounts.connection() as c:
        rows = {r['uid']: r for r in c.execute(
            'SELECT uid, avatar, revision FROM account_profiles WHERE uid IN (' + marks + ')', uids)}
    items = []
    for u in uids:
        row = rows.get(u)
        rev = int(row['revision']) if row else 0
        item = {'u': u, 'rev': rev}
        if have.get(u) != rev:
            item['a'] = (row['avatar'] or '') if row else ''
        items.append(item)
    return {'items': items}


def _kind_of(accounts, uid, devs):
    with accounts.connection() as c:
        row = c.execute('SELECT email, role FROM users WHERE id=? AND verified=1 AND disabled=0', (uid,)).fetchone()
    if not row:
        raise AuthError('forbidden', 403)
    return staff_kind(row['email'], row['role'], devs)


def _channel_row(c):
    row = c.execute('SELECT avatar, revision FROM chat_channel WHERE ch=?', (CHANNEL,)).fetchone()
    return (row['avatar'] or '', int(row['revision'])) if row else ('', 0)


def staff(accounts, devs):
    """Developer first, then moderators by name. Only what everybody may see: id, display name, kind, profile revision."""
    marks = ','.join('?' * len(devs)) if devs else "''"
    sql = ('SELECT u.id, u.email, u.role, COALESCE(p.name, \'\') AS name, COALESCE(p.revision, 0) AS rev '
           'FROM users u LEFT JOIN account_profiles p ON p.uid = u.id '
           'WHERE u.verified=1 AND u.disabled=0 AND (u.role=\'admin\' OR lower(u.email) IN (' + marks + ')) LIMIT ?')
    with accounts.connection() as c:
        rows = c.execute(sql, (*sorted(devs), STAFF_MAX * 2)).fetchall()
    out = []
    for r in rows:
        kind = staff_kind(r['email'], r['role'], devs)
        if kind:
            out.append({'u': r['id'], 'n': display_name(r['name'], r['id']), 'k': kind, 'pr': int(r['rev'])})
    out.sort(key=lambda x: (x['k'] != 'dev', x['n'].lower(), x['u']))
    return out[:STAFF_MAX]


def channel(accounts, user, payload, devs=frozenset()):
    """What the client needs to draw the channel window.

    Request:  {"known": <avatar revision the client already holds>}  (optional)
    Response: {"title", "rev", "avatar"?, "staff": [{u, n, k: dev|mod, pr}], "kind": my kind}
    "avatar" is left out when the client's revision is current, and "" means the channel has no picture.
    """
    if not isinstance(payload, dict) or not set(payload) <= {'known'}:
        raise AuthError('bad_request', 400)
    known = payload.get('known', -1)
    if not isinstance(known, int) or isinstance(known, bool) or not -1 <= known <= REV_MAX:
        raise AuthError('bad_request', 400)
    with accounts.connection() as c:
        avatar, rev = _channel_row(c)
    out = {'title': CHANNEL_TITLE, 'rev': rev, 'staff': staff(accounts, devs),
           'kind': _kind_of(accounts, user['id'], devs)}
    if known != rev:
        out['avatar'] = avatar
    return out


def channel_set(accounts, user, payload, devs=frozenset()):
    """Change the channel avatar. Developer and moderators only; the picture rules are the profile picture rules.

    Request:  {"avatar": base64 PNG or "" to remove, "expected_revision": "<digits>"}  (optimistic concurrency)
    Response: {"rev", "avatar"}. The chat daemon is nudged by the moderator's client (`chrev`), not by this service.
    """
    if not isinstance(payload, dict) or set(payload) != {'avatar', 'expected_revision'} \
            or any(not isinstance(v, str) for v in payload.values()):
        raise AuthError('bad_request', 400)
    if not _kind_of(accounts, user['id'], devs):
        raise AuthError('forbidden', 403)
    rev = payload['expected_revision']
    if not rev.isascii() or not rev.isdigit() or len(rev) > 12:
        raise AuthError('invalid_revision', 400)
    avatar = profiles.validate_avatar(payload['avatar'])
    with accounts.transaction() as c:
        current, revision = _channel_row(c)
        if avatar == current:
            return {'rev': revision, 'avatar': current}
        if int(rev) != revision:
            raise AuthError('channel_conflict', 409)
        revision += 1
        c.execute('INSERT INTO chat_channel(ch, avatar, revision, by, ts) VALUES(?,?,?,?,?) '
                  'ON CONFLICT(ch) DO UPDATE SET avatar=excluded.avatar, revision=excluded.revision, by=excluded.by, ts=excluded.ts',
                  (CHANNEL, avatar, revision, user['id'], accounts.now()))
    return {'rev': revision, 'avatar': avatar}
