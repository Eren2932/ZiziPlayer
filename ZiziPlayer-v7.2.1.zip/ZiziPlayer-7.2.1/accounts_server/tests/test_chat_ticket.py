"""Chat ticket endpoint (Accounts 1.4): auth, rate limit, payload contents, secret handling, daemon compatibility."""
import base64
import binascii
import json
import os
import struct
import sys
import unittest
import zlib

import test_accounts as existing
from core import AuthError
from web import ACCESS_COOKIE, Application
import chat_ticket

SECRET = 'unit-test-secret-0123456789abcdef0123456789'
DEV = existing.EMAIL


def png(side=8, shade=0x40):
    """A minimal valid RGB PNG the profile validator accepts."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', binascii.crc32(kind + data) & 0xffffffff)
    rows = b''.join(b'\x00' + bytes([shade, 0x90, 0xd0]) * side for _ in range(side))
    raw = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', side, side, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b''))
    return base64.b64encode(raw).decode('ascii')


def payload_of(ticket):
    body = ticket.split('.')[0]
    return json.loads(base64.urlsafe_b64decode(body + '=' * (-len(body) % 4)))


class ChatTicketTest(unittest.TestCase):
    setUpClass = classmethod(existing.AccountsTest.setUpClass.__func__)
    setUp = existing.AccountsTest.setUp
    verified = existing.AccountsTest.verified
    http = existing.AccountsTest.http

    def app(self, secret=SECRET, devs=()):
        self.web = Application(self.a, 'https://accounts.example.org', lambda *args: None, chat_secret=secret,
                               dev_emails=chat_ticket.parse_dev_emails(','.join(devs)))

    def user(self):
        p = self.verified()
        return p, ACCESS_COOKIE + '=' + p['access']

    def second_user(self):
        code = self.a.register('other@example.org', existing.PASSWORD)
        self.a.redeem(code, 'verify')
        return ACCESS_COOKIE + '=' + self.a.login('other@example.org', existing.PASSWORD)['access']

    def test_requires_login_and_secret(self):
        self.app()
        self.assertEqual(self.http('/auth/chat/ticket', {})[0], 401)
        _, jar = self.user()
        self.app('')
        status, _, body = self.http('/auth/chat/ticket', {}, jar=jar)
        self.assertEqual(status, 503)
        self.app('short')
        self.assertEqual(self.http('/auth/chat/ticket', {}, jar=jar)[0], 503)

    def test_ticket_contents_and_ttl(self):
        self.app()
        p, jar = self.user()
        status, _, body = self.http('/auth/chat/ticket', {}, jar=jar)
        self.assertEqual(status, 200)
        pl = payload_of(body['ticket'])
        self.assertEqual((pl['v'], pl['u'], pl['r'], pl['exp'] - pl['iat']), (1, p['user']['id'], 'user', 60))
        self.assertEqual(body['me'], p['user']['id'])
        self.assertRegex(pl['n'], r'^Zizi-[0-9a-f]{4}$')               # no profile yet: stable handle, never the e-mail
        self.assertNotIn('@', json.dumps(pl))
        self.assertEqual(body['ticket'].split('.')[1], chat_ticket.sign(SECRET, body['ticket'].split('.')[0]))
        again = self.http('/auth/chat/ticket', {}, jar=jar)[2]
        self.assertNotEqual(again['ticket'], body['ticket'])           # random jti

    def test_profile_name_is_used(self):
        self.app()
        p, jar = self.user()
        self.http('/auth/profile', {'name': 'Томиока  Гию', 'avatar': '', 'expected_revision': '0'}, jar=jar)
        pl = payload_of(self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket'])
        self.assertEqual((pl['n'], pl['pr']), ('Томиока Гию', 1))

    def test_rate_limit(self):
        self.app()
        _, jar = self.user()
        codes = [self.http('/auth/chat/ticket', {}, jar=jar)[0] for _ in range(22)]
        self.assertEqual(codes[:20], [200] * 20)
        self.assertEqual(set(codes[20:]), {429})

    def test_display_name_rules(self):
        uid = 'a' * 32
        self.assertEqual(chat_ticket.display_name('  A\u0000\n B  ', uid), 'A B')
        self.assertEqual(len(chat_ticket.display_name('x' * 99, uid)), 32)
        self.assertRegex(chat_ticket.display_name('', uid), r'^Zizi-[0-9a-f]{4}$')
        self.assertEqual(chat_ticket.display_name('\u200f\u0007', uid)[:5], 'Zizi-')

    def test_daemon_accepts_what_accounts_issues(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'chat_server'))
        import chatlib
        self.app()
        p, jar = self.user()
        ticket = self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket']
        got = chatlib.verify_ticket(SECRET, ticket, self.now, {})
        self.assertEqual((got['u'], got['r']), (p['user']['id'], 'user'))

    # ---- 1.4.1: avatars of chat participants -------------------------------------------------------------------

    def set_profile(self, jar, name, avatar):
        """Profile through the real route (revision rules apply); avatar is written straight into the row, the PNG
        validation of the profile route is covered by its own tests."""
        self.http('/auth/profile', {'name': name, 'avatar': '', 'expected_revision': '0'}, jar=jar)
        uid = self.http('/auth/chat/ticket', {}, jar=jar)[2]['me']
        with self.a.connection() as c:
            c.execute('UPDATE account_profiles SET avatar=? WHERE uid=?', (avatar, uid))
        return uid

    def test_avatars_payload_known_revision_and_missing(self):
        self.app()
        _, jar = self.user()
        other = self.second_user()
        uid = self.set_profile(other, 'Томиока', 'QUJD')
        ghost = 'f' * 32
        status, _, body = self.http('/auth/chat/avatars', {'uids': [uid, ghost]}, jar=jar)
        self.assertEqual(status, 200)
        self.assertEqual(body['items'], [{'u': uid, 'rev': 1, 'a': 'QUJD'}, {'u': ghost, 'rev': 0, 'a': ''}])
        self.assertRegex(body['me'], r'^[0-9a-f]{32}$')
        again = self.http('/auth/chat/avatars', {'uids': [uid, ghost], 'known': {uid: 1, ghost: 0}}, jar=jar)[2]
        self.assertEqual(again['items'], [{'u': uid, 'rev': 1}, {'u': ghost, 'rev': 0}])      # nothing re-sent
        stale = self.http('/auth/chat/avatars', {'uids': [uid], 'known': {uid: 0}}, jar=jar)[2]
        self.assertEqual(stale['items'], [{'u': uid, 'rev': 1, 'a': 'QUJD'}])

    def test_avatars_validation_and_auth(self):
        self.app()
        self.assertEqual(self.http('/auth/chat/avatars', {'uids': ['a' * 32]})[0], 401)
        _, jar = self.user()
        good = 'a' * 32
        for bad in ({}, {'uids': []}, {'uids': [good] * 5}, {'uids': ['A' * 32]}, {'uids': ["x'--"]}, {'uids': [1]},
                    {'uids': good}, {'uids': [good], 'known': []}, {'uids': [good], 'extra': 1}):
            self.assertEqual(self.http('/auth/chat/avatars', bad, jar=jar)[0], 400, bad)
        dup = self.http('/auth/chat/avatars', {'uids': [good, good], 'known': {good: True, 'z': 1}}, jar=jar)
        self.assertEqual((dup[0], dup[2]['items']), (200, [{'u': good, 'rev': 0, 'a': ''}]))   # dedupe, bool is not a revision

    def test_avatars_rate_limit(self):
        self.app()
        _, jar = self.user()
        codes = [self.http('/auth/chat/avatars', {'uids': ['a' * 32]}, jar=jar)[0] for _ in range(62)]
        self.assertEqual(codes[:60], [200] * 60)
        self.assertEqual(set(codes[60:]), {429})

    # ---- 1.5: developer, moderators, channel avatar --------------------------------------------------------------

    def make_mod(self, email='mod@example.org', name='Модератор'):
        code = self.a.register(email, existing.PASSWORD)
        self.a.redeem(code, 'verify')
        jar = ACCESS_COOKIE + '=' + self.a.login(email, existing.PASSWORD)['access']
        self.http('/auth/profile', {'name': name, 'avatar': '', 'expected_revision': '0'}, jar=jar)
        with self.a.connection() as c:
            c.execute('UPDATE users SET role=? WHERE email=?', ('admin', email))
        return jar

    def test_dev_email_parsing(self):
        self.assertEqual(chat_ticket.parse_dev_emails(' A@X.org, b@y.org;junk  c@z.org '),
                         frozenset({'a@x.org', 'b@y.org', 'c@z.org'}))
        self.assertEqual(chat_ticket.parse_dev_emails(''), frozenset())
        self.assertEqual(chat_ticket.parse_dev_emails(None), frozenset())

    def test_developer_ticket_has_flag_and_admin_role_without_manage_py(self):
        self.app(devs=(DEV.upper(),))                       # the list is case-insensitive
        p, jar = self.user()
        got = self.http('/auth/chat/ticket', {}, jar=jar)[2]
        pl = payload_of(got['ticket'])
        self.assertEqual((pl['r'], pl.get('dv'), got['kind']), ('admin', 1, 'dev'))
        self.assertNotIn('@', json.dumps(pl))
        with self.a.connection() as c:                      # the DB role is untouched: the flag comes from the environment
            self.assertEqual(c.execute('SELECT role FROM users WHERE id=?', (p['user']['id'],)).fetchone()[0], 'user')

    def test_plain_user_and_mod_tickets(self):
        self.app(devs=('someone-else@example.org',))
        _, jar = self.user()
        pl = payload_of(self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket'])
        self.assertEqual((pl['r'], 'dv' in pl), ('user', False))
        mod = self.make_mod()
        got = self.http('/auth/chat/ticket', {}, jar=mod)[2]
        self.assertEqual((payload_of(got['ticket'])['r'], 'dv' in payload_of(got['ticket']), got['kind']), ('admin', False, 'mod'))

    def test_unverified_email_never_becomes_developer(self):
        self.app(devs=('ghost@example.org',))
        self.a.register('ghost@example.org', existing.PASSWORD)          # registered, e-mail never confirmed
        with self.a.connection() as c:
            self.assertEqual(c.execute("SELECT verified FROM users WHERE email='ghost@example.org'").fetchone()[0], 0)
        self.assertEqual(chat_ticket.staff(self.a, frozenset({'ghost@example.org'})), [])

    def test_daemon_accepts_developer_ticket(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'chat_server'))
        import chatlib
        self.app(devs=(DEV,))
        p, jar = self.user()
        got = chatlib.verify_ticket(SECRET, self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket'], self.now, {})
        self.assertEqual((got['u'], got['r'], got['dv']), (p['user']['id'], 'admin', 1))

    def test_channel_staff_list_developer_first(self):
        self.app(devs=(DEV,))
        p, jar = self.user()
        self.http('/auth/profile', {'name': 'Разработчик', 'avatar': '', 'expected_revision': '0'}, jar=jar)
        self.make_mod('b@example.org', 'Борис')
        self.make_mod('a@example.org', 'Аня')
        status, _, body = self.http('/auth/chat/channel', {}, jar=jar)
        self.assertEqual(status, 200)
        self.assertEqual([(x['n'], x['k']) for x in body['staff']], [('Разработчик', 'dev'), ('Аня', 'mod'), ('Борис', 'mod')])
        self.assertEqual((body['title'], body['rev'], body['kind'], body['avatar'], body['me']), ('Общий', 0, 'dev', '', p['user']['id']))
        for item in body['staff']:
            self.assertEqual(set(item), {'u', 'n', 'k', 'pr'})          # nothing private: no e-mail, no role names
        self.assertNotIn('@', json.dumps(body))

    def test_channel_visible_to_every_user_and_known_revision(self):
        self.app(devs=(DEV,))
        _, dev = self.user()
        reader = self.second_user()
        self.assertEqual(self.http('/auth/chat/channel', {})[0], 401)
        body = self.http('/auth/chat/channel', {}, jar=reader)[2]
        self.assertEqual(body['kind'], '')
        pic = png()
        set_ = self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'}, jar=dev)
        self.assertEqual((set_[0], set_[2]['rev'], set_[2]['avatar']), (200, 1, pic))
        seen = self.http('/auth/chat/channel', {}, jar=reader)[2]
        self.assertEqual((seen['rev'], seen['avatar']), (1, pic))
        fresh = self.http('/auth/chat/channel', {'known': 1}, jar=reader)[2]
        self.assertNotIn('avatar', fresh)                                   # nothing re-sent for a current revision
        self.assertEqual(self.http('/auth/chat/channel', {'known': 0}, jar=reader)[2]['avatar'], pic)

    def test_channel_set_permissions(self):
        self.app(devs=(DEV,))
        _, dev = self.user()
        plain = self.second_user()
        mod = self.make_mod()
        pic = png()
        self.assertEqual(self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'})[0], 401)
        self.assertEqual(self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'}, jar=plain)[0], 403)
        self.assertEqual(self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'}, jar=mod)[0], 200)
        # moderator took revision 1; the developer holding a stale view is told so instead of overwriting blindly
        status, _, body = self.http('/auth/chat/channel/set', {'avatar': png(shade=1), 'expected_revision': '0'}, jar=dev)
        self.assertEqual((status, body.get('error')), (409, 'channel_conflict'))
        self.assertEqual(self.http('/auth/chat/channel/set', {'avatar': png(shade=1), 'expected_revision': '1'}, jar=dev)[2]['rev'], 2)

    def test_channel_set_validation_removal_and_idempotence(self):
        self.app(devs=(DEV,))
        _, dev = self.user()
        pic = png()
        user = self.a.authenticate(dev.split('=', 1)[1])['user']
        for bad in ({}, {'avatar': pic}, {'avatar': pic, 'expected_revision': '0', 'x': '1'}, {'avatar': 5, 'expected_revision': '0'},
                    {'avatar': pic, 'expected_revision': '-1'}, {'avatar': pic, 'expected_revision': 'x'},
                    {'avatar': 'not-base64!', 'expected_revision': '0'}, {'avatar': png(side=300), 'expected_revision': '0'}):
            with self.assertRaises(AuthError) as err:                        # called directly: the route's rate limit is its own test
                chat_ticket.channel_set(self.a, user, bad, frozenset({DEV}))
            self.assertEqual(err.exception.status, 400, bad)
        self.assertEqual(self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'}, jar=dev)[2]['rev'], 1)
        again = self.http('/auth/chat/channel/set', {'avatar': pic, 'expected_revision': '0'}, jar=dev)     # same picture: no new revision
        self.assertEqual((again[0], again[2]['rev']), (200, 1))
        gone = self.http('/auth/chat/channel/set', {'avatar': '', 'expected_revision': '1'}, jar=dev)[2]
        self.assertEqual((gone['rev'], gone['avatar']), (2, ''))

    def test_channel_validation_and_limits(self):
        self.app(devs=(DEV,))
        _, jar = self.user()
        user = self.a.authenticate(jar.split('=', 1)[1])['user']
        for bad in ({'known': 'x'}, {'known': True}, {'known': -2}, {'known': 1.5}, {'extra': 1}):
            with self.assertRaises(AuthError) as err:
                chat_ticket.channel(self.a, user, bad, frozenset({DEV}))
            self.assertEqual(err.exception.status, 400, bad)
        codes = [self.http('/auth/chat/channel', {}, jar=jar)[0] for _ in range(31)]
        self.assertEqual((codes[:30], codes[30:]), ([200] * 30, [429]))

    def test_channel_set_rate_limit(self):
        self.app(devs=(DEV,))
        _, jar = self.user()
        codes = [self.http('/auth/chat/channel/set', {'avatar': png(shade=i), 'expected_revision': str(i)}, jar=jar)[0] for i in range(7)]
        self.assertEqual((codes[:6], codes[6:]), ([200] * 6, [429]))


if __name__ == '__main__':
    unittest.main()
