package app.ziziplayer.ui.components

import android.os.Build
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.CameraGooeyGeometry as G
import app.ziziplayer.ui.CameraMorphGeometry as M
import kotlin.math.abs
import kotlin.math.ceil

/** Default entry point. No bitmap/readback on the UI thread and no second image request.
 * API 26–30 and software canvases keep the separately tested 6.69.14 compatibility renderer.
 * The Telegram CPU bitmap pipeline is intentionally NOT claimed/ported here.
 */
@Composable
internal fun CollectionCoverMorphOverlay(
    camera: CameraCutoutSnapshot,
    maximum: Dp,
    minimum: Dp,
    coverTop: Dp,
    corner: Dp,
    status: Dp,
    fraction: () -> Float,
    scroll: () -> Float,
    artwork: @Composable () -> Unit
) {
    val accelerated = LocalView.current.isHardwareAccelerated
    if (Build.VERSION.SDK_INT >= 31 && accelerated) {
        CameraGooeyOverlay(camera, maximum, minimum, coverTop, corner, status, fraction, scroll, artwork)
    } else {
        LegacyCollectionCoverMorphOverlay(camera, maximum, minimum, coverTop, corner, status, fraction, scroll, artwork)
    }
}

/** Two independently blurred lobes -> SRC_OVER -> ONE common alpha threshold.
 * Separately thresholding the lobes or thresholding before blur does NOT make a liquid bridge.
 * Coefficients/seed construction follow the studied Telegram high-performance GPU mechanism.
 * The source is recorded once and replayed. Owned layers are released by rememberGraphicsLayer.
 */
@Composable
private fun CameraGooeyOverlay(
    camera: CameraCutoutSnapshot,
    maximum: Dp,
    minimum: Dp,
    coverTop: Dp,
    corner: Dp,
    status: Dp,
    fraction: () -> Float,
    scroll: () -> Float,
    artwork: @Composable () -> Unit
) {
    val sourceLayer = rememberGraphicsLayer()
    val bodyLayer = rememberGraphicsLayer()
    val artworkGooLayer = rememberGraphicsLayer()
    val cameraGooLayer = rememberGraphicsLayer()
    val detailLayer = rememberGraphicsLayer()
    val density = LocalDensity.current
    val maxPx = with(density) { maximum.toPx() }
    val minPx = with(density) { minimum.toPx() }
    val statusPx = with(density) { status.toPx() }
    val topPx = with(density) { coverTop.toPx() }
    val radiusPx = with(density) { corner.toPx() }
    val edgePx = with(density) { 1.dp.toPx() }
    var origin by remember { mutableStateOf<Offset?>(null) }
    val alphaFilter = remember {
        ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f, 0f,
            0f, 0f, 0f, G.ALPHA_GAIN, G.ALPHA_OFFSET
        )))
    }
    val filterPaint = remember(alphaFilter) { Paint().apply { colorFilter = alphaFilter } }
    val blackPaint = remember { Paint().apply { colorFilter = ColorFilter.tint(Color.Black, BlendMode.SrcIn) } }
    val gooBlur = remember { BlurEffect(G.BLUR_RADIUS, G.BLUR_RADIUS, TileMode.Clamp) }
    BoxWithConstraints(Modifier.fillMaxSize().clearAndSetSemantics { }
        .onGloballyPositioned { origin = it.positionInWindow() }) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val aligned = origin?.let { abs(it.x) <= 1f && abs(it.y) <= 1f } == true &&
            abs(widthPx - camera.windowWidth) <= 1f && abs(statusPx - camera.statusTop) <= 1f
        val target = if (aligned) camera.target else null
        val outline = if (aligned) camera.outline else null
        val frame = remember(maxPx, minPx, topPx, statusPx, radiusPx, widthPx, target, fraction, scroll) {
            derivedStateOf {
                G.frame(maxPx, minPx, fraction(), scroll(), widthPx*.5f, statusPx+topPx,
                    radiusPx, minPx+topPx, statusPx, target)
            }
        }
        // Fixed for the entire gesture: a moving integer crop is a new source of jitter.
        // Three reduced-layer blur radii of transparent padding, plus the largest seed.
        val padding = maxOf(3f * G.BLUR_RADIUS * G.GOO_SCALE, 60f * density.density)
        val roi = remember(widthPx, statusPx, topPx, minPx, target, padding) {
            Rect(minOf(widthPx*.5f-minPx*.5f, target?.left ?: widthPx*.5f)-padding,
                minOf(statusPx+topPx, target?.top ?: statusPx)-padding,
                maxOf(widthPx*.5f+minPx*.5f, target?.right ?: widthPx*.5f)+padding,
                maxOf(statusPx+topPx+minPx, target?.bottom ?: statusPx)+padding)
        }
        val safe = remember(statusPx, widthPx, heightPx, target, edgePx, density.density) {
            Path().apply {
                addRect(Rect(0f, statusPx, widthPx, heightPx))
                if (target != null) {
                    // Wider than the physical hole only inside its local corridor; no clock tint.
                    val margin = maxOf(target.width()*.35f, 2f*density.density)
                    addRect(Rect(target.left-margin-edgePx, target.top-edgePx,
                        target.right+margin+edgePx, statusPx+edgePx))
                }
            }
        }
        Box(Modifier.size(maximum).testTag("collection:morph-artwork").drawWithCache {
            val f = frame.value
            val sourceWidth = size.width
            val sourceHeight = size.height
            val bounds = Rect(Offset.Zero, roi.size)
            val bodyPath = Path().apply {
                addRoundRect(RoundRect(f.left(), f.top(), f.left()+f.width, f.top()+f.height,
                    CornerRadius(f.radius, f.radius), CornerRadius(f.radius, f.radius),
                    CornerRadius(f.radius, f.radius), CornerRadius(f.radius, f.radius)), Path.Direction.Clockwise)
            }
            val seeds = target?.let { G.seeds(it, f, density.density) }
            val cameraTip = seeds?.camera?.let { trianglePath(it, roi) }
            val artworkTip = seeds?.artwork?.let { trianglePath(it, roi) }
            val fullSize = IntSize(ceil(roi.width).toInt().coerceAtLeast(1), ceil(roi.height).toInt().coerceAtLeast(1))
            val gooSize = IntSize(ceil(roi.width/G.GOO_SCALE).toInt().coerceAtLeast(1),
                ceil(roi.height/G.GOO_SCALE).toInt().coerceAtLeast(1))
            val detailScale = G.detailScale(f.progress)
            val detailSize = IntSize(ceil(roi.width/detailScale).toInt().coerceAtLeast(1),
                ceil(roi.height/detailScale).toInt().coerceAtLeast(1))
            val blur = G.blurIntensity(f.progress)*G.BLUR_RADIUS
            artworkGooLayer.renderEffect = gooBlur
            cameraGooLayer.renderEffect = gooBlur
            detailLayer.renderEffect = if (blur > 0f) BlurEffect(blur, blur, TileMode.Decal) else null
            // Keep the no-cutout fade/blur without swapping composable image instances when
            // insets arrive. The raw source must stay unfiltered for the actual gooey pipeline.
            val fallbackBlur = size.minDimension * M.blurFraction(f.progress)
            sourceLayer.renderEffect = if (target == null && fallbackBlur > 0f)
                BlurEffect(fallbackBlur, fallbackBlur, TileMode.Clamp) else null
            val imageAlpha = G.imageAlpha(f.progress)
            val detailAlpha = G.blurImageAlpha(f.progress)
            val imagePaint = Paint().apply { alpha = imageAlpha }
            val detailPaint = Paint().apply { alpha = detailAlpha }
            val fadePaint = Paint().apply { alpha = f.imageAlpha }
            onDrawWithContent {
                CameraMorphDebug.recordGooeyFrame(scroll(), f, seeds?.protrusion ?: 0f)
                if (f.imageAlpha <= 0f) return@onDrawWithContent
                sourceLayer.record { this@onDrawWithContent.drawContent() }
                clipPath(safe) {
                    if (target == null || outline == null || f.progress <= 0f) {
                        withPaintLayer(Rect(0f, 0f, widthPx, heightPx), fadePaint) {
                            clipPath(bodyPath) {
                                withTransform({
                                    translate(f.left(), f.top())
                                    scale(f.width/sourceWidth, f.height/sourceHeight, Offset.Zero)
                                }) { drawLayer(sourceLayer) }
                            }
                        }
                    } else {
                        // Raw body in fixed window-relative ROI, clipped before any blur.
                        bodyLayer.record(this, layoutDirection, fullSize) {
                            withTransform({ translate(-roi.left, -roi.top) }) {
                                clipPath(bodyPath) {
                                    withTransform({
                                        translate(f.left(), f.top())
                                        scale(f.width/sourceWidth, f.height/sourceHeight, Offset.Zero)
                                    }) { drawLayer(sourceLayer) }
                                }
                            }
                        }
                        artworkGooLayer.record(this, layoutDirection, gooSize) {
                            withTransform({ scale(1f/G.GOO_SCALE, 1f/G.GOO_SCALE, Offset.Zero) }) {
                                if (imageAlpha < 1f) withPaintLayer(bounds, blackPaint) { drawLayer(bodyLayer) }
                                if (artworkTip != null) drawPath(artworkTip, Color.Black)
                                withPaintLayer(bounds, imagePaint) { drawLayer(bodyLayer) }
                            }
                        }
                        cameraGooLayer.record(this, layoutDirection, gooSize) {
                            withTransform({ scale(1f/G.GOO_SCALE, 1f/G.GOO_SCALE, Offset.Zero) }) {
                                withTransform({ translate(-roi.left, -roi.top) }) { drawPath(outline, Color.Black) }
                                if (cameraTip != null) drawPath(cameraTip, Color.Black)
                            }
                        }
                        detailLayer.record(this, layoutDirection, detailSize) {
                            withTransform({ scale(1f/detailScale, 1f/detailScale, Offset.Zero) }) { drawLayer(bodyLayer) }
                        }
                        withTransform({ translate(roi.left, roi.top) }) {
                            // Single outer alpha: black must not expose bright content on completion.
                            withPaintLayer(bounds, fadePaint) {
                                withPaintLayer(bounds, filterPaint) {
                                    withTransform({ scale(G.GOO_SCALE, G.GOO_SCALE, Offset.Zero) }) {
                                        drawLayer(cameraGooLayer)
                                        drawLayer(artworkGooLayer)
                                    }
                                }
                                // Match the reference's detail pass: alpha-thresholded image blur,
                                // black underlay followed by fading color. Never change a reused
                                // layer's properties between replays within the same display list.
                                if (detailAlpha < 1f) withPaintLayer(bounds, blackPaint) {
                                    drawGooeyDetail(bodyLayer, detailLayer, detailScale, blur, bounds, filterPaint)
                                }
                                if (detailAlpha > 0f) withPaintLayer(bounds, detailPaint) {
                                    drawGooeyDetail(bodyLayer, detailLayer, detailScale, blur, bounds, filterPaint)
                                }
                            }
                        }
                    }
                    if (CameraMorphDebug.outlineEnabled && outline != null) {
                        drawPath(outline, Color.Cyan, style = Stroke(edgePx))
                    }
                }
            }
        }) { Box(Modifier.fillMaxSize()) { artwork() } }
    }
}

private fun trianglePath(points: FloatArray, roi: Rect): Path = Path().apply {
    moveTo(points[0]-roi.left, points[1]-roi.top)
    lineTo(points[2]-roi.left, points[3]-roi.top)
    lineTo(points[4]-roi.left, points[5]-roi.top)
    close()
}

private inline fun DrawScope.withPaintLayer(bounds: Rect, paint: Paint, block: DrawScope.() -> Unit) {
    if (paint.alpha == 1f && paint.colorFilter == null && paint.blendMode == BlendMode.SrcOver) {
        block()
        return
    }
    drawContext.canvas.saveLayer(bounds, paint)
    try { block() } finally { drawContext.canvas.restore() }
}

private fun DrawScope.drawGooeyDetail(body: GraphicsLayer, detail: GraphicsLayer,
    factor: Float, blur: Float, bounds: Rect, filter: Paint) {
    if (blur > 0f) withPaintLayer(bounds, filter) {
        withTransform({ scale(factor, factor, Offset.Zero) }) { drawLayer(detail) }
    } else drawLayer(body)
}
