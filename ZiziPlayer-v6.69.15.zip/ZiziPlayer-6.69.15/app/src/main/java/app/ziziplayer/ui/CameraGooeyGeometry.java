package app.ziziplayer.ui;

/**
 * 6.69.15. Independent implementation of the blur + alpha-threshold mechanism studied in
 * Telegram ProfileGooeyView (dc780e81). No Telegram source is embedded; see THIRD_PARTY_NOTICES.
 * Pure, stateless parameters shared by the Compose renderer and executable JVM tests.
 * The legacy WAIST/REACH/SWELL tables do NOT drive this renderer.
 */
public final class CameraGooeyGeometry {
    private CameraGooeyGeometry() {}
    // Telegram's high-performance GPU profile. Radius is in reduced-layer pixels, NOT dp.
    public static final float GOO_SCALE = 3f;
    public static final float BLUR_RADIUS = 15f;
    public static final float ALPHA_GAIN = 51f;
    public static final float ALPHA_OFFSET = -6375f;
    private static final float COS_45 = (float) Math.sqrt(.5);

    public static float progress(float value) { return CameraMorphGeometry.unit(value); }
    public static float protrusion(float p, float density) {
        float d = Float.isFinite(density) && density > 0f ? density : 1f;
        // AndroidUtilities.dp uses ceil for positive values. One constant rounding at setup,
        // NOT a rounding of scroll/coordinates. The pulse is 0 -> peak at .5 -> 0.
        float peak = (float) Math.ceil(7f * d) * GOO_SCALE;
        return peak * (1f - Math.abs(2f * progress(p) - 1f));
    }
    public static float blurIntensity(float p) {
        return Math.min(.75f, Math.max(0f, (progress(p) - .2f) / .5f));
    }
    public static float imageAlphaUnclamped(float p) { return 2f * (1f - progress(p)); }
    public static float imageAlpha(float p) { return Math.min(1f, imageAlphaUnclamped(p)); }
    public static float blurImageAlpha(float p) { return Math.min(1f, .75f * imageAlphaUnclamped(p)); }
    public static float detailScale(float p) { return 1.25f + .5f * blurIntensity(p); }
    public static float threshold(float alpha) {
        return progress(ALPHA_GAIN * progress(alpha) + ALPHA_OFFSET / 255f);
    }
    private static float mix(float a, float b, float p) { return a + (b - a) * p; }

    /** Preserve phase-one scroll/size. Phase two uses Telegram's linear shrink and central
     * approach to half the cutout diameter. Corner cutouts are an explicit Zizi extension:
     * finish lateral travel early, then use the same directional blob construction.
     * Existing safe-inset clip and final group fade remain application safety policy.
     */
    public static CameraMorphGeometry.Frame frame(float maximum, float minimum, float fraction,
            float scroll, float centerX, float coverTop, float initialRadius, float travel,
            float fallbackY, CameraMorphGeometry.Target target) {
        CameraMorphGeometry.Frame base = CameraMorphGeometry.frame(maximum, minimum, fraction,
                scroll, centerX, coverTop, initialRadius, travel, fallbackY, target);
        if (target == null || base.progress <= 0f) return base;
        float p = base.progress;
        float size = Math.max(0f, Math.min(maximum, minimum));
        float w = mix(size, target.width() * .5f, p);
        float h = mix(size, target.height() * .5f, p);
        float cx = mix(centerX, target.cx(), CameraMorphGeometry.smooth(p / .65f));
        float cy = mix(coverTop + size * .5f, target.cy(), p);
        float alpha = 1f - CameraMorphGeometry.smoother((p - .9f) / .1f);
        return new CameraMorphGeometry.Frame(cx, cy, w, h, Math.min(w, h) * .5f, p,
                alpha, 1f - imageAlpha(p), 1f - blurImageAlpha(p), base.anchorAlpha);
    }

    public static final class Seeds {
        /** Triangle vertices in window pixels, [x0,y0,x1,y1,x2,y2]. */
        public final float[] camera, artwork;
        public final float protrusion, nx, ny;
        private Seeds(float[] camera, float[] artwork, float protrusion, float nx, float ny) {
            this.camera = camera; this.artwork = artwork; this.protrusion = protrusion;
            this.nx = nx; this.ny = ny;
        }
    }
    public static Seeds seeds(CameraMorphGeometry.Target target, CameraMorphGeometry.Frame f, float density) {
        float dx = f.cx - target.cx(), dy = f.cy - target.cy();
        float length = (float) Math.hypot(dx, dy);
        float nx = length > .0001f ? dx / length : 0f;
        float ny = length > .0001f ? dy / length : 1f;
        float h = protrusion(f.progress, density);
        float r = Math.min(f.width, f.height) * .5f;
        float cameraR = (float) Math.hypot(nx * target.width() * .5f, ny * target.height() * .5f);
        return new Seeds(triangle(target.cx(), target.cy(), nx, ny, 0f, h*.5f, cameraR+h),
                triangle(f.cx, f.cy, nx, ny, -COS_45*r, r, -r-h*.25f), h, nx, ny);
    }
    private static float[] triangle(float x, float y, float nx, float ny,
            float base, float halfWidth, float tip) {
        return new float[] {x+nx*base-ny*halfWidth, y+ny*base+nx*halfWidth,
                x+nx*tip, y+ny*tip,
                x+nx*base+ny*halfWidth, y+ny*base-nx*halfWidth};
    }
}
