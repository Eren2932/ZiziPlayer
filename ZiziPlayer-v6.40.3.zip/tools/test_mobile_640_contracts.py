#!/usr/bin/env python3
"""Source wiring checks only. They do NOT compile Kotlin or test Android security/gestures."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (JAVA / name).read_text()
class Mobile640Contracts(unittest.TestCase):
    def test_single_focus_owner(self):
        service = read('playback/PlaybackService.kt')
        self.assertIn('false // FocusPlayer is the only audio-focus owner.', service)
        self.assertIn('MediaSession.Builder(this, FocusPlayer(this, player, ::mayPlay))', service)
    def test_framework_duck_does_not_bypass_fade(self):
        focus = read('playback/FocusPlayer.kt')
        self.assertIn('.setWillPauseWhenDucked(true)', focus)
        self.assertIn('fade(AudioInterruptionPolicy.DUCK_GAIN, AudioInterruptionPolicy.ATTACK_MS)', focus)
        self.assertIn('if (epoch == generation && !released)', focus)
        self.assertIn('if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED)', focus)
    def test_intent_cancellation_and_noisy_route(self):
        focus = read('playback/FocusPlayer.kt')
        self.assertIn('policy.cancel()', focus)
        self.assertIn('PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY', focus)
        self.assertIn('.setHandleAudioBecomingNoisy(true)', read('playback/PlaybackService.kt'))
    def test_vault_never_persists_plaintext_or_unlock(self):
        vault = read('privacy/FolderVault.kt')
        self.assertIn('PBKDF2WithHmacSHA256', vault)
        self.assertIn('210_000', vault)
        self.assertIn('SecureRandom()', vault)
        self.assertIn('MessageDigest.isEqual', vault)
        self.assertNotIn('putString("secret"', vault)
        self.assertNotIn('putBoolean("unlocked"', vault)
        self.assertIn('withContext(Dispatchers.Default)', vault)
        self.assertIn('PrivacyRules.retryDelay(failures)', vault)
    def test_all_primary_repository_projections_filtered(self):
        repo = read('data/MusicRepository.kt')
        for expression in ('visible(dao.observeTracks())', 'visible(dao.observeAllTracks())',
                           'visible(dao.observeFavoriteTracks())', 'visible(dao.observePlaylistTracks(playlistId))'):
            self.assertIn(expression, repo)
        self.assertIn('rows.filterNot { gate.blocks(it.track) }', repo)
        self.assertIn('rows.filterNot { it.trackId in blocked }', repo)
        self.assertIn('dao.playlistTracks(playlistId).filterNot(vault.state.value::blocks)', repo)
    def test_session_does_not_trust_client_folder_metadata(self):
        service = read('playback/PlaybackService.kt')
        self.assertIn('dao.vaultTracksByIds(ids)', service)
        self.assertIn('.chunked(400)', service)
        self.assertIn('if (gate.blocks(track)) return@mapNotNull null', service)
        self.assertIn('uri?.toString() != track.uri', service)
        self.assertIn('extras.putString("vaultFolder", track.sourceFolder)', service)
        self.assertIn('val track = tracks[item.mediaId] ?: return@mapNotNull null', service)
    def test_player_mutation_boundary_rechecks_late_futures(self):
        focus = read('playback/FocusPlayer.kt')
        self.assertIn('val safe = mediaItems.filter(mayPlay)', focus)
        self.assertIn('if (requested != null && !mayPlay(requested))', focus)
        self.assertIn('engine.currentMediaItem?.let { !mayPlay(it) }', focus)
        self.assertIn('engine.addMediaItems(index, mediaItems.filter(mayPlay))', focus)
        self.assertIn('engine.replaceMediaItems(fromIndex, toIndex, mediaItems.filter(mayPlay))', focus)
    def test_queue_purge_pauses_before_removal(self):
        service = read('playback/PlaybackService.kt')
        self.assertLess(service.index('p.pause()'), service.index('p.removeMediaItem(i)'))
        self.assertIn('vault.addListener(vaultListener)', service)
        self.assertIn('vault.removeListener(vaultListener)', service)
        controller = read('playback/PlayerController.kt')
        self.assertIn('safeTracks.any(app.ziziplayer.privacy.FolderVault.get(context).state.value::blocks)', controller)
    def test_background_and_old_ui_state_guarded(self):
        activity = read('MainActivity.kt')
        self.assertIn('FolderVault.get(this).lock()', activity)
        self.assertIn('vm.folderVault.uiSessionKey, gate.lockRevision)', activity)
        # 6.40.1: protection is scoped to auth, not the entire Activity.
        self.assertNotIn('window.addFlags', activity)
        self.assertIn('rawCurrent?.takeUnless(vaultGate::blocks)', activity)
    def test_unlock_never_happens_on_biometric_failure(self):
        auth = read('ui/components/VaultAuthDialog.kt')
        failure = auth.split('override fun onAuthenticationError', 1)[1].split('})', 1)[0]
        self.assertNotIn('unlockWithDevice', failure)
        self.assertIn('active() && epoch == authEpoch && biometricActive', auth)
        self.assertIn('SecureFlagPolicy.SecureOn', auth)
        self.assertIn('onDispose { lifecycle.removeObserver(observer); cancelAuthentication() }', auth)
    def test_folder_selection_is_real_and_local(self):
        ui = read('ui/screens/LibraryScreen.kt')
        self.assertIn('Скрыть папки', ui)
        self.assertIn('.combinedClickable(onClick = card.onOpen, onLongClick = card.onLongPress)', ui)
        self.assertIn('_selectedFolders.value.isNotEmpty() -> { selectFolders(emptySet()); true }', read('ui/MainViewModel.kt'))
        self.assertIn('!it.isRemote && it.sourceFolder == folder.name', ui)
        self.assertIn('vm.restoreFolders(setOf(name))', ui)
    def test_pull_is_scroll_remainder_not_global_swipe(self):
        pull = read('ui/components/VaultPullSurface.kt')
        self.assertIn('onPostScroll(consumed: Offset, available: Offset', pull)
        self.assertIn('source != NestedScrollSource.UserInput', pull)
        self.assertIn('val shouldOpen = gesture.release()', pull)
        self.assertIn('if (!normalEnd)', pull)
        self.assertIn('if (unlocked) lerp(p.surface, p.brand, 0.22f) else p.surface', pull)
        self.assertIn('if (released) p.onBrand else p.text', pull)
    def test_preflight_executes_new_checks(self):
        selftest = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn('test_mobile_640.py', selftest)
        self.assertIn('test_mobile_640_contracts.py', selftest)
if __name__ == '__main__': unittest.main(verbosity=2)
