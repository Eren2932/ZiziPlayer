#!/usr/bin/env python3
"""Source integration contracts only: not Kotlin compilation or Android rendering."""
from pathlib import Path
import os
import re
import unittest
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
JAVA = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (JAVA / path).read_text()


class Mobile643Contracts(unittest.TestCase):
    def test_version_and_preflight(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 85', gradle)
        self.assertIn('versionName = "6.40.3"', gradle)
        preflight = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn("'test_mobile_643.py'", preflight)
        self.assertIn("'test_mobile_643_contracts.py'", preflight)

    def test_dwell_is_the_only_gate(self):
        policy = (JAVA / 'privacy/VaultPullPolicy.java').read_text()
        self.assertIn('public static final long HOLD_MS = 300L', policy)
        self.assertIn('public static final float OPEN_DISTANCE_DP = 66f', policy)
        self.assertIn('public static final float MAX_DISTANCE_DP = 118f', policy)
        self.assertIn('public static final float RELEASE_RATIO = 0.94f', policy)
        # armed рождается ровно в одном месте и только по истечении выдержки.
        self.assertEqual(policy.count('armed = true'), 1)
        self.assertIn('clock - zoneSince >= HOLD_MS', policy)
        # Часы приходят снаружи: класс не должен уметь спросить время сам.
        self.assertNotIn('System.currentTimeMillis', policy)
        self.assertNotIn('System.nanoTime', policy)
        self.assertNotIn('android.', policy)
        # Монотонность часов: назад время не сдвигает выдержку.
        self.assertIn('if (nowMs > clock) clock = nowMs;', policy)
        # Каждая точка входа обязана нести время.
        for signature in ('public void begin(long nowMs)', 'public void tick(long nowMs)',
                          'public float pull(float remainder, long nowMs)',
                          'public float retract(float delta, long nowMs)'):
            self.assertIn(signature, policy)

    def test_curtain_has_two_captions_and_no_progress_bar(self):
        ui = read('ui/components/VaultPullSurface.kt')
        self.assertEqual(ui.count('"Отпусти для открытия"'), 1)
        self.assertEqual(ui.count('"Потяни для скрытых папок"'), 1)
        # Третьей подписи и полоски загрузки в шторке больше нет.
        self.assertNotIn('Потяни ещё немного', ui)
        self.assertNotIn('hintStage = gesture.hintStage; progress = gesture.progress', ui)
        self.assertNotIn('.width(64.dp).height(3.dp)', ui)
        self.assertNotIn('LinearProgressIndicator', ui)
        # Выдержку показывает заливка и капсула, а не отдельный индикатор.
        self.assertIn('gesture.holdProgress', ui)
        self.assertIn('drawCircle(p.brand', ui)
        self.assertIn('capsuleHeight = CAPSULE_WIDTH + (capsuleFull - CAPSULE_WIDTH) * fill', ui)

    def test_curtain_geometry_matches_the_measured_reference(self):
        ui = read('ui/components/VaultPullSurface.kt')
        self.assertIn('private val CAPSULE_INSET = 30.dp', ui)
        self.assertIn('private val CAPSULE_WIDTH = 18.dp', ui)
        self.assertIn('private val CAPSULE_MARGIN = 11.dp', ui)

    def test_curtain_ticks_while_the_finger_stands_still(self):
        ui = read('ui/components/VaultPullSurface.kt')
        # Без собственного тика выдержка не истечёт: событий скролла у неподвижного пальца нет.
        self.assertIn('withFrameMillis { gesture.tick(SystemClock.uptimeMillis()) }', ui)
        self.assertIn('LaunchedEffect(gesture, dragging)', ui)
        # Открывает по-прежнему отпускание, а не колбэк fling.
        self.assertIn('if (shouldOpen) openVaultAction.invoke()', ui)

    def test_search_tiles_reserve_a_text_band_above_the_covers(self):
        ui = read('ui/screens/SearchScreen.kt')
        quick = ui.split('private fun QuickTile(', 1)[1].split('/** Genre tile', 1)[0]
        genre = ui.split('private fun CategoryTile(', 1)[1].split('/** Desktop 0.3.5', 1)[0]
        for tile in (quick, genre):
            self.assertNotIn('fillMaxWidth(0.85f)', tile)
            self.assertIn('Column(Modifier.fillMaxSize())', tile)
            self.assertIn('Spacer(Modifier.height(DiscoveryArtworkPolicy.TEXT_GAP_DP.dp))', tile)
            self.assertIn('BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).clipToBounds())', tile)
            self.assertIn('DiscoveryArtworkPolicy.pairSizeDp(', tile)
            self.assertIn('if (artSize > 0.dp)', tile)
            self.assertLess(tile.index('Text('), tile.index('Spacer('))
            self.assertLess(tile.index('Spacer('), tile.index('TiltedArtPair('))
        self.assertIn('maxLines = 1', quick)
        self.assertIn('maxLines = 2', genre)

    def test_curtain_drawing_is_clipped_and_release_updates_clock(self):
        ui = read('ui/components/VaultPullSurface.kt')
        self.assertIn('.height(heightDp).clipToBounds().drawBehind', ui)
        event = ui.split('val pressed = event.changes.any', 1)[1]
        self.assertLess(event.index('gesture.tick('), event.index('gesture.release()'))
        self.assertIn('Modifier.padding(horizontal = 56.dp)', ui)


if __name__ == '__main__': unittest.main(verbosity=2)
