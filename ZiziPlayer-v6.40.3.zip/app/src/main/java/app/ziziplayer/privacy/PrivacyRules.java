package app.ziziplayer.privacy;

import java.util.Set;

/** Shared production rules; not a simulated copy of Android UI logic. */
public final class PrivacyRules {
    private PrivacyRules() {}
    public static boolean blocks(boolean unlocked, boolean remote, String folder, Set<String> hidden) {
        return !unlocked && !remote && hidden.contains(folder);
    }
    public static final long MAX_RETRY_MS = 120_000L;
    public static long retryDelay(int failures) {
        if (failures < 5) return 0L;
        // 30s, 60s, 120s; every subsequent error stays at two minutes.
        return Math.min(MAX_RETRY_MS, 30_000L * (1L << Math.min(2, failures - 5)));
    }
    /** Persist this deadline, not just a clamped countdown, when upgrading an old lockout. */
    public static long cappedRetryAt(long retryAt, long now) {
        long latest = now > Long.MAX_VALUE - MAX_RETRY_MS ? Long.MAX_VALUE : now + MAX_RETRY_MS;
        return Math.min(retryAt, latest);
    }
    public static long remainingSeconds(long retryAt, long now) {
        if (retryAt <= now) return 0L;
        return (cappedRetryAt(retryAt, now) - now + 999L) / 1000L;
    }
    /** Includes the skipped center node exactly like Android's pattern grid. */
    public static String appendPattern(String path, int node) {
        char next = (char) ('0' + node);
        if (node < 0 || node > 8 || path.indexOf(next) >= 0) return path;
        if (path.isEmpty()) return String.valueOf(next);
        int last = path.charAt(path.length() - 1) - '0';
        int dx = node % 3 - last % 3, dy = node / 3 - last / 3;
        if ((Math.abs(dx) == 2 || Math.abs(dy) == 2) && dx % 2 == 0 && dy % 2 == 0) {
            char middle = (char) ('0' + (last + node) / 2);
            if (path.indexOf(middle) < 0) path += middle;
        }
        return path + next;
    }
}
