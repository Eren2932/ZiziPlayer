package app.ziziplayer.privacy;

/** Platform-free gesture state; only the top-of-list nested-scroll remainder enters pull().
 *
 * 6.40.3. До этой версии взвод зависел ТОЛЬКО от пройденного расстояния. Расстояние было большое
 * (96dp по шторке, ~175dp по пальцу), но набиралось оно за один резкий смах примерно за 120 мс —
 * и человек попадал в ввод PIN, ничего такого не имея в виду. Теперь расстояние — это условие
 * входа в зону, а взводит жест ВРЕМЯ: палец должен простоять в зоне {@link #HOLD_MS} миллисекунд.
 * Смах физически не может взвести шторку: он покидает зону раньше, чем истечёт выдержка.
 *
 * Параметры по выборке эталонного видео 1080x2400; плотность 2.75 — допущение,
 * не метаданные устройства: порог около 180px = 66dp, снятие взвода около 170px,
 * предел растяга около 324px = 118dp. Точное визуальное совпадение требует проверки на Android.
 *
 * Время подаётся снаружи и никогда не читается внутри класса: состояние остаётся детерминированным
 * и проверяемым без Android.
 */
public final class VaultPullPolicy {
    /** Ход шторки до входа в зону взвода. */
    public static final float OPEN_DISTANCE_DP = 66f;
    /** Предел растяга: дальше шторка не едет, палец продолжает двигаться вхолостую. */
    public static final float MAX_DISTANCE_DP = 118f;
    /** Доля порога, ниже которой зона считается покинутой. Дрожание пальца выдержку не сбрасывает. */
    public static final float RELEASE_RATIO = 0.94f;
    /** Сопротивление: 1dp шторки на ~1.8dp пальца. */
    public static final float RESISTANCE = 0.55f;
    /** Сколько палец обязан простоять в зоне, чтобы шторка взвелась. */
    public static final long HOLD_MS = 300L;

    private final float threshold;
    private final float ceiling;
    private final float floor;
    private float distance;
    private boolean dragging, inZone, armed, buzzed, haptic, swallowFling;
    private long zoneSince;
    private long clock;

    public VaultPullPolicy(float threshold) {
        if (!(threshold > 0f) || !Float.isFinite(threshold)) throw new IllegalArgumentException();
        this.threshold = threshold;
        this.ceiling = threshold * (MAX_DISTANCE_DP / OPEN_DISTANCE_DP);
        this.floor = threshold * RELEASE_RATIO;
    }

    public float getDistance() { return distance; }
    public boolean isDragging() { return dragging; }
    public boolean isArmed() { return armed; }
    /** Растяг шторки, 0..1. Управляет только геометрией, к открытию отношения не имеет. */
    public float getProgress() { return Math.min(1f, distance / threshold); }
    /** Доля выдержки, 0..1. Это и есть заливка: отдельного индикатора прогресса в шторке нет. */
    public float getHoldProgress() {
        if (!inZone) return 0f;
        long held = clock - zoneSince;
        if (held <= 0L) return 0f;
        if (held >= HOLD_MS) return 1f;
        return (float) held / (float) HOLD_MS;
    }
    /** Ровно два состояния подписи: 0 — тянуть, 1 — отпускать. Промежуточной подписи нет. */
    public int getHintStage() { return armed ? 1 : 0; }

    /** Единственная точка, где рождается armed. Вызывается из pull/retract/tick — всегда с часами. */
    private void settle(long nowMs) {
        if (!dragging) return;
        if (nowMs > clock) clock = nowMs;
        boolean wantZone = inZone ? distance >= floor : distance >= threshold;
        if (wantZone && !inZone) {
            inZone = true;
            zoneSince = clock;
        } else if (!wantZone && inZone) {
            inZone = false;
            armed = false;
        }
        if (inZone && !armed && clock - zoneSince >= HOLD_MS) {
            armed = true;
            if (!buzzed) { buzzed = true; haptic = true; }
        }
    }

    public void begin(long nowMs) {
        cancel();
        dragging = true;
        clock = nowMs;
    }

    /** Продвигает выдержку, когда палец стоит на месте и события скролла не приходят. */
    public void tick(long nowMs) { settle(nowMs); }

    public float pull(float remainder, long nowMs) {
        if (!dragging || remainder <= 0f || !Float.isFinite(remainder)) { settle(nowMs); return 0f; }
        distance = Math.min(ceiling, distance + remainder * RESISTANCE);
        settle(nowMs);
        return remainder;
    }

    public float retract(float delta, long nowMs) {
        if (!dragging || distance <= 0f || delta >= 0f || !Float.isFinite(delta)) { settle(nowMs); return 0f; }
        float used = Math.max(delta, -distance / RESISTANCE);
        distance = Math.max(0f, distance + used * RESISTANCE);
        settle(nowMs);
        return used;
    }

    public boolean takeHaptic() { boolean value = haptic; haptic = false; return value; }

    public boolean release() {
        if (!dragging) return false;
        boolean open = armed;
        swallowFling = distance > 0f;
        reset();
        return open;
    }

    public boolean consumeFling() {
        // A child may enter onPreFling before/after the observer sees the final up event.
        boolean value = swallowFling || distance > 0f;
        swallowFling = false;
        return value;
    }

    public void cancel() { reset(); swallowFling = false; }

    private void reset() {
        distance = 0f;
        dragging = false; inZone = false; armed = false; buzzed = false; haptic = false;
        zoneSince = 0L; clock = 0L;
    }
}
