package app.ziziplayer.privacy

import android.content.Context
import android.util.Base64
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class VaultState(val folders: Set<String>, val unlocked: Boolean = false, val lockRevision: Long = 0) {
    fun blocks(track: TrackEntity): Boolean = PrivacyRules.blocks(unlocked, track.isRemote, track.sourceFolder, folders)
}

/** An application privacy gate, NOT file encryption. No credentials or unlock state in backups. */
class FolderVault private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("folder_vault_v1", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(VaultState(prefs.getStringSet("folders", emptySet())!!.toSet()))
    val state = mutable.asStateFlow()
    // Never reuse a protected Compose saved-state namespace after process death.
    val uiSessionKey: String = java.util.UUID.randomUUID().toString()
    private val mutex = Mutex()
    // Synchronous service listeners purge a running queue before the caller returns from lock/hide.
    private val listeners = mutableSetOf<() -> Unit>()
    val configured: Boolean get() = prefs.contains("verifier")
    val pattern: Boolean get() = prefs.getBoolean("pattern", false)
    fun remainingSeconds(): Long {
        val now = System.currentTimeMillis()
        val saved = prefs.getLong("retryAt", 0)
        val deadline = PrivacyRules.cappedRetryAt(saved, now)
        // apply updates in-memory prefs immediately and persists the shortened deadline.
        // Merely displaying min(120, remaining) would leave the OLD five-minute block active.
        if (deadline != saved) prefs.edit().putLong("retryAt", deadline).apply()
        return PrivacyRules.remainingSeconds(deadline, now)
    }
    fun addListener(listener: () -> Unit) { listeners += listener }
    fun removeListener(listener: () -> Unit) { listeners -= listener }
    private fun publish(value: VaultState) { mutable.value = value; listeners.toList().forEach { it() } }
    fun lock() { if (state.value.unlocked) publish(state.value.copy(unlocked = false, lockRevision = state.value.lockRevision + 1)) }
    fun unlockWithDevice() { if (configured) publish(state.value.copy(unlocked = true)) }
    fun hide(folders: Set<String>) {
        check(configured)
        val all = state.value.folders + folders
        prefs.edit().putStringSet("folders", all).apply()
        publish(VaultState(all, lockRevision = state.value.lockRevision + 1))
    }
    fun restore(folders: Set<String>) {
        check(state.value.unlocked)
        val rest = state.value.folders - folders
        prefs.edit().putStringSet("folders", rest).apply()
        publish(state.value.copy(folders = rest))
    }
    private fun derive(secret: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(secret.toCharArray(), salt, 210_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
    suspend fun configure(secret: String, isPattern: Boolean) = mutex.withLock {
        require(if (isPattern) secret.length in 4..9 && secret.all { it in '0'..'8' } && secret.toSet().size == secret.length
            else secret.length in 6..12 && secret.all { it in '0'..'9' })
        check(!configured)
        val salt = ByteArray(24).also { SecureRandom().nextBytes(it) }
        val hash = withContext(Dispatchers.Default) { derive(secret, salt) }
        val ok = withContext(Dispatchers.IO) {
            prefs.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("verifier", Base64.encodeToString(hash, Base64.NO_WRAP))
                .putBoolean("pattern", isPattern).commit()
        }
        if (!ok) throw IllegalStateException("Не удалось сохранить защиту")
    }
    suspend fun verify(secret: String): Boolean = mutex.withLock {
        if (!configured || remainingSeconds() > 0) return@withLock false
        val valid = withContext(Dispatchers.Default) {
            runCatching {
                val salt = Base64.decode(prefs.getString("salt", "").orEmpty(), Base64.NO_WRAP)
                val expected = Base64.decode(prefs.getString("verifier", "").orEmpty(), Base64.NO_WRAP)
                MessageDigest.isEqual(expected, derive(secret, salt))
            }.getOrDefault(false)
        }
        if (valid) {
            prefs.edit().remove("failures").remove("retryAt").apply()
            publish(state.value.copy(unlocked = true))
        } else {
            val failures = prefs.getInt("failures", 0).coerceIn(0, 19) + 1
            val delay = PrivacyRules.retryDelay(failures)
            prefs.edit().putInt("failures", failures).putLong("retryAt", System.currentTimeMillis() + delay).apply()
        }
        valid
    }
    companion object {
        @Volatile private var instance: FolderVault? = null
        fun get(context: Context): FolderVault = instance ?: synchronized(this) {
            instance ?: FolderVault(context.applicationContext).also { instance = it }
        }
    }
}
