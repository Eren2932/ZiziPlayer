package app.ziziplayer.ui.components

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.password
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.ziziplayer.privacy.FolderVault
import app.ziziplayer.privacy.PatternPath
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activity()
    else -> null
}

/** No DEVICE_CREDENTIAL fallback: the digits below verify the Zizi key, never the phone PIN. */
private fun canUseBiometrics(context: Context): Boolean = runCatching {
    when {
        Build.VERSION.SDK_INT >= 30 -> context.getSystemService(BiometricManager::class.java)
            ?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        Build.VERSION.SDK_INT >= 29 -> {
            @Suppress("DEPRECATION")
            val result = context.getSystemService(BiometricManager::class.java)?.canAuthenticate()
            result == BiometricManager.BIOMETRIC_SUCCESS
        }
        Build.VERSION.SDK_INT == 28 -> context.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT) &&
            context.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true
        else -> false // API 26–27 retain the existing Zizi PIN / pattern, without a duplicate phone-code button.
    }
}.getOrDefault(false)

@Composable
fun VaultAuthDialog(vault: FolderVault, onSuccess: () -> Unit, onDismiss: () -> Unit) {
    val setup = remember(vault) { !vault.configured }
    var pattern by remember { mutableStateOf(vault.pattern) }
    var input by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var biometricActive by remember { mutableStateOf(false) }
    var retrySeconds by remember { mutableLongStateOf(vault.remainingSeconds()) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = context.activity()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val biometricAvailable = remember(context) { canUseBiometrics(context) }
    val success by rememberUpdatedState(onSuccess)
    val dismiss by rememberUpdatedState(onDismiss)
    var cancellation by remember { mutableStateOf<CancellationSignal?>(null) }
    var live by remember { mutableStateOf(true) }
    var authEpoch by remember { mutableIntStateOf(0) }
    fun active() = live && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
    fun cancelAuthentication() {
        live = false; authEpoch++
        cancellation?.cancel(); cancellation = null
        input = ""; first = null
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                // No saved PIN and no late biometric callback can unlock a background Activity.
                cancelAuthentication(); dismiss()
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); cancelAuthentication() }
    }
    LaunchedEffect(retrySeconds) {
        if (retrySeconds > 0) { delay(1_000); retrySeconds = vault.remainingSeconds() }
    }
    fun submit() {
        if (busy || biometricActive || !active() || retrySeconds > 0) return
        val valid = if (pattern) input.length in 4..9 else input.length in 6..12
        if (!valid) { error = if (pattern) "Соедини минимум 4 точки" else "PIN: от 6 до 12 цифр"; return }
        if (setup && first == null) { first = input; input = ""; error = null; return }
        if (setup && first != input) { first = null; input = ""; error = "Не совпало. Задай ключ заново"; return }
        val secret = input
        input = ""; error = null; busy = true
        scope.launch {
            try {
                if (setup) { vault.configure(secret, pattern); if (active()) success() }
                else if (vault.verify(secret)) {
                    if (active()) success() else vault.lock()
                } else {
                    retrySeconds = vault.remainingSeconds()
                    error = if (retrySeconds == 0L) "Неверный ключ. Попробуй ещё раз" else null
                }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (_: Exception) { if (live) error = "Не удалось проверить или сохранить ключ. Попробуй снова" }
            finally { busy = false }
        }
    }
    fun biometric() {
        if (Build.VERSION.SDK_INT < 28 || activity == null || setup || busy || biometricActive || !active()) return
        val epoch = ++authEpoch
        input = ""; error = null; biometricActive = true
        val signal = CancellationSignal(); cancellation = signal
        try {
            val builder = BiometricPrompt.Builder(activity)
                .setTitle("Скрытые папки Zizi")
                .setSubtitle("Подтверди доступ биометрией устройства")
                .setNegativeButton(if (pattern) "Ввести рисунок Zizi" else "Ввести PIN Zizi", activity.mainExecutor) { _, _ ->
                    if (live && epoch == authEpoch) { biometricActive = false; cancellation = null }
                }
            if (Build.VERSION.SDK_INT >= 30) builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            builder.build().authenticate(signal, activity.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    if (active() && epoch == authEpoch && biometricActive) {
                        biometricActive = false; cancellation = null
                        vault.unlockWithDevice(); success()
                    }
                }
                override fun onAuthenticationError(code: Int, message: CharSequence) {
                    if (live && epoch == authEpoch) {
                        biometricActive = false; cancellation = null
                        error = "Биометрия закрыта или недоступна. Используй ключ Zizi"
                    }
                }
                override fun onAuthenticationFailed() {
                    // A rejected finger is not success; Android keeps its own prompt open.
                }
            })
        } catch (_: Exception) {
            biometricActive = false; cancellation = null
            error = "Биометрия недоступна. Используй ключ Zizi"
        }
    }
    val p = LocalPalette.current
    val enabled = !busy && !biometricActive && retrySeconds == 0L
    val fontScale = LocalConfiguration.current.fontScale
    Dialog(
        onDismissRequest = { if (!busy) { cancelAuthentication(); dismiss() } },
        properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn,
            usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        // Bottom alignment keeps the keypad within thumb reach; insets protect navigation
        // gestures / cutouts. Small windows and large fonts scroll, never shrink hit targets.
        BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp), contentAlignment = Alignment.BottomCenter) {
            Box(Modifier.matchParentSize().pointerInput(busy) {
                detectTapGestures { if (!busy) { cancelAuthentication(); dismiss() } }
            })
            val availableHeight = maxHeight
            val compact = availableHeight < 650.dp || fontScale > 1.2f
            Surface(Modifier.widthIn(max = 360.dp).fillMaxWidth(),
                shape = RoundedCornerShape(30.dp), color = p.surface,
                border = BorderStroke(1.dp, p.brand.copy(alpha = 0.12f))) {
                Column(Modifier.heightIn(max = availableHeight)
                    .background(Brush.verticalGradient(listOf(lerp(p.surface, p.brand, 0.065f), p.surface)))
                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (setup) (if (first == null) "Задай ключ Zizi" else "Повтори ключ Zizi")
                        else if (pattern) "Введи рисунок Zizi" else "Введи PIN Zizi",
                        color = p.text, fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Normal, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text(if (setup) "Защита внутри Zizi, не шифрование файлов. Запомни ключ: восстановления нет."
                        else "Скрытые папки",
                        color = p.subtext, fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center)
                    if (setup && first == null) Row {
                        TextButton(enabled = enabled, onClick = { pattern = false; input = ""; error = null }) {
                            Text(if (!pattern) "✓ PIN" else "PIN", color = p.brand)
                        }
                        TextButton(enabled = enabled, onClick = { pattern = true; input = ""; error = null }) {
                            Text(if (pattern) "✓ Рисунок" else "Рисунок", color = p.brand)
                        }
                    }
                    Spacer(Modifier.height(if (compact) 12.dp else 18.dp))
                    if (pattern) {
                        Box(Modifier.widthIn(max = if (compact) 224.dp else 252.dp)) {
                            PatternPad(input, enabled, { input = it; error = null }, p.brand)
                        }
                        TextButton(enabled = enabled, onClick = { input = "" }) { Text("Очистить рисунок", color = p.brand) }
                    } else {
                        PinPad(input, enabled, compact = compact, onChange = { input = it; error = null })
                    }
                    // Reserve one line so failed attempts / the countdown do not move the keys.
                    Box(Modifier.fillMaxWidth().heightIn(min = 32.dp).padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center) {
                        if (retrySeconds > 0) Text("Повтори через $retrySeconds с", color = p.brand,
                            fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center)
                        else error?.let { Text(it, color = p.brand, fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center) }
                    }
                    Button(onClick = ::submit, enabled = enabled && (if (pattern) input.length in 4..9 else input.length in 6..12),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = p.brand, contentColor = p.onBrand)) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = p.onBrand, strokeWidth = 2.dp)
                        else Text(if (setup && first == null) "Далее" else if (setup) "Сохранить ключ" else "Открыть")
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center) {
                        TextButton(enabled = !busy, onClick = { cancelAuthentication(); dismiss() },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("Отмена", color = p.subtext) }
                        if (!setup && biometricAvailable && activity != null) {
                            TextButton(enabled = !busy && !biometricActive, onClick = ::biometric,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                Icon(Icons.Outlined.Fingerprint, null, tint = p.brand, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(6.dp)); Text("Биометрия", color = p.brand)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** App-owned PIN keypad. No IME, clipboard, saved state or plaintext accessibility value. */
@Composable
private fun PinPad(value: String, enabled: Boolean, compact: Boolean, onChange: (String) -> Unit) {
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    val fontScale = LocalConfiguration.current.fontScale
    val ring = remember(p.brand) {
        Brush.linearGradient(listOf(lerp(p.brand, Color.White, 0.18f), p.brand,
            p.brand.copy(alpha = 0.42f), p.brand.copy(alpha = 0.82f)))
    }
    Row(Modifier.fillMaxWidth().heightIn(min = 24.dp).clearAndSetSemantics {
        password(); contentDescription = "PIN Zizi, введено ${value.length} цифр"
    }, horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        repeat(maxOf(6, value.length)) { index ->
            Box(Modifier.size(10.dp).border(1.2.dp, p.brand.copy(alpha = 0.8f), CircleShape)
                .background(if (index < value.length) p.brand else Color.Transparent, CircleShape))
        }
    }
    Text("6–12 цифр", color = p.subtext, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Spacer(Modifier.height(if (compact) 10.dp else 14.dp))
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val preferredSize = maxOf(if (compact) 56.dp else 64.dp,
            ((if (compact) 34f else 38f) * fontScale + 12f).dp)
        val keySize = minOf(preferredSize, (maxWidth - 32.dp) / 3).coerceAtLeast(48.dp)
        val keyGap = ((maxWidth - keySize * 3) / 2).coerceIn(8.dp, 24.dp)
        val keys = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "erase"))
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 10.dp)) {
            keys.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(keyGap, Alignment.CenterHorizontally)) {
                    row.forEach { key ->
                        if (key.isEmpty()) Spacer(Modifier.size(keySize))
                        else {
                            val keyEnabled = enabled && (if (key == "erase") value.isNotEmpty() else value.length < 12)
                            TextButton(
                                onClick = {
                                    if (key == "erase") onChange(value.dropLast(1))
                                    else if (value.length < 12) onChange(value + key)
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                },
                                enabled = keyEnabled, modifier = Modifier.size(keySize), shape = CircleShape,
                                border = if (key == "erase") null else if (keyEnabled) BorderStroke(1.25.dp, ring)
                                    else BorderStroke(1.25.dp, p.brand.copy(alpha = 0.2f)),
                                colors = ButtonDefaults.textButtonColors(contentColor = p.text,
                                    containerColor = if (key == "erase") Color.Transparent else p.brand.copy(alpha = 0.035f),
                                    disabledContentColor = p.subtext.copy(alpha = 0.4f)),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                if (key == "erase") Icon(Icons.Outlined.Backspace, "Удалить цифру", modifier = Modifier.size(24.dp))
                                else Text(key, fontSize = if (compact) 29.sp else 32.sp,
                                    lineHeight = if (compact) 34.sp else 38.sp, fontWeight = FontWeight.Light)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PatternPad(value: String, enabled: Boolean, onChange: (String) -> Unit, color: Color) {
    val livePath = remember { mutableStateOf(value) }
    SideEffect { livePath.value = value }
    val change by rememberUpdatedState(onChange)
    val haptics = LocalHapticFeedback.current
    fun append(node: Int) {
        val next = PatternPath.append(livePath.value, node)
        if (next != livePath.value) { livePath.value = next; change(next); haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).semantics {
        contentDescription = "Графический ключ, выбрано ${value.length} точек"
        customActions = (0..8).map { node -> CustomAccessibilityAction("Точка ${node + 1}") { if (enabled) append(node); enabled } }
    }.pointerInput(enabled) {
        if (!enabled) return@pointerInput
        fun hit(pos: Offset): Int? = (0..8).minByOrNull { i ->
            (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance()
        }?.takeIf { i -> (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance() < size.width / 7f }
        detectDragGestures(onDragStart = { pos -> livePath.value = ""; change(""); hit(pos)?.let { append(it) } },
            onDrag = { event, _ -> event.consume(); hit(event.position)?.let(::append) })
    }.pointerInput(enabled) {
        if (enabled) detectTapGestures { pos ->
            val col = (pos.x / (size.width / 3f)).toInt().coerceIn(0, 2)
            val row = (pos.y / (size.height / 3f)).toInt().coerceIn(0, 2)
            append(row * 3 + col)
        }
    }) {
        fun center(i: Int) = Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)
        value.zipWithNext().forEach { (a, b) -> drawLine(color.copy(alpha = 0.6f), center(a - '0'), center(b - '0'), 5.dp.toPx()) }
        for (i in 0..8) drawCircle(if (('0' + i) in value) color else Color.Gray, 9.dp.toPx(), center(i))
    }
}
