package app.ziziplayer.ui.components;

/** Decorative hub artwork selection; never issues a separate catalog request. */
public final class DiscoveryArtworkPolicy {
    private DiscoveryArtworkPolicy() {}
    // Desktop 0.3.5 DiscoveryTile: front +14 degrees, rear -9 degrees.
    public static float rotation(boolean front) { return front ? 14f : -9f; }
    public static int frontIndex(int count, int tileIndex) {
        return count <= 0 ? -1 : Math.floorMod(tileIndex, count);
    }
    public static int backIndex(int count, int tileIndex) {
        return count < 2 ? -1 : (frontIndex(count, tileIndex) + 1) % count;
    }

    /** Actual rotated square bounds, including downward offsets in TiltedArtPair. */
    private static float topRatio(boolean front) {
        double radians = Math.toRadians(Math.abs(rotation(front)));
        float offset = front ? 22f / 130f : 12f / 130f;
        return 0.5f + 0.5f * (float) (Math.cos(radians) + Math.sin(radians)) - offset;
    }
    public static final float PAIR_TOP_RATIO = Math.max(topRatio(false), topRatio(true));
    public static final float TEXT_GAP_DP = 10f;

    /** Fit below the measured text, with an extra inset for the artwork shadow. */
    public static float pairSizeDp(float tileHeightDp, float textBandDp, float wantedDp) {
        float room = (tileHeightDp - textBandDp - TEXT_GAP_DP) / PAIR_TOP_RATIO;
        if (!(room > 0f) || !(wantedDp > 0f)) return 0f;
        return Math.min(wantedDp, room);
    }
    public static float pairTopDp(float tileHeightDp, float sizeDp) {
        return tileHeightDp - sizeDp * PAIR_TOP_RATIO;
    }
}
