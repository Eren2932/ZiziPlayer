package app.ziziplayer.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.os.SystemClock
import app.ziziplayer.privacy.VaultPullPolicy
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.hypot
import kotlin.math.max

/** Отступ капсулы от левого края шторки. Замер эталона: 82px при 2.75 = 30dp. */
private val CAPSULE_INSET = 30.dp
/** Толщина капсулы. Замер эталона: 51px при 2.75 = 18dp. */
private val CAPSULE_WIDTH = 18.dp
/** Поля капсулы сверху и снизу. Замер эталона: 30px и 29px при 2.75 = 11dp. */
private val CAPSULE_MARGIN = 11.dp

/** Pull only the scroll remainder at the top, including an empty LazyColumn.
 * Release, not a fling callback, commits the gesture. There is no header lock button.
 *
 * 6.40.3. Шторка больше не открывается от резкого смаха. Расстояние вводит жест в зону взвода,
 * а взводит его выдержка {@link VaultPullPolicy#HOLD_MS} — палец обязан ДОЖАТЬ и постоять.
 * Выдержку показывает сама шторка: заливка бренд-цветом расходится кругом от капсулы, а капсула
 * растёт снизу вверх ровно на долю выдержки. Отдельной полоски прогресса нет, подписи ровно две.
 */
@Composable
fun VaultPullSurface(enabled: Boolean, unlocked: Boolean, onOpen: () -> Unit, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val threshold = with(density) { VaultPullPolicy.OPEN_DISTANCE_DP.dp.toPx() }
    val haptic = LocalHapticFeedback.current
    val openVaultAction by rememberUpdatedState(onOpen)
    val gesture = remember(enabled, threshold) { VaultPullPolicy(threshold) }
    var pull by remember(gesture) { mutableFloatStateOf(0f) }
    var dragging by remember(gesture) { mutableStateOf(false) }
    var hintStage by remember(gesture) { mutableIntStateOf(0) }
    var hold by remember(gesture) { mutableFloatStateOf(0f) }
    fun sync() {
        pull = gesture.distance; dragging = gesture.isDragging
        // Keep the released hint during collapse rather than flashing the initial prompt.
        if (dragging) { hintStage = gesture.hintStage; hold = gesture.holdProgress }
        if (gesture.takeHaptic()) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    // Палец может стоять неподвижно: без собственного тика выдержка никогда бы не истекла.
    LaunchedEffect(gesture, dragging) {
        while (dragging) {
            withFrameMillis { gesture.tick(SystemClock.uptimeMillis()) }
            sync()
        }
    }
    val connection = remember(enabled, gesture) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.retract(available.y, SystemClock.uptimeMillis())
                sync()
                return Offset(0f, used)
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.pull(available.y, SystemClock.uptimeMillis())
                sync()
                return Offset(0f, used)
            }
            override suspend fun onPreFling(available: Velocity): Velocity =
                if (gesture.consumeFling()) available else Velocity.Zero
        }
    }
    val height by animateFloatAsState(pull, tween(if (dragging) 0 else 160), label = "vault-pull")
    val fill by animateFloatAsState(if (dragging) hold else 0f, tween(if (dragging) 0 else 120), label = "vault-fill")
    val p = LocalPalette.current
    val base = if (unlocked) lerp(p.surface, p.brand, 0.22f) else p.surface
    val armed = hintStage == 1
    val heightDp = with(density) { height.toDp() }
    val capsuleFull = (heightDp - CAPSULE_MARGIN * 2).coerceAtLeast(CAPSULE_WIDTH)
    val capsuleHeight = CAPSULE_WIDTH + (capsuleFull - CAPSULE_WIDTH) * fill
    val capsuleTint = lerp(p.text, p.onBrand, fill)
    Column(Modifier.fillMaxSize().nestedScroll(connection).semantics {
        // TalkBack has the same action without adding a visible alternative entry point.
        if (enabled) customActions = listOf(CustomAccessibilityAction("Открыть скрытые папки") {
            openVaultAction.invoke(); true
        })
    }.pointerInput(enabled, gesture) {
        if (enabled) awaitEachGesture {
            var normalEnd = false
            try {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                gesture.begin(SystemClock.uptimeMillis()); sync()
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val pressed = event.changes.any { it.pressed }
                    gesture.tick(SystemClock.uptimeMillis())
                    if (!pressed) {
                        normalEnd = true
                        val shouldOpen = gesture.release()
                        sync()
                        if (shouldOpen) openVaultAction.invoke()
                    }
                } while (pressed)
            } finally {
                if (!normalEnd) { gesture.cancel(); sync() }
            }
        }
    }) {
        Box(Modifier.fillMaxWidth().height(heightDp).clipToBounds().drawBehind {
            drawRect(base)
            // Круговой reveal из центра капсулы: это и есть индикатор выдержки.
            if (fill > 0f) {
                val cx = CAPSULE_INSET.toPx() + CAPSULE_WIDTH.toPx() / 2f
                val cy = size.height / 2f
                val reach = hypot(max(cx, size.width - cx), max(cy, size.height - cy))
                drawCircle(p.brand, radius = reach * fill, center = Offset(cx, cy))
            }
        }, contentAlignment = Alignment.Center) {
            if (heightDp > CAPSULE_WIDTH) {
                Box(
                    Modifier.align(Alignment.BottomStart)
                        .padding(start = CAPSULE_INSET, bottom = CAPSULE_MARGIN)
                        .width(CAPSULE_WIDTH).height(capsuleHeight)
                        .clip(CircleShape).drawBehind { drawRect(capsuleTint) },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Icon(ZiziIcons.ChevronDown, contentDescription = null,
                        tint = base, modifier = Modifier.width(CAPSULE_WIDTH).height(CAPSULE_WIDTH))
                }
                Crossfade(targetState = armed, animationSpec = tween(140), label = "vault-pull-hint",
                    modifier = Modifier.padding(horizontal = 56.dp)) { released ->
                    Text(
                        if (released) "Отпусти для открытия" else "Потяни для скрытых папок",
                        color = if (released) p.onBrand else p.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Box(Modifier.weight(1f)) { content.invoke() }
    }
}
