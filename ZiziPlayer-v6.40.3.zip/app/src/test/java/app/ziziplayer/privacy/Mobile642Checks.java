package app.ziziplayer.privacy;

import app.ziziplayer.ui.components.DiscoveryArtworkPolicy;

/** Actual production Java execution, not a model of Compose layout or device input. */
public final class Mobile642Checks {
    private static int checks;
    private static void check(boolean value, String label) {
        checks++; if (!value) throw new AssertionError(label);
    }
    private static void lockout() {
        check(PrivacyRules.MAX_RETRY_MS == 120000L, "two-minute maximum");
        long[] expected = {0, 0, 0, 0, 0, 30000, 60000, 120000, 120000, 120000};
        for (int i = 0; i < expected.length; i++) check(PrivacyRules.retryDelay(i) == expected[i], "error " + i);
        for (int i = 7; i < 10000; i++) check(PrivacyRules.retryDelay(i) == 120000L, "no further doubling");
        check(PrivacyRules.retryDelay(Integer.MAX_VALUE) == 120000L, "large failure count");
        check(PrivacyRules.retryDelay(Integer.MIN_VALUE) == 0L, "negative failure count");
        long now = 1800000000000L;
        long deadline = PrivacyRules.cappedRetryAt(now + 300000L, now);
        check(deadline == now + 120000L, "shorten persisted legacy deadline");
        // Re-read the shortened deadline every second, like prefs after apply().
        for (int second = 0; second <= 180; second++) {
            long t = now + second * 1000L;
            deadline = PrivacyRules.cappedRetryAt(deadline, t);
            check(PrivacyRules.remainingSeconds(deadline, t) == Math.max(0, 120 - second), "countdown not pinned to 120");
        }
        check(PrivacyRules.cappedRetryAt(now + 30000, now) == now + 30000, "do not extend shorter block");
        check(PrivacyRules.cappedRetryAt(now - 1, now) == now - 1, "do not resurrect expired block");
        check(PrivacyRules.remainingSeconds(now + 1, now) == 1, "round up last millisecond");
        check(PrivacyRules.remainingSeconds(now + 119001, now) == 120, "ceiling with fraction");
        check(PrivacyRules.remainingSeconds(now, now) == 0, "expired exactly");
        check(PrivacyRules.remainingSeconds(Long.MAX_VALUE, now) == 120, "invalid far future is bounded");
        check(PrivacyRules.cappedRetryAt(Long.MAX_VALUE, Long.MAX_VALUE - 10) == Long.MAX_VALUE, "addition no overflow");
    }
    private static void curtain() {
        // 6.40.3 переписал смысл этой проверки: расстояние больше не открывает шторку само по себе.
        check(VaultPullPolicy.OPEN_DISTANCE_DP == 66f, "reference travel");
        VaultPullPolicy p = new VaultPullPolicy(VaultPullPolicy.OPEN_DISTANCE_DP);
        p.begin(0L); p.pull(72f / VaultPullPolicy.RESISTANCE, 0L);
        check(!p.isArmed() && p.getHintStage() == 0, "distance alone never arms");
        check(!p.release(), "old distance no longer opens immediately");
        p.begin(0L); p.pull(1000f, 0L); p.tick(VaultPullPolicy.HOLD_MS);
        check(p.isArmed() && p.getHintStage() == 1, "dwell arms");
        check(p.getProgress() == 1f && p.takeHaptic(), "full progress and one haptic");
        p.retract(-10f, VaultPullPolicy.HOLD_MS);
        check(p.isArmed(), "finger jitter tolerated");
        check(p.release(), "armed release works in hysteresis band");
        check(!p.release(), "one dialog only");
        p.cancel();
        check(!p.release() && p.getProgress() == 0f && p.getHintStage() == 0, "cancel fails closed");
        check(p.pull(1000f, 0L) == 0f, "scroll without down ignored");
        p.begin(0L); p.pull(Float.NaN, 0L); p.pull(Float.POSITIVE_INFINITY, 0L);
        check(p.getDistance() == 0f, "invalid scroll ignored");
        p.pull(100000f, 0L); check(p.getDistance() <= 66f * (118f / 66f) + 0.01f, "bounded height");
        check(p.consumeFling() && !p.release(), "fling token without dwell cannot open");
    }

    private static void artwork() {
        check(DiscoveryArtworkPolicy.rotation(false) == -9f, "desktop rear angle");
        check(DiscoveryArtworkPolicy.rotation(true) == 14f, "desktop front angle");
        check(DiscoveryArtworkPolicy.frontIndex(0, 0) == -1 && DiscoveryArtworkPolicy.backIndex(0, 0) == -1, "empty pool");
        check(DiscoveryArtworkPolicy.frontIndex(1, 200) == 0 && DiscoveryArtworkPolicy.backIndex(1, 200) == -1, "one cover not duplicated");
        for (int size = 2; size <= 40; size++) for (int tile = -24; tile <= 60; tile++) {
            int front = DiscoveryArtworkPolicy.frontIndex(size, tile), rear = DiscoveryArtworkPolicy.backIndex(size, tile);
            check(front >= 0 && front < size && rear >= 0 && rear < size, "safe pair indexes");
            check(front != rear, "two distinct images");
            check(front == DiscoveryArtworkPolicy.frontIndex(size, tile), "stable artwork across recomposition");
        }
    }
    public static void main(String[] args) {
        lockout(); curtain(); artwork();
        System.out.println("PASS: " + checks + " production Java assertions (120s lockout / staged curtain / cover pairs)");
    }
}
