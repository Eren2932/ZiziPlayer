package app.ziziplayer.privacy;

import app.ziziplayer.playback.DuckRecoveryPolicy;
import app.ziziplayer.playback.AudioInterruptionPolicy;

/** Executes the production state machines; no claim to execute Compose or AudioManager. */
public final class Mobile641Checks {
    private static int checks;
    private static void check(boolean ok, String label) {
        checks++; if (!ok) throw new AssertionError(label);
    }
    private static void pullTests() {
        // 6.40.3: те же гарантии, но взвод требует выдержки. Время подаётся явно.
        long hold = VaultPullPolicy.HOLD_MS;
        VaultPullPolicy p = new VaultPullPolicy(72f);
        check(p.pull(200f, 0L) == 0f, "no scroll without pointer down");
        p.begin(0L); p.pull(50f, 0L); check(!p.release(), "short pull never opens");
        p.begin(0L); p.pull(150f, 0L); p.tick(hold);
        check(p.takeHaptic(), "armed haptic");
        check(!p.takeHaptic(), "only one haptic consumed");
        check(p.release(), "opens on UP without any fling callback");
        check(!p.release(), "release cannot open twice");
        check(p.consumeFling(), "consume fling after UP");
        check(!p.consumeFling(), "fling token consumed once");
        p.begin(0L); p.pull(150f, 0L); p.tick(hold);
        check(p.consumeFling(), "fling arriving before observer");
        check(p.release(), "earlier fling does not erase armed release");
        p.begin(0L); p.pull(150f, 0L); p.tick(hold); p.cancel();
        check(!p.release(), "pointer cancellation fails closed");
        check(p.getDistance() == 0f && !p.isDragging(), "cancel resets visuals");
        p.begin(0L); p.pull(160f, 0L); p.tick(hold); p.retract(-100f, hold);
        check(!p.release(), "drag back under threshold");
        p.begin(0L); p.pull(200f, 0L); p.tick(hold); p.takeHaptic();
        p.retract(-200f, hold); p.pull(200f, hold); p.tick(hold * 2);
        check(!p.takeHaptic(), "one haptic per finger gesture even after recrossing");
        p.cancel(); p.begin(0L); p.pull(200f, 0L); p.tick(hold);
        check(p.takeHaptic(), "new gesture rearms haptic");
        p.retract(-1000f, hold); check(p.getDistance() == 0f, "retract clamped");
        check(p.pull(Float.NaN, hold) == 0f, "NaN ignored");
        check(p.pull(Float.POSITIVE_INFINITY, hold) == 0f, "infinite ignored");
        for (int i = 1; i <= 10000; i++) {
            p.begin(0L); p.pull(i / 10f, 0L); p.tick(hold);
            check(p.getDistance() <= 72f * (118f / 66f) + 0.01f, "height cap");
            boolean armed = p.getDistance() >= 72f;
            check(p.release() == armed, "threshold boundary " + i);
            check(!p.release(), "no duplicate " + i);
        }
    }

    private static void audioTests() {
        DuckRecoveryPolicy p = new DuckRecoveryPolicy();
        check(p.observe(0, 0) == p.HOLD, "inactive");
        p.begin(); check(p.observe(0, 0) == p.HOLD, "focus may precede foreign player start");
        check(p.observe(0, 10000) == p.HOLD, "no blind timeout when competitor invisible");
        check(p.confirmationDelay(10000) == -1, "no perpetual poll");
        check(p.observe(1, 10001) == p.HOLD, "initial duck already active");
        check(p.observe(0, 10010) == p.HOLD, "foreign stopped but focus retained");
        check(p.confirmationDelay(10010) == p.QUIET_MS, "one confirmation scheduled");
        check(p.observe(0, 10249) == p.HOLD, "debounce not yet complete");
        check(p.observe(0, 10250) == p.RESTORE, "restore without AUDIOFOCUS_GAIN");
        check(p.observe(0, 11000) == p.HOLD, "no repeated fades");
        check(p.confirmationDelay(11000) == -1, "no polling after restoration");
        check(p.observe(1, 12000) == p.DUCK, "resume voice in same focus lease re-ducks");
        check(p.observe(1, 13000) == p.HOLD, "duplicate foreign callback");
        p.observe(0, 14000); check(p.observe(1, 14100) == p.HOLD, "short gap not restored");
        check(p.confirmationDelay(14100) == -1, "foreign resumed cancels confirmation");
        p.observe(0, 15000); p.observe(-1, 15100);
        check(p.confirmationDelay(16000) == -1, "unknown snapshot cancels evidence");
        check(p.observe(0, 16000) == p.HOLD, "unknown gap restarts debounce");
        check(p.observe(0, 16240) == p.RESTORE, "fresh stable evidence recovers");
        p.cancel(); check(p.observe(2, 17000) == p.HOLD, "pause/cancel rejects stale callbacks");
        check(!p.isWatching() && p.confirmationDelay(17000) == -1, "cancel tears down timers");
        p.begin(); p.observe(1, 18000); p.observe(0, 18010); p.cancel();
        check(p.observe(0, 19000) == p.HOLD, "pending confirmation cannot restore after gain/loss/release");
        check(p.competitors(true, true, 1, 1) == 0, "own player not foreign activity");
        check(p.competitors(true, true, 2, 2) == 1, "same-attributes other player still counted");
        check(p.competitors(true, true, 2, 1) == 1, "speech/unknown usage counted conservatively");
        check(p.competitors(true, true, 3, 1) == 2, "multiple external players");
        check(p.competitors(false, true, 1, 1) == -1, "buffering cannot be used as own evidence");
        check(p.competitors(true, false, 1, 1) == -1, "call mode never restores");
        check(p.competitors(true, true, 0, 0) == -1, "missing OEM configs not mistaken for silence");
        check(p.competitors(true, true, 1, 0) == -1, "missing own candidate");
        for (int i = 0; i < 1000; i++) {
            long t = i * 2000L;
            p.begin(); p.observe(1, t); p.observe(0, t + 1);
            check(p.observe(0, t + 241) == p.RESTORE, "cycle restore");
            check(p.observe(1, t + 242) == p.DUCK, "cycle reduck");
            p.cancel(); check(p.observe(0, t + 1000) == p.HOLD, "cycle cancel");
        }
        // Smooth retargeting stays within base-volume bounds; never uses the system volume.
        for (int i = 0; i <= 1000; i++) {
            float volume = AudioInterruptionPolicy.interpolate(0.08f, 1f, i / 1000f);
            check(volume >= 0.08f && volume <= 1f, "fade bounds");
        }
    }
    public static void main(String[] args) {
        pullTests(); audioTests();
        System.out.println("PASS: " + checks + " production Java assertions (gesture + duck recovery)");
    }
}
