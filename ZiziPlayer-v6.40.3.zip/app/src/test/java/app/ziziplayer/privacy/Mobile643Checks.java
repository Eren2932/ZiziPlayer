package app.ziziplayer.privacy;

import app.ziziplayer.ui.components.DiscoveryArtworkPolicy;

/** 6.40.3. Ровно одна тема: шторку скрытых папок нельзя открыть резким смахом.
 * Исполняется настоящий production-класс, а не его модель. Время подаётся явно, поэтому
 * «быстро» и «медленно» здесь — не метафора, а миллисекунды.
 */
public final class Mobile643Checks {
    private static int checks;
    private static void check(boolean value, String label) {
        checks++; if (!value) throw new AssertionError(label);
    }

    private static VaultPullPolicy fresh() {
        return new VaultPullPolicy(VaultPullPolicy.OPEN_DISTANCE_DP);
    }

    /** Жест пальцем: travel dp за span мс, кадрами по 8 мс, затем UP. */
    private static boolean gesture(VaultPullPolicy p, float travel, long span, long holdAfter) {
        long t = 0L;
        p.begin(t);
        int frames = Math.max(1, (int) (span / 8L));
        for (int i = 0; i < frames; i++) {
            t += 8L;
            p.pull(travel / frames, t);
        }
        for (long h = 0; h < holdAfter; h += 8L) {
            t += 8L;
            p.tick(t);
        }
        return p.release();
    }

    private static void flickIsRejected() {
        // Ровно тот сценарий, из-за которого версия и появилась: 175dp пальца за 64 мс.
        check(!gesture(fresh(), 175f, 64L, 0L), "flick must not open");
        check(!gesture(fresh(), 400f, 40L, 0L), "violent flick must not open");
        check(!gesture(fresh(), 1000f, 8L, 0L), "single-frame slam must not open");
        for (long span = 8L; span < VaultPullPolicy.HOLD_MS; span += 8L) {
            check(!gesture(fresh(), 300f, span, 0L), "no open below dwell, span " + span);
        }
    }

    private static void deliberateOpens() {
        check(gesture(fresh(), 300f, 240L, VaultPullPolicy.HOLD_MS), "press and hold opens");
        check(gesture(fresh(), 175f, 400L, 400L), "slow deliberate pull opens");
        // Граница выдержки: на миллисекунду раньше — закрыто, ровно в срок — открыто.
        VaultPullPolicy p = fresh();
        p.begin(0L); p.pull(1000f, 0L);
        p.tick(VaultPullPolicy.HOLD_MS - 1L);
        check(!p.isArmed(), "one millisecond short");
        p.tick(VaultPullPolicy.HOLD_MS);
        check(p.isArmed() && p.release(), "exact dwell arms");
    }

    private static void dwellCannotBeFaked() {
        // Уйти из зоны и вернуться — значит начать выдержку заново, а не досчитать старую.
        VaultPullPolicy p = fresh();
        p.begin(0L); p.pull(1000f, 0L);
        p.tick(200L);
        p.retract(-1000f, 210L);
        check(p.getHoldProgress() == 0f, "leaving the zone drops the dwell");
        p.pull(1000f, 220L);
        p.tick(420L);
        check(!p.isArmed(), "old dwell is not credited");
        p.tick(520L);
        check(p.isArmed(), "fresh dwell completes");
        // Дрожание в пределах гистерезиса выдержку не трогает.
        VaultPullPolicy j = fresh();
        j.begin(0L); j.pull(1000f, 0L);
        for (long t = 8L; t <= 280L; t += 8L) { j.retract(-1f, t); j.pull(1f, t); }
        check(!j.isArmed(), "still short of the dwell");
        j.tick(VaultPullPolicy.HOLD_MS);
        check(j.isArmed(), "jitter did not restart the dwell");
        // Часы назад не приближают взвод.
        VaultPullPolicy b = fresh();
        b.begin(1000L); b.pull(1000f, 1000L);
        b.tick(900L); b.tick(500L); b.tick(0L);
        check(!b.isArmed(), "backwards clock cannot arm");
        b.tick(1000L + VaultPullPolicy.HOLD_MS);
        check(b.isArmed(), "monotonic clock still arms");
    }

    private static void surfaceContract() {
        VaultPullPolicy p = fresh();
        check(p.getHintStage() == 0 && p.getHoldProgress() == 0f, "idle curtain");
        p.begin(0L); p.pull(1000f, 0L);
        float previous = -1f;
        for (long t = 0; t <= VaultPullPolicy.HOLD_MS + 64L; t += 8L) {
            p.tick(t);
            float fill = p.getHoldProgress();
            check(fill >= previous, "fill never goes backwards");
            check(fill >= 0f && fill <= 1f, "fill bounds");
            check(p.getHintStage() == 0 || p.getHintStage() == 1, "exactly two hint stages");
            check(p.getHintStage() == (p.isArmed() ? 1 : 0), "hint follows armed");
            previous = fill;
        }
        check(p.getHoldProgress() == 1f, "fill saturates");
        // Растяг ограничен эталонным пределом и не зависит от того, сколько ещё проехал палец.
        p.pull(100000f, 1000L);
        float ceiling = VaultPullPolicy.OPEN_DISTANCE_DP * (VaultPullPolicy.MAX_DISTANCE_DP / VaultPullPolicy.OPEN_DISTANCE_DP);
        check(p.getDistance() <= ceiling + 0.01f, "bounded stretch");
        check(p.getProgress() == 1f, "progress saturates");
        check(p.release(), "held gesture opens on release");
        check(!p.isDragging() && p.getDistance() == 0f, "release resets");
    }

    private static void repeatedGestures() {
        VaultPullPolicy p = fresh();
        for (int i = 0; i < 1000; i++) {
            long t = 1000L * i;
            p.begin(t); p.pull(1000f, t); p.tick(t + 299);
            check(!p.isArmed() && !p.takeHaptic(), "no early arm or haptic");
            p.tick(t + 300);
            check(p.isArmed() && p.takeHaptic() && !p.takeHaptic(), "one haptic");
            p.retract(-1000f, t + 301);
            check(!p.isArmed(), "upward reversal disarms");
            p.pull(1000f, t + 302); p.tick(t + 601);
            check(!p.isArmed(), "return requires full new hold");
            p.tick(t + 602);
            check(p.isArmed() && !p.takeHaptic(), "no second buzz in same gesture");
            if (i % 2 == 0) {
                p.cancel(); check(!p.release() && !p.consumeFling(), "cancel fails closed");
            } else {
                check(p.release() && !p.release(), "release opens once");
                check(p.consumeFling() && !p.consumeFling(), "fling swallowed once");
            }
            p.tick(t + 999); p.pull(999f, t + 999);
            check(!p.isArmed() && p.getDistance() == 0f, "events after end cannot reopen");
        }
    }

    private static void artworkBounds() {
        // Independent corner transform, not just a second copy of pairTopDp().
        // Text band is measured by Compose in production; enumerate possible measured heights.
        for (int screen = 280; screen <= 840; screen += 4) {
            float width = (screen - 44f - 10f) / 2f;
            for (float ratio : new float[] {1.95f, 1.34f}) {
                float height = width / ratio;
                for (int band = 16; band <= 200; band += 4) {
                    float area = Math.max(0f, height - band - 10f);
                    float size = DiscoveryArtworkPolicy.pairSizeDp(area, 0f, 94f);
                    check(Float.isFinite(size) && size >= 0f && size <= 94f, "cover size bounds");
                    if (size == 0f) continue; // UI omits decorative art when it cannot fit.
                    for (boolean front : new boolean[] {false, true}) {
                        double angle = Math.toRadians(front ? 14 : -9);
                        double cy = area - size / 2 + size * (front ? 22.0 / 130 : 12.0 / 130);
                        for (int x : new int[] {-1, 1}) for (int y : new int[] {-1, 1}) {
                            double top = cy + size / 2 * (x * Math.sin(angle) + y * Math.cos(angle));
                            check(top >= 10.0 - 0.001, "rotated corner clears artwork inset");
                        }
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        flickIsRejected(); deliberateOpens(); dwellCannotBeFaked(); surfaceContract(); repeatedGestures(); artworkBounds();
        System.out.println("PASS: " + checks + " production Java assertions (vault dwell, cancellation, repeated gestures, rotated artwork bounds)");
    }
}
