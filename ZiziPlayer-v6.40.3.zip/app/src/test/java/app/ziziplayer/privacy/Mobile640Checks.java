package app.ziziplayer.privacy;

import app.ziziplayer.playback.AudioInterruptionPolicy;
import java.util.*;

/** Executable offline with a JDK; no claim to emulate Media3, Compose or biometric hardware. */
public final class Mobile640Checks {
    private static int assertions;
    private static void check(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        AudioInterruptionPolicy p = new AudioInterruptionPolicy();
        check(!p.gain(), "initial gain must not start music");
        p.transientLoss(true); p.transientLoss(false);
        check(p.gain(), "repeated transient loss retains playing intent");
        check(!p.gain(), "gain consumed only once");
        p.transientLoss(false); check(!p.gain(), "paused playback must stay paused");
        for (String reason : List.of("user pause", "noisy", "permanent loss", "stop", "release", "failed request")) {
            p.transientLoss(true); p.cancel(); check(!p.gain(), reason + " cancels auto resume");
        }
        float previous = 1f;
        for (int i = 0; i <= 1000; i++) {
            float gain = AudioInterruptionPolicy.interpolate(1f, AudioInterruptionPolicy.DUCK_GAIN, i / 1000f);
            check(gain <= previous + 0.000001f && gain >= 0.07999f, "attack monotonic and bounded");
            previous = gain;
        }
        check(Math.abs(previous - 0.08f) < 0.000001f, "duck endpoint");
        for (int seed = 0; seed < 100; seed++) {
            Random random = new Random(seed);
            String path = "";
            for (int i = 0; i < 100; i++) {
                path = PrivacyRules.appendPattern(path, random.nextInt(13) - 2);
                check(path.length() <= 9 && path.chars().distinct().count() == path.length(), "pattern is bounded and unique");
                check(path.chars().allMatch(c -> c >= '0' && c <= '8'), "pattern range");
            }
        }
        check(PrivacyRules.appendPattern("0", 8).equals("048"), "diagonal center inserted");
        check(PrivacyRules.appendPattern("0", 2).equals("012"), "horizontal center inserted");
        check(PrivacyRules.appendPattern("0", 6).equals("036"), "vertical center inserted");
        check(PrivacyRules.appendPattern("4", 4).equals("4"), "duplicate ignored");
        check(PrivacyRules.appendPattern("04", 8).equals("048"), "center not duplicated");
        check(PrivacyRules.appendPattern("0", 5).equals("05"), "non-collinear move has no midpoint");
        check(PrivacyRules.retryDelay(4) == 0 && PrivacyRules.retryDelay(5) == 30000, "lockout boundary");
        check(PrivacyRules.retryDelay(20) == 120000, "lockout ceiling");
        for (boolean unlocked : new boolean[]{false, true}) for (boolean remote : new boolean[]{false, true}) {
            check(PrivacyRules.blocks(unlocked, remote, "Music", Set.of("Music")) == (!unlocked && !remote), "gate combinations");
            check(!PrivacyRules.blocks(unlocked, remote, "Music2", Set.of("Music")), "exact folder match");
        }
        System.out.println("PASS: " + assertions + " production-rule assertions (focus intent, fade, pattern, privacy, lockout).");
        System.out.println("Not an Android compilation, rendered UI, hardware authentication or audio listening test.");
    }
}
