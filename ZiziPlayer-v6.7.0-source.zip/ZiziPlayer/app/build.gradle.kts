plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "app.ziziplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.ziziplayer"
        minSdk = 26
        targetSdk = 35
        versionCode = 16
        versionName = "6.7.0"
    }

    signingConfigs {
        if (System.getenv("SIGNING_STORE_FILE") != null) create("release") {
            storeFile = file(System.getenv("SIGNING_STORE_FILE"))
            storePassword = System.getenv("SIGNING_STORE_PASSWORD")
            keyAlias = System.getenv("SIGNING_KEY_ALIAS")
            keyPassword = System.getenv("SIGNING_KEY_PASSWORD")
        }
    }
    buildTypes {
        release {
            // Signed with the release key when CI provides one, otherwise with the debug key so
            // the optimised build can still be installed straight from the artifact.
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

// Schema history is required to write real migrations instead of wiping user data.
ksp { arg("room.schemaLocation", "$projectDir/schemas") }


dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")

    implementation("androidx.room:room-runtime:2.7.1")
    implementation("androidx.room:room-ktx:2.7.1")
    ksp("androidx.room:room-compiler:2.7.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    // Installs src/main/baseline-prof.txt on API 26-30, where the platform does not read the
    // profile out of the APK by itself. On API 31+ it is the system that applies it and this
    // dependency is only the initializer. ~120 KB, no code of ours calls into it.
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    // androidx.documentfile and androidx.palette were both dropped in 6.3: the scanner now queries
    // DocumentsContract directly (DocumentFile was the bottleneck, not a helper - every property
    // read was a separate IPC round trip), and palette was already superseded by the in-app
    // quantiser in 6.2. Neither was referenced any more, both were still being packaged, and both
    // still had keep rules pointed at them.
}
