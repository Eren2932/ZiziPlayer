package app.ziziplayer.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

/** One catalogue answer, already normalised across providers. */
data class RemoteMatch(
    val artist: String,
    val title: String,
    val album: String?,
    val coverUrl: String?,
    val durationMs: Long,
    val source: String,
    val score: Int = 0
)

/**
 * The HTTP layer, written on HttpURLConnection on purpose.
 *
 * No OkHttp, no Retrofit, no Moshi: five GET requests that return JSON do not justify three
 * dependencies, and every dependency added here is one I cannot compile-check from my side. The
 * JSON parser used is `org.json`, which is part of the Android framework itself.
 *
 * Everything about this class is defensive, because it runs on a phone on mobile data:
 *   - hard connect/read timeouts, so a hanging provider cannot pin a coroutine for a minute;
 *   - a response size cap, so a misbehaving endpoint cannot be streamed into OOM;
 *   - gzip, because these payloads are 10-50 KB of JSON and the user pays for the bytes;
 *   - a per-host minimum interval, which is not politeness but a hard requirement for
 *     MusicBrainz: over ~1 req/s it bans by IP, and a banned IP is a user whose feature silently
 *     stopped working.
 */
object RemoteMeta {

    private const val CONNECT_TIMEOUT = 8_000
    private const val READ_TIMEOUT = 10_000
    private const val MAX_BODY = 512 * 1024
    private const val MAX_IMAGE = 3 * 1024 * 1024

    /**
     * MusicBrainz requires a descriptive User-Agent with a contact and will serve 403 to a
     * default Java one. It is also what identifies Zizi in their logs if we ever misbehave.
     */
    private const val USER_AGENT =
        "ZiziPlayer/6.7 ( https://github.com/Eren2932/ZiziPlayer )"

    private val throttles = HashMap<String, HostThrottle>()
    private val throttleLock = Mutex()

    private class HostThrottle(val minIntervalMs: Long) {
        val mutex = Mutex()
        var lastAtMs = 0L
    }

    private suspend fun throttleFor(host: String): HostThrottle = throttleLock.withLock {
        throttles.getOrPut(host) {
            HostThrottle(
                when {
                    host.contains("musicbrainz") -> 1_100L
                    host.contains("coverartarchive") -> 500L
                    else -> 120L
                }
            )
        }
    }

    private suspend fun <T> onHost(host: String, block: suspend () -> T): T {
        val throttle = throttleFor(host)
        return throttle.mutex.withLock {
            val wait = throttle.lastAtMs + throttle.minIntervalMs - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            try { block() } finally { throttle.lastAtMs = System.currentTimeMillis() }
        }
    }

    /** Raised for retryable conditions only (timeout, 5xx, 429). A 404 is an answer, not a fault. */
    class Transient(message: String) : Exception(message)

    private suspend fun get(url: String, accept: String = "application/json"): String? =
        withContext(Dispatchers.IO) {
            val host = runCatching { URL(url).host }.getOrNull() ?: return@withContext null
            onHost(host) {
                var connection: HttpURLConnection? = null
                try {
                    connection = (URL(url).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = CONNECT_TIMEOUT
                        readTimeout = READ_TIMEOUT
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", USER_AGENT)
                        setRequestProperty("Accept", accept)
                        setRequestProperty("Accept-Encoding", "gzip")
                    }
                    val code = connection.responseCode
                    if (code == 429 || code >= 500) throw Transient("HTTP $code")
                    if (code !in 200..299) return@onHost null
                    val stream = body(connection) ?: return@onHost null
                    readText(stream, MAX_BODY)
                } catch (e: Transient) {
                    throw e
                } catch (e: Exception) {
                    // Timeouts and DNS failures are conditions, not bugs: retryable, not logged loud.
                    throw Transient(e.javaClass.simpleName)
                } finally {
                    connection?.disconnect()
                }
            }
        }

    private fun body(connection: HttpURLConnection): InputStream? {
        val raw = connection.inputStream ?: return null
        return if (connection.contentEncoding?.contains("gzip", ignoreCase = true) == true) {
            GZIPInputStream(raw)
        } else raw
    }

    private fun readText(stream: InputStream, cap: Int): String {
        stream.use { input ->
            val out = ByteArrayOutputStream(16 * 1024)
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > cap) throw Transient("body over cap")
                out.write(buffer, 0, read)
            }
            return out.toString("UTF-8")
        }
    }

    private val SIZE_SEGMENT = Regex("/\\d{2,4}x\\d{2,4}-")

    /**
     * A small derivative of a cover URL, for the manual picker's list.
     *
     * Fifteen candidates at 600x600 is ~1.5 MB downloaded so the user can glance at a list, on a
     * connection they may be paying for by the megabyte. All three providers expose the size in the
     * URL itself, so the thumbnail costs a string edit rather than another API. Any URL shape we do
     * not recognise is returned untouched: a slightly expensive picture beats a broken one.
     *
     * The full-size URL is still what gets stored and downloaded once a candidate is chosen.
     */
    fun thumbUrl(url: String): String = when {
        // iTunes: .../source/600x600bb.jpg
        url.contains("600x600bb") -> url.replace("600x600bb", "170x170bb")
        // Deezer: .../cover/<hash>/1000x1000-000000-80-0-0.jpg
        SIZE_SEGMENT.containsMatchIn(url) && url.contains("dzcdn.net") ->
            SIZE_SEGMENT.replace(url, "/170x170-")
        // Cover Art Archive: .../release/<mbid>/front-500
        url.endsWith("front-500") -> url.removeSuffix("front-500") + "front-250"
        else -> url
    }

    /** Cover bytes. Returns null on anything unexpected; never throws for a missing image. */
    suspend fun fetchImage(url: String): ByteArray? = withContext(Dispatchers.IO) {
        val host = runCatching { URL(url).host }.getOrNull() ?: return@withContext null
        onHost(host) {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = CONNECT_TIMEOUT
                    readTimeout = READ_TIMEOUT
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", USER_AGENT)
                    setRequestProperty("Accept", "image/*")
                }
                if (connection.responseCode !in 200..299) return@onHost null
                val length = connection.contentLength
                if (length > MAX_IMAGE) return@onHost null
                val stream = connection.inputStream ?: return@onHost null
                stream.use { input ->
                    val out = ByteArrayOutputStream(64 * 1024)
                    val buffer = ByteArray(32 * 1024)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        total += read
                        if (total > MAX_IMAGE) return@onHost null
                        out.write(buffer, 0, read)
                    }
                    out.toByteArray()
                }
            } catch (e: Exception) {
                null
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    /* ------------------------------------------------------------------ providers */

    /**
     * iTunes Search. No key, no registration, generous rate limit, and the best hit rate on
     * mainstream music. `artworkUrl100` is a resized derivative: swapping the size segment for
     * 600x600 is the documented trick and gives a cover big enough for the player.
     */
    suspend fun itunes(ask: TrackQuery.Ask): List<RemoteMatch> {
        val url = "https://itunes.apple.com/search?media=music&entity=song&limit=8&term=${encode(ask.term)}"
        val json = get(url) ?: return emptyList()
        val results = runCatching { JSONObject(json).optJSONArray("results") }.getOrNull() ?: return emptyList()
        return results.objects().mapNotNull { item ->
            val artist = item.optString("artistName").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val title = item.optString("trackName").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            RemoteMatch(
                artist = artist,
                title = title,
                album = item.optString("collectionName").takeIf { it.isNotBlank() },
                coverUrl = item.optString("artworkUrl100").takeIf { it.isNotBlank() }
                    ?.replace("100x100bb", "600x600bb"),
                durationMs = item.optLong("trackTimeMillis", 0L),
                source = "itunes"
            )
        }
    }

    /**
     * Deezer public search. Also keyless, and it is the one that knows the CIS rap / underground
     * catalogue iTunes has never heard of - which is most of what a Telegram-sourced library is.
     */
    suspend fun deezer(ask: TrackQuery.Ask): List<RemoteMatch> {
        val query = if (ask.artist.isNullOrBlank()) {
            "track:\"${ask.title}\""
        } else {
            "artist:\"${ask.artist}\" track:\"${ask.title}\""
        }
        val json = get("https://api.deezer.com/search?limit=8&q=${encode(query)}") ?: return emptyList()
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return emptyList()
        // Deezer answers 200 with {"error":{...}} for a malformed query - treat as no results.
        if (root.has("error") && root.optJSONObject("data") == null && !root.has("data")) return emptyList()
        val data = root.optJSONArray("data") ?: return emptyList()
        return data.objects().mapNotNull { item ->
            val artist = item.optJSONObject("artist")?.optString("name")?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            val title = item.optString("title").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val album = item.optJSONObject("album")
            RemoteMatch(
                artist = artist,
                title = title,
                album = album?.optString("title")?.takeIf { it.isNotBlank() },
                coverUrl = album?.optString("cover_xl")?.takeIf { it.isNotBlank() }
                    ?: album?.optString("cover_big")?.takeIf { it.isNotBlank() },
                durationMs = item.optLong("duration", 0L) * 1000L,
                source = "deezer"
            )
        }
    }

    /**
     * MusicBrainz + Cover Art Archive, the third pass.
     *
     * Two requests instead of one (recording search, then the cover for its release), which is why
     * it is last: it is the slowest and the most rate-limited of the three. Its value is being an
     * open database that contains obscure releases the commercial catalogues drop.
     *
     * The cover URL is NOT verified here - CAA answers 404 for a release with no art, and finding
     * that out costs another request. The download step treats a 404 as "no cover" and keeps the
     * artist/title, which is still an improvement over "Неизвестный артист".
     */
    suspend fun musicbrainz(ask: TrackQuery.Ask): List<RemoteMatch> {
        val lucene = buildString {
            append("recording:\"").append(ask.title.replace('"', ' ')).append('"')
            if (!ask.artist.isNullOrBlank()) {
                append(" AND artist:\"").append(ask.artist.replace('"', ' ')).append('"')
            }
        }
        val json = get(
            "https://musicbrainz.org/ws/2/recording?fmt=json&limit=6&query=${encode(lucene)}"
        ) ?: return emptyList()
        val recordings = runCatching { JSONObject(json).optJSONArray("recordings") }.getOrNull()
            ?: return emptyList()
        return recordings.objects().mapNotNull { item ->
            val title = item.optString("title").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val credits = item.optJSONArray("artist-credit")
            val artist = credits?.objects()?.firstOrNull()?.optJSONObject("artist")?.optString("name")
                ?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val release = item.optJSONArray("releases")?.objects()?.firstOrNull()
            val releaseId = release?.optString("id")?.takeIf { it.isNotBlank() }
            RemoteMatch(
                artist = artist,
                title = title,
                album = release?.optString("title")?.takeIf { it.isNotBlank() },
                coverUrl = releaseId?.let { "https://coverartarchive.org/release/$it/front-500" },
                durationMs = item.optLong("length", 0L),
                source = "musicbrainz"
            )
        }
    }

    /**
     * lrclib.net - synced lyrics, no key. Exact lookup first (artist + title + duration, which is
     * how the database is indexed), then a fuzzy search as a fallback.
     */
    suspend fun lyrics(artist: String, title: String, durationMs: Long): Pair<String?, String?>? {
        val seconds = (durationMs / 1000L).coerceAtLeast(0L)
        val exact = "https://lrclib.net/api/get?artist_name=${encode(artist)}&track_name=${encode(title)}" +
            if (seconds > 0) "&duration=$seconds" else ""
        runCatching { get(exact) }.getOrNull()?.let { json ->
            val root = runCatching { JSONObject(json) }.getOrNull()
            if (root != null) {
                val synced = root.optString("syncedLyrics").takeIf { it.isNotBlank() }
                val plain = root.optString("plainLyrics").takeIf { it.isNotBlank() }
                if (synced != null || plain != null) return synced to plain
            }
        }
        val search = "https://lrclib.net/api/search?artist_name=${encode(artist)}&track_name=${encode(title)}"
        val json = get(search) ?: return null
        val array = runCatching { JSONArray(json) }.getOrNull() ?: return null
        // Closest duration wins: same artist and title with a 40 s gap is a different version, and
        // its timestamps would drift away from the audio within seconds.
        var best: JSONObject? = null
        var bestGap = Long.MAX_VALUE
        array.objects().forEach { item ->
            val itemSeconds = item.optDouble("duration", 0.0).toLong()
            val gap = if (seconds > 0 && itemSeconds > 0) kotlin.math.abs(seconds - itemSeconds) else 0L
            if (gap < bestGap) { bestGap = gap; best = item }
        }
        val chosen = best ?: return null
        if (seconds > 0 && bestGap > 12L) return null
        val synced = chosen.optString("syncedLyrics").takeIf { it.isNotBlank() }
        val plain = chosen.optString("plainLyrics").takeIf { it.isNotBlank() }
        if (synced == null && plain == null) return null
        return synced to plain
    }

    private fun JSONArray.objects(): List<JSONObject> {
        val out = ArrayList<JSONObject>(length())
        for (index in 0 until length()) optJSONObject(index)?.let { out.add(it) }
        return out
    }
}
