package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import android.util.LruCache
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import kotlinx.coroutines.delay
// 6.14.0: компонент NowPlayingBadge читает палитру, а импорта не было — сборка падала здесь.
import app.ziziplayer.ui.theme.LocalPalette

/**
 * Custom seek bar. The stock Material slider fires a seek on every pixel of movement,
 * which is what made the play icon flicker; this one only reports the final value.
 */
@Composable
fun ZiziSlider(
    fraction: Float,
    accent: Color,
    inactive: Color,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    /** Жест отменён, а не завершён: состояние надо вернуть плееру, перемотку не подавать. */
    onScrubCancel: () -> Unit = {},
    modifier: Modifier = Modifier,
    /**
     * Доля трека, уже лежащая в буфере плеера (6.26.1). Рисуется третьим слоем между пустой
     * дорожкой и проигранной частью — «теневая» линия загрузки, как у референса.
     *
     * По умолчанию 0: локальный файл не буферизуется, и слой просто не рисуется, а не мигает
     * полной полосой на каждом треке из медиатеки.
     */
    buffered: Float = 0f,
    /**
     * 6.32.0. Можно ли вообще перематывать прямо сейчас.
     *
     * Пока длительность неизвестна, доля не переводится в миллисекунды: любое движение пальца
     * означало бы перемотку в случайное место. Дорожка в этом состоянии не врёт человеку, что
     * она управляема, — жест не принимается совсем, а бегунок гаснет.
     */
    seekable: Boolean = true,
    /**
     * 6.32.0. Идентификатор того, ЧЬЮ дорожку мы рисуем.
     *
     * Compose переиспользует один и тот же узел для нового трека, поэтому вся внутренняя
     * память компонента (перетаскивание, анимация буфера) переезжает на следующий трек вместе
     * с ним. Смена ключа стирает эту память мгновенно, без анимаций: у нового трека нет и не
     * может быть ни начатого жеста, ни унаследованного буфера.
     */
    resetKey: Any? = null
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var local by remember { mutableFloatStateOf(fraction) }
    var scrubbing by remember { mutableStateOf(false) }
    val shown = (if (scrubbing) local else fraction).coerceIn(0f, 1f)
    val density = LocalDensity.current

    // Буфер приходит скачками: ExoPlayer сообщает его по факту загрузки чанка, и на плохой сети
    // это шаг 8 %, а на хорошей — прыжок с нуля до 90 % за один опрос. Линия, которая телепортируется,
    // выглядит как баг, поэтому доля едет пружиной. Пружина, не tween: у tween фиксированная
    // длительность, и большой прыжок ползёт так же медленно, как маленький.
    //
    // 6.31.0. Пружина осталась, но только на РОСТ.
    //
    // animateFloatAsState анимировал в обе стороны, а буфер после перемотки и на смене трека не
    // растёт, а обнуляется. Тень в этот момент ползла назад через полэкрана — медленно, потому
    // что StiffnessVeryLow, — и одновременно вперёд гнался новый буфер. Отсюда «теневой ползунок
    // катается туда-сюда»: анимация назад по определению врёт, буфера там уже нет. Падение —
    // мгновенное (snapTo), рост — пружиной. Плюс жёсткость поднята до Low: VeryLow на прыжке
    // с нуля до 90 % ехал больше секунды и выглядел как отдельная живущая своей жизнью полоса.
    val bufferAnim = remember { Animatable(0f) }
    // Смена трека — не «буфер уменьшился», а «буфера нет». Никакой анимации, мгновенный ноль.
    LaunchedEffect(resetKey) {
        scrubbing = false
        local = 0f
        bufferAnim.snapTo(0f)
    }
    LaunchedEffect(buffered) {
        val target = buffered.coerceIn(0f, 1f)
        if (target < bufferAnim.value - 0.015f) bufferAnim.snapTo(target)
        else bufferAnim.animateTo(target, spring(dampingRatio = 1f, stiffness = Spring.StiffnessLow))
    }
    val bufferedShown = bufferAnim.value

    Box(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            // ONE gesture detector.
            //
            // v4 attached a tap detector AND a horizontal drag detector to the same box. A short
            // finger movement satisfied both, so two different seeks were dispatched for a single
            // gesture - that is exactly the twitching when nudging the thumb a little. On top of
            // that the tap path used an absolute position while the drag path accumulated relative
            // deltas, so the two disagreed about where the finger actually was.
            //
            // Now a press, a drag and a tap are the same code path, always absolute, one seek.
            //
            // 6.32.0. Ключ жеста — `seekable`: на неперематываемом треке детектор не работает
            // вообще, а не «работает и молча ничего не делает». Разница видна пальцем: бегунок
            // не уезжает туда, куда плеер всё равно не встанет.
            .pointerInput(seekable) {
                if (!seekable) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scrubbing = true
                    local = (down.position.x / widthPx).coerceIn(0f, 1f)
                    onScrubStart()
                    onScrub(local)
                    down.consume()
                    var cancelled = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null) { cancelled = true; break }
                        if (!change.pressed) break
                        val next = (change.position.x / widthPx).coerceIn(0f, 1f)
                        if (next != local) { local = next; onScrub(next) }
                        change.consume()
                    }
                    scrubbing = false
                    // 6.32.0. Палец, который потеряли (второе касание, отбор жеста родителем),
                    // не считается отпущенным пальцем. Раньше в этом случае улетала перемотка в
                    // последнюю известную точку — самый обидный сорт «я не просил».
                    if (cancelled) onScrubCancel() else onScrubEnd(local)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            // 6.26.1: 5 dp -> 4 dp. Замер референса даёт 9 px на кадре 1080 (то есть 3.4 dp при
            // 411 dp ширины) — там дорожка ещё тоньше. Остановился на 4 dp: при 3.4 dp полоса
            // становится тоньше собственного буферного слоя и перестаёт читаться как дорожка на
            // светлых обложках, где контраст к фону падает. Одна константа, если захочется ровно
            // как в референсе.
            val trackHeight = with(density) { 4.dp.toPx() }
            val radius = trackHeight / 2f
            val centerY = size.height / 2f
            drawRoundRect(
                color = inactive,
                topLeft = Offset(0f, centerY - radius),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(radius, radius)
            )
            // Слой загрузки. Цвет — акцент с альфой 0.30, а не отдельный серый: на любой обложке
            // он остаётся из той же семьи, что и проигранная часть, и читается как «то же самое,
            // но ещё не сыграно». Рисуется ДО проигранной части, поэтому на стыке нет шва.
            val bufferedWidth = size.width * bufferedShown
            if (bufferedWidth > 0.5f && bufferedShown > shown) {
                drawRoundRect(
                    color = accent.copy(alpha = 0.30f),
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(bufferedWidth, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val filled = size.width * shown
            if (filled > 0.5f) {
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(filled, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val thumb = with(density) { (if (scrubbing) 9.dp else 7.dp).toPx() }
            // coerceIn throws when min > max, which happens the moment the bar is laid out
            // narrower than the thumb (a very small window, a 0 px first frame). A crash inside
            // the draw phase takes the whole screen down, so the bounds are ordered explicitly.
            val minX = thumb.coerceAtMost(size.width / 2f)
            val maxX = (size.width - thumb).coerceAtLeast(minX)
            drawCircle(
                color = if (seekable) accent else accent.copy(alpha = 0.45f),
                radius = thumb,
                center = Offset(filled.coerceIn(minX, maxX), centerY)
            )
        }
    }
}

@Composable
fun PillChip(
    label: String,
    icon: ImageVector?,
    active: Boolean,
    palette: ChipColors,
    // 6.27.2: modifier ПЕРЕД onClick. В Kotlin хвостовая лямбда всегда садится на ПОСЛЕДНИЙ
    // параметр, даже если у него есть значение по умолчанию. Пока onClick стоял пятым, а
    // modifier шестым, вызов `PillChip(a, b, c, d) { ... }` отдавал лямбду в modifier и падал
    // с «No value passed for parameter 'onClick'» (сборка 6.27.1). Порядок Compose-конвенции
    // (modifier — последний параметр со значением по умолчанию перед слотом) снимает мину.
    modifier: Modifier = Modifier,
    /**
     * 6.29.0: высота и радиус — параметры, а не константы.
     *
     * Замер чипов референса медиатеки: 91 px на скрине 1080 = 34.6 dp, радиус = половина высоты
     * (полная пилюля). Наш чип поиска — 38 dp с радиусом 10, и он таким и остаётся: у него другая
     * задача (он крупный, потому что по нему бьют пальцем в движении). Значения по умолчанию
     * равны прежним константам, поэтому ни один существующий вызов не сдвинулся ни на пиксель.
     */
    height: Dp = CHIP_HEIGHT,
    radius: Dp = CHIP_RADIUS,
    onClick: () -> Unit
) {
    val background = if (active) palette.activeBackground else palette.background
    val content = if (active) palette.activeContent else palette.content
    Row(
        modifier
            .height(height)
            .clip(RoundedCornerShape(radius))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = CHIP_PADDING),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(CHIP_ICON))
            Box(Modifier.width(CHIP_GAP))
        }
        Text(label, color = content, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/*
 * Геометрия чипа, 6.26.1. Замер референса по кадру 1080 x 2400, перевод в dp при 411 dp ширины
 * (2.628 px/dp), чип «Скачать»:
 *
 *   габарит        193..472 x 1526..1628 px  ->  106 x 38.8 dp
 *   радиус угла    25.5 px                   ->  9.7 dp        (не пилюля: пилюля дала бы 19.4)
 *   зазор чипов    23 px                     ->  8.8 dp
 *   отступ слева   45 px                     ->  17.1 dp
 *   ink иконки     35 x 48 px                ->  13 x 18 dp
 *   ink подписи    142 px, cap height 27 px  ->  кегль ~14.5 sp
 *
 * Что было: высота 44, радиус 22 (полная пилюля), падинг 18, иконка 19, зазор 9. То есть чип был
 * на 6 dp выше и вдвое круглее референсного. Радиус — главное отличие: 22 dp при высоте 44 это
 * математически пилюля, у неё нет прямых участков на боках вообще, и ряд таких чипов читается как
 * цепочка капсул. У референса на боку 19 dp прямой стенки, и чип выглядит как плитка. Отсюда же
 * ощущение «поменьше и квадратнее»: 10 / 38 против 22 / 44.
 *
 * Кегль подписи не изменился: 14.5 sp совпал с замером. Это тот случай, когда трогать не надо.
 */
private val CHIP_HEIGHT = 38.dp
private val CHIP_RADIUS = 10.dp
private val CHIP_PADDING = 15.dp
private val CHIP_ICON = 18.dp
private val CHIP_GAP = 7.dp

/** Зазор между чипами в ряду и отступ ряда от края. Референс: 8.8 и 17.1 dp. */
val CHIP_SPACING = 9.dp
val CHIP_ROW_INSET = 17.dp

data class ChipColors(
    val background: Color,
    val content: Color,
    val activeBackground: Color,
    val activeContent: Color
)

/** Little animated equaliser shown on the row that is currently playing. */
@Composable
fun EqualizerBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    // v3 read the animated values during composition, so this tiny widget recomposed 60 times a
    // second - and it never stopped, even on pause. Now the values are read inside the draw
    // lambda (draw-phase only) and the animation exists exclusively while something is playing.
    if (!playing) {
        Canvas(modifier) { drawEqualizerBars(color, 0.35f, 0.6f, 0.4f) }
        return
    }
    val transition = rememberInfiniteTransition(label = "eq")
    val a = transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "a")
    val b = transition.animateFloat(1f, 0.45f, infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "b")
    val c = transition.animateFloat(0.55f, 0.95f, infiniteRepeatable(tween(430), RepeatMode.Reverse), label = "c")
    Canvas(modifier) { drawEqualizerBars(color, a.value, b.value, c.value) }
}

private fun DrawScope.drawEqualizerBars(color: Color, first: Float, second: Float, third: Float) {
    // listOf(...) here allocated a list plus three boxed Floats on EVERY frame of the animation,
    // for every visible playing row. Sixty times a second, straight into the young generation.
    val barWidth = size.width / 5f
    val radius = CornerRadius(barWidth / 2f, barWidth / 2f)
    bar(color, 0f, first, barWidth, radius)
    bar(color, barWidth * 2f, second, barWidth, radius)
    bar(color, barWidth * 4f, third, barWidth, radius)
}

private fun DrawScope.bar(color: Color, x: Float, value: Float, width: Float, radius: CornerRadius) {
    val height = size.height * value
    drawRoundRect(
        color = color,
        topLeft = Offset(x, size.height - height),
        size = Size(width, height),
        cornerRadius = radius
    )
}

/**
 * Round icon button (v6.2).
 *
 * Three things were wrong before:
 *   - `RoundedCornerShape(percent = 50)` is only a circle when the box is square, and the ripple was
 *     clipped to it, so shuffle / repeat read as rounded SQUARES on press. Now: [CircleShape] plus an
 *     unbounded ripple that overshoots the bounds slightly, the way every system player does it.
 *   - there was no active state, so "shuffle on" was a tint change of a couple of percent contrast.
 *     [active] paints a soft circular wash behind the glyph.
 *   - repeat-one was distinguishable only by the tiny "1" inside the glyph. [activeDot] adds the
 *     indicator dot underneath.
 *
 * [active] and [activeDot] are trailing defaults, so every existing call site is untouched.
 */
/**
 * Кнопка транспорта (6.25.0).
 *
 * Зачем отдельно от [RoundIconButton], а не ещё два параметра к нему.
 *
 *  1. **Размер в Dp, а не в Int.** У [RoundIconButton] диаметр — `Int` в dp, то есть константа,
 *     вбитая в вызов: 74 для play, 58 для skip. На эталонном 1080-px телефоне (411 dp по ширине)
 *     ряд транспорта занимал 0.18 ширины и выглядел как в референсе. На 1.5K-экране (1260 px,
 *     448 dp) те же 74 dp — уже 0.165 ширины, и ряд визуально уезжает к центру, оставляя по
 *     краям пустые поля. Здесь диаметр приходит как [Dp], вычисленный от реальной ширины, и
 *     пропорция держится на любой плотности.
 *  2. **Реакция на нажатие.** У ripple с `bounded = false` вся обратная связь — расходящееся
 *     пятно, которое на тёмном фоне плеера почти не видно. Тут кнопка ещё и проседает: пружина
 *     на scale, `dampingRatio` 0.55 — отдача есть, но без болтанки, а stiffness 1400 держит весь
 *     цикл в пределах 120 мс, иначе быстрые тапы по «вперёд» начинают отставать от пальца.
 *     Анимация идёт через [graphicsLayer], то есть в фазе draw: ни measure, ни layout не
 *     повторяются, поэтому просадка не пересобирает ряд из пяти кнопок на каждом кадре.
 *  3. **Глиф — доля от диаметра.** Пара «диаметр, кегль глифа» в [RoundIconButton] задаётся
 *     двумя независимыми числами, и на call site они разъезжались: 74/52 = 0.70 у play против
 *     58/34 = 0.59 у skip. Отношение сохраняется само.
 */
@Composable
fun TransportButton(
    icon: ImageVector,
    tint: Color,
    diameter: Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    glyphFraction: Float = 0.60f,
    background: Color = Color.Transparent,
    active: Boolean = false,
    pressedScale: Float = 0.90f,
    /**
     * Точка-индикатор под глифом. 6.29.2, для «повторять»: состояние показывает она, а не
     * подложка [active].
     *
     * Считается от кегля глифа, а не от диаметра кнопки, потому что привязана к рисунку знака, а
     * не к площади нажатия: в референсе центр точки стоит на 0.707 кегля ниже центра знака, а её
     * диаметр — 0.1475 кегля. Кнопка при этом может быть любой: 0.318 диаметра до центра точки
     * плюс её радиус — это 0.35 диаметра, то есть точка всегда внутри круга нажатия.
     */
    dot: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium * 3.5f),
        label = "transport_press"
    )
    Box(
        modifier
            .size(diameter)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(background)
            .clickable(
                interactionSource = interaction,
                indication = ripple(bounded = false, radius = diameter / 2 + 6.dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        if (active) {
            Box(
                Modifier
                    .matchParentSize()
                    .padding(diameter * 0.11f)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.16f))
            )
        }
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(diameter * glyphFraction))
        if (dot) {
            val glyph = diameter * glyphFraction
            Box(
                Modifier
                    .align(Alignment.Center)
                    .offset(y = glyph * 0.707f)
                    .size(glyph * 0.1475f)
                    .clip(CircleShape)
                    .background(tint)
            )
        }
    }
}

@Composable
fun RoundIconButton(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: Int = 52,
    iconSize: Int = 24,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    activeDot: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(
                interactionSource = interaction,
                indication = ripple(bounded = false, radius = (size / 2 + 4).dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        if (active) {
            Box(
                Modifier
                    .matchParentSize()
                    .padding((size * 0.10f).dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.16f))
            )
        }
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize.dp))
        if (activeDot) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = (size * 0.13f).dp)
                    .size(3.5.dp)
                    .clip(CircleShape)
                    .background(tint)
            )
        }
    }
}

/**
 * Titles in a real library are 60 % metadata: "0_0 Slowed + Reverb", "pursuit (super slowed)",
 * "AUTOMOTIVO DO MAL V1 (Super Slowed)". The reference player renders that trailing modifier in a
 * dimmer colour, which is what makes a screen of long titles scannable instead of a wall of bold.
 *
 * The split point is cached by title string, so scrolling 3000 rows runs the regex once per unique
 * title for the whole session, never once per frame.
 */
private val DIM_TAIL = Regex(
    """[\s\-–—|(\[]*\b((?:super|ultra|mega)\s+)?(slowed|slow(?:ed)?\s*[&+]\s*reverb|sped\s*up|speed\s*up|nightcore|reverb|remix|bass\s*boosted?|extended\s*mix|instrumental|mashup|8d\s*audio|lo-?fi)\b.*$""",
    RegexOption.IGNORE_CASE
)

private val dimTailCache = LruCache<String, Int>(2048)

fun dimTailStart(title: String): Int {
    dimTailCache.get(title)?.let { return it }
    val at = DIM_TAIL.find(title)?.range?.first?.takeIf { it >= 3 } ?: -1
    dimTailCache.put(title, at)
    return at
}

@Composable
fun TrackTitle(
    title: String,
    color: Color,
    dim: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier
) {
    val split = remember(title) { dimTailStart(title) }
    // The style is built once per size instead of on every composition. Handing Text a fontSize
    // and a fontWeight separately makes it merge a fresh TextStyle each time it runs, and this
    // composable is the title of every row in a 3000 track library.
    val style = remember(fontSize, fontWeight) { TextStyle(fontSize = fontSize, fontWeight = fontWeight) }
    if (split < 0) {
        Text(
            text = title,
            color = color,
            style = style,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    } else {
        val annotated = remember(title, color, dim) {
            buildAnnotatedString {
                withStyle(SpanStyle(color = color)) { append(title.substring(0, split)) }
                withStyle(SpanStyle(color = dim)) { append(title.substring(split)) }
            }
        }
        Text(
            text = annotated,
            style = style,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    }
}

/**
 * The player title, scrolled instead of truncated.
 *
 * A 25 sp bold title on a 360 dp screen fits about 18 characters, so "KXNO1X, TREVOLX - MONTAGEM
 * ..." was simply unreadable in the one place the app is supposed to be showing it off. It now
 * travels sideways, once the reader has had time to start reading, and loops through a gap.
 *
 * Why this and not `basicMarquee`:
 *   - the text is measured ONCE with a TextMeasurer and painted with drawText, so the animation
 *     lives entirely in the draw phase - a scrolling title costs one repaint per frame and zero
 *     recompositions, which matters because this screen also repaints the backdrop every frame of
 *     a swipe;
 *   - `basicMarquee` restarts its own measurement pass and, on the foundation version this
 *     project builds against, still carries the experimental annotation.
 *
 * A title that fits is left alone - moving text that does not need to move is noise, and none of
 * the reference players do it.
 */
@Composable
fun MarqueeText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier,
    speedDpPerSecond: Float = 30f,
    startDelayMs: Long = 1500L,
    gap: Dp = 54.dp
) {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val style = remember(fontSize, fontWeight) { TextStyle(fontSize = fontSize, fontWeight = fontWeight) }
    // Measured with no width constraint at all, which is the point: this is the width the title
    // WANTS, not the width it was allowed, so the comparison below is exact.
    val layout = remember(text, style, measurer, density) {
        measurer.measure(
            text = AnnotatedString(text),
            style = style,
            softWrap = false,
            overflow = TextOverflow.Visible,
            maxLines = 1
        )
    }
    var containerWidth by remember { mutableIntStateOf(0) }
    val gapPx = with(density) { gap.roundToPx() }
    val distance = (layout.size.width + gapPx).toFloat()
    val scrolling = containerWidth > 0 && layout.size.width > containerWidth + 2
    val shift = remember { Animatable(0f) }
    val height = with(density) { layout.size.height.toDp() }

    LaunchedEffect(text, scrolling, distance) {
        shift.snapTo(0f)
        if (!scrolling) return@LaunchedEffect
        val speedPx = with(density) { speedDpPerSecond.dp.toPx() }.coerceAtLeast(1f)
        val duration = ((distance / speedPx) * 1000f).toInt().coerceIn(1500, 30_000)
        while (true) {
            delay(startDelayMs)
            shift.animateTo(distance, tween(duration, easing = LinearEasing))
            // The second copy is sitting exactly where the first one started, so the reset is
            // invisible: no rubber-band back, no flicker, the loop just continues.
            shift.snapTo(0f)
        }
    }

    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .clipToBounds()
            .onSizeChanged { containerWidth = it.width }
    ) {
        val offset = -shift.value
        drawText(layout, color = color, topLeft = Offset(offset, 0f))
        if (scrolling) drawText(layout, color = color, topLeft = Offset(offset + distance, 0f))
    }
}

/**
 * Общее время списка человеческими словами: «48 мин», «1 ч 12 мин», «2 ч 05 мин» (6.17.0).
 *
 * Не `formatTime`: 4372000 мс это «1 ч 12 мин», а не «72:52». Секунды в сумме плейлиста не нужны
 * никому — они меняются от одного добавленного трека и только зашумляют строку.
 */
fun formatTotalTime(ms: Long): String {
    val totalMinutes = (ms / 60000).coerceAtLeast(0)
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return when {
        hours > 0 -> "%d ч %02d мин".format(hours, minutes)
        totalMinutes > 0 -> "$totalMinutes мин"
        ms > 0 -> "меньше минуты"
        else -> "пусто"
    }
}

/** «12 треков» с правильным окончанием: 1 трек, 2 трека, 5 треков, 21 трек. */
fun trackCountLabel(count: Int): String {
    val tail = count % 100
    val last = count % 10
    val word = when {
        tail in 11..14 -> "треков"
        last == 1 -> "трек"
        last in 2..4 -> "трека"
        else -> "треков"
    }
    return "$count $word"
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}

/**
 * 6.13.0 — единый маркер «этот трек сейчас в плеере».
 *
 * Правило, которого раньше не было: СТРОКА показывает состояние, КНОПКА показывает действие.
 * Строки поиска рисовали статичный ▶ у играющего трека, а мини-плеер в этот же момент показывал
 * ⏸ (действие «поставить на паузу») — снаружи это выглядело как рассинхрон плеера.
 * Теперь у всех списков один маркер: полоски эквалайзера, живые пока играет и замершие на паузе.
 * Второй побочный выигрыш: на паузе маркер больше не исчезает, и место в списке не теряется.
 */
@Composable
fun NowPlayingBadge(
    current: Boolean,
    playing: Boolean,
    size: Dp,
    corner: Dp = 7.dp,
    barSize: Dp = size * 0.42f,
    modifier: Modifier = Modifier
) {
    if (!current) return
    val p = LocalPalette.current
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(Color.Black.copy(alpha = 0.46f)),
        contentAlignment = Alignment.Center
    ) {
        EqualizerBars(p.accent, playing, Modifier.size(barSize))
    }
}
