# Mechanism reference for the camera effect

Studied upstream: Telegram for Android, https://github.com/DrKLO/Telegram,
commit dc780e81ed1261c369c27870e8e0999a1eb0b600.

Relevant upstream paths:
- TMessagesProj/src/main/java/org/telegram/ui/Components/ProfileGooeyView.java
- TMessagesProj/src/main/java/org/telegram/ui/ProfileActivity.java
- TMessagesProj/src/main/java/org/telegram/messenger/AndroidUtilities.java

Telegram's source is distributed under GPL terms; see its repository license.
This archive does not redistribute the Telegram source files or its artwork/assets.
CameraGooeyGeometry and CameraGooeyOverlay are new, application-specific implementations
of the studied graphical mechanism: opposing geometric seeds, separately blurred fields,
source-over alpha composition, then a common alpha threshold and a detail pass.
They use the reference's mathematical coefficients. This is not a claim that an entire
upstream class was copied, nor that Telegram's GPL code may be relicensed as MIT.
The pre-existing project LICENSE is unchanged. If future work copies upstream implementation
code instead of implementing the mechanism, review the associated GPL obligations before shipping.
