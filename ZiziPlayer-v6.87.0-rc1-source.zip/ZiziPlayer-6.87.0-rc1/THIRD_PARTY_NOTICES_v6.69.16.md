# Camera effect mechanism reference — 6.69.16

Upstream studied: Telegram for Android, https://github.com/DrKLO/Telegram,
commit dc780e81ed1261c369c27870e8e0999a1eb0b600.
Relevant classes: ProfileGooeyView, ProfileActivity, NotchInfoUtils, AndroidUtilities.

This archive does not embed Telegram source or assets. The Zizi Compose renderer
implements the blur / common-alpha-threshold mechanism independently. Version 6.69.16
adds a size-aware camera blur and removes screenshot-specific scaling from its own
public-API cutout adapter. The adaptive kernel and side-camera policy are NOT claimed
to be Telegram code. The bottom-aligned width-based circle policy was compared with
the reference's likely-circle branch, but remains explicitly an estimate.

Telegram source is GPL-licensed; no claim is made that it can be relicensed as MIT.
The existing Zizi LICENSE is unchanged. No upstream source snippets are redistributed
in this ZIP. See RELEASE_v6.69.16.md for implementation differences and verification scope.
