# Сервер 1.20-reco2-rc6 — обновление с 1.19

Только страница артиста («Популярное»). Меняются `zizi_browse.py` и `zizi_catalog.py` (строка версии).
`zizi_reco.py` не меняется: установщик покажет для него `skip`.

## Что изменено (`zizi_browse.py`)

| Было (1.19) | Стало (1.20) |
|---|---|
| 20 релизов | **40** релизов (`TOP_ALBUMS`) |
| только релизы | + **поиск по имени артиста** (`search?q=<имя>&limit=100`), оставляем только треки, где он основной артист (`artist.id`): синглы вне альбомов, хиты, сборники |
| потолок 100 треков | **200** (`MAX_TRACKS`) |
| `artist`, `artist/top`, `artist/albums` по очереди | **одновременно**: -2 захода (~0.6 с) на холодной странице |
| страница ждёт все релизы (до 12 с) | ждёт **до 4 с** (`SOFT_WAIT_S`), отвечает тем, что уже собрано; сборка доезжает в фоне и кладёт полный пул в кэш |
| кэш полного пула 15 мин | **3 часа** (дискография меняется редко) |
| 5 потоков | 6 (`ALBUM_WORKERS`) |

Неполный срез (ответ через 4 с) в кэш **не** попадает: следующее открытие присоединяется к идущей сборке или берёт готовый полный пул.
Упавший поиск пул «неполным» не делает: это добавка к релизам.
Релизы идут в порядке «самые лайкнутые первыми», поэтому срез через 4 с это лучшие релизы, а не случайные.

Цена холодной страницы: `3 + 40 + 1` запросов к Deezer. Повторные открытия и «Показать ещё» идут из кэша.
Лента «Для тебя» по-прежнему на 3 релизах.

## Порядок

```bash
cd /tmp && unzip ZiziServer-1.20-reco2-rc6.zip && cd ZiziServer-1.20/server
/opt/zizi/venv/bin/python tools/deploy_server.py --check
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply
# id фонк-артиста: число из ссылки deezer.com/artist/<id>
time curl -s "http://127.0.0.1:8080/catalog/browse/collection?id=ID&kind=artist&limit=100" | python3 -c 'import sys,json;d=json.load(sys.stdin);print(len(d["items"]), d["total"], d["next_offset"])'
# второй раз (кэш):
time curl -s "http://127.0.0.1:8080/catalog/browse/collection?id=ID&kind=artist&limit=100" | python3 -c 'import sys,json;d=json.load(sys.stdin);print(len(d["items"]), d["total"], d["next_offset"])'
```

Ожидание в `--check`: `zizi_reco.py skip`, `zizi_browse.py replace`, `zizi_catalog.py replace`.

## Откат

`sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>`

## Границы проверки

Выполнялось: серверные тесты на фикстурах (`test_reco3.py`: 33 теста, из них новые на поиск, фоновую сборку и параллельный старт),
план установки от файлов 1.19. Не выполнялось: `smoke_stage2.py` (нет uvicorn; на VPS идёт в `--check`), живой Deezer.
Что Deezer отдаёт `limit=100` на `search`, покажет первый запрос (при ошибке поиск молча пропускается, релизы работают).
