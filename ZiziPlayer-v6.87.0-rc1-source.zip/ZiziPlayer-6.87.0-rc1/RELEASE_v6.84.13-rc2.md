# ZiziPlayer 6.84.13-rc2 (versionCode 194)

Только починка сборки rc1. Функционально совпадает с 6.84.13-rc1 (H0/H1/H2).

## Причина падения
CI, шаг «Kotlin compile and JVM tests»: `HomeRecommendations.kt:459:37 Unresolved reference 'earlyDiscover'`, затем
`:461:40 'shelves'`, `:463:43 'error'` (последние два следствие первого: `early` получил тип ошибки).
Переменная была `val` внутри `else { ... }`, а использовалась после закрытия этого блока.

## Правка
- `var earlyDiscover: Deferred<EarlyDiscover>? = null` перед `withTimeoutOrNull(TOTAL_TIMEOUT_MS)`;
  внутри `else` только присваивание.
- Выход по устаревшей эпохе отменяет ранний запрос чарта.
- `tools/test_home_6813.py`: контракт на место объявления.
- versionCode 193 -> 194, versionName 6.84.13-rc2. CI берёт ZIP с наибольшим versionCode.

## Проверено здесь
`check_kotlin_syntax`, `check_imports`, `check_static_refs`, `test_home_6813.py` (13), `Home6813Checks` (90) на JDK 21.
Kotlin не компилировался, Android не запускался.
