# ZiziPlayer 6.84.14-rc4 (versionCode 198)

Наследует rc1-rc3. Клиент: трасса главной, ускорение `FeedBuilder`, пауза лирики. Сервер и `/play` не затронуты.

## Зачем
В логе rc3 снимок главной показан на 165 мс (цель достигнута), но:
- `BUILDER_READY` приходит через 1444-2075 мс при `ROOM_DONE` 6-37 мс. Те же 3447 треков в снимке собираются за 64 мс.
- Ни один из 8 видимых запусков `load()` не дошёл до `FIRST_PUBLISHED`/`PROFILE_READY`/`REQUEST`. Возраст снимка при
  холодном старте рос (1 ч, потом 2 ч). Гипотеза: `cancel()` при уходе с главной срабатывает раньше запроса
  `/reco/home`. rc4 это проверяет строкой `LOAD_STAGE CANCELLED`.

## Что читать в новой трассе
```
LOAD_STAGE SIZE tracks=N / rows=M        размер библиотеки и истории
LOAD_STAGE BUILDER_WAIT ms=              очередь потоков Default
LOAD_STAGE BUILDER_RUN  ms=              стенное время конструктора FeedBuilder
LOAD_STAGE BUILDER_CPU  ms=              процессорное время потока на нём
LOAD_STAGE BUILDER_BACK ms=              возврат на главный поток
LOAD_STAGE BUILD_*      ms=              то же для builder.build() в publish()
LOAD_STAGE CANCELLED    ms=              load() отменили, ms = сколько прожил
```
Как читать:
- `BUILDER_CPU` близко к `BUILDER_RUN` и оба большие: считаем долго, чинить код (профилировать `FeedBuilder`).
- `BUILDER_RUN` много больше `BUILDER_CPU`: поток вытесняют (термо- или конкуренция), код не виноват.
- `BUILDER_WAIT` большой: `Dispatchers.Default` занят чужой работой.
- `BUILDER_BACK` большой: главный поток занят, возврат ждёт его.
- `CANCELLED` без `REQUEST` перед ним подтверждает гипотезу про отмену.

Чтобы холодный старт попал в трассу: полностью закрыть приложение, открыть, сразу скопировать «Задержки
воспроизведения». Первые 32 события процесса теперь не вытесняются.

## Проверено
Статические проверки (`check_kotlin_syntax`, `check_imports`, `check_static_refs`, `check_package_shadow`,
`check_call_args`), контрактные тесты `tools/test_*.py` и Java-проверки на JVM. Не проверено: сборка Kotlin и Android.
