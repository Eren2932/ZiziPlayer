# Серверное обновление 1.23-prewarm-rc1 (Reco 2.5-prefetch-rc1 + автопрогрев главной)

Цель: следующий трек очереди и верхние треки главной стартуют без холодного `match -> resolve`.
Клиент: 6.84.12-rc1 (versionCode 192). Старый клиент работает с этим сервером без изменений: новые параметры он просто не шлёт.

Статус: серверные тесты зелёные в песочнице на фикстурах. **На живом Deezer, YouTube и на VPS не проверялось. Секунды выигрыша не измерены.**

## Что в комплекте

| Файл | Версия | Суть |
|---|---|---|
| `zizi_catalog.py` | 1.23-prewarm-rc1 | кэш метаданных трека Deezer в памяти (6 ч, до 2048): `/match/deezer` больше не ходит в `api.deezer.com` на каждый тап; `/prefetch?dz=` (match -> resolve -> байты); `/match/warm?resolve=1`; автопрогрев 4 верхних треков главной после `/reco/home`; `"prewarm": 1` в `/catalog/health` |
| `zizi_resolver.py` | 1.7-stage2 (health), правки 1.8 | `/prefetch` принимает `dz=` (до 3 id), фоновый match при занятом слоте повторяется до 12 с, свой пул потоков, хук `LINK_WARM` |
| `zizi_reco.py` | 2.5-prefetch-rc1 + хук | ваш 2.5 с VPS; добавлен вызов `track_warm` в `_remember` (в try/except: прогрев не ломает сборку главной) |
| `zizi_match.py`, `zizi_browse.py`, `zizi_versions.py` | без изменений | |
| `tools/deploy_server.py` | | **теперь ставит и `zizi_resolver.py`**; в health ждёт `prewarm=1`; в предустановочные тесты добавлен `test_prewarm_122.py` |
| `tools/server_known.json` | | добавлены базы: каталог 1.21-speed, Reco 2.4 и Reco 2.5 (ваш файл с VPS), резолвер до 1.23; резолвер убран из «без изменений» |
| `tools/server_bundle_seal.json` | | печать пересчитана (теперь включает резолвер) |

Почему пришлось тронуть установщик: он требовал, чтобы `zizi_resolver.py` на VPS был ровно тем, на котором прошли тесты, и сам его не писал.
С новым резолвером он отказал бы («unknown server edit»). Reco 2.5 тоже не был известной базой.

## Установка

Распакуйте архив в `~/zizi-1.23` (внутри будет `server/`).

```bash
mkdir -p ~/zizi-1.23 && unzip -o ZiziServer-1.23.zip -d ~/zizi-1.23

# 1. Проверка. Ничего не пишет. Покажет план: resolver/reco/catalog = replace, остальное = skip.
/opt/zizi/venv/bin/python ~/zizi-1.23/server/tools/deploy_server.py --check

# 2. Бэкап базы (WAL: копировать .db на ходу нельзя).
sqlite3 "$ZIZI_CATALOG_DB" ".backup '/opt/zizi/catalog.before-1.23.db'"

# 3. Установка (откат автоматический, если health не сошёлся).
sudo /opt/zizi/venv/bin/python ~/zizi-1.23/server/tools/deploy_server.py --apply

# Ручной откат
sudo /opt/zizi/venv/bin/python ~/zizi-1.23/server/tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>
```

Если `--check` пишет `unknown server edit: <файл> (sha256 …)`: на VPS этот файл правился руками или это другая сборка.
Не форсируйте: пришлите sha256 и файл, сделаем базу.

## Проверка после установки

```bash
H="Authorization: Bearer $T"; B=https://<ваш-хост>
curl -s -H "$H" $B/catalog/health | jq '{version, prewarm}'     # "1.23-prewarm-rc1", 1
curl -s -H "$H" $B/reco/health    | jq '{version, bg_calls, warmed, warming, bucket}'   # "2.5-prefetch-rc1"
# ручной прогрев одного Deezer-трека (подставьте реальный id):
curl -s -H "$H" "$B/prefetch?ids=&dz=3135556&bytes=1"            # {"queued":[],"dz":["3135556"],"bytes":true,...}
journalctl -u <служба> -n 50 | grep -E 'resolved|prefetch'
```

Выключить автопрогрев главной, не откатывая код: `ZIZI_HOME_WARM_N=0` в окружении службы и рестарт.

## Риски

- Слот извлечения на сервере один. Фоновый resolve, который уже идёт, задерживает тап до своего конца (≈1,1 с). Прогрев главной ограничен 4 треками и дедупом 5 минут.
- Дедуп прогрева по id (5 мин) может проглотить повторную просьбу «теперь с resolve».
- Шафл, включённый посреди трека, пересчитывает прогрев только со следующей смены трека.
- `smoke_stage2.py` поднимает настоящий ASGI-сервер и требует `uvicorn`. В песочнице сборки его не было, поэтому этот шаг там не прогонялся; на VPS он идёт в предустановочных тестах.
- Если на VPS лежат тесты 1.22, которых не было в репозитории, в комплект они не входят.
