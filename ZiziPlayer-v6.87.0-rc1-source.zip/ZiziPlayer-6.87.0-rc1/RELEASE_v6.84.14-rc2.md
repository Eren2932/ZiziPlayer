# ZiziPlayer 6.84.14-rc2 (versionCode 196)

Починка сборки 6.84.14-rc1. Функциональных изменений нет: всё из RELEASE_v6.84.14-rc1.md остаётся в силе.

## Что падало
```
HomeRecommendations.kt:525:14 Cannot infer type for this parameter. Please specify it explicitly.
HomeRecommendations.kt:525:24 Unresolved reference 'ziziplayer'.
```
В классе `HomeRecommendations` есть поле `app: ZiziApplication`. Выражение `app.ziziplayer.library.SyncGate` Kotlin
разбирает как «член ziziplayer у переменной app». Исправлено импортом `app.ziziplayer.library.SyncGate`.

## Защита
`tools/check_package_shadow.py` + шаг CI «Затенение пакета app». Файл `.github/workflows/build.yml` в ZIP
обновлён; CI берёт workflow из корня репо, а не из ZIP, поэтому шаг заработает после копирования build.yml.
