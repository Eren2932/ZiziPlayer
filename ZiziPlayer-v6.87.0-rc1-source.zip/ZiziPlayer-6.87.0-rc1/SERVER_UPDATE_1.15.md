# Серверное обновление 1.15-smart-reco

Один комплект вместо двух: умный подбор (1.14) + персональная главная (Reco 1) + бесконечная лента `POST /reco/feed` (Reco 1.1) + актуальный `zizi_browse.py`. Ставится одним скриптом `tools/deploy_server.py`, за одну остановку службы.

## Что заменяется в `/opt/zizi`

`zizi_match.py` (новый), `zizi_reco.py`, `zizi_browse.py`, `zizi_catalog.py`, и `zizi_versions.py` только если установленный не знает нужного API. Всё остальное (резолвер, планировщик, guard, extra, process), `.env`, базы и юнит systemd не трогается.

> `zizi_browse.py` на проде — Browse 1 RC1 (`sha256 d4c07d16…`). Обновление Browse из 6.47.0 (album_id в коллекции альбома) на сервер раньше не ставилось. Теперь RC1 известен установщику как допустимая база и заменяется текущей версией, на которой прошли тесты.

## Порядок

Распакуй `server/` из архива в `/root/zizi-1.15/server` (не поверх `/opt/zizi`) и запускай интерпретатором из venv сервиса.

```bash
cd /root/zizi-1.15/server

# 1) Проверка: валидирует установленные файлы и гоняет все тесты и smoke. Ничего не пишет.
/opt/zizi/venv/bin/python tools/deploy_server.py --check

# 2) Установка (root). Музыка прервётся на несколько секунд.
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply

# 3) Три факта должны быть на месте одновременно
curl -s http://127.0.0.1:8080/catalog/health | python3 -m json.tool | grep -E '"(version|match_engine|reco_contract|reco_feed|browse_contract)"'
```

Ожидается: `"version": "1.15-smart-reco"`, `"match_engine": "smart"`, `"reco_contract": 1`, `"reco_feed": 1`, `"browse_contract": 1`.

`--apply` делает бэкап в `/opt/zizi/server-backups/<время>-<pid>/`, ставит файлы, ждёт health и **сам откатывает все файлы**, если хоть один из пяти фактов не сошёлся; печатает, здоров ли сервис после отката. Упавший тест нельзя отключить: установка останавливается и печатает его вывод. **Не правь скрипты через `sed`.**

## Если `--check` пишет `ОТКАЗ: unknown server edit … sha256 …`

Файл на сервере не совпадает ни с одной известной версией. Установщик не перезаписывает чужие правки: пришли напечатанный хеш и имя файла.

## Откат

```bash
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>
```

## Что нового для клиента

- `POST /reco/feed` — страницы с курсором, граф раскрывается вширь по мере прокрутки, без повторов; повтор той же страницы отдаёт ту же страницу; два одновременных запроса не съедают по странице.
- `POST /reco/home`: `related` и `radio` параллельно, дедлайн 5 с, в ответе `retry_ms` для быстрых повторов.
- Старый клиент (6.81.0 и ниже) работает как раньше: `/reco/home` совместим.
