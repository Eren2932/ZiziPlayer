# Сервер 1.17-reco2-rc3 (Reco 2.2) — обновление

Заменяет `1.16-reco2-rc2`. Меняются **четыре файла** в `/opt/zizi`: `zizi_catalog.py`, `zizi_reco.py`, `zizi_browse.py`
и (без изменений, пропускается) `zizi_match.py` / `zizi_versions.py`. `.env`, базы, аудио, systemd-юнит не трогаются.
Ставит `tools/deploy_server.py` — тот же установщик, что и 1.16: бэкап, остановка, замена, health, автооткат.

## Зачем

Замер с VPS 04.10: Deezer отдаёт пустой `data` на `genre/*/artists`, `chart/0/artists`, `artist/{id}/top`
(даже для Eminem), а `search/*`, `artist/{id}` и `artist/{id}/related` работают. Пустота кэшировалась на 3–6 часов
и сервер отвечал 200 с `artists: []`. Итог на телефоне: пустое окно «Выбери любимых», пустые страницы артистов,
лента «Для тебя» с «Повторить».

## Что изменено

| Где | Было | Стало |
|---|---|---|
| `/reco/onboard` (без якоря) | жанры+чарт; пусто → `200 {"artists": []}` | жанры+чарт; если мало (<24) — добор из запасного списка `ONBOARD_NAMES` (имя → `search/artist`, точное совпадение, кэш 30 дней); совсем пусто → **503** |
| Жанровые запросы | каждый раз 8 запросов | если все пусты — пауза 600 с |
| `top()` / `radio()` (лента, полки) | пустой `artist/{id}/top` = «у артиста нет треков» | пусто → `search` по имени артиста, `order=RANKING`, только строки этого `artist.id` |
| `/catalog/browse/collection` (артист) | пустой `top` = пустая страница | пусто → тот же поиск, с `limit`/`index` страницы |
| Кэш пустых ответов (`onboard`, `top`, `radio`, `top_search`) | 3–6 ч | **120 с**; уже записанные в SQLite пустышки протухают за 120 с автоматически |
| Устаревшая пустышка при сбое | отдавалась как «ответ» | не отдаётся: «не знаем» → сработает запасной путь |
| Заглушки Deezer без фото (`/images/artist//`) | попадали в рекомендации | отфильтрованы в связанных и в знакомстве |
| `/reco/health` → `upstream` | calls/hits/stale/failures | + `empty{}`, `failed{}` по видам, `last_error` |
| `GET /reco/probe` (за тем же guard) | нет | 9 лёгких запросов к Deezer мимо кэша: что жив, что пуст, за сколько мс |
| Прогрев | нет | фоновый поток резолвит запасной список после старта (`ZIZI_RECO_WARM=0` отключает) |

Публичные контракты `/reco/home` и `/reco/feed` (=1) и формат ответов не менялись. Клиент 6.84.2 работает с этим сервером как есть.

## Порядок

```bash
cd /root && rm -rf zizi-1.17 && mkdir zizi-1.17 && cd zizi-1.17
unzip ../ZiziServer-1.17-reco2-rc3.zip && cd ZiziServer-1.17/server

# 1) Проверка. Ничего не меняет, музыку не прерывает: валидирует установленные файлы и гоняет тесты.
/opt/zizi/venv/bin/python tools/deploy_server.py --check

# 2) Установка (root). Музыка прервётся на несколько секунд. Сам откатится, если health не сошёлся.
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply

# 3) Проверка фактов
curl -s http://127.0.0.1:8080/catalog/health | python3 -m json.tool | grep -E 'version|reco_contract|reco_feed'
curl -s http://127.0.0.1:8080/reco/health
curl -s -w "\nhttp=%{http_code}\n" http://127.0.0.1:8080/reco/onboard | head -c 600
curl -s http://127.0.0.1:8080/reco/probe
```

Ожидание: `version` = `1.17-reco2-rc3`, `/reco/health.version` = `2.2-reco2-rc3`, `engine` = 4.
`/reco/onboard` на холодном старте может вернуть меньше артистов (запасной список ещё греется ~10–20 с) — повтор даёт полный набор.

Если `--check` пишет `unknown server edit: <файл> (sha256 …)`, значит на VPS файл правили руками. Пришли хеш из сообщения.

## Откат

```bash
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>
```

## Границы проверки

Выполнялось: серверные тесты на фикстурах (в том числе `test_reco3.py`, 14 тестов на воспроизведение замера 04.10),
план установщика от хешей, которые сейчас на VPS. **Не выполнялось:** живой Deezer, живой VPS, ASGI-смоук с настоящим FastAPI
(его делает `deploy_server.py --check` на сервере). Что именно сейчас жив у Deezer — покажет `/reco/probe` после установки.
