# ZiziPlayer 6.83.0-rc3 — исправление сборки RC2

Android versionCode: 174; versionName: 6.83.0-rc3.
База — ZiziPlayer-v6.83.0-rc2-source.zip, скачанный из публичного Eren2932/ZiziPlayer.

## Исправление
В обеих задачах compileDebugKotlin/compileReleaseKotlin отсутствовала Java-константа,
на которую HomeRecoFeed.start() ссылается как HomeFeedStreamPolicy.PROFILE_AGE_MS.
Добавлена public static final long PROFILE_AGE_MS = 3L * 60L * 60_000L (10 800 000 мс).
Число согласовано с FEED_TTL = 3 * 3600 секунд в текущем сервере RC2.
Существующая логика сохранения очереди/Seen при обновлении вкуса не изменена.

## Регрессия
- Настоящая Java-компиляция читает PROFILE_AGE_MS из production класса и сверяет с сервером.
- Все ссылки HomeFeedStreamPolicy.* из Kotlin проверяются на наличие объявленного Java-member.
- TTL проверяется существующим HomeFeed6820Checks, запускаемым также из Gradle JUnit.
- Новый tools/test_feed_profile_ttl_6830.py включён в check_selftest.py.

## Что не менялось
Сервер и обновлённый корневой .github/workflows/build.yml не изменены.
Копии workflow внутри ZIP совпадают с текущей версией из публичного репозитория.
Новый server ZIP для этого исправления не требуется: остаётся сервер RC2.
Все изменения рекомендаций RC2 сохранены; отката к RC1 нет.

## Сборка
Загрузить новый source ZIP в корень GitHub-репозитория, как предыдущие архивы.
Workflow выбирает ZIP по максимальному versionCode: должен выбрать 174 / 6.83.0-rc3.
Повторно менять корневой build.yml ради этой ошибки не нужно.
Повторить CI compilation/unit tests/assemble, затем проверить APK на телефоне.
Полная Gradle/Kotlin/Compose-сборка локально не выполнялась: нет Android SDK/Gradle.
Исправление подтверждено Java/source tests, но это не утверждение об успешном выпуске APK.

Предупреждения о compileSdk/AGP и отсутствии release signing key не являются причиной
показанного Unresolved reference. Без release key APK подписывается DEBUG-ключом и
может не устанавливаться поверх релизной установки.

## Финальная локальная проверка
Полный tools/check_selftest.py: exit 0, 171.29 секунд.
Это Java/Python/source checks; результат Android CI этим не подменяется.
