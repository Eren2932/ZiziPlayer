# Серверный патч 1.22 (необязательный): `rank` и `complete`

Мобильное приложение 6.85.0 работает и без него: порядок сервера для исполнителя уже идёт по `rank`
(`artist_pool` сортирует по rank), поэтому «Популярное» = первые строки списка.

Что даёт патч:
* `rank` у каждого трека (только целое >= 0). Клиент использует его для сортировки при слиянии страниц
  из разных срезов пула и для выбора размера блока «Популярное». Числом на экране не показывается:
  Deezer не отдаёт прослушивания.
* `complete: false` в ответе `/catalog/browse/collection`, пока пул артиста ещё собирается. Клиент тогда
  тихо перезапрашивает первую страницу (через 2.5 / 5 / 9 с) и вливает её. Без флага первая страница по
  недособранному пулу может не содержать настоящий топ-10.

Файлы:
* `server_patch_1.22/zizi_browse.rank_complete.diff` — 3 места в `server/zizi_browse.py` (`track()`, ветка `artist_pool`, возврат);
* `server_patch_1.22/test_browse.rank_complete.diff` — тест (19 тестов `server/tools/test_browse.py` проходят).

Применение (в копии `server/`, не трогая развёрнутый сервер):
1. `patch -p0 server/zizi_browse.py < server_patch_1.22/zizi_browse.rank_complete.diff`
2. `python3 server/tools/test_browse.py`
3. `python3 server/tools/seal_server_bundle.py` — печать и `browse_base_hashes.json` меняются вместе с файлом;
   дальше обычный деплой через `deploy_browse.py` / `deploy_server.py`.

Файл `server/zizi_browse.py` в этом архиве намеренно НЕ изменён: он входит в печать и хеши деплоя.
