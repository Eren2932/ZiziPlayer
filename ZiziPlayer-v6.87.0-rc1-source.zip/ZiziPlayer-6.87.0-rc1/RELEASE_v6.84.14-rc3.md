# ZiziPlayer 6.84.14-rc3 (versionCode 197)

Наследует rc1 и rc2 (починка компиляции). Меняется только восстановление снимка главной и трасса.

## Что показала трасса rc2
```
176   SNAPSHOT_READ HIT
216   SNAPSHOT_SHOWN RACE            <- готовый снимок выброшен
10940 SNAPSHOT_SHOWN SNAPSHOT shelves=9
```
Причина в `restoreSnapshot`: сверка с `generation`, который увеличивает каждый `load()`. Теперь `restoreEpoch`.

## Что измерить дальше
В «Задержки воспроизведения» появятся строки `SNAPSHOT_STAGE ... ms=`, `SNAPSHOT_STAGE SIZE tracks=` и
`LOAD_STAGE ... ms=`. Цель: SNAPSHOT_SHOWN SNAPSHOT около 200 мс.
