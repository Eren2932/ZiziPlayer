# Сервер 1.18-reco2-rc4 (Reco 2.3) — обновление с 1.17

Только серверная правка, клиент 6.84.3-rc1 не меняется. Меняются `zizi_catalog.py`, `zizi_reco.py`, `zizi_browse.py`.

## Зачем

`/reco/probe` на 1.17 показал, что у Deezer с этого VPS **живы**: `chart_tracks`, `artist_radio`, `artist_albums`, `artist_related`,
`search_artist`. **Пусты**: `artist_top` и `search` по трекам с `artist:"…"` + `order=RANKING`. Запасной путь 1.17 (поиск с этим синтаксисом)
поэтому не работал: страницы артистов оставались пустыми, а лента «Для тебя» не получала треков кандидатов.

## Что изменено

| Где | Стало |
|---|---|
| Топ артиста для ленты (`Engine.top`) и для радио-запаса | `artist/{id}/top` пуст → **релизы артиста**: `artist/{id}/albums` (50) → `TOP_ALBUMS=3` релиза с наибольшим `fans` → `album/{id}/tracks` → строки самого артиста → сортировка по `rank` → дубли по названию убраны → обложка подставляется из релиза. Кэш: релизы 6 ч, треки релиза 24 ч. Последний запас: обычный `search?q=<имя>` с фильтром по `artist.id` |
| Страница артиста (`/catalog/browse/collection`, «Популярное») | тот же сбор из релизов, пагинация срезом одного и того же рейтинга, кэш 15 мин на процесс; ошибка одного релиза страницу не ломает |
| Запрос `artist:"…"` / `order=RANKING` | убран из кода (Deezer сейчас отдаёт на него пусто) |
| `/reco/probe` | + `search_track_plain`, `search_track_artist_syntax`, `search_track_order`, `search_track_artist_order` (какой именно синтаксис сломан) и `album_tracks` (+ есть ли `rank`) |

Цена: холодная страница ленты — до `1 + 3` обращений к Deezer на артиста вместо одного (кэшируется на часы). Для 10 артистов на страницу это ~40 вызовов при пределе 8/с, поэтому **самая первая** страница ленты после установки может прийти неполной и добрать повтором.

## Порядок

```bash
cd /tmp && unzip ZiziServer-1.18-reco2-rc4.zip && cd ZiziServer-1.18/server
/opt/zizi/venv/bin/python tools/deploy_server.py --check
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply
curl -s http://127.0.0.1:8080/reco/probe | python3 -m json.tool
curl -s "http://127.0.0.1:8080/catalog/browse/collection?id=13&kind=artist&limit=5" | head -c 700
```

Ожидание: `/catalog/browse/collection` для Eminem отдаёт 5 треков с `art`; `probe.album_tracks.has_rank` = `true`.
Если `has_rank` = `false`, сортировка по популярности деградирует до порядка Deezer — пришли вывод `probe`.

## Откат

`sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>`

## Границы проверки

Выполнялось: серверные тесты на фикстурах, воспроизводящих probe 04.10 (в том числе лента из 3 страниц при мёртвом `top`),
план установки от хешей 1.17. Не выполнялось: живой Deezer. Что `album/{id}/tracks` отдаёт поле `rank`, я знаю из документации
Deezer, на VPS это покажет `probe`.
