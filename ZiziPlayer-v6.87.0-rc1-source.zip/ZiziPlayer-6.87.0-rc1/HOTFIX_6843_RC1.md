# 6.84.3-rc1 — пустые экраны при мёртвых эндпоинтах Deezer

## Диагноз (по замеру с VPS 04.10, 05:24)

```
catalog/health  1.16-reco2-rc2, reco_contract 1, reco_feed 1, browse_contract 1, match_engine smart
reco/health     2.1-reco2-rc2, engine 3, upstream calls 6164, failures 4131
reco/onboard    200 {"contract":1,"artists":[]}
Deezer напрямую genre/132/artists -> {"data":[]}; chart/0/artists -> {"data":[],"total":0};
                artist/13/top -> {"data":[],"total":0}; artist/13/related -> данные; /catalog/similar -> данные
```

Сервер жив, версия правильная. Проблема в данных Deezer и в том, что система принимала пустоту за правду:

| Экран | Причина |
|---|---|
| «Список пока недоступен» при выборе артистов | `/reco/onboard` строится из `genre/*/artists` и `chart/0/artists` — оба пусты |
| «Здесь пока нет доступных треков» на странице артиста | `artist/{id}/top` пуст |
| «Для тебя» → «Повторить» | лента берёт треки из `artist/{id}/top`/`radio`; страницы пустые, после `MAX_EMPTY_PAGES` подряд — `PAGE_STALL`; клиент останавливался молча (`error = null`) |
| Поиск и «Похожие» работают | `search/*` и `related` у Deezer живы |

Почему «сломалось через несколько часов» — **гипотеза, не доказано**: пустые ответы кэшировались на TTL вида
(`onboard` 6 ч, `top`/`radio` 3 ч), а ранее набранный кэш мог отдавать нормальные данные, пока не протух. Когда именно
Deezer перестал отдавать эти эндпоинты, по логам не восстановить; `/reco/probe` и счётчики `empty{}` в `/reco/health` теперь покажут это сразу.

## Что исправлено

Сервер `1.17-reco2-rc3` / Reco `2.2-reco2-rc3` — см. `SERVER_UPDATE_1.17.md`. Клиент: `HomeRecoFeed.kt` — остановленная
лента объясняет причину («Подборка пока пуста. Нажми «Повторить»»).

Клиентских правок почти нет намеренно: корень был на сервере, а запасные пути (поиск, связанные) серверу доступны
в одном месте и сразу работают для всех установленных копий приложения.

## Проверено

- `server/tools/test_reco3.py` (14 тестов): мёртвые жанры/чарт/top/radio как в замере → запасной список, поиск, страница артиста,
  короткий TTL пустышек, протухание «отравленного» SQLite-кэша, 503 вместо пустого 200, фильтр заглушек, отсутствие вызовов
  запасных путей при живых эндпоинтах.
- Серверные наборы: reco, reco2, reco2_rc2, feed, browse, browse_deploy, catalog_wiring, server_deploy (с планом установки от хешей
  VPS), guard, stage2, resolver_stage2, smoke_stage2, smart_match, version_family, device, extra.
- Репозиторные: `check_kotlin_syntax`, `check_imports`, `check_static_refs`, `check_call_args`, `check_room_schema_config`, `test_ci_source`,
  `test_reco_http_contract_6821`, `test_reco3_6843` (в `check_selftest`).

## Не проверено

Gradle/KSP/Kotlin/Compose-сборка, APK, Android-тесты, живой Deezer, живой VPS. Какие эндпоинты Deezer живы
сейчас — покажет `GET /reco/probe` после установки. Если `artist_albums` и `artist_radio` там тоже пусты, полки «Новинки»
и часть «Похоже на» останутся скромнее; это отдельный следующий шаг, не регресс.

## Чего это не лечит

Артисты-заглушки Deezer без треков (вероятно, DJ Asul) останутся пустыми — треков у них у Deezer нет. Теперь такие не
попадают в рекомендации (фильтр `/images/artist//`), но если пользователь откроет такого артиста из поиска, страница будет
честно пустой. Для DJ Samir запасной поиск треков сработает, если Deezer знает хоть один его трек.
