package app.ziziplayer.ui;

import java.util.Arrays;

/** Tests production Java, not a second implementation of the new easing. */
public final class CameraReach66918Checks {
    private static int assertions;
    private static void check(boolean value, String why) {
        assertions++;
        if (!value) throw new AssertionError(why);
    }
    private static void near(float a, float b, float epsilon, String why) {
        check(Float.isFinite(a) && Float.isFinite(b) && Math.abs(a-b)<=epsilon,
            why+": "+a+" != "+b);
    }
    public static void main(String[] args) {
        near(CameraGooeyGeometry.reach(.25f,3f),55.125f,.0001f,"Earlier axial reach");
        near(CameraGooeyGeometry.protrusion(.25f,3f),31.5f,.0001f,"Unchanged width envelope");
        for (float bad : new float[]{Float.NaN,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY,-1f}) {
            near(CameraGooeyGeometry.reach(bad,3f),0,0,"Invalid progress is inert");
        }
        near(CameraGooeyGeometry.reach(2f,3f),0,0,"No residual overscroll reach");
        for (float d : new float[]{.75f,1f,1.5f,2f,2.625f,2.75f,3f,4f}) {
            float peak=CameraGooeyGeometry.protrusion(.5f,d);
            float previous=0;
            for (int i=0;i<=10000;i++) {
                float p=i/10000f;
                float h=CameraGooeyGeometry.protrusion(p,d);
                float reach=CameraGooeyGeometry.reach(p,d);
                check(reach>=h-.00003f && reach<=peak+.00003f,"Reach bounded by existing peak");
                if (i<=5000) check(reach>=previous-.00003f,"Monotone approach; no double pulse");
                else check(reach<=previous+.00003f,"Monotone retreat; no rebound");
                if (p>=.5f) near(reach,h,0,"Second half exactly unchanged");
                near(h,peak*(1-Math.abs(2*p-1)),0,"Original width at every progress");
                previous=reach;
            }
            for (float x : new float[]{.12f,.5f,.88f}) {
                float cx=360*d*x, cy=22.666666f*d, radius=6.1666665f*d;
                var target=new CameraMorphGeometry.Target(cx-radius,cy-radius,cx+radius,cy+radius);
                for(int i=0;i<=1000;i++) {
                    float p=i/1000f;
                    var f=CameraGooeyGeometry.frame(238.66667f*d,105.01333f*d,1,123.01333f*d*p,
                        180*d,49.33333f*d,6*d,123.01333f*d,31.33333f*d,target);
                    var s=CameraGooeyGeometry.seeds(target,f,d);
                    float h=CameraGooeyGeometry.protrusion(f.progress,d);
                    float r=f.width*.5f;
                    float cr=(float)Math.hypot(s.nx*target.width()*.5f,s.ny*target.height()*.5f);
                    near((float)Math.hypot(s.camera[0]-s.camera[4],s.camera[1]-s.camera[5]),h,.001f,
                        "Camera base not widened");
                    near((float)Math.hypot(s.artwork[0]-s.artwork[4],s.artwork[1]-s.artwork[5]),2*r,.001f,
                        "Artwork base not widened");
                    near((s.camera[2]-target.cx())*s.nx+(s.camera[3]-target.cy())*s.ny,cr+s.reach,.001f,
                        "Camera apex uses earlier reach");
                    near((s.artwork[2]-f.cx)*s.nx+(s.artwork[3]-f.cy)*s.ny,-r-s.reach*.25f,.001f,
                        "Artwork apex uses earlier reach");
                    near(s.protrusion,h,0,"Width remains the diagnostic protrusion");
                    var again=CameraGooeyGeometry.seeds(target,f,d);
                    check(Arrays.equals(s.camera,again.camera)&&Arrays.equals(s.artwork,again.artwork),
                        "Stateless repeated geometry");
                }
            }
        }
        for(float d:new float[]{Float.NaN,Float.POSITIVE_INFINITY,-1f,0f}) {
            near(CameraGooeyGeometry.reach(.25f,d),CameraGooeyGeometry.reach(.25f,1f),0,"Density fallback");
        }
        System.out.println("PASS: "+assertions+" early-reach geometry assertions; not GPU rasterization.");
    }
}
