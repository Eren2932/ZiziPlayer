package app.ziziplayer.ui;

import org.junit.Test;

public final class CameraNotch6702Test {
    @Test public void topNotchKeepsTheExistingSymbioteGeometry() {
        CameraNotch6702Checks.main(new String[0]);
    }
}
