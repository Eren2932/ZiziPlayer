package app.ziziplayer.ui;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;

/** Executes production geometry. Does not stand in for an Android/GPU test. */
public final class CameraNotch6702Checks {
    private static int assertions;
    private static void check(boolean ok, String why) {
        assertions++;
        if (!ok) throw new AssertionError(why);
    }
    private static void near(float a, float b, float tolerance, String why) {
        check(Float.isFinite(a) && Math.abs(a-b)<=tolerance, why+": "+a+" != "+b);
    }
    private static CameraMorphGeometry.Target bounds(float cx, float w, float h) {
        return new CameraMorphGeometry.Target(cx-w/2,0,cx+w/2,h);
    }
    private static CameraMorphGeometry.Target anchor(CameraMorphGeometry.Target b, float d, boolean exact) {
        return CameraNotchGeometry.anchor(b,360*d,800*d,32*d,d,exact,b==null?0:b.cx());
    }
    private static CameraMorphGeometry.Frame frame(CameraMorphGeometry.Target t, float d, float p) {
        return CameraGooeyGeometry.frame(238.66667f*d,105.01333f*d,1f,123.01333f*d*p,
                180*d,50*d,6*d,123.01333f*d,32*d,t);
    }
    public static void main(String[] args) {
        if (args.length>0 && args[0].equals("samples")) { samples(); return; }
        Random random = new Random(6702);
        for (float d : new float[]{1f,1.75f,2f,2.625f,3f,4f}) {
            near(CameraNotchGeometry.blurRadius(d),5f*d,0,"Density-normalized shared kernel");
            for (float x : new float[]{.18f,.5f,.82f}) {
                for (float w : new float[]{24f,48f,72f}) {
                    var b = bounds(360*d*x,w*d,24*d);
                    var t = anchor(b,d,false);
                    check(t!=null,"Compact U/V bounds admitted");
                    near(t.cx(),b.cx(),.001f,"Keep reported horizontal position");
                    near(t.bottom,b.bottom,0,"Emitter bottom on physical tip");
                    near(t.width(),24*d,.001f,"Do not use full notch width for emitter");
                    near(t.height(),t.width(),.001f,"Compact emitter, not flattened notch");
                    near(t.top,b.bottom-24*d,.001f,"Bottom-aligned compact emitter");
                    float lastY = Float.POSITIVE_INFINITY;
                    for (int i=0;i<=1000;i++) {
                        float p=i/1000f;
                        var f=frame(t,d,p); var s=CameraGooeyGeometry.seeds(t,f,d);
                        var reverse=CameraGooeyGeometry.seeds(t,frame(t,d,p),d);
                        check(Arrays.equals(s.camera,reverse.camera) && Arrays.equals(s.artwork,reverse.artwork),
                                "Reverse/hold must be bit identical");
                        for (float[] points : new float[][]{s.camera,s.artwork})
                            for (float v:points) check(Float.isFinite(v),"Finite seed");
                        near((float)Math.hypot(s.camera[4]-s.camera[0],s.camera[5]-s.camera[1]),
                                CameraGooeyGeometry.protrusion(p,d),.002f,"Existing seed WIDTH envelope");
                        near((float)Math.hypot(s.camera[2]-t.cx(),s.camera[3]-t.cy())-t.width()/2,
                                CameraGooeyGeometry.reach(p,d),.002f,"Existing axial LENGTH envelope");
                        near(s.protrusion,CameraGooeyGeometry.protrusion(f.progress,d),0,"Unchanged pulse");
                        check(f.cy<=lastY+.002f,"Monotone absorption"); lastY=f.cy;
                        if (x==.5f) near(s.camera[3],b.bottom+s.reach,.002f,"Tip grows from bottom, not top edge");
                    }
                    var end=frame(t,d,1f);
                    near(end.top()+end.height,b.bottom,.001f,"Cover ends at notch bottom");
                    near(end.imageAlpha,0,0,"No remaining overlay");
                    near(frame(t,d,3f).imageAlpha,0,0,"No marker on deep scroll");
                }
            }
            // A wide exact contour still has the SAME local seed as a narrower notch.
            var narrow=anchor(bounds(180*d,48*d,24*d),d,true);
            var wide=anchor(bounds(180*d,120*d,24*d),d,true);
            check(wide!=null,"Wide measured outline supported");
            for(int i=0;i<=100;i++) {
                float p=i/100f;
                check(Arrays.equals(CameraGooeyGeometry.seeds(narrow,frame(narrow,d,p),d).camera,
                        CameraGooeyGeometry.seeds(wide,frame(wide,d,p),d).camera),
                        "Notch shoulders must not widen/lengthen marker");
            }
            check(anchor(bounds(180*d,120*d,24*d),d,false)==null,"Do not guess broad Rect-only notches");
        }
        float[] curveSamples={0,468,0,.25f,490,60,.5f,540,72,.75f,590,60,1,612,0};
        var sampled=CameraNotchGeometry.sampledBounds(curveSamples);
        check(sampled!=null,"Curve samples admitted");
        near(sampled.bottom,72,0,"Use contour extrema, not control points");
        near(CameraNotchGeometry.bottomCenter(curveSamples,sampled,3),540,0,"Sampled contour bottom");
        check(CameraNotchGeometry.sampledBounds(new float[]{0,1,1,1,1,1})==null,"Degenerate sampled path rejected");
        check(CameraNotchGeometry.sampledBounds(new float[]{0,1,1,1,Float.NaN,3})==null,"Nonfinite sampled path rejected");
        near(CameraNotchGeometry.blurRadius(Float.NaN),5,0,"Invalid density finite fallback");
        var b=bounds(540,144,72);
        for (var invalid : new CameraMorphGeometry.Target[]{null,bounds(540,1080,72),
                bounds(540,10,72),bounds(540,144,400),bounds(540,144,2),
                new CameraMorphGeometry.Target(0,8,144,72),
                new CameraMorphGeometry.Target(-1,0,143,72),
                new CameraMorphGeometry.Target(Float.NaN,0,612,72)}) {
            check(CameraNotchGeometry.anchor(invalid,1080,2400,96,3,false,540)==null,"Unsafe rect rejected");
        }
        check(CameraNotchGeometry.anchor(b,2400,1080,96,3,true,540)==null,"Landscape rejected");
        check(CameraNotchGeometry.anchor(b,1080,2400,0,3,true,540)==null,"Hidden status rejected");
        check(CameraNotchGeometry.anchor(b,1080,2400,96,0,true,540)==null,"Zero density rejected");
        check(CameraNotchGeometry.anchor(b,1080,2400,96,3,true,Float.NaN)==null,"NaN tip rejected");
        check(CameraNotchGeometry.anchor(b,1080,2400,96,3,true,700)==null,"Outside tip rejected");
        // Samples of an asymmetric V, then a flat-bottomed U. Bottom is not rect centre.
        near(CameraNotchGeometry.bottomCenter(new float[]{0,468,0,.4f,555,72,1,612,0},b,3),555,0,"Asymmetric bottom");
        near(CameraNotchGeometry.bottomCenter(new float[]{0,468,0,.4f,530,72,.6f,550,72,1,612,0},b,3),540,0,"Flat bottom centre");
        check(Float.isNaN(CameraNotchGeometry.bottomCenter(new float[]{0,468,0,1,612,0},b,3)),"Missing bottom rejected");
        check(Float.isNaN(CameraNotchGeometry.bottomCenter(new float[]{0,Float.NaN,72,1,612,0},b,3)),"Malformed sample rejected");
        var asymmetric=CameraNotchGeometry.anchor(b,1080,2400,96,3,true,555);
        near(asymmetric.cx(),555,0,"Use Path bottom instead of bounding-box centre");
        // Homogeneity in window pixels (tolerances account for float rounding).
        for (int i=0;i<5000;i++) {
            float d=.75f+random.nextFloat()*4, cx=100+random.nextFloat()*160;
            float w=25+random.nextFloat()*45, h=8+random.nextFloat()*16;
            var raw=bounds(cx,w,h);
            var a=anchor(raw,1,true); var scaled=anchor(bounds(cx*d,w*d,h*d),d,true);
            check(a!=null && scaled!=null,"Valid random fixture");
            near(scaled.cx(),a.cx()*d,.001f,"Density-invariant x");
            near(scaled.width(),a.width()*d,.001f,"Density-invariant size");
            near(scaled.bottom,a.bottom*d,.001f,"Density-invariant bottom");
        }
        System.out.println("PASS: "+assertions+" notch geometry assertions (not Android rendering)");
    }
    private static void samples() {
        for(float d:new float[]{1f,1.75f,3f}) for(String shape:new String[]{"u","v","wide"}) {
            float w=(shape.equals("wide")?120:shape.equals("v")?64:48)*d;
            float h=(shape.equals("v")?28:24)*d;
            var b=bounds(180*d,w,h); var t=anchor(b,d,true);
            for(int i=0;i<=100;i++) {
                float p=i/100f; var f=frame(t,d,p); var s=CameraGooeyGeometry.seeds(t,f,d);
                System.out.printf(Locale.ROOT,"%s %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f",
                    shape,d,p,b.left,b.top,b.right,b.bottom,t.cx(),t.cy(),t.width(),f.cx,f.cy,f.width,f.imageAlpha);
                for(float v:s.camera)System.out.printf(Locale.ROOT," %.6f",v);
                for(float v:s.artwork)System.out.printf(Locale.ROOT," %.6f",v);
                System.out.printf(Locale.ROOT," %.6f%n",CameraNotchGeometry.blurRadius(d));
            }
        }
    }
}
