package app.ziziplayer.ui.screens

import app.ziziplayer.ui.components.rememberTrackReorder
import app.ziziplayer.ui.components.reorderHandle
import app.ziziplayer.ui.components.reorderRow
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.CollectionCoverImage
import app.ziziplayer.ui.components.rememberCollectionCover
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

@Composable
internal fun UnifiedLocalCollectionScreen(
    vm: MainViewModel, state: LibraryUiState, playback: PlaybackState,
    selected: Set<String>, downloads: Map<String, DownloadStatus>,
    onMenu: (TrackEntity) -> Unit, onSort: () -> Unit, onAdd: () -> Unit,
    selectionHeader: @Composable (Dp) -> Unit
) {
    val p = LocalPalette.current
    val playlist = state.openPlaylist
    val destination = playlist?.id?.let { "playlist:$it" }
        ?: state.openFolder?.let { "folder:$it" } ?: state.filter.name
    val title = playlist?.name ?: state.openFolder?.let { folder ->
        state.folders.firstOrNull { it.name == folder }?.label ?: folder
    } ?: if (state.filter == LibraryFilter.FAVORITES) "Избранное" else "Все треки"
    var showDownloads by rememberSaveable(destination) { mutableStateOf(false) }
    var playlistMenu by rememberSaveable(destination) { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val picking = selected.isNotEmpty()
    val list = rememberSaveable(destination, saver = LazyListState.Saver) { LazyListState() }
    // Bridge separately emitted Room flows: an old imported URI must not flash back
    // between the order acknowledgement and playlist metadata. A newly assigned URI resets it.
    var followsReorderedCover by remember(destination, playlist?.coverUri) { mutableStateOf(false) }
    val reorder = rememberTrackReorder(list, state.visible, { it.id }, firstRowIndex = 1, topInset = 56.dp) { before, after ->
        val saved = vm.reorderCollection(state, before.map { it.id }, after.map { it.id })
        if (saved && before.firstOrNull()?.id != after.firstOrNull()?.id) followsReorderedCover = true
        saved
    }
    val previewCover = reorder.previewChangesFirst
    // Full persisted membership, not search/sort, is the authority after the preview ends.
    // Unlike playlistMeta, collectionTracks arrives from the same flow as the displayed order.
    // Do not retain artwork of a track that was deleted/hidden/locked while a decode
    // was pending. Membership changes reset BOTH the loader and the image transition;
    // reordering the same members preserves them, and search uses full membership.
    val coverMembers = remember(destination, state.collectionTracks) {
        state.collectionTracks.mapTo(HashSet()) { it.id }
    }
    val previewTrack = reorder.items.firstOrNull()?.takeIf { it.id in coverMembers }
    val track = if (previewCover) previewTrack ?: state.collectionCoverTrack else state.collectionCoverTrack
    val cover = key(destination, coverMembers) {
        rememberCollectionCover(track = track,
            url = playlist?.coverUri?.takeUnless { previewCover || followsReorderedCover || playlist?.followFirstTrack == true },
            smooth = true)
    }
    val reorderEnabled = !picking && state.query.isBlank() && !state.loading
    LaunchedEffect(reorderEnabled) { if (!reorderEnabled) reorder.cancel() }
    val ownsQueue = playback.queueSourceId == destination
    val selection: (@Composable () -> Unit)? = if (picking) { { selectionHeader(56.dp) } } else null
    PinnedCollectionScaffold(
        destination = destination, title = title, tint = cover.tint, trackCount = state.visible.size,
        playingHere = ownsQueue && playback.isPlaying,
        playEnabled = state.visible.isNotEmpty() || ownsQueue,
        onBack = { focus.clearFocus(); vm.handleBack() },
        onPlay = {
            if (ownsQueue) vm.playPause()
            else state.visible.firstOrNull()?.let { vm.play(it, state.visible, destination) }
        },
        artwork = { key(destination, coverMembers) { CollectionCoverImage(cover, Modifier.fillMaxSize()) } },
        selectionToolbar = selection,
        reorderListState = list,
        hero = {
            CollectionHeroContent(title = title, metadata = trackCountLabel(state.collectionTracks.size)) {
                CollectionActionsRow(
                    onShuffle = {
                        val shuffled = state.visible.shuffled()
                        shuffled.firstOrNull()?.let { vm.play(it, shuffled, destination) }
                    },
                    shuffleEnabled = state.visible.isNotEmpty(),
                    onMenu = if (playlist != null) { { playlistMenu = true } } else null
                ) {
                    IconButton(onClick = { showDownloads = true }, enabled = LocalCollectionActionsAlpha.current > 0f && state.collectionTracks.isNotEmpty()) {
                        Icon(ZiziIcons.DownloadCircle, "Скачать всю подборку", tint = p.subtext)
                    }
                    IconButton(onClick = onSort, enabled = LocalCollectionActionsAlpha.current > 0f) { Icon(ZiziIcons.Sort, "Сортировать", tint = p.text) }
                    TextButton(onClick = onAdd, enabled = LocalCollectionActionsAlpha.current > 0f) { Text("Импорт", color = p.text) }
                }
            }
        }
    ) {
        if (state.loading) item(key = "collection:loading") {
            Text("Загружаем…", color = p.subtext, modifier = Modifier.padding(20.dp))
        } else if (state.visible.isEmpty()) item(key = "collection:empty") {
            Text(if (state.query.isNotBlank()) "Ничего не найдено" else "Здесь пока нет треков",
                color = p.subtext, modifier = Modifier.padding(20.dp))
        }
        items(reorder.items, key = { it.id }, contentType = { "track" }) { track ->
            val lifted = reorder.draggingKey == track.id || reorder.settlingKey == track.id
            BoxWithConstraints(Modifier.fillMaxWidth()
                .animateItem(fadeInSpec = null, fadeOutSpec = null,
                    placementSpec = if (reorder.animatePlacement(track.id))
                        spring(dampingRatio = 1f, stiffness = 600f) else null)
                .reorderRow(reorder, track.id)
                .background(if (lifted) Color(0xFF242424) else Color.Transparent)) {
                CollectionTrackRow(track, maxWidth.value / 1080f, track.id == playback.currentTrackId,
                    selected = track.id in selected, picking = picking,
                    onPlay = { vm.play(track, state.visible, destination) }, onSelect = { vm.toggleSelected(track.id) },
                    onLongPress = { vm.startSelection(track.id) }, onMenu = { onMenu(track) },
                    menuModifier = Modifier.reorderHandle(reorder, track.id, reorderEnabled) { onMenu(track) })
            }
        }
    }
    if (showDownloads) CollectionDownloadDialog(vm, state.collectionTracks, downloads) { showDownloads = false }
    if (playlistMenu && playlist != null) PlaylistActionsHost(vm, state, playlist.id,
        onOpen = { playlistMenu = false }, onDismiss = { playlistMenu = false })
}
