package app.ziziplayer.data

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/** How far a scan has got. [total] is 0 while the file list is still being built. */
data class ScanProgress(val done: Int, val total: Int, val label: String)

/**
 * Tag reading is IO bound (open container, seek, parse), so several files at once is a real win,
 * but each `MediaMetadataRetriever` holds a native decoder. Four is enough to saturate storage on a
 * mid-range phone without inviting an OEM media-server stall.
 */
private const val METADATA_WORKERS = 4

/** Reporting every file would spam the UI state; every 25th is smooth at any list length. */
private const val PROGRESS_STEP = 25

/** A malformed provider can present a directory tree that loops. Bound the walk. */
private const val MAX_DIRECTORIES = 20_000

private val AUDIO_EXTENSIONS = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "wav", "opus", "wma", "mp4", "m4b", "aif", "aiff", "mka")

class MusicScanner(private val context: Context) {

    /**
     * MediaStore in one query. Nothing here opens a file: title, artist, album, duration, size and
     * album art are all columns, which is why this path was never the slow one.
     *
     * Two corrections against v6.2:
     *
     * 1. `RELATIVE_PATH` only exists from API 29. v6.2 asked for it with `getColumnIndexOrThrow` on
     *    every API level, so on Android 8 and 9 the scan threw `IllegalArgumentException`, the
     *    exception was swallowed by the caller's `runCatching`, and the library came up **empty**
     *    with no error shown - on a minSdk 26 app. Optional columns are now resolved with
     *    `getColumnIndex` and the folder falls back to the parent directory of `DATA`.
     * 2. `DISPLAY_NAME` and `SIZE` are read because they, not the provider row id, form the key.
     */
    @Suppress("DEPRECATION") // MediaStore.Audio.Media.DATA: the only folder source before API 29.
    suspend fun scanMediaStore(): List<TrackEntity> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val columns = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DATE_ADDED)
            add(MediaStore.Audio.Media.ALBUM_ID)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.DATA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) add(MediaStore.Audio.Media.RELATIVE_PATH)
        }.toTypedArray()

        val result = ArrayList<TrackEntity>()
        val cursor = runCatching {
            context.contentResolver.query(collection, columns, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, null)
        }.getOrNull() ?: return@withContext result

        cursor.use { c ->
            val idI = c.getColumnIndex(MediaStore.Audio.Media._ID)
            val titleI = c.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val artistI = c.getColumnIndex(MediaStore.Audio.Media.ARTIST)
            val albumI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM)
            val durationI = c.getColumnIndex(MediaStore.Audio.Media.DURATION)
            val dateI = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            val albumIdI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
            val nameI = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeI = c.getColumnIndex(MediaStore.Audio.Media.SIZE)
            val dataI = c.getColumnIndex(MediaStore.Audio.Media.DATA)
            val pathI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            } else -1
            if (idI < 0) return@use

            while (c.moveToNext()) {
                currentCoroutineContext().ensureActive()
                val mediaId = c.getLong(idI)
                val uri = ContentUris.withAppendedId(collection, mediaId)
                val displayName = c.string(nameI)
                val size = if (sizeI >= 0) c.getLong(sizeI) else 0L
                val albumId = if (albumIdI >= 0) c.getLong(albumIdI) else 0L
                result += TrackEntity(
                    id = TrackId.forFile(displayName, size, uri.toString()),
                    uri = uri.toString(),
                    title = c.string(titleI) ?: displayName?.substringBeforeLast('.') ?: "Без названия",
                    artist = (c.string(artistI) ?: "Неизвестный артист").replace("<unknown>", "Неизвестный артист"),
                    album = c.string(albumI) ?: "",
                    durationMs = if (durationI >= 0) c.getLong(durationI) else 0L,
                    artworkUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString(),
                    sourceFolder = folderName(c.string(pathI), c.string(dataI)),
                    dateAdded = if (dateI >= 0) c.getLong(dateI) * 1000 else System.currentTimeMillis(),
                    sizeBytes = size,
                    legacyId = "media:$mediaId"
                )
            }
        }
        result
    }

    /**
     * A user-picked folder tree.
     *
     * v6.2 walked it with `DocumentFile` and read tags inline, on one thread, with no way to stop.
     * Both halves of that were expensive:
     *
     * - **`DocumentFile` is one query per property.** `listFiles()` queries the directory, then
     *   every `.name`, `.type`, `.isDirectory` and `.length()` issues *another* IPC round trip to
     *   the document provider. For 3400 files that is well over ten thousand binder calls before a
     *   single tag is read. Here each directory is queried exactly once, with a projection, and
     *   every value comes out of that one row.
     * - **`MediaMetadataRetriever` on the walking thread.** It is now off the walk, capped at
     *   [METADATA_WORKERS] in parallel, and - crucially - **skipped entirely for files already in
     *   the database with the same byte size**. After the first scan a rescan touches no decoder at
     *   all, so "refresh library" goes from tens of seconds to roughly the cost of the walk.
     *
     * The walk is iterative rather than recursive: a deep tree used to grow the stack in lockstep
     * with its depth, and a provider that reports a cycle would have overflowed it.
     *
     * Cancellation is honoured per directory and per file, so leaving the screen or removing the
     * folder stops the work instead of letting it run to completion in the background.
     *
     * [onProgress] is invoked from the metadata workers, i.e. from several threads - the receiver
     * must be safe for that (the ViewModel funnels it into a `MutableStateFlow`, which is).
     */
    suspend fun scanTree(
        treeUri: Uri,
        known: Map<String, TrackEntity> = emptyMap(),
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): List<TrackEntity> = withContext(Dispatchers.IO) {
        val docs = walk(treeUri)
        if (docs.isEmpty()) return@withContext emptyList()

        val total = docs.size
        val counter = AtomicInteger(0)
        val gate = Semaphore(METADATA_WORKERS)

        coroutineScope {
            docs.map { doc ->
                async {
                    val uriText = doc.uri.toString()
                    val id = TrackId.forFile(doc.name, doc.size, uriText)
                    val legacy = "saf:" + UUID.nameUUIDFromBytes(uriText.toByteArray())
                    val cached = known[id]

                    val entity = if (cached != null && cached.sizeBytes == doc.size && doc.size > 0L && cached.durationMs > 0L) {
                        // Same file, same bytes: its tags cannot have changed. Only the things that
                        // describe *where* it currently lives are refreshed.
                        cached.copy(uri = uriText, sourceFolder = doc.folder, legacyId = legacy)
                    } else {
                        gate.withPermit {
                            currentCoroutineContext().ensureActive()
                            val meta = readMeta(doc.uri)
                            TrackEntity(
                                id = id,
                                uri = uriText,
                                title = meta.title?.takeIf { it.isNotBlank() }
                                    ?: doc.name.substringBeforeLast('.').ifBlank { "Без названия" },
                                artist = meta.artist?.takeIf { it.isNotBlank() } ?: "Неизвестный артист",
                                album = meta.album.orEmpty(),
                                durationMs = meta.duration,
                                sourceFolder = doc.folder,
                                dateAdded = if (doc.modified > 0L) doc.modified else System.currentTimeMillis(),
                                sizeBytes = doc.size,
                                legacyId = legacy
                            )
                        }
                    }

                    val done = counter.incrementAndGet()
                    if (done % PROGRESS_STEP == 0 || done == total) onProgress(done, total)
                    entity
                }
            }.awaitAll()
        }
    }

    // ---------------- tree walk ----------------

    private class RawDoc(val uri: Uri, val name: String, val size: Long, val folder: String, val modified: Long)

    private suspend fun walk(treeUri: Uri): List<RawDoc> {
        val resolver = context.contentResolver
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: return emptyList()
        val out = ArrayList<RawDoc>()
        val queue = ArrayDeque<Pair<String, String>>()
        val visited = HashSet<String>()
        queue.add(rootId to (rootDisplayName(treeUri, rootId) ?: "Выбранная папка"))

        var directories = 0
        val projection = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
        )

        while (queue.isNotEmpty() && directories < MAX_DIRECTORIES) {
            currentCoroutineContext().ensureActive()
            val (docId, folder) = queue.poll() ?: break
            if (!visited.add(docId)) continue
            directories++

            val children = runCatching { DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId) }.getOrNull() ?: continue
            runCatching {
                resolver.query(children, projection, null, null, null)?.use { c ->
                    val idI = c.getColumnIndex(Document.COLUMN_DOCUMENT_ID)
                    val nameI = c.getColumnIndex(Document.COLUMN_DISPLAY_NAME)
                    val mimeI = c.getColumnIndex(Document.COLUMN_MIME_TYPE)
                    val sizeI = c.getColumnIndex(Document.COLUMN_SIZE)
                    val modI = c.getColumnIndex(Document.COLUMN_LAST_MODIFIED)
                    if (idI < 0) return@use
                    while (c.moveToNext()) {
                        val childId = c.string(idI) ?: continue
                        val name = c.string(nameI) ?: ""
                        val mime = c.string(mimeI)
                        if (mime == Document.MIME_TYPE_DIR) {
                            queue.add(childId to name.ifBlank { folder })
                        } else if (isAudio(name, mime)) {
                            out += RawDoc(
                                uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId),
                                name = name,
                                size = if (sizeI >= 0) c.getLong(sizeI) else 0L,
                                folder = folder,
                                modified = if (modI >= 0) c.getLong(modI) else 0L
                            )
                        }
                    }
                }
            }
        }
        return out
    }

    private fun rootDisplayName(treeUri: Uri, rootId: String): String? = runCatching {
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        context.contentResolver.query(uri, arrayOf(Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.string(0) else null
        }
    }.getOrNull()

    private fun isAudio(name: String, mime: String?): Boolean {
        if (mime != null && mime.startsWith("audio/")) return true
        // Providers hand back application/octet-stream for flac and opus more often than not.
        val extension = name.substringAfterLast('.', "").lowercase()
        return extension.isNotEmpty() && extension in AUDIO_EXTENSIONS
    }

    // ---------------- tags ----------------

    private data class AudioMeta(val title: String?, val artist: String?, val album: String?, val duration: Long)

    private fun readMeta(uri: Uri): AudioMeta = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            AudioMeta(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally {
            // release() throws on some OEM builds when setDataSource failed; it must not take the
            // whole scan down with it.
            runCatching { retriever.release() }
        }
    }.getOrDefault(AudioMeta(null, null, null, 0L))

    // ---------------- helpers ----------------

    /** Folder label: RELATIVE_PATH on API 29+, otherwise the parent directory of the legacy path. */
    private fun folderName(relativePath: String?, data: String?): String {
        relativePath?.trimEnd('/')?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let { return it }
        data?.substringBeforeLast('/', "")?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let { return it }
        return "Устройство"
    }
}

/** `getString` on a column index that may be -1, without the try/catch at every call site. */
private fun Cursor.string(index: Int): String? = if (index < 0) null else runCatching { getString(index) }.getOrNull()
