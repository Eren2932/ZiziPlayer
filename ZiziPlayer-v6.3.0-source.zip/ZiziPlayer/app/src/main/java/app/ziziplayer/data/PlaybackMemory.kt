package app.ziziplayer.data

import android.content.Context

/**
 * Playback position lives OUTSIDE DataStore on purpose.
 *
 * In v4 the position was written into the settings DataStore every 5 seconds. The whole library
 * pipeline is derived from that same flow, so every write re-ran the filter, the search and a full
 * sort of the entire library on a background thread and pushed a brand new list into Compose.
 * Playing music literally rebuilt the library four times per minute - that is where the list lag
 * and the memory churn came from. SharedPreferences has no flow, so nothing downstream reacts.
 */
class PlaybackMemory(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("zizi_playback", Context.MODE_PRIVATE)

    fun save(trackId: String, positionMs: Long) {
        if (trackId.isEmpty()) return
        prefs.edit()
            .putString(KEY_TRACK, trackId)
            .putLong(KEY_POSITION, positionMs.coerceAtLeast(0L))
            .apply()
    }

    fun lastTrackId(): String? = prefs.getString(KEY_TRACK, null)

    /**
     * Follows the one-shot id rewrite. Without this, "resume where you left off" silently stops
     * working exactly once, on the upgrade to v6.3, because the remembered id no longer names a row.
     */
    fun remapLastTrack(oldId: String, newId: String) {
        if (prefs.getString(KEY_TRACK, null) != oldId) return
        prefs.edit().putString(KEY_TRACK, newId).apply()
    }
    fun lastPositionMs(): Long = prefs.getLong(KEY_POSITION, 0L)

    private companion object {
        const val KEY_TRACK = "last_track"
        const val KEY_POSITION = "last_position"
    }
}
