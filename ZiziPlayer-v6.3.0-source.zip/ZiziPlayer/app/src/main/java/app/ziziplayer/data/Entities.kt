package app.ziziplayer.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "tracks", indices = [Index(value = ["uri"], unique = true)])
data class TrackEntity(
    /** Derived from the file, not from the provider row. See [TrackId]. */
    @PrimaryKey val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long,
    val artworkUri: String? = null,
    val sourceFolder: String = "Устройство",
    val dateAdded: Long = System.currentTimeMillis(),
    /**
     * Part of the identity, and the reason a rescan can skip re-reading tags: a file whose size is
     * unchanged has unchanged metadata.
     */
    @ColumnInfo(defaultValue = "0") val sizeBytes: Long = 0L,
    /**
     * The id this row would have had under the v6.2 scheme. Filled by the scanner and consumed
     * exactly once, by the one-shot remap in [MusicRepository]; null afterwards for new rows.
     */
    val legacyId: String? = null
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val trackId: String, val addedAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrackEntity(val playlistId: Long, val trackId: String, val position: Int)

@Entity(tableName = "track_fx")
data class TrackFxEntity(
    @PrimaryKey val trackId: String,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val reverb: Int = 0
)

@Entity(tableName = "hidden")
data class HiddenEntity(@PrimaryKey val trackId: String, val hiddenAt: Long = System.currentTimeMillis())

@Entity(tableName = "play_stats")
data class PlayStatEntity(
    @PrimaryKey val trackId: String,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L
)

/** Projection used to show "N tracks" next to a playlist without loading its rows. */
data class PlaylistCount(val playlistId: Long, val total: Int)
