package app.ziziplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {
    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE") fun observeTracks(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE id = :id") suspend fun track(id: String): TrackEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTracks(tracks: List<TrackEntity>)
    /**
     * v4 used "DELETE FROM tracks WHERE id NOT IN (:ids)". SQLite caps a statement at 999 bound
     * variables, so every rescan crashed on libraries larger than that. The stale ids are now
     * computed in Kotlin and deleted in small chunks.
     */
    @Query("SELECT id FROM tracks") suspend fun allTrackIds(): List<String>
    @Query("DELETE FROM tracks WHERE id IN (:ids)") suspend fun deleteTracks(ids: List<String>)

    /**
     * Snapshot used by the scanner to avoid re-reading tags. A file whose name and byte size are
     * unchanged has unchanged metadata, so its row can be carried over verbatim and the
     * MediaMetadataRetriever call - tens of milliseconds, per file - skipped entirely.
     */
    @Query("SELECT * FROM tracks") suspend fun allTracks(): List<TrackEntity>

    /**
     * Every track id the user actually invested something in. Used to keep the one-shot id remap
     * proportional to the user's data instead of to the size of the library: a 3000-track library
     * with 40 favourites needs 40 remaps, not 3000.
     */
    @Query(
        """
        SELECT trackId FROM favorites
        UNION SELECT trackId FROM playlist_tracks
        UNION SELECT trackId FROM track_fx
        UNION SELECT trackId FROM hidden
        UNION SELECT trackId FROM play_stats
        """
    )
    suspend fun referencedTrackIds(): List<String>

    /**
     * Moves everything attached to [oldId] onto [newId], atomically.
     *
     * `OR IGNORE` matters: if both ids are already present - the same file reachable through both
     * MediaStore and a SAF grant, which the old scheme happily stored twice - the UPDATE would
     * violate the primary key and abort the whole transaction. Ignoring keeps the row that is
     * already correct and leaves the stale one to be swept by the prune queries.
     */
    @Transaction
    suspend fun remapTrackId(oldId: String, newId: String) {
        remapFavorite(oldId, newId)
        remapPlaylistTrack(oldId, newId)
        remapFx(oldId, newId)
        remapHidden(oldId, newId)
        remapStat(oldId, newId)
    }

    @Query("UPDATE OR IGNORE favorites SET trackId = :newId WHERE trackId = :oldId") suspend fun remapFavorite(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE playlist_tracks SET trackId = :newId WHERE trackId = :oldId") suspend fun remapPlaylistTrack(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE track_fx SET trackId = :newId WHERE trackId = :oldId") suspend fun remapFx(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE hidden SET trackId = :newId WHERE trackId = :oldId") suspend fun remapHidden(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE play_stats SET trackId = :newId WHERE trackId = :oldId") suspend fun remapStat(oldId: String, newId: String)

    /** Rows pointing at tracks that no longer exist. Without this the database only ever grows. */
    @Query("DELETE FROM favorites WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneFavorites()
    @Query("DELETE FROM playlist_tracks WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun prunePlaylistTracks()
    @Query("DELETE FROM track_fx WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneFx()
    @Query("DELETE FROM play_stats WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneStats()
    @Query("DELETE FROM hidden WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneHidden()

    @Query("SELECT trackId FROM favorites") fun observeFavoriteIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun favorite(item: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE trackId = :id") suspend fun unfavorite(id: String)

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun observePlaylists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun createPlaylist(item: PlaylistEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addToPlaylist(item: PlaylistTrackEntity)
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId") suspend fun removeFromPlaylist(playlistId: Long, trackId: String)
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") fun observePlaylistTracks(id: Long): Flow<List<TrackEntity>>
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") suspend fun playlistTracks(id: Long): List<TrackEntity>
    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_tracks WHERE playlistId = :id") suspend fun nextPosition(id: Long): Int

    @Query("SELECT * FROM track_fx WHERE trackId = :id") suspend fun fx(id: String): TrackFxEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveFx(item: TrackFxEntity)

    @Query("DELETE FROM tracks WHERE id = :id") suspend fun deleteTrack(id: String)

    @Query("SELECT trackId FROM hidden") fun observeHiddenIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun hide(item: HiddenEntity)
    @Query("DELETE FROM hidden WHERE trackId = :id") suspend fun unhide(id: String)
    @Query("DELETE FROM hidden") suspend fun clearHidden()

    @Query("SELECT * FROM play_stats") fun observeStats(): Flow<List<PlayStatEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun ensureStat(item: PlayStatEntity)
    @Query("UPDATE play_stats SET playCount = playCount + 1, lastPlayedAt = :now WHERE trackId = :id") suspend fun bumpStat(id: String, now: Long)

    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :id") suspend fun clearPlaylist(id: Long)
    @Query("UPDATE playlists SET name = :name WHERE id = :id") suspend fun renamePlaylist(id: Long, name: String)
    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :id") suspend fun playlistSize(id: Long): Int
    @Query("SELECT playlistId AS playlistId, COUNT(*) AS total FROM playlist_tracks GROUP BY playlistId")
    fun observePlaylistCounts(): Flow<List<PlaylistCount>>
}
