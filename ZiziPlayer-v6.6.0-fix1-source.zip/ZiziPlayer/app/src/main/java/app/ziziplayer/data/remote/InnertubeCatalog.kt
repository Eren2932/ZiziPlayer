package app.ziziplayer.data.remote

import android.net.Uri
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * YouTube Music through its own internal API (Innertube).
 *
 * This is the only source that actually contains the music this library is about - 2025/2026
 * distributor and upload repertoire that Jamendo, Audius and the Spotify API either do not have or
 * will not stream. It is also a private API, and the honest consequences are:
 *
 *  - it is used against YouTube's terms of service;
 *  - the response shape changes without notice, so **every** parse below returns null on anything
 *    unexpected instead of throwing (see Json.kt for why that is not laziness but the design);
 *  - stream URLs are short lived and IP bound, which is why nothing here is ever cached or stored:
 *    [resolveStream] is called from the Media3 loading thread at the moment the stream is opened.
 *
 * No cookies, no login, no account. Not only because personalisation is not worth it, but because
 * an account attached to this kind of traffic is an account that gets banned - the app would keep
 * working, the user's YouTube would not.
 */
class InnertubeCatalog(
    private val apiKey: String,
    private val hl: String = Locale.getDefault().language.ifEmpty { "ru" },
    private val gl: String = Locale.getDefault().country.ifEmpty { "RU" }
) : RemoteCatalog {

    override val id: String = "yt"
    override val label: String = "YouTube Music"

    private companion object {
        const val BASE = "https://music.youtube.com/youtubei/v1"

        /**
         * Search filter blobs. These are protobuf-encoded filter selections, i.e. exactly the
         * bytes the web app itself sends when a chip is tapped. They are stable in practice but
         * they are not ours, so a failed filtered search degrades to an unfiltered one rather than
         * to an error - the user sees results, mixed, instead of a red screen.
         */
        const val FILTER_SONGS = "EgWKAQIIAWoKEAkQBRAKEAMQBA=="
        const val FILTER_ALBUMS = "EgWKAQIYAWoKEAkQChAFEAMQBA=="
        const val FILTER_PLAYLISTS = "EgeKAQQoAEABagwQDhAKEAMQBRAJEBU="
        const val FILTER_ARTISTS = "EgWKAQIgAWoKEAkQChAFEAMQBA=="

        /** Clients tried in order for a stream. The first two answer with unciphered URLs. */
        val STREAM_CLIENTS = listOf("ANDROID_MUSIC", "IOS_MUSIC", "WEB_REMIX")

        val DURATION = Regex("""^\d{1,2}:\d{2}(:\d{2})?$""")
    }

    // ---------------------------------------------------------------- request plumbing

    private fun endpoint(path: String, extra: Map<String, String> = emptyMap()): String {
        val builder = Uri.parse("$BASE/$path").buildUpon()
        builder.appendQueryParameter("key", apiKey)
        builder.appendQueryParameter("prettyPrint", "false")
        extra.forEach { (k, v) -> builder.appendQueryParameter(k, v) }
        return builder.build().toString()
    }

    private fun context(client: String): JSONObject {
        val clientJson = JSONObject().put("hl", hl).put("gl", gl)
        when (client) {
            "ANDROID_MUSIC" -> clientJson
                .put("clientName", "ANDROID_MUSIC")
                .put("clientVersion", "7.27.52")
                .put("androidSdkVersion", 34)
                .put("osName", "Android")
                .put("osVersion", "14")
            "IOS_MUSIC" -> clientJson
                .put("clientName", "IOS_MUSIC")
                .put("clientVersion", "7.27.0")
                .put("deviceModel", "iPhone16,2")
                .put("osName", "iOS")
                .put("osVersion", "17.5.1.21F90")
            else -> clientJson
                .put("clientName", "WEB_REMIX")
                .put("clientVersion", "1.20241028.01.00")
        }
        return JSONObject().put("client", clientJson)
    }

    private fun headers(client: String): Map<String, String> = buildMap {
        put("X-Goog-Api-Format-Version", "1")
        put("Accept-Language", "$hl-$gl")
        if (client == "WEB_REMIX") {
            put("Origin", "https://music.youtube.com")
            put("Referer", "https://music.youtube.com/")
            put("X-Youtube-Client-Name", "67")
            put("X-Youtube-Client-Version", "1.20241028.01.00")
        }
    }

    // ---------------------------------------------------------------- search

    override suspend fun isUsable(): Boolean = apiKey.isNotBlank()

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        if (query.isBlank()) return SearchPage.EMPTY
        val body = JSONObject()
            .put("context", context("WEB_REMIX"))
            .put("query", query)
        filterFor(kind)?.let { body.put("params", it) }
        pageToken?.let { body.put("continuation", it) }

        val extra = if (pageToken == null) emptyMap() else mapOf("continuation" to pageToken, "type" to "next")
        val response = ZiziHttp.postJson(endpoint("search", extra), body, headers("WEB_REMIX"))

        // A 200 with neither of these keys means the response shape moved, not that nothing matched.
        if (!response.has("contents") && !response.has("continuationContents") && !response.has("onResponseReceivedActions")) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "YouTube Music ответил в неизвестном формате")
        }

        val items = parseListItems(response)
        val next = response.deepFind("continuationCommand", limit = 4).firstNotNullOfOrNull { it.str("token") }
        return SearchPage(items, next)
    }

    private fun filterFor(kind: RemoteKind?): String? = when (kind) {
        RemoteKind.TRACK -> FILTER_SONGS
        RemoteKind.ALBUM -> FILTER_ALBUMS
        RemoteKind.PLAYLIST -> FILTER_PLAYLISTS
        RemoteKind.ARTIST -> FILTER_ARTISTS
        null -> null
    }

    override suspend fun suggest(prefix: String): List<String> {
        if (prefix.isBlank()) return emptyList()
        val body = JSONObject().put("context", context("WEB_REMIX")).put("input", prefix)
        val response = runCatching {
            ZiziHttp.postJson(endpoint("music/get_search_suggestions"), body, headers("WEB_REMIX"))
        }.getOrNull() ?: return emptyList()
        return response.deepFind("searchSuggestionRenderer", limit = 12)
            .mapNotNull { it.runs("suggestion") }
            .distinct()
    }

    override suspend fun discover(): List<DiscoverShelf> {
        val body = JSONObject()
            .put("context", context("WEB_REMIX"))
            .put("browseId", "FEmusic_explore")
        val response = ZiziHttp.postJson(endpoint("browse"), body, headers("WEB_REMIX"))
        val shelves = response.deepFind("musicCarouselShelfRenderer", limit = 12).mapNotNull { shelf ->
            val title = shelf.node("header")?.runs("musicCarouselShelfBasicHeaderRenderer", "title")
                ?: shelf.runs("header", "musicCarouselShelfBasicHeaderRenderer", "title")
                ?: return@mapNotNull null
            val items = parseTwoRowItems(shelf) + parseListItems(shelf)
            if (items.isEmpty()) null else DiscoverShelf(title, items)
        }
        if (shelves.isEmpty()) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "Не удалось разобрать подборки YouTube Music")
        }
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val browseId = when (collection.kind) {
            // A playlist id becomes a browse id by prefixing VL; album and artist ids already are one.
            RemoteKind.PLAYLIST ->
                if (collection.remoteId.startsWith("VL")) collection.remoteId else "VL${collection.remoteId}"
            else -> collection.remoteId
        }
        val body = JSONObject().put("context", context("WEB_REMIX")).put("browseId", browseId)
        val response = ZiziHttp.postJson(endpoint("browse"), body, headers("WEB_REMIX"))
        return parseListItems(response).filterIsInstance<RemoteItem.Song>().map { it.track }
    }

    // ---------------------------------------------------------------- parsing

    /**
     * Rows, from anywhere in the payload.
     *
     * `musicResponsiveListItemRenderer` is asked for by name across the whole tree rather than
     * quoted through a nine-level path, because the path is what changes when YouTube reshuffles
     * its layout - the renderer name is what stays. Breadth first, so screen order is preserved.
     */
    private fun parseListItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicResponsiveListItemRenderer").mapNotNull { parseRow(it) }

    private fun parseRow(row: JSONObject): RemoteItem? {
        val texts = row.optJSONArray("flexColumns").items().mapNotNull {
            it.runs("musicResponsiveListItemFlexColumnRenderer", "text")
        }
        val title = texts.firstOrNull()?.takeIf { it.isNotBlank() } ?: return null
        val artwork = row.node("thumbnail")?.bestThumbnail()
        val explicit = row.deepString("iconType")?.contains("EXPLICIT") == true ||
            row.toString().contains("MUSIC_EXPLICIT_BADGE")

        val videoId = row.node("overlay")?.deepString("videoId")
            ?: row.node("playlistItemData")?.str("videoId")
            ?: row.deepString("videoId")

        if (videoId != null) {
            val duration = (texts + row.optJSONArray("fixedColumns").items().mapNotNull {
                it.runs("musicResponsiveListItemFixedColumnRenderer", "text")
            }).lastOrNull { DURATION.matches(it.trim()) }
            // Column layout differs per result type; the first non-title column that is not the
            // type label and not the duration is the artist.
            val artist = texts.drop(1).firstOrNull { !DURATION.matches(it.trim()) && it.isNotBlank() }
            return RemoteItem.Song(
                RemoteTrack(
                    provider = id,
                    remoteId = videoId,
                    title = title,
                    artist = cleanArtist(artist),
                    album = "",
                    durationMs = parseDuration(duration),
                    artworkUrl = artwork,
                    explicit = explicit
                )
            )
        }

        val browseId = row.deepString("browseId") ?: return null
        val playlistId = row.deepString("playlistId")
        val kind = when {
            browseId.startsWith("UC") || browseId.startsWith("MPLA") -> RemoteKind.ARTIST
            browseId.startsWith("MPRE") -> RemoteKind.ALBUM
            playlistId != null || browseId.startsWith("VL") -> RemoteKind.PLAYLIST
            else -> return null
        }
        return RemoteItem.Group(
            RemoteCollection(
                provider = id,
                remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                kind = kind,
                title = title,
                subtitle = texts.drop(1).joinToString(" • ").take(80),
                artworkUrl = artwork
            )
        )
    }

    /** Cards on the explore shelves use a different renderer than list rows. */
    private fun parseTwoRowItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicTwoRowItemRenderer", limit = 40).mapNotNull { card ->
            val title = card.runs("title") ?: return@mapNotNull null
            val subtitle = card.runs("subtitle").orEmpty()
            val artwork = card.node("thumbnailRenderer")?.bestThumbnail() ?: card.bestThumbnail()
            val videoId = card.deepString("videoId")
            if (videoId != null) {
                RemoteItem.Song(
                    RemoteTrack(
                        provider = id,
                        remoteId = videoId,
                        title = title,
                        artist = cleanArtist(subtitle),
                        artworkUrl = artwork
                    )
                )
            } else {
                val browseId = card.deepString("browseId") ?: return@mapNotNull null
                val playlistId = card.deepString("playlistId")
                val kind = when {
                    browseId.startsWith("UC") -> RemoteKind.ARTIST
                    browseId.startsWith("MPRE") -> RemoteKind.ALBUM
                    else -> RemoteKind.PLAYLIST
                }
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                        kind = kind,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artwork
                    )
                )
            }
        }

    private fun cleanArtist(raw: String?): String {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty()) return "Неизвестный исполнитель"
        // Subtitles arrive as "Трек • Артист • Альбом" or "Song • Artist"; the label is noise.
        val parts = value.split("•").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size <= 1) return value
        val label = setOf("song", "трек", "video", "видео", "single", "сингл", "album", "альбом", "playlist", "плейлист", "artist", "исполнитель")
        return parts.firstOrNull { it.lowercase() !in label && !it.endsWith("просмотров") } ?: parts.last()
    }

    private fun parseDuration(text: String?): Long {
        val value = text?.trim() ?: return 0L
        if (!DURATION.matches(value)) return 0L
        val parts = value.split(":").mapNotNull { it.toIntOrNull() }
        return when (parts.size) {
            2 -> (parts[0] * 60L + parts[1]) * 1000L
            3 -> (parts[0] * 3600L + parts[1] * 60L + parts[2]) * 1000L
            else -> 0L
        }
    }

    // ---------------------------------------------------------------- stream

    /**
     * Walks [STREAM_CLIENTS] until one returns a playable, unciphered audio format.
     *
     * The client matters and it is the whole trick: the web client returns URLs behind
     * `signatureCipher`, which has to be deobfuscated by running YouTube's own JavaScript. The
     * mobile music clients return the URL as-is. So we ask them first, and the web client is kept
     * last only to produce a meaningful error rather than a silent nothing.
     *
     * Failures are collected instead of swallowed: when this eventually breaks, the message says
     * which client refused and why, which is the difference between a five minute fix and an
     * evening.
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val problems = ArrayList<String>(STREAM_CLIENTS.size)
        for (client in STREAM_CLIENTS) {
            val body = JSONObject()
                .put("context", context(client))
                .put("videoId", remoteId)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .put("params", "8AEB")
            val response = try {
                ZiziHttp.postJson(endpoint("player"), body, headers(client))
            } catch (e: CatalogException) {
                if (e.reason == CatalogException.Reason.OFFLINE) throw e
                problems.add("$client: ${e.message}")
                continue
            }

            val status = response.str("playabilityStatus", "status")
            if (status != null && status != "OK") {
                val why = response.str("playabilityStatus", "reason")
                    ?: response.runs("playabilityStatus", "messages")
                    ?: status
                // A track that is blocked stays blocked no matter which client asks.
                if (status == "UNPLAYABLE" || status == "LOGIN_REQUIRED" || status == "ERROR") {
                    throw CatalogException(CatalogException.Reason.UNAVAILABLE, why)
                }
                problems.add("$client: $status")
                continue
            }

            val picked = pickFormat(response.array("streamingData", "adaptiveFormats"), quality)
                ?: pickFormat(response.array("streamingData", "formats"), quality)
            if (picked == null) {
                problems.add("$client: нет открытых аудиопотоков")
                continue
            }
            return picked
        }
        throw CatalogException(
            CatalogException.Reason.PROTOCOL,
            "YouTube Music не отдал поток. " + problems.joinToString("; ")
        )
    }

    /**
     * Audio only, no cipher, closest to the requested bitrate.
     *
     * Chosen by measured bitrate rather than by a hardcoded itag list: itags get retired, and a
     * table of magic numbers is one more thing that silently rots. Ties go to m4a/AAC - it is
     * hardware decoded on everything this app runs on, Opus is not always.
     */
    private fun pickFormat(formats: JSONArray?, quality: RemoteQuality): StreamInfo? {
        val candidates = formats.items().filter { format ->
            val mime = format.str("mimeType").orEmpty()
            val url = format.str("url")
            mime.startsWith("audio/") &&
                url != null &&
                format.str("signatureCipher") == null &&
                format.str("cipher") == null
        }
        if (candidates.isEmpty()) return null
        val target = quality.targetKbps * 1000
        val best = candidates.minByOrNull { format ->
            val bitrate = (format.long("bitrate") ?: format.long("averageBitrate") ?: 0L).toInt()
            val distance = abs(bitrate - target)
            val penalty = if (format.str("mimeType").orEmpty().contains("mp4a")) 0 else 8_000
            distance + penalty
        } ?: return null

        val url = best.str("url") ?: return null
        val bitrate = ((best.long("bitrate") ?: 0L) / 1000).toInt()
        return StreamInfo(
            url = url,
            mimeType = best.str("mimeType")?.substringBefore(';') ?: "audio/mp4",
            bitrateKbps = if (bitrate > 0) bitrate else quality.targetKbps,
            ttlMs = ttlOf(url)
        )
    }

    /**
     * The URL carries its own deadline in `expire=<epoch seconds>`.
     *
     * A minute is shaved off it, because "valid until" and "still valid when the request arrives"
     * are not the same thing on a mobile connection. If the parameter is missing we assume a
     * conservative hour rather than trusting the link forever.
     */
    private fun ttlOf(url: String): Long {
        val expire = Regex("""[?&]expire=(\d+)""").find(url)?.groupValues?.getOrNull(1)?.toLongOrNull()
            ?: return 60 * 60 * 1000L
        val left = expire * 1000L - System.currentTimeMillis() - 60_000L
        return left.coerceIn(60_000L, 6 * 60 * 60 * 1000L)
    }
}
