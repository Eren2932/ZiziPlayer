package app.ziziplayer.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TrackEntity::class,
        FavoriteEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class,
        TrackFxEntity::class,
        HiddenEntity::class,
        PlayStatEntity::class,
        SearchQueryEntity::class
    ],
    version = 4,
    // A schemaLocation is configured in app/build.gradle.kts, so the history can actually be
    // exported. Asking for the location while exporting was off only produced a build warning.
    exportSchema = true
)
abstract class ZiziDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        /** Adds the new tables without touching favourites, playlists or saved FX. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `hidden` (`trackId` TEXT NOT NULL, `hiddenAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `play_stats` (`trackId` TEXT NOT NULL, `playCount` INTEGER NOT NULL, `lastPlayedAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
            }
        }

        /**
         * Prepares the switch to content-derived track ids (see [TrackId]).
         *
         * This migration deliberately does **not** rewrite any id. It cannot: the new key is a hash
         * of the file name and byte size, and SQLite has neither SHA-1 nor access to the file
         * system. What it does is preserve the information needed to rewrite them later - it stamps
         * every existing row with `legacyId = id`.
         *
         * The remap itself runs once, in Kotlin, during the first scan after the upgrade
         * ([MusicRepository.migrateLegacyIds]): the scanner reports both ids for every file it
         * finds, so old key and new key meet in the same object and the child tables can be
         * rewritten with a plain UPDATE. If the process dies mid-way, nothing is lost - the flag
         * that marks the remap as done is only set at the end, so the next launch retries.
         *
         * `sizeBytes` is added with an explicit `DEFAULT 0` to match what Room generates for
         * `@ColumnInfo(defaultValue = "0")`; without the annotation on one side or the DEFAULT on
         * the other, Room's schema identity check fails at open time and takes the app down on
         * launch for every upgrading user.
         */
        /**
         * Makes room for the network catalogue. Nothing is dropped, nothing is rewritten.
         *
         * Every DEFAULT here is mandatory, not decorative. Room compares the live schema against
         * the one it generated from the entities, and a column declared NOT NULL without a matching
         * default is a mismatch - which surfaces as a crash on launch for everyone upgrading from
         * 6.5.1 and for nobody testing a fresh install. That is the exact trap MIGRATION_2_3 below
         * was written to avoid, so it is worth repeating rather than assuming.
         *
         * Index names are Room's own convention (`index_<table>_<columns joined by _>`); a
         * hand-picked name is the same mismatch by another route.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `source` TEXT NOT NULL DEFAULT 'local'")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `provider` TEXT")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `savedAt` INTEGER")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `lastSeenAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tracks_source` ON `tracks` (`source`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_tracks_provider_remoteId` ON `tracks` (`provider`, `remoteId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `search_history` (`query` TEXT NOT NULL, `queriedAt` INTEGER NOT NULL, PRIMARY KEY(`query`))")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `sizeBytes` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `legacyId` TEXT")
                db.execSQL("UPDATE `tracks` SET `legacyId` = `id`")
            }
        }
    }
}
