package app.ziziplayer.data.remote

/**
 * A source of music that is not on this phone.
 *
 * Six functions, and every one of them may fail with [CatalogException] - which is the honest
 * contract for something that lives behind somebody else's HTTP endpoint. Implementations must be
 * stateless enough to be shared between the UI process and the playback service: they are called
 * from a ViewModel for search and from a Media3 loading thread for [resolveStream].
 */
interface RemoteCatalog {

    /** Short, stable, stored in the database as part of the track id. Never localised. */
    val id: String

    /** Shown in settings. */
    val label: String

    /** False when the provider cannot serve audio right now (e.g. no reachable node). */
    suspend fun isUsable(): Boolean

    suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage

    /** Autocomplete for the search field. Empty list is a valid answer, not an error. */
    suspend fun suggest(prefix: String): List<String>

    /** Shelves for the search hub. */
    suspend fun discover(): List<DiscoverShelf>

    /** Tracks inside an album, a playlist, or an artist's top list. */
    suspend fun collection(collection: RemoteCollection): List<RemoteTrack>

    /**
     * A playable URL for [remoteId], valid now.
     *
     * Called from the Media3 loading thread at the moment the stream is opened, never in advance.
     * That is the whole reason expiring links are not a problem in this app.
     */
    suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo
}

/**
 * Who is active, and who answers when the active one is broken.
 *
 * The fallback is not decoration. Innertube is a private API: when YouTube changes it, search stops
 * working until the parser is patched, and without a fallback the whole section is simply dead in
 * every installed copy of the app until then. Audius is official and needs no key, so it can always
 * take over.
 */
class CatalogRegistry(private val catalogs: List<RemoteCatalog>) {

    val all: List<RemoteCatalog> get() = catalogs

    fun byId(id: String?): RemoteCatalog? = catalogs.firstOrNull { it.id == id }

    /** The catalogue that owns a track id of the form `r:<provider>:<remoteId>`. */
    fun forTrackId(trackId: String): Pair<RemoteCatalog, String>? {
        if (!trackId.startsWith("r:")) return null
        val rest = trackId.removePrefix("r:")
        val separator = rest.indexOf(':')
        if (separator <= 0) return null
        val catalog = byId(rest.substring(0, separator)) ?: return null
        val remoteId = rest.substring(separator + 1)
        if (remoteId.isEmpty()) return null
        return catalog to remoteId
    }

    /**
     * Runs [block] on [preferred], and on the remaining catalogues if it fails with something other
     * than "this one item does not exist" - a missing track is not a reason to search another
     * provider for it, a broken parser is.
     */
    suspend fun <T> withFallback(preferred: String?, block: suspend (RemoteCatalog) -> T): T {
        val ordered = buildList {
            byId(preferred)?.let { add(it) }
            addAll(catalogs.filter { it.id != preferred })
        }
        if (ordered.isEmpty()) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "Каталоги не настроены")
        }
        var last: CatalogException? = null
        for (catalog in ordered) {
            try {
                return block(catalog)
            } catch (e: CatalogException) {
                if (e.reason == CatalogException.Reason.UNAVAILABLE ||
                    e.reason == CatalogException.Reason.OFFLINE ||
                    e.reason == CatalogException.Reason.METERED_BLOCKED
                ) throw e
                last = e
            }
        }
        throw last ?: CatalogException(CatalogException.Reason.PROTOCOL, "Каталоги недоступны")
    }
}
