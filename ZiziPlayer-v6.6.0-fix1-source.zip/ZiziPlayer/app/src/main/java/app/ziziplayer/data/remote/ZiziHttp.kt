package app.ziziplayer.data.remote

import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * The one HTTP client in the process.
 *
 * It is shared with Media3 (`OkHttpDataSource.Factory(ZiziHttp.client)`) on purpose: one connection
 * pool, one DNS cache, one TLS session cache. A second client would mean a second full TCP+TLS
 * handshake for the audio stream right after the search request just finished talking to the same
 * host - which is exactly the "first second of playback stutters" case.
 *
 * `followRedirects` stays on: Audius answers a stream request with a 302 to a storage node, and
 * Media3 must follow it without us pre-resolving anything.
 */
object ZiziHttp {

    /** A plain mobile browser UA. No fingerprinting games, no impersonating an app we are not. */
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val json = "application/json; charset=utf-8".toMediaType()

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            // Audio is a long lived read; a pool that closes idle connections too eagerly makes
            // every track change pay for a new handshake.
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    suspend fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody(json))
                .header("User-Agent", USER_AGENT)
                .header("Content-Type", "application/json")
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    suspend fun getJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .get()
                .header("User-Agent", USER_AGENT)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    /**
     * Turns transport reality into [CatalogException].
     *
     * Every branch here exists because the UI has to do something different: 429 must back off,
     * 403/404 on a single track must skip it, a DNS failure must not be reported as "провайдер
     * сломался", and a 200 that is not JSON means the shape changed and that is our bug.
     */
    private fun execute(call: Call, url: String): JSONObject {
        val response = try {
            call.execute()
        } catch (e: UnknownHostException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Нет соединения", e)
        } catch (e: SocketTimeoutException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Сервер не отвечает", e)
        } catch (e: IOException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Сеть недоступна", e)
        }
        response.use { r ->
            val code = r.code
            if (code == 429) throw CatalogException(CatalogException.Reason.RATE_LIMITED, "Слишком много запросов")
            if (code == 403 || code == 404 || code == 410) {
                throw CatalogException(CatalogException.Reason.UNAVAILABLE, "Недоступно ($code)")
            }
            if (!r.isSuccessful) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "HTTP $code от ${host(url)}")
            }
            val text = try {
                r.body?.string()
            } catch (e: IOException) {
                throw CatalogException(CatalogException.Reason.OFFLINE, "Обрыв ответа", e)
            }
            if (text.isNullOrBlank()) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "Пустой ответ от ${host(url)}")
            }
            return try {
                JSONObject(text)
            } catch (e: Throwable) {
                throw CatalogException(
                    CatalogException.Reason.PROTOCOL,
                    "Ответ ${host(url)} не JSON (${text.length} байт)",
                    e
                )
            }
        }
    }

    private fun host(url: String): String = runCatching { java.net.URL(url).host }.getOrDefault(url)
}
