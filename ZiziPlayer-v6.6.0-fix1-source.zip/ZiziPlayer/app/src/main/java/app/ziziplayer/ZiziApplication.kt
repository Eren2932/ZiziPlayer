package app.ziziplayer

import android.app.Application
import androidx.room.Room
import app.ziziplayer.data.*
import app.ziziplayer.data.remote.AudiusCatalog
import app.ziziplayer.data.remote.CatalogRegistry
import app.ziziplayer.data.remote.InnertubeCatalog
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class ZiziApplication : Application() {
    lateinit var database: ZiziDatabase; private set
    lateinit var repository: MusicRepository; private set
    lateinit var playerController: PlayerController; private set

    override fun onCreate() {
        super.onCreate()
        // No destructive fallback: a schema change must never wipe playlists, favourites and FX.
        database = Room.databaseBuilder(this, ZiziDatabase::class.java, "zizi.db")
            .addMigrations(
                ZiziDatabase.MIGRATION_1_2,
                ZiziDatabase.MIGRATION_2_3,
                ZiziDatabase.MIGRATION_3_4
            )
            .build()
        val settings = SettingsStore(this)
        repository = MusicRepository(
            this,
            database.musicDao(),
            settings,
            MusicScanner(this),
            PlaybackMemory(this)
        )
        // Innertube first because it is the only catalogue that actually has this music; Audius
        // second because it is the one that keeps working when YouTube changes something. Order in
        // this list is only the fallback order - the active provider comes from settings.
        RemoteRuntime.registry = CatalogRegistry(
            listOf(
                InnertubeCatalog(apiKey = BuildConfig.INNERTUBE_KEY),
                AudiusCatalog()
            )
        )

        // The Media3 loading thread cannot ask a ViewModel for settings, so the handful of values it
        // needs are mirrored into RemoteRuntime as they change. Application scope, because the
        // playback service outlives every screen.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            settings.settings
                .map { NetworkPrefs(it.wifiOnly, it.streamQuality, it.meteredQuality, it.streamCacheEnabled, it.streamCacheMb) }
                .distinctUntilChanged()
                .collect { prefs ->
                    RemoteRuntime.wifiOnly = prefs.wifiOnly
                    RemoteRuntime.quality = prefs.quality
                    RemoteRuntime.meteredQuality = prefs.meteredQuality
                    RemoteRuntime.cacheEnabled = prefs.cacheEnabled
                    RemoteRuntime.cacheBytes = prefs.cacheMb.toLong() * 1024 * 1024
                }
        }

        playerController=PlayerController(this)
    }

    /** Only so distinctUntilChanged has something small to compare. */
    private data class NetworkPrefs(
        val wifiOnly: Boolean,
        val quality: app.ziziplayer.data.remote.RemoteQuality,
        val meteredQuality: app.ziziplayer.data.remote.RemoteQuality,
        val cacheEnabled: Boolean,
        val cacheMb: Int
    )
}
