package app.ziziplayer.data.remote

import android.net.Uri
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.last
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject

/**
 * Deezer как ВИТРИНА, а не как источник звука (6.30.0).
 *
 * Никакого аудио отсюда не приходит и прийти не может: Deezer наружу поток не отдаёт. Он отдаёт то,
 * чего у нас никогда не было и что нельзя вытащить из поиска YouTube — чистое название, артиста,
 * альбом, обложку в высоком разрешении и **ISRC**, глобальный код записи. Звук по-прежнему тянет
 * [ZiziResolve], то есть весь тракт 1.8.2 со складом, хвостом и лестницей клиентов.
 *
 * Стык между витриной и звуком — один серверный вызов `/match/deezer`, который по id каталога
 * находит тот же трек на YouTube и возвращает videoId. Сопоставление считается ОДИН раз на трек:
 * сервер кладёт `isrc → videoId` в SQLite, и со второго раза это бесплатно.
 *
 * Почему сопоставление живёт на сервере, а не здесь: оно требует нескольких поисковых запросов и
 * сравнения длительностей, то есть секунд процессорного времени и трафика. На телефоне это батарея
 * и задержка старта у каждого пользователя; на сервере — один раз для всех.
 */
class DeezerCatalog : RemoteCatalog {

    override val id: String = "dz"

    /** Наружу источник не называется: для пользователя это просто музыка. */
    override val label: String = "Музыка"

    companion object {
        private const val PAGE = 25

        /**
         * Прогрев не принадлежит ни одному экрану, поэтому и область у него своя (6.37.0).
         *
         * Не [kotlinx.coroutines.GlobalScope]: у неё нет супервизора, и одно упавшее сопоставление
         * унесло бы соседние. Прогрев обязан быть молчаливым по определению — не удался, значит
         * трек отрезолвится вживую, ровно как в 6.36.0.
         */
        private val warmScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        /** Сколько треков просим сопоставить заранее. Столько же, сколько греет [ZiziResolve]. */
        private const val WARM_MAX = 3

        /**
         * Сопоставить треки витрины ЗАРАНЕЕ, пока человек читает список (6.37.0).
         *
         * Главная поломка 6.36.0 была не в том, что сопоставление медленное, а в том, что оно
         * происходило в самый неподходящий момент — на пути воспроизведения, после тапа, под
         * таймаутом загрузочного потока Media3. Здесь оно делается заранее и в стороне: сервер
         * отвечает мгновенно и работает в фоне, а к моменту тапа videoId уже лежит у него в базе.
         *
         * Функция ничего не ждёт и ничего не возвращает: это подсказка серверу, а не шаг.
         */
        fun warm(remoteIds: List<String>) {
            if (!ZiziResolve.configured) return
            val ids = remoteIds.filter { it.isNotBlank() }.distinct().take(WARM_MAX)
            if (ids.isEmpty()) return
            warmScope.launch {
                runCatching {
                    val raw = ZiziResolve.baseUrl.trim().trimEnd('/')
                    val root = if (raw.startsWith("http")) raw else "http://$raw"
                    ZiziHttp.getJson(
                        Uri.parse("$root/match/warm").buildUpon()
                            .appendQueryParameter("ids", ids.joinToString(","))
                            .build().toString(),
                        ZiziResolve.authHeaders()
                    )
                }
            }
        }
    }

    private fun base(): String {
        val raw = ZiziResolve.baseUrl.trim().trimEnd('/')
        if (raw.isEmpty()) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Адрес резолвера не задан")
        }
        return if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "http://$raw"
    }

    private fun url(path: String, params: Map<String, String>): String {
        val b = Uri.parse(base() + path).buildUpon()
        params.forEach { (k, v) -> b.appendQueryParameter(k, v) }
        return b.build().toString()
    }

    private suspend fun get(path: String, params: Map<String, String>): JSONObject =
        if (path.startsWith("/catalog/browse") || path.startsWith("/reco/")) BrowseHttp.get(url(path, params))
        else ZiziHttp.getJson(url(path, params), ZiziResolve.authHeaders())

    /** Поля уходят телом JSON, не строкой запроса: профиль вкуса не должен попадать в access-лог по URL. */
    private suspend fun post(path: String, fields: Map<String, String>): JSONObject {
        val body = JSONObject()
        fields.forEach { (key, value) -> body.put(key, value) }
        return BrowseHttp.post(url(path, emptyMap()), body)
    }

    override suspend fun isUsable(): Boolean = ZiziResolve.configured

    // ── разбор ───────────────────────────────────────────────────────────────────────────────────

    private fun JSONObject.toTrack(): RemoteTrack = RemoteTrack(
        provider = id,
        remoteId = optString("id"),
        title = optString("title"),
        artist = optString("artist"),
        album = optString("album").takeIf { it.isNotEmpty() && it != "null" } ?: "",
        durationMs = optInt("dur").toLong() * 1000L,
        artworkUrl = optString("art").takeIf { it.isNotEmpty() && it != "null" },
        explicit = optBoolean("explicit", false),
        catalogArtistId = optString("artist_id").takeIf { it.isNotBlank() && it != "null" },
        catalogAlbumId = optString("album_id").takeIf { it.isNotBlank() && it != "null" },
        isrc = optString("isrc").takeIf { it.isNotBlank() && it != "null" }
    )

    private fun tracksOf(response: JSONObject, field: String): List<RemoteTrack> {
        val arr = response.optJSONArray(field) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.toTrack()?.takeIf { it.remoteId.isNotEmpty() }
        }
    }

    // ── интерфейс каталога ───────────────────────────────────────────────────────────────────────

    private fun JSONObject.toGroup(kind: RemoteKind): RemoteCollection = RemoteCollection(
        provider = id,
        remoteId = kind.name.lowercase(java.util.Locale.ROOT) + ":" + optString("id"),
        kind = kind,
        title = optString("title"),
        subtitle = optString("subtitle"),
        artworkUrl = optString("art").takeIf { it.isNotBlank() && it != "null" }
    )

    private suspend fun browse(query: String, kind: RemoteKind, offset: Int, limit: Int): SearchPage {
        val response = get("/catalog/browse", mapOf(
            "q" to query, "kind" to kind.name.lowercase(java.util.Locale.ROOT),
            "offset" to offset.toString(), "limit" to limit.toString()
        ))
        val array = response.optJSONArray("items")
            ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Обнови каталог сервера до Browse 1")
        val items = (0 until array.length()).mapNotNull { index ->
            val row = array.optJSONObject(index) ?: return@mapNotNull null
            if (row.optString("id").isBlank()) return@mapNotNull null
            if (kind == RemoteKind.TRACK) RemoteItem.Song(row.toTrack())
            else RemoteItem.Group(row.toGroup(kind))
        }
        val next = if (response.isNull("next_offset")) null else response.optInt("next_offset", -1)
            .takeIf { it > offset }?.toString()
        return SearchPage(items, next)
    }

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        val offset = pageToken?.toIntOrNull() ?: 0
        // Typed tabs and continuation keep one request. Only the first ALL page has four
        // bounded metadata calls (the same count as before); never resolve audio here.
        if (kind != null || offset > 0) return browse(query, kind ?: RemoteKind.TRACK, offset, PAGE)
        return coroutineScope {
            val kinds = listOf(RemoteKind.TRACK, RemoteKind.ALBUM, RemoteKind.PLAYLIST, RemoteKind.ARTIST)
            val requests = kinds.map { type ->
                async {
                    try {
                        val page = if (type == RemoteKind.TRACK) browse(query, type, 0, PAGE)
                            else withTimeoutOrNull(1800L) { browse(query, type, 0, 3) }
                                ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Раздел поиска не успел ответить")
                        page to null
                    } catch (e: CancellationException) { throw e }
                    catch (e: CatalogException) { SearchPage.EMPTY to e }
                }
            }
            val answers = requests.map { it.await() }
            val items = SearchOverviewOrder.interleave<RemoteItem>(answers.map { it.first.items })
            // One failed category must not erase successful artist/album/playlist matches.
            if (items.isEmpty()) answers.mapNotNull { it.second }.firstOrNull()?.let { throw it }
            SearchPage(items, answers.first().first.nextToken)
        }
    }

    /** Подсказок у витрины нет, и это не ошибка: пустой список — валидный ответ по контракту. */
    override suspend fun suggest(prefix: String): List<String> = emptyList()

    override suspend fun preview(prefix: String): List<RemoteItem> = previewUpdates(prefix).last()

    /** Same two bounded calls, but the first useful lane is visible without awaiting its peer. */
    override fun previewUpdates(prefix: String): Flow<List<RemoteItem>> = progressivePreview(
        listOf(RemoteKind.TRACK to 6, RemoteKind.ALBUM to 2).map { (kind, limit) ->
            flow {
                val page = withTimeoutOrNull(1800L) { browse(prefix, kind, 0, limit) }
                    ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Каталог не успел ответить")
                emit(page.items)
            }
        }
    ) { lanes ->
        val tracks = lanes[0]
        val albums = lanes[1]
        (tracks.take(3) + albums + tracks.drop(3)).take(8)
    }

    private fun JSONObject.text(key: String): String =
        optString(key).takeIf { it.isNotBlank() && it != "null" } ?: ""

    /** Reco 1. Один запрос на всю персональную часть «Главной»; сервер строит граф и кэширует его. */
    override suspend fun recommendHome(profile: RecoProfile): RecoResult? {
        val query = profile.queryParams()
        if (query["s"].isNullOrEmpty() && query["r"].isNullOrEmpty()) return null
        val json = try {
            post("/reco/home", query)
        } catch (e: CatalogException) {
            // Сервер старше 6.81 не знает этот адрес: это не ошибка, это сигнал уйти на прежний путь.
            if (e.reason == CatalogException.Reason.PROTOCOL) return null
            throw e
        }
        return recoResult(json, keepRaw = true)
    }

    /** Reco 2. Снимок главной из RecoVault: тот же разбор, что у живого ответа; битый снимок — null. */
    override fun parseRecoHome(raw: String): RecoResult? = try {
        recoResult(JSONObject(raw), keepRaw = false).takeIf { it.shelves.isNotEmpty() }
    } catch (_: Exception) { null }

    private fun recoResult(json: JSONObject, keepRaw: Boolean): RecoResult {
        val echo = json.optJSONArray("seeds")
        val seeds = if (echo == null) emptyList() else (0 until echo.length()).mapNotNull { i ->
            val o = echo.optJSONObject(i) ?: return@mapNotNull null
            val seedId = o.text("id")
            if (seedId.isEmpty() || !seedId.all { it in '0'..'9' }) null else RecoSeedEcho(o.text("ref"), seedId, o.text("name"))
        }
        val generated = json.optLong("generated", 0L).coerceAtLeast(0L)
        val requestedSeeds = json.optJSONObject("seed_coverage")?.optInt("requested", -1)?.takeIf { it >= 0 }
        val raw = json.optJSONArray("shelves") ?: return RecoResult(emptyList(), json.optBoolean("complete", false), json.optBoolean("cold"),
            seeds = seeds, generated = generated, requestedSeeds = requestedSeeds)
        val shelves = (0 until raw.length()).mapNotNull { i -> raw.optJSONObject(i)?.let(::recoShelf) }
        val complete = json.optBoolean("complete", true)
        // Даже частичные непустые карточки полезны при следующем старте; пустые ответы не стирают кэш.
        return RecoResult(shelves, complete, json.optBoolean("cold", false),
            json.optLong("retry_ms", 0L).coerceAtLeast(0L), seeds,
            if (keepRaw && shelves.isNotEmpty()) json.toString() else "", generated, requestedSeeds)
    }

    /**
     * Reco 2. Артисты для окна знакомства: без [relatedTo] — популярные по жанрам, с ним — похожие на
     * выбранного. Для старого сервера похожие доступны через /catalog/similar; без него — явная ошибка.
     */
    override suspend fun onboardArtists(relatedTo: String?): List<RecoArtist> {
        if (relatedTo.isNullOrBlank()) {
            val json = try { get("/reco/onboard", emptyMap()) }
            catch (e: CatalogException) {
                if (e.reason == CatalogException.Reason.PROTOCOL) return emptyList()
                throw e
            }
            return onboardRows(json, "artists")
        }
        val anchor = DeezerArtistRef.parse("dz", relatedTo)?.takeUnless { it == "0" }
            ?: return emptyList()
        // Older deployments can serve catalogue search while /reco/onboard is absent,
        // cold or empty. The existing /catalog/similar route returns the SAME related graph,
        // not arbitrary charts presented as similar music. Both calls are cancellable.
        val primary = try {
            withTimeoutOrNull(3_500L) { get("/reco/onboard", mapOf("a" to anchor)) }
        } catch (e: CancellationException) { throw e }
        catch (e: CatalogException) {
            if (e.reason == CatalogException.Reason.RATE_LIMITED) throw e
            null
        }
        val artists = primary?.let { onboardRows(it, "artists") }.orEmpty().filterNot { it.id == anchor }
        if (artists.isNotEmpty()) return artists
        val fallback = withTimeoutOrNull(4_000L) {
            get("/catalog/similar", mapOf("id" to anchor, "limit" to "25"))
        } ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Похожие исполнители не ответили")
        return onboardRows(fallback, "items").filterNot { it.id == anchor }
    }

    private fun onboardRows(json: JSONObject, key: String): List<RecoArtist> {
        val items = json.optJSONArray(key) ?: return emptyList()
        return (0 until items.length()).mapNotNull { i ->
            val o = items.optJSONObject(i) ?: return@mapNotNull null
            val artistId = DeezerArtistRef.parse("dz", o.text("id"))?.takeUnless { it == "0" }
            val name = o.text("name")
            if (artistId == null || !app.ziziplayer.ui.HomeRecoPolicy.isRealArtist(name)) null
            else RecoArtist(artistId, name, o.text("art").ifEmpty { null }, o.text("genre"))
        }.distinctBy { it.id }
    }

    /** 6.82.0. Страница бесконечной ленты. Старый сервер (404) и пустой профиль дают null, а не ошибку. */
    override suspend fun recommendFeed(profile: RecoProfile, cursor: String?, pageSize: Int): RecoFeedPage? {
        val query = profile.feedParams(cursor, pageSize)
        if (query["s"].isNullOrEmpty() && query["r"].isNullOrEmpty()) return null
        val json = try {
            post("/reco/feed", query)
        } catch (e: CatalogException) {
            if (e.reason == CatalogException.Reason.PROTOCOL) return null
            throw e
        }
        val raw = json.optJSONArray("items")
        val tracks = if (raw == null) emptyList() else (0 until raw.length()).mapNotNull { i ->
            raw.optJSONObject(i)?.takeIf { it.text("id").isNotEmpty() }?.toTrack()?.takeIf { it.title.isNotEmpty() }
        }
        return RecoFeedPage(
            tracks = tracks,
            cursor = json.text("cursor").ifEmpty { null },
            more = json.optBoolean("more", false),
            complete = json.optBoolean("complete", true),
            cold = json.optBoolean("cold", false),
            restarted = json.optBoolean("restarted", false),
            retryMs = json.optLong("retry_ms", 0L).coerceAtLeast(0L)
        )
    }

    private fun recoShelf(o: JSONObject): RecoShelf? {
        val kind = when (o.optString("kind")) {
            "albums" -> RecoShelfKind.ALBUMS
            "tracks" -> RecoShelfKind.TRACKS
            "artists" -> RecoShelfKind.ARTISTS
            else -> return null
        }
        val items = o.optJSONArray("items") ?: return null
        val cards = (0 until items.length()).mapNotNull { i ->
            val row = items.optJSONObject(i) ?: return@mapNotNull null
            val rowId = row.text("id")
            if (rowId.isEmpty()) return@mapNotNull null
            when (kind) {
                RecoShelfKind.TRACKS -> row.toTrack().takeIf { it.title.isNotEmpty() }?.let { RecoCard(track = it) }
                RecoShelfKind.ALBUMS -> RecoCard(collection = RemoteCollection(
                    provider = id, remoteId = "album:$rowId", kind = RemoteKind.ALBUM,
                    title = row.text("title"),
                    subtitle = listOf(row.text("label"), row.text("subtitle")).filter { it.isNotEmpty() }.joinToString(" · "),
                    artworkUrl = row.text("art").ifEmpty { null }))
                RecoShelfKind.ARTISTS -> RecoCard(collection = RemoteCollection(
                    provider = id, remoteId = "artist:$rowId", kind = RemoteKind.ARTIST,
                    title = row.text("title"), subtitle = "", artworkUrl = row.text("art").ifEmpty { null }))
            }
        }
        if (cards.isEmpty()) return null
        val anchor = o.optJSONObject("anchor")
        return RecoShelf(o.text("id"), kind, o.text("title"), anchor?.text("name")?.ifEmpty { null },
            anchor?.text("art")?.ifEmpty { null }, cards)
    }

    override suspend fun discover(): List<DiscoverShelf> {
        val j = get("/catalog/chart", mapOf("limit" to "40"))
        val shelves = mutableListOf<DiscoverShelf>()

        tracksOf(j, "tracks").map { RemoteItem.Song(it) }
            .takeIf { it.isNotEmpty() }
            ?.let { shelves += DiscoverShelf("Сейчас слушают", it) }

        j.optJSONArray("playlists")?.let { arr ->
            val items = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = "playlist:" + o.optString("id"),
                        kind = RemoteKind.PLAYLIST,
                        title = o.optString("title"),
                        subtitle = o.optInt("n").takeIf { it > 0 }?.let { "$it треков" } ?: "",
                        artworkUrl = o.optString("art")
                    )
                )
            }
            if (items.isNotEmpty()) shelves += DiscoverShelf("Подборки", items)
        }

        j.optJSONArray("artists")?.let { arr ->
            val items = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = "artist:" + o.optString("id"),
                        kind = RemoteKind.ARTIST,
                        title = o.optString("name"),
                        artworkUrl = o.optString("art")
                    )
                )
            }
            if (items.isNotEmpty()) shelves += DiscoverShelf("Артисты", items)
        }
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> =
        collectionPage(collection).tracks

    override suspend fun collectionPage(collection: RemoteCollection, pageToken: String?): CollectionPage {
        val response = get("/catalog/browse/collection", mapOf(
            "id" to collection.remoteId.substringAfter(':', collection.remoteId),
            "kind" to collection.kind.name.lowercase(java.util.Locale.ROOT),
            "limit" to "50", "offset" to (pageToken ?: "0")
        ))
        val detail = response.optJSONObject("collection")?.toGroup(collection.kind) ?: collection
        val next = if (response.isNull("next_offset")) null else response.optInt("next_offset", -1)
            .takeIf { it > (pageToken?.toIntOrNull() ?: 0) }?.toString()
        return CollectionPage(detail, tracksOf(response, "items"), next,
            if (response.isNull("total")) null else response.optInt("total").takeIf { it >= 0 })
    }

    /**
     * Витрина → звук. Единственное место, где эти два мира встречаются.
     *
     * Сначала спрашиваем сервер, какому videoId соответствует запись, и только потом отдаём задачу
     * [ZiziResolve] — тому же коду, что играет треки сегодня. Ошибка сопоставления и ошибка
     * резолва различимы: первая приходит как UNAVAILABLE (этой записи на YouTube нет — пропускаем
     * трек), вторая как всё остальное (сломан тракт — есть смысл в запасном провайдере).
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val response = try {
            // 6.37.0. Именно этот запрос — и только он — идёт через долгий клиент.
            //
            // Холодное сопоставление это работа на стороне сервера, а не ожидание сети, и меряется
            // она секундами. Общие 20 секунд [ZiziHttp.client] обрывали её на середине: сервер
            // доводил поиск до конца и клал результат в кэш, а телефон уже показал ошибку и ушёл
            // скипать трек. Со стороны это выглядело как «плеер сам ставит на паузу и листает
            // дальше» — при полностью исправном сервере.
            ZiziHttp.getJsonSlow(url("/match/deezer", mapOf("id" to remoteId)), ZiziResolve.authHeaders())
        } catch (e: CatalogException) {
            if (e.reason == CatalogException.Reason.UNAVAILABLE) throw e
            throw CatalogException(e.reason, "Сопоставление не удалось: " + e.message, e)
        }
        val videoId = response.optString("vid")
        if (videoId.isEmpty()) {
            throw CatalogException(
                CatalogException.Reason.UNAVAILABLE,
                "Записи нет на источнике звука"
            )
        }
        return ZiziResolve.resolve(videoId, quality)
    }
}

/**
 * Единая выдача поддерживаемых каталогов.
 *
 * Пользователь не должен знать слова «Deezer» и «Innertube» и не должен выбирать между
 * ними в настройках — он ищет музыку. [MixCatalog] опрашивает вложенные каталоги параллельно и
 * отдаёт наверх ОДИН плоский список: сверху записи с обложкой и альбомом, ниже всё остальное.
 *
 * Ключ склейки — `<провайдер>:<remoteId>`, поэтому `r:mix:dz:3135556` остаётся стабильным и
 * пригодным для избранного и плейлистов ровно так же, как обычный id. Дубликаты схлопываются по
 * нормализованным артисту, названию и длительности с точностью до пяти секунд: один и тот же трек,
 * найденный и в витрине, и в сыром поиске, показывается один раз, и побеждает версия с обложкой.
 *
 * Ошибки каталогов обрабатываются отдельно, а не одним общим try.
 */
class MixCatalog(private val parts: List<RemoteCatalog>) : RemoteCatalog {

    private companion object {
        /** Сколько ждём отдельный источник в витрине и поиске, прежде чем выдать без него. */
        const val PART_TIMEOUT_MS = 4500L
        /** Подсказки печатаются вживую: тут терпение измеряется десятыми долями секунды. */
        const val SUGGEST_TIMEOUT_MS = 1200L
    }

    override val id: String = "mix"
    override val label: String = "Музыка"

    /**
     * 6.36.0. Части, которые опрашиваются СЕЙЧАС, — не то же самое, что все части.
     *
     * Без VPN запрос к Innertube не получает отказ, он висит; таймаут 6.31.0 сделал это терпимым
     * (4.5 с вместо 15), но 4.5 секунды на КАЖДЫЙ поиск ради источника, который всё равно ничего
     * не вернёт, — это плата ни за что. Пока флаг выключен, Innertube в опрос не входит, и телефон
     * не трогает Google ни одним пакетом.
     *
     * [parts] при этом остаётся полным: по нему работает [unwrap], а значит `r:mix:yt:...`,
     * сохранённый в избранном при включённом флаге, резолвится и после того, как флаг выключили.
     */
    private val active: List<RemoteCatalog>
        get() = if (RemoteRuntime.youtubeDirect) parts else parts.filter { it.id != InnertubeCatalog.ID }

    override suspend fun isUsable(): Boolean = active.any { runCatching { it.isUsable() }.getOrDefault(false) }

    override suspend fun prewarm() {
        active.forEach { runCatching { it.prewarm() } }
    }

    private fun wrap(part: RemoteCatalog, track: RemoteTrack) =
        track.copy(provider = id, remoteId = part.id + ":" + track.remoteId)

    private fun wrap(part: RemoteCatalog, collection: RemoteCollection) =
        collection.copy(provider = id, remoteId = part.id + ":" + collection.remoteId)

    private fun unwrap(remoteId: String): Pair<RemoteCatalog, String> {
        val part = parts.firstOrNull { remoteId.startsWith(it.id + ":") }
            ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник больше не поддерживается. Найди трек заново")
        return part to remoteId.removePrefix(part.id + ":")
    }

    private fun key(track: RemoteTrack): String {
        val norm = { s: String ->
            s.lowercase()
                .replace(Regex("\\((?:official|lyric|audio|video|hd|mv)[^)]*\\)"), " ")
                .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }
        return norm(track.artist) + "|" + norm(track.title) + "|" + (track.durationMs / 5000L)
    }

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage =
        coroutineScope {
            val tokens = if (pageToken == null) null else try { JSONObject(pageToken) }
                catch (e: Exception) { throw CatalogException(CatalogException.Reason.PROTOCOL, "Повтори поиск", e) }
            val pages = active.filter { tokens == null || tokens.has(it.id) }.map { part ->
                part to async {
                    try {
                        val page = withTimeoutOrNull(PART_TIMEOUT_MS) {
                            part.search(query, kind, tokens?.optString(part.id))
                        } ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Каталог не успел ответить")
                        page to null
                    } catch (e: CatalogException) { SearchPage.EMPTY to e }
                }
            }
            val merged = LinkedHashMap<String, RemoteItem>()
            val next = JSONObject()
            var failure: CatalogException? = null
            for ((part, deferred) in pages) {
                val (page, error) = deferred.await()
                if (error != null) failure = error
                page.nextToken?.let { next.put(part.id, it) }
                for (item in page.items) when (item) {
                    is RemoteItem.Song -> {
                        val wrapped = RemoteItem.Song(wrap(part, item.track))
                        val k = key(item.track)
                        val current = merged[k] as? RemoteItem.Song
                        if (current == null || (current.track.artworkUrl == null && item.track.artworkUrl != null)) {
                            merged[k] = wrapped
                        }
                    }
                    is RemoteItem.Group -> merged["g:" + part.id + ":" + item.collection.remoteId] =
                        RemoteItem.Group(wrap(part, item.collection))
                }
            }
            if (merged.isEmpty()) failure?.let { throw it }
            SearchPage(merged.values.toList(), next.toString().takeIf { next.length() > 0 })
        }

    override suspend fun preview(prefix: String): List<RemoteItem> = previewUpdates(prefix).last()

    override fun previewUpdates(prefix: String): Flow<List<RemoteItem>> = progressivePreview(
        active.map { part ->
            flow {
                withTimeoutOrNull(2100L) {
                    part.previewUpdates(prefix).collect { emit(it) }
                    true
                } ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Каталог не успел ответить")
            }.map { items -> items.map { item -> when (item) {
                is RemoteItem.Song -> RemoteItem.Song(wrap(part, item.track))
                is RemoteItem.Group -> RemoteItem.Group(wrap(part, item.collection))
            } } }
        }
    ) { lanes ->
        lanes.flatten().distinctBy { item -> when (item) {
            is RemoteItem.Song -> "t:" + key(item.track)
            is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
        } }.take(8)
    }

    override suspend fun suggest(prefix: String): List<String> = coroutineScope {
        active.map { part ->
            async {
                withTimeoutOrNull(SUGGEST_TIMEOUT_MS) {
                    try { part.suggest(prefix) }
                    catch (e: CancellationException) { throw e }
                    catch (_: Exception) { emptyList() }
                } ?: emptyList()
            }
        }
            .flatMap { it.await() }
            .distinct()
            .take(10)
    }

    override suspend fun discover(): List<DiscoverShelf> = coroutineScope {
        val results = active.map { part ->
            async {
                try {
                    val shelves = withTimeoutOrNull(PART_TIMEOUT_MS) { part.discover() }
                        ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Источник не успел ответить")
                    shelves.map { shelf ->
                        DiscoverShelf(shelf.title, shelf.items.map { item ->
                            when (item) {
                                is RemoteItem.Song -> RemoteItem.Song(wrap(part, item.track))
                                is RemoteItem.Group -> RemoteItem.Group(wrap(part, item.collection))
                            }
                        })
                    } to null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: CatalogException) {
                    emptyList<DiscoverShelf>() to e
                } catch (e: Exception) {
                    emptyList<DiscoverShelf>() to CatalogException(
                        CatalogException.Reason.PROTOCOL, "Не удалось прочитать подборки", e
                    )
                }
            }
        }.map { it.await() }
        val shelves = results.flatMap { it.first }.filter { it.items.isNotEmpty() }
        // Preserve partial success, but never label an all-provider outage as "no new music".
        if (shelves.isEmpty()) results.mapNotNull { it.second }.lastOrNull()?.let { throw it }
        shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> =
        collectionPage(collection).tracks

    override suspend fun collectionPage(collection: RemoteCollection, pageToken: String?): CollectionPage {
        val (part, inner) = unwrap(collection.remoteId)
        val page = part.collectionPage(collection.copy(provider = part.id, remoteId = inner), pageToken)
        return page.copy(collection = wrap(part, page.collection), tracks = page.tracks.map { wrap(part, it) })
    }

    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val (part, inner) = unwrap(remoteId)
        return part.resolveStream(inner, quality)
    }

    override suspend fun streamReport(remoteId: String, quality: RemoteQuality): List<String> {
        val (part, inner) = unwrap(remoteId)
        return part.streamReport(inner, quality)
    }
}
