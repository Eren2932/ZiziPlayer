package app.ziziplayer.ui

import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.RecentEntity
import app.ziziplayer.data.RecentKind
import app.ziziplayer.data.remote.*
import app.ziziplayer.playback.RemoteRuntime
import app.ziziplayer.ui.components.ArtworkCache
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

internal enum class HomeShelfLayout { COVERS, TRACKS, ARTISTS }
internal data class HomeFeedCard(
    val id: String, val title: String, val subtitle: String,
    val tracks: List<TrackEntity> = emptyList(), val remote: RemoteCollection? = null
) {
    val cover: TrackEntity? get() = tracks.firstOrNull()
}
internal data class HomeFeedShelf(val id: String, val title: String, val subtitle: String,
    val layout: HomeShelfLayout, val cards: List<HomeFeedCard>, val seed: TrackEntity? = null,
    /** Полка «Похоже на»: заголовок строится вокруг артиста-якоря, а не вокруг названия полки. */
    val anchorName: String? = null, val anchorArt: String? = null)
internal data class HomeFeedState(
    val shelves: List<HomeFeedShelf> = emptyList(), val wave: List<TrackEntity> = emptyList(),
    val loading: Boolean = false, val error: String? = null,
    val serverContent: Boolean = false, val fromSnapshot: Boolean = false,
    val folders: Set<String> = emptySet(), val hidden: Set<String> = emptySet(), val loadedAt: Long = 0L
)

internal data class HomeTasteDelivery(val key: String = "", val ready: Boolean = false,
    val partial: Boolean = false, val error: String? = null)
private data class ConfirmedHomeTaste(val key: String, val picks: List<RecoVault.Pick>)

/** No new HTTP client, audio resolver, listener or timer. One metadata request at a time.
 * A snapshot lives in memory or AES-GCM RecoVault, never in a clear-text personalized disk cache. */
internal class HomeRecommendations(private val app: ZiziApplication, private val scope: CoroutineScope,
    private val hidden: StateFlow<Set<String>?>) {
    private val _state = MutableStateFlow(HomeFeedState())
    val state = _state.asStateFlow()
    private var job: Job? = null
    private var retry: Job? = null
    private var attempt = 0
    /** Быстрые повторы прогревающегося сервера (2/4/8 с); отдельный счётчик от лестницы 15/45/135 с. */
    private var quickAttempt = 0
    private var tastePollAttempt = 0
    private var lastAttempt = 0L
    private var lastTasteRevision: Long? = null
    @Volatile private var generation = 0
    /**
     * 6.82.0. Последний ответ сервера, только в памяти. Каждое обновление собирает FeedBuilder заново,
     * и без этого полки Reco исчезали с экрана до ответа сервера: человек видел пустую главную при
     * каждом возвращении в приложение. Сбрасывается вместе со всем при смене приватности.
     */
    private var lastReco: RecoResult? = null
    private val vault = RecoVault.get(app)
    private val _needsOnboarding = MutableStateFlow(false)
    val needsOnboarding = _needsOnboarding.asStateFlow()
    private var confirmedTaste: ConfirmedHomeTaste? = null
    // Keep the exact confirmed seeds while optional enrichment finishes after entering Home.
    private var finishingTaste: ConfirmedHomeTaste? = null
    private val _tasteDelivery = MutableStateFlow(HomeTasteDelivery())
    val tasteDelivery = _tasteDelivery.asStateFlow()

    fun beginTaste(key: String, picks: List<RecoVault.Pick>, alreadyCompleted: Boolean = false) {
        if (key.isEmpty() || key != HomeTastePolicy.selectionKey(picks.map { it.id })) return
        confirmedTaste = ConfirmedHomeTaste(key, picks)
        finishingTaste = null; tastePollAttempt = 0
        _needsOnboarding.value = !alreadyCompleted
        _tasteDelivery.value = HomeTasteDelivery(key)
    }

    private fun failTaste(error: String) {
        val request = confirmedTaste ?: return
        _tasteDelivery.value = HomeTasteDelivery(request.key, partial = _tasteDelivery.value.partial, error = error)
    }
    private fun privacyKey(snapshot: HomeState): String {
        val data = org.json.JSONObject()
            .put("folders", org.json.JSONArray(snapshot.vaultFolders.sorted()))
            .put("hidden", org.json.JSONArray(snapshot.hiddenIds.sorted())).toString()
        return java.security.MessageDigest.getInstance("SHA-256").digest(data.toByteArray())
            .joinToString("") { "%02x".format(it.toInt() and 255) }
    }
    /** Бесконечная лента «Для тебя» под полками; живёт и переживает уход с главной. */
    val feed = HomeRecoFeed(app, scope)

    fun clear() {
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        _tasteDelivery.value = HomeTasteDelivery(confirmedTaste?.key.orEmpty())
        attempt = 0; quickAttempt = 0; tastePollAttempt = 0; finishingTaste = null; lastAttempt = 0L; lastTasteRevision = null; lastReco = null
        feed.clear()
        _state.value = HomeFeedState()
    }
    fun cancel() {
        val interrupted = job?.isActive == true
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        feed.cancel()
        if (interrupted || confirmedTaste != null) lastAttempt = 0L
        _state.value = _state.value.copy(loading = false, loadedAt = if (interrupted) 0L else _state.value.loadedAt)
    }
    init {
        // Installation-scoped, account-independent invitation. Old "Later" is not completion.
        scope.launch {
            val epoch = generation
            val saved = withContext(Dispatchers.IO) { vault.state() }
            if (epoch == generation) {
                _needsOnboarding.value = !saved.onboardingCompleted
                if (saved.pendingTasteKey.isNotEmpty()) beginTaste(saved.pendingTasteKey, saved.picks, saved.onboardingCompleted)
            }
        }
        // Не ждём tracks/playlists/listening Room-flow. Gate загружен синхронно, hidden — из DataStore.
        scope.launch {
            combine(hidden.filterNotNull(), app.repository.vault.state.map { it.folders }.distinctUntilChanged()) { ids, folders ->
                HomeState(loading = false, hiddenIds = ids, vaultFolders = folders)
            }.collectLatest { snapshot -> restoreSnapshot(snapshot, System.currentTimeMillis()) }
        }
    }

    private suspend fun restoreSnapshot(snapshot: HomeState, now: Long): Boolean {
        if (!safe(snapshot) || lastReco != null || _state.value.shelves.isNotEmpty()) return false
        val epoch = generation
        val raw = withContext(Dispatchers.IO) {
            // Separate atomic files can leave an older snapshot next to a newly confirmed taste
            // after process death. Do not restore that snapshot during pending setup.
            if (vault.state().pendingTasteKey.isNotEmpty()) null
            else vault.readHome(privacyKey(snapshot), now)
        } ?: return false
        val catalog = RemoteRuntime.registry.byId("dz") ?: return false
        val restored = withContext(Dispatchers.Default) { catalog.parseRecoHome(raw) } ?: return false
        val vaultState = withContext(Dispatchers.IO) { vault.state() }
        val built = withContext(Dispatchers.Default) {
            FeedBuilder(snapshot, emptySet(), emptyList(), now, vaultState).apply { reco = restored }.build()
        }
        if (epoch != generation || !safe(snapshot) || lastReco != null || _state.value.shelves.isNotEmpty()) return false
        if (!built.serverContent || built.shelves.isEmpty()) return false
        lastReco = restored
        _state.value = built.copy(folders = snapshot.vaultFolders, hidden = snapshot.hiddenIds,
            loading = false, loadedAt = 0L, fromSnapshot = true)
        prefetch(built)
        return true
    }

    private fun prefetch(built: HomeFeedState) {
        val cards = built.shelves.take(3).flatMap { shelf -> shelf.cards.take(3).map { shelf.layout to it } }.take(8)
        ArtworkCache.prefetchUrls(cards.mapNotNull { it.second.remote?.artworkUrl }, 480)
        for ((layout, card) in cards) card.cover?.let { track ->
            ArtworkCache.prefetchTracks(app, listOf(track), if (layout == HomeShelfLayout.TRACKS) 160 else 480)
        }
    }

    private fun safe(snapshot: HomeState) = snapshot.vaultFolders == app.repository.vault.state.value.folders &&
        snapshot.hiddenIds == hidden.value

    fun load(snapshot: HomeState, force: Boolean = false, gapMs: Long = HomeFeedRefreshPolicy.ATTEMPT_GAP_MS) {
        if (snapshot.loading || !safe(snapshot)) return
        if (_state.value.folders != snapshot.vaultFolders || _state.value.hidden != snapshot.hiddenIds) clear()
        val tasteChanged = lastTasteRevision != null && lastTasteRevision != snapshot.tasteRevision
        if (job?.isActive == true && !tasteChanged) return
        val now = System.currentTimeMillis()
        // Taste changes bypass the 30-minute TTL/15-second retry gap, not privacy.
        if (!tasteChanged && !HomeFeedRefreshPolicy.shouldLoad(now, _state.value.loadedAt, lastAttempt, force, gapMs)) return
        val tasteWaitMs = if (tasteChanged) HomeTasteRefreshPolicy.networkWaitMs(now, lastAttempt) else 0L
        if (tasteChanged) finishingTaste = null
        if (tasteChanged) job?.cancel() // old profile must not publish after a new signal
        retry?.cancel(); retry = null
        lastTasteRevision = snapshot.tasteRevision
        lastAttempt = now
        val epoch = ++generation
        _state.value = _state.value.copy(loading = true, error = null,
            folders = snapshot.vaultFolders, hidden = snapshot.hiddenIds)
        job = scope.launch {
            try {
                // Быстрый путь повторён здесь: если основной load опередил startup-корутину.
                restoreSnapshot(snapshot, now)
                val favorites = app.database.musicDao().observeFavoriteIds().first().toSet()
                val known = snapshot.tracks.associateBy { it.id }
                val sessions = app.database.listeningDao().recommendationSnapshot().filter { row ->
                    row.trackId in known && row.trackId !in snapshot.hiddenIds &&
                        (row.source != "local" || row.sourceFolder !in snapshot.vaultFolders)
                }
                val (vaultState, recents) = withContext(Dispatchers.IO) {
                    vault.state() to app.database.musicDao().observeRecents().first()
                }
                if (epoch == generation) _needsOnboarding.value = !vaultState.onboardingCompleted
                val tasteRequest = confirmedTaste?.takeIf { it.key == vaultState.pendingTasteKey &&
                    it.key == HomeTastePolicy.selectionKey(vaultState.picks.map { pick -> pick.id }) }
                if (confirmedTaste != null && tasteRequest == null) {
                    confirmedTaste = null; _tasteDelivery.value = HomeTasteDelivery()
                }
                val builder = withContext(Dispatchers.Default) { FeedBuilder(snapshot, favorites, sessions, now, vaultState, recents) }
                var deliveryFailure: String? = null
                val catalog = RemoteRuntime.registry.byId("dz")
                builder.reco = lastReco
                suspend fun publish(error: String? = null, liveReco: RecoResult? = null) {
                    val built = withContext(Dispatchers.Default) { builder.build() }
                    if (epoch == generation && safe(snapshot)) {
                        _state.value = built.copy(loading = true, error = error, folders = snapshot.vaultFolders,
                            hidden = snapshot.hiddenIds, loadedAt = now)
                        prefetch(built)
                        if (tasteRequest != null && liveReco != null && confirmedTaste?.key == tasteRequest.key) {
                            val musicShelfIds = liveReco.shelves.filter { it.kind != RecoShelfKind.ARTISTS }.mapTo(HashSet()) { it.id }
                            val playable = built.shelves.filter { it.id in musicShelfIds }.sumOf { shelf ->
                                shelf.cards.count { card -> card.tracks.any { it.isRemote } ||
                                    card.remote?.kind == RemoteKind.ALBUM || card.remote?.kind == RemoteKind.PLAYLIST }
                            }
                            val selected = tasteRequest.picks.map { it.id }
                            val ready = HomeTastePolicy.delivered(tasteRequest.key, HomeTastePolicy.selectionKey(liveReco.seeds.map { it.ref }), true,
                                liveReco.complete, playable, selected, liveReco.seeds.map { it.id })
                            if (ready) {
                                val committed = try {
                                    withContext(Dispatchers.IO) {
                                        val at = if (liveReco.generated > 0L && liveReco.generated <= now / 1000L) liveReco.generated * 1000L else now
                                        epoch == generation && safe(snapshot) && liveReco.raw.isNotEmpty() &&
                                            vault.writeHome(privacyKey(snapshot), liveReco.raw, at) &&
                                            vault.completeOnboarding(tasteRequest.key)
                                    }
                                } catch (e: CancellationException) { throw e }
                                catch (_: Exception) { false }
                                if (epoch == generation && safe(snapshot) && confirmedTaste?.key == tasteRequest.key) {
                                    if (committed) {
                                        finishingTaste = tasteRequest.takeUnless { liveReco.complete }
                                        confirmedTaste = null
                                        _needsOnboarding.value = false
                                        _tasteDelivery.value = HomeTasteDelivery(tasteRequest.key, ready = true, partial = !liveReco.complete)
                                    } else {
                                        deliveryFailure = "Музыка готова, но не удалось сохранить завершение настройки. Попробуй ещё раз."
                                        failTaste(deliveryFailure!!)
                                    }
                                }
                            } else if (liveReco.complete) {
                                deliveryFailure = if (playable == 0) "Каталог пока не нашёл доступных музыкальных подборок для этого выбора. Попробуй ещё раз или измени исполнителей."
                                    else "Сервер не подтвердил всех выбранных исполнителей. Повтори загрузку; серверу нужен актуальный модуль Reco2."
                                failTaste(deliveryFailure!!)
                            } else _tasteDelivery.value = HomeTasteDelivery(tasteRequest.key, partial = playable > 0)
                        }
                    }
                }
                publish()
                // Recompute local shelves before the short network coalescing window.
                if (tasteWaitMs > 0L) delay(tasteWaitMs)
                if (epoch != generation || !safe(snapshot)) return@launch
                lastAttempt = System.currentTimeMillis()
                // The server-backed metadata catalog respects the user's existing resolver config.
                // Do not silently enable direct YouTube / Google access for a Home visit.
                // RemoteCatalog reports unsupported Reco through a null recommendHome result,
                // not a capability flag. Handle that actual response below, after the request.
                var failure: String? = null
                var partial = false // сервер ответил не целиком: тихий быстрый повтор, без сообщения об ошибке
                var warming = false // сервер ответил ПУСТО и НЕПОЛНО: он прогревается, спросим снова через 2/4/8 с
                var retryHintMs = 0L
                var feedProfile: RecoProfile? = null
                var stopNetwork = false
                suspend fun request(block: suspend () -> Unit) {
                    if (stopNetwork) return
                    try {
                        // Бюджет считается только на сам запрос: ожидание плеера в него больше не входит.
                        val done = withTimeoutOrNull(HomeFeedRefreshPolicy.REQUEST_TIMEOUT_MS) { block(); true }
                        if (done == null) { failure = "Каталог не успел ответить. Локальные подборки доступны"; stopNetwork = true }
                    } catch (e: CancellationException) { throw e }
                    catch (e: Exception) {
                        failure = if (e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED)
                            "Каталог просит паузу, подборки вернутся сами" else "Каталог недоступен. Локальные подборки сохранены"
                        stopNetwork = true // no retry storm when the first request fails
                    }
                }
                val complete = withTimeoutOrNull(HomeFeedRefreshPolicy.TOTAL_TIMEOUT_MS) {
                    // 6.81.0 ждал здесь `!isLoadingAudio` без предела и перед КАЖДЫМ запросом: пока трек грузился
                    // или контроллер не подключился (по умолчанию isLoadingAudio = true), подборки стояли, а потом
                    // сдавались по тайм-ауту. Метаданные плееру не мешают: ждём один раз и недолго.
                    if (app.playerController.state.value.connected && app.playerController.state.value.isLoadingAudio) {
                        withTimeoutOrNull(HomeFeedRefreshPolicy.AUDIO_GRACE_MS) {
                            app.playerController.state.first { !it.connected || !it.isLoadingAudio }
                        }
                    }
                    if (catalog == null) failure = "Каталог не настроен"
                    else {
                        // Reco 1: одна просьба к серверу вместо семи с телефона. Сервер строит граф «кто звучит
                        // как твои артисты», кэширует его и отдаёт готовые полки. Старый сервер или пустой полный
                        // ответ — тихий откат на прежний путь ниже, без сообщения об ошибке.
                        val identities = withContext(Dispatchers.IO) {
                            builder.identityCandidates().chunked(400).flatMap { app.database.listeningDao().catalogIdentities(it) }
                                .filter { it.provider == "dz" && !it.artistId.isNullOrBlank() }
                                .associate { it.trackId to it.artistId!! }
                        }
                        val learnedProfile = withContext(Dispatchers.Default) { builder.recoProfile(identities) }
                        // During explicit setup every chosen ID is a seed, even with a huge old library.
                        // Do not let the previous taste outrank a newly confirmed artist out of the top 30.
                        val explicitTaste = tasteRequest ?: finishingTaste
                        val profile = explicitTaste?.let { request -> RecoProfile(
                            seeds = request.picks.map { RecoSeed(it.id, 1.0) }, known = learnedProfile?.known.orEmpty(),
                            negative = learnedProfile?.negative.orEmpty(), recent = emptyList(),
                            version = learnedProfile?.version.orEmpty()) } ?: learnedProfile
                        feedProfile = profile
                        if (profile != null) {
                            try {
                                var recoAnswered = false // null от recommendHome (старый сервер) != «не успел ответить»
                                val reco = withTimeoutOrNull(HomeFeedRefreshPolicy.RECO_TIMEOUT_MS) {
                                    catalog.recommendHome(profile).also { recoAnswered = true }
                                }
                                if (tasteRequest != null && reco != null && reco.requestedSeeds?.let { it < tasteRequest.picks.size } == true) {
                                    deliveryFailure = "Сервер принял только ${reco.requestedSeeds} из ${tasteRequest.picks.size} исполнителей. Нужен сервер с поддержкой s2. Выбор сохранён."
                                    failTaste(deliveryFailure!!)
                                    return@withTimeoutOrNull true
                                }
                                when (HomeRecoPolicy.outcome(recoAnswered, reco?.shelves?.size ?: 0, reco?.complete ?: true)) {
                                    HomeRecoPolicy.SHOW -> {
                                        if (epoch != generation || !safe(snapshot)) return@withTimeoutOrNull true
                                        // During setup the delivery proof must describe the response actually shown,
                                        // not previous cards with matching shelf IDs (e.g. the ubiquitous "station").
                                        val replace = reco != null && (tasteRequest != null || HomeSnapshotPolicy.shouldReplace(
                                            lastReco?.shelves?.sumOf { it.cards.size } ?: 0, lastReco?.complete ?: false,
                                            reco.shelves.sumOf { it.cards.size }, reco.complete))
                                        if (replace) lastReco = reco
                                        builder.reco = lastReco; publish(liveReco = reco)
                                        if (reco != null) withContext(Dispatchers.IO) {
                                            if (epoch == generation && safe(snapshot)) {
                                                val found = linkedMapOf<String, String>()
                                                for (seed in reco.seeds) {
                                                    val name = seed.ref.removePrefix("n:")
                                                    if (seed.ref.isNotBlank() && !seed.ref.all { it in '0'..'9' } && HomeRecoPolicy.isRealArtist(name)) {
                                                        found[HomeFeedPolicy.normalize(HomeRecoPolicy.cleanArtist(name))] = seed.id
                                                    }
                                                }
                                                try { vault.rememberIds(found) } catch (_: Exception) { /* кэш ID не мешает показать ответ */ }
                                                val at = if (reco.generated > 0L && reco.generated <= now / 1000L) reco.generated * 1000L else now
                                                if (replace && reco.raw.isNotEmpty() && tasteRequest == null)
                                                    vault.writeHome(privacyKey(snapshot), reco.raw, at)
                                            }
                                        }
                                        if (reco?.complete == true && explicitTaste != null &&
                                            HomeTastePolicy.selectionKey(reco.seeds.map { it.ref }) == explicitTaste.key) finishingTaste = null
                                        // Неполный ответ: сервер достраивает остаток в кэше, быстрый повтор его заберёт.
                                        partial = reco?.complete == false
                                        retryHintMs = reco?.retryMs ?: 0L
                                    }
                                    // 6.81.0 принимал пустой неполный ответ за успех, шёл на прежний путь и 30 минут молчал.
                                    HomeRecoPolicy.RETRY -> { warming = true; retryHintMs = reco?.retryMs ?: 0L }
                                    HomeRecoPolicy.TIMEOUT -> {
                                        failure = "Каталог не успел ответить. Локальные подборки доступны"; stopNetwork = true
                                    }
                                    // A chart is not successful personalized onboarding.
                                    else -> if (tasteRequest != null) {
                                        failure = if (reco == null)
                                            "Текущий каталог не поддерживает рекомендации Reco2. Проверь адрес и версию сервера. Выбор сохранён."
                                        else "Сервер пока не отдал персональные подборки. Выбор сохранён — повтори загрузку позже."
                                        stopNetwork = true
                                    }
                                }
                            } catch (e: CancellationException) { throw e }
                            catch (e: Exception) {
                                failure = if (e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED)
                                    "Каталог просит паузу, подборки вернутся сами" else "Каталог недоступен. Локальные подборки сохранены"
                                stopNetwork = true
                            }
                        }
                    }
                    if (catalog != null && builder.reco == null && tasteRequest == null) {
                        request { builder.discover = HubContent.normalize(catalog.discover()); publish() }
                        // Прогревающемуся серверу поиск по артистам только мешает достраивать граф: ждём повтор.
                        // Maximum seven logical calls per refresh: chart + 3 artists × (tracks + albums).
                        if (!warming) for (artist in builder.seeds.take(3)) {
                            request {
                                val songs = catalog.search(artist, RemoteKind.TRACK, null).items
                                    .filterIsInstance<RemoteItem.Song>().map { it.track }
                                    .filter { HomeFeedPolicy.normalize(HomeRecoPolicy.cleanArtist(it.artist)) == HomeFeedPolicy.normalize(artist) }
                                builder.artistTracks[artist] = songs.take(30); publish()
                            }
                            request {
                                builder.albums[artist] = catalog.search(artist, RemoteKind.ALBUM, null).items
                                    .filterIsInstance<RemoteItem.Group>().map { it.collection }
                                    .filter { it.kind == RemoteKind.ALBUM }.take(10)
                                publish()
                            }
                        }
                    }
                    true
                }
                if (complete == null) failure = "Обновление остановлено по тайм-ауту. Полученные подборки сохранены"
                if (failure == null) failure = deliveryFailure
                publish(failure)
                if (epoch == generation && failure != null) failTaste(failure!!)
                if (epoch == generation) {
                    if (failure != null) {
                        _state.value = _state.value.copy(loadedAt = 0L)
                        if (deliveryFailure == null) scheduleRetry(snapshot, epoch)
                    } else if (warming || partial) {
                        _state.value = _state.value.copy(loadedAt = 0L)
                        scheduleRetry(snapshot, epoch, retryHintMs)
                    } else {
                        attempt = 0; quickAttempt = 0
                    }
                    // Лента стартует, когда сервер прогрет: на холодном кэше она лишь отняла бы у главной запросы к Deezer.
                    val seedProfile = feedProfile
                    if (failure == null && !warming && !partial && seedProfile != null) feed.start(seedProfile, snapshot, builder::recoBlocked)
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                if (epoch == generation) {
                    _state.value = _state.value.copy(error = "Подборки соберутся сами, как только появится связь")
                    failTaste("Не удалось получить рекомендации. Выбор сохранён; проверь соединение и повтори.")
                    scheduleRetry(snapshot, epoch)
                }
            } finally {
                if (epoch == generation) _state.value = _state.value.copy(loading = false)
            }
        }
    }

    /**
     * Неудача не требует действий пользователя: 15 c, 45 c, 135 c — и тишина.
     * Это не таймер обновления и не фоновая служба: корутина живёт в скоупе экрана,
     * уходит вместе с ним (cancel/clear) и имеет жёсткий бюджет попыток.
     *
     * 6.82.0. [quickHintMs] >= 0 — повтор прогревающегося сервера: 2, 4, 8 секунд (не быстрее подсказки
     * `retry_ms`), а когда они кончились — обычная лестница. Сообщения об ошибке при этом нет.
     */
    private fun scheduleRetry(snapshot: HomeState, epoch: Int, quickHintMs: Long = -1L) {
        if (epoch != generation) return
        val setupPoll = quickHintMs >= 0L && confirmedTaste != null && tastePollAttempt < HomeTastePolicy.MAX_BUILD_POLLS
        val quick = quickHintMs >= 0L && HomeFeedRefreshPolicy.canQuickRetry(quickAttempt + 1)
        val wait: Long
        if (setupPoll) {
            tastePollAttempt += 1
            wait = HomeTastePolicy.buildPollDelayMs(quickHintMs)
        } else if (quick) {
            quickAttempt += 1
            wait = HomeFeedRefreshPolicy.quickRetryDelayMs(quickAttempt, quickHintMs)
        } else {
            if (!HomeFeedRefreshPolicy.canRetry(attempt + 1)) return
            attempt += 1
            wait = HomeFeedRefreshPolicy.retryDelayMs(attempt)
        }
        retry?.cancel()
        retry = scope.launch {
            // Запас к паузе: минимальный интервал попыток считается по стенным часам.
            delay(wait + 250L)
            if (epoch == generation) load(snapshot, force = true,
                gapMs = if (setupPoll || quick) HomeFeedRefreshPolicy.QUICK_GAP_MS else HomeFeedRefreshPolicy.ATTEMPT_GAP_MS)
        }
    }
}

/** All scoring and shelf assembly happens on Default, not on a playback tick. */
private class FeedBuilder(private val source: HomeState, favorites: Set<String>,
    sessions: List<ListeningSessionEntity>, private val now: Long,
    private val vaultState: RecoVault.State = RecoVault.State(),
    private val recents: List<RecentEntity> = emptyList()) {
    private val qualifiedPlays = sessions.count { it.qualified }
    private val known = source.tracks.associateBy { it.id }
    private val evidence = sessions.groupBy { it.trackId }.mapValues { (_, rows) -> rows.sumOf {
        HomeFeedPolicy.sessionWeight(it.qualified, it.completed, it.outcome == "skipped" && it.listenedMs < 10_000L,
            (now - it.startedAt).coerceAtLeast(0L) / 86_400_000.0)
    } }
    private val scores = source.tracks.associate { it.id to HomeFeedPolicy.score(it.id in favorites, evidence[it.id] ?: 0.0) }
    private val artistScores = source.tracks.groupBy { HomeFeedPolicy.normalize(it.artist) }
        .mapValues { (_, tracks) -> tracks.sumOf { HomeRecoPolicy.trackAffinity(scores[it.id] ?: 0.0,
            it.id in source.playlistTrackIds, !it.isRemote || it.savedAt != null) } }
    // 6.83.0: «Неизвестный артист», «<unknown>», каналы-перезаливщики и «… - Topic» не становятся миксом.
    val seeds = source.tracks.filter { HomeRecoPolicy.isRealArtist(it.artist) && HomeRecoPolicy.trackAffinity(scores[it.id] ?: 0.0,
            it.id in source.playlistTrackIds, !it.isRemote || it.savedAt != null) > 0.0 }
        .distinctBy { HomeFeedPolicy.normalize(it.artist) }
        .sortedWith(compareByDescending<TrackEntity> { artistScores[HomeFeedPolicy.normalize(it.artist)] ?: 0.0 }.thenBy { it.id })
        .map { HomeRecoPolicy.cleanArtist(it.artist) }.distinctBy { HomeFeedPolicy.normalize(it) }.take(3)
    var discover: List<DiscoverShelf> = emptyList()
    /** Reco 1: готовые полки с сервера. null — сервер недоступен или старше 6.81, работает прежний путь. */
    var reco: RecoResult? = null
    val artistTracks = linkedMapOf<String, List<RemoteTrack>>()
    val albums = linkedMapOf<String, List<RemoteCollection>>()
    private val recentIds = sessions.sortedByDescending { it.startedAt }.map { it.trackId }.distinct().take(12)

    /** Remote-треки с ненулевой оценкой: только для них id артиста Deezer ищется в track_catalog. */
    fun identityCandidates(): List<String> = source.tracks.asSequence()
        .filter { it.isRemote && ((scores[it.id] ?: 0.0) != 0.0 || inLibrary(it) || it.id in source.playlistTrackIds) }
        .sortedByDescending { kotlin.math.abs(scores[it.id] ?: 0.0) }
        .map { it.id }.take(400).toList()

    private class Credit(val name: String) {
        var score = 0.0; var tracks = 0; var id: String? = null
        /** Лучший трек артиста по сродству: из него подсказка «имя~название» для точной привязки. */
        var hintTitle: String? = null; var hintScore = 0.0
    }

    /** Медиатека = «это моё»: локальные файлы и сохранённые треки каталога. Проигранное мимоходом — не в счёт. */
    private fun inLibrary(t: TrackEntity) = !t.isRemote || t.savedAt != null

    // ---- 6.83.0: что человеку не нравится и что у него уже есть
    private val dislikedTrackIds = vaultState.dislikedTracks.toHashSet()
    private val dislikedArtistKeys = vaultState.dislikedArtists.mapTo(HashSet()) { HomeFeedPolicy.normalize(it.name) }
    private val dislikedArtistIds = vaultState.dislikedArtists.mapNotNullTo(HashSet()) { it.id }
    val librarySongKeys: Set<String> = source.tracks.asSequence().filter(::inLibrary)
        .map { HomeRecoPolicy.songKey(it.artist, it.title) }.toHashSet()
    private fun artistDisliked(credited: String): Boolean =
        HomeRecoPolicy.splitArtists(credited).any { HomeFeedPolicy.normalize(HomeRecoPolicy.cleanArtist(it)) in dislikedArtistKeys }
    /** Скрыто правилом «не нравится» (трек или исполнитель). */
    fun disliked(t: TrackEntity): Boolean = t.id in dislikedTrackIds || canonical(t) in dislikedTrackIds ||
        ("song:" + HomeRecoPolicy.songKey(t.artist, t.title)) in dislikedTrackIds || artistDisliked(t.artist)
    /** Для рекомендаций: ещё и то, что уже лежит в медиатеке, — его человек и так знает. */
    fun recoBlocked(t: TrackEntity): Boolean = disliked(t) || HomeRecoPolicy.songKey(t.artist, t.title) in librarySongKeys
    /** Сколько сидов дал собственный вкус (без окна знакомства): 0 — человек новый. */
    var ownSeeds = 0
        private set

    /**
     * Reco 2. Профиль вкуса для сервера — «паутина» из всех сигналов, а не только из избранного:
     *
     *   A(артист) = Σ_треки (4·избранное + прослушивания·2^(−Δ/14) − ранние пропуски   [как раньше]
     *                        + 1.5·в плейлисте + 1·в медиатеке)                       [trackAffinity]
     *             + Σ_поиск 1.5·2^(−Δ/7)                                             [searchCredit]
     *             + 6·выбран при знакомстве·max(0, 1 − n/50)                         [onboardingCredit]
     *   вес сида  = ln(1+A)/ln(1+A_max)                                              [logWeight]
     *
     * Логарифм — убывающая отдача: артист с 200 лайками больше не задавливает остальных 29 сидов.
     * Соисполнители получают 60%. Мусор («Неизвестный артист», каналы, «- Topic») вычищается до счёта.
     * Точный id Deezer: из track_catalog, из окна знакомства, из истории поиска, из прошлых ответов сервера.
     * Название трека уходит только подсказкой для ещё не привязанных артистов (поле h).
     */
    fun recoProfile(identities: Map<String, String>): RecoProfile? {
        val credits = LinkedHashMap<String, Credit>()
        var slowedMass = 0.0; var spedMass = 0.0; var totalMass = 0.0
        fun credit(rawName: String): Credit? {
            val name = HomeRecoPolicy.cleanArtist(rawName)
            val key = HomeFeedPolicy.normalize(name)
            if (key.isEmpty()) return null
            return credits.getOrPut(key) { Credit(RecoQuery.safeName(name)) }
        }
        for (t in source.tracks) {
            if (disliked(t)) continue
            val parts = HomeRecoPolicy.splitArtists(t.artist)
            if (parts.isEmpty()) continue
            val score = scores[t.id] ?: 0.0
            val affinity = HomeRecoPolicy.trackAffinity(score, t.id in source.playlistTrackIds, inLibrary(t))
            parts.forEachIndexed { index, part ->
                val c = credit(part) ?: return@forEachIndexed
                c.tracks += 1
                c.score += if (index == 0) affinity else affinity * HomeRecoPolicy.SECONDARY_SHARE
                // id Deezer принадлежит первому из перечисленных артистов: так его присылает каталог.
                if (index == 0 && affinity > 0.0 && c.id == null) c.id = identities[t.id]
                if (index == 0 && affinity > c.hintScore && t.title.isNotBlank()) { c.hintTitle = t.title; c.hintScore = affinity }
            }
            if (score > 0.0) {
                totalMass += score
                if (HomeRecoPolicy.slowed(t.title)) slowedMass += score
                if (HomeRecoPolicy.spedUp(t.title)) spedMass += score
            }
        }
        // Поиск и открытые артисты: что человек ищет сейчас, даже если ещё ничего не сохранил.
        for (r in recents) {
            if (r.trackId != null && r.trackId !in known) continue
            if (r.kind == RecentKind.ALBUM || r.kind == RecentKind.PLAYLIST) continue
            val raw = when (r.kind) {
                RecentKind.ARTIST -> r.title
                RecentKind.TRACK, RecentKind.ALBUM -> HomeRecoPolicy.splitArtists(r.subtitle).firstOrNull() ?: ""
                else -> ""
            }
            val c = credit(raw) ?: continue
            c.score += HomeRecoPolicy.searchCredit((now - r.openedAt).coerceAtLeast(0L) / 86_400_000.0)
            val rid = r.remoteId
            if (r.kind == RecentKind.ARTIST) DeezerArtistRef.parse(r.provider, rid)?.let { c.id = it }
        }
        ownSeeds = credits.entries.count { (key, c) -> c.score > 0.0 && (c.id != null || key in vaultState.ids) }
        // Окно знакомства: сильный старт, который гаснет по мере того, как копится собственная история.
        val pickCredit = maxOf(HomeRecoPolicy.onboardingCredit(qualifiedPlays), HomeRecoPolicy.ONBOARDING_FLOOR)
        for (pick in vaultState.picks) {
            val c = credit(pick.name) ?: continue
            c.score += pickCredit
            c.id = pick.id
        }
        // Прошлые ответы сервера: «имя -> id», чтобы тёзки больше не путались.
        for ((key, c) in credits) if (c.id == null) vaultState.ids[key]?.let { c.id = it }
        fun dislikedCredit(key: String, c: Credit) = key in dislikedArtistKeys || (c.id != null && c.id in dislikedArtistIds)
        val ranked = credits.entries.filter { (key, c) -> c.score > 0.0 && c.name.isNotEmpty() && !dislikedCredit(key, c) }
            .sortedWith(compareByDescending<Map.Entry<String, Credit>> { it.value.score }.thenBy { it.value.name })
        val seeds = ranked.take(HomeRecoPolicy.MAX_SEEDS).map { it.value }
        val seedKeys = ranked.take(HomeRecoPolicy.MAX_SEEDS).mapTo(HashSet()) { it.key }
        val top = seeds.firstOrNull()?.score ?: 0.0
        fun ref(c: Credit) = c.id ?: RecoQuery.name(c.name)
        val knownNames = credits.entries.filter { (key, c) -> c.name.isNotEmpty() && c.score > HomeRecoPolicy.NEGATIVE_SCORE &&
                key !in seedKeys && !dislikedCredit(key, c) }
            .sortedWith(compareByDescending<Map.Entry<String, Credit>> { it.value.score }.thenByDescending { it.value.tracks }.thenBy { it.value.name })
            .take(HomeRecoPolicy.MAX_KNOWN).map { ref(it.value) }
        // «Не нравится» — первыми: это явный сигнал, пропуски — косвенный.
        val explicitNegative = vaultState.dislikedArtists.asReversed().map { it.id ?: RecoQuery.name(it.name) }
        val negativeNames = (explicitNegative + credits.values.filter { it.name.isNotEmpty() && it.score <= HomeRecoPolicy.NEGATIVE_SCORE }
            .sortedBy { it.score }.map(::ref)).distinct().take(HomeRecoPolicy.MAX_NEGATIVE)
        val recent = recentIds.mapNotNull(this.known::get).mapNotNull { t ->
            HomeRecoPolicy.splitArtists(t.artist).firstOrNull()?.let { HomeRecoPolicy.cleanArtist(it) }?.takeIf { it.isNotEmpty() }?.let { name ->
                identities[t.id] ?: vaultState.ids[HomeFeedPolicy.normalize(name)] ?: RecoQuery.name(name)
            }
        }.distinct().take(HomeRecoPolicy.MAX_RECENT)
        if (seeds.isEmpty() && recent.isEmpty()) return null
        val hints = seeds.filter { vaultState.allowTrackHints && it.id == null && !it.hintTitle.isNullOrBlank() }
            .map { RecoQuery.hint(it.name, it.hintTitle) }.filter { it.isNotEmpty() }.take(HomeRecoPolicy.MAX_HINTS)
        return RecoProfile(
            seeds.map { RecoSeed(ref(it), HomeRecoPolicy.logWeight(it.score, top)) },
            knownNames, negativeNames, recent, HomeRecoPolicy.versionPreference(slowedMass, spedMass, totalMass), hints)
    }
    private val favoriteTracks = source.tracks.filter { it.id in favorites }
    private fun canonical(t: TrackEntity): String = if (t.provider == "mix") "r:${t.remoteId}" else t.id
    private val knownCanonical = known.values.mapTo(HashSet(), ::canonical)
    private val hiddenCanonical = source.hiddenIds.mapTo(HashSet()) { if (it.startsWith("r:mix:")) "r:" + it.removePrefix("r:mix:") else it }
    private fun unique(tracks: List<TrackEntity>): List<TrackEntity> {
        val result = ArrayList<TrackEntity>(); val ids = HashSet<String>()
        val metadata = HashMap<String, MutableList<Long>>()
        for (t in tracks.take(600)) {
            if (t.title.isBlank() || t.id in source.hiddenIds || canonical(t) in hiddenCanonical ||
                (t.isRemote && !CatalogPolicy.supports(t.provider, t.remoteId))) continue
            val key = HomeFeedPolicy.normalize(t.artist) + "|" + HomeFeedPolicy.normalize(t.title)
            val durations = metadata.getOrPut(key) { mutableListOf() }
            if (!ids.add(canonical(t)) || (t.durationMs > 0L && durations.any { it > 0L && kotlin.math.abs(it - t.durationMs) <= 2000L })) continue
            durations += t.durationMs; result += t
            if (result.size >= 300) break
        }
        return result
    }
    private fun rank(tracks: List<TrackEntity>, limit: Int, novel: Boolean = false): List<TrackEntity> {
        fun value(t: TrackEntity): Double {
            val affinity = artistScores[HomeFeedPolicy.normalize(t.artist)]?.coerceIn(-4.0, 8.0) ?: 0.0
            return (scores[t.id] ?: 0.0) + affinity * 0.35 +
                (if (novel && canonical(t) !in knownCanonical) 3.0 else 0.0) -
                (if (t.id in recentIds) 2.0 else 0.0) + HomeFeedPolicy.dailyTie(t.id, now / 86_400_000L)
        }
        // Bound after scoring, not after alphabetical database order: a large library
        // must not permanently starve favourites whose titles start near the end.
        val values = tracks.associate { it.id to value(it) }
        val list = unique(tracks.filterNot(::disliked).sortedWith(compareByDescending<TrackEntity> { values[it.id] ?: 0.0 }.thenBy { it.id }))
        val byId = list.associateBy { it.id }
        return HomeFeedPolicy.rank(list.map { HomeFeedPolicy.Candidate(it.id, it.artist, values[it.id] ?: 0.0) }, limit)
            .mapNotNull(byId::get)
    }
    fun build(): HomeFeedState {
        val out = mutableListOf<HomeFeedShelf>()
        val exposures = HashMap<String, Int>()
        val shownGroups = HashSet<String>()
        val remote = unique(artistTracks.values.flatten().map { it.toEntity(now) }.filterNot(::disliked))
        val chart = unique(discover.flatMap { it.items }.filterIsInstance<RemoteItem.Song>().map { it.track.toEntity(now) }.filterNot(::disliked))
        val catalog = discover.flatMap { it.items }.filterIsInstance<RemoteItem.Group>().map { it.collection }
            .filter { CatalogPolicy.supports(it.provider, it.remoteId) }.distinctBy { "${it.provider}:${it.remoteId}" }
        fun songs(id: String, title: String, detail: String, tracks: List<TrackEntity>, layout: HomeShelfLayout = HomeShelfLayout.COVERS, seed: TrackEntity? = null) {
            val visible = unique(tracks).filter { (exposures[canonical(it)] ?: 0) < 2 }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                val key = canonical(it); exposures[key] = (exposures[key] ?: 0) + 1
                HomeFeedCard(it.id, it.title, it.artist, listOf(it))
            }, seed)
        }
        fun groups(id: String, title: String, detail: String, groups: List<RemoteCollection>, layout: HomeShelfLayout = HomeShelfLayout.COVERS,
            anchorName: String? = null, anchorArt: String? = null) {
            val visible = groups.filter { shownGroups.add("${it.provider}:${it.remoteId}") }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                HomeFeedCard("${it.provider}:${it.remoteId}", it.title, it.subtitle, remote = it)
            }, anchorName = anchorName, anchorArt = anchorArt)
        }
        // Reco 1. Порядок как у эталона: «Недавние» -> «Похоже на X» -> станция -> новое -> артисты -> «Начни с…».
        // Сначала треки, затем альбомы, затем артисты. Сортировка устойчивая: внутри вида порядок сервера цел.
        val recoShelves = reco?.shelves.orEmpty().sortedBy { HomeRecoPolicy.shelfRank(it.kind.name) }
        val recoMode = recoShelves.isNotEmpty()
        if (recoMode) {
            songs("continue-listening", "Слушаем дальше?", "Недавние прослушивания", recentIds.mapNotNull(known::get))
            for (shelf in recoShelves) {
                val collections = shelf.cards.mapNotNull { it.collection }
                    .filter { CatalogPolicy.supports(it.provider, it.remoteId) }
                    .filterNot { artistDisliked(if (shelf.kind == RecoShelfKind.ARTISTS) it.title else it.subtitle) }
                when (shelf.kind) {
                    RecoShelfKind.TRACKS -> songs(shelf.id, shelf.title, "По твоим прослушиваниям и избранному",
                        shelf.cards.mapNotNull { it.track?.toEntity(now) }.filterNot(::recoBlocked), HomeShelfLayout.TRACKS)
                    RecoShelfKind.ALBUMS -> groups(shelf.id, shelf.title, "", collections, HomeShelfLayout.COVERS,
                        shelf.anchorName, shelf.anchorArt)
                    RecoShelfKind.ARTISTS -> groups(shelf.id, shelf.title, "На основе того, что ты слушаешь",
                        collections, HomeShelfLayout.ARTISTS)
                }
            }
        }
        val wave = rank(source.tracks.filter { it.id in source.availableOfflineIds }, 50)
        val mixes = seeds.mapNotNull { artist ->
            val tracks = rank(source.tracks.filter { HomeFeedPolicy.normalize(HomeRecoPolicy.cleanArtist(it.artist)) == HomeFeedPolicy.normalize(artist) } +
                artistTracks[artist].orEmpty().map { it.toEntity(now) }, 40)
            if (tracks.isEmpty()) null else HomeFeedCard("mix:${HomeFeedPolicy.normalize(artist)}", "$artist: микс",
                "${tracks.size} треков · из твоей музыки", tracks)
        }.toMutableList()
        if (favoriteTracks.isNotEmpty()) mixes += HomeFeedCard("favorites-mix", "Любимое вперемешку", "Из твоего избранного", rank(favoriteTracks, 40))
        mixes.forEach { it.cover?.let { track -> exposures[canonical(track)] = 1 } }
        if (mixes.isNotEmpty()) out += HomeFeedShelf("mixes", "Миксы из твоей музыки", "Локальные подборки · не новые рекомендации", HomeShelfLayout.COVERS, mixes)
        songs("today", "Послушай сегодня", if (remote.isEmpty()) "Из твоей музыки" else "Знакомые исполнители и твоя музыка",
            rank(remote + source.tracks, 12, novel = true))
        groups("catalog-playlists", "Подборки каталога", "Редакционные подборки · не персональный рейтинг", catalog.filter { it.kind == RemoteKind.PLAYLIST })
        if (!recoMode) songs("continue-listening", "Слушаем дальше?", "Недавние прослушивания", recentIds.mapNotNull(known::get))
        for ((artist, tracks) in artistTracks) songs("artist:$artist", "Ещё от $artist", "Найдено в каталоге по исполнителю",
            rank(tracks.map { it.toEntity(now) }.filterNot(::disliked), 12, novel = true), seed = source.tracks.firstOrNull { HomeFeedPolicy.normalize(HomeRecoPolicy.cleanArtist(it.artist)) == HomeFeedPolicy.normalize(artist) })
        songs("new-to-you", "Незнакомое у знакомых", "Треки исполнителей из твоих предпочтений, которых нет в медиатеке",
            rank(remote.filter { canonical(it) !in knownCanonical }, 12, novel = true))
        for ((artist, albumGroups) in albums) groups("albums:$artist", "Альбомы: $artist", "Результаты каталога по запросу исполнителя", albumGroups)
        songs("chart", "Сейчас слушают", "Общий чарт каталога · не твой персональный топ", chart.take(12), HomeShelfLayout.TRACKS)
        val chosenArtists = vaultState.picks.filterNot { HomeFeedPolicy.normalize(it.name) in dislikedArtistKeys || it.id in dislikedArtistIds }
            .map { RemoteCollection(provider = "dz", remoteId = "artist:${it.id}", kind = RemoteKind.ARTIST,
                title = it.name, subtitle = "Выбрано тобой", artworkUrl = it.art) }
        groups("selected-artists", "Выбранные тобой исполнители", "Настройка музыкального вкуса", chosenArtists, HomeShelfLayout.ARTISTS)
        groups("catalog-artists", "Исполнители в каталоге", "Популярные сейчас", catalog.filter { it.kind == RemoteKind.ARTIST }, HomeShelfLayout.ARTISTS)
        songs("offline", "Всегда с тобой", "Доступно без интернета", wave.take(12))
        return HomeFeedState(out.take(18), wave, serverContent = recoMode)
    }
}
