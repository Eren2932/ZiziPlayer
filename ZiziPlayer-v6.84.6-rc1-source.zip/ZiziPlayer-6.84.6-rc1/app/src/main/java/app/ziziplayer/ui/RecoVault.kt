package app.ziziplayer.ui

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Reco 2. Персональное состояние рекомендаций на диске — только зашифрованным (AES-GCM, ключ в
 * AndroidKeyStore, noBackupFilesDir: в облачную копию не уходит). Тот же приём, что у AccountSessionVault.
 *
 * Два файла, потому что у них разная жизнь:
 *  - state: «имя -> id Deezer», выбор при знакомстве, «не нравится». Маленький, живёт до очистки истории;
 *  - home: снимок последней непустой серверной главной (полной или частичной). Нужен ради одного: холодный старт рисует полки сразу,
 *    а свежий ответ сервера тихо их подменяет. Привязан к отпечатку приватности (скрытые треки и
 *    закрытые папки): поменялась приватность — снимок не читается и стирается.
 *
 * Любая ошибка чтения (восстановление на другом телефоне, сброс ключа, порча) — это «пусто», никогда
 * не откат на открытый текст. Все методы блокирующие: звать с Dispatchers.IO.
 */
internal class RecoVault(context: Context) {
    private val dir = context.noBackupFilesDir
    private val stateFile = AtomicFile(File(dir, "reco-state-v1"))
    private val homeFile = AtomicFile(File(dir, "reco-home-v1"))
    private val alias = "zizi.reco.vault.v1"
    private val lock = Any()
    private var cached: State? = null

    data class Pick(val id: String, val name: String, val art: String?)
    data class Dislike(val id: String?, val name: String)
    data class State(
        val ids: Map<String, String> = emptyMap(),
        val picks: List<Pick> = emptyList(),
        val onboardingDismissed: Boolean = false,
        /** Invitation disappears only after a live, complete response for the confirmed IDs. */
        val onboardingCompleted: Boolean = false,
        /** Confirmed-but-not-delivered selection survives process death. Never sent to the server. */
        val pendingTasteKey: String = "",
        /** Названия треков — только после отдельного согласия в настройке вкуса. */
        val allowTrackHints: Boolean = false,
        val dislikedArtists: List<Dislike> = emptyList(),
        val dislikedTracks: List<String> = emptyList()
    )

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
        }.generateKey()
    }

    private fun readFile(file: AtomicFile, aad: String, maxBytes: Int): String? {
        if (!file.baseFile.exists()) return null
        return try {
            val bytes = file.readFully()
            require(bytes.size in 29..maxBytes)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
            String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        } catch (_: Exception) {
            file.delete()
            null
        }
    }

    private fun writeFile(file: AtomicFile, aad: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
        val bytes = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val stream = file.startWrite()
        try {
            stream.write(bytes)
            file.finishWrite(stream)
        } catch (error: Exception) {
            file.failWrite(stream)
            throw error
        }
    }

    // ── state ────────────────────────────────────────────────────────────────────────────────────

    fun state(): State = synchronized(lock) {
        cached ?: decode(readFile(stateFile, "reco-state", STATE_MAX_BYTES)).also { cached = it }
    }

    private fun update(change: (State) -> State): State = synchronized(lock) {
        val next = change(state())
        writeFile(stateFile, "reco-state", encode(next))
        cached = next
        next
    }

    /** «нормализованное имя -> id». Новые записи вытесняют самые старые, предел [MAX_IDS]. */
    fun rememberIds(found: Map<String, String>) {
        if (found.isEmpty()) return
        val current = state().ids
        if (found.all { (k, v) -> current[k] == v }) return
        update { s ->
            val merged = LinkedHashMap<String, String>(s.ids)
            found.forEach { (k, v) -> if (k.isNotEmpty() && v.isNotEmpty()) { merged.remove(k); merged[k] = v } }
            while (merged.size > MAX_IDS) merged.remove(merged.keys.first())
            s.copy(ids = merged)
        }
    }

    fun savePicks(picks: List<Pick>, allowHints: Boolean = false) = update { s ->
        val clean = picks.mapNotNull { p -> HomeTastePolicy.artistId(p.id)?.let { p.copy(id = it) } }
            .filter { HomeRecoPolicy.isRealArtist(it.name) }.distinctBy { it.id }.take(MAX_PICKS)
        require(clean.size >= HomeTastePolicy.MIN_PICKS)
        val names = clean.mapTo(HashSet()) { HomeFeedPolicy.normalize(it.name) }
        val ids = clean.mapTo(HashSet()) { it.id }
        s.copy(picks = clean, onboardingDismissed = true, allowTrackHints = allowHints,
            pendingTasteKey = HomeTastePolicy.selectionKey(clean.map { it.id }),
            dislikedArtists = s.dislikedArtists.filterNot { it.id in ids || HomeFeedPolicy.normalize(it.name) in names })
    }
    fun dismissOnboarding() = update { it.copy(onboardingDismissed = true) }

    /** Atomically compare the confirmed selection before marking the one-time invitation done. */
    fun completeOnboarding(expectedKey: String): Boolean = synchronized(lock) {
        val current = state()
        if (expectedKey.isEmpty() || current.pendingTasteKey != expectedKey ||
            HomeTastePolicy.selectionKey(current.picks.map { it.id }) != expectedKey) return false
        update { it.copy(onboardingCompleted = true, pendingTasteKey = "") }
        true
    }

    fun dislikeArtist(id: String?, name: String) = update { s ->
        val key = HomeFeedPolicy.normalize(name)
        val rest = s.dislikedArtists.filterNot { (id != null && it.id == id) || HomeFeedPolicy.normalize(it.name) == key }
        // Нелюбимый артист больше не может быть выбором при знакомстве.
        s.copy(dislikedArtists = (rest + Dislike(id, name)).takeLast(MAX_DISLIKES),
            picks = s.picks.filterNot { (id != null && it.id == id) || HomeFeedPolicy.normalize(it.name) == key })
    }
    fun dislikeTrack(trackId: String) = update { s ->
        s.copy(dislikedTracks = (s.dislikedTracks.filterNot { it == trackId } + trackId).takeLast(MAX_DISLIKED_TRACKS))
    }
    fun forgiveArtist(name: String) = update { s ->
        val key = HomeFeedPolicy.normalize(name)
        s.copy(dislikedArtists = s.dislikedArtists.filterNot { HomeFeedPolicy.normalize(it.name) == key })
    }

    // ── снимок главной ───────────────────────────────────────────────────────────────────────────

    fun readHome(privacyKey: String, now: Long): String? = synchronized(lock) {
        val text = readFile(homeFile, "reco-home", HOME_MAX_BYTES) ?: return null
        return try {
            val o = JSONObject(text)
            val at = o.optLong("at", 0L)
            if (o.optString("key") != privacyKey || now - at !in 0L..HOME_MAX_AGE_MS) { homeFile.delete(); null }
            else o.optString("raw").ifEmpty { null }
        } catch (_: Exception) { homeFile.delete(); null }
    }

    fun writeHome(privacyKey: String, raw: String, now: Long): Boolean = synchronized(lock) {
        if (raw.isEmpty()) return@synchronized false
        val wrapper = JSONObject().put("key", privacyKey).put("at", now).put("raw", raw).toString()
        if (wrapper.toByteArray(Charsets.UTF_8).size > HOME_MAX_BYTES) return@synchronized false
        try { writeFile(homeFile, "reco-home", wrapper); true }
        catch (_: Exception) { false /* AtomicFile preserves the previous working snapshot. */ }
    }

    fun dropHome() = synchronized(lock) { homeFile.delete() }

    /** Очистка истории: забыть всё, включая выбор при знакомстве и «не нравится». */
    fun clearAll() = synchronized(lock) {
        cached = State(); stateFile.delete(); homeFile.delete()
    }

    private fun encode(s: State): String = JSONObject()
        .put("ids", JSONObject().apply { s.ids.forEach { (k, v) -> put(k, v) } })
        .put("picks", JSONArray().apply { s.picks.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("art", it.art ?: "")) } })
        .put("dismissed", s.onboardingDismissed)
        .put("completed", s.onboardingCompleted)
        .put("pendingTaste", s.pendingTasteKey)
        .put("allowHints", s.allowTrackHints)
        .put("noArtists", JSONArray().apply { s.dislikedArtists.forEach { put(JSONObject().put("id", it.id ?: "").put("name", it.name)) } })
        .put("noTracks", JSONArray().apply { s.dislikedTracks.forEach { put(it) } })
        .toString()

    private fun decode(text: String?): State {
        if (text.isNullOrEmpty()) return State()
        return try {
            val o = JSONObject(text)
            val ids = LinkedHashMap<String, String>()
            o.optJSONObject("ids")?.let { m -> m.keys().forEach { k -> m.optString(k).takeIf { it.isNotEmpty() }?.let { ids[k] = it } } }
            fun objects(name: String): List<JSONObject> = o.optJSONArray(name)?.let { a -> (0 until a.length()).mapNotNull(a::optJSONObject) }.orEmpty()
            State(
                ids = ids,
                picks = objects("picks").mapNotNull { p ->
                    val id = p.optString("id"); val name = p.optString("name")
                    if (id.isEmpty() || name.isEmpty()) null else Pick(id, name, p.optString("art").ifEmpty { null })
                },
                onboardingDismissed = o.optBoolean("dismissed", false),
                onboardingCompleted = o.optBoolean("completed", false),
                pendingTasteKey = o.optString("pendingTaste", ""),
                allowTrackHints = o.optBoolean("allowHints", false),
                dislikedArtists = objects("noArtists").mapNotNull { d ->
                    val name = d.optString("name")
                    if (name.isEmpty()) null else Dislike(d.optString("id").ifEmpty { null }, name)
                },
                dislikedTracks = o.optJSONArray("noTracks")?.let { a -> (0 until a.length()).mapNotNull { a.optString(it).ifEmpty { null } } }.orEmpty()
            )
        } catch (_: Exception) { State() }
    }

    companion object {
        const val MAX_IDS = 800
        const val MAX_PICKS = 30
        const val MAX_DISLIKES = 200
        const val MAX_DISLIKED_TRACKS = 500
        const val STATE_MAX_BYTES = 256 * 1024
        const val HOME_MAX_BYTES = 2 * 1024 * 1024
        /** Снимок старше двух суток не показывается: такие полки уже не «свежие», а вводящие в заблуждение. */
        const val HOME_MAX_AGE_MS = 48L * 3600_000L

        @Volatile private var instance: RecoVault? = null
        fun get(context: Context): RecoVault = instance ?: synchronized(this) {
            instance ?: RecoVault(context.applicationContext).also { instance = it }
        }
    }
}
