package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.ziziplayer.R
import app.ziziplayer.data.remote.RecoArtist
import app.ziziplayer.ui.HomeTasteInviteGeometry
import app.ziziplayer.ui.HomeTasteGeometry
import app.ziziplayer.ui.HomeTastePhase
import app.ziziplayer.ui.HomeTastePolicy
import app.ziziplayer.ui.HomeTasteState
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import app.ziziplayer.ui.theme.ZiziModalSurface
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.roundToInt

private val TasteBackground = Color(0xFF111111)
private val TasteInviteBody = Color(0xFFB3B3B3)

/** Kept under the old entry point so Home/settings use one implementation. This is a full screen,
 * not a height-limited bottom sheet. Search has its own page and never loses the browsing deck. */
@Composable
internal fun HomeTasteSheet(
    state: HomeTasteState,
    onQuery: (String) -> Unit,
    onToggle: (RecoArtist) -> Unit,
    onHints: (Boolean) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    onSearchOpen: (Boolean) -> Unit,
    onMoreSearch: () -> Unit,
    onRetryArtists: () -> Unit,
    onEdit: () -> Unit,
    onColumnsChange: (Int) -> Unit = {},
    onMoreRecommendations: () -> Unit = {},
    onRetryRelated: (String) -> Unit = {}
) {
    val p = LocalPalette.current
    var options by rememberSaveable { mutableStateOf(false) }
    // Hoisted above page switching: opening search never resets the browse scroll/header.
    val artistGrid = rememberLazyGridState()
    val collapseState = rememberSaveable { mutableFloatStateOf(0f) }
    // 6.84.6: «Другие рекомендации» больше не прокручивает сетку наверх. Страница добавляется в конец
    // (см. appendRevision в TasteArtists), позиция прокрутки и выбор остаются на месте.
    LaunchedEffect(state.revealRevision) {
        state.revealId?.let { id ->
            val index = state.browseArtists.indexOfFirst { it.id == id }
            if (index >= 0) artistGrid.scrollToItem(index + if (state.error != null) 1 else 0)
        }
    }
    Dialog(onDismissRequest = { if (state.searchOpen) onSearchOpen(false) else onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false,
            dismissOnClickOutside = false)) {
        // Non-floating edge-to-edge window. Compose owns its size; safeDrawing + IME are
        // consumed ONCE below. Do not force MATCH_PARENT on a floating, decor-fitted Dialog.
        val keyboard = LocalSoftwareKeyboardController.current
        val focus = LocalFocusManager.current
        LaunchedEffect(state.searchOpen, state.phase) {
            if (!state.searchOpen) { focus.clearFocus(); keyboard?.hide() }
        }
        // 6.84.6 — страховка от «Готово за экраном». Часть прошивок (жесты без видимой панели, три кнопки,
        // скрытая «полоска») отдаёт диалоговому окну нулевой нижний inset, а само окно оставляет выше
        // видимой области: всё, что стоит у нижнего края, уезжает под экран. Поэтому, не доверяя
        // отчёту о inset'ах, один раз измеряем, сколько нижней части окна лежит ЗА видимым фреймом
        // дисплея, и поднимаем нижний край содержимого на эту величину. Без клавиатуры; на исправных
        // телефонах результат 0 и ничего не меняется.
        val view = LocalView.current
        val windowDensity = LocalDensity.current
        val imeInsets = WindowInsets.ime
        var hiddenBelowPx by remember { mutableIntStateOf(0) }
        val maxHiddenPx = with(windowDensity) { 160.dp.roundToPx() }
        BoxWithConstraints(Modifier.fillMaxSize().background(TasteBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing.union(WindowInsets.ime))
            .onGloballyPositioned { coords ->
                if (coords.isAttached && imeInsets.getBottom(windowDensity) == 0) {
                    val hidden = tasteHiddenBelowPx(view, coords.boundsInRoot().bottom, maxHiddenPx)
                    if (hidden != hiddenBelowPx) hiddenBelowPx = hidden
                }
            }
            .padding(bottom = with(windowDensity) { hiddenBelowPx.toDp() })
            .testTag("taste-screen")) {
            val width = HomeTasteGeometry.contentWidth(maxWidth.value)
            val compact = maxHeight < 420.dp || LocalDensity.current.fontScale > 1.5f
            val page = when {
                state.phase != HomeTastePhase.PICKING -> "gather"
                state.searchOpen -> "search"
                else -> "artists"
            }
            AnimatedContent(targetState = page, modifier = Modifier.fillMaxSize(),
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) }, label = "taste-page") { shown ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    when (shown) {
                        "gather" -> TasteGathering(state, width, onSave, onEdit, onDismiss)
                        "search" -> TasteSearch(state, width, onQuery, onToggle, { onSearchOpen(false) }, onMoreSearch, onRetryArtists)
                        else -> TasteArtists(state, width, onToggle, onSave, onDismiss, { onSearchOpen(true) },
                            onRetryArtists, { options = true }, onColumnsChange,
                            compact = compact, grid = artistGrid, collapseState = collapseState,
                            onMoreRecommendations = onMoreRecommendations, onRetryRelated = onRetryRelated)
                    }
                }
            }
        }
    }
    // A sibling window, not a bottom-sheet window nested inside the fullscreen dialog.
    // This keeps IME, navigation insets and accessibility focus owned by the correct window.
    if (options) ZiziSheetScaffold(onDismiss = { options = false }) {
        val exit = LocalSheetExit.current
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 8.dp)
            .testTag("taste-options-sheet")) {
            Text("Настройки рекомендаций", color = p.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Row(Modifier.fillMaxWidth().padding(top = 12.dp).heightIn(min = 56.dp)
                .toggleable(state.allowTrackHints, enabled = !state.saving, role = Role.Checkbox, onValueChange = onHints)
                .testTag("taste-options-hints"), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    Checkbox(state.allowTrackHints, onCheckedChange = null,
                        colors = CheckboxDefaults.colors(checkedColor = p.brand, checkmarkColor = p.onBrand))
                }
                Text("Уточнять исполнителей по названиям треков", color = p.text, fontSize = 16.sp,
                    lineHeight = 22.sp, modifier = Modifier.weight(1f).padding(start = 4.dp))
            }
            Text("По умолчанию выключено. Если включить, сервер получит имя и название трека только для ещё не определённых исполнителей. Файлы, папки и полная история не отправляются.",
                color = p.subtext, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp))
            TextButton(onClick = { exit {} }, modifier = Modifier.align(Alignment.End).heightIn(min = 48.dp)
                .testTag("taste-options-done")) { Text("Готово", color = p.text) }
        }
    }
}

/** Сколько пикселей низа окна лежит за видимой областью экрана (ниже видимого фрейма дисплея).
 * Допуск 2 px гасит округление: исправный телефон даёт 0. Верхняя граница защищает от абсурдных значений. */
private fun tasteHiddenBelowPx(view: android.view.View, boundsBottomInRoot: Float, maxPx: Int): Int {
    if (!view.isAttachedToWindow) return 0
    val visible = android.graphics.Rect()
    view.getWindowVisibleDisplayFrame(visible)
    val origin = IntArray(2)
    view.getLocationOnScreen(origin)
    val hidden = origin[1] + boundsBottomInRoot.roundToInt() - visible.bottom
    return if (hidden <= 2) 0 else hidden.coerceAtMost(maxPx)
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TasteArtists(state: HomeTasteState, width: Float, onToggle: (RecoArtist) -> Unit, onSave: () -> Unit,
    onDismiss: () -> Unit, onSearch: () -> Unit, onRetry: () -> Unit, onOptions: () -> Unit,
    onColumnsChange: (Int) -> Unit, compact: Boolean, grid: LazyGridState,
    collapseState: MutableFloatState,
    onMoreRecommendations: () -> Unit, onRetryRelated: (String) -> Unit) {
    val p = LocalPalette.current
    val inset = HomeTasteGeometry.scale(width, HomeTasteGeometry.INSET).dp
    val columns = HomeTasteGeometry.columns(width, LocalDensity.current.fontScale)
    val avatar = HomeTasteGeometry.avatar(width, columns).dp
    val density = LocalDensity.current
    // 6.84.6: новая страница «Других рекомендаций» появляется на месте плитки. Один ряд мягкой прокрутки
    // показывает её; при возврате со страницы поиска (handled == текущему) прокрутки нет.
    var handledAppend by remember { mutableLongStateOf(state.appendRevision) }
    LaunchedEffect(state.appendRevision) {
        if (state.appendRevision != handledAppend) {
            handledAppend = state.appendRevision
            delay(80)
            grid.animateScrollBy(with(density) { HomeTasteGeometry.rowStep(width, 1).dp.toPx() }, tween(380))
        }
    }
    var footerHeightPx by remember { mutableIntStateOf(0) }
    val footerPadding = maxOf(HomeTasteGeometry.scale(width, HomeTasteGeometry.FOOTER).dp,
        with(density) { footerHeightPx.toDp() } + 8.dp)
    var collapseRangePx by remember { mutableFloatStateOf(0f) }
    val fraction = if (compact) 1f else collapseState.floatValue
    val currentCompact by rememberUpdatedState(compact)
    LaunchedEffect(columns) { onColumnsChange(columns) }
    val collapse = remember(grid, collapseState) {
        object : NestedScrollConnection {
            private fun consume(dy: Float): Offset {
                if (currentCompact || collapseRangePx <= 0f || dy == 0f) return Offset.Zero
                val before = collapseState.floatValue * collapseRangePx
                val after = (before - dy).coerceIn(0f, collapseRangePx)
                collapseState.floatValue = HomeTasteGeometry.collapseFraction(after, collapseRangePx)
                return Offset(0f, before - after)
            }
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && grid.canScrollBackward) return Offset.Zero
                return consume(available.y)
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // A downward fling can reach the first row during this very dispatch.
                return if (available.y > 0f && !grid.canScrollBackward) consume(available.y) else Offset.Zero
            }
        }
    }
    val picked = remember(state.picks) { HomeTastePolicy.uniqueIds(state.picks.map { it.id }).toHashSet() }
    val count = picked.size
    // Footer belongs to the safe WINDOW, not the grid or the collapsing Column. A larger
    // title, two-line artist label or IME can never add its height to the button's Y position.
    Box(Modifier.width(width.dp).fillMaxHeight().clipToBounds().testTag("taste-picker-viewport")) {
        Column(Modifier.fillMaxSize().nestedScroll(collapse)) {
            TasteCollapsingTitle(width, fraction, onDismiss) { collapseRangePx = it }
            Row(Modifier.padding(horizontal = inset)
                .fillMaxWidth().heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_HEIGHT).dp)
                .clip(RoundedCornerShape(HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_RADIUS).dp))
                .background(Color.White).clickable(role = Role.Button, onClickLabel = "Найти исполнителя", onClick = onSearch)
                .padding(horizontal = HomeTasteGeometry.scale(width, 28f).dp).testTag("taste-open-search"),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(ZiziIcons.Search, null, tint = Color.Black,
                    modifier = Modifier.size(HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_ICON).dp))
                Text("Поиск", color = Color.Black, fontWeight = FontWeight.SemiBold,
                    fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_TEXT).sp,
                    modifier = Modifier.padding(start = HomeTasteGeometry.scale(width, 24f).dp, top = 4.dp, bottom = 4.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = inset)
                .heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.GRID_TOP).dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(if (count < HomeTastePolicy.MIN_PICKS) "Выбрано $count · минимум ${HomeTastePolicy.MIN_PICKS}" else "Выбрано $count",
                    color = p.subtext, fontSize = HomeTasteGeometry.scale(width, 32f).sp,
                    modifier = Modifier.weight(1f).testTag("taste-count"))
                IconButton(onClick = onOptions, modifier = Modifier.size(36.dp).testTag("taste-options")) {
                    Icon(ZiziIcons.Tune, "Настройки рекомендаций", tint = p.subtext, modifier = Modifier.size(20.dp))
                }
            }
            LazyVerticalGrid(columns = GridCells.Fixed(columns), state = grid,
                modifier = Modifier.weight(1f).fillMaxWidth().testTag("taste-grid"),
                contentPadding = PaddingValues(start = inset, end = inset, bottom = footerPadding),
                verticalArrangement = Arrangement.spacedBy(HomeTasteGeometry.scale(width, HomeTasteGeometry.ROW_GAP).dp)) {
                if (state.error != null) item(key = "error", span = { GridItemSpan(maxLineSpan) }) {
                    TasteProblem(state.error, onRetry)
                }
                items(state.browseArtists, key = { it.id }) { artist ->
                    TasteArtistCell(artist, selected = artist.id in picked, pending = artist.id in state.relatedLoading,
                        avatar = avatar, width = width, onToggle = { onToggle(artist) },
                        problem = state.relatedErrors[artist.id], onRetry = { onRetryRelated(artist.id) },
                        modifier = Modifier.animateItem(fadeInSpec = tween(220), fadeOutSpec = tween(140),
                            placementSpec = spring(stiffness = Spring.StiffnessMediumLow)))
                }
                if (state.catalogLoading) item(key = "loading", span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = p.brand, modifier = Modifier.size(28.dp))
                    }
                }
                // The video ends with a round cell in the grid, not a full-width footer button.
                item(key = "other-recommendations") {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                        Box(Modifier.width(avatar).heightIn(min = avatar).clip(CircleShape)
                            .background(Color(0xFF505964))
                            .clickable(enabled = !state.catalogLoading && !state.moreLoading, role = Role.Button,
                                onClickLabel = "Показать других исполнителей", onClick = onMoreRecommendations)
                            .padding(horizontal = HomeTasteGeometry.scale(width, 16f).dp, vertical = 12.dp)
                            .testTag("taste-other-recommendations"), contentAlignment = Alignment.Center) {
                            if (state.moreLoading) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp,
                                modifier = Modifier.size(28.dp).testTag("taste-more-loading"))
                            else Text("Другие\nрекомендации", color = Color.White, fontFamily = ZiziFontFamily,
                                letterSpacing = 0.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium,
                                fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.MORE_TEXT).sp,
                                lineHeight = HomeTasteGeometry.scale(width, 46f).sp)
                        }
                    }
                }
                if (state.moreError != null) item(key = "more-error", span = { GridItemSpan(maxLineSpan) }) {
                    // A paging failure belongs at the bottom where the user just tapped.
                    TasteProblem(state.moreError, onRetry)
                }
            }
        }
        androidx.compose.animation.AnimatedVisibility(visible = count >= HomeTastePolicy.MIN_PICKS, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(180)), exit = fadeOut(tween(120))) {
            Box(Modifier.fillMaxWidth().onSizeChanged { footerHeightPx = it.height }
                .background(Brush.verticalGradient(listOf(Color.Transparent, TasteBackground, TasteBackground)))
                .padding(top = 20.dp, bottom = HomeTasteGeometry.scale(width, HomeTasteGeometry.CONFIRM_BOTTOM).dp)
                .testTag("taste-footer"), contentAlignment = Alignment.Center) {
                TastePrimaryButton("Готово", width, onSave, "taste-confirm")
            }
        }
    }
}

/** Measure both real text layouts, then interpolate their height. No guessed scroll item height,
 * no text-size animation reflowing words, and no oversized child pushing the footer offscreen. */
@Composable
private fun TasteCollapsingTitle(width: Float, fraction: Float, onDismiss: () -> Unit, onRange: (Float) -> Unit) {
    val p = LocalPalette.current
    val inset = HomeTasteGeometry.scale(width, HomeTasteGeometry.INSET).dp
    val largeAlpha = HomeTasteGeometry.largeTitleAlpha(fraction)
    val smallAlpha = HomeTasteGeometry.compactTitleAlpha(fraction)
    val closeSpace = HomeTasteGeometry.scale(width, 120f).dp
    Box(Modifier.fillMaxWidth().testTag("taste-header")) {
        androidx.compose.ui.layout.Layout(modifier = Modifier.fillMaxWidth().clipToBounds(), content = {
            Text("Выбери любимых\nисполнителей", color = p.text, fontFamily = ZiziFontFamily,
                letterSpacing = 0.sp, fontWeight = FontWeight.Bold,
                fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.TITLE_TEXT).sp,
                lineHeight = HomeTasteGeometry.scale(width, HomeTasteGeometry.TITLE_LINE).sp,
                style = TextStyle(fontFamily = ZiziFontFamily, platformStyle = PlatformTextStyle(includeFontPadding = false)),
                modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = largeAlpha }
                    .then(if (largeAlpha < .5f) Modifier.clearAndSetSemantics { } else Modifier)
                    .padding(horizontal = inset).padding(end = closeSpace,
                        top = HomeTasteGeometry.scale(width, HomeTasteGeometry.TITLE_TOP).dp,
                        bottom = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_GAP).dp).testTag("taste-title"))
            Box(Modifier.fillMaxWidth().heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.COMPACT_TITLE_HEIGHT).dp)
                .graphicsLayer { alpha = smallAlpha }
                .then(if (smallAlpha < .5f) Modifier.clearAndSetSemantics { } else Modifier)
                .padding(start = inset, end = inset + closeSpace,
                    top = HomeTasteGeometry.scale(width, HomeTasteGeometry.TITLE_TOP).dp,
                    bottom = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_GAP).dp),
                contentAlignment = Alignment.CenterStart) {
                Text("Выбери любимых исполнителей", color = p.text, fontFamily = ZiziFontFamily,
                    fontWeight = FontWeight.Bold, letterSpacing = 0.sp,
                    fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.COMPACT_TITLE_TEXT).sp,
                    lineHeight = HomeTasteGeometry.scale(width, HomeTasteGeometry.COMPACT_TITLE_LINE).sp,
                    style = TextStyle(fontFamily = ZiziFontFamily, platformStyle = PlatformTextStyle(includeFontPadding = false)),
                    modifier = Modifier.testTag("taste-compact-title"))
            }
        }) { children, constraints ->
            val relaxed = constraints.copy(minHeight = 0)
            val large = children[0].measure(relaxed)
            val small = children[1].measure(relaxed)
            val range = (large.height - small.height).coerceAtLeast(0)
            onRange(range.toFloat())
            val hidden = (range * fraction).roundToInt().coerceIn(0, range)
            layout(constraints.maxWidth, large.height - hidden) {
                // In the video the large glyphs move ~half as far as the search field.
                large.placeRelative(0, -hidden / 2)
                small.placeRelative(0, 0)
            }
        }
        IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd)
            .padding(end = inset).size(40.dp).testTag("taste-close")) {
            Icon(ZiziIcons.Close, "Закрыть выбор исполнителей", tint = p.subtext, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun TasteArtistCell(artist: RecoArtist, selected: Boolean, pending: Boolean, avatar: Dp, width: Float,
    onToggle: () -> Unit, problem: String? = null, onRetry: () -> Unit = {}, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val amount by animateFloatAsState(if (selected) 1f else 0f, spring(stiffness = Spring.StiffnessMedium), label = "taste-pick")
    Column(modifier.fillMaxWidth().toggleable(selected, role = Role.Checkbox, onValueChange = { onToggle() })
        .semantics(mergeDescendants = true) { contentDescription = artist.name; stateDescription = if (selected) "Выбран" else "Не выбран" }
        .testTag("taste-artist-${artist.id}"), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(avatar)) {
            RemoteArtwork(artist.art, artist.id, 500, Modifier.matchParentSize().graphicsLayer {
                scaleX = 1f - .035f * amount; scaleY = scaleX
            }.clip(CircleShape))
            if (amount > 0f) Box(Modifier.matchParentSize().border(HomeTasteGeometry.scale(width, HomeTasteGeometry.BORDER).dp,
                p.brand.copy(alpha = amount), CircleShape))
            if (amount > 0f) Box(Modifier.align(Alignment.TopEnd).graphicsLayer {
                alpha = amount; scaleX = .7f + .3f * amount; scaleY = scaleX
            }.offset(x = HomeTasteGeometry.scale(width, -4f).dp,
                y = HomeTasteGeometry.scale(width, 6f).dp).size(HomeTasteGeometry.scale(width, HomeTasteGeometry.BADGE).dp)
                .clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                Icon(ZiziIcons.Check, null, tint = Color.Black, modifier = Modifier.fillMaxSize(.52f))
            }
            if (pending) CircularProgressIndicator(color = p.brand, strokeWidth = 2.dp,
                modifier = Modifier.align(Alignment.BottomStart).size(16.dp).testTag("taste-related-${artist.id}"))
        }
        Text(artist.name, color = p.text, fontFamily = ZiziFontFamily, letterSpacing = 0.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
            fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.LABEL_TEXT).sp,
            lineHeight = HomeTasteGeometry.scale(width, HomeTasteGeometry.LABEL_LINE).sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = HomeTasteGeometry.scale(width, HomeTasteGeometry.LABEL_GAP).dp, start = 2.dp, end = 2.dp))
        if (problem != null) TextButton(onClick = onRetry,
            modifier = Modifier.heightIn(min = 48.dp).testTag("taste-related-retry-${artist.id}")
                .semantics { contentDescription = "$problem Повторить загрузку похожих" },
            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)) {
            Text("Похожие · повторить", color = p.subtext, textAlign = TextAlign.Center, fontSize = 11.sp)
        }
    }
}

@Composable
private fun TasteSearch(state: HomeTasteState, width: Float, onQuery: (String) -> Unit, onToggle: (RecoArtist) -> Unit,
    onBack: () -> Unit, onMore: () -> Unit, onRetry: () -> Unit) {
    val p = LocalPalette.current
    val inset = HomeTasteGeometry.scale(width, HomeTasteGeometry.INSET).dp
    val requester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val list = rememberLazyListState()
    val current by rememberUpdatedState(state)
    LaunchedEffect(Unit) { requester.requestFocus(); keyboard?.show() }
    LaunchedEffect(list, state.query) {
        snapshotFlow {
            val now = current
            now.hasMore && !now.loading && !now.loadingMore && now.error == null &&
                list.layoutInfo.visibleItemsInfo.lastOrNull()?.index?.let { it >= now.artists.size - 4 } == true
        }.distinctUntilChanged().collect { if (it) onMore() }
    }
    Column(Modifier.width(width.dp).fillMaxHeight().testTag("taste-search-page")) {
        Row(Modifier.fillMaxWidth().heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_HEADER).dp)
            .padding(horizontal = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_EDGE).dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_BACK_TOUCH).dp).testTag("taste-search-back")) {
                Icon(ZiziIcons.ArrowBack, "Вернуться к исполнителям", tint = p.text)
            }
            BasicTextField(value = state.query, onValueChange = onQuery,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp).focusRequester(requester).testTag("taste-query"),
                singleLine = true, cursorBrush = SolidColor(p.text),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
                textStyle = TextStyle(color = p.text, fontFamily = ZiziFontFamily, letterSpacing = 0.sp, fontWeight = FontWeight.Medium,
                    fontSize = HomeTasteGeometry.scale(width, 48f).sp),
                decorationBox = { field -> Box { if (state.query.isEmpty()) Text("Поиск", color = p.subtext,
                    fontSize = HomeTasteGeometry.scale(width, 48f).sp); field() } })
            if (state.query.isNotEmpty()) IconButton(onClick = { onQuery("") }, modifier = Modifier.size(40.dp).testTag("taste-query-clear")) {
                Icon(ZiziIcons.Close, "Очистить поиск", tint = p.text, modifier = Modifier.size(20.dp))
            }
        }
        if (state.query.isBlank()) Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = inset), contentAlignment = Alignment.Center) {
            Text("Найди исполнителей, которые тебе нравятся.", color = p.text, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, fontSize = HomeTasteGeometry.scale(width, 54f).sp)
        } else LazyColumn(state = list, modifier = Modifier.weight(1f).fillMaxWidth().testTag("taste-search-results"),
            contentPadding = PaddingValues(horizontal = inset, vertical = 6.dp)) {
            if (state.loading) item("loading") { Box(Modifier.fillMaxWidth().height(72.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = p.brand, modifier = Modifier.size(26.dp))
            } }
            items(state.artists, key = { it.id }) { artist ->
                val selected = state.picks.any { it.id == artist.id }
                Row(Modifier.fillMaxWidth().heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_ROW).dp)
                    .toggleable(selected, role = Role.Checkbox, onValueChange = { onToggle(artist) })
                    .semantics { contentDescription = artist.name; stateDescription = if (selected) "Выбран" else "Не выбран" }
                    .testTag("taste-search-artist-${artist.id}"), verticalAlignment = Alignment.CenterVertically) {
                    RemoteArtwork(artist.art, artist.id, 500, Modifier.size(HomeTasteGeometry.scale(width, HomeTasteGeometry.SEARCH_AVATAR).dp)
                        .clip(CircleShape).then(if (selected) Modifier.border(2.dp, p.brand, CircleShape) else Modifier))
                    Text(artist.name, color = p.text, fontSize = HomeTasteGeometry.scale(width, 44f).sp,
                        fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = HomeTasteGeometry.scale(width, 36f).dp))
                    if (selected) Icon(ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(20.dp))
                }
            }
            if (state.error != null) item("error") { TasteProblem(state.error, onRetry) }
            if (state.loadingMore) item("more-loading") { Box(Modifier.fillMaxWidth().height(54.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = p.brand, modifier = Modifier.size(22.dp))
            } }
            if (state.hasMore && !state.loadingMore && state.error == null) item("more") {
                TextButton(onClick = onMore, modifier = Modifier.fillMaxWidth()) { Text("Показать ещё", color = p.text) }
            }
        }
    }
}

@Composable
private fun TasteGathering(state: HomeTasteState, width: Float, onRetry: () -> Unit, onEdit: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val failed = state.phase == HomeTastePhase.FAILED
    val ready = state.phase == HomeTastePhase.READY
    val density = LocalDensity.current
    val converged by animateFloatAsState(if (state.phase == HomeTastePhase.INTRO || failed) 0f else 1f,
        tween(480, easing = FastOutSlowInEasing), label = "taste-converge")
    BoxWithConstraints(Modifier.width(width.dp).fillMaxHeight().testTag("taste-gathering")) {
        val footerMax = maxHeight * .5f
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            // Independent scrollable body and measured footer: adding an error must not push the
            // exit action offscreen. Small displays / large font can scroll text, not lose actions.
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val bodyHeight = maxHeight
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Column(Modifier.fillMaxWidth().heightIn(min = bodyHeight)
                        .padding(horizontal = HomeTasteGeometry.scale(width, 64f).dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.width(HomeTasteGeometry.scale(width, 620f).dp)
                            .height(HomeTasteGeometry.scale(width, 200f).dp), contentAlignment = Alignment.Center) {
                            if (ready) Box(Modifier.size(HomeTasteGeometry.scale(width, HomeTasteGeometry.PROGRESS_AVATAR).dp)
                                .clip(CircleShape).background(p.brand), contentAlignment = Alignment.Center) {
                                Icon(ZiziIcons.Check, null, tint = p.onBrand, modifier = Modifier.fillMaxSize(.5f))
                            } else {
                                state.picks.takeLast(3).forEachIndexed { index, artist ->
                                    val center = (state.picks.takeLast(3).size - 1) / 2f
                                    val distance = HomeTasteGeometry.scale(width, (index - center) * 146f)
                                    RemoteArtwork(artist.art, artist.id, 500,
                                        Modifier.size(HomeTasteGeometry.scale(width, HomeTasteGeometry.PROGRESS_AVATAR).dp)
                                            .graphicsLayer {
                                                translationX = with(density) { (distance * (1f - converged)).dp.toPx() }
                                                alpha = if (index == 1) 1f else 1f - converged
                                                scaleX = 1f - .08f * converged; scaleY = scaleX
                                            }.clip(CircleShape).border(2.dp, p.brand, CircleShape))
                                }
                                if (state.phase == HomeTastePhase.BUILDING) CircularProgressIndicator(
                                    color = p.brand, trackColor = Color.Transparent, strokeWidth = 2.dp,
                                    modifier = Modifier.size(HomeTasteGeometry.scale(width, 188f).dp).testTag("taste-build-spinner"))
                            }
                        }
                        AnimatedContent(targetState = state.phase,
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) }, label = "taste-message") { phase ->
                            Text(when (phase) {
                                HomeTastePhase.INTRO -> "Отличный выбор!"
                                HomeTastePhase.READY -> "Твоя музыка готова"
                                HomeTastePhase.FAILED -> "Не удалось собрать музыку"
                                else -> "Ищем для тебя музыку…"
                            }, color = p.text, fontFamily = ZiziFontFamily, letterSpacing = 0.sp,
                                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.PROGRESS_TEXT).sp,
                                modifier = Modifier.padding(top = HomeTasteGeometry.scale(width, HomeTasteGeometry.PROGRESS_GAP).dp)
                                    .testTag("taste-stage").semantics { liveRegion = LiveRegionMode.Polite })
                        }
                        if (failed) Text(state.error.orEmpty(), color = p.subtext, textAlign = TextAlign.Center,
                            fontSize = 14.sp, lineHeight = 20.sp,
                            modifier = Modifier.padding(top = 18.dp).testTag("taste-delivery-error"))
                        else if (state.phase == HomeTastePhase.BUILDING) Text(
                            if (state.buildPartial) "Проверяем подборки для твоего выбора…"
                            else "На основе ${state.picks.size} выбранных исполнителей",
                            color = p.subtext, textAlign = TextAlign.Center, fontSize = 13.sp,
                            modifier = Modifier.padding(top = 14.dp).semantics { liveRegion = LiveRegionMode.Polite })
                    }
                }
            }
            Column(Modifier.fillMaxWidth().heightIn(max = footerMax).verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp).testTag("taste-actions"),
                horizontalAlignment = Alignment.CenterHorizontally) {
                if (failed) {
                    TastePrimaryButton("Повторить", width, onRetry, "taste-retry-delivery")
                    TextButton(onClick = onEdit, modifier = Modifier.heightIn(min = 48.dp).testTag("taste-edit")) {
                        Text("Изменить исполнителей", color = p.text, textAlign = TextAlign.Center)
                    }
                }
                // Keep the footer footprint on success to avoid jumping during the final check.
                TextButton(onClick = onDismiss, enabled = !ready,
                    modifier = Modifier.heightIn(min = 48.dp).testTag("taste-gather-close")) {
                    Text(if (ready) "Открываем главную…" else "На главную", color = p.subtext)
                }
            }
        }
    }
}

@Composable
private fun TastePrimaryButton(label: String, width: Float, onClick: () -> Unit, tag: String) {
    Button(onClick = onClick, modifier = Modifier.heightIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.CONFIRM_HEIGHT).dp)
        .widthIn(min = HomeTasteGeometry.scale(width, HomeTasteGeometry.CONFIRM_WIDTH).dp).testTag(tag), shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
        contentPadding = PaddingValues(horizontal = HomeTasteGeometry.scale(width, 48f).dp, vertical = 0.dp)) {
        Text(label, fontFamily = ZiziFontFamily, letterSpacing = 0.sp, fontWeight = FontWeight.Bold,
            fontSize = HomeTasteGeometry.scale(width, HomeTasteGeometry.CONFIRM_TEXT).sp,
            textAlign = TextAlign.Center)
    }
}

@Composable
private fun TasteProblem(message: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(message, color = LocalPalette.current.subtext, fontSize = 13.sp)
        TextButton(onClick = onRetry) { Text("Повторить", color = LocalPalette.current.text) }
    }
}

/** One invitation for a guest OR an account. Decorative portraits are supplied reference art,
 * not fake selected IDs. Cross closes this visit; the encrypted completion gate stays untouched. */
@Composable
internal fun HomeTasteInvite(onOpen: () -> Unit, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val width = HomeTasteInviteGeometry.width(maxWidth.value)
        val fixed = HomeTasteInviteGeometry.fixedLayout(LocalDensity.current.fontScale)
        fun dim(value: Float) = HomeTasteInviteGeometry.scale(width, value).dp
        val title = "Получи точные рекомендации"
        val body = "Расскажи, музыку каких исполнителей ты любишь, и мы подберем треки, которые могут тебе понравиться."
        val referenceLines = "Расскажи, музыку каких исполнителей ты\nлюбишь, и мы подберем треки, которые могут\nтебе понравиться."
        Box(Modifier.width(width.dp).then(if (fixed) Modifier.height(dim(HomeTasteInviteGeometry.HEIGHT)) else Modifier)
            .clip(RoundedCornerShape(dim(HomeTasteInviteGeometry.RADIUS))).background(ZiziModalSurface)
            .testTag("home-taste-invite")) {
            if (fixed) {
                Image(painterResource(R.drawable.taste_invite_collage), contentDescription = null,
                    modifier = Modifier.align(Alignment.TopCenter).offset(y = dim(HomeTasteInviteGeometry.HERO_TOP))
                        .size(dim(HomeTasteInviteGeometry.HERO_WIDTH), dim(HomeTasteInviteGeometry.HERO_HEIGHT)),
                    contentScale = ContentScale.FillBounds)
                Text(title, color = Color.White, fontFamily = ZiziFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.TITLE_FONT).sp,
                    lineHeight = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.TITLE_LINE).sp,
                    letterSpacing = 0.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
                    style = TextStyle(fontFamily = ZiziFontFamily, platformStyle = PlatformTextStyle(includeFontPadding = false)),
                    modifier = Modifier.align(Alignment.TopCenter).offset(y = dim(HomeTasteInviteGeometry.TITLE_TOP))
                        .fillMaxWidth().testTag("home-taste-title"))
                Text(referenceLines, color = TasteInviteBody, fontFamily = ZiziFontFamily, fontWeight = FontWeight.Medium,
                    fontSize = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BODY_FONT).sp,
                    lineHeight = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BODY_LINE).sp,
                    letterSpacing = 0.sp, textAlign = TextAlign.Center,
                    style = TextStyle(fontFamily = ZiziFontFamily, platformStyle = PlatformTextStyle(includeFontPadding = false)),
                    modifier = Modifier.align(Alignment.TopCenter).offset(y = dim(HomeTasteInviteGeometry.BODY_TOP))
                        .width(dim(HomeTasteInviteGeometry.BODY_WIDTH)).testTag("home-taste-body"))
                TasteInviteButton(width, onOpen, Modifier.align(Alignment.TopCenter)
                    .offset(y = dim(HomeTasteInviteGeometry.BUTTON_TOP)))
            } else Column(Modifier.fillMaxWidth().padding(horizontal = dim(32f)).padding(top = dim(36f), bottom = dim(48f)),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.taste_invite_collage), contentDescription = null,
                    modifier = Modifier.size(dim(HomeTasteInviteGeometry.HERO_WIDTH), dim(HomeTasteInviteGeometry.HERO_HEIGHT)),
                    contentScale = ContentScale.FillBounds)
                Text(title, color = Color.White, fontFamily = ZiziFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.TITLE_FONT).sp,
                    letterSpacing = 0.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = dim(28f)).testTag("home-taste-title"))
                Text(body, color = TasteInviteBody, fontFamily = ZiziFontFamily, fontWeight = FontWeight.Medium,
                    fontSize = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BODY_FONT).sp,
                    lineHeight = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BODY_LINE).sp,
                    letterSpacing = 0.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = dim(12f)).testTag("home-taste-body"))
                TasteInviteButton(width, onOpen, Modifier.padding(top = dim(32f)), accessible = true)
            }
            IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd)
                .offset(x = -(dim(HomeTasteInviteGeometry.CLOSE_FROM_RIGHT) - 24.dp),
                    y = dim(HomeTasteInviteGeometry.CLOSE_CENTER_Y) - 24.dp)
                .size(48.dp).testTag("home-taste-dismiss")) {
                Icon(ZiziIcons.Close, "Скрыть карточку до следующего посещения главной", tint = Color.White,
                    modifier = Modifier.size(dim(HomeTasteInviteGeometry.CLOSE_ICON)))
            }
        }
    }
}

@Composable
private fun TasteInviteButton(width: Float, onOpen: () -> Unit, modifier: Modifier, accessible: Boolean = false) {
    val buttonWidth = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BUTTON_WIDTH).dp
    val buttonHeight = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BUTTON_HEIGHT).dp
    Button(onClick = onOpen,
        modifier = modifier.then(if (accessible) Modifier.widthIn(min = buttonWidth).heightIn(min = 48.dp)
            else Modifier.width(buttonWidth).height(buttonHeight)).testTag("home-taste-start"), shape = CircleShape,
        contentPadding = PaddingValues(horizontal = if (accessible) 18.dp else 0.dp, vertical = if (accessible) 12.dp else 0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
        Text("Выбрать", fontFamily = ZiziFontFamily, fontWeight = FontWeight.Bold, letterSpacing = 0.sp,
            fontSize = HomeTasteInviteGeometry.scale(width, HomeTasteInviteGeometry.BUTTON_FONT).sp,
            maxLines = if (accessible) Int.MAX_VALUE else 1, textAlign = TextAlign.Center)
    }
}
