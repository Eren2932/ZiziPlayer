package app.ziziplayer.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay

/**
 * 6.84.4. Один индикатор загрузки вместо скелетонов: зелёное кольцо по центру, как на референсе.
 *
 * Показывается ТОЛЬКО при настоящем ожидании: если данные пришли быстрее [SHOW_AFTER_MS], экран не мигает
 * и кольца нет вовсе. Компонент живёт ровно пока висит его строка списка: пришли данные, строку убрали,
 * кольцо исчезло в тот же кадр. Содержимое никогда не ждёт индикатор.
 */
internal object ZiziLoaderTiming {
    const val SHOW_AFTER_MS = 350L
    const val FADE_IN_MS = 180
    const val SPIN_MS = 1000
}

/** true, когда с появления вызывающего прошло [afterMs]. Пока строки нет в композиции, таймер не идёт. */
@Composable
internal fun rememberLoaderVisible(afterMs: Long = ZiziLoaderTiming.SHOW_AFTER_MS): Boolean {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(afterMs)
        visible = true
    }
    return visible
}

/** Само кольцо: бледная дорожка и яркая дуга, которая крутится. Уважает системный масштаб анимаций. */
@Composable
internal fun ZiziLoader(
    modifier: Modifier = Modifier, diameter: Dp = 44.dp, stroke: Dp = 5.dp, description: String = "Загрузка"
) {
    val brand = LocalPalette.current.brand
    val transition = rememberInfiniteTransition(label = "zizi-loader")
    val angle by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(ZiziLoaderTiming.SPIN_MS, easing = LinearEasing)),
        label = "zizi-loader-angle")
    Canvas(modifier.size(diameter).semantics { contentDescription = description }) {
        val width = stroke.toPx()
        val topLeft = Offset(width / 2f, width / 2f)
        val arc = Size(this.size.width - width, this.size.height - width)
        drawArc(color = brand.copy(alpha = 0.28f), startAngle = 0f, sweepAngle = 360f, useCenter = false,
            topLeft = topLeft, size = arc, style = Stroke(width = width))
        drawArc(color = brand, startAngle = angle - 90f, sweepAngle = 110f, useCenter = false,
            topLeft = topLeft, size = arc, style = Stroke(width = width, cap = StrokeCap.Round))
    }
}

/** Контейнер для строки списка: пусто до [ZiziLoaderTiming.SHOW_AFTER_MS], потом кольцо плавно проявляется по центру. */
@Composable
internal fun ZiziLoaderBox(
    modifier: Modifier, diameter: Dp = 44.dp, stroke: Dp = 5.dp, description: String = "Загрузка"
) {
    val visible = rememberLoaderVisible()
    val fade by animateFloatAsState(if (visible) 1f else 0f, tween(ZiziLoaderTiming.FADE_IN_MS), label = "zizi-loader-fade")
    Box(modifier, contentAlignment = Alignment.Center) {
        if (visible) ZiziLoader(Modifier.alpha(fade), diameter, stroke, description)
    }
}
