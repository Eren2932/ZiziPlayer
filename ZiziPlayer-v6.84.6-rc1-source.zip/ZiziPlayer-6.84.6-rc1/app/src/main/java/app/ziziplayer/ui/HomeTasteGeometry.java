package app.ziziplayer.ui;

/** Reference: Screenshot_20261003_174226.jpg and 1080x2400 video frames.
 * Units below are measured reference pixels, converted once by the content width.
 * Android safe insets and font accessibility remain device-owned, not hardcoded to this phone. */
public final class HomeTasteGeometry {
    private HomeTasteGeometry() {}
    public static final float REF_WIDTH = 1080f;
    public static final float INSET = 46f;
    public static final float TITLE_TOP = 58f;
    public static final float TITLE_TEXT = 92f;
    public static final float TITLE_LINE = 128f;
    public static final float SEARCH_GAP = 48f;
    public static final float SEARCH_HEIGHT = 116f;
    public static final float SEARCH_RADIUS = 8f;
    public static final float SEARCH_ICON = 60f;
    public static final float SEARCH_TEXT = 42f;
    public static final float GRID_TOP = 92f;
    public static final float AVATAR = 288f;
    public static final float BADGE = 84f;
    public static final float BORDER = 9f;
    public static final float LABEL_GAP = 20f;
    public static final float LABEL_TEXT = 38f;
    public static final float LABEL_LINE = 50f;
    public static final float ROW_GAP = 46f;
    public static final float CONFIRM_HEIGHT = 142f;
    public static final float CONFIRM_WIDTH = 331f;
    public static final float CONFIRM_TEXT = 44f;
    public static final float CONFIRM_BOTTOM = 46f;
    public static final float COMPACT_TITLE_HEIGHT = 162f;
    public static final float COMPACT_TITLE_TEXT = 48f;
    public static final float COMPACT_TITLE_LINE = 56f;
    public static final float MORE_HEIGHT = 288f;
    public static final float MORE_TEXT = 36f;
    public static final float FOOTER = 210f;
    public static final float SEARCH_HEADER = 128f;
    public static final float SEARCH_EDGE = 12f;
    public static final float SEARCH_BACK_TOUCH = 128f;
    public static final float SEARCH_ROW = 184f;
    public static final float SEARCH_AVATAR = 132f;
    public static final float PROGRESS_AVATAR = 164f;
    public static final float PROGRESS_TEXT = 60f;
    public static final float PROGRESS_GAP = 100f;

    /** Gesture-synchronous fit to the supplied 60 fps recording (0.70–1.40 s).
     * Compact alpha follows collapse throughout; the large title stays opaque until ~53%,
     * then fades out by ~70%. They DO overlap in the recording. These are fitted parameters,
     * not a claim that the reference application's internal animation code is known. */
    public static float collapseFraction(float collapsed, float range) {
        if (!Float.isFinite(collapsed) || !Float.isFinite(range) || range <= 0f) return 0f;
        return Math.max(0f, Math.min(1f, collapsed / range));
    }
    public static float largeTitleAlpha(float fraction) {
        return 1f - Math.max(0f, Math.min(1f, (fraction - .53f) / .17f));
    }
    public static float compactTitleAlpha(float fraction) {
        return Math.max(0f, Math.min(1f, fraction));
    }

    public static float contentWidth(float viewportDp) {
        if (!Float.isFinite(viewportDp) || viewportDp <= 0f) return 320f;
        return Math.min(viewportDp, 520f);
    }
    public static float scale(float viewportDp, float referencePx) {
        return contentWidth(viewportDp) * referencePx / REF_WIDTH;
    }
    public static int columns(float viewportDp, float fontScale) {
        float width = contentWidth(viewportDp);
        float font = Float.isFinite(fontScale) && fontScale > 0f ? fontScale : 1f;
        float available = width - 2f * scale(width, INSET);
        return Math.max(1, Math.min(3, (int) Math.floor(available / (92f * Math.min(1.45f, Math.max(1f, font))))));
    }
    public static float cellWidth(float viewportDp, int columns) {
        return (contentWidth(viewportDp) - 2f * scale(viewportDp, INSET)) / Math.max(1, columns);
    }
    public static float avatar(float viewportDp, int columns) {
        return Math.min(scale(viewportDp, AVATAR), Math.max(48f, cellWidth(viewportDp, columns) - scale(viewportDp, 40f)));
    }
    public static float rowStep(float viewportDp, int lines) {
        return scale(viewportDp, AVATAR + LABEL_GAP + LABEL_LINE * Math.max(1, Math.min(2, lines)) + ROW_GAP);
    }
}
