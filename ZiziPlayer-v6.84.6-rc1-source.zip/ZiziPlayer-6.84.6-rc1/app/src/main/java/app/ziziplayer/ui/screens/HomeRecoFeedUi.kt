package app.ziziplayer.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.HomeFeedStreamPolicy
import app.ziziplayer.ui.RecoFeedState
import app.ziziplayer.ui.theme.LocalPalette

/**
 * 6.82.0. Лента «Для тебя»: треки подряд, подгружаются по мере прокрутки.
 *
 * Ключ строки — «reco-feed:индекс»: лента растёт только вперёд, индекс стабилен, а по ключу экран
 * узнаёт, до какой строки ленты человек доскроллил (HomeFeedStreamPolicy.indexOfKey).
 */
internal fun LazyListScope.homeRecoFeed(
    feed: RecoFeedState, currentTrackId: String?, unit: Float, sectionTop: Dp,
    onPlay: (Int) -> Unit, onMenu: (TrackEntity) -> Unit, onRetry: () -> Unit
) {
    val tracks = feed.tracks
    if (tracks.isEmpty() && !feed.stalled) return
    item(key = "reco-feed-heading", contentType = "reco-heading") {
        HomeHeading("Для тебя", Modifier.padding(top = sectionTop, bottom = 4.dp))
    }
    itemsIndexed(tracks, key = { index, _ -> HomeFeedStreamPolicy.keyOf(index) },
        contentType = { _, _ -> "reco-track" }) { index, track ->
        CollectionTrackRow(track, unit, track.id == currentTrackId,
            selected = false, picking = false,
            onPlay = { onPlay(index) }, onSelect = {},
            onLongPress = { onMenu(track) }, onMenu = { onMenu(track) }, horizontalInset = 0.dp)
    }
    if (feed.stalled) {
        item(key = "reco-feed-retry", contentType = "reco-retry") { FeedRetry(feed.error, onRetry) }
    } else if (feed.loading && tracks.isNotEmpty()) {
        item(key = "reco-feed-more", contentType = "reco-loader") {
            ZiziLoaderBox(Modifier.fillMaxWidth().height(72.dp), diameter = 28.dp, stroke = 3.dp,
                description = "Загружаем ещё")
        }
    }
}

/**
 * Пока подборок ещё нет, по центру кольцо загрузки (ZiziLoader), а не скелетон. Кольцо появляется лишь если
 * ожидание затянулось дольше ZiziLoaderTiming.SHOW_AFTER_MS: быстрый ответ показывается без мигания.
 * Имя функции прежнее: её вызов из HomeScreen закреплён тестами.
 */
internal fun LazyListScope.homeFeedSkeleton(sectionTop: Dp) {
    item(key = "feed-skeleton", contentType = "feed-loader") {
        ZiziLoaderBox(Modifier.fillMaxWidth().fillParentMaxHeight(0.5f).padding(top = sectionTop),
            description = "Загружаем подборки")
    }
}

@Composable
private fun FeedRetry(error: String?, onRetry: () -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!error.isNullOrEmpty()) Text(error, color = p.subtext, fontSize = 13.sp, lineHeight = 17.sp)
        TextButton(onClick = onRetry) { Text("Повторить", color = p.text) }
    }
}
