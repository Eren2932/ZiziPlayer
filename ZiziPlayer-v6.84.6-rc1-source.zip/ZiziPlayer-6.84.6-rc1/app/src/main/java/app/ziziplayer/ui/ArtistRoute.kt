package app.ziziplayer.ui

import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteKind

/**
 * 6.84.5. Куда ведёт «К исполнителю». Решение принимает [MainViewModel.artistRoute] без обращения к сети,
 * исполняет его MainActivity: она одна знает про вкладки. Правила выбора см. в [ArtistRoutePolicy].
 */
sealed interface ArtistRoute {
    /** У артиста есть id в каталоге: настоящая страница с баннером, та же, что открывает поиск. */
    data class Catalog(val collection: RemoteCollection) : ArtistRoute

    /** id нет, трек сетевой: страница открывается сразу, id находится по точному имени. */
    data class ByName(val names: List<String>) : ArtistRoute

    /** Локальные файлы без id в каталоге: страница исполнителя в медиатеке. */
    data class Local(val name: String) : ArtistRoute

    /** Исполнитель не указан (заглушка вроде «<unknown>»): переходить некуда. */
    data object None : ArtistRoute
}

/** Страница артиста каталога. Фото подтянет ответ сервера: у `collection` в нём всегда есть `art`. */
internal fun artistCollection(id: String, name: String): RemoteCollection = RemoteCollection(
    provider = "dz",
    remoteId = ArtistRoutePolicy.remoteId(id),
    kind = RemoteKind.ARTIST,
    title = name
)
