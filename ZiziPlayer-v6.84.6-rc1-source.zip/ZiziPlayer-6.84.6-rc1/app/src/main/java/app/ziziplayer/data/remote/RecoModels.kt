package app.ziziplayer.data.remote

import androidx.compose.runtime.Immutable
import app.ziziplayer.ui.HomeRecoPolicy

/**
 * Серверная «Главная» (Reco 1): профиль вкуса уходит одним запросом, полки приходят готовыми.
 *
 * Профиль компактен намеренно: артисты и веса, а не история. Названий треков, времени и
 * длительностей на сервере нет ни в запросе, ни в логе.
 */
@Immutable
data class RecoSeed(val ref: String, val weight: Double)

@Immutable
data class RecoProfile(
    val seeds: List<RecoSeed>,
    val known: List<String>,
    val negative: List<String>,
    val recent: List<String>,
    /** "slowed" | "sped" | "" */
    val version: String,
    /**
     * Reco 2: «имя~название трека» для артистов без id Deezer. Сервер ищет `artist:"…" track:"…"` и
     * больше не путает тёзок. Уходит только для имён, которые ещё не привязаны, и только телом POST.
     */
    val hints: List<String> = emptyList()
) {
    /**
     * Поля тела POST `/reco/home` (не query: см. BrowseHttp.post). Значения очищены от разделителей протокола.
     * s — первые 8 сидов (их понимает и сервер 1.15), s2 — остальные до 30 и h — подсказки: старый сервер
     * их молча пропускает. k/x/s укладываются в его пределы по символам, иначе он ответил бы 422.
     */
    fun queryParams(): Map<String, String> {
        val all = seeds.map { RecoQuery.seed(it.ref, it.weight) }
        val legacy = all.take(HomeRecoPolicy.LEGACY_SEEDS)
        return linkedMapOf(
            "s" to RecoQuery.joinRaw(legacy, legacy.size, HomeRecoPolicy.SEEDS_CHARS),
            "s2" to RecoQuery.joinRaw(all.drop(legacy.size), HomeRecoPolicy.MAX_SEEDS,
                HomeRecoPolicy.SEEDS2_CHARS),
            "k" to RecoQuery.join(known, HomeRecoPolicy.MAX_KNOWN, HomeRecoPolicy.KNOWN_CHARS),
            "x" to RecoQuery.join(negative, HomeRecoPolicy.MAX_NEGATIVE, HomeRecoPolicy.NEGATIVE_CHARS),
            "r" to RecoQuery.join(recent, 3),
            "v" to version,
            "h" to RecoQuery.joinRaw(hints, HomeRecoPolicy.MAX_HINTS, HomeRecoPolicy.HINTS_CHARS)
        ).filterValues { it.isNotEmpty() }
    }

    /**
     * Поля тела POST `/reco/feed` (6.82.0): тот же профиль плюс курсор `c` и размер страницы `n`.
     * Профиль на всё время ленты ОБЯЗАН быть одним и тем же: сервер сверяет его отпечаток с сессией
     * и при любом расхождении начинает ленту заново (restarted).
     */
    fun feedParams(cursor: String?, pageSize: Int): Map<String, String> {
        val fields = LinkedHashMap(queryParams())
        if (!cursor.isNullOrEmpty()) fields["c"] = cursor
        fields["n"] = pageSize.coerceIn(10, 50).toString()
        return fields
    }
}

enum class RecoShelfKind { ALBUMS, TRACKS, ARTISTS }

@Immutable
data class RecoCard(val track: RemoteTrack? = null, val collection: RemoteCollection? = null)

@Immutable
data class RecoShelf(
    val id: String,
    val kind: RecoShelfKind,
    val title: String,
    /** Артист-якорь полки «Похоже на»; у остальных полок null. */
    val anchorName: String?,
    val anchorArt: String?,
    val cards: List<RecoCard>
)

/**
 * [complete] = false: сервер уложился в бюджет не целиком; остаток он достроит в кэше.
 * [retryMs] — через сколько сервер просит спросить снова (`retry_ms`); 0, если не просит.
 */
@Immutable
data class RecoResult(val shelves: List<RecoShelf>, val complete: Boolean, val cold: Boolean, val retryMs: Long = 0L,
    /** Reco 2: какие артисты сервер узнал в сидах. [RecoSeedEcho.ref] — исходная строка, по ней клиент запоминает id. */
    val seeds: List<RecoSeedEcho> = emptyList(),
    /** Тело ответа как есть — для зашифрованного снимка главной (RecoVault). Пусто у результата из снимка. */
    val raw: String = "",
    /** Время сборки на сервере (сек). Снимок старше суток не показывается. */
    val generated: Long = 0L,
    /** Optional server capability evidence. null on older servers, never inferred from missing echoes. */
    val requestedSeeds: Int? = null)

@Immutable
data class RecoSeedEcho(val ref: String, val id: String, val name: String)

/** Артист в окне знакомства (`GET /reco/onboard`). */
@Immutable
data class RecoArtist(val id: String, val name: String, val art: String?, val genre: String = "")

/**
 * Страница бесконечной ленты `POST /reco/feed` (6.82.0).
 * [cursor] отдаётся обратно в следующем запросе как есть; [more] = false — лента кончилась;
 * [restarted] — сервер потерял сессию и начал с головы, повторы режет клиент.
 */
@Immutable
data class RecoFeedPage(
    val tracks: List<RemoteTrack>,
    val cursor: String?,
    val more: Boolean,
    val complete: Boolean,
    val cold: Boolean,
    val restarted: Boolean,
    val retryMs: Long
)
