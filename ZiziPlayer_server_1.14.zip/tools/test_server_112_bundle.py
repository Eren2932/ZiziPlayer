#!/usr/bin/env python3
"""Payload integrity + offline real Python health, and separate Android source contracts."""
from pathlib import Path
import hashlib
import sys
import tempfile
import unittest
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/tools'))
import test_smart_match as smart
import apply_smart_update as installer
import zizi_match as zm

class Bundle112Tests(unittest.TestCase):
    def test_exact_user_supplied_runtime(self):
        # 1.14: установщик и тесты обязаны говорить об ОДНИХ И ТЕХ ЖЕ файлах. Печать хешей в
        # apply_smart_update.py пересобирается tools/seal_smart_update.py после любой правки.
        for name, want in installer.SEAL.items():
            self.assertEqual(hashlib.sha256((ROOT / 'server' / name).read_bytes()).hexdigest(), want, name)

    def test_real_catalog_health_reports_actual_engine(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(smart.c, 'DB_PATH', tmp + '/catalog.db'):
                health = smart.c.catalog_health()
        self.assertEqual(health['version'], '1.14-smart-match')
        self.assertEqual(health['match_engine'], 'smart')
        self.assertEqual(health['match_policy'], zm.RULES)
        self.assertIs(health['strict_default'], False)
        self.assertIs(health['fallback'], True)       # телефон печатает этот ключ в диагностике
        self.assertIn(health['substitute'], ('all', 'degree', 'off'))

    def test_android_version_is_live_not_a_hardcoded_claim(self):
        source=(ROOT/'app/src/main/java/app/ziziplayer/data/remote/ZiziResolve.kt').read_text()
        health=source[source.index('    suspend fun health():'):]
        self.assertIn('"/catalog/health"', health)
        self.assertIn('catalog.optString("version", "не указана")', health)
        self.assertIn('catalog.has("fallback")', health)
        self.assertIn('версия каталога недоступна', health)
        self.assertEqual(health.count('catch (e: CancellationException)'), 2)
        self.assertNotIn('1.11', health)
        self.assertNotIn('1.12', health)
        self.assertEqual(health.count('ZiziHttp.getJson('), 2)

    def test_client_accepts_server_selected_video_without_confidence_gate(self):
        source=(ROOT/'app/src/main/java/app/ziziplayer/data/remote/DeezerCatalog.kt').read_text()
        start=source.index('    override suspend fun resolveStream(')
        end=source.index('\n}\n',start)
        method=source[start:end]
        self.assertIn('response.optString("vid")',method)
        self.assertIn('ZiziResolve.resolve(videoId, quality)',method)
        self.assertNotIn('optBoolean("confident"',method)

if __name__ == '__main__':
    unittest.main(verbosity=2)
