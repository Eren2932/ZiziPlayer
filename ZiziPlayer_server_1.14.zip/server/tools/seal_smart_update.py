#!/usr/bin/env python3
"""Пересобирает печать SHA-256 в apply_smart_update.py. Запускать после ЛЮБОЙ правки трёх файлов комплекта."""
import hashlib
import re
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
inst = Path(__file__).resolve().parent / 'apply_smart_update.py'
text = inst.read_text(encoding='utf-8')
for name in ('zizi_catalog.py', 'zizi_match.py', 'zizi_versions.py'):
    h = hashlib.sha256((SRC / name).read_bytes()).hexdigest()
    text, n = re.subn(rf"('{re.escape(name)}': ')([0-9a-f]{{64}}|__[A-Z]+__)(')", rf"\g<1>{h}\g<3>", text, count=1)
    assert n == 1, name
    print(f'{name}: {h}')
inst.write_text(text, encoding='utf-8')
