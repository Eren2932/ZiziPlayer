#!/usr/bin/env python3
"""Установка 1.14-smart-match в каталог сервера: три файла, бэкапы, откат при сбое.

    python3 apply_smart_update.py --target-dir /opt/zizi            # проверка, ничего не пишет
    sudo python3 apply_smart_update.py --target-dir /opt/zizi --apply

Что делает:
  * zizi_match.py     — новый модуль подбора; ставится целиком.
  * zizi_versions.py  — нужен новым кодом (speed_compatible, speed_family, SPEED_TAGS...). Если развёрнутый файл
                        уже умеет всё это, он НЕ трогается; если нет (сервер старше 1.13) — ставится с бэкапом.
  * zizi_catalog.py   — заменяется только если стоит одна из известных баз (1.11 / 1.12 / 1.13) или уже 1.14.
                        Неизвестный файл = отказ: кто-то правил его руками, и слепая замена эти правки сотрёт.
Порядок: сначала модули, потом каталог (каталог импортирует оба). Любой сбой — все изменения этого запуска
откатываются из бэкапов. Службу скрипт НЕ перезапускает.
"""
import argparse
import datetime
import hashlib
import os
import re
import stat
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]

# Заполняется tools/seal_smart_update.py; test_smart_update.py падает, если файлы изменились без пересборки.
SEAL = {
    'zizi_catalog.py': '90a378e9eac07ded5029e1fb6da1b96abf05d33ce2604b98bac1ee3f2b938fa9',
    'zizi_match.py': 'a320742a07c33b66c9eae59c07b5851d1b0338f7981a2cb960659687f7f3918a',
    'zizi_versions.py': 'f2702cc654940a5b729cff7b70513ce6c7ff0fd4a65fbcb4eeb8fc06696222f7',
}
# Известные базы zizi_catalog.py (SHA-256 из прошлых комплектов).
CATALOG_BASES = {
    '7a1783db8f7c0d29cae94b65c3e1de84be4c8f8841963bcd8755d0fd0896316c': '1.11-metadata-match',
    '4a7f0d05bcd3e75a8ec29c4a842a3b2eb0f7ceb373866461994a6c6d1c1d86b7': '1.12-fallback-match',
    '78637061e3101961ecfd211456578b1b4f74a54a009bcec57d17bf3be1de0e57': '1.13-version-family',
}
VERSIONS_API = ('def speed_compatible', 'def speed_family', 'def version_tags', 'def strip_version_phrases',
                'SPEED_TAGS', 'def normalized')


class UpdateError(Exception):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_payloads() -> dict:
    out = {}
    for name, want in SEAL.items():
        data = (SRC / name).read_bytes()
        if digest(data) != want:
            raise UpdateError(f'{name}: хеш комплекта не совпадает с печатью. Комплект повреждён или изменён '
                              f'после сборки — возьмите целый.')
        compile(data, name, 'exec')    # только синтаксис: ни импорта, ни сети
        out[name] = data
    return out


def versions_api_ok(data: bytes) -> bool:
    text = data.decode('utf-8', 'replace')
    return all(token in text for token in VERSIONS_API)


def plan(target: Path, payloads: dict) -> list:
    """Список действий [(имя, действие, пояснение)]. Ничего не пишет."""
    steps = []
    for name in ('zizi_match.py', 'zizi_versions.py', 'zizi_catalog.py'):
        path = target / name
        new = payloads[name]
        if path.is_symlink():
            raise UpdateError(f'{path}: символическая ссылка. Укажите настоящий файл.')
        if not path.exists():
            if name == 'zizi_catalog.py':
                raise UpdateError(f'{path} не найден: это не каталог сервера (ожидается /opt/zizi).')
            steps.append((name, 'install', 'файла нет — ставится'))
            continue
        old = path.read_bytes()
        if digest(old) == digest(new):
            steps.append((name, 'skip', 'уже актуален'))
        elif name == 'zizi_versions.py':
            if versions_api_ok(old):
                steps.append((name, 'skip', 'развёрнутый файл уже содержит нужный API — не трогаю'))
            else:
                steps.append((name, 'replace', 'старый файл без speed_compatible/SPEED_TAGS — заменяется'))
        elif name == 'zizi_catalog.py':
            base = CATALOG_BASES.get(digest(old))
            if base is None:
                raise UpdateError('zizi_catalog.py неизвестной версии (правился руками или другая сборка). Отказ: '
                                  'замена сотрёт чужие правки. Сравните вручную или передайте файл на разбор.')
            steps.append((name, 'replace', f'база {base}'))
        else:   # zizi_match.py есть, но отличается — это только прошлый запуск или ручная правка
            steps.append((name, 'replace', 'отличается от комплекта — заменяется с бэкапом'))
    return steps


def write_atomic(path: Path, data: bytes, like: os.stat_result = None) -> None:
    mode = stat.S_IMODE(like.st_mode) if like else 0o644
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.zizi-upd-', delete=False) as fh:
            tmp = Path(fh.name)
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, mode)
        if like is not None and hasattr(os, 'geteuid') and os.geteuid() == 0:
            os.chown(tmp, like.st_uid, like.st_gid)
        os.replace(tmp, path)
        tmp = None
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def verify_installed(path: Path, expected: bytes) -> None:
    """Читаем с диска то, что реально лежит: тот же хеш и синтаксически целый файл."""
    got = path.read_bytes()
    if digest(got) != digest(expected):
        raise UpdateError(f'{path.name}: после записи на диске другой файл')
    compile(got, path.name, 'exec')


def apply(target: Path, payloads: dict, steps: list) -> list:
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    done = []       # (path, backup|None, было ли файла)
    try:
        for name, action, _ in steps:
            if action == 'skip':
                continue
            path = target / name
            info = path.stat() if path.exists() else None
            backup = None
            if info is not None:
                backup = path.with_name(f'{path.name}.before-1.14-{stamp}')
                with backup.open('xb') as fh:                   # эксклюзивно: чужой бэкап не затираем
                    fh.write(path.read_bytes())
                    fh.flush()
                    os.fsync(fh.fileno())
                os.chmod(backup, stat.S_IMODE(info.st_mode))
                if hasattr(os, 'geteuid') and os.geteuid() == 0:
                    os.chown(backup, info.st_uid, info.st_gid)
            done.append((path, backup, info is not None))
            write_atomic(path, payloads[name], info)
            verify_installed(path, payloads[name])
    except BaseException:
        for path, backup, existed in reversed(done):
            try:
                if backup is not None and backup.exists():
                    write_atomic(path, backup.read_bytes(), backup.stat())
                elif not existed:
                    path.unlink(missing_ok=True)
            except OSError as e:     # откат не должен маскировать причину
                print(f'ОТКАТ {path}: {e}', file=sys.stderr)
        raise
    return done


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--target-dir', type=Path, required=True, help='каталог сервера, обычно /opt/zizi')
    ap.add_argument('--apply', action='store_true', help='записать; без флага — только проверка')
    args = ap.parse_args(argv)
    target = args.target_dir
    if not target.is_dir():
        ap.error(f'{target}: не каталог')
    try:
        payloads = load_payloads()
        steps = plan(target, payloads)
    except UpdateError as e:
        print('ОТКАЗ:', e, file=sys.stderr)
        return 2
    for name, action, why in steps:
        print(f'  {name:<18} {action:<8} {why}')
    if all(a == 'skip' for _, a, _ in steps):
        print('Уже 1.14: файлы не менялись.')
        return 0
    if not args.apply:
        print('Проверка пройдена. Ничего не записано. Добавьте --apply.')
        return 0
    try:
        done = apply(target, payloads, steps)
    except (OSError, SyntaxError, UpdateError) as e:
        print('СБОЙ, изменения этого запуска откатаны:', e, file=sys.stderr)
        return 3
    for path, backup, _ in done:
        print('Установлен:', path, '| бэкап:', backup)
    print('Служба не перезапускалась. Дальше: sudo systemctl restart zizi-resolver, затем /catalog/health.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
