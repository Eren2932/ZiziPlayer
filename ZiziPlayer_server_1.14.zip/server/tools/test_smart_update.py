#!/usr/bin/env python3
"""Установщик 1.14: проверка, установка, идемпотентность, отказ на неизвестной базе, откат при сбое."""
import hashlib
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import apply_smart_update as up

SRC = up.SRC
OLD_CATALOG = b'# old catalog 1.13\nVERSION = "old"\n'
OLD_VERSIONS_NO_API = b'# very old versions module\n'


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        (self.dir / 'zizi_catalog.py').write_bytes(OLD_CATALOG)
        os.chmod(self.dir / 'zizi_catalog.py', 0o640)
        (self.dir / 'zizi_versions.py').write_bytes((SRC / 'zizi_versions.py').read_bytes())
        self.base = patch.dict(up.CATALOG_BASES, {hashlib.sha256(OLD_CATALOG).hexdigest(): 'test-base'})
        self.base.start()

    def tearDown(self):
        self.base.stop()
        self.tmp.cleanup()

    def run_main(self, *extra):
        return up.main(['--target-dir', str(self.dir), *extra])

    def files(self):
        return {p.name for p in self.dir.iterdir()}

    def test_seal_matches_the_shipped_files(self):
        # Падает, если кто-то правил модуль и забыл tools/seal_smart_update.py.
        for name, want in up.SEAL.items():
            self.assertEqual(hashlib.sha256((SRC / name).read_bytes()).hexdigest(), want, name)

    def test_dry_run_writes_nothing(self):
        before = self.files()
        self.assertEqual(self.run_main(), 0)
        self.assertEqual(self.files(), before)
        self.assertEqual((self.dir / 'zizi_catalog.py').read_bytes(), OLD_CATALOG)

    def test_apply_installs_backs_up_keeps_mode_and_is_idempotent(self):
        self.assertEqual(self.run_main('--apply'), 0)
        self.assertEqual((self.dir / 'zizi_catalog.py').read_bytes(), (SRC / 'zizi_catalog.py').read_bytes())
        self.assertEqual((self.dir / 'zizi_match.py').read_bytes(), (SRC / 'zizi_match.py').read_bytes())
        backups = [p for p in self.dir.iterdir() if '.before-1.14-' in p.name]
        self.assertEqual(len(backups), 1)                                   # versions уже актуален: не трогали
        self.assertEqual(backups[0].read_bytes(), OLD_CATALOG)
        self.assertEqual(stat.S_IMODE((self.dir / 'zizi_catalog.py').stat().st_mode), 0o640)
        snapshot = self.files()
        self.assertEqual(self.run_main('--apply'), 0)                       # повтор: «уже 1.14»
        self.assertEqual(self.files(), snapshot)

    def test_unknown_catalog_is_refused_and_untouched(self):
        (self.dir / 'zizi_catalog.py').write_bytes(b'# hand edited\n')
        before = self.files()
        self.assertEqual(self.run_main('--apply'), 2)
        self.assertEqual((self.dir / 'zizi_catalog.py').read_bytes(), b'# hand edited\n')
        self.assertEqual(self.files(), before)

    def test_not_a_server_dir_is_refused(self):
        (self.dir / 'zizi_catalog.py').unlink()
        self.assertEqual(self.run_main('--apply'), 2)
        self.assertNotIn('zizi_match.py', self.files())

    def test_old_versions_module_without_the_api_is_replaced_with_backup(self):
        (self.dir / 'zizi_versions.py').write_bytes(OLD_VERSIONS_NO_API)
        self.assertEqual(self.run_main('--apply'), 0)
        self.assertEqual((self.dir / 'zizi_versions.py').read_bytes(), (SRC / 'zizi_versions.py').read_bytes())
        self.assertTrue(any(p.read_bytes() == OLD_VERSIONS_NO_API for p in self.dir.glob('zizi_versions.py.before-1.14-*')))

    def test_failure_midway_rolls_everything_back(self):
        real = up.verify_installed

        def boom(path, expected):
            if path.name == 'zizi_catalog.py':          # к этому моменту match и versions уже записаны
                raise up.UpdateError('boom')
            return real(path, expected)
        (self.dir / 'zizi_versions.py').write_bytes(OLD_VERSIONS_NO_API)
        with patch.object(up, 'verify_installed', boom):
            self.assertEqual(self.run_main('--apply'), 3)
        self.assertEqual((self.dir / 'zizi_catalog.py').read_bytes(), OLD_CATALOG)
        self.assertEqual((self.dir / 'zizi_versions.py').read_bytes(), OLD_VERSIONS_NO_API)
        self.assertNotIn('zizi_match.py', self.files())                     # новый файл при откате удаляется

    def test_disk_that_lies_is_caught(self):
        real = up.write_atomic
        calls = []

        def corrupt(path, data, like=None):
            calls.append(path.name)
            real(path, data + b'\n# junk' if path.name == 'zizi_match.py' else data, like)
        with patch.object(up, 'write_atomic', corrupt):
            self.assertEqual(self.run_main('--apply'), 3)
        self.assertNotIn('zizi_match.py', self.files())
        self.assertEqual((self.dir / 'zizi_catalog.py').read_bytes(), OLD_CATALOG)

    def test_tampered_payload_is_refused(self):
        with patch.dict(up.SEAL, {'zizi_match.py': '0' * 64}):
            self.assertEqual(self.run_main('--apply'), 2)
        self.assertNotIn('zizi_match.py', self.files())

    @unittest.skipIf(os.name == 'nt', 'symlink')
    def test_symlinked_target_is_refused(self):
        real = self.dir / 'real_catalog.py'
        real.write_bytes(OLD_CATALOG)
        (self.dir / 'zizi_catalog.py').unlink()
        os.symlink(real, self.dir / 'zizi_catalog.py')
        self.assertEqual(self.run_main('--apply'), 2)
        self.assertEqual(real.read_bytes(), OLD_CATALOG)


if __name__ == '__main__':
    unittest.main(verbosity=2)
