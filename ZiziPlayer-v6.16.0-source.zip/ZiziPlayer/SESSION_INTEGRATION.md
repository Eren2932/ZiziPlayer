# Session WebView integration (6.9.2)

## Контракт страницы

Страница должна быть доступна только по HTTPS. Когда payload готов, она один раз вызывает:

````html
<script>
  async function createSession() {
    const response = await fetch('/api/session', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ purpose: 'ziziplayer' })
    });
    if (!response.ok) throw new Error(`session: ${response.status}`);
    const { payload } = await response.json();
    window.AndroidTokenBridge.postToken(String(payload));
  }

  createSession();
</script>
````

Payload должен быть непустой однострочной ASCII-строкой длиной не более 16384 символов. Он не
пишется на диск и живёт в памяти приложения не более шести часов. Не размещайте секрет в URL.

## Настройка сборки

В `gradle.properties` или через `-P...`:

````properties
sessionBootstrapUrl=https://session.example.com/android/bootstrap
sessionProtectedHosts=api.example.com,*.cdn.example.com
sessionTokenHeader=X-Session-Payload
sessionUserAgent=Mozilla/5.0 (Linux; Android 14; CustomDevice) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36
sessionTokenWaitMs=12000
````

Те же значения можно передать переменными окружения `SESSION_BOOTSTRAP_URL`,
`SESSION_PROTECTED_HOSTS`, `SESSION_TOKEN_HEADER`, `SESSION_USER_AGENT` и
`SESSION_TOKEN_WAIT_MS`.

Если allowlist хостов пуст, автоматически защищается только хост `sessionBootstrapUrl`. Значение
`*` разрешено для сценария, где payload действительно должен уходить на каждый HTTP-хост, но это
не рекомендуется: токен может попасть стороннему CDN или провайдеру.

## Поведение клиента

`SessionHeadersInterceptor` всегда перезаписывает `User-Agent`, даже если вызывающий код указал
другой. Для защищённых хостов он также перезаписывает настроенный заголовок payload. До готовности
WebView сетевой worker ждёт максимум `sessionTokenWaitMs`; затем запрос завершается локально.

На HTTP 401/403 payload сбрасывается и страница загружается заново. Исходный запрос автоматически
не повторяется, потому что он может быть неидемпотентным.
