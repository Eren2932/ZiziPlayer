#!/usr/bin/env python3
"""
zizi-geoscan.py — ищет в подписке VPN узлы, которые Google считает НЕ российскими.

Критерий отбора узла — не ipinfo (он врёт про Google), а поле "GL" в HTML
главной youtube.com: это собственное мнение YouTube о стране клиента.

Безопасность: рабочий xray НЕ трогается. Поднимается отдельный процесс
на 127.0.0.1:10801 с конфигом в /tmp, после каждой проверки убивается.

Запуск на сервере:
    python3 /root/zizi-geoscan.py                # все узлы
    python3 /root/zizi-geoscan.py --limit 10     # первые 10
    python3 /root/zizi-geoscan.py --sub /root/sub.txt --port 10801
"""
import argparse, base64, json, os, re, shutil, signal, subprocess, sys, tempfile, time
import urllib.parse as up

GL_RE = re.compile(r'"GL"\s*:\s*"([A-Z]{2})"')


def find_xray() -> str:
    for p in ("/usr/local/bin/xray", "/usr/bin/xray", shutil.which("xray") or ""):
        if p and os.path.exists(p):
            return p
    sys.exit("xray не найден (искал /usr/local/bin/xray, /usr/bin/xray, PATH)")


def load_sub(path: str) -> list[str]:
    raw = open(path, "r", encoding="utf-8", errors="ignore").read().strip()
    if "://" not in raw:                      # подписка отдана base64 одним куском
        try:
            raw = base64.b64decode(raw + "=" * (-len(raw) % 4)).decode("utf-8", "ignore")
        except Exception:
            pass
    links = [l.strip() for l in raw.splitlines() if l.strip().startswith("vless://")]
    seen, out = set(), []
    for l in links:                            # дедуп по host:port
        u = up.urlparse(l)
        key = f"{u.hostname}:{u.port}"
        if key not in seen:
            seen.add(key)
            out.append(l)
    return out


def vless_outbound(link: str) -> tuple[dict, str]:
    u = up.urlparse(link)
    q = {k: v[0] for k, v in up.parse_qs(u.query).items()}
    name = up.unquote(u.fragment or f"{u.hostname}:{u.port}")
    net = q.get("type", "tcp")
    sec = q.get("security", "none")

    stream: dict = {"network": net, "security": sec}
    tls_common = {
        "serverName": q.get("sni") or q.get("host") or u.hostname,
        "fingerprint": q.get("fp", "chrome"),
        "allowInsecure": q.get("allowInsecure") == "1",
    }
    if sec == "tls":
        stream["tlsSettings"] = tls_common
        if q.get("alpn"):
            stream["tlsSettings"]["alpn"] = q["alpn"].split(",")
    elif sec == "reality":
        stream["realitySettings"] = {
            "serverName": tls_common["serverName"],
            "fingerprint": tls_common["fingerprint"],
            "publicKey": q.get("pbk", ""),
            "shortId": q.get("sid", ""),
            "spiderX": q.get("spx", "/"),
        }
    if net == "ws":
        stream["wsSettings"] = {"path": up.unquote(q.get("path", "/")),
                                "headers": {"Host": q.get("host") or u.hostname}}
    elif net == "grpc":
        stream["grpcSettings"] = {"serviceName": q.get("serviceName", "")}
    elif net in ("http", "h2"):
        stream["httpSettings"] = {"path": up.unquote(q.get("path", "/")),
                                  "host": [q.get("host") or u.hostname]}

    ob = {
        "protocol": "vless",
        "settings": {"vnext": [{
            "address": u.hostname, "port": int(u.port or 443),
            "users": [{"id": up.unquote(u.username or ""), "encryption": "none",
                       "flow": q.get("flow", "")}],
        }]},
        "streamSettings": stream,
    }
    return ob, name


def probe(xray: str, link: str, port: int, timeout: int) -> dict:
    ob, name = vless_outbound(link)
    cfg = {
        "log": {"loglevel": "error"},
        "inbounds": [{"listen": "127.0.0.1", "port": port, "protocol": "socks",
                      "settings": {"udp": False}}],
        "outbounds": [ob],
    }
    fd, cfg_path = tempfile.mkstemp(prefix="geoscan_", suffix=".json")
    with os.fdopen(fd, "w") as f:
        json.dump(cfg, f)

    res = {"name": name, "host": ob["settings"]["vnext"][0]["address"],
           "gl": "-", "ipinfo": "-", "ip": "-", "ms": 0}
    proc = None
    try:
        proc = subprocess.Popen([xray, "-c", cfg_path],
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                preexec_fn=os.setsid)
        time.sleep(1.5)
        if proc.poll() is not None:
            res["gl"] = "xray-fail"
            return res
        px = f"socks5h://127.0.0.1:{port}"
        t0 = time.time()
        yt = subprocess.run(["curl", "-s", "-m", str(timeout), "-x", px,
                             "-A", "Mozilla/5.0", "https://www.youtube.com/"],
                            capture_output=True, text=True, errors="ignore")
        res["ms"] = int((time.time() - t0) * 1000)
        m = GL_RE.search(yt.stdout or "")
        res["gl"] = m.group(1) if m else ("timeout" if not yt.stdout else "no-GL")
        info = subprocess.run(["curl", "-s", "-m", str(timeout), "-x", px,
                               "https://ipinfo.io/json"],
                              capture_output=True, text=True, errors="ignore")
        try:
            j = json.loads(info.stdout)
            res["ipinfo"], res["ip"] = j.get("country", "-"), j.get("ip", "-")
        except Exception:
            pass
    except Exception as e:
        res["gl"] = f"err:{type(e).__name__}"
    finally:
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception:
                pass
        os.unlink(cfg_path)
    return res


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sub", default="/root/sub.txt")
    ap.add_argument("--port", type=int, default=10801)
    ap.add_argument("--timeout", type=int, default=12)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--out", default="/root/geoscan.tsv")
    a = ap.parse_args()

    xray = find_xray()
    links = load_sub(a.sub)
    if a.limit:
        links = links[: a.limit]
    if not links:
        sys.exit(f"в {a.sub} не нашёл ни одной vless-ссылки")

    print(f"xray: {xray} · узлов: {len(links)} · порт проверки: {a.port}\n")
    print(f"{'GL':<9} {'ipinfo':<7} {'мс':>6}  узел")
    print("-" * 74)
    rows = []
    for i, link in enumerate(links, 1):
        r = probe(xray, link, a.port, a.timeout)
        rows.append(r)
        mark = "  <<< ГОДНЫЙ" if r["gl"] not in ("RU", "-", "timeout", "no-GL",
                                                 "xray-fail") and not r["gl"].startswith("err") else ""
        print(f"{r['gl']:<9} {r['ipinfo']:<7} {r['ms']:>6}  [{i}/{len(links)}] {r['name'][:38]}{mark}",
              flush=True)

    with open(a.out, "w", encoding="utf-8") as f:
        f.write("gl\tipinfo\tip\tms\tname\thost\n")
        for r in rows:
            f.write(f"{r['gl']}\t{r['ipinfo']}\t{r['ip']}\t{r['ms']}\t{r['name']}\t{r['host']}\n")

    good = [r for r in rows if r["gl"] not in ("RU",) and len(r["gl"]) == 2]
    lie = [r for r in rows if r["gl"] == "RU" and r["ipinfo"] not in ("RU", "-")]
    print("\n" + "=" * 74)
    print(f"проверено {len(rows)} · Google видит не-RU: {len(good)} · "
          f"врут (ipinfo не RU, а Google говорит RU): {len(lie)}")
    if good:
        good.sort(key=lambda r: r["ms"])
        print("\nбрать эти, по скорости:")
        for r in good[:5]:
            print(f"  GL={r['gl']} {r['ms']}мс  {r['name']}  ({r['host']})")
    else:
        print("\nни одного не-RU узла. Вариант: другой провайдер VPN "
              "или ZIZI_COOKIES / POT-провайдер.")
    print(f"\nтаблица: {a.out}")


if __name__ == "__main__":
    main()
