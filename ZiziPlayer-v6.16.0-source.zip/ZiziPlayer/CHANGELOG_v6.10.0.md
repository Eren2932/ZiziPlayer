# ZiziPlayer 6.10.0 — «ZiziResolve»

versionCode 23 · versionName 6.10.0

## Почему эта версия существует

Полная диагностика 6.9.4, один прогон, один трек `fBM-Ld2YyRw`:

```
ANDROID_VR     @ www.youtube.com → [app-id] LOGIN_REQUIRED · форматов 0
IOS            @ www.youtube.com → [app-id] LOGIN_REQUIRED · форматов 0
IOS_MUSIC      @ www.youtube.com → [app-id] LOGIN_REQUIRED · форматов 0
ANDROID_MUSIC  @ www.youtube.com → [app-id] LOGIN_REQUIRED · форматов 0
MWEB           @ www.youtube.com → [web-id] LOGIN_REQUIRED · форматов 0
WEB_REMIX      @ music.youtube.com → [web-id] LOGIN_REQUIRED · форматов 0
TVHTML5        @ www.youtube.com → [web-id] ERROR · форматов 0
WEB_EMBEDDED   @ www.youtube.com → [web-id] ERROR · форматов 0
```

Восемь клиентов, оба семейства хостов, живой poToken (166 симв., `via scramble+97`).
Отказ у всех. Это не ошибка разбора ответа — это аттестация на входе, и APK, который
Google не подписывал, её не проходит в принципе.

Тот же трек, тот же час, запрос с VPS:

```
https://rr4---sn-5hne6nz6.googlevideo.com/videoplayback?expire=1788024275
  &ip=147.45.166.244 &mime=audio/webm &clen=3071673 &dur=187.381 &c=VISIONOS
```

Разница не в коде и не в заголовках. Разница в том, **откуда задан вопрос**.
Поэтому резолв вынесен на сервер. Поиск остался на месте — он не ломался ни разу.

## Что изменилось в коде

| Файл | Изменение |
|---|---|
| `data/remote/ZiziResolve.kt` | **новый.** Клиент своего резолвера: `/resolve`, `/stream`, `/health`, два режима, отчёт для диагностики |
| `data/remote/InnertubeCatalog.kt` | `resolveStream` спрашивает сервер **первым и до минта токена**; лестница восьми клиентов осталась фолбэком. `streamReport` печатает строку `ZiziResolve @ host → …` перед клиентами |
| `data/SettingsStore.kt` | `resolverUrl`, `resolverToken`, `resolverProxy` (по умолчанию `true`) |
| `data/MusicRepository.kt` | три сеттера |
| `ui/MainViewModel.kt` | сеттеры + `probeResolver()` / `resolverStatus` |
| `ui/screens/Sheets.kt` | четыре строки в начале «Сетевого каталога»: адрес, токен, переключатель прокси, «Проверить сервер» |
| `ZiziApplication.kt` | адрес/токен/режим зеркалятся в `ZiziResolve` рядом с остальными playback-настройками |
| `AndroidManifest.xml` | `usesCleartextTraffic="true"` — резолвер живёт на `IP:8080` по http |
| `app/build.gradle.kts` | 22 → 23, 6.9.4 → 6.10.0 |

Остальные файлы не тронуты.

## Порядок в тракте

1. `ZiziResolve` настроен → спрашиваем сервер. Токен НЕ чеканится (экономия ~9 сек на трек).
2. Сервер отказал → в отчёт уходит его отказ, дальше старая лестница восьми клиентов.
3. Оба пути отказали → ошибка называет **оба**, а не «что-то пошло не так».

## Два режима

- **Гнать звук через сервер (по умолчанию, вкл.)** — `/stream`, сервер тянет байты с googlevideo
  и льёт их плееру, `Range` поддержан, перемотка живая. Снимает вопрос с тем, что ссылка
  чеканится под IP запросившего: телефон вообще не ходит к Google. TTL 12 ч — за перевыпуск
  отвечает сервер.
- **Выкл.** — прямая ссылка на googlevideo, трафик мимо VPS. Быстрее и бесплатнее, но работает
  только если 403 не прилетает. TTL 90 мин, с запасом к `expire`.

## Настройка после установки

Настройки → Сетевой каталог:

1. **Свой резолвер** → `147.45.166.244:8080`
2. **Токен резолвера** → тот, что напечатал установщик
3. **Проверить сервер** → ждём «сервер жив, кэш: N трек(ов)»
4. **Полная диагностика потока** → первая строка должна быть
   `ZiziResolve @ 147.45.166.244:8080 → OK · ZiziResolve /stream · audio/webm · 128 кбит/с · байты: HTTP 206 …`

Если строка `OK` — можно жать любой трек из поиска. Клиенты YouTube ниже пусть отказывают:
они теперь фолбэк, а не тракт.
