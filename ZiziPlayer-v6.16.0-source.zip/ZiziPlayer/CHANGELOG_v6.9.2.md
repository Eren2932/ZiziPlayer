# ZiziPlayer 6.9.2

Добавлена конфигурируемая сессионная интеграция через невидимый WebView.

Страница из `SESSION_BOOTSTRAP_URL` передаёт payload вызовом
`AndroidTokenBridge.postToken(payload)`. Payload хранится только в памяти процесса, ограничен по
размеру, не пишется в логи и принимается только пока главный frame находится на исходном HTTPS
origin. Переход главного frame на другой origin и mixed content блокируются.

Общий OkHttp-клиент теперь использует `SessionHeadersInterceptor`: он принудительно заменяет
`User-Agent` во всех запросах и добавляет payload только для allowlist из
`SESSION_PROTECTED_HOSTS`. Для защищённого хоста запрос ограниченно ждёт первичную загрузку WebView
и при отсутствии payload завершается локально, не отправляя неавторизованный запрос. На 401/403
payload инвалидируется и WebView запускается заново без автоматического повтора потенциально
неидемпотентного запроса.

Параметры сборки:

- `sessionBootstrapUrl` / `SESSION_BOOTSTRAP_URL` — абсолютный HTTPS URL страницы;
- `sessionProtectedHosts` / `SESSION_PROTECTED_HOSTS` — хосты через запятую, поддерживается `*.example.com`;
- `sessionTokenHeader` / `SESSION_TOKEN_HEADER` — имя заголовка, по умолчанию `X-Session-Payload`;
- `sessionUserAgent` / `SESSION_USER_AGENT` — единый UA WebView и OkHttp;
- `sessionTokenWaitMs` / `SESSION_TOKEN_WAIT_MS` — ожидание payload, по умолчанию 12000 мс.
