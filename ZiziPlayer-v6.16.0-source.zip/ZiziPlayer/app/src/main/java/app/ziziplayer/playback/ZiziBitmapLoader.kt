package app.ziziplayer.playback

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.data.remote.ZiziHttp
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.ListeningExecutorService
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import okhttp3.Request

/**
 * Artwork for the SYSTEM (notification shade, lock screen, media pill / island, car head units).
 *
 * v4 handed the system nothing but MediaMetadata.artworkUri, which is null for every track that
 * came from a user folder - that is why the shade showed a grey note icon. The loader walks a
 * chain instead: direct image -> embedded cover inside the audio file -> MediaStore thumbnail ->
 * a generated gradient with the first letter. The system therefore always receives a real bitmap.
 */
@UnstableApi
class ZiziBitmapLoader(private val context: Context) : BitmapLoader {

    private companion object {
        const val TARGET_PX = 512
    }

    private val executor: ListeningExecutorService = MoreExecutors.listeningDecorator(
        Executors.newSingleThreadExecutor { r -> Thread(r, "zizi-artwork").apply { isDaemon = true } }
    )

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> =
        executor.submit(Callable<Bitmap> { decodeBytes(data) ?: throw IllegalArgumentException("Cannot decode bitmap") })

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> =
        executor.submit(Callable<Bitmap> { resolve(uri) ?: throw IllegalArgumentException("No artwork for $uri") })

    override fun loadBitmapFromMetadata(metadata: MediaMetadata): ListenableFuture<Bitmap> =
        executor.submit(Callable<Bitmap> {
            metadata.artworkData?.let { decodeBytes(it) }
                ?: metadata.artworkUri?.let { resolve(it) }
                ?: generate(metadata.title?.toString())
        })

    /** Network image, then direct image, then embedded cover, then MediaStore thumbnail. */
    private fun resolve(uri: Uri): Bitmap? =
        remoteImage(uri) ?: decodeStream(uri) ?: embedded(uri) ?: thumbnail(uri)

    /**
     * Cover art for network tracks.
     *
     * ContentResolver cannot open an http(s) URI, so without this branch every remote track showed
     * the generated letter tile in the shade and on the lock screen - the artwork was right there in
     * the metadata and simply never fetched. Same OkHttp client as everything else, so it reuses
     * the connection the catalogue already has open to that CDN.
     */
    private fun remoteImage(uri: Uri): Bitmap? {
        val scheme = uri.scheme ?: return null
        if (scheme != "http" && scheme != "https") return null
        return runCatching {
            val request = Request.Builder()
                .url(uri.toString())
                .header("User-Agent", ZiziHttp.USER_AGENT)
                .build()
            ZiziHttp.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                response.body?.bytes()?.let { decodeBytes(it) }
            }
        }.getOrNull()
    }

    private fun decodeBytes(data: ByteArray): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        BitmapFactory.decodeByteArray(data, 0, data.size, options)
    }.getOrNull()

    private fun decodeStream(uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }.getOrNull()

    private fun embedded(uri: Uri): Bitmap? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture?.let { decodeBytes(it) }
        } finally {
            runCatching { retriever.release() }
        }
    }.getOrNull()

    private fun thumbnail(uri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching { context.contentResolver.loadThumbnail(uri, Size(TARGET_PX, TARGET_PX), null) }.getOrNull()
    }

    private fun sampleSize(width: Int, height: Int): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / 2 >= TARGET_PX && h / 2 >= TARGET_PX) { w /= 2; h /= 2; sample *= 2 }
        return sample
    }

    /** Same visual language as the in-app placeholder, so the shade matches the player. */
    private fun generate(title: String?): Bitmap {
        val size = TARGET_PX
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val seed = (title ?: "Zizi").hashCode()
        val hue = (((seed % 360) + 360) % 360).toFloat()
        val top = Color.HSVToColor(floatArrayOf(hue, 0.52f, 0.44f))
        val bottom = Color.HSVToColor(floatArrayOf((hue + 38f) % 360f, 0.62f, 0.18f))
        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), background)
        val glyph = title?.trim()?.firstOrNull()?.uppercase() ?: "♪"
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            alpha = 232
            textSize = size * 0.44f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val baseline = size / 2f - (text.descent() + text.ascent()) / 2f
        canvas.drawText(glyph, size / 2f, baseline, text)
        return bitmap
    }
}
