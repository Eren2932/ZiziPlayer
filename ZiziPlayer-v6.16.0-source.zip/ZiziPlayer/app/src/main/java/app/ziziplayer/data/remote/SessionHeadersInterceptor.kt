package app.ziziplayer.data.remote

import app.ziziplayer.BuildConfig
import java.io.IOException
import java.util.Locale
import okhttp3.Interceptor
import okhttp3.Response

/** Immutable request policy shared by WebView, API calls and Media3's OkHttpDataSource. */
object SessionRequestPolicy {
    val userAgent: String = BuildConfig.SESSION_USER_AGENT
        .replace("\r", " ")
        .replace("\n", " ")
        .trim()
        .ifEmpty { "ZiziPlayer/${BuildConfig.VERSION_NAME} (Android)" }

    val tokenHeader: String = BuildConfig.SESSION_TOKEN_HEADER.trim()
        .takeIf { it.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+")) }
        ?: "X-Session-Payload"

    private val bootstrapHost: String? = runCatching {
        java.net.URI(BuildConfig.SESSION_BOOTSTRAP_URL).host?.lowercase(Locale.US)
    }.getOrNull()

    val protectedHosts: Set<String> = BuildConfig.SESSION_PROTECTED_HOSTS
        .split(',')
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.isNotEmpty() }
        .toMutableSet()
        .apply { if (isEmpty()) bootstrapHost?.let(::add) }

    val waitMs: Long = BuildConfig.SESSION_TOKEN_WAIT_MS.coerceIn(1_000L, 30_000L)

    fun protects(host: String): Boolean {
        val normalized = host.lowercase(Locale.US)
        return protectedHosts.any { rule ->
            rule == "*" || normalized == rule ||
                (rule.startsWith("*.") && normalized.endsWith(rule.removePrefix("*")))
        }
    }
}

/**
 * Enforces one User-Agent on every request and adds the in-memory payload only to allowlisted
 * hosts. If a protected request arrives before the WebView finishes, the OkHttp worker waits for
 * the configured bounded interval and then fails closed instead of leaking an unauthenticated call.
 */
class SessionHeadersInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val isProtected = SessionRequestPolicy.protects(original.url.host)
        val builder = original.newBuilder()
            // header(), not addHeader(): caller-provided values cannot bypass the policy.
            .header("User-Agent", SessionRequestPolicy.userAgent)

        if (isProtected) {
            val payload = SessionWebToken.await(SessionRequestPolicy.waitMs)
            builder.header(SessionRequestPolicy.tokenHeader, payload)
        } else {
            // Do not let an accidentally supplied session payload escape to third-party hosts.
            builder.removeHeader(SessionRequestPolicy.tokenHeader)
        }

        val response = chain.proceed(builder.build())
        if (isProtected && (response.code == 401 || response.code == 403)) {
            SessionWebToken.invalidate()
            SessionWebToken.start(force = true)
        }
        return response
    }
}
