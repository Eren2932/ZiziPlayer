package app.ziziplayer.data.remote

import org.json.JSONArray
import org.json.JSONObject

/*
 * Defensive JSON navigation, on org.json.
 *
 * WHY org.json AND NOT kotlinx.serialization. Innertube's response is not a schema, it is a tree
 * of renderers that changes shape without notice: the same list item arrives as
 * musicResponsiveListItemRenderer in one build and wrapped in one more layer in the next, and
 * fields appear and disappear between clients. A generated deserialiser turns every such change
 * into an exception on a required field - the app stops working entirely because one badge moved.
 * Path walking that returns null on anything unexpected turns the same change into one skipped
 * row. org.json also ships with Android, so it costs zero dependencies and zero build plugins.
 *
 * Every helper here returns null instead of throwing. That is the whole contract.
 */

/** Walks nested objects. Any missing or non-object link ends the walk with null. */
internal fun JSONObject?.node(vararg path: String): JSONObject? {
    var cur = this ?: return null
    for (key in path) cur = cur.optJSONObject(key) ?: return null
    return cur
}

internal fun JSONObject?.array(vararg path: String): JSONArray? {
    if (this == null || path.isEmpty()) return null
    val parent = if (path.size == 1) this else node(*path.copyOfRange(0, path.size - 1)) ?: return null
    return parent.optJSONArray(path.last())
}

/** Objects of an array, skipping anything that is not one. */
internal fun JSONArray?.items(): List<JSONObject> {
    val source = this ?: return emptyList()
    val out = ArrayList<JSONObject>(source.length())
    for (i in 0 until source.length()) source.optJSONObject(i)?.let { out.add(it) }
    return out
}

internal fun JSONObject?.str(vararg path: String): String? {
    if (this == null || path.isEmpty()) return null
    val parent = if (path.size == 1) this else node(*path.copyOfRange(0, path.size - 1)) ?: return null
    val value = parent.optString(path.last(), "")
    return if (value.isEmpty() || value == "null") null else value
}

internal fun JSONObject?.long(vararg path: String): Long? {
    if (this == null || path.isEmpty()) return null
    val parent = if (path.size == 1) this else node(*path.copyOfRange(0, path.size - 1)) ?: return null
    if (!parent.has(path.last())) return null
    // Innertube sends 64 bit numbers as strings often enough that optLong alone loses them.
    parent.opt(path.last())?.let { raw ->
        when (raw) {
            is Number -> return raw.toLong()
            is String -> return raw.toLongOrNull()
        }
    }
    return null
}

internal fun JSONObject?.bool(vararg path: String): Boolean? {
    if (this == null || path.isEmpty()) return null
    val parent = if (path.size == 1) this else node(*path.copyOfRange(0, path.size - 1)) ?: return null
    if (!parent.has(path.last())) return null
    return parent.optBoolean(path.last(), false)
}

/**
 * Innertube text: either `{ "simpleText": "..." }` or `{ "runs": [ { "text": "..." }, ... ] }`.
 * Both forms appear for the same field depending on the client, so both are handled in one place.
 */
internal fun JSONObject?.runs(vararg path: String): String? {
    val holder = (if (path.isEmpty()) this else node(*path)) ?: return null
    holder.str("simpleText")?.let { return it }
    val runs = holder.optJSONArray("runs").items()
    if (runs.isEmpty()) return null
    val joined = runs.joinToString("") { it.optString("text", "") }.trim()
    return joined.ifEmpty { null }
}

/**
 * Every object stored under [key], anywhere in the tree, in document order.
 *
 * This is what makes the parser survive a redesign: instead of quoting a 9-level path that
 * Innertube is free to re-nest, we ask for every `musicResponsiveListItemRenderer` in the payload.
 * Breadth first, so the order matches the order on screen. [limit] is a hard stop - a malicious or
 * pathological response must not be able to spin here.
 */
internal fun JSONObject.deepFind(key: String, limit: Int = 400): List<JSONObject> {
    val out = ArrayList<JSONObject>()
    val queue = ArrayDeque<Any>()
    queue.addLast(this)
    var visited = 0
    while (queue.isNotEmpty() && out.size < limit && visited < 20_000) {
        visited++
        when (val current = queue.removeFirst()) {
            is JSONObject -> {
                val keys = current.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val value = current.opt(k)
                    if (k == key && value is JSONObject) out.add(value)
                    else if (value is JSONObject || value is JSONArray) queue.addLast(value)
                }
            }
            is JSONArray -> {
                for (i in 0 until current.length()) {
                    val value = current.opt(i)
                    if (value is JSONObject || value is JSONArray) queue.addLast(value)
                }
            }
        }
    }
    return out
}

/** First string value stored under [key] anywhere in the tree. Used for continuation tokens. */
internal fun JSONObject.deepString(key: String): String? {
    val queue = ArrayDeque<Any>()
    queue.addLast(this)
    var visited = 0
    while (queue.isNotEmpty() && visited < 20_000) {
        visited++
        when (val current = queue.removeFirst()) {
            is JSONObject -> {
                val keys = current.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val value = current.opt(k)
                    if (k == key && value is String && value.isNotEmpty()) return value
                    if (value is JSONObject || value is JSONArray) queue.addLast(value)
                }
            }
            is JSONArray -> {
                for (i in 0 until current.length()) {
                    val value = current.opt(i)
                    if (value is JSONObject || value is JSONArray) queue.addLast(value)
                }
            }
        }
    }
    return null
}

/**
 * Largest thumbnail in a `thumbnails` array.
 *
 * Deliberately picks the biggest and lets the image loader downscale: YouTube's smallest variant is
 * 60x60 and looks like porridge on a 56 dp row at 3x density.
 */
internal fun JSONObject?.bestThumbnail(): String? {
    val list = this?.deepFind("thumbnail", limit = 8).orEmpty()
    var best: String? = null
    var bestArea = -1L
    val arrays = ArrayList<JSONArray>()
    this?.optJSONArray("thumbnails")?.let { arrays.add(it) }
    list.forEach { holder -> holder.optJSONArray("thumbnails")?.let { arrays.add(it) } }
    arrays.forEach { array ->
        array.items().forEach { entry ->
            val url = entry.str("url") ?: return@forEach
            val area = (entry.long("width") ?: 0L) * (entry.long("height") ?: 0L)
            if (area >= bestArea) { bestArea = area; best = url }
        }
    }
    return best
}
