package app.ziziplayer.data.remote

import android.net.Uri
import org.json.JSONObject

/**
 * Audius: the official, key-free, fully legal catalogue.
 *
 * It is here for three reasons, and only one of them is "more music":
 *
 *  1. **It is the control source.** When a track does not play, the question is always "is the
 *     extractor broken or is the pipeline broken". Audius answers a plain MP3 over a plain 302, so
 *     if it plays and Innertube does not, the fault is in the extractor - one bisection instead of
 *     a day of guessing.
 *  2. **It is the fallback.** Innertube is a private API; the day YouTube changes it, search is
 *     dead in every installed copy of the app until the parser is patched. This one keeps working.
 *  3. It is a genuinely decent phonk/electronic/hip-hop catalogue, which is most of what this
 *     library actually holds.
 *
 * The API is content-addressed and node-distributed: `api.audius.co` returns a list of healthy
 * hosts and the app picks one. That list is cached for the session - re-asking on every keystroke
 * would double the latency of the search field for nothing.
 */
class AudiusCatalog(private val appName: String = "ZiziPlayer") : RemoteCatalog {

    override val id: String = "audius"
    override val label: String = "Audius"

    private companion object {
        const val DISCOVERY = "https://api.audius.co"
        const val PAGE_SIZE = 25
        /** A storage node keeps serving a granted stream for a while; re-resolve well before that. */
        const val STREAM_TTL_MS = 20 * 60 * 1000L
    }

    @Volatile private var host: String? = null

    private suspend fun host(): String {
        host?.let { return it }
        val response = ZiziHttp.getJson(DISCOVERY)
        val hosts = response.optJSONArray("data")
        val picked = (0 until (hosts?.length() ?: 0))
            .mapNotNull { hosts?.optString(it) }
            .filter { it.startsWith("https://") }
            .randomOrNull()
            ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Audius не отдал список узлов")
        host = picked.trimEnd('/')
        return host!!
    }

    override suspend fun isUsable(): Boolean = runCatching { host() }.isSuccess

    private fun url(host: String, path: String, params: Map<String, String>): String {
        val builder = Uri.parse("$host$path").buildUpon()
        params.forEach { (k, v) -> builder.appendQueryParameter(k, v) }
        builder.appendQueryParameter("app_name", appName)
        return builder.build().toString()
    }

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        if (query.isBlank()) return SearchPage.EMPTY
        val host = host()
        val offset = pageToken?.toIntOrNull() ?: 0
        val params = mapOf(
            "query" to query,
            "limit" to PAGE_SIZE.toString(),
            "offset" to offset.toString()
        )
        val path = when (kind) {
            RemoteKind.PLAYLIST, RemoteKind.ALBUM -> "/v1/playlists/search"
            RemoteKind.ARTIST -> "/v1/users/search"
            else -> "/v1/tracks/search"
        }
        val response = ZiziHttp.getJson(url(host, path, params))
        val data = response.optJSONArray("data").items()
        val items: List<RemoteItem> = when (kind) {
            RemoteKind.PLAYLIST, RemoteKind.ALBUM -> data.mapNotNull { playlist(it)?.let(RemoteItem::Group) }
            RemoteKind.ARTIST -> data.mapNotNull { artist(it)?.let(RemoteItem::Group) }
            else -> data.mapNotNull { track(it)?.let(RemoteItem::Song) }
        }
        // Offset paging has no "is there more" flag: a short page is the end of the list.
        val next = if (items.size < PAGE_SIZE) null else (offset + PAGE_SIZE).toString()
        return SearchPage(items, next)
    }

    /** Audius has no suggest endpoint. An empty list is a valid answer, not a failure. */
    override suspend fun suggest(prefix: String): List<String> = emptyList()

    override suspend fun discover(): List<DiscoverShelf> {
        val host = host()
        val shelves = ArrayList<DiscoverShelf>(2)
        runCatching {
            val week = ZiziHttp.getJson(url(host, "/v1/tracks/trending", mapOf("time" to "week", "limit" to "20")))
            val items = week.optJSONArray("data").items().mapNotNull { track(it)?.let(RemoteItem::Song) }
            if (items.isNotEmpty()) shelves.add(DiscoverShelf("В тренде за неделю", items))
        }
        runCatching {
            val month = ZiziHttp.getJson(url(host, "/v1/tracks/trending", mapOf("time" to "month", "limit" to "20")))
            val items = month.optJSONArray("data").items().mapNotNull { track(it)?.let(RemoteItem::Song) }
            if (items.isNotEmpty()) shelves.add(DiscoverShelf("Набирает обороты", items))
        }
        if (shelves.isEmpty()) throw CatalogException(CatalogException.Reason.OFFLINE, "Audius недоступен")
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val host = host()
        val path = when (collection.kind) {
            RemoteKind.ARTIST -> "/v1/users/${collection.remoteId}/tracks"
            else -> "/v1/playlists/${collection.remoteId}/tracks"
        }
        val params = if (collection.kind == RemoteKind.ARTIST) mapOf("limit" to "50", "sort" to "plays") else emptyMap()
        val response = ZiziHttp.getJson(url(host, path, params))
        return response.optJSONArray("data").items().mapNotNull { track(it) }
    }

    /**
     * The stream endpoint answers 302 to a storage node. We hand back the endpoint itself and let
     * OkHttp follow the redirect: pre-resolving it would mean two round trips and a URL that is
     * already one hop staler by the time playback starts.
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val host = host()
        return StreamInfo(
            url = url(host, "/v1/tracks/$remoteId/stream", emptyMap()),
            mimeType = "audio/mpeg",
            bitrateKbps = 320,
            ttlMs = STREAM_TTL_MS
        )
    }

    private fun track(json: JSONObject): RemoteTrack? {
        val remoteId = json.str("id") ?: return null
        val title = json.str("title") ?: return null
        if (json.bool("is_streamable") == false) return null
        if (json.bool("is_delete") == true) return null
        val seconds = json.long("duration") ?: 0L
        return RemoteTrack(
            provider = id,
            remoteId = remoteId,
            title = title,
            artist = json.str("user", "name") ?: json.str("user", "handle") ?: "Неизвестный исполнитель",
            album = json.str("album_backlink", "playlist_name") ?: "",
            durationMs = seconds * 1000L,
            artworkUrl = json.str("artwork", "480x480")
                ?: json.str("artwork", "1000x1000")
                ?: json.str("artwork", "150x150")
        )
    }

    private fun playlist(json: JSONObject): RemoteCollection? {
        val remoteId = json.str("id") ?: json.str("playlist_id") ?: return null
        val title = json.str("playlist_name") ?: return null
        return RemoteCollection(
            provider = id,
            remoteId = remoteId,
            kind = if (json.bool("is_album") == true) RemoteKind.ALBUM else RemoteKind.PLAYLIST,
            title = title,
            subtitle = json.str("user", "name") ?: "",
            artworkUrl = json.str("artwork", "480x480") ?: json.str("artwork", "150x150")
        )
    }

    private fun artist(json: JSONObject): RemoteCollection? {
        val remoteId = json.str("id") ?: return null
        val title = json.str("name") ?: json.str("handle") ?: return null
        val followers = json.long("follower_count") ?: 0L
        return RemoteCollection(
            provider = id,
            remoteId = remoteId,
            kind = RemoteKind.ARTIST,
            title = title,
            subtitle = if (followers > 0) "$followers слушателей" else "",
            artworkUrl = json.str("profile_picture", "480x480") ?: json.str("profile_picture", "150x150")
        )
    }
}
