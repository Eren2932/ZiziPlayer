package app.ziziplayer.data.remote

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * The discover hub, on disk.
 *
 * The hub is the first thing the section shows and it used to be a network request every single
 * time: open Search, watch a spinner, wait for `FEmusic_explore` to come back over a mobile link.
 * The content itself changes maybe twice a day.
 *
 * So it is cached, and the cache is read **before** the network is touched:
 *
 *  - a snapshot exists -> the shelves are on screen in the time it takes to parse a few KB of JSON,
 *    with no spinner and no traffic at all;
 *  - the snapshot is younger than [FRESH_MS] -> the request is not made. This is the case that
 *    actually saves the server and the user's data plan, because opening Search is the single most
 *    frequent action in the app;
 *  - it is older -> the shelves stay on screen and the refresh happens behind them. The user never
 *    looks at a spinner over content that is already good enough;
 *  - the refresh fails -> the snapshot stays. Yesterday's hub beats an error strip, and offline the
 *    section stops being a dead end.
 *
 * Written by hand with `org.json` rather than a serialization library on purpose: the format has to
 * survive its own future, and the version gate plus "unreadable means absent" is the whole contract.
 * A bad, truncated or older-format file is not an error to report - it is simply no cache.
 *
 * It lives in `cacheDir`, so the OS may delete it under storage pressure and that costs one request.
 */
object HubCache {

    /** How long a snapshot is served without asking the network at all. */
    const val FRESH_MS: Long = 30L * 60 * 1000

    private const val VERSION = 1

    /** Guards against a snapshot ten times the size of a hub, e.g. a provider going haywire. */
    private const val MAX_BYTES = 512 * 1024

    data class Snapshot(val shelves: List<DiscoverShelf>, val savedAt: Long) {
        val ageMs: Long get() = (System.currentTimeMillis() - savedAt).coerceAtLeast(0L)
        val fresh: Boolean get() = ageMs < FRESH_MS
    }

    private fun file(context: Context, provider: String): File {
        val safe = provider.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "unknown" }
        return File(context.cacheDir, "hub-$safe.json")
    }

    fun read(context: Context, provider: String): Snapshot? = runCatching {
        val f = file(context, provider)
        if (!f.exists() || f.length() > MAX_BYTES) return null
        val root = JSONObject(f.readText())
        if (root.optInt("v") != VERSION || root.optString("provider") != provider) return null
        val shelvesJson = root.optJSONArray("shelves") ?: return null
        val shelves = ArrayList<DiscoverShelf>(shelvesJson.length())
        for (i in 0 until shelvesJson.length()) {
            val shelf = shelvesJson.optJSONObject(i) ?: continue
            val itemsJson = shelf.optJSONArray("items") ?: continue
            val items = ArrayList<RemoteItem>(itemsJson.length())
            for (j in 0 until itemsJson.length()) {
                items += readItem(itemsJson.optJSONObject(j) ?: continue) ?: continue
            }
            val title = shelf.optString("title")
            if (items.isNotEmpty() && title.isNotEmpty()) shelves += DiscoverShelf(title, items)
        }
        if (shelves.isEmpty()) null else Snapshot(shelves, root.optLong("at"))
    }.getOrNull()

    fun write(context: Context, provider: String, shelves: List<DiscoverShelf>) {
        runCatching {
            val root = JSONObject()
                .put("v", VERSION)
                .put("provider", provider)
                .put("at", System.currentTimeMillis())
            val arr = JSONArray()
            shelves.forEach { shelf ->
                val items = JSONArray()
                shelf.items.forEach { item -> items.put(writeItem(item)) }
                if (items.length() > 0) {
                    arr.put(JSONObject().put("title", shelf.title).put("items", items))
                }
            }
            root.put("shelves", arr)
            val text = root.toString()
            if (text.length <= MAX_BYTES) {
                // Written through a temp file: a process death mid-write would otherwise leave a
                // truncated snapshot, and while `read` survives that, it survives it by throwing
                // the whole hub away.
                val target = file(context, provider)
                val tmp = File(target.parentFile, target.name + ".tmp")
                tmp.writeText(text)
                if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
            }
        }
    }

    fun clear(context: Context) {
        runCatching {
            context.cacheDir.listFiles { f -> f.name.startsWith("hub-") }?.forEach { it.delete() }
        }
    }

    // ------------------------------------------------------------------ items

    private fun readItem(json: JSONObject): RemoteItem? {
        val provider = json.optString("p").ifEmpty { return null }
        val remoteId = json.optString("r").ifEmpty { return null }
        val title = json.optString("t").ifEmpty { return null }
        val art = json.optString("w").ifEmpty { null }
        return if (json.optString("k") == "track") {
            RemoteItem.Song(RemoteTrack(
                provider = provider,
                remoteId = remoteId,
                title = title,
                artist = json.optString("a"),
                album = json.optString("b"),
                durationMs = json.optLong("d"),
                artworkUrl = art,
                explicit = json.optBoolean("x")
            ))
        } else {
            val kind = runCatching { RemoteKind.valueOf(json.optString("k")) }.getOrNull() ?: return null
            if (kind == RemoteKind.TRACK) return null
            RemoteItem.Group(RemoteCollection(
                provider = provider,
                remoteId = remoteId,
                kind = kind,
                title = title,
                subtitle = json.optString("s"),
                artworkUrl = art
            ))
        }
    }

    private fun writeItem(item: RemoteItem): JSONObject = when (item) {
        is RemoteItem.Song -> with(item.track) { JSONObject()
            .put("k", "track")
            .put("p", provider)
            .put("r", remoteId)
            .put("t", title)
            .put("a", artist)
            .put("b", album)
            .put("d", durationMs)
            .put("w", artworkUrl ?: "")
            .put("x", explicit) }
        is RemoteItem.Group -> with(item.collection) { JSONObject()
            .put("k", kind.name)
            .put("p", provider)
            .put("r", remoteId)
            .put("t", title)
            .put("s", subtitle)
            .put("w", artworkUrl ?: "") }
    }
}
