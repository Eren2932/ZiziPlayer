package app.ziziplayer.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.theme.LocalPalette

/** The app's top level destinations. Two, because there are two, and inventing a third is padding. */
enum class ZiziTab(val label: String, val icon: ImageVector) {
    LIBRARY("Медиатека", Icons.Rounded.LibraryMusic),
    SEARCH("Поиск", Icons.Filled.Search)
}

val ZIZI_TABS: List<ZiziTab> = ZiziTab.values().toList()

val TAB_BAR_HEIGHT = 54.dp

/**
 * The bottom tab bar.
 *
 * Two tabs, not the reference's five. The reference has five because it has five products behind
 * them; this app has a local library and a network catalogue, and a bar padded out with three
 * disabled-looking destinations would be the clearest possible signal that the section was copied
 * rather than designed. It is trivially extensible - add an entry to [ZiziTab] - and the layout
 * divides the width evenly, so a third tab needs no other change.
 *
 * No Material NavigationBar: that component brings its own 80 dp height, its own indicator pill and
 * its own colour scheme, and overriding all three to match a palette that changes with the artwork
 * is more code than drawing two columns. This also keeps the bar at 54 dp - the reference is 56 -
 * instead of Material's 80, which matters on a 6 inch screen with a mini player above it.
 */
@Composable
fun ZiziTabBar(current: ZiziTab, onPick: (ZiziTab) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(TAB_BAR_HEIGHT)
            .background(p.surface.copy(alpha = 0.97f))
    ) {
        ZIZI_TABS.forEach { tab ->
            TabItem(
                tab = tab,
                selected = tab == current,
                accent = p.accent,
                idle = p.subtext,
                modifier = Modifier.weight(1f),
                onClick = { onPick(tab) }
            )
        }
    }
}

@Composable
private fun TabItem(
    tab: ZiziTab,
    selected: Boolean,
    accent: Color,
    idle: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    // Colour and weight are animated, position is not. A tab bar that moves its own icons when you
    // press them reads as unstable; the reference animates nothing but the tint, and it is right.
    val tint by animateColorAsState(
        targetValue = if (selected) accent else idle,
        animationSpec = tween(durationMillis = 160),
        label = "tabTint"
    )
    val emphasis by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(durationMillis = 160),
        label = "tabEmphasis"
    )
    Box(
        modifier
            .fillMaxHeight()
            .selectable(
                selected = selected,
                interactionSource = interaction,
                // No ripple. A full-width rectangular ripple on a 54 dp bar looks like a rendering
                // glitch, and the tint change is already the feedback.
                indication = null,
                role = Role.Tab,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(tab.icon, contentDescription = tab.label, tint = tint, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(3.dp))
            Text(
                tab.label,
                color = tint,
                fontSize = 10.5.sp,
                fontWeight = if (emphasis > 0.5f) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}
