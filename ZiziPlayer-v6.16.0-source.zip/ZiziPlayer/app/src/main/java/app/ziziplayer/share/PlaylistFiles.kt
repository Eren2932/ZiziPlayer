package app.ziziplayer.share

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * Android-обвязка вокруг [PlaylistShare]: файл на диске и чтение чужого файла.
 *
 * Вынесено из [PlaylistShare] специально — там чистая логика, которую можно читать и проверять без
 * эмулятора, здесь `Context`, `cacheDir` и `ContentResolver`. Смешивать их в одном файле означало бы,
 * что формат обмена больше нельзя проверить, не подняв Android.
 */
object PlaylistFiles {

    /** Должно совпадать с `android:authorities` и с `<cache-path>` в res/xml/file_paths.xml. */
    private const val DIR = "shared-playlists"
    private const val AUTHORITY_SUFFIX = ".files"
    private const val KEEP_MS = 24L * 60 * 60 * 1000

    private fun authority(context: Context) = context.packageName + AUTHORITY_SUFFIX

    /**
     * Пишет плейлист в кэш и возвращает `content://` ссылку для системной шторки.
     *
     * Кэш, а не внешняя память: файл нужен ровно на время отправки, разрешений не требует и
     * подчищается сам. Старьё старше суток удаляется здесь же — иначе папка растёт молча.
     */
    fun write(context: Context, payload: PlaylistShare.Payload): Uri? = runCatching {
        val dir = File(context.cacheDir, DIR).apply { mkdirs() }
        val deadline = System.currentTimeMillis() - KEEP_MS
        dir.listFiles()?.forEach { if (it.lastModified() < deadline) it.delete() }
        val file = File(dir, PlaylistShare.fileName(payload.name))
        file.writeText(PlaylistShare.encodeJson(payload))
        FileProvider.getUriForFile(context, authority(context), file)
    }.getOrNull()

    /**
     * Читает присланный файл с потолком [PlaylistShare.MAX_BYTES].
     *
     * Читается кусками в буфер фиксированного размера, а не `readBytes()`: на входе чужие данные, и
     * «плейлист» на 40 МБ не должен ронять приложение по памяти прежде, чем мы успеем сказать, что
     * это не плейлист. Один лишний байт сверх лимита — уже отказ.
     */
    fun read(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val buffer = ByteArray(PlaylistShare.MAX_BYTES + 1)
            var read = 0
            while (read < buffer.size) {
                val n = stream.read(buffer, read, buffer.size - read)
                if (n <= 0) break
                read += n
            }
            if (read > PlaylistShare.MAX_BYTES) null else String(buffer, 0, read)
        }
    }.getOrNull()
}
