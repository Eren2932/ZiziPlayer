package app.ziziplayer.playback

import android.net.Uri

/**
 * Our own address for a track that lives on the network: `zizi://<provider>/<remoteId>`.
 *
 * THIS IS THE LOAD BEARING DECISION OF THE WHOLE FEATURE, so it is worth being explicit about why.
 *
 * A YouTube stream URL is valid for about six hours and is tied to the IP that asked for it. The
 * obvious design - resolve the URL when the user taps a search result and put it in the MediaItem -
 * breaks in four separate ways, all of which are painful and none of which are obvious in testing:
 *
 *   1. Queueing an album means resolving 20 URLs before the first note plays: 20 round trips on
 *      the tap, and `setQueue` (which this project deliberately moved off the main thread to stop
 *      the "button feels slow" symptom) becomes a multi-second freeze again.
 *   2. Track 15 of the queue starts six hours later and 403s, with no way back to a fresh URL.
 *   3. The saved queue and the remembered "resume where you left off" position point at a URL that
 *      is dead by morning, so the feature silently stops working overnight.
 *   4. Any URL written into the database is stale garbage that grows forever.
 *
 * So the database, the queue, the media session and the playback memory only ever see this scheme.
 * The real address is produced by [StreamResolver] on the Media3 loading thread, at the moment the
 * stream is actually opened - and if it turns out to be expired, one retry re-resolves it. Nothing
 * upstream knows or cares.
 *
 * It doubles as the cache key: [CacheDataSource] sits ABOVE the resolver, so it keys entries by
 * this stable URI instead of by a googlevideo address that changes every time. Without that
 * ordering, every replay would re-download the track.
 */
object RemoteUri {

    const val SCHEME = "zizi"

    fun of(provider: String, remoteId: String): String =
        "$SCHEME://$provider/${Uri.encode(remoteId)}"

    fun isRemote(uri: Uri?): Boolean = uri?.scheme == SCHEME

    fun isRemote(uri: String?): Boolean = uri != null && uri.startsWith("$SCHEME://")

    /** provider to remoteId, or null when the URI is not one of ours. */
    fun parse(uri: Uri): Pair<String, String>? {
        if (!isRemote(uri)) return null
        val provider = uri.host?.takeIf { it.isNotEmpty() } ?: return null
        val remoteId = uri.pathSegments?.firstOrNull()?.takeIf { it.isNotEmpty() } ?: return null
        return provider to remoteId
    }
}
