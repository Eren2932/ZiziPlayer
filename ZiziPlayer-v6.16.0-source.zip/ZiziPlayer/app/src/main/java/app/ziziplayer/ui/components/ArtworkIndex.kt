package app.ziziplayer.ui.components

import android.content.Context
import java.util.Collections

/**
 * Persists what we already know about covers so the expensive probe is paid once per file, ever:
 * which tracks have no artwork at all, and the colours extracted from the ones that do.
 *
 * Writes are batched - v5 hit SharedPreferences once per discovered track while scrolling.
 */
internal class ArtworkIndex(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("zizi_artwork", Context.MODE_PRIVATE)
    private val colors = context.applicationContext.getSharedPreferences("zizi_art_colors", Context.MODE_PRIVATE)
    private val pendingNoArt = Collections.synchronizedSet(HashSet<String>())
    private val pendingColors = Collections.synchronizedMap(HashMap<String, String>())

    /**
     * THE REASON NETWORK COVERS STAYED GREY AFTER 6.7.0.
     *
     * 6.6.0 had no code path that could fetch a remote cover at all, so every network track fell
     * through the pipeline and was written here as "has no artwork" - and this file is persisted,
     * forever, by design. 6.7.0 then added the fetch and it never ran: the verdict from the
     * previous version was read back at startup and short circuited the load before the new branch
     * could be reached. The feature was correct and invisible, which is the worst kind of fixed.
     *
     * Two changes, and both are needed. The key is versioned, so the poisoned set is abandoned
     * rather than migrated - it holds no information worth keeping, only wrong answers about files
     * that will be re-probed in milliseconds. And remote ids (`r:<provider>:<id>`) are filtered on
     * the way in AND on the way out: "this track has no cover" is a fact about a FILE. For a
     * network row it is a fact about one HTTP request on one bad minute, and it has no business
     * being written to disk.
     */
    fun noArtIds(): Set<String> =
        (prefs.getStringSet(KEY_NO_ART, emptySet()) ?: emptySet()).filterNot { it.startsWith("r:") }.toSet()

    fun swatches(): Map<String, ArtSwatches> {
        val out = HashMap<String, ArtSwatches>()
        colors.all.forEach { (id, raw) ->
            ArtSwatches.unpack(raw as? String)?.let { out[id] = it }
        }
        return out
    }

    fun rememberNoArt(id: String) {
        if (id.startsWith("r:")) return
        pendingNoArt.add(id)
        if (pendingNoArt.size >= 16) flushNoArt()
    }

    fun rememberSwatches(id: String, swatches: ArtSwatches) {
        pendingColors[id] = swatches.pack()
        if (pendingColors.size >= 16) flushColors()
    }

    /** Called when a prefetch batch settles and when the app goes to the background. */
    fun flush() { flushNoArt(); flushColors() }

    private fun flushNoArt() {
        val snapshot = synchronized(pendingNoArt) { HashSet(pendingNoArt).also { pendingNoArt.clear() } }
        if (snapshot.isEmpty()) return
        val merged = HashSet(noArtIds())
        merged.addAll(snapshot)
        prefs.edit().putStringSet(KEY_NO_ART, merged).apply()
    }

    private fun flushColors() {
        val snapshot = synchronized(pendingColors) { HashMap(pendingColors).also { pendingColors.clear() } }
        if (snapshot.isEmpty()) return
        val editor = colors.edit()
        snapshot.forEach { (id, packed) -> editor.putString(id, packed) }
        editor.apply()
    }

    companion object {
        // Versioned: bumping this abandons a set of verdicts instead of migrating it. Cheap, and
        // the only way to undo a wrong answer that was written to disk on purpose.
        private const val KEY_NO_ART = "no_art_ids_v2"
    }
}
