package app.ziziplayer.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Where a row came from.
 *
 * Plain string constants rather than an enum with a TypeConverter, for one blunt reason: the
 * migration below has to declare `DEFAULT 'local'` at the SQL level, and the column Room expects
 * must match that byte for byte or the database refuses to open on every device that upgrades.
 * A converter adds a layer between those two facts for no benefit.
 */
object TrackSource {
    const val LOCAL = "local"
    const val REMOTE = "remote"
}

@Entity(
    tableName = "tracks",
    indices = [
        Index(value = ["uri"], unique = true),
        // Every library query filters on it, on every keystroke.
        Index(value = ["source"]),
        // One row per remote track, whatever path led to it. NULLs are distinct in SQLite, so all
        // local rows (provider = NULL) coexist happily under a unique index.
        Index(value = ["provider", "remoteId"], unique = true)
    ]
)
data class TrackEntity(
    /** Derived from the file, not from the provider row. See [TrackId]. */
    @PrimaryKey val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long,
    val artworkUri: String? = null,
    val sourceFolder: String = "Устройство",
    val dateAdded: Long = System.currentTimeMillis(),
    /**
     * Part of the identity, and the reason a rescan can skip re-reading tags: a file whose size is
     * unchanged has unchanged metadata.
     */
    @ColumnInfo(defaultValue = "0") val sizeBytes: Long = 0L,
    /**
     * The id this row would have had under the v6.2 scheme. Filled by the scanner and consumed
     * exactly once, by the one-shot remap in [MusicRepository]; null afterwards for new rows.
     */
    val legacyId: String? = null,
    /** [TrackSource.LOCAL] or [TrackSource.REMOTE]. */
    @ColumnInfo(defaultValue = TrackSource.LOCAL) val source: String = TrackSource.LOCAL,
    /** Catalogue id for remote rows, null for local ones. */
    val provider: String? = null,
    /** The provider's own id, needed to resolve a stream. */
    val remoteId: String? = null,
    /**
     * When the user chose to keep this remote track.
     *
     * This one nullable Long is what separates "я это слушал" from "это моё". Only saved remote
     * tracks appear in the library; the rest exist purely so the mini player, the queue and the
     * play counters can resolve an id, and they are swept later. Without the split, one evening of
     * poking at search would bury a hand-curated local library under hundreds of strangers.
     */
    val savedAt: Long? = null,
    /** Last time this row was played or returned by search. Drives the sweep of unsaved rows. */
    @ColumnInfo(defaultValue = "0") val lastSeenAt: Long = 0L
) {
    val isRemote: Boolean get() = source == TrackSource.REMOTE
}

/** A query the user actually ran, for the search hub's history list. */
@Entity(tableName = "search_history")
data class SearchQueryEntity(
    @PrimaryKey val query: String,
    val queriedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val trackId: String, val addedAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrackEntity(val playlistId: Long, val trackId: String, val position: Int)

/**
 * Связь «сборник из поиска -> мой плейлист» (6.16.0).
 *
 * Нужна ровно для двух вещей, и обе видны пользователю: галочка на альбоме/плейлисте, который он
 * уже добавлял, и повторное нажатие, которое этот плейлист убирает. Хранить связь в имени
 * плейлиста было бы дешевле на одну таблицу и дороже на всё остальное: имя человек переименует
 * в тот же вечер, и отметка отвалится.
 *
 * Строка живёт, пока жив плейлист: [MusicDao.unlinkPlaylist] вызывается при удалении, а
 * [MusicDao.pruneLinks] подчищает то, что удалили в обход (импорт, миграция, ручная правка).
 */
@Entity(tableName = "playlist_links")
data class PlaylistLinkEntity(
    /** "<provider>:<remoteId>" — то, чем сборник опознаётся в каталоге. */
    @PrimaryKey val collectionKey: String,
    val playlistId: Long,
    val title: String,
    /**
     * true — плейлист СОЗДАН из этого сборника, значит повторное нажатие вправе удалить его
     * целиком. false — пользователь добавил сборник в свой давний плейлист, и удалять чужое
     * приложение не имеет права: оттуда убираются только треки сборника.
     */
    val owned: Boolean = true,
    val linkedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "track_fx")
data class TrackFxEntity(
    @PrimaryKey val trackId: String,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val reverb: Int = 0
)

@Entity(tableName = "hidden")
data class HiddenEntity(@PrimaryKey val trackId: String, val hiddenAt: Long = System.currentTimeMillis())

@Entity(tableName = "play_stats")
data class PlayStatEntity(
    @PrimaryKey val trackId: String,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L
)

/** Projection used to show "N tracks" next to a playlist without loading its rows. */
data class PlaylistCount(val playlistId: Long, val total: Int)

/** Сумма длительностей плейлиста, считается тем же запросом, что и количество (6.16.0). */
data class PlaylistDuration(val playlistId: Long, val totalMs: Long)

/** То, что подпись под плейлистом показывает целиком: «12 треков · 48 мин». */
data class PlaylistMeta(val count: Int = 0, val totalMs: Long = 0L)
