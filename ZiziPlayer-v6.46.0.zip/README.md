# ZiziPlayer — Android 6.46.0

Нативный Android-плеер: Kotlin, Compose, Media3, Room/DataStore, локальная музыка, сетевой каталог и офлайн-файлы.

**Исходники-кандидат 6.46.0, versionCode 94. Это не готовый проверенный APK.** Правки полноэкранного/inline-текста и капсулы; восстановление вариантов поиска текста; приоритет аудио перед LRCLIB, корректная отмена резолвера, отложенный прогрев и локальные замеры запуска.

Отчёт: `RELEASE_v6.46.0.md`. Проверки телефона: `DEVICE_CHECKLIST_v6.46.0.md`. Логи и список команд: `verification/v6.46.0/`. Исторические документы не являются результатами проверки этой версии.

## Обновить публичное репо

Загрузить **только итоговый `ZiziPlayer-v6.46.0.zip`** в корень Eren2932/ZiziPlayer. Не загружать рядом промежуточный `work-in-progress` с тем же versionCode: workflow требует единственный максимальный код. Старые 6.44.0/6.45.0 можно оставить. Не распаковывать исходники поверх корня и не менять Desktop, current.json, подпись и секреты. Дождаться нового успешного Actions для нового коммита, затем проверить APK на телефоне.

## Локальная проверка

39 проверочных команд завершились успешно в the Computer; это статические проверки и запуск Java-ядер, не Android-сборка.

````bash
python tools/check_selftest.py
python tools/check_kotlin_syntax.py app/src
python tools/check_imports.py app/src/main
python tools/check_static_refs.py app/src/main
python tools/check_call_args.py app/src/main
# В подготовленном Android-окружении:
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug --stacktrace
````

Требования: Android SDK 36, Gradle 8.11.1, JDK 17. Как и в исходной базе, готовых gradlew/wrapper JAR нет; CI устанавливает Gradle отдельно. Новых зависимостей нет.

Переключатель: **Настройки → Оформление → Тексты автоматически**. Замеры: **Настройки → О приложении → Задержки воспроизведения**. Только локальные 128 событий, отправка по нажатию, без треков/URL/токенов.
