package app.ziziplayer.playback

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.PresetReverb
import android.os.Bundle
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.ziziplayer.MainActivity
import app.ziziplayer.data.PlaybackMemory
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    companion object {
        const val CMD_REVERB = "app.ziziplayer.SET_REVERB"
        const val CMD_SKIP_SILENCE = "app.ziziplayer.SKIP_SILENCE"
        /** The UI is dead while the screen is off, so the service is the only one who can save. */
        private const val PERSIST_INTERVAL_MS = 4_000L
        /**
         * 6.18.0. onPositionDiscontinuity прилетает на КАЖДЫЙ шаг перемотки: одно движение пальца
         * по полосе — это десятки коллбэков, и раньше каждый из них шёл в SharedPreferences.
         * Запись асинхронная, но не бесплатная: файл переписывается целиком и фоново fsync'ится.
         * Позиция нужна с точностью до секунды, поэтому чаще чем раз в 700 мс писать нечего.
         * Важные моменты (смена трека, уход в фон, смерть сервиса) сохраняются в обход порога.
         */
        private const val PERSIST_MIN_GAP_MS = 700L
    }

    private var session: MediaSession? = null
    private var reverb: PresetReverb? = null
    private var reverbPercent = 0
    private lateinit var memory: PlaybackMemory
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        memory = PlaybackMemory(this)

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            // 6.19.0: режим пробуждения теперь зависит от того, что играет.
            //
            // WAKE_MODE_NETWORK берёт не только CPU wake lock (без него процессор засыпает с
            // погашенным экраном и воспроизведение рвётся), но ещё и WifiLock. Для сетевого трека
            // это обязательно: без wifi-локи трек умирает через две минуты прогулки с телефоном в
            // кармане. Для локального файла это чистый вред — Wi-Fi держится включённым всё время,
            // пока играет музыка с диска, и сеть тут не нужна ни на байт.
            //
            // Стартуем с LOCAL и поднимаем до NETWORK ровно тогда, когда в текущем элементе стоит
            // zizi://-адрес. См. [updateWakeMode].
            .setWakeMode(C.WAKE_MODE_LOCAL)
            // zizi:// -> resolved URL -> cache -> OkHttp. Local files bypass all of it: see
            // ZiziDataSources for why the wrapper order is not interchangeable.
            .setMediaSourceFactory(ZiziDataSources.mediaSourceFactory(this))
            .setLoadControl(ZiziDataSources.loadControl())
            .build()

        updateWakeMode(player)

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { attachReverb(audioSessionId) }
            override fun onIsPlayingChanged(isPlaying: Boolean) { persistPosition(force = true) }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                persistPosition(force = true)
                updateWakeMode(player)
            }
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) { persistPosition() }
        })

        val callback = object : MediaSession.Callback {
            override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
                val base = super.onConnect(session, controller)
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(
                        base.availableSessionCommands.buildUpon()
                            .add(SessionCommand(CMD_REVERB, Bundle.EMPTY))
                            .add(SessionCommand(CMD_SKIP_SILENCE, Bundle.EMPTY))
                            .build()
                    )
                    .setAvailablePlayerCommands(base.availablePlayerCommands)
                    .build()
            }

            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                command: SessionCommand,
                args: Bundle
            ): ListenableFuture<SessionResult> {
                if (command.customAction == CMD_REVERB) {
                    setReverb(args.getInt("percent", 0))
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                if (command.customAction == CMD_SKIP_SILENCE) {
                    (session.player as? ExoPlayer)?.skipSilenceEnabled = args.getBoolean("enabled", false)
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                return super.onCustomCommand(session, controller, command, args)
            }
        }

        // Tapping the notification (or the island) must open the player, not a blank task.
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        session = MediaSession.Builder(this, player)
            .setCallback(callback)
            .setBitmapLoader(ZiziBitmapLoader(this))
            .setSessionActivity(openApp)
            .build()

        setMediaNotificationProvider(PromotedNotificationProvider(this))

        scope.launch {
            while (isActive) {
                delay(PERSIST_INTERVAL_MS)
                if (session?.player?.isPlaying == true) persistPosition()
            }
        }
    }

    /** Survives screen off, app switching and a service kill by the system. */
    private var lastPersistAt = 0L

    private fun persistPosition(force: Boolean = false) {
        val player = session?.player ?: return
        val id = player.currentMediaItem?.mediaId ?: return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPersistAt < PERSIST_MIN_GAP_MS) return
        lastPersistAt = now
        memory.save(id, player.currentPosition)
    }

    fun setReverb(percent: Int) { reverbPercent = percent.coerceIn(0, 100); updateReverb() }

    @Suppress("DEPRECATION")
    /**
     * Держит wifi-локу только под сетевой трек (6.19.0).
     *
     * Проверяется адрес текущего элемента, а не «есть ли в очереди сетевые треки»: очередь может
     * быть смешанной, и пока играет файл с диска, Wi-Fi незачем держать включённым даже если
     * следующий трек сетевой. На переходе метод позовут снова.
     *
     * CPU wake lock есть в обоих режимах — его терять нельзя ни на секунду, иначе музыка с диска
     * начнёт рваться с погашенным экраном.
     */
    private fun updateWakeMode(player: ExoPlayer) {
        val uri = player.currentMediaItem?.localConfiguration?.uri
        val needsNetwork = RemoteUri.isRemote(uri)
        player.setWakeMode(if (needsNetwork) C.WAKE_MODE_NETWORK else C.WAKE_MODE_LOCAL)
    }

    private fun attachReverb(audioSessionId: Int) {
        reverb?.release()
        // Needs MODIFY_AUDIO_SETTINGS: without it the constructor throws and reverb stays dead.
        reverb = runCatching { PresetReverb(0, audioSessionId) }.getOrNull()
        updateReverb()
    }

    @Suppress("DEPRECATION")
    private fun updateReverb() {
        reverb?.apply {
            preset = when {
                reverbPercent == 0 -> PresetReverb.PRESET_NONE
                reverbPercent < 25 -> PresetReverb.PRESET_SMALLROOM
                reverbPercent < 50 -> PresetReverb.PRESET_MEDIUMROOM
                reverbPercent < 75 -> PresetReverb.PRESET_LARGEROOM
                else -> PresetReverb.PRESET_LARGEHALL
            }
            enabled = reverbPercent > 0
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        persistPosition(force = true)
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        persistPosition(force = true)
        scope.cancel()
        // SimpleCache locks its directory; leaving it held would make the next service instance
        // throw on startup instead of opening the cache.
        StreamCache.release()
        reverb?.release(); reverb = null
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
