package app.ziziplayer.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.data.AppTheme
import app.ziziplayer.ui.theme.LocalBackdropBlend
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziPalette
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue
import androidx.media3.common.Player
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious

@Composable
fun PlayerScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onClose: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    val queue by vm.queue.collectAsStateWithLifecycle()
    val fx by vm.fx.collectAsStateWithLifecycle()
    val blend = LocalBackdropBlend.current
    val theme = state.settings.theme
    val tintEnabled = state.settings.accentFromArtwork

    /*
     * THE MISMATCH BUG, and why it was structural rather than a race to patch.
     *
     * The carousel is a pager over the QUEUE, so the cover on screen is `queue[page]`. The title
     * under it was read from `currentTrack`, i.e. from whatever the PLAYER says is playing. Two
     * independent sources for one statement: the instant they disagree - a fast flick whose settle
     * handler has not fired, an auto-advance that landed mid-gesture, a seek the controller latched
     * - the screen shows one cover and names a different track. A faster handshake could only
     * narrow that window; it could never close it.
     *
     * The pager state is hoisted here and the PAGE is now the single source of truth for
     * everything the screen SAYS. Cover and title are the same fact and cannot disagree by
     * construction, whatever the player is doing behind them.
     */
    val pagerState = rememberPagerState(
        initialPage = playback.currentIndex.coerceAtLeast(0)
    ) { queue.size }
    val shownTrack = queue.getOrNull(pagerState.currentPage) ?: currentTrack

    /** Palette of any queue page, from cached swatches only - never blocks a gesture. */
    fun paletteOf(track: TrackEntity?): ZiziPalette? {
        if (track == null || !tintEnabled) return null
        val swatches = ArtworkCache.peekSwatches(track) ?: return null
        return basePalette(theme).tintedWith(swatches).withAccent(swatches)
    }

    if (queue.isNotEmpty()) {
        PagerPlaybackSync(
            pagerState = pagerState,
            queueSize = queue.size,
            playerIndex = playback.currentIndex,
            onSettled = { page ->
                // Hold the backdrop on the colour the finger stopped on, so it cannot bounce back
                // to the previous cover while the player catches up.
                blend.hold(paletteOf(queue.getOrNull(page)))
                vm.seekToIndex(page)
            }
        )
        BackdropSwipeBlend(
            pagerState = pagerState,
            queue = queue,
            playerIndex = playback.currentIndex,
            theme = theme,
            tintEnabled = tintEnabled
        )
    }

    var showFx by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        PlayerHeader(
            // 6.8.0 said "ПАПКА НА УСТРОЙСТВЕ" over every track, including the ones streaming from
            // a CDN. A caption that is false for half the queue is worse than no caption: it sent
            // us looking for a local file that never existed.
            caption = if (shownTrack?.isRemote == true) "ПОТОК ИЗ СЕТИ" else "ПАПКА НА УСТРОЙСТВЕ",
            source = shownTrack?.sourceFolder ?: "ZIZI",
            onClose = onClose,
            onShare = { shownTrack?.let(onShare) }
        )

        Spacer(Modifier.height(6.dp))

        CoverCarousel(
            queue = queue,
            pagerState = pagerState,
            isPlaying = playback.isPlaying,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.weight(1f))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 22.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                // Scrolled, not truncated: this is the one screen whose whole job is to tell you
                // what is playing, and it was ending half the library in an ellipsis.
                MarqueeText(
                    text = shownTrack?.title ?: "Ничего не играет",
                    color = p.text,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                // The artist line stays static on purpose: two things moving under one cover is
                // restless, and the reference scrolls the title only.
                Text(
                    text = shownTrack?.artist ?: "—",
                    color = p.subtext,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(10.dp))
            val favorite = shownTrack != null && state.favoriteIds.contains(shownTrack.id)
            RoundIconButton(
                icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                tint = if (favorite) p.accent else p.text,
                background = p.chip.copy(alpha = 0.55f),
                size = 46,
                iconSize = 22,
                onClick = { shownTrack?.let { vm.toggleFavorite(it) } }
            )
            Spacer(Modifier.width(8.dp))
            RoundIconButton(
                icon = Icons.Filled.MoreVert,
                tint = p.text,
                background = p.chip.copy(alpha = 0.55f),
                size = 46,
                iconSize = 22,
                onClick = { if (shownTrack != null) showMenu = true }
            )
        }

        Spacer(Modifier.height(14.dp))

        val chipColors = remember(p.chip, p.text, p.accent, p.onAccent) {
            ChipColors(p.chip, p.text, p.accent, p.onAccent)
        }
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                val fxActive = fx.speed != 1f || fx.pitch != 1f || fx.reverb > 0
                PillChip(
                    label = if (fxActive) "×%.2f".format(fx.speed) else "Скорость и тон",
                    icon = Icons.Filled.Speed,
                    active = fxActive,
                    palette = chipColors,
                    onClick = { if (currentTrack != null) showFx = true }
                )
            }
            item {
                val left = playback.sleepMinutesLeft
                PillChip(
                    label = if (left != null) "Сон · $left мин" else "Таймер сна",
                    icon = Icons.Filled.Bedtime,
                    active = left != null,
                    palette = chipColors,
                    onClick = { showSleep = true }
                )
            }
            item {
                PillChip(
                    label = "В плейлист",
                    icon = Icons.Filled.PlaylistAdd,
                    active = false,
                    palette = chipColors,
                    onClick = { if (shownTrack != null) showPlaylists = true }
                )
            }
            item {
                PillChip(
                    label = "Папки",
                    icon = Icons.Filled.FolderOpen,
                    active = false,
                    palette = chipColors,
                    onClick = { vm.setFilter(LibraryFilter.FOLDERS); onClose() }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Isolated: the position updates twice per second and must not touch the rest of the screen.
        PlayerProgress(vm)

        Spacer(Modifier.height(6.dp))

        PlayerControls(
            isPlaying = playback.isPlaying,
            shuffle = playback.shuffle,
            repeatMode = playback.repeatMode,
            onShuffle = vm::toggleShuffle,
            onPrevious = vm::previous,
            onPlayPause = vm::playPause,
            onNext = vm::next,
            onRepeat = vm::cycleRepeat
        )

        Spacer(Modifier.height(10.dp))

        PlayerBottomBar(
            queueSize = queue.size,
            onQueue = { showQueue = true },
            onFolders = { vm.setFilter(LibraryFilter.FOLDERS); onClose() }
        )
    }

    // Sheets that talk ABOUT the track follow the page, like the title does. FX are the one
    // exception: they retune the audio, so they belong to whatever is actually audible.
    val track = shownTrack
    if (showFx && currentTrack != null) FxSheet(vm, currentTrack) { showFx = false }
    if (showSleep) SleepSheet(playback.sleepMinutesLeft, { vm.setSleepTimer(it); showSleep = false }) { showSleep = false }
    if (showQueue) QueueSheet(
        tracks = queue,
        currentTrackId = playback.currentTrackId,
        isPlaying = playback.isPlaying,
        onPick = { vm.seekToIndex(it) },
        onSaveAsPlaylist = { vm.saveQueueAsPlaylist("Очередь ${queue.size}"); showQueue = false },
        onDismiss = { showQueue = false }
    )
    if (showPlaylists && track != null) PlaylistPickerSheet(
        playlists = state.playlists,
        onPick = { vm.addToPlaylist(it, track.id); showPlaylists = false },
        onCreate = { vm.createPlaylist(it, listOf(track)); showPlaylists = false },
        onDismiss = { showPlaylists = false }
    )
    if (showMenu && track != null) TrackMenuSheet(
        favorite = state.favoriteIds.contains(track.id),
        plays = state.stats[track.id]?.playCount ?: 0,
        sleepMinutesLeft = playback.sleepMinutesLeft,
        track = track,
        inPlaylist = state.openPlaylist,
        onDismiss = { showMenu = false },
        onFx = { showMenu = false; showFx = true },
        onSleep = { showMenu = false; showSleep = true },
        onAddToPlaylist = { showMenu = false; showPlaylists = true },
        onRemoveFromPlaylist = {
            state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
            showMenu = false
        },
        onToggleFavorite = { vm.toggleFavorite(track); showMenu = false },
        onHide = { vm.removeFromApp(track); showMenu = false },
        onDeleteFile = { showMenu = false; confirmDelete = track },
        onShare = { onShare(track); showMenu = false }
    )
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Это действие нельзя отменить.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
}

@Composable
private fun PlayerHeader(caption: String, source: String, onClose: () -> Unit, onShare: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(
            icon = Icons.Filled.KeyboardArrowDown,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            iconSize = 30,
            onClick = onClose
        )
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                caption,
                color = p.subtext.copy(alpha = 0.85f),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp
            )
            Text(
                text = source,
                color = p.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
        RoundIconButton(
            icon = Icons.Filled.Share,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            iconSize = 22,
            onClick = onShare
        )
    }
}

/**
 * Cover carousel.
 *
 * Geometry is measured from the VK reference on a 1080 px screen: the paused cover is 808 px
 * (74.6 % of the width) and its neighbours peek out by 89 px. So the pager is laid out at the
 * PAUSED size and the playing state only scales the focused page up by 1.114 inside a
 * graphicsLayer. Nothing is re-measured when playback starts or stops, which is why the
 * transition cannot stutter, and the side covers become clearly visible on pause.
 */
/**
 * Keeps the pager and the player pointing at the same track, in both directions.
 *
 * What was wrong with the old handshake - two rules that fought each other:
 *
 *   - the settle handler compared the page against a `playback` object CAPTURED when the coroutine
 *     was launched. The effect was keyed on the pager and the queue size, so it never restarted on
 *     a track change: it was comparing against a stale index for the rest of the screen's life,
 *     and its "the player is already here" check silently stopped working;
 *   - the player-driven correction was DROPPED if it arrived while the pager was moving. That drop
 *     is the bug you can see: an auto-advance during a flick was thrown away, nothing ever
 *     re-aligned the pager afterwards, and the two stayed on different tracks - one cover, another
 *     name, a third song - until you tapped something.
 *
 * The rules now:
 *   1. a page only seeks if it differs from the LIVE player index, so a programmatic scroll can
 *      never come back as a seek and no "programmatic" flag is needed at all;
 *   2. a player change is never dropped - it WAITS for the finger to leave, then aligns;
 *   3. when both want to move at once the finger wins, because the finger is the user.
 */
@Composable
private fun PagerPlaybackSync(
    pagerState: PagerState,
    queueSize: Int,
    playerIndex: Int,
    onSettled: (Int) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val livePlayerIndex by rememberUpdatedState(playerIndex)
    val settle by rememberUpdatedState(onSettled)
    // The page the user asked for, until the player confirms it. -1 = nothing pending.
    var pending by remember { mutableIntStateOf(-1) }

    // Finger -> player. Settled means "not scrolling any more", taken from the scroll flag itself
    // rather than settledPage: a fast flick can retarget mid-fling, and only the flag is honest
    // about when the gesture is actually over.
    LaunchedEffect(pagerState, queueSize) {
        snapshotFlow { pagerState.isScrollInProgress to pagerState.currentPage }
            .filter { !it.first }
            .map { it.second }
            .distinctUntilChanged()
            .drop(1) // the page the screen opened on is not a swipe
            .collect { page ->
                if (page < 0 || page >= queueSize) return@collect
                if (page == livePlayerIndex) {
                    pending = -1
                    return@collect
                }
                pending = page
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                settle(page)
            }
    }

    // Player -> pager.
    LaunchedEffect(pagerState, queueSize, playerIndex) {
        if (playerIndex < 0 || playerIndex >= queueSize) return@LaunchedEffect
        if (pending == playerIndex) {
            // Our own swipe, coming back as confirmation.
            pending = -1
            return@LaunchedEffect
        }
        // Wait for the gesture instead of dropping the correction.
        snapshotFlow { pagerState.isScrollInProgress }.first { !it }
        // The settle handler above runs on the same frame the fling ends: give it right of way,
        // then check whether the user has meanwhile asked to be somewhere else entirely.
        delay(80)
        val asked = pending
        if (asked >= 0 && asked != playerIndex) return@LaunchedEffect
        if (pagerState.currentPage == playerIndex) return@LaunchedEffect
        pending = -1
        // More than two pages apart is a queue change, not a track change: animating through it
        // would fling covers past the user for no reason.
        if ((pagerState.currentPage - playerIndex).absoluteValue > 2) pagerState.scrollToPage(playerIndex)
        else pagerState.animateScrollToPage(playerIndex)
    }
}

/**
 * Mixes the incoming cover's colour into the backdrop while the finger is still on the screen.
 *
 * The distance is measured from the PLAYING page, not from the pager's own current page. The
 * backdrop's base ramp belongs to the playing track, so anchoring the mix anywhere else makes the
 * colour jump at the half-way point, where the pager flips `currentPage` and the offset changes
 * sign. Measured from the player, the fraction runs 0 -> 1 continuously across the whole gesture.
 *
 * The fraction goes straight into the blend, which reads it in the draw phase: a drag repaints one
 * gradient per frame and recomposes nothing.
 */
@Composable
private fun BackdropSwipeBlend(
    pagerState: PagerState,
    queue: List<TrackEntity>,
    playerIndex: Int,
    theme: AppTheme,
    tintEnabled: Boolean
) {
    val blend = LocalBackdropBlend.current
    // Recomposes when the DIRECTION of the drag changes - once or twice per gesture. The fraction
    // itself never passes through composition.
    val neighbour by remember(pagerState, queue, playerIndex) {
        derivedStateOf {
            if (playerIndex < 0 || playerIndex >= queue.size) return@derivedStateOf null
            val delta = pagerState.currentPage + pagerState.currentPageOffsetFraction - playerIndex
            if (delta.absoluteValue < 0.02f) null
            else queue.getOrNull(playerIndex + if (delta > 0f) 1 else -1)
        }
    }
    val swatches = rememberArtSwatches(neighbour, tintEnabled)
    val palette = remember(theme, swatches) {
        if (swatches == null) null else basePalette(theme).tintedWith(swatches).withAccent(swatches)
    }
    LaunchedEffect(pagerState, palette, playerIndex) {
        snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction - playerIndex }
            .collect { delta -> blend.drag(palette, delta.absoluteValue.coerceAtMost(1f)) }
    }
    // Leaving the player mid-gesture must not leave the backdrop held on a colour nobody asked for.
    DisposableEffect(Unit) { onDispose { blend.release() } }
}

@Composable
private fun CoverCarousel(
    queue: List<TrackEntity>,
    pagerState: PagerState,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    if (queue.isEmpty()) {
        BoxWithConstraints(modifier) {
            val size = maxWidth * 0.746f
            Box(
                Modifier
                    .size(maxWidth * 0.831f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                TrackArtwork(
                    track = null,
                    maxPx = ARTWORK_FULL_PX,
                    modifier = Modifier
                        .size(size)
                        .clip(RoundedCornerShape(size * 0.085f)),
                    glyphSize = 64,
                    allowSlow = true
                )
            }
        }
        return
    }

    // Playing/paused factor: animated as a plain Animatable and read only inside graphicsLayer, so
    // the whole transition happens in the draw phase without a single recomposition.
    val playFactor = remember { Animatable(if (isPlaying) 1f else 0f) }
    LaunchedEffect(isPlaying) {
        playFactor.animateTo(
            if (isPlaying) 1f else 0f,
            spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium)
        )
    }

    // Swiping covers is also a scroll: nothing expensive may start behind it.
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.isScrollInProgress }.collectLatest { scrolling ->
            while (scrolling) {
                ArtworkCache.markBusy()
                delay(120)
            }
        }
    }

    // The pager <-> player handshake now lives in PagerPlaybackSync, next to the screen that owns
    // the pager state. A view that both REPORTS a gesture and OBEYS a correction cannot keep the
    // two straight - that is how the cover and the title drifted apart in the first place.
    BoxWithConstraints(modifier) {
        val screenWidth = maxWidth
        val pausedCover = screenWidth * 0.746f
        val playingCover = screenWidth * 0.831f
        val sidePadding = (screenWidth - pausedCover) / 2
        val corner = pausedCover * 0.085f
        val shape = remember(corner) { RoundedCornerShape(corner) }

        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = sidePadding),
            pageSpacing = 17.dp,
            beyondViewportPageCount = 1,
            key = { index -> queue.getOrNull(index)?.id ?: index.toString() },
            modifier = Modifier
                .fillMaxWidth()
                .height(playingCover)
        ) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(pausedCover)
                        .graphicsLayer {
                            // Deferred reads: scroll offset and play factor only trigger a redraw.
                            val distance = ((pagerState.currentPage - page) +
                                pagerState.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            val focus = 1f - distance
                            val play = playFactor.value
                            val scale = lerp(0.94f, lerp(1f, 1.114f, play), focus)
                            scaleX = scale
                            scaleY = scale
                            // Paused: neighbours are clearly visible.
                            // Playing: neighbours are fully transparent AT REST and fade in
                            // proportionally to the swipe, so exactly one cover is on screen while
                            // the music plays without making the gesture feel unresponsive.
                            val drag = pagerState.currentPageOffsetFraction.absoluteValue.coerceIn(0f, 1f)
                            val neighbour = lerp(0.92f, 0.95f * drag, play)
                            alpha = lerp(neighbour, 1f, focus)
                        }
                        // 6.5: the accent-coloured drop shadow is GONE.
                        //
                        // `shadow(18.dp, ambientColor = accent, spotColor = accent)` painted a
                        // coloured halo around every cover and kept painting it on pause, at rest,
                        // in a screenshot. Nothing in the reference does that: the cover goes down
                        // as a plain rounded rectangle and the BACKDROP carries the colour, which
                        // is exactly what the Oklch ramp is for. Nothing replaces it - artwork-
                        // tinted elevation is the clearest tell that a machine picked the styling.
                        .clip(shape)
                ) {
                    TrackArtwork(
                        track = queue.getOrNull(page),
                        maxPx = ARTWORK_FULL_PX,
                        modifier = Modifier.fillMaxSize(),
                        glyphSize = 62,
                        // The player is the ONE place allowed to parse the file itself: three
                        // covers at a time, one after another, never during a list scroll.
                        allowSlow = true
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerProgress(vm: MainViewModel) {
    val p = LocalPalette.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var scrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }
    var releaseJob by remember { mutableStateOf<Job?>(null) }

    // The controller now falls back to the duration stored in our own database, so this is never
    // the bogus 1 ms that used to send a seek straight to the end of the track.
    val duration = progress.durationMs.coerceAtLeast(1L)
    val seekable = progress.durationMs > 0L
    val fraction = if (scrubbing) scrubFraction
    else (progress.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    val shownPosition = if (scrubbing) (scrubFraction * duration).toLong() else progress.positionMs

    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        ZiziSlider(
            fraction = fraction,
            accent = p.accent,
            inactive = p.chip,
            onScrubStart = { scrubbing = true; scrubFraction = fraction },
            onScrub = { scrubFraction = it },
            onScrubEnd = { value ->
                // Covers taps too: hold the thumb where the finger left it, no jump back.
                scrubbing = true
                scrubFraction = value
                if (seekable) vm.seekTo((value * duration).toLong())
                // The controller latches the new position for a second, so a short hold is enough.
                // The previous release is cancelled, otherwise overlapping gestures fought over it.
                releaseJob?.cancel()
                releaseJob = scope.launch { delay(260); scrubbing = false }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            Text(formatTime(shownPosition), color = p.subtext, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(
                "-" + formatTime((duration - shownPosition).coerceAtLeast(0)),
                color = p.subtext,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun PlayerControls(
    isPlaying: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    onShuffle: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit
) {
    val p = LocalPalette.current
    // 6.18.0: «перемешать» и «повторять» больше не material-глифы.
    //
    // Rounded-набор 6.2 снял острые стыки, но сам рисунок остался прежним: ломаные под 45° и
    // разная плотность линий рядом с крупным Play — тестер назвал это «палками», и он прав.
    // Теперь оба знака свои (см. ZiziIcons): один вес обводки на весь ряд, круглые торцы,
    // shuffle на кубических кривых, repeat — кольцо с разрывом. Индикаторная точка у
    // «повторять один» больше не нужна: внутри кольца стоит настоящая «1», а два индикатора
    // одного состояния — это шум.
    val idle = p.text.copy(alpha = 0.92f)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        RoundIconButton(
            icon = ZiziIcons.Shuffle,
            tint = if (shuffle) p.accent else idle,
            background = Color.Transparent,
            size = 48,
            iconSize = 23,
            onClick = onShuffle,
            active = shuffle
        )
        RoundIconButton(
            icon = Icons.Rounded.SkipPrevious,
            tint = p.text,
            background = Color.Transparent,
            size = 58,
            iconSize = 34,
            onClick = onPrevious
        )
        RoundIconButton(
            icon = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            tint = p.text,
            background = Color.Transparent,
            size = 74,
            iconSize = 52,
            onClick = onPlayPause
        )
        RoundIconButton(
            icon = Icons.Rounded.SkipNext,
            tint = p.text,
            background = Color.Transparent,
            size = 58,
            iconSize = 34,
            onClick = onNext
        )
        RoundIconButton(
            icon = if (repeatMode == Player.REPEAT_MODE_ONE) ZiziIcons.RepeatOne else ZiziIcons.Repeat,
            tint = if (repeatMode == Player.REPEAT_MODE_OFF) idle else p.accent,
            background = Color.Transparent,
            size = 48,
            iconSize = 23,
            onClick = onRepeat,
            active = repeatMode != Player.REPEAT_MODE_OFF
        )
    }
}

@Composable
private fun PlayerBottomBar(queueSize: Int, onQueue: () -> Unit, onFolders: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.22f))
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .clickable(onClick = onQueue)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.QueueMusic, null, tint = p.text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Очередь", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text("$queueSize", color = p.subtext, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Row(
            Modifier
                .weight(1f)
                .clickable(onClick = onFolders)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.FolderOpen, null, tint = p.text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Папки", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}
