#!/usr/bin/env python3
"""Compile and execute the production account gate, not a translated Python implementation."""
from pathlib import Path
import subprocess
import tempfile
R = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-account-') as out:
    sources = ['app/src/main/java/app/ziziplayer/account/AccountGate.java',
               'app/src/test/java/app/ziziplayer/account/AccountGateChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                    *[str(R / p) for p in sources]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.account.AccountGateChecks'], check=True)
