import app.ziziplayer.lyrics.LrcTimeline;
import app.ziziplayer.lyrics.LyricsMatchPolicy;
import app.ziziplayer.lyrics.LyricsLookupTrace;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Lyrics6611Checks {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        String title = "Raya (Ultra Slowed)", artist = "Zericxxn";
        check(LyricsMatchPolicy.identityMatches(title, artist, title, artist), "Exact Raya identity rejected");
        check(!LyricsMatchPolicy.requiresExactDuration(title, title), "No guest mismatch");
        check(LyricsMatchPolicy.textDurationMatches(130000, 130000), "Text rejected");
        check(LrcTimeline.durationMatches(130000, 130000), "Sync rejected");
        check(LrcTimeline.durationMatches(132000, 130000), "2s boundary");
        check(!LrcTimeline.durationMatches(132001, 130000), "2s + 1ms boundary");
        check(!LyricsMatchPolicy.identityMatches("Raya", artist, title, artist), "Do not steal Ultra Slowed lyrics for original");
        check(!LyricsMatchPolicy.identityMatches(title, "Raya", title, artist), "Wrong artist rejected");
        check(!LrcTimeline.durationMatches(0, 130000), "Unknown media duration is not sync");
        var lines = LrcTimeline.parse(Files.readString(Path.of(args[0])));
        check(lines.size() == 32, "Actual provider cue count");
        check(lines.get(0).timeMs == 1740, "First cue");
        check(lines.get(31).timeMs == 128530, "Last cue");
        check(lines.stream().allMatch(line -> line.words.isEmpty()), "Provider has line timings, not word timings");
        check(lines.get(31).timeMs <= 132000, "Repository timing-validity upper bound");
        check(LrcTimeline.activeIndex(lines, 0, 0) == -1, "At screenshot 0:00 lyric not started");
        check(LrcTimeline.activeIndex(lines, 1740, 0) == 0, "First lyric starts");
        check(LrcTimeline.activeIndex(lines, 4090, 0) == 1, "Repeated line still advances");
        LyricsLookupTrace trace = new LyricsLookupTrace();
        trace.add("first\nline\rtest");
        check(trace.render().equals("first line test"), "Newlines sanitized");
        for (int i = 0; i < 60; i++) trace.add("x".repeat(500));
        check(trace.render().split("\n").length == 48, "Bounded event count");
        check(trace.render().split("\n")[0].length() == 240, "Bounded event length");
        trace.count("identity"); trace.count("identity");
        check(trace.render().contains("identity: 2"), "Counters aggregate");
        for (int i = 0; i < 30; i++) trace.count("reason" + i);
        check(trace.render().split("\n").length == 64, "Bounded counter count");
        System.out.println("PASS: " + checks + " production Java assertions; Raya 32 cues, 1740..128530ms. Not Android/HTTP playback.");
    }
}
