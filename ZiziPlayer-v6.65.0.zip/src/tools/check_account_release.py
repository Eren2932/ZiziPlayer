"""Validate public Google configuration without printing any values or reading the keystore."""
import os
import re
import sys
from urllib.parse import urlsplit


def validate(account_url, web_client_id, signing_store):
    if not web_client_id:
        return []  # Email-only and guest builds remain supported.
    errors = []
    if not re.fullmatch(r'[0-9]+-[A-Za-z0-9_-]+\.apps\.googleusercontent\.com', web_client_id):
        errors.append('GOOGLE_WEB_CLIENT_ID must be a Web OAuth client ID without whitespace.')
    try:
        url = urlsplit(account_url)
        valid = (account_url == account_url.strip() and url.scheme == 'https' and url.hostname
                 and not url.username and not url.password and url.path in ('', '/')
                 and not url.query and not url.fragment)
    except ValueError:
        valid = False
    if not valid:
        errors.append('Google sign-in requires ACCOUNT_URL to be an HTTPS origin without path, query or credentials.')
    if not signing_store:
        errors.append('Google release requires the existing signing keystore; refusing silent debug-key fallback.')
    return errors


if __name__ == '__main__':
    errors = validate(os.getenv('ACCOUNT_URL', ''), os.getenv('GOOGLE_WEB_CLIENT_ID', ''),
                      os.getenv('SIGNING_STORE_FILE', ''))
    for error in errors:
        print('::error::' + error)
    if not errors:
        print('Account release configuration: OK (public configuration shape only; OAuth not contacted).')
    sys.exit(bool(errors))
