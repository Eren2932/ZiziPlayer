#!/usr/bin/env python3
"""Replay prior downloaded research fixtures. Not live network, query quality or APK testing.
Raw source responses are external: --evidence-dir must contain the probe-* files.
Copyrighted lyrics are neither printed nor saved into this report.
"""
import argparse
import asyncio
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lyrics_server'))
from core import Engine, Netease, OfficialDescription, Track

async def run(base):
    bindings=json.loads((Path(__file__).resolve().parents[1]/'lyrics_server/sources.json').read_text())
    results=[]
    for name,t,prefix,official in [
        ('target',Track('Senemene','Dali Dade',144000),'probe-netease',True),
        ('control',Track('Never Gonna Give You Up','Rick Astley',214018),'probe-netease-control',False)]:
        async def fetch(url,limit):
            f=('probe-youtube.html' if 'youtube.com' in url else prefix+('-search.json' if '/search/' in url else '-lyrics.json'))
            text=(base/f).read_text()
            if len(text.encode())>limit:raise ValueError('body limit')
            return text
        providers=[Netease(fetch)]
        if official:providers.append(OfficialDescription(fetch,bindings))
        r=await Engine(providers).lookup(t)
        d=r['document']
        results.append({'case':name,'title':t.title,'artist':t.artist,'status':r['status'],
                        'source':d['source'] if d else None,'plainLines':len([s for s in d['plainLyrics'].splitlines() if s.strip()]) if d else 0,
                        'syncLines':len(d['syncedLyrics'].splitlines()) if d else 0,'diagnostics':r['diagnostics']})
    assert results[0]['plainLines']==53 and results[0]['syncLines']==0
    assert results[1]['syncLines']>=2
    return {'scope':'offline replay of previously downloaded real responses; no live queries or audio timing verification', 'results':results}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evidence-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    a.out.write_text(json.dumps(asyncio.run(run(a.evidence_dir)),ensure_ascii=False,indent=2)+'\n')
