"""ASGI service. Run from this directory: uvicorn app:app --host 127.0.0.1 --port 8091.
Only HTTPS fixed-host GET upstreams. No audio/upload/admin APIs. Providers opt-in.
"""
import asyncio
import json
import os
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from core import Engine, HttpError, Netease, OfficialDescription, SourceError, Track, Unavailable

ALLOWED = {'music.163.com', 'www.youtube.com'}

class Transport:
    def __init__(self, client):
        self.client = client
        self.slots = asyncio.Semaphore(8)

    async def __call__(self, url, limit):
        u = urlsplit(url)
        if u.scheme != 'https' or u.hostname not in ALLOWED or u.username or u.password or u.port not in (None, 443) or u.fragment:
            raise SourceError('upstream URL rejected')
        async with self.slots:
            # Transport timeout bounds connect/stream; the provider deadline also bounds semaphore wait.
            async with asyncio.timeout(4):
                async with self.client.stream('GET', url, follow_redirects=False) as response:
                    if response.status_code != 200:
                        raise HttpError(response.status_code)
                    output = bytearray()
                    async for chunk in response.aiter_bytes():
                        output.extend(chunk)
                        if len(output) > limit:
                            raise SourceError('upstream body too large')
                    return output.decode('utf-8', errors='strict')

class Application:
    def __init__(self, engine=None):
        self.engine = engine
        self.client = None

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'lifespan':
            while True:
                event = await receive()
                if event['type'] == 'lifespan.startup':
                    try:
                        import httpx
                        self.client = httpx.AsyncClient(timeout=3.5, trust_env=False,
                            limits=httpx.Limits(max_connections=8, max_keepalive_connections=4),
                            headers={'User-Agent': 'ZiziLyrics/0.1 (https://github.com/Eren2932/ZiziPlayer)'})
                        fetch = Transport(self.client)
                        enabled = {x.strip() for x in os.getenv('ZIZI_LYRICS_SOURCES', '').split(',') if x.strip()}
                        if enabled - {'netease', 'official_description'}:
                            raise ValueError('unknown configured provider')
                        providers = []
                        if 'netease' in enabled:
                            providers.append(Netease(fetch))
                        if 'official_description' in enabled:
                            path = Path(os.getenv('ZIZI_LYRICS_BINDINGS', str(Path(__file__).with_name('sources.json'))))
                            providers.append(OfficialDescription(fetch, json.loads(path.read_text())))
                        self.engine = Engine(providers)
                        await send({'type': 'lifespan.startup.complete'})
                    except Exception:
                        if self.client:
                            await self.client.aclose()
                        await send({'type': 'lifespan.startup.failed', 'message': 'Lyrics configuration/dependency error'})
                        return
                elif event['type'] == 'lifespan.shutdown':
                    if self.client:
                        await self.client.aclose()
                    await send({'type': 'lifespan.shutdown.complete'})
                    return
        elif scope['type'] == 'http':
            await self.http(scope, receive, send)

    async def http(self, scope, receive, send):
        async def reply(status, body):
            raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
            await send({'type': 'http.response.start', 'status': status, 'headers': [
                (b'content-type', b'application/json; charset=utf-8'), (b'cache-control', b'no-store'),
                (b'content-length', str(len(raw)).encode())]})
            await send({'type': 'http.response.body', 'body': raw})
        if scope.get('method') != 'GET':
            return await reply(405, {'error': 'method_not_allowed'})
        if scope.get('path') == '/health':
            active = bool(self.engine and self.engine.providers)
            return await reply(200 if active else 503, {'service': 'ZiziLyrics', 'version': '0.1', 'configured': active})
        if scope.get('path') != '/v1/lyrics':
            return await reply(404, {'error': 'route_not_found'})
        try:
            raw = scope.get('query_string', b'')
            if len(raw) > 4096:
                raise ValueError('too long')
            q = parse_qs(raw.decode('utf-8', errors='strict'), max_num_fields=4, strict_parsing=True)
            if set(q) != {'title', 'artist', 'durationMs'} or any(len(v) != 1 for v in q.values()):
                raise ValueError('invalid fields')
            track = Track(q['title'][0], q['artist'][0], int(q['durationMs'][0]))
        except (ValueError, UnicodeError):
            return await reply(400, {'error': 'invalid_metadata'})
        if not self.engine:
            return await reply(503, {'error': 'not_ready'})
        # Cancel upstream work on a real client disconnect. Read-only GET: drain request events.
        async def disconnected():
            while (await receive())['type'] != 'http.disconnect':
                pass
        work = asyncio.create_task(self.engine.lookup(track))
        disconnect = asyncio.create_task(disconnected())
        try:
            done, _ = await asyncio.wait({work, disconnect}, return_when=asyncio.FIRST_COMPLETED)
            if disconnect in done:
                return
            result = await work
            await reply(200, result)  # "miss" is typed JSON, not a route's HTTP 404.
        except Unavailable:
            await reply(503, {'error': 'temporarily_unavailable'})
        finally:
            work.cancel()
            disconnect.cancel()
            await asyncio.gather(work, disconnect, return_exceptions=True)

app = Application()
