import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchmark import classify
from core import Track, lyric_document
T=Track('Synthetic Song','Test Artist',100000)
def response(raw):
    return {'schemaVersion':1,'status':'found','document':lyric_document(raw,T,T.title,T.artist,100000,'NetEase','')}
class BenchmarkTests(unittest.TestCase):
    def test_sync_is_reported_as_unverified_not_accuracy(self):
        r=classify(response('[00:01.00]first\n[00:02.00]second'),T)
        self.assertEqual(r['status'],'sync_returned_unverified');self.assertFalse(r['audioTimingVerified'])
    def test_plain(self):self.assertEqual(classify(response('synthetic plain'),T)['status'],'plain')
    def test_no_lyrics_content_in_report(self):
        r=classify(response('synthetic plain'),T)
        self.assertNotIn('synthetic plain',str(r));self.assertIn('textSha256',r)
    def test_miss(self):self.assertEqual(classify({'schemaVersion':1,'status':'miss','document':None},T)['status'],'miss')
    def test_wrong_identity_is_error(self):
        r=response('plain');r['document']['artistName']='someone else'
        with self.assertRaises(ValueError):classify(r,T)
    def test_infinite_duration_is_error(self):
        r=response('plain');r['document']['duration']=float('inf')
        with self.assertRaises(ValueError):classify(r,T)
    def test_bad_timing_is_error(self):
        r=response('plain');r['document']['syncedLyrics']='[90:00.000]first\n[91:00.000]second'
        with self.assertRaises(ValueError):classify(r,T)
    def test_bad_schema_is_error(self):
        with self.assertRaises(ValueError):classify([],T)
if __name__=='__main__':unittest.main()
