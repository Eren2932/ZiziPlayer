"""Offline synthetic regressions. These are NOT live catalogue coverage measurements."""
import asyncio
import json
from pathlib import Path
import sys
import unittest
from urllib.parse import parse_qs, urlsplit
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import Engine, HttpError, Netease, SourceError, Track, Unavailable, lyric_document

T = Track('Synthetic Song', 'Test Artist', 100000)
def song(i=1, title=T.title, artist=T.artist, duration=100000):
    return {'id':i,'name':title,'artists':[{'name':artist}],'duration':duration}
def search(songs):
    return json.dumps({'code':200,'result':{'songs':songs}})
def lyric(text='[00:01.00]synthetic first\n[00:02.00]synthetic second'):
    return json.dumps({'code':200,'lrc':{'lyric':text}})

class GeneralSearchTests(unittest.IsolatedAsyncioTestCase):
    async def test_qualified_query_precedes_title_only(self):
        calls=[]
        async def fetch(url, limit):
            calls.append(url)
            return search([song()]) if '/search/' in url else lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])
        self.assertEqual(parse_qs(urlsplit(calls[0]).query)['s'], [T.title+' '+T.artist])
        self.assertEqual(len(calls), 2)

    async def test_fallback_title_query_on_qualified_miss(self):
        calls=[]
        async def fetch(url,limit):
            calls.append(url)
            if '/search/' in url:
                return search([] if len(calls)==1 else [song()])
            return lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])
        self.assertEqual(parse_qs(urlsplit(calls[1]).query)['s'], [T.title])
        self.assertEqual(len(calls),3)

    async def test_first_page_namesakes_do_not_block_artist_fallback(self):
        calls=[]
        async def fetch(url,limit):
            calls.append(url)
            if '/search/' in url: return search([song(artist='Another Artist')] if len(calls)==1 else [song()])
            return lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])

    async def test_multilingual_metadata_is_encoded_and_matches(self):
        # Synthetic metadata, not twelve real songs found on the Internet.
        pairs=[('Проверка песни','Тестовый артист'),('Äänien yö','Öinen ääni'),
               ('Canción de prueba','Árbol'),('Şarkı denemesi','Örnek'),
               ('أغنية اختبار','فنان اختبار'),('测试歌曲','测试歌手'),
               ('試験曲','試験歌手'),('시험 노래','시험 가수'),
               ('Δοκιμή','Τραγουδιστής'),('Пісня тест','Виконавець'),
               ('Düýş synagy','Synagçy'),('Chanson essai','Étoile')]
        for title,artist in pairs:
            with self.subTest(title=title):
                t=Track(title,artist,100000)
                async def fetch(url,limit):
                    if '/search/' in url:
                        self.assertEqual(parse_qs(urlsplit(url).query)['s'],[title+' '+artist])
                        return search([song(title=title,artist=artist)])
                    return lyric()
                self.assertTrue((await Netease(fetch).lookup(t))['syncedLyrics'])

    async def test_duplicate_catalog_ids_do_not_waste_candidate_budget(self):
        calls=[]
        async def fetch(url,limit):
            if '/search/' in url: return search([song(),song(),song(2)])
            i=parse_qs(urlsplit(url).query)['id'][0];calls.append(i)
            return lyric('[00:00.00]作词 : synthetic') if i=='1' else lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])
        self.assertEqual(calls,['1','2'])

    async def test_plain_survives_second_candidate_error(self):
        async def fetch(url,limit):
            if '/search/' in url:return search([song(),song(2)])
            if parse_qs(urlsplit(url).query)['id']==['1']:return lyric('synthetic plain')
            raise HttpError(502)
        self.assertEqual((await Netease(fetch).lookup(T))['plainLyrics'],'synthetic plain')

    async def test_invalid_candidate_can_recover_to_next(self):
        async def fetch(url,limit):
            if '/search/' in url:return search([song(),song(2)])
            return '{broken' if parse_qs(urlsplit(url).query)['id']==['1'] else lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])

    async def test_error_and_empty_do_not_become_negative_cache(self):
        async def fetch(url,limit):
            if '/search/' in url:return search([song(),song(2)])
            if parse_qs(urlsplit(url).query)['id']==['1']:raise HttpError(502)
            return '{"code":200,"nolyric":true}'
        e=Engine([Netease(fetch)])
        with self.assertRaises(Unavailable):await e.lookup(T)
        self.assertFalse(e.cache)

    async def test_429_stops_catalog_requests_and_sets_backoff(self):
        calls=[]
        async def fetch(url,limit):
            calls.append(url)
            if '/search/' in url:return search([song(),song(2)])
            raise HttpError(429)
        e=Engine([Netease(fetch)],clock=lambda:0)
        with self.assertRaises(Unavailable):await e.lookup(T)
        self.assertEqual(len(calls),2);self.assertEqual(e.backoff['NetEase'],60)

    async def test_nearest_duration_is_tried_first(self):
        async def fetch(url,limit):
            if '/search/' in url:return search([song(1,duration=110000),song(2)])
            self.assertEqual(parse_qs(urlsplit(url).query)['id'],['2'])
            return lyric()
        self.assertTrue((await Netease(fetch).lookup(T))['syncedLyrics'])

    async def test_distant_duration_never_fetches_words(self):
        async def fetch(url,limit):
            self.assertIn('/search/',url)
            return search([song(duration=200000)])
        self.assertIsNone(await Netease(fetch).lookup(T))

    async def test_missing_duration_never_enables_sync(self):
        async def fetch(url,limit):return search([song()]) if '/search/' in url else lyric()
        d=await Netease(fetch).lookup(Track(T.title,T.artist,0))
        self.assertTrue(d['plainLyrics']);self.assertFalse(d['syncedLyrics'])

    async def test_two_lyric_request_budget(self):
        calls=[]
        async def fetch(url,limit):
            calls.append(url)
            if '/search/' in url:return search([song(i) for i in range(1,21)])
            return '{"code":200,"uncollected":true}'
        self.assertIsNone(await Netease(fetch).lookup(T));self.assertEqual(len(calls),3)

    async def test_unexpected_search_shape_is_error(self):
        for value in ['[]','null','{"code":200,"result":{}}']:
            async def fetch(url,limit):return value
            with self.subTest(value=value),self.assertRaises(SourceError):await Netease(fetch).lookup(T)

    async def test_cancel_propagates_out_of_candidate_loop(self):
        async def fetch(url,limit):
            if '/search/' in url:return search([song(),song(2)])
            raise asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):await Netease(fetch).lookup(T)

class PackagingAndTimingTests(unittest.TestCase):
    def test_repeated_timestamp_tags_degrade_without_tag_leak(self):
        d=lyric_document('[00:01.00][00:20.00]synthetic\n[00:30.00]next',T,T.title,T.artist,100000,'test','')
        self.assertFalse(d['syncedLyrics']);self.assertNotIn('[00:',d['plainLyrics'])
    def test_workflow_update_is_not_stale(self):
        root=Path(__file__).resolve().parents[2]
        self.assertEqual((root/'.github/workflows/build.yml').read_bytes(),(root/'repo-update/.github/workflows/build.yml').read_bytes())
        self.assertIn('LYRICS_SERVER_URL:',(root/'repo-update/.github/workflows/build.yml').read_text())
    def test_equal_time_stamps_are_not_advertised_as_sync(self):
        d=lyric_document('[00:01.00]a\n[00:01.00]b',T,T.title,T.artist,100000,'test','')
        self.assertFalse(d['syncedLyrics'])

if __name__=='__main__':unittest.main()
