import asyncio
import hashlib
import json
from pathlib import Path
import sys
import unittest
from urllib.parse import urlencode
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import *
from app import Application, Transport

TRACK = Track('Synthetic Song', 'Test Artist', 100000)
def doc(sync=False):
    return {'syncedLyrics': '[00:01.000]synthetic\n[00:02.000]synthetic two' if sync else '',
            'plainLyrics': 'synthetic', 'source': 'fixture'}
class Provider:
    def __init__(self, name, result=None, error=None):
        self.id, self.result, self.error, self.calls = name, result, error, 0
    async def lookup(self, t):
        self.calls += 1
        if self.error:
            raise self.error
        return self.result

class PolicyTests(unittest.TestCase):
    def test_diacritics(self):
        self.assertTrue(same(Track('Senemene', 'Dali Dade', 144000), 'Senemene', 'Däli Däde'))
    def test_versions_not_stripped(self):
        self.assertFalse(same(TRACK, 'Synthetic Song (Slowed)', 'Test Artist'))
    def test_duration_boundary(self):
        self.assertTrue(tight(144000,146000)); self.assertFalse(tight(144000,146001))
    def test_unknown_not_synchronized(self):
        self.assertFalse(tight(0,100000))
    def test_bad_metadata(self):
        for d in (-1,86400001,True):
            with self.assertRaises(ValueError): Track('x','y',d)
    def test_credit_only(self):
        raw='[00:00.00-1] 作词 : synthetic\n[00:00.00-1] 作曲 : synthetic'
        self.assertIsNone(lyric_document(raw,TRACK,'Synthetic Song','Test Artist',100000,'test',''))
    def test_valid_lrc(self):
        d=lyric_document('[00:01.00]synthetic\n[00:02.00]next',TRACK,'Synthetic Song','Test Artist',100000,'test','')
        self.assertTrue(d['syncedLyrics'])
    def test_out_of_range_and_nonmonotonic_degrade(self):
        for raw in ['[00:02.00]a\n[00:01.00]b','[00:01.00]a\n[05:00.00]b']:
            self.assertFalse(lyric_document(raw,TRACK,'s','a',100000,'t','')['syncedLyrics'])
    def test_changed_duration_degrades(self):
        self.assertFalse(lyric_document('[00:01.00]a\n[00:02.00]b',TRACK,'s','a',105000,'t','')['syncedLyrics'])
    def test_offset_is_not_silently_ignored(self):
        d=lyric_document('[offset:500]\n[00:01.00]a\n[00:02.00]b',TRACK,'s','a',100000,'t','')
        self.assertFalse(d['syncedLyrics'])
    def test_placeholder_is_not_words(self):
        self.assertIsNone(lyric_document('[00:00.00]纯音乐，请欣赏',TRACK,'s','a',100000,'t',''))
    def test_html_rejected(self):
        with self.assertRaises(SourceError): lyric_document('<html>oops',TRACK,'s','a',100000,'t','')

class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def test_sync_beats_plain(self):
        e=Engine([Provider('plain',doc()),Provider('sync',doc(True))])
        self.assertTrue((await e.lookup(TRACK))['document']['syncedLyrics'])
    async def test_error_does_not_hide_plain(self):
        e=Engine([Provider('bad',error=SourceError()),Provider('plain',doc())])
        self.assertEqual((await e.lookup(TRACK))['status'],'found')
    async def test_all_miss(self):
        self.assertEqual((await Engine([Provider('empty')]).lookup(TRACK))['status'],'miss')
    async def test_error_is_not_miss_and_not_cached(self):
        p=Provider('bad',error=SourceError()); e=Engine([p])
        for _ in range(2):
            with self.assertRaises(Unavailable): await e.lookup(TRACK)
        self.assertEqual(p.calls,2); self.assertFalse(e.cache)
    async def test_backoff_is_per_source(self):
        now=[0]; a=Provider('limited',error=HttpError(429)); b=Provider('empty')
        e=Engine([a,b],clock=lambda:now[0])
        for t in [0,59,60]:
            now[0]=t
            with self.assertRaises(Unavailable): await e.lookup(TRACK)
        self.assertEqual(a.calls,2);self.assertEqual(b.calls,3)
    async def test_cached_plain_expires(self):
        now=[0]; p=Provider('plain',doc());e=Engine([p],clock=lambda:now[0])
        await e.lookup(TRACK);now[0]=299;await e.lookup(TRACK)
        self.assertEqual(p.calls,1);now[0]=300;await e.lookup(TRACK);self.assertEqual(p.calls,2)
    async def test_parent_cancel_cleans_up(self):
        stopped=asyncio.Event()
        class Waiting:
            id='waiting'
            async def lookup(self,t):
                try: await asyncio.sleep(100)
                finally: stopped.set()
        e=Engine([Waiting()]);task=asyncio.create_task(e.lookup(TRACK))
        await asyncio.sleep(.01);task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertTrue(stopped.is_set());self.assertFalse(e.inflight)
    async def test_timeout_not_miss(self):
        class Waiting:
            id='waiting'
            async def lookup(self,t):await asyncio.sleep(10)
        with self.assertRaises(Unavailable):await Engine([Waiting()],deadline=.01).lookup(TRACK)
    async def test_no_enabled_sources_is_error(self):
        with self.assertRaises(Unavailable):await Engine([]).lookup(TRACK)
    async def test_admission(self):
        e=Engine([Provider('test')]);e.inflight.add(TRACK)
        with self.assertRaises(Unavailable):await e.lookup(TRACK)

class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_netease_no_results(self):
        async def fetch(u,l):return '{"code":200,"result":{"songCount":0}}'
        self.assertIsNone(await Netease(fetch).lookup(TRACK))
    async def test_netease_wrong_version_does_not_fetch_lyric(self):
        calls=[]
        async def fetch(u,l):
            calls.append(u);return json.dumps({'code':200,'result':{'songs':[{'id':1,'name':'Synthetic Song (Remix)','artists':[{'name':'Test Artist'}],'duration':100000}]}})
        self.assertIsNone(await Netease(fetch).lookup(TRACK));self.assertEqual(len(calls),2)
    async def test_netease_full_route(self):
        async def fetch(u,l):
            if '/search/' in u:return json.dumps({'code':200,'result':{'songs':[{'id':1,'name':TRACK.title,'artists':[{'name':TRACK.artist}],'duration':100000}]}})
            return json.dumps({'code':200,'lrc':{'lyric':'[00:01.00]synthetic\n[00:02.00]next'}})
        self.assertTrue((await Netease(fetch).lookup(TRACK))['syncedLyrics'])
    async def test_official_binding_hash_and_owner(self):
        text='synthetic line\nsynthetic second line'
        binding={'title':TRACK.title,'artist':TRACK.artist,'durationMs':100000,'videoId':'abcdefghijk',
                 'videoTitle':'Test Artist - Synthetic Song','channelId':'channel',
                 'descriptionSha256':hashlib.sha256(text.encode()).hexdigest()}
        player={'videoDetails':{'videoId':'abcdefghijk','title':binding['videoTitle'],'channelId':'channel','lengthSeconds':'100','shortDescription':text}}
        owner={'videoOwnerRenderer':{'title':{'browseId':'channel'},'badges':[{'style':'BADGE_STYLE_TYPE_VERIFIED_ARTIST'}]}}
        async def fetch(u,l):return 'var ytInitialPlayerResponse = '+json.dumps(player)+';var ytInitialData = '+json.dumps(owner)+';'
        p=OfficialDescription(fetch,[binding]);self.assertEqual((await p.lookup(TRACK))['plainLyrics'],text)
        binding['descriptionSha256']='0'*64
        with self.assertRaises(SourceError):await p.lookup(TRACK)
        binding['descriptionSha256']=hashlib.sha256(text.encode()).hexdigest();owner['videoOwnerRenderer']['title']['browseId']='someoneelse'
        with self.assertRaises(SourceError):await p.lookup(TRACK)
    async def test_unbound_song_does_not_contact_youtube(self):
        async def fetch(u,l):self.fail('unexpected network')
        self.assertIsNone(await OfficialDescription(fetch,[]).lookup(TRACK))
    async def test_ssrf_rejected_before_transport(self):
        for url in ['http://music.163.com/a','https://127.0.0.1/x','https://www.youtube.com.evil/x','https://a:b@www.youtube.com/x']:
            with self.assertRaises(SourceError):await Transport(None)(url,100)

class HttpTests(unittest.IsolatedAsyncioTestCase):
    async def request(self, query, engine=None, path='/v1/lyrics'):
        app=Application(engine or Engine([Provider('plain',doc())]));output=[]
        async def receive():await asyncio.sleep(100)
        async def send(e):output.append(e)
        await app({'type':'http','method':'GET','path':path,'query_string':query},receive,send)
        return output[0]['status'],json.loads(output[1]['body'])
    async def test_api_shape(self):
        status,result=await self.request(urlencode({'title':TRACK.title,'artist':TRACK.artist,'durationMs':100000}).encode())
        self.assertEqual(status,200);self.assertEqual(result['schemaVersion'],1)
    async def test_bad_query(self):
        for q in [b'url=https://evil',b'title=a&artist=b&durationMs=nan',b'title=a&title=b&artist=c&durationMs=1']:
            status,_=await self.request(q);self.assertEqual(status,400)
    async def test_route_404_not_lyric_miss(self):
        status,_=await self.request(b'',path='/bad');self.assertEqual(status,404)
    async def test_error_503_not_404(self):
        status,_=await self.request(b'title=a&artist=b&durationMs=1',Engine([Provider('bad',error=SourceError())]))
        self.assertEqual(status,503)

if __name__=='__main__':unittest.main()
