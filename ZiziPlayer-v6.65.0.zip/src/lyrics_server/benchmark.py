#!/usr/bin/env python3
"""Measure a deployed ZiziLyrics server against YOUR CSV, without storing song words.
This is not the full Android pipeline: LRCLIB/OVH fallback and playback are not run.
Only statuses, metadata, content hashes, timing counts and latency are written.
Do not interpret returned timestamps as verified synchronization with the audio.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import time
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, Request
from core import Track, same, close, tight

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def classify(data, track):
    if not isinstance(data, dict) or data.get('schemaVersion') != 1:
        raise ValueError('schema')
    if data.get('status') == 'miss' and data.get('document') is None:
        return {'status':'miss'}
    d=data.get('document')
    if data.get('status') != 'found' or not isinstance(d,dict):
        raise ValueError('document')
    if not all(isinstance(d.get(k),str) for k in ('trackName','artistName','plainLyrics','syncedLyrics','source')):
        raise ValueError('fields')
    if not same(track,d['trackName'],d['artistName']):
        raise ValueError('wrong_identity')
    duration=d.get('duration')
    if type(duration) not in (int,float) or not 0 < duration <= 86400:
        raise ValueError('duration')
    duration=round(duration*1000)
    if not close(track.duration_ms,duration) or not d['plainLyrics'].strip():
        raise ValueError('unusable_document')
    sync=d['syncedLyrics']
    timestamps=[]
    if sync:
        for line in sync.splitlines():
            m=re.fullmatch(r'\[(\d{2,3}):([0-5]\d)\.(\d{3})\](.+)',line)
            if not m:raise ValueError('timing_format')
            timestamps.append(int(m[1])*60000+int(m[2])*1000+int(m[3]))
        if (d.get('timingProvenance') != 'provider_lrc' or len(timestamps)<2
                or not tight(track.duration_ms,duration)
                or any(t>duration+2000 for t in timestamps)
                or any(a>=b for a,b in zip(timestamps,timestamps[1:]))):
            raise ValueError('timing_validation')
    return {'status':'sync_returned_unverified' if sync else 'plain',
            'source':d['source'],'lineCount':len(d['plainLyrics'].splitlines()),
            'cueCount':len(timestamps),'textSha256':hashlib.sha256(d['plainLyrics'].encode()).hexdigest(),
            'audioTimingVerified':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--server',required=True,help='Your operator-configured HTTPS base URL')
    p.add_argument('--tracks',type=Path,required=True,help='UTF-8 CSV: title,artist,durationMs')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--allow-small',action='store_true',help='Allow fewer than 20 unique tracks; smoke test only')
    p.add_argument('--interval',type=float,default=1.0,help='Delay between requests, minimum one second')
    a=p.parse_args()
    u=urlsplit(a.server)
    if (u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment
            or u.port not in (None,443)):
        p.error('Use an HTTPS base URL without credentials/query/fragment, on port 443')
    if not 1<=a.interval<=60:p.error('interval must be 1..60 seconds')
    with a.tracks.open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if not 1<=len(rows)<=1000:p.error('Expected 1..1000 rows')
    tracks=[]
    try:
        for row in rows:
            t=Track(row['title'],row['artist'],int(row['durationMs']))
            if t not in tracks:tracks.append(t)
    except (ValueError,KeyError):p.error('Invalid title,artist,durationMs CSV')
    if len(tracks)<20 and not a.allow_small:p.error('Use at least 20 unique tracks, or --allow-small for a smoke test')
    opener=build_opener(NoRedirect())
    results=[]
    for i,t in enumerate(tracks):
        start=time.monotonic()
        item={'title':t.title,'artist':t.artist,'durationMs':t.duration_ms}
        url=a.server.rstrip('/')+'/v1/lyrics?'+urlencode({'title':t.title,'artist':t.artist,'durationMs':t.duration_ms})
        try:
            with opener.open(Request(url,headers={'Accept':'application/json','User-Agent':'ZiziLyrics-Coverage/0.1'}),timeout=10) as response:
                raw=response.read(512*1024+1)
                if len(raw)>512*1024:raise ValueError('body_limit')
                item.update(classify(json.loads(raw),t))
        except HTTPError as e:
            item.update(status='error',error='http_'+str(e.code))
        except Exception as e:
            # Never log bodies/URLs/headers or untrusted exception messages.
            item.update(status='error',error=type(e).__name__)
        item['latencyMs']=round((time.monotonic()-start)*1000)
        results.append(item)
        summary={k:sum(x['status']==k for x in results) for k in ('sync_returned_unverified','plain','miss','error')}
        summary.update(total=len(results),planned=len(tracks),
            textReturnPercent=round(100*(summary['sync_returned_unverified']+summary['plain'])/len(results),2),
            syncReturnPercent=round(100*summary['sync_returned_unverified']/len(results),2),
            medianLatencyMs=statistics.median(x['latencyMs'] for x in results))
        report={'scope':'deployed lyrics server only, NOT full Android hybrid or audio verification',
                'complete':len(results)==len(tracks),'summary':summary,'results':results}
        a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        print(f'{i+1}/{len(tracks)}: {item["status"]}')
        if i+1<len(tracks):time.sleep(a.interval)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
