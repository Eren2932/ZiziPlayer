"""ZiziLyrics experimental server 0.1. No audio, credentials or arbitrary URL input.
Transport is injected; endpoint access/licensing must be reviewed by the operator.
"""
import asyncio
from collections import OrderedDict
from dataclasses import dataclass
import hashlib
import json
import re
import time
import unicodedata
from urllib.parse import urlencode

class SourceError(Exception):
    pass

class HttpError(SourceError):
    def __init__(self, status):
        self.status = status
        super().__init__('upstream HTTP ' + str(status))

class Unavailable(SourceError):
    pass

@dataclass(frozen=True)
class Track:
    title: str
    artist: str
    duration_ms: int

    def __post_init__(self):
        for value in (self.title, self.artist):
            if not isinstance(value, str) or not value.strip() or len(value) > 160 or any(ord(c) < 32 for c in value):
                raise ValueError('invalid metadata')
        if type(self.duration_ms) is not int or not 0 <= self.duration_ms <= 86400000:
            raise ValueError('invalid duration')

def normalize(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', value).casefold()
                    if not unicodedata.combining(c))
    return ''.join(c for c in value if c.isalnum())

def same(track, title, artist):
    # No stripping slowed/live/remix/feat, no fuzzy nearest-song acceptance.
    return normalize(track.title) == normalize(title) and normalize(track.artist) == normalize(artist)

def tight(expected, actual):
    return expected > 0 and actual > 0 and abs(expected - actual) <= 2000

def close(expected, actual):
    return actual > 0 and (expected == 0 or abs(expected - actual) <= max(15000, expected // 10))

STAMP = re.compile(r'^\[(\d{1,3}):([0-5]\d)(?:[.:](\d{1,3}))?\](.*)$')
CREDIT = re.compile(r'^(?:作词|作曲|编曲|制作人|词|曲|lyrics\s+by|compos(?:er|ed\s+by)|written\s+by)\s*[:：]', re.I)

def lyric_document(raw, track, title, artist, duration, source, url):
    if not isinstance(raw, str) or len(raw) > 100000:
        raise SourceError('invalid lyrics body')
    if re.search(r'<(?:html|script|body|iframe)\b', raw, re.I):
        raise SourceError('HTML instead of lyrics')
    cues = []
    plain = []
    # Offset/enhanced tags need a dedicated parser; do not silently ignore their semantics.
    malformed_timing = bool(re.search(r"\[offset:|<\d{1,3}:\d{2}", raw, re.I))
    for line in raw.replace('\r', '').splitlines():
        line = line.strip()
        match = STAMP.match(line)
        if match:
            minute, second, fraction, text = match.groups()
            ms = int(minute) * 60000 + int(second) * 1000 + int(((fraction or '') + '000')[:3])
            text = text.strip()
            if text.startswith('['):
                malformed_timing = True
                text = re.sub(r'^(?:\[[^\]]*\]\s*)+', '', text)
            if text and not CREDIT.match(text):
                cues.append((ms, text))
                plain.append(text)
        else:
            # Includes observed [00:00.00-1] credit tags: strip only for content filtering,
            # NEVER reinterpret malformed tags as valid timestamps.
            text = re.sub(r'^\[[^\]]*\]\s*', '', line)
            if not text or CREDIT.match(text) or re.match(r'^\[(?:ar|ti|al|by|offset):', line, re.I):
                continue
            if line.startswith('['):
                malformed_timing = True
            plain.append(text)
    if not plain or all(x.strip() in {"纯音乐，请欣赏", "纯音乐，请欣赏。", "暂无歌词", "此歌曲为没有填词的纯音乐，请您欣赏", "Instrumental"} for x in plain):
        return None
    # Nonmonotonic, excessive or out-of-range tags cannot enable karaoke.
    valid = (len(cues) >= 2 and len(cues) == len(plain) and not malformed_timing
             and all(0 <= t <= duration + 2000 for t, _ in cues)
             and all(cues[i][0] < cues[i+1][0] for i in range(len(cues)-1)))
    synced = ''
    if valid and tight(track.duration_ms, duration):
        synced = '\n'.join(f'[{t//60000:02d}:{(t//1000)%60:02d}.{t%1000:03d}]{text}' for t, text in cues)
    return {'trackName': title, 'artistName': artist, 'duration': duration / 1000,
            'plainLyrics': '\n'.join(plain), 'syncedLyrics': synced, 'instrumental': False,
            'source': source, 'sourceUrl': url, 'matchVerified': True,
            'textProvenance': 'provider', 'timingProvenance': 'provider_lrc' if synced else 'none'}

class Netease:
    id = 'NetEase'
    def __init__(self, fetch):
        self.fetch = fetch

    async def lookup(self, track):
        # Artist-qualified search avoids spending the first page on namesakes.
        # Fall back to title-only for catalogues that index artist aliases poorly.
        candidates = []
        for query in dict.fromkeys((track.title + ' ' + track.artist, track.title)):
            url = 'https://music.163.com/api/search/get?' + urlencode(
                {'s': query, 'type': 1, 'limit': 20, 'offset': 0})
            data = json.loads(await self.fetch(url, 512*1024))
            if not isinstance(data, dict) or data.get('code') != 200 or not isinstance(data.get('result'), dict):
                raise SourceError('invalid search response')
            result = data['result']
            songs = result.get('songs', [])
            if not isinstance(songs, list) or ('songs' not in result and result.get('songCount') != 0):
                raise SourceError('invalid search results')
            seen = set()
            for song in songs[:20]:
                if not isinstance(song, dict):
                    continue
                title = song.get('name', '')
                artists = song.get('artists', [])
                if not isinstance(artists, list) or not all(isinstance(a, dict) and isinstance(a.get('name'), str) for a in artists):
                    continue
                artist = ' '.join(a['name'] for a in artists)
                duration = song.get('duration')
                song_id = song.get('id')
                if not isinstance(title, str) or type(duration) is not int or not 0 < duration <= 86400000:
                    continue
                if (same(track, title, artist) and close(track.duration_ms, duration)
                        and type(song_id) is int and song_id > 0 and song_id not in seen):
                    seen.add(song_id)
                    candidates.append((abs(track.duration_ms-duration), song_id, title, artist, duration))
            if candidates:
                break
        # Up to two search + two lyric requests, still within the provider deadline.
        best = None
        failure = None
        for _, song_id, title, artist, duration in sorted(candidates)[:2]:
            try:
                data = json.loads(await self.fetch('https://music.163.com/api/song/lyric?' + urlencode(
                    {'id': song_id, 'lv': -1, 'kv': -1, 'tv': -1}), 512*1024))
                if not isinstance(data, dict) or data.get('code') != 200:
                    raise SourceError('invalid lyric response')
                if data.get('nolyric') is True or data.get('uncollected') is True:
                    continue  # absence, NOT confirmed instrumental
                lrc = data.get('lrc')
                if not isinstance(lrc, dict) or not isinstance(lrc.get('lyric'), str):
                    raise SourceError('missing lyric field')
                doc = lyric_document(lrc['lyric'], track, title, artist, duration, self.id,
                                     'https://music.163.com/song?id=' + str(song_id))
            except HttpError as e:
                # Rate limiting belongs to the whole source, not one song ID.
                if e.status == 429:
                    raise
                failure = e
                continue
            except (SourceError, ValueError, TypeError) as e:
                failure = e
                continue
            if doc and doc['syncedLyrics']:
                return doc
            if doc and best is None:
                best = doc
        if best is None and failure is not None:
            raise SourceError('candidate lyrics unavailable') from failure
        return best


def embedded(html, name):
    m = re.search(r'(?:var\s+)?' + re.escape(name) + r'\s*=\s*', html)
    if not m:
        raise SourceError('page schema changed')
    try:
        return json.JSONDecoder().raw_decode(html[m.end():])[0]
    except (ValueError, RecursionError) as e:
        raise SourceError('invalid page metadata') from e


def nodes(obj):
    # Iterative traversal avoids recursion on untrusted page JSON.
    todo = [obj]
    visited = 0
    while todo:
        value = todo.pop()
        visited += 1
        if visited > 100000:
            raise SourceError('page tree too large')
        if isinstance(value, dict):
            yield value
            todo.extend(value.values())
        elif isinstance(value, list):
            todo.extend(value)

class OfficialDescription:
    id = 'Official description'
    def __init__(self, fetch, bindings):
        self.fetch = fetch
        # Operator-reviewed source references, never embedded lyric text.
        self.bindings = bindings

    async def lookup(self, track):
        binding = next((b for b in self.bindings if same(track, b['title'], b['artist'])
                        and tight(track.duration_ms, b['durationMs'])), None)
        if binding is None:
            return None
        vid = binding['videoId']
        if not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
            raise SourceError('invalid source binding')
        url = 'https://www.youtube.com/watch?' + urlencode({'v': vid})
        html = await self.fetch(url, 3*1024*1024)
        player = embedded(html, 'ytInitialPlayerResponse')
        initial = embedded(html, 'ytInitialData')
        v = player.get('videoDetails', {})
        if (v.get('videoId') != vid or v.get('channelId') != binding['channelId']
                or v.get('title') != binding['videoTitle']):
            raise SourceError('source identity changed')
        owners = [n['videoOwnerRenderer'] for n in nodes(initial) if 'videoOwnerRenderer' in n]
        verified = any(
            any(n.get('browseId') == binding['channelId'] for n in nodes(owner.get('title', {})))
            and any(n.get('style') == 'BADGE_STYLE_TYPE_VERIFIED_ARTIST' for n in nodes(owner.get('badges', [])))
            for owner in owners if isinstance(owner, dict))
        if not verified:
            raise SourceError('official owner not confirmed')
        duration = int(v.get('lengthSeconds', '0')) * 1000
        if not tight(track.duration_ms, duration):
            return None
        text = v.get('shortDescription')
        if not isinstance(text, str) or len(text) > 100000:
            raise SourceError('invalid description')
        if hashlib.sha256(text.encode()).hexdigest() != binding['descriptionSha256']:
            raise SourceError('description changed; operator review required')
        # Hash approval refers to this exact description; no AI guessing its boundaries.
        return {'trackName': binding['title'], 'artistName': binding['artist'], 'duration': duration/1000,
                'plainLyrics': text, 'syncedLyrics': '', 'instrumental': False,
                'source': self.id, 'sourceUrl': url, 'matchVerified': True,
                'textProvenance': 'reviewed_official_description', 'timingProvenance': 'none'}

class Engine:
    def __init__(self, providers, clock=time.monotonic, deadline=4.5):
        self.providers = providers
        self.clock = clock
        self.deadline = deadline
        self.cache = OrderedDict()
        self.backoff = {}
        self.inflight = set()

    async def lookup(self, track):
        cached = self.cache.get(track)
        if cached and cached[0] > self.clock():
            self.cache.move_to_end(track)
            return cached[1]
        self.cache.pop(track, None)
        if not self.providers:
            raise Unavailable('no enabled providers')
        # Nonblocking admission; bounded fanout, no unbounded request queue.
        if len(self.inflight) >= 4 or track in self.inflight:
            raise Unavailable('busy; retry later')
        self.inflight.add(track)
        async def run(provider):
            if self.backoff.get(provider.id, 0) > self.clock():
                return provider.id, 'backoff', None
            try:
                doc = await asyncio.wait_for(provider.lookup(track), self.deadline)
                return provider.id, 'found' if doc else 'miss', doc
            except asyncio.CancelledError:
                raise
            except HttpError as e:
                if e.status == 429:
                    self.backoff[provider.id] = self.clock() + 60
                return provider.id, 'http_' + str(e.status), None
            except Exception:
                return provider.id, 'error', None
        tasks = [asyncio.create_task(run(p)) for p in self.providers]
        try:
            results = await asyncio.gather(*tasks)
            docs = [doc for _, _, doc in results if doc]
            best = max(docs, key=lambda d: bool(d['syncedLyrics']), default=None)
            if best is None and any(status != 'miss' for _, status, _ in results):
                raise Unavailable('one or more providers unavailable')
            result = {'schemaVersion': 1, 'status': 'found' if best else 'miss', 'document': best,
                      'diagnostics': [{'provider': name, 'status': status} for name, status, _ in results]}
            ttl = 3600 if best and best['syncedLyrics'] else (300 if best else 30)
            self.cache[track] = (self.clock() + ttl, result)
            while len(self.cache) > 256:
                self.cache.popitem(last=False)
            return result
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self.inflight.discard(track)
