# ZiziPlayer 6.52.0 — Google-вход

Проверено по исходникам мобильной версии 6.51.0 из ветки main Eren2932/ZiziPlayer, полученным 15 сентября 2026. Новая поставка — 6.52.0 (102). На VPS ничего не менялось, Google Cloud из этого диалога не настраивался. Снятие SMTP-блокировки подтверждено пользователем, не отдельным сетевым тестом автора патча.

## Что создать в Google Cloud

Используй один Google Cloud-проект для обоих OAuth-клиентов. В Google Auth Platform / OAuth consent screen задай имя ZiziPlayer, контакт поддержки и аудиторию. Для общего приложения — External. Если проект находится в Testing, добавь свои Google-аккаунты в Test users, когда это предусмотрено настройками проекта. Для публичного запуска проверь Publishing status, требования к брендингу, домену, политике конфиденциальности и возможной верификации в самой консоли. Не запрашивай Drive, Gmail или YouTube scopes: здесь нужен только вход, не доступ к этим данным.

В Clients / Credentials создай OAuth client ID типа **Web application**. Сохрани его client ID. Для реализованного нативного ID-token flow не нужен redirect URI на VPS, JavaScript origin или client secret. Не придумывай /auth/google/callback: в приложении такого браузерного потока нет.

Создай второй OAuth client ID типа **Android**. Package name точно `app.ziziplayer`, SHA-1 — от сертификата подписи APK, который устанавливается на телефон. Сохрани Android client ID. SHA-1 не является паролем и не заменяет keystore.

**Не создавай новый ключ подписи приложения ради Google.** Используй существующий ключ GitHub Actions: замена ключа сломает обычную установку обновления поверх текущего APK. OAuth client ID и ключ подписи APK — разные сущности.

Для APK из GitHub Actions нужен SHA-1 release keystore этой сборки. Для APK, который Google Play переподписывает через Play App Signing, нужен SHA-1 **App signing certificate**, а не Upload certificate. Для отдельно тестируемой debug-подписи потребуется отдельная Android OAuth-регистрация. Текущий сервер принимает один дополнительный Android client ID в `azp`; не подставляй список через запятую — такая поддержка не реализована.

## Как получить правильный SHA-1

Новый workflow печатает SHA-1 и SHA-256 в шаге Verify signature, но для первичной настройки можно проверить уже выпущенный APK локально средствами Android SDK:

````bash
apksigner verify --print-certs ZiziPlayer-existing-release.apk
````

Или проверь существующий keystore. Пароль вводи интерактивно, не вставляй его в чат или строку команды:

````bash
keytool -list -v -keystore /path/to/existing-release.jks -alias YOUR_EXISTING_ALIAS
````

Скопируй именно SHA-1 сертификата подписанта, не SHA-256 файла APK. Если пользуешься только Actions и ещё не знаешь SHA-1, сначала собери тем же release-ключом с пустой GOOGLE_WEB_CLIENT_ID, забери отпечаток из Verify signature, затем добавь Google ID и пересобери.

## VPS: существующий env, не новый сервис

Штатный unit в проекте — `zizi-accounts.service`, он читает `/etc/zizi-accounts/accounts.env`. Если развёртывание было изменено вручную, сначала сверь `EnvironmentFile` в своём unit. Не публикуй содержимое env: там SMTP-пароль.

Отредактируй только две строки существующего env. Значения ниже — заглушки, их необходимо заменить:

````dotenv
ZIZI_GOOGLE_WEB_CLIENT_ID=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com
ZIZI_GOOGLE_ANDROID_CLIENT_ID=YOUR_ANDROID_CLIENT_ID.apps.googleusercontent.com
````

`ZIZI_GOOGLE_WEB_CLIENT_ID` задаёт ожидаемый `aud` Google ID token. `ZIZI_GOOGLE_ANDROID_CLIENT_ID` нужен для допустимого Android `azp`, если Google его выдаёт. Оба ID публичные; OAuth client secret этому коду не нужен.

Не меняй SMTP, RSA/JWT-ключи, базу аккаунтов, домен, nginx, музыкальный resolver и их токены. Не запускай установщик заново. Перезапусти существующий сервис:

````bash
sudo systemctl restart zizi-accounts
sudo systemctl is-active zizi-accounts
curl --fail --silent --show-error https://YOUR_EXISTING_ACCOUNT_HOST/auth/health
````

Ожидается `google_enabled: true`. Важно: это означает, что сервер создал verifier из конфигурации, **не** что Google уже принял package/SHA-1/client ID. Ошибочный непустой ID тоже может дать true — конечное доказательство только успешный вход из подписанного APK.

Если сервис перестал стартовать, смотри локально `sudo journalctl -u zizi-accounts -n 80 --no-pager`. Не отправляй секреты, токены, коды и полные env-файлы. Для восстановления email-only режима очисти две Google-переменные и перезапусти тот же сервис.

## GitHub Actions: Variables и Secrets

Settings → Secrets and variables → Actions → Variables:

| Variable | Значение |
|---|---|
| `ACCOUNT_URL` | Текущий HTTPS origin аккаунтов, без `/auth`, пути и query. Уже работающий адрес не меняй. |
| `GOOGLE_WEB_CLIENT_ID` | Точно тот же **Web** ID, что `ZIZI_GOOGLE_WEB_CLIENT_ID` на VPS. |

Android ID не передаётся в Variables или BuildConfig. Его связка package/SHA-1 регистрируется в Google Cloud, а сам ID прописывается на VPS для `azp`.

В Secrets остаются существующие `SIGNING_KEYSTORE_BASE64`, `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS`, `SIGNING_KEY_PASSWORD` и остальные секреты проекта. Client ID можно держать в Variables, это публичный идентификатор, он всё равно входит в APK. Ни client secret, ни SMTP-пароль, ни JWT private key в APK не нужны.

Перед сборкой необходимо обновить корневой `.github/workflows/build.yml`: workflow только внутри исходного ZIP GitHub Actions не исполняет. В этой поставке новая проверка останавливает Google-сборку при ошибочном формате Web ID, отсутствии HTTPS ACCOUNT_URL или отсутствии release keystore, вместо молчаливого перехода на debug-подпись. Это проверка формы параметров, не онлайн-проверка Google Cloud.

## Приёмка на телефоне

Сначала установи обновление поверх текущей версии, не удаляя приложение и его данные. Полноценный Gradle build и тесты JVM должны пройти в Actions до установки.

Проверь Google на входе и регистрации: открывается системный выбор Google-аккаунта, после выбора VPS выдаёт сессию ZiziPlayer, профиль показывает подтверждённый email. Отмена выбора не должна показывать ошибку и менять аккаунт. После временного отсутствия сети повторный тап должен повторить health-проверку без переоткрытия формы. Перезапуск приложения должен восстановить сессию; выход и выход со всех устройств — сохранить локальную медиатеку.

Ограничение текущего серверного кода: подтверждённый Gmail и Google Workspace допускаются; Google-аккаунт с внешней почтой без Workspace направляется на обычную регистрацию. Аккаунты с одинаковым email не связываются автоматически. Если почта уже зарегистрирована по паролю, нужно войти прежним способом. Это не лечится OAuth-ключами: для связывания нужен отдельный подтверждаемый пользователем flow. В этой поставке его нет.

Повтори рабочий почтовый цикл: регистрация → письмо → подтверждение → вход, неверный код, повторный код, забытый пароль, установка нового пароля. UI по-прежнему использует серверный длинный код (43 base64url-символа), а не выдуманные шесть цифр.

По интерфейсу проверь 100%, 130%, 200% системного шрифта, небольшой экран, клавиатуру, портрет/альбом, аппаратный Back и стрелку, свайд перехода при 60/120 Гц. На первом шаге Back закрывает форму; с пароля возвращает к почте. Пароли/коды не сохраняются при смене шага или уничтожении экрана. Поворот устройства может сбросить форму — намеренно не включено небезопасное сохранение секретов.

Нужно различать два результата: «подключена конфигурация» и «прошла живая авторизация». Только второй закрывает задачу Google-входа.
