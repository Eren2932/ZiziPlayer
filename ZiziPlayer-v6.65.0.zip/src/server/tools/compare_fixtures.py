#!/usr/bin/env python3
"""Сравнение 1.11 и 1.12 на наборе фикстур. Это НЕ живая выдача YouTube и не проверка аудио."""
import importlib.util, sys, types, tempfile, os
from unittest.mock import patch

def load(path, name):
    sys.path.insert(0, os.path.join(os.path.dirname(path), 'tools', '_stub'))
    sys.path.insert(0, os.path.dirname(path))
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

def cand(title, uploader, dur, vid='abcdefghijk'):
    return {'vid': vid, 'title': title, 'uploader': uploader, 'dur': dur}

CASES = [
  ("Love Lockdown (Album Version)", "Kanye West", 270,
   [cand('Kanye West - Love Lockdown', 'KanyeWestVEVO', 270)]),
  ("Heartless (Album Version)", "Kanye West", 211,
   [cand('Heartless', 'Kanye West - Topic', 211)]),
  ("Runaway (Explicit Version)", "Kanye West", 548,
   [cand('Kanye West - Runaway', 'Kanye West - Topic', 549)]),
  ("Blinding Lights", "The Weeknd", 200,
   [cand('The Weeknd - Blinding Lights (Official Video)', 'TheWeekndVEVO', 201)]),
  ("Smells Like Teen Spirit (2021 Remaster)", "Nirvana", 301,
   [cand('Nirvana - Smells Like Teen Spirit', 'NirvanaVEVO', 301)]),
  ("Sunflower (Single Version)", "Post Malone", 158,
   [cand('Post Malone - Sunflower', 'Post Malone - Topic', 160)]),
  ("Song", "Artist", 180, [cand('Other - Different Track', 'Other - Topic', 180)]),
  ("Song", "Artist", 180, [cand('Artist - Song (Karaoke)', 'Karaoke Channel', 180)]),
  ("Song", "Artist", 180, [cand('Artist - Song (Alice Remix)', 'Alice', 180)]),
  ("BACHI BACHI (Slowed + Reverb)", "Phonk", 200,
   [cand('BACHI BACHI (Slowed + Reverb)', 'Phonk - Topic', 200)]),
]

def run(mod, title, artist, dur, pool):
    with patch.object(mod, '_hunt', return_value=pool):
        try:
            r = mod.match_track(title, artist, dur)
            return ('strict/confident' if r.get('confident') else
                    'fallback' if r.get('fallback') else 'weak'), r['vid']
        except mod.HTTPException as e:
            return f'{e.status_code}', '-'

def main():
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True,
                        help='Path to original 1.11 server/zizi_catalog.py from mobile ZIP 6.48.1')
    parser.add_argument('--current', type=Path, default=Path(__file__).resolve().parents[1] / 'zizi_catalog.py')
    args = parser.parse_args()
    for label, path in (('1.11', args.baseline), ('1.12', args.current)):
        if not path.is_file():
            parser.error('Missing module: ' + str(path))
        print('=' * 78); print(label)
        m = load(str(path), 'cat_' + label.replace('.', '_'))
        for t, a, d, pool in CASES:
            with tempfile.TemporaryDirectory() as tmp:
                with patch.object(m, 'DB_PATH', tmp + '/c.db'):
                    out, _ = run(m, t, a, d, pool)
            print(f'  {out:18s} {t[:44]:46s} <- {pool[0]["title"][:34]}')

if __name__ == '__main__':
    main()
