#!/usr/bin/env python3
"""Retired 1.10 -> 1.11 installer. Never writes or downgrades a server."""

def main():
    raise SystemExit("Retired: this bundle contains 1.12-fallback-match, not the 1.11 payload. "
                     "Use server/tools/apply_fallback_update.py for a verified 1.11 -> 1.12 update. "
                     "If 1.12 is already deployed, no update is required. No files changed.")

if __name__ == '__main__':
    main()
