#!/usr/bin/env python3
"""The retired installer must fail closed and leave all targets untouched."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

class RetiredInstallerTests(unittest.TestCase):
    def test_never_writes_even_with_apply(self):
        script = Path(__file__).with_name('apply_strict_update.py')
        payload = script.parents[1] / 'zizi_catalog.py'
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'zizi_catalog.py'
            for content in (b'unknown fixture', payload.read_bytes()):
                for flags in ([], ['--apply']):
                    target.write_bytes(content)
                    result = subprocess.run([sys.executable, str(script), '--target', str(target), *flags],
                                            capture_output=True, text=True)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn('apply_fallback_update.py', result.stderr)
                    self.assertEqual(target.read_bytes(), content)
                    self.assertEqual(list(Path(directory).iterdir()), [target])

if __name__ == '__main__':
    unittest.main(verbosity=2)
