#!/usr/bin/env python3
"""Installer tests use temporary files only; no deployed server is touched."""
from pathlib import Path
import importlib.util
import sys
import tempfile
import unittest
from unittest.mock import patch

PATH = Path(__file__).with_name('apply_fallback_update.py')
spec = importlib.util.spec_from_file_location('installer', PATH)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.target=Path(self.tmp.name)/'zizi_catalog.py'
        self.target.write_bytes(b'old fixture\n')

    def run_installer(self, apply=False):
        args=['installer','--target',str(self.target)] + (['--apply'] if apply else [])
        with patch.object(sys,'argv',args): m.main()

    def test_dry_run_never_writes(self):
        with patch.object(m,'BASE_SHA256',m.digest(self.target.read_bytes())): self.run_installer()
        self.assertEqual(self.target.read_bytes(), b'old fixture\n')
        self.assertEqual(len(list(self.target.parent.iterdir())),1)

    def test_apply_backs_up_and_is_idempotent(self):
        with patch.object(m,'BASE_SHA256',m.digest(self.target.read_bytes())): self.run_installer(True)
        self.assertEqual(m.digest(self.target.read_bytes()), m.NEW_SHA256)
        backups=list(self.target.parent.glob('*.before-fallback-*'))
        self.assertEqual(len(backups),1); self.assertEqual(backups[0].read_bytes(),b'old fixture\n')
        self.run_installer(True)
        self.assertEqual(len(list(self.target.parent.iterdir())),2)

    def test_unknown_base_is_never_overwritten(self):
        with self.assertRaises(SystemExit): self.run_installer(True)
        self.assertEqual(self.target.read_bytes(), b'old fixture\n')

    def test_symlink_is_rejected(self):
        link=Path(self.tmp.name)/'link.py'; link.symlink_to(self.target)
        self.target=link
        with self.assertRaises(SystemExit): self.run_installer(True)

if __name__=='__main__': unittest.main(verbosity=2)
