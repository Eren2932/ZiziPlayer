#!/usr/bin/env python3
"""1.12-fallback-match: контракт запасного ответа.

Фикстуры, а не утверждения о реальной выдаче YouTube и тем более не доказательство того, что
аудио играет. Здесь проверяется ровно одно: отказ строгих ворот больше не равен тишине, и при
этом строгий кэш, строгий флаг и запрет на подмену версии остались нетронутыми.
"""
import sqlite3
import unittest
from contextlib import closing
from unittest.mock import patch
import test_strict_match as strict

candidate, c = strict.candidate, strict.c


class FallbackTests(unittest.TestCase):
    setUp = strict.StrictMatchTests.setUp
    match = strict.StrictMatchTests.match

    # ── то, ради чего всё затевалось ────────────────────────────────────────────────────────
    def test_album_version_is_matched_strictly_again(self):
        """Первопричина паузы: '(Album Version)' требовал слов «album» и «version» у кандидата."""
        for title in ('Kanye West - Love Lockdown', 'Love Lockdown (Official Audio)'):
            r = self.match([candidate(title, 'Kanye West - Topic', 270)],
                           title='Love Lockdown (Album Version)', artist='Kanye West', duration=270)
            self.assertTrue(r['confident'], title)
            self.assertTrue(r['strict'], title)
            self.assertFalse(r['fallback'], title)

    def test_neutral_qualifiers_do_not_weaken_the_version_gate(self):
        # Снимается только нейтральная скобка. Пометка версии остаётся обязательной в обе стороны.
        self.assertFalse(c.strict_candidate(candidate('Artist - Song (Alice Remix)', 'Artist', 180),
                                            'Song (Album Version)', 'Artist', 180))
        self.assertFalse(c.strict_candidate(candidate('Artist - Song', 'Artist', 180),
                                            'Song (Album Version) (Slowed)', 'Artist', 180))
        self.assertEqual(c._drop_neutral_qualifiers('Song (Original Mix)'), 'Song (Original Mix)')
        self.assertEqual(c._drop_neutral_qualifiers('Song (Album Version)').split(), ['Song'])
        self.assertEqual(c._drop_neutral_qualifiers('Song (2011 Digital Remaster)'),
                         'Song (2011 Digital Remaster)')  # remaster — это версия, а не издание

    def test_unproven_version_still_plays_instead_of_pausing(self):
        """Строгих доказательств нет (длительность гуляет), но это та же песня того же артиста."""
        r = self.match([candidate('Artist - Song', 'Artist', 195)], duration=180)
        self.assertTrue(r['fallback'])
        self.assertFalse(r['confident'])   # честно: доказательства версии нет
        self.assertFalse(r['strict'])
        self.assertTrue(r['vid'])          # но vid есть, и трек играет

    def test_strict_is_still_preferred_when_it_exists(self):
        r = self.match([candidate('Artist - Song (Remix)'), candidate('Artist - Song (Official Audio)')])
        self.assertTrue(r['confident']); self.assertTrue(r['strict']); self.assertFalse(r['fallback'])

    # ── изоляция кэшей ──────────────────────────────────────────────────────────────────────
    def test_fallback_lives_under_its_own_key_and_is_reused(self):
        first = self.match([candidate('Artist - Song', 'Artist', 195)])
        self.assertTrue(first['fallback']); self.assertFalse(first['cached'])
        self.assertNotEqual(first['key'], c.match_key('Song', 'Artist', 180, '', 'strict'))
        self.assertEqual(first['key'], c.match_key('Song', 'Artist', 180, '', 'fallback'))
        with patch.object(c, '_hunt', side_effect=AssertionError('запас обязан читаться из кэша')):
            again = c.match_track('Song', 'Artist', 180)
        self.assertTrue(again['cached']); self.assertTrue(again['fallback'])
        self.assertFalse(again['confident'])

    def test_fallback_expires_and_lets_a_strict_answer_win(self):
        """Запас не имеет права заморозить неточный выбор на неделю."""
        first = self.match([candidate('Artist - Song', 'Artist', 195)])
        self.assertTrue(first['fallback'])
        with closing(sqlite3.connect(self.db)) as db, db:  # состарили запас на семь часов
            db.execute('UPDATE match SET ts=ts-? WHERE key=?', (c.FALLBACK_TTL + 3600, first['key']))
        r = self.match([candidate('Artist - Song (Official Audio)')])
        self.assertTrue(r['confident']); self.assertTrue(r['strict']); self.assertFalse(r['fallback'])
        self.assertIsNotNone(c.cache_get(first['key']))            # строка жива
        self.assertIsNone(c.cache_get(first['key'], c.FALLBACK_TTL))  # но как запас уже не читается

    def test_stale_strict_miss_no_longer_buries_a_live_track(self):
        """Главная причина 6-часовых 'мёртвых' треков в 1.10/1.11."""
        c.miss_put(c.match_key('Song', 'Artist', 180, '', 'strict'), 'no confident match')
        r = self.match([candidate('Artist - Song (Official Audio)')])
        self.assertTrue(r['confident'])

    # ── границы запаса ──────────────────────────────────────────────────────────────────────
    def test_no_candidates_is_still_an_honest_404(self):
        with self.assertRaises(c.HTTPException) as ctx:
            self.match([])
        self.assertEqual(ctx.exception.status_code, 404)

    def test_unrequested_version_is_never_a_fallback(self):
        """Запас не подсовывает другую запись: karaoke, cover, live, remix — это не «та же песня»."""
        for wrong in ('Karaoke', 'Cover', 'Live', 'Alice Remix', 'Instrumental', 'Slowed'):
            with self.assertRaises(c.HTTPException) as ctx:
                self.match([candidate('Artist - Song (' + wrong + ')')])
            self.assertEqual(ctx.exception.status_code, 404, wrong)

    def test_requested_version_may_fall_back_to_the_original(self):
        """Обратное направление разрешено: просили Slowed, есть только оригинал — играем его."""
        r = self.match([candidate('Artist - Song', 'Artist', 180)], title='Song (Slowed)')
        self.assertTrue(r['fallback']); self.assertFalse(r['confident'])

    def test_same_duration_stranger_is_not_served(self):
        """Совпадение по одной длительности — не совпадение. Именно это ловили строгие ворота."""
        with self.assertRaises(c.HTTPException) as ctx:
            self.match([candidate('Other - Different Track', 'Other - Topic')])
        self.assertEqual(ctx.exception.status_code, 404)

    def test_artist_is_mandatory_even_in_fallback(self):
        with self.assertRaises(c.HTTPException) as ctx:
            self.match([candidate('Song', 'Random Channel', 195)])
        self.assertEqual(ctx.exception.status_code, 404)

    def test_incomplete_hunt_gives_503_and_caches_nothing(self):
        cands = c.HuntResults([candidate('Artist - Song', 'Artist', 195)]); cands.complete = False
        with patch.object(c, '_hunt', return_value=cands):
            with self.assertRaises(c.HTTPException) as ctx:
                c.match_track('Song', 'Artist', 180)
        self.assertEqual(ctx.exception.status_code, 503)
        self.assertIsNone(c.cache_get(c.match_key('Song', 'Artist', 180, '', 'fallback')))
        self.assertIsNone(c.miss_get(c.match_key('Song', 'Artist', 180, '', 'fallback')))

    def test_malformed_candidate_is_never_a_fallback(self):
        with self.assertRaises(c.HTTPException):
            self.match([None, {}, candidate(vid='bad')])

    # ── выключатель ─────────────────────────────────────────────────────────────────────────
    def test_switch_off_restores_111_behaviour(self):
        with patch.object(c, 'FALLBACK', False):
            with self.assertRaises(c.HTTPException) as ctx:
                self.match([candidate('Artist - Song', 'Artist', 195)])
        self.assertEqual(ctx.exception.status_code, 404)

    def test_explicit_weak_mode_is_untouched(self):
        r = self.match([candidate('Artist - Song (Remix)')], allow_weak=True)
        self.assertFalse(r['strict']); self.assertFalse(r['confident']); self.assertFalse(r['fallback'])
        self.assertEqual(r['key'], c.match_key('Song', 'Artist', 180, '', 'weak'))

    def test_key_helper_accepts_legacy_boolean(self):
        self.assertEqual(c.match_key('Song', 'Artist', 180, '', False),
                         c.match_key('Song', 'Artist', 180, '', 'strict'))
        self.assertEqual(c.match_key('Song', 'Artist', 180, '', True),
                         c.match_key('Song', 'Artist', 180, '', 'weak'))
        with self.assertRaises(ValueError):
            c.match_key('Song', 'Artist', 180, '', 'nonsense')


if __name__ == '__main__':
    unittest.main(verbosity=2)
