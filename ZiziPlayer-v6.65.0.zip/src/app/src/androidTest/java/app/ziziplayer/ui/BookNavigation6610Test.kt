package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import app.ziziplayer.ui.components.BookOverlayHost
import app.ziziplayer.ui.screens.WelcomeScreen
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Requires emulator/device: not executed by Python source checks. */
class BookNavigation6610Test {
    @get:Rule val compose = createComposeRule()

    @Test fun nextComesFromRightAndBackExactlyRetracesTheEdge() {
        var open by mutableStateOf(false)
        compose.setContent {
            BookOverlayHost(open = open, page = { Text("next") }) { Text("base") }
        }
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { open = true }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(96)
        val base = compose.onNodeWithTag("book-base", useUnmergedTree = true).fetchSemanticsNode()
        val page = compose.onNodeWithTag("book-page", useUnmergedTree = true).fetchSemanticsNode()
        assertTrue(base.positionInRoot.x < 0f)
        assertTrue(page.positionInRoot.x > 0f)
        assertEquals(base.positionInRoot.x + base.size.width, page.positionInRoot.x, 1f)
        compose.mainClock.advanceTimeBy(400)
        compose.onNodeWithText("next").assertIsDisplayed()
        compose.runOnIdle { open = false }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(96)
        val returning = compose.onNodeWithTag("book-base", useUnmergedTree = true).fetchSemanticsNode()
        val outgoing = compose.onNodeWithTag("book-page", useUnmergedTree = true).fetchSemanticsNode()
        assertTrue(returning.positionInRoot.x < 0f)
        assertTrue(outgoing.positionInRoot.x > 0f)
        assertEquals(returning.positionInRoot.x + returning.size.width, outgoing.positionInRoot.x, 1f)
        compose.mainClock.advanceTimeBy(400)
        compose.onNodeWithTag("book-page").assertDoesNotExist()
        compose.onNodeWithText("base").assertIsDisplayed()
    }

    @Test fun closingPageBlocksUnderlyingClicksThenRestoresThem() {
        var open by mutableStateOf(false)
        var clicks = 0
        compose.setContent {
            BookOverlayHost(open = open, page = { Box(Modifier.fillMaxSize()) }) {
                Box(Modifier.fillMaxSize().clickable { clicks++ }) { Text("base") }
            }
        }
        compose.runOnIdle { open = true }
        compose.waitForIdle()
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { open = false }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(240)
        compose.onRoot().performTouchInput { click() }
        compose.runOnIdle { assertEquals(0, clicks) }
        compose.mainClock.advanceTimeBy(400)
        compose.onRoot().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, clicks) }
    }

    @Test fun successfulSignInContinuesLeftAndRevealsDestinationFromRight() {
        var open by mutableStateOf(false)
        var completed by mutableStateOf(false)
        compose.setContent {
            BookOverlayHost(open = open, closeForward = completed, page = {
                Box(Modifier.fillMaxSize().background(Color.Black)) { Text("form") }
            }) { Text(if (completed) "library" else "welcome") }
        }
        compose.runOnIdle { open = true }
        compose.waitForIdle()
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { completed = true; open = false }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(96)
        val base = compose.onNodeWithTag("book-base", useUnmergedTree = true).fetchSemanticsNode()
        val page = compose.onNodeWithTag("book-page", useUnmergedTree = true).fetchSemanticsNode()
        assertTrue(base.positionInRoot.x > 0f)
        assertTrue(page.positionInRoot.x < 0f)
        assertEquals(page.positionInRoot.x + page.size.width, base.positionInRoot.x, 1f)
        compose.mainClock.advanceTimeBy(400)
        compose.onNodeWithText("library").assertIsDisplayed()
        compose.onNodeWithText("welcome").assertDoesNotExist()
    }

    @Test fun interruptedOpenReturnsToBaseAndDisposesPage() {
        var open by mutableStateOf(false)
        var mounted = false
        compose.setContent {
            BookOverlayHost(open = open, page = {
                DisposableEffect(Unit) { mounted = true; onDispose { mounted = false } }
                Text("next")
            }) { Text("base") }
        }
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { open = true }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(80)
        compose.runOnIdle { assertTrue(mounted); open = false }
        compose.mainClock.advanceTimeBy(400)
        compose.onNodeWithTag("book-page").assertDoesNotExist()
        compose.runOnIdle { assertTrue(!mounted) }
    }

    @Test fun welcomeAboutIsAPageAndReturnsWithoutActivatingGuest() {
        var guests = 0
        compose.setContent {
            WelcomeScreen(signInOffered = true, onSignIn = {}, onGuest = { guests++ })
        }
        compose.onNodeWithText("Об аккаунте").performClick()
        compose.onNodeWithText("Аккаунт ZiziPlayer").assertIsDisplayed()
        compose.onNodeWithText("Понятно").performClick()
        compose.onNodeWithText("Зарегистрироваться").assertIsDisplayed()
        compose.runOnIdle { assertEquals(0, guests) }
    }
}
