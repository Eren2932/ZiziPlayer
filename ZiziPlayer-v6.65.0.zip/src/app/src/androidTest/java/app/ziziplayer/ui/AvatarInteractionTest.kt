package app.ziziplayer.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.account.AvatarCropGeometry
import app.ziziplayer.account.AvatarImage
import app.ziziplayer.ui.screens.AccountScreen
import app.ziziplayer.ui.screens.AvatarCropViewport
import app.ziziplayer.ui.screens.AvatarRemovalSheet
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Requires a real/emulated Android device. Not executed by the source-only Python checks. */
class AvatarInteractionTest {
    @get:Rule val compose = createComposeRule()

    private fun profile(avatar: String = "") {
        compose.setContent {
            AccountScreen(state = AccountLocalState(), profile = AccountProfile(avatar = avatar, loaded = true),
                signInOffered = false, playlists = emptyList(), playlistMeta = emptyMap(), onPlaylist = {},
                onSignIn = {}, onSignOut = {}, onSignOutAll = {}, onClose = {}, onOpenLibrary = {},
                onSettings = {}, onEdit = {}, onRefresh = {})
        }
    }
    @Test fun accountMoreOpensTheBottomSheet() {
        profile()
        compose.onNodeWithContentDescription("Меню аккаунта").performClick()
        compose.onNodeWithText("Аккаунт", useUnmergedTree = true).assertIsDisplayed()
        compose.onNodeWithText("Облачная библиотека", useUnmergedTree = true).assertIsDisplayed()
    }
    @Test fun longPressAvatarOpensPhotoWithoutEditing() {
        val bitmap = Bitmap.createBitmap(8,8,Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(android.graphics.Color.RED)
        val avatar = runBlocking { AvatarImage.encodeCrop(bitmap, AvatarCropGeometry.initial()) }
        profile(avatar)
        compose.onNodeWithContentDescription("Аватарка профиля").performTouchInput { longClick() }
        compose.onNodeWithText("Просмотр фото").assertIsDisplayed()
        compose.onNodeWithContentDescription("Закрыть просмотр").performClick()
        compose.onNodeWithText("Просмотр фото").assertDoesNotExist()
    }
    @Test fun cropDragUpdatesPoseOnFirstGestureAndStaysInsideImage() {
        val bitmap = Bitmap.createBitmap(400,200,Bitmap.Config.ARGB_8888)
        var observed = AvatarCropGeometry.Pose(2f,0f,0f)
        compose.setContent {
            var pose by remember { mutableStateOf(observed) }
            AvatarCropViewport(bitmap, pose, enabled = true,
                onPose = { pose = it; observed = it }, modifier = Modifier.size(280.dp))
        }
        compose.onNodeWithTag("avatar-crop").performTouchInput {
            swipe(start = center, end = center + Offset(width * .25f, 0f), durationMillis = 400)
        }
        compose.runOnIdle {
            assertTrue(observed.x > 0f)
            val crop = AvatarCropGeometry.crop(400,200,observed)
            assertTrue(crop.left >= 0 && crop.top >= 0)
            assertTrue(crop.left + crop.side <= 400 && crop.top + crop.side <= 200)
        }
    }
    @Test fun removalWaitsForExplicitActionAndRunsOnce() {
        var removed = 0
        compose.setContent {
            var open by remember { mutableStateOf(true) }
            if (open) AvatarRemovalSheet(onRemove = { removed++ }, onDismiss = { open = false })
        }
        compose.runOnIdle { assertEquals(0, removed) }
        compose.onNodeWithText("Удалить фото").performClick()
        compose.waitUntil(timeoutMillis = 5000) { removed == 1 }
        compose.runOnIdle { assertEquals(1, removed) }
    }
    @Test fun pngExportHasExpectedPixelsSizeAndNoOriginalPayload() {
        val bitmap = Bitmap.createBitmap(400,200,Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.RED)
        val paint = android.graphics.Paint().apply { color = android.graphics.Color.BLUE }
        canvas.drawRect(200f,0f,400f,200f,paint)
        // Positive image translation selects the left edge; output must be entirely red.
        val pose = AvatarCropGeometry.constrain(400,200,AvatarCropGeometry.Pose(1f,.5f,0f))
        val encoded = runBlocking { AvatarImage.encodeCrop(bitmap,pose) }
        val bytes = Base64.decode(encoded,Base64.NO_WRAP)
        val result = BitmapFactory.decodeByteArray(bytes,0,bytes.size)
        assertEquals(256,result.width); assertEquals(256,result.height)
        assertEquals(android.graphics.Color.RED,result.getPixel(128,128))
        assertTrue(bytes.size <= 300 * 1024)
    }
}
