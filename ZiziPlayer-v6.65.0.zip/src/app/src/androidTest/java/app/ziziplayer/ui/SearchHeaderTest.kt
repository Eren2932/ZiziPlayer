package app.ziziplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.CollapsingSearchHeader
import app.ziziplayer.ui.components.SearchHeaderState
import app.ziziplayer.ui.components.rememberSearchHeaderState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Requires a real Android emulator/device. Not executed by the offline test suite. */
class SearchHeaderTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var header: SearchHeaderState
    private lateinit var list: LazyListState
    private var headerHeight = 0
    private var entryHeight = 0

    private fun mount() {
        compose.setContent {
            header = rememberSearchHeaderState()
            list = rememberLazyListState()
            Column(Modifier.fillMaxSize().nestedScroll(header.connection)) {
                Box(Modifier.onSizeChanged { headerHeight = it.height }) {
                    CollapsingSearchHeader(header,
                        title = { Text("Search title", Modifier.height(68.dp)) },
                        entry = { Text("Search entry", Modifier.fillMaxWidth().height(52.dp)
                            .onSizeChanged { entryHeight = it.height }.testTag("entry")) },
                        section = { Text("Popular section", Modifier.height(44.dp)) })
                }
                LazyColumn(Modifier.fillMaxSize().testTag("list"), state = list) {
                    items(100) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                }
            }
        }
    }
    @Test fun collapsedBottomMatchesEntryExactlyAndTitleIsNotAccessible() {
        mount()
        compose.runOnIdle { header.fraction = 1f }
        compose.runOnIdle { assertEquals(entryHeight, headerHeight) }
        compose.onNodeWithTag("entry").assertIsDisplayed()
        compose.onNodeWithText("Search title").assertDoesNotExist()
        compose.onNodeWithText("Popular section").assertDoesNotExist()
    }
    @Test fun fullHeightReturnsWithoutRoundingGap() {
        mount()
        var expanded = 0
        compose.runOnIdle { expanded = headerHeight; header.fraction = 1f }
        compose.runOnIdle { header.fraction = 0f }
        compose.runOnIdle { assertEquals(expanded, headerHeight) }
        compose.onNodeWithText("Search title").assertIsDisplayed()
    }
    @Test fun swipeCollapsesBeforeListContinues() {
        mount()
        compose.onNodeWithTag("list").performTouchInput { swipeUp() }
        compose.runOnIdle {
            assertEquals(1f, header.fraction, 0.001f)
            assertTrue(list.firstVisibleItemIndex > 0 || list.firstVisibleItemScrollOffset > 0)
        }
    }
    @Test fun reverseGestureExpandsOnlyAfterListReturnsUnusedDistance() {
        mount()
        compose.runOnIdle {
            header.fraction = 1f
            val delta = Offset(0f, 30f)
            val pre = header.connection.onPreScroll(delta, NestedScrollSource.UserInput)
            assertEquals(0f, pre.y, 0f)
            assertEquals(1f, header.fraction, 0f)
            val post = header.connection.onPostScroll(Offset.Zero, delta, NestedScrollSource.UserInput)
            assertEquals(30f, post.y, 0.001f)
            assertTrue(header.fraction < 1f)
        }
    }

}
