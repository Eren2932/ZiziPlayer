package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsProperties
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.ui.screens.AccountScreen
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.fullBleedHorizontal
import app.ziziplayer.ui.components.surfaceInputBoundary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Run with connectedDebugAndroidTest. These are not claimed as executed by offline checks. */
class SurfaceGestureTest {
    @get:Rule val compose = createComposeRule()

    @Test fun firstSwipeScrollsProfileAndDoesNotClickUnderlyingScreen() {
        lateinit var list: LazyListState
        var underlyingClicks = 0
        compose.setContent {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().clickable { underlyingClicks++ })
                Box(Modifier.fillMaxSize().background(Color.Black).surfaceInputBoundary()) {
                    list = rememberLazyListState()
                    LazyColumn(state = list, modifier = Modifier.fillMaxSize().testTag("profile")) {
                        items(100) { Text("Playlist $it", Modifier.fillMaxWidth().height(64.dp)) }
                    }
                }
            }
        }
        compose.onNodeWithTag("profile").performTouchInput { swipeUp() }
        compose.runOnIdle {
            assertTrue(list.firstVisibleItemIndex > 0 || list.firstVisibleItemScrollOffset > 0)
            assertEquals(0, underlyingClicks)
        }
    }

    @Test fun actualAccountScreenScrollsOnFirstSwipe() {
        compose.setContent {
            Box(Modifier.fillMaxSize().surfaceInputBoundary()) {
                AccountScreen(
                    state = AccountLocalState(), profile = AccountProfile(loaded = true),
                    signInOffered = false,
                    playlists = List(100) { PlaylistEntity(id = it.toLong() + 1, name = "Playlist $it") },
                    playlistMeta = emptyMap(), onPlaylist = {}, onSignIn = {}, onSignOut = {},
                    onSignOutAll = {}, onClose = {}, onOpenLibrary = {}, onSettings = {},
                    onEdit = {}, onRefresh = {}
                )
            }
        }
        val list = compose.onNode(hasScrollAction())
        list.performTouchInput { swipeUp() }
        val axis = list.fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange]
        compose.runOnIdle { assertTrue(axis.value() > 0f) }
    }

    @Test fun emptySurfaceDoesNotLeakTapsToSibling() {
        var underlyingClicks = 0
        compose.setContent {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().clickable { underlyingClicks++ })
                Box(Modifier.fillMaxSize().surfaceInputBoundary().testTag("overlay"))
            }
        }
        compose.onNodeWithTag("overlay").performTouchInput { click() }
        compose.runOnIdle { assertEquals(0, underlyingClicks) }
    }

    @Test fun drawerAndSettingsVerticalScrollKeepFirstGesture() {
        lateinit var scroll: ScrollState
        compose.setContent {
            scroll = rememberScrollState()
            Column(Modifier.fillMaxSize().surfaceInputBoundary()
                .testTag("settings").verticalScroll(scroll)) {
                repeat(100) { Text("Section $it", Modifier.height(64.dp)) }
            }
        }
        compose.onNodeWithTag("settings").performTouchInput { swipeUp() }
        compose.runOnIdle { assertTrue(scroll.value > 0) }
    }

    @Test fun bannerMeasuresFullViewportDespiteListInsets() {
        var viewportWidth = 0
        var bannerWidth = 0
        compose.setContent {
            LazyColumn(Modifier.fillMaxWidth().onSizeChanged { viewportWidth = it.width },
                contentPadding = PaddingValues(horizontal = 16.dp)) {
                item {
                    Row(Modifier.fullBleedHorizontal(16.dp).fillMaxWidth()
                        .onSizeChanged { bannerWidth = it.width }.background(Color.Black)
                        .padding(horizontal = 16.dp).height(56.dp)) { Text("Filters") }
                }
            }
        }
        compose.runOnIdle { assertTrue(viewportWidth > 0); assertEquals(viewportWidth, bannerWidth) }
    }
}
