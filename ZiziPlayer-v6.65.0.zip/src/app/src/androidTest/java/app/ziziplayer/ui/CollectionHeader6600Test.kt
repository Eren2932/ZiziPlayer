package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.screens.PinnedCollectionScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Requires emulator/device; never reported as passed by the offline checker. */
class CollectionHeader6600Test {
    @get:Rule val compose = createComposeRule()
    private fun mount() {
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides basePalette()) {
                PinnedCollectionScaffold(destination = "test:6600", title = "Test collection", tint = Color.DarkGray,
                    trackCount = 40, playingHere = false, playEnabled = true, onBack = {}, onPlay = {},
                    artwork = { Box(Modifier.fillMaxSize().background(Color.Gray)) },
                    hero = { Column { Text("Test collection"); Spacer(Modifier.height(88.dp)) } }) {
                    items(40) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                }
            }
        }
    }
    @Test fun shortDragShrinksCoverWithoutTimedAnimation() {
        mount()
        val before = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().size.width
        compose.onNodeWithTag("collection:list").performTouchInput {
            val point = Offset(center.x, height * .6f)
            down(point)
            moveTo(point + Offset(0f, -40f))
            advanceEventTime(1000)
            up()
        }
        val after = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().size.width
        assertTrue(after > 0 && after < before)
    }
    @Test fun deepScrollHasPinnedTitleAndOnlyOnePlayButton() {
        mount()
        compose.onNodeWithTag("collection:list").performScrollToIndex(10)
        compose.onNodeWithTag("collection:banner").assertIsDisplayed()
        compose.onAllNodesWithContentDescription("Слушать подборку").assertCountEquals(1)
    }
}
