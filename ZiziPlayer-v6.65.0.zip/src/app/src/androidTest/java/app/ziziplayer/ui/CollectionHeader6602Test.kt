package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.screens.CollectionActionsRow
import app.ziziplayer.ui.screens.CollectionHeroContent
import app.ziziplayer.ui.screens.PinnedCollectionScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import kotlin.math.abs

/** Requires an Android emulator/device. Not executed by source scanners. */
class CollectionHeader6602Test {
    @get:Rule val compose = createComposeRule()
    private var statusPx = 0
    private fun mount() {
        compose.setContent {
            statusPx = WindowInsets.statusBars.getTop(LocalDensity.current)
            CompositionLocalProvider(LocalPalette provides basePalette()) {
                Box(Modifier.requiredSize(360.dp, 640.dp)) {
                    PinnedCollectionScaffold(destination = "test:6602", title = "ZELENUYU",
                        tint = Color.DarkGray, trackCount = 20, playingHere = false, playEnabled = true,
                        onBack = {}, onPlay = {}, artwork = { Box(Modifier.fillMaxSize().background(Color.Gray)) },
                        hero = {
                            CollectionHeroContent(title = "ZELENUYU", metadata = "5 tracks") {
                                CollectionActionsRow(onShuffle = {}, shuffleEnabled = true, onMenu = {})
                            }
                        }) {
                        items(20) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                    }
                }
            }
        }
    }
    @Test fun coverUsesReferenceTopSizeAndHorizontalCenter() {
        mount()
        val viewport = compose.onNodeWithTag("collection:viewport").fetchSemanticsNode().boundsInRoot
        val cover = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().boundsInRoot
        val unit = viewport.width / 1080f
        assertTrue(abs(cover.top - viewport.top - statusPx - 54f * unit) <= 2f)
        assertTrue(abs(cover.width - 716f * unit) <= 2f)
        assertTrue(abs(cover.center.x - viewport.center.x) <= 1f)
    }
    @Test fun informationAndActionsUseReferenceCoordinates() {
        mount()
        val viewport = compose.onNodeWithTag("collection:viewport").fetchSemanticsNode().boundsInRoot
        val unit = viewport.width / 1080f
        val title = compose.onNodeWithTag("collection:hero-title").fetchSemanticsNode().boundsInRoot
        val play = compose.onNodeWithTag("collection:play").fetchSemanticsNode().boundsInRoot
        val menu = compose.onNodeWithTag("collection:menu").fetchSemanticsNode().boundsInRoot
        assertTrue(abs(title.left - viewport.left - 46f * unit) <= 2f)
        assertTrue(abs(title.top - viewport.top - statusPx - 840f * unit) <= 3f)
        assertTrue(abs(play.top - viewport.top - statusPx - 1150f * unit) <= 3f)
        assertTrue(abs(play.center.x - viewport.left - 970f * unit) <= 2f)
        assertTrue(abs(menu.center.y - play.center.y) <= 2f)
    }
}
