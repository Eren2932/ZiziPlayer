package app.ziziplayer.ui;

import java.util.Random;

/** Executes the same geometry methods called by Compose. */
public final class SearchHeader6590Checks {
    private static int checks;
    private static void check(boolean value) {
        checks++;
        if (!value) throw new AssertionError("Search header invariant #" + checks);
    }
    public static void main(String[] args) {
        for (int title : new int[]{0, 48, 68, 77, 135, 204, 333}) {
            for (int section : new int[]{0, 44, 88, 121, 176}) {
                for (int entry : new int[]{52, 103, 155, 210}) {
                    int previous = Integer.MAX_VALUE;
                    for (int step = 0; step <= 1000; step++) {
                        float f = step / 1000f;
                        int top = SearchHeaderGeometry.visibleHeight(title, f);
                        int bottom = SearchHeaderGeometry.visibleHeight(section, f);
                        int height = top + entry + bottom;
                        check(top >= 0 && top <= title && bottom >= 0 && bottom <= section);
                        check(height <= previous && height >= entry);
                        if (step == 0) check(height == title + entry + section);
                        if (step == 1000) check(top == 0 && height == entry);
                        previous = height;
                    }
                }
            }
        }
        Random random = new Random(6590);
        for (int i = 0; i < 100000; i++) {
            float range = 1 + random.nextInt(1400);
            float old = random.nextFloat() * range;
            float dy = (random.nextFloat() - 0.5f) * 4000f;
            float next = SearchHeaderGeometry.nextOffset(old, dy, range);
            float consumed = old - next;
            float remainder = dy - consumed;
            check(next >= 0 && next <= range);
            check(Math.abs(consumed) <= Math.abs(dy) + 0.001f);
            check(Math.abs((consumed + remainder) - dy) < 0.001f);
            check(dy < 0 ? next >= old : next <= old);
            float reverse = SearchHeaderGeometry.nextOffset(next, -consumed, range);
            check(Math.abs(reverse - old) < 0.001f);
        }
        check(SearchHeaderGeometry.nextOffset(4, -20, 0) == 0);
        check(SearchHeaderGeometry.nextOffset(4, Float.NaN, 10) == 4);
        check(SearchHeaderGeometry.visibleHeight(100, Float.NaN) == 100);
        check(SearchHeaderGeometry.visibleHeight(100, 2) == 0);
        System.out.println("PASS: " + checks + " production geometry assertions");
    }
}
