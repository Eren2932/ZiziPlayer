package app.ziziplayer.ui;
import org.junit.Test;
public final class SearchHeader6590Test {
    @Test public void measuredCollapsePreservesPixelBoundsAndDistance() {
        SearchHeader6590Checks.main(new String[0]);
    }
}
