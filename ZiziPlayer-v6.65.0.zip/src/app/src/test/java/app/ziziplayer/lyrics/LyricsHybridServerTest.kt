package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class LyricsHybridServerTest {
    private val track = TrackEntity(id="test", uri="", title="Synthetic", artist="Dali Dade", durationMs=100_000L)
    private fun body(sync: Boolean = false): JSONObject = JSONObject().put("schemaVersion", 1).put("status", "found")
        .put("document", JSONObject().put("trackName", "Synthetic").put("artistName", "Däli Däde")
            .put("duration", 100).put("plainLyrics", "synthetic line one\nsynthetic line two")
            .put("source", "NetEase").put("syncedLyrics", if(sync) "[00:01.000]synthetic\n[00:02.000]next" else "")
            .put("timingProvenance", if(sync) "provider_lrc" else "none"))
    @Test fun httpsOnlyAndNoCredentials() {
        for (url in listOf("http://example.org", "https://user:pass@example.org", "https://example.org?q=x", "https://example.org/#f")) {
            try { ServerLyricsProvider(url); fail("Expected invalid config") } catch (_: IllegalArgumentException) {}
        }
    }
    @Test fun serverReceivesOnlyMetadata() = runBlocking {
        val p = ServerLyricsProvider("https://example.org/lyrics/")
        p.lookup(track, { r ->
            assertEquals("/lyrics/v1/lyrics", r.url.encodedPath)
            assertEquals(setOf("title", "artist", "durationMs"), r.url.queryParameterNames)
            assertNull(r.header("Authorization")); assertNull(r.header("Cookie"))
            body().toString()
        }, null)
        Unit
    }
    @Test fun validProviderTimingIsPreserved() = runBlocking {
        val result = ServerLyricsProvider("https://example.org").lookup(track, { body(true).toString() }, null)!!
        assertEquals(2, LrcTimeline.parse(result.getString("syncedLyrics")).size)
        assertEquals("NetEase · ZiziLyrics", result.getString("source"))
    }
    @Test fun plainDescriptionNeverInventsTiming() = runBlocking {
        val root=body();root.getJSONObject("document").put("source", "Official description")
        val result=ServerLyricsProvider("https://example.org").lookup(track, { root.toString() }, null)!!
        assertEquals("", result.getString("syncedLyrics"))
    }
    @Test fun unknownTimingProvenanceDegradesToPlain() = runBlocking {
        val root=body(true);root.getJSONObject("document").put("timingProvenance", "generated_unreviewed")
        assertEquals("", ServerLyricsProvider("https://example.org").lookup(track, { root.toString() }, null)!!.getString("syncedLyrics"))
    }
    @Test fun changedDurationDegradesToPlain() = runBlocking {
        val root=body(true);root.getJSONObject("document").put("duration", 104)
        assertEquals("", ServerLyricsProvider("https://example.org").lookup(track, { root.toString() }, null)!!.getString("syncedLyrics"))
    }
    @Test fun unrelatedArtistRejected() = runBlocking {
        val root=body();root.getJSONObject("document").put("artistName", "Other")
        try { ServerLyricsProvider("https://example.org").lookup(track, { root.toString() }, null); fail() }
        catch (_: IOException) {}
    }
    @Test fun typedMissIsDifferentFromHttp404() = runBlocking {
        val p=ServerLyricsProvider("https://example.org")
        assertNull(p.lookup(track, { """{"schemaVersion":1,"status":"miss","document":null}""" }, null))
        try { p.lookup(track, { throw LyricsRepository.HttpFailure(404,"route missing") }, null);fail() }
        catch (e: LyricsRepository.HttpFailure) { assertEquals(404,e.status) }
    }
    @Test fun unsupportedSchemaAndMalformedResponseNotMiss() = runBlocking {
        for (text in listOf("{}", """{"schemaVersion":2,"status":"miss"}""", """{"schemaVersion":1,"status":"error"}""")) {
            try { ServerLyricsProvider("https://example.org").lookup(track,{text},null);fail() } catch (_: IOException) {}
        }
    }
}
