package app.ziziplayer.listening;

import java.util.BitSet;
import java.util.Random;

public final class ListeningClockChecks {
    private static int checks;
    private static void eq(long expected, long actual) {
        checks++; if (expected != actual) throw new AssertionError(expected + " != " + actual);
    }
    private static void yes(boolean value) { checks++; if (!value) throw new AssertionError("expected true"); }
    public static void main(String[] args) {
        ListeningClock c = new ListeningClock(0, 0);
        c.sample(10_000, 0, false, 1f); eq(0, c.listenedMs());
        c.sample(20_000, 0, true, 1f); eq(0, c.listenedMs());
        c.sample(25_000, 5000, false, 1f); eq(5000, c.listenedMs()); eq(5000, c.coveredMs());
        c.sample(125_000, 5000, false, 1f); eq(5000, c.listenedMs());
        c.sample(125_000, 5000, true, 1f);
        c.seek(130_000, 10_000, 290_000, true, 1f);
        c.sample(140_000, 300_000, false, 1f);
        eq(20_000, c.listenedMs()); eq(20_000, c.coveredMs());
        yes(!c.completed(300_000, "ended")); yes(!c.qualified(300_000));

        c = new ListeningClock(0, 0); c.sample(0, 0, true, 1f);
        c.sample(30_000, 30_000, true, 1f); yes(c.qualified(300_000));
        c.seek(30_000, 30_000, 0, true, 1f);
        c.sample(60_000, 30_000, true, 1f);
        eq(60_000, c.listenedMs()); eq(30_000, c.coveredMs());
        c.sample(90_000, 60_000, false, 1f); eq(60_000, c.coveredMs());
        yes(c.completed(60_000, "ended")); yes(!c.completed(60_000, "skipped"));
        yes(!c.completed(0, "ended"));

        c = new ListeningClock(0, 0); c.sample(0, 0, true, 2f);
        c.sample(30_000, 60_000, false, 2f); eq(30_000, c.listenedMs()); eq(60_000, c.coveredMs());
        yes(c.completed(60_000, "ended"));
        c = new ListeningClock(0, 0); c.sample(0, 0, true, 0.5f);
        c.sample(120_000, 60_000, false, 0.5f); eq(120_000, c.listenedMs()); eq(60_000, c.coveredMs());
        c = new ListeningClock(0, 0); c.sample(0, 0, true, 1f);
        c.sample(4999, 4999, true, 1f); yes(!c.qualified(10_000));
        c.sample(5000, 5000, false, 1f); yes(c.qualified(10_000));
        c.sample(5000, 5000, false, 1f); eq(5000, c.listenedMs());
        c.sample(4000, 5000, false, Float.NaN); eq(5000, c.listenedMs());
        c = new ListeningClock(0, 0); c.sample(0, 0, true, 1f);
        c.sample(1000, 200_000, false, 1f); eq(1000, c.listenedMs()); eq(0, c.coveredMs());

        c = new ListeningClock(0, 0); c.sample(0, 0, true, 1f);
        c.sample(5, 5, true, 1f); yes(!c.qualified(11));
        c.sample(6, 6, true, 1f); yes(c.qualified(11));
        c.sample(9, 9, true, 1f); yes(!c.completed(11, "ended"));
        c.sample(10, 10, false, 1f); yes(c.completed(11, "ended"));

        // Independent millisecond occupancy oracle for random seeks, repeats and pauses.
        Random r = new Random(647);
        c = new ListeningClock(0, 0); c.sample(0, 0, true, 1f);
        BitSet heard = new BitSet(600_000);
        long now = 0, listened = 0; int position = 0; boolean playing = true;
        for (int i = 0; i < 12_000; i++) {
            int dt = r.nextInt(1000); now += dt;
            int endpoint = Math.min(600_000, position + (playing ? dt : 0));
            if (playing) { listened += dt; heard.set(position, endpoint); }
            boolean nextPlaying = r.nextInt(5) != 0;
            if (r.nextInt(4) == 0) {
                int target = r.nextInt(600_000);
                c.seek(now, endpoint, target, nextPlaying, 1f); position = target;
            } else { c.sample(now, endpoint, nextPlaying, 1f); position = endpoint; }
            playing = nextPlaying;
            eq(listened, c.listenedMs()); eq(heard.cardinality(), c.coveredMs());
        }
        System.out.println("ListeningClock: " + checks + " assertions PASS");
    }
}
