package app.ziziplayer.lyrics

import org.junit.Test

class LrcTimelineTest {
    @Test fun parseAndSeek() { LrcTimelineChecks.run() }
}
