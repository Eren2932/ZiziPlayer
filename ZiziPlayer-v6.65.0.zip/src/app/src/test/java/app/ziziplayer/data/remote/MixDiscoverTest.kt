package app.ziziplayer.data.remote

import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class MixDiscoverTest {
    private class Fake(
        override val id: String,
        private val load: suspend () -> List<DiscoverShelf>
    ) : RemoteCatalog {
        override val label = id
        override suspend fun discover() = load()
        override suspend fun isUsable() = true
        override suspend fun suggest(prefix: String) = emptyList<String>()
        override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?) = SearchPage.EMPTY
        override suspend fun collection(collection: RemoteCollection) = emptyList<RemoteTrack>()
        override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo =
            throw UnsupportedOperationException("Metadata-only test")
    }

    private fun shelf(provider: String) = listOf(DiscoverShelf("Hits", listOf(
        RemoteItem.Song(RemoteTrack(provider, "1", "Track", "Artist"))
    )))

    private suspend fun withMix(parts: List<RemoteCatalog>, test: suspend (MixCatalog) -> Unit) {
        val old = RemoteRuntime.youtubeDirect
        try { RemoteRuntime.youtubeDirect = true; test(MixCatalog(parts)) }
        finally { RemoteRuntime.youtubeDirect = old }
    }

    @Test fun allProvidersOfflineThrowsInsteadOfReturningEmptySuccess() = runBlocking<Unit> {
        val parts = listOf("dz", "yt").map { id -> Fake(id) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "offline")
        } }
        withMix(parts) { mix ->
            try { mix.discover(); fail("Must preserve the provider failure") }
            catch (e: CatalogException) { assertEquals(CatalogException.Reason.OFFLINE, e.reason) }
        }
    }

    @Test fun partialSuccessSurvivesAnotherProviderFailure() = runBlocking<Unit> {
        withMix(listOf(Fake("dz") { shelf("dz") }, Fake("yt") {
            throw CatalogException(CatalogException.Reason.OFFLINE, "offline")
        })) { mix ->
            val result = mix.discover()
            val song = result.single().items.single() as RemoteItem.Song
            assertEquals("mix", song.track.provider)
            assertEquals("dz:1", song.track.remoteId)
        }
    }

    @Test fun parserFailureDoesNotDestroyOtherProvidersResults() = runBlocking<Unit> {
        withMix(listOf(Fake("dz") { shelf("dz") }, Fake("yt") { error("bad schema") })) { mix ->
            assertEquals(1, mix.discover().size)
        }
    }

    @Test fun allParserFailuresBecomeRecoverableCatalogErrors() = runBlocking<Unit> {
        withMix(listOf(Fake("dz") { error("bad schema") })) { mix ->
            try { mix.discover(); fail("Must wrap unexpected parser errors") }
            catch (e: CatalogException) { assertEquals(CatalogException.Reason.PROTOCOL, e.reason) }
        }
    }

    @Test fun genuinelyEmptyProviderRemainsAValidEmptyResponse() = runBlocking<Unit> {
        withMix(listOf(Fake("dz") { emptyList() })) { mix -> assertTrue(mix.discover().isEmpty()) }
    }

    @Test fun cancellationReachesTheInFlightProvider() = runBlocking<Unit> {
        val started = CompletableDeferred<Unit>()
        var cancelled = false
        withMix(listOf(Fake("dz") {
            started.complete(Unit)
            try { awaitCancellation() } finally { cancelled = true }
        })) { mix ->
            val job = launch { mix.discover() }
            started.await()
            job.cancelAndJoin()
            assertTrue(cancelled)
        }
    }
}
