package app.ziziplayer.ui

import org.junit.Test

class Polish6430Test {
    @Test fun progressAndScrim() { Polish6430Checks.run() }
}
