package app.ziziplayer.ui;
import org.junit.Test;
public class Collection6601Test {
    @Test public void actionPlacementAndShortListPinning() { Collection6601Checks.main(new String[0]); }
}
