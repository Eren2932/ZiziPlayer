package app.ziziplayer.ui;

public final class Polish6430Checks {
    private static int assertions;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static void near(float actual, float expected) {
        check(Math.abs(actual - expected) < .00001f, actual + " != " + expected);
    }
    public static void run() {
        assertions = 0;
        near(CollectionDownloadProgress.fraction(0, 0, 0), 0);
        near(CollectionDownloadProgress.fraction(11, 41, 0), 11f / 41);
        near(CollectionDownloadProgress.fraction(11, 41, 50), 11.5f / 41);
        near(CollectionDownloadProgress.fraction(41, 41, 0), 1);
        near(CollectionDownloadProgress.fraction(0, 2, 150), .75f);
        near(CollectionDownloadProgress.fraction(-1, 10, -20), 0);
        near(CollectionDownloadProgress.fraction(0, 10, Float.NaN), 0);
        near(CollectionDownloadProgress.fraction(0, 10, Float.POSITIVE_INFINITY), 0);
        near(CollectionDownloadProgress.fraction(200, 10, 400), 1);
        for (int total = 1; total <= 500; total++) {
            float prev = -1;
            for (int ready = 0; ready <= total; ready++) {
                float progress = CollectionDownloadProgress.fraction(ready, total, 0);
                check(progress >= prev && progress >= 0 && progress <= 1, "bounded monotone progress");
                prev = progress;
            }
        }
        near(CollectionGeometry.scrimAlpha(.5f), .325f);
        near(CollectionGeometry.scrimAlpha(1), .65f);
        near(1 - CollectionGeometry.scrimAlpha(1), .35f);
        System.out.println("Polish6430Checks: " + assertions + " assertions passed");
    }
    public static void main(String[] args) { run(); }
}
