package app.ziziplayer.ui;
import org.junit.Test;
public class HomeHeader6580Test {
    @Test public void headerGeometryAndAutoRefresh() { HomeHeader6580Checks.main(new String[0]); }
}
