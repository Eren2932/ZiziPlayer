package app.ziziplayer.listening

import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.data.ListeningSessionEntity
import java.lang.reflect.Proxy
import org.junit.Assert.*
import org.junit.Test

/** Executed by :app:testDebugUnitTest in CI. No Android clock, service or network needed. */
@OptIn(UnstableApi::class)
class ListeningManagerTest {
    private class Sink : ListeningSink {
        override var generation = 0L
        val rows = linkedMapOf<String, ListeningSessionEntity>()
        override fun submit(row: ListeningSessionEntity, ownerGeneration: Long) {
            if (ownerGeneration == generation) rows[row.sessionId] = row
        }
    }
    private class Rig {
        var elapsed = 0L
        var position = 0L
        var playing = false
        var state = Player.STATE_READY
        var speed = 1f
        var item = MediaItem.Builder().setMediaId("r:mix:dz:1").build()
        val sink = Sink()
        var listeners = 0
        val player = Proxy.newProxyInstance(Player::class.java.classLoader, arrayOf(Player::class.java)) { _, method, _ ->
            when (method.name) {
                "getCurrentMediaItem" -> item
                "getCurrentPosition" -> position
                "getDuration" -> 60_000L
                "isPlaying" -> playing
                "getPlaybackState" -> state
                "getPlaybackParameters" -> PlaybackParameters(speed)
                "addListener" -> { listeners++; null }
                "removeListener" -> { listeners--; null }
                "toString" -> "Listening test player"
                else -> throw AssertionError("Unexpected player access: ${method.name}")
            }
        } as Player
        val manager = ListeningManager(player, sink, { emptySet() }, { elapsed }, { 1_000_000L + elapsed })
        fun tick(ms: Long, advance: Boolean = playing) {
            elapsed += ms
            if (advance) position += (ms * speed).toLong()
            manager.checkpoint()
        }
        fun start() { playing = true; manager.checkpoint() }
    }
    @Test fun restoredPauseAndBufferingDoNotCount() {
        val r = Rig()
        r.tick(10_000)
        assertTrue(r.sink.rows.isEmpty())
        r.state = Player.STATE_BUFFERING; r.tick(20_000)
        assertTrue(r.sink.rows.isEmpty())
        r.state = Player.STATE_READY; r.start(); r.tick(5000)
        r.playing = false; r.manager.checkpoint(); r.tick(50_000)
        assertEquals(5000L, r.sink.rows.values.single().listenedMs)
        r.start(); r.tick(5000); r.manager.close()
        assertEquals(10_000L, r.sink.rows.values.single().listenedMs)
        assertEquals(0, r.listeners)
    }
    @Test fun completionAndRetriesUseOneSessionIdentity() {
        val r = Rig(); r.start(); r.tick(30_000)
        assertTrue(r.sink.rows.values.single().qualified)
        r.manager.checkpoint(); assertEquals(1, r.sink.rows.size)
        r.tick(30_000); r.playing = false; r.state = Player.STATE_ENDED
        r.manager.checkpoint(); r.manager.checkpoint()
        assertEquals(1, r.sink.rows.size)
        assertEquals("ended", r.sink.rows.values.single().outcome)
        assertTrue(r.sink.rows.values.single().completed)
    }
    @Test fun switchingTracksCreatesSeparateSessions() {
        val r = Rig(); r.start(); r.tick(7000)
        r.item = MediaItem.Builder().setMediaId("r:mix:dz:2").build(); r.position = 0
        r.manager.onMediaItemTransition(r.item, Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)
        r.manager.checkpoint(); r.tick(2000); r.manager.close()
        assertEquals(2, r.sink.rows.size)
        assertEquals("skipped", r.sink.rows.values.first().outcome)
        assertEquals(7000L, r.sink.rows.values.first().listenedMs)
        assertEquals(2000L, r.sink.rows.values.last().listenedMs)
    }
    @Test fun clearGenerationCannotResurrectOldSession() {
        val r = Rig(); r.start(); r.tick(9000)
        val oldId = r.sink.rows.keys.single()
        r.sink.generation++; r.sink.rows.clear(); r.manager.checkpoint(); r.tick(3000)
        assertEquals(1, r.sink.rows.size)
        assertNotEquals(oldId, r.sink.rows.keys.single())
        assertEquals(3000L, r.sink.rows.values.single().listenedMs)
    }
    @Test fun failureBeforeAudioIsNotAPlayOrSkip() {
        val r = Rig(); r.state = Player.STATE_BUFFERING; r.tick(5000)
        r.state = Player.STATE_IDLE
        r.manager.onPlayerError(PlaybackException("network", null, 2001))
        r.manager.checkpoint()
        val row = r.sink.rows.values.single()
        assertEquals("error", row.outcome); assertEquals(0L, row.listenedMs)
        assertFalse(row.qualified); assertFalse(row.completed)
    }
    @Test fun fullFastPlaybackStillQualifiesAtNaturalEnd() {
        val r = Rig(); r.speed = 3f; r.start(); r.tick(20_000)
        r.state = Player.STATE_ENDED; r.playing = false; r.manager.checkpoint()
        val row = r.sink.rows.values.single()
        assertTrue(row.completed); assertTrue(row.qualified)
        assertEquals(20_000L, row.listenedMs)
    }
    @Test fun naturalEndDoesNotMeanCoverageWhenStartedNearEnd() {
        val r = Rig(); r.position = 55_000; r.start(); r.tick(5000)
        r.state = Player.STATE_ENDED; r.playing = false; r.manager.checkpoint()
        val row = r.sink.rows.values.single()
        assertEquals("ended", row.outcome); assertFalse(row.completed)
        assertEquals(5000L, row.coveredMs)
    }
}
