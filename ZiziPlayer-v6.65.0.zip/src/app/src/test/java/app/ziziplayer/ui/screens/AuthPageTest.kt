package app.ziziplayer.ui.screens

import org.junit.Assert.*
import org.junit.Test

/** Real history, not a hard-coded parent table. Run with :app:testDebugUnitTest. */
class AuthPageTest {
    @Test fun productionHistoryStress() { AuthHistoryChecks.run() }
    @Test fun entryPagesAreEmailFields() {
        assertTrue(AuthPage.LoginEmail.emailEntry)
        assertTrue(AuthPage.RegisterEmail.emailEntry)
        assertFalse(AuthPage.LoginPassword.emailEntry)
    }
    @Test fun registrationAndVerificationBackFollowActualHistory() {
        val history = AuthHistory(AuthPage.RegisterEmail)
        assertTrue(history.forward(AuthPage.RegisterPassword))
        history.settle(history.revision())
        assertTrue(history.forward(AuthPage.Verify))
        history.settle(history.revision())
        assertTrue(history.back())
        assertEquals(AuthPage.RegisterPassword, history.current())
        assertFalse(history.back()) // second tap during the same animation
        history.settle(history.revision())
        assertTrue(history.back())
        assertEquals(AuthPage.RegisterEmail, history.current())
    }
    @Test fun verificationFromLoginReturnsToLoginPassword() {
        val history = AuthHistory(AuthPage.LoginEmail)
        history.forward(AuthPage.LoginPassword); history.settle(history.revision())
        history.forward(AuthPage.Verify); history.settle(history.revision())
        history.back()
        assertEquals(AuthPage.LoginPassword, history.current())
    }
    @Test fun recoveryKeepsEachPreviousStep() {
        val history = AuthHistory(AuthPage.LoginEmail)
        for (page in listOf(AuthPage.LoginPassword, AuthPage.Forgot, AuthPage.Reset)) {
            history.forward(page); history.settle(history.revision())
        }
        for (page in listOf(AuthPage.Forgot, AuthPage.LoginPassword, AuthPage.LoginEmail)) {
            assertTrue(history.back()); assertEquals(page, history.current())
            history.settle(history.revision())
        }
        assertFalse(history.back())
    }
    @Test fun staleAnimationCannotUnlockANewerTransaction() {
        val history = AuthHistory(AuthPage.LoginEmail)
        history.forward(AuthPage.LoginPassword)
        val old = history.revision()
        history.settle(old)
        history.forward(AuthPage.Verify)
        history.settle(old)
        assertTrue(history.isMoving)
        assertFalse(history.back())
    }
    @Test fun successfulVerificationCannotGoBackToAUsedCode() {
        val history = AuthHistory(AuthPage.Verify)
        history.resetTo(listOf(AuthPage.LoginEmail, AuthPage.LoginPassword))
        history.settle(history.revision())
        history.back()
        assertEquals(AuthPage.LoginEmail, history.current())
    }
    @Test fun draftSurvivesNavigationButNotIdentityChanges() {
        val draft = AuthDraft()
        draft.editEmail("test@example.org")
        draft.password = "a-unique-password"
        draft.confirmation = "a-unique-password"
        draft.code = "test-code"
        val history = AuthHistory(AuthPage.RegisterEmail)
        history.forward(AuthPage.RegisterPassword); history.settle(history.revision())
        history.back(); history.settle(history.revision())
        assertEquals("a-unique-password", draft.password)
        assertEquals(draft.password, draft.confirmation)
        draft.editEmail("test@example.org ")
        assertEquals("a-unique-password", draft.password)
        draft.editEmail("other@example.org")
        assertEquals("", draft.password)
        assertEquals("", draft.confirmation)
        assertEquals("", draft.code)
        assertTrue(draft.dirty)
    }
    @Test fun loginDraftAndRegistrationDraftAreIndependent() {
        val login = AuthDraft(); val registration = AuthDraft()
        login.password = "login-password"
        registration.password = "register-password"
        registration.clearSecrets()
        assertEquals("login-password", login.password)
        assertEquals("", registration.password)
    }
}
