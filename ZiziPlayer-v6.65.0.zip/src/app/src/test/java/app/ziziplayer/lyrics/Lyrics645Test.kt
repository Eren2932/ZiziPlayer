package app.ziziplayer.lyrics

import org.junit.Test

class Lyrics645Test {
    @Test fun wordCuesAndSpeedInvariance() { Lyrics645Checks.run() }
}
