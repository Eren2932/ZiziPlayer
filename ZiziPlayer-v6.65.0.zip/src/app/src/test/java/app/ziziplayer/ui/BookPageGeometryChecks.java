package app.ziziplayer.ui;

public final class BookPageGeometryChecks {
    private static int checks;
    private static void check(boolean condition) {
        checks++;
        if (!condition) throw new AssertionError("Book edge check " + checks);
    }
    public static void main(String[] args) {
        for (int width : new int[] {0, 1, 319, 360, 393, 411, 693, 1080, 1440, 2560}) {
            check(BookPageGeometry.baseOffset(width, 0f) == 0);
            check(BookPageGeometry.pageOffset(width, 0f) == width);
            check(BookPageGeometry.baseOffset(width, 1f) == -width);
            check(BookPageGeometry.pageOffset(width, 1f) == 0);
            int previous = 0;
            for (int i = 0; i <= 10000; i++) {
                float p = i / 10000f;
                int base = BookPageGeometry.baseOffset(width, p);
                int page = BookPageGeometry.pageOffset(width, p);
                check(base + width == page); // No gap or overlap, even at odd widths.
                check(base <= 0 && base >= -width && base <= previous);
                check(page >= 0 && page <= width);
                // At any reversal progress is unchanged, so neither surface can jump.
                check(BookPageGeometry.baseOffset(width, p) == base);
                int completedBase = BookPageGeometry.baseOffset(width, p, true);
                int completedPage = BookPageGeometry.pageOffset(width, p, true);
                check(completedPage + width == completedBase);
                check(completedBase >= 0 && completedPage <= 0);
                check(BookPageGeometry.baseOffset(width, p, false) == base);
                check(BookPageGeometry.pageOffset(width, p, false) == page);
                previous = base;
            }
            int last = -width;
            for (int i = 10000; i >= 0; i--) {
                int base = BookPageGeometry.baseOffset(width, i / 10000f);
                check(base >= last); // Back travels right, toward the previous page.
                last = base;
            }
        }
        System.out.println(checks + " production book geometry assertions passed");
    }
}
