package app.ziziplayer.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class SearchNavigationTest {
    @Test fun hubEntryOverridesAnyPreviousResultEditingOrigin() {
        assertEquals(SearchStage.HUB, SearchNavigation.editOrigin(SearchStage.HUB, SearchStage.RESULTS))
    }
    @Test fun resultFieldReturnsToResults() {
        assertEquals(SearchStage.RESULTS, SearchNavigation.editOrigin(SearchStage.RESULTS, SearchStage.HUB))
    }
    @Test fun typingAndClearingDoNotLoseTheEntryOrigin() {
        for (origin in listOf(SearchStage.HUB, SearchStage.RESULTS)) {
            assertEquals(origin, SearchNavigation.editOrigin(SearchStage.RECENT, origin))
            assertEquals(origin, SearchNavigation.editOrigin(SearchStage.SUGGEST, origin))
        }
    }
    @Test fun historyOpenedFromHubDoesNotReturnToAnOldQuery() {
        assertEquals(SearchStage.HUB, SearchNavigation.backFromEditor(SearchStage.HUB, "old query"))
    }
    @Test fun editingResultsReturnsToExistingQuery() {
        assertEquals(SearchStage.RESULTS, SearchNavigation.backFromEditor(SearchStage.RESULTS, "montagem"))
    }
    @Test fun emptyQueryCannotOpenAnEmptyResultsSurface() {
        assertEquals(SearchStage.HUB, SearchNavigation.backFromEditor(SearchStage.RESULTS, " "))
    }
}
