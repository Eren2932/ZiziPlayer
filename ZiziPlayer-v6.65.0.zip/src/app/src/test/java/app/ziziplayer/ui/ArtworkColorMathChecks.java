package app.ziziplayer.ui;

import app.ziziplayer.ui.theme.ArtworkColorMath;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Random;

/** Real production-math tests. Also executable without Android, Gradle or JUnit. */
public final class ArtworkColorMathChecks {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static int[] fill(int color) { int[] a = new int[4096]; Arrays.fill(a, color); return a; }
    private static int r(int c) { return (c >>> 16) & 255; }
    private static int g(int c) { return (c >>> 8) & 255; }
    private static int b(int c) { return c & 255; }
    private static double contrast(int a, int b) {
        double x = ArtworkColorMath.luminance(a), y = ArtworkColorMath.luminance(b);
        return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
    }
    private static double hue(int c) {
        double r = r(c), g = g(c), b = b(c);
        double max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        double d = max - min;
        if (d == 0) return 0;
        double h = max == r ? (g - b) / d : max == g ? (b - r) / d + 2 : (r - g) / d + 4;
        return (h * 60 + 360) % 360;
    }
    private static double hueGap(int a, int b) { return Math.abs((hue(a) - hue(b) + 540) % 360 - 180); }

    public static void uniformColoursKeepHue() {
        int[] inputs = {0xffff0000, 0xff00ff00, 0xff0000ff, 0xffff00ff, 0xffcc7722, 0xff8c8944, 0xff007788};
        for (int c : inputs) {
            int result = ArtworkColorMath.extract(fill(c))[0];
            check(hueGap(c, result) < 1, "Uniform cover changed hue");
        }
    }
    public static void primaryBeatsRivalHue() {
        int[] a = fill(0xffcc1122); Arrays.fill(a, 3000, 4096, 0xff1122cc);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) > b(c) * 4 && r(c) > g(c) * 4, "Red + minority blue turned purple");
    }
    public static void secondaryIsNotSynthetic() {
        int[] s = ArtworkColorMath.extract(fill(0xff20dd40));
        check(s[0] == s[1], "Single-hue cover acquired a made-up secondary");
        check(hueGap(s[0], s[2]) < 1, "Deep fallback rotated hue");
    }
    public static void redSeamIsCircular() {
        int[] a = fill(0xffee1020); Arrays.fill(a, 2048, 4096, 0xffee2010);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) > 200 && g(c) < 40 && b(c) < 40, "Red hue seam became cyan");
    }
    public static void neighbouringBinsCombine() {
        int[] a = fill(0xffdd1111); Arrays.fill(a, 1400, 2800, 0xffdd5511);
        Arrays.fill(a, 2800, 4096, 0xff1111dd);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) > b(c) * 3, "Split dominant hue lost to smaller blue region");
    }
    public static void blackAndWhiteStayNeutral() {
        int[] a = fill(0xffeeeeee); Arrays.fill(a, 1000, 4096, 0xff080808);
        for (int c : ArtworkColorMath.extract(a)) check(r(c) == g(c) && g(c) == b(c), "B/W tint");
    }
    public static void jpegNoiseStaysNeutral() {
        int[] a = fill(0xff777674); Arrays.fill(a, 2000, 4096, 0xff414344);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) == g(c) && g(c) == b(c), "JPEG noise invented a hue");
    }
    public static void tinyLogoCannotPaintPhotograph() {
        int[] a = fill(0xff777777); Arrays.fill(a, 0, 40, 0xff00ff00);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) == g(c) && g(c) == b(c), "One-percent logo painted whole backdrop");
    }
    public static void darkNoiseDoesNotOutvoteLitArtwork() {
        int[] a = fill(0xff092408); Arrays.fill(a, 0, 1800, 0xffd53024);
        int c = ArtworkColorMath.extract(a)[0];
        check(r(c) > g(c) * 3, "Near-black green overruled visible red");
    }
    public static void transparentPixelsCannotVote() {
        int[] a = fill(0x0000ff00); Arrays.fill(a, 0, 800, 0xffd32222);
        check(r(ArtworkColorMath.extract(a)[0]) > 180, "Hidden transparent RGB voted");
        check(ArtworkColorMath.extract(fill(0x8000ff00)) == null, "Translucent-only artwork should be unknown");
    }
    public static void emptyAndOversizeSamplesAreSafe() {
        check(ArtworkColorMath.extract(null) == null, "Null input");
        check(ArtworkColorMath.extract(new int[0]) == null, "Empty input");
        boolean rejected = false;
        try { ArtworkColorMath.extract(new int[4097]); } catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "Unbounded sampling accepted");
        check(ArtworkColorMath.extract(new int[]{0xffff0000}) != null, "One-pixel cover failed");
    }
    public static void extremesRemainGraphite() {
        for (int c : new int[]{0xff000000, 0xff777777, 0xffffffff}) {
            int[] ramp = ArtworkColorMath.backdrop(ArtworkColorMath.extract(fill(c))[0]);
            check(r(ramp[0]) == g(ramp[0]) && g(ramp[0]) == b(ramp[0]), "Neutral acquired tint");
            check(ArtworkColorMath.luminance(ramp[0]) > .04, "Neutral ramp is still invisible");
            check(ramp[6] == 0xff111111, "Bottom is not neutral near-black");
        }
    }
    public static void vividHueIsNotDesaturated() {
        int c = ArtworkColorMath.backdrop(0xff00ff00)[0];
        check(g(c) >= 110 && r(c) == 0 && b(c) == 0, "Vivid green became weak grey-green");
    }
    public static void visibleTopForDarkArt() {
        check(r(ArtworkColorMath.backdrop(0xff360606)[0]) >= 60, "Dark cover received invisible top");
    }
    public static void fullRgbGridHasReadableMonotoneRamps() {
        for (int r = 0; r <= 255; r += 17) for (int g = 0; g <= 255; g += 17) for (int b = 0; b <= 255; b += 17) {
            int primary = 0xff000000 | (r << 16) | (g << 8) | b;
            int[] ramp = ArtworkColorMath.backdrop(primary);
            double previous = Double.POSITIVE_INFINITY;
            for (int stop : ramp) {
                double lum = ArtworkColorMath.luminance(stop);
                check(lum <= previous + .0003, "Ramp got brighter near controls: " + Integer.toHexString(primary) + " " + previous + " -> " + lum);
                check(contrast(0xffe0e0e0, stop) >= 4.5, "Secondary text below 4.5:1");
                check(contrast(0xfff6f7f8, stop) >= 4.5, "Primary text below 4.5:1");
                check((stop >>> 24) == 255, "Background not opaque");
                previous = lum;
            }
            check(contrast(0xffe0e0e0, ArtworkColorMath.surface(primary)) >= 4.5, "Sheet contrast grid");
            check(contrast(0xffe0e0e0, ArtworkColorMath.chip(primary)) >= 4.5, "Chip contrast grid");
        }
    }
    public static void sourceHueSurvivesBrightnessCap() {
        for (int r = 0; r <= 255; r += 17) for (int g = 0; g <= 255; g += 17) for (int b = 0; b <= 255; b += 17) {
            if (Math.max(r, Math.max(g,b)) - Math.min(r, Math.min(g,b)) < 40) continue;
            int c = 0xff000000 | (r << 16) | (g << 8) | b;
            check(hueGap(c, ArtworkColorMath.coverTop(c)) < 3.5, "Brightness cap rotated hue");
        }
    }
    public static void randomInputIsDeterministicAndUntouched() {
        Random rng = new Random(6398);
        for (int n = 0; n < 24; n++) {
            int[] a = new int[4096]; for (int i = 0; i < a.length; i++) a[i] = rng.nextInt();
            int[] saved = a.clone(); int[] first = ArtworkColorMath.extract(a);
            check(Arrays.equals(first, ArtworkColorMath.extract(a)), "Non-deterministic swatches");
            check(Arrays.equals(saved, a), "Sampler mutated shared input");
        }
    }
    public static void mixEndpointsAreExact() {
        check(ArtworkColorMath.mix(0xff123456, 0xffabcdef, 0) == 0xff123456, "Mix start");
        check(ArtworkColorMath.mix(0xff123456, 0xffabcdef, 1) == 0xffabcdef, "Mix end");
    }
    public static void runAll() {
        uniformColoursKeepHue(); primaryBeatsRivalHue(); secondaryIsNotSynthetic(); redSeamIsCircular();
        neighbouringBinsCombine(); blackAndWhiteStayNeutral(); jpegNoiseStaysNeutral();
        tinyLogoCannotPaintPhotograph(); darkNoiseDoesNotOutvoteLitArtwork(); transparentPixelsCannotVote();
        emptyAndOversizeSamplesAreSafe(); extremesRemainGraphite(); vividHueIsNotDesaturated();
        visibleTopForDarkArt(); fullRgbGridHasReadableMonotoneRamps();
        sourceHueSurvivesBrightnessCap(); randomInputIsDeterministicAndUntouched(); mixEndpointsAreExact();
    }
    private static void referenceCrops(String folder) throws Exception {
        String[] names = {"ACIDTEKK", "COMA", "MENTE_MA", "Megalomaniac", "URANIUM", "WA_WA_WA"};
        double[] minHue = {0, 15, 320, 95, 30, 0};
        double[] maxHue = {0, 35, 345, 120, 60, 15};
        for (int i = 0; i < names.length; i++) {
            byte[] bytes = Files.readAllBytes(Path.of(folder, names[i] + ".argb"));
            check(bytes.length == 4096 * 4, "Reference sample size");
            int[] pixels = new int[4096];
            ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN).asIntBuffer().get(pixels);
            int[] swatches = ArtworkColorMath.extract(pixels);
            check(swatches != null, "Reference unexpectedly lost colour");
            int main = swatches[0];
            if (i == 0) check(r(main) == g(main) && g(main) == b(main), "ACIDTEKK must be graphite");
            else check(hue(main) >= minHue[i] && hue(main) <= maxHue[i], "Reference hue family: " + names[i]);
            System.out.printf("%s primary=#%06X top=#%06X%n", names[i], main & 0xffffff,
                    ArtworkColorMath.backdrop(main)[0] & 0xffffff);
        }
        System.out.println("PASS: 6 supplied reference crops (sampled covers, not rendered Compose screens).");
    }
    public static void main(String[] args) throws Exception {
        runAll();
        if (args.length > 0) referenceCrops(args[0]);
        System.out.println("PASS: 18 real JVM math cases; 4096-colour contrast grid; deterministic random samples.");
        System.out.println("Not an Android build, Compose render or device performance measurement.");
    }
}
