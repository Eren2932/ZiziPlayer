package app.ziziplayer.ui;

/** Референсные 1080 px и автообновление подборок; без Compose и без сети. */
public final class HomeHeader6580Checks {
    private static int checks;
    private static void check(boolean value, String label) {
        checks++; if (!value) throw new AssertionError(label);
    }
    private static float px(float viewportDp, float value) {
        return HomeHeaderGeometry.scale(viewportDp, value) * 1080f / viewportDp;
    }
    public static void main(String[] args) {
        float[] widths = {320f, 360f, 393f, 411f, 412f, 480f, 600f, 840f};
        for (float w : widths) {
            check(Math.abs(px(w, HomeHeaderGeometry.AVATAR) - 92f) < 0.001f, "avatar 92 px");
            check(Math.abs(px(w, HomeHeaderGeometry.CHIP_HEIGHT) - 92f) < 0.001f, "chip 92 px");
            check(Math.abs(px(w, HomeHeaderGeometry.INSET) - 46f) < 0.001f, "inset 46 px");
            check(Math.abs(px(w, HomeHeaderGeometry.TILE_HEIGHT) - 139f) < 0.001f, "tile 139 px");
            // Аватарка и вкладка одной высоты: шапка не «съезжает» по вертикали.
            check(HomeHeaderGeometry.AVATAR == HomeHeaderGeometry.CHIP_HEIGHT, "avatar equals chip height");
            float tile = HomeHeaderGeometry.tileWidth(w, 2);
            float inset = HomeHeaderGeometry.scale(w, HomeHeaderGeometry.INSET);
            float gap = HomeHeaderGeometry.scale(w, HomeHeaderGeometry.TILE_GAP);
            check(Math.abs(2f * tile + gap + 2f * inset - w) < 0.001f, "two tiles fill the row");
            check(Math.abs(HomeHeaderGeometry.tileWidth(w, 1) + 2f * inset - w) < 0.001f, "single column");
            check(tile > 0f && HomeHeaderGeometry.tileWidth(w, 1) > tile, "positive widths");
        }
        // 1080 px: колонка 482 px, ровно как измерено (46 .. 528 и 552 .. 1034).
        check(Math.abs(HomeHeaderGeometry.tileWidth(1080f, 2) - 482f) < 0.001f, "482 px tile");
        check(HomeHeaderGeometry.columns(393f, 1.0f) == 2, "two columns by default");
        check(HomeHeaderGeometry.columns(393f, 1.45f) == 1, "one column for large fonts");
        check(HomeHeaderGeometry.columns(280f, 1.0f) == 1, "one column on a narrow screen");
        check(HomeHeaderGeometry.tiles(0) == 0 && HomeHeaderGeometry.tiles(3) == 3
            && HomeHeaderGeometry.tiles(40) == 8, "bounded tile count");
        check(Math.abs(HomeHeaderGeometry.TILE_OVERLAY_ALPHA - 24f / 237f) < 1e-6f, "reference overlay");
        check(HomeHeaderGeometry.scale(0f, 46f) > 0f, "degenerate width is safe");

        // Автообновление: кнопки «Обновить» больше нет, решает арифметика.
        long now = 1_000_000_000L;
        check(HomeFeedRefreshPolicy.stale(now, 0L), "no snapshot is stale");
        check(!HomeFeedRefreshPolicy.stale(now, now - 60_000L), "fresh snapshot");
        check(HomeFeedRefreshPolicy.stale(now, now - HomeFeedRefreshPolicy.STALE_MS), "30 minutes");
        check(HomeFeedRefreshPolicy.stale(now, now + 5_000L), "clock moved backwards is stale");
        check(HomeFeedRefreshPolicy.shouldLoad(now, 0L, 0L, false), "cold start loads itself");
        check(!HomeFeedRefreshPolicy.shouldLoad(now, now - 60_000L, 0L, false), "no pointless reload");
        check(HomeFeedRefreshPolicy.shouldLoad(now, now - 60_000L, 0L, true), "force reloads");
        check(!HomeFeedRefreshPolicy.shouldLoad(now, 0L, now - 1_000L, true), "attempt gap holds even for force");
        check(HomeFeedRefreshPolicy.shouldLoad(now, 0L, now - 20_000L, false), "retry after the gap");
        check(HomeFeedRefreshPolicy.retryDelayMs(1) == 15_000L, "first retry 15 s");
        check(HomeFeedRefreshPolicy.retryDelayMs(2) == 45_000L, "second retry 45 s");
        check(HomeFeedRefreshPolicy.retryDelayMs(3) == 135_000L, "third retry 135 s");
        check(HomeFeedRefreshPolicy.retryDelayMs(4) == 0L, "no fourth retry");
        check(HomeFeedRefreshPolicy.retryDelayMs(0) == 0L && HomeFeedRefreshPolicy.retryDelayMs(-1) == 0L, "guarded input");
        check(HomeFeedRefreshPolicy.canRetry(1) && HomeFeedRefreshPolicy.canRetry(3)
            && !HomeFeedRefreshPolicy.canRetry(4) && !HomeFeedRefreshPolicy.canRetry(0), "retry budget");
        for (int i = 1; i <= HomeFeedRefreshPolicy.MAX_RETRIES; i++) {
            check(HomeFeedRefreshPolicy.retryDelayMs(i) >= HomeFeedRefreshPolicy.ATTEMPT_GAP_MS, "retry respects the gap");
            check(HomeFeedRefreshPolicy.retryDelayMs(i) <= HomeFeedRefreshPolicy.MAX_RETRY_MS, "retry is capped");
        }
        System.out.println("PASS: " + checks + " home header geometry / auto-refresh assertions; not Compose, not the catalog");
    }
}
