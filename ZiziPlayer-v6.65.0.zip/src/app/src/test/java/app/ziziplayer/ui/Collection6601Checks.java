package app.ziziplayer.ui;

/** Executes production constants and scroll math. Does not render Compose. */
public final class Collection6601Checks {
    private static int assertions;
    private static void ok(boolean value) { assertions++; if (!value) throw new AssertionError("check " + assertions); }
    private static void near(float a, float b) { ok(Math.abs(a - b) < .005f); }
    public static void main(String[] args) {
        near(CollectionGeometry.ACTION_SIZE, 48f);
        near(CollectionGeometry.ACTION_END, 20f);
        near(CollectionGeometry.SHUFFLE_ICON_SIZE, 28f);
        // Existing 24-unit glyph spans ~18 units including its stroke: 28dp canvas
        // gives ~21dp visible arrows, matching the reference's ~64px at 1080/360.
        ok(Math.abs(CollectionGeometry.SHUFFLE_ICON_SIZE * 18f / 24f - 64f / 3f) < 1f);
        // Full-resolution reference: 1080px wide, play bounds x884..1022 (139px).
        // Normalize to 360dp, round to practical dp, keep a >=48dp hit target.
        ok(Math.abs(CollectionGeometry.ACTION_SIZE - 139f * 360f / 1080f) < 2f);
        ok(Math.abs(CollectionGeometry.ACTION_END - 57f * 360f / 1080f) < 2f);
        ok(Math.abs(CollectionGeometry.ACTION_SIZE - 143.5f * 360f / 1080f) < 2f);
        for (float width : new float[]{240, 320, 360, 393, 411, 600, 840}) {
            float playLeft = width - CollectionGeometry.ACTION_END - CollectionGeometry.ACTION_SIZE;
            float shuffleLeft = playLeft - CollectionGeometry.ACTION_SIZE;
            ok(shuffleLeft >= CollectionGeometry.ACTION_END);
            near(playLeft - shuffleLeft, 48f);
            for (float density : new float[]{1, 1.5f, 2, 2.625f, 3, 4}) {
                for (float hero : new float[]{350, 470, 700, 1200}) {
                    float expanded = (hero - CollectionGeometry.ACTION_SIZE - CollectionGeometry.ACTION_BOTTOM_GAP) * density;
                    float pinned = (56f - CollectionGeometry.ACTION_SIZE / 2f) * density;
                    float travel = expanded - pinned;
                    near(CollectionGeometry.pinnedPlayTop(0, expanded, pinned), expanded);
                    near(CollectionGeometry.pinnedPlayTop(travel, expanded, pinned), pinned);
                    near(CollectionCollapseMath.banner(0, travel), 0);
                    near(CollectionCollapseMath.banner(travel * .64f, travel), 0);
                    ok(CollectionCollapseMath.banner(travel * .66f, travel) > 0);
                    near(CollectionCollapseMath.banner(travel, travel), 1);
                    float lastAlpha = -1;
                    for (int i = 0; i <= 200; i++) {
                        float scroll = travel * i / 200f;
                        float alpha = CollectionCollapseMath.banner(scroll, travel);
                        ok(alpha >= lastAlpha && alpha >= 0 && alpha <= 1);
                        lastAlpha = alpha;
                        float top = CollectionGeometry.pinnedPlayTop(scroll, expanded, pinned);
                        ok(top >= pinned && top <= expanded);
                        // Hero shuffle and moving Play share a baseline until Play pins.
                        near(top, expanded - scroll);
                    }
                    // Removing the editor must not break pinning on 0/1/2-track lists.
                    for (int count : new int[]{0, 1, 2, 50}) {
                        float row = Math.min(CollectionGeometry.ROW * width / CollectionGeometry.REFERENCE_WIDTH, 71f);
                        float bottom = 140f;
                        float tail = CollectionGeometry.minimumPinnedTail(720f, row * count, bottom,
                            CollectionGeometry.ACTION_SIZE, CollectionGeometry.ACTION_BOTTOM_GAP, pinned / density);
                        float maxScroll = hero + row * count + bottom + tail - 720f;
                        ok(maxScroll + .005f >= travel / density);
                    }
                }
            }
        }
        System.out.println("PASS: " + assertions + " collection action/scroll assertions; NOT a rendered UI test");
    }
}
