package app.ziziplayer.lyrics;

/** Synthetic text only; executes the production fallback validator. */
public final class LyricsFallbackChecks {
    private static int checks;
    private static void same(String expected, String actual) {
        checks++;
        if (expected == null ? actual != null : !expected.equals(actual))
            throw new AssertionError("Fallback text check " + checks + " failed");
    }
    public static void run() {
        checks = 0;
        same(null, LyricsFallbackText.clean(null));
        same(null, LyricsFallbackText.clean(""));
        same(null, LyricsFallbackText.clean(" \r\n\t "));
        same(null, LyricsFallbackText.clean(" 　"));
        same(null, LyricsFallbackText.clean("\ufeff"));
        same("строка café 🎵\n次の行", LyricsFallbackText.clean("\ufeff  строка café 🎵\r\n次の行  "));
        same("one\ntwo\nthree", LyricsFallbackText.clean("one\rtwo\r\nthree"));
        same("tabs\tare fine", LyricsFallbackText.clean("tabs\tare fine"));
        same(null, LyricsFallbackText.clean("<html>blocked</html>"));
        same(null, LyricsFallbackText.clean("<!DOCTYPE html>failure"));
        same(null, LyricsFallbackText.clean("<SCRIPT>alert(1)</SCRIPT>"));
        same(null, LyricsFallbackText.clean("some text <iframe src='example'>"));
        same(null, LyricsFallbackText.clean("broken" + (char)0 + "data"));
        same(null, LyricsFallbackText.clean("escape" + (char)27 + "data"));
        // A bracketed cue in a PLAIN field stays plain: never invent a synchronized document.
        same("[00:01.00]synthetic", LyricsFallbackText.clean("[00:01.00]synthetic"));
        same("<3 synthetic", LyricsFallbackText.clean("<3 synthetic"));
        same("I'm here — ¿qué tal?", LyricsFallbackText.clean("I'm here — ¿qué tal?"));
        String max = new String(new char[100_000]).replace('\0', 'x');
        same(max, LyricsFallbackText.clean(max));
        same(null, LyricsFallbackText.clean(max + "x"));
        System.out.println("PASS: " + checks + " production Java fallback-text assertions");
    }
    public static void main(String[] args) { run(); }
}
