package app.ziziplayer.ui;
import org.junit.Test;
public class Collection6600Test {
    @Test public void geometryColorAndProfileRules() { Collection6600Checks.main(new String[0]); }
}
