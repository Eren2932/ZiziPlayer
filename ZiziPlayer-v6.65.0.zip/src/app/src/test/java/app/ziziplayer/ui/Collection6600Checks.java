package app.ziziplayer.ui;

import java.util.*;
import app.ziziplayer.ui.theme.ArtworkColorMath;

public final class Collection6600Checks {
    private static int assertions;
    private static void ok(boolean value) { assertions++; if (!value) throw new AssertionError("check " + assertions); }
    private static void near(float a, float b) { ok(Math.abs(a-b) < .003f); }
    public static void main(String[] args) {
        for (float width : new float[]{240, 320, 360, 393, 411, 600, 840}) {
            float max = Math.min(width * .66f, 280f);
            float min = Math.min(max, Math.max(64f, max * .44f));
            float last = max;
            for (int step = 0; step <= 1000; step++) {
                float value = CollectionCollapseMath.coverSize(max, min, step/1000f);
                ok(value <= last + .001f && value >= min-.001f && value <= max+.001f);
                last = value;
            }
            near(CollectionCollapseMath.coverSize(max,min,0), max);
            near(CollectionCollapseMath.coverSize(max,min,1), min);
        }
        Random random = new Random(6600);
        for (int i=0;i<100000;i++) {
            float range=1+random.nextFloat()*1000;
            float old=random.nextFloat()*range;
            float dy=(random.nextFloat()-.5f)*4000;
            float next=CollectionCollapseMath.next(old,dy,range);
            float consumed=old-next;
            ok(next>=0 && next<=range);
            ok(Math.abs(consumed)<=Math.abs(dy)+.001f);
            ok(consumed==0 || Math.signum(consumed)==Math.signum(dy));
            near(CollectionCollapseMath.next(next,-consumed,range),old);
        }
        near(CollectionCollapseMath.next(12,Float.NaN,100),12);
        near(CollectionCollapseMath.next(12,-10,0),0);
        near(CollectionCollapseMath.next(0,-1000,120),120);
        near(CollectionCollapseMath.next(120,1000,120),0);
        for (float travel : new float[]{1,60,300,600,2000}) {
            float last=0;
            for(int i=0;i<=1000;i++) {
                float alpha=CollectionCollapseMath.banner(travel*i/1000f,travel);
                ok(alpha>=last-.00001f && alpha>=0 && alpha<=1); last=alpha;
            }
            near(CollectionCollapseMath.banner(0,travel),0);
            near(CollectionCollapseMath.banner(travel,travel),1);
        }
        String a=ProfilePlaylistPolicy.key(1,10), b=ProfilePlaylistPolicy.key(1,11);
        ok(!a.equals(b));
        Set<String> empty=Collections.emptySet();
        Set<String> hidden=ProfilePlaylistPolicy.update(empty,Set.of(a),true);
        ok(empty.isEmpty() && hidden.contains(a) && !hidden.contains(b));
        ok(ProfilePlaylistPolicy.update(hidden,Set.of(a),true).equals(hidden));
        ok(ProfilePlaylistPolicy.update(hidden,Set.of(a),false).isEmpty());
        ok(ProfilePlaylistPolicy.eligible(Set.of(a,b),Set.of(b)).equals(Set.of(b)));
        ok(hidden.contains(a));
        for(int color : new int[]{0xffff0000,0xff00ff00,0xff0000ff,0xffffffff,0xff000000,0xff777777}) {
            int[] pixels=new int[4096];Arrays.fill(pixels,color);
            int[] extracted=ArtworkColorMath.extract(pixels);
            int tint=ArtworkColorMath.coverTop(extracted[0]);
            ok((tint >>> 24)==255);
            if((color & 0xffffff)==0x777777 || color==0xff000000 || color==0xffffffff)
                ok(((tint>>16)&255)==((tint>>8)&255) && ((tint>>8)&255)==(tint&255));
        }
        System.out.println("PASS: "+assertions+" production JVM assertions (not Android/device tests)");
    }
}
