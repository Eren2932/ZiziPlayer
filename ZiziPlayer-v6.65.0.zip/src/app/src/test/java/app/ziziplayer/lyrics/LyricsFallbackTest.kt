package app.ziziplayer.lyrics

import org.junit.Test

class LyricsFallbackTest {
    @Test fun validatesSyntheticPlainText() { LyricsFallbackChecks.run() }
}
