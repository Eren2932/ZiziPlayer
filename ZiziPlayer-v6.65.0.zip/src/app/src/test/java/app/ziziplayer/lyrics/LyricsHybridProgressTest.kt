package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class LyricsHybridProgressTest {
    private val track=TrackEntity(id="test",uri="",title="Synthetic",artist="Test",durationMs=100_000)
    private fun plain(verified: Boolean = true)=JSONObject().put("source","test").put("plainLyrics","synthetic").put("matchVerified",verified)
    private fun p(name:String, run:suspend ()->JSONObject?)=object:LyricsProvider {
        override val id=name
        override val budgetMs=1000L
        override suspend fun lookup(track:TrackEntity,http:suspend (Request)->String,trace:LyricsLookupTrace?)=run()
    }
    @Test fun plainIsPublishedBeforeSynchronizedUpgrade()=runBlocking {
        val first=plain();val synced=plain().put("syncedLyrics","[00:01]synthetic\n[00:02]next")
        var published=false
        val engine=LyricsHybridLookup(listOf(p("plain"){first},p("sync"){assertTrue(published);synced}),{0L},true)
        val result=engine.lookup(track,{_,_->error("no HTTP")},null){assertSame(first,it);published=true}
        assertSame(synced,result)
    }
    @Test fun laterErrorDoesNotDiscardPlain()=runBlocking {
        val first=plain()
        val engine=LyricsHybridLookup(listOf(p("plain"){first},p("error"){throw IOException("offline")}),{0L},true)
        assertSame(first,engine.lookup(track,{_,_->""},null))
    }
    @Test fun unverifiedFallbackCannotReplaceVerifiedPlain()=runBlocking {
        val first=plain()
        val engine=LyricsHybridLookup(listOf(p("verified"){first},p("unverified"){plain(false)}),{0L},true)
        var count=0
        assertSame(first,engine.lookup(track,{_,_->""},null){count++});assertEquals(1,count)
    }
    @Test fun cancellationAfterProgressStillPropagates()=runBlocking {
        val engine=LyricsHybridLookup(listOf(p("plain"){plain()},p("cancel"){throw CancellationException("changed")}),{0L},true)
        try {engine.lookup(track,{_,_->""},null);fail()}catch (_:CancellationException){}
    }
    @Test fun synchronizedHitStopsFurtherSources()=runBlocking {
        var called=false
        val sync=plain().put("syncedLyrics","[00:01]synthetic\n[00:02]next")
        val engine=LyricsHybridLookup(listOf(p("sync"){sync},p("backup"){called=true;plain()}),{0L},true)
        assertSame(sync,engine.lookup(track,{_,_->""},null));assertFalse(called)
    }
    @Test fun sumOfBudgetsRemainsBounded() {
        try {
            LyricsHybridLookup(listOf(object:LyricsProvider {
                override val id="over"
                override val budgetMs=35000L
                override suspend fun lookup(track:TrackEntity,http:suspend(Request)->String,trace:LyricsLookupTrace?):JSONObject?=null
            }),{0L},true)
            fail()
        }catch (_:IllegalArgumentException){}
    }
}
