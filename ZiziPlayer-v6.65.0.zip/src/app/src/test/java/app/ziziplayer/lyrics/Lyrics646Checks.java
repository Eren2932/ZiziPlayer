package app.ziziplayer.lyrics;

import app.ziziplayer.ui.LyricsGeometry;

public final class Lyrics646Checks {
    private static int assertions;
    private static void check(boolean value, String label) {
        assertions++;
        if (!value) throw new AssertionError(label);
    }
    private static void near(float value, float expected, String label) {
        check(Math.abs(value - expected) < 0.02f, label + ": " + value + " != " + expected);
    }
    public static void run() {
        assertions = 0;
        check(LyricsMatchPolicy.identityMatches("Still With You", "Jungkook", "Still with you", "Jung Kook"), "artist spaces");
        check(LyricsMatchPolicy.identityMatches("Still With You (Official Audio)", "JUNGKOOK", "Still With You", "Jung Kook"), "cosmetic title");
        check(LyricsMatchPolicy.identityMatches("Song [Lyrics]", "Artist", "Song", "Artist"), "cosmetic square brackets");
        check(LyricsMatchPolicy.identityMatches("Song (Official Music Video)", "Artist", "Song", "Artist"), "official music video");
        check(LyricsMatchPolicy.identityMatches("Ｓｏｎｇ", "Artist", "Song", "Artist"), "NFKC");
        check(LyricsMatchPolicy.identityMatches("Café", "Søren", "Café", "Søren"), "canonical unicode");
        check(!LyricsMatchPolicy.identityMatches("Song", "Artist", "Song", "Other Artist"), "wrong artist rejected");
        check(!LyricsMatchPolicy.identityMatches("Song", "Artist", "Different song", "Artist"), "wrong title rejected");
        check(!LyricsMatchPolicy.identityMatches("Outside (Slowed + Reverb)", "skyemane", "Outside", "skyemane"), "slowed qualifier retained");
        check(!LyricsMatchPolicy.identityMatches("Song (Live)", "Artist", "Song", "Artist"), "live qualifier retained");
        check(!LyricsMatchPolicy.identityMatches("Song (Remix)", "Artist", "Song", "Artist"), "remix qualifier retained");
        check(!LyricsMatchPolicy.identityMatches("Song (Instrumental)", "Artist", "Song", "Artist"), "instrumental qualifier retained");
        check(!LyricsMatchPolicy.identityMatches("Song (Official Audio Remix)", "Artist", "Song", "Artist"), "mixed qualifier retained");
        check(!LyricsMatchPolicy.identityMatches("", "Artist", "Song", "Artist"), "empty title");
        check(!LyricsMatchPolicy.identityMatches("Song", "", "Song", "Artist"), "empty artist");
        check(!LyricsMatchPolicy.identityMatches(null, null, null, null), "null metadata");
        check(LyricsMatchPolicy.textDurationMatches(239000, 242000), "three-second metadata delta has plain text");
        check(!LrcTimeline.durationMatches(239000, 242000), "same delta must NOT karaoke");
        check(LrcTimeline.durationMatches(239000, 241000), "strict boundary sync");
        check(LyricsMatchPolicy.textDurationMatches(0, 239000), "unknown duration allows plain text");
        check(!LrcTimeline.durationMatches(0, 239000), "unknown duration cannot sync");
        check(!LyricsMatchPolicy.textDurationMatches(239000, 0), "invalid candidate duration");
        check(LyricsMatchPolicy.textDurationMatches(200000, 220000), "plain 10 percent boundary");
        check(!LyricsMatchPolicy.textDurationMatches(200000, 220001), "beyond plain boundary");
        check(!LyricsMatchPolicy.textDurationMatches(239000, 359000), "unrelated length");
        check(LyricsMatchPolicy.retryDelay(1000, 61000) == 60000, "provider backoff retained");
        check(LyricsMatchPolicy.retryDelay(61001, 61000) == 1, "expired backoff nonnegative");
        // Same 1080px image at realistic Android density settings. These execute the very
        // production formulas used by Compose; they are not screenshots of rendered Compose.
        for (float density : new float[]{2.75f, 2.875f, 2.9f, 3f}) {
            float width = 1080f / density;
            float diameter = LyricsGeometry.playDiameter(width, false) * density;
            float bottom = LyricsGeometry.bottomGap(width, false) * density;
            float top = 2400f - bottom - diameter;
            float slider = top - (15f + LyricsGeometry.progressTimeHeight(width, false)) * density;
            near(diameter, 185f, "reference diameter");
            near(bottom, 46f, "reference bottom margin");
            near(top, 2169f, "reference circle top");
            near(top + diameter / 2, 2261.5f, "reference circle centre");
            near(slider, 2097f, "reference slider centre");
            near(LyricsGeometry.headerFont(width) * density, 38f, "reference title size");
            near(LyricsGeometry.headerLine(width) * density, 51f, "reference header line spacing");
        }
        for (float width : new float[]{240f, 320f, 360f, 411f, 600f, 840f}) {
            float diameter = LyricsGeometry.playDiameter(width, false);
            check(diameter >= 48f && diameter <= 80f, "accessible normal target");
            near(LyricsGeometry.playDiameter(width, true), 48f, "compact target");
            check(LyricsGeometry.progressTimeHeight(width, true) >= 0, "compact nonnegative row");
        }
        System.out.println("PASS: " + assertions + " production metadata/geometry assertions. Not an Android render or provider test.");
    }
    public static void main(String[] args) { run(); }
}
