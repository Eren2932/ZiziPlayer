package app.ziziplayer.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** Plain state tests: no Android context, network or JSON framework calls. */
class LibrarySyncStateTest {
    private fun preview() = LibraryPreview(3, 2, 1, 0, emptyList())

    @Test fun defaultStateHasNoErrorOrCloudSnapshot() {
        val state = LibrarySyncState()
        assertEquals("", state.error)
        assertNull(state.cloudPreview)
        assertNull(state.cloudHash)
        assertFalse(state.busy)
        assertFalse(state.enabled)
        assertFalse(state.cloudAvailable)
    }

    @Test fun copyCarriesCloudPreviewAndHashTogether() {
        val preview = preview()
        val state = LibrarySyncState().copy(
            cloudAvailable = true, cloudPreview = preview, cloudHash = "snapshot-hash")
        val busy = state.copy(busy = true)
        assertSame(preview, busy.cloudPreview)
        assertEquals("snapshot-hash", busy.cloudHash)
        assertTrue(busy.cloudAvailable)
        assertNull(LibrarySyncState().cloudHash)
    }

    @Test fun failureAndRetryPreserveSnapshotAndConflict() {
        val preview = preview()
        val failed = LibrarySyncState(cloudPreview = preview, cloudHash = "snapshot-hash")
            .copy(message = "Conflict", error = "Conflict", needsChoice = true)
        assertEquals("Conflict", failed.error)
        val retrying = failed.copy(busy = true, error = "")
        assertEquals("", retrying.error)
        assertTrue(retrying.needsChoice)
        assertSame(preview, retrying.cloudPreview)
        assertEquals("snapshot-hash", retrying.cloudHash)
        assertEquals("Conflict", failed.error)
    }

    @Test fun newConnectionStateDoesNotReusePreviousAccountSnapshot() {
        val previous = LibrarySyncState(error = "Failure", cloudPreview = preview(),
            cloudHash = "previous-account-hash", savedAt = 42L)
        val connecting = LibrarySyncState(busy = true)
        assertTrue(connecting.busy)
        assertEquals("", connecting.error)
        assertNull(connecting.cloudPreview)
        assertNull(connecting.cloudHash)
        assertEquals(0L, connecting.savedAt)
        assertEquals("previous-account-hash", previous.cloudHash)
    }

    @Test fun cloudMetadataCanBeClearedExplicitly() {
        val populated = LibrarySyncState(cloudAvailable = true,
            cloudPreview = preview(), cloudHash = "snapshot-hash")
        val cleared = populated.copy(cloudAvailable = false, cloudPreview = null, cloudHash = null)
        assertFalse(cleared.cloudAvailable)
        assertNull(cleared.cloudPreview)
        assertNull(cleared.cloudHash)
        assertEquals("snapshot-hash", populated.cloudHash)
    }
}
