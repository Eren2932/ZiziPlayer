package app.ziziplayer.ui;
import org.junit.Test;
public class Home6490Test {
    @Test public void rankingAndGeometry() { Home6490Checks.main(new String[0]); }
}
