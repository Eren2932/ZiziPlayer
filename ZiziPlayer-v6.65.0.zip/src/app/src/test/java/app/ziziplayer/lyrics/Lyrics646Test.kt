package app.ziziplayer.lyrics

import org.junit.Test

class Lyrics646Test {
    @Test fun metadataAndGeometry() { Lyrics646Checks.run() }
}
