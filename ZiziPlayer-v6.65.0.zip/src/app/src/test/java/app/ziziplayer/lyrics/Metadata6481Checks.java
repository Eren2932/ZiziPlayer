package app.ziziplayer.lyrics;
import app.ziziplayer.playback.StartupTrace;
public final class Metadata6481Checks {
    private static void check(boolean value, String name) { if (!value) throw new AssertionError(name); }
    public static void main(String[] args) {
        check(LyricsMatchPolicy.identityMatches("Hai Phút Hơn", "Phao", "Hai Phút Hơn", "Pháo"), "observed LRCLIB Hai metadata");
        check(LyricsMatchPolicy.identityMatches("Beast (feat. Waka Flocka)", "Mia Martina", "Beast", "Mia Martina"), "omitted feature");
        check(LyricsMatchPolicy.requiresExactDuration("Beast (feat. Waka Flocka)", "Beast"), "omitted feature has duration gate");
        check(LrcTimeline.durationMatches(189000,190000), "observed Beast duration");
        check(!LrcTimeline.durationMatches(189000,217000), "different Beast duration rejected");
        check(LyricsMatchPolicy.identityMatches("Beast (feat. Waka Flocka)", "Mia Martina", "Beast (ft. Waka Flocka)", "Mia Martina"), "ft alias");
        check(LyricsMatchPolicy.identityMatches("Beast (feat. Waka Flocka)", "Mia Martina", "Beast", "Mia Martina, Waka Flocka"), "credit moved into artist");
        check(!LyricsMatchPolicy.identityMatches("Beast (feat. Waka Flocka)", "Mia Martina", "Beast (feat. Other)", "Mia Martina"), "wrong guest");
        check(!LyricsMatchPolicy.identityMatches("Hai Phút Hơn", "Phao", "Hai Phút Hơn", "Masew"), "different credited artist");
        check(!LyricsMatchPolicy.identityMatches("Song feat. Guest (Alice Remix)", "Artist", "Song feat. Guest (Bob Remix)", "Artist"), "named remix retained");
        check(!LyricsMatchPolicy.identityMatches("Song", "Artist", "Song (feat. Guest Remix)", "Artist"), "mixed feature-version retained");
        check(LyricsMatchPolicy.searchTitle("Beast (feat. Waka Flocka)").equals("Beast"), "bounded search fallback title");
        StartupTrace.Span s=StartupTrace.begin(StartupTrace.Stage.MATCH);
        StartupTrace.http(s,404); StartupTrace.finish(s,StartupTrace.Outcome.ERROR);
        String first=StartupTrace.snapshot();
        StartupTrace.http(s,200); StartupTrace.finish(s,StartupTrace.Outcome.OK);
        check(first.equals(StartupTrace.snapshot()), "ended span immutable");
        check(first.contains("MATCH HTTP=404"), "status available without body or URL");
        System.out.println("PASS: 14 metadata/duration/trace assertions (not Android runtime)");
    }
}
