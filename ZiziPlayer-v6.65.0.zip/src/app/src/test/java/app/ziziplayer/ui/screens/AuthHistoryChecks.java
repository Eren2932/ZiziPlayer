package app.ziziplayer.ui.screens;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Uses production AuthHistory, can run offline without Android/JUnit. */
public final class AuthHistoryChecks {
    private static int checks;
    private static void check(boolean value) {
        checks++;
        if (!value) throw new AssertionError("AuthHistory assertion " + checks);
    }
    public static void main(String[] args) { run(); }
    public static void run() {
        checks = 0;
        AuthHistory<String> h = new AuthHistory<>("register-email");
        check(!h.back());
        check(!h.forward("register-email"));
        check(h.forward("register-password"));
        check(!h.back());
        check(!h.forward("verify"));
        check(!h.resetTo(List.of("login-email")));
        h.settle(h.revision());
        check(h.forward("verify"));
        h.settle(h.revision());
        check(h.back());
        check(h.current().equals("register-password"));
        long revision = h.revision();
        h.settle(revision - 1);
        check(h.isMoving());
        check(!h.back());
        h.settle(revision);
        check(h.back());
        check(h.current().equals("register-email"));
        h.settle(h.revision());
        check(!h.back());
        check(h.resetTo(List.of("login-email", "login-password")));
        check(!h.isBackwards());
        h.settle(h.revision());
        check(h.back());
        check(h.current().equals("login-email"));
        h.settle(h.revision());
        check(!h.back());
        try { h.resetTo(List.of()); throw new AssertionError(); }
        catch (IllegalArgumentException expected) { check(h.depth() == 1); }

        // Fixed seed: compare 20,000 actions with a simple reference stack.
        Random random = new Random(6541);
        AuthHistory<Integer> actual = new AuthHistory<>(0);
        ArrayList<Integer> model = new ArrayList<>(List.of(0));
        boolean moving = false;
        boolean backwards = false;
        long rev = 0;
        for (int i = 0; i < 20000; i++) {
            int action = random.nextInt(5);
            int next = random.nextInt(7);
            switch (action) {
                case 0 -> {
                    boolean accepted = !moving && model.get(model.size()-1) != next;
                    check(actual.forward(next) == accepted);
                    if (accepted) { model.add(next); moving = true; backwards = false; rev++; }
                }
                case 1 -> {
                    boolean accepted = !moving && model.size() > 1;
                    check(actual.back() == accepted);
                    if (accepted) { model.remove(model.size()-1); moving = true; backwards = true; rev++; }
                }
                case 2 -> { actual.settle(rev); moving = false; }
                case 3 -> actual.settle(rev - 1);
                case 4 -> {
                    check(actual.resetTo(List.of(0, next)) == !moving);
                    if (!moving) { model.clear(); model.add(0); model.add(next); moving = true; backwards = false; rev++; }
                }
                default -> throw new AssertionError();
            }
            check(actual.current().equals(model.get(model.size()-1)));
            check(actual.depth() == model.size());
            check(actual.revision() == rev);
            check(actual.isMoving() == moving);
            check(actual.isBackwards() == backwards);
        }
        System.out.println(checks + " production AuthHistory assertions passed");
    }
}
