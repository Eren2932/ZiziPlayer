package app.ziziplayer.ui

import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import org.junit.Assert.*
import org.junit.Test

class HubContentTest {
    private fun song(id: String, provider: String = "dz", title: String = "Track") =
        RemoteItem.Song(RemoteTrack(provider, id, title, "Artist"))

    @Test fun duplicateShelfTitlesMergeWithoutDuplicateLazyKeys() {
        val result = HubContent.normalize(listOf(
            DiscoverShelf(" Hits ", listOf(song("1"), song("1"))),
            DiscoverShelf("Hits", listOf(song("1"), song("2")))
        ))
        assertEquals(1, result.size)
        assertEquals("Hits", result.single().title)
        assertEquals(listOf(song("1"), song("2")), result.single().items)
    }

    @Test fun emptyAndUnsupportedItemsDoNotReachTheUi() {
        val result = HubContent.normalize(listOf(
            DiscoverShelf(" ", listOf(song("1"))),
            DiscoverShelf("Empty", emptyList()),
            DiscoverShelf("Hits", listOf(song(""), song("2", "retired"), song("3", title = " "), song("4")))
        ))
        assertEquals(listOf(DiscoverShelf("Hits", listOf(song("4")))), result)
    }

    @Test fun identicalIdsInDifferentProvidersRemainDistinct() {
        val result = HubContent.normalize(listOf(DiscoverShelf("Hits", listOf(song("1", "dz"), song("1", "yt")))))
        assertEquals(2, result.single().items.size)
    }

    @Test fun outputIsBoundedAndStable() {
        val input = (1..100).map { i -> DiscoverShelf("$i", (1..500).map { song("$it") }) }
        val result = HubContent.normalize(input)
        assertEquals(HubContent.MAX_SHELVES, result.size)
        assertTrue(result.all { it.items.size == HubContent.MAX_ITEMS })
        assertEquals(result, HubContent.normalize(result))
    }

    @Test fun groupAndSongKeysCannotCollide() {
        val group = RemoteItem.Group(RemoteCollection("dz", "1", RemoteKind.ALBUM, "Album"))
        assertNotEquals(HubContent.itemKey(song("1")), HubContent.itemKey(group))
    }

    @Test fun sourceDataIsNotMutated() {
        val items = mutableListOf<RemoteItem>(song("1"), song("1"))
        HubContent.normalize(listOf(DiscoverShelf(" Hits ", items)))
        assertEquals(2, items.size)
    }
}
