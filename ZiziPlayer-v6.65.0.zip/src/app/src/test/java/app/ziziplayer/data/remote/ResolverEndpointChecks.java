package app.ziziplayer.data.remote;

public final class ResolverEndpointChecks {
    private static int checks;
    private static void check(String saved, String baked, String expected) {
        String actual = ResolverEndpoint.effective(saved, baked);
        if (!expected.equals(actual)) throw new AssertionError("Unexpected endpoint policy result");
        if (!actual.equals(ResolverEndpoint.effective(actual, baked)))
            throw new AssertionError("Migration must be idempotent");
        checks++;
    }
    public static void main(String[] args) {
        String secure = ResolverEndpoint.DEFAULT_URL;
        check(null, null, secure);
        check("", "", secure);
        check(" \n", " \t", secure);
        check(null, "147.45.166.244:8080", secure);
        check(null, "http://147.45.166.244:8080/", secure);
        check("147.45.166.244:8080/", "https://custom.example", secure);
        check("  http://147.45.166.244:8080///  ", "", secure);
        check("http://ziziplayer-audio.duckdns.org/", "", secure);
        check(secure + "/", "", secure);
        check("", "https://custom.example/resolver/", "https://custom.example/resolver");
        check("https://custom.example/resolver/", secure, "https://custom.example/resolver");
        check("http://192.168.1.2:8080/", secure, "http://192.168.1.2:8080");
        check("http://147.45.166.244:8080/custom", secure, "http://147.45.166.244:8080/custom");
        check("http://147.45.166.244:8081", secure, "http://147.45.166.244:8081");
        check("http://147.45.166.244:8080.evil.example", secure, "http://147.45.166.244:8080.evil.example");
        check("http://user@147.45.166.244:8080", secure, "http://user@147.45.166.244:8080");
        check("http://147.45.166.244:8080?custom=1", secure, "http://147.45.166.244:8080?custom=1");
        check("https://ziziplayer.duckdns.org/lyrics", secure, "https://ziziplayer.duckdns.org/lyrics");
        System.out.println("ResolverEndpoint: " + checks + " cases + idempotence passed");
    }
}
