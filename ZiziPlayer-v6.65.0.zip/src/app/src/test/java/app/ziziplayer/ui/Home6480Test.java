package app.ziziplayer.ui;

import org.junit.Test;

public final class Home6480Test {
    @Test public void measuredHeaderAndPinnedPlay() {
        Home6480Checks.main(new String[0]);
    }
}
