package app.ziziplayer.lyrics;

import java.util.Random;

/** Executes production Java, not a separate Python reimplementation. */
public final class Lyrics645Checks {
    private static int checks;
    private static void check(boolean value, String reason) {
        checks++;
        if (!value) throw new AssertionError(reason);
    }
    public static void run() {
        checks = 0;
        var lines = LrcTimeline.parse("[offset:100]\n[00:01.000]<00:01.000>Привет <00:01.500>мир 🌍<00:02.000>\n[00:03.000]Пауза");
        var line = lines.get(0);
        check(line.words.size() == 2, "real word spans retained; end marker is not a word");
        check(line.timeMs == 900 && line.words.get(1).timeMs == 1400, "offset applies once to cue and words");
        check(line.text.substring(line.words.get(1).start, line.words.get(1).end).equals("мир 🌍"), "UTF16 text span incl emoji");
        check(LrcTimeline.activeWord(line, 899, 0) == -1, "before first word");
        check(LrcTimeline.activeWord(line, 900, 0) == 0, "first exact word boundary");
        check(LrcTimeline.activeWord(line, 1399, 0) == 0, "before second word");
        check(LrcTimeline.activeWord(line, 1400, 0) == 1, "second exact word boundary");
        check(LrcTimeline.activeWord(line, 1300, 100) == 1, "positive user advance");
        check(LrcTimeline.activeWord(line, 1400, -100) == 0, "negative user advance");
        check(LrcTimeline.activeWord(line, 900, 0) == 0, "backward seek resets word");
        check(lines.get(1).words.isEmpty(), "ordinary LRC never synthesizes words");
        var repeat = LrcTimeline.parse("[00:01][00:06]<00:01>A <00:02>B");
        check(repeat.get(1).words.get(0).timeMs == 6000 && repeat.get(1).words.get(1).timeMs == 7000, "repeat word translation");
        check(LrcTimeline.parse("[00:01]<00:02>A <00:01>B").get(0).words.isEmpty(), "reject descending word clocks");
        check(LrcTimeline.parse("[00:02]<00:01>A").get(0).words.isEmpty(), "reject word before cue");
        check(LrcTimeline.parse("[00:01]unknown <00:02>A").get(0).words.isEmpty(), "untimed prefix falls back to line");
        check(LrcTimeline.parse("[00:01]<00:01>A <00:03>B\n[00:02]Next").get(0).words.isEmpty(), "cross-cue words fall back to line");
        check(LrcTimeline.parse("[00:01]<00:01>A\n[00:01]Translation").get(0).words.isEmpty(), "ambiguous duet/translation falls back");
        check(LrcTimeline.identityMatches("Track (Ultra Slowed)", "ARTIST", "Track - Ultra Slowed", "Artist"), "punctuation normalization retains all words");
        check(!LrcTimeline.identityMatches("Track (Ultra Slowed)", "Artist", "Track (Slowed)", "Artist"), "ultra vs ordinary slowed is not equivalent");
        check(!LrcTimeline.identityMatches("Track (Live)", "Artist", "Track", "Artist"), "live preserved");
        check(!LrcTimeline.identityMatches("Track Remix", "Artist", "Track", "Artist"), "remix preserved");
        check(!LrcTimeline.identityMatches("Track", "Other", "Track", "Artist"), "artist not guessed");
        try {
            LrcTimeline.parse("[00:01]".repeat(1000) + "<00:01>x ".repeat(1000));
            throw new AssertionError("unbounded repeated word allocation");
        } catch (IllegalArgumentException expected) { checks++; }
        Random random = new Random(6450);
        var words = LrcTimeline.parse("[00:01]<00:01>a <00:02>b <00:03>c <00:04>d").get(0);
        for (int i = 0; i < 30000; i++) {
            long media = random.nextInt(8000), advance = random.nextInt(120001) - 60000;
            int expected = -1;
            for (int j = 0; j < words.words.size(); j++) if (words.words.get(j).timeMs <= media + advance) expected = j;
            check(LrcTimeline.activeWord(words, media, advance) == expected, "word binary search vs linear oracle");
        }
        // Simulated source positions at variable speed, freeze (pause/buffer), and a backward seek.
        // This tests timeline math, not ExoPlayer/Sonic output or Bluetooth latency.
        double media = 0;
        for (double speed : new double[]{0.25, 0.5, 1, 1.25, 2, 0, 0, 0.75}) {
            for (int i = 0; i < 120; i++) {
                media += speed * 33;
                long pos = (long) media;
                int expected = pos < 1000 ? -1 : pos < 2000 ? 0 : pos < 3000 ? 1 : pos < 4000 ? 2 : 3;
                check(LrcTimeline.activeWord(words, pos, 0) == expected, "no wall-clock or double speed conversion");
            }
        }
        check(LrcTimeline.activeWord(words, 1500, 0) == 0, "seek after speed changes");
        System.out.println("PASS: " + checks + " enhanced-LRC/identity/source-position assertions; no Android audio execution");
    }
    public static void main(String[] args) { run(); }
}
