package app.ziziplayer.ui

import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteTrack
import java.io.IOException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test

class HubRefreshControllerTest {
    private fun shelves(id: String = "1") = listOf(DiscoverShelf("Подборки", listOf(
        RemoteItem.Song(RemoteTrack("dz", id, "Track $id", "Artist"))
    )))

    private inner class Harness(scope: CoroutineScope, timeoutMs: Long = 2_000L) {
        var cache: HubSnapshot? = null
        var next = shelves()
        var calls = 0
        var writes = 0
        var cacheReads = 0
        var select: suspend () -> String = { "dz" }
        var read: suspend () -> HubSnapshot? = { cache }
        var fetch: suspend () -> List<DiscoverShelf> = { next }
        var write: suspend () -> Unit = { }
        val messages = mutableListOf<String>()
        val controller = HubRefreshController(
            scope = scope,
            preferred = { select() },
            readCache = { cacheReads++; read() },
            discover = { calls++; fetch() },
            writeCache = { _, _ -> writes++; write() },
            message = { messages.add(it) },
            describeError = { "Нет соединения" },
            timeoutMs = timeoutMs,
            cacheWriteTimeoutMs = 30L
        )
        suspend fun idle() = withTimeout(3_000L) { controller.state.first { !it.refreshing } }
    }

    @Test fun freshStartupCacheSkipsNetworkAndFeedback() = runBlocking<Unit> {
        val h = Harness(this)
        h.cache = HubSnapshot(shelves(), true)
        h.controller.load()
        assertTrue(h.controller.state.value.refreshing)
        h.idle()
        assertEquals(0, h.calls)
        assertEquals(shelves(), h.controller.state.value.shelves)
        assertTrue(h.messages.isEmpty())
    }

    @Test fun manualRefreshBypassesFreshDiskCache() = runBlocking<Unit> {
        val h = Harness(this)
        h.cache = HubSnapshot(shelves("old"), true)
        h.controller.load(true); h.idle()
        assertEquals(1, h.calls)
        assertEquals(1, h.writes)
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(listOf("Подборки обновлены"), h.messages)
    }

    @Test fun repeatedTapsJoinOneFlightWithoutCancellingIt() = runBlocking<Unit> {
        val h = Harness(this)
        val started = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        h.fetch = { started.complete(Unit); release.await(); h.next }
        h.controller.load(true)
        started.await()
        repeat(100) { h.controller.load(true) }
        assertEquals(1, h.calls)
        assertTrue(h.controller.state.value.refreshing)
        release.complete(Unit); h.idle()
        assertEquals(1, h.writes)
        assertEquals(1, h.messages.size)
    }

    @Test fun manualTapUpgradesAnInProgressCacheRead() = runBlocking<Unit> {
        val h = Harness(this)
        val started = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        h.read = { started.complete(Unit); release.await(); HubSnapshot(shelves("old"), true) }
        h.controller.load()
        started.await()
        h.controller.load(true)
        release.complete(Unit); h.idle()
        assertEquals(1, h.calls)
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(1, h.messages.size)
    }

    @Test fun failureKeepsOldContentAndAllowsRetry() = runBlocking<Unit> {
        val h = Harness(this)
        h.cache = HubSnapshot(shelves("old"), true)
        h.controller.load(); h.idle()
        h.fetch = { throw IOException("offline") }
        h.controller.load(true); h.idle()
        assertEquals(shelves("old"), h.controller.state.value.shelves)
        assertNull(h.controller.state.value.error)
        assertFalse(h.controller.state.value.loading)
        assertTrue(h.messages.single().contains("Прежние сохранены"))
        h.fetch = { h.next }
        h.controller.load(true); h.idle()
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(2, h.calls)
    }

    @Test fun initialFailureHasAnErrorAndNoStuckSpinner() = runBlocking<Unit> {
        val h = Harness(this)
        h.fetch = { throw IOException() }
        h.controller.load(true); h.idle()
        assertEquals("Нет соединения", h.controller.state.value.error)
        assertFalse(h.controller.state.value.loading)
        assertFalse(h.controller.state.value.refreshing)
    }

    @Test fun settingsFailureIsInsideTheErrorBoundary() = runBlocking<Unit> {
        val h = Harness(this)
        h.select = { throw IOException() }
        h.controller.load(true); h.idle()
        assertEquals(0, h.calls)
        assertFalse(h.controller.state.value.loading)
        assertNotNull(h.controller.state.value.error)
    }

    @Test fun brokenCacheFallsBackToNetwork() = runBlocking<Unit> {
        val h = Harness(this)
        h.read = { throw IOException() }
        h.controller.load(true); h.idle()
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(1, h.calls)
    }

    @Test fun emptyRefreshDoesNotEraseContentOrWriteAnEmptyCache() = runBlocking<Unit> {
        val h = Harness(this)
        h.cache = HubSnapshot(shelves("old"), true)
        h.next = emptyList()
        h.controller.load(true); h.idle()
        assertEquals(shelves("old"), h.controller.state.value.shelves)
        assertEquals(0, h.writes)
        assertTrue(h.messages.single().contains("прежние сохранены"))
    }

    @Test fun emptyInitialResponseIsNotACrash() = runBlocking<Unit> {
        val h = Harness(this)
        h.next = emptyList()
        h.controller.load(true); h.idle()
        assertTrue(h.controller.state.value.shelves.isEmpty())
        assertNull(h.controller.state.value.error)
        assertTrue(h.messages.single().contains("Поиск по-прежнему доступен"))
    }

    @Test fun equalResponsePreservesListInstanceAndReportsNoChanges() = runBlocking<Unit> {
        val h = Harness(this)
        h.controller.load(true); h.idle()
        val before = h.controller.state.value.shelves
        h.messages.clear()
        h.controller.load(true); h.idle()
        assertSame(before, h.controller.state.value.shelves)
        assertEquals(listOf("Новых подборок пока нет"), h.messages)
        assertEquals(1, h.cacheReads)
    }

    @Test fun timeoutCancelsTheLoaderAndReleasesLoadingFlags() = runBlocking<Unit> {
        val h = Harness(this, timeoutMs = 500L)
        var cancelled = false
        h.fetch = { try { awaitCancellation() } finally { cancelled = true } }
        h.controller.load(true); h.idle()
        assertTrue(cancelled)
        assertFalse(h.controller.state.value.loading)
        assertTrue(h.messages.single().contains("не успел ответить"))
    }

    @Test fun parentCancellationIsNotReportedAsNetworkFailure() = runBlocking<Unit> {
        val owner = SupervisorJob(coroutineContext[Job])
        val h = Harness(CoroutineScope(coroutineContext + owner))
        val started = CompletableDeferred<Unit>()
        h.fetch = { started.complete(Unit); awaitCancellation() }
        h.controller.load(true)
        started.await()
        owner.cancelAndJoin()
        assertFalse(h.controller.state.value.refreshing)
        assertFalse(h.controller.state.value.loading)
        assertTrue(h.messages.isEmpty())
    }

    @Test fun diskWriteFailureDoesNotMisreportNetworkSuccess() = runBlocking<Unit> {
        val h = Harness(this)
        h.write = { throw IOException("disk full") }
        h.controller.load(true); h.idle()
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(listOf("Подборки обновлены"), h.messages)
    }

    @Test fun stalledCacheWriteDoesNotHoldTheSpinnerForever() = runBlocking<Unit> {
        val h = Harness(this)
        h.write = { awaitCancellation() }
        h.controller.load(true); h.idle()
        assertEquals(h.next, h.controller.state.value.shelves)
        assertEquals(listOf("Подборки обновлены"), h.messages)
    }
}
