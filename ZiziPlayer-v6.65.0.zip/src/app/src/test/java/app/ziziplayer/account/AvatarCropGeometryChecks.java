package app.ziziplayer.account;

import java.util.Random;

/** Executes the production geometry, not a separate implementation of the editor. */
public final class AvatarCropGeometryChecks {
    private static int checks;
    private static void check(boolean ok) { checks++; if (!ok) throw new AssertionError("Check " + checks); }
    private static void near(float actual, float expected, float tolerance) {
        checks++; if (Math.abs(actual - expected) > tolerance)
            throw new AssertionError(actual + " != " + expected + " at " + checks);
    }
    private static void bounds(int w, int h, AvatarCropGeometry.Pose p) {
        AvatarCropGeometry.Crop c = AvatarCropGeometry.crop(w, h, p);
        check(Float.isFinite(c.left) && Float.isFinite(c.top) && Float.isFinite(c.side));
        check(c.side > 0 && c.side <= Math.min(w, h));
        check(c.left >= 0 && c.top >= 0);
        check(c.left + c.side <= w + 0.002f && c.top + c.side <= h + 0.002f);
        check(p.zoom >= 1 && p.zoom <= AvatarCropGeometry.MAX_ZOOM);
        // Preview transform of the exported top-left and bottom-right is [0,1] on both axes.
        float unit = Math.min(w, h) / p.zoom;
        near((c.left - w / 2f) / unit + p.x + .5f, 0f, .002f);
        near((c.top - h / 2f) / unit + p.y + .5f, 0f, .002f);
        near((c.left + c.side - w / 2f) / unit + p.x + .5f, 1f, .003f);
        near((c.top + c.side - h / 2f) / unit + p.y + .5f, 1f, .003f);
    }
    public static void main(String[] args) {
        checks = 0;
        int[][] shapes = {{1,1},{256,256},{4032,3024},{3024,4032},{16000,1},{1,16000},{2048,1536},{692,1538}};
        for (int[] shape : shapes) {
            int w = shape[0], h = shape[1];
            AvatarCropGeometry.Crop centered = AvatarCropGeometry.crop(w, h, AvatarCropGeometry.initial());
            near(centered.left, (w - Math.min(w,h))/2f, .001f);
            near(centered.top, (h - Math.min(w,h))/2f, .001f);
            for (float x : new float[]{-1000000, -1, 0, 1, 1000000}) for (float y : new float[]{-1000000, 0, 1000000}) {
                AvatarCropGeometry.Pose p = AvatarCropGeometry.constrain(w,h,new AvatarCropGeometry.Pose(8,x,y));
                bounds(w,h,p);
            }
        }
        Random random = new Random(6570L);
        // Realistic full-resolution/capped image dimensions. Gesture streams include huge pans.
        for (int n=0; n<50000; n++) {
            int w=16+random.nextInt(15985), h=16+random.nextInt(15985);
            AvatarCropGeometry.Pose p=AvatarCropGeometry.initial();
            for (int j=0;j<5;j++) {
                p=AvatarCropGeometry.gesture(w,h,p,.4f+random.nextFloat()*2f,
                    (random.nextFloat()-.5f)*5, (random.nextFloat()-.5f)*5,
                    random.nextFloat()-.5f,random.nextFloat()-.5f);
                bounds(w,h,p);
            }
        }
        // Zoom keeps the chosen source point under an off-centre pinch when not at a boundary.
        AvatarCropGeometry.Pose old=new AvatarCropGeometry.Pose(2f,.1f,-.2f);
        AvatarCropGeometry.Pose next=AvatarCropGeometry.gesture(2048,2048,old,1.5f,0,0,.2f,-.3f);
        near((.2f-old.x)/old.zoom, (.2f-next.x)/next.zoom, .00001f);
        near((-.3f-old.y)/old.zoom, (-.3f-next.y)/next.zoom, .00001f);
        // Width/height of the phone are not part of Pose: rotating/resizing cannot change crop.
        AvatarCropGeometry.Crop a=AvatarCropGeometry.crop(4032,3024,next), b=AvatarCropGeometry.crop(4032,3024,next);
        near(a.left,b.left,0); near(a.top,b.top,0); near(a.side,b.side,0);
        for(float invalid : new float[]{Float.NaN,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY}) {
            bounds(512,1024,AvatarCropGeometry.constrain(512,1024,new AvatarCropGeometry.Pose(invalid,invalid,invalid)));
            bounds(512,1024,AvatarCropGeometry.gesture(512,1024,old,invalid,invalid,invalid,invalid,invalid));
        }
        boolean rejected=false;
        try { AvatarCropGeometry.crop(0,100,old); } catch(IllegalArgumentException e) { rejected=true; }
        check(rejected);
        System.out.println(checks + " production crop geometry assertions passed");
    }
}
