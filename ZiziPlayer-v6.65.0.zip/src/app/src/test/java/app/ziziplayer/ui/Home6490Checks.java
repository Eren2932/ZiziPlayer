package app.ziziplayer.ui;
import java.util.*;
import static app.ziziplayer.ui.HomeFeedPolicy.*;
public final class Home6490Checks {
    private static int checks;
    private static void check(boolean value, String label) {
        checks++; if (!value) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        check(normalize("Pháo").equals(normalize("Phao")), "diacritics");
        check(normalize("ТЁМНЫЙ ПРИНЦ").equals(normalize("тёмный принц")), "Cyrillic case");
        check(!normalize("Track slowed").equals(normalize("Track")), "do not merge slowed");
        check(!normalize("Track remix").equals(normalize("Track")), "do not merge remix");
        check(normalize(null).isEmpty(), "null safety");
        check(sessionWeight(true,true,false,0) == 3, "completed evidence");
        check(sessionWeight(true,true,false,14) == 1.5, "14 day half-life");
        check(sessionWeight(false,false,true,0) == -2.5, "early skip penalty");
        check(sessionWeight(false,false,false,0) == 0, "pause and error are not dislikes");
        check(score(true,0) == 4, "favorite bonus");
        check(score(false,999) == 12 && score(false,-999) == -6, "bounded evidence");
        List<Candidate> input = Arrays.asList(new Candidate("a1","A",8),new Candidate("a2","A",7),
            new Candidate("b1","B",6),new Candidate("c1","C",5),new Candidate("a1","A",80));
        List<String> ranked = rank(input,20);
        check(ranked.equals(Arrays.asList("a1","b1","a2","c1")), "diversity and ID dedup");
        check(rank(input,0).isEmpty() && rank(input,-1).isEmpty(), "nonpositive limit");
        check(rank(Collections.emptyList(),5).isEmpty(), "cold start");
        List<Candidate> many = new ArrayList<>();
        for(int i=0;i<1000;i++) many.add(new Candidate("id"+i,"Artist"+(i%8),dailyTie("id"+i,20000)));
        List<String> first = rank(many,1000);
        check(first.size()==100 && new HashSet<>(first).size()==100, "bounded unique queue");
        check(first.equals(rank(many,1000)), "stable snapshot order");
        check(dailyTie("x",1)==dailyTie("x",1), "stable daily tie");
        check(dailyTie("x",1)!=dailyTie("x",2), "daily rotation");
        for(float w: new float[]{320,360,393,412,480,600,840}) {
            check(inset(w)>0 && card(w)<=240 && card(w)>0, "responsive bounds");
            if(w<=600) check(Math.abs(card(w)/w-0.4)<0.0001, "40 percent card");
            check(2*inset(w)+card(w)<w, "reachable next card");
        }
        check(Math.abs(inset(393)*1080/393-46)<0.001, "reference inset");
        check(Math.abs(card(393)*1080/393-432)<0.001, "reference cover");
        check(Math.abs(gap(393)*1080/393-46)<0.001, "reference gap");
        System.out.println("PASS: "+checks+" production ranking/geometry assertions; not Compose or live catalog");
    }
}
