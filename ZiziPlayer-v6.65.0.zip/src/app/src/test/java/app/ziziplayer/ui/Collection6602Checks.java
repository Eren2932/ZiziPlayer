package app.ziziplayer.ui;

public final class Collection6602Checks {
    private static int assertions;
    private static void ok(boolean value) { assertions++; if (!value) throw new AssertionError("check " + assertions); }
    private static void near(float a, float b) { ok(Math.abs(a - b) < .01f); }
    public static void main(String[] args) {
        // Reconstruct screenshot coordinates without treating 1080px as 360dp.
        float density = 2.875f;
        float u = CollectionHeaderGeometry.unit(1080f / density);
        float coverTop = 110f + CollectionHeaderGeometry.COVER_TOP * u * density;
        float coverSize = CollectionHeaderGeometry.COVER_SIZE * u * density;
        near(coverTop, 164f);
        near(coverSize, 716f);
        near((1080f - coverSize) / 2f, 182f);
        near(coverTop + coverSize, 880f);
        float titleTop = coverTop + coverSize + CollectionHeaderGeometry.COVER_TITLE_GAP * u * density;
        near(titleTop, 950f); // text layout origin, not the first antialiased glyph pixel
        near(titleTop + CollectionHeaderGeometry.DETAILS_MIN_HEIGHT * u * density, 1260f);
        float touch = CollectionHeaderGeometry.touchSize(u);
        float end = CollectionHeaderGeometry.touchEnd(u);
        float disk = CollectionHeaderGeometry.PLAY_SIZE * u;
        float playCenter = 1080f - (end + touch / 2f) * density;
        near(playCenter, 970f);
        near(playCenter - disk * density / 2f, 900f);
        near(playCenter - (touch + CollectionHeaderGeometry.actionGap(u)) * density, 826f);
        near(CollectionHeaderGeometry.CONTENT_START * u * density, 46f);
        near(306f - coverTop, 142f);
        for (float width : new float[]{240, 280, 320, 360, 375.65217f, 393, 411, 420, 600, 840}) {
            u = CollectionHeaderGeometry.unit(width);
            touch = CollectionHeaderGeometry.touchSize(u);
            end = CollectionHeaderGeometry.touchEnd(u);
            disk = CollectionHeaderGeometry.PLAY_SIZE * u;
            ok(touch >= 48f && disk <= touch && disk > 0f);
            ok(CollectionHeaderGeometry.actionGap(u) >= 0f && end >= 0f);
            ok(CollectionHeaderGeometry.COVER_SIZE * u <= 280f);
            near(end + (touch - disk) / 2f, CollectionHeaderGeometry.PLAY_END * u);
            float shuffleLeft = width - end - 2 * touch - CollectionHeaderGeometry.actionGap(u);
            ok(shuffleLeft > CollectionHeaderGeometry.CONTENT_START * u);
            // The reference minimum is not a fixed height that clips large text.
            for (float detailsHeight : new float[]{310*u, 400*u, 700*u, 1200*u}) {
                float hero = (CollectionHeaderGeometry.COVER_TOP + CollectionHeaderGeometry.COVER_SIZE +
                    CollectionHeaderGeometry.COVER_TITLE_GAP + CollectionHeaderGeometry.ACTION_BOTTOM_GAP) * u + detailsHeight + touch;
                float bottomGap = CollectionHeaderGeometry.ACTION_BOTTOM_GAP * u;
                float expanded = hero - touch - bottomGap;
                float pinned = 56f - touch/2;
                float travel = expanded - pinned;
                near(CollectionGeometry.pinnedPlayTop(0, expanded, pinned), expanded);
                near(CollectionGeometry.pinnedPlayTop(travel, expanded, pinned), pinned);
                near(CollectionCollapseMath.banner(travel, travel), 1f);
                for (int count : new int[]{0,1,2,5,50}) {
                    float body = Math.min(CollectionGeometry.ROW * width/1080f, 71f)*count;
                    float tail = CollectionGeometry.minimumPinnedTail(720, body, 140, touch, bottomGap, pinned);
                    ok(hero + body + tail + 140 - 720 >= travel - .01f);
                }
            }
        }
        near(CollectionHeaderGeometry.unit(600), CollectionHeaderGeometry.unit(420));
        System.out.println("PASS: " + assertions + " production geometry assertions; not Compose rendering");
    }
}
