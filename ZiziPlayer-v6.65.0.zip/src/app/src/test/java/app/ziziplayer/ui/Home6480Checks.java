package app.ziziplayer.ui;

/** Executes production Java geometry. Not a substitute for Compose/device tests. */
public final class Home6480Checks {
    private static int assertions;
    private static void check(boolean yes, String message) {
        assertions++;
        if (!yes) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for (float density : new float[]{1f, 1.5f, 2f, 3.5f}) {
            for (float hero : new float[]{340, 460, 720, 1000}) {
                float expanded = (hero - 56 - 16) * density;
                float pinned = 28 * density;
                float previous = Float.MAX_VALUE;
                for (int i = -100; i <= 2000; i++) {
                    float scroll = i * density;
                    float y = CollectionGeometry.pinnedPlayTop(scroll, expanded, pinned);
                    check(y >= pinned, "never above seam");
                    check(y <= previous, "monotone upward motion");
                    if (i > -100) check(previous - y <= density + .001f, "no teleport");
                    if (scroll >= expanded - pinned) check(Math.abs(y-pinned)<.001f, "stays pinned");
                    if (scroll < 0) check(Math.abs(y-expanded)<.001f, "overscroll stable");
                    previous = y;
                }
                for (int tracks : new int[]{0,1,2,5,50,100}) {
                    for (float viewport : new float[]{280, 620, 900, 1366}) {
                        float body=tracks*66*density, bottom=150*density, vp=viewport*density;
                        float tail=CollectionGeometry.minimumPinnedTail(vp,body,bottom,56*density,16*density,pinned);
                        float maxScroll=hero*density+body+bottom+tail-vp;
                        check(tail>=0, "nonnegative tail");
                        check(maxScroll+.001f>=expanded-pinned, "even a single row reaches the clamp");
                        if (body+bottom+100*density>=vp) check(tail==0, "no artificial tail on long lists");
                    }
                }
            }
        }
        System.out.println("PASS: " + assertions + " production measured-header assertions; no Android/Compose execution.");
    }
}
