package app.ziziplayer.ui

import app.ziziplayer.ui.screens.CollectionCollapseState
import org.junit.Assert.assertEquals
import org.junit.Test

/** Run by Gradle: actual Compose state wrapper, not a reimplementation. */
class CollectionCollapseStateTest {
    @Test fun consumesOnlyItsRemainingRange() {
        val state = CollectionCollapseState()
        assertEquals(-120f, state.consume(-300f, 120f), 0.001f)
        assertEquals(1f, state.fraction, 0f)
        assertEquals(0f, state.consume(-30f, 120f), 0f)
    }
    @Test fun reverseReturnsExactlyWhatWasConsumed() {
        val state = CollectionCollapseState()
        assertEquals(-42f, state.consume(-42f, 120f), 0.001f)
        assertEquals(42f, state.consume(42f, 120f), 0.001f)
        assertEquals(0f, state.fraction, 0.001f)
    }
    @Test fun restoredFractionIsClamped() {
        assertEquals(0f, CollectionCollapseState(Float.NaN).fraction, 0f)
        assertEquals(1f, CollectionCollapseState(3f).fraction, 0f)
        assertEquals(0.5f, CollectionCollapseState(0.5f).fraction, 0f)
    }
    @Test fun zeroRangeDoesNotConsumeOrDivide() {
        val state = CollectionCollapseState(0.5f)
        assertEquals(0f, state.consume(-10f, 0f), 0f)
        assertEquals(0.5f, state.fraction, 0f)
    }
}
