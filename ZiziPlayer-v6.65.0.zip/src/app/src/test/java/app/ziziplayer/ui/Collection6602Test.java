package app.ziziplayer.ui;
import org.junit.Test;
public class Collection6602Test {
    @Test public void referenceCoordinatesAndShortListScroll() { Collection6602Checks.main(new String[0]); }
}
