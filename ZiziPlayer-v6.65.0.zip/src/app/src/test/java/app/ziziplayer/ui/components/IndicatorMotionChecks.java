package app.ziziplayer.ui.components;

public final class IndicatorMotionChecks {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        int samples = 0;
        for (int bar = 0; bar < 4; bar++) {
            float previous = IndicatorMotion.level(0f, bar, true);
            float min = previous, max = previous;
            for (int tick = 1; tick <= 8160; tick++) {
                float value = IndicatorMotion.level(tick / 8160f, bar, true);
                check(Float.isFinite(value) && value >= .35f && value <= 1f, "bounded");
                check(Math.abs(value - previous) < .01f, "no single-millisecond jump");
                check(IndicatorMotion.level(tick / 8160f, bar, false) ==
                      IndicatorMotion.level(0f, bar, false), "pause is static");
                min = Math.min(min, value); max = Math.max(max, value);
                previous = value; samples++;
            }
            check(max - min > .35f, "visible movement");
            check(IndicatorMotion.level(0f, bar, true) == IndicatorMotion.level(1f, bar, true), "seam");
            float before = IndicatorMotion.level(.99999f, bar, true);
            float after = IndicatorMotion.level(.00001f, bar, true);
            check(Math.abs(before - after) < .0001f, "smooth wrap");
            check(Float.isFinite(IndicatorMotion.level(Float.NaN, bar, true)), "NaN safe");
            check(Float.isFinite(IndicatorMotion.level(Float.POSITIVE_INFINITY, bar, true)), "infinity safe");
        }
        check(IndicatorMotion.level(.123f, 0, true) != IndicatorMotion.level(.123f, 1, true), "independent bars");
        for (int bad : new int[] {-1, 4}) {
            try { IndicatorMotion.level(0f, bad, true); throw new AssertionError("invalid bar accepted"); }
            catch (IllegalArgumentException expected) { }
        }
        System.out.println("IndicatorMotion: " + samples + " samples, bounds, pause, wrap, continuity and invalid input PASS");
    }
}
