package app.ziziplayer.playback

import org.junit.Test

class Startup646Test {
    @Test fun boundedLocalTrace() { Startup646Checks.run() }
}
