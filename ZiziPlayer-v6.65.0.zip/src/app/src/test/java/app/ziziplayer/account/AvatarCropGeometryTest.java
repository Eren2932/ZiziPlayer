package app.ziziplayer.account;
import org.junit.Test;
public final class AvatarCropGeometryTest {
    @Test public void cropGeometryInvariants() { AvatarCropGeometryChecks.main(new String[0]); }
}
