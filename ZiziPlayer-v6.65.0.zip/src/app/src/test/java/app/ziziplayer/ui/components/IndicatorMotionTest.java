package app.ziziplayer.ui.components;

import org.junit.Test;

public final class IndicatorMotionTest {
    @Test public void productionMotionIsBoundedContinuousAndStaticOnPause() {
        IndicatorMotionChecks.main(new String[0]);
    }
}
