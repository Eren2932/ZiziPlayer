package app.ziziplayer.ui;

import app.ziziplayer.playback.DownloadBatchPolicy;

/** Standalone production-core execution; not an Android/Compose rendering test. */
public final class Collection6420Checks {
    private static int assertions;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static void near(float actual, float expected, String message) {
        check(Math.abs(actual - expected) < 0.0001f, message + ": " + actual);
    }
    public static void run() {
        assertions = 0;
        near(CollectionGeometry.playTop(0, 0) + 108, 821, "expanded play y");
        near(CollectionGeometry.playTop(618, 0) + 108, 203, "collapsed play y");
        near(CollectionGeometry.playTop(2000, 0) + 108, 203, "long scroll pinned");
        near(CollectionGeometry.playTop(-100, 0), 713, "overscroll clamp");
        near(CollectionGeometry.playTop(0, 160), 873, "large text space");
        near(CollectionGeometry.REFERENCE_WIDTH - CollectionGeometry.PLAY_END - CollectionGeometry.PLAY_SIZE, 912, "play left");
        near(CollectionGeometry.PLAY_SIZE, 140, "play diameter");
        near(CollectionGeometry.scrimAlpha(0), 0, "no hard start");
        near(CollectionGeometry.scrimAlpha(1), .65f, "65 percent maximum");
        near(1 - CollectionGeometry.scrimAlpha(1), .35f, "35 percent transmission");
        near(CollectionGeometry.scrimAlpha(-1), 0, "lead in");
        near(CollectionGeometry.scrimAlpha(2), .65f, "plateau");
        float previousAlpha = -1, previousY = Float.MAX_VALUE;
        for (int i = 0; i <= 10000; i++) {
            float t = i / 10000f;
            float alpha = CollectionGeometry.scrimAlpha(t);
            check(alpha >= previousAlpha - 0.000001f && alpha >= 0 && alpha <= .650001f, "bounded monotone scrim");
            previousAlpha = alpha;
            float y = CollectionGeometry.playTop(t * 2000, 0);
            check(y <= previousY && y >= 95, "continuous pinned motion");
            if (i > 0) check(previousY - y <= .201f, "no teleport at clamp");
            previousY = y;
        }
        for (int width : new int[]{320, 360, 393, 412, 600, 840, 1080}) {
            float scale = width / CollectionGeometry.REFERENCE_WIDTH;
            float right = width - CollectionGeometry.PLAY_END * scale;
            float left = right - CollectionGeometry.PLAY_SIZE * scale;
            check(left >= 0 && right <= width, "button within available width");
            near((right - left) / scale, 140, "width independent diameter ratio");
        }
        near(CollectionGeometry.headerAlpha(0), 0, "expanded clear toolbar");
        near(CollectionGeometry.headerAlpha(618), 1, "collapsed opaque toolbar");
        near(CollectionGeometry.titleAlpha(460), 0, "title not duplicated early");
        near(CollectionGeometry.titleAlpha(618), 1, "title appears at clamp");
        for (int tracks : new int[]{0, 1, 6, 20, 1000}) {
            float viewport = 2292, hero = 896, bottom = 350;
            float tail = CollectionGeometry.minimumTail(viewport, hero, tracks, bottom);
            float content = hero + CollectionGeometry.ROW * (tracks + 1) + bottom + tail;
            check(content - viewport >= CollectionGeometry.COLLAPSE_SCROLL, "short list can fully collapse");
            check(tail >= 0, "nonnegative tail");
        }
        near(CollectionGeometry.minimumTail(2292, 896, 6, 350), 446, "six-track reference tail");
        DownloadBatchPolicy policy = new DownloadBatchPolicy();
        long first = policy.newRequest();
        check(policy.mayStart("a", first), "new batch accepted");
        policy.cancel("a");
        check(!policy.mayStart("a", first), "cancel not-yet-enqueued member");
        check(policy.mayStart("b", first), "unrelated member unaffected");
        long retry = policy.newRequest();
        check(policy.mayStart("a", retry), "explicit retry allowed");
        policy.cancelAll();
        check(!policy.mayStart("b", first) && !policy.mayStart("b", retry), "cancel all blocks stale producers");
        long next = policy.newRequest();
        check(policy.mayStart("a", next) && policy.mayStart("b", next), "new request after cancellation");
        System.out.println("PASS: " + assertions + " production geometry/batch-policy assertions. No Android or Compose execution.");
    }
    public static void main(String[] args) { run(); }
}
