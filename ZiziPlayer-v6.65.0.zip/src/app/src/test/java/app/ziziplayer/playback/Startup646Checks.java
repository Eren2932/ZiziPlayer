package app.ziziplayer.playback;

public final class Startup646Checks {
    private static void check(boolean v, String message) { if (!v) throw new AssertionError(message); }
    public static void run() throws InterruptedException {
        StartupTrace.Span span = StartupTrace.begin(StartupTrace.Stage.RESOLVE);
        StartupTrace.finish(span, StartupTrace.Outcome.CANCELLED);
        String once = StartupTrace.snapshot();
        StartupTrace.finish(span, StartupTrace.Outcome.ERROR);
        check(once.equals(StartupTrace.snapshot()), "cancel/response race must finish only once");
        StartupTrace.finish(null, StartupTrace.Outcome.OK);
        check(once.equals(StartupTrace.snapshot()), "untracked API call is a no-op");
        Thread[] workers = new Thread[4];
        for (int t = 0; t < workers.length; t++) {
            workers[t] = new Thread(() -> {
                for (int i = 0; i < 1000; i++) {
                    StartupTrace.Span s = StartupTrace.begin(StartupTrace.Stage.MATCH);
                    StartupTrace.finish(s, StartupTrace.Outcome.OK);
                }
            });
            workers[t].start();
        }
        for (Thread worker : workers) worker.join();
        String text = StartupTrace.snapshot();
        check(text.lines().count() == 130, "128 bounded events plus two header lines");
        check(text.length() < 18000, "bounded memory export");
        check(!text.contains("http:") && !text.contains("https:") && !text.contains("Bearer"), "no sensitive request fields");
        check(text.contains("MATCH OK took="), "completed stage durations");
        System.out.println("PASS: StartupTrace idempotency, null handling, concurrent 8000 events, size/privacy bounds. Not Android timing.");
    }
    public static void main(String[] args) throws InterruptedException { run(); }
}
