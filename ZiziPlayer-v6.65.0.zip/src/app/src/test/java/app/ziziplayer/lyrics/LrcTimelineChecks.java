package app.ziziplayer.lyrics;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class LrcTimelineChecks {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    public static void run() {
        checks = 0;
        check(LrcTimeline.parse(null).isEmpty(), "null");
        check(LrcTimeline.parse("[ar:Example]\nuntimed words").isEmpty(), "plain is not timed");
        var lines = LrcTimeline.parse("\ufeff[ar:Example]\r\n[00:03.123]Third\r\n[00:01.1][00:02.12]Repeated\n[00:04]End\n[00:05.000]");
        check(lines.size() == 5, "multi-tag and blank break");
        check(lines.get(0).timeMs == 1100 && lines.get(1).timeMs == 2120 && lines.get(2).timeMs == 3123, "fraction normalization, sort");
        check(lines.get(4).text.isEmpty(), "blank break retained");
        check(LrcTimeline.activeIndex(lines, 1099, 0) == -1, "intro");
        check(LrcTimeline.activeIndex(lines, 1100, 0) == 0, "exact boundary");
        check(LrcTimeline.activeIndex(lines, 6000, 0) == 4, "outro");
        check(LrcTimeline.activeIndex(lines, 2200, 0) == 1, "seek backward");
        check(LrcTimeline.activeIndex(lines, 1000, 100) == 0, "advance");
        check(LrcTimeline.activeIndex(lines, 1100, -100) == -1, "delay");
        check(LrcTimeline.seekPosition(lines.get(2), 500) == 2623, "inverse seek");
        check(LrcTimeline.seekPosition(lines.get(0), 5000) == 0, "seek clamp");
        check(LrcTimeline.parse("[offset:+250]\n[00:01.000]A").get(0).timeMs == 750, "LRC positive advance");
        check(LrcTimeline.parse("[offset:-250]\n[00:01.000]A").get(0).timeMs == 1250, "LRC negative delay");
        check(LrcTimeline.parse("[00:00.1]A\n[offset:200]").get(0).timeMs == 0, "offset anywhere and clamp");
        var duplicates = LrcTimeline.parse("[00:01]A\n[00:01]B\n[00:02]C\n[00:02]C");
        check(duplicates.size() == 2 && duplicates.get(0).text.equals("A\nB"), "simultaneous translation");
        check(duplicates.get(1).text.equals("C"), "deduplicate identical cue");
        check(LrcTimeline.parse("[00:99]bad\n[00:01]valid [00:02] literal").size() == 1, "malformed time");
        check(LrcTimeline.parse("[00:01]<00:01.0>A <00:01.5>B").get(0).text.equals("A B"), "enhanced LRC safely line-level");
        check(LrcTimeline.durationMatches(120000, 120263), "provider reference duration");
        check(LrcTimeline.durationMatches(120000, 122000), "inclusive tolerance");
        check(!LrcTimeline.durationMatches(120000, 122001), "duration mismatch");
        check(!LrcTimeline.durationMatches(0, 120000), "unknown duration");
        check(LrcTimeline.identityMatches(" GOZALO - Slowed ", "Ariis", "GOZALO - slowed", "ARIIS"), "case normalization");
        check(!LrcTimeline.identityMatches("GOZALO - Slowed", "Ariis", "GOZALO", "Ariis"), "never drop slowed qualifier");
        check(!LrcTimeline.identityMatches("Title", "Artist", "Title", "Other"), "artist identity");
        try { LrcTimeline.parse("x".repeat(LrcTimeline.MAX_CHARS + 1)); throw new AssertionError("size accepted"); }
        catch (IllegalArgumentException expected) { checks++; }
        try { LrcTimeline.parse("[00:01]A\n".repeat(10001)); throw new AssertionError("cue count accepted"); }
        catch (IllegalArgumentException expected) { checks++; }
        Random random = new Random(6440);
        List<LrcTimeline.Line> generated = new ArrayList<>();
        long time = 0;
        for (int i = 0; i < 1000; i++) { time += random.nextInt(1000) + 1; generated.add(new LrcTimeline.Line(time, "test")); }
        for (int i = 0; i < 20000; i++) {
            long position = random.nextInt((int)time + 1000), offset = random.nextInt(120001) - 60000;
            int expected = -1;
            for (int j = 0; j < generated.size(); j++) if (generated.get(j).timeMs <= position + offset) expected = j; else break;
            check(LrcTimeline.activeIndex(generated, position, offset) == expected, "binary search vs oracle");
        }
        System.out.println("PASS: " + checks + " production timeline assertions (including 20000 deterministic seek/offset cases)");
    }
    public static void main(String[] args) throws Exception {
        run();
        if (args.length > 0) {
            var lines = LrcTimeline.parse(new String(Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8));
            check(!lines.isEmpty(), "input LRC supplied timed cues");
            System.out.println("LRC file parse: " + lines.size() + " cues; last timestamp " + lines.get(lines.size()-1).timeMs + " ms (not audio alignment verification)");
        }
    }
}
