package app.ziziplayer.listening;
import org.junit.Test;
public final class ListeningClockTest {
    @Test public void productionClockRegressions() { ListeningClockChecks.main(new String[0]); }
}
