package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.Request
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Real Job cancellation, not just throwing a CancellationException from a fake provider. */
class LyricsHybridCancellationTest {
    private val track = TrackEntity(id = "fixture", uri = "", title = "Synthetic title",
        artist = "Synthetic artist", durationMs = 144_000L)
    private fun payload() = JSONObject().put("source", "fixture").put("plainLyrics", "synthetic")
    private fun request() = Request.Builder().url("https://lrclib.net/api/get").build()
    private fun provider(name: String, run: suspend (suspend (Request) -> String) -> JSONObject?) =
        object : LyricsProvider {
            override val id = name
            override val budgetMs = 1_000L
            override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
                trace: LyricsLookupTrace?) = run(http)
        }

    private suspend fun transportFailure(reason: Exception) {
        var transportCalls = 0
        var backupCalls = 0
        val lookup = LyricsHybridLookup(listOf(provider("primary") { http -> http(request()); payload() },
            provider("backup") { backupCalls++; payload() }), { 0L })
        var observed: Exception? = null
        try { lookup.lookup(track, { _, _ -> transportCalls++; throw reason }, null) }
        catch (e: Exception) { observed = e }
        assertNotNull("Failure must propagate out of the HTTP timeout boundary", observed)
        assertEquals(reason.javaClass, observed!!.javaClass)
        assertEquals(reason.message, observed.message)
        assertEquals(1, transportCalls)
        assertEquals(0, backupCalls)
    }

    @Test fun cancellationFromTransportStopsChain() = runBlocking {
        transportFailure(CancellationException("track changed during HTTP"))
    }

    @Test fun audioBusyFromTransportStopsChain() = runBlocking {
        transportFailure(LyricsRepository.AudioBusy())
    }

    @Test fun cancellingRunningRequestCleansUpAndNeverStartsBackup() = runBlocking {
        var transportCalls = 0
        var cleanup = false
        var backupCalls = 0
        val lookup = LyricsHybridLookup(listOf(provider("primary") { http -> http(request()); payload() },
            provider("backup") { backupCalls++; payload() }), { 0L })
        val job = launch(start = CoroutineStart.UNDISPATCHED) {
            lookup.lookup(track, { _, _ ->
                transportCalls++
                try { awaitCancellation() } finally { cleanup = true }
            }, null)
        }
        assertEquals(1, transportCalls)
        job.cancelAndJoin()
        assertTrue(cleanup)
        assertEquals(0, backupCalls)
    }

    @Test fun cancelledCallerDoesNotStartProvider() = runBlocking {
        var providerCalls = 0
        var transportCalls = 0
        var returned = false
        val lookup = LyricsHybridLookup(listOf(provider("primary") { http ->
            providerCalls++; http(request()); payload()
        }), { 0L })
        val job = launch(start = CoroutineStart.UNDISPATCHED) {
            currentCoroutineContext().cancel(CancellationException("already cancelled"))
            lookup.lookup(track, { _, _ -> transportCalls++; "{}" }, null)
            returned = true
        }
        job.join()
        assertEquals(0, providerCalls)
        assertEquals(0, transportCalls)
        assertFalse(returned)
    }

    private fun checkCancelledProvider(outcome: String) = runBlocking {
        var backupCalls = 0
        var transportCalls = 0
        var returned = false
        lateinit var owner: Job
        val lookup = LyricsHybridLookup(listOf(provider("primary") { http ->
            owner.cancel(CancellationException("new track selected"))
            when (outcome) {
                "miss" -> null
                "error" -> throw IOException("cancelled transport reported an I/O error")
                "http" -> { http(request()); payload() }
                else -> payload()
            }
        }, provider("backup") { backupCalls++; payload() }), { 0L })
        val job = launch(start = CoroutineStart.UNDISPATCHED) {
            owner = currentCoroutineContext().job
            lookup.lookup(track, { _, _ -> transportCalls++; "{}" }, null)
            returned = true
        }
        job.join()
        assertEquals(0, backupCalls)
        assertEquals(0, transportCalls)
        assertFalse(returned)
    }

    @Test fun cancelledProviderCannotAdvanceAfterMiss() = checkCancelledProvider("miss")
    @Test fun cancelledProviderCannotAdvanceAfterIoFailure() = checkCancelledProvider("error")
    @Test fun cancelledProviderCannotInvokeTransport() = checkCancelledProvider("http")
    @Test fun cancelledProviderCannotPublishHit() = checkCancelledProvider("hit")
}
