package app.ziziplayer.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Snapshots deliberately survive metadata replacement and removal of the source file. */
@Entity(tableName = "listening_sessions", indices = [Index(value = ["trackId"]), Index(value = ["startedAt"])])
data class ListeningSessionEntity(
    @PrimaryKey val sessionId: String,
    val trackId: String,
    val title: String,
    val artist: String,
    val artworkUri: String?,
    val source: String,
    val sourceFolder: String,
    val startedAt: Long,
    val updatedAt: Long,
    val endedAt: Long?,
    val durationMs: Long,
    val listenedMs: Long,
    val coveredMs: Long,
    val endPositionMs: Long,
    val qualified: Boolean,
    val completed: Boolean,
    /** active, ended, skipped, replaced, removed, stopped, error, interrupted */
    val outcome: String
)

@Entity(tableName = "home_pins")
data class HomePinEntity(@PrimaryKey val playlistId: Long, val pinnedAt: Long)

/** Optional authoritative identities, never inferred from an artist's display name. */
@Entity(tableName = "track_catalog")
data class TrackCatalogEntity(
    @PrimaryKey val trackId: String,
    val provider: String,
    val artistId: String?,
    val albumId: String?,
    val isrc: String?
)
