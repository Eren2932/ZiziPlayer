package app.ziziplayer.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private val accountColors = longArrayOf(0xFFFF6430, 0xFF3DCC91, 0xFF8EAAFF, 0xFFFFC857, 0xFFFF83BA, 0xFF50C9DF)

/** Stable per user ID. The palette is allocated once, not on each avatar recomposition. */
fun accountColor(id: String): Color = Color(accountColors[Math.floorMod(id.hashCode(), accountColors.size)])

@Composable
fun AccountAvatar(id: String, name: String, avatar: String, size: Dp, modifier: Modifier = Modifier) {
    val image = rememberAccountAvatarBitmap(avatar)
    Box(modifier.size(size).clip(CircleShape).background(accountColor(id)), contentAlignment = Alignment.Center) {
        val current = image
        if (current != null) Image(current, null, Modifier.size(size), contentScale = ContentScale.Crop)
        else Text(name.trim().let { if (it.isBlank()) "Z" else String(Character.toChars(it.codePointAt(0))).uppercase() },
            color = Color.Black, fontSize = (size.value * 0.53f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun rememberAccountAvatarBitmap(avatar: String): ImageBitmap? {
    // New mounts reuse the decoded bitmap immediately: no initials frame between home and drawer.
    // key() also prevents an old bitmap being displayed after a different avatar was selected.
    val image by key(avatar) {
        produceState(AvatarBitmapCache.get(avatar), avatar) {
            if (value == null && avatar.isNotBlank()) {
                value = withContext(Dispatchers.Default) { AvatarBitmapCache.decode(avatar) }
            }
        }
    }
    return image
}

/** Bounded to four 256×256 images; exact payload keys avoid hash-collision identity mixups. */
private object AvatarBitmapCache {
    private val images = LruCache<String, ImageBitmap>(4)
    private val decodeLock = Mutex()
    fun get(avatar: String): ImageBitmap? = images.get(avatar)
    suspend fun decode(avatar: String): ImageBitmap? = decodeLock.withLock {
        images.get(avatar)?.let { return@withLock it }
        val bitmap = runCatching {
            if (avatar.isBlank() || avatar.length > 410000) null else {
                val raw = Base64.decode(avatar, Base64.NO_WRAP)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
                if (bounds.outWidth !in 1..256 || bounds.outHeight !in 1..256) null
                else BitmapFactory.decodeByteArray(raw, 0, raw.size)?.asImageBitmap()
            }
        }.getOrNull()
        if (bitmap != null) images.put(avatar, bitmap)
        bitmap
    }
}
