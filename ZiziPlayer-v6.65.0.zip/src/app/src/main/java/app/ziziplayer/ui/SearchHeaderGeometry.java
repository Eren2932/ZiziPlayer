package app.ziziplayer.ui;

/** Pixel-space collapse math. No density constants or time-based animation. */
public final class SearchHeaderGeometry {
    private SearchHeaderGeometry() {}
    public static float nextOffset(float oldOffset, float dy, float range) {
        if (!Float.isFinite(range) || range <= 0f) return 0f;
        float old = Float.isFinite(oldOffset) ? Math.max(0f, Math.min(oldOffset, range)) : 0f;
        if (!Float.isFinite(dy)) return old;
        return Math.max(0f, Math.min(old - dy, range));
    }
    public static int visibleHeight(int fullHeight, float fraction) {
        float f = Float.isFinite(fraction) ? Math.max(0f, Math.min(fraction, 1f)) : 0f;
        return Math.round(Math.max(0, fullHeight) * (1f - f));
    }
}
