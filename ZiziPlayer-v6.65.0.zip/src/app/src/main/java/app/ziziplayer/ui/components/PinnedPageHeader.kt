package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.theme.LocalPalette

/** Fixed controls, scrolling content underneath; no invisible accessibility twin. */
@Composable
fun PinnedPageHeader(title: String, progress: () -> Float, onBack: () -> Unit,
    modifier: Modifier = Modifier, revealTitle: Boolean = true,
    action: @Composable () -> Unit = { Spacer(Modifier.size(48.dp)) }) {
    val p = LocalPalette.current
    val titleAccessible by remember(progress, revealTitle) { derivedStateOf { !revealTitle || progress() >= 0.99f } }
    Row(modifier.fillMaxWidth().pinnedPageChrome(progress).blockSurfaceInput().statusBarsPadding()
        .heightIn(min = 56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
            Icon(ZiziIcons.ArrowBack, "Назад", tint = p.text)
        }
        Text(title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).graphicsLayer { alpha = if (revealTitle) progress() else 1f }
                .then(if (titleAccessible) Modifier else Modifier.clearAndSetSemantics { }))
        action()
    }
}
