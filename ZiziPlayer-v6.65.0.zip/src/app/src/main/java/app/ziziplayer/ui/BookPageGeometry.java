package app.ziziplayer.ui;

/** Shared integer edge. Forward: base LEFT, next page RIGHT; back traverses the same path. */
public final class BookPageGeometry {
    private BookPageGeometry() {}
    public static int baseOffset(int width, float progress, boolean completing) {
        return completing ? -baseOffset(width, progress) : baseOffset(width, progress);
    }
    public static int pageOffset(int width, float progress, boolean completing) {
        return completing ? -pageOffset(width, progress) : pageOffset(width, progress);
    }
    public static int baseOffset(int width, float progress) {
        return -Math.round(width * progress);
    }
    public static int pageOffset(int width, float progress) {
        return width + baseOffset(width, progress);
    }
}
