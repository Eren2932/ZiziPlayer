package app.ziziplayer.ui

import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** A bounded, key-safe snapshot shared by disk and network paths. */
internal object HubContent {
    const val MAX_SHELVES = 24
    const val MAX_ITEMS = 60

    fun itemKey(item: RemoteItem): String = when (item) {
        is RemoteItem.Song -> item.track.trackId
        is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
    }

    fun normalize(input: List<DiscoverShelf>): List<DiscoverShelf> {
        val grouped = linkedMapOf<String, LinkedHashMap<String, RemoteItem>>()
        for (shelf in input.take(48)) {
            val title = shelf.title.trim()
            if (title.isEmpty()) continue
            if (title !in grouped && grouped.size >= MAX_SHELVES) continue
            val items = grouped.getOrPut(title) { linkedMapOf() }
            for (item in shelf.items.take(200)) {
                val supported = when (item) {
                    is RemoteItem.Song -> CatalogPolicy.supports(item.track.provider, item.track.remoteId)
                    is RemoteItem.Group -> CatalogPolicy.supports(item.collection.provider, item.collection.remoteId)
                }
                if (!supported || item.sortTitle.isBlank()) continue
                val key = itemKey(item)
                if (key !in items && items.size < MAX_ITEMS) items[key] = item
            }
        }
        return grouped.filterValues { it.isNotEmpty() }.map { (title, items) ->
            DiscoverShelf(title, items.values.toList())
        }
    }
}

internal data class HubSnapshot(val shelves: List<DiscoverShelf>, val fresh: Boolean)
internal data class HubLoadState(
    val shelves: List<DiscoverShelf> = emptyList(),
    val loading: Boolean = false,
    val refreshing: Boolean = false,
    val error: String? = null
)

/**
 * Main-thread confined, single-flight refresh. Pure Kotlin: injected I/O and scope let JVM
 * tests exercise real cancellation, duplicate taps, cache failures and timeouts without Android.
 * A force tap during startup joins that request and upgrades it to a network refresh.
 * No request cancels/replaces another, so an old finally cannot clear a newer spinner.
 */
internal class HubRefreshController(
    private val scope: CoroutineScope,
    private val preferred: suspend () -> String,
    private val readCache: suspend (String) -> HubSnapshot?,
    private val discover: suspend (String) -> List<DiscoverShelf>,
    private val writeCache: suspend (String, List<DiscoverShelf>) -> Unit,
    private val message: (String) -> Unit,
    private val describeError: (Exception) -> String,
    private val timeoutMs: Long = 20_000L,
    private val cacheWriteTimeoutMs: Long = 1_500L
) {
    private val _state = MutableStateFlow(HubLoadState())
    val state = _state.asStateFlow()
    private var forceRequested = false
    private var reportRequested = false

    fun load(force: Boolean = false) {
        if (_state.value.refreshing) {
            forceRequested = forceRequested || force
            reportRequested = reportRequested || force
            return
        }
        if (!force && _state.value.shelves.isNotEmpty()) return
        forceRequested = force
        reportRequested = force
        // Set BEFORE launching: even taps in the same UI frame join one flight.
        _state.value = _state.value.copy(
            loading = _state.value.shelves.isEmpty(), refreshing = true, error = null
        )
        scope.launch {
            try {
                var provider: String? = null
                var cacheToWrite: List<DiscoverShelf>? = null
                val outcome = withTimeoutOrNull(timeoutMs) {
                    val selected = preferred()
                    provider = selected
                    val cached = if (_state.value.shelves.isEmpty()) {
                        try { readCache(selected) }
                        catch (e: CancellationException) { throw e }
                        catch (_: Exception) { null } // Cache failure is a miss, not a broken hub.
                    } else null
                    val cachedShelves = withContext(Dispatchers.Default) {
                        HubContent.normalize(cached?.shelves.orEmpty())
                    }
                    if (cachedShelves.isNotEmpty()) {
                        _state.value = _state.value.copy(shelves = cachedShelves, loading = false)
                    }
                    if (!forceRequested && cached?.fresh == true && cachedShelves.isNotEmpty()) {
                        return@withTimeoutOrNull Outcome.CACHED
                    }
                    val response = discover(selected)
                    val fresh = withContext(Dispatchers.Default) { HubContent.normalize(response) }
                    if (fresh.isEmpty()) return@withTimeoutOrNull Outcome.EMPTY
                    val unchanged = fresh == _state.value.shelves
                    // Equal snapshots retain the old list instance and its scroll/artwork state.
                    if (!unchanged) _state.value = _state.value.copy(shelves = fresh, loading = false)
                    cacheToWrite = fresh
                    if (unchanged) Outcome.UNCHANGED else Outcome.UPDATED
                }
                if (outcome == null) {
                    fail("Источник не успел ответить. Попробуй ещё раз")
                } else {
                    // A full/unwritable disk must not turn a successful refresh into an error.
                    val selected = provider
                    val snapshot = cacheToWrite
                    if (selected != null && snapshot != null) {
                        try {
                            withTimeoutOrNull(cacheWriteTimeoutMs) { writeCache(selected, snapshot) }
                        } catch (e: CancellationException) { throw e }
                        catch (_: Exception) { /* The in-memory snapshot is already usable. */ }
                    }
                    if (reportRequested) message(when (outcome) {
                        Outcome.UPDATED -> "Подборки обновлены"
                        Outcome.UNCHANGED, Outcome.CACHED -> "Новых подборок пока нет"
                        Outcome.EMPTY -> if (_state.value.shelves.isEmpty())
                            "Подборок пока нет. Поиск по-прежнему доступен"
                        else "Новых подборок пока нет — прежние сохранены"
                    })
                }
            } catch (e: CancellationException) {
                throw e // Leaving the ViewModel is not a provider failure.
            } catch (e: Exception) {
                fail(describeError(e))
            } finally {
                _state.value = _state.value.copy(loading = false, refreshing = false)
                forceRequested = false
                reportRequested = false
            }
        }
    }

    private fun fail(reason: String) {
        val hasContent = _state.value.shelves.isNotEmpty()
        _state.value = _state.value.copy(error = if (hasContent) null else reason)
        if (reportRequested) message(
            "Не удалось обновить подборки: $reason" + if (hasContent) ". Прежние сохранены" else ""
        )
    }

    private enum class Outcome { CACHED, UPDATED, UNCHANGED, EMPTY }
}
