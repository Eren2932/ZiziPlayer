package app.ziziplayer.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.offset
import androidx.compose.ui.unit.constrainWidth

/** Extend a lazy item's surface through symmetric list content padding, not its content.
 * Parent still measures the original item width; the child is placed at -inset on both LTR/RTL.
 * Only use in a bounded-width lazy list, with the same inset as its contentPadding.
 */
fun Modifier.fullBleedHorizontal(inset: Dp): Modifier = layout { measurable, constraints ->
    val edge = inset.roundToPx().coerceAtLeast(0)
    val child = measurable.measure(constraints.offset(horizontal = edge * 2))
    layout(constraints.constrainWidth(child.width - edge * 2), child.height) {
        child.placeRelative(-edge, 0)
    }
}
