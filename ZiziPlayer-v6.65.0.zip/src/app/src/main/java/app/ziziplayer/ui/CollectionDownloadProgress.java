package app.ziziplayer.ui;

/** Track-weighted availability, not byte progress (remote sizes may be unknown). */
public final class CollectionDownloadProgress {
    private CollectionDownloadProgress() {}
    public static float fraction(int ready, int total, float runningPercentSum) {
        if (total <= 0) return 0f;
        float running = Float.isFinite(runningPercentSum) ? Math.max(0f, runningPercentSum) : 0f;
        return Math.max(0f, Math.min(1f, (Math.max(0, ready) + running / 100f) / total));
    }
}
