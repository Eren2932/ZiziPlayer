package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import app.ziziplayer.ui.AccountUiGeometry
import kotlin.math.roundToInt

/** One clock for both surfaces. Read progress in drawing/layers, never rebuild the feed per frame. */
@Composable
fun AccountDrawerHost(open: Boolean, onClose: () -> Unit,
    drawer: @Composable () -> Unit, content: @Composable () -> Unit) {
    val progress = remember { Animatable(0f) }
    val mounted by remember(open) { derivedStateOf { open || progress.value > 0f } }
    LaunchedEffect(open) {
        // A rapid reversal starts the next animation at the current position.
        progress.animateTo(if (open) 1f else 0f, tween(280, easing = FastOutSlowInEasing))
    }
    BoxWithConstraints(Modifier.fillMaxSize().clipToBounds().background(Color(0xFF202020))) {
        // fillMaxWidth rounds its measured width to integer pixels; use the identical edge.
        val travel = (with(LocalDensity.current) { maxWidth.toPx() } * AccountUiGeometry.DRAWER_FRACTION).roundToInt().toFloat()
        if (mounted) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(AccountUiGeometry.DRAWER_FRACTION)
                .graphicsLayer { translationX = travel * (progress.value - 1f) }
                .then(if (!open) Modifier.clearAndSetSemantics { } else Modifier)) {
                drawer()
                // The outgoing menu must not dispatch a second destination while it closes.
                if (!open) Box(Modifier.fillMaxSize().blockSurfaceInput())
            }
        }
        Box(Modifier.fillMaxSize().graphicsLayer { translationX = travel * progress.value }) {
            Box(Modifier.fillMaxSize().then(if (mounted) Modifier.clearAndSetSemantics { } else Modifier)) { content() }
            if (mounted) {
                Box(Modifier.fillMaxSize().drawWithContent {
                    drawRect(Color.Black.copy(alpha = 0.65f * progress.value))
                }.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null,
                    onClickLabel = "Закрыть меню аккаунта", onClick = onClose))
            }
        }
    }
}
