package app.ziziplayer.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.ui.window.Dialog
import app.ziziplayer.ui.CollectionDownloadProgress
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.CollectionGeometry as G
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ArtworkPrefetcher
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Local destinations deliberately do not compose the library title, chips or surface bar.
 * One scroll owner, one play button, one permanent toolbar; no sticky duplicate controls.
 */
@Composable
internal fun LocalCollectionScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    selected: Set<String>,
    downloads: Map<String, DownloadStatus>,
    onMenu: (TrackEntity) -> Unit,
    onSort: () -> Unit,
    onAdd: () -> Unit,
    selectionHeader: @Composable (Dp) -> Unit
) {
    if (state.openArtist == null) {
        UnifiedLocalCollectionScreen(vm, state, playback, selected, downloads, onMenu, onSort, onAdd, selectionHeader)
        return
    }
    val p = LocalPalette.current
    val base = Color(0xFF121212)
    val destination = state.openPlaylist?.id?.let { "playlist:$it" }
        ?: state.openFolder?.let { "folder:$it" }
        ?: state.openArtist?.let { "artist:$it" } ?: state.filter.name
    val title = state.openPlaylist?.name
        ?: state.openFolder?.let { folder -> state.folders.firstOrNull { it.name == folder }?.label ?: folder }
        ?: state.openArtist
        ?: if (state.filter == LibraryFilter.FAVORITES) "Избранное" else "Все треки"
    // Stable per destination, independent of the currently playing artwork.
    val color = when {
        state.openFolder != null -> Color(0xFF246B68)
        state.openArtist != null -> Color(0xFF594681)
        state.openPlaylist != null -> Color(0xFF8C4D32)
        state.filter == LibraryFilter.FAVORITES -> Color(0xFF984629)
        else -> Color(0xFF345B79)
    }
    val list = rememberSaveable(destination, saver = LazyListState.Saver) { LazyListState() }
    LaunchedEffect(list) {
        snapshotFlow { list.isScrollInProgress }.collectLatest { moving ->
            while (moving) {
                ArtworkCache.markBusy()
                ArtworkPrefetcher.focusOn((list.firstVisibleItemIndex - 2).coerceAtLeast(0))
                delay(120)
            }
        }
    }
    var showDownloads by rememberSaveable(destination) { mutableStateOf(false) }
    val picking = selected.isNotEmpty()
    val focus = LocalFocusManager.current
    LaunchedEffect(state.searchOpen) { if (!state.searchOpen) focus.clearFocus() }
    // Do not reset scroll for query changes: the editor itself is inside the hero.
    // Keeping a stable first hero item means filtering cannot steal focus or jump the header.
    BoxWithConstraints(Modifier.fillMaxSize().background(base)) {
        val unit = maxWidth.value / G.REFERENCE_WIDTH
        val toolbarHeight = (G.TOOLBAR * unit).dp.coerceAtLeast(48.dp)
        val density = LocalDensity.current
        val pxPerUnit = with(density) { unit.dp.toPx() }
        var titleHeightPx by remember(title, maxWidth, density.fontScale) { mutableIntStateOf(0) }
        val fontExtra = (titleHeightPx / pxPerUnit - 80f).coerceAtLeast(0f) +
            (density.fontScale - 1f).coerceAtLeast(0f) * 40f
        val heroUnits = G.HERO + fontExtra
        val bottomPadding = LocalBottomChromeInset.current + 24.dp
        val statusInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val viewportUnits = (maxHeight - statusInset).value / unit
        val tail = (G.minimumTail(viewportUnits, heroUnits, state.visible.size, bottomPadding.value / unit) * unit).dp
        fun scrollUnits(): Float = if (list.firstVisibleItemIndex == 0)
            list.firstVisibleItemScrollOffset / pxPerUnit else heroUnits

        // The destination owns the status area too; the host still draws the system icon tint.
        Box(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(color))
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            LazyColumn(
                state = list,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = bottomPadding)
            ) {
                item(key = "collection:hero", contentType = "hero") {
                    Box(Modifier.fillMaxWidth().height((heroUnits * unit).dp).background(
                        Brush.verticalGradient(0f to color, 0.55f to color.copy(alpha = 0.52f), 1f to base)
                    )) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = (G.CONTENT_INSET * unit).dp)
                            .offset(y = (164f * unit).dp), horizontalArrangement = Arrangement.spacedBy((24f * unit).dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f).heightIn(min = (112f * unit).dp)
                                .clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.10f))
                                .padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(ZiziIcons.Search, null, tint = Color.White, modifier = Modifier.size(21.dp))
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(
                                    value = state.query,
                                    onValueChange = { vm.setSearchOpen(true); vm.setQuery(it) },
                                    singleLine = true,
                                    textStyle = TextStyle(color = Color.White, fontFamily = ZiziFontFamily,
                                        fontSize = (39f * unit).sp, fontWeight = FontWeight.SemiBold),
                                    cursorBrush = SolidColor(p.brand),
                                    modifier = Modifier.weight(1f).semantics { contentDescription = "Поиск в подборке" },
                                    decorationBox = { field ->
                                        Box {
                                            if (state.query.isEmpty()) Text("Поиск в подборке", color = Color.White,
                                                fontSize = (39f * unit).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            field()
                                        }
                                    }
                                )
                            }
                            Box(Modifier.width((334f * unit).dp).heightIn(min = (112f * unit).dp)
                                .clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.10f))
                                .clickable(role = Role.Button, onClick = onSort).padding(8.dp), contentAlignment = Alignment.Center) {
                                Text("Сортировать", color = Color.White, fontWeight = FontWeight.Bold,
                                    fontSize = (39f * unit).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Text(title, color = Color.White, fontSize = (72f * unit).sp,
                            lineHeight = (80f * unit).sp, fontWeight = FontWeight.ExtraBold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis,
                            onTextLayout = { titleHeightPx = it.size.height },
                            modifier = Modifier.offset(y = (510f * unit).dp)
                                .padding(horizontal = (G.CONTENT_INSET * unit).dp))
                        Text(trackCountLabel(state.collectionTracks.size), color = Color(0xFFB8B8B8),
                            fontSize = (39f * unit).sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.offset(y = ((650f + fontExtra) * unit).dp)
                                .padding(horizontal = (G.CONTENT_INSET * unit).dp))
                        IconButton(onClick = { showDownloads = true },
                            enabled = state.collectionTracks.isNotEmpty(),
                            modifier = Modifier.offset(x = (10f * unit).dp, y = ((713f + fontExtra) * unit).dp)
                                .size((G.PLAY_SIZE * unit).dp)) {
                            Icon(ZiziIcons.DownloadCircle, "Скачать всю подборку", tint = p.subtext,
                                modifier = Modifier.size((64f * unit).dp))
                        }
                        IconButton(onClick = { if (state.visible.isNotEmpty()) { val shuffled = state.visible.shuffled(); vm.play(shuffled.first(), shuffled) } },
                            enabled = state.visible.isNotEmpty(),
                            modifier = Modifier.align(Alignment.TopEnd)
                                .offset(x = (-160f * unit).dp, y = ((713f + fontExtra) * unit).dp)
                                .size((G.PLAY_SIZE * unit).dp)) {
                            Icon(ZiziIcons.Shuffle, "Перемешать подборку", tint = p.brand, modifier = Modifier.size((70f * unit).dp))
                        }
                    }
                }
                item(key = "collection:add", contentType = "action") {
                    Row(Modifier.fillMaxWidth().heightIn(min = (G.ROW * unit).dp)
                        .clickable(role = Role.Button, onClick = onAdd)
                        .padding(horizontal = (G.CONTENT_INSET * unit).dp, vertical = (22f * unit).dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size((G.ART * unit).dp).background(Color(0xFF282828)), contentAlignment = Alignment.Center) {
                            Icon(ZiziIcons.Plus, null, tint = p.subtext, modifier = Modifier.size((70f * unit).dp))
                        }
                        Spacer(Modifier.width((36f * unit).dp))
                        Text("Импортировать музыку", color = p.text, fontSize = (48f * unit).sp,
                            fontWeight = FontWeight.Bold, maxLines = 2)
                    }
                }
                if (state.loading) item(key = "collection:loading") {
                    Text("Загружаем…", color = p.subtext, modifier = Modifier.padding(24.dp))
                } else if (state.visible.isEmpty()) item(key = "collection:empty") {
                    Text(if (state.query.isNotBlank()) "Ничего не найдено" else "Здесь пока нет треков",
                        color = p.subtext, modifier = Modifier.padding(24.dp))
                }
                items(state.visible, key = { it.id }, contentType = { "track" }) { track ->
                    CollectionTrackRow(track, unit, track.id == playback.currentTrackId,
                        selected = track.id in selected, picking = picking,
                        onPlay = { vm.play(track, state.visible) }, onSelect = { vm.toggleSelected(track.id) },
                        onLongPress = { vm.startSelection(track.id) }, onMenu = { onMenu(track) })
                }
                item(key = "collection:collapse-room", contentType = "spacer") { Spacer(Modifier.height(tail)) }
            }
            // Background alpha is read in draw, position in placement, not as whole-screen state.
            Box(Modifier.fillMaxWidth().height(toolbarHeight)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .clearAndSetSemantics { }
                .graphicsLayer { alpha = G.headerAlpha(scrollUnits()) }.background(color))
            Crossfade(
                targetState = picking, animationSpec = tween(160), label = "collection-selection",
                modifier = Modifier.fillMaxWidth().height(toolbarHeight)
            ) { selecting ->
                if (selecting) {
                    Box(Modifier.fillMaxSize().background(color)) { selectionHeader(toolbarHeight) }
                } else {
                    Box(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { focus.clearFocus(); vm.handleBack() }, modifier = Modifier.size(48.dp)) {
                                Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (48f * unit).sp,
                            textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxSize().padding(horizontal = (180f * unit).dp)
                                .wrapContentHeight(Alignment.CenterVertically)
                                .graphicsLayer { alpha = G.titleAlpha(scrollUnits()) })
                    }
                }
            }
            if (!picking) {
                val playingHere = playback.isPlaying && state.collectionTracks.any { it.id == playback.currentTrackId }
                IconButton(
                    enabled = state.visible.isNotEmpty() || playingHere,
                    onClick = {
                        if (state.collectionTracks.any { it.id == playback.currentTrackId }) vm.playPause()
                        else state.visible.firstOrNull()?.let { vm.play(it, state.visible) }
                    },
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = (G.PLAY_END * unit).dp)
                        .offset { IntOffset(0, ((G.playTop(scrollUnits(), fontExtra)) * pxPerUnit).roundToInt()) }
                        .size((G.PLAY_SIZE * unit).dp).clip(CircleShape)
                        .background(if (state.visible.isEmpty()) p.chip else p.brand)
                ) {
                    Icon(if (playingHere) ZiziIcons.Pause else ZiziIcons.CollectionPlayFilled,
                        if (playingHere) "Пауза" else "Слушать подборку",
                        tint = Color.Black, modifier = Modifier.size(((if (playingHere) 64f else G.PLAY_SIZE) * unit).dp))
                }
            }
        }
    }
    if (showDownloads) {
        CollectionDownloadDialog(vm, state.collectionTracks, downloads) { showDownloads = false }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun CollectionTrackRow(
    track: TrackEntity, unit: Float, current: Boolean, selected: Boolean, picking: Boolean,
    onPlay: () -> Unit, onSelect: () -> Unit, onLongPress: () -> Unit, onMenu: () -> Unit,
    horizontalInset: Dp? = null
) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = (G.ROW * unit).dp)
        .background(if (selected) p.brand.copy(alpha = 0.16f) else Color.Transparent)
        .semantics { this.selected = selected }
        .combinedClickable(onClick = if (picking) onSelect else onPlay, onLongClick = onLongPress)
        .padding(start = horizontalInset ?: (G.CONTENT_INSET * unit).dp, end = horizontalInset ?: (46f * unit).dp, top = (22f * unit).dp, bottom = (22f * unit).dp),
        verticalAlignment = Alignment.CenterVertically) {
        TrackArtwork(track, 224, Modifier.size((G.ART * unit).dp).clip(RoundedCornerShape(4.dp)), glyphSize = 22)
        Spacer(Modifier.width((36f * unit).dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = if (current) p.brand else p.text, fontSize = (48f * unit).sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(track.artist, color = p.subtext, fontSize = (39f * unit).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = if (picking) onSelect else onMenu, modifier = Modifier.size(48.dp)) {
            Icon(if (picking && selected) ZiziIcons.Check else ZiziIcons.More,
                if (picking) "Выбрать трек" else "Меню трека", tint = if (selected) p.brand else p.subtext,
                modifier = Modifier.size(22.dp))
        }
    }
}

/** Disk checks run on IO, never in list composition. Membership is the whole collection,
 * not the visible search results. Cancel/retry touch only this destination's IDs.
 */
@Composable
internal fun CollectionDownloadDialog(
    vm: MainViewModel, tracks: List<TrackEntity>, live: Map<String, DownloadStatus>, onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val unique = remember(tracks) { tracks.distinctBy { it.id } }
    val disk by produceState<Map<String, DownloadStatus>?>(null, unique) {
        value = withContext(Dispatchers.IO) { unique.associate { it.id to vm.downloadStatus(it) } }
    }
    val statuses = remember(disk, live) {
        disk?.mapValues { (id, status) -> live[id] ?: when (status) {
            is DownloadStatus.Running, DownloadStatus.Queued, is DownloadStatus.Failed -> DownloadStatus.None
            else -> status
        } }
    }
    val values = statuses?.values.orEmpty()
    val done = values.count { it is DownloadStatus.Done || it is DownloadStatus.Local }
    val active = values.count { it is DownloadStatus.Running || it is DownloadStatus.Queued }
    val failed = values.count { it is DownloadStatus.Failed }
    val unknownSize = values.any { it is DownloadStatus.Running && it.percent < 0 }
    val runningPercent = values.sumOf { if (it is DownloadStatus.Running) it.percent.coerceIn(0, 100) else 0 }.toFloat()
    val progress = CollectionDownloadProgress.fraction(done, unique.size, runningPercent)
    val animatedProgress = animateFloatAsState(progress, tween(180), label = "collection-download-progress")
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xFF111111), tonalElevation = 0.dp) {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp)
                .verticalScroll(rememberScrollState()).padding(24.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Загрузка подборки", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(ZiziIcons.Close, "Закрыть", tint = p.subtext, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(if (statuses == null) "Проверяем файлы…" else "На устройстве $done из ${unique.size}",
                    color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(14.dp))
                if (statuses == null || unknownSize) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = p.brand, trackColor = Color(0xFF303030))
                } else {
                    LinearProgressIndicator(progress = { animatedProgress.value },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = p.brand, trackColor = Color(0xFF303030))
                }
                Spacer(Modifier.height(12.dp))
                Text(when {
                    statuses == null -> " "
                    unique.isEmpty() -> "В подборке пока нет треков"
                    done == unique.size -> "Всё готово для прослушивания без сети"
                    active > 0 -> "В работе: $active" + if (failed > 0) " · Ошибок: $failed" else ""
                    failed > 0 -> "Не удалось скачать: $failed"
                    else -> "Осталось скачать: ${unique.size - done}"
                }, color = p.subtext, fontSize = 13.sp, minLines = 2)
                Spacer(Modifier.height(8.dp))
                Text("Можно закрыть — загрузка продолжится", color = p.subtext, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { vm.downloadCollection(unique) },
                    enabled = statuses != null && done + active < unique.size,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = p.brand, contentColor = p.onBrand)) {
                    Text(if (failed > 0) "Повторить недокачанные" else "Скачать недостающие", fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { vm.cancelCollectionDownloads(unique) }, enabled = active > 0,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Text("Отменить загрузку", color = if (active > 0) p.subtext else p.subtext.copy(alpha = 0.38f))
                }
            }
        }
    }
}
