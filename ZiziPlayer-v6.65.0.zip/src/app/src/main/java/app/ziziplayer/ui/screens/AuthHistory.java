package app.ziziplayer.ui.screens;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Main-thread navigation transaction. One accepted action per completed animation. */
public final class AuthHistory<T> {
    private final ArrayList<T> stack = new ArrayList<>();
    private boolean moving;
    private boolean backwards;
    private long revision;

    public AuthHistory(T root) { stack.add(Objects.requireNonNull(root)); }
    public T current() { return stack.get(stack.size() - 1); }
    public int depth() { return stack.size(); }
    public boolean isMoving() { return moving; }
    public boolean isBackwards() { return backwards; }
    public long revision() { return revision; }

    public boolean forward(T next) {
        Objects.requireNonNull(next);
        if (moving || current().equals(next)) return false;
        stack.add(next);
        begin(false);
        return true;
    }

    public boolean back() {
        if (moving || stack.size() == 1) return false;
        stack.remove(stack.size() - 1);
        begin(true);
        return true;
    }

    /** Successful verification/reset starts a fresh login path, not an old one-time-code path. */
    public boolean resetTo(List<T> path) {
        if (path.isEmpty()) throw new IllegalArgumentException("Empty auth path");
        for (T step : path) Objects.requireNonNull(step);
        if (moving) return false;
        stack.clear();
        stack.addAll(path);
        // This is a successful forward step (verify/reset -> login), not a Back press.
        begin(false);
        return true;
    }

    private void begin(boolean back) {
        backwards = back;
        revision++;
        moving = true;
    }

    /** Ignore a stale animation's completion; zero animation scale also settles this way. */
    public void settle(long completedRevision) {
        if (completedRevision == revision) moving = false;
    }
}
