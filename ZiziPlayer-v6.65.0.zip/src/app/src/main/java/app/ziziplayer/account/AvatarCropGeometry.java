package app.ziziplayer.account;

/** Pure geometry shared by the gesture preview and the exported crop. Units: crop side = 1. */
public final class AvatarCropGeometry {
    public static final float MAX_ZOOM = 8f;
    private AvatarCropGeometry() {}

    public static final class Pose {
        public final float zoom, x, y;
        public Pose(float zoom, float x, float y) { this.zoom = zoom; this.x = x; this.y = y; }
    }
    public static final class Crop {
        public final float left, top, side;
        Crop(float left, float top, float side) { this.left = left; this.top = top; this.side = side; }
    }
    public static Pose initial() { return new Pose(1f, 0f, 0f); }
    private static float finite(float value, float fallback) { return Float.isFinite(value) ? value : fallback; }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    private static void dimensions(int width, int height) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("Invalid image dimensions");
    }
    public static Pose constrain(int width, int height, Pose pose) {
        dimensions(width, height);
        float zoom = clamp(finite(pose.zoom, 1f), 1f, MAX_ZOOM);
        float min = Math.min(width, height);
        float dx = Math.max(0f, (width / min * zoom - 1f) / 2f);
        float dy = Math.max(0f, (height / min * zoom - 1f) / 2f);
        return new Pose(zoom, clamp(finite(pose.x, 0f), -dx, dx), clamp(finite(pose.y, 0f), -dy, dy));
    }
    /** Zoom stays anchored under the centroid; pan and centroid are relative to the crop square. */
    public static Pose gesture(int width, int height, Pose pose, float zoomChange,
                               float panX, float panY, float centroidX, float centroidY) {
        Pose old = constrain(width, height, pose);
        float nextZoom = clamp(old.zoom * finite(zoomChange, 1f), 1f, MAX_ZOOM);
        float ratio = nextZoom / old.zoom;
        float cx = finite(centroidX, 0f), cy = finite(centroidY, 0f);
        return constrain(width, height, new Pose(nextZoom,
            (old.x - cx) * ratio + cx + finite(panX, 0f),
            (old.y - cy) * ratio + cy + finite(panY, 0f)));
    }
    public static Crop crop(int width, int height, Pose pose) {
        Pose p = constrain(width, height, pose);
        float side = Math.min(width, height) / p.zoom;
        return new Crop(clamp(width / 2f - (0.5f + p.x) * side, 0f, width - side),
                        clamp(height / 2f - (0.5f + p.y) * side, 0f, height - side), side);
    }
}
