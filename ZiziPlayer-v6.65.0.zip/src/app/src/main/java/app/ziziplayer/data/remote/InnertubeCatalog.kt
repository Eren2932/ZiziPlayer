package app.ziziplayer.data.remote

import android.net.Uri
import kotlinx.coroutines.CancellationException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * YouTube Music through its own internal API (Innertube).
 *
 * Optional direct catalogue and playback source. The primary metadata catalogue uses the server.
 * This is a private API, and the consequences are:
 *
 *  - it is used against YouTube's terms of service;
 *  - the response shape changes without notice, so **every** parse below returns null on anything
 *    unexpected instead of throwing (see Json.kt for why that is not laziness but the design);
 *  - stream URLs are short lived and IP bound, which is why nothing here is ever cached or stored:
 *    [resolveStream] is called from the Media3 loading thread at the moment the stream is opened.
 *
 * No cookies, no login, no account. Not only because personalisation is not worth it, but because
 * an account attached to this kind of traffic is an account that gets banned - the app would keep
 * working, the user's YouTube would not.
 */
class InnertubeCatalog(
    private val apiKey: String,
    private val hl: String = Locale.getDefault().language.ifEmpty { "ru" },
    private val gl: String = Locale.getDefault().country.ifEmpty { "RU" }
) : RemoteCatalog {

    override val id: String = ID
    override val label: String = "YouTube Music"

    companion object {
        /**
         * Идентификатор источника как константа companion-объекта (6.19.1).
         *
         * `id` — свойство экземпляра из интерфейса `RemoteCatalog`, и обращаться к нему там, где
         * экземпляра нет (например из политики ошибок загрузки), нельзя: `InnertubeCatalog.id` не
         * компилируется. Писать вместо этого литерал `"yt"` по коду — способ однажды разъехаться
         * между местом сравнения и местом записи в базу. Поэтому строка живёт здесь одна, а
         * `id` экземпляра берётся из неё.
         */
        const val ID = "yt"

        /**
         * THREE hosts, because the host has to match the client - 6.7.0 sent every client to
         * music.youtube.com and that is one of the two reasons YouTube "did not start".
         *
         * music.youtube.com is the web app's own host and it is the only one that wants the web
         * `key`. The app clients (VR, the two music apps) talk to youtubei.googleapis.com, and the
         * embedded TV player talks to www.youtube.com - asking them on the wrong host returns a
         * perfectly well formed response with no `streamingData` in it at all, which is exactly the
         * silence we were getting.
         */
        const val MUSIC = "https://music.youtube.com/youtubei/v1"
        const val API = "https://youtubei.googleapis.com/youtubei/v1"
        const val WWW = "https://www.youtube.com/youtubei/v1"

        /**
         * Search filter blobs. These are protobuf-encoded filter selections, i.e. exactly the
         * bytes the web app itself sends when a chip is tapped. They are stable in practice but
         * they are not ours, so a failed filtered search degrades to an unfiltered one rather than
         * to an error - the user sees results, mixed, instead of a red screen.
         */
        const val FILTER_SONGS = "EgWKAQIIAWoKEAkQBRAKEAMQBA=="
        const val FILTER_ALBUMS = "EgWKAQIYAWoKEAkQChAFEAMQBA=="
        const val FILTER_PLAYLISTS = "EgeKAQQoAEABagwQDhAKEAMQBRAJEBU="
        const val FILTER_ARTISTS = "EgWKAQIgAWoKEAkQChAFEAMQBA=="

        /**
         * Clients tried in order for a stream, and WHY the order is what it is.
         *
         * 6.6.0 asked ANDROID_MUSIC first, then IOS_MUSIC, then WEB_REMIX, and every track failed:
         * the player answered `status: OK`, handed back a URL, and the GET of that URL came back
         * 403. That is not a parsing bug and it is not a network bug - it is attestation. Since
         * mid-2024 the mobile app clients are expected to present a `poToken` minted by Google's
         * own attestation service; a request without one still gets a *shaped* answer, which is the
         * cruel part, but the URLs inside it are dead on arrival. The queue then did exactly what
         * it was told to do with a dead remote track: skipped to the next one, and the next, and
         * the next. "Само свайпает без проигрывания" was the auto-skip working correctly on top of
         * a source that was 100% broken.
         *
         * ANDROID_VR is first because it is the one client that is still served unciphered,
         * un-attested URLs: it ships on standalone headsets that cannot run the attestation
         * library, so Google kept it exempt. TVHTML5_SIMPLY_EMBEDDED_PLAYER is the second exemption
         * (embedded playback on TVs) and it is a genuinely different code path, so it survives when
         * the first one does not. The two mobile music clients stay as third and fourth: they cost
         * one request each, they still work for some tracks, and the day attestation is relaxed
         * they are the ones with the best audio formats. WEB_REMIX stays last and is expected to
         * fail with `signatureCipher` - it is kept only so the error message can say so.
         *
         * [ua] is not decoration either. A googlevideo URL is bound to the client identity that
         * minted it, and fetching an ANDROID_VR URL with a Chrome user agent is one more way to
         * earn a 403. The chosen UA travels with the URL all the way into the data source - see
         * [StreamInfo.userAgent] and `StreamResolver`.
         */
        val STREAM_CLIENTS = listOf(
            StreamClient(
                name = "ANDROID_VR",
                // 6.9.3: 1.65.x was ahead of what the Quest store actually ships. An app version
                // the server has never seen is a cheap way to look synthetic; 1.61.50 is the build
                // the extractors currently pin.
                version = "1.61.50",
                ua = "com.google.android.apps.youtube.vr.oculus/1.61.50 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
            ),
            /*
             * NEW IN 6.8.1. The plain iOS client, not the music one.
             *
             * 6.8.0 had five clients and every one of them answered "Sign in to confirm you're not
             * a bot" - which is the bot check, not a broken host and not a missing key. The iOS
             * main client is a genuinely different attestation path from IOS_MUSIC (different app,
             * different integrity requirements) and it is the one that is still commonly served
             * plain URLs. It costs one request to ask.
             */
            StreamClient(
                name = "IOS",
                version = "20.10.4",
                ua = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X; ru_RU)"
            ),
            StreamClient(
                name = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                version = "2.0",
                ua = "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"
            ),
            /*
             * NEW IN 6.8.1. Embedded web player.
             *
             * Embedded playback is a separate exemption from the app clients: the page that embeds
             * a video has no way to attest, so the bot check is applied differently there. Its URLs
             * are often ciphered - which is why it is BELOW the TV one - but "often" is not
             * "always", and when it is not ciphered it plays.
             */
            StreamClient(
                name = "WEB_EMBEDDED_PLAYER",
                version = "1.20250310.01.00",
                ua = ZiziHttp.USER_AGENT
            ),
            /*
             * NEW IN 6.8.1. Mobile web.
             *
             * The cheapest possible client identity: a phone browser, no app, nothing to attest.
             * Kept low in the order because it hands back ciphered formats more often than not.
             */
            StreamClient(
                name = "MWEB",
                version = "2.20250311.03.00",
                ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
            ),
            StreamClient(
                name = "IOS_MUSIC",
                version = "7.27.0",
                ua = "com.google.ios.youtubemusic/7.27.0 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)"
            ),
            StreamClient(
                name = "ANDROID_MUSIC",
                version = "7.27.52",
                ua = "com.google.android.apps.youtube.music/7.27.52 (Linux; U; Android 14; ru_RU) gzip"
            ),
            StreamClient(
                name = "WEB_REMIX",
                version = "1.20241028.01.00",
                ua = ZiziHttp.USER_AGENT
            )
        )

        /**
         * The numeric client id, which Innertube cross-checks against the context.
         *
         * 6.8.0 sent `X-Youtube-Client-Name` for WEB_REMIX only. For the app clients the header was
         * simply absent, and a request whose header and whose context disagree about who is asking
         * is exactly the kind of request the bot check likes least. Cheap to send, so it is sent
         * for every client now.
         */
        val CLIENT_IDS = mapOf(
            "MWEB" to "2",
            "IOS" to "5",
            "ANDROID_MUSIC" to "21",
            "IOS_MUSIC" to "26",
            "ANDROID_VR" to "28",
            "WEB_EMBEDDED_PLAYER" to "56",
            "WEB_REMIX" to "67",
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" to "85"
        )

        /**
         * THE MISSING HALF OF EVERY REQUEST THIS APP HAS EVER SENT (6.8.1).
         *
         * `visitorData` is the session identity Innertube hands out on first contact and expects to
         * see on every request afterwards. Up to 6.8.0 the app never asked for one and never sent
         * one, so every single call - search, browse, player - arrived as a brand new anonymous
         * client with no history. Search tolerates that. The player endpoint is precisely where the
         * bot check lives, and a caller with no visitor identity is its first suspect: that is the
         * literal meaning of the "Войдите, чтобы подтвердить, что вы не робот" we got from all five
         * clients at once.
         *
         * It is NOT a poToken and it is not claimed to be one - a token still has to be minted by
         * running Google's BotGuard JavaScript, which needs a WebView and is the next step. This is
         * the free half: one request per session, no JS, no new dependency, and it is a hard
         * prerequisite for the token anyway (a poToken is bound to the visitorData it was minted
         * for). If the check relaxes for a client once it has a session, this alone fixes playback.
         */
        @Volatile private var visitorId: String? = null
        @Volatile private var visitorAtMs: Long = 0L
        private const val VISITOR_TTL_MS = 6 * 60 * 60 * 1000L

        val DURATION = Regex("""^\d{1,2}:\d{2}(:\d{2})?$""")

        /**
         * Which internal client last produced a URL the CDN actually served, and which ones are
         * being rested.
         *
         * Process wide and deliberately so: the resolver runs on Media3's loader thread, once per
         * track, and the answer to "who works right now" is a property of the network and of
         * YouTube's current mood - not of a screen. It is what makes the verification below cost
         * one round trip per session instead of one per track.
         */
        @Volatile private var trusted: String? = null
        private val restedUntil = ConcurrentHashMap<String, Long>()

        /** A client is rested for ten minutes after the CDN refused its URL. */
        private const val REST_MS = 10 * 60 * 1000L

        /**
         * Called when playback itself failed with 403 on a URL we had already trusted.
         *
         * The trust is dropped, not the client: it goes back into the verified-on-first-use pool,
         * so the very next track pays one probe and either confirms it or moves on.
         */
        fun distrust() { trusted = null }
    }

    // ---------------------------------------------------------------- request plumbing

    /**
     * 6.9.3. WHO IS ALLOWED TO SEE THE WEB SESSION.
     *
     * visitorData and the BotGuard poToken are BOTH browser artefacts: the visitor id is handed out
     * by music.youtube.com to a browser, and the token is minted by the web player's own request
     * key (O43z0dpjhgX20SCx4KAo) from a youtube.com origin. 6.9.0-6.9.2 attached both to every
     * client in the ladder, app clients included - which means ANDROID_VR was introducing itself as
     * an Oculus app while carrying a web browser's session identity and a web browser's
     * attestation. That is not "extra proof", it is a contradiction, and a contradiction is exactly
     * what the bot check is looking for. It is the most plausible reason the ONE client that is
     * supposed to be exempt from attestation - ANDROID_VR - answers LOGIN_REQUIRED.
     *
     * So the web identity now stays inside the web family. The app clients go back to being
     * anonymous app clients, which is what they are and what yt-dlp/NewPipe send.
     */
    private fun isWebFamily(client: StreamClient): Boolean = when (client.name) {
        "WEB_REMIX", "WEB_EMBEDDED_PLAYER", "MWEB", "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> true
        else -> false
    }

    /**
     * 6.9.4. THE BUG THAT WAS NEVER A BOT CHECK.
     *
     * The 6.9.3 diagnostics report finally said it out loud: all four app clients answered
     * `OFFLINE: Нет соединения`, while the three clients on www.youtube.com and music.youtube.com
     * answered normally in the same second. `OFFLINE` here is [ZiziHttp]'s label for
     * UnknownHostException - a DNS failure. The phone was online the whole time.
     *
     * `youtubei.googleapis.com` simply does not resolve on this network. Which means ANDROID_VR -
     * the one client in the whole ladder that is exempt from attestation and the entire reason the
     * ladder is ordered the way it is - HAS NEVER BEEN ASKED. Not once, in any release. We spent
     * three versions hardening the identity of a request that never left the handset.
     *
     * The 6.7.0 comment above ("app clients talk to youtubei.googleapis.com") is simply wrong, and
     * always was: `www.youtube.com/youtubei/v1/player` serves every client, app ones included, and
     * it is the host yt-dlp uses for all of them. So the app clients now go there FIRST, and
     * googleapis is kept only as a second chance for networks where it does resolve.
     */
    private fun hostsFor(client: StreamClient): List<String> = when (client.name) {
        "ANDROID_VR", "ANDROID_MUSIC", "IOS_MUSIC", "IOS" -> listOf(WWW, API)
        "TVHTML5_SIMPLY_EMBEDDED_PLAYER", "WEB_EMBEDDED_PLAYER", "MWEB" -> listOf(WWW)
        else -> listOf(MUSIC, WWW)
    }

    private fun hostFor(client: StreamClient): String = hostsFor(client).first()

    /** Just the host name, for the diagnostics report. */
    private fun hostLabel(client: StreamClient): String =
        hostFor(client).removePrefix("https://").substringBefore('/')

    private fun endpoint(
        client: StreamClient,
        path: String,
        extra: Map<String, String> = emptyMap(),
        host: String = hostFor(client)
    ): String {
        val builder = Uri.parse(host + "/" + path).buildUpon()
        // The `key` belongs to the web app and to nothing else. Sending it with an app client is
        // how a request gets answered politely and uselessly; Innertube has not required it for
        // app clients for a long time.
        if (client.name == "WEB_REMIX" && apiKey.isNotBlank()) {
            builder.appendQueryParameter("key", apiKey)
        }
        builder.appendQueryParameter("prettyPrint", "false")
        extra.forEach { (k, v) -> builder.appendQueryParameter(k, v) }
        return builder.build().toString()
    }

    /**
     * The `context.client` block, per client.
     *
     * Every field here is one the real client sends. Innertube does not validate most of them, but
     * the ones it does validate it validates silently: an ANDROID_VR context without
     * `androidSdkVersion`, or a TVHTML5 context without `clientScreen`, comes back as a perfectly
     * well formed response with no `streamingData` in it at all.
     */
    private fun context(client: StreamClient): JSONObject {
        val clientJson = JSONObject()
            .put("hl", hl)
            .put("gl", gl)
            .put("clientName", client.name)
            .put("clientVersion", client.version)
        // 6.9.3: web family only - see [isWebFamily].
        if (isWebFamily(client)) visitorId?.let { clientJson.put("visitorData", it) }
        when (client.name) {
            "ANDROID_VR" -> clientJson
                .put("deviceMake", "Oculus")
                .put("deviceModel", "Quest 3")
                .put("androidSdkVersion", 32)
                .put("osName", "Android")
                .put("osVersion", "12L")
            "ANDROID_MUSIC" -> clientJson
                .put("androidSdkVersion", 34)
                .put("osName", "Android")
                .put("osVersion", "14")
            "IOS_MUSIC" -> clientJson
                .put("deviceMake", "Apple")
                .put("deviceModel", "iPhone16,2")
                .put("osName", "iOS")
                .put("osVersion", "17.5.1.21F90")
            "IOS" -> clientJson
                .put("deviceMake", "Apple")
                .put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone")
                .put("osVersion", "18.3.2.22D82")
            "MWEB" -> clientJson
                .put("platform", "MOBILE")
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER", "WEB_EMBEDDED_PLAYER" -> clientJson
                .put("clientScreen", "EMBED")
        }
        val context = JSONObject().put("client", clientJson)
        if (client.name == "TVHTML5_SIMPLY_EMBEDDED_PLAYER" ||
            client.name == "WEB_EMBEDDED_PLAYER" ||
            client.name == "WEB_REMIX"
        ) {
            // The embedded player refuses to resolve anything without knowing which page it is
            // supposedly embedded in.
            context.put(
                "thirdParty",
                JSONObject().put("embedUrl", "https://www.youtube.com/")
            )
        }
        return context
    }

    private fun headers(client: StreamClient): Map<String, String> = buildMap {
        put("X-Goog-Api-Format-Version", "1")
        put("Accept-Language", "$hl-$gl")
        // The UA has to match the client on the API call too, not just on the media fetch.
        put("User-Agent", client.ua)
        // Header identity must agree with the context identity - see [CLIENT_IDS].
        CLIENT_IDS[client.name]?.let { put("X-Youtube-Client-Name", it) }
        put("X-Youtube-Client-Version", client.version)
        // The session, where the server looks for it first - web family only (6.9.3).
        if (isWebFamily(client)) visitorId?.let { put("X-Goog-Visitor-Id", it) }
        when (client.name) {
            "WEB_REMIX" -> {
                put("Origin", "https://music.youtube.com")
                put("Referer", "https://music.youtube.com/")
            }
            "WEB_EMBEDDED_PLAYER", "MWEB", "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> {
                put("Origin", "https://www.youtube.com")
                put("Referer", "https://www.youtube.com/")
            }
        }
    }

    /**
     * Gets a session identity, once, and keeps it.
     *
     * Deliberately best-effort: if the call fails the catalogue carries on exactly as 6.8.0 did
     * rather than refusing to work. A missing visitor is a lower chance of being served, not a
     * broken app.
     */
    private suspend fun ensureVisitor() {
        val now = System.currentTimeMillis()
        if (visitorId != null && now - visitorAtMs < VISITOR_TTL_MS) return
        val fresh = try {
            ZiziHttp.postJson(
                endpoint(web, "visitor_id"),
                JSONObject().put("context", context(web)),
                headers(web)
            ).str("responseContext", "visitorData")
        } catch (e: CatalogException) {
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            null
        }
        if (fresh != null) {
            visitorId = fresh
            visitorAtMs = now
        }
    }

    /**
     * Every Innertube answer carries the visitor it wants us to use next. Free to pick up, so it is
     * picked up - this is how the identity survives without a dedicated call at all on most runs.
     */
    private fun harvestVisitor(response: JSONObject) {
        val fresh = response.str("responseContext", "visitorData") ?: return
        if (visitorId == null) {
            visitorId = fresh
            visitorAtMs = System.currentTimeMillis()
        }
    }

    /**
     * The player request body.
     *
     * `playbackContext` is only sent to the browser-shaped clients: the app clients do not send it,
     * and a field a real client would not send is one more difference for the bot check to notice.
     */
    private fun playerBody(client: StreamClient, remoteId: String, poToken: String?): JSONObject {
        val body = JSONObject()
            .put("context", context(client))
            .put("videoId", remoteId)
            .put("contentCheckOk", true)
            .put("racyCheckOk", true)
        /*
         * THE FIELD THAT ALL EIGHT CLIENTS WERE REFUSING US FOR (6.9.0).
         *
         * `serviceIntegrityDimensions.poToken` is where the attestation goes, and it is the same
         * field for every client - app, embedded and web alike. The token is minted by
         * [PoTokenMinter] against the very visitorData this body's context carries, because the
         * server checks that binding: a token minted for a different session is worth exactly as
         * much as no token, which is what "Войдите, чтобы подтвердить, что вы не бот" was telling
         * us eight times in a row.
         *
         * It stays optional. No token means the request goes out exactly as 6.8.1 sent it - which
         * is a request that fails today, but a working app that fails is still better than a WebView
         * problem turning into a crash.
         */
        // 6.9.3: a web-minted token presented by an app client is worse than no token at all.
        if (poToken != null && isWebFamily(client)) {
            body.put("serviceIntegrityDimensions", JSONObject().put("poToken", poToken))
        }
        if (client.name == "TVHTML5_SIMPLY_EMBEDDED_PLAYER" ||
            client.name == "WEB_EMBEDDED_PLAYER" ||
            client.name == "MWEB" ||
            client.name == "WEB_REMIX"
        ) {
            body.put(
                "playbackContext",
                JSONObject().put(
                    "contentPlaybackContext",
                    JSONObject()
                        .put("html5Preference", "HTML5_PREF_WANTS")
                        .put("referer", "https://www.youtube.com/watch?v=" + remoteId)
                )
            )
        }
        return body
    }

    /**
     * One player request, walking the host ladder (6.9.4).
     *
     * A host that does not resolve is not an offline phone and it is not a verdict about the
     * client - it is one dead address out of two. Only when every address for this client is dead
     * does the OFFLINE reason survive and get reported.
     *
     * Returns the parsed response together with the host that actually answered, because "which
     * host" turned out to be the single fact worth printing in the report.
     */
    private suspend fun playerCall(
        client: StreamClient,
        remoteId: String,
        poToken: String?
    ): Pair<JSONObject, String> {
        var last: CatalogException? = null
        for (host in hostsFor(client)) {
            try {
                val response = ZiziHttp.postJson(
                    endpoint(client, "player", emptyMap(), host),
                    playerBody(client, remoteId, poToken),
                    headers(client)
                )
                return response to host.removePrefix("https://").substringBefore('/')
            } catch (e: CatalogException) {
                last = e
                // Anything that is not a dead address is this host's real answer: stop.
                if (e.reason != CatalogException.Reason.OFFLINE) throw e
            }
        }
        throw last ?: CatalogException(CatalogException.Reason.OFFLINE, "Нет адреса")
    }

    /** The client used for browsing and searching. Never used for streams - see [STREAM_CLIENTS]. */
    private val web = StreamClient("WEB_REMIX", "1.20241028.01.00", ZiziHttp.USER_AGENT)

    // ---------------------------------------------------------------- search

    // The key is optional now (see [endpoint]), so the catalogue is usable without one.
    override suspend fun isUsable(): Boolean = true

    /**
     * One page of results - and, since 6.8.0, a page token that can mean two different things.
     *
     * Innertube pages a search in two incompatible ways and 6.7.0 only knew about one of them:
     *
     *  - a `continuationCommand` token, which walks further down the SAME shelf;
     *  - a shelf's own `bottomEndpoint` params ("Показать все"), which is the only way into the
     *    DEEP shelves - the ones behind "Треки", "Видео", "Альбомы" on an unfiltered search. An
     *    unfiltered response carries the first five rows of each shelf and a button, and nothing
     *    else; there is no continuation to follow, which is exactly why "треков мало".
     *
     * So the token is tagged: `c:` is a continuation, `p:` is a filter blob for a deeper request.
     * The screen still treats it as opaque - see [SearchPage.nextToken].
     */
    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        if (query.isBlank()) return SearchPage.EMPTY

        val deeperParams = if (pageToken != null && pageToken.startsWith("p:")) pageToken.substring(2) else null
        val continuation = when {
            pageToken == null -> null
            pageToken.startsWith("p:") -> null
            pageToken.startsWith("c:") -> pageToken.substring(2)
            // Tokens minted by 6.7.0 and stored in a live UI state carry no prefix.
            else -> pageToken
        }

        val activeParams = deeperParams ?: filterFor(kind)
        val body = JSONObject()
            .put("context", context(web))
            .put("query", query)
        activeParams?.let { body.put("params", it) }
        continuation?.let { body.put("continuation", it) }

        val extra = if (continuation == null) emptyMap() else mapOf("continuation" to continuation, "type" to "next")
        val response = ZiziHttp.postJson(endpoint(web, "search", extra), body, headers(web))
        // Free session identity: the search that found the track hands us the visitor the player
        // request will be judged by.
        harvestVisitor(response)

        // A 200 with neither of these keys means the response shape moved, not that nothing matched.
        if (!response.has("contents") && !response.has("continuationContents") && !response.has("onResponseReceivedActions")) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "YouTube Music ответил в неизвестном формате")
        }

        // The top result lives in its own renderer and was silently dropped before: the single most
        // relevant row of the whole response was the one row the parser could not see.
        val items = (parseCardShelf(response) + parseListItems(response)).distinctBy { item ->
            when (item) {
                is RemoteItem.Song -> item.track.trackId
                is RemoteItem.Group -> item.collection.kind.name + ":" + item.collection.remoteId
            }
        }
        val next = continuationToken(response)?.let { "c:" + it }
            ?: deeperShelfParams(response, activeParams)?.let { "p:" + it }
        return SearchPage(items, next)
    }

    /** Both spellings of a continuation token. The second one still appears on browse responses. */
    private fun continuationToken(response: JSONObject): String? =
        response.deepFind("continuationCommand", limit = 8).firstNotNullOfOrNull { it.str("token") }
            ?: response.deepFind("nextContinuationData", limit = 8).firstNotNullOfOrNull { it.str("continuation") }

    /**
     * The "Показать все" filter blob of the first shelf that offers one.
     *
     * [current] is excluded so a filtered search cannot hand back its own filter and page in place
     * forever - which would look exactly like a list that refuses to grow.
     */
    private fun deeperShelfParams(response: JSONObject, current: String?): String? {
        val shelves = response.deepFind("musicShelfRenderer", limit = 12) +
            response.deepFind("musicCarouselShelfRenderer", limit = 12)
        for (shelf in shelves) {
            val params = shelf.str("bottomEndpoint", "searchEndpoint", "params")
                ?: shelf.node("moreContentButton")?.deepFind("searchEndpoint", limit = 4)
                    ?.firstNotNullOfOrNull { it.str("params") }
                ?: shelf.node("header")?.deepFind("searchEndpoint", limit = 4)
                    ?.firstNotNullOfOrNull { it.str("params") }
            if (params != null && params != current) return params
        }
        return null
    }

    /** The big "top result" card at the head of an unfiltered search. */
    private fun parseCardShelf(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicCardShelfRenderer", limit = 4).mapNotNull { card ->
            val title = card.runs("title") ?: return@mapNotNull null
            val subtitle = card.runs("subtitle").orEmpty()
            val artwork = card.node("thumbnail")?.bestThumbnail() ?: card.bestThumbnail()
            val videoId = card.deepString("videoId")
            if (videoId != null) {
                RemoteItem.Song(
                    RemoteTrack(
                        provider = id,
                        remoteId = videoId,
                        title = title,
                        artist = cleanArtist(subtitle),
                        artworkUrl = artwork
                    )
                )
            } else {
                val browseId = card.deepString("browseId") ?: return@mapNotNull null
                val playlistId = card.deepString("playlistId")
                val kind = when {
                    browseId.startsWith("UC") || browseId.startsWith("MPLA") -> RemoteKind.ARTIST
                    browseId.startsWith("MPRE") -> RemoteKind.ALBUM
                    playlistId != null || browseId.startsWith("VL") -> RemoteKind.PLAYLIST
                    else -> return@mapNotNull null
                }
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                        kind = kind,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artwork
                    )
                )
            }
        }

    private fun filterFor(kind: RemoteKind?): String? = when (kind) {
        RemoteKind.TRACK -> FILTER_SONGS
        RemoteKind.ALBUM -> FILTER_ALBUMS
        RemoteKind.PLAYLIST -> FILTER_PLAYLISTS
        RemoteKind.ARTIST -> FILTER_ARTISTS
        null -> null
    }

    override suspend fun suggest(prefix: String): List<String> {
        if (prefix.isBlank()) return emptyList()
        val body = JSONObject().put("context", context(web)).put("input", prefix)
        val response = runCatching {
            ZiziHttp.postJson(endpoint(web, "music/get_search_suggestions"), body, headers(web))
        }.getOrNull() ?: return emptyList()
        return response.deepFind("searchSuggestionRenderer", limit = 12)
            .mapNotNull { it.runs("suggestion") }
            .distinct()
    }

    override suspend fun discover(): List<DiscoverShelf> {
        val body = JSONObject()
            .put("context", context(web))
            .put("browseId", "FEmusic_explore")
        val response = ZiziHttp.postJson(endpoint(web, "browse"), body, headers(web))
        harvestVisitor(response)
        val shelves = response.deepFind("musicCarouselShelfRenderer", limit = 12).mapNotNull { shelf ->
            val title = shelf.node("header")?.runs("musicCarouselShelfBasicHeaderRenderer", "title")
                ?: shelf.runs("header", "musicCarouselShelfBasicHeaderRenderer", "title")
                ?: return@mapNotNull null
            val items = parseTwoRowItems(shelf) + parseListItems(shelf)
            if (items.isEmpty()) null else DiscoverShelf(title, items)
        }
        if (shelves.isEmpty()) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "Не удалось разобрать подборки YouTube Music")
        }
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val browseId = when (collection.kind) {
            // A playlist id becomes a browse id by prefixing VL; album and artist ids already are one.
            RemoteKind.PLAYLIST ->
                if (collection.remoteId.startsWith("VL")) collection.remoteId else "VL${collection.remoteId}"
            else -> collection.remoteId
        }
        val body = JSONObject().put("context", context(web)).put("browseId", browseId)
        var response = ZiziHttp.postJson(endpoint(web, "browse"), body, headers(web))
        harvestVisitor(response)

        // A browse response holds the first ~100 rows and a continuation. 6.7.0 read page one and
        // stopped, so a 300 track playlist opened as a 100 track playlist with no hint that the
        // rest existed. Five pages is a deliberate ceiling: it covers every real album and playlist
        // while keeping a pathological "все треки мира" list from paging forever on mobile data.
        val out = ArrayList<RemoteTrack>()
        var page = 0
        while (true) {
            out.addAll(parseListItems(response).filterIsInstance<RemoteItem.Song>().map { it.track })
            page++
            val token = continuationToken(response)?.takeIf { page < 5 } ?: break
            val nextBody = JSONObject().put("context", context(web)).put("continuation", token)
            response = try {
                ZiziHttp.postJson(
                    endpoint(web, "browse", mapOf("continuation" to token, "type" to "next")),
                    nextBody,
                    headers(web)
                )
            } catch (e: CatalogException) {
                // Whatever we already have is worth more than an exception.
                break
            }
        }
        return out.distinctBy { it.remoteId }
    }

    // ---------------------------------------------------------------- parsing

    /**
     * Rows, from anywhere in the payload.
     *
     * `musicResponsiveListItemRenderer` is asked for by name across the whole tree rather than
     * quoted through a nine-level path, because the path is what changes when YouTube reshuffles
     * its layout - the renderer name is what stays. Breadth first, so screen order is preserved.
     */
    private fun parseListItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicResponsiveListItemRenderer").mapNotNull { parseRow(it) }

    private fun parseRow(row: JSONObject): RemoteItem? {
        val texts = row.optJSONArray("flexColumns").items().mapNotNull {
            it.runs("musicResponsiveListItemFlexColumnRenderer", "text")
        }
        val title = texts.firstOrNull()?.takeIf { it.isNotBlank() } ?: return null
        val artwork = row.node("thumbnail")?.bestThumbnail()
        val explicit = row.deepString("iconType")?.contains("EXPLICIT") == true ||
            row.toString().contains("MUSIC_EXPLICIT_BADGE")

        val videoId = row.node("overlay")?.deepString("videoId")
            ?: row.node("playlistItemData")?.str("videoId")
            ?: row.deepString("videoId")

        if (videoId != null) {
            val duration = (texts + row.optJSONArray("fixedColumns").items().mapNotNull {
                it.runs("musicResponsiveListItemFixedColumnRenderer", "text")
            }).lastOrNull { DURATION.matches(it.trim()) }
            // Column layout differs per result type; the first non-title column that is not the
            // type label and not the duration is the artist.
            val artist = texts.drop(1).firstOrNull { !DURATION.matches(it.trim()) && it.isNotBlank() }
            return RemoteItem.Song(
                RemoteTrack(
                    provider = id,
                    remoteId = videoId,
                    title = title,
                    artist = cleanArtist(artist),
                    album = "",
                    durationMs = parseDuration(duration),
                    artworkUrl = artwork,
                    explicit = explicit
                )
            )
        }

        val browseId = row.deepString("browseId") ?: return null
        val playlistId = row.deepString("playlistId")
        val kind = when {
            browseId.startsWith("UC") || browseId.startsWith("MPLA") -> RemoteKind.ARTIST
            browseId.startsWith("MPRE") -> RemoteKind.ALBUM
            playlistId != null || browseId.startsWith("VL") -> RemoteKind.PLAYLIST
            else -> return null
        }
        return RemoteItem.Group(
            RemoteCollection(
                provider = id,
                remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                kind = kind,
                title = title,
                subtitle = texts.drop(1).joinToString(" • ").take(80),
                artworkUrl = artwork
            )
        )
    }

    /** Cards on the explore shelves use a different renderer than list rows. */
    private fun parseTwoRowItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicTwoRowItemRenderer", limit = 40).mapNotNull { card ->
            val title = card.runs("title") ?: return@mapNotNull null
            val subtitle = card.runs("subtitle").orEmpty()
            val artwork = card.node("thumbnailRenderer")?.bestThumbnail() ?: card.bestThumbnail()
            val videoId = card.deepString("videoId")
            if (videoId != null) {
                RemoteItem.Song(
                    RemoteTrack(
                        provider = id,
                        remoteId = videoId,
                        title = title,
                        artist = cleanArtist(subtitle),
                        artworkUrl = artwork
                    )
                )
            } else {
                val browseId = card.deepString("browseId") ?: return@mapNotNull null
                val playlistId = card.deepString("playlistId")
                val kind = when {
                    browseId.startsWith("UC") -> RemoteKind.ARTIST
                    browseId.startsWith("MPRE") -> RemoteKind.ALBUM
                    else -> RemoteKind.PLAYLIST
                }
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                        kind = kind,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artwork
                    )
                )
            }
        }

    private fun cleanArtist(raw: String?): String {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty()) return "Неизвестный исполнитель"
        // Subtitles arrive as "Трек • Артист • Альбом" or "Song • Artist"; the label is noise.
        val parts = value.split("•").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size <= 1) return value
        val label = setOf("song", "трек", "video", "видео", "single", "сингл", "album", "альбом", "playlist", "плейлист", "artist", "исполнитель")
        return parts.firstOrNull { it.lowercase() !in label && !it.endsWith("просмотров") } ?: parts.last()
    }

    private fun parseDuration(text: String?): Long {
        val value = text?.trim() ?: return 0L
        if (!DURATION.matches(value)) return 0L
        val parts = value.split(":").mapNotNull { it.toIntOrNull() }
        return when (parts.size) {
            2 -> (parts[0] * 60L + parts[1]) * 1000L
            3 -> (parts[0] * 3600L + parts[1] * 60L + parts[2]) * 1000L
            else -> 0L
        }
    }

    // ---------------------------------------------------------------- stream

    /**
     * Walks [STREAM_CLIENTS] until one returns a playable, unciphered audio format.
     *
     * The client matters and it is the whole trick: the web client returns URLs behind
     * `signatureCipher`, which has to be deobfuscated by running YouTube's own JavaScript. The
     * mobile music clients return the URL as-is. So we ask them first, and the web client is kept
     * last only to produce a meaningful error rather than a silent nothing.
     *
     * Failures are collected instead of swallowed: when this eventually breaks, the message says
     * which client refused and why, which is the difference between a five minute fix and an
     * evening.
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        /*
         * 6.10.0: OUR OWN SERVER IS ASKED FIRST, AND BEFORE ANY TOKEN IS MINTED.
         *
         * The 6.9.4 full diagnostics closed the client path for good: eight clients, both host
         * families, a valid poToken in hand - LOGIN_REQUIRED eight times out of eight, форматов 0.
         * The same track resolved from a VPS on the first try. So the question is asked from the
         * server now, and the ladder below stays only as a fallback for the case where the server
         * is down - it is not the main path any more.
         *
         * Placed above ensureVisitor()/sessionToken() deliberately: minting attestation the server
         * does not need cost nine seconds per track and bought nothing.
         */
        var resolverFailure: String? = null
        if (ZiziResolve.configured) {
            try {
                return ZiziResolve.resolve(remoteId, quality)
            } catch (e: CatalogException) {
                resolverFailure = "Резолвер @ " + ZiziResolve.hostLabel() + " → отказ " + e.reason + ": " + e.message
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                resolverFailure = "Резолвер @ " + ZiziResolve.hostLabel() + " → сбой " + e.javaClass.simpleName + ": " + e.message
            }
            /*
             * 6.10.1: A FINAL VERDICT ENDS THE ATTEMPT HERE.
             *
             * The server's live logs settled what "most tracks do not play" actually is: not a
             * bot-check but a geo refusal - every googlevideo URL carries gcr=ru and the track's
             * own allow-list reads "every country except Russia". No client, no token and no host
             * changes that. Running the eight-client ladder afterwards cost ~9 s of poToken
             * minting per track to arrive at the same "no", and that cost was paid on every track
             * in the queue. That was the delay the user felt.
             *
             * So: geo-blocked, removed, members-only -> stop, and say which one it was.
             */
            ZiziResolve.finalVerdict(remoteId)?.let { verdict ->
                throw CatalogException(CatalogException.Reason.UNAVAILABLE, "YouTube Music: $verdict")
            }
        }
        // One request per session at most, and it is what every client below sends as its identity.
        ensureVisitor()
        // And the proof that this session is a browser. Also at most once per session - and it is
        // deliberately fetched BEFORE the loop, so all eight clients present the same identity plus
        // the same attestation instead of racing eight WebView runs.
        val poToken = sessionToken()
        // Browser-shaped clients are judged on the URL by the videoId, not by the session: the web
        // player mints a second, content-bound token for exactly this. Free once the minter is
        // alive, null when it is not.
        val contentToken = if (poToken != null) PoTokenMinter.content(remoteId) else null
        var contentBlocked: String? = null
        val problems = ArrayList<String>(STREAM_CLIENTS.size + 1)
        // The server's refusal is the first line of the verdict, not a swallowed detail: when both
        // paths fail the person reading the error has to see which of the two broke.
        resolverFailure?.let { problems.add(it) }
        val now = System.currentTimeMillis()

        /*
         * Order: the client that worked last, then everyone who is not being rested, then the
         * rested ones as a last resort.
         *
         * sortedBy is stable, so inside each of those three groups the hand-picked order of
         * STREAM_CLIENTS is preserved - VR first, embedded TV second, and so on.
         */
        val ordered = STREAM_CLIENTS.sortedBy { candidate ->
            when {
                candidate.name == trusted -> -1
                (restedUntil[candidate.name] ?: 0L) > now -> 1
                else -> 0
            }
        }

        /*
         * 6.9.4: OFFLINE NO LONGER KILLS THE LADDER.
         *
         * Up to 6.9.3 the first client to report OFFLINE rethrew immediately, aborting the whole
         * loop. ANDROID_VR is first in that loop and youtubei.googleapis.com does not resolve on
         * every network - so on those networks ONE dead DNS name ended the resolve before the
         * seven remaining clients were asked, on every single track. That is the "нажимаешь и оно
         * просто листает дальше".
         *
         * A dead host is now counted, not thrown. The OFFLINE verdict is only reached if EVERY
         * client failed that way, which is the only case where the phone really is offline.
         */
        var offline = 0
        var asked = 0

        for (client in ordered) {
            asked++
            val answered = try {
                playerCall(client, remoteId, poToken)
            } catch (e: CatalogException) {
                if (e.reason == CatalogException.Reason.OFFLINE) offline++
                problems.add("${client.name}: ${e.message}")
                continue
            }
            val response = answered.first
            harvestVisitor(response)

            val status = response.str("playabilityStatus", "status")
            if (status != null && status != "OK") {
                val why = response.str("playabilityStatus", "reason")
                    ?: response.runs("playabilityStatus", "messages")
                    ?: status
                /**
                 * 6.6.0 gave up on the whole track here, for every client, on any of these three
                 * statuses. That was wrong for two of them and it is the reason a single grumpy
                 * client killed tracks that the next client in the list would have played:
                 *
                 *  - LOGIN_REQUIRED from an app client means "you did not attest", not "this track
                 *    is private". The embedded and VR clients are exactly the ones that answer the
                 *    same id without it, so this must fall through to them.
                 *  - ERROR is Innertube's catch-all, including for a context it did not like.
                 *  - UNPLAYABLE is the only one that really is about the video (age gate, region,
                 *    takedown), and even then it is only final once every client agrees.
                 *
                 * So nothing is fatal until the loop is exhausted, and the reason of the LAST
                 * client to complain about the content itself is what the user gets told.
                 */
                problems.add("${client.name}: $why")
                if (status == "UNPLAYABLE") contentBlocked = why
                continue
            }

            val picked = pickFormat(response.array("streamingData", "adaptiveFormats"), quality)
                ?: pickFormat(response.array("streamingData", "formats"), quality)
            if (picked == null) {
                // The single most useful diagnostic in this file: it distinguishes "no audio at
                // all" from "audio, but every URL was behind signatureCipher", which is the
                // signature of a client that needs the JS player deobfuscated.
                val ciphered = response.array("streamingData", "adaptiveFormats").items()
                    .count { it.str("signatureCipher") != null || it.str("cipher") != null }
                problems.add(
                    if (ciphered > 0) "${client.name}: $ciphered потоков зашифрованы"
                    else "${client.name}: нет аудиопотоков"
                )
                continue
            }
            /*
             * THE FIX FOR "ТРЕКИ САМИ СВАЙПАЮТСЯ".
             *
             * Up to 6.7.0 this line returned the first URL that parsed. Whether the CDN would
             * actually serve it was somebody else's problem - and when it would not (403, because
             * that client's attestation had caught up with it), the player saw a broken stream,
             * gave up, and auto-skipped. Four clients were sitting right there in the list, any of
             * which might have worked, and none of them were ever asked.
             *
             * So the URL is now proven before it leaves this function: two bytes, ranged, with the
             * agent it was minted for. A refusal rests that client for ten minutes and the loop
             * simply continues to the next one.
             *
             * The cost is one round trip, and only on the first track of a session: the client
             * that answers becomes [trusted] and is taken on faith afterwards. If playback later
             * dies on a trusted client, `distrust()` is called from the load error policy and the
             * next track pays for one probe again.
             */
            val proven = picked.copy(
                url = withPot(picked.url, potForUrl(client, poToken, contentToken)),
                client = client.name,
                userAgent = client.ua
            )
            if (client.name == trusted) {
                return proven
            }
            val cdn = ZiziHttp.statusOf(proven.url, client.ua)
            if (cdn == null || cdn < 200 || cdn >= 300) {
                restedUntil[client.name] = System.currentTimeMillis() + REST_MS
                problems.add("${client.name}: CDN ${cdn ?: "нет ответа"}")
                // A 403 on a URL we attested for is the one case where the token itself is the
                // suspect, so it is dropped and the next track mints a fresh one.
                if (cdn == 403 && poToken != null) PoTokenMinter.invalidate()
                continue
            }
            restedUntil.remove(client.name)
            trusted = client.name
            return proven
        }
        contentBlocked?.let { throw CatalogException(CatalogException.Reason.UNAVAILABLE, it) }
        if (offline == asked) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Нет соединения")
        }
        throw CatalogException(
            CatalogException.Reason.PROTOCOL,
            "YouTube Music не отдал поток. " + problems.joinToString("; ")
        )
    }

    /**
     * THE ROW THAT ENDS THE GUESSING (6.8.1).
     *
     * [resolveStream] returns one line: the reason the LAST client gave, truncated by whatever
     * shows it. That is how three different diseases - wrong host, bot check, SABR-only formats -
     * all reached the user as the same sentence, and how two releases were spent patching the wrong
     * one.
     *
     * This asks EVERY client, ignoring trust and rest, and reports what each one actually said:
     * the host it was asked on, the playability status with its verbatim reason, how many formats
     * came back, how many of them were audio, how many were behind a cipher, and - when a URL did
     * come out - what the CDN answered to two real bytes. Eight lines, and between them they name
     * the layer without a single assumption:
     *
     *   - `LOGIN_REQUIRED «Sign in to confirm...»` everywhere  -> bot check, poToken is the answer;
     *   - `OK · форматов 0`                                    -> SABR, formats are gone from the
     *                                                             response entirely, a different
     *                                                             and much bigger problem;
     *   - `OK · аудио N, шифр N`                               -> the JS player has to be run;
     *   - `OK ... · CDN HTTP 403`                              -> the URL is minted but not served;
     *   - `OK ... · CDN HTTP 206`                              -> the tract is alive and the fault
     *                                                             is below us, in the decoder.
     *
     * It is slow (up to eight round trips plus probes) and it is only ever called from settings.
     */
    override suspend fun streamReport(remoteId: String, quality: RemoteQuality): List<String> {
        // 6.10.0: the server is probed first and BEFORE the forced mint, so its line appears even
        // if the WebView hangs for ten seconds afterwards.
        val resolverLine = if (ZiziResolve.configured) {
            "Резолвер @ " + ZiziResolve.hostLabel() + " → " + ZiziResolve.report(remoteId, quality)
        } else {
            "Резолвер не настроен — поток берётся у YouTube напрямую (см. Настройки → Свой резолвер)"
        }
        ensureVisitor()
        // force = true: the report must mint NOW. The ten minute backoff protects playback from a
        // broken WebView; it must not answer a person who deliberately pressed the button with a
        // cached complaint from eight minutes ago (6.9.1).
        val poToken = sessionToken(force = true)
        val out = ArrayList<String>(STREAM_CLIENTS.size + 3)
        out.add("Диагностика потока")
        out.add("трек: " + remoteId + " · цель " + quality.targetKbps + " кбит/с")
        out.add("visitorData: " + (visitorId?.let { "есть, " + it.length + " симв." } ?: "НЕТ"))
        out.add("poToken: " + PoTokenMinter.diagnostics())
        out.add(resolverLine)
        for (client in STREAM_CLIENTS) {
            val line = StringBuilder().append(client.name).append(" @ ")
            val answered = try {
                playerCall(client, remoteId, poToken)
            } catch (e: CatalogException) {
                line.append(hostsFor(client).joinToString(",") { it.removePrefix("https://").substringBefore('/') })
                out.add(line.append(" → отказ ").append(e.reason).append(": ").append(e.message).toString())
                continue
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                line.append(hostLabel(client))
                out.add(line.append(" → сбой ").append(e.javaClass.simpleName).append(": ").append(e.message).toString())
                continue
            }
            val response = answered.first
            line.append(answered.second).append(" → ")
            harvestVisitor(response)
            val status = response.str("playabilityStatus", "status") ?: "без статуса"
            val reason = response.str("playabilityStatus", "reason")
                ?: response.runs("playabilityStatus", "messages")
            line.append(if (isWebFamily(client)) " [web-id]" else " [app-id]").append(" ").append(status)
            if (status != "OK" && reason != null) line.append(" «").append(reason).append("»")
            val adaptive = response.array("streamingData", "adaptiveFormats").items()
            val plain = response.array("streamingData", "formats").items()
            val audio = adaptive.count { it.str("mimeType").orEmpty().startsWith("audio/") }
            val ciphered = (adaptive + plain)
                .count { it.str("signatureCipher") != null || it.str("cipher") != null }
            line.append(" · форматов ").append(adaptive.size + plain.size)
                .append(" (аудио ").append(audio).append(", шифр ").append(ciphered).append(")")
            val picked = pickFormat(response.array("streamingData", "adaptiveFormats"), quality)
                ?: pickFormat(response.array("streamingData", "formats"), quality)
            if (picked == null) {
                out.add(line.append(" · ссылки нет").toString())
                continue
            }
            line.append(" · ").append(picked.bitrateKbps).append(" кбит/с ").append(picked.mimeType)
            line.append(" · CDN ").append(ZiziHttp.probeStream(withPot(picked.url, poToken), client.ua))
            out.add(line.toString())
        }
        return out
    }

    /**
     * The session attestation, or null (6.9.0).
     *
     * Bound to [visitorId], which is why [ensureVisitor] must have run first: the pair is checked
     * together, and a token minted for a visitor we are not presenting is not a token. Null is not
     * an error - it is 6.8.1 behaviour, and the diagnostics row says which step of the mint failed.
     */
    private suspend fun sessionToken(force: Boolean = false): String? {
        val visitor = visitorId ?: return null
        return try {
            PoTokenMinter.session(visitor, force)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * The CDN wants the token too, on the URL (6.9.0).
     *
     * `serviceIntegrityDimensions` gets a request *answered*; `pot=` gets the bytes *served*. They
     * are two separate checks at two separate layers, and 403-after-a-successful-resolve - the exact
     * failure 6.7.0 spent a release on - is what the missing second one looks like.
     *
     * Already-present parameters are left alone: some responses come back with `pot=` baked in, and
     * a URL with two of them is refused.
     */
    private fun potForUrl(client: StreamClient, session: String?, content: String?): String? =
        when (client.name) {
            "WEB_REMIX", "WEB_EMBEDDED_PLAYER", "MWEB" -> content ?: session
            // 6.9.3: app clients get no `pot=` either. Their URLs are not minted against the web
            // session, and a mismatched pot on a googlevideo URL is itself a 403.
            else -> null
        }

    private fun withPot(url: String, poToken: String?): String {
        if (poToken == null || poToken.isEmpty()) return url
        if (url.contains("&pot=") || url.contains("?pot=")) return url
        val separator = if (url.contains('?')) '&' else '?'
        return url + separator + "pot=" + Uri.encode(poToken)
    }

    /**
     * Pays for the session up front, off the playback path (6.9.0).
     *
     * Attestation costs one to three seconds. Paid on the first track, it is a first track that
     * takes three seconds to start; paid at launch, in the background, it is nothing at all. Called
     * from `ZiziApplication`, best-effort, and it never touches the UI.
     */
    override suspend fun prewarm() {
        ensureVisitor()
        sessionToken()
    }

    /**
     * Audio only, no cipher, closest to the requested bitrate.
     *
     * Chosen by measured bitrate rather than by a hardcoded itag list: itags get retired, and a
     * table of magic numbers is one more thing that silently rots. Ties go to m4a/AAC - it is
     * hardware decoded on everything this app runs on, Opus is not always.
     */
    private fun pickFormat(formats: JSONArray?, quality: RemoteQuality): StreamInfo? {
        val candidates = formats.items().filter { format ->
            val mime = format.str("mimeType").orEmpty()
            val url = format.str("url")
            mime.startsWith("audio/") &&
                url != null &&
                format.str("signatureCipher") == null &&
                format.str("cipher") == null
        }
        if (candidates.isEmpty()) return null
        val target = quality.targetKbps * 1000
        val best = candidates.minByOrNull { format ->
            val bitrate = (format.long("bitrate") ?: format.long("averageBitrate") ?: 0L).toInt()
            val distance = abs(bitrate - target)
            val penalty = if (format.str("mimeType").orEmpty().contains("mp4a")) 0 else 8_000
            distance + penalty
        } ?: return null

        val url = best.str("url") ?: return null
        val bitrate = ((best.long("bitrate") ?: 0L) / 1000).toInt()
        return StreamInfo(
            url = url,
            mimeType = best.str("mimeType")?.substringBefore(';') ?: "audio/mp4",
            bitrateKbps = if (bitrate > 0) bitrate else quality.targetKbps,
            ttlMs = ttlOf(url)
        )
    }

    /**
     * The URL carries its own deadline in `expire=<epoch seconds>`.
     *
     * A minute is shaved off it, because "valid until" and "still valid when the request arrives"
     * are not the same thing on a mobile connection. If the parameter is missing we assume a
     * conservative hour rather than trusting the link forever.
     */
    private fun ttlOf(url: String): Long {
        val expire = Regex("""[?&]expire=(\d+)""").find(url)?.groupValues?.getOrNull(1)?.toLongOrNull()
            ?: return 60 * 60 * 1000L
        val left = expire * 1000L - System.currentTimeMillis() - 60_000L
        return left.coerceIn(60_000L, 6 * 60 * 60 * 1000L)
    }
}
