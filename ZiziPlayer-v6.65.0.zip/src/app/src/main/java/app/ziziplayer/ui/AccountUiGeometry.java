package app.ziziplayer.ui;

/** Pure geometry shared by the profile/history chrome and tested without Android. */
public final class AccountUiGeometry {
    private AccountUiGeometry() {}
    public static final float DRAWER_FRACTION = 0.9f;
    public static final float TOP_SCRIM_ALPHA = 0.85f;
    public static float collapse(float scroll, float hero, float toolbar) {
        if (hero <= 0f || toolbar <= 0f) return 0f;
        float end = Math.max(toolbar, hero - toolbar);
        return CollectionGeometry.smoothstep((scroll - (end - toolbar)) / toolbar);
    }
    public static float historyCollapse(float scroll, float toolbar) {
        return toolbar <= 0f ? 0f : CollectionGeometry.smoothstep(scroll / toolbar);
    }
}
