package app.ziziplayer.ui;

import java.text.Normalizer;
import java.util.*;

/** Deterministic bounded heuristic, not a probability or collaborative filtering model. */
public final class HomeFeedPolicy {
    private HomeFeedPolicy() {}
    public static String normalize(String text) {
        return Normalizer.normalize(text == null ? "" : text, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT)
            .replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
    }
    public static double sessionWeight(boolean qualified, boolean completed, boolean earlySkip, double ageDays) {
        return ((qualified ? 2.0 : 0.0) + (completed ? 1.0 : 0.0) - (earlySkip ? 2.5 : 0.0))
            * Math.pow(0.5, Math.max(0.0, ageDays) / 14.0);
    }
    public static double score(boolean favorite, double evidence) {
        return (favorite ? 4.0 : 0.0) + Math.max(-6.0, Math.min(12.0, evidence));
    }
    public static double dailyTie(String id, long day) {
        return (Integer.toUnsignedLong((id + ":" + day).hashCode()) % 10000L) / 100000.0;
    }
    public static final class Candidate {
        public final String id, artist;
        public final double score;
        public Candidate(String id, String artist, double score) {
            this.id = id; this.artist = normalize(artist); this.score = score;
        }
    }
    /** Greedy artist penalty: adjacent repeat -8, previous appearances -2 each. */
    public static List<String> rank(List<Candidate> input, int limit) {
        LinkedHashMap<String, Candidate> unique = new LinkedHashMap<>();
        for (Candidate c : input) { if (unique.size() >= 300) break; unique.putIfAbsent(c.id, c); }
        List<Candidate> remaining = new ArrayList<>(unique.values());
        List<String> result = new ArrayList<>();
        Map<String, Integer> counts = new HashMap<>(); String previous = null;
        while (!remaining.isEmpty() && result.size() < Math.max(0, Math.min(limit, 100))) {
            Candidate best = null; double bestScore = -Double.MAX_VALUE;
            for (Candidate c : remaining) {
                double s = c.score - 2.0 * counts.getOrDefault(c.artist, 0)
                    - (c.artist.equals(previous) ? 8.0 : 0.0);
                if (best == null || s > bestScore || (s == bestScore && c.id.compareTo(best.id) < 0)) {
                    best = c; bestScore = s;
                }
            }
            remaining.remove(best); result.add(best.id); previous = best.artist;
            counts.put(best.artist, counts.getOrDefault(best.artist, 0) + 1);
        }
        return result;
    }
    // Reference 1080px: inset 46, card 432, gap 46; viewport contains 2.16 cards.
    public static float inset(float width) { return width * 46f / 1080f; }
    public static float card(float width) { return Math.min(240f, width * 0.4f); }
    public static float gap(float width) { return width * 46f / 1080f; }
}
