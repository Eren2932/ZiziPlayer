package app.ziziplayer.ui

import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.remote.*
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

internal enum class HomeShelfLayout { COVERS, TRACKS, ARTISTS }
internal data class HomeFeedCard(
    val id: String, val title: String, val subtitle: String,
    val tracks: List<TrackEntity> = emptyList(), val remote: RemoteCollection? = null
) {
    val cover: TrackEntity? get() = tracks.firstOrNull()
}
internal data class HomeFeedShelf(val id: String, val title: String, val subtitle: String,
    val layout: HomeShelfLayout, val cards: List<HomeFeedCard>, val seed: TrackEntity? = null)
internal data class HomeFeedState(
    val shelves: List<HomeFeedShelf> = emptyList(), val wave: List<TrackEntity> = emptyList(),
    val loading: Boolean = false, val error: String? = null,
    val folders: Set<String> = emptySet(), val hidden: Set<String> = emptySet(), val loadedAt: Long = 0L
)

/** No new HTTP client, audio resolver, listener or timer. One metadata request at a time.
 * A snapshot lives only in this ViewModel, never in an unencrypted personalized disk cache. */
internal class HomeRecommendations(private val app: ZiziApplication, private val scope: CoroutineScope,
    private val hidden: StateFlow<Set<String>?>) {
    private val _state = MutableStateFlow(HomeFeedState())
    val state = _state.asStateFlow()
    private var job: Job? = null
    private var retry: Job? = null
    private var attempt = 0
    private var lastAttempt = 0L
    private var generation = 0

    fun clear() {
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        attempt = 0; lastAttempt = 0L
        _state.value = HomeFeedState()
    }
    fun cancel() {
        val interrupted = job?.isActive == true
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        if (interrupted) lastAttempt = 0L
        _state.value = _state.value.copy(loading = false, loadedAt = if (interrupted) 0L else _state.value.loadedAt)
    }
    private fun safe(snapshot: HomeState) = snapshot.vaultFolders == app.repository.vault.state.value.folders &&
        snapshot.hiddenIds == hidden.value

    fun load(snapshot: HomeState, force: Boolean = false) {
        if (snapshot.loading || !safe(snapshot)) return
        if (_state.value.folders != snapshot.vaultFolders || _state.value.hidden != snapshot.hiddenIds) clear()
        if (job?.isActive == true) return
        val now = System.currentTimeMillis()
        // Одна арифметика на всё: срок свежести, минимальный интервал и бюджет автоповторов.
        if (!HomeFeedRefreshPolicy.shouldLoad(now, _state.value.loadedAt, lastAttempt, force)) return
        retry?.cancel(); retry = null
        lastAttempt = now
        val epoch = ++generation
        _state.value = _state.value.copy(loading = true, error = null,
            folders = snapshot.vaultFolders, hidden = snapshot.hiddenIds)
        job = scope.launch {
            try {
                val favorites = app.database.musicDao().observeFavoriteIds().first().toSet()
                val known = snapshot.tracks.associateBy { it.id }
                val sessions = app.database.listeningDao().recommendationSnapshot().filter { row ->
                    row.trackId in known && row.trackId !in snapshot.hiddenIds &&
                        (row.source != "local" || row.sourceFolder !in snapshot.vaultFolders)
                }
                val builder = withContext(Dispatchers.Default) { FeedBuilder(snapshot, favorites, sessions, now) }
                suspend fun publish(error: String? = null) {
                    val built = withContext(Dispatchers.Default) { builder.build() }
                    if (epoch == generation && safe(snapshot)) _state.value = built.copy(
                        loading = true, error = error, folders = snapshot.vaultFolders,
                        hidden = snapshot.hiddenIds, loadedAt = now)
                }
                publish()
                // The server-backed metadata catalog respects the user's existing resolver config.
                // Do not silently enable direct YouTube / Google access for a Home visit.
                val catalog = RemoteRuntime.registry.byId("dz")
                var failure: String? = null
                var stopNetwork = false
                suspend fun request(block: suspend () -> Unit) {
                    if (stopNetwork) return
                    try {
                        val done = withTimeoutOrNull(8_000L) {
                            // Observe existing playback state; no extra player listener or polling.
                            app.playerController.state.first { !it.isLoadingAudio }
                            block(); true
                        }
                        if (done == null) { failure = "Каталог не успел ответить. Локальные подборки доступны"; stopNetwork = true }
                    } catch (e: CancellationException) { throw e }
                    catch (e: Exception) {
                        failure = if (e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED)
                            "Каталог просит паузу, подборки вернутся сами" else "Каталог недоступен. Локальные подборки сохранены"
                        stopNetwork = true // no retry storm when the first request fails
                    }
                }
                val complete = withTimeoutOrNull(45_000L) {
                    if (catalog == null) failure = "Каталог не настроен"
                    else {
                        request { builder.discover = HubContent.normalize(catalog.discover()); publish() }
                        // Maximum seven logical calls per refresh: chart + 3 artists × (tracks + albums).
                        for (artist in builder.seeds.take(3)) {
                            request {
                                val songs = catalog.search(artist, RemoteKind.TRACK, null).items
                                    .filterIsInstance<RemoteItem.Song>().map { it.track }
                                    .filter { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) }
                                builder.artistTracks[artist] = songs.take(30); publish()
                            }
                            request {
                                builder.albums[artist] = catalog.search(artist, RemoteKind.ALBUM, null).items
                                    .filterIsInstance<RemoteItem.Group>().map { it.collection }
                                    .filter { it.kind == RemoteKind.ALBUM }.take(10)
                                publish()
                            }
                        }
                    }
                    true
                }
                if (complete == null) failure = "Обновление остановлено по тайм-ауту. Полученные подборки сохранены"
                publish(failure)
                if (failure != null && epoch == generation) {
                    _state.value = _state.value.copy(loadedAt = 0L)
                    scheduleRetry(snapshot, epoch)
                } else if (failure == null) attempt = 0
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                if (epoch == generation) {
                    _state.value = _state.value.copy(error = "Подборки соберутся сами, как только появится связь")
                    scheduleRetry(snapshot, epoch)
                }
            } finally {
                if (epoch == generation) _state.value = _state.value.copy(loading = false)
            }
        }
    }

    /**
     * Неудача не требует действий пользователя: 15 c, 45 c, 135 c — и тишина.
     * Это не таймер обновления и не фоновая служба: корутина живёт в скоупе экрана,
     * уходит вместе с ним (cancel/clear) и имеет жёсткий бюджет попыток.
     */
    private fun scheduleRetry(snapshot: HomeState, epoch: Int) {
        if (epoch != generation || !HomeFeedRefreshPolicy.canRetry(attempt + 1)) return
        attempt += 1
        val wait = HomeFeedRefreshPolicy.retryDelayMs(attempt)
        retry?.cancel()
        retry = scope.launch {
            // Запас к паузе: минимальный интервал попыток считается по стенным часам.
            delay(wait + 250L)
            if (epoch == generation) load(snapshot, force = true)
        }
    }
}

/** All scoring and shelf assembly happens on Default, not on a playback tick. */
private class FeedBuilder(private val source: HomeState, favorites: Set<String>,
    sessions: List<ListeningSessionEntity>, private val now: Long) {
    private val known = source.tracks.associateBy { it.id }
    private val evidence = sessions.groupBy { it.trackId }.mapValues { (_, rows) -> rows.sumOf {
        HomeFeedPolicy.sessionWeight(it.qualified, it.completed, it.outcome == "skipped" && it.listenedMs < 10_000L,
            (now - it.startedAt).coerceAtLeast(0L) / 86_400_000.0)
    } }
    private val scores = source.tracks.associate { it.id to HomeFeedPolicy.score(it.id in favorites, evidence[it.id] ?: 0.0) }
    private val artistScores = source.tracks.groupBy { HomeFeedPolicy.normalize(it.artist) }
        .mapValues { (_, tracks) -> tracks.sumOf { scores[it.id] ?: 0.0 } }
    val seeds = source.tracks.filter { it.artist.isNotBlank() && (scores[it.id] ?: 0.0) > 0.0 }
        .distinctBy { HomeFeedPolicy.normalize(it.artist) }
        .sortedWith(compareByDescending<TrackEntity> { artistScores[HomeFeedPolicy.normalize(it.artist)] ?: 0.0 }.thenBy { it.id })
        .map { it.artist }.take(3)
    var discover: List<DiscoverShelf> = emptyList()
    val artistTracks = linkedMapOf<String, List<RemoteTrack>>()
    val albums = linkedMapOf<String, List<RemoteCollection>>()
    private val recentIds = sessions.sortedByDescending { it.startedAt }.map { it.trackId }.distinct().take(12)
    private val favoriteTracks = source.tracks.filter { it.id in favorites }
    private fun canonical(t: TrackEntity): String = if (t.provider == "mix") "r:${t.remoteId}" else t.id
    private val knownCanonical = known.values.mapTo(HashSet(), ::canonical)
    private val hiddenCanonical = source.hiddenIds.mapTo(HashSet()) { if (it.startsWith("r:mix:")) "r:" + it.removePrefix("r:mix:") else it }
    private fun unique(tracks: List<TrackEntity>): List<TrackEntity> {
        val result = ArrayList<TrackEntity>(); val ids = HashSet<String>()
        val metadata = HashMap<String, MutableList<Long>>()
        for (t in tracks.take(600)) {
            if (t.title.isBlank() || t.id in source.hiddenIds || canonical(t) in hiddenCanonical ||
                (t.isRemote && !CatalogPolicy.supports(t.provider, t.remoteId))) continue
            val key = HomeFeedPolicy.normalize(t.artist) + "|" + HomeFeedPolicy.normalize(t.title)
            val durations = metadata.getOrPut(key) { mutableListOf() }
            if (!ids.add(canonical(t)) || (t.durationMs > 0L && durations.any { it > 0L && kotlin.math.abs(it - t.durationMs) <= 2000L })) continue
            durations += t.durationMs; result += t
            if (result.size >= 300) break
        }
        return result
    }
    private fun rank(tracks: List<TrackEntity>, limit: Int, novel: Boolean = false): List<TrackEntity> {
        fun value(t: TrackEntity): Double {
            val affinity = artistScores[HomeFeedPolicy.normalize(t.artist)]?.coerceIn(-4.0, 8.0) ?: 0.0
            return (scores[t.id] ?: 0.0) + affinity * 0.35 +
                (if (novel && canonical(t) !in knownCanonical) 3.0 else 0.0) -
                (if (t.id in recentIds) 2.0 else 0.0) + HomeFeedPolicy.dailyTie(t.id, now / 86_400_000L)
        }
        // Bound after scoring, not after alphabetical database order: a large library
        // must not permanently starve favourites whose titles start near the end.
        val values = tracks.associate { it.id to value(it) }
        val list = unique(tracks.sortedWith(compareByDescending<TrackEntity> { values[it.id] ?: 0.0 }.thenBy { it.id }))
        val byId = list.associateBy { it.id }
        return HomeFeedPolicy.rank(list.map { HomeFeedPolicy.Candidate(it.id, it.artist, values[it.id] ?: 0.0) }, limit)
            .mapNotNull(byId::get)
    }
    fun build(): HomeFeedState {
        val out = mutableListOf<HomeFeedShelf>()
        val exposures = HashMap<String, Int>()
        val shownGroups = HashSet<String>()
        val remote = unique(artistTracks.values.flatten().map { it.toEntity(now) })
        val chart = unique(discover.flatMap { it.items }.filterIsInstance<RemoteItem.Song>().map { it.track.toEntity(now) })
        val catalog = discover.flatMap { it.items }.filterIsInstance<RemoteItem.Group>().map { it.collection }
            .filter { CatalogPolicy.supports(it.provider, it.remoteId) }.distinctBy { "${it.provider}:${it.remoteId}" }
        fun songs(id: String, title: String, detail: String, tracks: List<TrackEntity>, layout: HomeShelfLayout = HomeShelfLayout.COVERS, seed: TrackEntity? = null) {
            val visible = unique(tracks).filter { (exposures[canonical(it)] ?: 0) < 2 }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                val key = canonical(it); exposures[key] = (exposures[key] ?: 0) + 1
                HomeFeedCard(it.id, it.title, it.artist, listOf(it))
            }, seed)
        }
        fun groups(id: String, title: String, detail: String, groups: List<RemoteCollection>, layout: HomeShelfLayout = HomeShelfLayout.COVERS) {
            val visible = groups.filter { shownGroups.add("${it.provider}:${it.remoteId}") }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                HomeFeedCard("${it.provider}:${it.remoteId}", it.title, it.subtitle, remote = it)
            })
        }
        val wave = rank(source.tracks.filter { it.id in source.availableOfflineIds }, 50)
        val mixes = seeds.mapNotNull { artist ->
            val tracks = rank(source.tracks.filter { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) } +
                artistTracks[artist].orEmpty().map { it.toEntity(now) }, 40)
            if (tracks.isEmpty()) null else HomeFeedCard("mix:${HomeFeedPolicy.normalize(artist)}", "$artist: микс",
                "${tracks.size} треков · по твоим прослушиваниям и избранному", tracks)
        }.toMutableList()
        if (favoriteTracks.isNotEmpty()) mixes += HomeFeedCard("favorites-mix", "Любимое вперемешку", "Из твоего избранного", rank(favoriteTracks, 40))
        mixes.forEach { it.cover?.let { track -> exposures[canonical(track)] = 1 } }
        if (mixes.isNotEmpty()) out += HomeFeedShelf("mixes", "Твои миксы", "На основе избранного и зачтённых прослушиваний", HomeShelfLayout.COVERS, mixes)
        songs("today", "Послушай сегодня", if (remote.isEmpty()) "Из твоей музыки" else "Знакомые исполнители и твоя музыка",
            rank(remote + source.tracks, 12, novel = true))
        groups("catalog-playlists", "Подборки каталога", "Редакционные подборки · не персональный рейтинг", catalog.filter { it.kind == RemoteKind.PLAYLIST })
        songs("continue-listening", "Слушаем дальше?", "Недавние прослушивания", recentIds.mapNotNull(known::get))
        for ((artist, tracks) in artistTracks) songs("artist:$artist", "Ещё от $artist", "Найдено в каталоге по исполнителю",
            rank(tracks.map { it.toEntity(now) }, 12, novel = true), seed = source.tracks.firstOrNull { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) })
        songs("new-to-you", "Незнакомое у знакомых", "Треки исполнителей из твоих предпочтений, которых нет в медиатеке",
            rank(remote.filter { canonical(it) !in knownCanonical }, 12, novel = true))
        for ((artist, albumGroups) in albums) groups("albums:$artist", "Альбомы: $artist", "Результаты каталога по запросу исполнителя", albumGroups)
        songs("chart", "Сейчас слушают", "Общий чарт каталога · не твой персональный топ", chart.take(12), HomeShelfLayout.TRACKS)
        val artists = mixes.filter { it.id.startsWith("mix:") }.map { it.copy(title = it.title.removeSuffix(": микс"), subtitle = "Твоя подборка") }
        if (artists.isNotEmpty()) out += HomeFeedShelf("your-artists", "Твои любимые исполнители", "По избранному и истории", HomeShelfLayout.ARTISTS, artists)
        groups("catalog-artists", "Исполнители в каталоге", "Популярные сейчас", catalog.filter { it.kind == RemoteKind.ARTIST }, HomeShelfLayout.ARTISTS)
        songs("offline", "Всегда с тобой", "Доступно без интернета", wave.take(12))
        return HomeFeedState(out.take(18), wave)
    }
}
