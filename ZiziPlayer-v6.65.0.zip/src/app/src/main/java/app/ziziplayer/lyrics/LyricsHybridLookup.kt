package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/** Provider boundaries: a null result is an actual miss, an exception is NOT a miss. */
internal interface LyricsProvider {
    val id: String
    val budgetMs: Long
    val requestLimit: Int get() = 1
    val requestTimeoutMs: Long get() = 7_000L
    suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
        trace: LyricsLookupTrace?): JSONObject?
}

/**
 * Bounded fallback with opt-in progressive plain → synchronized upgrades.
 *
 * [parallelCount] providers run simultaneously; a synchronized result from any of them
 * immediately cancels the remaining parallel tasks. This eliminates the "server delays
 * LRCLIB" regression: when server is configured both start at t=0 and the first to return
 * a synchronized result wins. Remaining providers after the parallel group run sequentially
 * and may upgrade a plain result to a synchronized one.
 *
 * Cancellation and audio gates apply equally to all sources; parent deadlines must never
 * be converted to successful results.
 */
internal class LyricsHybridLookup(
    private val providers: List<LyricsProvider>,
    private val clockMs: () -> Long,
    private val upgradePlain: Boolean = false,
    private val parallelCount: Int = 1
) {
    private val lock = Mutex()
    private val backoffUntil = mutableMapOf<String, Long>()
    private data class Completed(val payload: JSONObject?)

    init {
        require(providers.isNotEmpty() && providers.map { it.id }.distinct().size == providers.size)
        require(parallelCount in 1..providers.size)
        require(providers.all {
            it.budgetMs > 0 && it.requestTimeoutMs in 1L..7_000L && it.requestLimit in 1..3
        })
        // Effective wall-time upper bound: parallel group contributes max(budgets), not sum.
        val effectiveBudget = providers.take(parallelCount).maxOf { it.budgetMs } +
            providers.drop(parallelCount).sumOf { it.budgetMs }
        require(effectiveBudget <= 34_000L)
    }

    private fun rank(p: JSONObject): Int = when {
        p.optString("syncedLyrics").isNotBlank() -> 3
        p.optString("plainLyrics").isNotBlank() -> if (p.optBoolean("matchVerified", true)) 2 else 1
        else -> 0
    }

    /**
     * Run a single provider within the coordinator's budget/backoff/cancellation rules.
     * Re-throws [CancellationException] and [LyricsRepository.AudioBusy]; all other
     * exceptions are returned as the second element of the pair so callers can decide
     * whether to continue with the next source.
     */
    private suspend fun runProviderSafe(
        provider: LyricsProvider,
        track: TrackEntity,
        transport: suspend (LyricsProvider, Request) -> String,
        trace: LyricsLookupTrace?
    ): Pair<JSONObject?, Exception?> {
        val deadline = lock.withLock { backoffUntil[provider.id] ?: 0L }
        val now = clockMs()
        if (now < deadline) {
            trace?.add("${provider.id}: backoff; trying next source")
            return null to LyricsRepository.DeferredLyrics(deadline - now)
        }
        return try {
            trace?.add("${provider.id}: begin; budgetMs=${provider.budgetMs}")
            val completed = withTimeoutOrNull(provider.budgetMs) {
                currentCoroutineContext().ensureActive()
                var requests = 0
                Completed(provider.lookup(track, { request ->
                    currentCoroutineContext().ensureActive()
                    if (++requests > provider.requestLimit) throw IOException("${provider.id}: лимит запросов")
                    try {
                        withTimeoutOrNull(provider.requestTimeoutMs) { transport(provider, request) }
                            ?: throw IOException("${provider.id}: запрос занял слишком долго")
                    }
                    catch (e: CancellationException) { throw e }
                    catch (e: LyricsRepository.HttpFailure) {
                        if (e.status == 429) {
                            lock.withLock { backoffUntil[provider.id] = clockMs() + 60_000L }
                            trace?.add("${provider.id}: HTTP 429; backoffMs=60000")
                        }
                        throw e
                    }
                }, trace))
            } ?: throw IOException("${provider.id}: превышено время поиска")
            currentCoroutineContext().ensureActive()
            val payload = completed.payload
            if (payload != null) {
                trace?.add("${provider.id}: ${if (payload.optString("syncedLyrics").isNotBlank()) "synced" else "plain"}")
            } else {
                trace?.add("${provider.id}: not found")
            }
            payload to null
        } catch (e: CancellationException) { throw e }
        catch (e: LyricsRepository.AudioBusy) { throw e }
        catch (e: Exception) {
            trace?.add("${provider.id}: ${e.javaClass.simpleName}; trying next source")
            null to if (e is IOException) e else IOException("${provider.id}: некорректный ответ сервиса", e)
        }
    }

    /**
     * Run [group] providers in parallel. Results are collected via a Channel as they arrive;
     * remaining providers are cancelled as soon as a synchronized result is found.
     * [LyricsRepository.AudioBusy] and [CancellationException] propagate immediately and
     * cancel the whole group via structured concurrency.
     */
    private suspend fun runParallelGroup(
        group: List<LyricsProvider>,
        track: TrackEntity,
        transport: suspend (LyricsProvider, Request) -> String,
        trace: LyricsLookupTrace?
    ): List<Pair<JSONObject?, Exception?>> = coroutineScope {
        val channel = Channel<Pair<JSONObject?, Exception?>>(Channel.UNLIMITED)
        val jobs = group.map { provider ->
            launch {
                try {
                    val result = runProviderSafe(provider, track, transport, trace)
                    channel.send(result)
                } catch (e: CancellationException) {
                    // A cancelled launch does not fail its parent automatically. Wake the
                    // receiver instead of leaving it waiting for a result that can never arrive.
                    channel.cancel(e)
                    throw e
                }
            }
        }
        val collected = mutableListOf<Pair<JSONObject?, Exception?>>()
        var pending = group.size
        while (pending > 0) {
            val result = channel.receive()
            pending--
            collected.add(result)
            if (result.first?.optString("syncedLyrics")?.isNotBlank() == true) {
                // Synchronized result: cancel remaining parallel work early.
                jobs.forEach { it.cancel() }
                break
            }
        }
        jobs.forEach { it.join() }
        channel.close()
        collected
    }

    suspend fun lookup(
        track: TrackEntity,
        transport: suspend (LyricsProvider, Request) -> String,
        trace: LyricsLookupTrace?,
        onProgress: suspend (JSONObject) -> Unit = {}
    ): JSONObject {
        var firstFailure: Exception? = null
        var best: JSONObject? = null

        // ── Parallel phase ────────────────────────────────────────────────────────────
        val parallelGroup = providers.take(parallelCount)
        val sequentialTail = providers.drop(parallelCount)

        val parallelResults = if (parallelGroup.size == 1) {
            // Single provider: skip channel overhead.
            currentCoroutineContext().ensureActive()
            listOf(runProviderSafe(parallelGroup[0], track, transport, trace))
        } else {
            currentCoroutineContext().ensureActive()
            runParallelGroup(parallelGroup, track, transport, trace)
        }

        for ((payload, error) in parallelResults) {
            currentCoroutineContext().ensureActive()
            if (payload != null) {
                if (!upgradePlain || rank(payload) == 3 ||
                    (payload.optBoolean("instrumental", false) && best == null)) {
                    trace?.add("${payload.optString("source", "")}: selected from parallel group")
                    return payload
                }
                if (best == null || rank(payload) > rank(best!!)) {
                    best = payload
                }
            } else if (error != null && firstFailure == null) {
                firstFailure = error
            }
        }

        // Publish best plain from parallel phase while sequential tail searches for sync upgrade.
        if (best != null) {
            currentCoroutineContext().ensureActive()
            onProgress(best!!)
            trace?.add("parallel group: plain shown; looking for synchronized upgrade")
        }

        // ── Sequential tail ───────────────────────────────────────────────────────────
        for (provider in sequentialTail) {
            currentCoroutineContext().ensureActive()
            val (payload, error) = runProviderSafe(provider, track, transport, trace)
            currentCoroutineContext().ensureActive()
            if (payload != null) {
                if (!upgradePlain || rank(payload) == 3 ||
                    (payload.optBoolean("instrumental", false) && best == null)) {
                    trace?.add("${provider.id}: selected")
                    return payload
                }
                if (best == null || rank(payload) > rank(best!!)) {
                    best = payload
                    currentCoroutineContext().ensureActive()
                    onProgress(payload)
                    trace?.add("${provider.id}: plain shown; looking for synchronized upgrade")
                }
            } else if (error != null && firstFailure == null) {
                firstFailure = error
            }
        }

        currentCoroutineContext().ensureActive()
        best?.let { return it }
        throw (firstFailure ?: LyricsRepository.NoLyrics(
            "В подключённых источниках текст не найден. Можно повторить поиск или импортировать LRC"))
    }
}
