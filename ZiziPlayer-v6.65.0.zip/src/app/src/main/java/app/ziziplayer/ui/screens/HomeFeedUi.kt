package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.HomeFeedCard
import app.ziziplayer.ui.HomeFeedPolicy
import app.ziziplayer.ui.HomeFeedShelf
import app.ziziplayer.ui.HomeShelfLayout
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.rememberUrlArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

internal fun LazyListScope.homeFeedShelves(
    shelves: List<HomeFeedShelf>, onOpen: (HomeFeedCard) -> Unit,
    onPlay: (TrackEntity, List<TrackEntity>, String) -> Unit, onMenu: (TrackEntity) -> Unit
) {
    shelves.forEach { shelf ->
        item(key = "feed:${shelf.id}", contentType = shelf.layout.name) {
            HomeFeedShelfView(shelf, onOpen, onPlay, onMenu)
        }
    }
}

@Composable
private fun HomeFeedShelfView(shelf: HomeFeedShelf, onOpen: (HomeFeedCard) -> Unit,
    onPlay: (TrackEntity, List<TrackEntity>, String) -> Unit, onMenu: (TrackEntity) -> Unit) {
    val p = LocalPalette.current
    val queue = androidx.compose.runtime.remember(shelf.cards) { shelf.cards.flatMap { it.tracks }.distinctBy { it.id } }
    Column(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (shelf.seed != null) TrackArtwork(shelf.seed, 160, Modifier.size(50.dp).clip(CircleShape))
            Column(Modifier.weight(1f)) {
                Text(shelf.title, color = p.text, fontSize = 22.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)
                if (shelf.subtitle.isNotEmpty()) Text(shelf.subtitle, color = p.subtext, fontSize = 12.sp,
                    modifier = Modifier.padding(top = 5.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(12.dp))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val viewport = maxWidth.value / (1f - 92f / 1080f)
            val inset = HomeFeedPolicy.inset(viewport).dp
            val gap = HomeFeedPolicy.gap(viewport).dp
            val card = HomeFeedPolicy.card(viewport).dp
            LazyRow(Modifier.requiredWidth(viewport.dp), contentPadding = PaddingValues(horizontal = inset),
                horizontalArrangement = Arrangement.spacedBy(gap)) {
                if (shelf.layout == HomeShelfLayout.TRACKS) {
                    items(shelf.cards.chunked(3), key = { it.first().id }, contentType = { "track-page" }) { page ->
                        Column(Modifier.width((viewport * 0.86f).dp)) {
                            page.forEach { entry -> entry.tracks.firstOrNull()?.let { track ->
                                Row(Modifier.fillMaxWidth().heightIn(min = 68.dp)
                                    .clickable { onPlay(track, queue, "home:feed:${shelf.id}") },
                                    verticalAlignment = Alignment.CenterVertically) {
                                    TrackArtwork(track, 160, Modifier.size(50.dp).clip(RoundedCornerShape(4.dp)))
                                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                        Text(track.title, color = p.text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(track.artist, color = p.subtext, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    IconButton(onClick = { onMenu(track) }) { Icon(ZiziIcons.More, "Действия с треком", tint = p.subtext) }
                                }
                            } }
                        }
                    }
                } else items(shelf.cards, key = { it.id }, contentType = { "cover" }) { entry ->
                    Column(Modifier.width(card).clickable {
                        if (entry.tracks.size == 1 && entry.id == entry.tracks.first().id && entry.remote == null && shelf.layout != HomeShelfLayout.ARTISTS)
                            onPlay(entry.tracks.first(), queue, "home:feed:${shelf.id}")
                        else onOpen(entry)
                    }) {
                        Box(Modifier.size(card).clip(if (shelf.layout == HomeShelfLayout.ARTISTS) CircleShape else RoundedCornerShape(4.dp))) {
                            if (entry.remote != null) {
                                val art = rememberUrlArtwork(entry.remote.artworkUrl, 480)
                                if (art != null) androidx.compose.foundation.Image(art.image, null,
                                    modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                else Box(Modifier.fillMaxSize().background(p.surface), contentAlignment = Alignment.Center) {
                                    Icon(ZiziIcons.Library, null, tint = p.subtext)
                                }
                            } else if (shelf.layout == HomeShelfLayout.ARTISTS) {
                                // An album sleeve is not a verified portrait of its artist.
                                Box(Modifier.fillMaxSize().background(p.surface), contentAlignment = Alignment.Center) {
                                    Icon(ZiziIcons.Person, null, tint = p.subtext, modifier = Modifier.size(44.dp))
                                }
                            } else TrackArtwork(entry.cover, 480, Modifier.fillMaxSize())
                            if (shelf.layout != HomeShelfLayout.ARTISTS && (entry.id.startsWith("mix:") || entry.id == "favorites-mix")) {
                                Text("ZIZI · МИКС", color = p.text,
                                    fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()
                                        .background(p.surface.copy(alpha = 0.88f)).padding(8.dp))
                            }
                        }
                        Text(entry.title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 12.dp).fillMaxWidth(),
                            textAlign = if (shelf.layout == HomeShelfLayout.ARTISTS) androidx.compose.ui.text.style.TextAlign.Center
                                else androidx.compose.ui.text.style.TextAlign.Start)
                        if (entry.subtitle.isNotEmpty()) Text(entry.subtitle, color = p.subtext, fontSize = 13.sp,
                            lineHeight = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}
