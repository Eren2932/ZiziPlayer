package app.ziziplayer.lyrics;

import java.util.regex.Pattern;

/** Validation, not transcription, translation or a recording-identity check. */
public final class LyricsFallbackText {
    private LyricsFallbackText() {}
    private static final int MAX_CHARS = 100_000;
    private static final Pattern HTML = Pattern.compile(
        "(?is)<(?:!doctype|html|head|body|script|iframe)\\b");

    public static String clean(String raw) {
        if (raw == null || raw.length() > MAX_CHARS) return null;
        String text = raw.replace("\r\n", "\n").replace('\r', '\n');
        if (text.startsWith("\ufeff")) text = text.substring(1);
        text = text.trim();
        if (text.isEmpty() || HTML.matcher(text).find()) return null;
        boolean hasVisibleCharacter = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isISOControl(c) && c != '\n' && c != '\t') return null;
            if (!Character.isWhitespace(c) && !Character.isSpaceChar(c) &&
                Character.getType(c) != Character.FORMAT) hasVisibleCharacter = true;
        }
        return hasVisibleCharacter ? text : null;
    }
}
