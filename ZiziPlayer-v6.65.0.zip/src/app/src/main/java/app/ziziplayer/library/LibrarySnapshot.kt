package app.ziziplayer.library

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.AtomicFile
import androidx.room.withTransaction
import app.ziziplayer.ZiziApplication
import app.ziziplayer.privacy.FolderVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Metadata only. Never exports preferences, credentials, cache, audio, or Android grants. */
class LibrarySnapshot(private val context: Context) {
    private val room = (context.applicationContext as ZiziApplication).database
    private val safety = AtomicFile(File(context.noBackupFilesDir, "library-before-restore.json"))

    private fun privacyCheck() {
        if (FolderVault.get(context).state.value.folders.isNotEmpty()) throw IllegalStateException(
            "Облачная библиотека и экспорт приостановлены: есть защищённые папки. Их данные не отправлены. Сначала снимите защиту папок, если хотите включить их метаданные в копию."
        )
    }

    suspend fun capture(): JSONObject = withContext(Dispatchers.IO) {
        privacyCheck()
        room.withTransaction { captureInside() }
    }

    private fun captureInside(): JSONObject {
        val tables = JSONObject()
        val db = room.openHelper.writableDatabase
        for (table in TABLES) {
            val rows = JSONArray()
            db.query("SELECT * FROM `$table` ORDER BY " + columns(table).joinToString(",") { "`${it.name}`" }).use { c ->
                while (c.moveToNext()) {
                    val row = JSONObject()
                    for (i in 0 until c.columnCount) row.put(c.getColumnName(i), when (c.getType(i)) {
                        Cursor.FIELD_TYPE_NULL -> JSONObject.NULL
                        Cursor.FIELD_TYPE_INTEGER -> c.getLong(i)
                        Cursor.FIELD_TYPE_FLOAT -> c.getDouble(i)
                        Cursor.FIELD_TYPE_STRING -> c.getString(i)
                        else -> error("Неподдерживаемое поле библиотеки")
                    })
                    rows.put(row)
                }
            }
            tables.put(table, rows)
        }
        return JSONObject().put("format", FORMAT).put("schema", 10).put("tables", tables).also { checkSize(it.toString()) }
    }

    private data class Column(val name: String, val type: String, val required: Boolean)
    private fun columns(table: String): List<Column> {
        val result = mutableListOf<Column>()
        room.openHelper.writableDatabase.query("PRAGMA table_info(`$table`)").use { c ->
            while (c.moveToNext()) result.add(Column(c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("type")), c.getInt(c.getColumnIndexOrThrow("notnull")) != 0))
        }
        return result
    }

    private fun validate(value: JSONObject) {
        require(value.keys().asSequence().toSet() == setOf("format", "schema", "tables")) { "Неизвестный формат копии" }
        require(value.getString("format") == FORMAT && value.getInt("schema") == 10) { "Несовместимая версия копии" }
        checkSize(value.toString())
        val tables = value.getJSONObject("tables")
        require(tables.keys().asSequence().toSet() == TABLES.toSet()) { "Неполная копия библиотеки" }
        var count = 0
        for (table in TABLES) {
            val rows = tables.getJSONArray(table)
            count += rows.length()
            require(count <= 100000) { "В копии слишком много записей" }
            val cols = columns(table)
            for (i in 0 until rows.length()) {
                val row = rows.getJSONObject(i)
                require(row.keys().asSequence().toSet() == cols.map { it.name }.toSet()) { "Неверные поля: $table" }
                for (col in cols) {
                    val item = row.get(col.name)
                    require(if (item == JSONObject.NULL) !col.required else when (col.type) {
                        "TEXT" -> item is String && item.length <= 65536
                        "INTEGER" -> item is Int || item is Long
                        "REAL" -> item is Number && item.toDouble().isFinite()
                        else -> false
                    }) { "Неверное значение: $table/${col.name}" }
                }
            }
        }
    }

    /** Validate without writing anything, before asking the user to replace their library. */
    suspend fun previewFile(raw: String): LibraryPreview = withContext(Dispatchers.IO) {
        privacyCheck()
        checkSize(raw)
        val value = JSONObject(raw)
        room.withTransaction { validate(value); LibraryPreview.from(value) }
    }

    /** Transactional replacement only after explicit choice (or a genuinely empty new library).
     * A scanner cannot interleave DB writes with this transaction. A durable safety copy is written
     * before the first DELETE. Local files/permissions themselves are never changed.
     */
    suspend fun restore(raw: String, expectedHash: String? = null): String = withContext(Dispatchers.IO) {
        privacyCheck()
        checkSize(raw)
        val value = JSONObject(raw)
        room.withTransaction {
            validate(value)
            val before = captureInside()
            if (expectedHash != null && hash(before) != expectedHash)
                throw app.ziziplayer.account.AccountApiException(409, "library_conflict")
            val bytes = before.toString().toByteArray(Charsets.UTF_8)
            val stream = safety.startWrite()
            try { stream.write(bytes); safety.finishWrite(stream) }
            catch (e: Exception) { safety.failWrite(stream); throw e }
            val tables = value.getJSONObject("tables")
            // Preserve this phone's file bindings; foreign content:// IDs cannot be trusted here.
            val local = mutableMapOf<String, JSONObject>()
            val current = before.getJSONObject("tables").getJSONArray("tracks")
            for (i in 0 until current.length()) {
                val row = current.getJSONObject(i)
                if (row.getString("source") == "local") local[row.getString("id")] = row
            }
            val tracks = tables.getJSONArray("tracks")
            val incoming = mutableSetOf<String>()
            for (i in 0 until tracks.length()) {
                val row = tracks.getJSONObject(i)
                val id = row.getString("id"); incoming.add(id)
                if (row.getString("source") == "local") {
                    val here = local[id]
                    row.put("uri", here?.getString("uri") ?: "zizi-missing:$id")
                    row.put("sourceFolder", here?.getString("sourceFolder") ?: "Восстановленные файлы")
                    row.put("artworkUri", here?.opt("artworkUri") ?: JSONObject.NULL)
                }
            }
            local.filterKeys { it !in incoming }.values.forEach { tracks.put(it) }
            val shadows = tables.getJSONArray("favorite_shadow")
            for (i in 0 until shadows.length()) {
                val row = shadows.getJSONObject(i)
                if (row.getString("source") == "local") {
                    val id = row.getString("trackId"); val here = local[id]
                    row.put("uri", here?.getString("uri") ?: "zizi-missing:$id")
                    row.put("sourceFolder", here?.getString("sourceFolder") ?: "Восстановленные файлы")
                    row.put("artworkUri", here?.opt("artworkUri") ?: JSONObject.NULL)
                }
            }
            val playlists = tables.getJSONArray("playlists")
            for (i in 0 until playlists.length()) {
                val row = playlists.getJSONObject(i)
                if (!row.isNull("coverUri") && !row.getString("coverUri").startsWith("https://")) row.put("coverUri", JSONObject.NULL)
            }
            val db = room.openHelper.writableDatabase
            for (table in TABLES.reversed()) db.execSQL("DELETE FROM `$table`")
            for (table in TABLES) {
                val rows = tables.getJSONArray(table)
                for (i in 0 until rows.length()) {
                    val row = rows.getJSONObject(i)
                    val values = ContentValues()
                    row.keys().forEach { key -> when (val item = row.get(key)) {
                        JSONObject.NULL -> values.putNull(key)
                        is String -> values.put(key, item)
                        is Int -> values.put(key, item)
                        is Long -> values.put(key, item)
                        is Number -> values.put(key, item.toDouble())
                        else -> error("Неверное значение")
                    } }
                    check(db.insert(table, SQLiteDatabase.CONFLICT_ABORT, values) != -1L)
                }
            }
            // Return the exact restored revision while still under the DB transaction. Edits
            // made after commit must remain dirty, not be accidentally acknowledged as synced.
            hash(captureInside())
        }
    }

    suspend fun readSafety(): String = withContext(Dispatchers.IO) {
        if (!safety.baseFile.exists()) throw IllegalStateException("Страховочная копия ещё не создана: восстановлений не было.")
        safety.openRead().bufferedReader().use { it.readText() }
    }

    companion object {
        const val FORMAT = "zizi-library-1"
        const val MAX_BYTES = 8 * 1024 * 1024
        val TABLES = listOf("tracks", "favorites", "playlists", "playlist_tracks", "track_fx", "eq_profiles", "hidden",
            "play_stats", "search_history", "playlist_links", "recents", "favorite_shadow", "listening_sessions", "home_pins", "track_catalog")
        fun checkSize(raw: String) { require(raw.toByteArray(Charsets.UTF_8).size <= MAX_BYTES) { "Копия больше 8 МиБ. Данные не изменены." } }
        fun hash(value: JSONObject): String = MessageDigest.getInstance("SHA-256")
            .digest(value.toString().toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        fun hasPersonalData(value: JSONObject): Boolean {
            val tables = value.getJSONObject("tables")
            if (TABLES.filterNot { it == "tracks" || it == "track_catalog" }.any { tables.getJSONArray(it).length() > 0 }) return true
            val tracks = tables.getJSONArray("tracks")
            return (0 until tracks.length()).any { val t = tracks.getJSONObject(it); t.getString("source") == "remote" && !t.isNull("savedAt") }
        }
        fun summary(value: JSONObject): String {
            val tables = value.getJSONObject("tables")
            val rows = tables.getJSONArray("tracks")
            val saved = (0 until rows.length()).count { !rows.getJSONObject(it).isNull("savedAt") }
            return "Сохранено треков: $saved · избранное: ${tables.getJSONArray("favorites").length()} · плейлисты: ${tables.getJSONArray("playlists").length()}"
        }
    }
}
