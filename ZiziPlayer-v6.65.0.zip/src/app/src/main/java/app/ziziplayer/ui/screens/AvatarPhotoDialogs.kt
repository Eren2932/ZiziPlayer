package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.ziziplayer.account.AvatarImage
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.rememberAccountAvatarBitmap
import kotlinx.coroutines.CancellationException

@Composable
internal fun AccountPhotoPreview(avatar: String, onDismiss: () -> Unit) {
    val image = rememberAccountAvatarBitmap(avatar)
    PhotoPreview(image, if (image == null) "Фото недоступно" else "", onDismiss)
}

@Composable
internal fun GalleryPhotoPreview(uri: Uri, onDismiss: () -> Unit, onSelect: () -> Unit) {
    val context = LocalContext.current
    var image by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    var error by remember(uri) { mutableStateOf("") }
    LaunchedEffect(uri) {
        try { image = AvatarImage.decode(context, uri, 1024).asImageBitmap() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = "Не удалось открыть фото" }
    }
    PhotoPreview(image, error, onDismiss, onSelect)
}

@Composable
private fun PhotoPreview(image: ImageBitmap?, error: String, onDismiss: () -> Unit, onSelect: (() -> Unit)? = null) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        BoxWithConstraints(Modifier.fillMaxSize().clickable(onClick = onDismiss).padding(20.dp), contentAlignment = Alignment.Center) {
            val controls = if (onSelect == null) 88.dp else 136.dp
            val side = minOf((maxWidth - 24.dp).coerceAtLeast(1.dp),
                (maxHeight - controls).coerceAtLeast(1.dp), 480.dp)
            Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF181818),
                modifier = Modifier.width(side + 24.dp).clickable(enabled = true, onClick = {})) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Просмотр фото", color = Color.White, modifier = Modifier.weight(1f))
                        IconButton(onClick = onDismiss) { Icon(ZiziIcons.Close, "Закрыть просмотр", tint = Color.White) }
                    }
                    Box(Modifier.size(side), contentAlignment = Alignment.Center) {
                        if (image != null) Image(image, "Фотография", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else if (error.isNotBlank()) Text(error, color = Color.White)
                        else CircularProgressIndicator(color = Color.White)
                    }
                    if (onSelect != null) TextButton(onClick = onSelect, enabled = image != null, modifier = Modifier.align(Alignment.End)) {
                        Text("Выбрать", color = if (image != null) Color.White else Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
internal fun AvatarRemovalSheet(onRemove: () -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss = onDismiss) {
        val exit = LocalSheetExit.current
        SheetTitle("Аватарка", "Изменения применятся после сохранения профиля")
        MenuItem(ZiziIcons.Trash, "Удалить фото", subtitle = "Вместо фотографии появится буква имени", danger = true,
            onClick = { exit(onRemove) })
        MenuItem(ZiziIcons.Close, "Отмена", onClick = { exit {} })
    }
}
