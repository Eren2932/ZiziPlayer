package app.ziziplayer.account;

/**
 * 6.50.0 — чистые правила «показывать ли приветствие» и «что предлагать на экране аккаунта».
 *
 * ПОЧЕМУ ЭТО JAVA БЕЗ ANDROID
 *
 * Ровно по той же причине, по которой так написаны ListeningClock и HomeFeedPolicy: решение
 * «закрыть человеку приложение окном» обязано быть проверяемым без эмулятора. Ошибка здесь не
 * рисует криво — она либо показывает приветствие на каждом запуске, либо не показывает его никогда.
 *
 * ЧЕГО ЗДЕСЬ СОЗНАТЕЛЬНО НЕТ
 *
 * Сети, хранилища и токенов. Этот класс не знает, поднят ли сервис аккаунтов; ему передают
 * готовый факт. Поэтому те же правила будут верны и когда синхронизация появится.
 */
public final class AccountGate {

    /**
     * Номер приветствия. Растёт ТОЛЬКО когда мы готовы снова занять человеку первый экран.
     *
     * Он существует не ради красоты: без него «показать один раз» невозможно отличить от
     * «показать один раз после этого обновления». 6.50.0 — первое приветствие, ревизия 1.
     */
    public static final int WELCOME_REVISION = 1;

    /** Решение человека. UNDECIDED — приветствие ещё не закрыто выбором. */
    public enum Mode { UNDECIDED, GUEST, SIGNED_IN }

    private AccountGate() {}

    /**
     * Показывать ли приветствие.
     *
     * Правила по важности:
     *  1. вошёл в аккаунт — никогда (у него уже есть ответ на вопрос окна);
     *  2. выбрал гостя и видел текущее приветствие — никогда (выбор уважаем, а не переспрашиваем);
     *  3. выбрал гостя, но приветствие новее — один раз, потому что мы сообщаем НОВОЕ;
     *  4. не выбирал ничего — да.
     *
     * Пункт 3 — единственное место, где окно возвращается. Именно его легче всего превратить в
     * «показывать всегда», перепутав знак сравнения, поэтому он и вынесен сюда под проверку.
     */
    public static boolean shouldShowWelcome(Mode mode, int seenRevision) {
        if (mode == Mode.SIGNED_IN) return false;
        if (mode == Mode.GUEST) return seenRevision < WELCOME_REVISION;
        return true;
    }

    /**
     * Можно ли вообще предлагать кнопку входа.
     *
     * Кнопка, которая ничего не делает, хуже отсутствующей кнопки: человек нажимает её и решает,
     * что приложение сломано. Пока адрес сервиса аккаунтов не задан, вход показывается как
     * «готовится», а не как рабочее действие.
     */
    public static boolean signInOffered(boolean serviceConfigured) {
        return SIGN_IN_IMPLEMENTED && serviceConfigured;
    }

    /** 6.51.0: email/Google identity and server sessions are implemented in source.
     * Availability still requires a configured HTTPS origin. This flag does NOT mean
     * the server is deployed, the APK was built, or media sync is available.
     */
    public static final boolean SIGN_IN_IMPLEMENTED = true;

    /**
     * Нормализация адреса сервиса аккаунтов.
     *
     * Пустая строка — сервиса нет. HTTP отвергается намеренно: через этот адрес поедут
     * идентификаторы сессии, и «работает по http» — это не компромисс, это отсутствие защиты.
     * Проверка простая и честная: мы отвечаем только за схему и непустой хост, а не за то,
     * что по адресу действительно живёт наш сервер.
     */
    public static String normalizeServiceUrl(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        try {
            java.net.URI uri = new java.net.URI(value);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                    uri.getRawUserInfo() != null || uri.getRawQuery() != null ||
                    uri.getRawFragment() != null ||
                    (uri.getPort() != -1 && uri.getPort() != 443) ||
                    !(uri.getRawPath().isEmpty() || "/".equals(uri.getRawPath())) ||
                    value.indexOf('\\') >= 0) return "";
            return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
        } catch (java.net.URISyntaxException error) {
            return "";
        }
    }
}
