package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.account.AccountProfileStore
import app.ziziplayer.library.LibraryPreview
import app.ziziplayer.library.LibrarySnapshot
import app.ziziplayer.library.LibrarySync
import app.ziziplayer.library.LibrarySyncState
import app.ziziplayer.ui.components.AccountAvatar
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.surfaceInputBoundary
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date

@Composable
fun LibraryStorageScreen(state: LibrarySyncState, account: AccountLocalState, onClose: () -> Unit,
    onSignIn: () -> Unit) {
    val context = LocalContext.current
    val sync = remember(context) { LibrarySync.get(context) }
    val snapshots = remember(context) { LibrarySnapshot(context.applicationContext) }
    val profiles = remember(context) { AccountProfileStore.get(context) }
    val storedProfile by profiles.state.collectAsStateWithLifecycle()
    // Do not display the previous user's avatar during account switching.
    val profile = storedProfile.takeIf { !account.isGuest && it.userId == account.userId } ?: AccountProfile()
    val name = if (account.isGuest) "На этом телефоне" else profileName(account, profile)
    val scope = rememberCoroutineScope()
    val p = LocalPalette.current
    var confirm by remember { mutableStateOf<String?>(null) }
    var confirmedPreview by remember { mutableStateOf<LibraryPreview?>(null) }
    var confirmedCloudHash by remember { mutableStateOf<String?>(null) }
    var imported by remember { mutableStateOf<String?>(null) }
    var importedPreview by remember { mutableStateOf<LibraryPreview?>(null) }
    var localPreview by remember(account.userId) { mutableStateOf<LibraryPreview?>(null) }
    var previewError by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var fileBusy by remember { mutableStateOf(false) }
    var safetyExport by rememberSaveable { mutableStateOf(false) }
    var filesOpen by rememberSaveable { mutableStateOf(false) }
    var detailsOpen by rememberSaveable { mutableStateOf(false) }
    var cloudOpen by rememberSaveable { mutableStateOf(false) }
    val blocked = state.busy || fileBusy
    BackHandler { if (!blocked) onClose() }
    LaunchedEffect(account.userId, state.busy, state.localSummary) {
        if (!state.busy) {
            try {
                localPreview = withContext(Dispatchers.IO) { LibraryPreview.from(snapshots.capture()) }
                previewError = ""
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { localPreview = null; previewError = e.message ?: "Не удалось прочитать библиотеку" }
        }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            fileBusy = true
            try {
                val raw = if (safetyExport) snapshots.readSafety() else snapshots.capture().toString()
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(uri, "wt") ?: error("Нет доступа к файлу")
                    stream.use { it.write(raw.toByteArray(Charsets.UTF_8)) }
                }
                notice = "Копия сохранена в файл. Храните его в надёжном месте."
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { notice = e.message ?: "Не удалось сохранить файл" }
            finally { fileBusy = false }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            fileBusy = true
            try {
                val raw = withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openInputStream(uri) ?: error("Нет доступа к файлу")
                    stream.use {
                        val buffer = ByteArray(8192); val output = ByteArrayOutputStream()
                        while (true) {
                            val n = it.read(buffer); if (n < 0) break
                            require(output.size() + n <= LibrarySnapshot.MAX_BYTES) { "Файл больше 8 МиБ" }
                            output.write(buffer, 0, n)
                        }
                        output.toString("UTF-8")
                    }
                }
                importedPreview = snapshots.previewFile(raw)
                imported = raw
                confirmedPreview = importedPreview
                confirm = "import"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { notice = e.message ?: "Не удалось прочитать файл" }
            finally { fileBusy = false }
        }
    }
    Column(Modifier.fillMaxSize().background(p.surface).surfaceInputBoundary().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose, enabled = !blocked) { Icon(ZiziIcons.ArrowBack, "Назад", tint = p.text) }
            Text("Сохранение библиотеки", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 17.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            StorageCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AccountAvatar(account.userId.orEmpty(), name, profile.avatar, 48.dp,
                        Modifier.semantics { contentDescription = "Аккаунт: $name" })
                    Column(Modifier.weight(1f)) {
                        Text(name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(if (account.isGuest) "Без облачного сохранения" else account.displayName.orEmpty(),
                            color = p.subtext, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                Text(when {
                    fileBusy -> "Работа с файлом…"
                    state.busy -> "Проверяем библиотеку…"
                    state.error.isNotBlank() -> "Сохранение требует внимания"
                    state.needsChoice -> "Выбери, какую библиотеку оставить"
                    state.enabled -> "Автосохранение подключено"
                    account.isGuest -> "Сохрани копию в файл или войди в аккаунт"
                    else -> "Облако не подключено"
                }, color = p.text, fontWeight = FontWeight.Medium)
                if (state.savedAt > 0 && !account.isGuest) Text("Сохранено в облаке: " +
                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(state.savedAt * 1000)),
                    color = p.subtext, fontSize = 13.sp)
                if (state.error.isNotBlank()) Text(state.error, color = p.text, fontSize = 14.sp)
                if (notice.isNotBlank() && notice != state.error) Text(notice, color = p.text, fontSize = 14.sp)
                if (state.needsChoice) Text("Копии не объединяются. Перед заменой проверь их состав ниже.", color = p.subtext, fontSize = 14.sp)
                if (account.isGuest) AccountPill("Войти в аккаунт", onSignIn, primary = true, enabled = !blocked)
                else if (state.enabled) AccountPill("Сохранить сейчас", {
                    notice = ""
                    fileBusy = true
                    scope.launch {
                        try {
                            sync.flush(manual = true)
                            val result = sync.state.value
                            notice = when {
                                result.error.isNotBlank() -> result.error
                                result.needsChoice -> "Сохранение приостановлено: выбери библиотеку."
                                result.message.startsWith("Изменений для отправки нет.") -> "Новых изменений нет. Дата последней копии указана выше."
                                result.enabled && result.savedAt > 0 -> "Библиотека сохранена в аккаунте."
                                else -> "Сохранение не подтверждено. Проверь подключение облака."
                            }
                        } finally { fileBusy = false }
                    }
                },
                    primary = true, enabled = !blocked)
                else if (!state.needsChoice) AccountPill("Подключить облако", { scope.launch { sync.refresh() } },
                    primary = true, enabled = !blocked)
                if (state.enabled) Text("Автосохранение — пока приложение открыто. Перед удалением нажми «Сохранить сейчас» и дождись результата.",
                    color = p.subtext, fontSize = 13.sp)
            }
            StorageCard {
                Text("На телефоне", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                localPreview?.let { LibraryContents(it) }
                    ?: Text(previewError.ifBlank { "Загружаем состав…" }, color = p.subtext)
                Text("Также сохраняются история и настройки отдельных треков.", color = p.subtext, fontSize = 13.sp)
                if (state.needsChoice && !account.isGuest) AccountPill("Оставить эту библиотеку", { confirmedPreview = localPreview; confirm = "phone" },
                    primary = true, enabled = !blocked && localPreview != null)
            }
            if (!account.isGuest && (state.cloudAvailable || state.needsChoice)) StorageCard {
                Text("В аккаунте", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (state.needsChoice || cloudOpen) {
                    state.cloudPreview?.let { LibraryContents(it) } ?: Text("Облачной копии пока нет", color = p.subtext)
                } else TextButton(onClick = { cloudOpen = true }) { Text("Посмотреть состав", color = p.text) }
                if (state.cloudAvailable) AccountPill("Восстановить эту копию", {
                    confirmedCloudHash = state.cloudHash; confirmedPreview = state.cloudPreview; confirm = "cloud"
                }, enabled = !blocked && state.cloudHash != null)
            }
            Text("Аудиофайлы не входят в копию. Сетевые обложки загружаются по ссылкам; локальные фото нужно выбрать заново.",
                color = p.subtext, fontSize = 13.sp)
            StorageCard {
                TextButton(onClick = { filesOpen = !filesOpen }) {
                    Text(if (filesOpen) "Копия в файл · свернуть" else "Копия в файл", color = p.text, fontWeight = FontWeight.Bold)
                }
                if (filesOpen) {
                    AccountPill("Сохранить файл", {
                        safetyExport = false; export.launch("ZiziPlayer-library-${System.currentTimeMillis()}.json")
                    }, enabled = !blocked)
                    AccountPill("Восстановить из файла", {
                        importLauncher.launch(arrayOf("application/json", "application/octet-stream"))
                    }, enabled = !blocked)
                    AccountPill("Копия до восстановления", {
                        safetyExport = true; export.launch("ZiziPlayer-before-restore.json")
                    }, enabled = !blocked)
                    Text("Файл содержит личную историю. Пароли и вход в аккаунт в него не записываются.", color = p.subtext, fontSize = 13.sp)
                }
            }
            TextButton(onClick = { detailsOpen = !detailsOpen }) { Text(if (detailsOpen) "Скрыть подробности" else "Что важно знать", color = p.subtext) }
            if (detailsOpen) StorageCard {
                Text("Профиль и аватар хранятся отдельно в аккаунте, не в файле библиотеки. Выход из аккаунта не удаляет библиотеку телефона.", color = p.subtext, fontSize = 13.sp)
                Text("Общие настройки, кэш, разрешения Android и аудиофайлы не переносятся. Локальные файлы подключаются заново. Доступность музыки зависит от каталога.", color = p.subtext, fontSize = 13.sp)
                if (!account.isGuest) AccountPill("Проверить облако", { scope.launch { sync.refresh() } }, enabled = !blocked)
                Text(state.message, color = p.subtext, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
    if (confirm != null) AlertDialog(onDismissRequest = { if (!blocked) { confirm = null; imported = null; importedPreview = null } },
        title = { Text(if (confirm == "phone") "Заменить копию в аккаунте?" else "Заменить библиотеку телефона?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (confirm == "import") "Источник: выбранный файл" else "Аккаунт: $name\n${account.displayName.orEmpty()}")
                confirmedPreview?.let { LibraryContents(it) }
                Text(if (confirm == "phone") "Копия в аккаунте будет заменена библиотекой телефона."
                    else "Избранное, плейлисты и история будут заменены, не объединены. Аудиофайлы не удаляются. Перед заменой создаётся внутренняя копия для отката.")
                if (confirm != "phone") Text("Для надёжного отката сначала сохрани текущую библиотеку в отдельный файл.")
            }
        },
        confirmButton = { TextButton(enabled = !blocked, onClick = {
            val action = confirm; val raw = imported; val hash = confirmedCloudHash
            confirm = null; imported = null; importedPreview = null; fileBusy = true
            scope.launch {
                try { when (action) {
                    "phone" -> sync.usePhone()
                    "cloud" -> if (hash != null) sync.useCloud(expectedHash = hash)
                    "import" -> if (raw != null) sync.importFile(raw)
                } } finally { fileBusy = false }
            }
        }) { Text("Заменить") } },
        dismissButton = { TextButton(enabled = !blocked, onClick = { confirm = null; imported = null; importedPreview = null }) { Text("Отмена") } })
}

@Composable
private fun StorageCard(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.chip).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun LibraryContents(preview: LibraryPreview) {
    val p = LocalPalette.current
    // Vertical metrics survive 200% fonts and narrow displays without clipping numbers.
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((label, count) in listOf("Сохранённые треки" to preview.savedTracks,
            "Избранное" to preview.favorites, "Плейлисты" to preview.playlists)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(label, color = p.subtext, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Text(count.toString(), color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
    if (preview.covers.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(preview.covers, key = { it.id }) { cover ->
            Column(Modifier.width(88.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                RemoteArtwork(cover.url, cover.title, 192, Modifier.size(88.dp).clip(RoundedCornerShape(10.dp)), glyphSize = 28)
                Text(cover.title, color = p.text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (cover.subtitle.isNotBlank()) Text(cover.subtitle, color = p.subtext, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
    if (preview.localTracks > 0) Text("Локальные записи: ${preview.localTracks}. Сами файлы подключаются отдельно.", color = p.subtext, fontSize = 13.sp)
}
