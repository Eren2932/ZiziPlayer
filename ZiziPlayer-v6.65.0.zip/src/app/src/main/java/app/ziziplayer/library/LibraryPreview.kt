package app.ziziplayer.library

import org.json.JSONObject

/** Bounded display data, derived from the actual snapshot, never from placeholder counts.
 * Only HTTPS covers are previewed: local images are not portable in this snapshot format.
 */
data class LibraryCover(val id: String, val title: String, val subtitle: String, val url: String?)
data class LibraryPreview(
    val savedTracks: Int,
    val favorites: Int,
    val playlists: Int,
    val localTracks: Int,
    val covers: List<LibraryCover>
) {
    companion object {
        fun from(value: JSONObject): LibraryPreview {
            val tables = value.getJSONObject("tables")
            val tracks = tables.getJSONArray("tracks")
            val lists = tables.getJSONArray("playlists")
            val favorites = tables.getJSONArray("favorites")
            val favoriteIds = (0 until favorites.length()).map { favorites.getJSONObject(it).getString("trackId") }.toSet()
            val covers = mutableListOf<LibraryCover>()
            var saved = 0
            var local = 0
            fun https(row: JSONObject, key: String): String? =
                if (row.isNull(key)) null else row.optString(key).takeIf { it.startsWith("https://") }
            for (i in 0 until tracks.length()) {
                val row = tracks.getJSONObject(i)
                if (row.optString("source") == "local") local++
                if (!row.isNull("savedAt")) saved++
                if (!row.isNull("savedAt") || row.getString("id") in favoriteIds) {
                    if (covers.size < 8) covers.add(LibraryCover("track:" + row.getString("id"),
                        row.optString("title").ifBlank { "Без названия" }, row.optString("artist"), https(row, "artworkUri")))
                }
            }
            val shadows = tables.getJSONArray("favorite_shadow")
            for (i in 0 until shadows.length()) {
                if (covers.size >= 8) break
                val row = shadows.getJSONObject(i)
                val id = "track:" + row.getString("trackId")
                if (row.getString("trackId") in favoriteIds && covers.none { it.id == id })
                    covers.add(LibraryCover(id, row.optString("title"), row.optString("artist"), https(row, "artworkUri")))
            }
            for (i in 0 until minOf(lists.length(), 4)) {
                val row = lists.getJSONObject(i)
                covers.add(LibraryCover("playlist:" + row.getLong("id"), row.optString("name"), "Плейлист", https(row, "coverUri")))
            }
            return LibraryPreview(saved, tables.getJSONArray("favorites").length(), lists.length(), local, covers)
        }
    }
}
