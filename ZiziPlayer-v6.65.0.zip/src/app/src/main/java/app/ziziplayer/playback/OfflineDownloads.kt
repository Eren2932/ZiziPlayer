package app.ziziplayer.playback

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * Скачивание трека целиком. 6.24.1: сначала во временный файл, потом публикация с проверкой.
 *
 * ## Почему поменялась схема
 *
 * 6.24.0 писала байты прямо в целевой файл (строку MediaStore) по мере их приезда. Красиво, но
 * у этого три следствия, и все три вылезли у тестировщика:
 *
 *  - цель приходилось создавать после первого блока (до него неизвестно расширение) — то есть
 *    в момент, когда отменить уже некрасиво, а проверить ещё нечего;
 *  - если публикация цели не удавалась (флаг `IS_PENDING` не снялся, прошивка не дала строку),
 *    **уже скачанные байты выбрасывались**. Второй попытки другим способом не было;
 *  - место на диске не проверялось вообще: на телефоне с почти полной памятью загрузка
 *    доходила до 90% и падала с «нет связи», хотя связь была ни при чём.
 *
 * Теперь: поток пишется в `cacheDir/zizi-dl/<id>.part`, а по последнему байту
 * [OfflineStore.save] публикует файл в первую сработавшую цель (медиатека → публичная
 * «Музыка/Zizi» → папка приложения) и проверяет результат. Лишняя копия стоит одного прохода
 * по диску и снимает целый класс отказов: байты уже наши, и их есть куда положить.
 *
 * ## Что ещё
 *
 *  - не больше двух загрузок одновременно, остальные показываются как «в очереди»;
 *  - живёт [DownloadService] — foreground-уведомление с процентом и отменой;
 *  - прогресс публикуется не чаще раза в 120 мс;
 *  - [DownloadEvents] — то, что стоит сказать вслух: «Сохранено в Музыка/Zizi» или причина отказа.
 *    До 6.24.1 результат загрузки существовал ТОЛЬКО как подпись внутри меню трека: закрыл
 *    меню — и отказ пропал вместе с ним. Именно так «оно молча ничего не скачало» и выглядело;
 *  - недокачанные `*.part` подчищаются на старте: обрыв не оставляет мусора в кэше.
 *
 * Отмена по-прежнему закрывает источник руками: `read()` блокирующий, отмена корутины сама его
 * не прерывает, и без этого поток докачивал бы трек в никуда.
 */
@UnstableApi
object OfflineDownloads {

    private const val MAX_PARALLEL = 2
    private const val BUFFER_BYTES = 64 * 1024
    private const val PROGRESS_MIN_GAP_MS = 120L
    /** Запас поверх размера трека: временный файл плюс его копия в целевой папке. */
    private const val SPACE_FACTOR = 2.4

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Semaphore(MAX_PARALLEL)
    private val batchPolicy = DownloadBatchPolicy()
    private val jobs = ConcurrentHashMap<String, Job>()
    private val readers = ConcurrentHashMap<String, DataSource>()
    /** Кто остановлен пользователем: отличает «нажал отмену» от «оборвалась связь». */
    private val cancelled: MutableSet<String> = Collections.synchronizedSet(HashSet())

    private val _states = MutableStateFlow<Map<String, DownloadStatus>>(emptyMap())
    /** Только «живые» состояния: в очереди / качается / только что упало. Остальное — с диска. */
    val states: StateFlow<Map<String, DownloadStatus>> = _states

    /** Сколько загрузок ещё не закончилось. Читает [DownloadService] для своего уведомления. */
    fun activeCount(): Int = _states.value.values.count {
        it is DownloadStatus.Running || it is DownloadStatus.Queued
    }

    /** Дёшево и синхронно: индекс в памяти плюс одна проверка существования файла. */
    fun statusOf(context: Context, track: TrackEntity): DownloadStatus {
        if (!RemoteUri.isRemote(track.uri)) return DownloadStatus.Local
        _states.value[track.id]?.let { return it }
        return if (OfflineStore.isDownloaded(context, track)) DownloadStatus.Done else DownloadStatus.None
    }

    fun isComplete(context: Context, track: TrackEntity): Boolean =
        RemoteUri.isRemote(track.uri) && OfflineStore.isDownloaded(context, track)

    /** Где лежит копия — строкой для меню трека. `null` — копии нет. */
    fun locationOf(context: Context, track: TrackEntity): String? = OfflineStore.whereIs(context, track)

    /** A snapshot may include local and downloaded tracks; start() skips both safely.
     * Call from IO for a large collection: OfflineStore validates saved files on disk.
     */
    fun startAll(context: Context, tracks: List<TrackEntity>) {
        val request = batchPolicy.newRequest()
        tracks.distinctBy { it.id }.forEach { track ->
            synchronized(this) {
                if (batchPolicy.mayStart(track.id, request)) start(context, track)
            }
        }
    }

    fun cancelCollection(tracks: List<TrackEntity>) {
        tracks.distinctBy { it.id }.forEach { track ->
            synchronized(this) {
                batchPolicy.cancel(track.id)
                if (jobs.containsKey(track.id)) cancel(track.id)
            }
        }
    }

    @Synchronized
    fun start(context: Context, track: TrackEntity) {
        if (!RemoteUri.isRemote(track.uri)) return
        if (jobs.containsKey(track.id)) return
        val app = context.applicationContext
        if (OfflineStore.isDownloaded(app, track)) { publish(track.id, DownloadStatus.Done); return }
        cancelled.remove(track.id)
        // Сразу «в очереди», ещё до захвата разрешения: тап обязан немедленно что-то изменить
        // на экране, иначе человек жмёт второй раз.
        publish(track.id, DownloadStatus.Queued)
        DownloadService.start(app)
        // Register BEFORE execution. An immediate resolver failure used to complete before
        // jobs[id] was assigned, leaving a finished job that blocked every retry.
        lateinit var job: Job
        job = scope.launch(start = CoroutineStart.LAZY) {
            gate.withPermit { download(app, track) }
        }
        jobs[track.id] = job
        // Completion also runs if cancellation wins BEFORE the coroutine body starts.
        // A finally inside that body alone cannot release such a queued registration.
        job.invokeOnCompletion {
            synchronized(this@OfflineDownloads) {
                if (jobs.remove(track.id, job) && job.isCancelled) clear(track.id)
            }
        }
        job.start()
    }

    private suspend fun download(context: Context, track: TrackEntity) {
        if (cancelled.contains(track.id)) { clear(track.id); return }
        publish(track.id, DownloadStatus.Running(-1))
        val temp = tempFile(context, track.id)
        var source: DataSource? = null
        try {
            temp.parentFile?.mkdirs()
            source = ZiziDataSources.resolvingFactory(context).createDataSource()
            readers[track.id] = source
            val length = source.open(DataSpec.Builder().setUri(Uri.parse(track.uri)).build())
            ensureSpace(context, length)

            var format: AudioFormatSniffer.Format? = null
            var total = 0L
            var lastPublishAt = 0L
            FileOutputStream(temp).use { out ->
                val buffer = ByteArray(BUFFER_BYTES)
                while (currentCoroutineContext().isActive) {
                    val read = source.read(buffer, 0, buffer.size)
                    if (read == C.RESULT_END_OF_INPUT) break
                    if (read <= 0) continue
                    if (format == null) format = AudioFormatSniffer.of(buffer, read)
                    out.write(buffer, 0, read)
                    total += read
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastPublishAt >= PROGRESS_MIN_GAP_MS) {
                        lastPublishAt = now
                        val percent = if (length > 0L) ((total * 100L) / length).toInt().coerceIn(0, 99) else -1
                        publish(track.id, DownloadStatus.Running(percent, total))
                    }
                }
                out.flush()
                // Байты должны быть на диске ДО публикации: копирование читает файл заново,
                // а не тот же буфер, который система ещё держит у себя.
                runCatching { out.fd.sync() }
            }

            if (!currentCoroutineContext().isActive || cancelled.contains(track.id)) {
                temp.delete(); clear(track.id); return
            }
            val sniffed = format ?: throw IOException("источник отдал пустой поток")
            if (total <= 0L) throw IOException("источник отдал пустой поток")
            // Оборванный поток без ошибки: сервер закрыл соединение на середине. Публиковать
            // половину трека нельзя — снаружи это «скачалось, но играет 40 секунд».
            if (length > 0L && total < length) {
                throw IOException("связь оборвалась на " + ((total * 100L) / length) + "%")
            }

            val entry = OfflineStore.save(context, track, temp, sniffed.mime, sniffed.extension)
            publish(track.id, DownloadStatus.Running(100, total))
            publish(track.id, DownloadStatus.Done)
            DownloadEvents.emit(DownloadEvent.Saved(track.title, entry.where, entry.visibleToOthers))
        } catch (cancel: CancellationException) {
            clear(track.id)
            throw cancel
        } catch (error: Throwable) {
            // Закрытый руками источник роняет read() обычным IOException — это отмена, не сбой.
            if (cancelled.remove(track.id)) {
                clear(track.id)
            } else {
                val reason = shortReason(error)
                publish(track.id, DownloadStatus.Failed(reason))
                DownloadEvents.emit(DownloadEvent.Failed(track.title, reason))
            }
        } finally {
            readers.remove(track.id)
            runCatching { source?.close() }
            runCatching { temp.delete() }
        }
    }

    /**
     * Место под загрузку проверяется ДО первого байта.
     *
     * Без этой проверки телефон с полной памятью показывает «нет связи» на 90 процентах —
     * сообщение, по которому починить нельзя ничего.
     */
    private fun ensureSpace(context: Context, length: Long) {
        if (length <= 0L) return
        val need = (length * SPACE_FACTOR).toLong()
        val free = runCatching { context.cacheDir.usableSpace }.getOrDefault(Long.MAX_VALUE)
        if (free < need) {
            val mb = (need - free) / 1024 / 1024 + 1
            throw IOException("не хватает памяти: нужно ещё ~$mb МБ")
        }
    }

    private fun tempFile(context: Context, trackId: String): File {
        val safe = trackId.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(64)
        return File(DownloadTemp.dir(context), "$safe.part")
    }

    /**
     * Мусор от прошлого запуска. Вызывается из Application, идемпотентно.
     *
     * Процесс могли убить в середине загрузки: `*.part` остался бы в кэше навсегда и никто бы
     * его не нашёл (кэш чистит только система, и только когда память кончится).
     */
    fun purgeTemp(context: Context) = DownloadTemp.purge(context)

    @Synchronized
    fun cancel(trackId: String) {
        batchPolicy.cancel(trackId)
        cancelled.add(trackId)
        // Порядок важен: сначала источник (он выбьет блокирующее чтение), потом корутина.
        // Наоборот — поток остался бы качать в никуда.
        runCatching { readers.remove(trackId)?.close() }
        jobs[trackId]?.cancel()
        clear(trackId)
    }

    @Synchronized
    fun cancelAll() {
        batchPolicy.cancelAll()
        (jobs.keys.toList() + _states.value.keys.toList()).distinct().forEach { cancel(it) }
    }

    /** «Удалить загрузку»: файл уходит, трек остаётся в библиотеке и играет из сети. */
    fun remove(context: Context, track: TrackEntity) {
        cancel(track.id)
        OfflineStore.delete(context.applicationContext, track.id)
        clear(track.id)
    }

    fun removeAll(context: Context, onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }) {
        cancelAll()
        OfflineStore.deleteAll(context.applicationContext, onProgress)
        _states.value = emptyMap()
    }

    /**
     * Короткая причина отказа. Человеку нужно знать, что делать дальше, а не класс исключения.
     *
     * Порядок проверок не случаен: «нет места» и «нет разрешения» лечатся действием
     * пользователя, поэтому они выше общего «нет связи».
     */
    private fun shortReason(error: Throwable): String {
        val message = error.message ?: ""
        return when {
            message.contains("памяти", ignoreCase = true) -> message
            message.contains("разрешени", ignoreCase = true) ||
                message.contains("доступ", ignoreCase = true) -> "нужен доступ к памяти в настройках Android"
            message.contains("403") -> "источник отказал, попробуй ещё раз"
            message.contains("оборвалась") -> message
            message.contains("Музык", ignoreCase = true) -> message
            message.contains("пустой поток") -> "источник не отдал звук"
            error is IOException -> "нет связи"
            else -> "не удалось скачать"
        }
    }

    private fun publish(id: String, status: DownloadStatus) = _states.update { it + (id to status) }

    private fun clear(id: String) = _states.update { it - id }
}
