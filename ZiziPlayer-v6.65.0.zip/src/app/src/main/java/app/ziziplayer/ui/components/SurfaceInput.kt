package app.ziziplayer.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/** Non-scrolling shield. Children see Main first, but drag descendants can still be cancelled. */
fun Modifier.blockSurfaceInput(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Main)
            event.changes.forEach { it.consume() }
        }
    }
}

/**
 * Opaque destination hit-test boundary. The topmost sibling owns this pointer path even
 * without consuming changes. Observe only: consuming movement on Main (or Final) cancels
 * a descendant scrollable while it is waiting for touch slop in the Final pass.
 * Use blockSurfaceInput for non-scrolling shields, never around draggable/scrollable content.
 */
fun Modifier.surfaceInputBoundary(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) awaitPointerEvent(PointerEventPass.Main)
    }
}
