package app.ziziplayer.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.ui.MainViewModel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

internal data class LyricsCursor(val sameTrack: Boolean, val matchesDuration: Boolean, val active: Int, val word: Int = -1)

/** Existing position stream in; UI emission only on line/identity/validation change. */
@Composable
internal fun rememberLyricsCursor(vm: MainViewModel, track: TrackEntity, doc: LyricsDocument, advanceMs: Long): State<LyricsCursor> {
    val cursor = remember(vm, track.id, doc, advanceMs) {
        vm.progress.map { progress ->
            val same = progress.trackId == track.id
            val matches = doc.source == "Импорт LRC" || LrcTimeline.durationMatches(doc.durationMs, progress.durationMs)
            val active = if (same && matches) LrcTimeline.activeIndex(doc.lines, progress.positionMs, advanceMs) else -1
            LyricsCursor(same, matches, active, if (active >= 0)
                LrcTimeline.activeWord(doc.lines[active], progress.positionMs, advanceMs) else -1)
        }.distinctUntilChanged()
    }
    return cursor.collectAsStateWithLifecycle(initialValue = LyricsCursor(false, false, -1))
}
