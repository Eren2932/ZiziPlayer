package app.ziziplayer.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.theme.LocalPalette

/** Three distinct tasks: choose music, search for it, manage the collection. */
enum class ZiziTab(val label: String, val icon: ImageVector, val glyph: Dp) {
    HOME("Главная", ZiziIcons.Home, 19.dp),
    SEARCH("Поиск", ZiziIcons.Search, 17.5.dp),
    LIBRARY("Медиатека", ZiziIcons.Library, 19.dp)
}

val ZIZI_TABS: List<ZiziTab> = ZiziTab.values().toList()

/**
 * 6.41.0: 54 -> 46 dp. Панель больше не несёт подложку (см. [ZiziTabBar]), поэтому её высота
 * это ровно высота содержимого: знак 19 + 5.5 зазора + подпись 9.5 sp + 2.5 + точка 3.5.
 * У эталона от верха знака до низа точки 108 px = 39.3 dp, остальное — воздух панели.
 */
val TAB_BAR_HEIGHT = 46.dp

/** Stable equal-width destinations; mini-player remains shared above the bar. */
@Composable
fun ZiziTabBar(current: ZiziTab, onPick: (ZiziTab) -> Unit) {
    val p = LocalPalette.current
    val tabBarHeight = TAB_BAR_HEIGHT + 16.dp * (LocalDensity.current.fontScale - 1f).coerceAtLeast(0f)
    Row(
        Modifier
            .fillMaxWidth()
            .height(tabBarHeight)
    ) {
        ZIZI_TABS.forEach { tab ->
            TabItem(
                tab = tab,
                selected = tab == current,
                // Активная вкладка БЕЛАЯ, а не акцентная: единственный цветной элемент панели —
                // точка под подписью. Так и у эталона, и причина не в красоте: accent берётся из
                // обложки, и на жёлтой обложке подпись активной вкладки становилась жёлтой на
                // чёрном — то есть менее заметной, чем неактивная серая.
                active = p.text,
                idle = p.subtext,
                dot = p.brand,
                modifier = Modifier.weight(1f),
                onClick = { onPick(tab) }
            )
        }
    }
}

@Composable
private fun TabItem(
    tab: ZiziTab,
    selected: Boolean,
    active: Color,
    idle: Color,
    dot: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    // Colour and weight are animated, position is not. A tab bar that moves its own icons when you
    // press them reads as unstable; the reference animates nothing but the tint, and it is right.
    val tint by animateColorAsState(
        targetValue = if (selected) active else idle,
        animationSpec = tween(durationMillis = 160),
        label = "tabTint"
    )
    val emphasis by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(durationMillis = 160),
        label = "tabEmphasis"
    )
    Box(
        modifier
            .fillMaxHeight()
            .selectable(
                selected = selected,
                interactionSource = interaction,
                // No ripple. A full-width rectangular ripple on a 54 dp bar looks like a rendering
                // glitch, and the tint change is already the feedback.
                indication = null,
                role = Role.Tab,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(tab.icon, contentDescription = tab.label, tint = tint, modifier = Modifier.size(tab.glyph))
            Spacer(Modifier.height(5.5.dp))
            Text(
                tab.label,
                color = tint,
                // 10.5 -> 9.5 sp. Замер эталона: «Медиатека» шириной 139 px против наших 166,
                // прописная 19 px против 20.5. Подпись под знаком — это ярлык, а не текст.
                fontSize = 9.5.sp,
                fontWeight = if (emphasis > 0.5f) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1
            )
            Spacer(Modifier.height(2.5.dp))
            // Точка занимает место ВСЕГДА, а не только у активной вкладки: иначе появление
            // точки поднимало бы знак и подпись на 6 dp при каждом переключении раздела.
            Box(
                Modifier
                    .size(3.5.dp)
                    .clip(CircleShape)
                    .background(dot.copy(alpha = emphasis))
            )
        }
    }
}
