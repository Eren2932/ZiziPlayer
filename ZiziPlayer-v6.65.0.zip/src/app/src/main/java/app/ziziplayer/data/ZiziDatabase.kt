package app.ziziplayer.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TrackEntity::class,
        FavoriteEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class,
        TrackFxEntity::class,
        EqProfileEntity::class,
        HiddenEntity::class,
        PlayStatEntity::class,
        SearchQueryEntity::class,
        PlaylistLinkEntity::class,
        RecentEntity::class,
        FavoriteShadowEntity::class,
        ListeningSessionEntity::class,
        HomePinEntity::class,
        TrackCatalogEntity::class
    ],
    version = 10,
    // A schemaLocation is configured in app/build.gradle.kts, so the history can actually be
    // exported. Asking for the location while exporting was off only produced a build warning.
    exportSchema = true
)
abstract class ZiziDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao
    abstract fun listeningDao(): ListeningDao

    companion object {
        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `listening_sessions` (`sessionId` TEXT NOT NULL, `trackId` TEXT NOT NULL, `title` TEXT NOT NULL, `artist` TEXT NOT NULL, `artworkUri` TEXT, `source` TEXT NOT NULL, `sourceFolder` TEXT NOT NULL, `startedAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `endedAt` INTEGER, `durationMs` INTEGER NOT NULL, `listenedMs` INTEGER NOT NULL, `coveredMs` INTEGER NOT NULL, `endPositionMs` INTEGER NOT NULL, `qualified` INTEGER NOT NULL, `completed` INTEGER NOT NULL, `outcome` TEXT NOT NULL, PRIMARY KEY(`sessionId`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_listening_sessions_trackId` ON `listening_sessions` (`trackId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_listening_sessions_startedAt` ON `listening_sessions` (`startedAt`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `home_pins` (`playlistId` INTEGER NOT NULL, `pinnedAt` INTEGER NOT NULL, PRIMARY KEY(`playlistId`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `track_catalog` (`trackId` TEXT NOT NULL, `provider` TEXT NOT NULL, `artistId` TEXT, `albumId` TEXT, `isrc` TEXT, PRIMARY KEY(`trackId`))")
            }
        }

        /** Adds the new tables without touching favourites, playlists or saved FX. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `hidden` (`trackId` TEXT NOT NULL, `hiddenAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `play_stats` (`trackId` TEXT NOT NULL, `playCount` INTEGER NOT NULL, `lastPlayedAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
            }
        }

        /**
         * Prepares the switch to content-derived track ids (see [TrackId]).
         *
         * This migration deliberately does **not** rewrite any id. It cannot: the new key is a hash
         * of the file name and byte size, and SQLite has neither SHA-1 nor access to the file
         * system. What it does is preserve the information needed to rewrite them later - it stamps
         * every existing row with `legacyId = id`.
         *
         * The remap itself runs once, in Kotlin, during the first scan after the upgrade
         * ([MusicRepository.migrateLegacyIds]): the scanner reports both ids for every file it
         * finds, so old key and new key meet in the same object and the child tables can be
         * rewritten with a plain UPDATE. If the process dies mid-way, nothing is lost - the flag
         * that marks the remap as done is only set at the end, so the next launch retries.
         *
         * `sizeBytes` is added with an explicit `DEFAULT 0` to match what Room generates for
         * `@ColumnInfo(defaultValue = "0")`; without the annotation on one side or the DEFAULT on
         * the other, Room's schema identity check fails at open time and takes the app down on
         * launch for every upgrading user.
         */
        /**
         * Makes room for the network catalogue. Nothing is dropped, nothing is rewritten.
         *
         * Every DEFAULT here is mandatory, not decorative. Room compares the live schema against
         * the one it generated from the entities, and a column declared NOT NULL without a matching
         * default is a mismatch - which surfaces as a crash on launch for everyone upgrading from
         * 6.5.1 and for nobody testing a fresh install. That is the exact trap MIGRATION_2_3 below
         * was written to avoid, so it is worth repeating rather than assuming.
         *
         * Index names are Room's own convention (`index_<table>_<columns joined by _>`); a
         * hand-picked name is the same mismatch by another route.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `source` TEXT NOT NULL DEFAULT 'local'")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `provider` TEXT")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `savedAt` INTEGER")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `lastSeenAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tracks_source` ON `tracks` (`source`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_tracks_provider_remoteId` ON `tracks` (`provider`, `remoteId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `search_history` (`query` TEXT NOT NULL, `queriedAt` INTEGER NOT NULL, PRIMARY KEY(`query`))")
            }
        }

        /**
         * 6.17.0 — одна новая таблица и ничего больше.
         *
         * Ни одна существующая колонка не трогается: связь «сборник -> плейлист» это отдельная
         * сущность, и попытка ужать её в `playlists` новой колонкой стоила бы ALTER TABLE на
         * таблице, которую читает каждый экран.
         */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `playlist_links` (" +
                        "`collectionKey` TEXT NOT NULL, " +
                        "`playlistId` INTEGER NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`owned` INTEGER NOT NULL, " +
                        "`linkedAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`collectionKey`))"
                )
            }
        }

        /**
         * 6.19.0 — только индексы. Ни одна таблица не пересоздаётся, ни одна колонка не меняется.
         *
         * Это важно понимать про SQLite: `CREATE INDEX` на существующей таблице — операция,
         * которая либо проходит целиком, либо не проходит вовсе, и данные она не трогает в
         * принципе. Поэтому эта миграция не может потерять ни избранное, ни плейлисты — самое
         * плохое, что она может сделать, это занять секунду на очень большой библиотеке.
         *
         * Имена индексов — строго по соглашению Room (`index_<таблица>_<колонки через _>`).
         * Своё имя здесь означало бы расхождение с тем, что Room сгенерирует из @Entity, а
         * расхождение схемы — это отказ открыть базу при запуске у всех, кто обновляется.
         *
         * ЧЕГО ТУТ СОЗНАТЕЛЬНО НЕТ: внешних ключей с ON DELETE CASCADE, хотя ревью их просило.
         * Причина не в лени, а в `upsertTracks`, который использует `OnConflictStrategy.REPLACE`.
         * REPLACE в SQLite — это DELETE старой строки плюс INSERT новой, и при включённых внешних
         * ключах (Room включает их всегда) каскад отработал бы на этом DELETE. То есть каждое
         * пересканирование библиотеки удаляло бы избранное, состав плейлистов, эффекты и счётчики
         * прослушиваний у всех треков, которые сканер нашёл заново, — то есть у всех. Ручные
         * `prune*` из [MusicDao] делают ту же работу без этой мины.
         */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tracks_title` ON `tracks` (`title`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tracks_sourceFolder` ON `tracks` (`sourceFolder`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tracks_dateAdded` ON `tracks` (`dateAdded`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_playlist_tracks_trackId` ON `playlist_tracks` (`trackId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_playlist_links_playlistId` ON `playlist_links` (`playlistId`)")
            }
        }

        /**
         * 6.24.4 — эквалайзер. Одна новая колонка и одна новая таблица.
         *
         * `eqConfig` добавляется как NULLABLE TEXT БЕЗ DEFAULT. Это не небрежность, а
         * единственный вариант, который совпадёт с тем, что Room сгенерирует из @Entity: у
         * nullable-поля без `@ColumnInfo(defaultValue = ...)` в схеме Room нет DEFAULT, и если
         * дописать сюда `DEFAULT ''`, проверка идентичности схемы при открытии базы упадёт — у
         * всех, кто обновляется, и ни у кого, кто ставит начисто. Ровно та же мина, о которую
         * бились MIGRATION_2_3 и MIGRATION_3_4; повторяю вывод, а не наступаю снова.
         *
         * Что здесь НЕ делается: не трогается `reverb`, не переписывается ни одна строка
         * `track_fx`. Перенос старого «Реверб %» в новый тракт — задача Kotlin на чтении
         * (withLegacyReverb), а не SQL: SQLite не должен знать, как звучит зал.
         *
         * Внешних ключей на `eq_profiles` нет и быть не может: пресет не привязан к треку.
         */
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `track_fx` ADD COLUMN `eqConfig` TEXT")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `eq_profiles` (" +
                        "`name` TEXT NOT NULL, " +
                        "`config` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`name`))"
                )
            }
        }

        /**
         * 6.27.0 — «Недавние». Одна новая таблица, один индекс, ноль изменений в существующих.
         *
         * Три вещи, в которых здесь легко ошибиться и каждая стоит краха при запуске у всех, кто
         * обновляется (и ни у кого, кто ставит начисто):
         *
         *  1. НИ ОДНОГО DEFAULT. Значения по умолчанию у RecentEntity — котлиновские, а Room
         *     кладёт DEFAULT в схему только для `@ColumnInfo(defaultValue = ...)`. Дописать сюда
         *     `DEFAULT 0` к `durationMs` значило бы разойтись с тем, что Room сгенерирует из
         *     @Entity, — и проверка идентичности схемы отказалась бы открыть базу. Та же мина,
         *     о которую бились MIGRATION_2_3, 3_4 и 6_7; повторяю вывод, а не наступаю снова.
         *
         *  2. Имя индекса — строго по соглашению Room: `index_<таблица>_<колонки через _>`.
         *     Своё имя — то же расхождение схемы другим путём.
         *
         *  3. `key` в обратных кавычках. Это не ключевое слово SQLite, но `key` регулярно им
         *     становится в чужих диалектах, а Room генерирует именно экранированный вариант.
         *
         * Внешнего ключа на `tracks` здесь нет сознательно — см. комментарий к RecentEntity.
         */
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `recents` (" +
                        "`key` TEXT NOT NULL, " +
                        "`kind` TEXT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`subtitle` TEXT NOT NULL, " +
                        "`artworkUrl` TEXT, " +
                        "`provider` TEXT, " +
                        "`remoteId` TEXT, " +
                        "`trackId` TEXT, " +
                        "`durationMs` INTEGER NOT NULL, " +
                        "`openedAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`key`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_recents_openedAt` ON `recents` (`openedAt`)")
            }
        }

        /**
         * 6.27.1: тень избранного и обложка плейлиста.
         *
         * Два изменения в одной миграции, и оба по одной причине: пользовательское решение обязано
         * переживать пересканирование. Лайк переживает потерю трека (`favorite_shadow`), обложка
         * переживает изменение состава (`playlists.coverUri`).
         *
         * Ни одного DEFAULT — снова. Котлиновские значения по умолчанию в схему Room не попадают,
         * а `@ColumnInfo(defaultValue = ...)` здесь ни у одного поля нет: у `favorite_shadow`
         * дефолтов нет вообще (все значения приходят из трека), у `coverUri` NULL и есть смысл —
         * «обложку не задавали». Дописать сюда `DEFAULT` значило бы разойтись с генерируемой
         * схемой и получить отказ открыть базу у всех, кто обновляется. Та же мина, о которую
         * бились MIGRATION_2_3, 3_4, 6_7, и о которую не наступила 7_8.
         */
        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `favorite_shadow` (" +
                        "`trackId` TEXT NOT NULL, " +
                        "`uri` TEXT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`artist` TEXT NOT NULL, " +
                        "`album` TEXT NOT NULL, " +
                        "`durationMs` INTEGER NOT NULL, " +
                        "`artworkUri` TEXT, " +
                        "`sourceFolder` TEXT NOT NULL, " +
                        "`source` TEXT NOT NULL, " +
                        "`provider` TEXT, " +
                        "`remoteId` TEXT, " +
                        "`addedAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`trackId`))"
                )
                db.execSQL("ALTER TABLE `playlists` ADD COLUMN `coverUri` TEXT")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `sizeBytes` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tracks` ADD COLUMN `legacyId` TEXT")
                db.execSQL("UPDATE `tracks` SET `legacyId` = `id`")
            }
        }
    }
}
