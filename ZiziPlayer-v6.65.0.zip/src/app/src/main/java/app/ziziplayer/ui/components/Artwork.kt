package app.ziziplayer.ui.components

import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.ui.theme.ArtworkColorMath
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.ZiziHttp
import app.ziziplayer.data.remote.ZiziResolve
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections

const val ARTWORK_ROW_PX = 160
const val ARTWORK_FULL_PX = 640

/**
 * Three colours pulled out of one cover: the accent, a second shade for depth, and a deep one for
 * the far ends of the gradient. v5 used a single seed, so the whole screen was one flat wash of
 * colour. Reference players build the backdrop out of several shades of the same cover, which is
 * why it reads as "the cover flew across the screen" instead of "someone tinted the app brown".
 */
@Immutable
data class ArtSwatches(val primary: Color, val secondary: Color, val deep: Color) {
    fun pack(): String = "${ArtworkColorMath.SWATCH_VERSION};${primary.toArgb()},${secondary.toArgb()},${deep.toArgb()}"

    companion object {
        fun unpack(raw: String?): ArtSwatches? {
            // Only colour verdicts are versioned. Thumbnails and no-art verdicts stay intact;
            // old colours are recalculated lazily from the next normally decoded bitmap.
            val prefix = "${ArtworkColorMath.SWATCH_VERSION};"
            if (raw == null || !raw.startsWith(prefix)) return null
            val parts = raw.removePrefix(prefix).split(',')
            if (parts.size != 3) return null
            val ints = parts.map { it.toIntOrNull() ?: return null }
            return ArtSwatches(Color(ints[0]), Color(ints[1]), Color(ints[2]))
        }
    }
}

/** One decoded cover. The ImageBitmap wrapper is built once, not on every recomposition. */
@Immutable
class Art(val image: ImageBitmap, val kb: Int, val swatches: ArtSwatches?)

/**
 * Artwork pipeline, third rewrite - this time for a 3000 track library.
 *
 * The order of attempts:
 *   1. in-memory LruCache                       (instant, no allocation)
 *   2. on-disk thumbnail cache                  (~1 ms, survives app restarts)
 *   3. MediaStore album art / loadThumbnail     (cheap, system side cache)
 *   4. MediaMetadataRetriever                   (20-120 ms - NEVER from a visible row)
 *
 * The single most important rule: a scrolling row is only ever allowed to use steps 1-3.
 * v5 let every row start step 4, so scrolling a 400 track list queued 400 file parses behind a
 * one-permit semaphore - the list could not be smooth, whatever else was optimised. Step 4 now
 * belongs to [ArtworkPrefetcher], which walks the library in the background, pauses while the
 * finger is down, and writes the result to disk so it is paid exactly once per file, ever.
 */
object ArtworkCache {
    // Floor raised from 6 MB in 6.5: at 160 px a cover is ~100 KB, so 6 MB held barely 60 of
    // them. Flicking a long list evicted rows faster than it drew them and every one of them came
    // back through a disk decode - a cache that small is a cache that guarantees jank.
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceIn(12 * 1024, 64 * 1024)
    private val memory = object : LruCache<String, Art>(maxKb) {
        override fun sizeOf(key: String, value: Art): Int = value.kb
    }
    private val swatchMemory = LruCache<String, ArtSwatches>(2048)
    // One bounded CPU sampler, shared by track and URL artwork. In particular loadUrl is
    // called on Main: returning from an IO decode must not run sampling on the UI thread.
    private val swatchGate = Semaphore(1)
    private val noArt = Collections.synchronizedSet(HashSet<String>())
    private val fastGate = Semaphore(2)
    private val slowGate = Semaphore(1)

    /**
     * Network covers get their own gate, four wide.
     *
     * They must not share [fastGate]: a cover fetch is 150-600 ms of waiting on a socket, and two
     * of them holding the two fast permits would stall every LOCAL cover behind them - a search
     * result list would freeze the library's thumbnails. Four at a time keeps a screenful of
     * remote rows filling in at once without opening a connection per row.
     */
    /**
     * 6.24.3. Свой scope для загрузок и карта уже идущих. Живут столько же, сколько процесс:
     * начатая загрузка обложки обязана доехать до диска, даже если строка ушла за экран.
     */
    private val fetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inflight = ConcurrentHashMap<String, Deferred<Art?>>()

    /**
     * 6.24.3: на медленном канале четыре параллельных запроса делят его на четыре и не
     * доезжает ни один; вдобавок они стоят в той же очереди, что запрос поиска и звук. Два
     * потока на мобильном — это «две обложки приехали», а не «четыре недокачаны».
     */
    private val netGate = Semaphore(2)


    /** `/hqdefault.jpg` and friends at the end of an i.ytimg.com thumbnail path. */
    private val YT_THUMB = Regex("""/(default|mqdefault|hqdefault|sddefault|maxresdefault)\.jpg""")

    /**
     * THE SCROLL BUG. Steps 1-3 were described as "cheap", so step 2 - the disk decode - ran with
     * no gate at all on Dispatchers.IO, which is 64 threads wide. Flicking a 400 row list started
     * up to 64 concurrent BitmapFactory.decodeFile calls; they do not block on IO, they burn CPU
     * and allocate, so they competed with the very frames they were decoding for. The list could
     * not be smooth no matter what else was optimised. Three at a time saturates the decode
     * throughput of a mid-range phone and leaves the render thread alone.
     */
    private val diskGate = Semaphore(3)

    /**
     * WHY COVERS GOT *WORSE* IN 6.8.0, not better.
     *
     * 6.8.0 versioned the "this file has no cover" key, which was the right call - the old set was
     * poisoned - but it also threw away the verdict for all 449 local files at once. The background
     * pass then re-probed every one of them, and each probe takes a [diskGate] permit before it can
     * even look for a cached thumbnail. There are three permits. A remote row on screen needed one
     * of the same three, so network tiles queued behind hundreds of local re-probes and filled in
     * minutes later, if at all. Nothing was broken; the traffic light was.
     *
     * Two gates fix it, and both halves are needed:
     *
     *  - remote rows read the disk through their own two permits, so they can never be starved by a
     *    local indexing pass;
     *  - the background pass holds at most ONE [diskGate] permit at a time ([prefetchGate]), so it
     *    can no longer occupy the whole disk stage. Indexing gets slower on paper and finishes at
     *    the same time in practice - it was never disk bound, it was contending with itself.
     *
     * The index key is deliberately NOT bumped again in 6.8.1: bumping it is what triggered the
     * storm, and the v2 set now holds correct answers.
     */
    private val remoteDiskGate = Semaphore(2)
    private val prefetchGate = Semaphore(1)

    @Volatile private var busyUntilMs = 0L
    @Volatile private var index: ArtworkIndex? = null
    @Volatile private var dir: File? = null

    private fun key(id: String, px: Int) = "$id@$px"

    fun attach(context: Context) {
        if (index != null) return
        val app = context.applicationContext
        val store = ArtworkIndex(app)
        index = store
        noArt.addAll(store.noArtIds())
        store.swatches().forEach { (id, swatches) -> swatchMemory.put(id, swatches) }
        val cacheDir = File(app.cacheDir, "artwork").apply { mkdirs() }
        dir = cacheDir
        // Keep the thumbnail cache bounded: oldest files go first.
        CoroutineScope(Dispatchers.IO).launch { prune(cacheDir) }
    }

    /** Called by every scrollable list: while the finger moves, nothing expensive may start. */
    fun markBusy() { busyUntilMs = System.currentTimeMillis() + 260 }
    fun isBusy(): Boolean = System.currentTimeMillis() < busyUntilMs

    /**
     * Sleeps until the busy window actually expires, instead of waking up every 60 ms to ask.
     *
     * Every visible row waits on this. With a 60 ms poll, twenty rows on screen meant ~200 pointless
     * coroutine resumes per flick, all of them landing on the main dispatcher while the frames they
     * were waiting for were being drawn. The busy window has a known end, so one sleep is enough.
     */
    suspend fun awaitIdle(maxWaitMs: Long = 900L) {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (true) {
            val now = System.currentTimeMillis()
            val remaining = busyUntilMs - now
            if (remaining <= 0L || now >= deadline) return
            delay(remaining.coerceIn(16L, 200L))
        }
    }

    /** Exactly the requested size, or nothing. */
    fun peekExact(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px))
    }

    /**
     * Anything usable right now, including a smaller thumbnail of the same cover. Used purely as a
     * stand-in for the first frame so nothing ever flashes a grey placeholder while the full size
     * decodes - it never replaces the real load.
     */
    fun peek(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px)) ?: if (px > ARTWORK_ROW_PX) memory.get(key(id, ARTWORK_ROW_PX)) else null
    }

    fun peekSwatches(track: TrackEntity?): ArtSwatches? = track?.let { swatchMemory.get(it.id) }

    /** Flushes the batched "no art" / colour verdicts to disk. */
    fun flushIndex() { index?.flush() }

    /**
     * Re-applies the 40 MB cap. v6.0 only did this at startup, so a full indexing pass could leave
     * the cache well over the cap until the next launch.
     */
    suspend fun pruneNow() {
        val base = dir ?: return
        withContext(Dispatchers.IO) { prune(base) }
    }

    fun hasNoArt(track: TrackEntity?): Boolean = track != null && noArt.contains(track.id)

    /** True when this track needs no further work at all - used to skip cheaply while prefetching. */
    fun isSettled(id: String): Boolean =
        memory.get(key(id, ARTWORK_ROW_PX)) != null || noArt.contains(id) || fileFor(id, ARTWORK_ROW_PX)?.exists() == true

    /**
     * The background pass enters through here, never through [load] directly: one permit, so the
     * indexer occupies a third of the disk stage instead of all of it. See [prefetchGate].
     */
    internal suspend fun loadIndexed(context: Context, track: TrackEntity, px: Int): Art? =
        prefetchGate.withPermit { load(context, track, px, allowSlow = true) }

    /**
     * 6.24.3. Загрузка, которая НЕ умирает вместе со строкой списка.
     *
     * Так выглядела причина «обложки грузятся по новой на каждом проходе». Сетевой запрос жил в
     * LaunchedEffect строки, а LazyColumn уничтожает ушедшую за экран строку вместе с её
     * корутиной. На Wi-Fi обложка успевала за 200 мс и это было незаметно. На мобильном 20 КБ/с
     * запрос отменялся на середине: скачанные байты выбрасывались, на диск не попадало НИЧЕГО,
     * и следующий заход начинался с нуля. Список физически не мог сойтись.
     *
     * Здесь запрос запускается в scope приложения, поэтому отмена читателя больше не отменяет
     * саму загрузку: она доезжает, ложится в память и на диск, и следующий взгляд на строку
     * получает готовое. Плюс дедупликация: десять возвратов к одной строке присоединяются к
     * ОДНОМУ запросу, а не запускают десять.
     */
    suspend fun loadDetached(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        peekExact(track, px)?.let { return it }
        val app = context.applicationContext
        val k = key(track.id, px)
        val task = inflight.computeIfAbsent(k) {
            fetchScope.async {
                try { load(app, track, px, allowSlow) } finally { inflight.remove(k) }
            }
        }
        return try {
            task.await()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            null
        }
    }

    suspend fun load(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        val cacheKey = key(track.id, px)
        memory.get(cacheKey)?.let { return it }
        // The `noArt` verdict is about a FILE and must never apply to a network row: its cover is
        // an HTTP request, and a request that failed once has to be allowed to succeed later. This
        // one condition is the other half of the grey-tile bug described in ArtworkIndex.
        if (!track.isRemote && noArt.contains(track.id)) return null

        // 2. disk (gated - see diskGate). withPermit is inline, so the non-local return below is
        // legal and the permit is still released through its finally block.
        val cached: Bitmap? = (if (track.isRemote) remoteDiskGate else diskGate).withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { readDisk(track.id, px) }
        }
        if (cached != null) return finish(track, px, cached, writeDisk = false)

        // 2b. THE MISSING BRANCH (6.6.1). Why remote covers were blank.
        //
        // A remote row carries an https artwork URL, and step 3 below handed it to
        // ContentResolver.openInputStream, which understands content:// and file:// and nothing
        // else. It returned null, silently. Step 4 then pointed MediaMetadataRetriever at a
        // zizi:// uri, which it also cannot open. So every network track fell through the entire
        // pipeline to `noArt` - and because the verdict is cached and persisted, the tile stayed
        // grey even after the network came back. There was no code path that could ever have
        // fetched them; nothing was misconfigured, the fetch simply did not exist.
        //
        // Remote rows take this branch and return from it either way: the two local decoders below
        // have nothing to offer something with no file behind it, and running them costs two failed
        // syscalls per tile.
        if (track.isRemote) {
            // Cached art may remain, but removed providers never trigger fresh image requests.
            if (!CatalogPolicy.supports(track.provider, track.remoteId)) return null
            /*
             * 6.8.1: the missing URL is not always missing.
             *
             * Innertube does not put a thumbnail on every row it returns - deep search shelves and
             * album track lists frequently come back without one, which is why "обложки не везде"
             * was real and not a caching illusion. But a YouTube track always has a thumbnail at a
             * derivable address: /vi/<id>/mqdefault.jpg. Deriving it costs nothing and turns a grey
             * tile into a cover for every row the API was too terse to describe.
             */
            val url = track.artworkUri?.takeIf { it.isNotBlank() }
                ?: track.remoteId
                    ?.takeIf { track.provider == "yt" && it.isNotBlank() }
                    ?.let { "https://i.ytimg.com/vi/" + it + "/mqdefault.jpg" }
            if (url.isNullOrBlank()) {
                // Not remembered, not even in memory: a saved remote row can get its artwork URL
                // filled in by the next search that returns it, and a cached "no" would outlive
                // that. Two skipped syscalls are not worth a permanently grey tile.
                return null
            }
            val fetched: Bitmap? = netGate.withPermit {
                memory.get(cacheKey)?.let { return it }
                withContext(Dispatchers.IO) { fromNetwork(url, px) }
            }
            if (fetched != null) return finish(track, px, fetched, writeDisk = true)
            // Deliberately NOT marked as coverless. A cover that failed while the phone was in a
            // lift is not a cover that does not exist, and `noArt` is written to disk - one bad
            // minute would blank the tile permanently.
            return null
        }

        // 3. fast system paths
        //
        // THE v6.0 COMPILE ERROR LIVED HERE.
        // The elvis had `Art?` on the left (the memory cache) and `Bitmap?` on the right (the
        // decoders), so Kotlin inferred their only common supertype - `Any` - and the call below
        // failed with "Argument type mismatch: actual type is 'kotlin.Any'" at Artwork.kt:167:52.
        // A cache hit now returns the finished Art immediately (withPermit is inline, so the
        // non-local return is legal and still releases the permit through its finally block) and
        // the remaining expression is a plain `Bitmap?`, which is what finish() wants.
        //
        // The re-check is not just there to satisfy the compiler: this permit is contended, and by
        // the time it is granted another coroutine may have decoded the very same cover already.
        val fast: Bitmap? = fastGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) {
                fromArtworkUri(context, track, px) ?: fromThumbnail(context, track, px)
            }
        }
        if (fast != null) return finish(track, px, fast, writeDisk = true)
        if (!allowSlow) return null

        // 4. the expensive one, one at a time, never while scrolling
        val slow = fromEmbedded(context, track, px)
        if (slow != null) return finish(track, px, slow, writeDisk = true)
        noArt.add(track.id)
        index?.rememberNoArt(track.id)
        return null
    }

    private suspend fun finish(track: TrackEntity, px: Int, bitmap: Bitmap, writeDisk: Boolean): Art =
        finishId(track.id, px, bitmap, writeDisk, persistSwatches = true)

    private suspend fun finishId(
        id: String,
        px: Int,
        bitmap: Bitmap,
        writeDisk: Boolean,
        persistSwatches: Boolean
    ): Art {
        val swatches = swatchMemory.get(id) ?: swatchGate.withPermit {
            // A row and its full-size cover may arrive together: recheck after acquiring.
            swatchMemory.get(id) ?: withContext(Dispatchers.Default) {
                extract(bitmap)?.also { extracted ->
                    swatchMemory.put(id, extracted)
                    if (persistSwatches) index?.rememberSwatches(id, extracted)
                }
            }
        }
        val art = Art(bitmap.asImageBitmap(), (bitmap.byteCount / 1024).coerceAtLeast(1), swatches)
        memory.put(key(id, px), art)
        if (writeDisk) CoroutineScope(Dispatchers.IO).launch { writeDisk(id, px, bitmap) }
        return art
    }

    // ---------------- covers that belong to a URL, not to a row ----------------

    /**
     * Search results are not library rows.
     *
     * A result exists in the UI long before - and very often instead of - a database row, so it has
     * no track id to key a cover on. Keying on the URL instead lets the hub, the result list and
     * the collection sheet share one cache with the player, and it means opening the same album
     * twice costs one fetch, ever: the second time the tiles are already on disk.
     *
     * The `u:` prefix keeps this namespace apart from track ids (`f:`, `u:`... note `u:` is a
     * legitimate local prefix, hence the full `url:` spelling below) so a cover can never be
     * mistaken for a track's own artwork.
     */
    private fun urlId(url: String): String = "url:$url"

    fun peekUrl(url: String?, px: Int): Art? {
        val target = url ?: return null
        return memory.get(key(urlId(target), px))
    }

    suspend fun loadUrl(url: String?, px: Int): Art? {
        val target = url?.takeIf { it.isNotBlank() } ?: return null
        val id = urlId(target)
        val cacheKey = key(id, px)
        memory.get(cacheKey)?.let { return it }

        val cached: Bitmap? = diskGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { readDisk(id, px) }
        }
        if (cached != null) return finishId(id, px, cached, writeDisk = false, persistSwatches = false)

        val fetched: Bitmap? = netGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { fromNetwork(target, px) }
        }
        // Swatches are extracted (they are nearly free once the bitmap is decoded and the player
        // may want them) but never written to the on-disk index: that index is keyed by track id
        // and is swept against the tracks table, so URL entries in it would leak forever.
        return fetched?.let { finishId(id, px, it, writeDisk = true, persistSwatches = false) }
    }

    /** Bounded visible-crop sampling; pure colour selection lives in ArtworkColorMath. */
    private fun extract(source: Bitmap): ArtSwatches? {
        val soft = source.softwareForSampling() ?: return null
        return try {
            sample(soft)
        } finally {
            if (soft !== source) soft.recycle()
        }
    }

    /**
     * `getPixels` throws on `Config.HARDWARE`, and `ContentResolver.loadThumbnail` is entitled to
     * hand one back - it decodes through `ImageDecoder`, which prefers a hardware buffer whenever
     * the device supports it. The old code called `getPixels` straight away inside `runCatching`, so
     * on those devices the throw was swallowed, `extract` returned null, and the UI quietly fell
     * back to the canned palette. That is exactly the "only a handful of fixed palettes" symptom.
     *
     * `Bitmap.copy` to a software config is the one operation that is documented to work on a
     * hardware bitmap, so it is used here rather than `createScaledBitmap`, which would go through a
     * software `Canvas` and throw "Software rendering doesn't support hardware bitmaps".
     */
    private fun Bitmap.softwareForSampling(): Bitmap? {
        val cfg = config
        val needsCopy = cfg == null ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && cfg == Bitmap.Config.HARDWARE)
        if (!needsCopy) return this
        return runCatching { copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
    }

    private fun sample(bitmap: Bitmap): ArtSwatches? = runCatching {
        // Match ContentScale.Crop: letterboxing outside the visible square cannot vote.
        val side = minOf(bitmap.width, bitmap.height)
        if (side <= 0) return@runCatching null
        val samples = minOf(side, ArtworkColorMath.SAMPLE_SIDE)
        val left = (bitmap.width - side) / 2
        val top = (bitmap.height - side) / 2
        val row = IntArray(side)
        val pixels = IntArray(samples * samples)
        for (y in 0 until samples) {
            val sourceY = top + ((y + 0.5f) * side / samples).toInt().coerceAtMost(side - 1)
            bitmap.getPixels(row, 0, side, left, sourceY, side, 1)
            for (x in 0 until samples) {
                val sourceX = ((x + 0.5f) * side / samples).toInt().coerceAtMost(side - 1)
                pixels[y * samples + x] = row[sourceX]
            }
        }
        val colors = ArtworkColorMath.extract(pixels) ?: return@runCatching null
        ArtSwatches(Color(colors[0]), Color(colors[1]), Color(colors[2]))
    }.getOrNull()

    // ---------------- sources ----------------

    private fun fromArtworkUri(context: Context, track: TrackEntity, px: Int): Bitmap? {
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { decode(it.readBytes(), px) }
        }.getOrNull()
    }

    /**
     * A cover over HTTP, on the app's one OkHttp client.
     *
     * The client is shared with the catalogue and with playback, so a cover fetch reuses the TLS
     * session that search already opened to the same host instead of paying for a handshake per
     * tile.
     */
    private fun fromNetwork(url: String, px: Int): Bitmap? {
        val sized = sizedUrl(url, px)
        // The rewritten URL is an optimisation, not a requirement. If the CDN does not like the
        // crop we asked for (a video thumbnail with no `maxresdefault`, a host that changed its
        // path scheme), the original address is still valid - falling back to it costs one request
        // on a cover that would otherwise simply be missing.
        // 6.36.0. Первым спрашивается свой сервер (`/img?u=`): CDN обложек — последнее место, куда
        // телефон ходил напрямую, и без VPN оно давало серую сетку при полностью живом каталоге.
        // Порядок попыток — от самого надёжного к самому дешёвому, и каждая следующая строка это
        // ровно один лишний запрос на обложку, которой иначе не было бы вообще.
        val bytes = ZiziResolve.imageUrl(sized)?.let { ZiziHttp.fetchBytes(it) }
            ?: ZiziHttp.fetchBytes(sized)
            ?: (if (sized != url) ZiziHttp.fetchBytes(url) else null)
            ?: return null
        return decode(bytes, px)
    }

    /**
     * Asks the CDN for the size we are actually going to draw.
     *
     * Supported Google image URLs encode their crop as `...=w544-h544-l90-rj`. A
     * 160 dp row does not need 544 px, and on a screen of results the difference is roughly a
     * megabyte per screenful versus a hundred kilobytes - on mobile data, that is the whole
     * experience. Anything we do not recognise is fetched untouched and simply downsampled during
     * decode, so an unknown host costs bandwidth but never correctness.
     */
    private fun sizedUrl(url: String, px: Int): String {
        // 6.24.3. Было `240` в `-l90-rj` (JPEG качества 90) — это 15–25 КБ на одну строку
        // списка. `-rw` на том же хосте Google отдаёт WebP: те же 192 px весят 5–8 КБ. На
        // строке 48 dp разницу не видит никто, а на 20 КБ/с это разница между «обложки
        // приехали» и «обложки не приехали».
        val size = when {
            px <= ARTWORK_ROW_PX -> 192
            px <= 320 -> 480
            else -> 720
        }
        // Google's image host: everything from "=w" onwards is the crop spec, and it is rewritable.
        val marker = url.lastIndexOf("=w")
        if (marker > 0 && (url.contains("googleusercontent") || url.contains("ytimg"))) {
            return url.substring(0, marker) + "=w" + size + "-h" + size + "-l85-rw"
        }
        // Video thumbnails (i.ytimg.com) name their crop instead of parameterising it. Anything
        // above hqdefault is deliberately not requested: maxresdefault does not exist for most
        // uploads and answers 404, which would cost a wasted round trip per tile.
        if (url.contains("i.ytimg.com")) {
            val name = if (size <= 240) "mqdefault.jpg" else "hqdefault.jpg"
            // The `?sqp=...` crop signature is minted for the file name it came with, so it is
            // dropped along with the name rather than carried over onto a different one.
            val bare = url.substringBefore('?')
            if (YT_THUMB.containsMatchIn(bare)) return YT_THUMB.replace(bare) { "/" + name }
            return url
        }
        return url
    }

    private fun fromThumbnail(context: Context, track: TrackEntity, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            context.contentResolver.loadThumbnail(Uri.parse(track.uri), android.util.Size(px, px), null)
        }.getOrNull()
    }

    private suspend fun fromEmbedded(context: Context, track: TrackEntity, px: Int): Bitmap? =
        slowGate.withPermit {
            var guard = 0
            while (isBusy() && guard < 60) { delay(80); guard++ }
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(track.uri))
                        retriever.embeddedPicture
                    } finally {
                        runCatching { retriever.release() }
                    }
                }.getOrNull()
            } ?: return@withPermit null
            decode(bytes, px)
        }

    // ---------------- disk ----------------

    private val hexDigits = "0123456789abcdef".toCharArray()

    /**
     * Cache file names, memoised.
     *
     * The old version ran a full `String.format` per byte - twenty of them - plus a fresh SHA-1
     * instance, and it did that for EVERY track on every isSettled/read/write. On a 3400 track
     * library the indexing pass alone paid it ten thousand times. Manual hex over a memoised
     * digest is roughly two orders of magnitude cheaper and allocates one String per track, once.
     */
    private val nameCache = LruCache<String, String>(4096)

    private fun hashOf(id: String): String {
        nameCache.get(id)?.let { return it }
        val digest = MessageDigest.getInstance("SHA-1").digest(id.toByteArray())
        val chars = CharArray(digest.size * 2)
        for (i in digest.indices) {
            val value = digest[i].toInt() and 0xFF
            chars[i * 2] = hexDigits[value ushr 4]
            chars[i * 2 + 1] = hexDigits[value and 0x0F]
        }
        val hex = String(chars)
        nameCache.put(id, hex)
        return hex
    }

    private fun fileFor(id: String, px: Int): File? {
        val base = dir ?: return null
        return File(base, "${hashOf(id)}-$px.webp")
    }

    private fun readDisk(id: String, px: Int): Bitmap? {
        val file = fileFor(id, px)?.takeIf { it.exists() } ?: return null
        val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
        val bitmap = runCatching { BitmapFactory.decodeFile(file.absolutePath, options) }.getOrNull()
        if (bitmap == null) runCatching { file.delete() }
        return bitmap
    }

    private fun writeDisk(id: String, px: Int, bitmap: Bitmap) {
        val file = fileFor(id, px) ?: return
        runCatching {
            val tmp = File(file.absolutePath + ".tmp")
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            }
            tmp.outputStream().use { bitmap.compress(format, 82, it) }
            if (!tmp.renameTo(file)) tmp.delete()
        }
    }

    private fun prune(base: File) {
        runCatching {
            val files = base.listFiles() ?: return
            var total = files.sumOf { it.length() }
            val cap = 40L * 1024 * 1024
            if (total <= cap) return
            files.sortedBy { it.lastModified() }.forEach { file ->
                if (total <= cap / 2) return
                total -= file.length()
                file.delete()
            }
        }
    }

    private fun decode(bytes: ByteArray, px: Int): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        var sample = 1
        while (largest / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

/**
 * Walks the library in the background and pays the expensive cover probe once per file, writing
 * both the thumbnail and the extracted colours to disk. Pauses whenever a list is being scrolled,
 * so it can never compete with the finger.
 */
object ArtworkPrefetcher {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastTracks: List<TrackEntity> = emptyList()
    private var appContext: Context? = null

    /**
     * Where the user is actually looking. The pass used to start at track 0 and walk to the end,
     * so scrolling to track 2000 meant waiting for 2000 covers you will never see before the ones
     * on screen were even queued - which is why the list "never finished loading" on a big library.
     */
    @Volatile private var focus = 0

    fun focusOn(index: Int) {
        if (index >= 0) focus = index
    }

    fun submit(context: Context, tracks: List<TrackEntity>) {
        job?.cancel()
        job = null
        lastTracks = tracks
        if (tracks.isEmpty()) return
        val app = context.applicationContext
        appContext = app
        val unmetered = isUnmetered(app)
        job = scope.launch {
            val total = tracks.size
            val taken = BooleanArray(total)
            var processed = 0
            var done = 0
            while (processed < total) {
                if (!isActive) return@launch
                // Re-aimed on every item, not once at the start: the window the user is looking at
                // is always served next, wherever they scrolled to in the meantime.
                val aim = focus.coerceIn(0, total - 1)
                var index = -1
                var probe = aim
                var steps = 0
                while (steps < total) {
                    if (!taken[probe]) { index = probe; break }
                    probe = (probe + 1) % total
                    steps++
                }
                if (index < 0) break
                taken[index] = true
                processed++
                val track = tracks[index]
                // Remote rows are skipped by the background pass. The pass exists to pay for
                // MediaMetadataRetriever once per FILE; a remote row has no file, and letting the
                // indexer walk a saved network library would mean hundreds of cover downloads the
                // user never asked for, on mobile data, in the background. Their covers are
                // fetched by the rows that are actually on screen.
                // 6.24.3. Раньше здесь стояло безусловное `if (track.isRemote) continue`, и
                // для полностью сетевой медиатеки это означало, что фоновый прогрев не делает
                // НИЧЕГО: обложки добывались только теми строками, что прямо сейчас на экране,
                // и на медленном канале не добывались вообще. Опасение в старом комментарии
                // («сотни загрузок на мобильных данных») справедливо — поэтому remote греется
                // только на нелимитированной сети. На Wi-Fi медиатека сходится один раз и
                // навсегда, на мобильном поведение остаётся прежним.
                if (track.isRemote && !unmetered) continue
                if (ArtworkCache.isSettled(track.id)) continue
                while (ArtworkCache.isBusy()) {
                    if (!isActive) return@launch
                    delay(160)
                }
                ArtworkCache.loadIndexed(app, track, ARTWORK_ROW_PX)
                done++
                if (done % 24 == 0) ArtworkCache.flushIndex()
                delay(8)
            }
            ArtworkCache.flushIndex()
            ArtworkCache.pruneNow()
        }
    }

    /**
     * 6.24.3. «Можно ли сейчас тратить байты на то, чего пользователь не просил». Wi-Fi без
     * тарификации — да; мобильный, роуминг, точка доступа с лимитом — нет. Ошибка чтения
     * трактуется как «лимит есть»: тратить чужой трафик по недоразумению хуже, чем не прогреть.
     */
    private fun isUnmetered(context: Context): Boolean = runCatching {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return@runCatching false)
            ?: return@runCatching false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }.getOrDefault(false)

    fun stop() { job?.cancel(); job = null }

    /**
     * Restarts indexing after the app comes back to the foreground. Without this the composition
     * survives backgrounding, the LaunchedEffect never re-runs, and indexing would stay dead for
     * the rest of the process.
     */
    fun resume() {
        val app = appContext ?: return
        if (job?.isActive == true) return
        submit(app, lastTracks)
    }
}

/** Shared neutral surface for absent artwork. No identity hashing or synthetic palette. */
private val MissingArtworkSurface = Color(0xFF191919)

/**
 * Deliberately NOT produceState.
 *
 * produceState keeps the previous value when its keys change - it only restarts the producer. In a
 * recycled list row, and in the player when the track changes, that means the widget would keep
 * showing the cover of the *previous* track until the new one finished decoding, and if the new
 * track had no cover at all it would show the wrong artwork forever.
 *
 * remember(key) re-seeds synchronously from the in-memory cache instead: a cached cover appears on
 * the very first frame (no grey flash while scrolling) and a cache miss starts exactly one load.
 */
@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int, allowSlow: Boolean = false): Art? {
    val context = LocalContext.current
    val id = track?.id
    val holder = remember(id, maxPx) { mutableStateOf(ArtworkCache.peekExact(track, maxPx)) }
    LaunchedEffect(id, maxPx, allowSlow) {
        val target = track ?: return@LaunchedEffect
        if (holder.value != null) return@LaunchedEffect
        // A track we already know has no cover used to start a full load anyway: 400 coroutines,
        // 400 cache lookups, 400 cancellations per flick, all to return null.
        if (ArtworkCache.hasNoArt(target)) return@LaunchedEffect
        // A row that is only passing under the finger must not decode at all. Rows that are still
        // on screen when the scroll settles decode ~60 ms later; rows that flew past are cancelled
        // by leaving the composition and cost nothing. The guard is bounded so a stuck busy flag
        // can never leave the list grey.
        if (!allowSlow) ArtworkCache.awaitIdle()
        holder.value = ArtworkCache.loadDetached(context, target, maxPx, allowSlow)
    }
    // While a bigger size decodes, the smaller thumbnail of the same cover stands in for it.
    return holder.value ?: ArtworkCache.peek(track, maxPx)
}

/** Only genuine artwork can colour the player. Missing/pending artwork uses the base theme. */
@Composable
fun rememberArtSwatches(track: TrackEntity?, enabled: Boolean): ArtSwatches? {
    if (!enabled) return null
    val art = rememberArtwork(track, ARTWORK_ROW_PX, allowSlow = true)
    val cached = ArtworkCache.peekSwatches(track)
    return when {
        art?.swatches != null -> art.swatches
        cached != null -> cached
        track == null -> null
        else -> null
    }
}

/** Paired-note silhouette, cached per tile size. No bitmap, shader or per-track palette. */
private fun notePath(height: Float, canvas: Size): Path {
    val h = height
    val left = (canvas.width - h) / 2f
    val top = (canvas.height - h) / 2f
    fun x(v: Float) = left + v * h
    fun y(v: Float) = top + v * h
    return Path().apply {
        moveTo(x(0.31f), y(0.74f))
        lineTo(x(0.31f), y(0.22f))
        quadraticBezierTo(x(0.31f), y(0.17f), x(0.36f), y(0.16f))
        lineTo(x(0.85f), y(0.06f))
        quadraticBezierTo(x(0.91f), y(0.05f), x(0.91f), y(0.11f))
        lineTo(x(0.91f), y(0.65f))
        lineTo(x(0.81f), y(0.65f))
        lineTo(x(0.81f), y(0.29f))
        lineTo(x(0.41f), y(0.37f))
        lineTo(x(0.41f), y(0.74f))
        close()
        addOval(androidx.compose.ui.geometry.Rect(x(0.06f), y(0.65f), x(0.41f), y(0.92f)))
        addOval(androidx.compose.ui.geometry.Rect(x(0.56f), y(0.56f), x(0.91f), y(0.83f)))
    }
}

@Composable
private fun MissingArtwork(glyphSize: Int) {
    Box(Modifier.fillMaxSize().drawWithCache {
        val height = minOf(size.minDimension * 0.40f, glyphSize.dp.toPx() * 1.5f)
        val path = notePath(height, size)
        val ink = Color(0xFF8C8C8C)
        onDrawBehind {
            drawRect(MissingArtworkSurface)
            drawPath(path, ink)
        }
    })
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44,
    allowSlow: Boolean = false
) {
    val art = rememberArtwork(track, maxPx, allowSlow)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            MissingArtwork(glyphSize)
        }
    }
}


/**
 * A cover that belongs to a URL rather than to a library row.
 *
 * Deliberately a separate composable from [TrackArtwork] instead of a flag on it. The two have
 * different failure modes and different placeholders: a library row without a cover is settled and
 * will never change, a search result without one is usually just early. Folding them together would
 * mean one of the two cases carrying the other's rules.
 */
@Composable
fun rememberUrlArtwork(url: String?, maxPx: Int): Art? {
    val holder = remember(url, maxPx) { mutableStateOf(ArtworkCache.peekUrl(url, maxPx)) }
    LaunchedEffect(url, maxPx) {
        if (holder.value != null) return@LaunchedEffect
        if (url.isNullOrBlank()) return@LaunchedEffect
        // Same courtesy as the local path: a tile flying past under the finger does not open a
        // socket. Rows still on screen when the flick settles fetch ~60 ms later, and rows that
        // left the composition are cancelled before the request is made.
        ArtworkCache.awaitIdle()
        holder.value = ArtworkCache.loadUrl(url, maxPx)
    }
    return holder.value
}

@Composable
fun RemoteArtwork(
    url: String?,
    seed: String?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44
) {
    val art = rememberUrlArtwork(url, maxPx)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            MissingArtwork(glyphSize)
        }
    }
}
