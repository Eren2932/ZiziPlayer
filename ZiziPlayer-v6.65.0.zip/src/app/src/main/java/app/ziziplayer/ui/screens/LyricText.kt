package app.ziziplayer.ui.screens

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import app.ziziplayer.lyrics.LrcTimeline

/** Real enhanced-LRC word spans only. Ordinary LRC is never dressed up as word-aligned. */
internal fun lyricText(line: LrcTimeline.Line, activeWord: Int, ink: Color): AnnotatedString = buildAnnotatedString {
    append(line.text.ifBlank { "♪" })
    if (line.words.isNotEmpty()) {
        addStyle(SpanStyle(color = ink.copy(alpha = 0.5f)), 0, length)
        line.words.forEachIndexed { index, word ->
            if (index <= activeWord) addStyle(SpanStyle(color = ink), word.start, word.end)
        }
    }
}
