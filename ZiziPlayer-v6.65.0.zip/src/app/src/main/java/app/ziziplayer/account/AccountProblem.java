package app.ziziplayer.account;

/** User-facing failures. Never include server HTML, cookie values or request bodies. */
public final class AccountProblem {
    private AccountProblem() {}
    public static String library(int status, String reason) {
        if (status == 404 || "sync_unavailable".equals(reason)) return "Сервер не поддерживает облачную библиотеку. Требуется Accounts 1.1 или новее; вход и письма работают отдельно.";
        if ("library_too_large".equals(reason)) return "Копия превышает серверный предел 8 МиБ. Существующая библиотека в аккаунте не заменена.";
        if (status == 413) return "Сервер отклонил размер копии (HTTP 413). Проверьте client_max_body_size 17m в nginx аккаунтов; предел библиотеки — 8 МиБ.";
        if (status == 401) return "Сессия истекла. Войдите заново; библиотека осталась на телефоне.";
        if (status == 429) return "Слишком много запросов. Повторите проверку через минуту; данные на телефоне не удалены.";
        if (status == 409) return "Данные или аккаунт изменились. Автосохранение приостановлено: проверьте облако и выберите библиотеку.";
        if (status == 400) return "Сервер отклонил формат библиотеки. Обновите клиент и Accounts; прежняя копия не заменена.";
        if (status == 403) return "Сервер отказал в доступе. Проверьте настройки HTTPS/origin аккаунтов. Данные на телефоне не удалены.";
        return "Сервис аккаунтов недоступен (HTTP " + status + "). Повторите проверку; локальные данные не удалены.";
    }
    public static boolean retryable(int status) { return status == 429 || status >= 500; }
}
