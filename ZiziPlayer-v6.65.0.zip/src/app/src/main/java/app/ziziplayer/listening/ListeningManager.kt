package app.ziziplayer.listening

import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.TrackSource
import java.util.UUID

/** Owned by PlaybackService, attached to the underlying ExoPlayer exactly once.
 * All methods run on the player's application looper. Uses the existing service heartbeat.
 */
@UnstableApi
class ListeningManager(
    private val player: Player,
    private val store: ListeningSink,
    private val protectedFolders: () -> Set<String>,
    private val elapsedRealtime: () -> Long = SystemClock::elapsedRealtime,
    private val wallClock: () -> Long = System::currentTimeMillis
) : Player.Listener {
    private var clock: ListeningClock? = null
    private var row: ListeningSessionEntity? = null
    private var epoch = store.generation
    private var lastSavedMs = -1L
    private var failed = false
    private var transitionPending = false

    init { player.addListener(this) }

    private fun now() = elapsedRealtime()
    private fun position() = player.currentPosition.coerceAtLeast(0L)
    private fun duration() = player.duration.takeIf { it > 0L } ?: 0L
    private fun permitted(item: MediaItem): Boolean {
        val folder = item.mediaMetadata.extras?.getString("vaultFolder")
        // Never collect protected folders, even while unlocked.
        return folder == null || folder !in protectedFolders()
    }
    private fun start(item: MediaItem) {
        if (item.mediaId.isBlank() || !permitted(item)) return
        val stamp = wallClock()
        val metadata = item.mediaMetadata
        val remote = item.mediaId.startsWith("r:")
        row = ListeningSessionEntity(
            sessionId = UUID.randomUUID().toString(), trackId = item.mediaId,
            title = metadata.title?.toString().orEmpty(), artist = metadata.artist?.toString().orEmpty(),
            artworkUri = metadata.artworkUri?.toString(),
            source = if (remote) TrackSource.REMOTE else TrackSource.LOCAL,
            sourceFolder = metadata.extras?.getString("vaultFolder").orEmpty(),
            startedAt = stamp, updatedAt = stamp, endedAt = null, durationMs = duration(),
            listenedMs = 0, coveredMs = 0, endPositionMs = position(),
            qualified = false, completed = false, outcome = "active"
        )
        clock = ListeningClock(now(), position())
        lastSavedMs = -1
    }
    private fun checkGeneration() {
        if (epoch != store.generation) {
            epoch = store.generation; row = null; clock = null; lastSavedMs = -1
        }
    }
    private fun sample() {
        val c = clock ?: return
        c.sample(now(), position(), player.isPlaying, player.playbackParameters.speed)
        row = row?.copy(durationMs = duration().takeIf { it > 0 } ?: row!!.durationMs,
            endPositionMs = position())
    }
    private fun save(outcome: String = "active") {
        val c = clock ?: return
        val old = row ?: return
        if (c.listenedMs() == 0L && outcome != "error") return
        if (outcome == "active" && lastSavedMs == c.listenedMs()) return
        val stamp = wallClock()
        val completed = c.completed(old.durationMs, outcome)
        val updated = old.copy(updatedAt = stamp, endedAt = if (outcome == "active") null else stamp,
            listenedMs = c.listenedMs(), coveredMs = c.coveredMs(),
            qualified = old.qualified || c.qualified(old.durationMs) || completed,
            completed = completed, outcome = outcome)
        row = updated
        lastSavedMs = c.listenedMs()
        store.submit(updated, epoch)
    }
    private fun finish(outcome: String) {
        // Position may already belong to the next item. Discontinuity captured the old endpoint.
        val old = row
        if (old != null) clock?.sample(now(), old.endPositionMs, false, player.playbackParameters.speed)
        save(outcome); row = null; clock = null
    }
    override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
        checkGeneration()
        clock?.seek(now(), oldPosition.positionMs.coerceAtLeast(0), newPosition.positionMs.coerceAtLeast(0),
            player.isPlaying, player.playbackParameters.speed)
        row = row?.copy(endPositionMs = oldPosition.positionMs.coerceAtLeast(0))
        val changed = oldPosition.mediaItemIndex != newPosition.mediaItemIndex ||
            oldPosition.mediaItem?.mediaId != newPosition.mediaItem?.mediaId
        if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION || changed) {
            finish(when {
                failed -> "error"
                reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION -> "ended"
                reason == Player.DISCONTINUITY_REASON_SEEK -> "skipped"
                reason == Player.DISCONTINUITY_REASON_REMOVE -> "removed"
                else -> "replaced"
            })
            transitionPending = true
        } else {
            row = row?.copy(endPositionMs = newPosition.positionMs.coerceAtLeast(0))
        }
    }
    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        checkGeneration()
        if (!transitionPending) finish(when (reason) {
            Player.MEDIA_ITEM_TRANSITION_REASON_AUTO, Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT -> "ended"
            Player.MEDIA_ITEM_TRANSITION_REASON_SEEK -> "skipped"
            else -> "replaced"
        })
        transitionPending = false
        failed = false
    }
    override fun onPlayerError(error: PlaybackException) {
        checkGeneration()
        // Keep zero-time failures diagnostically, without treating them as plays or skips.
        if (row == null) player.currentMediaItem?.let(::start)
        sample(); finish("error"); failed = true
    }
    override fun onEvents(player: Player, events: Player.Events) {
        update()
        transitionPending = false
        // Important boundaries persist immediately; periodic checkpoints share service heartbeat.
        if (!player.isPlaying) save()
    }
    private fun update() {
        checkGeneration()
        val item = player.currentMediaItem
        if (item == null || !permitted(item)) { finish("removed"); return }
        if (failed && !player.isPlaying) return
        if (failed) failed = false
        if (row != null && row?.trackId != item.mediaId) finish("replaced")
        if (player.playbackState == Player.STATE_ENDED) {
            sample(); finish("ended"); return
        }
        if (player.playbackState == Player.STATE_IDLE) {
            sample(); finish(if (failed) "error" else "stopped"); return
        }
        // Do not create history for a restored paused queue or for loading-only attempts.
        if (row == null && player.isPlaying) start(item)
        sample()
    }
    fun checkpoint() { update(); save() }
    fun close() {
        checkGeneration(); sample(); finish("stopped"); player.removeListener(this)
    }
}
