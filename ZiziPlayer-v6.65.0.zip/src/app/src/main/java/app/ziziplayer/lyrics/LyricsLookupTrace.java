package app.ziziplayer.lyrics;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** Bounded, in-memory, per-request diagnostics. Never stores URLs, credentials or lyrics. */
public final class LyricsLookupTrace {
    private final ArrayList<String> events = new ArrayList<>();
    private final LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
    public synchronized void add(String event) {
        if (events.size() >= 48) events.remove(0);
        String clean = event == null ? "" : event.replace('\n', ' ').replace('\r', ' ');
        events.add(clean.substring(0, Math.min(240, clean.length())));
    }
    public synchronized void count(String reason) {
        if (counts.containsKey(reason) || counts.size() < 16)
            counts.put(reason, counts.getOrDefault(reason, 0) + 1);
    }
    public synchronized String render() {
        StringBuilder out = new StringBuilder(String.join("\n", events));
        for (Map.Entry<String, Integer> entry : counts.entrySet())
            out.append('\n').append(entry.getKey()).append(": ").append(entry.getValue());
        return out.toString();
    }
}
