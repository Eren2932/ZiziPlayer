package app.ziziplayer.ui;

import java.util.HashSet;
import java.util.Set;

/** Local presentation preferences, NOT public access permissions. */
public final class ProfilePlaylistPolicy {
    private ProfilePlaylistPolicy() {}
    public static String key(long id, long createdAt) { return id + ":" + createdAt; }
    public static Set<String> update(Set<String> before, Set<String> keys, boolean hidden) {
        Set<String> next = new HashSet<>(before);
        if (hidden) next.addAll(keys); else next.removeAll(keys);
        return next;
    }
    public static Set<String> eligible(Set<String> selected, Set<String> available) {
        Set<String> result = new HashSet<>(selected);
        result.retainAll(available);
        return result;
    }
}
