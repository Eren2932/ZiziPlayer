@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.ziziplayer.account.AvatarGallery
import app.ziziplayer.account.GalleryPhoto
import app.ziziplayer.account.GalleryThumbnails
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

@Composable
internal fun AvatarGallerySheet(hasAvatar: Boolean, onPick: (Uri) -> Unit,
    onPhotoActions: () -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val session = remember { mutableIntStateOf(0) }
    val access = remember { mutableStateOf(AvatarGallery.signature(context)) }
    var requested by rememberSaveable { mutableStateOf(false) }
    // Returning from Settings or Android's limited-photo selector can revoke/change access.
    // A fresh keyed session drops old URIs, thumbnails and pagination; no background observer.
    // Но пересобираем сессию только при реальной смене доступа: ON_RESUME сам по себе
    // (возврат из системного диалога) больше не перезагружает уже загруженную сетку.
    val sync = remember(context) {
        {
            val now = AvatarGallery.signature(context)
            if (now != access.value || now == AvatarGallery.LIMITED) {
                access.value = now
                session.intValue++
            }
        }
    }
    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { sync() }
    DisposableEffect(lifecycle, sync) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) sync() }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    val p = LocalPalette.current
    val height = (LocalConfiguration.current.screenHeightDp * 0.90f).dp
    // Один резкий доводчик до 90% высоты: промежуточного якоря нет, поэтому лист
    // не ловит второй анимации и не дрожит под пальцем при открытии.
    ZiziSheetScaffold(onDismiss = onDismiss, scrollable = false, partiallyExpandable = false,
        modifier = Modifier.fillMaxWidth().height(height)) {
        val exit = LocalSheetExit.current
        // Тяжёлая работа (запрос доступа, чтение MediaStore, декодирование превью)
        // стартует только после того, как лист доехал до своей позиции.
        val settled = LocalSheetSettled.current
        LaunchedEffect(settled) {
            if (settled && !requested && !AvatarGallery.hasAccess(context)) {
                requested = true
                permission.launch(AvatarGallery.permissions())
            }
        }
        val pick: (Uri) -> Unit = { uri -> exit { onPick(uri) } }
        var launchError by remember { mutableStateOf("") }
        val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) pick(uri)
        }
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Выберите фотографию", color = p.text, fontSize = 20.sp, modifier = Modifier.weight(1f))
            if (hasAvatar) IconButton(onClick = { exit(onPhotoActions) }) { Icon(ZiziIcons.More, "Действия с аватаркой") }
            IconButton(onClick = { exit {} }) { Icon(ZiziIcons.Close, "Закрыть галерею") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                try { systemPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                catch (e: Exception) { launchError = "Системный выбор фото недоступен на этом устройстве" }
            }) { Text("Другие фото / файлы", color = p.brand) }
            if (AvatarGallery.limited(context)) TextButton(onClick = { permission.launch(AvatarGallery.permissions()) }) {
                Text("Доступ", color = p.brand)
            }
        }
        if (launchError.isNotBlank()) Text(launchError, color = p.subtext, modifier = Modifier.padding(horizontal = 22.dp))
        key(session.intValue) {
            if (access.value != AvatarGallery.NONE) {
                GalleryGrid(active = settled, onPick = pick, modifier = Modifier.weight(1f))
            } else Column(Modifier.weight(1f).fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.Center) {
                Text("Разрешите доступ к фотографиям, чтобы видеть галерею здесь. Или выберите отдельное фото кнопкой выше — полный доступ не нужен.", color = p.subtext)
                TextButton(onClick = { permission.launch(AvatarGallery.permissions()) }) { Text("Разрешить доступ", color = p.brand) }
            }
        }
    }
}

@Composable
private fun GalleryGrid(active: Boolean, onPick: (Uri) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val p = LocalPalette.current
    val thumbnails = remember { GalleryThumbnails() }
    val grid = rememberLazyGridState()
    var photos by remember { mutableStateOf<List<GalleryPhoto>>(emptyList()) }
    var beforeId by remember { mutableStateOf<Long?>(null) }
    var more by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(true) }
    var request by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<Uri?>(null) }
    LaunchedEffect(request, active) {
        // Пока лист летит, MediaStore не трогаем: чтение на первом кадре анимации и давало рывок.
        if (!active) return@LaunchedEffect
        loading = true; error = ""
        try {
            val page = AvatarGallery.page(context, beforeId)
            photos = photos + page.photos
            beforeId = page.photos.lastOrNull()?.id ?: beforeId
            more = page.hasMore
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = "Не удалось прочитать фото. Проверьте доступ к галерее или воспользуйтесь системным выбором." }
        finally { loading = false }
    }
    LaunchedEffect(grid, photos.size, loading, more, error) {
        if (!loading && more && error.isBlank() && photos.isNotEmpty()) {
            // Страница вперёд на восемь рядов: к нижнему краю новые фото уже готовы.
            snapshotFlow { (grid.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1) >= photos.size - 24 }.first { it }
            request++
        }
    }
    Column(modifier.fillMaxWidth()) {
        if (error.isNotBlank()) Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(error, color = p.subtext, modifier = Modifier.weight(1f))
            TextButton(onClick = { if (!loading) request++ }) { Text("Повторить") }
        }
        if ((loading || !active) && photos.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = p.brand) }
        else if (photos.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth().padding(22.dp), contentAlignment = Alignment.Center) {
            Text("Доступных фото пока нет. Можно выбрать фотографию через «Другие фото / файлы».", color = p.subtext)
        } else LazyVerticalGrid(columns = GridCells.Fixed(3), state = grid, modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(photos, key = { it.id }, contentType = { "photo" }) { photo ->
                val bitmap by produceState(thumbnails.cached(photo.uri), photo.uri) {
                    if (value == null) {
                        try { value = thumbnails.load(context, photo.uri) }
                        catch (e: CancellationException) { throw e }
                        catch (_: Exception) { /* Removed/revoked image: retain a tappable placeholder. */ }
                    }
                }
                Box(Modifier.fillMaxWidth().aspectRatio(1f).background(p.chip).combinedClickable(
                    role = Role.Button, onClickLabel = "Выбрать фото", onLongClickLabel = "Просмотреть фото",
                    onClick = { onPick(photo.uri) }, onLongClick = { preview = photo.uri }), contentAlignment = Alignment.Center) {
                    val current = bitmap
                    if (current != null) Image(current.asImageBitmap(), "Фото", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(ZiziIcons.ViewGrid, "Фото недоступно", tint = p.subtext)
                }
            }
        }
        // Полоса подгрузки занимает своё место всегда: сетка не подпрыгивает на каждой странице.
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (loading && photos.isNotEmpty()) LinearProgressIndicator(
                Modifier.fillMaxWidth().height(3.dp), color = p.brand, trackColor = p.chip)
        }
    }
    preview?.let { uri -> GalleryPhotoPreview(uri, onDismiss = { preview = null }, onSelect = { preview = null; onPick(uri) }) }
}
