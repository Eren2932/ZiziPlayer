package app.ziziplayer.data.remote;

/** Public audio origin migration. Never changes custom hosts, prefixes or credentials. */
public final class ResolverEndpoint {
    public static final String DEFAULT_URL = "https://ziziplayer-audio.duckdns.org";
    private ResolverEndpoint() {}

    public static String effective(String saved, String baked) {
        String selected = clean(saved);
        if (selected.isEmpty()) selected = clean(baked);
        if (selected.isEmpty() || selected.equals("147.45.166.244:8080")
                || selected.equals("http://147.45.166.244:8080")
                || selected.equals("http://ziziplayer-audio.duckdns.org")) {
            return DEFAULT_URL;
        }
        return selected;
    }

    private static String clean(String value) {
        if (value == null) return "";
        String result = value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }
}
