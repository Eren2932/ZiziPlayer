package app.ziziplayer.lyrics;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Line and optional word media timestamps, never wall-clock time. No Android dependencies. */
public final class LrcTimeline {
    private LrcTimeline() {}
    public static final int MAX_CHARS = 512 * 1024;
    public static final int MAX_LINES = 10000;
    public static final int MAX_WORDS = 50000;
    private static final Pattern TIME = Pattern.compile("\\[(\\d{1,3}):([0-5]\\d)(?:[.:](\\d{1,3}))?\\]");
    private static final Pattern OFFSET = Pattern.compile("(?im)^\\s*\\[offset:([+-]?\\d{1,8})\\]\\s*$");
    private static final Pattern WORD_TIME = Pattern.compile("<(\\d{1,3}):([0-5]\\d)(?:[.:](\\d{1,3}))?>");
    public static final class Word {
        public final long timeMs;
        public final int start, end;
        public Word(long timeMs, int start, int end) {
            this.timeMs = timeMs; this.start = start; this.end = end;
        }
    }
    public static final class Line {
        public final long timeMs;
        public final String text;
        public final List<Word> words;
        public Line(long timeMs, String text) { this(timeMs, text, Collections.emptyList()); }
        public Line(long timeMs, String text, List<Word> words) {
            this.timeMs = timeMs; this.text = text;
            this.words = Collections.unmodifiableList(new ArrayList<>(words));
        }
    }
    public static List<Line> parse(String source) {
        if (source == null || source.isEmpty()) return Collections.emptyList();
        if (source.length() > MAX_CHARS) throw new IllegalArgumentException("LRC too large");
        source = source.replace("\ufeff", "");
        long offset = 0;
        Matcher om = OFFSET.matcher(source);
        while (om.find()) offset = Long.parseLong(om.group(1));
        TreeMap<Long, Line> sorted = new TreeMap<>();
        int count = 0, wordCount = 0;
        for (String raw : source.split("\\r?\\n")) {
            Matcher m = TIME.matcher(raw);
            List<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                // A timestamp in the middle of prose is not a new timed line.
                if (!raw.substring(end, m.start()).trim().isEmpty()) break;
                String fraction = m.group(3);
                long millis = fraction == null ? 0 : Long.parseLong((fraction + "000").substring(0, 3));
                long t = Long.parseLong(m.group(1)) * 60000 + Long.parseLong(m.group(2)) * 1000 + millis;
                // LRC positive offset means display earlier: cue time = stamp - offset.
                stamps.add(Math.max(0, t - offset));
                end = m.end();
                if (++count > MAX_LINES) throw new IllegalArgumentException("Too many LRC cues");
            }
            if (stamps.isEmpty()) continue;
            String payload = raw.substring(end).trim();
            String text = WORD_TIME.matcher(payload).replaceAll("");
            // Multiple line tags repeat the same phrase: shift real word stamps by the cue delta.
            List<Word> words = parseWords(payload, offset, stamps.get(0));
            if ((long) wordCount + (long) words.size() * stamps.size() > MAX_WORDS)
                throw new IllegalArgumentException("Too many enhanced LRC words");
            wordCount += words.size() * stamps.size();
            for (long t : stamps) {
                List<Word> shifted = new ArrayList<>();
                for (Word w : words) shifted.add(new Word(w.timeMs + t - stamps.get(0), w.start, w.end));
                Line next = new Line(t, text, shifted);
                Line previous = sorted.get(t);
                if (previous == null || previous.text.isEmpty()) sorted.put(t, next);
                else if (!text.isEmpty() && !previous.text.equals(text))
                    // Translation / duet at one time: retain prose, not ambiguous word highlighting.
                    sorted.put(t, new Line(t, previous.text + "\n" + text));
            }
        }
        List<Line> result = new ArrayList<>(sorted.values());
        for (int i = 0; i + 1 < result.size(); i++) {
            Line line = result.get(i);
            if (!line.words.isEmpty() && line.words.get(line.words.size() - 1).timeMs >= result.get(i + 1).timeMs)
                result.set(i, new Line(line.timeMs, line.text));
        }
        return Collections.unmodifiableList(result);
    }
    private static List<Word> parseWords(String payload, long offset, long cue) {
        Matcher m = WORD_TIME.matcher(payload);
        List<Word> words = new ArrayList<>();
        int rawEnd = 0, length = 0, start = 0;
        long time = -1;
        boolean valid = true;
        while (m.find()) {
            String segment = payload.substring(rawEnd, m.start());
            length += segment.length();
            if (time >= 0 && length > start && !segment.trim().isEmpty())
                words.add(new Word(time, start, length));
            else if (time < 0 && !segment.trim().isEmpty()) valid = false;
            String fraction = m.group(3);
            long next = Math.max(0, Long.parseLong(m.group(1)) * 60000 + Long.parseLong(m.group(2)) * 1000
                + (fraction == null ? 0 : Long.parseLong((fraction + "000").substring(0, 3))) - offset);
            if (next < cue || next < time) valid = false;
            time = next; start = length; rawEnd = m.end();
        }
        String tail = payload.substring(rawEnd);
        if (time >= 0 && !tail.trim().isEmpty()) words.add(new Word(time, start, length + tail.length()));
        return valid ? words : Collections.emptyList();
    }
    /** No interpolation of invented word boundaries: enhanced-LRC timestamps only. */
    public static int activeWord(Line line, long mediaMs, long advanceMs) {
        long position = Math.max(0, mediaMs) + Math.max(-60000, Math.min(60000, advanceMs));
        int lo = 0, hi = line.words.size();
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (line.words.get(mid).timeMs <= position) lo = mid + 1; else hi = mid;
        }
        return lo - 1;
    }
    /** Last cue <= media position + user advance; -1 before the first cue. O(log n). */
    public static int activeIndex(List<Line> lines, long mediaMs, long advanceMs) {
        long position = Math.max(0, mediaMs) + Math.max(-60000, Math.min(60000, advanceMs));
        int lo = 0, hi = lines.size();
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs <= position) lo = mid + 1; else hi = mid;
        }
        return lo - 1;
    }
    public static long seekPosition(Line line, long advanceMs) {
        return Math.max(0, line.timeMs - Math.max(-60000, Math.min(60000, advanceMs)));
    }
    public static boolean durationMatches(long expectedMs, long actualMs) {
        return expectedMs > 0 && actualMs > 0 && Math.abs(expectedMs - actualMs) <= 2000;
    }
    private static String normalized(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFKC)
            .replaceAll("[\\p{P}\\p{S}]", " ").trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }
    /** Deliberately do not remove slowed/remix/live qualifiers or infer a different artist. */
    public static boolean identityMatches(String title, String artist, String candidateTitle, String candidateArtist) {
        return !normalized(title).isEmpty() && !normalized(artist).isEmpty()
            && normalized(title).equals(normalized(candidateTitle))
            && normalized(artist).equals(normalized(candidateArtist));
    }
}
