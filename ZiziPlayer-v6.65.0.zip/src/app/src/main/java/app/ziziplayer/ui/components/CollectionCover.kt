package app.ziziplayer.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.theme.ArtworkColorMath

/** Image and tint come from ONE decoded artwork, never from the playback queue. */
@Immutable
internal data class CollectionCover(val art: Art?, val tint: Color)

@Composable
internal fun rememberCollectionCover(track: TrackEntity? = null, url: String? = null): CollectionCover {
    val art = if (!url.isNullOrBlank()) rememberUrlArtwork(url, 640)
        else rememberArtwork(track, 640, allowSlow = true)
    val tint = art?.swatches?.primary?.let { Color(ArtworkColorMath.coverTop(it.toArgb())) }
        ?: Color(0xFF292929)
    return CollectionCover(art, tint)
}

@Composable
internal fun CollectionCoverImage(cover: CollectionCover, modifier: Modifier = Modifier) {
    Box(modifier.background(Color(0xFF292929)), contentAlignment = Alignment.Center) {
        val art = cover.art
        if (art != null) Image(bitmap = art.image, contentDescription = null,
            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(ZiziIcons.Queue, null, tint = Color(0xFF8C8C8C), modifier = Modifier.size(48.dp))
    }
}
