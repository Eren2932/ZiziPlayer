package app.ziziplayer.account

import android.Manifest
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Connect coroutine cancellation to the provider call, without adding a worker thread pool. */
private suspend fun <T> mediaCall(block: (CancellationSignal) -> T): T = withContext(Dispatchers.IO) {
    suspendCancellableCoroutine { continuation ->
        val signal = CancellationSignal()
        continuation.invokeOnCancellation { signal.cancel() }
        try { continuation.resumeWith(Result.success(block(signal))) }
        catch (e: Exception) { continuation.resumeWith(Result.failure(e)) }
    }
}

data class GalleryPhoto(val id: Long, val uri: Uri)
data class GalleryPage(val photos: List<GalleryPhoto>, val hasMore: Boolean)

/** No observer/service and no scan on startup. Exists only while the avatar sheet is mounted. */
object AvatarGallery {
    const val PAGE_SIZE = 90
    fun permissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    fun hasAccess(context: Context): Boolean = permissions().any { granted(context, it) }
    fun limited(context: Context): Boolean = Build.VERSION.SDK_INT >= 34 &&
        !granted(context, Manifest.permission.READ_MEDIA_IMAGES) && granted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)

    const val NONE = "none"
    const val LIMITED = "limited"
    const val FULL = "full"

    /**
     * Состояние доступа одной строкой и без запросов к провайдеру: дешёвая проверка прав.
     * Лист пересобирает сессию только при смене этой строки, а не на каждый ON_RESUME —
     * иначе после выдачи разрешения галерея перезагружалась дважды и заметно дёргалась.
     */
    fun signature(context: Context): String = when {
        !hasAccess(context) -> NONE
        limited(context) -> LIMITED
        else -> FULL
    }

    /** Keyset paging, not OFFSET: work does not grow with the number of pages already viewed. */
    suspend fun page(context: Context, beforeId: Long?): GalleryPage = withContext(Dispatchers.IO) {
        val job = currentCoroutineContext()
        job.ensureActive()
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.Images.Media._ID} DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, PAGE_SIZE)
            if (beforeId != null) {
                putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${MediaStore.Images.Media._ID} < ?")
                putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf(beforeId.toString()))
            }
        }
        mediaCall { signal ->
            val photos = ArrayList<GalleryPhoto>(PAGE_SIZE)
            val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val cursor = context.contentResolver.query(collection, arrayOf(MediaStore.Images.Media._ID), args, signal)
                ?: error("Не удалось прочитать галерею")
            cursor.use {
                val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                // Some OEM providers ignore QUERY_ARG_LIMIT. Never materialise their entire cursor.
                while (photos.size < PAGE_SIZE && it.moveToNext()) {
                    job.ensureActive()
                    val id = it.getLong(idColumn)
                    photos.add(GalleryPhoto(id, ContentUris.withAppendedId(collection, id)))
                }
            }
            GalleryPage(photos, photos.size == PAGE_SIZE)
        }
    }
}

/** Per-sheet LRU, max 8 MiB + visible cell references; at most four decodes in flight.
 * Четыре дорожки вместо двух: сетка из трёх колонок заполняется за меньшее число волн,
 * а потолок памяти остаётся тем же (LRU 8 MiB). */
class GalleryThumbnails {
    private val lane = Semaphore(4)
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount
    }
    fun cached(uri: Uri): Bitmap? = cache.get(uri.toString())
    suspend fun load(context: Context, uri: Uri): Bitmap = lane.withPermit {
        cached(uri) ?: withContext(Dispatchers.IO) {
            currentCoroutineContext().ensureActive()
            val bitmap = if (Build.VERSION.SDK_INT >= 29) {
                mediaCall { signal -> context.contentResolver.loadThumbnail(uri, Size(256, 256), signal) }
            } else {
                val resolver = context.contentResolver
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                require(options.outWidth in 1..16000 && options.outHeight in 1..16000)
                options.inJustDecodeBounds = false
                var sample = 1
                while ((maxOf(options.outWidth, options.outHeight) + sample - 1) / sample > 256) sample *= 2
                options.inSampleSize = sample
                options.inPreferredConfig = Bitmap.Config.ARGB_8888
                val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                    ?: error("Нет доступа к фото")
                val orientation = runCatching {
                    resolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
                }.getOrDefault(1)
                AvatarImage.orient(raw, orientation)
            }
            currentCoroutineContext().ensureActive()
            cache.put(uri.toString(), bitmap)
            bitmap
        }
    }
}
