package app.ziziplayer.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.ziziplayer.account.AvatarCropGeometry
import app.ziziplayer.account.AvatarImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private class CropGesturePose(var value: AvatarCropGeometry.Pose)

/** Fullscreen local draft editor. No server write occurs until AccountEditScreen saves. */
@Composable
internal fun AvatarCropScreen(uri: Uri, onCancel: () -> Unit, onCropped: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri) { mutableStateOf("") }
    var working by remember(uri) { mutableStateOf(false) }
    // Save only a few numbers, never photo bytes in a Bundle. Pose units survive size changes.
    var zoom by rememberSaveable(uri.toString()) { mutableFloatStateOf(1f) }
    var x by rememberSaveable(uri.toString()) { mutableFloatStateOf(0f) }
    var y by rememberSaveable(uri.toString()) { mutableFloatStateOf(0f) }
    val pose = AvatarCropGeometry.Pose(zoom, x, y)
    val update: (AvatarCropGeometry.Pose) -> Unit = { zoom = it.zoom; x = it.x; y = it.y }
    LaunchedEffect(uri) {
        try { bitmap = AvatarImage.decode(context, uri) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = e.message ?: "Не удалось открыть фото" }
    }
    Dialog(onDismissRequest = { if (!working) onCancel() }, properties = DialogProperties(
        usePlatformDefaultWidth = false, decorFitsSystemWindows = false, dismissOnClickOutside = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding()) {
            Row(Modifier.fillMaxWidth().heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onCancel, enabled = !working) { Text("Отмена", color = Color.White) }
                Text("Обрезать фото", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                TextButton(enabled = bitmap != null && !working, onClick = {
                    val source = bitmap
                    if (source != null && !working) {
                        // Set synchronously: two taps cannot enqueue two encodes/saves.
                        working = true; error = ""
                        scope.launch {
                            try { onCropped(AvatarImage.encodeCrop(source, pose)) }
                            catch (e: CancellationException) { throw e }
                            catch (e: Exception) { error = e.message ?: "Не удалось обработать фото" }
                            finally { working = false }
                        }
                    }
                }) { Text("Готово", color = if (bitmap != null && !working) Color.White else Color.Gray) }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                val current = bitmap
                if (current != null) {
                    val side = minOf(maxWidth, maxHeight)
                    AvatarCropViewport(current, pose, enabled = !working, onPose = update, modifier = Modifier.size(side))
                } else if (error.isBlank()) CircularProgressIndicator(color = Color.White)
            }
            if (working) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color.White)
            Text(error.ifBlank { "Раздвиньте пальцы, чтобы приблизить. Перемещайте фото внутри рамки." },
                color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(20.dp))
        }
    }
}

@Composable
internal fun AvatarCropViewport(bitmap: Bitmap, pose: AvatarCropGeometry.Pose, enabled: Boolean,
    onPose: (AvatarCropGeometry.Pose) -> Unit, modifier: Modifier = Modifier) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    val gestureState = remember(bitmap) { CropGesturePose(pose) }
    SideEffect { gestureState.value = pose }
    val currentUpdate by rememberUpdatedState(onPose)
    val currentEnabled by rememberUpdatedState(enabled)
    Canvas(modifier.testTag("avatar-crop").semantics {
        contentDescription = "Кадрирование аватарки: перемещение и масштаб"
        customActions = if (enabled) listOf(
            CustomAccessibilityAction("Увеличить") { onPose(AvatarCropGeometry.gesture(bitmap.width, bitmap.height, pose, 1.25f, 0f, 0f, 0f, 0f)); true },
            CustomAccessibilityAction("Уменьшить") { onPose(AvatarCropGeometry.gesture(bitmap.width, bitmap.height, pose, 0.8f, 0f, 0f, 0f, 0f)); true },
            CustomAccessibilityAction("По центру") { onPose(AvatarCropGeometry.initial()); true }
        ) else emptyList()
    }.pointerInput(bitmap) {
        // Keys do not include pose: changing zoom must NOT restart the active gesture detector.
        // Keep a synchronous local pose too: multiple pointer events can precede recomposition.
        detectTransformGestures { centroid, pan, change, _ ->
            if (currentEnabled && size.width > 0) {
                val unit = size.width.toFloat()
                val gesturePose = AvatarCropGeometry.gesture(bitmap.width, bitmap.height, gestureState.value, change,
                    pan.x / unit, pan.y / unit, centroid.x / unit - 0.5f, centroid.y / unit - 0.5f)
                gestureState.value = gesturePose
                currentUpdate(gesturePose)
            }
        }
    }) {
        val crop = AvatarCropGeometry.crop(bitmap.width, bitmap.height, pose)
        val imageScale = size.width / crop.side
        clipRect {
            withTransform({
                scale(imageScale, imageScale, pivot = Offset.Zero)
                translate(-crop.left, -crop.top)
            }) { drawImage(image) }
        }
        // Square export + round avatar guide, not a destructive circular crop.
        val mask = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(Offset.Zero, size))
            addOval(Rect(Offset.Zero, size))
        }
        drawPath(mask, Color.Black.copy(alpha = 0.48f))
        for (i in 1..2) {
            val at = size.width * i / 3f
            drawLine(Color.White.copy(alpha = 0.24f), Offset(at, 0f), Offset(at, size.height), 1.dp.toPx())
            drawLine(Color.White.copy(alpha = 0.24f), Offset(0f, at), Offset(size.width, at), 1.dp.toPx())
        }
        drawRect(Color.White.copy(alpha = 0.85f), style = Stroke(1.dp.toPx()))
        drawCircle(Color.White.copy(alpha = 0.7f), radius = size.minDimension / 2f, style = Stroke(1.dp.toPx()))
    }
}
