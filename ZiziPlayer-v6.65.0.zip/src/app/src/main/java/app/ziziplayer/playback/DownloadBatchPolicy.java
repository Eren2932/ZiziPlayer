package app.ziziplayer.playback;

import java.util.HashMap;
import java.util.Map;

/** Cancellation of a collection must also cover members not enqueued yet.
 * A new explicit request may retry; a stale producer may never revive a cancelled batch.
 * All methods are synchronized so enqueueing and UI cancellation can run on different threads.
 */
public final class DownloadBatchPolicy {
    private long clock;
    private long cancelledAll;
    private final Map<String, Long> cancelledTracks = new HashMap<>();
    public synchronized long newRequest() { return ++clock; }
    public synchronized void cancel(String id) { cancelledTracks.put(id, ++clock); }
    public synchronized void cancelAll() { cancelledAll = ++clock; }
    public synchronized boolean mayStart(String id, long request) {
        return request > cancelledAll && request > cancelledTracks.getOrDefault(id, 0L);
    }
}
