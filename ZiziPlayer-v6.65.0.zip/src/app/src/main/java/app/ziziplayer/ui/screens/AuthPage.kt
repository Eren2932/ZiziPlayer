package app.ziziplayer.ui.screens

internal enum class AuthPage {
    LoginEmail, RegisterEmail, LoginPassword, RegisterPassword, Verify, Forgot, Reset;
    val emailEntry: Boolean get() = this == LoginEmail || this == RegisterEmail
}

internal enum class AuthFlow { Login, Register, Recovery }
internal data class AuthStep(val page: AuthPage, val flow: AuthFlow)

/** Direction belongs to the accepted transaction, never to mutable shared UI state. */
internal data class AuthRoute(val step: AuthStep, val backwards: Boolean = false, val revision: Long = 0)
