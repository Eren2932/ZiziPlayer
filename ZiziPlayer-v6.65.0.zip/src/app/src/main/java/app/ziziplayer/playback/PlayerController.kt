package app.ziziplayer.playback

import app.ziziplayer.data.remote.CatalogPolicy
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.session.SessionCommand
import app.ziziplayer.playback.dsp.DspCodec
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.ZiziResolve
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlin.math.absoluteValue

/**
 * Structural playback state. Deliberately WITHOUT position:
 * position changes several times per second and would invalidate every consumer of this state.
 * Position lives in [PlayerController.progress] so that only the seek bar reacts to it.
 */
@androidx.compose.runtime.Immutable
data class PlaybackState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentIndex: Int = 0,
    val currentTrackId: String? = null,
    val queueIds: List<String> = emptyList(),
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val sleepMinutesLeft: Int? = null,
    /** Network tracks spend real time loading; the transport controls have to show it. */
    val isBuffering: Boolean = false,
    /** Last playback failure, ready to show. Cleared by [PlayerController.clearError]. */
    val error: String? = null,
    /** Raw loading signal for background metadata: unlike the UI spinner, includes paused buffering. */
    val isLoadingAudio: Boolean = true,
    /** Origin of the active queue, not membership of the current track in a shelf. */
    val queueSourceId: String? = null
)

/** Position stream, updated only while playing and only while the UI is on screen. */
/**
 * [bufferedMs] — 6.26.1. Серверная часть тракта буфер и так наполняла, просто наружу его никто не
 * отдавал, поэтому клиент не мог показать загрузку. Поле живёт здесь, а не в состоянии плеера:
 * оно меняется с той же частотой, что позиция, и в [PlaybackUiState] заставляло бы перерисовывать
 * весь экран вместо одной полосы.
 */
/**
 * 6.32.0. У показания ПОЯВИЛСЯ ВЛАДЕЛЕЦ — [trackId].
 *
 * До этого поток позиции был безымянным: три числа без указания того, о каком треке они
 * говорят. Любой потребитель был вынужден считать, что позиция относится к тому треку,
 * который он видел последним, а это неправда ровно в тот момент, когда трек сменился, —
 * то есть именно тогда, когда ошибка заметна. Отсюда весь букет: ползунок на новом треке
 * показывал место, оставленное на прошлом; перемотка, поданная за миг до автоперехода,
 * ложилась на новый трек; резервное сохранение позиции писало чужое время в базу.
 *
 * Идентификатор снимает класс ошибок целиком, а не конкретный случай: сравнение
 * `progress.trackId != мой трек` — это одно условие, которое нельзя проиграть по времени.
 */
data class Progress(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedMs: Long = 0L,
    val trackId: String? = null
)

@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {

    private companion object {
        /** Seeking closer than this to the end makes ExoPlayer treat the track as finished. */
        const val END_GUARD_MS = 1200L
        /** Consecutive failed remote tracks before we stop skipping and report it. */
        const val MAX_AUTO_SKIPS = 3
        /** How long a fresh seek target wins over the session's own (lagging) reports. */
        const val SEEK_LATCH_MS = 4000L
        const val SEEK_LATCH_TOLERANCE_MS = 150L
        /** Окно, в котором ошибка потока считается следствием перемотки, а не смерти трека. */
        const val SEEK_RETRY_WINDOW_MS = 7000L
        /** Столько раз источник пересобирается на месте, прежде чем ошибка считается настоящей. */
        const val MAX_SEEK_RETRIES = 2
        const val TICK_MS = 250L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingQueue: PendingQueue? = null
    private var sleepJob: Job? = null
    private var tickerJob: Job? = null
    private var sleepEndAtMs: Long? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress
    private val _connected = MutableStateFlow(false)

    /** Cached queue ids: rebuilt only when the timeline actually changes, never on every tick. */
    private var cachedQueueIds: List<String> = emptyList()
    // 6.10.1: track uris in queue order, kept only to warm the resolver for what plays next.
    private var queueUris: List<String> = emptyList()
    private var uiActive = false
    private var lyricsClockUsers = 0
    /** Lease from the visible lyrics UI; still no polling while Activity is stopped. */
    fun retainLyricsClock(): () -> Unit {
        lyricsClockUsers++
        var released = false
        return {
            if (!released) { released = true; lyricsClockUsers = (lyricsClockUsers - 1).coerceAtLeast(0) }
        }
    }
    private var queueEpoch = 0
    private var prefetchJob: Job? = null
    private var prefetchOwner: Pair<Int, String>? = null

    /**
     * Duration taken from our own database, keyed by media id.
     *
     * Right after a track change the session reports an unknown duration. v4 published that as 0,
     * so the seek bar computed its fraction against a one millisecond track: dragging anywhere
     * jumped to the very end, and a seek past the end made ExoPlayer skip to the next track.
     * That is exactly the "slider glitches and switches tracks" bug.
     */
    private var knownDurations: Map<String, Long> = emptyMap()

    private var seekTargetMs = 0L
    private var latchUntilMs = 0L
    /**
     * 6.31.0. Перемотка, поданная РАНЬШЕ, чем элемент стал перематываемым.
     *
     * Тап по дорожке в первую же секунду трека приходил в плеер, который ещё стоит в
     * STATE_BUFFERING: таймлайн пуст, длительность неизвестна, окно не помечено seekable.
     * Media3 такой seek не выполняет и не отвергает — он остаётся висеть, а поток при этом
     * уже открыт с нулевого смещения. Результат ровно тот, который описал человек: звук
     * пропадает и не возвращается даже при перемотке в начало, лечит только перезапуск трека.
     * Теперь цель запоминается и применяется на первом STATE_READY.
     */
    private var pendingSeekMs: Long? = null
    private var lastSeekAtMs = 0L
    /**
     * 6.32.0. Трек, которому принадлежит перемотка.
     *
     * Перемотка живёт дольше одного кадра: цель ставится по жесту, а исполняется на первом
     * STATE_READY, иногда через секунду. За эту секунду трек может смениться сам (автопереход,
     * ошибка потока, свайп по карусели). Без владельца отложенная цель прикладывалась к тому,
     * что играет СЕЙЧАС, и человека уносило: перемотал в начале трека — оказался на следующем,
     * на том же самом месте. Цель без своего трека недействительна.
     */
    private var seekTrackId: String? = null
    /** Сколько раз мы уже пересобирали источник после перемотки на текущем элементе. */
    private var seekRetries = 0

    private data class PendingQueue(val tracks: List<TrackEntity>, val index: Int, val play: Boolean, val positionMs: Long, val sourceId: String? = null)

    private var lastError: String? = null
    private var consecutiveErrors = 0

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) { handlePlayerError(error) }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // 6.32.0. СЧЁТЧИК АВТОПРОПУСКОВ БОЛЬШЕ НЕ ОБНУЛЯЕТСЯ ЗДЕСЬ.
            //
            // Это и был механизм «уносит через всю очередь». Ограничитель MAX_AUTO_SKIPS = 3
            // существовал, но не работал ни разу: автопропуск сам вызывает смену элемента, и
            // первым делом эта смена ставила счётчик обратно в ноль. То есть каждый пропуск
            // разрешал следующий, и на плохой сети очередь пролистывалась до конца на полной
            // скорости, а человек видел «перекинуло на следующий, потом ещё, потом ещё».
            //
            // Ноль означает не «трек сменился», а «музыка ЗАИГРАЛА»: счётчик снимается на
            // STATE_READY в onEvents. Смена элемента при этом по-прежнему гасит устаревшую
            // жалобу на экране — она относилась к прошлому треку.
            if (lastError != null) { lastError = null; publish() }
            StartupTrace.mark(StartupTrace.Stage.ITEM_CHANGED)
            // Prefetch is scheduled by onEvents only AFTER this item actually starts playing.
        }

        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_TIMELINE_CHANGED)) invalidateQueue()
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && player.isPlaying)
                StartupTrace.mark(StartupTrace.Stage.AUDIO_PLAYING)
            // A new track invalidates any pending seek target immediately.
            // Новый трек обнуляет ВСЁ, что относилось к перемотке предыдущего: защёлку, цель,
            // владельца цели и счётчик попыток. 6.31.0 сбрасывал только первые два, поэтому
            // seekTargetMs оставался жить и защёлка, включённая чуть позже, поднимала на новом
            // треке позицию прошлого.
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                latchUntilMs = 0L
                pendingSeekMs = null
                seekTargetMs = 0L
                seekTrackId = null
                seekRetries = 0
            }
            // Трек доехал до готовности — значит и перемотка удалась, и очередь жива.
            // Только это и есть доказательство, что предыдущие пропуски были частным случаем,
            // а не началом обвала.
            if (player.playbackState == Player.STATE_READY) {
                seekRetries = 0
                consecutiveErrors = 0
            }
            publish()
            if (events.contains(Player.EVENT_POSITION_DISCONTINUITY) ||
                events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                events.contains(Player.EVENT_IS_PLAYING_CHANGED) ||
                events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED)
            ) publishProgress()
            // 6.31.0: элемент мог стать перематываемым только сейчас — самое время исполнить
            // перемотку, которую человек попросил секунду назад.
            applyPendingSeek()
            syncTicker()
            schedulePrefetch()
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync().also { f ->
            f.addListener({
                runCatching { f.get() }.onSuccess { c ->
                    controller = c
                    c.addListener(listener)
                    pendingQueue?.also { q -> pendingQueue = null; setQueue(q.tracks, q.index, q.play, q.positionMs, q.sourceId) }
                    invalidateQueue(); publish(); publishProgress(); syncTicker()
                    // Сервис мог подняться заново и потерять тракт — возвращаем его на место.
                    if (lastDsp != DspConfig.NEUTRAL) pushDsp()
                    _connected.value = true
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }

    /** Suspends until the session is bound. Callers that inspect the live queue must await this. */
    suspend fun awaitConnected() { _connected.first { it } }

    /** True when a session is already playing something: restoring over it would rewind the user. */
    fun hasQueue(): Boolean = (controller?.mediaItemCount ?: 0) > 0

    /** Called from the Activity lifecycle: no polling at all while the UI is not visible. */
    fun setUiActive(active: Boolean) {
        if (uiActive == active) return
        uiActive = active
        if (active) { publish(); publishProgress() }
        syncTicker()
    }

    private fun syncTicker() {
        // 6.32.0. Тикаем и во время буферизации: после перемотки в потоке плеер стоит в
        // STATE_BUFFERING с playWhenReady, позиция не растёт, зато растёт буфер — а показывать
        // его было нечем, опрос запускался только по факту игры. Именно так теневая полоса
        // «замерзала» ровно в тот момент, когда она нужнее всего.
        val shouldTick = uiActive && (_state.value.isPlaying || _state.value.isBuffering)
        if (shouldTick) {
            if (tickerJob?.isActive == true) return
            tickerJob = scope.launch {
                while (isActive) { delay(if (lyricsClockUsers > 0 && !_state.value.isLoadingAudio) 33L else TICK_MS); publishProgress(); publishSleep() }
            }
        } else {
            tickerJob?.cancel(); tickerJob = null
        }
    }

    private fun invalidateQueue() {
        val p = controller ?: return
        cachedQueueIds = ArrayList<String>(p.mediaItemCount).apply {
            for (i in 0 until p.mediaItemCount) add(p.getMediaItemAt(i).mediaId)
        }
    }

    /** Dismisses the current error banner. */
    fun clearError() { if (lastError != null) { lastError = null; publish() } }

    /**
     * Playback errors, which barely existed while this was a local player.
     *
     * A local file fails once in a blue moon and usually stays failed. A network track fails
     * routinely and for reasons that are none of the user's business: a stale link, a track pulled
     * from the catalogue, a gap in coverage. Two rules come out of that:
     *
     *  - a dead REMOTE track must not stop the queue - it skips, the way a scratched CD track does,
     *    because stopping means the user has to pick up the phone to keep the music going;
     *  - a dead LOCAL file must NOT auto-skip - that would silently walk through a whole broken
     *    folder and leave the user staring at the last track with no idea what happened.
     *
     * The skip counter is the guard against the ugly case: a queue where everything fails would
     * otherwise race to the end at full speed. Three in a row and we stop and say so.
     */
    private fun handlePlayerError(error: PlaybackException) {
        val p = controller
        // mediaId, not the URI: Media3 strips localConfiguration from items handed to a controller,
        // so currentMediaItem.localConfiguration is null on this side of the session.
        val remote = p?.currentMediaItem?.mediaId?.startsWith("r:") == true
        // 6.31.0. Ошибка сразу после перемотки — это не «трек умер», это оборванный Range.
        //
        // Прокси отдаёт байты по мере скачивания, и запрос на смещение, которого на диске ещё
        // нет, приходит с пустым телом. Media3 считает это фатальной ошибкой источника и
        // останавливается совсем: звука нет даже при возврате в начало. Раньше мы в этом месте
        // уходили на следующий трек, что человек и видел как «сломался и не лечится».
        // Правильная реакция — пересобрать источник на том же элементе и встать на цель.
        val sinceSeek = SystemClock.elapsedRealtime() - lastSeekAtMs
        // 6.32.0. Окно 2.5 с было замерено на локальном файле и не подходит потоку: новый
        // Range-запрос к прокси, который ещё сам скачивает трек, отваливается позже — 3-5 с
        // после жеста. Ошибка приходила ЗА окном, и код уходил в ветку «трек умер», то есть
        // перескакивал вперёд, а с consecutiveErrors до трёх — через три трека подряд. Это и
        // есть «меня перекидывает дальше и дальше». Окно 7 с, но попыток на элемент — две,
        // иначе действительно мёртвый трек будет пересобираться бесконечно.
        if (p != null && sinceSeek < SEEK_RETRY_WINDOW_MS && seekRetries < MAX_SEEK_RETRIES) {
            seekRetries++
            val target = seekTargetMs
            lastError = null
            publish()
            p.prepare()
            p.seekTo(target)
            p.play()
            latchUntilMs = SystemClock.elapsedRealtime() + SEEK_LATCH_MS
            publishProgress()
            return
        }
        lastError = describe(error, remote)
        consecutiveErrors++
        publish()
        if (remote && consecutiveErrors <= MAX_AUTO_SKIPS && p != null && p.hasNextMediaItem()) {
            p.seekToNextMediaItem()
            p.prepare()
            p.play()
        }
    }

    private fun describe(error: PlaybackException, remote: Boolean): String = when (error.errorCode) {
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Нет соединения"
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
        PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ->
            if (remote) "Трек недоступен" else "Источник недоступен"
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
            if (remote) "Трек недоступен" else "Файл не найден"
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
            "Формат не поддерживается"
        else -> generateSequence(error.cause) { it.cause }.lastOrNull()
            ?.message?.takeIf { it.isNotBlank() && it.length <= 120 }
            ?: "Ошибка воспроизведения"
    }

    private fun publish() {
        val p = controller ?: return
        // playWhenReady instead of isPlaying: the icon must not flicker while the player buffers after a seek
        val playing = p.playWhenReady && p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        val next = PlaybackState(
            connected = true,
            isPlaying = playing,
            currentIndex = p.currentMediaItemIndex.coerceAtLeast(0),
            currentTrackId = p.currentMediaItem?.mediaId,
            queueIds = cachedQueueIds,
            queueSourceId = p.currentMediaItem?.mediaMetadata?.extras?.getString("zizi.queueSource"),
            shuffle = p.shuffleModeEnabled,
            repeatMode = p.repeatMode,
            sleepMinutesLeft = minutesLeft(),
            // playWhenReady is part of the condition on purpose: a paused player that is filling
            // its buffer is not something the user needs a spinner for.
            isBuffering = p.playbackState == Player.STATE_BUFFERING && p.playWhenReady,
            error = lastError,
            isLoadingAudio = p.playbackState == Player.STATE_BUFFERING ||
                (p.playWhenReady && p.playbackState == Player.STATE_IDLE)
        )
        if (next.isLoadingAudio != _state.value.isLoadingAudio) {
            StartupTrace.mark(if (next.isLoadingAudio) StartupTrace.Stage.AUDIO_LOADING else StartupTrace.Stage.AUDIO_PREPARED)
        }
        if (next != _state.value) _state.value = next
    }

    /** Session duration when it is known, our own metadata otherwise. Never zero for a real track. */
    private fun durationOf(p: MediaController): Long {
        val reported = p.duration
        if (reported > 0L) return reported
        val id = p.currentMediaItem?.mediaId ?: return 0L
        return knownDurations[id] ?: 0L
    }

    private fun publishProgress() {
        val p = controller ?: return
        val duration = durationOf(p)
        val trackId = p.currentMediaItem?.mediaId
        // Цель перемотки действительна только для своего трека. Проверка стоит ЗДЕСЬ, а не
        // только в обработчике смены элемента: смена могла произойти без события (перезапуск
        // сессии, восстановление очереди), и защёлка не должна пережить её ни при каком пути.
        if (seekTrackId != null && seekTrackId != trackId) {
            seekTrackId = null
            pendingSeekMs = null
            latchUntilMs = 0L
            seekTargetMs = 0L
        }
        val reported = p.currentPosition.coerceAtLeast(0L)
        // While latched the freshly seeked target wins, so the thumb never snaps back.
        //
        // 6.31.0. Допуск был 700 мс, и это и есть тот самый «дёргается туда-сюда»: сессия
        // отдавала позицию в полусекунде от цели, защёлка считала это попаданием и снималась,
        // после чего ползунок видимо отскакивал на 0.7 с назад. Сходимость — это 150 мс, не 700.
        // Плюс защёлка держится 4 с вместо 1 с: у потока перемотка означает новый Range-запрос,
        // и одной секунды на него не хватало — палец уже отпущен, а позиция ещё старая.
        val latched = SystemClock.elapsedRealtime() < latchUntilMs
        val position = if (pendingSeekMs != null) {
            // Перемотка ещё даже не подана в плеер: показываем то, что человек выбрал.
            seekTargetMs
        } else if (latched && (reported - seekTargetMs).absoluteValue > SEEK_LATCH_TOLERANCE_MS) {
            seekTargetMs
        } else {
            if (latched) latchUntilMs = 0L
            reported
        }
        // Буфер не может быть меньше позиции (у локального файла он равен длительности, у
        // потока — растёт впереди). Ограничение снизу позицией убирает мигание слоя на первых
        // кадрах, когда сессия ещё отдаёт нули.
        val buffered = p.bufferedPosition.coerceIn(position, duration.coerceAtLeast(position))
        val next = Progress(position, duration, buffered, trackId)
        if (next != _progress.value) _progress.value = next
    }

    private fun publishSleep() {
        val left = minutesLeft()
        if (left != _state.value.sleepMinutesLeft) _state.value = _state.value.copy(sleepMinutesLeft = left)
    }

    private fun minutesLeft(): Int? = sleepEndAtMs?.let { end ->
        val left = end - System.currentTimeMillis()
        if (left <= 0) null else ((left + 59_999) / 60_000).toInt()
    }

    /**
     * Building hundreds of MediaItems takes tens of milliseconds, which used to be spent on the
     * main thread right after a tap - that is exactly the "button feels slow" symptom. The list is
     * now built on a background dispatcher and only handed to the controller on the main thread.
     */
    /**
     * 6.10.1 - asks our own resolver to pre-resolve the next few remote tracks.
     *
     * Deliberately best-effort and index-based: under shuffle the guess can be wrong, and that is
     * fine. A wrong guess costs one cached entry on the server; a right guess removes the whole
     * visible delay. Local tracks are skipped, and the resolver itself drops ids it has already
     * seen, so this cannot turn into a request storm.
     */
    /** One delayed job; buffering, pausing and a new queue cancel work not yet sent. */
    private fun schedulePrefetch() {
        val p = controller ?: return
        val id = p.currentMediaItem?.mediaId
        if (!p.isPlaying || id == null) {
            prefetchJob?.cancel()
            prefetchJob = null
            prefetchOwner = null
            return
        }
        val owner = queueEpoch to id
        if (prefetchOwner == owner) return
        prefetchJob?.cancel()
        prefetchOwner = owner
        prefetchJob = scope.launch {
            delay(1500L)
            if (prefetchOwner == owner && queueEpoch == owner.first && p.isPlaying &&
                p.currentMediaItem?.mediaId == owner.second) {
                prefetchAhead(p.currentMediaItemIndex + 1)
            }
        }
    }

    private fun prefetchAhead(fromIndex: Int) {
        if (!ZiziResolve.configured || queueUris.isEmpty()) return
        val ids = ArrayList<String>(3)
        var i = fromIndex.coerceAtLeast(0)
        while (i < queueUris.size && ids.size < 3) {
            val parsed = RemoteUri.parse(Uri.parse(queueUris[i]))
            if (parsed != null && parsed.first == "yt") ids.add(parsed.second)
            i++
        }
        // Очередь — единственное место, где прогрев БАЙТОВ оправдан: эти треки почти наверняка
        // будут услышаны, и «вперёд» по ним обязано быть мгновенным.
        if (ids.isNotEmpty()) ZiziResolve.prefetch(ids, bytes = true)
    }

    fun setQueue(tracks: List<TrackEntity>, startIndex: Int, play: Boolean = true, startPositionMs: Long = 0L, sourceId: String? = null) {
        val gate = app.ziziplayer.privacy.FolderVault.get(context).state.value
        val requested = tracks.getOrNull(startIndex.coerceIn(0, (tracks.size - 1).coerceAtLeast(0))) ?: return
        if (gate.blocks(requested)) return
        val safeTracks = tracks.filterNot(gate::blocks)
        val safeIndex = safeTracks.indexOfFirst { it.id == requested.id }
        if (safeIndex < 0) return
        val p = controller ?: run { pendingQueue = PendingQueue(safeTracks, safeIndex, play, startPositionMs, sourceId); return }
        val epoch = ++queueEpoch
        scope.launch {
            val prepared = withContext(Dispatchers.Default) {
                val durations = HashMap<String, Long>(safeTracks.size * 2)
                val items = safeTracks.map { t ->
                    durations[t.id] = t.durationMs
                    mediaItemOf(t, sourceId)
                }
                items to durations
            }
            if (epoch != queueEpoch || safeTracks.any(app.ziziplayer.privacy.FolderVault.get(context).state.value::blocks)) return@launch
            knownDurations = prepared.second
            latchUntilMs = 0L
            val items = prepared.first
            queueUris = safeTracks.map { it.uri }
            StartupTrace.mark(StartupTrace.Stage.PREPARE_QUEUE)
            p.setMediaItems(items, safeIndex.coerceIn(items.indices), startPositionMs.coerceAtLeast(0))
            p.prepare(); if (play) p.play()
            // Never prefetch the currently opening item or compete with its initial buffer.
            invalidateQueue(); publish(); publishProgress(); syncTicker()
        }
    }

    /**
     * Один способ собрать MediaItem на всё приложение.
     *
     * Был встроен внутрь setQueue; «добавить в очередь» обязано класть в таймлайн ровно такой же
     * item, иначе у добавленного трека была бы другая обложка в шторке — классическое расхождение,
     * которое замечают через неделю и ищут час.
     */
    private fun mediaItemOf(t: TrackEntity, sourceId: String? = null): MediaItem =
        MediaItem.Builder().setMediaId(t.id).setUri(t.uri)
            // 6.24.0: адрес ещё и в requestMetadata. Единственная часть элемента, которая
            // гарантированно переживает границу сессии: localConfiguration Media3 срезает, и
            // сервис восстанавливает URI именно отсюда (см. PlaybackService.withUri).
            .setRequestMetadata(
                MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(t.uri)).build()
            )
            .setMediaMetadata(
            MediaMetadata.Builder()
                .setExtras(Bundle().apply { sourceId?.let { putString("zizi.queueSource", it) } })
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                // Fall back to the audio file itself: the service reads the embedded
                // cover from it, so the system notification is never left without art.
                .setArtworkUri(if (t.isRemote && !CatalogPolicy.supports(t.provider, t.remoteId)) null
                    else Uri.parse(t.artworkUri ?: t.uri))
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .build()
        ).build()

    /**
     * «Играть следующим» / «Добавить в очередь».
     *
     * Вставка в существующий таймлайн, а не пересборка очереди: пересборка сбросила бы позицию
     * текущего трека и порядок шаффла. На пустом плеере ведёт себя как обычный старт.
     */
    fun enqueue(track: TrackEntity, playNext: Boolean) {
        if (app.ziziplayer.privacy.FolderVault.get(context).state.value.blocks(track)) return
        val p = controller ?: run {
            pendingQueue = PendingQueue(listOf(track), 0, play = false, positionMs = 0L)
            return
        }
        knownDurations = knownDurations + (track.id to track.durationMs)
        if (p.mediaItemCount == 0) {
            queueUris = listOf(track.uri)
            p.setMediaItems(listOf(mediaItemOf(track)), 0, 0L)
            p.prepare()
        } else {
            val index = if (playNext) (p.currentMediaItemIndex + 1).coerceAtMost(p.mediaItemCount)
                        else p.mediaItemCount
            // 6.24.0: список адресов держится в синхроне с таймлайном. Раньше добавление в
            // очередь его не трогало, и прогрев резолвера «что играет дальше» после каждого
            // «играть следующим» смотрел на сдвинутый список, то есть греил чужой трек.
            queueUris = ArrayList<String>(queueUris.size + 1).apply {
                addAll(queueUris)
                add(index.coerceIn(0, size), track.uri)
            }
            p.addMediaItem(index, mediaItemOf(track, p.currentMediaItem?.mediaMetadata?.extras?.getString("zizi.queueSource")))
        }
        invalidateQueue(); publish(); publishProgress()
    }

    /**
     * Перейти к треку очереди ПО ИДЕНТИФИКАТОРУ, а не по номеру строки (6.24.0).
     *
     * Экран очереди показывает не таймлайн плеера, а результат сопоставления его id с библиотекой
     * (MainViewModel.queue). Любой трек, которого в библиотеке нет — например, найденный поиском и
     * добавленный через «Добавить в очередь», — из списка выпадает, и дальше номера строк на экране
     * и номера элементов в плеере расходятся: человек жмёт одну песню, играет другая. Ошибка тем
     * подлее, что появляется только у тех, кто пользуется поиском и очередью одновременно.
     *
     * Идентификатор такого расхождения не имеет в принципе.
     */
    fun seekToTrack(trackId: String) {
        val index = cachedQueueIds.indexOf(trackId)
        if (index >= 0) seekToIndex(index)
    }

    /** Used when a track is removed from the library: it must leave the running queue too. */
    fun removeFromQueue(trackId: String) {
        val p = controller ?: return
        val index = cachedQueueIds.indexOf(trackId)
        if (index < 0) return
        if (p.mediaItemCount <= 1) { p.pause(); p.clearMediaItems() } else p.removeMediaItem(index)
        invalidateQueue(); publish(); publishProgress()
    }

    fun playPause() { controller?.let { if (it.playWhenReady) it.pause() else it.play() }; publish(); syncTicker() }

    /**
     * Перемотка. [expectedTrackId] — трек, который человек ВИДЕЛ, когда отпускал палец.
     *
     * 6.32.0. Экран и плеер живут в разных потоках событий, и между жестом и его доставкой
     * трек успевает смениться сам. Раньше такая перемотка молча применялась к новому треку —
     * человек получал следующую песню, начатую с середины предыдущей. Теперь несовпадение
     * владельца отменяет перемотку: не сделать ничего здесь честнее, чем сделать не то.
     */
    fun seekTo(positionMs: Long, expectedTrackId: String? = null) {
        val p = controller ?: return
        val currentId = p.currentMediaItem?.mediaId
        if (expectedTrackId != null && currentId != null && expectedTrackId != currentId) {
            publishProgress()
            return
        }
        val duration = durationOf(p)
        // Never land inside the last moment of a track: that is what made it jump to the next one.
        val max = if (duration > 0L) (duration - END_GUARD_MS).coerceAtLeast(0L) else Long.MAX_VALUE
        val target = positionMs.coerceAtLeast(0L).coerceAtMost(max)
        seekTargetMs = target
        seekTrackId = currentId
        seekRetries = 0
        lastSeekAtMs = SystemClock.elapsedRealtime()
        latchUntilMs = lastSeekAtMs + SEEK_LATCH_MS
        // Ползунок обязан встать под палец немедленно, независимо от того, применён seek или отложен.
        //
        // 6.32.0. Буфер после перемотки СБРАСЫВАЕТСЯ на цель, а не переносится с прошлого места.
        // Прогрессивный поток после seek открывает новый Range: байтов впереди ещё нет, и
        // старое значение bufferedMs (например 90 % трека) — прямая ложь. Именно поэтому
        // теневая полоса оставалась впереди, а потом «съезжала» назад к правде.
        _progress.value = Progress(target, duration, target, currentId)
        if (isSeekReady(p)) {
            pendingSeekMs = null
            p.seekTo(target)
        } else {
            // Элемент ещё не готов принимать перемотку. Держим цель и ставим её, как только готов.
            pendingSeekMs = target
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
        }
    }

    /**
     * Готов ли текущий элемент принять перемотку.
     *
     * Три условия, и каждое из них по отдельности недостаточно: не IDLE (иначе seek уходит в
     * пустой плеер), длительность известна СЕССИИ (наша `knownDurations` тут не годится — она
     * знает трек, но не таймлайн), окно помечено перематываемым (у прогрессивного потока это
     * появляется только после того, как известен размер).
     */
    private fun isSeekReady(p: MediaController): Boolean =
        p.playbackState != Player.STATE_IDLE &&
            p.currentMediaItem != null &&
            p.duration > 0L &&
            p.isCurrentMediaItemSeekable

    /** Применяет отложенную перемотку. Вызывается из onEvents на каждой смене состояния. */
    private fun applyPendingSeek() {
        val p = controller ?: return
        val target = pendingSeekMs ?: return
        // Владелец цели обязан совпадать с текущим элементом, иначе цель просто выбрасывается.
        val currentId = p.currentMediaItem?.mediaId
        if (seekTrackId != null && seekTrackId != currentId) {
            pendingSeekMs = null
            seekTrackId = null
            latchUntilMs = 0L
            seekTargetMs = 0L
            return
        }
        if (!isSeekReady(p)) return
        pendingSeekMs = null
        val duration = durationOf(p)
        val max = if (duration > 0L) (duration - END_GUARD_MS).coerceAtLeast(0L) else Long.MAX_VALUE
        val clamped = target.coerceAtMost(max)
        seekTargetMs = clamped
        latchUntilMs = SystemClock.elapsedRealtime() + SEEK_LATCH_MS
        p.seekTo(clamped)
        publishProgress()
    }

    /** Ручной переход обнуляет перемотку целиком: цель прошлого трека новому не принадлежит. */
    private fun dropSeekIntent() { latchUntilMs = 0L; pendingSeekMs = null; seekTargetMs = 0L; seekTrackId = null; seekRetries = 0 }

    fun seekToIndex(index: Int) { dropSeekIntent(); controller?.seekToDefaultPosition(index); publish(); publishProgress() }
    fun next() { dropSeekIntent(); controller?.seekToNextMediaItem(); publish(); publishProgress() }
    fun previous() {
        val p = controller ?: return
        dropSeekIntent()
        // Standard behaviour: restart the track if we are past 3 seconds, otherwise go back
        if (p.currentPosition > 3000) p.seekTo(0) else p.seekToPreviousMediaItem()
        publish(); publishProgress()
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; publish() }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
        publish()
    }
    fun setPlayback(speed: Float, pitch: Float) {
        controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
    }

    /**
     * 6.24.4. Отправка тракта в сервис.
     *
     * Последняя конфигурация запоминается здесь по одной причине: сервис может умереть и
     * подняться заново (система выгрузила процесс, пользователь смахнул задачу), и тогда у него
     * нейтральный тракт, а у экрана — полный набор ползунков. Без [lastDsp] человек увидел бы
     * свои настройки на экране и не услышал бы их в звуке — самый неприятный сорт бага, потому
     * что интерфейс при нём выглядит исправным. При переподключении конфиг уезжает повторно.
     */
    fun setDsp(config: DspConfig) {
        lastDsp = config
        pushDsp()
    }

    private var lastDsp: DspConfig = DspConfig.NEUTRAL

    private fun pushDsp() {
        val c = controller ?: return
        c.sendCustomCommand(
            SessionCommand(PlaybackService.CMD_DSP, Bundle.EMPTY),
            Bundle().apply { putString("config", DspCodec.encode(lastDsp)) }
        )
    }
    fun setSkipSilence(enabled: Boolean) {
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_SKIP_SILENCE, Bundle.EMPTY), Bundle().apply { putBoolean("enabled", enabled) })
    }
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel(); sleepJob = null
        if (minutes == null || minutes <= 0) { sleepEndAtMs = null; publishSleep(); return }
        sleepEndAtMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause(); sleepEndAtMs = null; publish(); publishSleep()
        }
        publishSleep()
    }
    fun release() {
        sleepJob?.cancel(); tickerJob?.cancel()
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        scope.cancel()
    }
}
