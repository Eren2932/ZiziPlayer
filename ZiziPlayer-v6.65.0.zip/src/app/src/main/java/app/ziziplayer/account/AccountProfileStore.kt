package app.ziziplayer.account

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Private profile, kept in RAM. Only confirmed server responses become saved state. */
data class AccountProfile(
    val userId: String? = null,
    val name: String = "",
    val avatar: String = "",
    val revision: Long = 0,
    val loaded: Boolean = false,
    val busy: Boolean = false,
    val error: String = ""
)

class AccountProfileStore private constructor(context: Context) {
    private val api = AccountRepository.get(context)
    private val lane = Mutex()
    private val mutable = MutableStateFlow(AccountProfile())
    val state = mutable.asStateFlow()
    private fun read(id: String, json: JSONObject) = AccountProfile(id, json.getString("name"),
        json.getString("avatar"), json.getLong("revision"), loaded = true)
    private fun problem(e: Exception): String = when {
        e is AccountApiException && e.status == 404 -> "Для изменения профиля обновите сервер Accounts до 1.2."
        e is AccountApiException && e.status == 409 -> "Профиль изменён на другом устройстве. Закройте редактор и обновите профиль; ваши правки пока не сохранены."
        e is AccountApiException && e.status == 400 -> "Проверьте имя (1–80 символов) и изображение. Изменения не сохранены."
        e is AccountApiException -> AccountProblem.library(e.status, e.reason)
        else -> "Не удалось связаться с аккаунтом. Изменения не сохранены; повторите попытку."
    }
    suspend fun connect(id: String?) = lane.withLock {
        withContext(Dispatchers.IO + NonCancellable) {
            val old = mutable.value
            mutable.value = if (old.userId == id) old.copy(busy = true, error = "") else AccountProfile(userId = id, busy = true)
            if (id == null) { mutable.value = AccountProfile(); return@withContext }
            try { mutable.value = read(id, api.profileGet(id)) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { mutable.value = mutable.value.copy(busy = false, error = problem(e)) }
        }
    }
    suspend fun save(id: String, name: String, avatar: String, revision: Long): Boolean = lane.withLock {
        withContext(Dispatchers.IO + NonCancellable) {
            if (mutable.value.userId != id || !mutable.value.loaded) return@withContext false
            mutable.value = mutable.value.copy(busy = true, error = "")
            try {
                mutable.value = read(id, api.profileSave(id, name.trim(), avatar, revision))
                true
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { mutable.value = mutable.value.copy(busy = false, error = problem(e)); false }
        }
    }
    companion object {
        @Volatile private var instance: AccountProfileStore? = null
        fun get(context: Context): AccountProfileStore = instance ?: synchronized(this) {
            instance ?: AccountProfileStore(context.applicationContext).also { instance = it }
        }
    }
}
