package app.ziziplayer.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.R
import app.ziziplayer.ui.theme.LocalPalette

/** Reference proportions: 48dp pill, 1dp outline; minimum, not a text-clipping fixed height. */
@Composable
internal fun AccountPill(
    label: String,
    onClick: () -> Unit,
    primary: Boolean = false,
    enabled: Boolean = true,
    loading: Boolean = false,
    google: Boolean = false
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(50)
    val modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
    val pillContent: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (google) Image(painterResource(R.drawable.ic_google_signin), null,
                Modifier.align(Alignment.CenterStart).size(22.dp))
            if (loading) CircularProgressIndicator(Modifier.size(22.dp),
                color = if (primary) p.onBrand else Color.White, strokeWidth = 2.dp)
            else Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = if (google) 30.dp else 0.dp))
        }
    }
    if (primary) Button(onClick = onClick, enabled = enabled, modifier = modifier, shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = p.brand, contentColor = p.onBrand)) { pillContent() }
    else OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier, shape = shape,
        border = BorderStroke(1.dp, Color(0xFF727272)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { pillContent() }
}
