package app.ziziplayer.lyrics;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Metadata equivalence, NOT audio recognition. Version qualifiers are never discarded. */
public final class LyricsMatchPolicy {
    private LyricsMatchPolicy() {}
    private static final Pattern COSMETIC = Pattern.compile(
        "(?i)\\s*[\\[(](?:official\\s+(?:audio|music\\s+video|video)|lyrics?|lyric\\s+video|audio)[\\])]\\s*");
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern FEATURE = Pattern.compile(
        "(?i)\\s*[\\[(](?:feat(?:uring)?|ft)\\.?\\s+([^\\])]+)[\\])]\\s*");
    private static final Pattern BARE_FEATURE = Pattern.compile("(?i)\\s+\\b(?:feat(?:uring)?|ft)\\.?\\s+");
    private static final Pattern VERSION = Pattern.compile(
        "(?i)\\b(slowed|slow|sped|speed|nightcore|reverb|remix|rmx|bootleg|live|cover|karaoke|instrumental|acoustic|edit|extended|remaster|remastered|8d|boosted)\\b");
    private static String[] titleParts(String value) {
        String clean = COSMETIC.matcher(value == null ? "" : value).replaceAll(" ").trim();
        java.util.regex.Matcher match = FEATURE.matcher(clean);
        StringBuilder guests = new StringBuilder();
        StringBuffer base = new StringBuffer();
        while (match.find()) {
            if (VERSION.matcher(match.group(1)).find()) continue;
            guests.append(' ').append(match.group(1));
            match.appendReplacement(base, " ");
        }
        match.appendTail(base);
        String title = base.toString().trim();
        match = BARE_FEATURE.matcher(title);
        if (match.find() && !VERSION.matcher(title.substring(match.end())).find()) {
            guests.append(' ').append(title.substring(match.end()));
            title = title.substring(0, match.start()).trim();
        }
        return new String[]{title, guests.toString().trim()};
    }
    private static final Pattern PUNCTUATION = Pattern.compile("[\\p{P}\\p{S}]");
    private static final Pattern SPACE = Pattern.compile("\\s+");
    public static String searchTitle(String title) {
        return titleParts(title)[0];
    }
    private static String normalized(String value) {
        String unicode = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFKD);
        unicode = MARKS.matcher(unicode).replaceAll("").replace('đ', 'd').replace('Đ', 'D');
        return SPACE.matcher(PUNCTUATION.matcher(unicode).replaceAll(" ").trim())
            .replaceAll(" ").toLowerCase(Locale.ROOT);
    }
    public static boolean identityMatches(String title, String artist, String otherTitle, String otherArtist) {
        String[] wanted = titleParts(title), found = titleParts(otherTitle);
        String t = normalized(wanted[0]);
        String a = normalized(artist).replace(" ", "");
        String other = normalized(otherArtist).replace(" ", "");
        // Some providers move exactly the known guest credit into artistName.
        String guest = normalized(wanted[1]).replace(" ", "");
        if (!guest.isEmpty() && other.equals(a + guest)) other = a;
        boolean guestsAgree = wanted[1].isEmpty() || found[1].isEmpty()
            || normalized(wanted[1]).equals(normalized(found[1]));
        return !t.isEmpty() && !a.isEmpty() && t.equals(normalized(found[0]))
            && a.equals(other) && guestsAgree;
    }
    /** Omitted guest credits need the tight recording-duration gate, not the plain-text window. */
    public static boolean requiresExactDuration(String title, String otherTitle) {
        return titleParts(title)[1].isEmpty() != titleParts(otherTitle)[1].isEmpty();
    }
    /** A close recording may supply plain lyrics; only the strict timeline gate enables karaoke. */
    public static boolean textDurationMatches(long expected, long actual) {
        if (actual <= 0) return false;
        return expected <= 0 || Math.abs(expected - actual) <= Math.max(15000L, expected / 10L);
    }
    public static long retryDelay(long now, long deadline) {
        return Math.max(1L, deadline - now);
    }
}
