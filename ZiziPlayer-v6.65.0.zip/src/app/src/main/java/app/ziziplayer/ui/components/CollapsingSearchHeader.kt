package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.clearAndSetSemantics
import app.ziziplayer.ui.SearchHeaderGeometry

/** Scroll distance is consumed exactly once: collapse before list, expand after list reaches top.
 * No timed animation competes with a drag/fling. Fraction survives density/font changes.
 */
@Stable
class SearchHeaderState {
    var fraction by mutableFloatStateOf(0f)
    var titleHeight by mutableIntStateOf(0)
    var sectionHeight by mutableIntStateOf(0)
    private val range get() = (titleHeight + sectionHeight).toFloat()

    private fun consume(dy: Float): Float {
        if (range <= 0f) return 0f
        val old = fraction * range
        val next = SearchHeaderGeometry.nextOffset(old, dy, range)
        fraction = next / range
        return old - next
    }
    val connection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
            Offset(0f, if (available.y < 0f) consume(available.y) else 0f)
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
            Offset(0f, if (available.y > 0f) consume(available.y) else 0f)
    }
}

@Composable
fun rememberSearchHeaderState(): SearchHeaderState {
    return rememberSaveable(saver = Saver<SearchHeaderState, Float>(
        save = { it.fraction },
        restore = { value -> SearchHeaderState().apply { fraction = value.coerceIn(0f, 1f) } }
    )) { SearchHeaderState() }
}

/** Three measured slots, one clipped surface. At f=1 its bottom IS the search entry bottom.
 * The outer clip follows the measured height: an invisible refresh/genre action cannot
 * intercept the entry or remain in TalkBack's focus order at full collapse.
 */
@Composable
fun CollapsingSearchHeader(
    state: SearchHeaderState,
    title: @Composable () -> Unit,
    entry: @Composable () -> Unit,
    section: @Composable () -> Unit
) {
    val hidden = if (state.fraction >= 1f) Modifier.clearAndSetSemantics { } else Modifier
    Layout(modifier = Modifier.fillMaxWidth().clipToBounds(), content = {
        Box(Modifier.fillMaxWidth().onSizeChanged { state.titleHeight = it.height }.then(hidden)) { title() }
        Box(Modifier.fillMaxWidth()) { entry() }
        Box(Modifier.fillMaxWidth().onSizeChanged { state.sectionHeight = it.height }.then(hidden)) { section() }
    }) { children, constraints ->
        val loose = constraints.copy(minHeight = 0)
        val titleBox = children[0].measure(loose)
        val entryBox = children[1].measure(loose)
        val sectionBox = children[2].measure(loose)
        val f = state.fraction.coerceIn(0f, 1f)
        val titleVisible = SearchHeaderGeometry.visibleHeight(titleBox.height, f)
        val sectionVisible = SearchHeaderGeometry.visibleHeight(sectionBox.height, f)
        layout(constraints.maxWidth, titleVisible + entryBox.height + sectionVisible) {
            if (titleVisible > 0) titleBox.placeRelative(0, titleVisible - titleBox.height)
            entryBox.placeRelative(0, titleVisible)
            if (sectionVisible > 0) sectionBox.placeRelative(0, titleVisible + entryBox.height)
        }
    }
}
