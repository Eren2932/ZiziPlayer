package app.ziziplayer.ui;

/**
 * Обновление подборок без кнопки «Обновить».
 *
 * Пользователь не должен нажимать ничего: свежесть определяется временем, а неудача
 * повторяется сама с ограниченным числом попыток и растущей паузой. Это детерминированная
 * арифметика, а не таймер и не фоновая служба: вызывающий код сам решает, когда спросить.
 */
public final class HomeFeedRefreshPolicy {
    private HomeFeedRefreshPolicy() {}

    /** Снимок считается свежим 30 минут. */
    public static final long STALE_MS = 30L * 60_000L;
    /** Минимальная пауза между любыми двумя попытками. */
    public static final long ATTEMPT_GAP_MS = 15_000L;
    /** Максимум автоматических повторов после ошибки. */
    public static final int MAX_RETRIES = 3;
    /** Верхняя граница паузы автоповтора. */
    public static final long MAX_RETRY_MS = 300_000L;

    /** 15 c, 45 c, 135 c ... с потолком 5 минут. Ноль — когда повторять уже нельзя. */
    public static long retryDelayMs(int attempt) {
        if (attempt < 1 || attempt > MAX_RETRIES) return 0L;
        double delay = ATTEMPT_GAP_MS * Math.pow(3.0, attempt - 1);
        return (long) Math.min(MAX_RETRY_MS, delay);
    }

    /** Есть ли ещё право на автоповтор. */
    public static boolean canRetry(int attempt) {
        return attempt >= 1 && attempt <= MAX_RETRIES;
    }

    /** Данные устарели: снимка нет вовсе либо он старше STALE_MS. */
    public static boolean stale(long now, long loadedAt) {
        return loadedAt <= 0L || now - loadedAt >= STALE_MS || now < loadedAt;
    }

    /**
     * Ручное обновление исчезло, поэтому решение принимается здесь:
     * грузим при устаревании или по явному force, но не чаще ATTEMPT_GAP_MS.
     */
    public static boolean shouldLoad(long now, long loadedAt, long lastAttempt, boolean force) {
        if (lastAttempt > 0L && now - lastAttempt < ATTEMPT_GAP_MS && now >= lastAttempt) return false;
        return force || stale(now, loadedAt);
    }
}
