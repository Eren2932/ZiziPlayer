package app.ziziplayer.ui;

/** Reference Screenshot_20260915_231104.jpg, original 1080x2400.
 * Distances are in reference pixels, NOT density-dependent dp. System inset is added once.
 * Tablets cap the artwork/type scale at a 420dp content width; touch targets stay >=48dp.
 */
public final class CollectionHeaderGeometry {
    private CollectionHeaderGeometry() {}
    public static final float WIDTH = 1080f;
    public static final float COVER_TOP = 54f;
    public static final float COVER_SIZE = 716f;
    public static final float COVER_RADIUS = 8f;
    public static final float COVER_TITLE_GAP = 70f;
    public static final float CONTENT_START = 46f;
    public static final float PLAY_END = 40f;
    public static final float PLAY_SIZE = 140f;
    public static final float PLAY_SHUFFLE_CENTERS = 144f;
    public static final float SHUFFLE_CANVAS = 86f;
    public static final float TITLE_SIZE = 72f;
    public static final float TITLE_LINE = 80f;
    public static final float META_SIZE = 40f;
    public static final float META_LINE = 48f;
    public static final float DETAILS_MIN_HEIGHT = 310f;
    public static final float META_BOTTOM_GAP = 32f;
    public static final float SUBTITLE_TOP_GAP = 34f;
    public static final float ACTION_BOTTOM_GAP = 4f;
    public static float unit(float widthDp) {
        return Math.max(0f, Math.min(420f, widthDp)) / WIDTH;
    }
    public static float touchSize(float unit) { return Math.max(48f, PLAY_SIZE * unit); }
    public static float touchEnd(float unit) {
        return Math.max(0f, PLAY_END * unit - (touchSize(unit) - PLAY_SIZE * unit) / 2f);
    }
    public static float actionGap(float unit) {
        return Math.max(0f, PLAY_SHUFFLE_CENTERS * unit - touchSize(unit));
    }
}
