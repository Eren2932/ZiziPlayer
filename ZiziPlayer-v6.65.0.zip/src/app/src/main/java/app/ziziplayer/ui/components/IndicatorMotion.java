package app.ziziplayer.ui.components;

/** Pure decorative motion: smooth, bounded and periodic. Never consumes audio samples. */
public final class IndicatorMotion {
    private IndicatorMotion() { }
    public static final int PERIOD_MS = 8160;
    private static final int[] CYCLES = {7, 6, 9, 8};
    private static final float[] MIN = {0.35f, 0.45f, 0.55f, 0.40f};
    private static final float[] MAX = {1f, 1f, 0.95f, 0.90f};
    private static final float[] OFFSET = {0f, 0.5f, 0f, 0.5f};
    private static final float[] REST = {0.35f, 0.60f, 0.45f, 0.80f};

    public static float level(float phase, int bar, boolean playing) {
        if (bar < 0 || bar >= 4) throw new IllegalArgumentException("bar must be 0..3");
        if (!playing) return REST[bar];
        if (!Float.isFinite(phase)) phase = 0f;
        double angle = 2.0 * Math.PI * ((phase % 1.0) * CYCLES[bar] + OFFSET[bar]);
        float wave = (float) (0.5 - 0.5 * Math.cos(angle));
        return MIN[bar] + (MAX[bar] - MIN[bar]) * wave;
    }
}
