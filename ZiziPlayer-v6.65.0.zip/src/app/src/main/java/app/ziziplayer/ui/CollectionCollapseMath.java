package app.ziziplayer.ui;

/** Pixel distance consumed once: artwork shrinks first, then the list moves. */
public final class CollectionCollapseMath {
    private CollectionCollapseMath() {}
    public static float clamp(float value, float maximum) {
        if (!Float.isFinite(value) || !Float.isFinite(maximum) || maximum <= 0f) return 0f;
        return Math.max(0f, Math.min(maximum, value));
    }
    public static float next(float offset, float dy, float range) {
        return clamp(clamp(offset, range) - (Float.isFinite(dy) ? dy : 0f), range);
    }
    public static float coverSize(float expanded, float minimum, float fraction) {
        float max = Math.max(0f, expanded);
        float min = clamp(minimum, max);
        return max - (max - min) * clamp(fraction, 1f);
    }
    public static float banner(float scroll, float travel) {
        float progress = clamp(scroll / Math.max(1f, travel), 1f);
        return CollectionGeometry.smoothstep((progress - .65f) / .35f);
    }
}
