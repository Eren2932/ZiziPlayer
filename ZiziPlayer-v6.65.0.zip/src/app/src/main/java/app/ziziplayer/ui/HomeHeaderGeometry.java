package app.ziziplayer.ui;

/**
 * Дом: шапка и сетка «под рукой».
 *
 * Все константы измерены попиксельно на референсе 1080 x 2400 (Spotify home, image-1.png),
 * ниже его статусбара 108 px. Скриншот НЕ содержит плотности экрана, поэтому единственная
 * корректная операция — масштабирование по доступной ширине: dp = px * viewportDp / 1080.
 * На эталонном 1080-пиксельном экране это даёт ровно измеренное число физических пикселей
 * при любой плотности; на других ширинах пропорция сохраняется.
 *
 * Чистая Java: проверяется без Android и Compose (HomeHeader6580Checks).
 */
public final class HomeHeaderGeometry {
    private HomeHeaderGeometry() {}

    public static final float REFERENCE_WIDTH = 1080f;

    /* --- шапка: аватарка + вкладки ------------------------------------------------ */
    /** Левый/правый отступ контента; совпадает с CollectionGeometry.CONTENT_INSET. */
    public static final float INSET = 46f;
    /** Диаметр аватарки: измерено x 46..137, y 134..225. */
    public static final float AVATAR = 92f;
    /** Зазор аватарка -> первая вкладка: 173 - 138. */
    public static final float AVATAR_GAP = 35f;
    /** Высота пилюли вкладки: y 134..225, ровно как аватарка. */
    public static final float CHIP_HEIGHT = 92f;
    /** Зазор между вкладками: 351 - 328. */
    public static final float CHIP_GAP = 24f;
    /** Горизонтальный внутренний отступ вкладки: «Подкасты» 652..816 внутри 602..864. */
    public static final float CHIP_PADDING = 48f;
    /** Кегль текста вкладки: cap-height 26 px. */
    public static final float CHIP_TEXT = 36f;
    /** Верх шапки под статусбаром: 134 - 108. */
    public static final float HEADER_TOP = 26f;
    /** Шапка -> первая плитка: 273 - 226. */
    public static final float HEADER_BOTTOM = 47f;

    /* --- сетка плиток «под рукой» -------------------------------------------------- */
    /** Высота плитки и сторона её квадратной обложки: 273..411. */
    public static final float TILE_HEIGHT = 139f;
    /** Зазор между плитками по обеим осям: шаг 162.5 при высоте 139; колонки 528 -> 552. */
    public static final float TILE_GAP = 24f;
    public static final float TILE_RADIUS = 12f;
    /** Кегль подписи плитки (жирный), измерено по строке 490..518. */
    public static final float TILE_TEXT = 38f;
    /** Обложка -> подпись: 209 - 185. */
    public static final float TILE_TEXT_GAP = 24f;
    public static final float TILE_TEXT_END = 24f;
    /** Иконка внутри квадрата обложки плитки. */
    public static final float TILE_ICON = 56f;
    /** Кнопка запуска волны внутри её обложки; не выходит за квадрат 139. */
    public static final float WAVE_PLAY = 62f;
    /** Ровно 4 ряда по 2 плитки, как в референсе: волна, избранное, медиатека + 5 плейлистов. */
    public static final int TILES = 8;

    /* --- типографика секций -------------------------------------------------------- */
    public static final float SECTION_TEXT = 56f;
    public static final float SECTION_TOP = 47f;
    public static final float CAPTION_TEXT = 32f;

    /**
     * Цвет плитки как наложение: #2A2A2A на фоне #121212 = белый с альфой
     * a = (42 - 18) / (255 - 18). На нашем AMOLED-фоне сохраняется та же светлотная дельта,
     * а не чужой абсолютный серый.
     */
    public static final float TILE_OVERLAY_ALPHA = 24f / 237f;

    /** Референсные пиксели -> dp для реальной ширины вьюпорта в dp. */
    public static float scale(float viewportDp, float referencePx) {
        return referencePx * Math.max(1f, viewportDp) / REFERENCE_WIDTH;
    }

    /** Одна колонка на узких экранах и при крупном системном шрифте: подпись не обрезается. */
    public static int columns(float viewportDp, float fontScale) {
        return viewportDp < 300f || fontScale > 1.3f ? 1 : 2;
    }

    /** Ширина плитки внутри отступов: n равных плиток и (n-1) зазоров. */
    public static float tileWidth(float viewportDp, int columns) {
        int n = Math.max(1, columns);
        float content = Math.max(0f, viewportDp - 2f * scale(viewportDp, INSET));
        return Math.max(0f, (content - (n - 1) * scale(viewportDp, TILE_GAP)) / n);
    }

    /** Сколько плиток показываем: не больше референсных 8 и не больше, чем есть. */
    public static int tiles(int available) {
        return Math.max(0, Math.min(TILES, available));
    }
}
