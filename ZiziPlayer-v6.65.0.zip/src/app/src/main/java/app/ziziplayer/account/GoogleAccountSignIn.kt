package app.ziziplayer.account

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import app.ziziplayer.BuildConfig
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.json.JSONObject

/** Official credential UI, not an embedded WebView. ID token is verified only by our server. */
object GoogleAccountSignIn {
    val configured: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()

    suspend fun signIn(activity: Activity, repository: AccountRepository): JSONObject {
        check(configured)
        val challenge = repository.googleChallenge()
        val option = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setNonce(challenge.getString("nonce")).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(activity).getCredential(activity, request).credential
        if (result !is CustomCredential || result.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            throw AccountApiException(401, "google_verification_failed")
        }
        val credential = GoogleIdTokenCredential.createFrom(result.data)
        return repository.googleLogin(challenge.getString("challenge"), credential.idToken)
    }
}
