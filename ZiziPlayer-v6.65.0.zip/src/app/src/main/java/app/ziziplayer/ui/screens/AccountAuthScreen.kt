package app.ziziplayer.ui.screens

import android.app.Activity
import android.util.Patterns
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.updateTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import app.ziziplayer.ui.theme.ZiziFontFamily
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.clearAndSetSemantics
import app.ziziplayer.ui.components.blockSurfaceInput
import app.ziziplayer.ui.components.surfaceInputBoundary
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.account.AccountApiException
import app.ziziplayer.account.AccountRepository
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Credentials live only in non-saveable memory; the repository owns all identity decisions. */
@Composable
fun AccountAuthScreen(
    activity: Activity,
    repository: AccountRepository,
    onSignedIn: (String, String) -> Unit,
    onClose: () -> Unit,
    initialRegister: Boolean = false,
    interactive: Boolean = true
) {
    val initial = remember {
        if (initialRegister) AuthStep(AuthPage.RegisterEmail, AuthFlow.Register)
        else AuthStep(AuthPage.LoginEmail, AuthFlow.Login)
    }
    val history = remember { AuthHistory(initial) }
    var route by remember { mutableStateOf(AuthRoute(initial)) }
    val drafts = remember { AuthFlow.entries.associateWith { AuthDraft() } }
    val page = route.step.page
    val draft = drafts.getValue(route.step.flow)
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var navigationMoving by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    var clearOnSettle by remember { mutableStateOf<AuthFlow?>(null) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val transition = updateTransition(route, label = "account-navigation")
    val ready = interactive && !closing && !busy && !discard &&
        !navigationMoving && !transition.isRunning && transition.currentState == transition.targetState

    LaunchedEffect(transition.currentState, transition.targetState, transition.isRunning) {
        if (!transition.isRunning && transition.currentState == transition.targetState) {
            history.settle(transition.currentState.revision)
            navigationMoving = history.isMoving
            clearOnSettle?.let { drafts.getValue(it).clearSecrets() }
            clearOnSettle = null
        }
    }
    DisposableEffect(activity) {
        val wasSecure = activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (!wasSecure) activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    fun canInteract(): Boolean = ready && !history.isMoving && !busy && !closing && !discard
    fun publishNavigation() {
        navigationMoving = true
        focus.clearFocus()
        keyboard?.hide()
        route = AuthRoute(history.current(), history.isBackwards, history.revision())
        message = ""
    }
    fun switch(next: AuthPage, flow: AuthFlow = route.step.flow) {
        if (history.forward(AuthStep(next, flow))) publishNavigation()
    }
    fun close() {
        if (closing) return
        closing = true
        focus.clearFocus()
        keyboard?.hide()
        onClose()
    }
    fun back() {
        // This synchronous lock also catches a second tap before Compose recomposes.
        if (!canInteract()) return
        if (history.back()) publishNavigation()
        else if (drafts.values.any { it.dirty }) discard = true
        else close()
    }
    // Keep consuming Back during transitions/close; never fall through to the player below.
    BackHandler { back() }

    fun validEmail(): Boolean {
        if (!Patterns.EMAIL_ADDRESS.matcher(draft.email.trim()).matches()) {
            message = "Проверьте адрес электронной почты."; return false
        }
        return true
    }
    fun launchAction(action: String) {
        if (!canInteract()) return
        if (action in setOf("register", "login", "forgot", "resend") && !validEmail()) return
        if (action in setOf("register", "reset") && draft.password != draft.confirmation) {
            message = "Пароли не совпадают"; return
        }
        if (action in setOf("register", "login", "reset") && draft.password.length !in 12..128) {
            message = "Пароль должен содержать от 12 до 128 символов"; return
        }
        if (action in setOf("verify", "reset") && draft.code.isBlank()) {
            message = "Вставьте код из письма."; return
        }
        focus.clearFocus()
        keyboard?.hide()
        busy = true; message = ""
        scope.launch {
            try {
                val result = repository.submit(action, draft.email, draft.password, draft.code)
                when (action) {
                    "login" -> {
                        drafts.values.forEach { it.clearSecrets() }
                        closing = true
                        onSignedIn(result.getString("email"), result.getString("id"))
                    }
                    "register" -> {
                        // Retain until outgoing password screen has left; then discard submitted secrets.
                        clearOnSettle = route.step.flow
                        switch(AuthPage.Verify)
                        message = result.optString("message", "Проверьте почту, включая папку «Спам».")
                    }
                    "resend" -> {
                        draft.code = ""
                        message = result.optString("message", "Новый код отправлен. Проверьте почту.")
                    }
                    "forgot" -> {
                        draft.code = ""
                        switch(AuthPage.Reset)
                        message = result.optString("message")
                    }
                    "verify", "reset" -> {
                        val login = drafts.getValue(AuthFlow.Login)
                        login.email = draft.email
                        login.clearSecrets()
                        clearOnSettle = route.step.flow
                        if (history.resetTo(listOf(AuthStep(AuthPage.LoginEmail, AuthFlow.Login),
                                AuthStep(AuthPage.LoginPassword, AuthFlow.Login)))) publishNavigation()
                        message = if (action == "verify") "Почта подтверждена. Теперь войдите."
                            else "Пароль изменён. Войдите заново."
                    }
                }
            } catch (error: CancellationException) { throw error
            } catch (error: Exception) { message = accountErrorMessage(error)
            } finally { busy = false }
        }
    }
    fun continuePage() {
        if (!canInteract()) return
        if (page.emailEntry) {
            if (validEmail()) switch(if (page == AuthPage.RegisterEmail) AuthPage.RegisterPassword else AuthPage.LoginPassword)
        } else launchAction(when (page) {
            AuthPage.RegisterPassword -> "register"
            AuthPage.Verify -> "verify"
            AuthPage.Forgot -> "forgot"
            AuthPage.Reset -> "reset"
            else -> "login"
        })
    }

    Box(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()
        .displayCutoutPadding().imePadding().clipToBounds()) {
        transition.AnimatedContent(modifier = Modifier.fillMaxSize(), transitionSpec = {
            val direction = if (targetState.backwards) -1 else 1
            (slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it * direction } togetherWith
                slideOutHorizontally(tween(280, easing = FastOutSlowInEasing)) { -it * direction })
                .using(null) // Insets already animate the viewport. Never animate its size a second time.
        }) { shownRoute ->
            val shown = shownRoute.step.page
            val shownDraft = drafts.getValue(shownRoute.step.flow)
            val enabled = ready && shownRoute == route
            val passwordFocus = remember { FocusRequester() }
            val confirmationFocus = remember { FocusRequester() }
            BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black).surfaceInputBoundary()) {
                val viewport = maxHeight
                Column(Modifier.widthIn(max = 560.dp).fillMaxSize().align(Alignment.TopCenter)
                    .then(if (!enabled) Modifier.clearAndSetSemantics { } else Modifier)) {
                    // Bounded body scrolls independently. The footer is NOT part of this scroll.
                    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                        Box(Modifier.fillMaxWidth().heightIn(min = 56.dp), contentAlignment = Alignment.Center) {
                            IconButton(onClick = { back() }, enabled = enabled,
                                modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp)) {
                                Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(24.dp))
                            }
                            Text(when (shown) {
                                AuthPage.RegisterEmail, AuthPage.RegisterPassword -> "Создание аккаунта"
                                AuthPage.Verify -> "Подтверждение почты"
                                AuthPage.Forgot, AuthPage.Reset -> "Восстановление доступа"
                                else -> "Вход в ZiziPlayer"
                            }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 64.dp, vertical = 12.dp))
                        }
                        // Fixed content spacing: no viewport-proportional jump when the IME opens.
                        Spacer(Modifier.height(24.dp))
                        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (shown.emailEntry || shown == AuthPage.Forgot) {
                                Text(if (shown == AuthPage.RegisterEmail) "Какая у тебя почта?" else "Эл. почта",
                                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                if (shown == AuthPage.RegisterEmail) Text("Этот адрес электронной почты нужно будет подтвердить.",
                                    color = Color.White, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium)
                                AuthField(shownDraft.email, { shownDraft.editEmail(it) }, "Эл. почта", enabled,
                                    keyboard = KeyboardType.Email, showLabel = false, onDone = { continuePage() })
                            } else {
                                Text(shownDraft.email, color = Color(0xFFB3B3B3), fontSize = 16.sp)
                            }
                            if (shown == AuthPage.Verify || shown == AuthPage.Reset) {
                                Text("Вставьте полный код из письма. Он действует 30 минут. Новый запрос заменяет предыдущий код.",
                                    color = Color.White, fontSize = 16.sp)
                                AuthField(shownDraft.code, { shownDraft.code = it.take(100) }, "Код из письма", enabled,
                                    imeAction = if (shown == AuthPage.Reset) ImeAction.Next else ImeAction.Done,
                                    onDone = { if (shown == AuthPage.Verify) continuePage() else passwordFocus.requestFocus() })
                            }
                            if (shown in setOf(AuthPage.LoginPassword, AuthPage.RegisterPassword, AuthPage.Reset)) {
                                AuthField(shownDraft.password, { shownDraft.password = it.take(128) }, "Пароль", enabled, secret = true,
                                    keyboard = KeyboardType.Password, focusRequester = passwordFocus,
                                    imeAction = if (shown == AuthPage.LoginPassword) ImeAction.Done else ImeAction.Next,
                                    onDone = { if (shown == AuthPage.LoginPassword) continuePage() else confirmationFocus.requestFocus() })
                            }
                            if (shown == AuthPage.RegisterPassword || shown == AuthPage.Reset) {
                                Text("12–128 символов. Используйте уникальный пароль.", color = Color(0xFFB3B3B3), fontSize = 14.sp)
                                AuthField(shownDraft.confirmation, { shownDraft.confirmation = it.take(128) }, "Повторите пароль", enabled,
                                    secret = true, keyboard = KeyboardType.Password, focusRequester = confirmationFocus, onDone = { continuePage() })
                            }
                            if (message.isNotEmpty() && shownRoute == route) Text(message, color = Color.White, fontSize = 14.sp,
                                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                            Spacer(Modifier.height(8.dp))
                            AccountPill(when (shown) {
                                AuthPage.Verify -> "Подтвердить"
                                AuthPage.Forgot -> "Отправить код"
                                AuthPage.Reset -> "Сохранить пароль"
                                else -> "Продолжить"
                            }, { continuePage() }, primary = true, enabled = enabled, loading = busy && shownRoute == route)
                            if (shown == AuthPage.LoginPassword) {
                                TextButton(onClick = {
                                    if (canInteract()) {
                                        drafts.getValue(AuthFlow.Recovery).editEmail(shownDraft.email)
                                        switch(AuthPage.Forgot, AuthFlow.Recovery)
                                    }
                                }, enabled = enabled) { Text("Забыли пароль?", color = Color.White) }
                                TextButton(onClick = { if (canInteract()) switch(AuthPage.Verify) }, enabled = enabled) {
                                    Text("Подтвердить почту", color = Color.White)
                                }
                            }
                            if (shown == AuthPage.Verify) TextButton(onClick = { launchAction("resend") }, enabled = enabled) {
                                Text("Отправить код повторно", color = Color.White)
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                    if (shown.emailEntry) {
                        // Normal screens: fully visible above IME. Extreme landscape/font scale:
                        // bounded, independently scrollable footer leaves space for the form too.
                        Column(Modifier.fillMaxWidth().heightIn(max = viewport * 0.4f)
                            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (shown == AuthPage.RegisterEmail) "Уже есть аккаунт?" else "Нет аккаунта?",
                                color = Color(0xFFB3B3B3), fontSize = 16.sp, textAlign = TextAlign.Center)
                            TextButton(onClick = {
                                if (canInteract()) {
                                    val nextFlow = if (shown == AuthPage.RegisterEmail) AuthFlow.Login else AuthFlow.Register
                                    val nextDraft = drafts.getValue(nextFlow)
                                    if (nextDraft.email.isBlank()) nextDraft.editEmail(shownDraft.email)
                                    switch(if (nextFlow == AuthFlow.Login) AuthPage.LoginEmail else AuthPage.RegisterEmail, nextFlow)
                                }
                            }, enabled = enabled, modifier = Modifier.heightIn(min = 48.dp)) {
                                Text(if (shown == AuthPage.RegisterEmail) "Войти" else "Зарегистрироваться",
                                    color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                // Outgoing pages cannot scroll, receive taps or expose stale form semantics.
                if (!enabled) Box(Modifier.fillMaxSize().blockSurfaceInput())
            }
        }
    }
    if (discard) AlertDialog(onDismissRequest = { discard = false },
        title = { Text("Закрыть форму?") },
        text = { Text("Введённые данные будут удалены. Можно остаться и продолжить заполнение.") },
        confirmButton = { TextButton(onClick = { discard = false; close() }) { Text("Закрыть") } },
        dismissButton = { TextButton(onClick = { discard = false }) { Text("Продолжить заполнение") } })
}

@Composable
private fun AuthField(
    value: String,
    onValueChange: (String) -> Unit,
    title: String,
    enabled: Boolean,
    keyboard: KeyboardType = KeyboardType.Text,
    secret: Boolean = false,
    showLabel: Boolean = true,
    imeAction: ImeAction = ImeAction.Done,
    focusRequester: FocusRequester? = null,
    onDone: () -> Unit = {}
) {
    val p = LocalPalette.current
    var focused by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (showLabel) Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        BasicTextField(value = value, onValueChange = onValueChange, enabled = enabled, singleLine = true,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .border(if (focused) 2.dp else 1.dp, if (focused) p.brand else Color(0xFF353535), RoundedCornerShape(4.dp))
                .semantics { this.contentDescription = title },
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp, fontFamily = ZiziFontFamily),
            cursorBrush = SolidColor(p.brand),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = imeAction),
            keyboardActions = KeyboardActions(onDone = { onDone() }, onNext = { onDone() }),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart) { inner() }
            })
    }
}

private fun accountErrorMessage(error: Exception): String = when ((error as? AccountApiException)?.reason) {
    "invalid_credentials" -> "Почта или пароль неверны."
    "email_not_verified" -> "Сначала подтвердите почту: нажмите «Подтвердить почту» под формой входа."
    "invalid_email" -> "Проверьте адрес почты. В этой версии поддерживаются адреса латиницей."
    "password_length" -> "Пароль должен содержать от 12 до 128 символов."
    "invalid_code" -> "Код неверен, уже использован или истёк. Запросите новое письмо."
    "use_existing_sign_in" -> "Для этой почты уже есть аккаунт. Войдите прежним способом. Автоматически связывать аккаунты небезопасно."
    "google_email_use_password" -> "Для этого адреса Google используйте регистрацию по почте и паролю."
    "google_not_configured", "not_configured" -> "Этот способ входа ещё не настроен на сервере или в сборке."
    "rate_limited", "busy" -> "Слишком много попыток. Подождите несколько минут и повторите."
    "google_verification_failed" -> "Не удалось подтвердить вход через Google. Повторите выбор аккаунта."
    "session_reused" -> "Сессия отозвана для безопасности. Войдите заново."
    else -> "Не удалось завершить запрос. Проверьте интернет и повторите позже. Если письмо не пришло, запросите его повторно."
}
