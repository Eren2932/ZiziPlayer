package app.ziziplayer.listening;

import java.util.Map;
import java.util.TreeMap;

/** Pure service-owned session clock. Elapsed time is monotonic; seeks never add coverage.
 * isPlaying measures player activity, not acoustic output or the listener's attention.
 */
public final class ListeningClock {
    private long lastAt, lastPosition, listened, covered;
    private boolean playing;
    private float speed = 1f;
    private final TreeMap<Long, Long> ranges = new TreeMap<>();
    public ListeningClock(long now, long position) { lastAt = now; lastPosition = Math.max(0, position); }
    public void sample(long now, long position, boolean active, float nextSpeed) {
        long elapsed = Math.max(0, now - lastAt);
        position = Math.max(0, position);
        if (playing) {
            listened += elapsed;
            long progress = position - lastPosition;
            // Discontinuities have their own entry point. Defensive guard for missed callbacks.
            if (progress > 0 && progress <= elapsed * (double) speed + 250.0) add(lastPosition, position);
        }
        lastAt = now; lastPosition = position; playing = active;
        speed = Float.isFinite(nextSpeed) && nextSpeed > 0f ? nextSpeed : 1f;
    }
    public void seek(long now, long oldPosition, long newPosition, boolean active, float nextSpeed) {
        sample(now, oldPosition, active, nextSpeed);
        lastPosition = Math.max(0, newPosition);
    }
    private void add(long from, long to) {
        Map.Entry<Long, Long> floor = ranges.floorEntry(from);
        if (floor != null && floor.getValue() >= from) {
            from = floor.getKey(); to = Math.max(to, floor.getValue());
            covered -= floor.getValue() - floor.getKey(); ranges.remove(floor.getKey());
        }
        Map.Entry<Long, Long> next;
        while ((next = ranges.ceilingEntry(from)) != null && next.getKey() <= to) {
            to = Math.max(to, next.getValue()); covered -= next.getValue() - next.getKey();
            ranges.remove(next.getKey());
        }
        // Pathological scrubbing must not grow memory without bound. Underestimate, never invent.
        if (ranges.size() >= 2048) return;
        ranges.put(from, to); covered += to - from;
    }
    public long listenedMs() { return listened; }
    public long coveredMs() { return covered; }
    public boolean qualified(long duration) {
        long threshold = duration > 0 ? Math.min(30_000L, Math.max(1L, duration / 2 + duration % 2)) : 30_000L;
        return listened >= threshold;
    }
    public boolean completed(long duration, String outcome) {
        return "ended".equals(outcome) && duration > 0 && covered >= duration - duration / 10;
    }
}
