package app.ziziplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.toEntity
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.Job
import kotlinx.coroutines.withTimeoutOrNull
import app.ziziplayer.data.HomePinEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.PlaylistVaultRow
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.OfflineDownloads
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

internal data class HomePlaylist(val playlist: PlaylistEntity, val cover: TrackEntity?, val count: Int, val pinned: Boolean)
internal data class HomeHistory(val session: ListeningSessionEntity, val track: TrackEntity?)
internal enum class HomeCollectionKind(val title: String, val sourceId: String) {
    WAVE("Моя волна", "home:wave-local-v1"),
    RECENT_ADDED("Недавно добавлено", "home:recent-added"),
    DISCOVERY("Подборка", "home:discovery")
}
internal data class HomeCollection(val kind: HomeCollectionKind, val trackIds: List<String>,
    val title: String = kind.title, val sourceId: String = kind.sourceId)
internal data class HomeState(
    val loading: Boolean = true,
    val hiddenIds: Set<String> = emptySet(),
    val vaultFolders: Set<String> = emptySet(),
    val playlists: List<HomePlaylist> = emptyList(),
    val recentAdded: List<TrackEntity> = emptyList(),
    val offline: List<TrackEntity> = emptyList(),
    val tracks: List<TrackEntity> = emptyList(),
    val availableOfflineIds: Set<String> = emptySet(),
    val history: List<HomeHistory> = emptyList(),
    val listenedMs: Long = 0,
    val qualified: Int = 0,
    val completed: Int = 0,
    val skipped: Int = 0
)
private data class HomeSources(
    val tracks: List<TrackEntity>, val playlists: List<PlaylistEntity>,
    val membership: List<PlaylistVaultRow>, val hidden: Set<String>, val pins: List<HomePinEntity>
)
private data class HomeLibrary(val sources: HomeSources, val offlineIds: Set<String>)

/** Local-first projections. No playback clock, network calls or mutable player state here. */
@OptIn(UnstableApi::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as ZiziApplication
    private val music = app.database.musicDao()
    private val dao = app.database.listeningDao()
    private val refresh = MutableStateFlow(0L)
    private val hiddenSource = app.repository.hiddenIds.shareIn(viewModelScope, SharingStarted.Eagerly, replay = 1)
    internal val hidden = hiddenSource.stateIn<Set<String>?>(viewModelScope, SharingStarted.Eagerly, null)
    internal val recommendations = HomeRecommendations(app, viewModelScope, hidden)
    private val _catalogTracks = MutableStateFlow<List<TrackEntity>>(emptyList())
    internal val catalogTracks = _catalogTracks.asStateFlow()
    private val _collectionBusy = MutableStateFlow(false)
    internal val collectionBusy = _collectionBusy.asStateFlow()
    private val _collectionError = MutableStateFlow<String?>(null)
    internal val collectionError = _collectionError.asStateFlow()
    private val _hasMore = MutableStateFlow(false)
    internal val hasMore = _hasMore.asStateFlow()
    private var collectionJob: Job? = null
    private var collectionEpoch = 0
    private var remoteCollection: RemoteCollection? = null
    private var nextPage: String? = null
    private val _historyOpen = MutableStateFlow(false)
    val historyOpen = _historyOpen.asStateFlow()
    private val _collection = MutableStateFlow<HomeCollection?>(null)
    internal val collection = _collection.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    val storageProblem = app.listeningStore.problem

    private val sources = combine(music.observeAllTracks(), music.observePlaylists(),
        music.observePlaylistVaultRows(), hiddenSource, dao.observePins()) { tracks, playlists, membership, hidden, pins ->
        HomeSources(tracks, playlists, membership, hidden, pins)
    }.distinctUntilChanged()
    // File existence is checked off-main and NOT on each listening checkpoint.
    private val local = combine(sources, OfflineDownloads.states, refresh) { source, _, _ ->
        HomeLibrary(source, source.tracks.filter { !it.isRemote || OfflineDownloads.isComplete(app, it) }
            .mapTo(HashSet()) { it.id })
    }.flowOn(Dispatchers.IO)

    // Opening Home must not deserialize 10,000 listening sessions. History owns
    // that subscription; Stage 1 shelves only use library projections.
    private val historySessions = _historyOpen.flatMapLatest { open ->
        if (open) dao.observeSessions() else flowOf(emptyList<ListeningSessionEntity>())
    }
    internal val state = combine(local, historySessions, app.repository.vault.state) { library, sessions, gate ->
        val source = library.sources
        fun allowed(t: TrackEntity) = t.id !in source.hidden &&
            (!t.isRemote || CatalogPolicy.supports(t.provider, t.remoteId)) &&
            (t.isRemote || t.sourceFolder !in gate.folders)
        val tracks = source.tracks.filter(::allowed)
        val byId = tracks.associateBy { it.id }
        val knownIds = source.tracks.mapTo(HashSet()) { it.id }
        val members = source.membership.groupBy { it.playlistId }
        val pins = source.pins.associateBy { it.playlistId }
        val playlists = source.playlists.mapNotNull { playlist ->
            val rows = members[playlist.id].orEmpty()
            // Do not reveal a protected playlist's title/cover through a new home surface.
            if (rows.any { !allowed(it.track) }) return@mapNotNull null
            HomePlaylist(playlist, rows.firstOrNull()?.track, rows.size, playlist.id in pins)
        }.sortedWith(compareByDescending<HomePlaylist> { pins[it.playlist.id]?.pinnedAt ?: 0L }
            .thenByDescending { it.playlist.createdAt })
        val history = sessions.filter { row -> row.trackId !in source.hidden &&
            (row.source != "local" || row.sourceFolder !in gate.folders) &&
            (row.trackId !in knownIds || byId.containsKey(row.trackId))
        }.map { HomeHistory(it, byId[it.trackId]) }
        HomeState(loading = false, hiddenIds = source.hidden, vaultFolders = gate.folders, playlists = playlists,
            tracks = tracks, availableOfflineIds = tracks.filter { it.id in library.offlineIds }.mapTo(HashSet()) { it.id },
            recentAdded = tracks.filter { !it.isRemote || it.savedAt != null }
                .sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(100),
            offline = tracks.filter { it.id in library.offlineIds }.sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(50),
            history = history, listenedMs = history.sumOf { it.session.listenedMs },
            qualified = history.count { it.session.qualified }, completed = history.count { it.session.completed },
            skipped = history.count { it.session.outcome == "skipped" })
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState())

    init {
        // Watch privacy even while another tab owns the screen. Both flows are shared
        // with the existing projection; never retain a protected seed across re-entry.
        viewModelScope.launch {
            var previous: Pair<Set<String>, Set<String>>? = null
            combine(hidden.filterNotNull(), app.repository.vault.state.map { it.folders }) { ids, folders -> ids to folders }
                .distinctUntilChanged().collect { privacy ->
                    if (previous != null && previous != privacy) privacyChanged()
                    previous = privacy
                }
        }
    }
    fun entered() { refresh.value += 1 }
    fun openHistory() { _historyOpen.value = true }
    internal fun openCollection(kind: HomeCollectionKind) {
        val tracks = when (kind) {
            HomeCollectionKind.WAVE -> recommendations.state.value.wave.ifEmpty { state.value.offline }
            HomeCollectionKind.RECENT_ADDED -> state.value.recentAdded
            HomeCollectionKind.DISCOVERY -> emptyList()
        }
        // Stable ordering while open. Later changes can remove forbidden/deleted
        // IDs but never reorder a list under the user's finger.
        _collection.value = HomeCollection(kind, tracks.map { it.id })
    }
    internal fun refreshFeed(force: Boolean = false) { recommendations.load(state.value, force) }
    internal fun leaveHome() {
        recommendations.cancel(); collectionEpoch++; collectionJob?.cancel()
        if (_collectionBusy.value && remoteCollection != null) _collectionError.value = "Загрузка приостановлена. Нажми «Повторить»"
        _collectionBusy.value = false
    }
    internal fun privacyChanged() {
        recommendations.clear(); collectionEpoch++; collectionJob?.cancel(); remoteCollection = null
        _catalogTracks.value = emptyList(); _collection.value = null; _collectionBusy.value = false
        _hasMore.value = false; _collectionError.value = null
    }
    private fun permitted(track: TrackEntity): Boolean = hidden.value != null && track.id !in hidden.value.orEmpty() &&
        (if (track.provider == "mix") "r:${track.remoteId}" else track.id) !in hidden.value.orEmpty().map { if (it.startsWith("r:mix:")) "r:" + it.removePrefix("r:mix:") else it } &&
        (if (track.isRemote) CatalogPolicy.supports(track.provider, track.remoteId)
         else track.sourceFolder !in app.repository.vault.state.value.folders)

    /** Persist only after an explicit user action, never just because a tile was visible. */
    internal fun useTracks(tracks: List<TrackEntity>, action: (List<TrackEntity>) -> Unit) = viewModelScope.launch {
        try {
            val allowed = tracks.filter(::permitted).distinctBy { it.id }.take(200)
            music.rememberRemote(allowed.filter { it.isRemote })
            val current = allowed.filter(::permitted)
            if (current.isNotEmpty()) action(current)
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось открыть треки" }
    }
    internal fun openFeed(card: HomeFeedCard) {
        recommendations.cancel()
        collectionEpoch++; collectionJob?.cancel(); _catalogTracks.value = emptyList(); _collectionError.value = null
        nextPage = null; _hasMore.value = false; remoteCollection = card.remote
        _collection.value = HomeCollection(HomeCollectionKind.DISCOVERY, card.tracks.map { it.id },
            card.title, "home:feed:${card.id}")
        _catalogTracks.value = card.tracks.filter(::permitted)
        if (card.remote != null) loadCollectionPage()
    }
    internal fun loadCollectionPage() {
        val group = remoteCollection ?: return
        val selected = _collection.value ?: return
        if (collectionJob?.isActive == true || _catalogTracks.value.size >= 200) return
        _collectionBusy.value = true; _collectionError.value = null
        val epoch = ++collectionEpoch
        collectionJob = viewModelScope.launch {
            try {
                val page = withTimeoutOrNull(12_000L) {
                    RemoteRuntime.registry.byId(group.provider)?.collectionPage(group, nextPage)
                }
                if (epoch != collectionEpoch || _collection.value?.sourceId != selected.sourceId) return@launch
                if (page == null) { _collectionError.value = "Каталог не успел ответить. Повтори загрузку"; return@launch }
                val tracks = (_catalogTracks.value + page.tracks.map { it.toEntity() })
                    .filter(::permitted).distinctBy { it.id }.take(200)
                _catalogTracks.value = tracks
                _collection.value = selected.copy(trackIds = tracks.map { it.id })
                val previous = nextPage
                nextPage = page.nextToken?.takeIf { it != previous }
                _hasMore.value = nextPage != null && tracks.size < 200
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == collectionEpoch) _collectionError.value = "Не удалось загрузить подборку. Попробуй ещё раз" }
            finally { if (epoch == collectionEpoch) _collectionBusy.value = false }
        }
    }
    fun back(): Boolean {
        if (_collection.value != null) {
            collectionEpoch++; collectionJob?.cancel(); remoteCollection = null; _collectionBusy.value = false
            _collection.value = null; _catalogTracks.value = emptyList(); return true
        }
        if (!_historyOpen.value) return false
        _historyOpen.value = false
        return true
    }
    fun dismissMessage() { _message.value = null }
    fun setPinned(id: Long, pinned: Boolean) = viewModelScope.launch {
        try {
            if (state.value.playlists.none { it.playlist.id == id }) return@launch
            if (!dao.setPinned(id, pinned, System.currentTimeMillis())) _message.value = "Можно закрепить до шести плейлистов"
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось изменить закрепления" }
    }
    fun clearHistory() = viewModelScope.launch {
        try { app.listeningStore.clearHistory(); recommendations.clear(); _message.value = "История очищена. Старые счётчики медиатеки сохранены" }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось очистить историю" }
    }
}
