package app.ziziplayer.ui;

/** Ratios measured on the supplied 1080 x 2400 reference; arguments/results use the same units. */
public final class LyricsGeometry {
    private LyricsGeometry() {}
    public static float playDiameter(float width, boolean compact) {
        return compact ? 48f : Math.max(48f, Math.min(80f, width * (185f / 1080f)));
    }
    public static float bottomGap(float width, boolean compact) {
        return compact ? 4f : width * (46f / 1080f);
    }
    public static float progressTimeHeight(float width, boolean compact) {
        // Slider's touch region is 30dp high: subtract its lower half, not its visual stroke.
        return compact ? 9.5f : Math.max(4f, width * (72f / 1080f) - 15f);
    }
    public static float headerHeight(float width) { return width * (210f / 1080f); }
    public static float headerFont(float width) { return Math.max(12f, Math.min(18f, width * (38f / 1080f))); }
    public static float headerLine(float width) { return headerFont(width) * (51f / 38f); }
}
