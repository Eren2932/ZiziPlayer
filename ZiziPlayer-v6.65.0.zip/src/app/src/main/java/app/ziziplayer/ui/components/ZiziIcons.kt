package app.ziziplayer.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Свой набор глифов. 6.18.0 — транспорт, 6.24.1 — всё остальное приложение.
 *
 * ## Зачем
 *
 * `Icons.Filled.*` — рисунок Material 2014 года: залитые силуэты, плотность линий разная у
 * соседних знаков, скруглений почти нет. В интерфейсе Zizi, где всё построено на тонких линиях,
 * крупных радиусах и полупрозрачных подложках, они читаются как наклейки из другого приложения.
 * Особенно это било по мусорке: `Icons.Filled.DeleteOutline`, `DeleteForever` и `DeleteSweep` —
 * три разных по весу и по логике знака в одном столбце меню.
 *
 * ## Правила набора
 *
 * Один вес линии (2.05 из 24) на весь набор, круглые торцы и стыки, сетка 24, оптический центр
 * вместо геометрического. Поэтому «удалить», «скачать» и «поделиться» выглядят частями одного
 * шрифта, а не иконками из трёх пачек.
 *
 * Заливка у обводочных знаков не задаётся (`fill = null`), у сплошных ([solid]) — задаётся
 * чёрным: `Icon` красит вектор ColorFilter'ом, поэтому tint, акцент темы и подсветка активного
 * состояния работают одинаково и там, и там.
 *
 * Векторы собираются лениво и один раз: `ImageVector` неизменяем, а пересборка на каждой
 * рекомпозиции — это лишний `VectorPainter` на каждом кадре.
 *
 * 6.25.0: системных знаков больше не осталось ни одного. `PlayArrow`, `Pause`, `SkipNext`,
 * `SkipPrevious`, `ArrowBack`, `GraphicEq`, `Close` и `Refresh` в material-варианте держались
 * дольше всех «потому что они крупные и там Material безупречен». На проверку это оказалось
 * ровно наоборот: у material-транспорта треугольник Play построен по геометрическому центру
 * (центр описанного прямоугольника), а глаз видит центр массы треугольника — он на 1/6 ширины
 * левее. Поэтому Play в круглой кнопке всегда казался сдвинутым влево, и это правился отступом
 * в вызове, отдельно на каждом экране. Здесь треугольник смещён на свои 0.4 единицы сетки один
 * раз, внутри глифа: центр массы (7.6 + 7.6 + 19.6) / 3 = 11.6 против середины круга 12.
 *
 * Толстые знаки транспорта рисуются [heavy] — обводка увеличенной ширины с круглыми торцами,
 * а не залитый контур со скруглениями: скругление в залитом пути пришлось бы задавать дугами
 * в каждом углу, и при масштабировании с 22 до 56 dp радиус поехал бы вместе с путём. У
 * обводки радиус торца всегда равен половине её ширины, на любом размере.
 */
object ZiziIcons {
    /** Account/settings outline on the shared 24-unit grid. */
    val AccountGear by lazy { stroked("account_gear") {
        moveTo(9f, 3f); lineTo(15f, 3f); lineTo(15.6f, 5.4f); lineTo(17.3f, 6.4f)
        lineTo(19.7f, 5.8f); lineTo(22f, 10f); lineTo(20.2f, 11.8f); lineTo(20.2f, 13.6f)
        lineTo(21.7f, 15.4f); lineTo(19f, 19.3f); lineTo(16.7f, 18.6f); lineTo(15f, 19.5f)
        lineTo(14.4f, 22f); lineTo(9.6f, 22f); lineTo(9f, 19.5f); lineTo(7.3f, 18.6f)
        lineTo(5f, 19.3f); lineTo(2.3f, 15.4f); lineTo(3.8f, 13.6f); lineTo(3.8f, 11.8f)
        lineTo(2f, 10f); lineTo(4.3f, 5.8f); lineTo(6.7f, 6.4f); lineTo(8.4f, 5.4f); close()
        circle(12f, 12.5f, 3.7f)
    } }


    val Home by lazy { stroked("zizi_home") {
        moveTo(3f, 10.5f); lineTo(12f, 3f); lineTo(21f, 10.5f)
        moveTo(5f, 9f); lineTo(5f, 21f); lineTo(10f, 21f); lineTo(10f, 14f)
        lineTo(14f, 14f); lineTo(14f, 21f); lineTo(19f, 21f); lineTo(19f, 9f)
    } }


    // Selection toolbar: one optical weight, 24-unit grid, lazy immutable vectors.
    val SelectionClose by lazy { stroked("SelectionClose") {
        moveTo(6f, 6f); lineTo(18f, 18f); moveTo(18f, 6f); lineTo(6f, 18f)
    } }
    val SelectionAll by lazy { stroked("SelectionAll") {
        moveTo(8f, 3f); lineTo(5f, 3f); quadTo(3f, 3f, 3f, 5f); lineTo(3f, 8f)
        moveTo(16f, 3f); lineTo(19f, 3f); quadTo(21f, 3f, 21f, 5f); lineTo(21f, 8f)
        moveTo(3f, 16f); lineTo(3f, 19f); quadTo(3f, 21f, 5f, 21f); lineTo(8f, 21f)
        moveTo(16f, 21f); lineTo(19f, 21f); quadTo(21f, 21f, 21f, 19f); lineTo(21f, 16f)
        moveTo(7.5f, 12f); lineTo(10.5f, 15f); lineTo(16.5f, 9f)
    } }
    val SelectionPlay by lazy { stroked("SelectionPlay") {
        moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close()
    } }
    val SelectionFavorite by lazy { stroked("SelectionFavorite") {
        moveTo(12f, 20f)
        curveTo(9f, 17.5f, 3f, 13.5f, 3f, 8.5f)
        curveTo(3f, 3.5f, 9f, 2.5f, 12f, 7f)
        curveTo(15f, 2.5f, 21f, 3.5f, 21f, 8.5f)
        curveTo(21f, 13.5f, 15f, 17.5f, 12f, 20f); close()
    } }
    val SelectionAdd by lazy { stroked("SelectionAdd") {
        moveTo(3f, 5f); lineTo(17f, 5f)
        moveTo(3f, 11f); lineTo(12f, 11f)
        moveTo(3f, 17f); lineTo(9f, 17f)
        moveTo(17f, 12f); lineTo(17f, 22f)
        moveTo(12f, 17f); lineTo(22f, 17f)
    } }
    val SelectionMore by lazy { heavy("SelectionMore", 3f) {
        moveTo(5f, 12f); lineTo(5.1f, 12f)
        moveTo(12f, 12f); lineTo(12.1f, 12f)
        moveTo(19f, 12f); lineTo(19.1f, 12f)
    } }

    private const val STROKE = 2.05f

    private fun stroked(name: String, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /** Сплошной знак: «стоп» и «играть» обязаны быть тяжелее остальных, это команды. */
    private fun solid(name: String, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.Black),
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /**
     * Тяжёлый знак: обводка ширины [width] с круглыми торцами. Для «пауза», «вперёд», «назад» —
     * там, где нужна масса Play, но с идеально круглыми концами на любом кегле.
     */
    private fun heavy(name: String, width: Float, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = width,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /**
     * Смешанный знак: сначала обводка [strokePath] шириной [width], затем ЗАЛИТЫЙ [fillPath].
     *
     * 6.41.0. Понадобился ровно для «Медиатеки» референса: рамка и две полки там линии, а
     * треугольник внутри рамки — пятно. Рисовать треугольник обводкой нельзя: при 19 dp его
     * сторона всего 5 единиц сетки, и обводка 1.75 съедает середину — знак превращается в
     * кляксу. Два пути в одном векторе решают это без второго `Icon` и без слоёв в вёрстке.
     */
    private fun mixed(
        name: String,
        width: Float,
        strokePath: PathBuilder.() -> Unit,
        fillPath: PathBuilder.() -> Unit
    ): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = width,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { strokePath() }
            path(
                fill = SolidColor(Color.Black),
                strokeLineJoin = StrokeJoin.Round
            ) { fillPath() }
        }.build()

    /* ============================================================ транспорт (6.18.0) */

    /**
     * «Перемешать»: две S-образные линии меняются местами, обе со стрелкой вправо.
     * Кривые симметричны относительно центра, поэтому знак остаётся уравновешенным и в 23 dp.
     */
    /**
     * «Перемешать»: две скрещённые стрелки, нижняя проходит под верхней и потому разорвана.
     *
     * 6.29.3. До этого здесь были две сплошные S-кривые во всю ширину: они просто накладывались
     * в середине, и на тёмном фоне место пересечения читалось как узел, а не как перехлёст.
     * Референс строит знак иначе — короткий хвост, кривая, горизонтальная планка, стрелка, — а
     * перехлёст показывает разрывом одной из линий. Разрыв и есть смысл знака.
     *
     * Числа сняты с референса подгонкой по IoU (0.935 на маске 74x66). Знак зеркально симметричен
     * относительно y=12. Хвосты слева разнесены сильнее планок справа (±5.19 против ±4.66) — это
     * не огрех замера, а свойство оригинала: так сходящиеся линии не слипаются на входе в кривую.
     *
     * Габарит 17.99 из 24 против прежних 18.05 — вес и кегль знака не изменились, изменился
     * только рисунок, поэтому размеры на местах вызова трогать не нужно.
     */
    val Shuffle: ImageVector by lazy {
        stroked("zizi_shuffle") {
            // Верхняя линия: снизу-слева наверх-направо, сплошная — она идёт поверх.
            moveTo(4.03f, 17.187f)
            lineTo(5.3f, 17.187f)
            curveTo(8.088f, 17.187f, 13.191f, 7.338f, 16.087f, 7.338f)
            lineTo(19.97f, 7.338f)

            // Нижняя линия: сверху-слева вниз-направо, с разрывом на месте перехлёста.
            // Кривая разбита по де Кастельжо на t=0.333 и t=0.700 от исходной.
            moveTo(4.03f, 6.813f)
            lineTo(5.3f, 6.813f)
            curveTo(6.227f, 6.813f, 7.41f, 7.902f, 8.683f, 9.356f)
            moveTo(13.007f, 14.534f)
            curveTo(14.151f, 15.775f, 15.219f, 16.662f, 16.087f, 16.662f)
            lineTo(19.97f, 16.662f)

            // Наконечники смотрят строго вправо, а не вдоль диагонали: крыло 3.144 под 42.5°.
            moveTo(17.652f, 5.214f); lineTo(19.97f, 7.338f); lineTo(17.652f, 9.462f)
            moveTo(17.652f, 14.538f); lineTo(19.97f, 16.662f); lineTo(17.652f, 18.786f)
        }
    }

    /**
     * «Повторять»: скруглённый прямоугольник с разрывом внизу и стрелкой, входящей в разрыв.
     *
     * 6.29.2. До этого здесь было кольцо радиуса 7.4 — круг среди прямоугольных карточек плеера.
     * Референс — знак-скоба: широкая горизонтальная рамка с большим радиусом угла, разрыв не
     * сверху, а снизу-слева, и стрелка, которая возвращает дорожку в начало. Разница не
     * стилистическая: круг занимает вписанный квадрат, а рамка — всю ширину глифа, поэтому в ряду
     * транспорта знак читается на том же кегле заметно крупнее и не проваливается рядом с
     * «перемешать».
     *
     * ## Откуда числа
     *
     * Геометрия снята с референса пиксельно, а не подобрана на глаз: маска эталона (62 px по
     * ширине) и растр кандидата сравнивались по IoU, параметры (полуширина, радиус угла, толщина,
     * срез разрыва, остриё, разлёт крыльев) подбирались покоординатным спуском до 0.95 —
     * оставшееся расхождение это одна строка сглаживания на верхней грани JPEG-эталона.
     * Множитель перевода — 0.3725 единицы сетки на пиксель эталона, центр (30.5, 27.675) px → (12, 12).
     *
     * ## Почему три пути, а не один
     *
     *  * **Рамка — [StrokeCap.Butt].** В эталоне торцы у разрыва срезаны строго вертикально: и
     *    внизу у «хвоста», и вверху у цифры. Круглый торец на срезе 2.24 шириной сразу видно —
     *    разрыв перестаёт быть щелью и превращается в две капли.
     *  * **Стрелка — [StrokeCap.Round].** Остриё и оба крыла в эталоне скруглены. Один путь на
     *    рамку и стрелку такое сочетание задать не даёт: cap задаётся на путь целиком.
     *  * **Цифра — свой путь**, потому что у неё срезаны оба торца, а стык флажка со стволом
     *    скруглён; join у пути общий, cap тоже, и это ровно её комбинация.
     *
     * Толщина 2.24 против 2.05 у остального набора — это не разнобой: доля от ширины знака у
     * референса 0.098, и при кегле 0.45 диаметра кнопки (см. PlayerScreen) на экране получается
     * ровно 2.05 dp, как у соседей по ряду.
     *
     * Точка активного состояния в глиф не входит: её рисует TransportButton под знаком, иначе
     * рамка со стрелкой ужалась бы на четверть, чтобы освободить место под точку внутри той же
     * сетки 24, и «повторять» стало бы самым мелким знаком в ряду.
     */
    val Repeat: ImageVector by lazy { repeatGlyph("zizi_repeat", one = false) }

    /**
     * «Повторять один»: та же рамка с разрывом вверху и «1» в разрыве. Ствол цифры чуть правее
     * центра (12.86 против 12) — флажок висит слева, и по массе знак уравновешен именно так;
     * поставить ствол ровно по центру значит увести всю цифру влево.
     */
    val RepeatOne: ImageVector by lazy { repeatGlyph("zizi_repeat_one", one = true) }

    /** Толщина обводки знака «повторять». Своя, см. KDoc [Repeat]. */
    private const val REPEAT_STROKE = 2.24f

    private fun repeatGlyph(name: String, one: Boolean): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = REPEAT_STROKE,
                strokeLineCap = StrokeCap.Butt,
                strokeLineJoin = StrokeJoin.Round
            ) { repeatFrame(one) }
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = REPEAT_STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { repeatArrow() }
            if (one) {
                path(
                    fill = null,
                    stroke = SolidColor(Color.Black),
                    strokeLineWidth = REPEAT_STROKE,
                    strokeLineCap = StrokeCap.Butt,
                    strokeLineJoin = StrokeJoin.Round
                ) { repeatDigitOne() }
            }
        }.build()

    /**
     * Рамка: срез разрыва (6.79, 19.24) → низ влево → по часовой вокруг всех четырёх углов →
     * обратно по нижней грани к острию стрелки (10.77). Радиус угла 3.46 по осевой линии.
     *
     * Обход именно по часовой стрелке, поэтому у всех четырёх дуг `isPositiveArc = true`: в
     * системе с осью Y вниз положительное направление — по часовой.
     */
    private fun PathBuilder.repeatFrame(one: Boolean) {
        moveTo(6.79f, 19.24f)
        lineTo(5.18f, 19.24f)
        // радиусы, поворот, длинная дуга, по часовой, конечная точка
        arcTo(3.46f, 3.46f, 0f, false, true, 1.72f, 15.78f)
        lineTo(1.72f, 6.06f)
        arcTo(3.46f, 3.46f, 0f, false, true, 5.18f, 2.60f)
        if (one) {
            // Верхняя грань разорвана под цифру: та же щель 6.79 … 17.22, что и внизу.
            lineTo(6.79f, 2.60f)
            moveTo(17.22f, 2.60f)
        }
        lineTo(18.82f, 2.60f)
        arcTo(3.46f, 3.46f, 0f, false, true, 22.28f, 6.06f)
        lineTo(22.28f, 15.78f)
        arcTo(3.46f, 3.46f, 0f, false, true, 18.82f, 19.24f)
        lineTo(10.77f, 19.24f)
    }

    /**
     * Стрелка: крылья ±3.35 по вертикали при выносе 3.24 по горизонтали — половинный угол 46°,
     * как в эталоне. Остриё стоит ровно на осевой линии нижней грани (19.24), поэтому стык
     * рамки и стрелки не виден: круглое остриё накрывает срезанный торец грани.
     */
    private fun PathBuilder.repeatArrow() {
        moveTo(14.01f, 15.89f); lineTo(10.77f, 19.24f); lineTo(14.01f, 22.59f)
    }

    /** «1»: флажок и ствол одной ломаной, стык скруглён join'ом, оба торца срезаны. */
    private fun PathBuilder.repeatDigitOne() {
        moveTo(10.12f, 3.52f); lineTo(12.86f, 1.32f); lineTo(12.86f, 10.82f)
    }

    /* ============================================================ удаление */

    /**
     * Корзина. Один силуэт на все три «удалить» в приложении, разница только в приписке —
     * поэтому «убрать из Zizi», «удалить все загрузки» и «удалить файл» видно как родственные
     * действия разной силы, а не как три случайных знака.
     */
    val Trash: ImageVector by lazy { stroked("zizi_trash") { can(); ribs() } }

    /** «Удалить всё»: та же корзина и линии движения — знак «сразу несколько». */
    val TrashSweep: ImageVector by lazy {
        stroked("zizi_trash_sweep") {
            can()
            moveTo(10.2f, 10.8f); lineTo(10.5f, 15.6f)
            moveTo(13.8f, 10.8f); lineTo(13.5f, 15.6f)
            moveTo(1.9f, 10.2f); lineTo(3.9f, 10.2f)
            moveTo(1.9f, 14.0f); lineTo(3.9f, 14.0f)
        }
    }

    /** «Удалить навсегда»: корзина с крестом внутри. Необратимость видно до нажатия. */
    val TrashForever: ImageVector by lazy {
        stroked("zizi_trash_forever") {
            can()
            moveTo(9.9f, 10.9f); lineTo(14.1f, 15.5f)
            moveTo(14.1f, 10.9f); lineTo(9.9f, 15.5f)
        }
    }

    private fun PathBuilder.can() {
        // Крышка и ручка отдельными подпутями: так ручка не «врастает» в крышку углом.
        moveTo(3.9f, 6.9f); lineTo(20.1f, 6.9f)
        moveTo(9.4f, 6.9f); lineTo(9.4f, 4.9f); lineTo(14.6f, 4.9f); lineTo(14.6f, 6.9f)
        // Корпус слегка сужается вниз — иначе корзина читается как коробка.
        moveTo(6.1f, 7.4f); lineTo(7.0f, 19.1f); lineTo(17.0f, 19.1f); lineTo(17.9f, 7.4f)
    }

    private fun PathBuilder.ribs() {
        moveTo(10.2f, 10.8f); lineTo(10.5f, 15.6f)
        moveTo(13.8f, 10.8f); lineTo(13.5f, 15.6f)
    }

    /* ============================================================ загрузки */

    /** «Скачать»: стрелка входит в лоток. Лоток — это «на устройство», без него это просто вниз. */
    val Download: ImageVector by lazy {
        stroked("zizi_download") {
            moveTo(12f, 3.6f); lineTo(12f, 14.4f)
            moveTo(8.4f, 11.0f); lineTo(12f, 14.6f); lineTo(15.6f, 11.0f)
            tray()
        }
    }

    /** Collection action: circled download, distinct from the tray used in track menus. */
    val DownloadCircle: ImageVector by lazy {
        stroked("zizi_download_circle") {
            circle(12f, 12f, 10.6f)
            moveTo(12f, 5.8f); lineTo(12f, 17.0f)
            moveTo(7.8f, 12.8f); lineTo(12f, 17.0f); lineTo(16.2f, 12.8f)
        }
    }

    /** Exact collection-button canvas: 140 px disk, 42 x 47 px triangle in the reference.
     * Render at the disk size. Mini-player and full-player glyphs remain unchanged.
     */
    val CollectionPlayFilled: ImageVector by lazy {
        ImageVector.Builder(name = "zizi_collection_play", defaultWidth = 24.dp, defaultHeight = 24.dp,
            viewportWidth = 140f, viewportHeight = 140f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(54f, 45f); lineTo(96f, 69f); lineTo(54f, 92f); close()
            }
        }.build()
    }

    /** «Скачано»: тот же лоток, но вместо стрелки галочка. Одна семья, разные состояния. */
    val DownloadDone: ImageVector by lazy {
        stroked("zizi_download_done") {
            moveTo(7.4f, 9.6f); lineTo(10.7f, 13.0f); lineTo(16.6f, 5.2f)
            tray()
        }
    }

    /** «Скачать из сети»: облако со стрелкой внутрь. Для настроек каталога. */
    val CloudDownload: ImageVector by lazy {
        stroked("zizi_cloud_download") {
            cloud()
            moveTo(12f, 8.6f); lineTo(12f, 15.4f)
            moveTo(9.2f, 12.6f); lineTo(12f, 15.6f); lineTo(14.8f, 12.6f)
        }
    }

    private fun PathBuilder.tray() {
        moveTo(4.6f, 16.4f); lineTo(4.6f, 19.4f); lineTo(19.4f, 19.4f); lineTo(19.4f, 16.4f)
    }

    /* ============================================================ облако и сеть */

    val Cloud: ImageVector by lazy { stroked("zizi_cloud") { cloud() } }

    /** «Только из сети / связи нет»: облако, перечёркнутое по диагонали. */
    val CloudOff: ImageVector by lazy {
        stroked("zizi_cloud_off") {
            cloud()
            moveTo(3.6f, 3.6f); lineTo(20.4f, 20.4f)
        }
    }

    /** «Нашёлся в каталоге»: облако с галочкой. */
    val CloudCheck: ImageVector by lazy {
        stroked("zizi_cloud_check") {
            cloud()
            moveTo(8.8f, 12.8f); lineTo(11.2f, 15.2f); lineTo(15.4f, 10.2f)
        }
    }

    private fun PathBuilder.cloud() {
        moveTo(17.0f, 18.2f)
        curveTo(19.5f, 18.2f, 21.6f, 16.2f, 21.6f, 13.7f)
        curveTo(21.6f, 11.3f, 19.7f, 9.3f, 17.3f, 9.2f)
        curveTo(16.5f, 6.2f, 13.7f, 4.1f, 10.6f, 4.6f)
        curveTo(7.3f, 5.2f, 5.0f, 8.1f, 5.1f, 11.4f)
        curveTo(3.4f, 12.2f, 2.5f, 14.1f, 3.0f, 15.9f)
        curveTo(3.5f, 17.4f, 4.9f, 18.3f, 6.5f, 18.2f)
        lineTo(17.0f, 18.2f)
    }

    /** Wi-Fi: три дуги одного центра и точка. */
    val Wifi: ImageVector by lazy {
        stroked("zizi_wifi") {
            moveTo(2.9f, 9.5f); arcTo(12.9f, 12.9f, 0f, false, true, 21.1f, 9.5f)
            moveTo(5.9f, 12.6f); arcTo(8.6f, 8.6f, 0f, false, true, 18.1f, 12.6f)
            moveTo(8.9f, 15.7f); arcTo(4.4f, 4.4f, 0f, false, true, 15.1f, 15.7f)
            moveTo(12f, 19.2f); lineTo(12.05f, 19.2f)
        }
    }

    /** «Проверить связь»: столбики сигнала и галочка. */
    val Network: ImageVector by lazy {
        stroked("zizi_network") {
            moveTo(4.6f, 18.4f); lineTo(4.6f, 14.6f)
            moveTo(9.0f, 18.4f); lineTo(9.0f, 11.0f)
            moveTo(13.4f, 18.4f); lineTo(13.4f, 7.4f)
            moveTo(14.9f, 13.6f); lineTo(17.2f, 15.9f); lineTo(21.2f, 10.6f)
        }
    }

    /** Глобус: «язык интерфейса» и «источник в интернете». */
    val Globe: ImageVector by lazy {
        stroked("zizi_globe") {
            circle(12f, 12f, 8.4f)
            moveTo(3.6f, 12f); lineTo(20.4f, 12f)
            moveTo(12f, 3.6f)
            curveTo(8.4f, 6.6f, 8.4f, 17.4f, 12f, 20.4f)
            curveTo(15.6f, 17.4f, 15.6f, 6.6f, 12f, 3.6f)
        }
    }

    /** Сервер: два блока с индикаторами. Для «свой резолвер». */
    val Server: ImageVector by lazy {
        stroked("zizi_server") {
            moveTo(4.2f, 5.4f); lineTo(19.8f, 5.4f); lineTo(19.8f, 10.4f); lineTo(4.2f, 10.4f)
            lineTo(4.2f, 5.4f)
            moveTo(4.2f, 13.6f); lineTo(19.8f, 13.6f); lineTo(19.8f, 18.6f); lineTo(4.2f, 18.6f)
            lineTo(4.2f, 13.6f)
            moveTo(7.4f, 7.9f); lineTo(7.45f, 7.9f)
            moveTo(7.4f, 16.1f); lineTo(7.45f, 16.1f)
        }
    }

    /** Диск: «сколько занято». Цилиндр, а не абстрактная коробка. */
    val Storage: ImageVector by lazy {
        stroked("zizi_storage") {
            moveTo(4.2f, 7.0f)
            curveTo(4.2f, 5.3f, 7.7f, 4.0f, 12f, 4.0f)
            curveTo(16.3f, 4.0f, 19.8f, 5.3f, 19.8f, 7.0f)
            curveTo(19.8f, 8.7f, 16.3f, 10.0f, 12f, 10.0f)
            curveTo(7.7f, 10.0f, 4.2f, 8.7f, 4.2f, 7.0f)
            moveTo(4.2f, 7.0f); lineTo(4.2f, 17.0f)
            curveTo(4.2f, 18.7f, 7.7f, 20.0f, 12f, 20.0f)
            curveTo(16.3f, 20.0f, 19.8f, 18.7f, 19.8f, 17.0f)
            lineTo(19.8f, 7.0f)
            moveTo(4.2f, 12.0f)
            curveTo(4.2f, 13.7f, 7.7f, 15.0f, 12f, 15.0f)
            curveTo(16.3f, 15.0f, 19.8f, 13.7f, 19.8f, 12.0f)
        }
    }

    /* ============================================================ папки */

    val Folder: ImageVector by lazy { stroked("zizi_folder") { folder() } }

    /** «Открыть папку»: у открытой папки передняя стенка отведена вперёд. */
    val FolderOpen: ImageVector by lazy {
        stroked("zizi_folder_open") {
            moveTo(3.6f, 18.4f); lineTo(3.6f, 6.2f); lineTo(9.4f, 6.2f); lineTo(11.2f, 8.8f)
            lineTo(20.4f, 8.8f); lineTo(20.4f, 11.4f)
            moveTo(2.6f, 18.6f); lineTo(5.8f, 11.6f); lineTo(22.0f, 11.6f); lineTo(18.8f, 18.6f)
            lineTo(2.6f, 18.6f)
        }
    }

    /**
     * Папка с музыкой (6.27.1).
     *
     * Заменяет [FolderOpen] там, где знак означает не действие «открыть», а сущность «папка с
     * треками»: раздел «Папки» в плеере и строки списка папок. Причина — вес. У [FolderOpen]
     * передняя стенка отведена вперёд, из-за чего в глифе три длинные линии вместо одной и
     * пятно получается заметно темнее соседних знаков в том же ряду: в столбце меню и в ряду
     * чипов он выпирал как будто выделенный, хотя выделенным не был.
     *
     * Здесь корпус папки — тот же [folder], что у «добавить папку», то есть ровно тот вес, что
     * у всего набора, а смысл несёт то, что внутри.
     *
     * 6.34.0: внутри больше не нота, а эквалайзер из трёх столбиков. Нота с флажком на 22 dp
     * нижней строки плеера не читалась — головка почти касалась стенки, штиль уходил в верхнюю
     * кромку, — и знак выглядел как папка с царапиной. Столбики стоят на общей линии и
     * различимы на всех размерах, где знак вообще применяется (19–24 dp).
     */
    val FolderMusic: ImageVector by lazy {
        stroked("zizi_folder_music") {
            folder()
            // 6.34.0. Внутри папки не нота, а эквалайзер из трёх столбиков.
            //
            // Нота с флажком в 22 dp нижней строки плеера не читалась: головка радиусом 1.8
            // почти касалась стенки папки, штиль с флажком уходил в верхнюю кромку, и знак
            // выглядел как папка с царапиной. Столбики стоят на общей линии, между ними
            // 3.5 при обводке 2.05 — просвет 1.45, он держится и на 19 dp списка папок.
            moveTo(8.5f, 16.4f); lineTo(8.5f, 13.6f)
            moveTo(12.0f, 16.4f); lineTo(12.0f, 11.6f)
            moveTo(15.5f, 16.4f); lineTo(15.5f, 14.6f)
        }
    }

    /** «Добавить папку»: папка с плюсом. */
    val FolderPlus: ImageVector by lazy {
        stroked("zizi_folder_plus") {
            folder()
            moveTo(12f, 11.4f); lineTo(12f, 16.6f)
            moveTo(9.4f, 14.0f); lineTo(14.6f, 14.0f)
        }
    }

    private fun PathBuilder.folder() {
        moveTo(3.6f, 18.6f); lineTo(3.6f, 6.2f); lineTo(9.4f, 6.2f); lineTo(11.2f, 8.8f)
        lineTo(20.4f, 8.8f); lineTo(20.4f, 18.6f); lineTo(3.6f, 18.6f)
    }

    /* ============================================================ очередь и плейлисты */

    /**
     * Очередь (6.34.0): текущий трек капсулой сверху, за ним две строки.
     *
     * Прежний знак был «три линии и нота справа»: нота стояла вплотную к концам линий, на 22 dp
     * головка сливалась с нижней строкой, и в ряду с папкой два знака выглядели одинаково
     * мелкорябыми. Здесь смысл несёт форма, а не деталь: капсула — то, что играет сейчас,
     * строки — то, что после. Последняя строка короче — очередь не обрывается, а продолжается.
     */
    val Queue: ImageVector by lazy {
        stroked("zizi_queue") {
            moveTo(5.6f, 4.8f); lineTo(18.4f, 4.8f)
            arcTo(2.2f, 2.2f, 0f, false, true, 20.6f, 7.0f)
            lineTo(20.6f, 7.4f)
            arcTo(2.2f, 2.2f, 0f, false, true, 18.4f, 9.6f)
            lineTo(5.6f, 9.6f)
            arcTo(2.2f, 2.2f, 0f, false, true, 3.4f, 7.4f)
            lineTo(3.4f, 7.0f)
            arcTo(2.2f, 2.2f, 0f, false, true, 5.6f, 4.8f)
            moveTo(3.4f, 14.2f); lineTo(20.6f, 14.2f)
            moveTo(3.4f, 18.6f); lineTo(17.2f, 18.6f)
        }
    }

    /** «Играть следующим»: список и треугольник — действие происходит сразу после текущего. */
    val PlayNext: ImageVector by lazy {
        stroked("zizi_play_next") {
            listLines(rightEdge = 13.4f)
            moveTo(16.0f, 10.8f); lineTo(21.4f, 14.6f); lineTo(16.0f, 18.4f); lineTo(16.0f, 10.8f)
        }
    }

    /** «Добавить в очередь» и «в плейлист»: список и плюс. */
    val QueueAdd: ImageVector by lazy {
        stroked("zizi_queue_add") {
            listLines(rightEdge = 13.4f)
            moveTo(18.6f, 11.4f); lineTo(18.6f, 18.2f)
            moveTo(15.2f, 14.8f); lineTo(22.0f, 14.8f)
        }
    }

    /** «Убрать из плейлиста»: список и минус. Ровно на один штрих мягче, чем корзина. */
    val QueueRemove: ImageVector by lazy {
        stroked("zizi_queue_remove") {
            listLines(rightEdge = 13.4f)
            moveTo(15.2f, 14.8f); lineTo(22.0f, 14.8f)
        }
    }

    private fun PathBuilder.listLines(rightEdge: Float) {
        moveTo(3.4f, 6.6f); lineTo(rightEdge, 6.6f)
        moveTo(3.4f, 11.0f); lineTo(rightEdge, 11.0f)
        moveTo(3.4f, 15.4f); lineTo(rightEdge - 3.4f, 15.4f)
    }

    /* ============================================================ базовые действия */

    /** «Поделиться»: файл выходит наружу. Стрелка вверх из открытой коробки. */
    val Share: ImageVector by lazy {
        stroked("zizi_share") {
            moveTo(12f, 3.4f); lineTo(12f, 13.8f)
            moveTo(8.6f, 6.8f); lineTo(12f, 3.4f); lineTo(15.4f, 6.8f)
            moveTo(7.6f, 9.6f); lineTo(5.2f, 9.6f); lineTo(5.2f, 19.6f); lineTo(18.8f, 19.6f)
            lineTo(18.8f, 9.6f); lineTo(16.4f, 9.6f)
        }
    }

    val Close: ImageVector by lazy {
        stroked("zizi_close") {
            moveTo(5.8f, 5.8f); lineTo(18.2f, 18.2f)
            moveTo(18.2f, 5.8f); lineTo(5.8f, 18.2f)
        }
    }

    val Check: ImageVector by lazy {
        stroked("zizi_check") { moveTo(5.2f, 12.6f); lineTo(9.8f, 17.2f); lineTo(18.8f, 6.4f) }
    }

    /** «Выбрать несколько»: две галочки. */
    val CheckDouble: ImageVector by lazy {
        stroked("zizi_check_double") {
            moveTo(2.4f, 13.0f); lineTo(6.2f, 16.8f); lineTo(13.0f, 8.6f)
            moveTo(10.6f, 16.6f); lineTo(11.4f, 17.4f); lineTo(21.6f, 6.4f)
        }
    }

    val Plus: ImageVector by lazy {
        stroked("zizi_plus") {
            moveTo(12f, 4.8f); lineTo(12f, 19.2f)
            moveTo(4.8f, 12f); lineTo(19.2f, 12f)
        }
    }

    /**
     * «Пересканировать»: дуга 270° с наконечником — круг, у которого есть начало.
     *
     * Точки посчитаны, а не подобраны: дуга радиуса 7.4 вокруг (12, 12) от θ = 45° по часовой
     * до θ = 315°, разрыв ровно справа. Наконечник стоит по касательной к концу дуги (барбы под
     * ±30° к направлению движения), поэтому стрелка «продолжает» линию, а не приклеена углом —
     * в первой версии 6.24.1 здесь был именно такой угол, и знак читался как сломанный.
     */
    val Refresh: ImageVector by lazy {
        stroked("zizi_refresh") {
            moveTo(17.23f, 17.23f)
            arcTo(7.4f, 7.4f, 0f, true, true, 17.23f, 6.77f)
            moveTo(16.4f, 3.68f); lineTo(17.23f, 6.77f); lineTo(14.14f, 5.94f)
        }
    }

    val Info: ImageVector by lazy {
        stroked("zizi_info") {
            circle(12f, 12f, 8.4f)
            moveTo(12f, 11.0f); lineTo(12f, 16.4f)
            moveTo(12f, 7.6f); lineTo(12.05f, 7.6f)
        }
    }

    val Person: ImageVector by lazy {
        stroked("zizi_person") {
            circle(12f, 8.2f, 3.6f)
            moveTo(5.2f, 19.6f)
            curveTo(5.2f, 15.6f, 8.3f, 13.6f, 12f, 13.6f)
            curveTo(15.7f, 13.6f, 18.8f, 15.6f, 18.8f, 19.6f)
        }
    }

    /**
     * ЛУПА 6.41.0 — снята с эталона попиксельно, а не подогнана на глаз.
     *
     * Замер эталона (скриншот знака, 110 px ширины): габарит глифа 61 x 60 px, внешний
     * диаметр кольца 54 px, ширина линии 5.5 px, ручка уходит по диагонали до (85, 133) от
     * левого верхнего угла глифа (27, 76). Отсюда три отношения, которые и есть «тот же знак»:
     *
     *      линия / габарит .......... 5.5 / 61 = 0.090   (у нас было 0.113 — знак был жирнее)
     *      кольцо / габарит ......... 54 / 61 = 0.885    (было 0.816 — голова была мельче)
     *      вылет ручки за кольцо .... 20 px = 0.33 диаметра
     *
     * Пересчёт в сетку 24 при глифе 22.4 единицы (масштаб 0.3672): центр (10.5, 10.5), радиус
     * средней линии 8.9, обводка 2.0, ручка от (16.5, 16.5) до (22.0, 22.0).
     *
     * Глиф теперь занимает почти весь квадрат сетки — 22.4 из 24 против 18.2 у остального
     * набора. Это не ошибка центрирования: у эталона лупа именно такая, «с полями» она
     * перестаёт быть этим знаком. Плата — кегли на местах вызова: одна и та же лупа при том же
     * dp стала на 23 % крупнее, поэтому размеры в вызовах уменьшены в 0.81 раза (см. TabBar,
     * SearchScreen, Sheets). Один знак, один коэффициент, ни одного «подгоню тут на глаз».
     *
     * Обводка 2.0 вместо общего веса набора 2.05 — не вольность, а следствие замера: 0.090 от
     * 22.4 даёт ровно 2.02. Разница с набором 0.05 единицы, то есть 0.04 dp при кегле 19.
     */
    internal const val LENS_STROKE = 2.0f

    private fun PathBuilder.lens() {
        circle(10.5f, 10.5f, 8.9f)
        // Ручка начинается ВНУТРИ кольца (16.5 против 16.79 на его средней линии): иначе на
        // дробном масштабе между дугой и линией остаётся щель в полпикселя.
        moveTo(16.5f, 16.5f); lineTo(22.0f, 22.0f)
    }

    val Search: ImageVector by lazy {
        heavy("zizi_search", LENS_STROKE) { lens() }
    }

    /** «Не нашлось»: та же лупа, перечёркнутая. Наклонная линия по хорде нового кольца. */
    val SearchOff: ImageVector by lazy {
        heavy("zizi_search_off", LENS_STROKE) {
            lens()
            moveTo(5.9f, 15.1f); lineTo(15.1f, 5.9f)
        }
    }

    /**
     * Микрофон — знак, которого в 6.40.2 не было вовсе: голосового ввода в приложении нет.
     * На эталоне он стоит в правом конце поля поиска, и здесь он делает то же, что там:
     * открывает системное распознавание речи (см. SearchScreen), а не изображает кнопку.
     *
     * Замер эталона: высота знака 25 px при поле 141 px — то есть 22 dp кегля на сетке 24.
     */
    val Mic: ImageVector by lazy {
        stroked("zizi_mic") {
            roundedRect(9.2f, 3.2f, 14.8f, 13.2f, 2.8f)
            moveTo(6.4f, 11.2f)
            lineTo(6.4f, 12.2f)
            curveTo(6.4f, 15.3f, 8.9f, 17.8f, 12.0f, 17.8f)
            curveTo(15.1f, 17.8f, 17.6f, 15.3f, 17.6f, 12.2f)
            lineTo(17.6f, 11.2f)
            moveTo(12.0f, 17.8f); lineTo(12.0f, 20.6f)
            moveTo(8.7f, 20.6f); lineTo(15.3f, 20.6f)
        }
    }

    /**
     * «Ещё»: три точки в столбик.
     *
     * 6.29.3. На общем весе набора (2.05) точки выходили 1.88 dp при шаге 6.6 — на тёмном фоне
     * это читалось как пунктир, а не как кнопка. В референсе отношение диаметра к шагу 0.47,
     * у нас было 0.31, то есть знак был вдвое жиже оригинала при том же габарите.
     *
     * Поэтому это единственный знак набора со своей шириной линии: 3.65 при шаге 7.775. Правило
     * единого веса нарушено осознанно — точка это не штрих, её вес задаёт не толщина линии, а
     * площадь пятна, и подчинять её общему 2.05 значит рисовать другой знак.
     */
    private const val MORE_DOT = 3.65f

    val More: ImageVector by lazy {
        heavy("zizi_more", MORE_DOT) {
            moveTo(12f, 4.225f); lineTo(12.05f, 4.225f)
            moveTo(12f, 12f); lineTo(12.05f, 12f)
            moveTo(12f, 19.775f); lineTo(12.05f, 19.775f)
        }
    }

    val ChevronRight: ImageVector by lazy {
        stroked("zizi_chevron_right") { moveTo(9.4f, 5.4f); lineTo(16.0f, 12f); lineTo(9.4f, 18.6f) }
    }

    val ChevronUp: ImageVector by lazy {
        stroked("zizi_chevron_up") { moveTo(5.4f, 14.6f); lineTo(12f, 8.0f); lineTo(18.6f, 14.6f) }
    }

    val ChevronDown: ImageVector by lazy {
        stroked("zizi_chevron_down") { moveTo(5.4f, 9.4f); lineTo(12f, 16.0f); lineTo(18.6f, 9.4f) }
    }

    val Copy: ImageVector by lazy {
        stroked("zizi_copy") {
            moveTo(8.6f, 8.6f); lineTo(19.4f, 8.6f); lineTo(19.4f, 19.4f); lineTo(8.6f, 19.4f)
            lineTo(8.6f, 8.6f)
            moveTo(5.8f, 15.4f); lineTo(4.6f, 15.4f); lineTo(4.6f, 4.6f); lineTo(15.4f, 4.6f)
            lineTo(15.4f, 5.8f)
        }
    }

    val Paste: ImageVector by lazy {
        stroked("zizi_paste") {
            moveTo(8.6f, 5.6f); lineTo(4.8f, 5.6f); lineTo(4.8f, 20.0f); lineTo(19.2f, 20.0f)
            lineTo(19.2f, 5.6f); lineTo(15.4f, 5.6f)
            moveTo(8.8f, 3.6f); lineTo(15.2f, 3.6f); lineTo(15.2f, 7.4f); lineTo(8.8f, 7.4f)
            lineTo(8.8f, 3.6f)
        }
    }

    /** «Ищем…»: песочные часы. */
    val Hourglass: ImageVector by lazy {
        stroked("zizi_hourglass") {
            moveTo(6.8f, 3.8f); lineTo(17.2f, 3.8f); lineTo(17.2f, 7.2f); lineTo(12f, 12f)
            lineTo(17.2f, 16.8f); lineTo(17.2f, 20.2f); lineTo(6.8f, 20.2f); lineTo(6.8f, 16.8f)
            lineTo(12f, 12f); lineTo(6.8f, 7.2f); lineTo(6.8f, 3.8f)
        }
    }

    /** «Уже на устройстве»: телефон. */
    val Phone: ImageVector by lazy {
        stroked("zizi_phone") {
            moveTo(6.8f, 3.6f); lineTo(17.2f, 3.6f); lineTo(17.2f, 20.4f); lineTo(6.8f, 20.4f)
            lineTo(6.8f, 3.6f)
            moveTo(10.4f, 18.0f); lineTo(13.6f, 18.0f)
        }
    }

    /** История: часы. Стрелка «назад» в 20 dp превращается в кашу, циферблат — нет. */
    val Clock: ImageVector by lazy {
        stroked("zizi_clock") {
            circle(12f, 12f, 8.2f)
            moveTo(12f, 7.2f); lineTo(12f, 12.4f); lineTo(15.8f, 14.6f)
        }
    }

    /** Таймер сна: месяц. Через полумесяц «выключится само» понятно без подписи. */
    val Moon: ImageVector by lazy {
        stroked("zizi_moon") {
            moveTo(20.4f, 14.6f)
            curveTo(19.2f, 18.4f, 15.4f, 21.0f, 11.4f, 20.4f)
            curveTo(6.9f, 19.7f, 3.6f, 15.7f, 4.1f, 11.2f)
            curveTo(4.5f, 7.3f, 7.2f, 4.2f, 10.9f, 3.4f)
            curveTo(8.8f, 6.6f, 8.8f, 10.8f, 11.2f, 13.4f)
            curveTo(13.6f, 16.0f, 17.2f, 16.4f, 20.4f, 14.6f)
        }
    }

    /** Скорость: спидометр со стрелкой вправо-вверх. */
    val Speed: ImageVector by lazy {
        stroked("zizi_speed") {
            moveTo(4.0f, 16.4f); arcTo(8.2f, 8.2f, 0f, false, true, 20.0f, 16.4f)
            // Стрелка кончается ВНУТРИ шкалы: доведённая до дуги, она сливалась с ней в углу.
            moveTo(12f, 16.4f); lineTo(15.8f, 11.6f)
            moveTo(12f, 16.4f); lineTo(12.05f, 16.4f)
        }
    }

    /** Эквалайзер: четыре столбика разной высоты. */
    val Equalizer: ImageVector by lazy {
        stroked("zizi_equalizer") {
            moveTo(5.6f, 9.4f); lineTo(5.6f, 14.6f)
            moveTo(9.9f, 5.6f); lineTo(9.9f, 18.4f)
            moveTo(14.1f, 8.2f); lineTo(14.1f, 15.8f)
            moveTo(18.4f, 10.8f); lineTo(18.4f, 13.2f)
        }
    }

    /** Сортировка: строки по убыванию и стрелка направления. */
    val Sort: ImageVector by lazy {
        stroked("zizi_sort") {
            moveTo(4.2f, 7.0f); lineTo(13.4f, 7.0f)
            moveTo(4.2f, 12.0f); lineTo(10.6f, 12.0f)
            moveTo(4.2f, 17.0f); lineTo(7.8f, 17.0f)
            moveTo(17.6f, 6.4f); lineTo(17.6f, 17.6f)
            moveTo(14.6f, 14.4f); lineTo(17.6f, 17.8f); lineTo(20.6f, 14.4f)
        }
    }

    /* ============================================================ видимость и доступ */

    val Eye: ImageVector by lazy { stroked("zizi_eye") { eye(); circle(12f, 12f, 3.0f) } }

    val EyeOff: ImageVector by lazy {
        stroked("zizi_eye_off") {
            eye()
            circle(12f, 12f, 3.0f)
            moveTo(3.6f, 20.4f); lineTo(20.4f, 3.6f)
        }
    }

    private fun PathBuilder.eye() {
        moveTo(2.4f, 12f)
        curveTo(5.2f, 7.2f, 8.4f, 4.9f, 12f, 4.9f)
        curveTo(15.6f, 4.9f, 18.8f, 7.2f, 21.6f, 12f)
        curveTo(18.8f, 16.8f, 15.6f, 19.1f, 12f, 19.1f)
        curveTo(8.4f, 19.1f, 5.2f, 16.8f, 2.4f, 12f)
    }

    val Key: ImageVector by lazy {
        stroked("zizi_key") {
            circle(7.6f, 12f, 3.6f)
            moveTo(11.2f, 12f); lineTo(20.6f, 12f)
            moveTo(17.2f, 12f); lineTo(17.2f, 15.6f)
            moveTo(20.2f, 12f); lineTo(20.2f, 14.8f)
        }
    }

    /** «Служебный доступ»: замок с откинутой дугой — открыт, но всё ещё замок. */
    val LockOpen: ImageVector by lazy {
        stroked("zizi_lock_open") {
            moveTo(5.6f, 11.4f); lineTo(18.4f, 11.4f); lineTo(18.4f, 19.6f); lineTo(5.6f, 19.6f)
            lineTo(5.6f, 11.4f)
            moveTo(9.2f, 11.4f); lineTo(9.2f, 8.2f)
            curveTo(9.2f, 5.9f, 11.1f, 4.2f, 13.4f, 4.4f)
            curveTo(15.4f, 4.6f, 16.8f, 6.2f, 16.8f, 8.2f)
        }
    }

    /**
     * Отчёт о сбое: жук. Единственный знак набора, который можно назвать смешным.
     *
     * Тело — капсула, а не круг: круг с шестью лучами (так было в первой версии 6.24.1)
     * читается как солнце, а не как насекомое. Панцирь вытянут по вертикали, спинка отделена
     * линией, лап по две на сторону — этого достаточно, чтобы знак узнавался в 20 dp.
     */
    val Bug: ImageVector by lazy {
        stroked("zizi_bug") {
            moveTo(7.4f, 12.6f)
            arcTo(4.6f, 4.6f, 0f, false, true, 16.6f, 12.6f)
            lineTo(16.6f, 15.2f)
            curveTo(16.6f, 18.4f, 14.5f, 20.4f, 12f, 20.4f)
            curveTo(9.5f, 20.4f, 7.4f, 18.4f, 7.4f, 15.2f)
            lineTo(7.4f, 12.6f)
            moveTo(7.6f, 13.1f); lineTo(16.4f, 13.1f)
            moveTo(9.5f, 8.7f); lineTo(7.9f, 5.9f)
            moveTo(14.5f, 8.7f); lineTo(16.1f, 5.9f)
            moveTo(7.4f, 13.9f); lineTo(4.0f, 12.2f)
            moveTo(7.4f, 17.3f); lineTo(4.0f, 18.8f)
            moveTo(16.6f, 13.9f); lineTo(20.0f, 12.2f)
            moveTo(16.6f, 17.3f); lineTo(20.0f, 18.8f)
        }
    }

    /** Тема оформления: палитра. */
    val Palette: ImageVector by lazy {
        stroked("zizi_palette") {
            moveTo(12f, 20.4f)
            curveTo(7.4f, 20.4f, 3.6f, 16.6f, 3.6f, 12.0f)
            curveTo(3.6f, 7.4f, 7.4f, 3.6f, 12f, 3.6f)
            curveTo(16.6f, 3.6f, 20.4f, 6.9f, 20.4f, 10.9f)
            curveTo(20.4f, 13.4f, 18.4f, 14.9f, 16.0f, 14.9f)
            lineTo(14.7f, 14.9f)
            curveTo(13.3f, 14.9f, 12.5f, 16.1f, 12.9f, 17.3f)
            curveTo(13.3f, 18.7f, 12.9f, 20.4f, 12f, 20.4f)
            moveTo(8.4f, 9.4f); lineTo(8.45f, 9.4f)
            moveTo(12f, 7.6f); lineTo(12.05f, 7.6f)
            moveTo(15.6f, 9.8f); lineTo(15.65f, 9.8f)
        }
    }

    /* ============================================================ избранное */

    val Heart: ImageVector by lazy { stroked("zizi_heart") { heart() } }

    /** Заполненное сердце: то же самое, залитое. Форма не меняется при нажатии — меняется вес. */
    val HeartFilled: ImageVector by lazy { solid("zizi_heart_filled") { heart() } }

    private fun PathBuilder.heart() {
        moveTo(12f, 19.8f)
        curveTo(12f, 19.8f, 3.2f, 14.6f, 3.2f, 9.2f)
        curveTo(3.2f, 6.2f, 5.6f, 4.2f, 8.2f, 4.2f)
        curveTo(10.0f, 4.2f, 11.3f, 5.2f, 12f, 6.4f)
        curveTo(12.7f, 5.2f, 14.0f, 4.2f, 15.8f, 4.2f)
        curveTo(18.4f, 4.2f, 20.8f, 6.2f, 20.8f, 9.2f)
        curveTo(20.8f, 14.6f, 12f, 19.8f, 12f, 19.8f)
    }

    /* ============================================================ команды */

    /** «Остановить»: сплошной квадрат. Команда обязана быть тяжелее описания. */
    val Stop: ImageVector by lazy {
        solid("zizi_stop") {
            moveTo(7.4f, 7.4f); lineTo(16.6f, 7.4f); lineTo(16.6f, 16.6f); lineTo(7.4f, 16.6f)
            lineTo(7.4f, 7.4f)
        }
    }

    /** «Играть»: сплошной треугольник с чуть скруглёнными углами (StrokeJoin.Round). */
    val Play: ImageVector by lazy {
        solid("zizi_play") {
            moveTo(8.0f, 5.6f); lineTo(19.2f, 12f); lineTo(8.0f, 18.4f); lineTo(8.0f, 5.6f)
        }
    }

    /* ============================================================ транспорт крупный (6.25.0) */

    /**
     * Play плеера. Отдельно от [Play] (тот стоит в списках при 16–20 dp): здесь вершина уведена
     * до 19.6, а центр массы посчитан под круглую кнопку — см. заметку в шапке файла.
     */
    val PlayFilled: ImageVector by lazy {
        solid("zizi_play_filled") {
            moveTo(7.6f, 4.9f); lineTo(19.6f, 12.0f); lineTo(7.6f, 19.1f); lineTo(7.6f, 4.9f)
        }
    }

    /**
     * Пауза: две вертикали ширины 3.6 с круглыми торцами. Просвет 2.2 — уже, чем у Material
     * (там 4.0 при той же ширине штриха), потому что в 56 dp широкий просвет распадается на два
     * отдельных знака, а пауза должна читаться как один.
     */
    val Pause: ImageVector by lazy {
        heavy("zizi_pause", 3.6f) {
            moveTo(9.3f, 6.4f); lineTo(9.3f, 17.6f)
            moveTo(14.7f, 6.4f); lineTo(14.7f, 17.6f)
        }
    }

    /**
     * «Вперёд»: треугольник и планка. 6.33.0 — рисунок пересобран по эталонному кадру.
     *
     * До этого знак был ШИРЕ, чем высок (13.0 x 12.4 из 24), и рядом с крупным Play читался как
     * плоская стрелка. Замер референса на кадре 1080 даёт ровно обратную пропорцию: 34 px в
     * ширину при 38 px в высоту, то есть 0.895. Знак не «увеличен» — он перерисован: треугольник
     * занимает 27/34 ширины, планка 7/34, между ними ноль — вершина упирается в планку, как в
     * оригинале.
     *
     * Габарит в сетке: 17.18 x 19.2 (x 3.41..20.59, y 2.4..21.6). Кегль на месте вызова считается
     * от высоты: 19.2/24 глифа = 38 px экрана при кнопке 0.0825 ширины.
     */
    val SkipNext: ImageVector by lazy {
        solid("zizi_skip_next") {
            moveTo(3.41f, 2.4f); lineTo(17.05f, 12.0f); lineTo(3.41f, 21.6f); lineTo(3.41f, 2.4f)
            moveTo(17.05f, 2.4f); lineTo(20.59f, 2.4f); lineTo(20.59f, 21.6f); lineTo(17.05f, 21.6f)
            lineTo(17.05f, 2.4f)
        }
    }

    /** «Назад»: зеркальный [SkipNext]. Зеркалим руками, а не RTL-флагом: знак не про текст. */
    val SkipPrevious: ImageVector by lazy {
        solid("zizi_skip_previous") {
            moveTo(20.59f, 2.4f); lineTo(6.95f, 12.0f); lineTo(20.59f, 21.6f); lineTo(20.59f, 2.4f)
            moveTo(6.95f, 2.4f); lineTo(3.41f, 2.4f); lineTo(3.41f, 21.6f); lineTo(6.95f, 21.6f)
            lineTo(6.95f, 2.4f)
        }
    }

    /* ============================================================ вывод звука (6.33.0) */

    /**
     * НАСТОЯЩИЕ наушники, снятые с эталонного кадра по пикселям (6.34.0).
     *
     * До этого дужка была полукругом с двумя прямыми стойками, а чашки — залитыми прямоугольниками.
     * Референс устроен иначе, и разница видна не «на вкус», а на маске: дужка там не полукруг, а
     * дуга примерно в 202°, то есть она заходит НИЖЕ горизонтали и уже там встречает чашку; сами
     * чашки — не заливка, а полая капсула той же обводки, наклонённая внутрь примерно на 22°.
     * Из-за заливки наш знак был тяжелее соседних по ряду и читался как клякса на 20 dp.
     *
     * Числа. Кадр 1080x2400, иконка 56x53 px, обводка 5 px. В координатах 24x24 это радиус дуги
     * 10.93 от центра (12, 12), концы на 11° ниже горизонтали, капсула радиусом 2.57 с осью
     * (4.37, 15.86) -> (5.72, 19.07) слева и зеркально справа. Обводка 2.14 — это те самые 5 px,
     * а не общий STROKE набора (2.05): знак сверялся с эталоном попиксельно, и 0.09 здесь
     * означали бы, что дужка на кадре чуть тоньше оригинала.
     *
     * Верхняя «крышка» капсулы намеренно нарисована: в эталоне место стыка чашки и дужки — сплошное
     * пятно, а не аккуратный стык двух линий, и именно оно даёт узнаваемое утолщение у уха.
     */
    val Headphones: ImageVector by lazy {
        heavy("zizi_headphones", 2.14f) {
            // Дужка: одна дуга через верх, 202°.
            moveTo(1.27f, 14.09f)
            arcTo(10.93f, 10.93f, 0f, true, true, 22.73f, 14.09f)
            // Левая чашка: внешняя стенка вниз, донце, внутренняя стенка вверх, крышка.
            moveTo(2.00f, 16.86f); lineTo(3.35f, 20.07f)
            arcTo(2.57f, 2.57f, 0f, false, false, 8.09f, 18.07f)
            lineTo(6.74f, 14.86f)
            arcTo(2.57f, 2.57f, 0f, false, false, 2.00f, 16.86f)
            // Правая — зеркало левой: x -> 24 - x, направление дуг обратное.
            moveTo(22.00f, 16.86f); lineTo(20.65f, 20.07f)
            arcTo(2.57f, 2.57f, 0f, false, true, 15.91f, 18.07f)
            lineTo(17.26f, 14.86f)
            arcTo(2.57f, 2.57f, 0f, false, true, 22.00f, 16.86f)
        }
    }

    /** Руна Bluetooth одним росчерком: для колонки или машины, где «наушники» были бы враньём. */
    val BluetoothAudio: ImageVector by lazy {
        stroked("zizi_bluetooth_audio") {
            moveTo(6.9f, 8.2f); lineTo(17.1f, 15.8f); lineTo(12.0f, 20.4f); lineTo(12.0f, 3.6f)
            lineTo(17.1f, 8.2f); lineTo(6.9f, 15.8f)
        }
    }

    /** Динамик телефона: конус и две волны. Знак «звук идёт вслух», а не в наушники. */
    val PhoneSpeaker: ImageVector by lazy {
        ImageVector.Builder(
            name = "zizi_phone_speaker",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.Black), strokeLineJoin = StrokeJoin.Round) {
                moveTo(11.6f, 4.6f); lineTo(6.6f, 9.0f); lineTo(3.2f, 9.0f)
                curveTo(2.6f, 9.0f, 2.2f, 9.4f, 2.2f, 10.0f)
                lineTo(2.2f, 14.0f)
                curveTo(2.2f, 14.6f, 2.6f, 15.0f, 3.2f, 15.0f)
                lineTo(6.6f, 15.0f); lineTo(11.6f, 19.4f)
                curveTo(12.1f, 19.8f, 12.6f, 19.6f, 12.6f, 19.0f)
                lineTo(12.6f, 5.0f)
                curveTo(12.6f, 4.4f, 12.1f, 4.2f, 11.6f, 4.6f)
                close()
            }
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(16.1f, 9.4f)
                curveTo(17.4f, 10.9f, 17.4f, 13.1f, 16.1f, 14.6f)
                moveTo(19.0f, 6.9f)
                curveTo(21.5f, 9.7f, 21.5f, 14.3f, 19.0f, 17.1f)
            }
        }.build()
    }

    /** «Назад» в заголовке раздела: стрелка влево. */
    val ArrowBack: ImageVector by lazy {
        stroked("zizi_arrow_back") {
            moveTo(19.8f, 12.0f); lineTo(4.9f, 12.0f)
            moveTo(11.4f, 5.0f); lineTo(4.4f, 12.0f); lineTo(11.4f, 19.0f)
        }
    }

    /** Спектр: пять полос. Высоты неравные и несимметричные — симметричный спектр выглядит мёртвым. */
    val Spectrum: ImageVector by lazy {
        stroked("zizi_spectrum") {
            moveTo(4.3f, 14.6f); lineTo(4.3f, 9.4f)
            moveTo(8.1f, 18.4f); lineTo(8.1f, 5.6f)
            moveTo(12.0f, 15.8f); lineTo(12.0f, 8.2f)
            moveTo(15.9f, 19.4f); lineTo(15.9f, 4.6f)
            moveTo(19.7f, 13.4f); lineTo(19.7f, 10.6f)
        }
    }

    /** «Недавнее»: часы. Стрелки на 12 и на 4 — положение читается при 17 dp, в отличие от 12:10. */
    val History: ImageVector by lazy {
        stroked("zizi_history") {
            circle(12f, 12f, 8.1f)
            moveTo(12.0f, 7.2f); lineTo(12.0f, 12.3f); lineTo(15.7f, 14.4f)
        }
    }

    /* ============================================================ выбор и правка */

    /** Отмеченный пункт: рамка и галочка внутри. Пустая рамка — [CheckBoxEmpty]. */
    val CheckBox: ImageVector by lazy {
        stroked("zizi_checkbox") {
            box()
            moveTo(7.8f, 12.2f); lineTo(10.6f, 15.0f); lineTo(16.4f, 8.6f)
        }
    }

    val CheckBoxEmpty: ImageVector by lazy { stroked("zizi_checkbox_empty") { box() } }

    /** «Выбрать все»: рамка с пунктирной левой стороной и галочкой — множественный выбор. */
    val SelectAll: ImageVector by lazy {
        stroked("zizi_select_all") {
            moveTo(4.4f, 8.0f); lineTo(4.4f, 16.0f)
            moveTo(8.0f, 19.6f); lineTo(16.0f, 19.6f)
            moveTo(8.0f, 4.4f); lineTo(16.0f, 4.4f)
            moveTo(19.6f, 8.0f); lineTo(19.6f, 16.0f)
            moveTo(8.4f, 12.2f); lineTo(11.2f, 15.0f); lineTo(16.0f, 9.2f)
        }
    }

    private fun PathBuilder.box() {
        moveTo(4.4f, 4.4f); lineTo(19.6f, 4.4f); lineTo(19.6f, 19.6f); lineTo(4.4f, 19.6f)
        lineTo(4.4f, 4.4f)
    }

    /** «Переименовать»: карандаш под 45°, с отделённым кончиком. */
    val Edit: ImageVector by lazy {
        stroked("zizi_edit") {
            moveTo(16.4f, 3.9f); lineTo(20.1f, 7.6f); lineTo(8.6f, 19.1f); lineTo(3.9f, 20.1f)
            lineTo(4.9f, 15.4f); lineTo(16.4f, 3.9f)
            moveTo(13.9f, 6.4f); lineTo(17.6f, 10.1f)
        }
    }

    /** Ссылка: два звена цепи. */
    val Link: ImageVector by lazy {
        stroked("zizi_link") {
            moveTo(10.4f, 13.6f); lineTo(13.6f, 10.4f)
            moveTo(11.0f, 7.6f); lineTo(13.4f, 5.2f)
            curveTo(15.2f, 3.4f, 18.0f, 3.4f, 19.8f, 5.2f)
            curveTo(21.6f, 7.0f, 21.6f, 9.8f, 19.8f, 11.6f)
            lineTo(17.4f, 14.0f)
            moveTo(13.0f, 16.4f); lineTo(10.6f, 18.8f)
            curveTo(8.8f, 20.6f, 6.0f, 20.6f, 4.2f, 18.8f)
            curveTo(2.4f, 17.0f, 2.4f, 14.2f, 4.2f, 12.4f)
            lineTo(6.6f, 10.0f)
        }
    }

    /** «Настройки списка»: два ползунка. */
    val Tune: ImageVector by lazy {
        stroked("zizi_tune") {
            moveTo(3.6f, 8.6f); lineTo(20.4f, 8.6f)
            moveTo(3.6f, 15.4f); lineTo(20.4f, 15.4f)
            circle(9.0f, 8.6f, 2.4f)
            circle(15.4f, 15.4f, 2.4f)
        }
    }

    /** Медиатека: нота и полки. Знак вкладки «Библиотека». */
    /* ============================================================ медиатека (6.29.0) */

    /**
     * «Сеткой»: четыре плитки 2x2. Просвет между плитками 2.4 единицы — при 20 dp это 2 px, то
     * есть знак не сливается в один квадрат даже на mdpi, и при этом не рассыпается на четыре
     * точки. Углы скруглены самой обводкой (StrokeJoin.Round), отдельных дуг не нужно.
     */
    val ViewGrid: ImageVector by lazy {
        stroked("zizi_view_grid") {
            moveTo(4.4f, 4.4f); lineTo(10.8f, 4.4f); lineTo(10.8f, 10.8f); lineTo(4.4f, 10.8f); close()
            moveTo(13.2f, 4.4f); lineTo(19.6f, 4.4f); lineTo(19.6f, 10.8f); lineTo(13.2f, 10.8f); close()
            moveTo(4.4f, 13.2f); lineTo(10.8f, 13.2f); lineTo(10.8f, 19.6f); lineTo(4.4f, 19.6f); close()
            moveTo(13.2f, 13.2f); lineTo(19.6f, 13.2f); lineTo(19.6f, 19.6f); lineTo(13.2f, 19.6f); close()
        }
    }

    /**
     * «Списком»: три строки, у каждой квадрат обложки и подпись. Именно так это нарисовано в
     * референсе, и это важнее абстрактных трёх линий: знак показывает, ЧТО получится, а не
     * «список вообще».
     */
    val ViewList: ImageVector by lazy {
        stroked("zizi_view_list") {
            moveTo(3.8f, 5.0f); lineTo(7.4f, 5.0f); lineTo(7.4f, 8.6f); lineTo(3.8f, 8.6f); close()
            moveTo(10.4f, 6.8f); lineTo(20.2f, 6.8f)
            moveTo(3.8f, 10.2f); lineTo(7.4f, 10.2f); lineTo(7.4f, 13.8f); lineTo(3.8f, 13.8f); close()
            moveTo(10.4f, 12.0f); lineTo(20.2f, 12.0f)
            moveTo(3.8f, 15.4f); lineTo(7.4f, 15.4f); lineTo(7.4f, 19.0f); lineTo(3.8f, 19.0f); close()
            moveTo(10.4f, 17.2f); lineTo(20.2f, 17.2f)
        }
    }

    /**
     * «Порядок»: стрелка вниз и стрелка вверх рядом — тот самый знак, что стоит слева от подписи
     * сортировки в референсе. От [Sort] отличается смыслом: [Sort] это «отсортировать»,
     * ZiziIcons.SortSwap — «сейчас порядок такой, нажми, чтобы сменить».
     */
    val SortSwap: ImageVector by lazy {
        stroked("zizi_sort_swap") {
            moveTo(7.6f, 4.6f); lineTo(7.6f, 19.4f)
            moveTo(4.2f, 16.0f); lineTo(7.6f, 19.6f); lineTo(11.0f, 16.0f)
            moveTo(16.4f, 19.4f); lineTo(16.4f, 4.6f)
            moveTo(13.0f, 8.0f); lineTo(16.4f, 4.4f); lineTo(19.8f, 8.0f)
        }
    }

    /** Diagonal pin: a single readable silhouette, matched to the 2.05 / 24 icon family. */
    val Pin: ImageVector by lazy {
        stroked("zizi_pin") {
            moveTo(14.5f, 3.5f)
            lineTo(20.5f, 9.5f)
            lineTo(18.4f, 11.6f)
            lineTo(16.9f, 11.2f)
            lineTo(12.8f, 15.3f)
            lineTo(13.3f, 17.7f)
            lineTo(11.7f, 19.3f)
            lineTo(4.7f, 12.3f)
            lineTo(6.3f, 10.7f)
            lineTo(8.7f, 11.2f)
            lineTo(12.8f, 7.1f)
            lineTo(12.4f, 5.6f)
            close()
            moveTo(8.2f, 15.8f); lineTo(3.2f, 20.8f)
        }
    }

    /**
     * МЕДИАТЕКА 6.41.0 — знак эталона, а не «пластинка с нотой».
     *
     * До этой версии здесь стояли две вертикальные линии (корешки) плюс нота: свой рисунок,
     * который с эталоном не совпадал ничем, кроме смысла. У эталона это «подписки»: две
     * горизонтальные полки сверху и рамка с треугольником под ними — и ровно так человек и
     * читает раздел, в котором лежат подборки, а не диски.
     *
     * Замер (нижняя панель эталона, 1080 px): габарит 43 x 48 px, полка 26 x 3 и 37 x 3,
     * рамка 43 x 31 с радиусом 5, треугольник 12 x 12 внутри рамки. Пересчёт в сетку 24 при
     * высоте глифа 22.4 (масштаб 0.4667) и даёт числа ниже; ширина выходит 20.1, поэтому знак
     * центрирован по горизонтали вручную (1.95 .. 22.05), а не «от нуля».
     *
     * Вес линии 1.75 против общего 2.05 — тоже замер: 3.5 px обводки на габарит 48 это 0.073,
     * а не 0.085. Знак с четырьмя параллельными линиями на 19 dp при общем весе набора слипался.
     */
    val Library: ImageVector by lazy {
        mixed(
            name = "zizi_library",
            width = 1.75f,
            strokePath = {
                // Полки. Верхняя короче нижней — так же, как у эталона: это перспектива стопки.
                moveTo(7.5f, 1.6f); lineTo(17.4f, 1.6f)
                moveTo(5.2f, 5.3f); lineTo(20.3f, 5.3f)
                roundedRect(2.65f, 9.8f, 20.85f, 22.35f, 2.3f)
            },
            fillPath = {
                moveTo(9.4f, 13.3f)
                lineTo(15.0f, 15.85f)
                lineTo(9.4f, 18.4f)
                close()
            }
        )
    }

    /**
     * Окружность двумя полудугами.
     *
     * Одной `arcTo` полный круг нарисовать нельзя: начальная и конечная точки совпадают, и
     * дуга вырождается в ничто. Две дуги по 180° — единственный способ, который не зависит от
     * реализации парсера пути.
     */
    /**
     * Прямоугольник со скруглёнными углами по средней линии обводки: (l, t) - (r, b), радиус [rad].
     * Углы — четвертями дуг, а не кривыми Безье: у дуги радиус равен заданному на любом масштабе.
     */
    private fun PathBuilder.roundedRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        moveTo(l + rad, t)
        lineTo(r - rad, t)
        arcTo(rad, rad, 0f, false, true, r, t + rad)
        lineTo(r, b - rad)
        arcTo(rad, rad, 0f, false, true, r - rad, b)
        lineTo(l + rad, b)
        arcTo(rad, rad, 0f, false, true, l, b - rad)
        lineTo(l, t + rad)
        arcTo(rad, rad, 0f, false, true, l + rad, t)
        close()
    }

    private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        moveTo(cx - r, cy)
        arcTo(r, r, 0f, false, true, cx + r, cy)
        arcTo(r, r, 0f, false, true, cx - r, cy)
    }
}
