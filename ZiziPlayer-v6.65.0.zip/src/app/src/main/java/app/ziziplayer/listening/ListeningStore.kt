package app.ziziplayer.listening

import app.ziziplayer.data.ListeningDao
import app.ziziplayer.data.ListeningSessionEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

interface ListeningSink {
    val generation: Long
    fun submit(row: ListeningSessionEntity, ownerGeneration: Long)
}

/** One process-owned writer. No Room work on the audio callback or main thread. */
class ListeningStore(private val dao: ListeningDao) : ListeningSink {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val signal = Channel<Unit>(Channel.CONFLATED)
    private val lock = Any()
    private val writes = Mutex()
    private val pending = LinkedHashMap<String, ListeningSessionEntity>()
    @Volatile override var generation: Long = 0L
        private set
    private val _problem = MutableStateFlow<String?>(null)
    val problem = _problem.asStateFlow()

    init {
        scope.launch {
            // Only once per process, before this process's first checkpoint.
            var recovered = false
            while (!recovered) {
                try {
                    writes.withLock { dao.recoverInterrupted(); dao.trim(System.currentTimeMillis() - RETENTION_MS) }
                    recovered = true
                } catch (e: CancellationException) { throw e }
                catch (_: Exception) { _problem.value = "История временно недоступна"; delay(5000) }
            }
            for (ignored in signal) {
                while (true) {
                    val work = synchronized(lock) { pending.values.firstOrNull()?.let { generation to it } } ?: break
                    try {
                        writes.withLock {
                            if (work.first == generation) {
                                dao.checkpoint(work.second)
                                if (work.second.outcome != "active") dao.trim(System.currentTimeMillis() - RETENTION_MS)
                                synchronized(lock) {
                                    if (pending[work.second.sessionId] == work.second) pending.remove(work.second.sessionId)
                                }
                            }
                        }
                        _problem.value = null
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) {
                        _problem.value = "Не удалось сохранить историю. Повторяем запись…"
                        delay(5000)
                    }
                }
            }
        }
    }

    override fun submit(row: ListeningSessionEntity, ownerGeneration: Long) {
        synchronized(lock) {
            if (ownerGeneration != generation) return
            if (pending.size >= 256 && row.sessionId !in pending) {
                // Disk failure must not exhaust memory or stop audio. Visible, not silent loss.
                _problem.value = "Хранилище истории недоступно: часть новых сессий не сохранена"
                return
            }
            pending[row.sessionId] = row
        }
        signal.trySend(Unit)
    }

    suspend fun clearHistory() = writes.withLock {
        // Serialize with checkpoints; old callbacks cannot resurrect deleted sessions.
        synchronized(lock) { generation += 1; pending.clear() }
        dao.clearHistory()
    }

    companion object { const val RETENTION_MS = 180L * 24 * 60 * 60 * 1000 }
}
