package app.ziziplayer.data

import app.ziziplayer.ui.ProfilePlaylistPolicy

/** Include creation time so a restored/reused numeric ID cannot hide another playlist. */
val PlaylistEntity.profileKey: String get() = ProfilePlaylistPolicy.key(id, createdAt)
