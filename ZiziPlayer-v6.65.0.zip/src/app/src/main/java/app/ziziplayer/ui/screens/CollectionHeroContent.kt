package app.ziziplayer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.CollectionHeaderGeometry as H

@Immutable
internal data class CollectionHeaderMetrics(val unit: Float) {
    val playDisk get() = (H.PLAY_SIZE * unit).dp
    val touchSize get() = H.touchSize(unit).dp
    val touchEnd get() = H.touchEnd(unit).dp
    val actionGap get() = H.actionGap(unit).dp
    val bottomGap get() = (H.ACTION_BOTTOM_GAP * unit).dp
}
internal val LocalCollectionActionsAlpha = staticCompositionLocalOf { 1f }
internal val LocalCollectionHeaderMetrics = staticCompositionLocalOf { CollectionHeaderMetrics(1f / 3f) }

/** A shared measured information area; missing artist data does not create fake controls.
 * Minimum space matches the reference. Text/large fonts may grow it, never overlap actions.
 */
@Composable
internal fun CollectionHeroContent(
    title: String,
    metadata: String,
    subtitle: String? = null,
    actions: @Composable () -> Unit
) {
    val m = LocalCollectionHeaderMetrics.current
    val u = m.unit
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().heightIn(min = (H.DETAILS_MIN_HEIGHT * u).dp)
            .padding(start = (H.CONTENT_START * u).dp, end = (H.PLAY_END * u).dp),
            verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(title, color = Color.White, fontSize = (H.TITLE_SIZE * u).sp,
                    lineHeight = (H.TITLE_LINE * u).sp, fontWeight = FontWeight.ExtraBold,
                    maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("collection:hero-title"))
                if (!subtitle.isNullOrBlank()) Text(subtitle, color = Color(0xFFE0E0E0),
                    fontSize = (H.META_SIZE * u).sp, lineHeight = (H.META_LINE * u).sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = (H.SUBTITLE_TOP_GAP * u).dp))
            }
            Text(metadata, color = Color(0xFFE0E0E0), fontSize = (H.META_SIZE * u).sp,
                lineHeight = (H.META_LINE * u).sp,
                modifier = Modifier.padding(bottom = (H.META_BOTTOM_GAP * u).dp)
                    .testTag("collection:metadata"))
        }
        actions()
        Spacer(Modifier.height(m.bottomGap))
    }
}
