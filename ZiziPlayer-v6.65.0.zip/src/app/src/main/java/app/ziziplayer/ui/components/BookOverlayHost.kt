package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import app.ziziplayer.ui.BookPageGeometry

/** Full-width push with AccountDrawerHost timing: forward enters RIGHT, base exits LEFT.
 * Both edges use the same rounded pixel on the same clock, including a rapid reversal.
 * Keep the base composed (scroll/drafts survive), but never expose its input behind a page.
 */
@Composable
fun BookOverlayHost(
    open: Boolean,
    modifier: Modifier = Modifier,
    // Set only after a successful action on the fully open page. Replace the hidden base
    // with the success destination before closing; cancelling/back leaves this false.
    closeForward: Boolean = false,
    page: @Composable (interactive: Boolean) -> Unit,
    content: @Composable () -> Unit
) {
    val progress = remember { Animatable(0f) }
    var width by remember { mutableIntStateOf(0) }
    val mounted = open || progress.value > 0f
    val ready = open && progress.value == 1f && !progress.isRunning
    val completing = !open && closeForward
    LaunchedEffect(open) {
        progress.animateTo(if (open) 1f else 0f, tween(280, easing = FastOutSlowInEasing))
    }
    Box(modifier.fillMaxSize().clipToBounds().background(Color.Black)
        .onSizeChanged { width = it.width }) {
        Box(Modifier.fillMaxSize().testTag("book-base").graphicsLayer {
            translationX = BookPageGeometry.baseOffset(width, progress.value, completing).toFloat()
        }) {
            Box(Modifier.fillMaxSize().then(if (mounted) Modifier.clearAndSetSemantics { } else Modifier)) {
                content()
            }
            if (mounted) Box(Modifier.fillMaxSize().blockSurfaceInput())
        }
        if (mounted) {
            Box(Modifier.fillMaxSize().testTag("book-page").graphicsLayer {
                translationX = BookPageGeometry.pageOffset(width, progress.value, completing).toFloat()
            }.surfaceInputBoundary()) {
                Box(Modifier.fillMaxSize().then(if (!ready) Modifier.clearAndSetSemantics { } else Modifier)) {
                    page(ready)
                }
                if (!ready) Box(Modifier.fillMaxSize().blockSurfaceInput())
            }
        }
    }
}
