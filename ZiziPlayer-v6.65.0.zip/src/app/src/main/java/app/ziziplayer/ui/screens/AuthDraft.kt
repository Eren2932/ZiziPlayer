package app.ziziplayer.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Separate in-memory drafts: switching login/register/recovery cannot overwrite a password. */
internal class AuthDraft {
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmation by mutableStateOf("")
    var code by mutableStateOf("")
    val dirty: Boolean get() = email.isNotEmpty() || password.isNotEmpty() || confirmation.isNotEmpty() || code.isNotEmpty()
    fun clearSecrets() { password = ""; confirmation = ""; code = "" }
    fun editEmail(value: String) {
        // Credentials typed for a different identity must not silently be submitted for this one.
        if (email.trim() != value.trim()) clearSecrets()
        email = value.take(254)
    }
}

