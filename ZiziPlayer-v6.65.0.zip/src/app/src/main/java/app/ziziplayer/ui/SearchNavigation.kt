package app.ziziplayer.ui

/** Explicit origin prevents an old query from turning "back from history" into stale results. */
internal object SearchNavigation {
    fun editOrigin(stage: SearchStage, previous: SearchStage): SearchStage = when (stage) {
        SearchStage.HUB, SearchStage.RESULTS -> stage
        SearchStage.RECENT, SearchStage.SUGGEST -> previous
    }

    fun backFromEditor(origin: SearchStage, query: String): SearchStage =
        if (origin == SearchStage.RESULTS && query.isNotBlank()) SearchStage.RESULTS else SearchStage.HUB
}
