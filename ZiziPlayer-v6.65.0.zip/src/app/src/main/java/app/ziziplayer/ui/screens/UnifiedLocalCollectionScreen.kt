package app.ziziplayer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.CollectionCoverImage
import app.ziziplayer.ui.components.rememberCollectionCover
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

@Composable
internal fun UnifiedLocalCollectionScreen(
    vm: MainViewModel, state: LibraryUiState, playback: PlaybackState,
    selected: Set<String>, downloads: Map<String, DownloadStatus>,
    onMenu: (TrackEntity) -> Unit, onSort: () -> Unit, onAdd: () -> Unit,
    selectionHeader: @Composable (Dp) -> Unit
) {
    val p = LocalPalette.current
    val playlist = state.openPlaylist
    val destination = playlist?.id?.let { "playlist:$it" }
        ?: state.openFolder?.let { "folder:$it" } ?: state.filter.name
    val title = playlist?.name ?: state.openFolder?.let { folder ->
        state.folders.firstOrNull { it.name == folder }?.label ?: folder
    } ?: if (state.filter == LibraryFilter.FAVORITES) "Избранное" else "Все треки"
    // Same cover as the playlist card; search/sort and the active player cannot retint it.
    val track = if (playlist != null) state.playlistMeta[playlist.id]?.cover
        else state.collectionTracks.maxByOrNull { it.dateAdded }
    val cover = rememberCollectionCover(track = track, url = playlist?.coverUri)
    var showDownloads by rememberSaveable(destination) { mutableStateOf(false) }
    var playlistMenu by rememberSaveable(destination) { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val picking = selected.isNotEmpty()
    val ownsQueue = playback.queueSourceId == destination
    val selection: (@Composable () -> Unit)? = if (picking) { { selectionHeader(56.dp) } } else null
    PinnedCollectionScaffold(
        destination = destination, title = title, tint = cover.tint, trackCount = state.visible.size,
        playingHere = ownsQueue && playback.isPlaying,
        playEnabled = state.visible.isNotEmpty() || ownsQueue,
        onBack = { focus.clearFocus(); vm.handleBack() },
        onPlay = {
            if (ownsQueue) vm.playPause()
            else state.visible.firstOrNull()?.let { vm.play(it, state.visible, destination) }
        },
        artwork = { CollectionCoverImage(cover, Modifier.fillMaxSize()) },
        selectionToolbar = selection,
        hero = {
            CollectionHeroContent(title = title, metadata = trackCountLabel(state.collectionTracks.size)) {
                CollectionActionsRow(
                    onShuffle = {
                        val shuffled = state.visible.shuffled()
                        shuffled.firstOrNull()?.let { vm.play(it, shuffled, destination) }
                    },
                    shuffleEnabled = state.visible.isNotEmpty(),
                    onMenu = if (playlist != null) { { playlistMenu = true } } else null
                ) {
                    IconButton(onClick = { showDownloads = true }, enabled = LocalCollectionActionsAlpha.current > 0f && state.collectionTracks.isNotEmpty()) {
                        Icon(ZiziIcons.DownloadCircle, "Скачать всю подборку", tint = p.subtext)
                    }
                    IconButton(onClick = onSort, enabled = LocalCollectionActionsAlpha.current > 0f) { Icon(ZiziIcons.Sort, "Сортировать", tint = p.text) }
                    TextButton(onClick = onAdd, enabled = LocalCollectionActionsAlpha.current > 0f) { Text("Импорт", color = p.text) }
                }
            }
        }
    ) {
        if (state.loading) item(key = "collection:loading") {
            Text("Загружаем…", color = p.subtext, modifier = Modifier.padding(20.dp))
        } else if (state.visible.isEmpty()) item(key = "collection:empty") {
            Text(if (state.query.isNotBlank()) "Ничего не найдено" else "Здесь пока нет треков",
                color = p.subtext, modifier = Modifier.padding(20.dp))
        }
        items(state.visible, key = { it.id }, contentType = { "track" }) { track ->
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                CollectionTrackRow(track, maxWidth.value / 1080f, track.id == playback.currentTrackId,
                    selected = track.id in selected, picking = picking,
                    onPlay = { vm.play(track, state.visible, destination) }, onSelect = { vm.toggleSelected(track.id) },
                    onLongPress = { vm.startSelection(track.id) }, onMenu = { onMenu(track) })
            }
        }
    }
    if (showDownloads) CollectionDownloadDialog(vm, state.collectionTracks, downloads) { showDownloads = false }
    if (playlistMenu && playlist != null) PlaylistActionsHost(vm, state, playlist.id,
        onOpen = { playlistMenu = false }, onDismiss = { playlistMenu = false })
}
