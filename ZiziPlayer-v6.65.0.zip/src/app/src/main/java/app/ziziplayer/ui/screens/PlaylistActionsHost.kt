package app.ziziplayer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.profileKey
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.CollectionCoverImage
import app.ziziplayer.ui.components.rememberCollectionCover
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** One real action host shared by the library, collection toolbar and profile. */
@Composable
internal fun PlaylistActionsHost(
    vm: MainViewModel, state: LibraryUiState, playlistId: Long,
    onOpen: () -> Unit, onDismiss: () -> Unit
) {
    val playlist = state.playlists.firstOrNull { it.id == playlistId }
    if (playlist == null) { LaunchedEffect(playlistId) { onDismiss() }; return }
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    var stage by rememberSaveable(playlist.profileKey) { mutableStateOf("menu") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tracks by remember(playlist.profileKey) { mutableStateOf<List<TrackEntity>?>(null) }
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val hidden = playlist.profileKey in state.settings.profileHiddenPlaylists
    val cover = rememberCollectionCover(state.playlistMeta[playlist.id]?.cover, playlist.coverUri)
    fun runAction(action: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try { action() }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { error = "Не удалось выполнить действие. Проверьте состояние плейлиста и повторите попытку." }
            finally { busy = false }
        }
    }
    when (stage) {
        "menu" -> ZiziSheetScaffold(onDismiss = { if (!busy) onDismiss() }) {
            val exit = LocalSheetExit.current
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                CollectionCoverImage(cover, Modifier.size(56.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(trackCountLabel(state.playlistMeta[playlist.id]?.count ?: 0), color = p.subtext)
                }
            }
            HorizontalDivider(color = p.subtext.copy(alpha = 0.2f))
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.brand)
            // Async actions keep the sheet mounted until completed so cancellation cannot eat them.
            MenuItem(ZiziIcons.Play, "Слушать с начала") {
                runAction {
                    val rows = vm.playlistActionTracks(playlist)
                    if (rows.isEmpty()) error = "В плейлисте пока нет доступных треков"
                    else { vm.play(rows.first(), rows, "playlist:${playlist.id}"); onDismiss() }
                }
            }
            MenuItem(ZiziIcons.Shuffle, "Перемешать") {
                runAction {
                    val rows = vm.playlistActionTracks(playlist).shuffled()
                    if (rows.isEmpty()) error = "В плейлисте пока нет доступных треков"
                    else { vm.play(rows.first(), rows, "playlist:${playlist.id}"); onDismiss() }
                }
            }
            MenuItem(ZiziIcons.Queue, "Открыть плейлист", subtitle = "Треки, поиск и сортировка") {
                if (!busy) exit(onOpen)
            }
            MenuItem(ZiziIcons.DownloadCircle, "Скачать", subtitle = "Загрузка доступных треков на устройство") {
                runAction { tracks = vm.playlistActionTracks(playlist); stage = "downloads" }
            }
            MenuItem(ZiziIcons.Share, "Поделиться") { if (!busy) stage = "share" }
            MenuItem(ZiziIcons.Edit, "Переименовать") { if (!busy) stage = "rename" }
            MenuItem(ZiziIcons.Plus, "Добавить в другой плейлист", subtitle = "Копировать состав, не перемещать файлы") {
                if (!busy) stage = "copy"
            }
            MenuItem(if (hidden) ZiziIcons.Eye else ZiziIcons.EyeOff,
                if (hidden) "Вернуть в профиль" else "Удалить из профиля",
                subtitle = "Плейлист останется в медиатеке на этом устройстве") {
                runAction { vm.setProfilePlaylistsHidden(listOf(playlist), !hidden); onDismiss() }
            }
            MenuItem(ZiziIcons.Trash, "Удалить плейлист", danger = true,
                subtitle = "Удалить сам плейлист, не аудиофайлы") { if (!busy) stage = "delete" }
        }
        "share" -> PlaylistShareSheet(vm, playlist, onDismiss)
        "rename" -> RenameDialog(initial = playlist.name, onConfirm = { name ->
            runAction { vm.renamePlaylistConfirmed(playlist, name); onDismiss() }
        }, onDismiss = { if (!busy) onDismiss() })
        "delete" -> AlertDialog(onDismissRequest = { if (!busy) onDismiss() }, containerColor = p.surface,
            title = { Text("Удалить плейлист?", color = p.text) },
            text = { Text("«${playlist.name}» и его список треков будут удалены из медиатеки. Самих треков, избранного и аудиофайлов это не касается. Отменить удаление нельзя.", color = p.subtext) },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                runAction { vm.deletePlaylistConfirmed(playlist); onDismiss() }
            }) { Text(if (busy) "Удаляем…" else "Удалить плейлист", color = androidx.compose.ui.graphics.Color(0xFFFF6969)) } },
            dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена", color = p.text) } })
        "copy" -> AlertDialog(onDismissRequest = { if (!busy) onDismiss() }, containerColor = p.surface,
            title = { Text("Добавить в другой плейлист", color = p.text) },
            text = {
                val targets = state.playlists.filter { it.id != playlist.id }
                Column {
                    if (targets.isEmpty()) Text("Сначала создайте другой плейлист в медиатеке.", color = p.subtext)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.brand)
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(targets, key = { it.id }) { target ->
                            TextButton(enabled = !busy, onClick = {
                                runAction { vm.copyPlaylistContents(playlist, target); onDismiss() }
                            }) { Text(target.name, color = p.text) }
                        }
                    }
                }
            }, confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена", color = p.text) } })
        "downloads" -> {
            val rows = tracks
            if (rows != null) CollectionDownloadDialog(vm, rows, downloads, onDismiss)
            else LaunchedEffect(playlist.profileKey) { stage = "menu" }
        }
    }
    error?.let { message -> AlertDialog(onDismissRequest = { error = null }, containerColor = p.surface,
        title = { Text("Действие не выполнено", color = p.text) }, text = { Text(message, color = p.subtext) },
        confirmButton = { TextButton(onClick = { error = null }) { Text("Понятно", color = p.brand) } }) }
}
