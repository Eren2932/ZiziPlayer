package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.profileKey
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.ProfilePlaylistPolicy
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
internal fun ProfilePlaylistsScreen(vm: MainViewModel, state: LibraryUiState, onBack: () -> Unit, onPlaylist: (Long) -> Unit) {
    val p = LocalPalette.current
    var hiddenMode by rememberSaveable { mutableStateOf(false) }
    var selection by rememberSaveable(hiddenMode) { mutableStateOf(arrayListOf<String>()) }
    var menuId by rememberSaveable { mutableStateOf<Long?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val hidden = state.settings.profileHiddenPlaylists
    val rows = remember(state.playlists, hidden, hiddenMode) {
        state.playlists.filter { (it.profileKey in hidden) == hiddenMode }
    }
    val available = remember(rows) { rows.map { it.profileKey }.toSet() }
    val selected = ProfilePlaylistPolicy.eligible(selection.toSet(), available)
    val allSelected = rows.isNotEmpty() && selected.size == rows.size
    val bottom = LocalBottomChromeInset.current
    BackHandler { if (!busy) onBack() }
    Box(Modifier.fillMaxSize().background(p.surface).statusBarsPadding()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottom + 110.dp)) {
            item(key = "back") {
                IconButton(enabled = !busy, onClick = onBack, modifier = Modifier.padding(start = 6.dp)) {
                    Icon(ZiziIcons.ArrowBack, "Назад в профиль", tint = p.text)
                }
            }
            item(key = "heading") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text(if (hiddenMode) "Скрытые плейлисты" else "Плейлисты в профиле", color = p.text,
                        fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(12.dp))
                    Text(if (hiddenMode) "Выбери плейлисты, которые нужно вернуть в профиль."
                        else "Выбери плейлисты, которые нужно убрать из профиля. Они останутся в медиатеке. Новые плейлисты видны по умолчанию.", color = p.text)
                    Text("Настройка действует на этом устройстве и не меняет доступ к облачной копии.",
                        color = p.subtext, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    TextButton(enabled = !busy, onClick = { hiddenMode = !hiddenMode; selection = arrayListOf(); error = null }) {
                        Text(if (hiddenMode) "Показать плейлисты профиля" else "Вернуть скрытые плейлисты", color = p.brand)
                    }
                    FilledTonalButton(enabled = rows.isNotEmpty() && !busy,
                        onClick = { selection = if (allSelected) arrayListOf() else ArrayList(available) },
                        shape = CircleShape,
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = p.chip, contentColor = p.text)) {
                        Icon(if (allSelected) ZiziIcons.Close else ZiziIcons.SelectAll, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (allSelected) "Отменить выбор" else "Выбрать все")
                    }
                    error?.let { Text(it, color = p.subtext, modifier = Modifier.padding(top = 12.dp)) }
                    if (rows.isEmpty()) Text(if (hiddenMode) "Скрытых плейлистов нет." else "В профиле пока нет плейлистов.",
                        color = p.subtext, modifier = Modifier.padding(top = 20.dp))
                }
            }
            items(rows, key = { it.profileKey }, contentType = { "playlist" }) { playlist ->
                val checked = playlist.profileKey in selected
                Row(Modifier.fillMaxWidth().toggleable(value = checked, enabled = !busy, role = Role.Checkbox,
                    onValueChange = { yes -> selection = ArrayList(if (yes) selected + playlist.profileKey else selected - playlist.profileKey) })
                    .padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked, onCheckedChange = null,
                        colors = CheckboxDefaults.colors(checkedColor = p.brand, checkmarkColor = p.onBrand))
                    Spacer(Modifier.width(12.dp))
                    if (!playlist.coverUri.isNullOrBlank()) RemoteArtwork(playlist.coverUri, playlist.name, 160, Modifier.size(48.dp))
                    else TrackArtwork(state.playlistMeta[playlist.id]?.cover, 160, Modifier.size(48.dp), glyphSize = 24)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(playlist.name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(if (hiddenMode) "Скрыт из профиля" else "Виден в профиле", color = p.subtext, fontSize = 13.sp)
                    }
                    IconButton(enabled = !busy, onClick = { menuId = playlist.id }) {
                        Icon(ZiziIcons.More, "Меню плейлиста ${playlist.name}", tint = p.subtext)
                    }
                }
            }
        }
        if (selected.isNotEmpty()) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            .background(p.surface).padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = bottom + 16.dp)) {
            Button(enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = p.brand, contentColor = p.onBrand),
                onClick = {
                    val targets = rows.filter { it.profileKey in selected }
                    busy = true; error = null
                    scope.launch {
                        try {
                            vm.setProfilePlaylistsHidden(targets, hidden = !hiddenMode)
                            selection = arrayListOf()
                        } catch (e: CancellationException) { throw e }
                        catch (_: Exception) { error = "Не удалось сохранить выбор. Повторите попытку." }
                        finally { busy = false }
                    }
                }) {
                Text(if (busy) "Сохраняем…" else (if (hiddenMode) "Вернуть в профиль" else "Удалить из профиля") + " (${selected.size})",
                    fontWeight = FontWeight.Bold)
            }
        }
    }
    menuId?.let { id -> PlaylistActionsHost(vm, state, id,
        onOpen = { menuId = null; onPlaylist(id) }, onDismiss = { menuId = null }) }
}
