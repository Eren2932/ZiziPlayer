package app.ziziplayer.account

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Local decoding only. The server receives a metadata-free 256×256 PNG, never a gallery URI. */
object AvatarImage {
    suspend fun decode(context: Context, uri: Uri, maxEdge: Int = 2048): Bitmap = withContext(Dispatchers.IO) {
        require(maxEdge in 256..2048)
        val job = currentCoroutineContext()
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream(); val buffer = ByteArray(8192)
            while (true) {
                job.ensureActive()
                val n = input.read(buffer); if (n < 0) break
                require(out.size() + n <= 20 * 1024 * 1024) { "Изображение больше 20 МиБ" }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: error("Нет доступа к изображению")
        job.ensureActive()
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(java.nio.ByteBuffer.wrap(bytes))) { decoder, info, _ ->
                require(info.size.width in 1..16000 && info.size.height in 1..16000) { "Изображение слишком большое" }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
                val reduction = (maxOf(info.size.width, info.size.height).toFloat() / maxEdge).coerceAtLeast(1f)
                decoder.setTargetSize((info.size.width / reduction).toInt().coerceAtLeast(1),
                    (info.size.height / reduction).toInt().coerceAtLeast(1))
            }
        } else {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            require(options.outWidth in 1..16000 && options.outHeight in 1..16000) { "Неподдерживаемое изображение" }
            options.inJustDecodeBounds = false
            var sample = 1
            while ((maxOf(options.outWidth, options.outHeight) + sample - 1) / sample > maxEdge) sample *= 2
            options.inSampleSize = sample
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: error("Не удалось открыть изображение")
            val orientation = runCatching { ExifInterface(bytes.inputStream()).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }.getOrDefault(1)
            orient(raw, orientation)
        }
        // Bitmap ownership is GC-based after publication to Compose. Recycling a displayed
        // bitmap in onDispose can race the render thread or an in-flight export.
    }

    internal fun orient(raw: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix().apply { when (orientation) {
            2 -> setScale(-1f, 1f)
            3 -> setRotate(180f)
            4 -> setScale(1f, -1f)
            5 -> { setRotate(90f); postScale(-1f, 1f) }
            6 -> setRotate(90f)
            7 -> { setRotate(270f); postScale(-1f, 1f) }
            8 -> setRotate(270f)
        } }
        return try {
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true).also { if (it !== raw) raw.recycle() }
        } catch (e: Exception) { raw.recycle(); throw e }
    }

    suspend fun encodeCrop(bitmap: Bitmap, pose: AvatarCropGeometry.Pose): String = withContext(Dispatchers.Default) {
        currentCoroutineContext().ensureActive()
        val crop = AvatarCropGeometry.crop(bitmap.width, bitmap.height, pose)
        val output = ByteArrayOutputStream()
        val normalized = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(normalized)
            // Float matrix rather than rounded integer rectangles: preview and export share
            // exactly the same source window, including fractional-pixel crops at high zoom.
            canvas.clipRect(0f, 0f, 256f, 256f)
            val scale = 256f / crop.side
            canvas.scale(scale, scale)
            canvas.translate(-crop.left, -crop.top)
            canvas.drawBitmap(bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            check(normalized.compress(Bitmap.CompressFormat.PNG, 100, output))
            require(output.size() <= 300 * 1024) { "Не удалось уменьшить изображение" }
            currentCoroutineContext().ensureActive()
            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally { normalized.recycle() }
    }
}
