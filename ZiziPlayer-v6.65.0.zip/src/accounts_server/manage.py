"""Local operator actions. Never run with the music server's DB."""
import argparse
import os
import sqlite3
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

p=argparse.ArgumentParser();sub=p.add_subparsers(dest='action',required=True)
k=sub.add_parser('keys');k.add_argument('directory')
r=sub.add_parser('role');r.add_argument('db');r.add_argument('email');r.add_argument('role',choices=['user','admin'])
a=p.parse_args()
if a.action=='keys':
    directory=Path(a.directory);directory.mkdir(mode=0o700,parents=True,exist_ok=True)
    if any((directory/x).exists() for x in ('private.pem','public.pem')):
        raise SystemExit('Refusing to overwrite existing keys')
    key=rsa.generate_private_key(public_exponent=65537,key_size=3072)
    for name,data in [('private.pem',key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())),
                      ('public.pem',key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))]:
        fd=os.open(directory/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as f:f.write(data)
    print('RSA key pair created; private key never belongs in GitHub or APK.')
else:
    # mode=rw prevents a typo from silently creating a new empty DB.
    c=sqlite3.connect(Path(a.db).resolve().as_uri()+'?mode=rw',uri=True)
    with c:
        cur=c.execute('UPDATE users SET role=? WHERE email=? AND verified=1 AND disabled=0',(a.role,a.email.strip().lower()))
        if cur.rowcount!=1:raise SystemExit('No active verified user with this email')
    c.close();print('Role updated. Authorization reads current role on every request.')
