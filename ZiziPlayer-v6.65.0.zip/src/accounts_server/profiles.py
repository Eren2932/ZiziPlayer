"""Private account profile; no public URLs or arbitrary files. Standard-library PNG validation."""
import base64
import binascii
import struct
import unicodedata
import zlib
from core import AuthError

MAX_BODY = 512 * 1024
MAX_IMAGE = 300 * 1024

def validate_avatar(value):
    if value == '': return ''
    try:
        if not isinstance(value, str) or len(value) > 4 * ((MAX_IMAGE + 2) // 3): raise ValueError()
        raw = base64.b64decode(value, validate=True)
        if len(raw) > MAX_IMAGE or raw[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError()
        pos, chunks, pixels, ended, seen_idat = 8, [], b'', False, False
        width = height = color = 0
        while pos < len(raw):
            if pos + 12 > len(raw): raise ValueError()
            size = struct.unpack('>I', raw[pos:pos+4])[0]
            kind = raw[pos+4:pos+8]; data = raw[pos+8:pos+8+size]
            if pos + size + 12 > len(raw): raise ValueError()
            crc = struct.unpack('>I', raw[pos+8+size:pos+12+size])[0]
            if binascii.crc32(kind + data) & 0xffffffff != crc: raise ValueError()
            if not chunks and kind != b'IHDR': raise ValueError()
            if kind == b'IHDR':
                if chunks or size != 13: raise ValueError()
                width,height,depth,color,comp,filt,interlace = struct.unpack('>IIBBBBB',data)
                if not (1 <= width == height <= 256) or depth != 8 or color not in (2,6) or (comp,filt,interlace) != (0,0,0): raise ValueError()
            elif kind == b'IDAT':
                pixels += data; seen_idat = True
            elif kind == b'IEND':
                if size or not seen_idat: raise ValueError()
                ended = True
            elif kind not in (b'sRGB', b'gAMA', b'cHRM', b'sBIT'):
                # No text, EXIF, animation, URLs or unknown chunks.
                raise ValueError()
            chunks.append(kind); pos += size + 12
            if ended: break
        if not ended or pos != len(raw): raise ValueError()
        stride = width * (4 if color == 6 else 3) + 1
        limit = height * stride
        decoder = zlib.decompressobj()
        decoded = decoder.decompress(pixels, limit + 1)
        if len(decoded) != limit or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail: raise ValueError()
        if any(decoded[i] > 4 for i in range(0, limit, stride)): raise ValueError()
        return base64.b64encode(raw).decode('ascii')
    except (ValueError, TypeError, binascii.Error, struct.error, zlib.error):
        raise AuthError('invalid_avatar', 400) from None

def latest(accounts, uid):
    with accounts.connection() as c:
        row = c.execute('SELECT name,avatar,revision FROM account_profiles WHERE uid=?', (uid,)).fetchone()
    return dict(row) if row else {'name':'', 'avatar':'', 'revision':0}

def save(accounts, uid, payload):
    if not isinstance(payload, dict) or set(payload) != {'name','avatar','expected_revision'} or any(not isinstance(v, str) for v in payload.values()): raise AuthError('bad_request',400)
    name = unicodedata.normalize('NFC', payload['name']).strip()
    if not 1 <= len(name) <= 80 or any(unicodedata.category(c).startswith('C') for c in name):
        raise AuthError('invalid_name',400)
    rev = payload['expected_revision']
    if not rev.isascii() or not rev.isdigit() or len(rev)>15: raise AuthError('invalid_revision',400)
    avatar = validate_avatar(payload['avatar'])
    with accounts.transaction() as c:
        row = c.execute('SELECT * FROM account_profiles WHERE uid=?',(uid,)).fetchone()
        revision = row['revision'] if row else 0
        if row and (row['name'],row['avatar']) == (name,avatar):
            return {'name':name,'avatar':avatar,'revision':revision}
        if int(rev) != revision: raise AuthError('profile_conflict',409)
        revision += 1
        c.execute('INSERT INTO account_profiles VALUES(?,?,?,?) ON CONFLICT(uid) DO UPDATE SET name=excluded.name,avatar=excluded.avatar,revision=excluded.revision', (uid,name,avatar,revision))
    return {'name':name,'avatar':avatar,'revision':revision}
