"""Small WSGI API. Run behind HTTPS nginx with gunicorn, one worker/four threads.
No request-body/token logging, no CORS, no redirects, no music-server integration.
"""
from __future__ import annotations
import json
import os
import smtplib
import ssl
import library
import profiles
from email.message import EmailMessage
from http.cookies import SimpleCookie, CookieError
from pathlib import Path
from core import Accounts, Tokens, AuthError, ACCESS_SECONDS, email_address, origin

ACCESS_COOKIE = '__Host-zizi_access'
REFRESH_COOKIE = '__Host-zizi_refresh'


def cookie(name, value, age):
    return ('Set-Cookie', f'{name}={value}; Path=/; Max-Age={max(0,age)}; Secure; HttpOnly; SameSite=Strict')


def cookies(environ):
    raw = environ.get('HTTP_COOKIE','')
    if len(raw)>12000:
        raise AuthError('bad_request',400)
    try:
        # Reject duplicate authentication names, rather than picking a parser-dependent winner.
        for name in (ACCESS_COOKIE,REFRESH_COOKIE):
            if sum(part.strip().split('=',1)[0]==name for part in raw.split(';'))>1:
                raise AuthError('bad_request',400)
        jar=SimpleCookie();jar.load(raw)
        return {key: jar[key].value for key in (ACCESS_COOKIE,REFRESH_COOKIE) if key in jar}
    except CookieError:
        raise AuthError('bad_request',400) from None


class Application:
    def __init__(self, accounts, public_origin, send_mail, google_verifier=None):
        self.accounts=accounts
        self.origin=origin(public_origin)
        self.send_mail=send_mail
        self.google_verifier=google_verifier

    def __call__(self,environ,start_response):
        headers=[('Content-Type','application/json; charset=utf-8'),('Cache-Control','no-store'),
                 ('Pragma','no-cache'),('X-Content-Type-Options','nosniff'),
                 ('Referrer-Policy','no-referrer'),('Content-Security-Policy',"default-src 'none'; frame-ancestors 'none'")]
        status=200
        try:
            if environ.get('wsgi.url_scheme')!='https':
                raise AuthError('https_required',400)
            method,path=environ.get('REQUEST_METHOD'),environ.get('PATH_INFO','')
            if method not in ('POST','GET'):
                raise AuthError('method_not_allowed',405)
            if environ.get('HTTP_ORIGIN') not in (None,self.origin):
                raise AuthError('origin_denied',403)
            if environ.get('HTTP_SEC_FETCH_SITE')=='cross-site':
                raise AuthError('origin_denied',403)
            # Authenticate large writes before reading their body. Generic auth keeps its small cap.
            if method == 'POST' and path in ('/auth/library', '/auth/profile'):
                self.accounts.authenticate(cookies(environ).get(ACCESS_COOKIE,''))
            payload={}
            if method=='POST':
                if environ.get('HTTP_X_ZIZI_ACCOUNT')!='1':
                    raise AuthError('csrf',403)
                if environ.get('CONTENT_TYPE','').split(';')[0].strip()!='application/json':
                    raise AuthError('content_type',415)
                try:
                    size=int(environ.get('CONTENT_LENGTH','0'))
                except ValueError:
                    raise AuthError('bad_request',400) from None
                body_limit = library.MAX_BYTES * 2 + 16384 if path == '/auth/library' else profiles.MAX_BODY if path == '/auth/profile' else 16384
                if not 2<=size<=body_limit:
                    raise AuthError('body_size',413)
                try:
                    payload=json.loads(environ['wsgi.input'].read(size))
                except (ValueError,UnicodeError):
                    raise AuthError('bad_json',400) from None
                if not isinstance(payload,dict) or any(not isinstance(v,str) for v in payload.values()):
                    raise AuthError('bad_request',400)
            # REMOTE_ADDR must be rewritten ONLY by the local trusted nginx configuration.
            ip=environ.get('REMOTE_ADDR','unknown')
            if ip in ('127.0.0.1','::1'):
                # Only nginx on loopback can supply the client address; never trust XFF directly.
                import ipaddress
                try:ip=str(ipaddress.ip_address(environ.get('HTTP_X_REAL_IP',ip)))
                except ValueError:raise AuthError('bad_request',400) from None
            self.accounts.rate('ip:'+ip,120,60)
            if method=='POST' and path in ('/auth/register','/auth/login','/auth/resend','/auth/forgot','/auth/reset','/auth/verify','/auth/google','/auth/google/challenge'):
                self.accounts.rate('sensitive-ip:'+ip,20,600)
                if 'email' in payload:
                    email=email_address(payload['email'])
                    self.accounts.rate(path+':email:'+email,5,600)
            jar=cookies(environ)
            a=self.accounts
            pair=None
            result={'ok':True}
            if (method,path)==('GET','/auth/health'):
                result={'version':'1.2.0','google_enabled':self.google_verifier is not None,'sync_enabled':True,'library_format':'zizi-library-1','profile_enabled':True}
            elif (method,path)==('POST','/auth/register'):
                email=email_address(payload.get('email'))
                code=a.register(email,payload.get('password'))
                if code:self.send_mail(email,'verify',code)
                result={'message':'Если адрес доступен для регистрации, письмо отправлено. Проверьте почту или запросите код повторно.'}
            elif method=='POST' and path in ('/auth/resend','/auth/forgot'):
                email=email_address(payload.get('email'))
                purpose='verify' if path.endswith('resend') else 'reset'
                code=a.request_ticket(email,purpose)
                if code:self.send_mail(email,purpose,code)
                result={'message':'Если адрес подходит для этого действия, письмо отправлено.'}
            elif (method,path)==('POST','/auth/verify'):
                a.redeem(payload.get('code'),'verify')
            elif (method,path)==('POST','/auth/reset'):
                a.redeem(payload.get('code'),'reset',payload.get('password'))
            elif (method,path)==('POST','/auth/login'):
                pair=a.login(payload.get('email'),payload.get('password'))
            elif (method,path)==('POST','/auth/refresh'):
                a.rate('refresh:'+ip,30,60)
                pair=a.refresh(jar.get(REFRESH_COOKIE,''))
            elif method=='POST' and path in ('/auth/logout','/auth/logout-all'):
                try:
                    a.logout(jar.get(REFRESH_COOKIE,''),all_sessions=path.endswith('logout-all'))
                except AuthError as e:
                    if e.status!=401 or path.endswith('logout-all'):raise
                headers += [cookie(ACCESS_COOKIE,'',0),cookie(REFRESH_COOKIE,'',0)]
            elif path == '/auth/profile':
                user=a.authenticate(jar.get(ACCESS_COOKIE,''))['user']
                a.rate('profile:'+user['id'],20,60)
                result = profiles.latest(a,user['id']) if method == 'GET' else profiles.save(a,user['id'],payload)
            elif path == '/auth/library':
                user=a.authenticate(jar.get(ACCESS_COOKIE,''))['user']
                a.rate('library:'+user['id'],30,60)
                if method == 'GET': result=library.latest(a,user['id'])
                else:
                    if set(payload) != {'expected_revision','document'}: raise AuthError('bad_request',400)
                    result=library.save(a,user['id'],payload['expected_revision'],payload['document'])
            elif (method,path)==('GET','/auth/me'):
                result=a.authenticate(jar.get(ACCESS_COOKIE,''))['user']
            elif (method,path)==('GET','/auth/admin/status'):
                a.authenticate(jar.get(ACCESS_COOKIE,''),'service:inspect')
                result={'version':'1.2.0','sync_enabled':True,'library_format':'zizi-library-1','profile_enabled':True}
            elif (method,path)==('POST','/auth/google/challenge'):
                if not self.google_verifier:raise AuthError('google_not_configured',503)
                result=a.challenge()
            elif (method,path)==('POST','/auth/google'):
                if not self.google_verifier:raise AuthError('google_not_configured',503)
                token=payload.get('id_token','')
                if not 1<=len(token)<=10000:raise AuthError()
                verified=self.google_verifier(token)
                pair=a.google_login(payload.get('challenge',''),verified)
            else:
                raise AuthError('not_found',404)
            if pair:
                headers += [cookie(ACCESS_COOKIE,pair['access'],min(ACCESS_SECONDS,pair['expires']-a.now())),
                            cookie(REFRESH_COOKIE,pair['refresh'],pair['expires']-a.now())]
                # Tokens are deliberately NEVER returned as JSON.
                result=pair['user']
        except AuthError as e:
            status=e.status;result={'error':e.code}
            if status==401:
                headers += [cookie(ACCESS_COOKIE,'',0),cookie(REFRESH_COOKIE,'',0)] if environ.get('PATH_INFO')=='/auth/refresh' else []
            if status==429:headers.append(('Retry-After','60'))
        except Exception:
            # No exception detail, query, cookie, password or email leaks to the client/logs.
            status=503;result={'error':'temporarily_unavailable'}
        body=json.dumps(result,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        headers.append(('Content-Length',str(len(body))))
        from http import HTTPStatus
        start_response(f'{status} {HTTPStatus(status).phrase}',headers)
        return [body]


class Mailer:
    def __init__(self):
        self.host=os.environ['ZIZI_SMTP_HOST']
        self.port=int(os.getenv('ZIZI_SMTP_PORT','587'))
        self.user=os.environ['ZIZI_SMTP_USER']
        self.password=os.environ['ZIZI_SMTP_PASSWORD']
        self.sender=os.environ['ZIZI_MAIL_FROM']
        self.context=ssl.create_default_context()

    def __call__(self,email,purpose,code):
        mail=EmailMessage()
        mail['From']=self.sender;mail['To']=email
        mail['Subject']='ZiziPlayer: '+('подтверждение почты' if purpose=='verify' else 'сброс пароля')
        mail.set_content('Код для '+('подтверждения почты' if purpose=='verify' else 'сброса пароля')+
                         ' в ZiziPlayer (действует 30 минут):\n\n'+code+
                         '\n\nСкопируйте код в приложение. Никому его не сообщайте. '
                         'Если вы не запрашивали действие, проигнорируйте письмо.')
        try:
            with smtplib.SMTP(self.host,self.port,timeout=10) as smtp:
                smtp.ehlo();smtp.starttls(context=self.context);smtp.ehlo()
                smtp.login(self.user,self.password);smtp.send_message(mail)
        except (OSError,smtplib.SMTPException):
            # Keep generic endpoint responses identical for existing/non-existing accounts.
            # Operators get a generic failure signal; no tokens or recipient in logs.
            import logging
            logging.getLogger('zizi.accounts').error('Account mail delivery failed; check SMTP configuration')


def google_verifier(client_id, android_client_id=''):
    # Google-maintained verification, with cached certificates and bounded network timeout.
    from google.oauth2 import id_token
    from google.auth.transport.requests import Request
    import requests
    import cachecontrol
    import threading
    session=cachecontrol.CacheControl(requests.Session())
    request=Request(session=session)
    lock=threading.Lock()
    def bounded(url,method='GET',body=None,headers=None,timeout=None,**kwargs):
        return request(url=url,method=method,body=body,headers=headers,timeout=5,**kwargs)
    def verify(token):
        try:
            with lock:
                claims=id_token.verify_oauth2_token(token,bounded,client_id)
            if claims.get('azp') not in {None,client_id,android_client_id}:
                raise ValueError()
            return claims
        except Exception:
            raise AuthError('google_verification_failed') from None
    return verify


def create_app():
    public=origin(os.environ['ZIZI_ACCOUNT_ORIGIN'])
    private=Path(os.environ['ZIZI_JWT_PRIVATE']).read_bytes()
    public_key=Path(os.environ['ZIZI_JWT_PUBLIC']).read_bytes()
    tokens=Tokens(private,public_key,public)
    accounts=Accounts(os.environ['ZIZI_ACCOUNT_DB'],tokens)
    accounts.prune()
    cid=os.getenv('ZIZI_GOOGLE_WEB_CLIENT_ID','').strip()
    return Application(accounts,public,Mailer(),google_verifier(cid,os.getenv('ZIZI_GOOGLE_ANDROID_CLIENT_ID','')) if cid else None)
