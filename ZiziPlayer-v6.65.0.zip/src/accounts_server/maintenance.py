"""Daily cleanup, no private key needed. Run as zizi-accounts, using accounts.env."""
import os
from pathlib import Path
import sqlite3
import time
path=Path(os.environ['ZIZI_ACCOUNT_DB']).resolve()
c=sqlite3.connect(path.as_uri()+'?mode=rw',uri=True,timeout=10)
now=int(time.time())
with c:
    c.execute('DELETE FROM spent_refresh WHERE sid IN (SELECT id FROM sessions WHERE expires<=?)',(now,))
    for table in ('sessions','tickets','challenges','limits'):
        c.execute('DELETE FROM '+table+' WHERE expires<=?',(now,))
c.execute('PRAGMA wal_checkpoint(PASSIVE)')
c.close()
print('Expired account sessions and one-time codes cleaned up.')
