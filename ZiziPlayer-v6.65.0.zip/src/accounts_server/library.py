"""Account-owned metadata snapshots. No audio, paths to files, or SQL supplied by clients.
Optimistic revision check and two retained generations; all writes are transactional.
"""
import hashlib
import json
from core import AuthError

MAX_BYTES = 8 * 1024 * 1024
TABLES = frozenset("tracks favorites playlists playlist_tracks track_fx eq_profiles hidden play_stats search_history playlist_links recents favorite_shadow listening_sessions home_pins track_catalog".split())


def validate(document):
    if not isinstance(document, str) or len(document.encode('utf-8')) > MAX_BYTES:
        raise AuthError('library_too_large', 413)
    try:
        value = json.loads(document)
        if not isinstance(value, dict) or set(value) != {'format', 'schema', 'tables'}:
            raise ValueError()
        if value['format'] != 'zizi-library-1' or type(value['schema']) is not int or value['schema'] != 10:
            raise ValueError()
        tables = value['tables']
        if not isinstance(tables, dict) or set(tables) != TABLES:
            raise ValueError()
        total = 0
        for rows in tables.values():
            if not isinstance(rows, list): raise ValueError()
            total += len(rows)
            if total > 100000: raise ValueError()
            for row in rows:
                if not isinstance(row, dict) or not 1 <= len(row) <= 40: raise ValueError()
                for key, item in row.items():
                    if not isinstance(key, str) or len(key) > 80: raise ValueError()
                    if item is not None and type(item) not in (str, int, float): raise ValueError()
                    if isinstance(item, str) and len(item) > 65536: raise ValueError()
        # Disallow NaN/Infinity and canonicalise whitespace/key order for idempotent retries.
        result = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
        if len(result.encode('utf-8')) > MAX_BYTES: raise AuthError('library_too_large', 413)
        return result
    except (ValueError, KeyError, TypeError, RecursionError):
        raise AuthError('invalid_library', 400) from None


def latest(accounts, uid):
    with accounts.connection() as c:
        row = c.execute('SELECT * FROM library_snapshots WHERE uid=? ORDER BY revision DESC LIMIT 1', (uid,)).fetchone()
    if not row: return {'revision': 0, 'saved_at': 0, 'document': None}
    return {'revision': row['revision'], 'saved_at': row['saved_at'], 'document': json.loads(row['document'])}


def save(accounts, uid, expected, document):
    if not isinstance(expected, str) or not expected.isascii() or not expected.isdigit() or len(expected) > 15:
        raise AuthError('invalid_revision', 400)
    document = validate(document)
    digest = hashlib.sha256(document.encode('utf-8')).hexdigest()
    with accounts.transaction() as c:
        current = c.execute('SELECT revision,digest,saved_at FROM library_snapshots WHERE uid=? ORDER BY revision DESC LIMIT 1', (uid,)).fetchone()
        revision = current['revision'] if current else 0
        # Retry after a response was lost cannot create another generation or erase newer data.
        if current and current['digest'] == digest:
            return {'revision': revision, 'saved_at': current['saved_at']}
        if int(expected) != revision: raise AuthError('library_conflict', 409)
        revision += 1
        saved_at = accounts.now()
        c.execute('INSERT INTO library_snapshots VALUES(?,?,?,?,?)', (uid,revision,document,digest,saved_at))
        c.execute('DELETE FROM library_snapshots WHERE uid=? AND revision<?', (uid,revision-1))
    return {'revision': revision, 'saved_at': saved_at}
