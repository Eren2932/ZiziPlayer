#!/usr/bin/env python3
"""Compatibility entry point. This bundle installs Accounts 1.2, including profiles.py.
For a new deployment use install_accounts_12.py explicitly.
"""
from install_accounts_12 import install, main
if __name__ == '__main__': main()
