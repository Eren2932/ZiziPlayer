import contextlib
import io
from pathlib import Path
import shutil
import tempfile
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from install_library_11 import install

PAYLOAD=Path(__file__).resolve().parents[1]
class InstallerTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.target=Path(self.tmp.name)/'current';self.target.mkdir()
        for name in ('core.py','web.py','library.py'):shutil.copy2(PAYLOAD/name,self.target/name)
        (self.target/'accounts.env').write_text('example-preserved-configuration')
    def test_known_current_install_is_idempotent(self):
        with contextlib.redirect_stdout(io.StringIO()):
            install(self.target,False);install(self.target,True)
        self.assertEqual((self.target/'accounts.env').read_text(),'example-preserved-configuration')
        for name in ('core.py','web.py','library.py'):
            self.assertEqual((self.target/name).read_bytes(),(PAYLOAD/name).read_bytes())
    def test_modified_smtp_code_is_never_overwritten(self):
        p=self.target/'web.py';p.write_text(p.read_text()+'\n# deployed custom SMTP fix\n')
        original=p.read_bytes()
        with self.assertRaises(ValueError):install(self.target,True)
        self.assertEqual(p.read_bytes(),original)
    def test_missing_core_fails_closed(self):
        (self.target/'core.py').unlink()
        with self.assertRaises(ValueError):install(self.target,True)
    def test_symlink_is_rejected(self):
        (self.target/'web.py').unlink();(self.target/'web.py').symlink_to(PAYLOAD/'web.py')
        with self.assertRaises(ValueError):install(self.target,True)
if __name__=='__main__':unittest.main(verbosity=2)
