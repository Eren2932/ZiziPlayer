"""WSGI/SQLite tests against production Accounts 1.2; no live user credentials."""
import base64
import binascii
import concurrent.futures
import io
import struct
import unittest
import zlib
import test_accounts as existing
from test_accounts import PASSWORD, EMAIL
from core import Accounts, AuthError
from web import ACCESS_COOKIE, Application
import profiles


def chunk(kind, value):
    return struct.pack('>I', len(value)) + kind + value + struct.pack('>I', binascii.crc32(kind + value) & 0xffffffff)

def png(side=8, color=6, extra=b'', pixels=None):
    raw = (b'\x00' + b'\x50' * side * (4 if color == 6 else 3)) * side if pixels is None else pixels
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', side, side, 8, color, 0, 0, 0)) + extra + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')

def image(**kwargs): return base64.b64encode(png(**kwargs)).decode()

class ProfileTest(unittest.TestCase):
    setUpClass = classmethod(existing.AccountsTest.setUpClass.__func__)
    setUp = existing.AccountsTest.setUp
    verified = existing.AccountsTest.verified
    http = existing.AccountsTest.http
    def user(self):
        p=self.verified();return p, ACCESS_COOKIE+'='+p['access']
    def save(self, jar, name='Томиока', avatar='', rev=0):
        return self.http('/auth/profile', {'name':name,'avatar':avatar,'expected_revision':str(rev)},jar=jar)
    def test_anonymous_denied(self):
        self.assertEqual(self.http('/auth/profile')[0],401)
        self.assertEqual(self.save('')[0],401)
    def test_health(self):
        h=self.http('/auth/health')[2]
        self.assertEqual(h['version'],'1.2.0');self.assertTrue(h['profile_enabled']);self.assertTrue(h['sync_enabled'])
    def test_roundtrip_photo_name_and_restart(self):
        p,jar=self.user();photo=image()
        result=self.save(jar,avatar=photo);self.assertEqual(result[0],200)
        self.a=Accounts(self.a.db,self.tokens,lambda:self.now)
        self.web=Application(self.a,'https://accounts.example.org',lambda *args:None)
        self.assertEqual(self.http('/auth/profile',jar=jar)[2],{'name':'Томиока','avatar':photo,'revision':1})
    def test_empty_profile_and_remove_photo(self):
        _,jar=self.user();self.assertEqual(self.http('/auth/profile',jar=jar)[2]['revision'],0)
        self.assertEqual(self.save(jar,avatar=image())[0],200)
        self.assertEqual(self.save(jar,rev=1)[2]['avatar'],'')
    def test_other_account_cannot_read_or_write_owner(self):
        p,jar=self.user();self.save(jar)
        code=self.a.register('other@example.org',PASSWORD);self.a.redeem(code,'verify')
        other=self.a.login('other@example.org',PASSWORD);otherjar=ACCESS_COOKIE+'='+other['access']
        self.assertEqual(self.http('/auth/profile',jar=otherjar)[2]['revision'],0)
        self.assertEqual(self.http('/auth/profile',{'name':'x','avatar':'','expected_revision':'0','uid':p['user']['id']},jar=otherjar)[0],400)
        self.assertEqual(self.http('/auth/profile',jar=jar)[2]['name'],'Томиока')
    def test_cas_conflict_and_lost_response(self):
        _,jar=self.user();self.save(jar)
        self.assertEqual(self.save(jar)[2]['revision'],1)
        self.assertEqual(self.save(jar,name='New',rev=1)[2]['revision'],2)
        self.assertEqual(self.save(jar,name='Stale',rev=1)[0],409)
        self.assertEqual(self.http('/auth/profile',jar=jar)[2]['name'],'New')
    def test_concurrent_writers(self):
        p,jar=self.user();self.save(jar)
        def write(name):
            try:return profiles.save(self.a,p['user']['id'],{'name':name,'avatar':'','expected_revision':'1'})['revision']
            except AuthError as e:return e.status
        with concurrent.futures.ThreadPoolExecutor(2) as pool:self.assertCountEqual(list(pool.map(write,['A','B'])),[2,409])
    def test_expired_and_revoked(self):
        p,jar=self.user();self.save(jar);self.a.logout(p['refresh'])
        self.assertEqual(self.http('/auth/profile',jar=jar)[0],401)
        p=self.a.login(EMAIL,PASSWORD);self.now+=901
        self.assertEqual(self.save(ACCESS_COOKIE+'='+p['access'])[0],401)
    def test_csrf_origin_method(self):
        _,jar=self.user();data={'name':'A','avatar':'','expected_revision':'0'}
        for extra in ({'HTTP_X_ZIZI_ACCOUNT':''},{'HTTP_ORIGIN':'https://evil.example'},{'HTTP_SEC_FETCH_SITE':'cross-site'}):
            self.assertEqual(self.http('/auth/profile',data,jar=jar,extra=extra)[0],403)
        self.assertEqual(self.http('/auth/profile',jar=jar,method='DELETE')[0],405)
    def test_name_validation_and_nfc(self):
        _,jar=self.user()
        for name in ('',' '*10,'x'*81,'line\nbreak','zero'+chr(0),'hidden'+chr(8203)):
            self.assertEqual(self.save(jar,name=name)[0],400)
        self.assertEqual(self.save(jar,name='  Café  ')[2]['name'],'Café')
    def test_invalid_payload_does_not_break_login(self):
        _,jar=self.user()
        self.assertEqual(self.save(jar,name=None)[0],400)
        self.assertEqual(self.save(jar,rev=-1)[0],400)
        self.assertEqual(self.http('/auth/me',jar=jar)[0],200)
    def test_oversize_rejection_keeps_old_profile(self):
        _,jar=self.user();self.save(jar)
        self.assertEqual(self.save(jar,avatar='x'*(profiles.MAX_BODY+1),rev=1)[0],413)
        self.assertEqual(self.http('/auth/profile',jar=jar)[2]['name'],'Томиока')
    def test_library_and_profile_survive_restart_together(self):
        import json
        from test_library import document
        _,jar=self.user();self.save(jar,avatar=image())
        payload={'expected_revision':'0','document':json.dumps(document())}
        self.assertEqual(self.http('/auth/library',payload,jar=jar)[0],200)
        self.a=Accounts(self.a.db,self.tokens,lambda:self.now)
        self.web=Application(self.a,'https://accounts.example.org',lambda *args:None)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['document'],document())
        self.assertEqual(self.http('/auth/profile',jar=jar)[2]['name'],'Томиока')
    def test_schema_upgrade_preserves_existing_library(self):
        import json
        from test_library import document
        _,jar=self.user()
        self.http('/auth/library',{'expected_revision':'0','document':json.dumps(document())},jar=jar)
        with self.a.connection() as c: c.execute('DROP TABLE account_profiles')
        self.a=Accounts(self.a.db,self.tokens,lambda:self.now)
        self.web=Application(self.a,'https://accounts.example.org',lambda *args:None)
        self.assertEqual(self.http('/auth/me',jar=jar)[0],200)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['document'],document())
        self.assertEqual(self.http('/auth/profile',jar=jar)[2]['revision'],0)
    def test_multimegabyte_library_with_mobile_string_envelope(self):
        import json
        from test_library import document
        _,jar=self.user();d=document()
        d['tables']['playlists']=[{'id':i,'name':'Музыка '*300,'createdAt':100,'coverUri':None} for i in range(1000)]
        raw=json.dumps(d,ensure_ascii=False,separators=(',',':'))
        self.assertGreater(len(raw.encode()),3*1024*1024)
        self.assertEqual(self.http('/auth/library',{'expected_revision':'0','document':raw},jar=jar)[0],200)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['document'],d)
    def test_rate_limit(self):
        _,jar=self.user()
        for _ in range(20):self.assertEqual(self.http('/auth/profile',jar=jar)[0],200)
        self.assertEqual(self.http('/auth/profile',jar=jar)[0],429)

class ImageTest(unittest.TestCase):
    def test_rgb_rgba_sizes(self):
        for side in (1,8,256):
            for color in (2,6):
                s=image(side=side,color=color);self.assertEqual(profiles.validate_avatar(s),s)
    def test_reject_bad_image_and_metadata(self):
        values=['https://example.org/a.png','data:image/png;base64,'+image(),'AAAA',image(side=257),image(pixels=b'bad'),
                base64.b64encode(png()+b'trailing').decode(),image(extra=chunk(b'tEXt',b'private data')),
                image(extra=chunk(b'acTL',b'animation'))]
        raw=bytearray(png());raw[-1]^=1;values.append(base64.b64encode(raw).decode())
        for value in values:
            with self.subTest(size=len(value)),self.assertRaises(AuthError):profiles.validate_avatar(value)
    def test_decompression_bomb_bounded(self):
        with self.assertRaises(AuthError):profiles.validate_avatar(image(pixels=b'\x00'*(4*1024*1024)))
    def test_empty_avatar(self):self.assertEqual(profiles.validate_avatar(''),'')

if __name__=='__main__':unittest.main(verbosity=2)
