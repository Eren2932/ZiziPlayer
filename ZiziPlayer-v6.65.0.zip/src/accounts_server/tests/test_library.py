"""Real SQLite + WSGI + signed sessions. No live server or Android claim."""
import concurrent.futures
import copy
import json
import unittest
import test_accounts as existing
from test_accounts import PASSWORD, EMAIL
from web import ACCESS_COOKIE, REFRESH_COOKIE
import library


def document(title='A'):
    tables = {name: [] for name in library.TABLES}
    tables['tracks'] = [{'id': 'r:yt:test', 'title': title, 'source': 'remote', 'savedAt': 100}]
    tables['favorites'] = [{'trackId': 'r:yt:test', 'addedAt': 100}]
    tables['playlists'] = [{'id': 1, 'name': 'Мои треки', 'createdAt': 100, 'coverUri': None}]
    tables['playlist_tracks'] = [{'playlistId': 1, 'trackId': 'r:yt:test', 'position': 0}]
    return {'format': 'zizi-library-1', 'schema': 10, 'tables': tables}


class LibraryTest(unittest.TestCase):
    setUpClass = classmethod(existing.AccountsTest.setUpClass.__func__)
    setUp = existing.AccountsTest.setUp
    verified = existing.AccountsTest.verified
    http = existing.AccountsTest.http

    def user(self):
        p = self.verified()
        return p, ACCESS_COOKIE + '=' + p['access']

    def save(self, jar, rev, value=None):
        return self.http('/auth/library', {'expected_revision': str(rev), 'document': json.dumps(value or document())}, jar=jar)

    def test_no_anonymous_read_or_write(self):
        self.assertEqual(self.http('/auth/library')[0], 401)
        self.assertEqual(self.save('', 0)[0], 401)

    def test_round_trip_remote_library(self):
        _, jar = self.user()
        self.assertEqual(self.http('/auth/library', jar=jar)[2]['revision'], 0)
        self.assertEqual(self.save(jar, 0)[2]['revision'], 1)
        status, _, body = self.http('/auth/library', jar=jar)
        self.assertEqual(status, 200)
        self.assertEqual(body['document'], document())
        self.assertEqual(body['saved_at'], self.now)

    def test_only_session_owner_not_body_owner(self):
        p, jar = self.user(); self.save(jar, 0)
        code=self.a.register('other@example.org', PASSWORD); self.a.redeem(code,'verify')
        other=self.a.login('other@example.org', PASSWORD)
        otherjar=ACCESS_COOKIE+'='+other['access']
        self.assertEqual(self.http('/auth/library',jar=otherjar)[2]['revision'],0)
        data={'expected_revision':'0','document':json.dumps(document()),'uid':p['user']['id']}
        self.assertEqual(self.http('/auth/library',data,jar=otherjar)[0],400)

    def test_lost_response_retry_is_idempotent(self):
        _,jar=self.user()
        self.assertEqual(self.save(jar,0)[2]['revision'],1)
        self.assertEqual(self.save(jar,0)[2]['revision'],1)
        with self.a.connection() as c:
            self.assertEqual(c.execute('SELECT count(*) FROM library_snapshots').fetchone()[0],1)

    def test_stale_device_cannot_erase_newer_library(self):
        _,jar=self.user();self.save(jar,0)
        self.assertEqual(self.save(jar,1,document('new'))[0],200)
        self.assertEqual(self.save(jar,1,document('old'))[0],409)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['document'],document('new'))

    def test_concurrent_devices_exactly_one_writer(self):
        p,jar=self.user();self.save(jar,0)
        def work(title):
            try:return library.save(self.a,p['user']['id'],'1',json.dumps(document(title)))['revision']
            except Exception as e:return getattr(e,'status',None)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            self.assertCountEqual(list(pool.map(work,['B','C'])),[2,409])

    def test_retains_two_generations(self):
        p,jar=self.user()
        for i in range(4):self.assertEqual(self.save(jar,i,document(str(i)))[0],200)
        with self.a.connection() as c:
            self.assertEqual([r[0] for r in c.execute('SELECT revision FROM library_snapshots ORDER BY revision')],[3,4])

    def test_reject_bad_shapes_and_nonfinite(self):
        p,jar=self.user()
        bad=[]
        for key,value in [('format','other'),('schema',11),('schema',True),('tables',{})]:
            d=document();d[key]=value;bad.append(d)
        d=document();d['tables']['users']=[];bad.append(d)
        d=document();d['tables']['tracks'][0]['title']={};bad.append(d)
        d=document();d['tables']['tracks'][0]['title']='x'*65537;bad.append(d)
        d=document();d['tables']['tracks'][0]['savedAt']=float('nan');bad.append(d)
        for d in bad:
            with self.subTest(d=list(d.keys())):self.assertEqual(self.save(jar,0,d)[0],400)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['revision'],0)

    def test_authentication_survives_library_rejection(self):
        _,jar=self.user()
        self.assertEqual(self.http('/auth/library',{'expected_revision':'-1','document':json.dumps(document())},jar=jar)[0],400)
        self.assertEqual(self.http('/auth/me',jar=jar)[0],200)

    def test_revoked_and_expired_sessions_cannot_read(self):
        p,jar=self.user();self.save(jar,0)
        self.a.logout(p['refresh'])
        self.assertEqual(self.http('/auth/library',jar=jar)[0],401)
        p=self.a.login(EMAIL,PASSWORD);jar=ACCESS_COOKIE+'='+p['access'];self.now+=901
        self.assertEqual(self.http('/auth/library',jar=jar)[0],401)

    def test_csrf_and_origin_checks_apply(self):
        _,jar=self.user();data={'expected_revision':'0','document':json.dumps(document())}
        for extra in ({'HTTP_X_ZIZI_ACCOUNT':''},{'HTTP_ORIGIN':'https://evil.example'}, {'HTTP_SEC_FETCH_SITE':'cross-site'}):
            self.assertEqual(self.http('/auth/library',data,jar=jar,extra=extra)[0],403)

    def test_auth_body_limit_unchanged(self):
        self.assertEqual(self.http('/auth/login',{'email':'x'*20000,'password':PASSWORD})[0],413)

    def test_health_advertises_library_protocol(self):
        body=self.http('/auth/health')[2]
        self.assertTrue(body['sync_enabled']);self.assertEqual(body['library_format'],'zizi-library-1')

    def test_large_library_roundtrip_above_old_32k_cap(self):
        _,jar=self.user();d=document()
        d['tables']['playlists']=[{'id':i,'name':'Плейлист '+str(i),'createdAt':100,'coverUri':None} for i in range(1000)]
        self.assertGreater(len(json.dumps(d)),32768)
        self.assertEqual(self.save(jar,0,d)[0],200)
        self.assertEqual(self.http('/auth/library',jar=jar)[2]['document'],d)

if __name__=='__main__':unittest.main(verbosity=2)
