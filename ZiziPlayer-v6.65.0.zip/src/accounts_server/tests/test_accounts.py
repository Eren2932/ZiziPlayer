import concurrent.futures
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from core import Accounts,Tokens,AuthError,ACCESS_SECONDS,REFRESH_SECONDS,MAIL_SECONDS,b64,unb64,digest,origin
from web import Application,ACCESS_COOKIE,REFRESH_COOKIE

PASSWORD='a long unique test password'
EMAIL='person@example.org'
class AccountsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        cls.private=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
        cls.public=key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.now=1800000000
        self.tokens=Tokens(self.private,self.public,'https://accounts.example.org',lambda:self.now)
        self.a=Accounts(Path(self.tmp.name)/'accounts.sqlite',self.tokens,lambda:self.now)
        self.mail=[]
        self.web=Application(self.a,'https://accounts.example.org',lambda *args:self.mail.append(args))

    def verified(self):
        code=self.a.register(EMAIL,PASSWORD);self.a.redeem(code,'verify')
        return self.a.login(EMAIL,PASSWORD)

    def denied(self,fn,code=None):
        with self.assertRaises(AuthError) as error:fn()
        if code:self.assertEqual(error.exception.code,code)

    def http(self,path,data=None,jar='',method=None,extra=None):
        raw=json.dumps(data if data is not None else {}).encode()
        env={'wsgi.url_scheme':'https','PATH_INFO':path,'REQUEST_METHOD':method or ('POST' if data is not None else 'GET'),
             'wsgi.input':io.BytesIO(raw),'CONTENT_LENGTH':str(len(raw)),'CONTENT_TYPE':'application/json',
             'HTTP_X_ZIZI_ACCOUNT':'1','REMOTE_ADDR':'192.0.2.1','HTTP_COOKIE':jar}
        env.update(extra or {})
        capture=[]
        body=b''.join(self.web(env,lambda status,headers:capture.append((int(status.split()[0]),headers))))
        return capture[0][0],capture[0][1],json.loads(body)

    def test_ttl_exact(self):
        p=self.verified()
        for name,ttl in [('access',900),('refresh',604800)]:
            c=self.tokens.verify(p[name],name)
            self.assertEqual(c['exp']-c['iat'],ttl)
        self.assertEqual(ACCESS_SECONDS,900);self.assertEqual(REFRESH_SECONDS,604800)

    def test_signature_and_algorithm_confusion(self):
        p=self.verified();h,c,s=p['access'].split('.')
        forged=b64(json.dumps(dict(alg='none',typ='JWT',kid=self.tokens.kid)).encode())+'.'+c+'.'+s
        self.denied(lambda:self.tokens.verify(forged,'access'))
        claim=json.loads(unb64(c));claim['sub']='0'*32
        self.denied(lambda:self.tokens.verify(h+'.'+b64(json.dumps(claim).encode())+'.'+s,'access'))
        self.denied(lambda:self.tokens.verify(h+'.'+c+'.'+b64(b'bad'),'access'))

    def test_no_cross_use_of_token_types(self):
        p=self.verified()
        self.denied(lambda:self.a.authenticate(p['refresh']))
        self.denied(lambda:self.a.refresh(p['access']))

    def test_expiry_boundary(self):
        p=self.verified();self.now+=899;self.a.authenticate(p['access'])
        self.now+=1;self.denied(lambda:self.a.authenticate(p['access']))
        p2=self.a.refresh(p['refresh']);self.a.authenticate(p2['access'])
        self.now=1800000000+604800
        self.denied(lambda:self.a.refresh(p2['refresh']))

    def test_rotation_is_not_sliding(self):
        p=self.verified();self.now+=604799;p2=self.a.refresh(p['refresh'])
        self.assertEqual(p['expires'],p2['expires'])
        self.assertEqual(self.tokens.verify(p2['access'],'access')['exp'],p['expires'])
        self.now+=1;self.denied(lambda:self.a.authenticate(p2['access']))

    def test_rotation_reuse_revokes_entire_family_and_persists(self):
        p=self.verified();p2=self.a.refresh(p['refresh'])
        self.assertNotEqual(p2['refresh'],p['refresh'])
        self.denied(lambda:self.a.refresh(p['refresh']),'session_reused')
        self.denied(lambda:self.a.authenticate(p2['access']))
        self.denied(lambda:self.a.refresh(p2['refresh']))
        with self.a.connection() as c:self.assertEqual(c.execute('SELECT revoked FROM sessions').fetchone()[0],1)

    def test_concurrent_rotation_fails_closed(self):
        p=self.verified()
        def run():
            try:return self.a.refresh(p['refresh'])
            except AuthError as e:return e.code
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:run(),range(2)))
        winners=[r for r in results if isinstance(r,dict)]
        self.assertEqual(len(winners),1);self.assertIn('session_reused',results)
        self.denied(lambda:self.a.authenticate(winners[0]['access']))

    def test_sessions_are_separate(self):
        one=self.verified();two=self.a.login(EMAIL,PASSWORD)
        newer=self.a.refresh(one['refresh']);self.denied(lambda:self.a.refresh(one['refresh']))
        self.a.authenticate(two['access']);self.denied(lambda:self.a.authenticate(newer['access']))

    def test_logout_revokes_access_immediately(self):
        p=self.verified();self.a.logout(p['refresh']);self.denied(lambda:self.a.authenticate(p['access']))

    def test_logout_all_revokes_all_families(self):
        p=self.verified();other=self.a.login(EMAIL,PASSWORD)
        self.a.logout(p['refresh'],True)
        for x in (p,other):self.denied(lambda:self.a.authenticate(x['access']))

    def test_spent_token_cannot_logout_other_sessions(self):
        p=self.verified();other=self.a.login(EMAIL,PASSWORD);self.a.refresh(p['refresh'])
        self.denied(lambda:self.a.logout(p['refresh'],True));self.a.authenticate(other['access'])

    def test_password_reset_revokes_all_and_code_single_use(self):
        p=self.verified();code=self.a.request_ticket(EMAIL,'reset')
        self.a.redeem(code,'reset','my next unique password')
        self.denied(lambda:self.a.authenticate(p['access']))
        self.denied(lambda:self.a.login(EMAIL,PASSWORD))
        self.a.login(EMAIL,'my next unique password')
        self.denied(lambda:self.a.redeem(code,'reset',PASSWORD),'invalid_code')

    def test_unverified_login_denied(self):
        self.a.register(EMAIL,PASSWORD)
        self.denied(lambda:self.a.login(EMAIL,PASSWORD),'email_not_verified')

    def test_registration_does_not_replace_existing_password(self):
        self.verified();self.assertIsNone(self.a.register(EMAIL,'different long password'))
        self.a.login(EMAIL,PASSWORD);self.denied(lambda:self.a.login(EMAIL,'different long password'))

    def test_verification_expiry_and_reissue(self):
        old=self.a.register(EMAIL,PASSWORD);new=self.a.request_ticket(EMAIL,'verify')
        self.denied(lambda:self.a.redeem(old,'verify'),'invalid_code')
        self.now+=MAIL_SECONDS;self.denied(lambda:self.a.redeem(new,'verify'),'invalid_code')

    def test_mail_ticket_purpose_is_bound(self):
        code=self.a.register(EMAIL,PASSWORD)
        self.denied(lambda:self.a.redeem(code,'reset',PASSWORD),'invalid_code')
        self.a.redeem(code,'verify');self.denied(lambda:self.a.redeem(code,'verify'),'invalid_code')

    def test_password_hashes_salted_and_bounded(self):
        one=self.a.passwords.hash(PASSWORD);two=self.a.passwords.hash(PASSWORD)
        self.assertNotEqual(one,two);self.assertNotIn(PASSWORD,one)
        self.assertTrue(self.a.passwords.verify(PASSWORD,one))
        self.assertFalse(self.a.passwords.verify('not the correct password',one))
        self.a.passwords.slot.acquire()
        try:self.denied(lambda:self.a.passwords.hash(PASSWORD),'busy')
        finally:self.a.passwords.slot.release()

    def test_database_has_hashes_not_tokens(self):
        p=self.verified();self.a.refresh(p['refresh'])
        with self.a.connection() as c:dump='\n'.join(c.iterdump())
        for secret in (PASSWORD,p['access'],p['refresh']):self.assertNotIn(secret,dump)
        self.assertIn(digest(p['refresh']),dump)

    def test_role_cannot_be_escalated_by_registration(self):
        code=self.a.register(EMAIL,PASSWORD);self.a.redeem(code,'verify');p=self.a.login(EMAIL,PASSWORD)
        self.assertEqual(p['user']['role'],'user')
        self.denied(lambda:self.a.authenticate(p['access'],'service:inspect'),'forbidden')

    def test_rbac_uses_current_database_role(self):
        p=self.verified()
        with self.a.connection() as c:c.execute("UPDATE users SET role='admin'")
        self.a.authenticate(p['access'],'service:inspect')
        with self.a.connection() as c:c.execute("UPDATE users SET role='user'")
        self.denied(lambda:self.a.authenticate(p['access'],'service:inspect'),'forbidden')

    def test_disable_revokes_effective_access_and_refresh(self):
        p=self.verified()
        with self.a.connection() as c:c.execute('UPDATE users SET disabled=1')
        self.denied(lambda:self.a.authenticate(p['access']));self.denied(lambda:self.a.refresh(p['refresh']))

    def test_limiter_persistent_and_expires(self):
        for _ in range(3):self.a.rate('same',3,60)
        self.denied(lambda:self.a.rate('same',3,60),'rate_limited')
        self.now+=60;self.a.rate('same',3,60)

    def test_http_cookie_flags_and_no_tokens_in_body(self):
        self.verified();status,headers,body=self.http('/auth/login',dict(email=EMAIL,password=PASSWORD))
        self.assertEqual(status,200);self.assertNotIn('access',body);self.assertNotIn('refresh',body)
        cs=[v for k,v in headers if k=='Set-Cookie'];self.assertEqual(len(cs),2)
        for v in cs:
            for flag in ('Path=/','Secure','HttpOnly','SameSite=Strict'):self.assertIn(flag,v)
            self.assertNotIn('Domain=',v)
        self.assertIn('Max-Age=900;',cs[0]);self.assertIn('Max-Age=604800;',cs[1])
        jar='; '.join(v.split(';')[0] for v in cs)
        self.assertEqual(self.http('/auth/me',jar=jar)[0],200)
        self.assertEqual(self.http('/auth/admin/status',jar=jar)[0],403)

    def test_http_refresh_and_logout_flow(self):
        self.verified();_,heads,_=self.http('/auth/login',dict(email=EMAIL,password=PASSWORD))
        jar='; '.join(v.split(';')[0] for k,v in heads if k=='Set-Cookie')
        status,heads,_=self.http('/auth/refresh',{},jar)
        self.assertEqual(status,200)
        jar='; '.join(v.split(';')[0] for k,v in heads if k=='Set-Cookie')
        status,heads,_=self.http('/auth/logout',{},jar);self.assertEqual(status,200)
        self.assertTrue(all('Max-Age=0;' in v for k,v in heads if k=='Set-Cookie'))
        self.assertEqual(self.http('/auth/me',jar=jar)[0],401)

    def test_http_csrf_origin_and_content_type(self):
        for extra in ({'HTTP_X_ZIZI_ACCOUNT':''},{'HTTP_ORIGIN':'https://evil.example'},{'HTTP_SEC_FETCH_SITE':'cross-site'}):
            self.assertEqual(self.http('/auth/login',{},extra=extra)[0],403)
        self.assertEqual(self.http('/auth/login',{},extra={'CONTENT_TYPE':'text/plain'})[0],415)
        self.assertEqual(self.http('/auth/login',{},method='OPTIONS')[0],405)
        self.assertEqual(self.http('/auth/health',extra={'wsgi.url_scheme':'http'})[0],400)

    def test_http_duplicate_cookie_and_bad_payload(self):
        self.assertEqual(self.http('/auth/me',jar=f'{ACCESS_COOKIE}=one; {ACCESS_COOKIE}=two')[0],400)
        self.assertEqual(self.http('/auth/login',{'email':123})[0],400)
        self.assertEqual(self.http('/auth/login',{},extra={'CONTENT_LENGTH':'99999'})[0],413)

    def test_generic_recovery_and_registration_responses(self):
        _,_,new=self.http('/auth/register',dict(email=EMAIL,password=PASSWORD))
        _,_,existing=self.http('/auth/register',dict(email=EMAIL,password=PASSWORD))
        self.assertEqual(new,existing);self.assertEqual(len(self.mail),1)
        _,_,yes=self.http('/auth/forgot',dict(email=EMAIL))
        _,_,no=self.http('/auth/forgot',dict(email='missing@example.org'))
        self.assertEqual(yes,no)

    def test_google_disabled_fails_closed(self):
        self.assertEqual(self.http('/auth/google/challenge',{})[0],503)
        self.assertFalse(self.http('/auth/health')[2]['google_enabled'])

    def google_claims(self,nonce,email='person@gmail.com',sub='google-sub-123'):
        return dict(sub=sub,email=email,email_verified=True,nonce=nonce)

    def test_google_nonce_single_use(self):
        challenge=self.a.challenge();claims=self.google_claims(challenge['nonce'])
        pair=self.a.google_login(challenge['challenge'],claims);self.a.authenticate(pair['access'])
        self.denied(lambda:self.a.google_login(challenge['challenge'],claims))

    def test_google_nonce_wrong_or_expired(self):
        challenge=self.a.challenge()
        self.denied(lambda:self.a.google_login(challenge['challenge'],self.google_claims('wrong')))
        self.now+=300
        self.denied(lambda:self.a.google_login(challenge['challenge'],self.google_claims(challenge['nonce'])))

    def test_google_does_not_link_by_email(self):
        self.verified();challenge=self.a.challenge()
        claims=self.google_claims(challenge['nonce'],EMAIL);claims['hd']='example.org'
        self.denied(lambda:self.a.google_login(challenge['challenge'],claims),'use_existing_sign_in')
        self.a.login(EMAIL,PASSWORD)

    def test_google_unverified_or_external_email_denied(self):
        challenge=self.a.challenge();claims=self.google_claims(challenge['nonce']);claims['email_verified']=False
        self.denied(lambda:self.a.google_login(challenge['challenge'],claims),'google_email_use_password')
        self.denied(lambda:self.a.google_login(challenge['challenge'],self.google_claims(challenge['nonce'],'external@example.org')),'google_email_use_password')

    def test_google_server_ignores_self_asserted_request_claims(self):
        # Verifier boundary is injected here; these tests do NOT validate Google's live keys.
        self.web.google_verifier=lambda token: (_ for _ in ()).throw(AuthError('google_verification_failed'))
        self.assertEqual(self.http('/auth/google',dict(id_token='fake',challenge='fake',email='attacker@gmail.com'))[0],401)

    def test_malformed_tokens_fail_closed(self):
        for token in ('','a.b.c','☃','x'*4097,'null.e30.AA','W10.e30.AA'):
            self.denied(lambda:self.tokens.verify(token,'access'))

    def test_origin_validation(self):
        for value in ('http://example.org','https://user@example.org','https://example.org?x=1','https://example.org/path','https://example.org:8443'):
            with self.assertRaises(ValueError):origin(value)

    def test_prune_cleans_expired_sessions_and_tickets(self):
        p=self.verified();self.a.refresh(p['refresh']);self.a.challenge();self.a.request_ticket(EMAIL,'reset')
        self.now+=REFRESH_SECONDS;self.a.prune()
        with self.a.connection() as c:
            for table in ('sessions','spent_refresh','tickets','challenges'):
                self.assertEqual(c.execute('SELECT count(*) FROM '+table).fetchone()[0],0)

    def test_wrong_issuer_and_audience_are_rejected(self):
        pair=self.verified()
        alternate=Tokens(self.private,self.public,'https://different.example.org',lambda:self.now)
        self.denied(lambda:alternate.verify(pair['access'],'access'))
        h,p,_=pair['access'].split('.')
        c=json.loads(unb64(p));c['aud']='music-catalog'
        data=h+'.'+b64(json.dumps(c).encode())
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        sig=b64(self.tokens.private.sign(data.encode(),padding.PKCS1v15(),hashes.SHA256()))
        self.denied(lambda:self.tokens.verify(data+'.'+sig,'access'))

    def test_x509_public_certificate_container(self):
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes
        from cryptography.x509.oid import NameOID
        import datetime
        key=serialization.load_pem_private_key(self.private,None)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'test-only')])
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
              .serial_number(x509.random_serial_number())
              .not_valid_before(datetime.datetime(2026,1,1,tzinfo=datetime.timezone.utc))
              .not_valid_after(datetime.datetime(2030,1,1,tzinfo=datetime.timezone.utc))
              .sign(key,hashes.SHA256()))
        tokens=Tokens(self.private,cert.public_bytes(serialization.Encoding.PEM),'https://accounts.example.org',lambda:self.now)
        tokens.verify(self.verified()['access'],'access')

    def test_mismatched_key_pair_rejected(self):
        other=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        public=other.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        with self.assertRaises(ValueError):Tokens(self.private,public,'https://accounts.example.org')

    def test_logout_all_without_valid_cookie_cannot_claim_success(self):
        self.assertEqual(self.http('/auth/logout-all',{})[0],401)
        self.assertEqual(self.http('/auth/logout',{})[0],200)

    def test_untrusted_proxy_header_cannot_change_rate_identity(self):
        for i in range(20):
            self.http('/auth/verify',dict(code='bad'),extra={'HTTP_X_REAL_IP':'198.51.100.'+str(i)})
        status,_,body=self.http('/auth/verify',dict(code='bad'),extra={'HTTP_X_REAL_IP':'198.51.100.99'})
        self.assertEqual(status,429);self.assertEqual(body['error'],'rate_limited')

    def test_user_session_cap(self):
        first=self.verified()
        for _ in range(10):self.a.login(EMAIL,PASSWORD);self.now+=1
        self.denied(lambda:self.a.authenticate(first['access']))
        with self.a.connection() as c:
            self.assertEqual(c.execute('SELECT count(*) FROM sessions WHERE revoked=0').fetchone()[0],10)

if __name__=='__main__':unittest.main(verbosity=2)
