package app.ziziplayer.ui

/** Platform-free rules shared by the ViewModel and collection screen. */
internal object SearchPresentation {
    fun nextPage(next: String?, previous: String?, received: Int): String? =
        next?.takeIf { it.isNotBlank() && it != previous && received > 0 }

    fun durationMinutes(durations: List<Long>, complete: Boolean): Long? =
        if (!complete || durations.isEmpty() || durations.any { it <= 0L }) null
        else durations.sum() / 60000L
}
