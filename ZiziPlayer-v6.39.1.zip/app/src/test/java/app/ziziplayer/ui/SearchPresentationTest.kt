package app.ziziplayer.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SearchPresentationTest {
    @Test fun repeatedTokenStopsPaging() {
        assertNull(SearchPresentation.nextPage("25", "25", 25))
    }
    @Test fun emptyPageStopsPaging() {
        assertNull(SearchPresentation.nextPage("50", "25", 0))
    }
    @Test fun noTokenStopsPaging() {
        assertNull(SearchPresentation.nextPage(null, "25", 25))
        assertNull(SearchPresentation.nextPage("", null, 25))
    }
    @Test fun advancingTokenIsPreserved() {
        assertEquals("50", SearchPresentation.nextPage("50", "25", 25))
    }
    @Test fun partialPlaylistHasNoInventedDuration() {
        assertNull(SearchPresentation.durationMinutes(listOf(180000L), false))
    }
    @Test fun unknownDurationsAreNotZeroLengthSongs() {
        assertNull(SearchPresentation.durationMinutes(listOf(180000L, 0L), true))
        assertNull(SearchPresentation.durationMinutes(emptyList(), true))
    }
    @Test fun completeDurationUsesAllTracks() {
        assertEquals(7L, SearchPresentation.durationMinutes(listOf(180000L, 240000L), true))
    }
}
