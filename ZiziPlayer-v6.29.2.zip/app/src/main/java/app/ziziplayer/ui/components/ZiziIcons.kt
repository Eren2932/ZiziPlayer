package app.ziziplayer.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Свой набор глифов. 6.18.0 — транспорт, 6.24.1 — всё остальное приложение.
 *
 * ## Зачем
 *
 * `Icons.Filled.*` — рисунок Material 2014 года: залитые силуэты, плотность линий разная у
 * соседних знаков, скруглений почти нет. В интерфейсе Zizi, где всё построено на тонких линиях,
 * крупных радиусах и полупрозрачных подложках, они читаются как наклейки из другого приложения.
 * Особенно это било по мусорке: `Icons.Filled.DeleteOutline`, `DeleteForever` и `DeleteSweep` —
 * три разных по весу и по логике знака в одном столбце меню.
 *
 * ## Правила набора
 *
 * Один вес линии (2.05 из 24) на весь набор, круглые торцы и стыки, сетка 24, оптический центр
 * вместо геометрического. Поэтому «удалить», «скачать» и «поделиться» выглядят частями одного
 * шрифта, а не иконками из трёх пачек.
 *
 * Заливка у обводочных знаков не задаётся (`fill = null`), у сплошных ([solid]) — задаётся
 * чёрным: `Icon` красит вектор ColorFilter'ом, поэтому tint, акцент темы и подсветка активного
 * состояния работают одинаково и там, и там.
 *
 * Векторы собираются лениво и один раз: `ImageVector` неизменяем, а пересборка на каждой
 * рекомпозиции — это лишний `VectorPainter` на каждом кадре.
 *
 * 6.25.0: системных знаков больше не осталось ни одного. `PlayArrow`, `Pause`, `SkipNext`,
 * `SkipPrevious`, `ArrowBack`, `GraphicEq`, `Close` и `Refresh` в material-варианте держались
 * дольше всех «потому что они крупные и там Material безупречен». На проверку это оказалось
 * ровно наоборот: у material-транспорта треугольник Play построен по геометрическому центру
 * (центр описанного прямоугольника), а глаз видит центр массы треугольника — он на 1/6 ширины
 * левее. Поэтому Play в круглой кнопке всегда казался сдвинутым влево, и это правился отступом
 * в вызове, отдельно на каждом экране. Здесь треугольник смещён на свои 0.4 единицы сетки один
 * раз, внутри глифа: центр массы (7.6 + 7.6 + 19.6) / 3 = 11.6 против середины круга 12.
 *
 * Толстые знаки транспорта рисуются [heavy] — обводка увеличенной ширины с круглыми торцами,
 * а не залитый контур со скруглениями: скругление в залитом пути пришлось бы задавать дугами
 * в каждом углу, и при масштабировании с 22 до 56 dp радиус поехал бы вместе с путём. У
 * обводки радиус торца всегда равен половине её ширины, на любом размере.
 */
object ZiziIcons {

    private const val STROKE = 2.05f

    private fun stroked(name: String, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /** Сплошной знак: «стоп» и «играть» обязаны быть тяжелее остальных, это команды. */
    private fun solid(name: String, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.Black),
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /**
     * Тяжёлый знак: обводка ширины [width] с круглыми торцами. Для «пауза», «вперёд», «назад» —
     * там, где нужна масса Play, но с идеально круглыми концами на любом кегле.
     */
    private fun heavy(name: String, width: Float, pathBuilder: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = width,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { pathBuilder() }
        }.build()

    /* ============================================================ транспорт (6.18.0) */

    /**
     * «Перемешать»: две S-образные линии меняются местами, обе со стрелкой вправо.
     * Кривые симметричны относительно центра, поэтому знак остаётся уравновешенным и в 23 dp.
     */
    val Shuffle: ImageVector by lazy {
        stroked("zizi_shuffle") {
            moveTo(3.4f, 7.6f)
            lineTo(6.2f, 7.6f)
            curveTo(9.8f, 7.6f, 11.4f, 16.4f, 15.0f, 16.4f)
            lineTo(19.0f, 16.4f)

            moveTo(3.4f, 16.4f)
            lineTo(6.2f, 16.4f)
            curveTo(9.8f, 16.4f, 11.4f, 7.6f, 15.0f, 7.6f)
            lineTo(19.0f, 7.6f)

            // Наконечники: вершина совпадает с концом линии, поэтому стык не виден.
            moveTo(16.6f, 5.2f); lineTo(19.4f, 7.6f); lineTo(16.6f, 10.0f)
            moveTo(16.6f, 14.0f); lineTo(19.4f, 16.4f); lineTo(16.6f, 18.8f)
        }
    }

    /**
     * «Повторять»: скруглённый прямоугольник с разрывом внизу и стрелкой, входящей в разрыв.
     *
     * 6.29.2. До этого здесь было кольцо радиуса 7.4 — круг среди прямоугольных карточек плеера.
     * Референс — знак-скоба: широкая горизонтальная рамка с большим радиусом угла, разрыв не
     * сверху, а снизу-слева, и стрелка, которая возвращает дорожку в начало. Разница не
     * стилистическая: круг занимает вписанный квадрат, а рамка — всю ширину глифа, поэтому в ряду
     * транспорта знак читается на том же кегле заметно крупнее и не проваливается рядом с
     * «перемешать».
     *
     * ## Откуда числа
     *
     * Геометрия снята с референса пиксельно, а не подобрана на глаз: маска эталона (62 px по
     * ширине) и растр кандидата сравнивались по IoU, параметры (полуширина, радиус угла, толщина,
     * срез разрыва, остриё, разлёт крыльев) подбирались покоординатным спуском до 0.95 —
     * оставшееся расхождение это одна строка сглаживания на верхней грани JPEG-эталона.
     * Множитель перевода — 0.3725 единицы сетки на пиксель эталона, центр (30.5, 27.675) px → (12, 12).
     *
     * ## Почему три пути, а не один
     *
     *  * **Рамка — [StrokeCap.Butt].** В эталоне торцы у разрыва срезаны строго вертикально: и
     *    внизу у «хвоста», и вверху у цифры. Круглый торец на срезе 2.24 шириной сразу видно —
     *    разрыв перестаёт быть щелью и превращается в две капли.
     *  * **Стрелка — [StrokeCap.Round].** Остриё и оба крыла в эталоне скруглены. Один путь на
     *    рамку и стрелку такое сочетание задать не даёт: cap задаётся на путь целиком.
     *  * **Цифра — свой путь**, потому что у неё срезаны оба торца, а стык флажка со стволом
     *    скруглён; join у пути общий, cap тоже, и это ровно её комбинация.
     *
     * Толщина 2.24 против 2.05 у остального набора — это не разнобой: доля от ширины знака у
     * референса 0.098, и при кегле 0.45 диаметра кнопки (см. PlayerScreen) на экране получается
     * ровно 2.05 dp, как у соседей по ряду.
     *
     * Точка активного состояния в глиф не входит: её рисует TransportButton под знаком, иначе
     * рамка со стрелкой ужалась бы на четверть, чтобы освободить место под точку внутри той же
     * сетки 24, и «повторять» стало бы самым мелким знаком в ряду.
     */
    val Repeat: ImageVector by lazy { repeatGlyph("zizi_repeat", one = false) }

    /**
     * «Повторять один»: та же рамка с разрывом вверху и «1» в разрыве. Ствол цифры чуть правее
     * центра (12.86 против 12) — флажок висит слева, и по массе знак уравновешен именно так;
     * поставить ствол ровно по центру значит увести всю цифру влево.
     */
    val RepeatOne: ImageVector by lazy { repeatGlyph("zizi_repeat_one", one = true) }

    /** Толщина обводки знака «повторять». Своя, см. KDoc [Repeat]. */
    private const val REPEAT_STROKE = 2.24f

    private fun repeatGlyph(name: String, one: Boolean): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = REPEAT_STROKE,
                strokeLineCap = StrokeCap.Butt,
                strokeLineJoin = StrokeJoin.Round
            ) { repeatFrame(one) }
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = REPEAT_STROKE,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) { repeatArrow() }
            if (one) {
                path(
                    fill = null,
                    stroke = SolidColor(Color.Black),
                    strokeLineWidth = REPEAT_STROKE,
                    strokeLineCap = StrokeCap.Butt,
                    strokeLineJoin = StrokeJoin.Round
                ) { repeatDigitOne() }
            }
        }.build()

    /**
     * Рамка: срез разрыва (6.79, 19.24) → низ влево → по часовой вокруг всех четырёх углов →
     * обратно по нижней грани к острию стрелки (10.77). Радиус угла 3.46 по осевой линии.
     *
     * Обход именно по часовой стрелке, поэтому у всех четырёх дуг `isPositiveArc = true`: в
     * системе с осью Y вниз положительное направление — по часовой.
     */
    private fun PathBuilder.repeatFrame(one: Boolean) {
        moveTo(6.79f, 19.24f)
        lineTo(5.18f, 19.24f)
        // радиусы, поворот, длинная дуга, по часовой, конечная точка
        arcTo(3.46f, 3.46f, 0f, false, true, 1.72f, 15.78f)
        lineTo(1.72f, 6.06f)
        arcTo(3.46f, 3.46f, 0f, false, true, 5.18f, 2.60f)
        if (one) {
            // Верхняя грань разорвана под цифру: та же щель 6.79 … 17.22, что и внизу.
            lineTo(6.79f, 2.60f)
            moveTo(17.22f, 2.60f)
        }
        lineTo(18.82f, 2.60f)
        arcTo(3.46f, 3.46f, 0f, false, true, 22.28f, 6.06f)
        lineTo(22.28f, 15.78f)
        arcTo(3.46f, 3.46f, 0f, false, true, 18.82f, 19.24f)
        lineTo(10.77f, 19.24f)
    }

    /**
     * Стрелка: крылья ±3.35 по вертикали при выносе 3.24 по горизонтали — половинный угол 46°,
     * как в эталоне. Остриё стоит ровно на осевой линии нижней грани (19.24), поэтому стык
     * рамки и стрелки не виден: круглое остриё накрывает срезанный торец грани.
     */
    private fun PathBuilder.repeatArrow() {
        moveTo(14.01f, 15.89f); lineTo(10.77f, 19.24f); lineTo(14.01f, 22.59f)
    }

    /** «1»: флажок и ствол одной ломаной, стык скруглён join'ом, оба торца срезаны. */
    private fun PathBuilder.repeatDigitOne() {
        moveTo(10.12f, 3.52f); lineTo(12.86f, 1.32f); lineTo(12.86f, 10.82f)
    }

    /* ============================================================ удаление */

    /**
     * Корзина. Один силуэт на все три «удалить» в приложении, разница только в приписке —
     * поэтому «убрать из Zizi», «удалить все загрузки» и «удалить файл» видно как родственные
     * действия разной силы, а не как три случайных знака.
     */
    val Trash: ImageVector by lazy { stroked("zizi_trash") { can(); ribs() } }

    /** «Удалить всё»: та же корзина и линии движения — знак «сразу несколько». */
    val TrashSweep: ImageVector by lazy {
        stroked("zizi_trash_sweep") {
            can()
            moveTo(10.2f, 10.8f); lineTo(10.5f, 15.6f)
            moveTo(13.8f, 10.8f); lineTo(13.5f, 15.6f)
            moveTo(1.9f, 10.2f); lineTo(3.9f, 10.2f)
            moveTo(1.9f, 14.0f); lineTo(3.9f, 14.0f)
        }
    }

    /** «Удалить навсегда»: корзина с крестом внутри. Необратимость видно до нажатия. */
    val TrashForever: ImageVector by lazy {
        stroked("zizi_trash_forever") {
            can()
            moveTo(9.9f, 10.9f); lineTo(14.1f, 15.5f)
            moveTo(14.1f, 10.9f); lineTo(9.9f, 15.5f)
        }
    }

    private fun PathBuilder.can() {
        // Крышка и ручка отдельными подпутями: так ручка не «врастает» в крышку углом.
        moveTo(3.9f, 6.9f); lineTo(20.1f, 6.9f)
        moveTo(9.4f, 6.9f); lineTo(9.4f, 4.9f); lineTo(14.6f, 4.9f); lineTo(14.6f, 6.9f)
        // Корпус слегка сужается вниз — иначе корзина читается как коробка.
        moveTo(6.1f, 7.4f); lineTo(7.0f, 19.1f); lineTo(17.0f, 19.1f); lineTo(17.9f, 7.4f)
    }

    private fun PathBuilder.ribs() {
        moveTo(10.2f, 10.8f); lineTo(10.5f, 15.6f)
        moveTo(13.8f, 10.8f); lineTo(13.5f, 15.6f)
    }

    /* ============================================================ загрузки */

    /** «Скачать»: стрелка входит в лоток. Лоток — это «на устройство», без него это просто вниз. */
    val Download: ImageVector by lazy {
        stroked("zizi_download") {
            moveTo(12f, 3.6f); lineTo(12f, 14.4f)
            moveTo(8.4f, 11.0f); lineTo(12f, 14.6f); lineTo(15.6f, 11.0f)
            tray()
        }
    }

    /** «Скачано»: тот же лоток, но вместо стрелки галочка. Одна семья, разные состояния. */
    val DownloadDone: ImageVector by lazy {
        stroked("zizi_download_done") {
            moveTo(7.4f, 9.6f); lineTo(10.7f, 13.0f); lineTo(16.6f, 5.2f)
            tray()
        }
    }

    /** «Скачать из сети»: облако со стрелкой внутрь. Для настроек каталога. */
    val CloudDownload: ImageVector by lazy {
        stroked("zizi_cloud_download") {
            cloud()
            moveTo(12f, 8.6f); lineTo(12f, 15.4f)
            moveTo(9.2f, 12.6f); lineTo(12f, 15.6f); lineTo(14.8f, 12.6f)
        }
    }

    private fun PathBuilder.tray() {
        moveTo(4.6f, 16.4f); lineTo(4.6f, 19.4f); lineTo(19.4f, 19.4f); lineTo(19.4f, 16.4f)
    }

    /* ============================================================ облако и сеть */

    val Cloud: ImageVector by lazy { stroked("zizi_cloud") { cloud() } }

    /** «Только из сети / связи нет»: облако, перечёркнутое по диагонали. */
    val CloudOff: ImageVector by lazy {
        stroked("zizi_cloud_off") {
            cloud()
            moveTo(3.6f, 3.6f); lineTo(20.4f, 20.4f)
        }
    }

    /** «Нашёлся в каталоге»: облако с галочкой. */
    val CloudCheck: ImageVector by lazy {
        stroked("zizi_cloud_check") {
            cloud()
            moveTo(8.8f, 12.8f); lineTo(11.2f, 15.2f); lineTo(15.4f, 10.2f)
        }
    }

    private fun PathBuilder.cloud() {
        moveTo(17.0f, 18.2f)
        curveTo(19.5f, 18.2f, 21.6f, 16.2f, 21.6f, 13.7f)
        curveTo(21.6f, 11.3f, 19.7f, 9.3f, 17.3f, 9.2f)
        curveTo(16.5f, 6.2f, 13.7f, 4.1f, 10.6f, 4.6f)
        curveTo(7.3f, 5.2f, 5.0f, 8.1f, 5.1f, 11.4f)
        curveTo(3.4f, 12.2f, 2.5f, 14.1f, 3.0f, 15.9f)
        curveTo(3.5f, 17.4f, 4.9f, 18.3f, 6.5f, 18.2f)
        lineTo(17.0f, 18.2f)
    }

    /** Wi-Fi: три дуги одного центра и точка. */
    val Wifi: ImageVector by lazy {
        stroked("zizi_wifi") {
            moveTo(2.9f, 9.5f); arcTo(12.9f, 12.9f, 0f, false, true, 21.1f, 9.5f)
            moveTo(5.9f, 12.6f); arcTo(8.6f, 8.6f, 0f, false, true, 18.1f, 12.6f)
            moveTo(8.9f, 15.7f); arcTo(4.4f, 4.4f, 0f, false, true, 15.1f, 15.7f)
            moveTo(12f, 19.2f); lineTo(12.05f, 19.2f)
        }
    }

    /** «Проверить связь»: столбики сигнала и галочка. */
    val Network: ImageVector by lazy {
        stroked("zizi_network") {
            moveTo(4.6f, 18.4f); lineTo(4.6f, 14.6f)
            moveTo(9.0f, 18.4f); lineTo(9.0f, 11.0f)
            moveTo(13.4f, 18.4f); lineTo(13.4f, 7.4f)
            moveTo(14.9f, 13.6f); lineTo(17.2f, 15.9f); lineTo(21.2f, 10.6f)
        }
    }

    /** Глобус: «язык интерфейса» и «источник в интернете». */
    val Globe: ImageVector by lazy {
        stroked("zizi_globe") {
            circle(12f, 12f, 8.4f)
            moveTo(3.6f, 12f); lineTo(20.4f, 12f)
            moveTo(12f, 3.6f)
            curveTo(8.4f, 6.6f, 8.4f, 17.4f, 12f, 20.4f)
            curveTo(15.6f, 17.4f, 15.6f, 6.6f, 12f, 3.6f)
        }
    }

    /** Сервер: два блока с индикаторами. Для «свой резолвер». */
    val Server: ImageVector by lazy {
        stroked("zizi_server") {
            moveTo(4.2f, 5.4f); lineTo(19.8f, 5.4f); lineTo(19.8f, 10.4f); lineTo(4.2f, 10.4f)
            lineTo(4.2f, 5.4f)
            moveTo(4.2f, 13.6f); lineTo(19.8f, 13.6f); lineTo(19.8f, 18.6f); lineTo(4.2f, 18.6f)
            lineTo(4.2f, 13.6f)
            moveTo(7.4f, 7.9f); lineTo(7.45f, 7.9f)
            moveTo(7.4f, 16.1f); lineTo(7.45f, 16.1f)
        }
    }

    /** Диск: «сколько занято». Цилиндр, а не абстрактная коробка. */
    val Storage: ImageVector by lazy {
        stroked("zizi_storage") {
            moveTo(4.2f, 7.0f)
            curveTo(4.2f, 5.3f, 7.7f, 4.0f, 12f, 4.0f)
            curveTo(16.3f, 4.0f, 19.8f, 5.3f, 19.8f, 7.0f)
            curveTo(19.8f, 8.7f, 16.3f, 10.0f, 12f, 10.0f)
            curveTo(7.7f, 10.0f, 4.2f, 8.7f, 4.2f, 7.0f)
            moveTo(4.2f, 7.0f); lineTo(4.2f, 17.0f)
            curveTo(4.2f, 18.7f, 7.7f, 20.0f, 12f, 20.0f)
            curveTo(16.3f, 20.0f, 19.8f, 18.7f, 19.8f, 17.0f)
            lineTo(19.8f, 7.0f)
            moveTo(4.2f, 12.0f)
            curveTo(4.2f, 13.7f, 7.7f, 15.0f, 12f, 15.0f)
            curveTo(16.3f, 15.0f, 19.8f, 13.7f, 19.8f, 12.0f)
        }
    }

    /* ============================================================ папки */

    val Folder: ImageVector by lazy { stroked("zizi_folder") { folder() } }

    /** «Открыть папку»: у открытой папки передняя стенка отведена вперёд. */
    val FolderOpen: ImageVector by lazy {
        stroked("zizi_folder_open") {
            moveTo(3.6f, 18.4f); lineTo(3.6f, 6.2f); lineTo(9.4f, 6.2f); lineTo(11.2f, 8.8f)
            lineTo(20.4f, 8.8f); lineTo(20.4f, 11.4f)
            moveTo(2.6f, 18.6f); lineTo(5.8f, 11.6f); lineTo(22.0f, 11.6f); lineTo(18.8f, 18.6f)
            lineTo(2.6f, 18.6f)
        }
    }

    /**
     * Папка с музыкой (6.27.1).
     *
     * Заменяет [FolderOpen] там, где знак означает не действие «открыть», а сущность «папка с
     * треками»: раздел «Папки» в плеере и строки списка папок. Причина — вес. У [FolderOpen]
     * передняя стенка отведена вперёд, из-за чего в глифе три длинные линии вместо одной и
     * пятно получается заметно темнее соседних знаков в том же ряду: в столбце меню и в ряду
     * чипов он выпирал как будто выделенный, хотя выделенным не был.
     *
     * Здесь корпус папки — тот же [folder], что у «добавить папку», то есть ровно тот вес, что
     * у всего набора, а смысл несёт нота внутри. Нота построена по тем же правилам, что и в
     * [Queue]: головка кругом радиуса 1.8, штиль вертикалью, флажок одной линией вверх-вправо —
     * так знак остаётся узнаваемым и в 19 dp, где отдельные детали уже не разбираются.
     */
    val FolderMusic: ImageVector by lazy {
        stroked("zizi_folder_music") {
            folder()
            circle(10.3f, 15.3f, 1.8f)
            moveTo(12.1f, 15.3f); lineTo(12.1f, 11.5f)
            lineTo(15.4f, 12.7f)
        }
    }

    /** «Добавить папку»: папка с плюсом. */
    val FolderPlus: ImageVector by lazy {
        stroked("zizi_folder_plus") {
            folder()
            moveTo(12f, 11.4f); lineTo(12f, 16.6f)
            moveTo(9.4f, 14.0f); lineTo(14.6f, 14.0f)
        }
    }

    private fun PathBuilder.folder() {
        moveTo(3.6f, 18.6f); lineTo(3.6f, 6.2f); lineTo(9.4f, 6.2f); lineTo(11.2f, 8.8f)
        lineTo(20.4f, 8.8f); lineTo(20.4f, 18.6f); lineTo(3.6f, 18.6f)
    }

    /* ============================================================ очередь и плейлисты */

    /** Очередь: строки списка и нота. */
    val Queue: ImageVector by lazy {
        stroked("zizi_queue") {
            listLines(rightEdge = 15.4f)
            circle(17.4f, 17.4f, 2.4f)
            moveTo(19.8f, 17.4f); lineTo(19.8f, 10.4f)
        }
    }

    /** «Играть следующим»: список и треугольник — действие происходит сразу после текущего. */
    val PlayNext: ImageVector by lazy {
        stroked("zizi_play_next") {
            listLines(rightEdge = 13.4f)
            moveTo(16.0f, 10.8f); lineTo(21.4f, 14.6f); lineTo(16.0f, 18.4f); lineTo(16.0f, 10.8f)
        }
    }

    /** «Добавить в очередь» и «в плейлист»: список и плюс. */
    val QueueAdd: ImageVector by lazy {
        stroked("zizi_queue_add") {
            listLines(rightEdge = 13.4f)
            moveTo(18.6f, 11.4f); lineTo(18.6f, 18.2f)
            moveTo(15.2f, 14.8f); lineTo(22.0f, 14.8f)
        }
    }

    /** «Убрать из плейлиста»: список и минус. Ровно на один штрих мягче, чем корзина. */
    val QueueRemove: ImageVector by lazy {
        stroked("zizi_queue_remove") {
            listLines(rightEdge = 13.4f)
            moveTo(15.2f, 14.8f); lineTo(22.0f, 14.8f)
        }
    }

    private fun PathBuilder.listLines(rightEdge: Float) {
        moveTo(3.4f, 6.6f); lineTo(rightEdge, 6.6f)
        moveTo(3.4f, 11.0f); lineTo(rightEdge, 11.0f)
        moveTo(3.4f, 15.4f); lineTo(rightEdge - 3.4f, 15.4f)
    }

    /* ============================================================ базовые действия */

    /** «Поделиться»: файл выходит наружу. Стрелка вверх из открытой коробки. */
    val Share: ImageVector by lazy {
        stroked("zizi_share") {
            moveTo(12f, 3.4f); lineTo(12f, 13.8f)
            moveTo(8.6f, 6.8f); lineTo(12f, 3.4f); lineTo(15.4f, 6.8f)
            moveTo(7.6f, 9.6f); lineTo(5.2f, 9.6f); lineTo(5.2f, 19.6f); lineTo(18.8f, 19.6f)
            lineTo(18.8f, 9.6f); lineTo(16.4f, 9.6f)
        }
    }

    val Close: ImageVector by lazy {
        stroked("zizi_close") {
            moveTo(5.8f, 5.8f); lineTo(18.2f, 18.2f)
            moveTo(18.2f, 5.8f); lineTo(5.8f, 18.2f)
        }
    }

    val Check: ImageVector by lazy {
        stroked("zizi_check") { moveTo(5.2f, 12.6f); lineTo(9.8f, 17.2f); lineTo(18.8f, 6.4f) }
    }

    /** «Выбрать несколько»: две галочки. */
    val CheckDouble: ImageVector by lazy {
        stroked("zizi_check_double") {
            moveTo(2.4f, 13.0f); lineTo(6.2f, 16.8f); lineTo(13.0f, 8.6f)
            moveTo(10.6f, 16.6f); lineTo(11.4f, 17.4f); lineTo(21.6f, 6.4f)
        }
    }

    val Plus: ImageVector by lazy {
        stroked("zizi_plus") {
            moveTo(12f, 4.8f); lineTo(12f, 19.2f)
            moveTo(4.8f, 12f); lineTo(19.2f, 12f)
        }
    }

    /**
     * «Пересканировать»: дуга 270° с наконечником — круг, у которого есть начало.
     *
     * Точки посчитаны, а не подобраны: дуга радиуса 7.4 вокруг (12, 12) от θ = 45° по часовой
     * до θ = 315°, разрыв ровно справа. Наконечник стоит по касательной к концу дуги (барбы под
     * ±30° к направлению движения), поэтому стрелка «продолжает» линию, а не приклеена углом —
     * в первой версии 6.24.1 здесь был именно такой угол, и знак читался как сломанный.
     */
    val Refresh: ImageVector by lazy {
        stroked("zizi_refresh") {
            moveTo(17.23f, 17.23f)
            arcTo(7.4f, 7.4f, 0f, true, true, 17.23f, 6.77f)
            moveTo(16.4f, 3.68f); lineTo(17.23f, 6.77f); lineTo(14.14f, 5.94f)
        }
    }

    val Info: ImageVector by lazy {
        stroked("zizi_info") {
            circle(12f, 12f, 8.4f)
            moveTo(12f, 11.0f); lineTo(12f, 16.4f)
            moveTo(12f, 7.6f); lineTo(12.05f, 7.6f)
        }
    }

    val Person: ImageVector by lazy {
        stroked("zizi_person") {
            circle(12f, 8.2f, 3.6f)
            moveTo(5.2f, 19.6f)
            curveTo(5.2f, 15.6f, 8.3f, 13.6f, 12f, 13.6f)
            curveTo(15.7f, 13.6f, 18.8f, 15.6f, 18.8f, 19.6f)
        }
    }

    val Search: ImageVector by lazy {
        stroked("zizi_search") {
            circle(10.6f, 10.6f, 6.4f)
            moveTo(15.4f, 15.4f); lineTo(20.4f, 20.4f)
        }
    }

    /** «Не нашлось»: та же лупа, перечёркнутая. */
    val SearchOff: ImageVector by lazy {
        stroked("zizi_search_off") {
            circle(10.6f, 10.6f, 6.4f)
            moveTo(15.4f, 15.4f); lineTo(20.4f, 20.4f)
            moveTo(7.4f, 13.8f); lineTo(13.8f, 7.4f)
        }
    }

    val More: ImageVector by lazy {
        stroked("zizi_more") {
            moveTo(12f, 5.4f); lineTo(12.05f, 5.4f)
            moveTo(12f, 12f); lineTo(12.05f, 12f)
            moveTo(12f, 18.6f); lineTo(12.05f, 18.6f)
        }
    }

    val ChevronRight: ImageVector by lazy {
        stroked("zizi_chevron_right") { moveTo(9.4f, 5.4f); lineTo(16.0f, 12f); lineTo(9.4f, 18.6f) }
    }

    val ChevronUp: ImageVector by lazy {
        stroked("zizi_chevron_up") { moveTo(5.4f, 14.6f); lineTo(12f, 8.0f); lineTo(18.6f, 14.6f) }
    }

    val ChevronDown: ImageVector by lazy {
        stroked("zizi_chevron_down") { moveTo(5.4f, 9.4f); lineTo(12f, 16.0f); lineTo(18.6f, 9.4f) }
    }

    val Copy: ImageVector by lazy {
        stroked("zizi_copy") {
            moveTo(8.6f, 8.6f); lineTo(19.4f, 8.6f); lineTo(19.4f, 19.4f); lineTo(8.6f, 19.4f)
            lineTo(8.6f, 8.6f)
            moveTo(5.8f, 15.4f); lineTo(4.6f, 15.4f); lineTo(4.6f, 4.6f); lineTo(15.4f, 4.6f)
            lineTo(15.4f, 5.8f)
        }
    }

    val Paste: ImageVector by lazy {
        stroked("zizi_paste") {
            moveTo(8.6f, 5.6f); lineTo(4.8f, 5.6f); lineTo(4.8f, 20.0f); lineTo(19.2f, 20.0f)
            lineTo(19.2f, 5.6f); lineTo(15.4f, 5.6f)
            moveTo(8.8f, 3.6f); lineTo(15.2f, 3.6f); lineTo(15.2f, 7.4f); lineTo(8.8f, 7.4f)
            lineTo(8.8f, 3.6f)
        }
    }

    /** «Ищем…»: песочные часы. */
    val Hourglass: ImageVector by lazy {
        stroked("zizi_hourglass") {
            moveTo(6.8f, 3.8f); lineTo(17.2f, 3.8f); lineTo(17.2f, 7.2f); lineTo(12f, 12f)
            lineTo(17.2f, 16.8f); lineTo(17.2f, 20.2f); lineTo(6.8f, 20.2f); lineTo(6.8f, 16.8f)
            lineTo(12f, 12f); lineTo(6.8f, 7.2f); lineTo(6.8f, 3.8f)
        }
    }

    /** «Уже на устройстве»: телефон. */
    val Phone: ImageVector by lazy {
        stroked("zizi_phone") {
            moveTo(6.8f, 3.6f); lineTo(17.2f, 3.6f); lineTo(17.2f, 20.4f); lineTo(6.8f, 20.4f)
            lineTo(6.8f, 3.6f)
            moveTo(10.4f, 18.0f); lineTo(13.6f, 18.0f)
        }
    }

    /** История: часы. Стрелка «назад» в 20 dp превращается в кашу, циферблат — нет. */
    val Clock: ImageVector by lazy {
        stroked("zizi_clock") {
            circle(12f, 12f, 8.2f)
            moveTo(12f, 7.2f); lineTo(12f, 12.4f); lineTo(15.8f, 14.6f)
        }
    }

    /** Таймер сна: месяц. Через полумесяц «выключится само» понятно без подписи. */
    val Moon: ImageVector by lazy {
        stroked("zizi_moon") {
            moveTo(20.4f, 14.6f)
            curveTo(19.2f, 18.4f, 15.4f, 21.0f, 11.4f, 20.4f)
            curveTo(6.9f, 19.7f, 3.6f, 15.7f, 4.1f, 11.2f)
            curveTo(4.5f, 7.3f, 7.2f, 4.2f, 10.9f, 3.4f)
            curveTo(8.8f, 6.6f, 8.8f, 10.8f, 11.2f, 13.4f)
            curveTo(13.6f, 16.0f, 17.2f, 16.4f, 20.4f, 14.6f)
        }
    }

    /** Скорость: спидометр со стрелкой вправо-вверх. */
    val Speed: ImageVector by lazy {
        stroked("zizi_speed") {
            moveTo(4.0f, 16.4f); arcTo(8.2f, 8.2f, 0f, false, true, 20.0f, 16.4f)
            // Стрелка кончается ВНУТРИ шкалы: доведённая до дуги, она сливалась с ней в углу.
            moveTo(12f, 16.4f); lineTo(15.8f, 11.6f)
            moveTo(12f, 16.4f); lineTo(12.05f, 16.4f)
        }
    }

    /** Эквалайзер: четыре столбика разной высоты. */
    val Equalizer: ImageVector by lazy {
        stroked("zizi_equalizer") {
            moveTo(5.6f, 9.4f); lineTo(5.6f, 14.6f)
            moveTo(9.9f, 5.6f); lineTo(9.9f, 18.4f)
            moveTo(14.1f, 8.2f); lineTo(14.1f, 15.8f)
            moveTo(18.4f, 10.8f); lineTo(18.4f, 13.2f)
        }
    }

    /** Сортировка: строки по убыванию и стрелка направления. */
    val Sort: ImageVector by lazy {
        stroked("zizi_sort") {
            moveTo(4.2f, 7.0f); lineTo(13.4f, 7.0f)
            moveTo(4.2f, 12.0f); lineTo(10.6f, 12.0f)
            moveTo(4.2f, 17.0f); lineTo(7.8f, 17.0f)
            moveTo(17.6f, 6.4f); lineTo(17.6f, 17.6f)
            moveTo(14.6f, 14.4f); lineTo(17.6f, 17.8f); lineTo(20.6f, 14.4f)
        }
    }

    /* ============================================================ видимость и доступ */

    val Eye: ImageVector by lazy { stroked("zizi_eye") { eye(); circle(12f, 12f, 3.0f) } }

    val EyeOff: ImageVector by lazy {
        stroked("zizi_eye_off") {
            eye()
            circle(12f, 12f, 3.0f)
            moveTo(3.6f, 20.4f); lineTo(20.4f, 3.6f)
        }
    }

    private fun PathBuilder.eye() {
        moveTo(2.4f, 12f)
        curveTo(5.2f, 7.2f, 8.4f, 4.9f, 12f, 4.9f)
        curveTo(15.6f, 4.9f, 18.8f, 7.2f, 21.6f, 12f)
        curveTo(18.8f, 16.8f, 15.6f, 19.1f, 12f, 19.1f)
        curveTo(8.4f, 19.1f, 5.2f, 16.8f, 2.4f, 12f)
    }

    val Key: ImageVector by lazy {
        stroked("zizi_key") {
            circle(7.6f, 12f, 3.6f)
            moveTo(11.2f, 12f); lineTo(20.6f, 12f)
            moveTo(17.2f, 12f); lineTo(17.2f, 15.6f)
            moveTo(20.2f, 12f); lineTo(20.2f, 14.8f)
        }
    }

    /** «Служебный доступ»: замок с откинутой дугой — открыт, но всё ещё замок. */
    val LockOpen: ImageVector by lazy {
        stroked("zizi_lock_open") {
            moveTo(5.6f, 11.4f); lineTo(18.4f, 11.4f); lineTo(18.4f, 19.6f); lineTo(5.6f, 19.6f)
            lineTo(5.6f, 11.4f)
            moveTo(9.2f, 11.4f); lineTo(9.2f, 8.2f)
            curveTo(9.2f, 5.9f, 11.1f, 4.2f, 13.4f, 4.4f)
            curveTo(15.4f, 4.6f, 16.8f, 6.2f, 16.8f, 8.2f)
        }
    }

    /**
     * Отчёт о сбое: жук. Единственный знак набора, который можно назвать смешным.
     *
     * Тело — капсула, а не круг: круг с шестью лучами (так было в первой версии 6.24.1)
     * читается как солнце, а не как насекомое. Панцирь вытянут по вертикали, спинка отделена
     * линией, лап по две на сторону — этого достаточно, чтобы знак узнавался в 20 dp.
     */
    val Bug: ImageVector by lazy {
        stroked("zizi_bug") {
            moveTo(7.4f, 12.6f)
            arcTo(4.6f, 4.6f, 0f, false, true, 16.6f, 12.6f)
            lineTo(16.6f, 15.2f)
            curveTo(16.6f, 18.4f, 14.5f, 20.4f, 12f, 20.4f)
            curveTo(9.5f, 20.4f, 7.4f, 18.4f, 7.4f, 15.2f)
            lineTo(7.4f, 12.6f)
            moveTo(7.6f, 13.1f); lineTo(16.4f, 13.1f)
            moveTo(9.5f, 8.7f); lineTo(7.9f, 5.9f)
            moveTo(14.5f, 8.7f); lineTo(16.1f, 5.9f)
            moveTo(7.4f, 13.9f); lineTo(4.0f, 12.2f)
            moveTo(7.4f, 17.3f); lineTo(4.0f, 18.8f)
            moveTo(16.6f, 13.9f); lineTo(20.0f, 12.2f)
            moveTo(16.6f, 17.3f); lineTo(20.0f, 18.8f)
        }
    }

    /** Тема оформления: палитра. */
    val Palette: ImageVector by lazy {
        stroked("zizi_palette") {
            moveTo(12f, 20.4f)
            curveTo(7.4f, 20.4f, 3.6f, 16.6f, 3.6f, 12.0f)
            curveTo(3.6f, 7.4f, 7.4f, 3.6f, 12f, 3.6f)
            curveTo(16.6f, 3.6f, 20.4f, 6.9f, 20.4f, 10.9f)
            curveTo(20.4f, 13.4f, 18.4f, 14.9f, 16.0f, 14.9f)
            lineTo(14.7f, 14.9f)
            curveTo(13.3f, 14.9f, 12.5f, 16.1f, 12.9f, 17.3f)
            curveTo(13.3f, 18.7f, 12.9f, 20.4f, 12f, 20.4f)
            moveTo(8.4f, 9.4f); lineTo(8.45f, 9.4f)
            moveTo(12f, 7.6f); lineTo(12.05f, 7.6f)
            moveTo(15.6f, 9.8f); lineTo(15.65f, 9.8f)
        }
    }

    /* ============================================================ избранное */

    val Heart: ImageVector by lazy { stroked("zizi_heart") { heart() } }

    /** Заполненное сердце: то же самое, залитое. Форма не меняется при нажатии — меняется вес. */
    val HeartFilled: ImageVector by lazy { solid("zizi_heart_filled") { heart() } }

    private fun PathBuilder.heart() {
        moveTo(12f, 19.8f)
        curveTo(12f, 19.8f, 3.2f, 14.6f, 3.2f, 9.2f)
        curveTo(3.2f, 6.2f, 5.6f, 4.2f, 8.2f, 4.2f)
        curveTo(10.0f, 4.2f, 11.3f, 5.2f, 12f, 6.4f)
        curveTo(12.7f, 5.2f, 14.0f, 4.2f, 15.8f, 4.2f)
        curveTo(18.4f, 4.2f, 20.8f, 6.2f, 20.8f, 9.2f)
        curveTo(20.8f, 14.6f, 12f, 19.8f, 12f, 19.8f)
    }

    /* ============================================================ команды */

    /** «Остановить»: сплошной квадрат. Команда обязана быть тяжелее описания. */
    val Stop: ImageVector by lazy {
        solid("zizi_stop") {
            moveTo(7.4f, 7.4f); lineTo(16.6f, 7.4f); lineTo(16.6f, 16.6f); lineTo(7.4f, 16.6f)
            lineTo(7.4f, 7.4f)
        }
    }

    /** «Играть»: сплошной треугольник с чуть скруглёнными углами (StrokeJoin.Round). */
    val Play: ImageVector by lazy {
        solid("zizi_play") {
            moveTo(8.0f, 5.6f); lineTo(19.2f, 12f); lineTo(8.0f, 18.4f); lineTo(8.0f, 5.6f)
        }
    }

    /* ============================================================ транспорт крупный (6.25.0) */

    /**
     * Play плеера. Отдельно от [Play] (тот стоит в списках при 16–20 dp): здесь вершина уведена
     * до 19.6, а центр массы посчитан под круглую кнопку — см. заметку в шапке файла.
     */
    val PlayFilled: ImageVector by lazy {
        solid("zizi_play_filled") {
            moveTo(7.6f, 4.9f); lineTo(19.6f, 12.0f); lineTo(7.6f, 19.1f); lineTo(7.6f, 4.9f)
        }
    }

    /**
     * Пауза: две вертикали ширины 3.6 с круглыми торцами. Просвет 2.2 — уже, чем у Material
     * (там 4.0 при той же ширине штриха), потому что в 56 dp широкий просвет распадается на два
     * отдельных знака, а пауза должна читаться как один.
     */
    val Pause: ImageVector by lazy {
        heavy("zizi_pause", 3.6f) {
            moveTo(9.3f, 6.4f); lineTo(9.3f, 17.6f)
            moveTo(14.7f, 6.4f); lineTo(14.7f, 17.6f)
        }
    }

    /** «Вперёд»: треугольник и вертикаль. Оба элемента — один знак, зазор 2.0. */
    val SkipNext: ImageVector by lazy {
        solid("zizi_skip_next") {
            moveTo(6.4f, 5.8f); lineTo(15.0f, 12.0f); lineTo(6.4f, 18.2f); lineTo(6.4f, 5.8f)
            moveTo(17.0f, 5.8f); lineTo(19.4f, 5.8f); lineTo(19.4f, 18.2f); lineTo(17.0f, 18.2f)
            lineTo(17.0f, 5.8f)
        }
    }

    /** «Назад»: зеркальный [SkipNext]. Зеркалим руками, а не RTL-флагом: знак не про текст. */
    val SkipPrevious: ImageVector by lazy {
        solid("zizi_skip_previous") {
            moveTo(17.6f, 5.8f); lineTo(9.0f, 12.0f); lineTo(17.6f, 18.2f); lineTo(17.6f, 5.8f)
            moveTo(7.0f, 5.8f); lineTo(4.6f, 5.8f); lineTo(4.6f, 18.2f); lineTo(7.0f, 18.2f)
            lineTo(7.0f, 5.8f)
        }
    }

    /** «Назад» в заголовке раздела: стрелка влево. */
    val ArrowBack: ImageVector by lazy {
        stroked("zizi_arrow_back") {
            moveTo(19.8f, 12.0f); lineTo(4.9f, 12.0f)
            moveTo(11.4f, 5.0f); lineTo(4.4f, 12.0f); lineTo(11.4f, 19.0f)
        }
    }

    /** Спектр: пять полос. Высоты неравные и несимметричные — симметричный спектр выглядит мёртвым. */
    val Spectrum: ImageVector by lazy {
        stroked("zizi_spectrum") {
            moveTo(4.3f, 14.6f); lineTo(4.3f, 9.4f)
            moveTo(8.1f, 18.4f); lineTo(8.1f, 5.6f)
            moveTo(12.0f, 15.8f); lineTo(12.0f, 8.2f)
            moveTo(15.9f, 19.4f); lineTo(15.9f, 4.6f)
            moveTo(19.7f, 13.4f); lineTo(19.7f, 10.6f)
        }
    }

    /** «Недавнее»: часы. Стрелки на 12 и на 4 — положение читается при 17 dp, в отличие от 12:10. */
    val History: ImageVector by lazy {
        stroked("zizi_history") {
            circle(12f, 12f, 8.1f)
            moveTo(12.0f, 7.2f); lineTo(12.0f, 12.3f); lineTo(15.7f, 14.4f)
        }
    }

    /* ============================================================ выбор и правка */

    /** Отмеченный пункт: рамка и галочка внутри. Пустая рамка — [CheckBoxEmpty]. */
    val CheckBox: ImageVector by lazy {
        stroked("zizi_checkbox") {
            box()
            moveTo(7.8f, 12.2f); lineTo(10.6f, 15.0f); lineTo(16.4f, 8.6f)
        }
    }

    val CheckBoxEmpty: ImageVector by lazy { stroked("zizi_checkbox_empty") { box() } }

    /** «Выбрать все»: рамка с пунктирной левой стороной и галочкой — множественный выбор. */
    val SelectAll: ImageVector by lazy {
        stroked("zizi_select_all") {
            moveTo(4.4f, 8.0f); lineTo(4.4f, 16.0f)
            moveTo(8.0f, 19.6f); lineTo(16.0f, 19.6f)
            moveTo(8.0f, 4.4f); lineTo(16.0f, 4.4f)
            moveTo(19.6f, 8.0f); lineTo(19.6f, 16.0f)
            moveTo(8.4f, 12.2f); lineTo(11.2f, 15.0f); lineTo(16.0f, 9.2f)
        }
    }

    private fun PathBuilder.box() {
        moveTo(4.4f, 4.4f); lineTo(19.6f, 4.4f); lineTo(19.6f, 19.6f); lineTo(4.4f, 19.6f)
        lineTo(4.4f, 4.4f)
    }

    /** «Переименовать»: карандаш под 45°, с отделённым кончиком. */
    val Edit: ImageVector by lazy {
        stroked("zizi_edit") {
            moveTo(16.4f, 3.9f); lineTo(20.1f, 7.6f); lineTo(8.6f, 19.1f); lineTo(3.9f, 20.1f)
            lineTo(4.9f, 15.4f); lineTo(16.4f, 3.9f)
            moveTo(13.9f, 6.4f); lineTo(17.6f, 10.1f)
        }
    }

    /** Ссылка: два звена цепи. */
    val Link: ImageVector by lazy {
        stroked("zizi_link") {
            moveTo(10.4f, 13.6f); lineTo(13.6f, 10.4f)
            moveTo(11.0f, 7.6f); lineTo(13.4f, 5.2f)
            curveTo(15.2f, 3.4f, 18.0f, 3.4f, 19.8f, 5.2f)
            curveTo(21.6f, 7.0f, 21.6f, 9.8f, 19.8f, 11.6f)
            lineTo(17.4f, 14.0f)
            moveTo(13.0f, 16.4f); lineTo(10.6f, 18.8f)
            curveTo(8.8f, 20.6f, 6.0f, 20.6f, 4.2f, 18.8f)
            curveTo(2.4f, 17.0f, 2.4f, 14.2f, 4.2f, 12.4f)
            lineTo(6.6f, 10.0f)
        }
    }

    /** «Настройки списка»: два ползунка. */
    val Tune: ImageVector by lazy {
        stroked("zizi_tune") {
            moveTo(3.6f, 8.6f); lineTo(20.4f, 8.6f)
            moveTo(3.6f, 15.4f); lineTo(20.4f, 15.4f)
            circle(9.0f, 8.6f, 2.4f)
            circle(15.4f, 15.4f, 2.4f)
        }
    }

    /** Медиатека: нота и полки. Знак вкладки «Библиотека». */
    /* ============================================================ медиатека (6.29.0) */

    /**
     * «Сеткой»: четыре плитки 2x2. Просвет между плитками 2.4 единицы — при 20 dp это 2 px, то
     * есть знак не сливается в один квадрат даже на mdpi, и при этом не рассыпается на четыре
     * точки. Углы скруглены самой обводкой (StrokeJoin.Round), отдельных дуг не нужно.
     */
    val ViewGrid: ImageVector by lazy {
        stroked("zizi_view_grid") {
            moveTo(4.4f, 4.4f); lineTo(10.8f, 4.4f); lineTo(10.8f, 10.8f); lineTo(4.4f, 10.8f); close()
            moveTo(13.2f, 4.4f); lineTo(19.6f, 4.4f); lineTo(19.6f, 10.8f); lineTo(13.2f, 10.8f); close()
            moveTo(4.4f, 13.2f); lineTo(10.8f, 13.2f); lineTo(10.8f, 19.6f); lineTo(4.4f, 19.6f); close()
            moveTo(13.2f, 13.2f); lineTo(19.6f, 13.2f); lineTo(19.6f, 19.6f); lineTo(13.2f, 19.6f); close()
        }
    }

    /**
     * «Списком»: три строки, у каждой квадрат обложки и подпись. Именно так это нарисовано в
     * референсе, и это важнее абстрактных трёх линий: знак показывает, ЧТО получится, а не
     * «список вообще».
     */
    val ViewList: ImageVector by lazy {
        stroked("zizi_view_list") {
            moveTo(3.8f, 5.0f); lineTo(7.4f, 5.0f); lineTo(7.4f, 8.6f); lineTo(3.8f, 8.6f); close()
            moveTo(10.4f, 6.8f); lineTo(20.2f, 6.8f)
            moveTo(3.8f, 10.2f); lineTo(7.4f, 10.2f); lineTo(7.4f, 13.8f); lineTo(3.8f, 13.8f); close()
            moveTo(10.4f, 12.0f); lineTo(20.2f, 12.0f)
            moveTo(3.8f, 15.4f); lineTo(7.4f, 15.4f); lineTo(7.4f, 19.0f); lineTo(3.8f, 19.0f); close()
            moveTo(10.4f, 17.2f); lineTo(20.2f, 17.2f)
        }
    }

    /**
     * «Порядок»: стрелка вниз и стрелка вверх рядом — тот самый знак, что стоит слева от подписи
     * сортировки в референсе. От [Sort] отличается смыслом: [Sort] это «отсортировать»,
     * ZiziIcons.SortSwap — «сейчас порядок такой, нажми, чтобы сменить».
     */
    val SortSwap: ImageVector by lazy {
        stroked("zizi_sort_swap") {
            moveTo(7.6f, 4.6f); lineTo(7.6f, 19.4f)
            moveTo(4.2f, 16.0f); lineTo(7.6f, 19.6f); lineTo(11.0f, 16.0f)
            moveTo(16.4f, 19.4f); lineTo(16.4f, 4.6f)
            moveTo(13.0f, 8.0f); lineTo(16.4f, 4.4f); lineTo(19.8f, 8.0f)
        }
    }

    /**
     * Канцелярская кнопка: шляпка, две ножки, основание, игла. Не «маркер на карте» (круг со
     * шпилем) — маркер читается как «место», а нужно «закреплено сверху».
     */
    val Pin: ImageVector by lazy {
        stroked("zizi_pin") {
            moveTo(8.4f, 4.2f); lineTo(15.6f, 4.2f)
            moveTo(10.4f, 4.2f); lineTo(9.6f, 12.6f)
            moveTo(13.6f, 4.2f); lineTo(14.4f, 12.6f)
            moveTo(7.6f, 12.6f); lineTo(16.4f, 12.6f)
            moveTo(12.0f, 12.6f); lineTo(12.0f, 20.4f)
        }
    }

    val Library: ImageVector by lazy {
        stroked("zizi_library") {
            moveTo(3.6f, 5.4f); lineTo(3.6f, 18.6f)
            moveTo(7.4f, 5.4f); lineTo(7.4f, 18.6f)
            circle(13.6f, 16.4f, 2.6f)
            moveTo(16.2f, 16.4f); lineTo(16.2f, 6.4f); lineTo(20.4f, 7.8f)
        }
    }

    /**
     * Окружность двумя полудугами.
     *
     * Одной `arcTo` полный круг нарисовать нельзя: начальная и конечная точки совпадают, и
     * дуга вырождается в ничто. Две дуги по 180° — единственный способ, который не зависит от
     * реализации парсера пути.
     */
    private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        moveTo(cx - r, cy)
        arcTo(r, r, 0f, false, true, cx + r, cy)
        arcTo(r, r, 0f, false, true, cx - r, cy)
    }
}
