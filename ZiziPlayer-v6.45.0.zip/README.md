# ZiziPlayer — Android 6.45.0

Нативный Android-плеер на Kotlin, Jetpack Compose и Media3. Локальные файлы/SAF, сетевой каталог и офлайн-загрузки, очередь, избранное, плейлисты, Room/DataStore и индивидуальный DSP.

**Эта поставка — исходники-кандидат 6.45.0, versionCode 93, не готовый проверенный APK.** Добавлены автоматический поиск текста текущего трека, animated inline lyrics, экран с закреплённым транспортом, enhanced-LRC слова, сохранение сдвига и ограниченные сетевые повторы. Распознавание вокала и универсальное выравнивание произвольного ремикса не реализованы.

Полный отчёт: `RELEASE_v6.45.0.md`. Приёмка: `DEVICE_CHECKLIST_v6.45.0.md`. Манифест: `RELEASE_MANIFEST_v6.45.0.json`. Проверки: `verification/v6.45.0/`. Документы более ранних версий оставлены как история, их результаты не являются проверкой текущей версии.

## Обновление репозитория

Загрузить `ZiziPlayer-v6.45.0.zip` целиком в корень Eren2932/ZiziPlayer. Старый 6.44.0 (92) можно оставить; workflow выбирает новый единственный максимальный код 93. Не распаковывать ZIP поверх корня, не менять desktop `current.json`, workflow и секреты подписи. Нужен новый успешный Actions для нового коммита; повтор старого запуска не проверит новую версию.

## Проверки и сборка

В the Computer завершились 47 проверочных команд, все успешно. Production Java-парсер тестировался исполнением; Kotlin/Compose — только статическими проверками. Полная Gradle-сборка и тестирование на Android не выполнялись.

````bash
python tools/check_selftest.py
python tools/check_kotlin_syntax.py app/src
python tools/check_imports.py app/src/main
python tools/check_static_refs.py app/src/main
python tools/check_call_args.py app/src/main
# Только в подготовленном Android / Gradle окружении:
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug --stacktrace
````

Требования проекта: Android SDK 36, Gradle 8.11.1, JDK 17. В архиве, как и в базе, нет готового wrapper JAR / gradlew: CI подготавливает Gradle отдельно. Зависимости и подпись не изменены.
