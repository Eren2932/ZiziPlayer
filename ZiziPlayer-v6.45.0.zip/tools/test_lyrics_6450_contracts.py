#!/usr/bin/env python3
"""Source regression contracts. These are NOT Kotlin/Compose runtime tests."""
from pathlib import Path
import unittest
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
def read(path): return (S / path).read_text()
class Lyrics645Contracts(unittest.TestCase):
    def test_automatic_owner_survives_screen(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('combine(currentTrack, repo.settings.map { it.autoLyrics }', vm)
        self.assertIn('}.collectLatest { (track, automatic)', vm)
        self.assertIn('owner.observe(lyrics, automatic, viewModelScope)', vm)
        state = read('ui/screens/LyricsUiState.kt')
        self.assertIn('requests.collectLatest', state)
        self.assertIn('throw e', state)
        self.assertIn('repository.cached(current)', state)
        self.assertIn('delay(200)', state)
        self.assertNotIn('LaunchedEffect', state)
        self.assertIn('repeat(3)', state)
        self.assertIn('repository.retryDelay(e)', state)
        self.assertIn('attempt == 2 || wait == null', state)
    def test_privacy_toggle_is_persistent_and_disclosed(self):
        settings = read('data/SettingsStore.kt')
        for t in ['val autoLyrics: Boolean = true', 'p[autoLyrics] ?: true', 'suspend fun setAutoLyrics']:
            self.assertIn(t, settings)
        sheets = read('ui/screens/Sheets.kt')
        self.assertIn('Аудио не отправляется', sheets)
        self.assertIn('checked = state.settings.autoLyrics', sheets)
        self.assertIn('onChange = vm::setAutoLyrics', sheets)
    def test_provider_search_is_bounded_and_version_safe(self):
        s = read('lyrics/LyricsRepository.kt')
        for t in ['/api/get', '/api/search', 'minOf(result.length(), 100)', 'identityMatches', 'durationMatches',
                  'providerBackoffUntil', 'e.status == 429', 'size > 128', 'size > 24', '.drop(48)', 'e is NoLyrics',
                  'continuation.invokeOnCancellation { call.cancel() }', 'throw e', 'force: Boolean = false']:
            self.assertIn(t, s)
        for t in ['Authorization', 'SessionHeadersInterceptor', 'ZiziResolve', 'track.uri', 'audioBytes', 'removeSuffix("Slowed")']:
            self.assertNotIn(t, s)
    def test_inline_empty_and_instrumental_visibility(self):
        screen = read('ui/screens/PlayerScreen.kt')
        self.assertIn('document?.hasText == true', screen)
        self.assertIn('shownTrack?.id == currentTrack?.id', screen)
        self.assertIn('if (hasLyrics && currentTrack != null) LyricsPreview', screen)
        self.assertIn('InlineLyrics(', screen)
        self.assertIn('maxHeight - lyricBudget', screen)
        self.assertIn('.heightIn(max = coverLimit)', screen)
        self.assertIn('minOf(maxWidth, maxHeight / COVER_PLAYING)', screen)
        preview = read('ui/screens/LyricsPreview.kt')
        self.assertIn('AnimatedContent(targetState = cue', preview)
        self.assertIn('slideInVertically', preview)
        self.assertNotIn('Найти текст', preview)
        self.assertIn('!instrumental &&', read('lyrics/LyricsRepository.kt'))
    def test_fixed_transport_and_nested_scroll_containment(self):
        s = read('ui/screens/LyricsScreen.kt')
        for t in ['BackHandler', '.safeDrawingPadding()', '.nestedScroll(containScroll)', 'Modifier.weight(1f)',
                  'if (tools)', 'maxHeight < 440.dp', 'PlayerProgress(vm)', 'ZiziIcons.SkipNext', 'ZiziIcons.SkipPrevious']:
            self.assertIn(t, s)
        self.assertNotIn('Dialog(', s)
        self.assertIn('onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset = available', s)
    def test_follow_animation_and_word_spans(self):
        s = read('ui/screens/LyricsScreen.kt')
        for t in ['animateScrollBy', 'animateFloatAsState', 'animateColorAsState', 'DragInteraction.Start',
                  'follow = false', 'abs(active - previousActive) > 4', 'viewportStartOffset + anchorPx',
                  'vm.seekTo(LrcTimeline.seekPosition(line, advanceMs), track.id)']:
            self.assertIn(t, s)
        self.assertIn('LrcTimeline.activeWord', read('ui/screens/LyricsCursor.kt'))
        self.assertIn('word.start, word.end', read('ui/screens/LyricText.kt'))
    def test_clock_is_one_lifecycle_gated_controller(self):
        s = read('playback/PlayerController.kt')
        self.assertIn('if (lyricsClockUsers > 0) 33L else TICK_MS', s)
        self.assertIn('uiActive &&', s)
        self.assertIn('if (!released)', s)
        self.assertIn('onDispose { release?.invoke() }', read('ui/screens/PlayerScreen.kt'))
        cursor = read('ui/screens/LyricsCursor.kt')
        self.assertIn('progress.trackId == track.id', cursor)
        self.assertNotIn('speed', cursor)
        self.assertNotIn('delay(', cursor)
    def test_import_and_offset_remain_available_without_auto_card(self):
        s = read('ui/screens/Sheets.kt')
        self.assertIn('Текст / импорт LRC', s)
        self.assertIn('onLyrics: (() -> Unit)? = null', s)
        owner = read('ui/screens/LyricsUiState.kt')
        self.assertIn('previous?.join()', owner)
        self.assertIn('repository.saveAdvance(current, value)', owner)
        self.assertIn('repository.importLrc(current, request.uri)', owner)
    def test_wired_into_existing_ci(self):
        s = (R/'tools/check_selftest.py').read_text()
        for t in ['test_lyrics_6450.py', 'test_lyrics_6450_contracts.py', 'test_lyrics_file_api.py']:
            self.assertIn(t, s)
        self.assertIn('Lyrics645Checks.run()', (R/'app/src/test/java/app/ziziplayer/lyrics/Lyrics645Test.kt').read_text())
if __name__ == '__main__': unittest.main(verbosity=2)
