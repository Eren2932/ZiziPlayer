#!/usr/bin/env python3
"""6.41.4 source contracts only: these do NOT compile Kotlin or measure Android rendering."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(path): return (SRC/path).read_text()

class Mobile6414Contracts(unittest.TestCase):
    def test_identity(self):
        s = (ROOT/'app/build.gradle.kts').read_text()
        for expected in ['versionCode = 93', 'versionName = "6.45.0"', 'applicationId = "app.ziziplayer"']:
            self.assertIn(expected, s)

    def test_single_smooth_scrim(self):
        s = read('ui/components/TopChrome.kt').split('fun Modifier.bottomChrome()')[1]
        self.assertIn('CollectionGeometry.scrimAlpha(t)', s)
        self.assertIn('Brush.verticalGradient', s)
        self.assertEqual(s.count('drawRect('), 1)
        self.assertIn('onDrawBehind', s)
        self.assertNotIn('graphicsLayer', s)

    def test_search_header_geometry_is_fixed(self):
        s = read('ui/screens/LibraryScreen.kt').split('private fun LibraryHeader(')[1].split('private fun TrackList(')[0]
        self.assertIn('targetState = state.searchOpen', s)
        self.assertIn('LIBRARY_SEARCH_MS = 180', s)
        self.assertIn('.height(HEADER_HEIGHT)', s)
        self.assertNotIn('animateContentSize', s)
        self.assertNotIn('LazyColumn', s)

    def test_empty_search_keeps_content_mounted(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertNotIn('searchInvite', s)
        self.assertNotIn('SearchInvite(', s)
        self.assertIn('surfaceBar = {\n                        LibrarySurfaceBar(', s)
        self.assertEqual(s.count('item(key = "surface:sort", contentType = "sort") { surfaceBar() }'), 2)
        self.assertIn('Поиск по плейлистам', s)
        self.assertIn('Поиск по исполнителям', s)

    def test_outgoing_editor_cannot_publish_or_steal_focus(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('LaunchedEffect(text, state.searchOpen)', s)
        self.assertIn('if (!state.searchOpen) return@LaunchedEffect', s)
        self.assertIn('enabled = state.searchOpen', s)
        self.assertIn('remember(state.searchOpen)', s)
        self.assertIn('Modifier.clearAndSetSemantics { }', s)
        self.assertIn('if (interactive) onSearch()', s)
        vm = read('ui/MainViewModel.kt')
        self.assertIn('if (it.searchOpen) it.copy(query = query) else it', vm)
        self.assertIn('content.copy(searchOpen = sel.searchOpen, query = sel.query)', vm)

    def test_focus_waits_for_header_and_attachment(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('delay(LIBRARY_SEARCH_MS.toLong())\n            withFrameNanos { }\n            requester.requestFocus()', s)
        self.assertIn('focus.clearFocus()\n            keyboard?.hide()', s)

    def test_open_state_is_excluded_from_expensive_pipeline(self):
        s = read('ui/MainViewModel.kt')
        self.assertIn('selection.map { it.copy(searchOpen = false) }.distinctUntilChanged()', s)
        self.assertIn('private val libraryContent = combine(sources, libraryContext)', s)
        self.assertIn('}.flowOn(Dispatchers.Default)', s)

    def test_shared_clock_not_per_widget_timers(self):
        s = read('ui/components/PlaybackIndicatorMotion.kt')
        self.assertEqual(s.count('rememberInfiniteTransition(label'), 1)
        self.assertIn('if (playing && started)', s)
        self.assertIn('Lifecycle.State.STARTED', s)
        self.assertIn('lifecycle.removeObserver(observer)', s)
        self.assertNotIn('while (', s)
        self.assertNotIn('phase.value', s)
        c = read('ui/components/Common.kt')
        self.assertEqual(c.count('val phase = LocalPlaybackIndicatorPhase.current'), 2)
        self.assertNotIn('LocalAudioSpectrum', c)
        self.assertNotIn('rememberInfiniteTransition', c)

    def test_real_spectrum_only_inside_eq_surface(self):
        s = read('MainActivity.kt')
        self.assertEqual(s.count('ProvideAudioSpectrum(playing'), 1)
        self.assertIn('ProvidePlaybackIndicatorMotion(playing = playback.isPlaying)', s)
        eq = s.index('if (eqOpen) {\n                    Box')
        self.assertGreater(s.index('ProvideAudioSpectrum(playing'), eq)
        self.assertIn('LocalAudioSpectrum.current', read('ui/screens/EqualizerScreen.kt'))

    def test_static_search_art_direction_retained(self):
        s = read('ui/components/TopChrome.kt').split('fun Modifier.searchChrome')[1].split('/** База')[0]
        self.assertIn('brand.copy(alpha = 0.26f)', s)
        self.assertIn('cover.copy(alpha = 0.23f)', s)
        self.assertIn('SEARCH_CHROME_BASE.copy(alpha = 0.74f)', s)
        self.assertNotIn('animate', s)

    def test_new_checks_run_in_ci_preflight(self):
        s = (ROOT/'tools/check_selftest.py').read_text()
        self.assertIn('test_mobile_6414_contracts.py', s)
        self.assertIn('test_indicator_motion.py', s)

if __name__ == '__main__': unittest.main(verbosity=2)
