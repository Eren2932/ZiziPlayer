package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import java.util.Locale
import kotlin.math.abs

/** Same Activity window/insets as the player. Only the body scrolls; transport is measured first. */
@Composable
internal fun LyricsScreen(
    vm: MainViewModel,
    track: TrackEntity,
    playback: PlaybackState,
    state: LyricsUiState,
    onClose: () -> Unit
) {
    val p = LocalPalette.current
    BackHandler(onBack = onClose)
    var tools by rememberSaveable { mutableStateOf(false) }
    var pickedFor by rememberSaveable { mutableStateOf<String?>(null) }
    val liveTrackId by rememberUpdatedState(track.id)
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pickedFor == liveTrackId) state.importFile(uri)
        pickedFor = null
    }
    // Do not forward the lyrics list's overscroll to the dismissible player underneath.
    val containScroll = remember { object : NestedScrollConnection {
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset = available
    } }
    val background = remember(p.top, p.bottom) { Brush.verticalGradient(listOf(p.top, p.bottom)) }
    BoxWithConstraints(Modifier.fillMaxSize().background(background).pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) { awaitPointerEvent().changes.forEach { it.consume() } }
        }
    }.nestedScroll(containScroll).safeDrawingPadding()) {
        val compact = maxHeight < 440.dp
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(ZiziIcons.ChevronDown, "Закрыть текст", tint = p.text) }
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = p.text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!compact) Text(track.artist, color = p.subtext, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { tools = !tools }) { Icon(ZiziIcons.Tune, "Настройка текста и импорт LRC", tint = p.text) }
            }
            val doc = state.document
            if (doc != null && doc.hasText) {
                LyricsBody(vm, track, doc, state.advanceMs, Modifier.weight(1f), compact)
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(if (state.busy) "Загружаем текст…" else state.message ?: "Для этой версии текста нет. Можно импортировать LRC.",
                        color = p.subtext, maxLines = 4, overflow = TextOverflow.Ellipsis)
                }
            }
            // Advanced controls are opt-in, not a permanent 150dp tax on the lyrics viewport.
            if (tools) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    TextButton(onClick = { state.shift(state.advanceMs - 500) }) { Text("−0,5 с", color = p.text) }
                    TextButton(onClick = { state.shift(0) }) { Text(String.format(Locale.ROOT, "%+.1f с", state.advanceMs / 1000.0), color = p.text) }
                    TextButton(onClick = { state.shift(state.advanceMs + 500) }) { Text("+0,5 с", color = p.text) }
                }
                if (!compact) Text("+ показывает раньше · число сбрасывает сдвиг", color = p.subtext,
                    fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 24.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(enabled = !state.busy, onClick = state::retry) { Text("Обновить", color = p.text) }
                    TextButton(enabled = !state.busy, onClick = { pickedFor = track.id; importer.launch(arrayOf("*/*")) }) {
                        Text("Импорт LRC", color = p.text)
                    }
                }
                if (state.message != null && !compact) Text(state.message.orEmpty(), color = p.subtext,
                    fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 24.dp))
            }
            PlayerProgress(vm)
            Row(Modifier.fillMaxWidth().padding(bottom = if (compact) 0.dp else 8.dp),
                horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::previous) { Icon(ZiziIcons.SkipPrevious, "Предыдущий трек", tint = p.text) }
                IconButton(onClick = vm::playPause, modifier = Modifier.size(if (compact) 48.dp else 56.dp).background(p.text, CircleShape)) {
                    Icon(if (playback.isPlaying) ZiziIcons.Pause else ZiziIcons.PlayFilled,
                        if (playback.isPlaying) "Пауза" else "Воспроизвести", tint = Color.Black, modifier = Modifier.size(28.dp))
                }
                IconButton(onClick = vm::next) { Icon(ZiziIcons.SkipNext, "Следующий трек", tint = p.text) }
            }
        }
    }
}

@Composable
private fun LyricsBody(vm: MainViewModel, track: TrackEntity, doc: LyricsDocument, advanceMs: Long, modifier: Modifier, compact: Boolean) {
    val p = LocalPalette.current
    val cursor by rememberLyricsCursor(vm, track, doc, advanceMs)
    val list = rememberLazyListState()
    var follow by remember(doc) { mutableStateOf(true) }
    var previousActive by remember(doc) { mutableIntStateOf(-1) }
    val synchronized = cursor.sameTrack && cursor.matchesDuration && doc.lines.isNotEmpty()
    val active = cursor.active
    LaunchedEffect(list) {
        list.interactionSource.interactions.collect { if (it is DragInteraction.Start) follow = false }
    }
    Column(modifier.fillMaxWidth()) {
        if (!compact) Text(when {
            doc.lines.isEmpty() -> "${doc.source} · без таймкодов"
            !cursor.sameTrack -> "Ожидание позиции трека"
            !cursor.matchesDuration -> "Другая длительность: синхронизация отключена"
            doc.lines.any { it.words.isNotEmpty() } -> "${doc.source} · пословные метки LRC"
            else -> "${doc.source} · по строкам"
        }, color = p.subtext, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp))
        if (!follow && synchronized) TextButton(onClick = { follow = true }) { Text("К текущей строке", color = p.text) }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val anchor = maxHeight * 0.22f
            val anchorPx = with(LocalDensity.current) { anchor.roundToPx() }
            LaunchedEffect(active, follow, anchorPx) {
                if (follow) {
                    if (active < 0) list.scrollToItem(0)
                    else {
                        val visible = list.layoutInfo.visibleItemsInfo.firstOrNull { it.index == active }
                        if (previousActive < 0 || abs(active - previousActive) > 4 || visible == null)
                            list.scrollToItem(active)
                        else list.animateScrollBy((visible.offset - (list.layoutInfo.viewportStartOffset + anchorPx)).toFloat(),
                            spring(dampingRatio = 0.88f, stiffness = 190f))
                    }
                }
                previousActive = active
            }
            val plainLines = remember(doc) { doc.plain.lines() }
            LazyColumn(state = list, modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = anchor, bottom = maxHeight * 0.65f),
                verticalArrangement = Arrangement.spacedBy(if (compact) 12.dp else 24.dp)) {
                if (doc.lines.isNotEmpty()) {
                    itemsIndexed(doc.lines, key = { _, line -> line.timeMs }) { index, line ->
                        val selected = index == active
                        val scale by animateFloatAsState(if (selected) 1f else 0.96f,
                            spring(dampingRatio = 0.78f, stiffness = 240f), label = "lyricScale")
                        val ink by animateColorAsState(if (selected) p.text else p.text.copy(alpha = if (index < active) 0.34f else 0.52f),
                            tween(240), label = "lyricInk")
                        Text(if (selected) lyricText(line, cursor.word, p.text) else androidx.compose.ui.text.AnnotatedString(line.text.ifBlank { "♪" }),
                            color = ink, fontSize = if (compact) 22.sp else 28.sp, lineHeight = if (compact) 29.sp else 37.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()
                                .graphicsLayer { scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0f, 0.5f) }
                                .semantics { this.selected = selected }.clickable(enabled = synchronized) {
                                    follow = true
                                    vm.seekTo(LrcTimeline.seekPosition(line, advanceMs), track.id)
                                }.padding(vertical = 8.dp))
                    }
                } else itemsIndexed(plainLines) { _, line -> Text(line, color = p.text, fontSize = 23.sp, lineHeight = 31.sp) }
            }
        }
    }
}
