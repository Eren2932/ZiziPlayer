package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.theme.LocalPalette

/** No loading/empty/instrumental card. The player remains unchanged when there is no text. */
@Composable
internal fun LyricsPreview(vm: MainViewModel, track: TrackEntity, state: LyricsUiState, onOpen: () -> Unit) {
    val doc = state.document?.takeIf { it.hasText } ?: return
    val p = LocalPalette.current
    val cursor by rememberLyricsCursor(vm, track, doc, state.advanceMs)
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        .clip(RoundedCornerShape(20.dp)).background(p.chip).clickable(onClick = onOpen).padding(20.dp)) {
        Text("Текст песни", color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        val start = cursor.active.coerceAtLeast(0)
        Text(if (doc.lines.isNotEmpty()) doc.lines.drop(start).take(3).joinToString("\n") { it.text.ifBlank { "♪" } }
            else doc.plain, color = p.text.copy(alpha = 0.8f), fontSize = 22.sp, lineHeight = 30.sp,
            maxLines = 5, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Открыть текст  ↗", color = p.text, fontWeight = FontWeight.Bold)
    }
}

/** Key includes cue index: repeated identical phrases still transition on the correct cue. */
@Composable
internal fun InlineLyrics(vm: MainViewModel, track: TrackEntity, state: LyricsUiState, onOpen: () -> Unit) {
    val doc = state.document ?: return
    val p = LocalPalette.current
    val cursor by rememberLyricsCursor(vm, track, doc, state.advanceMs)
    val active = cursor.active
    val cue = if (cursor.sameTrack && cursor.matchesDuration) active else -1
    Box(Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 28.dp)
        .clip(RoundedCornerShape(8.dp)).clickable(onClick = onOpen), contentAlignment = Alignment.Center) {
        AnimatedContent(targetState = cue, transitionSpec = {
            (fadeIn(tween(230)) + slideInVertically(tween(320)) { it / 2 }) togetherWith
                (fadeOut(tween(150)) + slideOutVertically(tween(300)) { -it / 2 })
        }, label = "inlineLyrics") { index ->
            val line = doc.lines.getOrNull(index)
            Text(text = if (line == null || line.text.isBlank()) androidx.compose.ui.text.AnnotatedString("♪ ♪ ♪")
                else lyricText(line, if (index == active) cursor.word else -1, p.text),
                color = p.text.copy(alpha = 0.86f), fontSize = 18.sp, lineHeight = 24.sp,
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center)
        }
    }
}
