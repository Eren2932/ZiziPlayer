package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.lyrics.LyricsRepository
import app.ziziplayer.ui.MainViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** One owner in the ViewModel: opening/closing a screen never restarts a request. */
@Stable
internal class LyricsUiState(val track: TrackEntity? = null) {
    var document by mutableStateOf<LyricsDocument?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var advanceMs by mutableLongStateOf(0L)
        private set
    private data class Request(val revision: Int = 0, val uri: Uri? = null)
    private val requests = MutableStateFlow(Request())
    private var offsetWrite: Job? = null
    private var persistAdvance: ((Long) -> Unit)? = null
    fun retry() { requests.value = Request(requests.value.revision + 1) }
    fun importFile(uri: Uri) { requests.value = Request(requests.value.revision + 1, uri) }
    fun shift(value: Long) {
        advanceMs = value.coerceIn(-60000L, 60000L)
        persistAdvance?.invoke(advanceMs)
    }
    private suspend fun fetchAutomatically(repository: LyricsRepository, current: TrackEntity, force: Boolean): LyricsDocument {
        repeat(3) { attempt ->
            try { return repository.fetch(current, force = force && attempt == 0) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val wait = repository.retryDelay(e)
                if (attempt == 2 || wait == null) throw e
                message = "Сеть недоступна. Повторяем загрузку текста…"
                delay(wait)
            }
        }
        error("Unreachable lyrics retry state")
    }
    suspend fun observe(repository: LyricsRepository, networkAllowed: Boolean, scope: CoroutineScope) {
        val current = track ?: return
        advanceMs = repository.advance(current)
        persistAdvance = { value ->
            val previous = offsetWrite
            offsetWrite = scope.launch { previous?.join(); repository.saveAdvance(current, value) }
        }
        requests.collectLatest { request ->
            busy = true
            message = null
            try {
                document = if (request.uri != null) repository.importLrc(current, request.uri) else {
                    val cached = if (request.revision == 0) repository.cached(current) else null
                    cached ?: if (networkAllowed) {
                        // Avoid starting HTTP for transient queue items during rapid Next taps.
                        delay(200)
                        fetchAutomatically(repository, current, force = request.revision > 0)
                    } else {
                        if (request.revision > 0) message = "Автозагрузка отключена в настройках. Доступен импорт LRC."
                        document
                    }
                }
                if (request.uri != null) shift(0L)
                if (document != null && networkAllowed) message = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = e.message ?: "Не удалось загрузить текст"
            } finally { busy = false }
        }
    }
}

@Composable
internal fun rememberLyricsUiState(vm: MainViewModel, track: TrackEntity?): LyricsUiState {
    val owned by vm.lyricsUi.collectAsStateWithLifecycle()
    val empty = remember(track?.id) { LyricsUiState() }
    return if (owned.track?.id == track?.id) owned else empty
}
