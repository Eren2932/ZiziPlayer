package app.ziziplayer.lyrics

import android.content.Context
import android.net.Uri
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import org.json.JSONArray
import kotlinx.coroutines.CancellationException
import android.os.SystemClock
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToLong

internal data class LyricsDocument(
    val lines: List<LrcTimeline.Line>,
    val plain: String,
    val source: String,
    val durationMs: Long,
    val instrumental: Boolean = false
) {
    val hasText: Boolean get() = !instrumental && (lines.any { it.text.isNotBlank() } || plain.isNotBlank())
}

/** Automatic current-track metadata only; no audio uploads or resolver credentials. */
class LyricsRepository(context: Context) {
    private val app = context.applicationContext
    private val lock = Mutex()
    private val misses = object : LinkedHashMap<String, Long>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean = size > 128
    }
    private var providerBackoffUntil = 0L
    private val offsets by lazy { app.getSharedPreferences("lyrics-offsets-v1", Context.MODE_PRIVATE) }
    internal suspend fun advance(track: TrackEntity): Long = withContext(Dispatchers.IO) {
        offsets.getLong(key(track), 0L).coerceIn(-60000L, 60000L)
    }
    internal suspend fun saveAdvance(track: TrackEntity, value: Long) = withContext(Dispatchers.IO) {
        val id = key(track)
        val edit = offsets.edit()
        if (offsets.all.size >= 256 && !offsets.contains(id)) offsets.all.keys.take(32).forEach { edit.remove(it) }
        edit.putLong(id, value.coerceIn(-60000L, 60000L)).apply()
    }
    // A dedicated public-metadata client MUST NOT inherit the resolver's auth interceptor.
    private val client by lazy {
        OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS)
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false).followRedirects(false).build()
    }
    private val memory = object : LinkedHashMap<String, LyricsDocument>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LyricsDocument>?): Boolean = size > 24
    }
    private fun key(track: TrackEntity): String {
        val identity = listOf(track.id, track.title, track.artist, track.album, track.durationMs.toString())
        val encoded = identity.joinToString("") { "${it.length}:$it" }
        return MessageDigest.getInstance("SHA-256").digest(encoded.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
    private fun dir(imported: Boolean) = File(if (imported) app.filesDir else app.cacheDir,
        if (imported) "lyrics-imports-v1" else "lyrics-cache-v1").apply { mkdirs() }
    private fun decode(json: JSONObject): LyricsDocument {
        val synced = if (json.isNull("syncedLyrics")) "" else json.optString("syncedLyrics", "")
        val plain = if (json.isNull("plainLyrics")) "" else json.optString("plainLyrics", "")
        return LyricsDocument(LrcTimeline.parse(synced), plain,
            json.optString("source", "LRCLIB"), (json.optDouble("duration", 0.0) * 1000).roundToLong(),
            json.optBoolean("instrumental", false))
    }
    internal suspend fun cached(track: TrackEntity): LyricsDocument? = withContext(Dispatchers.IO) {
        lock.withLock {
            val id = key(track)
            memory[id] ?: sequenceOf(File(dir(true), "$id.json"), File(dir(false), "$id.json"))
                .mapNotNull { file ->
                    if (!file.isFile || file.length() > MAX_BYTES ||
                        (file.parentFile == dir(false) && System.currentTimeMillis() - file.lastModified() > CACHE_AGE_MS)) null
                    else try { decode(JSONObject(file.readText())) } catch (_: Exception) { null }
                }.firstOrNull()?.also { memory[id] = it }
        }
    }
    private suspend fun store(track: TrackEntity, json: JSONObject, imported: Boolean): LyricsDocument =
        withContext(Dispatchers.IO) {
            lock.withLock {
                val doc = decode(json)
                val id = key(track)
                val folder = dir(imported)
                val target = File(folder, "$id.json")
                val entries = folder.listFiles { f -> f.extension == "json" }.orEmpty()
                if (imported && !target.exists() && entries.size >= 128)
                    throw IOException("Достигнут лимит 128 импортированных текстов")
                val encoded = json.toString().toByteArray(Charsets.UTF_8)
                if (encoded.size > MAX_BYTES) throw IOException("Слишком большой текст")
                val tmp = File.createTempFile("lyrics-", ".tmp", folder)
                try {
                    tmp.writeBytes(encoded)
                    if (!tmp.renameTo(target)) throw IOException("Не удалось сохранить текст")
                } finally { tmp.delete() }
                if (!imported) folder.listFiles { f -> f.extension == "json" }.orEmpty()
                    .sortedByDescending { it.lastModified() }.drop(48).forEach { it.delete() }
                memory[id] = doc
                doc
            }
        }
    internal suspend fun importLrc(track: TrackEntity, uri: Uri): LyricsDocument = withContext(Dispatchers.IO) {
        val text = app.contentResolver.openInputStream(uri)?.use { readLimited(it).toString(Charsets.UTF_8) }
            ?: throw IOException("Не удалось открыть LRC")
        if (LrcTimeline.parse(text).isEmpty()) throw IOException("В файле нет таймкодов LRC. Нужен UTF-8 LRC")
        store(track, JSONObject().put("syncedLyrics", text).put("plainLyrics", "")
            .put("source", "Импорт LRC").put("duration", 0), true)
    }
    internal suspend fun fetch(track: TrackEntity, force: Boolean = false): LyricsDocument = withContext(Dispatchers.IO) {
        if (track.title.isBlank() || track.artist.isBlank() ||
            track.artist.equals("Неизвестный артист", true) || track.artist.equals("<unknown>", true) || track.durationMs <= 0)
            throw NoLyrics("Недостаточно метаданных для текста")
        val id = key(track)
        val now = SystemClock.elapsedRealtime()
        if (lock.withLock { now < providerBackoffUntil || (!force && now < (misses[id] ?: 0L)) })
            throw NoLyrics("Текст пока недоступен; повторный поиск отложен")
        try {
            val exactUrl = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
                .addQueryParameter("track_name", track.title)
                .addQueryParameter("artist_name", track.artist)
                .addQueryParameter("album_name", track.album)
                .addQueryParameter("duration", (track.durationMs / 1000.0).toString()).build()
            val exact = try { JSONObject(get(request(exactUrl))) }
                catch (e: HttpFailure) { if (e.status == 404) null else throw e }
            val selected = if (exact != null && eligible(track, exact)) exact else {
                // One fallback, same full title (including slowed/remix qualifiers), never a queue scan.
                val searchUrl = "https://lrclib.net/api/search".toHttpUrl().newBuilder()
                    .addQueryParameter("track_name", track.title)
                    .addQueryParameter("artist_name", track.artist).build()
                val result = JSONArray(get(request(searchUrl)))
                val candidates = (0 until minOf(result.length(), 100)).mapNotNull { result.optJSONObject(it) }
                    .filter { eligible(track, it) }
                val albumMatches = candidates.filter { track.album.isNotBlank() &&
                    it.optString("albumName").equals(track.album, ignoreCase = true) }
                val ranked = (albumMatches.ifEmpty { candidates }).sortedWith(
                    compareByDescending<JSONObject> { !it.optString("syncedLyrics").let { text -> text == "null" || text.isBlank() } }
                        .thenBy { kotlin.math.abs(it.optDouble("duration", 0.0) * 1000 - track.durationMs) })
                // Different equally plausible lyrics are not safe to select silently.
                val best = ranked.firstOrNull() ?: throw NoLyrics("Для этой версии текст не найден")
                val bestDuration = best.optDouble("duration", 0.0)
                if (ranked.drop(1).any { other ->
                    kotlin.math.abs(other.optDouble("duration", 0.0) - bestDuration) < 0.25 &&
                        other.optString("syncedLyrics") != best.optString("syncedLyrics") &&
                        other.optString("syncedLyrics").isNotBlank() && other.optString("syncedLyrics") != "null"
                }) throw NoLyrics("Найдено несколько разных текстов этой версии; нужен точный LRC")
                best
            }
            val doc = decode(selected)
            val stored = store(track, JSONObject().put("syncedLyrics", selected.opt("syncedLyrics"))
                .put("plainLyrics", selected.opt("plainLyrics")).put("duration", doc.durationMs / 1000.0)
                .put("instrumental", doc.instrumental).put("source", "LRCLIB"), false)
            lock.withLock { misses.remove(id) }
            stored
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lock.withLock {
                val time = SystemClock.elapsedRealtime()
                misses[id] = time + if (e is NoLyrics || (e is HttpFailure && e.status == 404)) 600_000L else 30_000L
                if (e is HttpFailure && e.status == 429) providerBackoffUntil = time + 60_000L
            }
            throw e
        }
    }
    internal fun retryDelay(error: Exception): Long? = when {
        error is NoLyrics -> null
        error is HttpFailure && error.status == 429 -> 60_000L
        error is HttpFailure && error.status < 500 -> null
        error is IOException -> 30_000L
        else -> null
    }
    private fun eligible(track: TrackEntity, json: JSONObject): Boolean {
        if (!LrcTimeline.identityMatches(track.title, track.artist, json.optString("trackName"), json.optString("artistName"))) return false
        val seconds = json.optDouble("duration", 0.0)
        if (!seconds.isFinite() || seconds <= 0) return false
        val doc = try { decode(json) } catch (_: Exception) { return false }
        return LrcTimeline.durationMatches(track.durationMs, doc.durationMs) &&
            (doc.lines.lastOrNull()?.timeMs ?: 0L) <= doc.durationMs + 2000 &&
            doc.lines.all { line -> line.words.all { it.timeMs <= doc.durationMs + 2000 } } &&
            (doc.instrumental || doc.hasText)
    }
    private fun request(url: okhttp3.HttpUrl) = Request.Builder().url(url)
        .header("User-Agent", "ZiziPlayer/6.45.0 (https://github.com/Eren2932/ZiziPlayer)")
        .header("Accept", "application/json").build()
    private class NoLyrics(message: String) : IOException(message)
    private class HttpFailure(val status: Int, message: String) : IOException(message)
    private suspend fun get(request: Request): String = suspendCancellableCoroutine { continuation ->
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWithException(IOException("Сервис текста недоступен. Проверьте сеть", e))
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    try {
                        if (!continuation.isActive) return
                        if (!r.isSuccessful) throw HttpFailure(r.code, when (r.code) {
                            404 -> "Для этой версии текст не найден. Можно импортировать LRC"
                            429 -> "Сервис ограничил запросы. Попробуйте позднее"
                            else -> "Сервис текста временно недоступен (HTTP ${r.code})"
                        })
                        val body = r.body ?: throw IOException("Пустой ответ сервиса")
                        val raw = body.byteStream().use { readLimited(it).toString(Charsets.UTF_8) }
                        if (continuation.isActive) continuation.resume(raw)
                    } catch (e: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(e)
                    }
                }
            }
        })
    }
    private fun readLimited(input: InputStream): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (output.size() + count > MAX_BYTES) throw IOException("Текст превышает лимит 512 КБ")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }
    private companion object {
        const val MAX_BYTES = 512 * 1024
        const val CACHE_AGE_MS = 30L * 24 * 60 * 60 * 1000
    }
}
