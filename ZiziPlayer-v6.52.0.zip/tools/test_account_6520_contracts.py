"""Static UI/configuration regression checks. Not Android rendering or live OAuth tests."""
import unittest
from pathlib import Path
from check_account_release import validate

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'

class Account6520(unittest.TestCase):
    def test_email_only_remains_supported(self):
        self.assertEqual(validate('', '', ''), [])

    def test_google_public_configuration(self):
        self.assertEqual(validate('https://accounts.example.org', '12345-abc.apps.googleusercontent.com', '/tmp/release.jks'), [])

    def test_reject_bad_oauth_configuration(self):
        for client in (' 123-abc.apps.googleusercontent.com', 'Android Client ID', '123-abc.apps.googleusercontent.com\n'):
            self.assertTrue(validate('https://accounts.example.org', client, '/tmp/release.jks'))
        for url in ('', 'http://accounts.example.org', 'https://accounts.example.org/path',
                    'https://user:password@accounts.example.org', 'https://accounts.example.org?x=1'):
            self.assertTrue(validate(url, '123-abc.apps.googleusercontent.com', '/tmp/release.jks'))

    def test_google_never_silently_uses_debug_certificate(self):
        self.assertTrue(validate('https://accounts.example.org', '123-abc.apps.googleusercontent.com', ''))

    def test_reference_ui_and_recovery(self):
        s = (SRC/'ui/screens/AccountAuthScreen.kt').read_text()
        for text in ('LoginEmail', 'RegisterEmail', 'LoginPassword', 'RegisterPassword',
                     'AuthPage.Verify', 'AuthPage.Forgot', 'AuthPage.Reset', 'BackHandler { back() }',
                     'AnimatedContent', 'tween(240', 'if (shown.emailEntry)', 'launchAction("google")',
                     'repository.capabilities()', 'FLAG_SECURE'):
            self.assertIn(text, s)
        self.assertNotIn('Facebook', s)
        self.assertNotIn('Вход через Google не настроен или сервис сейчас недоступен.', s)
        self.assertNotIn('rememberSaveable', s)

    def test_brand_and_shared_pills(self):
        s = (SRC/'ui/screens/AccountAuthComponents.kt').read_text()
        for text in ('p.brand', 'p.onBrand', 'RoundedCornerShape(50)', 'min = 48.dp', 'ic_google_signin'):
            self.assertIn(text, s)

    def test_workflow_copies_match(self):
        root = (ROOT/'.github/workflows/build.yml').read_text()
        self.assertEqual(root, (ROOT/'repo-update/.github/workflows/build.yml').read_text())
        self.assertIn('python3 tools/check_account_release.py', root)
        self.assertIn('SHA-1|SHA-256', root)

if __name__ == '__main__':
    unittest.main(verbosity=2)
