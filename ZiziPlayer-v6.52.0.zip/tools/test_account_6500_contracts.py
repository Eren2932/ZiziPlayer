#!/usr/bin/env python3
"""6.50.0: экраны аккаунта. Проверяется ТО, ЧТО ЛЕГКО СЛОМАТЬ ТЕКСТОМ, а не вёрстка.

Главный риск этой версии — не кривая кнопка, а ложное обещание. Экран, который говорит
«сохранено в облаке» при отсутствующем сервере, опаснее отсутствующего экрана: человек
перестаёт беречь локальные данные и теряет их на первой же переустановке.
"""
from pathlib import Path
import unittest

R = Path(__file__).resolve().parents[1]
SRC = R / 'app/src/main/java/app/ziziplayer'


def read(rel):
    return (SRC / rel).read_text(encoding='utf-8')


class AccountContracts(unittest.TestCase):

    def test_sign_in_requires_configured_service(self):
        gate = read('account/AccountGate.java')
        self.assertIn('SIGN_IN_IMPLEMENTED = true', gate)
        self.assertIn('return SIGN_IN_IMPLEMENTED && serviceConfigured;', gate)

    def test_guest_choice_marks_the_welcome_revision(self):
        # Иначе «продолжить как гость» не запоминается и окно возвращается каждый запуск.
        store = read('account/AccountStore.kt')
        self.assertIn('mode = AccountGate.Mode.GUEST', store)
        self.assertIn('seenWelcomeRevision = AccountGate.WELCOME_REVISION', store)

    def test_sign_out_keeps_the_local_library(self):
        store = read('account/AccountStore.kt')
        for forbidden in ('clearAllTables', 'deleteDatabase', 'clear()'):
            self.assertNotIn(forbidden, store)

    def test_no_screen_claims_cloud_storage(self):
        # Ни один экран не имеет права утверждать сохранность, пока её никто не обеспечивает.
        for rel in ('ui/screens/WelcomeScreen.kt', 'ui/screens/AccountScreen.kt'):
            text = read(rel)
            for claim in ('Сохранено в аккаунте', 'Синхронизировано', 'Данные в облаке',
                          'Всё сохранено'):
                self.assertNotIn(claim, text, rel)

    def test_account_screen_states_the_current_truth(self):
        screen = read('ui/screens/AccountScreen.kt')
        self.assertIn('Синхронизация не включена', screen)
        self.assertIn('только на этом телефоне', screen)

    def test_guest_path_always_exists_on_welcome(self):
        # Окно не должно превращаться в тупик, когда входа нет.
        welcome = read('ui/screens/WelcomeScreen.kt')
        self.assertIn('Продолжить как гость', welcome)
        self.assertIn('onGuest', welcome)

    def test_welcome_is_gated_not_unconditional(self):
        main = read('MainActivity.kt')
        self.assertIn('if (account.showWelcome)', main)
        self.assertIn('AccountGate.normalizeServiceUrl(BuildConfig.ACCOUNT_URL)', main)

    def test_account_screen_is_reachable_from_settings(self):
        sheets = read('ui/screens/Sheets.kt')
        self.assertIn('SettingsSection.ACCOUNT', sheets)
        self.assertIn('onOpenAccount()', sheets)
        main = read('MainActivity.kt')
        self.assertIn('onOpenAccount = { accountOpen = true }', main)
        # Кнопка «назад» закрывает экран аккаунта раньше остальных слоёв.
        self.assertIn('accountOpen -> accountOpen = false', main)

    def test_account_url_is_empty_by_default(self):
        gradle = (R / 'app/build.gradle.kts').read_text(encoding='utf-8')
        self.assertIn('System.getenv("ACCOUNT_URL") ?: ""', gradle)
        self.assertIn('buildConfigField("String", "ACCOUNT_URL", quoted(accountUrl))', gradle)


if __name__ == '__main__':
    unittest.main(verbosity=2)
