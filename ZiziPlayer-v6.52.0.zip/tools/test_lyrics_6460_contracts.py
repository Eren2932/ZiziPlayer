#!/usr/bin/env python3
"""Source wiring guards. Not compilation, a mock HTTP execution, or Compose rendering."""
from pathlib import Path
import unittest
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
def read(name): return (S / name).read_text()
class Lyrics646Contracts(unittest.TestCase):
    def test_three_request_ceiling_and_identity_gate(self):
        s = read('lyrics/LyricsRepository.kt')
        self.assertIn('for (includeArtist in listOf(true, false))', s)
        self.assertIn('if (track.durationMs > 0L)', s)
        self.assertIn('minOf(result.length(), 100)', s)
        self.assertIn('LyricsMatchPolicy.identityMatches', s)
        self.assertIn('LyricsMatchPolicy.searchTitle(track.title)', s)
        self.assertIn('doc.lines.isNotEmpty() && validTimings &&', s)
        self.assertIn('LrcTimeline.durationMatches(track.durationMs, doc.durationMs)', s)
    def test_timing_variants_no_longer_hide_all_text(self):
        s = read('lyrics/LyricsRepository.kt')
        self.assertNotIn('ranked.drop(1).any', s)
        self.assertIn('compareByDescending<Candidate> { it.document.hasText }', s)
        self.assertIn('.thenByDescending { it.synchronized }', s)
        self.assertIn('if (selected.synchronized) selected.json.opt("syncedLyrics") else ""', s)
        self.assertIn('doc.plain.ifBlank { doc.lines.joinToString', s)
    def test_network_errors_are_not_negative_song_cache(self):
        s = read('lyrics/LyricsRepository.kt')
        self.assertEqual(s.count('misses[id] ='), 1)
        self.assertIn('if (e is NoLyrics) misses[id] = time + 120_000L', s)
        self.assertIn('error is DeferredLyrics -> error.delayMs', s)
        self.assertIn('if (candidates.any { it.document.hasText }) break', s)
        self.assertIn('memory[id] = found', s)
    def test_known_document_survives_duration_refinement(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('if (sameMetadata) owner.seed(previous)', vm)
        self.assertIn('it.id == track.id && it.title == track.title && it.artist == track.artist && it.album == track.album', vm)
        state = read('ui/screens/LyricsUiState.kt')
        self.assertIn('document = previous.document', state)
        self.assertEqual(state.count('repository.fetch('), 1)
    def test_header_and_transport_use_measured_geometry(self):
        s = read('ui/screens/LyricsScreen.kt')
        for t in ('LyricsGeometry.playDiameter', 'LyricsGeometry.bottomGap', 'LyricsGeometry.headerFont',
                  'horizontalAlignment = Alignment.CenterHorizontally', 'textAlign = TextAlign.Center',
                  'PlayerProgress(vm, lyricsLayout = true, compact = compact)'):
            self.assertIn(t, s)
        self.assertIn('Modifier.weight(1f)', s)
        self.assertNotIn('else 56.dp', s)
    def test_inline_budget_is_document_not_current_line_dependent(self):
        s = read('ui/screens/LyricsPreview.kt')
        measure = s.split('internal fun rememberInlineLyricsHeight')[1].split('/** Key includes')[0]
        self.assertNotIn('cursor', measure)
        self.assertIn('remember(doc, width, density, measurer)', measure)
        self.assertIn('if (measured.lineCount >= 3) break', measure)
        self.assertIn('maxLines = 3', s)
        self.assertNotIn('height(76.dp)', s)
        player = read('ui/screens/PlayerScreen.kt')
        self.assertIn('measuredLyrics + 24.dp', player)
        self.assertIn('maxHeight - lyricBudget', player)
        self.assertIn('padding(vertical = lyricInset)', player)
    def test_mini_reuses_lifecycle_gated_marquee(self):
        mini = read('ui/screens/LibraryScreen.kt').split('fun MiniPlayer(')[1].split('private fun MiniProgressLine')[0]
        self.assertIn('MarqueeText(', mini)
        self.assertNotIn('TrackTitle(', mini)
        self.assertIn('resetKey = track.id', mini)
        self.assertIn('enabled = animateTitle', mini)
        self.assertIn('animateTitle = !mounted', read('MainActivity.kt'))
        marquee = read('ui/components/Common.kt').split('fun MarqueeText(')[1].split('fun formatTotalTime')[0]
        self.assertIn('repeatOnLifecycle(Lifecycle.State.RESUMED)', marquee)
        self.assertIn('if (!scrolling || !enabled)', marquee)
        self.assertIn('.semantics { this.text = AnnotatedString(text) }', marquee)
        self.assertIn('val offset = -shift.value', marquee)
    def test_no_new_playback_listener_or_dependency(self):
        for name in ('lyrics/LyricsRepository.kt', 'ui/screens/LyricsUiState.kt',
                     'ui/screens/LyricsPreview.kt', 'ui/screens/LyricsScreen.kt'):
            self.assertNotIn('addListener(', read(name))
        gradle = (R / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 102', gradle)
        self.assertIn('versionName = "6.52.0"', gradle)
    def test_audio_priority_gates_every_network_request(self):
        repo = read('lyrics/LyricsRepository.kt')
        self.assertEqual(repo.count('get(request(builder.build()), awaitNetworkSlot)'), 2)
        gate = repo.split('private suspend fun get(request: Request,')[1].split('private suspend fun execute')[0]
        self.assertLess(gate.index('awaitNetworkSlot()'), gate.index('return execute(request, span)'))
        self.assertIn('continuation.invokeOnCancellation { call.cancel() }', repo)
        vm = read('ui/MainViewModel.kt')
        gate = vm.split('private suspend fun awaitLyricsNetworkSlot')[1].split('fun retainLyricsClock')[0]
        for token in ('state.connected', 'state.currentTrackId == trackId', '!state.isLoadingAudio',
                      'distinctUntilChanged().transformLatest', 'delay(750L)', '.first()'):
            self.assertIn(token, gate)
        controller = read('playback/PlayerController.kt')
        self.assertIn('isLoadingAudio = p.playbackState == Player.STATE_BUFFERING ||', controller)
        self.assertIn('(p.playWhenReady && p.playbackState == Player.STATE_IDLE)', controller)
        self.assertEqual(controller.count('override fun onEvents('), 1)
    def test_duration_refinement_reuses_valid_sync_but_retry_bypasses_it(self):
        state = read('ui/screens/LyricsUiState.kt')
        for token in ('val retained = if (request.revision == 0)',
                      'it.lines.isNotEmpty() && LrcTimeline.durationMatches(current.durationMs, it.durationMs)',
                      'cached ?: retained ?: if (networkAllowed)', 'awaitNetworkSlot = awaitNetworkSlot'):
            self.assertIn(token, state)
    def test_checks_wired_into_ci(self):
        preflight = (R/'tools/check_selftest.py').read_text()
        self.assertIn("'test_lyrics_6460.py'", preflight)
        self.assertIn("'test_lyrics_6460_contracts.py'", preflight)
        self.assertIn('Lyrics646Checks.run()', (R/'app/src/test/java/app/ziziplayer/lyrics/Lyrics646Test.kt').read_text())
if __name__ == '__main__': unittest.main(verbosity=2)
