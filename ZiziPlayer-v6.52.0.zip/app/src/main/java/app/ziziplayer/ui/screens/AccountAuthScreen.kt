package app.ziziplayer.ui.screens

import android.app.Activity
import android.util.Patterns
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import app.ziziplayer.ui.theme.ZiziFontFamily
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.exceptions.GetCredentialCancellationException
import app.ziziplayer.account.AccountApiException
import app.ziziplayer.account.AccountRepository
import app.ziziplayer.account.GoogleAccountSignIn
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

internal enum class AuthPage {
    LoginEmail, RegisterEmail, LoginPassword, RegisterPassword, Verify, Forgot, Reset;
    val emailEntry: Boolean get() = this == LoginEmail || this == RegisterEmail
    val parent: AuthPage? get() = when (this) {
        LoginEmail, RegisterEmail -> null
        LoginPassword -> LoginEmail
        RegisterPassword -> RegisterEmail
        Forgot -> LoginPassword
        Reset -> Forgot
        Verify -> LoginEmail
    }
}

/** Credentials live only in non-saveable memory; the repository owns all identity decisions. */
@Composable
fun AccountAuthScreen(
    activity: Activity,
    repository: AccountRepository,
    onSignedIn: (String) -> Unit,
    onClose: () -> Unit,
    initialRegister: Boolean = false
) {
    val p = LocalPalette.current
    var page by remember { mutableStateOf(if (initialRegister) AuthPage.RegisterEmail else AuthPage.LoginEmail) }
    var backwards by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    DisposableEffect(activity) {
        val wasSecure = activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (!wasSecure) activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    fun switch(next: AuthPage, back: Boolean = false) {
        focus.clearFocus()
        backwards = back
        page = next
        password = ""; confirmation = ""; code = ""; message = ""
    }
    fun back() {
        if (busy) return
        val parent = page.parent
        if (parent == null) { focus.clearFocus(); onClose() } else switch(parent, true)
    }
    BackHandler { back() }

    fun validEmail(): Boolean {
        if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            message = "Проверьте адрес электронной почты."; return false
        }
        return true
    }
    fun launchAction(action: String) {
        if (busy) return
        if (action in setOf("register", "login", "forgot", "resend") && !validEmail()) return
        if (action in setOf("register", "reset") && password != confirmation) {
            message = "Пароли не совпадают"; return
        }
        if (action in setOf("register", "login", "reset") && password.length !in 12..128) {
            message = "Пароль должен содержать от 12 до 128 символов"; return
        }
        if (action in setOf("verify", "reset") && code.isBlank()) {
            message = "Вставьте код из письма."; return
        }
        focus.clearFocus()
        busy = true; message = ""
        scope.launch {
            try {
                val result = if (action == "google") {
                    // Retry health on every explicit attempt: a transient outage never permanently hides Google.
                    if (!GoogleAccountSignIn.configured) throw AccountApiException(503, "not_configured")
                    if (!repository.capabilities().optBoolean("google_enabled", false))
                        throw AccountApiException(503, "google_not_configured")
                    GoogleAccountSignIn.signIn(activity, repository)
                } else repository.submit(action, email, password, code)
                password = ""; confirmation = ""; code = ""
                when (action) {
                    "login", "google" -> onSignedIn(result.getString("email"))
                    "register", "resend" -> {
                        switch(AuthPage.Verify)
                        message = result.optString("message", "Проверьте почту, включая папку «Спам».")
                    }
                    "forgot" -> { switch(AuthPage.Reset); message = result.optString("message") }
                    "verify" -> { switch(AuthPage.LoginPassword, true); message = "Почта подтверждена. Теперь войдите." }
                    "reset" -> { switch(AuthPage.LoginPassword, true); message = "Пароль изменён. Войдите заново." }
                }
            } catch (error: CancellationException) { throw error
            } catch (_: GetCredentialCancellationException) {
                // Dismissing Google's chooser is navigation, not an error banner.
            } catch (error: Exception) { message = accountErrorMessage(error)
            } finally { busy = false }
        }
    }
    fun continuePage() {
        if (busy) return
        if (page.emailEntry) {
            if (validEmail()) switch(if (page == AuthPage.RegisterEmail) AuthPage.RegisterPassword else AuthPage.LoginPassword)
        } else launchAction(when (page) {
            AuthPage.RegisterPassword -> "register"
            AuthPage.Verify -> "verify"
            AuthPage.Forgot -> "forgot"
            AuthPage.Reset -> "reset"
            else -> "login"
        })
    }

    Box(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().imePadding().clipToBounds()) {
        AnimatedContent(targetState = page, modifier = Modifier.fillMaxSize(), transitionSpec = {
            val direction = if (backwards) -1 else 1
            (slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { it * direction } togetherWith
                slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { -it * direction })
                .using(SizeTransform(clip = true))
        }, label = "account-page") { shown ->
            BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
                val viewport = maxHeight
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).heightIn(min = viewport)) {
                    Box(Modifier.fillMaxWidth().heightIn(min = 56.dp), contentAlignment = Alignment.Center) {
                        IconButton(onClick = { back() }, enabled = !busy,
                            modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp)) {
                            Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(24.dp))
                        }
                        Text(when (shown) {
                            AuthPage.RegisterEmail, AuthPage.RegisterPassword -> "Создание аккаунта"
                            AuthPage.Verify -> "Подтверждение почты"
                            AuthPage.Forgot, AuthPage.Reset -> "Восстановление доступа"
                            else -> "Вход в ZiziPlayer"
                        }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 64.dp, vertical = 12.dp))
                    }
                    Spacer(Modifier.height(if (shown.emailEntry) (viewport * 0.24f).coerceAtMost(220.dp) else 24.dp))
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (shown.emailEntry || shown == AuthPage.Forgot) {
                            Text(if (shown == AuthPage.RegisterEmail) "Какая у тебя почта?" else "Эл. почта",
                                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            if (shown == AuthPage.RegisterEmail) Text("Этот адрес электронной почты нужно будет подтвердить.",
                                color = Color.White, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium)
                            AuthField(email, { email = it.take(254) }, "Эл. почта", !busy,
                                keyboard = KeyboardType.Email, showLabel = false, onDone = { continuePage() })
                        } else {
                            Text(email, color = Color(0xFFB3B3B3), fontSize = 16.sp)
                        }
                        if (shown == AuthPage.Verify || shown == AuthPage.Reset) {
                            Text("Вставьте полный код из письма. Он действует 30 минут. Новый запрос заменяет предыдущий код.",
                                color = Color.White, fontSize = 16.sp)
                            AuthField(code, { code = it.take(100) }, "Код из письма", !busy,
                                onDone = { if (shown == AuthPage.Verify) continuePage() })
                        }
                        if (shown in setOf(AuthPage.LoginPassword, AuthPage.RegisterPassword, AuthPage.Reset)) {
                            AuthField(password, { password = it.take(128) }, "Пароль", !busy, secret = true,
                                keyboard = KeyboardType.Password, onDone = { if (shown == AuthPage.LoginPassword) continuePage() })
                        }
                        if (shown == AuthPage.RegisterPassword || shown == AuthPage.Reset) {
                            Text("12–128 символов. Используйте уникальный пароль.", color = Color(0xFFB3B3B3), fontSize = 14.sp)
                            AuthField(confirmation, { confirmation = it.take(128) }, "Повторите пароль", !busy,
                                secret = true, keyboard = KeyboardType.Password, onDone = { continuePage() })
                        }
                        if (message.isNotEmpty()) Text(message, color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                        Spacer(Modifier.height(8.dp))
                        AccountPill(when (shown) {
                            AuthPage.Verify -> "Подтвердить"
                            AuthPage.Forgot -> "Отправить код"
                            AuthPage.Reset -> "Сохранить пароль"
                            else -> "Продолжить"
                        }, { continuePage() }, primary = true, enabled = !busy, loading = busy)
                        if (shown.emailEntry) {
                            Text(if (shown == AuthPage.RegisterEmail) "Или зарегистрируйся другим способом" else "Или войди другим способом",
                                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp))
                            AccountPill("Google", { launchAction("google") }, enabled = !busy, google = true)
                        }
                        if (shown == AuthPage.LoginPassword) {
                            TextButton(onClick = { switch(AuthPage.Forgot) }, enabled = !busy) { Text("Забыли пароль?", color = Color.White) }
                            TextButton(onClick = { switch(AuthPage.Verify) }, enabled = !busy) { Text("Подтвердить почту", color = Color.White) }
                        }
                        if (shown == AuthPage.Verify) TextButton(onClick = { launchAction("resend") }, enabled = !busy) {
                            Text("Отправить код повторно", color = Color.White)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.height(32.dp))
                    if (shown.emailEntry) Column(Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (shown == AuthPage.RegisterEmail) "Уже есть аккаунт?" else "Нет аккаунта?",
                            color = Color(0xFFB3B3B3), fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = { switch(if (shown == AuthPage.RegisterEmail) AuthPage.LoginEmail else AuthPage.RegisterEmail,
                            shown == AuthPage.RegisterEmail) }, enabled = !busy) {
                            Text(if (shown == AuthPage.RegisterEmail) "Войти" else "Зарегистрироваться",
                                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthField(
    value: String,
    onValueChange: (String) -> Unit,
    title: String,
    enabled: Boolean,
    keyboard: KeyboardType = KeyboardType.Text,
    secret: Boolean = false,
    showLabel: Boolean = true,
    onDone: () -> Unit = {}
) {
    val p = LocalPalette.current
    var focused by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (showLabel) Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        BasicTextField(value = value, onValueChange = onValueChange, enabled = enabled, singleLine = true,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                .onFocusChanged { focused = it.isFocused }
                .border(if (focused) 2.dp else 1.dp, if (focused) p.brand else Color(0xFF353535), RoundedCornerShape(4.dp))
                .semantics { this.contentDescription = title },
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp, fontFamily = ZiziFontFamily),
            cursorBrush = SolidColor(p.brand),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onDone() }),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart) { inner() }
            })
    }
}

private fun accountErrorMessage(error: Exception): String = when ((error as? AccountApiException)?.reason) {
    "invalid_credentials" -> "Почта или пароль неверны."
    "email_not_verified" -> "Сначала подтвердите почту: нажмите «Подтвердить почту» под формой входа."
    "invalid_email" -> "Проверьте адрес почты. В этой версии поддерживаются адреса латиницей."
    "password_length" -> "Пароль должен содержать от 12 до 128 символов."
    "invalid_code" -> "Код неверен, уже использован или истёк. Запросите новое письмо."
    "use_existing_sign_in" -> "Для этой почты уже есть аккаунт. Войдите прежним способом. Автоматически связывать аккаунты небезопасно."
    "google_email_use_password" -> "Для этого адреса Google используйте регистрацию по почте и паролю."
    "google_not_configured", "not_configured" -> "Этот способ входа ещё не настроен на сервере или в сборке."
    "rate_limited", "busy" -> "Слишком много попыток. Подождите несколько минут и повторите."
    "google_verification_failed" -> "Не удалось подтвердить вход через Google. Повторите выбор аккаунта."
    "session_reused" -> "Сессия отозвана для безопасности. Войдите заново."
    else -> "Не удалось завершить запрос. Проверьте интернет и повторите позже. Если письмо не пришло, запросите его повторно."
}
