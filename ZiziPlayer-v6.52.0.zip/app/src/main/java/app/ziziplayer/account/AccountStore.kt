package app.ziziplayer.account

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 6.50.0 — что приложение помнит о выборе аккаунта НА ЭТОМ телефоне.
 *
 * ГРАНИЦА ОТВЕТСТВЕННОСТИ
 *
 * Здесь лежит только решение человека: «войду» или «пока как гость». Ни библиотеки, ни треков, ни
 * истории — они по-прежнему в Room и никуда не переезжают. Это важно понимать буквально: пока
 * сервис аккаунтов не подключён, данные живут ровно там же, где жили в 6.49.0, и очистка данных
 * приложения их так же удалит. Окно входа само по себе ничего не сохраняет.
 *
 * ПОЧЕМУ SharedPreferences, А НЕ DataStore
 *
 * Причина та же, что у [app.ziziplayer.data.remote.ZiziInstall]: решение «показывать приветствие»
 * нужно ПЕРВОМУ кадру. DataStore отдаёт значение через suspend/Flow, то есть первый кадр пришлось
 * бы рисовать «ещё не знаю» — и человек увидел бы медиатеку, поверх которой через мгновение
 * прыгает приветственный экран. SharedPreferences читается синхронно, и этого мгновения не будет.
 *
 * Токенов здесь нет и не будет: когда появится настоящий вход, ключи сессии поедут в
 * защищённое хранилище, а не в общие настройки.
 */
class AccountStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AccountLocalState> = _state.asStateFlow()

    /** Первый кадр читает это, а не поток: значение уже в памяти к моменту вызова. */
    val initial: AccountLocalState get() = _state.value

    private fun read(): AccountLocalState {
        val stored = prefs.getString(KEY_MODE, null)
        val storedMode = runCatching { AccountGate.Mode.valueOf(stored ?: MODE_UNDECIDED) }
            .getOrDefault(AccountGate.Mode.UNDECIDED)
        return AccountLocalState(
            // A preference is not proof of a live session. Restore verifies with the server.
            mode = if (storedMode == AccountGate.Mode.SIGNED_IN) AccountGate.Mode.GUEST else storedMode,
            seenWelcomeRevision = prefs.getInt(KEY_SEEN, 0),
            displayName = prefs.getString(KEY_NAME, null)?.takeIf { it.isNotBlank() }
        )
    }

    private fun write(state: AccountLocalState) {
        prefs.edit()
            .putString(KEY_MODE, state.mode.name)
            .putInt(KEY_SEEN, state.seenWelcomeRevision)
            .putString(KEY_NAME, state.displayName.orEmpty())
            .apply()
        _state.value = state
    }

    /**
     * «Продолжить как гость». Отмечается и выбор, и увиденная ревизия приветствия — иначе окно
     * вернулось бы на следующем запуске и выбор оказался бы фикцией.
     */
    fun chooseGuest() = write(
        _state.value.copy(
            mode = AccountGate.Mode.GUEST,
            seenWelcomeRevision = AccountGate.WELCOME_REVISION
        )
    )

    /**
     * Отметить приветствие прочитанным, не меняя выбор.
     *
     * Нужно ровно одному сценарию: человек уже гость, мы показали ему НОВОЕ приветствие, он его
     * закрыл. Второй раз то же самое сообщение он видеть не должен.
     */
    fun markWelcomeSeen() = write(_state.value.copy(seenWelcomeRevision = AccountGate.WELCOME_REVISION))

    /**
     * Вход выполнен. Вызывать ТОЛЬКО после подтверждения сервером — не после нажатия кнопки.
     *
     * Пока сервис аккаунтов не подключён, вызывать это неоткуда, и это правильно: состояние
     * «вошёл» без сервера означало бы обещание сохранности, которого никто не выполняет.
     */
    fun markSignedIn(displayName: String?) = write(
        _state.value.copy(
            mode = AccountGate.Mode.SIGNED_IN,
            seenWelcomeRevision = AccountGate.WELCOME_REVISION,
            displayName = displayName?.trim()?.take(80)?.takeIf { it.isNotBlank() }
        )
    )

    /**
     * Выход. Возвращает телефон в гостевой режим, а не в UNDECIDED: человек уже знает про
     * аккаунты, и снова закрывать ему приложение приветствием незачем.
     *
     * Локальную библиотеку выход не трогает вообще — ни одной строки в Room.
     */
    fun signOut() = write(
        _state.value.copy(mode = AccountGate.Mode.GUEST, displayName = null)
    )

    private companion object {
        const val PREFS = "zizi_account"
        const val KEY_MODE = "mode"
        const val KEY_SEEN = "welcome_revision"
        const val KEY_NAME = "display_name"
        const val MODE_UNDECIDED = "UNDECIDED"
    }
}

/** Снимок локального решения. Никаких секретов: только режим, ревизия окна и имя для экрана. */
data class AccountLocalState(
    val mode: AccountGate.Mode = AccountGate.Mode.UNDECIDED,
    val seenWelcomeRevision: Int = 0,
    val displayName: String? = null
) {
    val isGuest: Boolean get() = mode != AccountGate.Mode.SIGNED_IN
    val showWelcome: Boolean get() = AccountGate.shouldShowWelcome(mode, seenWelcomeRevision)
}
