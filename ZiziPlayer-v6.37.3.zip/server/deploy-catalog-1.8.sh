#!/usr/bin/env bash
# Выкатка zizi_catalog 1.8 / zizi_guard 1.8 / zizi_resolver 1.6.2 — ключ на устройство.
# Запускать НА СЕРВЕРЕ, из папки, куда положены zizi_*.py и tools/.
#
# ЧЕМ ОТЛИЧАЕТСЯ ОТ 1.7 И ПОЧЕМУ ЭТО ВАЖНЕЕ САМОЙ ФИЧИ
#
# В 1.7 отсутствие врезки `include_router(catalog_router)` печаталось как ВНИМАНИЕ и выкатка
# продолжалась. Ровно это и произошло: штатный scp перезаписал zizi_resolver.py версией из
# архива, унёс врезку, скрипт предупредил в середине вывода и бодро рестартнул сервис. Итог —
# `Application startup complete` без ошибок и 404 на /catalog/health.
#
# Здесь такой проверки-предупреждения больше нет ни одной: любое несоответствие валит выкатку
# до рестарта. Проверка, которая не останавливает выкатку, — это не проверка, а комментарий.
set -euo pipefail
DEST=${DEST:-/opt/zizi}
SRC=${1:-./zizi_catalog.py}
GUARD=${GUARD:-./zizi_guard.py}
RESOLVER=${RESOLVER:-./zizi_resolver.py}
BASE=${BASE:-http://127.0.0.1:8080}

say() { printf '%s\n' "$*"; }
die() { printf 'ОТМЕНА: %s\n' "$*" >&2; exit 1; }

[ -f "$SRC" ]      || die "нет файла $SRC"
[ -f "$GUARD" ]    || die "нет файла $GUARD — zizi_catalog без него не поднимется"
[ -f "$RESOLVER" ] || die "нет файла $RESOLVER — в 1.6.2 он проверяет ключи устройств"

say "== синтаксис =="
python3 -c "import ast,sys;[ast.parse(open(f,encoding='utf-8').read()) for f in sys.argv[1:]]" \
  "$SRC" "$GUARD" "$RESOLVER" || die "синтаксическая ошибка в исходниках"

# ── врезка каталога. Проверяем ТО, ЧТО ПРИВЕЗЛИ, а не то, что лежит на сервере: файл из архива
# сейчас перезапишет живой, и если врезки нет в нём — она пропадёт.
grep -q 'include_router(catalog_router)' "$RESOLVER" \
  || die "в привезённом zizi_resolver.py нет app.include_router(catalog_router).
       Именно так 6.37.2 встал с 404 на /catalog/health при чистом старте.
       Добавь в конец файла:
         from zizi_catalog import router as catalog_router
         app.include_router(catalog_router)"

say "== тесты на этой машине =="
# Тест, который прошёл где-то ещё, про ЭТОТ сервер ничего не утверждает: здесь свой python3.
for t in tools/test_zizi_guard.py tools/test_zizi_device.py tools/test_catalog_wiring.py; do
  [ -f "$t" ] || die "нет $t — выкатка защиты без прогона её тестов не делается"
  python3 "$t" >/tmp/zizi-deploy-test.log 2>&1 || {
    tail -20 /tmp/zizi-deploy-test.log
    die "$t упал — сервис не тронут"
  }
  say "  ok  $t"
done

ts=$(date +%Y%m%d-%H%M%S)
for f in zizi_catalog.py zizi_guard.py zizi_resolver.py; do
  [ -f "$DEST/$f" ] && cp "$DEST/$f" "$DEST/$f.bak-$ts" && say "бэкап: $f.bak-$ts"
done
install -m 644 "$SRC"      "$DEST/zizi_catalog.py"
install -m 644 "$GUARD"    "$DEST/zizi_guard.py"
install -m 644 "$RESOLVER" "$DEST/zizi_resolver.py"
mkdir -p "$DEST/img" "$DEST/tools"
for t in tools/test_zizi_guard.py tools/test_zizi_device.py tools/test_catalog_wiring.py; do
  install -m 644 "$t" "$DEST/$t"
done
[ -d tools/_stub ] && mkdir -p "$DEST/tools/_stub" && install -m 644 tools/_stub/*.py "$DEST/tools/_stub/"

# ── переменные окружения. Ничего не дописываем сами: молча менять zizi.env — это тот же класс
# сюрприза, что и молча ронять роутер. Только говорим, что не задано и чем это обернётся.
env_missing=0
grep -q '^ZIZI_ADMIN_TOKEN=' "$DEST/zizi.env" 2>/dev/null || {
  say ""
  say "ПОДСКАЗКА: ZIZI_ADMIN_TOKEN не задан — /flush открывается токеном из APK."
  say "  echo \"ZIZI_ADMIN_TOKEN=\$(openssl rand -hex 24)\" >> $DEST/zizi.env"
  env_missing=1
}
grep -q '^ZIZI_DEVICE_KEY=' "$DEST/zizi.env" 2>/dev/null || {
  say ""
  say "ПОДСКАЗКА: ZIZI_DEVICE_KEY не задан — ключи устройств подписываются производным от"
  say "ZIZI_TOKEN. Работает, но смена ZIZI_TOKEN погасит все выданные ключи сразу."
  say "  echo \"ZIZI_DEVICE_KEY=\$(openssl rand -hex 32)\" >> $DEST/zizi.env"
  env_missing=1
}

say ""
say "== рестарт =="
systemctl restart zizi-resolver
sleep 2

# ── приёмка. Каталог обязан ОТВЕТИТЬ: 404 здесь означает, что роутер снова не смонтирован,
# и это провал выкатки, а не мелочь в конце вывода.
code=$(curl -s -o /tmp/zizi-health.json -w '%{http_code}' "$BASE/catalog/health" || true)
[ "$code" = "200" ] || {
  say "/catalog/health -> HTTP $code"
  journalctl -u zizi-resolver -n 20 --no-pager || true
  die "каталог не отвечает после рестарта. Бэкапы: $DEST/*.bak-$ts"
}
say "health: $(cat /tmp/zizi-health.json)"

ver=$(python3 -c 'import json;print(json.load(open("/tmp/zizi-health.json")).get("version",""))')
[ "$ver" = "1.8" ] || die "сервис ответил версией каталога '$ver', ожидалась 1.8 — рестарт поднял старый файл"

# Выдача ключа обязана быть закрытой. Если сюда пускают без токена — вся затея отменяется,
# потому что утёкший токен из APK перестаёт быть узким местом.
code=$(curl -s -o /dev/null -w '%{http_code}' -H 'X-Zizi-Install: deploy-selfcheck-0001' "$BASE/auth/device" || true)
[ "$code" = "401" ] || [ "$code" = "429" ] \
  || die "/auth/device без токена ответил $code, ожидался 401. Проверь ZIZI_TOKEN в zizi.env"
say "  ok  /auth/device без токена -> $code"

say ""
say "Готово. Дальше по цифрам в /catalog/health:"
say "  guard.anon_pct   -> 0   можно ZIZI_CATALOG_TOKEN_MODE=require"
say "  guard.device_pct -> 100 можно ZIZI_DEVICE_MODE=require  (после этого токен из APK бесполезен)"
[ "$env_missing" = 1 ] && say "" && say "Подсказки выше не блокируют работу, но их стоит закрыть."
exit 0
