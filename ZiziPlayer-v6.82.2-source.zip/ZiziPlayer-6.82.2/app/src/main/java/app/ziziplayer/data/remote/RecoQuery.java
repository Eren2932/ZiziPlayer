package app.ziziplayer.data.remote;

import java.util.List;
import java.util.Locale;

/**
 * Запись профиля вкуса в параметры `/reco/home`. Чистый текст без Android: проверяется на JVM.
 *
 * Разделители протокола — `|` между элементами и `~` между ссылкой и весом. Они вычищаются из
 * имён ДО склейки, иначе артист «A|B» превратился бы в двух. Вес всегда с точкой, иначе в русской
 * локали сервер получил бы «0,873» и молча заменил его единицей.
 */
public final class RecoQuery {
    private RecoQuery() {}

    /** Имя для передачи по сети: без разделителей и управляющих символов, не длиннее 60. */
    public static String safeName(String name) {
        if (name == null) return "";
        String clean = name.replaceAll("[|~\\p{Cntrl}]+", " ").replaceAll("\\s+", " ").trim();
        return clean.length() <= 60 ? clean : clean.substring(0, 60).trim();
    }

    /**
     * Ссылка на артиста по имени. Имя из одних цифр («070», «50») сервер принял бы за id Deezer,
     * поэтому оно уходит с префиксом `n:`.
     */
    public static String name(String name) {
        String clean = safeName(name);
        return !clean.isEmpty() && clean.chars().allMatch(c -> c >= '0' && c <= '9') ? "n:" + clean : clean;
    }

    /** Строка сида: `ref~0.873`. */
    public static String seed(String ref, double weight) {
        double clamped = Double.isNaN(weight) ? 1.0 : Math.max(0.05, Math.min(1.0, weight));
        return safeName(ref) + "~" + String.format(Locale.ROOT, "%.3f", clamped);
    }

    /** Склейка элементов через `|`; пустые отбрасываются, длина списка ограничена. */
    public static String join(List<String> items, int limit) {
        StringBuilder out = new StringBuilder();
        int taken = 0;
        for (String item : items) {
            String clean = safeName(item);
            if (clean.isEmpty()) continue;
            if (taken++ >= limit) break;
            if (out.length() > 0) out.append('|');
            out.append(clean);
        }
        return out.toString();
    }
}
