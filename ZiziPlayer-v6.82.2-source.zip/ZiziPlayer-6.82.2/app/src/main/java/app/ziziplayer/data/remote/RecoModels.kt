package app.ziziplayer.data.remote

import androidx.compose.runtime.Immutable

/**
 * Серверная «Главная» (Reco 1): профиль вкуса уходит одним запросом, полки приходят готовыми.
 *
 * Профиль компактен намеренно: артисты и веса, а не история. Названий треков, времени и
 * длительностей на сервере нет ни в запросе, ни в логе.
 */
@Immutable
data class RecoSeed(val ref: String, val weight: Double)

@Immutable
data class RecoProfile(
    val seeds: List<RecoSeed>,
    val known: List<String>,
    val negative: List<String>,
    val recent: List<String>,
    /** "slowed" | "sped" | "" */
    val version: String
) {
    /** Поля тела POST `/reco/home` (не query: см. BrowseHttp.post). Значения очищены от разделителей протокола. */
    fun queryParams(): Map<String, String> = linkedMapOf(
        "s" to seeds.take(8).joinToString("|") { RecoQuery.seed(it.ref, it.weight) },
        "k" to RecoQuery.join(known, 40),
        "x" to RecoQuery.join(negative, 20),
        "r" to RecoQuery.join(recent, 3),
        "v" to version
    ).filterValues { it.isNotEmpty() }

    /**
     * Поля тела POST `/reco/feed` (6.82.0): тот же профиль плюс курсор `c` и размер страницы `n`.
     * Профиль на всё время ленты ОБЯЗАН быть одним и тем же: сервер сверяет его отпечаток с сессией
     * и при любом расхождении начинает ленту заново (restarted).
     */
    fun feedParams(cursor: String?, pageSize: Int): Map<String, String> {
        val fields = LinkedHashMap(queryParams())
        if (!cursor.isNullOrEmpty()) fields["c"] = cursor
        fields["n"] = pageSize.coerceIn(10, 50).toString()
        return fields
    }
}

enum class RecoShelfKind { ALBUMS, TRACKS, ARTISTS }

@Immutable
data class RecoCard(val track: RemoteTrack? = null, val collection: RemoteCollection? = null)

@Immutable
data class RecoShelf(
    val id: String,
    val kind: RecoShelfKind,
    val title: String,
    /** Артист-якорь полки «Похоже на»; у остальных полок null. */
    val anchorName: String?,
    val anchorArt: String?,
    val cards: List<RecoCard>
)

/**
 * [complete] = false: сервер уложился в бюджет не целиком; остаток он достроит в кэше.
 * [retryMs] — через сколько сервер просит спросить снова (`retry_ms`); 0, если не просит.
 */
@Immutable
data class RecoResult(val shelves: List<RecoShelf>, val complete: Boolean, val cold: Boolean, val retryMs: Long = 0L)

/**
 * Страница бесконечной ленты `POST /reco/feed` (6.82.0).
 * [cursor] отдаётся обратно в следующем запросе как есть; [more] = false — лента кончилась;
 * [restarted] — сервер потерял сессию и начал с головы, повторы режет клиент.
 */
@Immutable
data class RecoFeedPage(
    val tracks: List<RemoteTrack>,
    val cursor: String?,
    val more: Boolean,
    val complete: Boolean,
    val cold: Boolean,
    val restarted: Boolean,
    val retryMs: Long
)
