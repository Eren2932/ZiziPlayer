package app.ziziplayer.ui;

import java.util.Random;

/** Executed against production Java, both by offline preflight and the Gradle JUnit wrapper. */
public final class CameraMorph6692Checks {
    private static int assertions;
    private static void ok(boolean condition, String why) {
        assertions++;
        if (!condition) throw new AssertionError(why + " (#" + assertions + ")");
    }
    private static void near(float a, float b, float epsilon, String why) {
        ok(Float.isFinite(a) && Math.abs(a-b) <= epsilon, why + ": " + a + " vs " + b);
    }
    private static CameraMorphGeometry.Frame frame(float f, float s, CameraMorphGeometry.Target t) {
        return CameraMorphGeometry.frame(716, 315.04f, f, s, 540, 164, 8, 369.04f, 110, t);
    }
    public static void main(String[] args) {
        assertions = 0;
        CameraMorphGeometry.Target center = new CameraMorphGeometry.Target(513,48,567,102);
        CameraMorphGeometry.Target corner = new CameraMorphGeometry.Target(30,48,84,102);
        CameraMorphGeometry.Target pill = new CameraMorphGeometry.Target(478,48,602,102);
        ok(CameraMorphGeometry.supported(center,1080,2400,110,3,true),"round path accepted");
        ok(CameraMorphGeometry.supported(corner,1080,2400,110,3,true),"corner hole accepted");
        ok(CameraMorphGeometry.supported(pill,1080,2400,110,3,true),"compact pill accepted");
        ok(CameraMorphGeometry.supported(center,1080,2400,110,3,false),"compact rect approximation accepted");
        ok(!CameraMorphGeometry.supported(pill,1080,2400,110,3,false),"unknown capsule not guessed");
        ok(!CameraMorphGeometry.supported(new CameraMorphGeometry.Target(400,0,680,110),1080,2400,110,3,true),"wide notch rejected");
        ok(!CameraMorphGeometry.supported(new CameraMorphGeometry.Target(510,0,570,110),1080,2400,110,3,false),"safe inset is not a diameter");
        ok(!CameraMorphGeometry.supported(center,2400,1080,110,3,true),"landscape fallback");
        ok(!CameraMorphGeometry.supported(center,1080,2400,0,3,true),"hidden status fallback");
        ok(!CameraMorphGeometry.supported(null,1080,2400,110,3,true),"absent cutout fallback");
        ok(!CameraMorphGeometry.supported(new CameraMorphGeometry.Target(Float.NaN,48,567,102),1080,2400,110,3,true),"NaN rejected");
        ok(!CameraMorphGeometry.supported(center,1080,2400,110,0,true),"bad density rejected");
        // The existing first-stage geometry must not regress, including reverse scroll.
        for (int i=0;i<=1000;i++) {
            float f=i/1000f;
            CameraMorphGeometry.Frame p=frame(f,0,center);
            near(p.width,CollectionCollapseMath.coverSize(716,315.04f,f),.001f,"first phase size");
            near(p.top(),164,.001f,"first phase top anchored");
            near(p.imageAlpha,1,0,"first phase opaque");
            near(p.anchorAlpha,0,0,"no artificial camera when expanded");
            ok(p.radius>=0 && p.radius<=p.width/2+.001,"bounded radius");
        }
        CameraMorphGeometry.Frame handoff=frame(1,0,center), next=frame(1,.1f,center);
        near((next.width-handoff.width)/.1f,-1,.004f,"size velocity continuous at scroll handoff");
        near((next.cy-handoff.cy)/.1f,-.5f,.004f,"center velocity continuous at handoff");
        for (CameraMorphGeometry.Target target : new CameraMorphGeometry.Target[]{center,corner,pill,null}) {
            float previousW=Float.POSITIVE_INFINITY, previousY=Float.POSITIVE_INFINITY;
            int neckFrames=0;
            CameraMorphGeometry.Frame[] forward = new CameraMorphGeometry.Frame[2001];
            for(int i=0;i<=2000;i++) {
                float s=369.04f*i/2000f;
                CameraMorphGeometry.Frame p=frame(1,s,target);
                forward[i] = p;
                ok(Float.isFinite(p.cx+p.cy+p.width+p.height+p.radius),"finite frame");
                ok(p.width<=previousW+.001 && p.cy<=previousY+.001,"monotone size and vertical motion");
                ok(p.width>=0 && p.height>=0 && p.radius>=0 && p.radius<=Math.min(p.width,p.height)/2+.001,"shape bounded");
                ok(p.imageAlpha>=0 && p.imageAlpha<=1 && p.topBlack>=p.bottomBlack,"bounded alpha and blackening");
                // Metadata follows actual list pixels; overlay never falls onto its title.
                ok(p.cy+p.height/2 <= 164+315.04f+70-s+.01,"does not overlap scrolling title");
                float[] neck=CameraMorphGeometry.bridge(target,p);
                if(neck!=null) {
                    neckFrames++;
                    for(float v:neck)ok(Float.isFinite(v),"finite bridge");
                    float r1=Math.min(target.width(),target.height())/2;
                    float r2=Math.min(p.width,p.height)/2;
                    near((float)Math.hypot(neck[0]-target.cx(),neck[1]-target.cy()),r1,.002f,"neck target endpoint");
                    near((float)Math.hypot(neck[6]-p.cx,neck[7]-p.cy),r2,.002f,"neck source endpoint");
                    float tx=neck[2]-neck[0],ty=neck[3]-neck[1];
                    near(((neck[0]-target.cx())*tx+(neck[1]-target.cy())*ty)/r1,0,.0002f,"target tangent radial error < .0002 px");
                    float sx=neck[4]-neck[6],sy=neck[5]-neck[7];
                    near(((neck[6]-p.cx)*sx+(neck[7]-p.cy)*sy)/r2,0,.0002f,"source tangent radial error < .0002 px");
                }
                if(target==null) { near(p.anchorAlpha,0,0,"fallback never draws camera");ok(neck==null,"fallback no bridge"); }
                previousW=p.width; previousY=p.cy;
            }
            for (int i=2000; i>=0; i--) {
                CameraMorphGeometry.Frame reverse=frame(1,369.04f*i/2000f,target), saved=forward[i];
                near(reverse.cx,saved.cx,0,"reverse x");
                near(reverse.cy,saved.cy,0,"reverse y");
                near(reverse.width,saved.width,0,"reverse width");
                near(reverse.height,saved.height,0,"reverse height");
                near(reverse.radius,saved.radius,0,"reverse rounding");
                near(reverse.imageAlpha,saved.imageAlpha,0,"reverse opacity");
                near(reverse.topBlack,saved.topBlack,0,"reverse top shading");
                near(reverse.bottomBlack,saved.bottomBlack,0,"reverse bottom shading");
                near(reverse.anchorAlpha,saved.anchorAlpha,0,"reverse anchor");
            }
            ok(target==null ? neckFrames==0 : neckFrames>25,"bridge must actually appear for supported targets");
            CameraMorphGeometry.Frame end=frame(1,369.04f,target), deep=frame(1,9000,target);
            near(end.anchorAlpha,target==null?0:1,.00001f,"final system contour visibility");
            if(target!=null) {
                near(end.topBlack,1,.00001f,"black at completion (top)");
                near(end.bottomBlack,1,.00001f,"black at completion (bottom)");
                near(end.radius,Math.min(target.width(),target.height())/2,.001f,"fully rounded at contour");
            }
            near(end.imageAlpha,0,.00001f,"no residual artwork at completion");
            near(end.cx,deep.cx,0,"deep scroll endpoint stable");
            near(end.cy,deep.cy,0,"deep scroll endpoint stable y");
            near(end.width,target==null?0:target.width(),.001f,"actual target width");
            near(end.height,target==null?0:target.height(),.001f,"actual target height");
            near(end.cx,target==null?540:target.cx(),.001f,"actual target x");
            near(end.cy,target==null?110:target.cy(),.001f,"actual target y");
        }
        // Density/viewport/property sweep, including tablet capped artwork and compact capsules.
        Random random=new Random(6692);
        for(int n=0;n<400;n++) {
            float density=.75f+random.nextFloat()*3.5f;
            float widthDp=280+random.nextFloat()*560;
            float maximum=CollectionHeaderGeometry.COVER_SIZE*CollectionHeaderGeometry.unit(widthDp)*density;
            float minimum=Math.max(64*density,maximum*.44f);
            float unit=CollectionHeaderGeometry.unit(widthDp)*density;
            float top=CollectionHeaderGeometry.COVER_TOP*unit, status=30*density;
            float titleGap=CollectionHeaderGeometry.COVER_TITLE_GAP*unit;
            float diameter=(8+random.nextFloat()*12)*density;
            float cameraX=(20+random.nextFloat()*(widthDp-40))*density;
            CameraMorphGeometry.Target t=new CameraMorphGeometry.Target(cameraX-diameter/2, status/2-diameter/2,
                cameraX+diameter/2,status/2+diameter/2);
            float last=maximum;
            for(int step=0;step<=100;step++) {
                float scroll=(minimum+top)*step/100f;
                CameraMorphGeometry.Frame f=CameraMorphGeometry.frame(maximum,minimum,1,scroll,widthDp*density/2,
                    status+top,3*density,minimum+top,status,t);
                ok(f.width<=last+.001 && f.width>=diameter-.001,"random monotone width");
                ok(Float.isFinite(f.left()+f.top()+f.radius),"random finite geometry");
                ok(f.top()+f.height <= status+top+minimum+titleGap-scroll+.01f,
                    "random artwork never crosses the scrolling title");
                last=f.width;
            }
        }
        // Zero-velocity join at the staging point and at the final contour.
        float join=369.04f*.75f, eps=.1f;
        CameraMorphGeometry.Frame a=frame(1,join-eps,center), b=frame(1,join,center), c=frame(1,join+eps,center);
        near((b.top()-a.top())/eps,(c.top()-b.top())/eps,.005f,"staging top is C1 continuous");
        CameraMorphGeometry.Frame e=frame(1,369.04f,center), prev=frame(1,369.04f-eps,center);
        near((e.width-prev.width)/eps,0,.004f,"arrival size velocity tends to zero");
        near((e.cy-prev.cy)/eps,0,.004f,"arrival center velocity tends to zero");
        near(CameraMorphGeometry.unit(Float.NaN),0,0,"NaN progress clamped");
        near(CameraMorphGeometry.unit(-1),0,0,"negative progress clamped");
        near(CameraMorphGeometry.unit(2),1,0,"overscroll clamped");
        System.out.println("PASS: " + assertions + " production geometry assertions (not Android rendering)");
    }
}
