package app.ziziplayer.playback.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** PCM regression tests: real engine, real filters, no Android stubs or simulated DSP. */
class DspHeadroomTest {
    private val rate = 48000
    private val bands = listOf(10f, 10f, 6f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)
    private fun boost(auto: Boolean) = DspConfig(enabled = true, bandsDb = bands, autoGain = auto)

    /** Run one second and measure only the settled last half. Keep the limiter enabled. */
    private fun level(engine: DspEngine, freq: Float): Float {
        val pcm = FloatArray(rate * 2) { i ->
            (0.01 * sin(2.0 * Math.PI * freq * (i / 2) / rate)).toFloat()
        }
        val peak = engine.process(pcm, rate)
        assertTrue("test signal must not clip: $peak", peak < 0.9f)
        assertEquals("measure headroom, not limiter compression", 1f, engine.limiterGain, 1e-6f)
        var sum = 0.0
        for (i in rate until pcm.size) sum += pcm[i].toDouble() * pcm[i]
        val result = sqrt(sum / rate).toFloat()
        assertTrue("signal must remain audible and finite: $result", result > 0f && result.isFinite())
        return result
    }

    private fun level(c: DspConfig, freq: Float): Float =
        level(DspEngine(rate, 2).apply { setConfig(c) }, freq)

    @Test fun `neutral and cut only configs do not receive automatic gain`() {
        val neutral = DspConfig(enabled = true)
        val cut = neutral.copy(bandsDb = List(DspConfig.BAND_COUNT) { -6f })
        for (c in listOf(neutral, cut)) {
            assertEquals(0f, DspResponse.autoGainDb(c), 1e-6f)
            assertEquals(level(c.copy(autoGain = false), 1000f), level(c, 1000f), 1e-6f)
        }
    }

    @Test fun `moderate boost compensation follows response and respects headroom cap`() {
        val moderate = boost(true).copy(bandsDb = listOf(0f, 4f) + List(8) { 0f })
        val peak = DspResponse.peakBoostDb(moderate)
        assertTrue(peak > 3.9f && peak < 4.1f)
        assertEquals(-peak, DspResponse.autoGainDb(moderate), 1e-5f)
        // Current product policy caps automatic attenuation at 12 dB, not unlimited gain.
        assertTrue(DspResponse.peakBoostDb(boost(true)) > 12f)
        assertEquals(-12f, DspResponse.autoGainDb(boost(true)), 1e-5f)
        assertEquals(0f, DspResponse.autoGainDb(boost(false)), 1e-6f)
        assertEquals(0f, DspResponse.autoGainDb(boost(true).copy(enabled = false)), 1e-6f)
    }

    @Test fun `automatic headroom scales actual PCM uniformly without changing EQ shape`() {
        val off = boost(false)
        val on = off.copy(autoGain = true)
        val attenuation = 10f.pow(DspResponse.autoGainDb(on) / 20f)
        assertTrue("must actually attenuate", attenuation < 0.5f)
        for (freq in floatArrayOf(60f, 1000f, 6000f)) {
            val raw = level(off, freq)
            val compensated = level(on, freq)
            assertEquals("$freq Hz: actual attenuation", attenuation, compensated / raw, 0.002f)
            // Independently verify PCM against the steady-state filter response in dB.
            val db = DspResponse.curveDb(on, floatArrayOf(freq))[0] + DspResponse.effectivePreampDb(on)
            val expected = (0.01 / sqrt(2.0)).toFloat() * 10f.pow(db / 20f)
            assertEquals("$freq Hz: predicted vs actual response", expected, compensated, expected * 0.01f)
        }
    }

    @Test fun `manual preamp adds to automatic headroom instead of replacing it`() {
        val base = boost(true)
        val manual = base.copy(preampDb = -3f)
        assertEquals(DspResponse.autoGainDb(base) - 3f, DspResponse.effectivePreampDb(manual), 1e-5f)
        for (freq in floatArrayOf(60f, 6000f)) {
            assertEquals(10f.pow(-3f / 20f), level(manual, freq) / level(base, freq), 0.002f)
        }
    }

    @Test fun `toggling headroom on a running engine converges both ways`() {
        val off = boost(false)
        val on = off.copy(autoGain = true)
        val engine = DspEngine(rate, 2)
        engine.setConfig(off)
        val original = level(engine, 60f)
        engine.setConfig(on)
        val compensated = level(engine, 60f)
        assertEquals(10f.pow(DspResponse.autoGainDb(on) / 20f), compensated / original, 0.002f)
        engine.setConfig(off)
        assertEquals("switching off must restore prior EQ level", original, level(engine, 60f), original * 0.002f)
    }

    @Test fun `legacy settings without ag preserve actual PCM gain`() {
        val legacy = DspCodec.decode("v1|on=1;bands=10,10,6,0,0,0,0,0,0,0;lim=1")
        assertFalse(legacy.autoGain)
        for (freq in floatArrayOf(60f, 6000f)) {
            assertEquals(level(boost(false), freq), level(legacy, freq), 1e-6f)
        }
    }

    @Test fun `codec preserves explicit headroom modes and their PCM output`() {
        for (auto in listOf(false, true)) {
            val original = boost(auto)
            val restored = DspCodec.decode(DspCodec.encode(original))
            assertEquals(auto, restored.autoGain)
            assertTrue(abs(level(original, 60f) - level(restored, 60f)) < 1e-6f)
        }
    }
}
