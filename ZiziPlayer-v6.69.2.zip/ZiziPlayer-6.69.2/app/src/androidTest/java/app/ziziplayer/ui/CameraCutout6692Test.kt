package app.ziziplayer.ui

import android.graphics.Insets
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.DisplayCutout
import androidx.test.filters.SdkSuppress
import app.ziziplayer.ui.components.cameraCutoutSnapshot
import org.junit.Assert.*
import org.junit.Test

/** Runs on Android, including API 28. Source scanning cannot detect NoSuchMethodError. */
@SdkSuppress(minSdkVersion = 28)
class CameraCutout6692Test {
    @Suppress("DEPRECATION")
    private fun cutout(vararg bounds: Rect) = DisplayCutout(Rect(0, 110, 0, 0), bounds.toList())

    @Test fun api28CompactBoundsAreReadWithoutApi29Methods() {
        val result = cameraCutoutSnapshot(cutout(Rect(513, 48, 567, 102)), 1080, 2400, 110, 3f)
        assertNotNull(result.target)
        assertNotNull(result.outline)
        assertFalse(result.exact) // The API-28 public constructor supplies no path.
        assertEquals(513f, result.target!!.left, 0f)
        assertEquals(48f, result.target!!.top, 0f)
    }

    @Test fun unsafeOrAbsentGeometryDoesNotInventACamera() {
        assertNull(cameraCutoutSnapshot(null, 1080, 2400, 110, 3f).target)
        assertNull(cameraCutoutSnapshot(cutout(Rect(400, 0, 680, 110)), 1080, 2400, 110, 3f).target)
        assertNull(cameraCutoutSnapshot(cutout(Rect(30, 1800, 84, 1854)), 1080, 2400, 110, 3f).target)
        assertNull(cameraCutoutSnapshot(cutout(Rect(400, 0, 680, 110), Rect(513, 48, 567, 102)),
            1080, 2400, 110, 3f).target)
    }

    @Test fun otherWindowCoordinateSystemsAreRejected() {
        val c = cutout(Rect(513, 48, 567, 102))
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 110, 3f, multiWindow = true).target)
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 110, 3f, screenX = 12).target)
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 110, 3f, screenY = 12).target)
        assertNull(cameraCutoutSnapshot(c, 2400, 1080, 110, 3f).target)
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 0, 3f).target)
    }

    @Test
    @SdkSuppress(minSdkVersion = 33)
    fun exactPathRefinesLooseBoundsWithoutMutatingTheFrameworkPath() {
        val native = Path().apply { addOval(513f, 48f, 567f, 102f, Path.Direction.CW) }
        val c = DisplayCutout.Builder().setSafeInsets(Insets.of(0, 110, 0, 0))
            .setBoundingRectTop(Rect(500, 32, 580, 110)).setCutoutPath(native).build()
        val before = RectF().also { native.computeBounds(it, true) }
        repeat(3) {
            val result = cameraCutoutSnapshot(c, 1080, 2400, 110, 3f)
            assertTrue(result.exact)
            assertEquals(513f, result.target!!.left, .01f)
            assertEquals(48f, result.target!!.top, .01f)
            assertEquals(567f, result.target!!.right, .01f)
            assertEquals(102f, result.target!!.bottom, .01f)
        }
        val after = RectF().also { native.computeBounds(it, true) }
        assertEquals(before, after)
    }
}
