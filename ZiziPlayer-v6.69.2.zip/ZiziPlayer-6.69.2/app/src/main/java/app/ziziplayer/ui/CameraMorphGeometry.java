package app.ziziplayer.ui;

/** 6.69.2. Pure pixel geometry; no Android, animation clock, device-name table or I/O. */
public final class CameraMorphGeometry {
    private CameraMorphGeometry() {}

    public static final class Target {
        public final float left, top, right, bottom;
        public Target(float left, float top, float right, float bottom) {
            this.left = left; this.top = top; this.right = right; this.bottom = bottom;
        }
        public float width() { return right - left; }
        public float height() { return bottom - top; }
        public float cx() { return (left + right) * .5f; }
        public float cy() { return (top + bottom) * .5f; }
    }

    /** Conservative admission, not a claim that an OEM bounding rect is the physical hole. */
    public static boolean supported(Target t, float width, float height, float status, float density,
            boolean exactPath) {
        if (t == null || !finite(t.left, t.top, t.right, t.bottom, width, height, status, density)
                || width <= 0 || height <= width || status <= 0 || density <= 0) return false;
        float w = t.width(), h = t.height();
        if (t.left < 0 || t.top <= 0 || t.right > width || t.bottom > status + 8 * density
                || t.top >= status || w < 4 * density || h < 4 * density
                || w > Math.min(width * .28f, 104 * density) || h > 64 * density) return false;
        float aspect = w / h;
        // A wide notch / waterfall / top-to-hole safe-inset rectangle is NOT a round camera.
        return exactPath ? aspect >= .65f && aspect <= 3f
                : t.top > 0 && aspect >= .8f && aspect <= 1.25f && w <= 48 * density;
    }

    public static final class Frame {
        public final float cx, cy, width, height, radius, progress;
        public final float imageAlpha, topBlack, bottomBlack, anchorAlpha;
        Frame(float cx, float cy, float width, float height, float radius, float progress,
                float imageAlpha, float topBlack, float bottomBlack, float anchorAlpha) {
            this.cx = cx; this.cy = cy; this.width = width; this.height = height;
            this.radius = radius; this.progress = progress; this.imageAlpha = imageAlpha;
            this.topBlack = topBlack; this.bottomBlack = bottomBlack; this.anchorAlpha = anchorAlpha;
        }
        public float left() { return cx - width * .5f; }
        public float top() { return cy - height * .5f; }
    }

    public static float unit(float x) {
        return Float.isFinite(x) ? Math.max(0f, Math.min(1f, x)) : 0f;
    }
    public static float smooth(float x) { float t = unit(x); return t * t * (3f - 2f * t); }
    private static float positive(float x) { return Float.isFinite(x) ? Math.max(0f, x) : 0f; }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static boolean finite(float... xs) {
        for (float x : xs) if (!Float.isFinite(x)) return false;
        return true;
    }

    /** Monotone cubic Hermite: match the incoming scroll velocity, stop without overshoot.
     * velocity is pixels / scroll-pixel. Limiting the initial tangent to 3*delta is sufficient
     * for monotonicity when the outgoing tangent is zero.
     */
    public static float hermite(float start, float end, float velocity, float travel, float progress) {
        float t = unit(progress), delta = end - start;
        float tangent = velocity * positive(travel);
        if (tangent * delta <= 0) tangent = 0;
        else tangent = Math.copySign(Math.min(Math.abs(tangent), 3f * Math.abs(delta)), delta);
        float t2 = t * t, t3 = t2 * t;
        float value = (2*t3 - 3*t2 + 1)*start + (t3 - 2*t2 + t)*tangent + (-2*t3 + 3*t2)*end;
        return Math.max(Math.min(start, end), Math.min(Math.max(start, end), value));
    }

    /** Two existing scroll phases, one reversible picture. The first phase continues to consume
     * the exact same pixel range as 6.69.1; the second uses the list's real offset, not a timer.
     * During phase one d(size)/ds=-1 and d(centerY)/ds=-.5. Hermite preserves those derivatives
     * at the handoff for ordinary compact holes. No new nested scroller is introduced.
     */
    public static Frame frame(float maximum, float minimum, float fraction, float scroll,
            float centerX, float coverTop, float initialRadius, float travel, float fallbackY,
            Target target) {
        maximum = positive(maximum);
        minimum = Math.min(maximum, positive(minimum));
        scroll = positive(scroll);
        float f = scroll > 0 ? 1f : unit(fraction);
        float startSize = lerp(maximum, minimum, f);
        float p = unit(scroll / Math.max(1f, positive(travel)));
        float endW = target == null ? 0f : positive(target.width());
        float endH = target == null ? 0f : positive(target.height());
        float endX = target == null ? centerX : target.cx();
        float endY = target == null ? fallbackY : target.cy();
        float w = hermite(startSize, endW, -1f, travel, p);
        float h = hermite(startSize, endH, -1f, travel, p);
        float x = lerp(centerX, endX, smooth(p));
        float y;
        if (target == null) {
            y = hermite(coverTop + startSize * .5f, endY, -.5f, travel, p);
        } else {
            // First shrink below the status bar, then enter the hole as a compact black shape.
            // Both top segments have zero endpoint slope. This avoids a wide artwork cap being
            // chopped by the narrow status-bar safety corridor, especially on corner cameras.
            float stagingTop = Math.min(coverTop, fallbackY);
            float top = p <= .75f ? lerp(coverTop, stagingTop, smooth(p / .75f))
                    : lerp(stagingTop, target.top, smooth((p - .75f) / .25f));
            y = top + h * .5f;
        }
        float radius = lerp(Math.min(positive(initialRadius), startSize * .5f), startSize * .5f, smooth(f));
        radius = startSize > 0 ? radius * Math.min(w, h) / startSize : 0f;
        float alpha = 1f - smooth((p - (target == null ? .35f : .90f)) / (target == null ? .65f : .10f));
        return new Frame(x, y, w, h, radius, p, alpha,
                target == null ? 0f : smooth(p / .18f),
                target == null ? 0f : smooth((p - .12f) / .70f),
                target == null ? 0f : smooth(p / .18f));
    }

    /** Cubic metaball neck between compact target and circular artwork. Points are
     * P1, C1, C2, P2, P3, C3, C4, P4. Its ends lie on the circles; cubic tangents
     * agree with the circles. Null for containment, zero sizes or an excessive gap.
     */
    public static float[] bridge(Target target, Frame frame) {
        if (target == null || frame.progress <= 0 || frame.progress >= 1) return null;
        double x1 = target.cx(), y1 = target.cy(), x2 = frame.cx, y2 = frame.cy;
        double r1 = Math.min(target.width(), target.height()) * .5;
        double r2 = Math.min(frame.width, frame.height) * .5;
        double d = Math.hypot(x2 - x1, y2 - y1);
        if (r1 <= .1 || r2 <= .1 || !Double.isFinite(d)
                || d <= Math.abs(r1 - r2) + .01 || d > r1 + r2 + 4*r1) return null;
        double u1 = 0, u2 = 0;
        if (d < r1 + r2) {
            u1 = acos((r1*r1 + d*d - r2*r2) / (2*r1*d));
            u2 = acos((r2*r2 + d*d - r1*r1) / (2*r2*d));
        }
        double axis = Math.atan2(y2 - y1, x2 - x1), a = acos((r1 - r2) / d);
        // Bring the neck in smoothly at the distance limit as well as at scroll start.
        double strength = .5 * smooth((float)((r1 + r2 + 4*r1 - d) / (2*r1)));
        double a1 = axis + u1 + (a - u1)*strength;
        double b1 = axis - u1 - (a - u1)*strength;
        double a2 = axis + Math.PI - u2 - (Math.PI - u2 - a)*strength;
        double b2 = axis - Math.PI + u2 + (Math.PI - u2 - a)*strength;
        float[] q = new float[16];
        point(q, 0, x1, y1, r1, a1);
        point(q, 6, x2, y2, r2, a2);
        point(q, 8, x2, y2, r2, b2);
        point(q, 14, x1, y1, r1, b1);
        double handle = Math.min(strength * 2.4,
                Math.hypot(q[0]-q[6], q[1]-q[7]) / (r1+r2));
        handle *= Math.min(1, d*2 / (r1+r2));
        point(q, 2, q[0], q[1], r1*handle, a1-Math.PI/2);
        point(q, 4, q[6], q[7], r2*handle, a2+Math.PI/2);
        point(q, 10, q[8], q[9], r2*handle, b2-Math.PI/2);
        point(q, 12, q[14], q[15], r1*handle, b1+Math.PI/2);
        return q;
    }
    private static double acos(double x) { return Math.acos(Math.max(-1, Math.min(1, x))); }
    private static void point(float[] q, int i, double x, double y, double r, double angle) {
        q[i] = (float)(x + r*Math.cos(angle)); q[i+1] = (float)(y + r*Math.sin(angle));
    }
}
