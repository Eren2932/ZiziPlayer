package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Read the Activity's LocalView before entering the dialog's separate window. */
@Composable
internal fun CameraMorphDiagnosticsDialog(onDismiss: () -> Unit) {
    val camera = rememberCameraCutout()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Слияние обложки с камерой") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SelectionContainer { Text(camera.report()) }
                Spacer(Modifier.height(12.dp))
                Text("Контур виден только на экранах подборок. Бирюзовый — форма системы, " +
                    "розовый — её границы. Сравнивай с отверстием прямо на телефоне. " +
                    "Проверка временная: выключается здесь или после перезапуска приложения.")
                if (CameraMorphDebug.outlineEnabled) Text("Проверочный контур сейчас включён.")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                CameraMorphDebug.outlineEnabled = !CameraMorphDebug.outlineEnabled
                onDismiss()
            }) { Text(if (CameraMorphDebug.outlineEnabled) "Выключить контур" else "Включить контур") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
