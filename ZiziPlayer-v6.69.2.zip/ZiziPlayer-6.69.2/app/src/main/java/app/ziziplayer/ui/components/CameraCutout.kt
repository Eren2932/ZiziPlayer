package app.ziziplayer.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.os.Build
import android.view.View
import android.view.DisplayCutout
import android.view.ViewTreeObserver
import androidx.annotation.RequiresApi
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import app.ziziplayer.ui.CameraMorphGeometry

/** Window-pixel coordinates. Paths are private copies, never the mutable framework cache. */
internal data class CameraCutoutSnapshot(
    val target: CameraMorphGeometry.Target? = null,
    val outline: Path? = null,
    val windowWidth: Int = 0,
    val windowHeight: Int = 0,
    val statusTop: Int = 0,
    val exact: Boolean = false,
    val reason: String = "Ожидание геометрии окна"
) {
    fun report(): String = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}\n" +
        "Окно: ${windowWidth}×${windowHeight} px; status: $statusTop px\n" +
        "Режим: $reason\n" + (target?.let {
            "Контур: ${if (exact) "системный Path" else "приближение по Rect"}\n" +
                "left=${it.left}; top=${it.top}; right=${it.right}; bottom=${it.bottom} px"
        } ?: "Слияние с камерой выключено; используется безопасное сворачивание.")
}

/** Test injection also exercises the real overlay without depending on emulator hardware. */
internal val LocalCameraCutoutOverride = staticCompositionLocalOf<CameraCutoutSnapshot?> { null }

/** Memory-only diagnostic. No device identifiers, persistence, permissions or network calls. */
internal object CameraMorphDebug {
    var outlineEnabled by mutableStateOf(false)
}

@Composable
internal fun rememberCameraCutout(): CameraCutoutSnapshot {
    LocalCameraCutoutOverride.current?.let { return it }
    val view = LocalView.current
    val configuration = LocalConfiguration.current
    var snapshot by remember(view, configuration) { mutableStateOf(CameraCutoutSnapshot()) }
    DisposableEffect(view, configuration) {
        val root = view.rootView
        val activity = view.context.cameraActivity()
        val location = IntArray(2)
        var previousKey: List<Any?>? = null
        fun refresh() {
            if (Build.VERSION.SDK_INT < 28) {
                snapshot = CameraCutoutSnapshot(reason = "Android ниже 9: нет стандартного DisplayCutout")
                return
            }
            val insets = root.rootWindowInsets
            root.getLocationOnScreen(location)
            @Suppress("DEPRECATION")
            val status = if (Build.VERSION.SDK_INT >= 30)
                insets?.getInsets(android.view.WindowInsets.Type.statusBars())?.top ?: 0
            else insets?.stableInsetTop ?: 0
            val multiWindow = activity?.isInMultiWindowMode == true || activity?.isInPictureInPictureMode == true
            val cutout = insets?.displayCutout
            // Pre-draw observes inset changes WITHOUT replacing Compose's insets listener.
            // Parsing/copying paths happens only when relevant geometry changes, not every frame.
            val key = listOf(cutout, root.width, root.height, status, location[0], location[1],
                root.display?.rotation, multiWindow)
            if (key != previousKey) {
                previousKey = key
                snapshot = readCameraCutout(root, status, multiWindow, location[0], location[1])
            }
        }
        val listener = ViewTreeObserver.OnPreDrawListener { refresh(); true }
        val observer = root.viewTreeObserver
        observer.addOnPreDrawListener(listener)
        refresh()
        onDispose {
            if (observer.isAlive) observer.removeOnPreDrawListener(listener)
            else if (root.viewTreeObserver.isAlive) root.viewTreeObserver.removeOnPreDrawListener(listener)
        }
    }
    return snapshot
}

private fun Context.cameraActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> if (baseContext === this) null else baseContext.cameraActivity()
    else -> null
}

@RequiresApi(28)
private fun readCameraCutout(root: View, status: Int, multiWindow: Boolean, screenX: Int, screenY: Int): CameraCutoutSnapshot {
    return cameraCutoutSnapshot(root.rootWindowInsets?.displayCutout, root.width, root.height,
        status, root.resources.displayMetrics.density, multiWindow, screenX, screenY)
}

/** Android adapter separated from the View so API-28 admission is executable on an emulator. */
@RequiresApi(28)
internal fun cameraCutoutSnapshot(
    cutout: DisplayCutout?, width: Int, height: Int, status: Int, density: Float,
    multiWindow: Boolean = false, screenX: Int = 0, screenY: Int = 0
): CameraCutoutSnapshot {
    val base = CameraCutoutSnapshot(windowWidth = width, windowHeight = height, statusTop = status)
    // Path is in display coordinates. Only admit a full-screen, unshifted portrait window;
    // never silently mix it with a freeform / dialog / split-screen coordinate system.
    if (multiWindow || screenX != 0 || screenY != 0 || height <= width)
        return base.copy(reason = "Не полноэкранное портретное окно")
    if (cutout == null) return base.copy(reason = "Система не сообщает вырез")
    return try {
        // getBoundingRectTop() is API 29, NOT API 28. The public list exists on API 28;
        // supported() below rejects side/bottom shapes by their actual pixel coordinates.
        val bounds = cutout.boundingRects.singleOrNull()
            ?: return base.copy(reason = "Нет единственного верхнего выреза")
        if (bounds.isEmpty) return base.copy(reason = "Пустая область выреза")
        val path = if (Build.VERSION.SDK_INT >= 31) cutout.cutoutPath?.let { AndroidPath(it) } else null
        var exact = false
        val box = RectF(bounds)
        if (path != null && !path.isEmpty) {
            val region = AndroidPath().apply { addRect(box, AndroidPath.Direction.CW) }
            if (!path.op(region, AndroidPath.Op.INTERSECT) || path.isEmpty)
                return base.copy(reason = "Контур не совпал с верхней областью выреза")
            path.computeBounds(box, true)
            exact = true
        }
        val target = CameraMorphGeometry.Target(box.left, box.top, box.right, box.bottom)
        if (!CameraMorphGeometry.supported(target, width.toFloat(), height.toFloat(),
                status.toFloat(), density, exact))
            return base.copy(reason = "Широкий/неопределённый вырез: безопасное сворачивание")
        val outline = if (exact) path!! else AndroidPath().apply {
            // A small near-square rect is an approximation, explicitly reported as such.
            addOval(box, AndroidPath.Direction.CW)
        }
        base.copy(target = target, outline = outline.asComposePath(), exact = exact,
            reason = if (exact) "Слияние по системному контуру" else "Слияние по компактному прямоугольнику")
    } catch (_: RuntimeException) {
        base.copy(reason = "Некорректная геометрия прошивки: безопасное сворачивание")
    }
}
