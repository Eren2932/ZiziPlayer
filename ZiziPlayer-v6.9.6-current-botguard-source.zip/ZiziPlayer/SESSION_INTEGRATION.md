# Innertube proof architecture (6.9.6)

## Почему строка poToken могла существовать, но не работать

Успешный ответ GenerateIT и base64url-строка ещё не доказывают, что YouTube примет proof. В старой
схеме challenge получался через WAA `Create`. На август 2026 player endpoint отвергает такие токены.
Кроме того, разные места протокола требуют разную привязку.

## Актуальный WebView flow

`PoTokenMinter` загружает локальную управляющую страницу с origin `https://www.youtube.com/`, после
чего она:

1. получает HTML главной страницы YouTube;
2. извлекает `ytcfg` и устанавливает `yt.config_`, включая `EVENT_ID`;
3. извлекает challenge из `window.ytAtN(...).R.bgChallenge`;
4. загружает interpreter, указанный самим challenge;
5. выполняет BotGuard snapshot;
6. вызывает `https://www.youtube.com/api/jnn/v1/GenerateIT`;
7. сохраняет WebPo minter внутри невидимого WebView.

## Два контекста одного minter

### GVS/session token

Минтится для `visitorData`. Он записывается в:

````json
context.client.poToken
````

И добавляется параметром `pot=` к Googlevideo URL. Атомарный `InnertubeSessionProof` не позволяет
смешать токен с другим visitorData.

### PLAYER token

Минтится отдельно для `videoId` каждого трека и записывается в:

````json
serviceIntegrityDimensions.poToken
````

Передача visitor-bound токена в это поле является ошибкой привязки и приводит к LOGIN_REQUIRED до
выдачи форматов.

Поскольку minter иногда возвращает Promise, PLAYER token передаётся из JavaScript через методы
`ZiziPo.content(requestId, token)` и `ZiziPo.contentFail(...)`. Обычный callback
`evaluateJavascript` для этого недостаточен: Promise сериализуется не как итоговая строка.

## User-Agent

OkHttp interceptor не изменяет User-Agent. API-запрос и медиазапрос используют UA выбранного
Innertube-клиента.
