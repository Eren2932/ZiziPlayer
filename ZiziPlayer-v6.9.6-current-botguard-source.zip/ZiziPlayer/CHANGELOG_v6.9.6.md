# ZiziPlayer 6.9.6 — актуальный BotGuard challenge и раздельные PLAYER/GVS proof

Диагностика 6.9.5 показала точный отказ: локальный poToken создавался, но все player-клиенты
возвращали LOGIN_REQUIRED до выдачи форматов. Причиной были одновременно устаревший challenge flow
и неверная привязка токена.

Старый минтер вызывал WAA `Create` на `jnn-pa.googleapis.com`. На август 2026 этот challenge больше
не принимается YouTube player API, даже когда GenerateIT возвращает строку, похожую на токен. Новый
WebView flow получает главную страницу `www.youtube.com`, извлекает согласованную пару `ytcfg` с
`EVENT_ID` и `window.ytAtN(...).R.bgChallenge`, загружает указанный interpreter и отправляет snapshot
в `https://www.youtube.com/api/jnn/v1/GenerateIT`.

Разделены контексты proof:

- GVS/session poToken минтится для visitorData, кладётся в `context.client.poToken` и используется как
  `pot=` на URL медиапотока;
- PLAYER poToken минтится для videoId и кладётся в `serviceIntegrityDimensions.poToken` запроса
  `player`;
- асинхронный video-bound mint теперь возвращается через отдельный JS-мост, а не через
  `evaluateJavascript`, который не умеет разворачивать Promise.

Обновлены известные версии IOS, MWEB, WEB_EMBEDDED_PLAYER и WEB_REMIX на значения из актуального
реестра клиентов. IOS/MWEB/Web Music поставлены раньше устаревших fallback; ANDROID_VR 1.65.10
перемещён вниз, поскольку с 2026-08-17 его форматы массово получают CDN 403.

Кнопка полной диагностики теперь действительно форсирует новый integrity run. Отчёт показывает
отдельно GVS token для visitorData и PLAYER token для videoId, а номер версии берётся из
`BuildConfig.VERSION_NAME`, поэтому больше не отображает захардкоженное `6.9.1`.
