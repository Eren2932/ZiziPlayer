#!/usr/bin/env python3
"""Source integration checks, NOT Kotlin compilation, Compose or Android device tests."""
from pathlib import Path
import os
import re
import unittest
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
JAVA = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (JAVA / path).read_text()
class Mobile641Contracts(unittest.TestCase):
    def test_secure_only_auth_window(self):
        for p in JAVA.rglob('*.kt'):
            text = p.read_text()
            if p.name == 'AccountAuthScreen.kt':
                # 6.51: credentials screen only, with exact restoration on disposal.
                self.assertIn('DisposableEffect(activity)', text)
                self.assertIn('onDispose { if (!wasSecure) activity.window.clearFlags', text)
            else:
                self.assertNotIn('window.addFlags', text, str(p))
            self.assertNotIn('setRecentsScreenshotEnabled(false)', text, str(p))
            if 'SecureFlagPolicy.SecureOn' in text:
                self.assertEqual(p.name, 'VaultAuthDialog.kt')
        self.assertIn('SecureFlagPolicy.SecureOn', read('ui/components/VaultAuthDialog.kt'))
    def test_no_header_lock(self):
        ui = read('ui/screens/LibraryScreen.kt')
        self.assertNotIn('Icons.Outlined.Lock', ui)
        self.assertNotIn('contentDescription = "Открыть скрытые папки"', ui)
        self.assertIn('VaultPullSurface(', ui)
        self.assertIn('state.filter == LibraryFilter.COLLECTION || state.filter == LibraryFilter.FOLDERS', ui)
    def test_authentication_single_entry_guard(self):
        ui = read('ui/screens/LibraryScreen.kt')
        self.assertIn('gate.folders.isEmpty() || authenticate || showVault || pendingHide.isNotEmpty()', ui)
        self.assertIn('if (gate.unlocked) showVault = true else', ui)
        self.assertIn('if (authenticate) VaultAuthDialog', ui)
        self.assertIn('else showVault = true', ui)
    def test_release_independent_of_fling(self):
        pull = read('ui/components/VaultPullSurface.kt')
        self.assertIn('val shouldOpen = gesture.release()', pull)
        self.assertIn('if (shouldOpen) openVaultAction.invoke()', pull)
        fling = pull.split('override suspend fun onPreFling', 1)[1].split('\n        }', 1)[0]
        self.assertNotIn('openVaultAction', fling)
        self.assertNotIn('gesture.cancel()', fling)
        self.assertIn('if (!normalEnd) { gesture.cancel(); sync() }', pull)
    def test_scroll_remainder_and_empty_collections(self):
        pull = read('ui/components/VaultPullSurface.kt')
        self.assertIn('onPostScroll(consumed: Offset, available: Offset', pull)
        self.assertIn('gesture.pull(available.y)', pull)
        self.assertIn('source != NestedScrollSource.UserInput', pull)
        ui = read('ui/screens/LibraryScreen.kt').split('private fun CollectionSurface(', 1)[1]
        self.assertEqual(ui.count('if (cards.isEmpty()) item(key = "empty:collections")'), 2)
    def test_talkback_without_visual_shortcut(self):
        pull = read('ui/components/VaultPullSurface.kt')
        self.assertIn('CustomAccessibilityAction("Открыть скрытые папки")', pull)
        self.assertNotIn('.clickable', pull)
    def test_pin_is_real_keypad_not_system_credential_imitation(self):
        auth = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('PinPad(input, enabled', auth)
        self.assertIn('vault.verify(secret)', auth)
        self.assertIn('Введи PIN', auth)  # 6.41.0: имя приложения убрано из текстов внутри него
        self.assertIn('password(); contentDescription', auth)
        self.assertNotIn('OutlinedTextField', auth)
        self.assertNotIn('rememberSaveable', auth)
        self.assertIn('value.length < 12', auth)
    def test_one_biometric_route_no_device_credential(self):
        auth = read('ui/components/VaultAuthDialog.kt')
        self.assertNotIn('createConfirmDeviceCredentialIntent', auth)
        self.assertNotIn('Authenticators.DEVICE_CREDENTIAL', auth)
        self.assertNotIn('ActivityResultContracts', auth)
        self.assertEqual(auth.count('.authenticate(signal'), 1)
        self.assertIn('builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)', auth)
        self.assertIn('setNegativeButton(if (pattern)', auth)
    def test_cancel_background_and_late_biometric(self):
        auth = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('Lifecycle.Event.ON_STOP', auth)
        self.assertIn('cancellation?.cancel()', auth)
        self.assertIn('input = ""; first = null', auth)
        self.assertIn('active() && epoch == authEpoch && biometricActive', auth)
        failure = auth.split('override fun onAuthenticationError', 1)[1].split('override fun onAuthenticationFailed', 1)[0]
        self.assertNotIn('unlockWithDevice', failure)
    def test_existing_keys_and_retry_limit_preserved(self):
        auth = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('vault.pattern', auth)
        self.assertIn('PatternPad(input, enabled', auth)
        self.assertIn('if (retrySeconds > 0)', auth)
        self.assertIn('delay(1_000)', auth)
        self.assertIn('PBKDF2WithHmacSHA256', read('privacy/FolderVault.kt'))
    def test_audio_uses_public_anonymous_api_without_capture(self):
        focus = read('playback/FocusPlayer.kt')
        self.assertIn('audio.activePlaybackConfigurations', focus)
        self.assertIn('engine.isPlaying, audio.mode == AudioManager.MODE_NORMAL', focus)
        for forbidden in ('it.isActive', 'it.clientUid', 'it.sessionId', 'AudioRecord(', 'MediaProjection'):
            self.assertNotIn(forbidden, focus)
        manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text()
        self.assertNotIn('RECORD_AUDIO', manifest)
        self.assertNotIn('BIND_NOTIFICATION_LISTENER_SERVICE', manifest)
    def test_audio_observer_release_and_pause_cleanup(self):
        focus = read('playback/FocusPlayer.kt')
        self.assertIn('audio.registerAudioPlaybackCallback(playbackObserver, handler)', focus)
        self.assertIn('audio.unregisterAudioPlaybackCallback(playbackObserver)', focus)
        self.assertIn('private fun abandon() {\n        stopDuckMonitoring()', focus)
        self.assertIn('AUDIOFOCUS_LOSS_TRANSIENT -> {\n                stopDuckMonitoring()', focus)
        self.assertIn('AUDIOFOCUS_GAIN -> {\n                stopDuckMonitoring()', focus)
        self.assertIn('handler.removeCallbacks(confirmQuiet)', focus)
    def test_recovery_adjusts_volume_not_focus_or_play_intent(self):
        focus = read('playback/FocusPlayer.kt')
        sample = focus.split('private fun samplePlaybackActivity()', 1)[1].split('\n    init {', 1)[0]
        self.assertIn('DuckRecoveryPolicy.RESTORE -> fade(1f, AudioInterruptionPolicy.RELEASE_MS)', sample)
        self.assertIn('DuckRecoveryPolicy.DUCK -> fade(AudioInterruptionPolicy.DUCK_GAIN', sample)
        self.assertNotIn('engine.play()', sample)
        self.assertNotIn('requestAudioFocus', sample)
        self.assertIn('if (delay >= 0) handler.postDelayed(confirmQuiet, delay)', sample)
    def test_version_and_ci_wiring(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertGreaterEqual(int(re.search(r'versionCode = (\d+)', gradle).group(1)), 83)
        self.assertRegex(gradle, r'versionName = "6\.\d+\.\d+"')
        selftest = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn('test_mobile_641.py', selftest)
        self.assertIn('test_mobile_641_contracts.py', selftest)
if __name__ == '__main__': unittest.main(verbosity=2)
