package app.ziziplayer.account

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Decode locally, normalise orientation, centre-crop, strip metadata; no source URI is uploaded. */
object AvatarImage {
    suspend fun load(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream(); val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer); if (n < 0) break
                require(out.size() + n <= 20 * 1024 * 1024) { "Изображение больше 20 МиБ" }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: error("Нет доступа к изображению")
        val bitmap = if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(java.nio.ByteBuffer.wrap(bytes))) { decoder, info, _ ->
                require(info.size.width in 1..16000 && info.size.height in 1..16000) { "Изображение слишком большое" }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetSampleSize((maxOf(info.size.width, info.size.height) / 512).coerceAtLeast(1))
            }
        } else {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            require(options.outWidth in 1..16000 && options.outHeight in 1..16000) { "Неподдерживаемое изображение" }
            options.inJustDecodeBounds = false
            var sample = 1
            while (maxOf(options.outWidth, options.outHeight) / sample > 512) sample *= 2
            options.inSampleSize = sample
            val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: error("Не удалось открыть изображение")
            val orientation = runCatching { ExifInterface(bytes.inputStream()).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }.getOrDefault(1)
            val matrix = Matrix().apply { when (orientation) {
                2 -> setScale(-1f, 1f)
                3 -> setRotate(180f)
                4 -> setScale(1f, -1f)
                5 -> { setRotate(90f); postScale(-1f, 1f) }
                6 -> setRotate(90f)
                7 -> { setRotate(270f); postScale(-1f, 1f) }
                8 -> setRotate(270f)
            } }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true).also { if (it !== raw) raw.recycle() }
        }
        val side = minOf(bitmap.width, bitmap.height)
        val crop = Bitmap.createBitmap(bitmap, (bitmap.width-side)/2, (bitmap.height-side)/2, side, side)
        val scaled = Bitmap.createScaledBitmap(crop, 256, 256, true)
        // Always 8-bit RGBA, never wide-gamut/F16 PNG.
        val normalized = scaled.copy(Bitmap.Config.ARGB_8888, false) ?: error("Не удалось обработать изображение")
        val output = ByteArrayOutputStream()
        try {
            check(normalized.compress(Bitmap.CompressFormat.PNG, 100, output))
            require(output.size() <= 300 * 1024) { "Не удалось уменьшить изображение" }
            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally {
            normalized.recycle(); if (scaled !== crop) scaled.recycle()
            if (crop !== bitmap) crop.recycle(); bitmap.recycle()
        }
    }
}
