package app.ziziplayer.library

import android.content.Context
import app.ziziplayer.BuildConfig
import app.ziziplayer.account.AccountApiException
import app.ziziplayer.account.AccountRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** A single foreground sync lane. Conflicts pause instead of silently choosing the last writer. */
class LibrarySync private constructor(context: Context) {
    private val snapshots = LibrarySnapshot(context.applicationContext)
    private val api = AccountRepository.get(context)
    private val prefs = context.getSharedPreferences("zizi_library_sync", Context.MODE_PRIVATE)
    private val lane = Mutex()
    private val mutable = MutableStateFlow(LibrarySyncState())
    val state = mutable.asStateFlow()
    private var uid: String? = null
    private var enabled = false
    private var revision = 0L
    private var cloud: JSONObject? = null
    private var lastHash = ""
    private var accountKey = ""
    private var retryConnect = false
    private var retryAfter = 0L

    private suspend fun operation(action: suspend () -> Unit) = lane.withLock {
        withContext(Dispatchers.IO + NonCancellable) {
            mutable.value = mutable.value.copy(busy = true)
            try { action() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val conflict = e is AccountApiException && e.status == 409
                if (conflict) enabled = false
                val transient = e !is AccountApiException || app.ziziplayer.account.AccountProblem.retryable(e.status)
                if (!enabled && !mutable.value.needsChoice && !conflict && transient &&
                    e !is IllegalStateException && e !is IllegalArgumentException) retryConnect = true
                retryAfter = android.os.SystemClock.elapsedRealtime() + 60_000L
                val text = when {
                    e is AccountApiException -> app.ziziplayer.account.AccountProblem.library(e.status, e.reason)
                    e is IllegalStateException || e is IllegalArgumentException -> e.message ?: "Копия не подходит. Данные не изменены."
                    else -> "Не удалось сохранить или получить библиотеку. Проверьте соединение. Локальные данные не удалены."
                }
                mutable.value = mutable.value.copy(message = text, needsChoice = conflict || mutable.value.needsChoice)
            } finally { mutable.value = mutable.value.copy(busy = false, enabled = enabled) }
        }
    }

    private fun bind(id: String, hash: String, savedAt: Long) {
        if (!prefs.edit().putString("owner", accountKey).putLong("revision", revision)
            .putString("hash", hash).putLong("saved_at", savedAt).commit()) throw IllegalStateException("Не удалось сохранить состояние синхронизации")
        uid = id; lastHash = hash; enabled = true; retryConnect = false
        mutable.value = mutable.value.copy(needsChoice = false, savedAt = savedAt, cloudAvailable = revision > 0,
            cloudSummary = cloud?.let { LibrarySnapshot.summary(it) }.orEmpty(),
            message = "Облачная библиотека подключена. Изменения сохраняются, пока приложение открыто; перед удалением дождитесь подтверждения сохранения.")
    }

    suspend fun connect(id: String?) = operation {
        enabled = false; retryConnect = false; retryAfter = 0L; uid = id; cloud = null; revision = 0L
        mutable.value = LibrarySyncState(busy = true)
        if (id == null) return@operation
        accountKey = BuildConfig.ACCOUNT_URL + ":" + id
        checkRemote(id)
    }

    private suspend fun checkRemote(id: String) {
        retryConnect = false
        val local = snapshots.capture()
        mutable.value = mutable.value.copy(localSummary = LibrarySnapshot.summary(local))
        val health = api.capabilities()
        if (!health.optBoolean("sync_enabled") || health.optString("library_format") != LibrarySnapshot.FORMAT)
            throw AccountApiException(404, "sync_unavailable")
        val hash = LibrarySnapshot.hash(local)
        val remote = api.libraryGet(id)
        revision = remote.getLong("revision")
        cloud = remote.optJSONObject("document")
        val sameOwner = prefs.getString("owner", "") == accountKey
        val knownHash = prefs.getString("hash", "").orEmpty()
        mutable.value = mutable.value.copy(cloudAvailable = cloud != null, localSummary = LibrarySnapshot.summary(local),
            cloudSummary = cloud?.let { LibrarySnapshot.summary(it) }.orEmpty(), savedAt = remote.optLong("saved_at"))
        val decision = LibrarySyncPolicy.choose(sameOwner, revision == prefs.getLong("revision", -1),
            cloud != null, LibrarySnapshot.hasPersonalData(local), hash == knownHash)
        if (decision == LibrarySyncPolicy.Action.CONNECT) {
            lastHash = knownHash; enabled = true
            mutable.value = mutable.value.copy(needsChoice = false, message = "Облачная библиотека подключена.")
            flushInside(id)
        } else if (decision == LibrarySyncPolicy.Action.RESTORE) {
            val restoredHash = snapshots.restore(cloud!!.toString(), expectedHash = hash)
            bind(id, restoredHash, remote.getLong("saved_at"))
            mutable.value = mutable.value.copy(message = "Библиотека восстановлена из аккаунта. Локальные аудиофайлы подключаются отдельно.")
        } else {
            enabled = false
            mutable.value = mutable.value.copy(needsChoice = true,
                message = if (cloud == null) "Привяжите библиотеку этого телефона к аккаунту: избранное, сохранённые треки и плейлисты будут доступны после переустановки."
                else "На телефоне и в аккаунте есть данные. Выберите библиотеку. Автоматическая замена отключена; перед восстановлением создаётся страховочная копия.")
        }
    }

    suspend fun refresh() = operation {
        val id = uid ?: return@operation
        enabled = false
        checkRemote(id)
    }

    /** Explicit upload is also the only way to bind an existing phone library to a new account. */
    suspend fun usePhone() = operation {
        val id = uid ?: return@operation
        val local = snapshots.capture()
        val result = api.librarySave(id, revision, local)
        revision = result.getLong("revision"); cloud = local
        bind(id, LibrarySnapshot.hash(local), result.getLong("saved_at"))
        mutable.value = mutable.value.copy(localSummary = LibrarySnapshot.summary(local), message = "Библиотека телефона сохранена в аккаунте.")
    }

    suspend fun useCloud() = operation {
        val id = uid ?: return@operation
        val remote = api.libraryGet(id)
        val document = remote.optJSONObject("document") ?: error("Облачная библиотека пока пуста")
        val restoredHash = snapshots.restore(document.toString())
        revision = remote.getLong("revision"); cloud = document
        bind(id, restoredHash, remote.getLong("saved_at"))
    }

    private suspend fun flushInside(id: String) {
        val local = snapshots.capture()
        val hash = LibrarySnapshot.hash(local)
        if (hash == lastHash) {
            mutable.value = mutable.value.copy(message = "Изменений для отправки нет. Последняя подтверждённая копия указана ниже.")
            return
        }
        if (LibrarySyncPolicy.pauseEmptyUpload(LibrarySnapshot.hasPersonalData(local), cloud?.let { LibrarySnapshot.hasPersonalData(it) } == true)) {
            enabled = false
            mutable.value = mutable.value.copy(needsChoice = true, message = "Библиотека телефона пуста. Облачные данные не перезаписаны: выберите, что сохранить.")
            return
        }
        val result = api.librarySave(id, revision, local)
        revision = result.getLong("revision"); cloud = local
        bind(id, hash, result.getLong("saved_at"))
        mutable.value = mutable.value.copy(message = "Изменения библиотеки сохранены в аккаунте.", localSummary = LibrarySnapshot.summary(local))
    }

    suspend fun flush(manual: Boolean = false) = operation {
        if (manual) retryAfter = 0L
        val id = uid
        if (id != null && retryConnect && android.os.SystemClock.elapsedRealtime() >= retryAfter) {
            checkRemote(id)
            return@operation
        }
        if (enabled && id != null && android.os.SystemClock.elapsedRealtime() >= retryAfter) {
            val local = snapshots.capture()
            val hash = LibrarySnapshot.hash(local)
            if (hash == lastHash) {
                val remote = api.libraryGet(id)
                if (remote.getLong("revision") != revision) {
                    val document = remote.optJSONObject("document")
                        ?: throw AccountApiException(409, "library_conflict")
                    val restoredHash = snapshots.restore(document.toString(), expectedHash = hash)
                    cloud = document; revision = remote.getLong("revision")
                    bind(id, restoredHash, remote.getLong("saved_at"))
                    mutable.value = mutable.value.copy(message = "Получены изменения библиотеки из аккаунта.")
                } else mutable.value = mutable.value.copy(message = "Текущая библиотека сохранена в аккаунте.")
            } else flushInside(id)
        }
    }

    /** Imports are not uploaded until the user explicitly binds the resulting local library. */
    suspend fun importFile(raw: String) = operation {
        enabled = false; retryConnect = false
        if (!prefs.edit().remove("owner").remove("hash").commit()) throw IllegalStateException("Не удалось приостановить синхронизацию")
        snapshots.restore(raw)
        mutable.value = mutable.value.copy(needsChoice = uid != null, message = "Резервный файл восстановлен. Чтобы отправить его в аккаунт, выберите библиотеку телефона.")
    }

    companion object {
        @Volatile private var instance: LibrarySync? = null
        fun get(context: Context): LibrarySync = instance ?: synchronized(this) {
            instance ?: LibrarySync(context.applicationContext).also { instance = it }
        }
    }
}

data class LibrarySyncState(
    val busy: Boolean = false,
    val enabled: Boolean = false,
    val needsChoice: Boolean = false,
    val cloudAvailable: Boolean = false,
    val savedAt: Long = 0L,
    val localSummary: String = "",
    val cloudSummary: String = "",
    val message: String = "Войдите в аккаунт, чтобы подключить облачную библиотеку. Экспорт в файл доступен без входа."
)
