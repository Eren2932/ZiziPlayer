package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import app.ziziplayer.ui.theme.ZiziFontFamily
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.account.*
import app.ziziplayer.ui.components.AccountAvatar
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun AccountEditScreen(account: AccountLocalState, profile: AccountProfile, onClose: () -> Unit) {
    val context = LocalContext.current
    val store = remember { AccountProfileStore.get(context) }
    val scope = rememberCoroutineScope()
    val p = LocalPalette.current
    val scale = accountScale()
    // Draft deliberately stays in RAM, not SavedState/Bundle (photo can exceed Binder limits).
    var name by remember(account.userId) { mutableStateOf(profileName(account, profile)) }
    var avatar by remember(account.userId) { mutableStateOf(profile.avatar) }
    val revision = remember(account.userId) { profile.revision }
    var choosing by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var discard by remember { mutableStateOf(false) }
    val busy = working || profile.busy
    val dirty = name.trim() != profileName(account, profile) || avatar != profile.avatar
    val valid = name.trim().isNotBlank() && name.codePointCount(0, name.length) <= 80 && !name.any { it.isISOControl() }
    val close: () -> Unit = { if (!busy) { if (dirty) discard = true else onClose() } }
    BackHandler { close() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            working = true; error = ""
            try { avatar = AvatarImage.load(context, uri) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { error = e.message ?: "Не удалось открыть фото" }
            finally { working = false }
        }
    }
    Column(Modifier.fillMaxSize().background(p.surface).statusBarsPadding().imePadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = close, enabled = !busy) { Icon(ZiziIcons.Close, "Закрыть редактор", tint = p.text) }
            Text("Изменение профиля", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(enabled = dirty && valid && !busy && profile.loaded, onClick = {
                val id = account.userId
                if (id != null) scope.launch {
                    working = true
                    try { if (store.save(id, name, avatar, revision)) onClose() }
                    finally { working = false }
                }
            }) { Text("Сохранить", color = if (dirty && valid && !busy) p.text else p.subtext, fontSize = 15.sp) }
        }
        Spacer(Modifier.height((20*scale).dp))
        Box(Modifier.align(Alignment.CenterHorizontally)) {
            AccountAvatar(account.userId.orEmpty(), name, avatar, (127*scale).dp)
            Box(Modifier.align(Alignment.BottomEnd).size(48.dp)
                .clickable(enabled = !busy) { choosing = true }, contentAlignment = Alignment.BottomEnd) {
                Box(Modifier.size((30.7f*scale).dp).clip(RoundedCornerShape(5.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                    Icon(ZiziIcons.Edit, "Изменить аватарку", tint = Color.Black, modifier = Modifier.size(20.dp))
                }
            }
        }
        Spacer(Modifier.height((32*scale).dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = (15.3f*scale).dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Имя", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width((90*scale).dp))
            BasicTextField(name, onValueChange = { if (it.codePointCount(0, it.length) <= 80) name = it },
                enabled = !busy, singleLine = true, textStyle = TextStyle(color = p.text, fontSize = 17.sp, fontFamily = ZiziFontFamily),
                cursorBrush = SolidColor(p.brand), modifier = Modifier.weight(1f))
        }
        HorizontalDivider(Modifier.padding(horizontal = (15.3f*scale).dp), color = p.chip)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp))
        if (error.isNotBlank() || profile.error.isNotBlank()) Text(error.ifBlank { profile.error }, color = p.subtext, modifier = Modifier.padding(16.dp))
        Spacer(Modifier.navigationBarsPadding())
    }
    if (discard) AlertDialog(onDismissRequest = { discard = false },
        title = { Text("Отменить изменения?") }, text = { Text("Имя и фото ещё не сохранены в аккаунте.") },
        confirmButton = { TextButton(onClick = { discard = false; onClose() }) { Text("Не сохранять") } },
        dismissButton = { TextButton(onClick = { discard = false }) { Text("Продолжить") } })
    if (choosing) AlertDialog(onDismissRequest = { choosing = false }, title = { Text("Аватарка") },
        text = { Text("Фото будет обрезано по центру до квадрата и сохранено в аккаунте после нажатия «Сохранить».") },
        confirmButton = { TextButton(onClick = { choosing = false; picker.launch(arrayOf("image/*")) }) { Text("Выбрать фото") } },
        dismissButton = { Row {
            if (avatar.isNotEmpty()) TextButton(onClick = { avatar = ""; choosing = false }) { Text("Удалить фото") }
            TextButton(onClick = { choosing = false }) { Text("Отмена") }
        } })
}
