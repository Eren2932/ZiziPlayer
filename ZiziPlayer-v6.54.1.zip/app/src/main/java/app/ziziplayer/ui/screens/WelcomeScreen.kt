package app.ziziplayer.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.R

/** Guest access and the honest local-storage disclosure remain available without crowding the hero. */
@Composable
fun WelcomeScreen(
    signInOffered: Boolean,
    onSignIn: () -> Unit,
    onGuest: () -> Unit,
    onRegister: () -> Unit = onSignIn
) {
    var about by remember { mutableStateOf(false) }
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        val viewport = maxHeight
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
            .heightIn(min = viewport).padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height((viewport * 0.27f).coerceAtMost(240.dp)))
            Image(painterResource(R.drawable.zizi_auth_logo), "ZiziPlayer", Modifier.size(80.dp))
            Spacer(Modifier.height(24.dp))
            Text("Твоя музыка.\nВ твоём ZiziPlayer.", color = Color.White, fontSize = 30.sp,
                lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(40.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (signInOffered) {
                    AccountPill("Зарегистрироваться", onRegister, primary = true)
                    AccountPill("Войти", onSignIn)
                } else AccountPill("Продолжить", onGuest, primary = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onGuest) { Text("Продолжить как гость", color = Color.White, fontSize = 12.sp) }
                TextButton(onClick = { about = true }) { Text("Об аккаунте", color = Color(0xFFB3B3B3), fontSize = 12.sp) }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
    if (about) AlertDialog(onDismissRequest = { about = false },
        title = { Text("Аккаунт ZiziPlayer") },
        text = { Text("Войдите и подключите облачную библиотеку: сохранённые треки каталога, избранное и плейлисты можно восстановить после переустановки. Перед удалением приложения проверьте подтверждение сохранения. Аудиофайлы с телефона не загружаются в аккаунт. Гостевые данные хранятся только на устройстве.") },
        confirmButton = { TextButton(onClick = { about = false }) { Text("Понятно") } })
}
