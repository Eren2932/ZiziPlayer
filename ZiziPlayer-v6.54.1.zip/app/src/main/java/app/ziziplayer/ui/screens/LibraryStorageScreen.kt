package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.library.LibrarySnapshot
import app.ziziplayer.library.LibrarySync
import app.ziziplayer.library.LibrarySyncState
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date

@Composable
fun LibraryStorageScreen(state: LibrarySyncState, signedIn: Boolean, onClose: () -> Unit) {
    val context = LocalContext.current
    val sync = remember(context) { LibrarySync.get(context) }
    val snapshots = remember(context) { LibrarySnapshot(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val p = LocalPalette.current
    var confirm by remember { mutableStateOf<String?>(null) }
    var imported by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("") }
    var fileBusy by remember { mutableStateOf(false) }
    var safetyExport by remember { mutableStateOf(false) }
    val blocked = state.busy || fileBusy
    BackHandler { if (!blocked) onClose() }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            fileBusy = true
            try {
                val raw = if (safetyExport) snapshots.readSafety() else snapshots.capture().toString()
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(uri, "wt") ?: error("Нет доступа к файлу")
                    stream.use { it.write(raw.toByteArray(Charsets.UTF_8)) }
                }
                notice = "Файл сохранён. Он содержит историю и метаданные библиотеки без паролей и аудио. Храните его в надёжном месте."
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { notice = e.message ?: "Не удалось сохранить файл" }
            finally { fileBusy = false }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            fileBusy = true
            try {
                imported = withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openInputStream(uri) ?: error("Нет доступа к файлу")
                    stream.use {
                        val buffer = ByteArray(8192); val output = ByteArrayOutputStream()
                        while (true) {
                            val n = it.read(buffer); if (n < 0) break
                            require(output.size() + n <= LibrarySnapshot.MAX_BYTES) { "Файл больше 8 МиБ" }
                            output.write(buffer, 0, n)
                        }
                        output.toString("UTF-8")
                    }
                }
                confirm = "import"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { notice = e.message ?: "Не удалось прочитать файл" }
            finally { fileBusy = false }
        }
    }
    Column(Modifier.fillMaxSize().background(p.surface).systemBarsPadding()
        .verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onClose, enabled = !blocked) { Text("Назад", color = p.text) }
        Text("Твоя библиотека", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(state.message, color = p.text)
        if (state.savedAt > 0) Text("Подтверждено сервером: " + DateFormat.getDateTimeInstance().format(Date(state.savedAt * 1000)), color = p.subtext)
        if (state.localSummary.isNotEmpty()) Text("На телефоне\n${state.localSummary}", color = p.subtext)
        if (state.cloudSummary.isNotEmpty()) Text("В аккаунте\n${state.cloudSummary}", color = p.subtext)
        if (signedIn) {
            AccountPill("Проверить облако", { scope.launch { sync.refresh() } }, enabled = !blocked)
            if (state.enabled) AccountPill("Сохранить сейчас", { scope.launch { sync.flush(manual = true) } }, primary = true, enabled = !blocked)
            if (state.needsChoice) AccountPill("Использовать библиотеку телефона", { confirm = "phone" }, primary = true, enabled = !blocked)
            if (state.cloudAvailable) AccountPill("Восстановить из аккаунта", { confirm = "cloud" }, enabled = !blocked)
        }
        Spacer(Modifier.height(8.dp))
        Text("Дополнительная страховка", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AccountPill("Экспорт библиотеки в файл", {
            safetyExport = false; export.launch("ZiziPlayer-library-${System.currentTimeMillis()}.json")
        }, enabled = !blocked)
        AccountPill("Импорт резервного файла", { importLauncher.launch(arrayOf("application/json", "application/octet-stream")) }, enabled = !blocked)
        AccountPill("Экспорт копии до восстановления", {
            safetyExport = true; export.launch("ZiziPlayer-before-restore.json")
        }, enabled = !blocked)
        Text("В облаке — сохранённые записи каталога, избранное, плейлисты, история и настройки отдельных треков. Аудиофайлы, общие настройки приложения, пароли, разрешения Android и кэш не переносятся. Локальные файлы на новом телефоне нужно подключить заново. Недоступность трека в каталоге аккаунт не устраняет.", color = p.subtext, fontSize = 13.sp)
        Text("Автосохранение работает при открытом приложении примерно раз в 15 секунд. Перед удалением приложения нажмите «Сохранить сейчас» и дождитесь подтверждения. При конфликте двух устройств синхронизация останавливается для выбора. Библиотека на телефоне общая: выход не удаляет её, привязка к другому аккаунту требует отдельного выбора.", color = p.subtext, fontSize = 13.sp)
        if (notice.isNotEmpty()) Text(notice, color = p.text)
        if (blocked) Text("Подождите…", color = p.brand)
    }
    if (confirm != null) AlertDialog(onDismissRequest = { confirm = null; imported = null },
        title = { Text(if (confirm == "phone") "Привязать библиотеку телефона?" else "Восстановить библиотеку?") },
        text = { Text(if (confirm == "phone")
            "В аккаунт будут отправлены метаданные и история этой библиотеки. Если в облаке уже есть копия, она будет заменена. После подключения изменения сохраняются автоматически при открытом приложении."
            else "Избранное, плейлисты и история на телефоне будут заменены выбранной копией, не объединены. Перед заменой приложение сохранит одну внутреннюю страховочную копию. Экспортируйте текущую библиотеку отдельно для надёжного отката. Сами аудиофайлы не удаляются.") },
        confirmButton = { TextButton(onClick = {
            val action = confirm; val raw = imported; confirm = null; imported = null
            scope.launch { when (action) {
                "phone" -> sync.usePhone()
                "cloud" -> sync.useCloud()
                "import" -> if (raw != null) sync.importFile(raw)
            } }
        }) { Text("Подтвердить") } },
        dismissButton = { TextButton(onClick = { confirm = null; imported = null }) { Text("Отмена") } })
}
