package app.ziziplayer.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "tracks", indices = [Index(value = ["uri"], unique = true)])
data class TrackEntity(
    @PrimaryKey val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long,
    val artworkUri: String? = null,
    val sourceFolder: String = "Устройство",
    val dateAdded: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val trackId: String, val addedAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrackEntity(val playlistId: Long, val trackId: String, val position: Int)

@Entity(tableName = "track_fx")
data class TrackFxEntity(
    @PrimaryKey val trackId: String,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val reverb: Int = 0
)
