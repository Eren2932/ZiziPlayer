package app.ziziplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.theme.ZiziPalette
import java.util.concurrent.TimeUnit

fun formatTime(ms: Long): String {
    if(ms<=0) return "0:00"
    val total=TimeUnit.MILLISECONDS.toSeconds(ms)
    return "%d:%02d".format(total/60,total%60)
}

@Composable fun MatteChip(label:String,icon:ImageVector,p:ZiziPalette,active:Boolean=false,onClick:()->Unit) {
    Row(
        Modifier.height(52.dp).background(if(active) p.accent else p.chip,RoundedCornerShape(20.dp)).clickable(onClick=onClick).padding(horizontal=17.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon,null,tint=if(active) Color(0xFF111114) else p.text,modifier=Modifier.size(23.dp))
        Text(label,color=if(active) Color(0xFF111114) else p.text,fontSize=15.sp)
    }
}

@Composable fun RoundIcon(icon:ImageVector,p:ZiziPalette,onClick:()->Unit) {
    Box(Modifier.size(58.dp).background(p.chip,CircleShape).clickable(onClick=onClick),contentAlignment=Alignment.Center) {
        Icon(icon,null,tint=p.text,modifier=Modifier.size(29.dp))
    }
}
