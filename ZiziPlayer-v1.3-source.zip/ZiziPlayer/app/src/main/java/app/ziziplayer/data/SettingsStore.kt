package app.ziziplayer.data

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("zizi_settings")

enum class AppTheme { GRAPHITE, MIDNIGHT, AMOLED, SUNSET }

data class UserSettings(val theme: AppTheme = AppTheme.GRAPHITE, val accentFromArtwork: Boolean = true, val folderUris: Set<String> = emptySet())

class SettingsStore(private val context: Context) {
    private val theme = stringPreferencesKey("theme")
    private val dynamicAccent = booleanPreferencesKey("dynamic_accent")
    private val folders = stringSetPreferencesKey("folders")

    val settings: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            theme = runCatching { AppTheme.valueOf(p[theme] ?: AppTheme.GRAPHITE.name) }.getOrDefault(AppTheme.GRAPHITE),
            accentFromArtwork = p[dynamicAccent] ?: true,
            folderUris = p[folders] ?: emptySet()
        )
    }
    suspend fun setTheme(value: AppTheme) = context.dataStore.edit { it[theme] = value.name }
    suspend fun setDynamicAccent(value: Boolean) = context.dataStore.edit { it[dynamicAccent] = value }
    suspend fun addFolder(uri: Uri) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) + uri.toString() }
    suspend fun removeFolder(uri: String) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) - uri }
}
