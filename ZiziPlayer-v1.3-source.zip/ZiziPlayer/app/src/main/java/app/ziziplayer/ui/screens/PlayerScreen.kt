package app.ziziplayer.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.palette
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlin.math.pow
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class,ExperimentalMaterial3Api::class)
@Composable fun PlayerScreen(
    tracks:List<TrackEntity>, playback:PlaybackState, favoriteIds:Set<String>, playlists:List<PlaylistEntity>, theme:AppTheme,
    onBack:()->Unit,onPlayPause:()->Unit,onSeek:(Long)->Unit,onIndex:(Int)->Unit,onNext:()->Unit,onPrevious:()->Unit,
    onShuffle:()->Unit,onRepeat:()->Unit,onFavorite:(TrackEntity)->Unit,onPickFolder:()->Unit,
    loadFx:suspend(String)->TrackFxEntity,onApplyFx:(String,Float,Float,Int)->Unit,onAddToPlaylist:(Long,String)->Unit
) {
    if(tracks.isEmpty()) return
    val p=palette(theme)
    val context=LocalContext.current
    val currentIndex=playback.currentIndex.coerceIn(tracks.indices)
    val current=tracks[currentIndex]
    val pager=rememberPagerState(initialPage=currentIndex,pageCount={tracks.size})
    var showFx by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }

    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.distinctUntilChanged().collect { page ->
            if(page!=playback.currentIndex) onIndex(page)
        }
    }
    LaunchedEffect(playback.currentIndex,pager.isScrollInProgress) {
        if(!pager.isScrollInProgress && pager.currentPage!=currentIndex) pager.animateScrollToPage(currentIndex)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.top,p.middle,p.bottom)))) {
        Artwork(current,Modifier.fillMaxWidth().height(430.dp).blur(90.dp).alpha(.18f),ContentScale.Crop)
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(75.dp).padding(horizontal=14.dp),verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack) { Icon(Icons.Rounded.KeyboardArrowDown,null,tint=p.text,modifier=Modifier.size(38.dp)) }
                Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("ПАПКА НА УСТРОЙСТВЕ",color=p.subtext,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.4.sp)
                    Text(current.sourceFolder,color=p.text,fontSize=18.sp,fontWeight=FontWeight.Bold,maxLines=1)
                }
                IconButton(onClick={
                    runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="audio/*";putExtra(Intent.EXTRA_STREAM,Uri.parse(current.uri));addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) },"Поделиться треком")) }
                }) { Icon(Icons.Rounded.Share,null,tint=p.text,modifier=Modifier.size(31.dp)) }
            }
            BoxWithConstraints(Modifier.fillMaxWidth().height(320.dp)) {
                val playingSize=296.dp
                val pausedSize=267.dp
                val coverSize by animateDpAsState(if(playback.isPlaying) playingSize else pausedSize,spring(dampingRatio=.82f,stiffness=Spring.StiffnessMediumLow),label="cover")
                val padding=((maxWidth-coverSize)/2).coerceAtLeast(0.dp)
                HorizontalPager(
                    state=pager,contentPadding=PaddingValues(horizontal=padding),pageSpacing=18.dp,
                    pageSize=PageSize.Fixed(coverSize),beyondViewportPageCount=1,modifier=Modifier.fillMaxSize(),
                    verticalAlignment=Alignment.CenterVertically
                ) { page ->
                    val selected=page==pager.currentPage
                    val alpha by animateFloatAsState(if(selected)1f else .62f,label="neighbor")
                    Artwork(tracks[page],Modifier.size(coverSize).alpha(alpha).clip(RoundedCornerShape(28.dp)).border(1.dp,Color.White.copy(.06f),RoundedCornerShape(28.dp)))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(current.title,color=p.text,fontSize=28.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(current.artist,color=p.subtext,fontSize=15.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                RoundIcon(if(current.id in favoriteIds)Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,p){onFavorite(current)}
                Spacer(Modifier.width(10.dp));RoundIcon(Icons.Rounded.MoreVert,p){showFx=true}
            }
            LazyRow(Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=20.dp,vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                item { MatteChip("Скорость",Icons.Rounded.Speed,p,true){showFx=true} }
                item { MatteChip("Тональность",Icons.Rounded.GraphicEq,p,false){showFx=true} }
                item { MatteChip("В плейлист",Icons.Rounded.PlaylistAdd,p,false){showPlaylists=true} }
                item { MatteChip("Папка",Icons.Rounded.FolderOpen,p,false,onPickFolder) }
            }
            val duration=playback.durationMs.takeIf{it>0} ?: current.durationMs
            Slider(
                value=playback.positionMs.coerceAtMost(duration).toFloat(),onValueChange={onSeek(it.toLong())},
                valueRange=0f..duration.coerceAtLeast(1).toFloat(),modifier=Modifier.padding(horizontal=11.dp),
                colors=SliderDefaults.colors(thumbColor=p.accent,activeTrackColor=p.accent,inactiveTrackColor=p.chip)
            )
            Row(Modifier.fillMaxWidth().padding(horizontal=22.dp)) {
                Text(formatTime(playback.positionMs),color=p.subtext,fontSize=13.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.weight(1f));Text("-${formatTime((duration-playback.positionMs).coerceAtLeast(0))}",color=p.subtext,fontSize=13.sp,fontWeight=FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth().weight(1f).padding(horizontal=25.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                IconButton(onClick=onShuffle) { Icon(Icons.Rounded.Shuffle,null,tint=if(playback.shuffle)p.accent else p.subtext,modifier=Modifier.size(29.dp)) }
                IconButton(onClick=onPrevious) { Icon(Icons.Rounded.SkipPrevious,null,tint=p.text,modifier=Modifier.size(45.dp)) }
                IconButton(onClick=onPlayPause,modifier=Modifier.size(78.dp)) { Icon(if(playback.isPlaying)Icons.Rounded.Pause else Icons.Rounded.PlayArrow,null,tint=p.text,modifier=Modifier.size(68.dp)) }
                IconButton(onClick=onNext) { Icon(Icons.Rounded.SkipNext,null,tint=p.text,modifier=Modifier.size(45.dp)) }
                IconButton(onClick=onRepeat) { Icon(if(playback.repeatMode==2)Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,null,tint=if(playback.repeatMode==0)p.subtext else p.accent,modifier=Modifier.size(29.dp)) }
            }
            Row(Modifier.fillMaxWidth().height(82.dp).background(p.bottom.copy(alpha=.88f),RoundedCornerShape(topStart=26.dp,topEnd=26.dp)),verticalAlignment=Alignment.CenterVertically) {
                TextButton(onClick={showQueue=true},modifier=Modifier.weight(1f)) { Icon(Icons.Rounded.QueueMusic,null,tint=p.text);Spacer(Modifier.width(9.dp));Text("Очередь ${tracks.size}",color=p.text,fontSize=17.sp,fontWeight=FontWeight.Bold) }
                TextButton(onClick=onPickFolder,modifier=Modifier.weight(1f)) { Icon(Icons.Rounded.FolderOpen,null,tint=p.text);Spacer(Modifier.width(9.dp));Text("Папки",color=p.text,fontSize=17.sp,fontWeight=FontWeight.Bold) }
            }
        }
    }
    if(showFx) FxSheet(current,loadFx,onDismiss={showFx=false},onApply={s,pt,r->onApplyFx(current.id,s,pt,r);showFx=false})
    if(showQueue) QueueSheet(tracks,currentIndex,onDismiss={showQueue=false},onTrack={onIndex(it);showQueue=false},theme=theme)
    if(showPlaylists) PlaylistPickerSheet(playlists,theme,onDismiss={showPlaylists=false}) { id -> onAddToPlaylist(id,current.id);showPlaylists=false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun FxSheet(track:TrackEntity,loadFx:suspend(String)->TrackFxEntity,onDismiss:()->Unit,onApply:(Float,Float,Int)->Unit) {
    var speed by remember(track.id){mutableFloatStateOf(1f)}
    var semitones by remember(track.id){mutableFloatStateOf(0f)}
    var reverb by remember(track.id){mutableFloatStateOf(0f)}
    LaunchedEffect(track.id){ val fx=loadFx(track.id);speed=fx.speed;semitones=(12.0*(kotlin.math.ln(fx.pitch.toDouble())/kotlin.math.ln(2.0))).toFloat();reverb=fx.reverb.toFloat() }
    ModalBottomSheet(onDismissRequest=onDismiss,containerColor=Color(0xFF202024),dragHandle={BottomSheetDefaults.DragHandle(color=Color.White.copy(.45f))}) {
        Column(Modifier.padding(horizontal=24.dp).padding(bottom=32.dp)) {
            Text("Скорость и тональность",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("${track.title} · настройки сохраняются для трека",color=Color(0xFF9E9EA6),fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
            Spacer(Modifier.height(26.dp))
            FxSlider("Скорость","${"%.2f".format(speed)}×",speed,{speed=it},.5f..2f)
            FxSlider("Тональность","${if(semitones>=0)"+" else ""}${semitones.roundToInt()} st",semitones,{semitones=it},-12f..12f,23)
            FxSlider("Reverb / Room","${reverb.roundToInt()} %",reverb,{reverb=it},0f..100f)
            Text("ПРЕСЕТЫ",color=Color(0xFF9E9EA6),fontSize=12.sp,letterSpacing=1.5.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Preset("Slowed"){speed=.85f;semitones=-2f;reverb=38f};Preset("Nightcore"){speed=1.25f;semitones=3f;reverb=10f};Preset("Daycore"){speed=.72f;semitones=-3f;reverb=22f};Preset("Оригинал"){speed=1f;semitones=0f;reverb=0f}
            }
            Button(onClick={onApply(speed,2f.pow(semitones/12f),reverb.roundToInt())},modifier=Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(29.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Color(0xFF111114))) { Text("Применить",fontSize=17.sp,fontWeight=FontWeight.Bold) }
        }
    }
}

@Composable private fun FxSlider(label:String,valueText:String,value:Float,onValue:(Float)->Unit,range:ClosedFloatingPointRange<Float>,steps:Int=0) {
    Row(Modifier.fillMaxWidth()){Text(label,color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text(valueText,color=Color(0xFF7AD8FF),fontWeight=FontWeight.Bold)}
    Slider(value,onValue,valueRange=range,steps=steps,colors=SliderDefaults.colors(thumbColor=Color.White,activeTrackColor=Color(0xFF7AD8FF),inactiveTrackColor=Color(0xFF46464E)))
    Spacer(Modifier.height(8.dp))
}
@Composable private fun Preset(label:String,onClick:()->Unit)=AssistChip(onClick=onClick,label={Text(label)},colors=AssistChipDefaults.assistChipColors(containerColor=Color(0xFF38383E),labelColor=Color.White),border=null)

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun QueueSheet(tracks:List<TrackEntity>,current:Int,onDismiss:()->Unit,onTrack:(Int)->Unit,theme:AppTheme) {
    val p=palette(theme)
    ModalBottomSheet(onDismissRequest=onDismiss,containerColor=p.middle) {
        Text("Очередь · ${tracks.size}",color=p.text,fontSize=25.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=24.dp))
        LazyColumn(contentPadding=PaddingValues(16.dp,12.dp,16.dp,40.dp)) {
            itemsIndexed(tracks,key={_,t->t.id}) { i,t ->
                Row(Modifier.fillMaxWidth().background(if(i==current)p.chip else Color.Transparent,RoundedCornerShape(18.dp)).clickable{onTrack(i)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Artwork(t,Modifier.size(52.dp).clip(RoundedCornerShape(13.dp)));Spacer(Modifier.width(12.dp));Column {Text(t.title,color=p.text,maxLines=1,overflow=TextOverflow.Ellipsis);Text(t.artist,color=p.subtext,fontSize=12.sp)}
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun PlaylistPickerSheet(playlists:List<PlaylistEntity>,theme:AppTheme,onDismiss:()->Unit,onPick:(Long)->Unit) {
    val p=palette(theme)
    ModalBottomSheet(onDismissRequest=onDismiss,containerColor=p.middle) {
        Text("Добавить в плейлист",color=p.text,fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=24.dp))
        if(playlists.isEmpty()) Text("Создайте первый плейлист в библиотеке",color=p.subtext,modifier=Modifier.padding(24.dp))
        playlists.forEach { pl -> TextButton(onClick={onPick(pl.id)},modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp)) { Icon(Icons.Rounded.PlaylistAdd,null,tint=p.accent);Spacer(Modifier.width(12.dp));Text(pl.name,color=p.text,modifier=Modifier.weight(1f)) } }
        Spacer(Modifier.height(28.dp))
    }
}
