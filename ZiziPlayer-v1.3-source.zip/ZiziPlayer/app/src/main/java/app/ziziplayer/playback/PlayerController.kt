package app.ziziplayer.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.session.SessionCommand
import app.ziziplayer.data.TrackEntity
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

@OptIn(UnstableApi::class)
data class PlaybackState(
    val connected: Boolean=false,
    val isPlaying: Boolean=false,
    val currentIndex: Int=0,
    val currentTrackId: String?=null,
    val queueIds: List<String> = emptyList(),
    val positionMs: Long=0,
    val durationMs: Long=0,
    val shuffle: Boolean=false,
    val repeatMode: Int=Player.REPEAT_MODE_ALL
)

@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var future: ListenableFuture<MediaController>?=null
    private var controller: MediaController?=null
    private var pendingQueue: Triple<List<TrackEntity>,Int,Boolean>?=null
    private val _state=MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state

    private val listener=object: Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = publish()
    }

    init {
        val token=SessionToken(context,ComponentName(context,PlaybackService::class.java))
        future=MediaController.Builder(context,token).buildAsync().also { f ->
            f.addListener({
                runCatching { f.get() }.onSuccess { c ->
                    controller=c; c.addListener(listener)
                    pendingQueue?.also { (tracks,index,play) -> pendingQueue=null;setQueue(tracks,index,play) }
                    publish()
                }
            },ContextCompat.getMainExecutor(context))
        }
        scope.launch { while(isActive) { publish(); delay(500) } }
    }

    private fun publish() {
        val p=controller ?: return
        _state.value=PlaybackState(
            connected=true,isPlaying=p.isPlaying,currentIndex=p.currentMediaItemIndex.coerceAtLeast(0),
            currentTrackId=p.currentMediaItem?.mediaId,queueIds=(0 until p.mediaItemCount).map { p.getMediaItemAt(it).mediaId },positionMs=p.currentPosition.coerceAtLeast(0),
            durationMs=p.duration.coerceAtLeast(0),shuffle=p.shuffleModeEnabled,repeatMode=p.repeatMode
        )
    }

    fun setQueue(tracks: List<TrackEntity>, startIndex: Int, play: Boolean=true) {
        if(tracks.isEmpty()) return
        val p=controller ?: run { pendingQueue=Triple(tracks,startIndex,play);return }
        val items=tracks.map { t ->
            MediaItem.Builder().setMediaId(t.id).setUri(t.uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                    .setArtworkUri(t.artworkUri?.let(Uri::parse)).build()
            ).build()
        }
        p.setMediaItems(items,startIndex.coerceIn(items.indices),0); p.prepare(); if(play) p.play(); publish()
    }
    fun playPause() { controller?.let { if(it.isPlaying) it.pause() else it.play() }; publish() }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs) }
    fun seekToIndex(index: Int) { controller?.seekToDefaultPosition(index) }
    fun next()=controller?.seekToNextMediaItem()
    fun previous()=controller?.seekToPreviousMediaItem()
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled=!it.shuffleModeEnabled }; publish() }
    fun cycleRepeat() { controller?.let { it.repeatMode=when(it.repeatMode){ Player.REPEAT_MODE_OFF->Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL->Player.REPEAT_MODE_ONE; else->Player.REPEAT_MODE_OFF } }; publish() }
    fun setPlayback(speed: Float,pitch: Float,reverb: Int=0) {
        controller?.setPlaybackParameters(PlaybackParameters(speed,pitch))
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_REVERB,Bundle.EMPTY),Bundle().apply { putInt("percent",reverb) })
    }
    fun release() { controller?.removeListener(listener); future?.let { MediaController.releaseFuture(it) }; scope.cancel() }
}
