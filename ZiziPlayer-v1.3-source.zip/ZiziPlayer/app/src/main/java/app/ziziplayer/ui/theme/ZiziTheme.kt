package app.ziziplayer.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import app.ziziplayer.data.AppTheme

data class ZiziPalette(val top: Color,val middle: Color,val bottom: Color,val accent: Color,val chip: Color,val text: Color=Color.White,val subtext: Color)

fun palette(theme: AppTheme)=when(theme) {
    AppTheme.GRAPHITE -> ZiziPalette(Color(0xFF3C3C40),Color(0xFF29292C),Color(0xFF18181A),Color.White,Color(0xFF38383B),subtext=Color(0xFF9E9EA4))
    AppTheme.MIDNIGHT -> ZiziPalette(Color(0xFF26304E),Color(0xFF181E34),Color(0xFF0B0E1A),Color(0xFF7AA2FF),Color(0xFF2C3450),subtext=Color(0xFF96A0BE))
    AppTheme.AMOLED -> ZiziPalette(Color(0xFF121212),Color(0xFF080808),Color.Black,Color(0xFF00E096),Color(0xFF1C1C1E),subtext=Color(0xFF8C8C92))
    AppTheme.SUNSET -> ZiziPalette(Color(0xFF4E2C26),Color(0xFF341C1A),Color(0xFF180C0C),Color(0xFFFF8A5C),Color(0xFF482C28),Color(0xFFFFF4F0),Color(0xFFC49E94))
}

@Composable fun ZiziTheme(theme: AppTheme,content: @Composable () -> Unit) {
    val p=palette(theme)
    MaterialTheme(
        colorScheme=darkColorScheme(primary=p.accent,background=p.bottom,surface=p.middle,onSurface=p.text,onBackground=p.text,secondary=p.subtext),
        typography=Typography(), content=content
    )
}
