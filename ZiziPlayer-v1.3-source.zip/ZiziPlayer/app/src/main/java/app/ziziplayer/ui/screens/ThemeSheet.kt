package app.ziziplayer.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.*
import app.ziziplayer.ui.theme.palette

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ThemeSheet(settings:UserSettings,onDismiss:()->Unit,onTheme:(AppTheme)->Unit,onDynamicAccent:(Boolean)->Unit) {
    val p=palette(settings.theme)
    ModalBottomSheet(onDismissRequest=onDismiss,containerColor=p.middle) {
        Text("Оформление",color=p.text,fontSize=26.sp,modifier=Modifier.padding(horizontal=24.dp))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            AppTheme.entries.forEach { theme ->
                val q=palette(theme)
                Column(Modifier.width(120.dp).clickable{onTheme(theme)}) {
                    Box(Modifier.fillMaxWidth().height(170.dp).background(Brush.verticalGradient(listOf(q.top,q.middle,q.bottom)),RoundedCornerShape(24.dp)).border(if(theme==settings.theme)3.dp else 1.dp,if(theme==settings.theme)q.accent else q.chip,RoundedCornerShape(24.dp)))
                    Text(when(theme){AppTheme.GRAPHITE->"Графит";AppTheme.MIDNIGHT->"Полночь";AppTheme.AMOLED->"AMOLED";AppTheme.SUNSET->"Закат"},color=p.text,modifier=Modifier.padding(top=8.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(24.dp),horizontalArrangement=Arrangement.SpaceBetween) {
            Column { Text("Акцент из обложки",color=p.text);Text("Подстраивать элементы под текущий арт",color=p.subtext,fontSize=12.sp) }
            Switch(settings.accentFromArtwork,onDynamicAccent)
        }
        Spacer(Modifier.height(24.dp))
    }
}
