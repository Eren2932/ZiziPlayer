package app.ziziplayer.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlaybackState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
data class MainUiState(
    val tracks: List<TrackEntity> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val settings: UserSettings = UserSettings(),
    val playback: PlaybackState = PlaybackState(),
    val scanning: Boolean = false,
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = ""
) {
    val visibleTracks: List<TrackEntity> get() = tracks.filter {
        (filter != LibraryFilter.FAVORITES || it.id in favoriteIds) &&
            (query.isBlank() || it.title.contains(query,true) || it.artist.contains(query,true))
    }
    val currentTrack: TrackEntity? get() = tracks.firstOrNull { it.id==playback.currentTrackId }
}
enum class LibraryFilter { TRACKS, FAVORITES, PLAYLISTS, FOLDERS }

class MainViewModel(app: Application): AndroidViewModel(app) {
    private val application=app as ZiziApplication
    private val repo=application.repository
    val player=application.playerController
    private val scanning=MutableStateFlow(false)
    private val filter=MutableStateFlow(LibraryFilter.TRACKS)
    private val query=MutableStateFlow("")

    private val baseState = combine(repo.tracks,repo.favoriteIds,repo.playlists,repo.settings,player.state) { tracks,favorites,playlists,settings,playback ->
        MainUiState(tracks=tracks,favoriteIds=favorites,playlists=playlists,settings=settings,playback=playback)
    }
    val uiState: StateFlow<MainUiState> = combine(baseState,scanning,filter,query) { base,isScanning,currentFilter,currentQuery ->
        base.copy(scanning=isScanning,filter=currentFilter,query=currentQuery)
    }.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),MainUiState())

    init { rescan() }
    fun rescan()=viewModelScope.launch { scanning.value=true; runCatching { repo.rescan() }; scanning.value=false }
    fun addFolder(uri: Uri)=viewModelScope.launch { scanning.value=true; runCatching { repo.addFolder(uri) }; scanning.value=false }
    fun setFilter(value: LibraryFilter) { filter.value=value }
    fun setQuery(value: String) { query.value=value }
    fun play(track: TrackEntity) { val list=uiState.value.visibleTracks; player.setQueue(list,list.indexOfFirst { it.id==track.id }.coerceAtLeast(0)) }
    fun toggleFavorite(track: TrackEntity)=viewModelScope.launch { repo.toggleFavorite(track.id,track.id in uiState.value.favoriteIds) }
    fun saveFx(trackId: String,speed: Float,pitch: Float,reverb: Int)=viewModelScope.launch { repo.saveFx(TrackFxEntity(trackId,speed,pitch,reverb)); player.setPlayback(speed,pitch,reverb) }
    suspend fun loadFx(trackId: String)=repo.fx(trackId)
    fun createPlaylist(name: String)=viewModelScope.launch { repo.createPlaylist(name) }
    fun addToPlaylist(playlistId: Long,trackId: String)=viewModelScope.launch { repo.addToPlaylist(playlistId,trackId) }
    fun playPlaylist(playlistId: Long)=viewModelScope.launch { val tracks=repo.playlistTracks(playlistId); if(tracks.isNotEmpty()) player.setQueue(tracks,0) }
    fun setTheme(value: AppTheme)=viewModelScope.launch { repo.setTheme(value) }
    fun setDynamicAccent(value: Boolean)=viewModelScope.launch { repo.setDynamicAccent(value) }
}
