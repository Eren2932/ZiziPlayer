package app.ziziplayer.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable fun rememberArtwork(track: TrackEntity?): State<Bitmap?> {
    val context=androidx.compose.ui.platform.LocalContext.current
    return produceState<Bitmap?>(null,track?.id) {
        value=track?.let { t -> withContext(Dispatchers.IO) {
            fun fromUri(uri: String?): Bitmap? = uri?.let { runCatching { context.contentResolver.openInputStream(Uri.parse(it))?.use(BitmapFactory::decodeStream) }.getOrNull() }
            fromUri(t.artworkUri) ?: runCatching {
                val m=MediaMetadataRetriever()
                try { m.setDataSource(context,Uri.parse(t.uri)); m.embeddedPicture?.let { BitmapFactory.decodeByteArray(it,0,it.size) } }
                finally { m.release() }
            }.getOrNull()
        } }
    }
}

@Composable fun Artwork(track: TrackEntity?,modifier: Modifier=Modifier,contentScale: ContentScale=ContentScale.Crop) {
    val bitmap by rememberArtwork(track)
    Box(modifier.background(Color(0xFF09090B))) {
        if(bitmap!=null) Image(bitmap!!.asImageBitmap(),track?.title,Modifier.fillMaxSize(),contentScale=contentScale)
        else DefaultArtwork(Modifier.fillMaxSize())
    }
}

@Composable private fun DefaultArtwork(modifier: Modifier) {
    Box(modifier.background(Color(0xFF09090B)),contentAlignment=androidx.compose.ui.Alignment.Center) {
        androidx.compose.material3.Text("Z",color=Color.White.copy(alpha=.9f),style=androidx.compose.material3.MaterialTheme.typography.displayLarge)
    }
}
