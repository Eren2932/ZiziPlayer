package app.ziziplayer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.theme.ZiziTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel=viewModel()
            val state by vm.uiState.collectAsStateWithLifecycle()
            var playerOpen by rememberSaveable { mutableStateOf(false) }
            val folderPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::addFolder) }
            val permissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.rescan() }

            LaunchedEffect(Unit) {
                val audioPermission=if(Build.VERSION.SDK_INT>=33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
                val required=buildList {
                    if(ContextCompat.checkSelfPermission(this@MainActivity,audioPermission)!=android.content.pm.PackageManager.PERMISSION_GRANTED) add(audioPermission)
                    if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if(required.isNotEmpty()) permissionLauncher.launch(required.toTypedArray()) else vm.rescan()
            }
            LaunchedEffect(state.playback.currentTrackId) {
                state.playback.currentTrackId?.let { id ->
                    val fx=vm.loadFx(id); vm.player.setPlayback(fx.speed,fx.pitch,fx.reverb)
                }
            }

            val activeQueue=remember(state.tracks,state.playback.queueIds) {
                if(state.playback.queueIds.isEmpty()) state.tracks else state.playback.queueIds.mapNotNull { id -> state.tracks.firstOrNull { it.id==id } }
            }
            ZiziTheme(state.settings.theme) {
                if(playerOpen && state.tracks.isNotEmpty()) {
                    PlayerScreen(
                        tracks=activeQueue,playback=state.playback,favoriteIds=state.favoriteIds,playlists=state.playlists,theme=state.settings.theme,
                        onBack={playerOpen=false},onPlayPause=vm.player::playPause,onSeek=vm.player::seekTo,onIndex=vm.player::seekToIndex,
                        onNext={vm.player.next()},onPrevious={vm.player.previous()},onShuffle=vm.player::toggleShuffle,onRepeat=vm.player::cycleRepeat,
                        onFavorite=vm::toggleFavorite,onPickFolder={folderPicker.launch(null)},loadFx=vm::loadFx,onApplyFx=vm::saveFx,onAddToPlaylist=vm::addToPlaylist
                    )
                } else {
                    LibraryScreen(
                        state=state,onFilter=vm::setFilter,onQuery=vm::setQuery,
                        onTrack={vm.play(it);playerOpen=true},onFavorite=vm::toggleFavorite,onOpenPlayer={playerOpen=true},
                        onPlayPause=vm.player::playPause,onPickFolder={folderPicker.launch(null)},onRescan=vm::rescan,
                        onTheme=vm::setTheme,onDynamicAccent=vm::setDynamicAccent,onCreatePlaylist=vm::createPlaylist,onAddToPlaylist=vm::addToPlaylist,onPlayPlaylist={vm.playPlaylist(it);playerOpen=true}
                    )
                }
            }
        }
    }
}
