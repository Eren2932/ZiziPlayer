#!/usr/bin/env python3
"""Самотест проверок. Появился в 6.37.1, и не от хорошей жизни.

Три «известных подозрительных вызова» висели в выводе `check_call_args.py` с 6.35.0 и были
записаны в ложные срабатывания. Они действительно были ложными — но причина оказалась не
безобидной: `split_top()` принимал оператор сравнения (`cfg.width < 0.3f`) за открытие
угловой скобки generic, скобка никогда не закрывалась, и ВСЕ аргументы правее переставали
считаться переданными. По замеру на 6.37.0 так разбирались 13 вызовов из 2339 в семи файлах:
два подали сигнал, одиннадцать прошли молча с урезанной проверкой.

Смысл этого файла ровно один. Gradle в песочнице запустить нечем, поэтому `tools/check_*.py` —
единственная граница корректности в проекте. У этой границы не было способа сообщить, что она
сломалась: вывод «подозрительных вызовов: 0» и «проверка местами не работает» — это один и тот
же вывод. Фикстуры делают разницу видимой.

Запускать ДО прогона проверок по коду. Не сошлось — сломан прибор, а не код, и результатам
основного прогона в этом случае верить нельзя.

Формат фикстуры: первая строка `// expect: clean` либо `// expect: <подстрока вердикта>`.
Каждая фикстура проверяется отдельным прогоном, в своём каталоге: у скрипта проверки одно
пространство имён на весь корень, и сигнатуры фикстур не должны видеть друг друга.
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES = os.path.join(HERE, 'fixtures')
CHECKER = os.path.join(HERE, 'check_call_args.py')


def expectation(path):
    with open(path, encoding='utf-8') as fh:
        first = fh.readline().strip()
    m = re.match(r'//\s*expect:\s*(.+)$', first)
    if not m:
        return None
    want = m.group(1).strip()
    return None if want == 'clean' else want


def run_checker(kt_path, work):
    """Гоняет проверку на одной фикстуре в изолированном каталоге."""
    root = os.path.join(work, os.path.splitext(os.path.basename(kt_path))[0])
    os.makedirs(root, exist_ok=True)
    shutil.copy(kt_path, root)
    out = subprocess.run(
        [sys.executable, CHECKER, root],
        capture_output=True, text=True, check=False
    )
    return [l for l in out.stdout.splitlines() if '->' in l]


def main():
    if not os.path.isdir(FIXTURES):
        print('НЕТ КАТАЛОГА ФИКСТУР:', FIXTURES)
        return 1

    names = sorted(f for f in os.listdir(FIXTURES) if f.endswith('.kt'))
    if not names:
        print('НЕТ ФИКСТУР в', FIXTURES)
        return 1

    # Root workflow already calls this file from the selected ZIP. Thus uploading
    # only the ZIP enables the new guard, without changing repository workflow YAML.
    # Includes checker fixtures and main/test/androidTest source imports.
    imports = subprocess.run([sys.executable, os.path.join(HERE, 'test_imports_6695.py')], check=False)
    if imports.returncode != 0:
        return 1

    failed = 0
    work = tempfile.mkdtemp(prefix='zizi-selftest-')
    try:
        for name in names:
            path = os.path.join(FIXTURES, name)
            with open(path, encoding='utf-8') as fh:
                if not re.match(r'//\s*expect:', fh.readline()):
                    print(f'ПРОВАЛ  {name}: нет строки `// expect:` в первой строке')
                    failed += 1
                    continue

            want = expectation(path)
            verdicts = run_checker(path, work)

            if want is None:
                if verdicts:
                    failed += 1
                    print(f'ПРОВАЛ  {name}: ждали чисто, получили {len(verdicts)}:')
                    for v in verdicts:
                        print('           ' + v.strip())
                else:
                    print(f'ок      {name}: чисто, как и ждали')
            else:
                if any(want in v for v in verdicts):
                    print(f'ок      {name}: найдено «{want}»')
                else:
                    failed += 1
                    print(f'ПРОВАЛ  {name}: ждали «{want}», получили '
                          f'{len(verdicts) or "ничего"}:')
                    for v in verdicts:
                        print('           ' + v.strip())
    finally:
        shutil.rmtree(work, ignore_errors=True)

    print(f'\nфикстур: {len(names)} · провалов: {failed}')
    if failed:
        print('Сломан ИНСТРУМЕНТ, а не код. Результатам основного прогона верить нельзя.')
    # 6.39.7: the existing root workflow calls this preflight from the source ZIP.
    # Run UI source contracts here too, so uploading only the ZIP does not leave new
    # regressions disconnected from CI. These are NOT Compose / Kotlin execution tests.
    if not failed:
        for name in ('test_headset_icon_6823.py', 'test_playback_6822.py', 'test_playback_6822_contracts.py', 'test_player_brand_6751_contracts.py', 'test_search_6760.py', 'test_search_6770.py', 'test_search_menu_6771.py', 'test_search_6780.py', 'test_search_6790.py', 'test_audio_output_6750.py', 'test_audio_output_6750_contracts.py', 'test_library_6710.py', 'test_library_6711.py', 'test_library_6712.py', 'test_library_6713.py', 'test_resolver_6650.py', 'test_live_ui_contracts.py', 'test_menu_ui_contracts.py',
                     'test_artwork_ui_contracts.py', 'test_artwork_color_math.py',
                     'test_lyrics_palette_6720.py', 'test_lyrics_palette_6720_contracts.py',
                     'test_lyrics_preview_6800.py', 'test_lyrics_preview_6800_contracts.py',
                     'test_artwork_surfaces_6730.py',
                     'test_artwork_surfaces_6730_contracts.py',
                     'test_artwork_context_6740.py', 'test_artwork_context_6740_contracts.py',
                     'test_transition_ui_contracts.py', 'test_player_transition_policy.py',
                     'test_mobile_640_contracts.py', 'test_mobile_640.py',
                     'test_mobile_641_contracts.py', 'test_mobile_641.py',
                     'test_mobile_642_contracts.py', 'test_mobile_642.py',
                     'test_mobile_6410_contracts.py', 'test_mobile_6411_contracts.py',
                     'test_mobile_6412_contracts.py', 'test_mobile_6413_contracts.py',
                     'test_mobile_6414_contracts.py', 'test_indicator_motion.py', 'test_pcm_spectrum.py',
                     'test_collection_6420_contracts.py', 'test_collection_6420.py',
                     'test_polish_6430_contracts.py', 'test_polish_6430.py',
                     'test_lyrics_6440_contracts.py', 'test_lyrics_6440.py',
                     'test_lyrics_file_api.py', 'test_lyrics_6450.py', 'test_lyrics_6450_contracts.py',
                     'test_lyrics_6460.py', 'test_lyrics_6460_contracts.py',
                     'test_lyrics_6461_contracts.py', 'test_lyrics_6611.py', 'test_lyrics_hybrid_6620.py', 'test_lyrics_6640.py',
                     'test_listening_6470.py', 'test_home_6470_contracts.py',
                     'test_home_6480_geometry.py', 'test_home_6480_contracts.py', 'test_home_6490.py',
                     'test_startup_6460.py', 'test_startup_6460_contracts.py', 'test_metadata_6481.py',
                     'test_account_6500.py', 'test_account_6500_contracts.py', 'test_account_6510_contracts.py', 'test_account_6520_contracts.py',
                     'test_library_6530.py', 'test_library_6530_contracts.py', 'test_account_6540.py', 'test_auth_6541.py', 'test_ui_6550.py', 'test_ui_6560.py', 'test_avatar_crop_6570.py', 'test_avatar_ui_6570.py', 'test_auth_6610.py',
                     'test_queue_6660_contracts.py', 'test_ui_6670.py', 'test_release_6680.py', 'test_home_6580.py', 'test_home_6820.py', 'test_reco_http_contract_6821.py', 'test_reco2_6830.py', 'test_reco2_rc2_6830.py', 'test_feed_profile_ttl_6830.py'):
            print('\n' + ('Production Java core execution: ' if name in ('test_playback_6822.py', 'test_lyrics_preview_6800.py', 'test_audio_output_6750.py', 'test_artwork_context_6740.py', 'test_artwork_surfaces_6730.py', 'test_lyrics_palette_6720.py', 'test_artwork_color_math.py', 'test_player_transition_policy.py', 'test_mobile_640.py', 'test_mobile_641.py', 'test_mobile_642.py', 'test_indicator_motion.py', 'test_pcm_spectrum.py', 'test_collection_6420.py', 'test_polish_6430.py', 'test_lyrics_6440.py', 'test_lyrics_file_api.py', 'test_lyrics_6450.py', 'test_lyrics_6460.py', 'test_startup_6460.py', 'test_home_6480_geometry.py', 'test_account_6500.py', 'test_avatar_crop_6570.py')
                           else 'UI source contracts (not Kotlin execution): ') + name, flush=True)
            result = subprocess.run([sys.executable, os.path.join(HERE, name)], check=False)
            if result.returncode != 0:
                failed += 1
    # The repository workflow invokes this script from the selected source ZIP.
    # Keep strict matching tests connected even if only the ZIP is uploaded.
    print("\nProduction Python server 1.15: smart matcher + Reco feed + unified installer (not live ASGI/audio):", flush=True)
    for name in ('test_smart_match.py', 'test_version_family.py', 'test_zizi_reco.py', 'test_zizi_feed.py', 'test_reco2.py', 'test_reco2_rc2.py',
                 'test_server_deploy.py', 'test_smoke_stage2.py'):
        result = subprocess.run([sys.executable, os.path.join(HERE, '..', 'server', 'tools', name)], check=False)
        if result.returncode != 0:
            failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_server_112_bundle.py')], check=False)
    if result.returncode != 0:
        failed += 1
    print("\nProduction geometry, SQL and profile contracts: test_collection_6600.py", flush=True)
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_collection_6600.py')], check=False)
    if result.returncode != 0:
        failed += 1
    print("\nCollection menu/action regressions: test_collection_6601.py", flush=True)
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_collection_6601.py')], check=False)
    if result.returncode != 0:
        failed += 1
    print("\nReference/header menu regressions: test_collection_6602.py", flush=True)
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_collection_6602.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_ci_6697.py')], check=False)
    if result.returncode != 0:
        failed += 1
    print("\nCamera morph: production geometry and wiring (not Android):", flush=True)
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_material_6696.py')], check=False)
    if result.returncode != 0:
        return result.returncode
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_morph_6692.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_pixel_probe_6699.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_contact_66910.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_collection_restore_66911.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_stability_66912.py')], check=False)
    if result.returncode != 0:
        failed += 1
    result = subprocess.run([sys.executable, os.path.join(HERE, 'test_camera_contour_66913.py')], check=False)
    if result.returncode != 0:
        failed += 1
    for name in ('test_camera_input_66914.py', 'test_camera_gooey_66915.py', 'test_camera_anchor_66916.py', 'test_camera_reach_66918.py', 'test_reorder_66919.py', 'test_reorder_66920.py', 'test_profile_6700.py', 'test_live_order_6700.py', 'test_profile_6701.py', 'test_camera_notch_6702.py', 'test_camera_compat_6703.py', 'test_player_corners_6704.py'):
        result = subprocess.run([sys.executable, os.path.join(HERE, name)], check=False)
        if result.returncode != 0:
            failed += 1
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
