# 6.68.0 — исправление CI (#497)

Причина подтверждена логом пользователя и тестом: `.github/workflows/build.yml`
содержал запуск test_release_6680.py, а repo-update/.github/workflows/build.yml — нет.
Тест test_workflow_copies_match останавливал сборку ДО Gradle/Kotlin.

Изменения относительно предыдущего ZIP 6.68.0:
- Синхронизированы две копии workflow (побайтово одинаковые).
- test_account_6520_contracts.py добавлен в check_selftest.py, чтобы это расхождение
  обнаруживалось основным локальным прогоном, а не только следующим этапом CI.
- Обновлён манифест контрольных сумм. Код приложения и версия 124/6.68.0 не менялись.

Проверено на the Computer:
- Все 16 команд этапа Stage 2 regression and diagnostic probe tests: EXIT 0.
- check_selftest.py с включённым тестом копий workflow: EXIT 0.
- 4 статических проверки: 0 замечаний; синтаксис Kotlin также проверен на app/src.
- Тесты guard, catalog wiring, device, library policy и синтаксис сервера: EXIT 0.
- test_ci_source.py: EXIT 0.

Это исходники, не APK. Gradle/Kotlin/JVM-тесты и Android-устройство здесь не проверены.
Проверки конфигурации секретов GitHub не воспроизводились.

Загрузка: удалить прежний ZiziPlayer-v6.68.0.zip и загрузить
ZiziPlayer-v6.68.0-ci-fix.zip в корень main. Желательно одним коммитом.
НЕ держать одновременно оба архива с versionCode 124: селектор отклоняет дубли.
Workflow внутри ZIP не меняет workflow корня репозитория; для этого исправления менять
корневой workflow не требуется — исправляется сравнение файлов внутри выбранного проекта.
