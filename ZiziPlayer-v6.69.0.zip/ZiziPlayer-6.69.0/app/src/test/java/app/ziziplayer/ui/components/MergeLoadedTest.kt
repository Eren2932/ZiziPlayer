package app.ziziplayer.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

/** 6.68.0: слияние скачанных участков с живым буфером — без двойной заливки и «дыр» в полпикселя. */
class MergeLoadedTest {
    private fun eq(expected: List<Float>, actual: List<Float>) {
        assertEquals(expected.size, actual.size)
        expected.indices.forEach { assertEquals(expected[it], actual[it], 1e-4f) }
    }

    @Test fun emptyWithoutBufferIsEmpty() = eq(emptyList(), mergeLoaded(emptyList(), 0.3f, 0.3f))

    @Test fun seekBackKeepsDownloadedTail() =
        // Скачано 0..0.9, бегунок перемотан на 0.1: тень НЕ сжимается до [0.1, буфер].
        eq(listOf(0f, 0.9f), mergeLoaded(listOf(0f, 0.9f), 0.1f, 0.12f))

    @Test fun seekForwardShowsTwoIslands() =
        eq(listOf(0f, 0.3f, 0.7f, 0.75f), mergeLoaded(listOf(0f, 0.3f), 0.7f, 0.75f))

    @Test fun overlappingAndUnsortedAreMerged() =
        eq(listOf(0.1f, 0.6f), mergeLoaded(listOf(0.4f, 0.6f, 0.1f, 0.45f), 0.2f, 0.3f))

    @Test fun tinyGapsAreGlued() =
        eq(listOf(0f, 0.5f), mergeLoaded(listOf(0f, 0.25f, 0.253f, 0.5f), 0f, 0f))

    @Test fun valuesAreClamped() =
        eq(listOf(0f, 1f), mergeLoaded(listOf(-0.2f, 1.4f), 0f, 0f))
}
