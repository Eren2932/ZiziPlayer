package app.ziziplayer.library;

import static app.ziziplayer.library.LibrarySyncPolicy.Action.*;

public final class LibrarySyncPolicyChecks {
    private static int checks;
    private static void expect(Object wanted, Object actual) {
        checks++;
        if (!wanted.equals(actual)) throw new AssertionError(wanted + " != " + actual);
    }
    public static void main(String[] args) {
        expect(RESTORE, LibrarySyncPolicy.choose(false, false, true, false, false)); // reinstall
        expect(CHOOSE, LibrarySyncPolicy.choose(false, false, true, true, false)); // old guest data
        expect(CHOOSE, LibrarySyncPolicy.choose(false, false, false, true, false)); // first binding
        expect(CHOOSE, LibrarySyncPolicy.choose(false, false, false, false, false)); // explicit opt-in
        expect(CONNECT, LibrarySyncPolicy.choose(true, true, true, true, false)); // pending offline edits
        expect(RESTORE, LibrarySyncPolicy.choose(true, false, true, true, true)); // other device only
        expect(CHOOSE, LibrarySyncPolicy.choose(true, false, true, true, false)); // concurrent edits
        expect(CHOOSE, LibrarySyncPolicy.choose(true, true, false, true, true)); // server lost copy
        expect(RESTORE, LibrarySyncPolicy.choose(true, false, true, false, false)); // empty phone, same owner (6.68.0)
        // Exhaustive 32-state matrix: never silently upload a new account's guest library.
        for (int mask=0;mask<32;mask++) {
            boolean same=(mask&1)!=0, rev=(mask&2)!=0, cloud=(mask&4)!=0;
            boolean data=(mask&8)!=0, equal=(mask&16)!=0;
            LibrarySyncPolicy.Action action=LibrarySyncPolicy.choose(same,rev,cloud,data,equal);
            if (!cloud) expect(CHOOSE, action);
            if (!same && data) expect(CHOOSE, action);
            if (action==CONNECT) expect(true,same && rev && cloud);
            if (action==RESTORE) expect(true,cloud && (!data || (same && equal)));
        }
        expect(true, LibrarySyncPolicy.pauseEmptyUpload(false,true));
        expect(false, LibrarySyncPolicy.pauseEmptyUpload(true,true));
        expect(false, LibrarySyncPolicy.pauseEmptyUpload(false,false));
        expect(false, LibrarySyncPolicy.pauseEmptyUpload(true,false));
        System.out.println("Library sync policy: " + checks + " assertions passed");
    }
}
