package app.ziziplayer.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 6.67.0: правило имени плейлиста — одно для формы, переименования, импорта и вьюмодели. */
class PlaylistNamingTest {

    @Test fun cleanTrimsAndCollapsesWhitespace() {
        assertEquals("Ночной вайб", PlaylistNaming.clean("  Ночной \t\n  вайб  "))
        assertEquals("", PlaylistNaming.clean("   \n\t "))
    }

    @Test fun cleanCapsLengthWithoutTrailingSpace() {
        val raw = "a".repeat(59) + " bbbb"
        val clean = PlaylistNaming.clean(raw)
        assertTrue(clean.length <= PlaylistNaming.MAX_LENGTH)
        assertEquals("a".repeat(59), clean)
    }

    @Test fun limitInputForbidsNewlinesAndCaps() {
        assertEquals("a b", PlaylistNaming.limitInput("a\nb"))
        assertEquals(PlaylistNaming.MAX_LENGTH, PlaylistNaming.limitInput("x".repeat(500)).length)
    }

    @Test fun duplicateIgnoresCaseAndSpaces() {
        val existing = listOf("Любимое", "Ночь  в городе")
        assertTrue(PlaylistNaming.isDuplicate(" любимое ", existing))
        assertTrue(PlaylistNaming.isDuplicate("ночь в ГОРОДЕ", existing))
        assertFalse(PlaylistNaming.isDuplicate("Любимое 2", existing))
        assertFalse(PlaylistNaming.isDuplicate("   ", existing))
    }

    @Test fun suggestionsStartWithMonthAndSkipTakenNames() {
        val s = PlaylistNaming.suggestions(month = 9, year = 2026, existing = listOf("любимое"))
        assertEquals("Сентябрь 2026", s.first())
        assertFalse(s.any { it.equals("Любимое", ignoreCase = true) })
        assertTrue(s.size <= 6)
        assertEquals("", PlaylistNaming.monthName(13))
    }

    @Test fun coverHueIsStableAndInRange() {
        val a = PlaylistNaming.coverHue("Фокус")
        assertEquals(a, PlaylistNaming.coverHue("  фокус "), 0f)
        for (name in listOf("a", "Я", "🔥", "Очень длинное имя плейлиста", "123")) {
            val h = PlaylistNaming.coverHue(name)
            assertTrue(h >= 0f && h < 360f)
        }
        assertEquals(24f, PlaylistNaming.coverHue(""), 0f)
    }

    @Test fun coverGlyphSkipsSymbols() {
        assertEquals("Н", PlaylistNaming.coverGlyph("🔥 ночь"))
        assertEquals("7", PlaylistNaming.coverGlyph("7 лет"))
        assertEquals("", PlaylistNaming.coverGlyph("🔥🔥"))
    }
}
