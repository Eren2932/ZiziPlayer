package app.ziziplayer.playback.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 6.69.0. Логика пресетов и выбора тракта — то, что видит пользователь на экране «Звук»:
 * подсветка активного чипа, сложение слоёв, снятие повторным нажатием, авто-запас.
 */
class DspPresetsTest {

    private fun preset(name: String) = DspPresets.all.first { it.name == name }

    @Test fun `every preset is recognised as active right after applying`() {
        for (p in DspPresets.all) {
            val c = p.applyTo(DspConfig.NEUTRAL)
            assertTrue(p.name, p.isActive(c))
            // Кодек округляет до сотых — подсветка должна пережить сохранение и загрузку.
            assertTrue(p.name + " after codec", p.isActive(DspCodec.decode(DspCodec.encode(c))))
        }
    }

    @Test fun `timbre and scene presets stack`() {
        val c = preset("Под водой").applyTo(preset("Наушники").applyTo(DspConfig.NEUTRAL))
        assertTrue(preset("Наушники").isActive(c))
        assertTrue(preset("Под водой").isActive(c))
        assertEquals("Наушники", DspPresets.activeTimbre(c)?.name)
        assertEquals("Под водой", DspPresets.activeScene(c)?.name)
    }

    @Test fun `same layer preset replaces without leftovers`() {
        val club = preset("Клуб").applyTo(DspConfig.NEUTRAL)
        assertTrue(club.drive > 0f)
        val hall = preset("Концертный зал").applyTo(club)
        assertEquals(0f, hall.drive)
        assertFalse(preset("Клуб").isActive(hall))
        val rock = preset("Рок").applyTo(preset("Глубокий низ").applyTo(DspConfig.NEUTRAL))
        assertEquals(0f, rock.bassDrive)
    }

    @Test fun `clearing a layer keeps the other one`() {
        val c = preset("8D").applyTo(preset("Бас+").applyTo(DspConfig.NEUTRAL))
        val noTimbre = c.clearedTimbre()
        assertFalse(noTimbre.hasTimbre)
        assertTrue(preset("8D").isActive(noTimbre))
        val noScene = c.clearedScene()
        assertFalse(noScene.hasScene)
        assertTrue(preset("Бас+").isActive(noScene))
    }

    @Test fun `manual band edit turns preset highlight off`() {
        val c = preset("Бас+").applyTo(DspConfig.NEUTRAL)
        val edited = c.copy(bandsDb = c.bandsDb.toMutableList().also { it[5] = 3f })
        assertFalse(preset("Бас+").isActive(edited))
        assertNull(DspPresets.activeTimbre(edited))
    }

    @Test fun `timbre preset enables auto headroom on legacy configs`() {
        val legacy = DspCodec.decode("v1|on=1;pre=-3;bands=8,7,4,1,-1,0,0,1,2,2")
        assertFalse(legacy.autoGain)
        val c = preset("Бас+").applyTo(legacy)
        assertTrue(c.autoGain)
        assertTrue(DspResponse.autoGainDb(c) < -5f)
    }

    @Test fun `resolve order global then track then legacy reverb`() {
        val g = DspCodec.encode(preset("Рок").applyTo(DspConfig.NEUTRAL))
        val t = DspCodec.encode(preset("Вокал").applyTo(DspConfig.NEUTRAL))
        assertTrue(preset("Рок").isActive(DspResolve.forTrack(t, 0, true, g)))
        assertTrue(preset("Вокал").isActive(DspResolve.forTrack(t, 0, false, g)))
        assertTrue(DspResolve.forTrack(null, 60, false, g).reverbMix > 0f)
        assertEquals(DspConfig.NEUTRAL, DspResolve.forTrack(null, 0, false, null))
        // Пустая строка трека — осознанное «выключено», легаси-ревер поверх не лезет.
        assertTrue(DspResolve.forTrack("", 60, false, null).isNeutral)
    }
}
