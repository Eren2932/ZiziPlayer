package app.ziziplayer.library;

/** Pure startup decision: identity is established by the account API, never by these flags. */
public final class LibrarySyncPolicy {
    private LibrarySyncPolicy() {}
    public enum Action { CONNECT, RESTORE, CHOOSE }
    public static Action choose(boolean sameOwner, boolean revisionMatches, boolean cloudPresent,
                                boolean localHasData, boolean localMatchesSaved) {
        if (sameOwner && revisionMatches && cloudPresent) return Action.CONNECT;
        // 6.68.0: на телефоне нет ничего личного, а в аккаунте есть — выбирать нечего.
        // Восстановление всё равно пишет страховочную копию перед заменой.
        if (cloudPresent && !localHasData) return Action.RESTORE;
        if (cloudPresent && ((!sameOwner && !localHasData) || (sameOwner && localMatchesSaved)))
            return Action.RESTORE;
        return Action.CHOOSE;
    }
    public static boolean pauseEmptyUpload(boolean localHasData, boolean cloudHasData) {
        return !localHasData && cloudHasData;
    }
}
