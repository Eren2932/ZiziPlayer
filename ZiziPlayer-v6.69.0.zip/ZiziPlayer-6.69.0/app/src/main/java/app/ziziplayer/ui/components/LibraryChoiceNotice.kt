package app.ziziplayer.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay

/**
 * 6.68.0. Тихое уведомление вместо полноэкранного окна «Сохранение библиотеки».
 *
 * До этой версии любое `needsChoice` (а оно поднималось и на ложных развилках — потерянный
 * ответ сервера, история прослушиваний, изменившаяся за полсекунду до проверки) открывало
 * экран поверх всего приложения. Теперь синхронизация идёт в фоне, настоящую развилку
 * человек видит одной плашкой сверху — один раз на конкретную развилку, с кнопкой «Открыть».
 * Плашка сама уходит через [autoHideMs] и больше не возвращается к той же развилке; сам
 * вопрос никуда не девается — он виден в меню аккаунта («Нужно выбрать копию»).
 */
@Composable
fun LibraryChoiceNotice(
    visible: Boolean,
    onOpen: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    autoHideMs: Long = 9_000L
) {
    val dismiss by rememberUpdatedState(onDismiss)
    LaunchedEffect(visible) {
        if (visible) { delay(autoHideMs); dismiss() }
    }
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut()
    ) {
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .fillMaxWidth()
                .shadow(10.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF262626))
                .clickable(onClick = onOpen)
                .padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(ZiziIcons.Cloud, null, tint = Color(0xFFF2F2F2), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Нужно выбрать копию библиотеки", color = Color(0xFFF2F2F2), fontSize = 14.5.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("На телефоне и в аккаунте разные данные. Ничего не удалено.", color = Color(0xFFA8A8A8),
                    fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text("Открыть", color = LocalPalette.current.brand, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onOpen)
                    .padding(horizontal = 8.dp, vertical = 6.dp))
            Icon(ZiziIcons.Close, "Скрыть", tint = Color(0xFFA8A8A8),
                modifier = Modifier.clip(CircleShape).clickable(onClick = onDismiss).padding(8.dp).size(18.dp))
        }
    }
}
