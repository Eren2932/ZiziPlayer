package app.ziziplayer.playback

import app.ziziplayer.data.TrackFxEntity
import app.ziziplayer.data.UserSettings
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspResolve
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * 6.69.0. Тракт трека на стороне сервиса.
 *
 * До 6.69.0 свою настройку трека выбирал только MainViewModel — то есть только пока жив экран.
 * Свернул приложение, система убила Activity, очередь переключилась на следующий трек — и он
 * играл с настройкой предыдущего. Теперь на каждой смене трека сервис сам читает строку трека и
 * глобальный режим и применяет ту же [DspResolve.forTrack], что и экран.
 *
 * Гонка с экраном закрыта счётчиком: если за время чтения из базы пришла команда от UI (человек
 * уже двигает ползунок на новом треке), результат чтения выбрасывается — последнее слово за UI.
 */
internal class DspDirector(
    private val scope: CoroutineScope,
    private val loadFx: suspend (String) -> TrackFxEntity?,
    private val loadSettings: suspend () -> UserSettings,
    private val applyConfig: (DspConfig) -> Unit
) {
    private var uiSeq = 0L
    private var job: Job? = null

    /** Команда тракта пришла от контроллера: она новее всего, что мы сейчас читаем. */
    fun onUiCommand() {
        uiSeq++
        job?.cancel()
    }

    fun onTrack(mediaId: String?) {
        if (mediaId.isNullOrEmpty()) return
        job?.cancel()
        val started = uiSeq
        job = scope.launch {
            val cfg = runCatching {
                val fx = loadFx(mediaId)
                val s = loadSettings()
                DspResolve.forTrack(fx?.eqConfig, fx?.reverb ?: 0, s.dspGlobal, s.dspConfig)
            }.getOrNull() ?: return@launch
            if (uiSeq == started) applyConfig(cfg)
        }
    }

    fun cancel() {
        job?.cancel()
    }
}
