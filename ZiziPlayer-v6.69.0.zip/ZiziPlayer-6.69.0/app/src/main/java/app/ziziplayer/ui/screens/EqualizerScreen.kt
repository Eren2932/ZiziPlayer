package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.EqProfileEntity
import app.ziziplayer.playback.dsp.DspCodec
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspMeter
import app.ziziplayer.playback.dsp.DspPreset
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.playback.dsp.DspResponse
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.LocalAudioSpectrum
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

/**
 * Экран «Звук» (6.69.0 — переписан).
 *
 * Было: одна лента на пять экранов — кривая, пре-амп, три ряда пресетов, которые правили
 * произвольные поля, двенадцать ползунков модулей вперемешку, а переключатель «на все треки»
 * прятался в самом низу. Человек не понимал ни что сейчас звучит, ни что изменит следующий тап.
 *
 * Стало — три ответа на три вопроса:
 *  1. ЧТО ЗВУЧИТ — шапка: общий выключатель, область действия («этот трек / вся музыка») одним
 *     сегментом наверху и строка статуса (активные пресеты, авто-запас, работа лимитера);
 *  2. КАК ЗВУЧИТ ТРЕК — вкладка «Тембр»: настоящая АЧХ тракта, пресеты стиля и устройства,
 *     тонкая настройка свёрнута;
 *  3. ГДЕ ЗВУЧИТ — вкладка «Сцена»: пресеты пространства и модули, сгруппированные карточками.
 * Плюс «Мои» — сохранённые настройки.
 *
 * Пресеты подсвечиваются честно (слой совпадает — чип горит), повторный тап снимает пресет,
 * пресеты тембра и сцены складываются (см. [DspPreset]).
 *
 * Собственного состояния тракта у экрана по-прежнему нет: читает `vm.dsp`, пишет через VM.
 */
@Composable
fun EqualizerScreen(vm: MainViewModel, onClose: () -> Unit) {
    val p = LocalPalette.current
    val cfg by vm.dsp.collectAsStateWithLifecycle()
    val profiles by vm.eqProfiles.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var saveDialog by remember { mutableStateOf(false) }

    // Лимитер опрашивается, только пока экран открыт: аудиопоток лишь пишет одно volatile-поле.
    var reduction by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = DspMeter.reductionDb()
            // Вверх сразу, вниз плавно: иначе цифра мигает на каждой бочке и её не прочитать.
            reduction = if (now > reduction) now else reduction * 0.8f + now * 0.2f
            delay(150)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Header(
            enabled = cfg.enabled,
            onClose = onClose,
            onToggle = { vm.setDsp(cfg.copy(enabled = it)) }
        )
        ScopeSelector(global = settings.dspGlobal, onChange = { vm.setDspGlobal(it) })
        StatusStrip(cfg = cfg, reductionDb = reduction, onEnable = { vm.setDsp(cfg.copy(enabled = true)) })
        Segmented(
            options = listOf("Тембр", "Сцена", "Мои"),
            selected = tab,
            marks = listOf(cfg.enabled && cfg.hasTimbre, cfg.enabled && cfg.hasScene, false),
            onSelect = { tab = it },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Column(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            when (tab) {
                0 -> TimbreTab(cfg, vm)
                1 -> SceneTab(cfg, vm)
                else -> MineTab(cfg, profiles, vm, onSave = { saveDialog = true })
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (saveDialog) {
        SaveProfileDialog(
            onDismiss = { saveDialog = false },
            onSave = { name -> vm.saveEqProfile(name); saveDialog = false }
        )
    }
}

/* ------------------------------------------------------------------ шапка */

@Composable
private fun Header(enabled: Boolean, onClose: () -> Unit, onToggle: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(start = 8.dp, end = 18.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onClose)
                .padding(12.dp)
        ) {
            Icon(ZiziIcons.Close, contentDescription = "Закрыть", tint = p.text, modifier = Modifier.size(22.dp))
        }
        Text(
            "Звук",
            color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        Text(
            if (enabled) "Вкл" else "Выкл",
            color = if (enabled) p.accent else p.subtext,
            fontSize = 13.sp, fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.width(10.dp))
        Switch(checked = enabled, onCheckedChange = onToggle, colors = switchColors())
    }
}

/**
 * Область действия — первое, что надо знать о настройке, поэтому она наверху, а не тумблером
 * под двенадцатью ползунками. Переключение переносит то, что звучит, в выбранную сторону.
 */
@Composable
private fun ScopeSelector(global: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.padding(horizontal = 16.dp)) {
        Segmented(
            options = listOf("Этот трек", "Вся музыка"),
            selected = if (global) 1 else 0,
            onSelect = { onChange(it == 1) },
            compact = true
        )
        Text(
            if (global) "Одна настройка на всё. Свои настройки треков не пропали — вернутся, если выключить."
            else "Настройка запоминается для этого трека и включится вместе с ним.",
            color = p.subtext, fontSize = 11.5.sp,
            modifier = Modifier.padding(start = 4.dp, top = 6.dp)
        )
    }
}

/**
 * Одна строка «что сейчас звучит». Именно её не хватало: после трёх пресетов и пары ползунков
 * человек уже не мог сказать, в каком состоянии тракт.
 */
@Composable
private fun StatusStrip(cfg: DspConfig, reductionDb: Float, onEnable: () -> Unit) {
    val p = LocalPalette.current
    val timbre = DspPresets.activeTimbre(cfg)
    val scene = DspPresets.activeScene(cfg)
    val autoGain = DspResponse.autoGainDb(cfg)
    val squeezing = cfg.enabled && reductionDb >= 1f

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(p.chip.copy(alpha = 0.55f))
            .then(if (!cfg.enabled) Modifier.clickable(onClick = onEnable) else Modifier)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        if (!cfg.enabled) {
            Text("Обработка выключена", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (cfg.hasTimbre || cfg.hasScene) "Настройки сохранены. Нажми, чтобы включить."
                else "Звук идёт как в записи. Выбери пресет или двигай кривую — обработка включится сама.",
                color = p.subtext, fontSize = 12.sp
            )
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusPart("Тембр", when {
                !cfg.hasTimbre -> "ровно"
                timbre != null -> timbre.name
                else -> "своя кривая"
            }, Modifier.weight(1f))
            StatusPart("Сцена", when {
                !cfg.hasScene -> "нет"
                scene != null -> scene.name
                else -> "своя"
            }, Modifier.weight(1f))
        }
        if (autoGain < -0.05f || squeezing) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (autoGain < -0.05f) {
                    Badge("Запас ${dbText(autoGain)}", p.subtext)
                }
                if (squeezing) {
                    Badge("Лимитер −${"%.1f".format(reductionDb)} дБ", DANGER)
                }
            }
            if (squeezing) {
                Text(
                    if (cfg.autoGain) "Сигнал упирается в потолок. Убавь подъём полос или пре-амп."
                    else "Сигнал упирается в потолок. Включи «Авто-запас» во вкладке «Тембр».",
                    color = p.subtext, fontSize = 11.5.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun StatusPart(label: String, value: String, modifier: Modifier) {
    val p = LocalPalette.current
    Column(modifier) {
        Text(label, color = p.subtext, fontSize = 11.sp)
        Text(
            value, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

/* ------------------------------------------------------------------ вкладка «Тембр» */

@Composable
private fun TimbreTab(cfg: DspConfig, vm: MainViewModel) {
    val p = LocalPalette.current
    var fine by rememberSaveable { mutableStateOf(false) }

    ResponseGraph(config = cfg, onBand = { i, db -> vm.setDspBand(i, db) })

    PresetRow("Стиль", DspPresets.style, cfg, vm)
    PresetRow("Устройство", DspPresets.device, cfg, vm)

    // Тонкая настройка свёрнута: пре-амп и Q нужны одному из десяти, а пугают всех.
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .clickable { fine = !fine }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Тонкая настройка", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                "Бас, воздух, пре-амп, ширина полос, защита",
                color = p.subtext, fontSize = 11.5.sp
            )
        }
        Icon(
            if (fine) ZiziIcons.ChevronUp else ZiziIcons.ChevronDown,
            contentDescription = null, tint = p.subtext, modifier = Modifier.size(22.dp)
        )
    }
    AnimatedVisibility(visible = fine) {
        Column {
            EqSlider(
                label = "Глубокий бас",
                value = cfg.bassDrive,
                percent = true,
                hint = "Гармоники низа: бас слышно даже там, где динамик его не играет.",
                onChange = { v -> vm.editDsp { it.copy(bassDrive = round(v, 0.01f)) } }
            )
            EqSlider(
                label = "Воздух",
                value = cfg.air,
                percent = true,
                hint = "Мягко открывает самый верх, не делая голос шипящим.",
                onChange = { v -> vm.editDsp { it.copy(air = round(v, 0.01f)) } }
            )
            EqSlider(
                label = "Пре-амп",
                value = cfg.preampDb,
                range = DspConfig.PREAMP_MIN_DB..DspConfig.PREAMP_MAX_DB,
                display = dbText(cfg.preampDb),
                hint = "Общий уровень до обработки. С авто-запасом трогать обычно не нужно.",
                onChange = { v -> vm.editDsp { it.copy(preampDb = round(v, 0.5f)) } }
            )
            EqSlider(
                label = "Ширина полос",
                value = cfg.bandQ,
                range = DspConfig.Q_MIN..DspConfig.Q_MAX,
                display = when {
                    cfg.bandQ < 0.85f -> "Мягко"
                    cfg.bandQ < 1.6f -> "Обычно"
                    else -> "Узко"
                } + " · Q %.1f".format(cfg.bandQ),
                hint = "Мягко — полосы плавно перетекают. Узко — точечная правка одной частоты.",
                onChange = { v -> vm.editDsp { it.copy(bandQ = round(v, 0.1f)) } }
            )
            ToggleRow(
                label = "Авто-запас",
                subtitle = "Сам опускает уровень ровно на подъём кривой: бас сильнее — без хрипа и «дыхания».",
                checked = cfg.autoGain,
                onChange = { v -> vm.editDsp { it.copy(autoGain = v) } }
            )
            ToggleRow(
                label = "Лимитер",
                subtitle = "Страховка от перегруза на выходе. Пока перегруза нет — ничего не делает.",
                checked = cfg.limiter,
                onChange = { v -> vm.editDsp { it.copy(limiter = v) } }
            )
        }
    }

    ResetButton("Сбросить тембр", enabled = cfg.hasTimbre) { vm.resetDspTimbre() }
}

/**
 * АЧХ тракта одним холстом.
 *
 * Кривая — не сплайн по точкам ползунков, а настоящая характеристика ([DspResponse.curveDb]),
 * посчитанная теми же биквадами, что звучат: видно и перекрытие соседних полос, и «воздух».
 * Ручки стоят на значениях полос, поэтому при широком Q кривая может уйти выше ручки — это
 * правда о звуке, а не ошибка рисования.
 *
 * Жест один на весь холст: палец ведёт линию и меняет полосу под собой; тап ставит значение,
 * двойной тап возвращает полосу в ноль. Над холстом — какая полоса под пальцем и что она делает.
 */
@Composable
private fun ResponseGraph(config: DspConfig, onBand: (Int, Float) -> Unit) {
    val p = LocalPalette.current
    val spectrumState = LocalAudioSpectrum.current
    val dim by animateFloatAsState(if (config.enabled) 1f else 0.35f, label = "eqDim")
    val report by rememberUpdatedState(onBand)
    var active by remember { mutableIntStateOf(-1) }

    val count = DspConfig.BAND_COUNT
    val bands = remember(config.bandsDb) { FloatArray(count) { config.bandsDb.getOrElse(it) { 0f } } }
    val freqs = remember { FloatArray(GRAPH_POINTS) { i -> 31.25f * 2f.pow(-0.5f + 10f * i / (GRAPH_POINTS - 1)) } }
    val curve = remember(config.bandsDb, config.bandQ, config.air) {
        DspResponse.curveDb(config.copy(enabled = true), freqs)
    }

    // --- строка над холстом
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (active in 0 until count) {
            val f = DspConfig.BAND_FREQUENCIES[active]
            Text(
                (if (f >= 1000f) "${(f / 1000f).let { if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString() }} кГц" else "${f.toInt()} Гц") +
                    " · " + DspConfig.BAND_ROLES[active],
                color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            Text(dbText(bands[active]), color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        } else {
            Text(
                "Веди пальцем по кривой · двойной тап — полосу в ноль",
                color = p.subtext, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(220.dp)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .pointerInput(Unit) {
                fun bandAt(x: Float): Int {
                    val w = size.width.toFloat()
                    return if (w <= 0f) 0 else ((x / w) * count).toInt().coerceIn(0, count - 1)
                }
                fun dbAt(y: Float): Float {
                    val h = size.height.toFloat()
                    val half = h / 2f - GRAPH_PAD
                    if (half <= 0f) return 0f
                    val db = ((h / 2f - y) / half * GRAPH_RANGE_DB)
                        .coerceIn(-DspConfig.BAND_LIMIT_DB, DspConfig.BAND_LIMIT_DB)
                    // Полшага в децибелах — предел, на котором ещё имеет смысл целиться пальцем.
                    return (db * 2f).roundToInt() / 2f
                }
                detectDragGestures(
                    onDragStart = { pos -> active = bandAt(pos.x); report(active, dbAt(pos.y)) },
                    onDragEnd = { active = -1 },
                    onDragCancel = { active = -1 },
                    onDrag = { change, _ ->
                        change.consume()
                        active = bandAt(change.position.x)
                        report(active, dbAt(change.position.y))
                    }
                )
            }
            .pointerInput(Unit) {
                fun bandAt(x: Float): Int {
                    val w = size.width.toFloat()
                    return if (w <= 0f) 0 else ((x / w) * count).toInt().coerceIn(0, count - 1)
                }
                detectTapGestures(
                    onTap = { pos ->
                        val h = size.height.toFloat()
                        val half = h / 2f - GRAPH_PAD
                        if (half > 0f) {
                            val db = ((h / 2f - pos.y) / half * GRAPH_RANGE_DB)
                                .coerceIn(-DspConfig.BAND_LIMIT_DB, DspConfig.BAND_LIMIT_DB)
                            report(bandAt(pos.x), (db * 2f).roundToInt() / 2f)
                        }
                    },
                    onDoubleTap = { pos -> report(bandAt(pos.x), 0f) }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val spectrum = spectrumState.value.bands
            val w = size.width
            val h = size.height
            val slot = w / count
            val zeroY = h / 2f
            val half = h / 2f - GRAPH_PAD
            fun yOf(db: Float) = zeroY - (db / GRAPH_RANGE_DB).coerceIn(-1.1f, 1.1f) * half

            // сетка: 0 дБ жирнее, ±6 и ±12 — тонкие
            for (db in floatArrayOf(-12f, -6f, 0f, 6f, 12f)) {
                drawLine(
                    color = p.subtext.copy(alpha = if (db == 0f) 0.35f else 0.10f),
                    start = Offset(0f, yOf(db)), end = Offset(w, yOf(db)),
                    strokeWidth = if (db == 0f) 1.6f else 1f
                )
            }
            // вертикаль активной полосы
            if (active in 0 until count) {
                val cx = slot * active + slot / 2f
                drawRoundRect(
                    color = p.accent.copy(alpha = 0.10f),
                    topLeft = Offset(cx - slot / 2f + 2f, 0f),
                    size = Size(slot - 4f, h),
                    cornerRadius = CornerRadius(14f, 14f)
                )
            }
            // спектр того, что играет, — позади
            for (i in 0 until count) {
                val level = spectrum.getOrElse(i) { 0f }
                if (level <= 0.01f) continue
                val barH = level * (h * 0.92f)
                val cx = slot * i + slot / 2f
                val barW = slot * 0.46f
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        0f to p.accent.copy(alpha = 0.26f * dim),
                        1f to p.accent.copy(alpha = 0.04f * dim)
                    ),
                    topLeft = Offset(cx - barW / 2f, h - barH),
                    size = Size(barW, barH),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
            // настоящая АЧХ
            val line = Path()
            for (i in freqs.indices) {
                val x = w * i / (freqs.size - 1)
                val y = yOf(curve[i])
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
            }
            val fill = Path().apply {
                addPath(line)
                lineTo(w, zeroY)
                lineTo(0f, zeroY)
                close()
            }
            drawPath(
                path = fill,
                brush = Brush.verticalGradient(
                    0f to p.accent.copy(alpha = 0.22f * dim),
                    1f to p.accent.copy(alpha = 0.02f * dim)
                )
            )
            drawPath(path = line, brush = SolidColor(p.accent.copy(alpha = dim)), style = Stroke(width = 3.2f))
            // ручки полос
            for (i in 0 until count) {
                val c = Offset(slot * i + slot / 2f, yOf(bands[i]))
                val big = i == active
                drawCircle(color = p.top.copy(alpha = 0.9f * dim), radius = if (big) 15f else 10f, center = c)
                drawCircle(
                    color = (if (bands[i] == 0f && !big) p.subtext else p.accent).copy(alpha = dim),
                    radius = if (big) 10f else 6.5f, center = c
                )
            }
        }
    }

    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
        DspConfig.BAND_LABELS.forEachIndexed { i, label ->
            Text(
                label,
                color = if (i == active) p.accent else p.subtext,
                fontSize = 10.sp,
                fontWeight = if (i == active) FontWeight.Bold else FontWeight.Normal,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/* ------------------------------------------------------------------ вкладка «Сцена» */

@Composable
private fun SceneTab(cfg: DspConfig, vm: MainViewModel) {
    PresetRow("Пространство", DspPresets.space.filter { it.values.hasScene }, cfg, vm)

    ModuleCard(
        title = "Ревер",
        subtitle = "Отражения помещения вокруг звука",
        active = cfg.reverbMix > 0f,
        onOff = { vm.editDsp { it.copy(reverbMix = 0f) } }
    ) {
        EqSlider(
            label = "Количество",
            value = cfg.reverbMix,
            percent = true,
            onChange = { v -> vm.editDsp { it.copy(reverbMix = round(v, 0.01f)) } }
        )
        AnimatedVisibility(visible = cfg.reverbMix > 0f) {
            Column {
                EqSlider(
                    label = "Помещение",
                    value = cfg.reverbSize,
                    percent = true,
                    display = when {
                        cfg.reverbSize < 0.3f -> "Комната"
                        cfg.reverbSize < 0.7f -> "Зал"
                        else -> "Собор"
                    },
                    onChange = { v -> vm.editDsp { it.copy(reverbSize = round(v, 0.01f)) } }
                )
                EqSlider(
                    label = "Стены",
                    value = cfg.reverbDamp,
                    percent = true,
                    display = when {
                        cfg.reverbDamp < 0.3f -> "Звонкие"
                        cfg.reverbDamp < 0.7f -> "Дерево"
                        else -> "Мягкие"
                    },
                    onChange = { v -> vm.editDsp { it.copy(reverbDamp = round(v, 0.01f)) } }
                )
            }
        }
    }

    ModuleCard(
        title = "8D",
        subtitle = "Звук вращается вокруг головы · только в наушниках",
        active = cfg.rotation > 0f,
        onOff = { vm.editDsp { it.copy(rotation = 0f) } }
    ) {
        EqSlider(
            label = "Глубина",
            value = cfg.rotation,
            percent = true,
            onChange = { v -> vm.editDsp { it.copy(rotation = round(v, 0.01f)) } }
        )
        AnimatedVisibility(visible = cfg.rotation > 0f) {
            EqSlider(
                label = "Скорость",
                value = cfg.rotationHz,
                range = DspConfig.ROTATION_HZ_MIN..0.5f,
                display = "%.0f с на круг".format(1f / cfg.rotationHz.coerceAtLeast(DspConfig.ROTATION_HZ_MIN)),
                onChange = { v -> vm.editDsp { it.copy(rotationHz = round(v, 0.01f).coerceAtLeast(DspConfig.ROTATION_HZ_MIN)) } }
            )
        }
    }

    ModuleCard(
        title = "Стерео",
        subtitle = "Влево — к моно, вправо — шире",
        active = cfg.width != 0f,
        onOff = { vm.editDsp { it.copy(width = 0f) } }
    ) {
        EqSlider(
            label = "Ширина",
            value = cfg.width,
            range = -1f..1f,
            display = when {
                cfg.width < -0.95f -> "Моно"
                abs(cfg.width) < 0.02f -> "Как записано"
                cfg.width > 0f -> "+${(cfg.width * 100).roundToInt()}%"
                else -> "${(cfg.width * 100).roundToInt()}%"
            },
            onChange = { v ->
                // Возле нуля прилипает к «как записано»: попасть пальцем ровно в 0 иначе нельзя.
                val snapped = if (abs(v) < 0.04f) 0f else round(v, 0.01f)
                vm.editDsp { it.copy(width = snapped) }
            }
        )
    }

    ModuleCard(
        title = "Характер",
        subtitle = "Окраска всего сигнала",
        active = cfg.underwater > 0f || cfg.drive > 0f,
        onOff = { vm.editDsp { it.copy(underwater = 0f, drive = 0f) } }
    ) {
        EqSlider(
            label = "Под водой",
            value = cfg.underwater,
            percent = true,
            hint = "Верх плавно уходит, будто трек играет из-под воды.",
            onChange = { v -> vm.editDsp { it.copy(underwater = round(v, 0.01f)) } }
        )
        EqSlider(
            label = "Ламповое тепло",
            value = cfg.drive,
            percent = true,
            hint = "Мягкое насыщение: немного — плотность, много — грязь.",
            onChange = { v -> vm.editDsp { it.copy(drive = round(v, 0.01f)) } }
        )
    }

    ResetButton("Сбросить сцену", enabled = cfg.hasScene) { vm.resetDspScene() }
}

@Composable
private fun ModuleCard(
    title: String,
    subtitle: String,
    active: Boolean,
    onOff: () -> Unit,
    content: @Composable () -> Unit
) {
    val p = LocalPalette.current
    val edge by animateColorAsState(if (active) p.accent.copy(alpha = 0.45f) else Color.Transparent, label = "cardEdge")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(p.chip.copy(alpha = 0.45f))
            .border(1.dp, edge, RoundedCornerShape(18.dp))
            .padding(top = 12.dp, bottom = 6.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = p.subtext, fontSize = 11.5.sp)
            }
            if (active) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onOff)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Убрать", color = p.accent, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        content()
    }
}

/* ------------------------------------------------------------------ вкладка «Мои» */

@Composable
private fun MineTab(cfg: DspConfig, profiles: List<EqProfileEntity>, vm: MainViewModel, onSave: () -> Unit) {
    val p = LocalPalette.current
    val current = DspCodec.encode(cfg)

    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(p.accent)
            .clickable(onClick = onSave)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(ZiziIcons.Plus, contentDescription = null, tint = p.onAccent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Сохранить текущую настройку", color = p.onAccent, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }

    if (profiles.isEmpty()) {
        Text(
            "Настроил под свои наушники — сохрани, и настройка встанет в один тап на любом треке.",
            color = p.subtext, fontSize = 12.5.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        )
    }

    profiles.forEach { profile ->
        val decoded = remember(profile.config) { DspCodec.decode(profile.config) }
        val isCurrent = DspCodec.encode(decoded.copy(enabled = cfg.enabled)) == current
        ProfileRow(profile, decoded, isCurrent, vm)
    }

    ResetButton("Сбросить всё", enabled = cfg.hasTimbre || cfg.hasScene) { vm.resetDsp() }
}

/** Тап — применить, корзина — удалить с подтверждением. Подпись — что внутри настройки. */
@Composable
private fun ProfileRow(profile: EqProfileEntity, decoded: DspConfig, isCurrent: Boolean, vm: MainViewModel) {
    val p = LocalPalette.current
    var confirm by remember { mutableStateOf(false) }
    val summary = remember(decoded) {
        val t = when {
            !decoded.hasTimbre -> "тембр ровно"
            else -> DspPresets.activeTimbre(decoded)?.name ?: "своя кривая"
        }
        val s = when {
            !decoded.hasScene -> null
            else -> DspPresets.activeScene(decoded)?.name ?: "своя сцена"
        }
        listOfNotNull(t, s).joinToString(" · ")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isCurrent) p.accent.copy(alpha = 0.16f) else p.chip.copy(alpha = 0.45f))
            .clickable { vm.applyEqProfile(profile) }
            .padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                profile.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(summary, color = p.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (isCurrent) {
            Icon(ZiziIcons.Check, contentDescription = "Звучит сейчас", tint = p.accent, modifier = Modifier.size(20.dp))
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .clickable { confirm = true }
                .padding(10.dp)
        ) {
            Icon(ZiziIcons.Trash, contentDescription = "Удалить", tint = p.subtext, modifier = Modifier.size(19.dp))
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = p.surface,
            title = { Text("Удалить «${profile.name}»?", color = p.text) },
            text = { Text("Настройка исчезнет из списка. На звук прямо сейчас это не повлияет.", color = p.subtext) },
            confirmButton = {
                TextButton(onClick = { vm.deleteEqProfile(profile.name); confirm = false }) {
                    Text("Удалить", color = DANGER)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Отмена", color = p.subtext) }
            }
        )
    }
}

/* ------------------------------------------------------------------ общие блоки */

/**
 * Ряд пресетов одного слоя. Активный горит, под рядом — что он делает; повторный тап снимает.
 * Подсветка считается сравнением слоя ([DspPreset.isActive]) — это 20 сравнений чисел на кадр.
 */
@Composable
private fun PresetRow(title: String, presets: List<DspPreset>, cfg: DspConfig, vm: MainViewModel) {
    val p = LocalPalette.current
    val active = if (cfg.enabled) presets.firstOrNull { it.values.let { v -> v.hasTimbre || v.hasScene } && it.isActive(cfg) } else null
    SectionTitle(title)
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        presets.forEach { preset ->
            val on = preset == active
            val bg by animateColorAsState(if (on) p.accent else p.chip, label = "presetBg")
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(bg)
                    .clickable { vm.applyDspPreset(preset) }
                    .padding(horizontal = 15.dp, vertical = 9.dp)
            ) {
                Text(
                    preset.name,
                    color = if (on) p.onAccent else p.text,
                    fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
    Text(
        if (active != null) "${active.hint}. Нажми ещё раз, чтобы снять." else " ",
        color = p.subtext, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 6.dp)
    )
}

/** Сегментированный переключатель: вкладки и область действия. [marks] — точка «здесь что-то включено». */
@Composable
private fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    marks: List<Boolean> = emptyList()
) {
    val p = LocalPalette.current
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(p.chip.copy(alpha = 0.7f))
            .padding(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            val bg by animateColorAsState(if (on) p.accent else Color.Transparent, label = "segBg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = if (compact) 8.dp else 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        label,
                        color = if (on) p.onAccent else p.text,
                        fontSize = if (compact) 13.sp else 14.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium
                    )
                    if (marks.getOrElse(i) { false }) {
                        Spacer(Modifier.width(6.dp))
                        Box(
                            Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(50))
                                .background(if (on) p.onAccent else p.accent)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        color = p.text,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun EqSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    percent: Boolean = false,
    display: String? = null,
    hint: String? = null,
    onChange: (Float) -> Unit
) {
    val p = LocalPalette.current
    Column(Modifier.padding(horizontal = 18.dp, vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(
                display ?: if (percent) "${(value * 100).roundToInt()}%" else "%.2f".format(value),
                color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = p.accent,
                activeTrackColor = p.accent,
                inactiveTrackColor = p.chip
            )
        )
        if (hint != null) {
            Text(hint, color = p.subtext.copy(alpha = 0.75f), fontSize = 11.5.sp)
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun ToggleRow(label: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = p.subtext, fontSize = 11.5.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
private fun ResetButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(top = 18.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(p.chip.copy(alpha = if (enabled) 1f else 0.4f))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    ZiziIcons.Refresh, contentDescription = null,
                    tint = if (enabled) p.text else p.subtext, modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    label, color = if (enabled) p.text else p.subtext,
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun switchColors() = LocalPalette.current.let { p ->
    SwitchDefaults.colors(
        checkedThumbColor = p.onAccent,
        checkedTrackColor = p.accent,
        uncheckedTrackColor = p.chip,
        uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
    )
}

@Composable
private fun SaveProfileDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Сохранить настройку", color = p.text) },
        text = {
            Column {
                Text("Имя, по которому ты её узнаешь через месяц.", color = p.subtext, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.chip)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = name,
                        onValueChange = { if (it.length <= 40) name = it },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = ZiziFontFamily, color = p.text, fontSize = 15.sp),
                        cursorBrush = SolidColor(p.accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (name.isEmpty()) Text("Например: Мои наушники", color = p.subtext, fontSize = 15.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onSave(name) }) {
                Text("Сохранить", color = p.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.subtext) } }
    )
}

/* ------------------------------------------------------------------ мелочи */

private const val GRAPH_POINTS = 120
/** Шкала холста шире предела полосы: соседние полосы при широком Q складываются выше ±12. */
private const val GRAPH_RANGE_DB = 15f
private const val GRAPH_PAD = 12f

private fun dbText(db: Float): String {
    val v = if (abs(db) < 0.05f) 0f else db
    return (if (v > 0f) "+" else if (v < 0f) "−" else "") + "%.1f дБ".format(abs(v))
}

/** Квантование значения ползунка: без него в базу уезжает 0.4372159 и строка кодека пухнет. */
private fun round(value: Float, step: Float): Float =
    (value / step).roundToInt() * step
