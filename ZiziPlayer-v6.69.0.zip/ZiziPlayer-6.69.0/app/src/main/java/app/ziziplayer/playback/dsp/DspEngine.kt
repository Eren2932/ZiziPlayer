package app.ziziplayer.playback.dsp

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Звуковой тракт на чистом Kotlin: без android.*, поэтому целиком проверяется JVM-тестами.
 *
 * Порядок модулей: пре-амп (ручной + авто-запас) -> 10 полос -> психоакустический бас ->
 * «воздух» -> «под водой» -> насыщение -> ширина -> 8D -> ревер -> лимитер.
 *
 * Все параметры сглаживаются блоками по [BLOCK] кадров с постоянной времени [SMOOTH_MS]:
 * движение ползунка, пресет, включение и выключение тракта звучат плавно, без щелчков.
 *
 * 6.69.0:
 *  - выключенный тракт — это цель «ноль», а не обрыв: движок доезжает до нуля, и только потом
 *    процессор уходит на побайтовое копирование (см. [isIdle]);
 *  - модуль, включающийся с нуля, начинает с чистого состояния: раньше фильтр полосы,
 *    простоявшей в нуле час, просыпался с памятью часовой давности, а ревер повторял хвост
 *    трека, игравшего до выключения;
 *  - коэффициенты полос пересчитываются только когда их значение изменилось;
 *  - 8D двигает задержку дробно (линейная интерполяция), а не скачками по целому сэмплу —
 *    скачки были слышны как мелкий треск на верхах;
 *  - размер и затухание ревера тоже сглаживаются;
 *  - авто-запас ([DspResponse.autoGainDb]) и измерение работы лимитера ([limiterGain]).
 */
class DspEngine(private val sampleRate: Int, private val channels: Int) {

    companion object {
        private const val BLOCK = 64
        private const val SMOOTH_MS = 40f
        /** Потолок лимитера: -0.4 дБFS, запас на межсэмпловые пики после ЦАП. */
        private const val CEILING = 0.955f
    }

    /** Цель целиком, одной ссылкой: поля не могут прийти в аудиопоток вразнобой. */
    private class Target(val cfg: DspConfig, val preampDb: Float)

    private val stereo = channels >= 2
    private val smoothing = exp(-1f / (SMOOTH_MS * 0.001f * sampleRate / BLOCK)).coerceIn(0f, 0.99f)

    @Volatile private var target = Target(DspConfig.NEUTRAL, 0f)
    @Volatile private var requested: DspConfig = DspConfig.NEUTRAL

    private val bandsNow = FloatArray(DspConfig.BAND_COUNT)
    private val bandsSet = FloatArray(DspConfig.BAND_COUNT) { Float.NaN }
    private var qSet = Float.NaN
    private var airSet = Float.NaN
    private var preampNow = 0f
    private var airNow = 0f
    private var waterNow = 0f
    private var widthNow = 0f
    private var rotationNow = 0f
    private var reverbNow = 0f
    private var sizeNow = 0.5f
    private var dampNow = 0.5f
    private var driveNow = 0f
    private var bassNow = 0f
    private var qNow = 1f
    private var preampGain = 1f

    private val eq = Array(DspConfig.BAND_COUNT) { Biquad(channels) }
    private val airShelf = Biquad(channels)
    private val waterLp = Biquad(channels)
    private val bassSplit = Biquad(channels).apply { setLowPass(sampleRate, 140f, 0.8f) }
    private val bassTame = Biquad(channels).apply { setLowPass(sampleRate, 900f, 0.7f) }

    private val reverb = Reverb(sampleRate)
    private val rotate = Rotator(sampleRate)
    private var limiterGainNow = 1f
    private var limiterEnv = 0f

    private var lfoPhase = 0.0
    private var rotPhase = 0.0

    /**
     * Минимальное усиление лимитера за последний вызов [process]: 1 — не работал, 0.5 — давил
     * на 6 дБ. Читается экраном через [DspMeter], чтобы честно сказать «упираешься в потолок».
     */
    var limiterGain: Float = 1f
        private set

    /** Можно звать из любого потока: цель подменяется одной volatile-ссылкой. */
    fun setConfig(config: DspConfig) {
        val safe = config.sanitized()
        requested = safe
        val effective = if (safe.enabled) safe else safe.copy(
            preampDb = 0f, bandsDb = List(DspConfig.BAND_COUNT) { 0f }, bassDrive = 0f, air = 0f,
            width = 0f, underwater = 0f, rotation = 0f, reverbMix = 0f, drive = 0f
        )
        target = Target(effective, if (safe.enabled) DspResponse.effectivePreampDb(safe) else 0f)
    }

    fun currentConfig(): DspConfig = requested

    /**
     * Движок доехал до нуля и цель — ноль: обработка ничего не меняет, и процессор вправе
     * перейти на побайтовое копирование. Звать из аудиопотока.
     */
    val isIdle: Boolean
        get() {
            val t = target
            if (t.preampDb != 0f || t.cfg.hasTimbre || t.cfg.hasScene) return false
            if (preampNow != 0f || airNow != 0f || waterNow != 0f || widthNow != 0f) return false
            if (rotationNow != 0f || reverbNow != 0f || driveNow != 0f || bassNow != 0f) return false
            for (v in bandsNow) if (v != 0f) return false
            return true
        }

    /** Сброс памяти фильтров и хвостов. Сглаженные значения не трогаются: это не смена настроек. */
    fun reset() {
        eq.forEach { it.reset() }
        airShelf.reset(); waterLp.reset(); bassSplit.reset(); bassTame.reset()
        reverb.reset(); rotate.reset()
        limiterGainNow = 1f; limiterEnv = 0f; limiterGain = 1f
        lfoPhase = 0.0; rotPhase = 0.0
    }

    /** Обрабатывает [frames] кадров на месте. Возвращает пик выхода. */
    fun process(pcm: FloatArray, frames: Int): Float {
        var peak = 0f
        var minGain = 1f
        var frame = 0
        while (frame < frames) {
            val block = minOf(BLOCK, frames - frame)
            val t = target
            advanceSmoothing(t)
            updateCoefficients()
            peak = maxOf(peak, processBlock(pcm, frame, block, t.cfg))
            if (limiterGainNow < minGain) minGain = limiterGainNow
            frame += block
        }
        limiterGain = minGain
        return peak
    }

    private fun advanceSmoothing(t: Target) {
        val c = t.cfg
        val k = smoothing
        for (i in bandsNow.indices) {
            val was = bandsNow[i]
            bandsNow[i] = glide(was, c.bandsDb[i], k)
            if (was == 0f && bandsNow[i] != 0f) eq[i].reset()
        }
        preampNow = glide(preampNow, t.preampDb, k)

        val airWas = airNow
        airNow = glide(airNow, c.air, k)
        if (airWas == 0f && airNow != 0f) airShelf.reset()

        val waterWas = waterNow
        waterNow = glide(waterNow, c.underwater, k)
        if (waterWas == 0f && waterNow != 0f) { waterLp.reset(); lfoPhase = 0.0 }

        val bassWas = bassNow
        bassNow = glide(bassNow, c.bassDrive, k)
        if (bassWas == 0f && bassNow != 0f) { bassSplit.reset(); bassTame.reset() }

        val rotWas = rotationNow
        rotationNow = glide(rotationNow, c.rotation, k)
        if (rotWas == 0f && rotationNow != 0f) rotate.reset()

        val reverbWas = reverbNow
        reverbNow = glide(reverbNow, c.reverbMix, k)
        if (reverbWas == 0f && reverbNow != 0f) reverb.reset()

        widthNow = glide(widthNow, c.width, k)
        driveNow = glide(driveNow, c.drive, k)
        sizeNow = glide(sizeNow, c.reverbSize, k)
        dampNow = glide(dampNow, c.reverbDamp, k)
        qNow = glide(qNow, c.bandQ, k)
        preampGain = if (preampNow == 0f) 1f else 10f.pow(preampNow / 20f)
    }

    private fun glide(now: Float, to: Float, k: Float): Float {
        val next = to + (now - to) * k
        return if (abs(next - to) < 1e-4f) to else next
    }

    private fun updateCoefficients() {
        val qChanged = qNow != qSet
        for (i in 0 until DspConfig.BAND_COUNT) {
            val g = bandsNow[i]
            if (g == 0f) continue
            if (qChanged || g != bandsSet[i]) {
                eq[i].setPeaking(sampleRate, DspConfig.BAND_FREQUENCIES[i], g, qNow)
                bandsSet[i] = g
            }
        }
        qSet = qNow
        if (airNow != 0f && airNow != airSet) {
            airShelf.setHighShelf(sampleRate, DspResponse.AIR_FREQ, airNow * DspResponse.AIR_MAX_DB)
            airSet = airNow
        }
        if (reverbNow > 0f) reverb.configure(sizeNow, dampNow)
    }

    private fun processBlock(pcm: FloatArray, startFrame: Int, frames: Int, cfg: DspConfig): Float {
        var peak = 0f
        if (waterNow > 0f) {
            val depth = waterNow
            val base = 5200f - 4550f * depth
            val sweep = (280f + 420f * depth) * sin(lfoPhase).toFloat()
            waterLp.setLowPass(sampleRate, (base + sweep).coerceAtLeast(180f), 0.9f + 0.5f * depth)
            lfoPhase += 2.0 * PI * 0.08 * frames / sampleRate
            if (lfoPhase > 2 * PI) lfoPhase -= 2 * PI
        }

        val rotDepth = rotationNow
        val step = 2.0 * PI * cfg.rotationHz / sampleRate
        val limiterOn = cfg.limiter

        var i = 0
        while (i < frames) {
            val idx = (startFrame + i) * channels
            var l = pcm[idx] * preampGain
            var r = if (stereo) pcm[idx + 1] * preampGain else l

            for (b in 0 until DspConfig.BAND_COUNT) {
                if (bandsNow[b] == 0f) continue
                l = eq[b].process(0, l)
                if (stereo) r = eq[b].process(1, r)
            }

            if (bassNow > 0f) {
                val lowL = bassSplit.process(0, l)
                val harmL = bassTame.process(0, tanh(lowL * (1f + 6f * bassNow)))
                l += harmL * bassNow * 0.7f
                if (stereo) {
                    val lowR = bassSplit.process(1, r)
                    val harmR = bassTame.process(1, tanh(lowR * (1f + 6f * bassNow)))
                    r += harmR * bassNow * 0.7f
                }
            }

            if (airNow > 0f) {
                l = airShelf.process(0, l)
                if (stereo) r = airShelf.process(1, r)
            }

            if (waterNow > 0f) {
                val wl = waterLp.process(0, l)
                l = l * (1f - waterNow) + wl * waterNow * 1.25f
                if (stereo) {
                    val wr = waterLp.process(1, r)
                    r = r * (1f - waterNow) + wr * waterNow * 1.25f
                }
            }

            if (driveNow > 0f) {
                val k = 1f + 7f * driveNow
                val comp = 1f / tanh(k * 0.7f)
                l = l * (1f - driveNow) + tanh(l * k) * comp * driveNow
                if (stereo) r = r * (1f - driveNow) + tanh(r * k) * comp * driveNow
            }

            if (stereo && widthNow != 0f) {
                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f * (1f + widthNow * 1.6f).coerceAtLeast(0f)
                l = mid + side
                r = mid - side
            }

            if (stereo && rotDepth > 0f) {
                rotPhase += step
                if (rotPhase > 2 * PI) rotPhase -= 2 * PI
                val pair = rotate.process(l, r, rotPhase, rotDepth)
                l = pair[0]; r = pair[1]
            }

            if (reverbNow > 0f) {
                val wet = reverb.process(l, r, reverbNow)
                l = l * (1f - reverbNow * 0.5f) + wet[0]
                r = r * (1f - reverbNow * 0.5f) + wet[1]
            }

            if (limiterOn) {
                val instant = maxOf(abs(l), abs(r))
                limiterEnv = maxOf(instant, limiterEnv * 0.9995f)
                val want = if (limiterEnv > CEILING) CEILING / limiterEnv else 1f
                limiterGainNow = if (want < limiterGainNow) want else limiterGainNow + (want - limiterGainNow) * 0.0002f
                l *= limiterGainNow
                r *= limiterGainNow
            } else {
                limiterGainNow = 1f
            }
            if (l > 1f) l = 1f else if (l < -1f) l = -1f
            if (r > 1f) r = 1f else if (r < -1f) r = -1f

            pcm[idx] = l
            if (stereo) pcm[idx + 1] = r
            // Каналы сверх стерео (5.1) получают только уровень: полосы и сцена считаются
            // для фронтальной пары, иначе центр и тыл пришлось бы сводить заново.
            for (c in 2 until channels) pcm[idx + c] = pcm[idx + c] * preampGain

            val p = maxOf(abs(l), abs(r))
            if (p > peak) peak = p
            i++
        }
        return peak
    }
}

/**
 * Freeverb (Jezar): 8 гребёнок + 4 фазовращателя на канал. Задержки масштабируются под частоту
 * потока, иначе на 48 кГц зал становился бы на 9% меньше, чем на 44.1.
 */
private class Reverb(sampleRate: Int) {

    private val combTuning = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val allpassTuning = intArrayOf(556, 441, 341, 225)
    private val spread = 23

    private val scale = sampleRate / 44100.0

    private val combL = combTuning.map { Comb(sized(it)) }
    private val combR = combTuning.map { Comb(sized(it + spread)) }
    private val apL = allpassTuning.map { Allpass(sized(it)) }
    private val apR = allpassTuning.map { Allpass(sized(it + spread)) }

    private var feedback = 0.84f
    private var damp = 0.4f
    private val out = FloatArray(2)

    private fun sized(base: Int): Int = maxOf(8, (base * scale).toInt())

    /** Обратная связь не выше 0.98: при 1.0 гребёнка самовозбуждается. */
    fun configure(size: Float, dampness: Float) {
        feedback = 0.70f + 0.28f * size.coerceIn(0f, 1f)
        damp = (0.15f + 0.65f * dampness.coerceIn(0f, 1f))
    }

    fun reset() {
        combL.forEach { it.reset() }; combR.forEach { it.reset() }
        apL.forEach { it.reset() }; apR.forEach { it.reset() }
    }

    fun process(l: Float, r: Float, mix: Float): FloatArray {
        val input = (l + r) * 0.015f
        var wetL = 0f
        var wetR = 0f
        for (i in combL.indices) {
            wetL += combL[i].process(input, feedback, damp)
            wetR += combR[i].process(input, feedback, damp)
        }
        for (i in apL.indices) {
            wetL = apL[i].process(wetL)
            wetR = apR[i].process(wetR)
        }
        out[0] = wetL * mix * 1.75f
        out[1] = wetR * mix * 1.75f
        return out
    }

    private class Comb(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        private var store = 0f
        fun reset() { buf.fill(0f); store = 0f; idx = 0 }
        fun process(input: Float, feedback: Float, damp: Float): Float {
            val output = buf[idx]
            store = output * (1f - damp) + store * damp
            buf[idx] = input + store * feedback
            idx++
            if (idx >= buf.size) idx = 0
            return output
        }
    }

    private class Allpass(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        fun reset() { buf.fill(0f); idx = 0 }
        fun process(input: Float): Float {
            val buffered = buf[idx]
            val output = -input + buffered
            buf[idx] = input + buffered * 0.5f
            idx++
            if (idx >= buf.size) idx = 0
            return output
        }
    }
}

/**
 * 8D: равномощное панорамирование по синусу плюс межушная задержка до 0.66 мс для дальнего уха.
 * Задержка дробная (линейная интерполяция): целочисленные скачки задержки были слышны как треск.
 */
private class Rotator(sampleRate: Int) {

    private val maxDelay = maxOf(4, (sampleRate * 0.00066f).toInt())
    private val size = maxDelay + 3
    private val lineL = FloatArray(size)
    private val lineR = FloatArray(size)
    private var idx = 0
    private val out = FloatArray(2)

    fun reset() { lineL.fill(0f); lineR.fill(0f); idx = 0 }

    private fun tap(line: FloatArray, delay: Float): Float {
        val whole = delay.toInt()
        val frac = delay - whole
        val a = line[(idx - whole + size) % size]
        val b = line[(idx - whole - 1 + size + size) % size]
        return a + (b - a) * frac
    }

    fun process(l: Float, r: Float, phase: Double, depth: Float): FloatArray {
        lineL[idx] = l
        lineR[idx] = r
        val pan = sin(phase).toFloat() * depth
        val theta = (pan + 1f) * (PI / 4).toFloat()
        val gainL = cos(theta)
        val gainR = sin(theta)
        val delay = (abs(pan) * maxDelay).coerceIn(0f, maxDelay.toFloat())
        val dry = 1f - depth
        val farL = if (pan > 0f) tap(lineL, delay) else l
        val farR = if (pan < 0f) tap(lineR, delay) else r
        out[0] = farL * gainL * depth + l * dry
        out[1] = farR * gainR * depth + r * dry
        idx++
        if (idx >= size) idx = 0
        return out
    }
}
