package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

/** Сколько плейлистов помещается в «Быстрый доступ». Совпадает с лимитом DAO (setPinned). */
private const val HOME_PIN_LIMIT = 6

/**
 * 6.67.0: закрепления — лист, а не AlertDialog со списком TextButton.
 * Обложка и число треков у каждой строки, справа переключатель-пилюля, в шапке «3 из 6».
 * Достигнут лимит — незакреплённые строки гаснут, а не отвечают тостом после нажатия.
 */
@Composable
internal fun HomePinsSheet(
    playlists: List<app.ziziplayer.ui.HomePlaylist>,
    onToggle: (Long, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val pinnedCount = playlists.count { it.pinned }
    val full = pinnedCount >= HOME_PIN_LIMIT
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Быстрый доступ", "Закреплено $pinnedCount из $HOME_PIN_LIMIT")
        if (playlists.isEmpty()) {
            Text("Сначала создай плейлист в медиатеке.", color = p.subtext, fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp))
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 480.dp)) {
            items(playlists, key = { it.playlist.id }, contentType = { "pin" }) { card ->
                val enabled = card.pinned || !full
                PickerRow(
                    label = card.playlist.name,
                    subtitle = app.ziziplayer.ui.components.trackCountLabel(card.count),
                    enabled = enabled,
                    onClick = { onToggle(card.playlist.id, !card.pinned) },
                    trailing = {
                        Box(
                            Modifier
                                .height(32.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (card.pinned) p.brand else p.chip)
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(ZiziIcons.Pin, contentDescription = null,
                                    tint = if (card.pinned) p.onBrand else if (enabled) p.text else p.subtext,
                                    modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (card.pinned) "Закреплён" else "Закрепить",
                                    color = if (card.pinned) p.onBrand else if (enabled) p.text else p.subtext,
                                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                ) {
                    val cover = card.playlist.coverUri
                    if (!cover.isNullOrBlank()) app.ziziplayer.ui.components.RemoteArtwork(
                        cover, "playlist:" + card.playlist.id, 144, Modifier.fillMaxSize(), 18)
                    else TrackArtwork(card.cover, 144, Modifier.fillMaxSize(), 18)
                }
            }
        }
    }
}

