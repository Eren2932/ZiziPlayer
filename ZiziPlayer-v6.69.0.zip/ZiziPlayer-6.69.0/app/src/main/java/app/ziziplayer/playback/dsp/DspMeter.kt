package app.ziziplayer.playback.dsp

/**
 * 6.69.0. Показания тракта для экрана «Звук»: насколько сейчас давит лимитер.
 *
 * Одно volatile-поле, а не Flow: аудиопоток пишет его на каждом буфере и не должен ни
 * аллоцировать, ни будить подписчиков. Экран сам опрашивает поле несколько раз в секунду,
 * и только пока открыт.
 */
object DspMeter {
    /** Минимальное усиление лимитера за последний буфер: 1 — не работал. */
    @Volatile
    var limiterGain: Float = 1f
        private set

    fun publish(gain: Float) {
        limiterGain = if (gain.isNaN()) 1f else gain.coerceIn(0f, 1f)
    }

    fun reset() {
        limiterGain = 1f
    }

    /** Подавление в дБ, положительное число: 0 — лимитер не работает. */
    fun reductionDb(): Float {
        val g = limiterGain
        if (g >= 0.999f) return 0f
        return (-20.0 * kotlin.math.log10(g.coerceAtLeast(1e-4f).toDouble())).toFloat()
    }
}
