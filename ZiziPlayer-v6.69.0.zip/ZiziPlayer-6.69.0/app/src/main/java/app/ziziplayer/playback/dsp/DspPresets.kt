package app.ziziplayer.playback.dsp

import kotlin.math.abs

/**
 * Встроенный пресет (6.69.0 — переписано).
 *
 * Каждый пресет владеет ровно одним слоем тракта ([Layer]) и задаёт его ЦЕЛИКОМ:
 *  - [Layer.TIMBRE] — кривая, пре-амп, Q, психоакустический бас, «воздух»;
 *  - [Layer.SCENE] — ревер, «под водой», 8D, ширина, насыщение.
 *
 * Отсюда три свойства, которых не было до 6.69.0:
 *  1. пресеты разных слоёв складываются («Наушники» + «Под водой»), одного слоя — заменяют
 *     друг друга без остатков («Рок» после «Клуба» больше не тащит чужой перегруз);
 *  2. активный пресет определяется честно — сравнением слоя ([isActive]), и чип подсвечивается;
 *  3. повторное нажатие активного пресета снимает его — возвращает слой в ноль.
 */
data class DspPreset(
    val name: String,
    val layer: Layer,
    val kind: Kind,
    /** Значения слоя. Поля чужого слоя здесь игнорируются. */
    val values: DspConfig,
    /** Одна строка «что это даст» — подпись под названием в списке пресетов. */
    val hint: String = ""
) {
    enum class Layer { TIMBRE, SCENE }

    /** Группировка на экране: жанр/настроение, устройство, эффект пространства. */
    enum class Kind { STYLE, DEVICE, SPACE }

    /** Применить к [c]: слой пресета заменяется целиком, остальное не трогается. */
    fun applyTo(c: DspConfig): DspConfig {
        val v = values.sanitized()
        val next = when (layer) {
            // Пресеты тембра рассчитаны на авто-запас (пре-амп в них нулевой). Настройка, сохранённая
            // до 6.69.0, приходит с выключенным авто-запасом — без этого «Бас+» на ней хрипел бы.
            Layer.TIMBRE -> c.withTimbreOf(v).copy(autoGain = true)
            Layer.SCENE -> c.withSceneOf(v)
        }
        return next.copy(enabled = true)
    }

    /** Слой [c] совпадает со слоем пресета (с допуском на округление кодека). */
    fun isActive(c: DspConfig): Boolean {
        val a = c.sanitized()
        val b = values.sanitized()
        return when (layer) {
            Layer.TIMBRE -> near(a.preampDb, b.preampDb) && near(a.bandQ, b.bandQ) &&
                near(a.bassDrive, b.bassDrive) && near(a.air, b.air) &&
                a.bandsDb.indices.all { near(a.bandsDb[it], b.bandsDb[it]) }
            Layer.SCENE -> near(a.width, b.width) && near(a.underwater, b.underwater) &&
                near(a.rotation, b.rotation) && near(a.reverbMix, b.reverbMix) &&
                near(a.drive, b.drive) &&
                // Параметры выключенного модуля не видны на слух — и в сравнении не участвуют.
                (a.rotation == 0f || near(a.rotationHz, b.rotationHz)) &&
                (a.reverbMix == 0f || (near(a.reverbSize, b.reverbSize) && near(a.reverbDamp, b.reverbDamp)))
        }
    }

    /** Совместимость со старым API: пресет как функция от тракта. */
    val transform: (DspConfig) -> DspConfig get() = ::applyTo

    private fun near(x: Float, y: Float) = abs(x - y) < 0.011f
}

object DspPresets {

    private fun bands(vararg v: Float): List<Float> {
        require(v.size == DspConfig.BAND_COUNT)
        return v.toList()
    }

    private fun timbre(
        name: String, kind: DspPreset.Kind, hint: String, curve: List<Float>,
        preamp: Float = 0f, q: Float = 1f, bass: Float = 0f, air: Float = 0f
    ) = DspPreset(
        name, DspPreset.Layer.TIMBRE, kind,
        DspConfig(enabled = true, preampDb = preamp, bandsDb = curve, bandQ = q, bassDrive = bass, air = air),
        hint
    )

    private fun scene(
        name: String, hint: String,
        reverb: Float = 0f, size: Float = 0.5f, damp: Float = 0.5f,
        water: Float = 0f, rotation: Float = 0f, rotationHz: Float = 0.12f,
        width: Float = 0f, drive: Float = 0f
    ) = DspPreset(
        name, DspPreset.Layer.SCENE, DspPreset.Kind.SPACE,
        DspConfig(
            enabled = true, reverbMix = reverb, reverbSize = size, reverbDamp = damp,
            underwater = water, rotation = rotation, rotationHz = rotationHz, width = width, drive = drive
        ),
        hint
    )

    // Пре-амп в пресетах — только там, где он часть характера. Запас под подъём кривой теперь
    // держит авто-запас, и дублировать его здесь значило бы опустить громкость дважды.

    val style: List<DspPreset> = listOf(
        timbre("Ровно", DspPreset.Kind.STYLE, "Без коррекции",
            bands(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        timbre("Бас+", DspPreset.Kind.STYLE, "Плотный низ, верх чуть ярче",
            bands(8f, 7f, 4f, 1f, -1f, 0f, 0f, 1f, 2f, 2f)),
        timbre("Глубокий низ", DspPreset.Kind.STYLE, "Саб-бас и гармоники низа",
            bands(10f, 8f, 3f, 0f, -2f, -2f, 0f, 1f, 1f, 0f), q = 0.9f, bass = 0.35f),
        timbre("Вокал", DspPreset.Kind.STYLE, "Голос вперёд, низ тише",
            bands(-3f, -2f, 0f, 1f, 3f, 4f, 3f, 1f, 0f, -1f), q = 1.2f),
        timbre("Хип-хоп", DspPreset.Kind.STYLE, "Бочка и чёткие хэты",
            bands(7f, 6f, 3f, 0f, -2f, 0f, 2f, 3f, 3f, 2f), bass = 0.25f),
        timbre("Рок", DspPreset.Kind.STYLE, "Гитары и барабаны вперёд",
            bands(4f, 3f, 1f, -1f, -2f, 0f, 3f, 4f, 3f, 1f)),
        timbre("Электроника", DspPreset.Kind.STYLE, "Низ и искрящийся верх",
            bands(6f, 5f, 2f, 0f, -2f, -1f, 1f, 3f, 4f, 4f), q = 1.1f),
        timbre("Классика", DspPreset.Kind.STYLE, "Мягко, с воздухом",
            bands(2f, 2f, 1f, 0f, 0f, 0f, 1f, 2f, 2f, 3f), q = 0.8f, air = 0.2f),
        timbre("Подкаст", DspPreset.Kind.STYLE, "Разборчивая речь без гула",
            bands(-8f, -6f, -2f, 1f, 4f, 4f, 3f, 2f, -1f, -3f), q = 1.4f),
        // Тише слушаешь — хуже слышно края (кривые равной громкости). Компенсируем краями.
        timbre("Тихо", DspPreset.Kind.STYLE, "Для малой громкости: края громче",
            bands(5f, 4f, 2f, 0f, -1f, -1f, 0f, 2f, 3f, 4f), q = 0.9f),
        timbre("Радио", DspPreset.Kind.STYLE, "Узкая полоса, как в старом приёмнике",
            bands(-12f, -10f, -4f, 2f, 4f, 4f, 2f, -4f, -10f, -12f), q = 1.2f)
    )

    val device: List<DspPreset> = listOf(
        timbre("Наушники", DspPreset.Kind.DEVICE, "Небольшой подъём краёв",
            bands(3f, 2f, 0f, -1f, -1f, 0f, 1f, 2f, 2f, 1f), air = 0.15f),
        // Ниже 300 Гц телефонный динамик не играет ничего. Поднимать там бас — тратить весь запас
        // по уровню впустую, поэтому низ срезается, а его присутствие даёт bassDrive.
        timbre("Динамик телефона", DspPreset.Kind.DEVICE, "Низ гармониками, без хрипа",
            bands(-12f, -10f, -2f, 2f, 3f, 2f, 1f, 2f, 1f, -2f), bass = 0.55f, air = 0.1f),
        timbre("Колонка", DspPreset.Kind.DEVICE, "Bluetooth-колонка: плотнее низ",
            bands(2f, 4f, 2f, -1f, -2f, 0f, 2f, 2f, 1f, 0f), bass = 0.2f),
        timbre("В машине", DspPreset.Kind.DEVICE, "Меньше гула салона, голос чище",
            bands(4f, 3f, -1f, -3f, -1f, 1f, 3f, 3f, 2f, 1f), q = 1.1f)
    )

    val space: List<DspPreset> = listOf(
        scene("Без эффектов", "Сцена выключена"),
        scene("Slowed + reverb", "Мягкий зал и немного шире",
            reverb = 0.45f, size = 0.72f, damp = 0.45f, width = 0.3f),
        scene("8D", "Звук вращается вокруг головы",
            rotation = 0.85f, rotationHz = 0.12f, reverb = 0.22f, size = 0.55f, width = 0.35f),
        scene("8D медленно", "Один оборот за 20 секунд",
            rotation = 0.7f, rotationHz = 0.05f, reverb = 0.18f, width = 0.3f),
        scene("Под водой", "Приглушённо, будто из-под воды",
            water = 0.62f, reverb = 0.28f, size = 0.7f, damp = 0.75f, width = 0.2f),
        scene("Глубоко", "Ещё глуше и дальше",
            water = 0.88f, reverb = 0.4f, size = 0.85f, damp = 0.85f, width = 0.1f),
        scene("Концертный зал", "Живой зал средних размеров",
            reverb = 0.35f, size = 0.8f, damp = 0.4f, width = 0.25f),
        scene("Собор", "Огромный звонкий объём",
            reverb = 0.6f, size = 0.95f, damp = 0.25f, width = 0.4f),
        scene("Клуб", "Плотно, с перегрузом",
            reverb = 0.25f, size = 0.45f, damp = 0.6f, drive = 0.18f, width = 0.25f),
        scene("Ламповый", "Тёплое насыщение",
            drive = 0.35f, reverb = 0.12f, width = 0.15f),
        scene("Лоу-фай", "Моно, глухо и грязно",
            width = -1f, drive = 0.3f, water = 0.35f),
        scene("Широкое стерео", "Раздвинуть сцену", width = 0.8f),
        scene("Моно", "Одинаково в обоих ушах", width = -1f)
    )

    /** Старые имена групп сохранены для кода, который о них знает. */
    val curve: List<DspPreset> get() = style

    val all: List<DspPreset> = style + device + space

    /** Активный пресет слоя, если слой совпадает с одним из встроенных. Нейтраль не считается. */
    fun activeTimbre(c: DspConfig): DspPreset? =
        if (!c.hasTimbre) null else (style + device).firstOrNull { it.isActive(c) }

    fun activeScene(c: DspConfig): DspPreset? =
        if (!c.hasScene) null else space.firstOrNull { it.isActive(c) }
}
