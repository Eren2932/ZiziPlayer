package app.ziziplayer.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.PlaylistNaming
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlinx.coroutines.delay

/*
 * 6.67.0: СОЗДАНИЕ ПЛЕЙЛИСТА.
 *
 * До этой версии «Новый плейлист» был голым AlertDialog Material: серое поле, две текстовые
 * кнопки, ни фокуса, ни клавиши «Готово», ни проверки дублей. На фоне экранов 6.5x-6.6x (плитки,
 * оранжевый бренд, поле поиска с обводкой) это было самое старое окно приложения.
 *
 * Теперь одна форма [PlaylistCreateForm] обслуживает три входа:
 *   - «+» в медиатеке                      -> [PlaylistCreateSheet];
 *   - «Новый плейлист» в листе выбора      -> тот же лист выбора переключается в форму;
 *   - главная, меню трека                  -> лист выбора (раньше там был сырой AlertDialog).
 *
 * Логика имени — в app.ziziplayer.ui.PlaylistNaming, без Compose: её проверяет JVM-тест.
 */

/* ------------------------------------------------------------------ поле ввода */

/**
 * Поле в языке приложения: та же плитка, что и поле поиска — фон chip, скругление 16, обводка
 * брендом в фокусе. Вместо OutlinedTextField: у того своя высота, своя анимация подписи и серый
 * контур Material, которые на этих экранах выглядели чужими.
 */
@Composable
internal fun ZiziNameField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    leadingIcon: ImageVector? = null,
    maxLength: Int? = null,
    onDone: () -> Unit = {}
) {
    val p = LocalPalette.current
    var focused by remember { mutableStateOf(false) }
    val borderColor by animateColorAsState(
        if (focused) p.brand else Color.White.copy(alpha = 0.06f),
        animationSpec = tween(160),
        label = "name-field-border"
    )
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(p.chip)
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, contentDescription = null, tint = if (focused) p.brand else p.subtext, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
        }
        Box(Modifier.weight(1f).padding(vertical = 14.dp), contentAlignment = Alignment.CenterStart) {
            if (value.text.isEmpty()) {
                Text(placeholder, color = p.subtext, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            BasicTextField(
                value = value,
                onValueChange = { next ->
                    val limited = if (maxLength != null) PlaylistNaming.limitInput(next.text).take(maxLength) else next.text
                    onValueChange(if (limited == next.text) next else next.copy(text = limited, selection = TextRange(limited.length)))
                },
                singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, fontFamily = ZiziFontFamily),
                cursorBrush = SolidColor(p.brand),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onDone() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
                    .onFocusChanged { focused = it.isFocused }
            )
        }
        if (maxLength != null && value.text.length >= maxLength - 15) {
            Text(
                "${value.text.length}/$maxLength",
                color = if (value.text.length >= maxLength) p.brand else p.subtext,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
        }
        if (value.text.isNotEmpty()) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onValueChange(TextFieldValue("")) },
                contentAlignment = Alignment.Center
            ) {
                Icon(ZiziIcons.Close, contentDescription = "Очистить", tint = p.subtext, modifier = Modifier.size(18.dp))
            }
        }
    }
}

/** Фокус и клавиатура после того, как лист доехал. Без сна фокус просит ещё не прикреплённый узел. */
@Composable
internal fun AutoFocus(requester: FocusRequester, enabled: Boolean = true) {
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(requester, enabled) {
        if (!enabled) return@LaunchedEffect
        delay(180)
        runCatching { requester.requestFocus() }
        keyboard?.show()
    }
}

/* ------------------------------------------------------------------ превью обложки */

/**
 * Живое превью: градиент по оттенку имени и первая буква. Ровно так будет выглядеть плитка
 * пустого плейлиста до первого трека, так что человек видит результат до нажатия «Создать».
 */
@Composable
internal fun PlaylistCoverPreview(name: String, modifier: Modifier = Modifier) {
    val hue = PlaylistNaming.coverHue(name)
    val glyph = PlaylistNaming.coverGlyph(name)
    val top by animateColorAsState(Color.hsv(hue, 0.62f, 0.78f), tween(260), label = "cover-top")
    val bottom by animateColorAsState(Color.hsv((hue + 38f) % 360f, 0.78f, 0.30f), tween(260), label = "cover-bottom")
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(top, bottom))),
        contentAlignment = Alignment.Center
    ) {
        if (glyph.isEmpty()) {
            Icon(ZiziIcons.Queue, contentDescription = null, tint = Color.White.copy(alpha = 0.92f), modifier = Modifier.size(44.dp))
        } else {
            Text(glyph, color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Black)
        }
    }
}

/* ------------------------------------------------------------------ форма */

/**
 * Форма создания. Живёт внутри любого листа: [PlaylistCreateSheet] и лист выбора плейлиста.
 *
 * @param onCreate получает уже ОЧИЩЕННОЕ имя ([PlaylistNaming.clean]).
 * @param onBack если не null — сверху стрелка «к списку» (режим внутри листа выбора).
 */
@Composable
internal fun PlaylistCreateForm(
    existingNames: Collection<String>,
    onCreate: (String) -> Unit,
    initial: String = "",
    title: String = "Новый плейлист",
    subtitle: String? = null,
    confirmLabel: String = "Создать",
    onBack: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    var field by rememberSaveable(initial, stateSaver = TextFieldValue.Saver) {
        val start = PlaylistNaming.limitInput(initial)
        // Заготовка выделена целиком: одно касание клавиатуры заменяет её, а не дописывает.
        mutableStateOf(TextFieldValue(start, selection = TextRange(0, start.length)))
    }
    val focus = remember { FocusRequester() }
    AutoFocus(focus)

    val calendar = remember { java.util.Calendar.getInstance() }
    val suggestions = remember(existingNames) {
        PlaylistNaming.suggestions(
            month = calendar.get(java.util.Calendar.MONTH) + 1,
            year = calendar.get(java.util.Calendar.YEAR),
            existing = existingNames
        )
    }
    val canCreate = PlaylistNaming.canCreate(field.text)
    val duplicate = remember(field.text, existingNames) { PlaylistNaming.isDuplicate(field.text, existingNames) }
    var submitted by remember { mutableStateOf(false) }
    val submit = {
        if (canCreate && !submitted) {
            submitted = true
            onCreate(PlaylistNaming.clean(field.text))
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(start = if (onBack != null) 8.dp else 22.dp, end = 22.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Icon(ZiziIcons.ArrowBack, contentDescription = "К списку плейлистов", tint = p.text, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(4.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!subtitle.isNullOrBlank()) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(Modifier.height(12.dp))
        PlaylistCoverPreview(field.text, Modifier.align(Alignment.CenterHorizontally).size(132.dp))
        Spacer(Modifier.height(20.dp))

        ZiziNameField(
            value = field,
            onValueChange = { field = it },
            placeholder = "Как назовём?",
            focusRequester = focus,
            maxLength = PlaylistNaming.MAX_LENGTH,
            onDone = submit,
            modifier = Modifier.padding(horizontal = 22.dp)
        )

        // Строка-подсказка фиксированной высоты: появление предупреждения не двигает кнопку.
        Box(Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 26.dp), contentAlignment = Alignment.CenterStart) {
            if (duplicate) {
                Text("Такой плейлист уже есть — появится второй с тем же именем", color = p.brand, fontSize = 12.5.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (suggestions.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                suggestions.forEach { suggestion ->
                    val active = PlaylistNaming.clean(field.text) == suggestion
                    Box(
                        Modifier
                            .height(36.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (active) p.brand else p.chip)
                            .clickable { field = TextFieldValue(suggestion, selection = TextRange(suggestion.length)) }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(suggestion, color = if (active) p.onBrand else p.text, fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        ZiziPrimaryButton(
            label = confirmLabel,
            enabled = canCreate && !submitted,
            onClick = submit,
            modifier = Modifier.padding(horizontal = 22.dp)
        )
    }
}

/** Главная кнопка листа: бренд, 54 dp, во всю ширину. Одна на экран. */
@Composable
internal fun ZiziPrimaryButton(label: String, enabled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val background by animateColorAsState(if (enabled) p.brand else p.chip, tween(160), label = "primary-bg")
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (enabled) p.onBrand else p.subtext, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

/** Отдельный лист «Новый плейлист» — для «+» в медиатеке. */
@Composable
fun PlaylistCreateSheet(
    existingNames: Collection<String>,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
    initial: String = "",
    title: String = "Новый плейлист",
    subtitle: String? = null,
    confirmLabel: String = "Создать"
) {
    ZiziSheetScaffold(onDismiss) {
        val exit = LocalSheetExit.current
        PlaylistCreateForm(
            existingNames = existingNames,
            initial = initial,
            title = title,
            subtitle = subtitle,
            confirmLabel = confirmLabel,
            onCreate = { name -> exit { onCreate(name) } }
        )
    }
}
