@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import app.ziziplayer.ui.AccountUiGeometry
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.PinnedPageHeader
import app.ziziplayer.ui.components.surfaceInputBoundary
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.lerp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.profileKey
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.ui.components.AccountAvatar
import app.ziziplayer.ui.components.accountColor
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

/** Measured ratios from 1080px reference. Width-scaled geometry; font scaling remains accessible. */
@Composable
internal fun accountScale(): Float = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp / 360f).coerceAtMost(1.6f)

internal fun profileName(state: AccountLocalState, profile: AccountProfile): String =
    profile.name.ifBlank { state.displayName?.substringBefore('@')?.ifBlank { null } ?: "ZiziPlayer" }

@Composable
fun AccountScreen(
    state: AccountLocalState,
    profile: AccountProfile,
    signInOffered: Boolean,
    playlists: List<PlaylistEntity>,
    playlistMeta: Map<Long, app.ziziplayer.data.PlaylistMeta>,
    onPlaylist: (Long) -> Unit,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onSignOutAll: () -> Unit,
    onClose: () -> Unit,
    onOpenLibrary: () -> Unit,
    onSettings: () -> Unit,
    onEdit: () -> Unit,
    onRefresh: () -> Unit,
    hiddenPlaylists: Set<String> = emptySet(),
    onManagePlaylists: () -> Unit = {},
    onPlaylistMenu: (Long) -> Unit = {}
) {
    val visiblePlaylists = remember(playlists, hiddenPlaylists) {
        playlists.filterNot { it.profileKey in hiddenPlaylists }
    }
    val p = LocalPalette.current
    val scale = accountScale()
    val name = profileName(state, profile)
    val color = accountColor(state.userId.orEmpty())
    var menu by remember { mutableStateOf(false) }
    var preview by remember(profile.avatar) { mutableStateOf(false) }
    var logoutAll by remember { mutableStateOf<Boolean?>(null) }
    val list = rememberLazyListState()
    val density = LocalDensity.current
    val toolbarPx = with(density) { 56.dp.toPx() }
    var heroPx by remember { mutableIntStateOf(0) }
    val bottom = LocalBottomChromeInset.current
    val progress: () -> Float = remember(list, toolbarPx, heroPx) {
        { if (list.firstVisibleItemIndex > 0) 1f else AccountUiGeometry.collapse(
            list.firstVisibleItemScrollOffset.toFloat(), heroPx.toFloat(), toolbarPx) }
    }
    Box(Modifier.fillMaxSize().background(p.surface)) {
    // The hero colour leaves the status region as the toolbar collapses. The SAME
    // pinnedPageChrome above paints both regions; there is no additional system tint.
    Box(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).drawBehind {
        drawRect(lerp(color, p.surface, progress().coerceIn(0f, 1f)))
    })
    LazyColumn(state = list, modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(bottom = bottom + 24.dp)) {
        item(key = "profile:hero", contentType = "hero") {
        Column(Modifier.fillMaxWidth().onSizeChanged { heroPx = it.height }
            .background(Brush.verticalGradient(listOf(color, p.surface)))) {
            Spacer(Modifier.height(56.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = (15.3f*scale).dp), verticalAlignment = Alignment.CenterVertically) {
                AccountAvatar(state.userId.orEmpty(), name, profile.avatar, (108*scale).dp,
                    Modifier.semantics { contentDescription = "Аватарка профиля" }.combinedClickable(enabled = profile.avatar.isNotBlank(),
                        onClickLabel = "Просмотреть аватарку", onLongClickLabel = "Просмотреть аватарку",
                        onClick = { preview = true }, onLongClick = { preview = true }))
                Spacer(Modifier.width((15.3f*scale).dp))
                Column(Modifier.weight(1f)) {
                    Text(if (state.isGuest) "Гостевой режим" else name, color = p.text, fontSize = (24*scale).sp,
                        fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Text(if (state.isGuest) "Данные на телефоне" else "Аккаунт ZiziPlayer", color = p.subtext, fontSize = 14.sp)
                }
            }
            Row(Modifier.padding(start = (15.3f*scale).dp, top = (23*scale).dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = if (state.isGuest) onSignIn else onEdit,
                    enabled = if (state.isGuest) signInOffered else profile.loaded && !profile.busy,
                    shape = CircleShape) { Text(if (state.isGuest) "Войти" else "Изменить", color = p.text, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                IconButton(onClick = onSettings) { Icon(ZiziIcons.AccountGear, "Настройки", tint = p.subtext, modifier = Modifier.size(26.dp)) }
                IconButton(onClick = { menu = true }) { Icon(ZiziIcons.More, "Меню аккаунта", tint = p.subtext) }
            }
        }
        }
        item(key = "profile:heading", contentType = "heading") {
        Column(Modifier.padding(horizontal = (15.3f*scale).dp)) {
            if (profile.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (profile.error.isNotBlank()) {
                Text(profile.error, color = p.subtext)
                TextButton(onClick = onRefresh, enabled = !profile.busy) { Text("Повторить") }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Плейлисты", color = p.text, fontSize = (20*scale).sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = onManagePlaylists) {
                    Icon(ZiziIcons.Edit, null, tint = p.subtext, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Изменить", color = p.subtext, fontWeight = FontWeight.Bold)
                }
            }
            if (visiblePlaylists.isEmpty()) Text(if (playlists.isEmpty()) "Плейлистов пока нет. Создай первый в медиатеке."
                else "Плейлисты скрыты. Нажми «Изменить», чтобы вернуть их в профиль.", color = p.subtext)
        }
        }
            items(visiblePlaylists, key = { "profile:playlist:${it.id}" }, contentType = { "playlist" }) { playlist ->
                Row(Modifier.fillMaxWidth().padding(horizontal = (15.3f*scale).dp).clickable { onPlaylist(playlist.id) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    val cover = playlistMeta[playlist.id]?.cover
                    if (playlist.coverUri != null) app.ziziplayer.ui.components.RemoteArtwork(
                        playlist.coverUri, playlist.name, 160, Modifier.size((46*scale).dp))
                    else app.ziziplayer.ui.components.TrackArtwork(cover, 160, Modifier.size((46*scale).dp), glyphSize = 24)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(playlist.name, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("Треков: ${playlistMeta[playlist.id]?.count ?: 0}", color = p.subtext, fontSize = 14.sp)
                    }
                    IconButton(onClick = { onPlaylistMenu(playlist.id) }) {
                        Icon(ZiziIcons.More, "Меню плейлиста ${playlist.name}", tint = p.subtext)
                    }
                }
            }
        item(key = "profile:cloud", contentType = "cloud") {
        Column(Modifier.padding(horizontal = (15.3f*scale).dp)) {
            Spacer(Modifier.height(24.dp))
            AccountMenuRow(ZiziIcons.Cloud, "Библиотека и облачное сохранение", libraryRowSubtitle("Статус, экспорт и восстановление"), onOpenLibrary)
            Text("Сам вход ещё не означает, что данные отправлены. До подтверждения сохранения данные остаются только на телефоне.", color = p.subtext, fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
        }
    }
    }
    PinnedPageHeader(title = if (state.isGuest) "Гостевой режим" else name,
        progress = progress, onBack = onClose)
    }
    if (preview) AccountPhotoPreview(profile.avatar, onDismiss = { preview = false })
    if (menu) ZiziSheetScaffold(onDismiss = { menu = false }) {
        val exit = LocalSheetExit.current
        SheetTitle("Аккаунт")
        MenuItem(ZiziIcons.Cloud, "Облачная библиотека", onClick = { exit(onOpenLibrary) })
        if (!state.isGuest) {
            MenuItem(ZiziIcons.Refresh, "Обновить профиль", onClick = { exit(onRefresh) })
            MenuItem(ZiziIcons.ArrowBack, "Выйти", onClick = { exit { logoutAll = false } })
            MenuItem(ZiziIcons.Phone, "Выйти на всех устройствах", danger = true, onClick = { exit { logoutAll = true } })
        }
    }
    logoutAll?.let { all -> AlertDialog(onDismissRequest = { logoutAll = null },
        title = { Text(if (all) "Выйти на всех устройствах?" else "Выйти из аккаунта?") },
        text = { Text("Локальная библиотека останется на телефоне. Перед выходом проверьте сохранение в облако. Данные другого аккаунта не загружаются без отдельного выбора.") },
        confirmButton = { TextButton(onClick = { logoutAll = null; if (all) onSignOutAll() else onSignOut() }) { Text("Выйти") } },
        dismissButton = { TextButton(onClick = { logoutAll = null }) { Text("Отмена") } }) }
}

/**
 * 6.68.0. Окно выбора копии больше не выскакивает само — поэтому развилка обязана быть видна
 * здесь, в том месте, куда человек и так пойдёт за библиотекой.
 */
@Composable
private fun libraryRowSubtitle(normal: String): String {
    val context = androidx.compose.ui.platform.LocalContext.current
    val sync = androidx.compose.runtime.remember { app.ziziplayer.library.LibrarySync.get(context) }
    val state by sync.state.collectAsStateWithLifecycle()
    return if (state.needsChoice) "Нужно выбрать копию — данные не удалены" else normal
}

@Composable
internal fun AccountMenuRow(icon: ImageVector, title: String, subtitle: String = "", onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = 58.dp).clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = p.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotEmpty()) { Spacer(Modifier.height(5.dp)); Text(subtitle, color = p.subtext, fontSize = 13.sp) }
        }
    }
}

@Composable
fun AccountDrawer(state: AccountLocalState, profile: AccountProfile,
    onProfile: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit, onLibrary: () -> Unit) {
    val p = LocalPalette.current
    val scale = accountScale()
        // Width and movement belong exclusively to AccountDrawerHost.
        Column(Modifier.fillMaxSize().background(Color(0xFF202020))
            .surfaceInputBoundary().statusBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = (15.3f*scale).dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                AccountAvatar(state.userId.orEmpty(), profileName(state, profile), profile.avatar, (46*scale).dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(profileName(state, profile), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("Посмотреть профиль", color = p.subtext, fontSize = 14.sp)
                }
            }
            HorizontalDivider(color = Color(0xFF383838))
            Column(Modifier.padding(horizontal = (15.3f*scale).dp)) {
                AccountMenuRow(ZiziIcons.History, "Недавние", onClick = onHistory)
                AccountMenuRow(ZiziIcons.Cloud, "Облачная библиотека", libraryRowSubtitle("Сохранение и восстановление"), onLibrary)
                AccountMenuRow(ZiziIcons.AccountGear, "Настройки", onClick = onSettings)
            }
        }
}
