package app.ziziplayer.playback.dsp

/**
 * Полное описание звукового тракта. Неизменяемое значение: UI, ViewModel, сервис и аудиопоток
 * обмениваются им целиком и никогда не правят поля на месте.
 *
 * В классе нет ни одного импорта android.*: вся логика тракта проверяется JVM-тестами.
 *
 * 6.69.0. Параметры разложены на два слоя, и это не косметика, а основа пресетов:
 *  - ТЕМБР — [bandsDb], [preampDb], [bandQ], [bassDrive], [air]: как звучит сам трек;
 *  - СЦЕНА — [reverbMix]/[reverbSize]/[reverbDamp], [underwater], [rotation]/[rotationHz],
 *    [width], [drive]: где и как он звучит.
 * Пресет тембра переписывает ВЕСЬ тембр и не трогает сцену; пресет сцены — наоборот
 * (см. [DspPresets]). До 6.69.0 пресеты правили произвольные поля, и «Рок» после «Клуба»
 * оставлял чужой перегруз, который нельзя было ни увидеть, ни снять тем же пресетом.
 */
data class DspConfig(
    val enabled: Boolean = false,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(BAND_COUNT) { 0f },
    val bandQ: Float = 1.0f,

    // ---- тембр, модули ----
    /** Психоакустический бас: гармоники низа, слышные даже там, где динамик низ не играет. */
    val bassDrive: Float = 0f,
    /** «Воздух»: мягкая полка выше 11 кГц. */
    val air: Float = 0f,

    // ---- сцена ----
    /** Ширина стерео: -1 — моно, 0 — как есть, 1 — шире. */
    val width: Float = 0f,
    val underwater: Float = 0f,
    /** Глубина 8D-вращения, 0..1. */
    val rotation: Float = 0f,
    /** Скорость вращения в оборотах в секунду. */
    val rotationHz: Float = 0.12f,
    val reverbMix: Float = 0f,
    val reverbSize: Float = 0.5f,
    val reverbDamp: Float = 0.5f,
    /** Ламповое насыщение всего сигнала. */
    val drive: Float = 0f,

    // ---- защита ----
    val limiter: Boolean = true,
    /**
     * 6.69.0. Авто-запас: тракт сам опускает уровень ровно на максимальный подъём кривой.
     * Без него +8 дБ на басу означали «упрись в лимитер на каждой бочке», и человек не понимал,
     * почему трек начинает «дышать». Для строк, сохранённых до 6.69.0, по умолчанию выключен
     * (см. [DspCodec.decode]): громкость старых настроек меняться не должна.
     */
    val autoGain: Boolean = true
) {

    /**
     * Нейтральность — про результат, а не про флаг. Нейтральный тракт в аудиопотоке не стоит ни
     * одного умножения: процессор копирует байты как есть.
     */
    val isNeutral: Boolean
        get() = !enabled || (!hasTimbre && !hasScene)

    /** Есть ли что-то в слое тембра. */
    val hasTimbre: Boolean
        get() = preampDb != 0f || bandsDb.any { it != 0f } || bassDrive != 0f || air != 0f

    /** Есть ли что-то в слое сцены. */
    val hasScene: Boolean
        get() = width != 0f || underwater != 0f || rotation != 0f || reverbMix != 0f || drive != 0f

    fun sanitized(): DspConfig {
        val bands = ArrayList<Float>(BAND_COUNT)
        for (i in 0 until BAND_COUNT) {
            bands.add(bandsDb.getOrElse(i) { 0f }.finiteOr(0f).coerceIn(-BAND_LIMIT_DB, BAND_LIMIT_DB))
        }
        return copy(
            preampDb = preampDb.finiteOr(0f).coerceIn(PREAMP_MIN_DB, PREAMP_MAX_DB),
            bandsDb = bands,
            bandQ = bandQ.finiteOr(1f).coerceIn(Q_MIN, Q_MAX),
            bassDrive = bassDrive.unit(),
            air = air.unit(),
            width = width.finiteOr(0f).coerceIn(-1f, 1f),
            underwater = underwater.unit(),
            rotation = rotation.unit(),
            rotationHz = rotationHz.finiteOr(0.12f).coerceIn(ROTATION_HZ_MIN, ROTATION_HZ_MAX),
            reverbMix = reverbMix.unit(),
            reverbSize = reverbSize.unit(),
            reverbDamp = reverbDamp.unit(),
            drive = drive.unit()
        )
    }

    /** Слой тембра из [other], сцена и флаги остаются свои. */
    fun withTimbreOf(other: DspConfig): DspConfig = copy(
        preampDb = other.preampDb, bandsDb = other.bandsDb, bandQ = other.bandQ,
        bassDrive = other.bassDrive, air = other.air
    )

    /** Слой сцены из [other], тембр и флаги остаются свои. */
    fun withSceneOf(other: DspConfig): DspConfig = copy(
        width = other.width, underwater = other.underwater, rotation = other.rotation,
        rotationHz = other.rotationHz, reverbMix = other.reverbMix, reverbSize = other.reverbSize,
        reverbDamp = other.reverbDamp, drive = other.drive
    )

    /** Сброс только тембра: кривая в ноль, эффекты сцены остаются. */
    fun clearedTimbre(): DspConfig = withTimbreOf(NEUTRAL)

    /** Сброс только сцены: эффекты в ноль, кривая остаётся. */
    fun clearedScene(): DspConfig = withSceneOf(NEUTRAL)

    /**
     * Перенос старого «Реверб %» (прошивочный PresetReverb до 6.24.4) в наш ревер. Вызывается
     * ровно тогда, когда у трека ещё нет собственной строки тракта.
     */
    fun withLegacyReverb(percent: Int): DspConfig {
        if (percent <= 0) return this
        val p = percent.coerceIn(0, 100) / 100f
        return copy(
            enabled = true,
            reverbMix = maxOf(reverbMix, p * 0.55f),
            reverbSize = maxOf(reverbSize, 0.35f + p * 0.5f)
        )
    }

    companion object {
        const val BAND_COUNT = 10
        const val BAND_LIMIT_DB = 12f
        const val PREAMP_MIN_DB = -12f
        const val PREAMP_MAX_DB = 6f
        const val Q_MIN = 0.5f
        const val Q_MAX = 4f
        const val ROTATION_HZ_MIN = 0.02f
        const val ROTATION_HZ_MAX = 1.5f

        /** ISO-октавы. Меняются только вместе с версией кодека: строки хранят 10 чисел по порядку. */
        val BAND_FREQUENCIES = floatArrayOf(
            31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f
        )

        val BAND_LABELS = arrayOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

        /** Человеческое имя области частот — подпись в пузыре над ползунком полосы. */
        val BAND_ROLES = arrayOf(
            "саб-бас", "бас", "удар", "тело", "середина",
            "голос", "присутствие", "чёткость", "яркость", "воздух"
        )

        val NEUTRAL = DspConfig()

        private fun Float.finiteOr(fallback: Float): Float =
            if (isNaN() || isInfinite()) fallback else this

        private fun Float.unit(): Float = finiteOr(0f).coerceIn(0f, 1f)
    }
}

/**
 * Частотная характеристика тракта — одна формула и для звука, и для экрана.
 *
 * Считается теми же [Biquad], что работают в аудиопотоке, поэтому кривая на экране — это то,
 * что реально звучит (включая перекрытие соседних полос при широком Q), а не сплайн по точкам.
 * Вызывается вне аудиопотока: в [DspEngine.setConfig] и при рисовании.
 */
object DspResponse {
    /** Частота, на которой считается кривая для экрана и авто-запаса. */
    const val REFERENCE_RATE = 48000

    /** Частота полки «воздуха» и её максимальный подъём — общие для движка и расчёта. */
    const val AIR_FREQ = 11000f
    const val AIR_MAX_DB = 7f

    private val peakGrid: FloatArray = grid(96)

    /** Логарифмическая сетка 20 Гц..20 кГц из [points] точек. */
    fun grid(points: Int): FloatArray {
        val n = points.coerceAtLeast(2)
        val lo = kotlin.math.ln(20.0)
        val hi = kotlin.math.ln(20000.0)
        return FloatArray(n) { i -> kotlin.math.exp(lo + (hi - lo) * i / (n - 1)).toFloat() }
    }

    /** Суммарная АЧХ полос и «воздуха» в дБ на частотах [freqs]. Пре-амп и авто-запас не входят. */
    fun curveDb(c: DspConfig, freqs: FloatArray, rate: Int = REFERENCE_RATE): FloatArray {
        val s = c.sanitized()
        val out = FloatArray(freqs.size)
        val filter = Biquad(1)
        for (b in 0 until DspConfig.BAND_COUNT) {
            val g = s.bandsDb[b]
            if (g == 0f) continue
            filter.setPeaking(rate, DspConfig.BAND_FREQUENCIES[b], g, s.bandQ)
            for (i in freqs.indices) out[i] += filter.magnitudeDb(rate, freqs[i])
        }
        if (s.air > 0f) {
            filter.setHighShelf(rate, AIR_FREQ, s.air * AIR_MAX_DB)
            for (i in freqs.indices) out[i] += filter.magnitudeDb(rate, freqs[i])
        }
        return out
    }

    /** Максимальный подъём кривой, дБ, не меньше нуля. */
    fun peakBoostDb(c: DspConfig): Float {
        if (!c.hasTimbre) return 0f
        var max = 0f
        for (v in curveDb(c, peakGrid)) if (v > max) max = v
        return max
    }

    /**
     * Сколько авто-запас снимает с уровня, дБ (≤ 0). Психоакустический бас добавляет гармоники
     * поверх кривой — ему отдаётся ещё до 2 дБ.
     */
    fun autoGainDb(c: DspConfig): Float {
        val s = c.sanitized()
        if (!s.enabled || !s.autoGain) return 0f
        val boost = peakBoostDb(s) + 2f * s.bassDrive
        return -boost.coerceIn(0f, -DspConfig.PREAMP_MIN_DB)
    }

    /** Итоговый уровень на входе тракта: ручной пре-амп плюс авто-запас. */
    fun effectivePreampDb(c: DspConfig): Float = c.sanitized().preampDb + autoGainDb(c)
}

/**
 * Какой тракт звучит у трека. Одна функция и для сервиса ([app.ziziplayer.playback.DspDirector]),
 * и для экрана: иначе неизбежен день, когда ползунок показывает одно, а звучит другое.
 *
 * 1. Глобальный режим -> глобальная строка, своя строка трека не читается (и не стирается).
 * 2. У трека есть своя строка -> она.
 * 3. Строки нет, но есть старый «Реверб %» -> переносится в наш ревер.
 * 4. Ничего нет -> нейтраль.
 */
object DspResolve {
    fun forTrack(eqConfig: String?, legacyReverb: Int, global: Boolean, globalConfig: String?): DspConfig = when {
        global -> DspCodec.decode(globalConfig)
        eqConfig != null -> DspCodec.decode(eqConfig)
        else -> DspConfig.NEUTRAL.withLegacyReverb(legacyReverb)
    }
}

/**
 * Строковый формат для Room и DataStore: `v1|on=1;pre=-2;bands=1,2,...;...`.
 *
 * Ключ=значение, а не позиционный CSV: новое поле дописывается ключом, старые строки читаются
 * с умолчанием, битая строка даёт нейтраль, а не падение при старте. Независим от локали.
 */
object DspCodec {

    private const val VERSION = "v1"

    fun encode(c: DspConfig): String {
        val s = c.sanitized()
        val sb = StringBuilder(VERSION).append('|')
        fun put(k: String, v: Any) { sb.append(k).append('=').append(v).append(';') }
        put("on", if (s.enabled) 1 else 0)
        put("pre", fmt(s.preampDb))
        put("bands", s.bandsDb.joinToString(",") { fmt(it) })
        put("q", fmt(s.bandQ))
        put("bass", fmt(s.bassDrive))
        put("air", fmt(s.air))
        put("wide", fmt(s.width))
        put("water", fmt(s.underwater))
        put("rot", fmt(s.rotation))
        put("rothz", fmt(s.rotationHz))
        put("rvmix", fmt(s.reverbMix))
        put("rvsize", fmt(s.reverbSize))
        put("rvdamp", fmt(s.reverbDamp))
        put("drive", fmt(s.drive))
        put("lim", if (s.limiter) 1 else 0)
        put("ag", if (s.autoGain) 1 else 0)
        return sb.toString()
    }

    fun decode(raw: String?): DspConfig {
        if (raw.isNullOrBlank()) return DspConfig.NEUTRAL
        val body = raw.substringAfter('|', raw)
        val map = HashMap<String, String>()
        for (part in body.split(';')) {
            if (part.isBlank()) continue
            val i = part.indexOf('=')
            if (i <= 0) continue
            map[part.substring(0, i).trim()] = part.substring(i + 1).trim()
        }
        fun f(k: String, d: Float): Float = map[k]?.toFloatOrNull() ?: d
        fun b(k: String, d: Boolean): Boolean = map[k]?.let { it == "1" || it == "true" } ?: d
        val bands = map["bands"]?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: emptyList()
        return DspConfig(
            enabled = b("on", false),
            preampDb = f("pre", 0f),
            bandsDb = bands,
            bandQ = f("q", 1f),
            bassDrive = f("bass", 0f),
            air = f("air", 0f),
            width = f("wide", 0f),
            underwater = f("water", 0f),
            rotation = f("rot", 0f),
            rotationHz = f("rothz", 0.12f),
            reverbMix = f("rvmix", 0f),
            reverbSize = f("rvsize", 0.5f),
            reverbDamp = f("rvdamp", 0.5f),
            drive = f("drive", 0f),
            limiter = b("lim", true),
            // Строки до 6.69.0 ключа не знают: авто-запас для них выключен, громкость прежняя.
            autoGain = b("ag", false)
        ).sanitized()
    }

    private fun fmt(v: Float): String {
        val r = Math.round(v * 100f) / 100f
        return if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()
    }
}
