package app.ziziplayer.ui

/*
 * 6.67.0. Правило имени плейлиста — одно на форму создания, переименование, импорт и
 * MainViewModel.createPlaylist. Лежит в пакете ui рядом с остальными политиками (HomeFeedPolicy,
 * SearchPresentation), а не в screens: вьюмодель не должна зависеть от экранов.
 */

/** Чистая логика имени плейлиста. Никакого Android и Compose — только строки. */
object PlaylistNaming {
    /** Потолок длины. 60 символов — две строки в плитке медиатеки и одна в шапке коллекции. */
    const val MAX_LENGTH = 60

    private val SPACES = Regex("\\s+")

    /** Обрезать края, схлопнуть внутренние пробелы/табы/переводы строк, срезать до лимита. */
    fun clean(raw: String): String = raw.replace(SPACES, " ").trim().take(MAX_LENGTH).trim()

    /** Что делать с вводом ДО сохранения: переводы строк запрещены, длина ограничена. */
    fun limitInput(raw: String): String = raw.replace('\n', ' ').replace('\r', ' ').take(MAX_LENGTH)

    fun canCreate(raw: String): Boolean = clean(raw).isNotEmpty()

    /** Дубль — без учёта регистра и лишних пробелов: «Ночь» и « ночь » одно и то же для глаза. */
    fun isDuplicate(raw: String, existing: Collection<String>): Boolean {
        val key = clean(raw).lowercase()
        if (key.isEmpty()) return false
        return existing.any { clean(it).lowercase() == key }
    }

    private val MONTHS = listOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    )

    /** [month] — 1..12. Вне диапазона — пустая строка, а не падение. */
    fun monthName(month: Int): String = MONTHS.getOrElse(month - 1) { "" }

    private val BASE_SUGGESTIONS = listOf("Любимое", "В дорогу", "Тренировка", "Ночной вайб", "Фокус", "Под настроение")

    /**
     * Подсказки под полем. Уже занятые имена не предлагаются: подсказка, которая ведёт в дубль,
     * хуже отсутствия подсказки. Первая — «месяц год»: самый частый способ назвать сборник.
     */
    fun suggestions(month: Int, year: Int, existing: Collection<String>, limit: Int = 6): List<String> {
        val seasonal = monthName(month).takeIf { it.isNotEmpty() }?.let { "$it $year" }
        return (listOfNotNull(seasonal) + BASE_SUGGESTIONS)
            .filterNot { isDuplicate(it, existing) }
            .take(limit)
    }

    /**
     * Оттенок обложки-превью, 0..359. String.hashCode задан спецификацией Java и одинаков на
     * всех устройствах, поэтому одно и то же имя всегда даёт один и тот же цвет.
     */
    fun coverHue(raw: String): Float {
        val key = clean(raw).lowercase()
        if (key.isEmpty()) return 24f // бренд #F97316 ≈ 25°
        return Math.floorMod(key.hashCode(), 360).toFloat()
    }

    /** Буква на превью: первая буква или цифра имени, заглавная. Эмодзи и знаки пропускаются. */
    fun coverGlyph(raw: String): String =
        clean(raw).firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString().orEmpty()
}
