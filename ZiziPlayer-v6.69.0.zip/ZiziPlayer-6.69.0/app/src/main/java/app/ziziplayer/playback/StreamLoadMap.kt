package app.ziziplayer.playback

import android.os.SystemClock
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.cache.ContentMetadata

/**
 * 6.68.0. Карта РЕАЛЬНО скачанных участков потокового трека.
 *
 * До этой версии «тень» на дорожке была одним числом — bufferedPosition плеера. Это буфер
 * ПЕРЕД головкой воспроизведения, и больше ничего: после перемотки назад он обнулялся и рос
 * заново от бегунка, хотя байты этого места давно лежали на диске. Человек видел, как зона
 * загрузки «перезапускается» и бежит следом за пальцем.
 *
 * Здесь спрашивается сам дисковый кэш (SimpleCache): какие байтовые диапазоны ресурса у нас
 * есть. Диапазон байтов переводится в долю трека по полной длине ресурса. Для аудио потока
 * это почти линейно (заголовок — доли процента), чего достаточно для честной картинки.
 *
 * Запрос дешёвый (индекс в памяти), но не бесплатный, поэтому результат держится
 * [MIN_INTERVAL_MS] и пересчитывается только для текущего ключа.
 */
@OptIn(UnstableApi::class)
internal class StreamLoadMap {
    private companion object {
        const val MIN_INTERVAL_MS = 300L
        /** Шаг квантования долей: мельче пикселя нет смысла, а без него Progress менялся бы на каждом тике. */
        const val QUANT = 500f
    }

    private var lastKey: String? = null
    private var resolvedKey: String? = null
    private var lastAt = 0L
    private var last: List<Float> = emptyList()

    fun reset() { lastKey = null; resolvedKey = null; last = emptyList(); lastAt = 0L }

    /** [uri] — zizi://-адрес трека (ключ кэша); null/локальный — пустая карта. */
    fun query(uri: String?): List<Float> {
        if (uri == null || !RemoteUri.isRemote(uri)) { if (lastKey != null) reset(); return emptyList() }
        val now = SystemClock.elapsedRealtime()
        if (uri == lastKey && now - lastAt < MIN_INTERVAL_MS) return last
        if (uri != lastKey) { lastKey = uri; resolvedKey = null; last = emptyList() }
        lastAt = now
        val cache = StreamCache.peek() ?: return emptyList()
        last = try {
            val key = resolvedKey ?: findKey(cache, uri)?.also { resolvedKey = it } ?: return emptyList()
            val length = ContentMetadata.getContentLength(cache.getContentMetadata(key))
            if (length <= 0L) return emptyList()
            val out = ArrayList<Float>()
            var s = -1L; var e = -1L
            for (span in cache.getCachedSpans(key)) {
                if (!span.isCached || span.length <= 0L) continue
                val a = span.position; val b = span.position + span.length
                if (s < 0) { s = a; e = b }
                else if (a <= e) { if (b > e) e = b }
                else { addSpan(out, s, e, length); s = a; e = b }
            }
            if (s >= 0) addSpan(out, s, e, length)
            out
        } catch (_: Exception) { emptyList() }
        return last
    }

    private fun addSpan(out: MutableList<Float>, s: Long, e: Long, length: Long) {
        val a = q(s.toFloat() / length); var b = q(e.toFloat() / length)
        if (b >= 0.995f) b = 1f
        if (b > a) { out.add(a); out.add(b) }
    }

    private fun q(v: Float) = (v.coerceIn(0f, 1f) * QUANT).toInt() / QUANT

    /**
     * Ключ записи в кэше. CacheDataSource стоит НАД резолвером и по умолчанию ключует адресом
     * zizi://…; если когда-нибудь ключ получит суффикс (качество, режим прокси) — ищем по
     * префиксу один раз на трек и запоминаем.
     */
    private fun findKey(cache: androidx.media3.datasource.cache.Cache, uri: String): String? {
        if (cache.getCachedSpans(uri).isNotEmpty()) return uri
        return cache.keys.firstOrNull { it.startsWith(uri) && cache.getCachedSpans(it).isNotEmpty() }
    }
}
