@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.share.PlaylistFiles
import app.ziziplayer.share.PlaylistShare
import app.ziziplayer.ui.ImportRow
import app.ziziplayer.ui.ImportState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.PlaylistNaming
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.components.ZiziIcons

/* =========================================================== отправка ========================= */

/**
 * Лист «Поделиться плейлистом».
 *
 * Два транспорта в одном месте, потому что выбирает не разработчик, а мессенджер получателя: файл
 * уходит системной шторкой, строка кладётся в буфер обмена. Строка — не «на всякий случай», а
 * рабочий путь: часть мессенджеров переименовывает вложения и подменяет MIME, и файл на другом
 * конце перестаёт быть плейлистом.
 *
 * Числа показываются до отправки специально: человек должен видеть, что 12 треков из 40 уедут без
 * паспорта и будут искаться у получателя, а не узнавать это по его жалобе.
 */
@Composable
fun PlaylistShareSheet(vm: MainViewModel, playlist: PlaylistEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var payload by remember(playlist.id) { mutableStateOf<PlaylistShare.Payload?>(null) }

    LaunchedEffect(playlist.id) { payload = vm.playlistPayload(playlist) }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Поделиться плейлистом", playlist.name)
        val data = payload
        when {
            data == null -> Row(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(Modifier.size(18.dp), color = p.accent, strokeWidth = 2.dp)
                Spacer(Modifier.width(14.dp))
                Text("Собираем плейлист…", color = p.subtext, fontSize = 14.sp)
            }

            data.entries.isEmpty() -> Text(
                "Плейлист пуст — отправлять нечего.",
                color = p.subtext,
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 16.dp)
            )

            else -> {
                val text = remember(data) { PlaylistShare.encodeText(data) }
                val overflow = data.entries.size > PlaylistShare.MAX_TRACKS
                Column(Modifier.padding(horizontal = 22.dp)) {
                    Text(
                        "${data.entries.size} треков · ${data.readyCount} с паспортом" +
                            if (data.searchCount > 0) " · ${data.searchCount} будут искаться" else "",
                        color = p.subtext,
                        fontSize = 13.sp
                    )
                    if (overflow) Text(
                        "Уедут только первые ${PlaylistShare.MAX_TRACKS} — это лимит формата.",
                        color = p.accent,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Text(
                        "Едут названия и паспорта треков, а не музыка: около ${text.length / 1024 + 1} КБ.",
                        color = p.subtext,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                MenuItem(ZiziIcons.Share, "Отправить файлом") {
                    val uri = PlaylistFiles.write(context, data)
                    if (uri != null) {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = PlaylistShare.MIME
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_SUBJECT, playlist.name)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, "Плейлист «${playlist.name}»"))
                    }
                    onDismiss()
                }
                MenuItem(ZiziIcons.Copy, "Скопировать строкой") {
                    clipboard.setText(AnnotatedString(text))
                    onDismiss()
                }
            }
        }
    }
}

/* =========================================================== приём ============================= */

/**
 * Предпросмотр импорта.
 *
 * Показывает построчно, что получится, ДО создания плейлиста: своё, найденное в каталоге и не
 * найденное вообще. Кнопка создания активна, пока есть хотя бы один трек, и не ждёт конца поиска —
 * догонять каталогом двадцать чужих локальных треков можно долго, а плейлист из уже найденных
 * человеку нужен сейчас.
 */
@Composable
fun PlaylistImportSheet(vm: MainViewModel, state: ImportState, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var name by remember(state.name) { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue(state.name)) }

    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Плейлист", "${state.rows.size} треков")

        Column(Modifier.padding(horizontal = 22.dp)) {
            // 6.67.0: общее поле приложения вместо OutlinedTextField Material.
            ZiziNameField(
                value = name,
                onValueChange = { name = it },
                placeholder = "Название",
                maxLength = PlaylistNaming.MAX_LENGTH
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.looking > 0) {
                    CircularProgressIndicator(Modifier.size(14.dp), color = p.accent, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Ищем в каталоге: осталось ${state.looking}", color = p.subtext, fontSize = 13.sp)
                } else {
                    Text(
                        "Готово ${state.readyCount} из ${state.rows.size}" +
                            if (state.missing > 0) " · не найдено ${state.missing}" else "",
                        color = if (state.missing > 0) p.accent else p.subtext,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Свой LazyColumn, а не общий скролл листа: строк может быть 300, и вложить их в
        // verticalScroll означало бы построить все триста разом.
        LazyColumn(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 300.dp)
                .padding(top = 12.dp)
        ) {
            // Ключ по позиции, а не по треку: один и тот же трек может лежать в плейлисте дважды,
            // а повторяющийся key в LazyColumn — это не косметика, это падение на месте.
            itemsIndexed(state.rows) { _, row -> ImportRowView(row) }
        }

        Spacer(Modifier.height(14.dp))
        ZiziPrimaryButton(
            label = if (state.busy) "Создаём…" else "Создать плейлист",
            enabled = state.readyCount > 0 && !state.busy,
            onClick = { vm.confirmImport(PlaylistNaming.clean(name.text)) },
            modifier = Modifier.padding(horizontal = 22.dp)
        )
    }
}

@Composable
private fun ImportRowView(row: ImportRow) {
    val p = LocalPalette.current
    val icon: ImageVector
    val note: String
    when {
        row.local != null -> { icon = ZiziIcons.Phone; note = "уже на устройстве" }
        row.found != null -> { icon = ZiziIcons.CloudCheck; note = "нашёлся в каталоге" }
        row.entry.resolvable -> { icon = ZiziIcons.CloudCheck; note = "приехал с паспортом" }
        row.looked -> { icon = ZiziIcons.SearchOff; note = "не найден" }
        else -> { icon = ZiziIcons.Hourglass; note = "ищем…" }
    }
    val tint = if (row.ready) p.accent else p.subtext
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                row.entry.title,
                color = if (row.ready) p.text else p.subtext,
                fontSize = 15.sp,
                maxLines = 1
            )
            Text(
                listOfNotNull(
                    row.entry.artist.takeIf { it.isNotBlank() },
                    row.entry.durationMs.takeIf { it > 0 }?.let { formatTime(it) },
                    note
                ).joinToString(" · "),
                color = p.subtext,
                fontSize = 12.sp,
                maxLines = 1
            )
        }
    }
}

/* =========================================================== ручной ввод ======================= */

/**
 * Вставка плейлиста строкой.
 *
 * Поле заполняется из буфера обмена сразу: в девяти случаях из десяти человек пришёл сюда именно
 * после «скопировать» в мессенджере, и заставлять его делать долгое нажатие в пустом поле — это
 * лишний шаг ради ничего. [PlaylistShare.decode] терпит текст вокруг строки, так что вставлять
 * можно вместе с «смотри какой плейлист».
 */
@Composable
fun PastePlaylistDialog(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf(clipboard.getText()?.text.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Вставить плейлист", color = p.text) },
        text = {
            Column {
                Text(
                    "Строка вида ZIZI1:… или ссылка zizi://p/… — можно вместе с текстом сообщения.",
                    color = p.subtext,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = p.accent,
                        unfocusedBorderColor = p.subtext.copy(alpha = 0.4f),
                        cursorColor = p.accent,
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text); onDismiss() },
                enabled = text.isNotBlank()
            ) { Text("Открыть", color = p.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.subtext) } }
    )
}

/**
 * Два пути приёма в одном месте: файл через системный выбор и строка из буфера.
 *
 * 6.67.0: лист вместо AlertDialog. Карточка «Импортируй плейлист» в медиатеке — крупная плитка,
 * а открывалось из неё маленькое серое окно с кнопкой «Закрыть». Теперь это две большие плитки
 * в том же листе, что и остальные действия медиатеки; закрывается жестом, как все листы.
 */
@Composable
fun ImportSourceDialog(onFile: () -> Unit, onPaste: () -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        val exit = LocalSheetExit.current
        SheetTitle("Импорт плейлиста", "Файл .zizi, строка ZIZI1:… или ссылка zizi://")
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ImportSourceRow(ZiziIcons.FolderOpen, "Из файла", "Выбрать .zizi в файлах телефона") {
                exit { onFile() }
            }
            ImportSourceRow(ZiziIcons.Paste, "Вставить строкой", "Из буфера обмена — можно вместе с текстом сообщения") {
                exit { onPaste() }
            }
        }
    }
}

@Composable
private fun ImportSourceRow(icon: ImageVector, label: String, subtitle: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(p.brand.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.brand, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
        }
        Icon(ZiziIcons.ChevronRight, contentDescription = null, tint = p.subtext, modifier = Modifier.size(20.dp))
    }
}
