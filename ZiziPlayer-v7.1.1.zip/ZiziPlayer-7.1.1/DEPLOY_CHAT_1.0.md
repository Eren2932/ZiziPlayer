# Развёртывание чата (chat_server 1.0 + маршрут тикета в accounts)

Один сервер Aeza. Чат — отдельный процесс рядом с accounts, свой SQLite, свой systemd-юнит. Accounts и резолвер не трогаются,
кроме одного маршрута и одной строки в `accounts.env`.

## 1. Секрет (один на оба сервиса)
````bash
openssl rand -hex 32
````
- `ZIZI_CHAT_SECRET=<значение>` в `accounts.env` (см. `accounts_server/deploy/accounts.env.example`);
- то же значение в `/etc/zizi-chat/chat.env` (`chat_server/deploy/chat.env.example`, права 600).

## 2. Обновить accounts
Заменить `web.py`, добавить `chat_ticket.py`, `systemctl restart zizi-accounts`.
Проверка: без сессии `POST /auth/chat/ticket` отвечает 401; с секретом пустым в env — 503 `chat_not_configured`.

## 3. Поставить демон
````bash
cd chat_server && sudo bash deploy/install-zizi-chat.sh
curl -s http://127.0.0.1:8092/health      # ok:true, persist:true
````
Скрипт кладёт релиз в `/opt/zizi-chat/<дата>`, переключает `current`, оставляет 5 последних релизов,
добавляет drop-in `Nice=10` для резолвера.

## 4. nginx
Блок `location /rt/` из `chat_server/deploy/nginx-chat-location.conf.example` внутрь server-блока accounts-домена
(`proxy_buffering off`, `proxy_read_timeout 70s`, заголовок `X-Real-IP $remote_addr`). `nginx -t && systemctl reload nginx`.

## 5. Сквозная проверка (nginx + TLS + секрет)
````bash
python3 /opt/zizi-chat/current/smoke.py --env /etc/zizi-chat/chat.env --url wss://ВАШ_ХОСТ/rt/ws --say "smoke"
````
Все шаги должны быть `ok`. Затем нагрузка: `python3 loadtest.py` (параметры в начале файла).

## 6. Первый админ
Роль берётся из accounts. Назначается только локальной командой на сервере (клиент роль выдать не может):
````bash
sudo -u zizi-accounts /opt/zizi-accounts/venv/bin/python /opt/zizi-accounts/current/manage.py role \
  /var/lib/zizi-accounts/accounts.sqlite ВАША_ПОЧТА admin
````
Роль попадает в тикет при следующем подключении к чату: после назначения закройте и откройте экран «Общий».

## Откат
`ln -sfn /opt/zizi-chat/<предыдущий> /opt/zizi-chat/current && systemctl restart zizi-chat`.
Клиент без демона не ломается: экран покажет «Чат сейчас недоступен».

## Лимиты по диску
`ZIZI_CHAT_DB_MAX_MB=250`; запись в базу останавливается, если свободно меньше порога аудио-кэша + 64 МБ (чат продолжает работать из памяти).
