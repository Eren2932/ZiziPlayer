# Внешний workflow для ZiziPlayer 6.102.1

`build.yml` из этой папки заменяет **`.github/workflows/build.yml` в корне GitHub-репозитория**.
Это точечная правка реально установленного workflow на commit `366fb6d9cfc208548833fd72d5d70f775205a29d`:
добавлены комментарий и шаблон `ZiziPlayer-[0-9]*.zip`. Все шаги сборки, подписи,
публикации, camera-регрессий, permissions и concurrency сохранены без изменения.

GitHub НЕ читает workflow из загруженных ZIP. Просто загрузить новый source ZIP —
не значит обновить внешний workflow. Файл `build.yml` в корне репозитория тоже не подходит:
нужен именно `.github/workflows/build.yml`.

1. Заменить внешний workflow этим файлом (можно через GitHub: открыть файл → Edit → заменить содержимое).
2. Загрузить `ZiziPlayer-v6.102.1-source.zip` в корень `main` и закоммитить. Не распаковывать его в репозиторий.
3. В Actions ожидается автоматический запуск с событием `push`. В шаге выбора исходников:
   `Selected: ZiziPlayer-v6.102.1-source.zip version: 6.102.1 versionCode: 248`.
4. Оставить только один полный архив с максимальным versionCode 248. Старые архивы с меньшим кодом не мешают.

Новое имя ZIP содержит `v`, поэтому загрузка запускает сборку и на прежнем workflow.
Обновление внешнего workflow дополнительно разрешает будущие имена без `v`.
При последовательных коммитах предыдущий запуск может стать `cancelled` —
это существующий `cancel-in-progress: true`, новый запуск его заменяет.

Реальная Android-проверка остаётся в CI:
`gradle --no-daemon --max-workers=2 :app:compileDebugKotlin :app:compileReleaseKotlin :app:testDebugUnitTest --stacktrace`,
затем `gradle --no-daemon :app:assembleRelease --stacktrace`.
Gradle Wrapper-скриптов и wrapper JAR в исходной поставке нет; существующий workflow
устанавливает Gradle 8.11.1 через `gradle/actions/setup-gradle@v4`.
