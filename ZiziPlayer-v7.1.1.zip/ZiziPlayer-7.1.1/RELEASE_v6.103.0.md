# 6.103.0 — shared playlists and complete library picker

Read `START_HERE_6.103.0.md` for user-facing changes, build instructions and device acceptance checks.

## Source provenance

- Repository: https://github.com/Eren2932/ZiziPlayer
- Downloaded repository tree: `7f16ae435519037545fb3ec3dcd14404f3ad801d`
- Base archive: `ZiziPlayer-v6.102.1-source.zip`, 9,488,871 bytes.
- Base archive SHA-256: `fa45bddf1b79e68452807321778c55ad4530c0840b7826a0c3c5241c2dffd487`.
- Base archive Git blob SHA-1: `604c955f814ece0f098684e67ae76db746c6efce` (matches saved repository tree).
- Base archive CRC check passed; new release identity: versionName 6.103.0 / versionCode 249.

## Implementation map

| Area | Files | Change |
|---|---|---|
| Insets | `ZiziSheetHost.kt`, `Sheets.kt` | Dialog-local IME measurement, single consumed inset, busy dismissal guard |
| Layout | `SharedSheetLayout.kt` | One bounded LazyColumn with independently pinned action footer |
| Library source | `MusicDao.kt`, `MusicRepository.kt`, `SharedLibraryIndex.kt` | Complete owned-library union, canonical identity deduplication, existing privacy gates |
| Picker | `SharedLibraryPicker.kt` | Source tabs, global local-metadata search, retained cross-tab selection, limits and errors |
| Search | `SharedSearch.java` | Locale-independent normalization and reusable query tokens |
| Shared UI | `SharedScreens.kt`, `SharedUi.kt` | Accessible minimum controls, wrapping invitation choices, editable state locking, retry/empty states |
| Confirmed join | `SharedRepository.kt` | Record confirmed membership before snapshot retrieval; retry snapshot without reusing token |
| Tests | `test_shared_6103.py`, `SharedLibraryIndexTest.kt`, `SharedSearchTest.kt`, `SharedUi6103Checks.java` | Java math/search, SQLite membership, source contracts and pending Kotlin/JUnit tests |

No server/protocol changes, database migration, signing configuration or audio-engine changes. The new DAO method is a read-only query on the existing table. All versioned schemas are unchanged.

The archived source and host-side test results are a handoff for Android CI, not a claim of an APK build or a device performance measurement. Device UI acceptance remains required, especially IME animations/large font/landscape and other users of the common sheet host.
