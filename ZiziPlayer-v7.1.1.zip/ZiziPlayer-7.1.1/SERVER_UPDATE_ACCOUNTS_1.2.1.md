# Accounts 1.2.1 (клиент 6.108.0)

Меняется один файл: `accounts_server/core.py`. Остальной сервер не затронут.

## Что меняется
- Срок refresh — **простой**: 60 дней, каждая ротация продлевает. Было: ровно 7 дней от входа.
- Потерянный ответ ротации не отзывает сессию: предыдущий токен в течение 90 с после ротации получает новую пару.
  Окно повторами не продлевается, позапрошлый токен окна не имеет. Настройки: `REFRESH_SECONDS`, `REFRESH_REUSE_GRACE_SECONDS`
  (0 — прежняя строгость).
- В `sessions` добавляются колонки `rotated`, `previous_hash` — автоматически при старте. Старый код их игнорирует, откат безопасен.
- Уже выданные сессии не ломаются: при ближайшей ротации они получают новый срок.

## Установка
```
sudo cp -a /opt/zizi-accounts/releases/<текущий> /opt/zizi-accounts/releases/1.2.1
sudo cp accounts_server/core.py /opt/zizi-accounts/releases/1.2.1/core.py
sudo /opt/zizi-accounts/venv/bin/python /opt/zizi-accounts/releases/1.2.1/tests/test_accounts.py
sudo ln -sfn /opt/zizi-accounts/releases/1.2.1 /opt/zizi-accounts/current
sudo systemctl restart zizi-accounts.service
```
Перед установкой сделайте копию базы аккаунтов. Откат: вернуть симлинк `current` и перезапустить сервис.
