package app.ziziplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.OpenCollection
import app.ziziplayer.ui.SearchPresentation
import app.ziziplayer.ui.components.CollectionCoverImage
import app.ziziplayer.ui.components.rememberCollectionCover
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

@Composable
internal fun RemoteCollectionScreen(
    open: OpenCollection, savedIds: Set<String>, currentTrackId: String?, isPlaying: Boolean,
    imported: Boolean, onClose: () -> Unit, onPlay: (Int) -> Unit, onShuffle: () -> Unit,
    onAddCollection: () -> Unit, onRemoveCollection: () -> Unit,
    onSave: (RemoteTrack) -> Unit, onUnsave: (String) -> Unit,
    onRetry: () -> Unit, onLoadMore: () -> Unit
) {
    val p = LocalPalette.current
    val collection = open.collection
    val cover = rememberCollectionCover(url = collection.artworkUrl)
    PinnedCollectionScaffold(
        destination = "remote:${collection.provider}:${collection.kind}:${collection.remoteId}", title = collection.title,
        tint = cover.tint, trackCount = open.tracks.size,
        // This callback always starts from index 0; do not falsely show a Pause action.
        playingHere = false, playEnabled = open.tracks.isNotEmpty(),
        onBack = onClose, onPlay = { onPlay(0) },
        artwork = { CollectionCoverImage(cover, Modifier.fillMaxSize()) },
        hero = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                Text(collection.title, color = Color.White, fontSize = 28.sp, lineHeight = 32.sp,
                    fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (collection.subtitle.isNotBlank()) Text(collection.subtitle, color = Color(0xFFE0E0E0),
                    modifier = Modifier.padding(top = 10.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                val count = if (open.total != null && open.total > open.tracks.size)
                    "Загружено ${open.tracks.size} из ${open.total}" else "Треков: ${open.tracks.size}"
                val minutes = SearchPresentation.durationMinutes(open.tracks.map { it.durationMs },
                    complete = !open.loading && open.nextToken == null && open.error == null)
                Text((if (collection.kind == RemoteKind.ALBUM) "Альбом" else "Плейлист") + " · " + count +
                    (minutes?.let { " · $it мин." } ?: ""), color = Color(0xFFE0E0E0),
                    modifier = Modifier.padding(vertical = 10.dp), fontSize = 14.sp)
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(end = 68.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = if (imported) onRemoveCollection else onAddCollection,
                        enabled = open.tracks.isNotEmpty(), modifier = Modifier.weight(1f)) {
                        Text(if (imported) "Убрать сохранение" else "Сохранить треки", color = p.text)
                    }
                    IconButton(onClick = onShuffle, enabled = open.tracks.isNotEmpty()) {
                        Icon(ZiziIcons.Shuffle, "Перемешать загруженные треки", tint = p.brand)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    ) {
        if (open.loading) item(key = "loading") { LoadingRow("Открываем…") }
        itemsIndexed(open.tracks, key = { index, track -> "$index:${track.trackId}" }) { index, track ->
            ResultTrackRow(track, savedIds.contains(track.trackId), currentTrackId == track.trackId && isPlaying,
                currentTrackId == track.trackId, onPlay = { onPlay(index) }, onSave = { onSave(track) },
                onUnsave = { onUnsave(track.trackId) })
        }
        when {
            open.error != null -> item(key = "error") { ErrorBlock(open.error, onRetry) }
            open.appending -> item(key = "more-loading") { LoadingRow("Загружаем ещё…") }
            open.nextToken != null -> item(key = "more") {
                TextButton(onClick = onLoadMore) { Text("Показать ещё", color = p.brand) }
            }
            !open.loading && open.tracks.isEmpty() -> item(key = "empty") {
                Text("Здесь пока нет доступных треков", color = p.subtext, modifier = Modifier.padding(20.dp))
            }
        }
    }
}
