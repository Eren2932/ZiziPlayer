"""6.69.0 (CI-fix): единая проверка версии для python-контрактов.

До этого фикса шестнадцать тестов проверяли `versionCode = 124` / `versionName = "6.68.0"`
буквальной строкой. Контракт фичи («эта вещь есть начиная с 6.68.0») был перепутан
с контрактом релиза («сейчас собирается ровно 6.68.0»). Итог: бамп до 6.69.0 без
единой правки кода уронил «Самотест проверок» до Gradle.

Теперь каждый тест говорит «не ниже версии, где фича появилась». Бамп версии тесты
не трогает, а откат ниже нижней границы по-прежнему ловится.
"""
import re

_CODE = re.compile(r'^\s*versionCode\s*=\s*([0-9]+)\s*$', re.M)
_NAME = re.compile(r'^\s*versionName\s*=\s*"([0-9]+)\.([0-9]+)\.([0-9]+)([A-Za-z0-9._+-]*)"\s*$', re.M)


def release_identity(gradle_text):
    """(versionCode, (major, minor, patch), versionName) из app/build.gradle.kts."""
    codes = _CODE.findall(gradle_text)
    names = _NAME.findall(gradle_text)
    if len(codes) != 1 or len(names) != 1:
        raise AssertionError(
            f'ожидалось ровно по одному versionCode/versionName, найдено {len(codes)}/{len(names)}')
    major, minor, patch, suffix = names[0]
    name = f'{major}.{minor}.{patch}{suffix}'
    return int(codes[0]), (int(major), int(minor), int(patch)), name


def assert_release_at_least(case, gradle_text, min_code, min_name):
    """Версия сборки не ниже той, в которой появилась проверяемая фича."""
    code, triple, name = release_identity(gradle_text)
    floor = tuple(int(x) for x in min_name.split('.')[:3])
    case.assertGreaterEqual(code, min_code, f'versionCode {code} ниже {min_code}')
    case.assertGreaterEqual(triple, floor, f'versionName {name} ниже {min_name}')
