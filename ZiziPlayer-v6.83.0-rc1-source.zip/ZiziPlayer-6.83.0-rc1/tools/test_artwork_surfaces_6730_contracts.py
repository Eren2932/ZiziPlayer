#!/usr/bin/env python3
"""Source integration contracts. These do not replace Android compilation/rendering."""
from pathlib import Path
import unittest
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(f): return (SRC / f).read_text()

class SurfaceContracts(unittest.TestCase):
    def test_player_uses_cached_primary_and_matching_shadow(self):
        s = read('ui/theme/ZiziTheme.kt')
        self.assertIn('val deepSwatch = swatches.deep.toArgb()', s)
        for token in ['ArtworkSurfaceMath.playerBackdrop(primary, deepSwatch, bodySwatch)',
                      'ArtworkSurfaceMath.miniPlayer(primary, deepSwatch, bodySwatch)',
                      'ArtworkSurfaceMath.chip(primary, deepSwatch, bodySwatch)',
                      'artworkPrimary = swatches.primary']:
            self.assertIn(token, s)
        self.assertIn('surface = Color(ArtworkColorMath.surface(primary))', s)
        self.assertIn('val miniPlayer: Color = surface', s)
        self.assertIn('val miniPlayerSubtext: Color = subtext', s)
    def test_capsule_uses_dedicated_background_and_readable_artist(self):
        s = read('ui/components/MiniPlayerCard.kt')
        self.assertIn('.background(p.miniPlayer)', s)
        self.assertIn('Text(track.artist, color = secondary', s)
        self.assertIn('Color.White.copy(alpha = 0.70f)', s)
        self.assertNotIn('.background(p.surface)', s)
        self.assertIn('ConnectedDeviceAccent', s)  # Stable Zizi brand, not artwork-derived text.
    def test_player_caption_uses_verified_opaque_ink(self):
        s = read('ui/screens/PlayerScreen.kt').split('private fun PlayerHeader(')[1].split('private fun ')[0]
        self.assertIn('color = p.playerHeaderSubtext', s)
        self.assertNotIn('p.subtext.copy(alpha = 0.85f)', s)
        theme = read('ui/theme/ZiziTheme.kt')
        self.assertIn('playerHeaderSubtext = Color(ArtworkSurfaceMath.PLAYER_HEADER_INK)', theme)
        self.assertIn('val playerHeaderSubtext: Color = subtext.copy(alpha = 0.85f)', theme)
    def test_collection_colour_comes_from_its_own_cover(self):
        s = read('ui/components/CollectionCover.kt')
        self.assertIn('art?.swatches?.let { Color(ArtworkSurfaceMath.collectionTop(it.primary.toArgb(), it.body.toArgb())) }', s)
        self.assertNotIn('LocalPalette', s)
        for name in ['ui/screens/CollectionPageScreen.kt','ui/screens/HomeCollectionScreen.kt']:
            self.assertIn('ArtworkSurfaceMath.collectionTop(', read(name))
    def test_no_track_overrides_or_added_io_and_color_cache_version(self):
        s = read('ui/theme/ArtworkSurfaceMath.java')
        for token in ['RAYA', 'PASSO', 'ABNORMAL', 'Bitmap', 'ArtworkCache', 'currentTimeMillis', 'Random']:
            self.assertNotIn(token, s)
        self.assertIn('SWATCH_VERSION = 3', read('ui/theme/ArtworkColorMath.java'))
        self.assertIn('val ZiziBrand = Color(0xFFF97316)', read('ui/theme/ZiziTheme.kt'))
    def test_lyrics_still_uses_original_primary(self):
        s = read('ui/theme/LyricsPalette.kt')
        self.assertIn('LocalPalette.current.artworkPrimary', s)
        self.assertIn('LyricsColorMath.create(primary?.toArgb())', s)
        self.assertNotIn('ArtworkSurfaceMath', s)
    def test_ci_registration(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn("'test_artwork_surfaces_6730.py'", s)
        self.assertIn("'test_artwork_surfaces_6730_contracts.py'", s)
        assert_release_at_least(self, (ROOT / 'app/build.gradle.kts').read_text(), 156, '6.73.0')

if __name__ == '__main__': unittest.main(verbosity=2)
