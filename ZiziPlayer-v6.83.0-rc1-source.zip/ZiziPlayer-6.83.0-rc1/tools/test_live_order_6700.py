#!/usr/bin/env python3
"""Production JVM logic plus source wiring guards; NOT Kotlin or instrumentation execution."""
from pathlib import Path
import subprocess
import tempfile
import unittest

R = Path(__file__).resolve().parents[1]
S = R/'app/src/main/java/app/ziziplayer'

class LiveOrder6700(unittest.TestCase):
    def test_production_live_membership_projection(self):
        with tempfile.TemporaryDirectory() as out:
            sources = [S/'ui/ReorderMath.java', R/'app/src/test/java/app/ziziplayer/ui/LiveOrder6700Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out, *map(str,sources)], check=True)
            subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.LiveOrder6700Checks'], check=True)

    def test_acknowledgement_releases_data_gate_not_only_gesture_lock(self):
        source = (S/'ui/components/TrackReorder.kt').read_text()
        sync = source.split('fun sync(',1)[1].split('fun start(',1)[0]
        self.assertNotIn('else if (!saving)', sync)
        self.assertIn('replace(values)', sync.rsplit('} else {',1)[1])
        self.assertIn('list.firstVisibleItemIndex <= firstRowIndex', sync)
        self.assertIn('!list.isScrollInProgress', sync)
        self.assertIn('newFirst !in indices', sync)
        finish = source.split('fun finish(',1)[1].split('fun accessibilityMove(',1)[0]
        cleanup = finish.rsplit('finally {',1)[1]
        self.assertIn('replace(external)', cleanup)
        self.assertIn('expected = null', cleanup)

    def test_existing_flow_and_sort_reset_remain_live(self):
        source = (S/'ui/MainViewModel.kt').read_text()
        self.assertIn('combine(sources, libraryContext, collectionOrder)', source)
        self.assertIn('ReorderMath.applyOrder(normallySorted.map { it.id }, manualIds)', source)
        self.assertIn('base.asSequence().filter { it.id !in known }.maxByOrNull { it.dateAdded }', source)
        reset = source.split('fun setSortMode(',1)[1].split('fun setLibraryView(',1)[0]
        self.assertIn('repo.clearCollectionOrder(scope)', reset)
        self.assertIn('repo.setSortMode(mode)', reset)

    def test_android_cases_are_in_ci_not_claimed_as_executed_here(self):
        import json,re
        inventory = json.loads((R/'tools/camera_test_inventory.json').read_text())
        for cls in ('TrackReorder6700Test','Profile6700UiTest'):
            source = (R/f'app/src/androidTest/java/app/ziziplayer/ui/{cls}.kt').read_text()
            names = re.findall(r'@Test\s+fun\s+(\w+)', source)
            self.assertGreaterEqual(len(names),4)
            for api in ('28','35'):
                for name in names: self.assertIn(f'app.ziziplayer.ui.{cls}#{name}', inventory[api])
            self.assertIn(f'app.ziziplayer.ui.{cls}', (R/'tools/run_camera_ci.sh').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
