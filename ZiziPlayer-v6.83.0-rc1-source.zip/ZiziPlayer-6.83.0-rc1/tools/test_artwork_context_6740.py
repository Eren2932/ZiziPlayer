#!/usr/bin/env python3
"""Compile/run production colour math; not Kotlin or device validation."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-context-') as out:
    sources = ['app/src/main/java/app/ziziplayer/ui/theme/' + n + '.java' for n in
               ('ArtworkColorMath', 'ArtworkSurfaceMath', 'ArtworkSurfaceSampler')]
    sources += ['app/src/test/java/app/ziziplayer/ui/ArtworkContextMathChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                    '-d', out, *[str(ROOT / p) for p in sources]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.ArtworkContextMathChecks',
                    str(ROOT / 'tools/fixtures/surfaces-6740')], check=True)
