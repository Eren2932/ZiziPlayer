"""Production JVM tests and explicit source contracts. NOT an Android/Compose build."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
UI=ROOT/'app/src/main/java/app/ziziplayer/ui'
CHECK=ROOT/'app/src/test/java/app/ziziplayer/ui/CameraGooey66915Checks.java'

class CameraGooey66915(unittest.TestCase):
    def execute(self, mutation=None):
        source=(UI/'CameraGooeyGeometry.java').read_text()
        if mutation:
            old,new=mutation
            self.assertEqual(source.count(old),1)
            source=source.replace(old,new)
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'CameraGooeyGeometry.java'; p.write_text(source)
            run=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',temp,
                                str(UI/'CameraMorphGeometry.java'),str(p),str(CHECK)],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stderr)
            return subprocess.run(['java','-cp',temp,'app.ziziplayer.ui.CameraGooey66915Checks'],capture_output=True,text=True)
    def test_production_parameters_and_subpixel_reversal(self):
        r=self.execute(); self.assertEqual(r.returncode,0,r.stdout+r.stderr); print(r.stdout,flush=True)
    def test_constant_wide_seed_is_rejected(self):
        r=self.execute(('peak * (1f - Math.abs(2f * progress(p) - 1f))','peak'))
        self.assertNotEqual(r.returncode,0); self.assertIn('No initial protrusion',r.stderr)
    def test_missing_common_threshold_is_rejected(self):
        r=self.execute(('return progress(ALPHA_GAIN * progress(alpha) + ALPHA_OFFSET / 255f);','return progress(alpha);'))
        self.assertNotEqual(r.returncode,0); self.assertIn('Threshold floor',r.stderr)
    def test_wrong_final_size_is_rejected(self):
        r=self.execute(('Math.min(target.width(), target.height())) * .5f;','Math.min(target.width(), target.height()));'))
        self.assertNotEqual(r.returncode,0); self.assertIn('Reference linear size',r.stderr)
    def test_runtime_uses_new_mechanism_and_one_image(self):
        s=(UI/'components/CameraGooeyOverlay.kt').read_text()
        for part in ('Build.VERSION.SDK_INT >= 31 && accelerated',
                     'LegacyCollectionCoverMorphOverlay(', 'G.frame(', 'G.seeds(',
                     'G.ALPHA_GAIN, G.ALPHA_OFFSET', 'artworkGooLayer.renderEffect = gooBlur',
                     'cameraGooLayer.renderEffect = gooBlur', 'CameraMorphDebug.recordGooeyFrame('):
            self.assertIn(part,s)
        route=s.split('private fun CameraGooeyOverlay(',1)[0]
        self.assertNotIn('camera.target != null',route)
        self.assertEqual(s.count('{ artwork() }'),1)
        self.assertEqual(s.count('sourceLayer.record { this@onDrawWithContent.drawContent() }'),1)
        combined=s[s.index('withPaintLayer(bounds, filterPaint) {'):]
        self.assertLess(combined.index('drawLayer(cameraGooLayer)'),combined.index('drawLayer(artworkGooLayer)'))
        # 6.69.17: one kernel, reference clip, no opacity fade of the black goo.
        for banned in ('val cameraBlur', 'cameraGooLayer.renderEffect = cameraBlur', 'target.width()*.35f'):
            self.assertNotIn(banned,s)
        self.assertIn('cameraMorphSafetyPath(widthPx, heightPx, statusPx, target, outline,',s)
        self.assertIn('camera.topAttached, legacy = false, edgePx = edgePx)',s)
        safety=(UI/'components/CollectionCoverMorph.kt').read_text().split('internal fun cameraMorphSafetyPath(',1)[1]
        self.assertIn('if (legacy) status else target?.top ?: status',safety)
        g=(UI/'CameraGooeyGeometry.java').read_text()
        self.assertIn('float alpha = p < 1f ? 1f : 0f;',g)
        self.assertNotIn('smoother((p - .9f) / .1f)',g)
        for banned in ('M.goo(', 'WAIST_', 'REACH_', 'Path.combine', 'Bitmap', 'animateFloat', 'pointerInput(', 'LaunchedEffect'):
            self.assertNotIn(banned,s)
        roi=s.split('val roi = remember(',1)[1].split('val safe = remember(',1)[0]
        for banned in ('f.left', 'f.top', 'f.progress', 'frame.value'):
            self.assertNotIn(banned,roi)
    def test_old_scroll_fix_is_unchanged(self):
        s=(UI/'screens/PinnedCollectionScaffold.kt').read_text()
        self.assertIn('preciseScroll = before.after(consumed.y, index, offset)',s)
        self.assertEqual(s.count('LazyColumn('),1)
        self.assertNotIn('animateScrollBy',s)
    def test_ci_includes_new_checks(self):
        self.assertIn('test_camera_gooey_66915.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraGooey66915UiTest',(ROOT/'tools/run_camera_ci.sh').read_text())

if __name__=='__main__': unittest.main(verbosity=2)
