"""Full-contour regression. Pure JVM and source guards; no Android execution claim."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/ziziplayer/ui'
CHECKS = ROOT / 'app/src/test/java/app/ziziplayer/ui/CameraMorph66913Checks.java'

class CameraContour66913(unittest.TestCase):
    def run_geometry(self, source):
        with tempfile.TemporaryDirectory() as tmp:
            local = Path(tmp) / 'CameraMorphGeometry.java'
            local.write_text(source)
            result = subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', tmp,
                                     str(local), str(CHECKS)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            return subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.ui.CameraMorph66913Checks'],
                                  capture_output=True, text=True)

    def test_production_contour(self):
        result = self.run_geometry((UI/'CameraMorphGeometry.java').read_text())
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        print(result.stdout, flush=True)

    def test_old_shoulder_rotation_rejected(self):
        source = (UI/'CameraMorphGeometry.java').read_text()
        source = source.replace('double h2 = k*Math.max(a - half, 0);', '''double psi = Math.PI*.5*smooth((float)(w/(.5*U)));
        double sin = Math.sin(psi), cos = Math.cos(psi);
        double h2 = (1-sin)*k*Math.max(a-half,0)+sin*.5*k*sw;''')
        source = source.replace('double h3 = Math.min(.20*len, U);',
                                'double h3 = (1-sin)*Math.min(.20*len,U)+sin*.45*(qs-sw);')
        source = source.replace('sw,-half-h2, sw,-half', 'sw-h2*sin,-half-h2*cos, sw,-half')
        source = source.replace('sw,-half-h3, qs-h4', 'sw+h3*sin,-half-h3*cos, qs-h4')
        result = self.run_geometry(source)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('shoulder retracts', result.stderr)

    def test_fast_fillet_rejected(self):
        source = (UI/'CameraMorphGeometry.java').read_text()
        self.assertEqual(source.count('w / (2 * U)'), 1)
        result = self.run_geometry(source.replace('w / (2 * U)', 'w / (.5 * U)'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('full contour amplifies scroll', result.stderr)

    def test_duplicate_artwork_boundary_rejected(self):
        source = (UI/'CameraMorphGeometry.java').read_text()
        self.assertEqual(source.count('true, path, extension,'), 1)
        result = self.run_geometry(source.replace('true, path, extension,', 'true, path, path,'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('extension duplicates', result.stderr)

    def test_wiring(self):
        self.assertIn('test_camera_contour_66913.py', (ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraMorph66913Checks.main',
                      (ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph66913Test.java').read_text())
        ui = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        for name in ('centralContactHoldAndMicroReversal66913', 'cornerContactHoldAndMicroReversal66913'):
            self.assertIn(name, ui)
            self.assertEqual((ROOT/'tools/camera_test_inventory.json').read_text().count(name), 2)
        renderer=(UI/'components/CollectionCoverMorph.kt').read_text()
        self.assertIn('!g.joined && g.ink != null', renderer)
        self.assertEqual(renderer.count('{ artwork() }'), 1)

if __name__ == '__main__':
    unittest.main(verbosity=2)
