"""Production JVM + source wiring, NOT GPU/device validation."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT/'app/src/main/java/app/ziziplayer/ui'
CHECK = ROOT/'app/src/test/java/app/ziziplayer/ui/CameraAnchor66916Checks.java'

class CameraAnchor66916(unittest.TestCase):
    def execute(self, mutation=False):
        source = (UI/'CameraGooeyGeometry.java').read_text()
        if mutation:
            old = 'public static float cameraBlurRadius(CameraMorphGeometry.Target target) { return BLUR_RADIUS; }'
            self.assertEqual(source.count(old), 1)
            source = source.replace(old, 'public static float cameraBlurRadius(CameraMorphGeometry.Target target) {'
                ' return target == null ? BLUR_RADIUS : Math.min(BLUR_RADIUS, Math.min(target.width(), target.height()) / (4f * GOO_SCALE)); }')
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)/'CameraGooeyGeometry.java'; p.write_text(source)
            compile = subprocess.run(['java','com.sun.tools.javac.Main','-d',temp,
                str(UI/'CameraMorphGeometry.java'),str(p),str(CHECK)],capture_output=True,text=True)
            self.assertEqual(compile.returncode,0,compile.stderr)
            return subprocess.run(['java','-cp',temp,'app.ziziplayer.ui.CameraAnchor66916Checks'],
                capture_output=True,text=True)

    def test_production(self):
        result = self.execute()
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        print(result.stdout,flush=True)

    def test_old_erasing_kernel_is_rejected(self):
        result = self.execute(mutation=True)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('One kernel for both lobes',result.stderr)

    def test_renderer_uses_one_reference_kernel_for_both_lobes(self):
        # 6.69.17: reference ProfileGooeyView sets the SAME intensity on both RenderNodes.
        s = (UI/'components/CameraGooeyOverlay.kt').read_text()
        self.assertIn('artworkGooLayer.renderEffect = gooBlur',s)
        self.assertIn('cameraGooLayer.renderEffect = gooBlur',s)
        self.assertNotIn('val cameraBlur',s)
        self.assertNotIn('cameraGooLayer.renderEffect = cameraBlur',s)
        self.assertIn('else G.BLUR_RADIUS',s)
        self.assertIn('seeds?.protrusion ?: 0f, gooRadius)',s)
        self.assertIn('cameraBlur=$cameraBlur',(UI/'components/CameraCutout.kt').read_text())

    def test_no_screenshot_calibration_in_production(self):
        s = (UI/'CameraMorphGeometry.java').read_text()
        self.assertIn('float diameter = w;',s)
        self.assertIn('float bottom = bounds.bottom;',s)
        self.assertNotIn('float diameter = .60f * w;',s)
        self.assertNotIn('float bottom = bounds.bottom - .05f * w;',s)

    def test_wired_into_selftest(self):
        self.assertIn('test_camera_anchor_66916.py',(ROOT/'tools/check_selftest.py').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
