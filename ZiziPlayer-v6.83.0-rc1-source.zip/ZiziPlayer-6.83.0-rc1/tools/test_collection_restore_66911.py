"""JVM production math + source wiring, not a substitute for Android restoration tests."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
UI=ROOT/'app/src/main/java/app/ziziplayer/ui'
class Restore66911(unittest.TestCase):
    def run_math(self, mutate=False):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'CollectionCollapseMath.java'
            s=(UI/'CollectionCollapseMath.java').read_text()
            if mutate:
                self.assertEqual(s.count('return Math.max(hero, travel);'),1)
                s=s.replace('return Math.max(hero, travel);','return hero;')
            p.write_text(s)
            c=subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,str(p),str(UI/'CollectionGeometry.java'),str(UI/'CameraMorphGeometry.java'),str(ROOT/'app/src/test/java/app/ziziplayer/ui/CollectionRestore66911Checks.java')],capture_output=True,text=True)
            self.assertEqual(c.returncode,0,c.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CollectionRestore66911Checks'],capture_output=True,text=True)
    def test_restoration_math(self):
        run=self.run_math();self.assertEqual(run.returncode,0,run.stderr);print(run.stdout)
    def test_original_unmeasured_hero_bug_is_rejected(self):
        run=self.run_math(True);self.assertNotEqual(run.returncode,0);self.assertIn('AssertionError',run.stderr)
    def test_shared_header_uses_safe_progress_without_pixel_persistence(self):
        s=(UI/'screens/PinnedCollectionScaffold.kt').read_text()
        for part in ['preciseScroll.visualScroll(list.firstVisibleItemIndex,','list.firstVisibleItemScrollOffset, heroPx.toFloat(), morphTravelPx)',
                     'if (list.firstVisibleItemIndex > 0) 1f','heroPx > 0 || list.firstVisibleItemIndex > 0',
                     'enabled = playEnabled && headerReady','alpha = if (headerReady) 1f else 0f']:
            self.assertIn(part,s)
        self.assertNotIn('else heroPx.toFloat()',s)
    def test_body_uses_direct_content_and_preserves_single_shading(self):
        s=(UI/'components/CollectionCoverMorph.kt').read_text()
        # Exactly one mirrored callsite: inside the reflected extension transform.
        self.assertEqual(s.count('this@onDrawWithContent.drawMirroredLayer(sourceLayer)'),1)
        body=s.split('clipPath(silhouette) {',1)[1].split('// Shade the UNION',1)[0]
        self.assertEqual(body.count('drawLayer(sourceLayer)'),2)
        self.assertIn('cameraMorphSilhouette(body, flesh)',s)
        self.assertEqual(s.count('alpha = bodyBlack)'),1)
        a=(ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        self.assertIn('(1f - bodyInk) * (1f - neckInk)',a)
        self.assertIn('expected, body.red, .025f',a)
        self.assertNotIn('@Ignore',a)
    def test_real_android_navigation_regressions_are_wired(self):
        s=(ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        for text in ['rememberSaveableStateHolder()', 'SaveableStateProvider("test:collection")',
                     'collectionVisible.value = false', 'collectionVisible.value = true',
                     'centralCameraCoverStaysHiddenAfterNavigation66911', 'cornerCameraCoverStaysHiddenAfterNavigation66911',
                     'noCameraCoverStaysHiddenAfterNavigation66911','Hidden cover must not reappear after navigation']:
            self.assertIn(text,s)
    def test_apk_has_no_emulator_dependency_and_manual_tests_remain_strict(self):
        s=(ROOT/'.github/workflows/build.yml').read_text()
        camera=s.split('  camera-regression:',1)[1].split('  build:',1)[0]
        build=s.split('\n  build:',1)[1]
        self.assertIn("if: github.event_name == 'workflow_dispatch' && inputs.run_camera_tests",camera)
        self.assertIn('default: false',s.split('run_camera_tests:',1)[1].split('  push:',1)[0])
        self.assertNotIn('needs:',build)
        for absent in ['android-emulator-runner@',':app:assembleDebugAndroidTest',':app:compileDebugAndroidTestKotlin','secrets.SIGNING']:
            if absent=='secrets.SIGNING': self.assertNotIn(absent,camera)
            else: self.assertNotIn(absent,build)
        for present in [':app:testDebugUnitTest',':app:assembleRelease','name: Verify signature','tools/check_selftest.py']:
            self.assertIn(present,build)
        self.assertIn('script: bash tools/run_camera_ci.sh 28',camera)
        self.assertIn('script: bash tools/run_camera_ci.sh 35',camera)
        self.assertNotIn('continue-on-error:',s)
        self.assertEqual(s,(ROOT/'repo-update/.github/workflows/build.yml').read_text())
    def test_selftest_wiring(self):
        self.assertIn('test_collection_restore_66911.py',(ROOT/'tools/check_selftest.py').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
