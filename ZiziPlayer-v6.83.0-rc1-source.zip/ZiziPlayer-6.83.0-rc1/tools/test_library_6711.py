"""6.71.1 source/wiring contracts. Not Android compilation, pixel checks or animation execution."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
CONTROLS = (SRC / 'ui/screens/LibraryControls.kt').read_text()
SCREEN = (SRC / 'ui/screens/LibraryScreen.kt').read_text()
VM = (SRC / 'ui/MainViewModel.kt').read_text()

class Library6711(unittest.TestCase):
    def test_search_has_no_back_arrow_or_close_callback(self):
        search = CONTROLS.split('internal fun LibrarySearchBlock(')[1]
        self.assertNotIn('ArrowBack', search)
        self.assertNotIn('onClose', search)
        self.assertIn('"Очистить поиск"', search)
        self.assertIn('if (searchOpen) "Закрыть поиск" else "Поиск по медиатеке"', CONTROLS)
        self.assertIn('onSearch = { vm.setSearchOpen(!state.searchOpen) }', SCREEN)
    def test_search_keeps_root_back_and_late_query_guard(self):
        self.assertIn('state.searchOpen -> { setSearchOpen(false); true }', VM)
        self.assertIn('if (it.searchOpen) it.copy(query = query) else it', VM)
        self.assertIn('if (!open) return@LaunchedEffect', CONTROLS)
    def test_legacy_long_press_picker_is_gone(self):
        self.assertNotIn('combinedClickable', CONTROLS)
        self.assertNotIn('onLongClick', CONTROLS)
        self.assertIn('onClick = { onView(view.next()) }', CONTROLS)
        for name in ['setLibraryViewExpanded', 'viewExpanded']:
            for s in [CONTROLS, SCREEN, VM, (SRC/'ui/LibraryPanelState.kt').read_text()]:
                self.assertNotIn(name, s)
    def test_plus_uses_one_vector_and_continuous_rotation(self):
        self.assertIn('if (addExpanded) 135f else 0f', CONTROLS)
        self.assertIn('Icon(ZiziIcons.Plus, null, tint = addTint', CONTROLS)
        self.assertIn('graphicsLayer { rotationZ = addRotation }', CONTROLS)
        self.assertIn('tween(LIBRARY_ADD_MS, easing = FastOutSlowInEasing)', CONTROLS)
        self.assertNotIn('if (addExpanded) ZiziIcons.Close', CONTROLS)
    def test_banner_is_compact_but_not_fixed_height(self):
        banner = CONTROLS.split('private fun LibraryAddAction(')[1].split('/** The four silhouettes')[0]
        for text in ['heightIn(min = 64.dp)', 'RoundedCornerShape(10.dp)', 'Text(title',
                     'Text(subtitle', '.clickable(enabled = enabled, role = Role.Button']:
            self.assertIn(text, banner)
        self.assertNotIn('.height(', banner)
        self.assertNotIn('height(82.dp)', SCREEN)
        self.assertIn('LibraryAddPanel(enabled = addExpanded', SCREEN)
    def test_import_transition_uses_same_duration_as_rotation(self):
        self.assertIn('internal const val LIBRARY_ADD_MS = 260', CONTROLS)
        self.assertIn('expandVertically(tween(LIBRARY_ADD_MS', SCREEN)
        self.assertIn('shrinkVertically(tween(LIBRARY_ADD_MS', SCREEN)
        self.assertIn('onImport = { if (vm.consumeLibraryAddAction()) importSource = true }', SCREEN)
    def test_shuffle_reads_mode_but_starts_a_new_queue(self):
        self.assertIn('shuffle = playback.shuffle', SCREEN)
        self.assertIn('shuffleEnabled = !state.loading && state.tracks.any { !gate.blocks(it) }', SCREEN)
        self.assertIn('onShuffle = vm::shuffleLibrary', SCREEN)
        self.assertNotIn('vm.shuffleAll()', SCREEN)
        self.assertIn('fun toggleShuffle() = player.toggleShuffle()', VM)
        player = (SRC/'playback/PlayerController.kt').read_text()
        self.assertIn('shuffle = p.shuffleModeEnabled', player)
        self.assertIn('it.shuffleModeEnabled = !it.shuffleModeEnabled', player)
    def test_shuffle_indicator_is_orange_dot_and_accessible(self):
        self.assertIn('if (shuffle) p.brand', CONTROLS)
        self.assertIn('selected = shuffle', CONTROLS)
        self.assertIn('stateDescription = if (shuffle) "Случайный порядок включён" else "Случайный порядок выключен"', CONTROLS)
        self.assertIn('AnimatedVisibility(shuffle,', CONTROLS)
        self.assertIn('Modifier.size(3.dp).clip(CircleShape).background(p.brand)', CONTROLS)
        self.assertIn('.clickable(enabled = shuffleEnabled', CONTROLS)
    def test_existing_interactions_not_removed(self):
        for text in ['CustomAccessibilityAction("Действия")', 'folderMenu = folderSelection.first()',
                     'pickPlaylistFile.launch(arrayOf("*/*"))', 'AccountAvatar(',
                     'LocalBottomChromeInset.current + 20.dp']:
            self.assertIn(text, SCREEN)
    def test_tests_are_connected_and_gestures_are_covered(self):
        self.assertIn('test_library_6711.py', (ROOT/'tools/check_selftest.py').read_text())
        ui = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/Library6710UiTest.kt').read_text()
        for name in ['noLongClickAction', 'tapCycles', 'shuffleFollowsExternalPlayerState',
                     'emptyLibraryCannotStartShuffle', 'rapidPlusTapsSettleOnLatestState',
                     'addPanelSupportsLargeTextAndSeparateActions']:
            self.assertIn(name, ui)

if __name__ == '__main__': unittest.main(verbosity=2)
