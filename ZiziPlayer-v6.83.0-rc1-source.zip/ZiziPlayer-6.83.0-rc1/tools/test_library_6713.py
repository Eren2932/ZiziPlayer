"""6.71.3 source contracts and production Java geometry; NOT Android rendering."""
from pathlib import Path
import re
import subprocess
import tempfile
import unittest
from release_identity import assert_release_at_least

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()
THEME = read('ui/theme/ZiziTheme.kt')
LIB = read('ui/screens/LibraryScreen.kt')
CONTROLS = read('ui/screens/LibraryControls.kt')
SHEETS = read('ui/screens/Sheets.kt')

class Library6713(unittest.TestCase):
    def test_neutral_scope_controls_both_palette_and_material_defaults(self):
        scope = THEME.split('internal fun NeutralSurfaceTheme(')[1].split('/* ---')[0]
        self.assertIn('val neutral = basePalette()', scope)
        self.assertIn('CompositionLocalProvider(LocalPalette provides neutral)', scope)
        self.assertIn('ZiziTheme(neutral, content)', scope)
        self.assertNotIn('tintedWith(', scope)
        self.assertNotIn('withAccent(', scope)
    def test_library_root_scoped_without_changing_detail_or_player(self):
        before, after = LIB.split('} else NeutralSurfaceTheme {', 1)
        self.assertIn('LocalCollectionScreen(', before)
        root = after.split('/* ---------------------------------------------------------------------- 6.29.0 ---- */')[0]
        for node in ['LibraryHeader(', 'LibrarySearchBlock(', 'LibraryToolbar(', 'CollectionSurface(']:
            self.assertIn(node, root)
        for name in ['MainActivity.kt', 'ui/screens/PlayerScreen.kt']:
            player = read(name)
            self.assertIn('basePalette().tintedWith(swatches).withAccent(swatches)', player)
            self.assertNotIn('NeutralSurfaceTheme', player)
    def test_all_modal_sheets_have_own_neutral_boundary(self):
        scaffold = SHEETS.split('internal fun ZiziSheetScaffold(')[1].split('/**\n * Строка «Скачать»')[0]
        self.assertIn(') = NeutralSurfaceTheme {', scaffold)
        self.assertIn('containerColor = ZiziModalSurface', scaffold)
        self.assertIn('contentColor = p.text', scaffold)
        for node in ['fun TrackInfoSheet(', 'fun FolderMenuSheet(', 'fun SleepSheet(']:
            body = SHEETS.split(node)[1].split('\n@Composable')[0]
            self.assertIn('ZiziSheetScaffold(', body)
    def test_captured_palette_and_dialogs_scoped_at_the_caller(self):
        for name in ['FxSheet', 'PlaylistPickerSheet', 'QueueSheet', 'ConfirmDialog', 'RenameDialog']:
            body = SHEETS.split('fun '+name+'(')[1].split('\n@Composable')[0]
            self.assertLess(body.index(') = NeutralSurfaceTheme {'), body.index('val p = LocalPalette.current'))
        for file,names in [('PlaylistActionsHost.kt',['PlaylistActionsHost']),
                           ('PlaylistShareSheets.kt',['PlaylistShareSheet','PlaylistImportSheet','PastePlaylistDialog'])]:
            source = read('ui/screens/'+file)
            for name in names:
                body = source.split('fun '+name+'(')[1].split('\n@Composable')[0]
                self.assertLess(body.index(') = NeutralSurfaceTheme {'), body.index('val p = LocalPalette.current'))
        self.assertIn('return@NeutralSurfaceTheme', read('ui/screens/PlaylistActionsHost.kt'))
    def test_shortcuts_keep_only_covers_colored(self):
        shortcut = LIB.split('private fun LibraryShortcut(')[1].split('\n/**')[0]
        self.assertIn('.background(p.chip)', shortcut)
        self.assertIn('LibraryCardCover(card, height, shortcut = true)', shortcut)
        for removed in ['favoritesSurface', 'tracksSurface']:
            self.assertNotIn(removed, CONTROLS+LIB)
        for color in ['0xFF7653C1','0xFF33205D','0xFF13777B','0xFF103B48']:
            self.assertIn(color, CONTROLS)
        for cover in ['favoritesTop', 'favoritesBottom', 'tracksTop', 'tracksBottom']:
            self.assertIn('LibraryShortcutColors.'+cover, LIB)
    def test_search_has_card_aligned_outer_padding_not_just_inner_padding(self):
        search = CONTROLS.split('internal fun LibrarySearchBlock(')[1]
        self.assertIn('LibraryGeometry.edge(maxWidth.value).dp', search)
        self.assertIn('.padding(start = edge, end = edge, bottom = 10.dp)', search)
        self.assertLess(search.index('.padding(start = edge'), search.index('.clip(RoundedCornerShape'))
        self.assertIn('.heightIn(min = 52.dp)', search)
        self.assertIn('Modifier.weight(1f).focusRequester(requester)', search)
        self.assertIn('enabled = open, singleLine = true', search)
        self.assertIn('if (text.isNotEmpty()) LibraryToolButton', search)
    def test_neutral_palette_contrast(self):
        base = THEME.split('private val Amoled = themePalette(')[1].split('/** One neutral')[0]
        colors = {k:int(v,16) for k,v in re.findall(r'(surface|chip|text|subtext) = Color\(0xFF([0-9A-F]{6})\)',base)}
        self.assertEqual(set(colors), {'surface','chip','text','subtext'})
        def rgb(v): return [(v>>b)&255 for b in (16,8,0)]
        def lum(v):
            def linear(x):
                x /= 255
                return x/12.92 if x <= .04045 else ((x+.055)/1.055)**2.4
            return sum(w*linear(x) for w,x in zip((.2126,.7152,.0722),rgb(v)))
        for background in ['surface','chip']:
            r,g,b = rgb(colors[background]);self.assertEqual(r,g);self.assertEqual(g,b)
            for ink in ['text','subtext']:
                self.assertGreaterEqual((lum(colors[ink])+.05)/(lum(colors[background])+.05),4.5)
    def test_production_search_geometry(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,
                str(SRC/'ui/LibraryGeometry.java'),
                str(ROOT/'app/src/test/java/app/ziziplayer/ui/LibraryNeutral6713Checks.java')],capture_output=True,text=True)
            self.assertEqual(0,result.returncode,result.stderr)
            result = subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.LibraryNeutral6713Checks'],capture_output=True,text=True)
            self.assertEqual(0,result.returncode,result.stderr)
            print(result.stdout.strip())
    def test_release_and_regressions_are_registered(self):
        assert_release_at_least(self,(ROOT/'app/build.gradle.kts').read_text(),154,'6.71.3')
        self.assertIn("'test_library_6713.py'",(ROOT/'tools/check_selftest.py').read_text())
        tests = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/LibraryNeutral6713UiTest.kt').read_text()
        for name in ['neutralScopeIgnoresCoverAndRestoresPlayerTheme', 'sheetHasNeutralContentAndMaterialColors',
                     'searchInsetsMatchCardGeometryWithLargeText']:
            self.assertIn(name, tests)

if __name__ == '__main__': unittest.main(verbosity=2)
