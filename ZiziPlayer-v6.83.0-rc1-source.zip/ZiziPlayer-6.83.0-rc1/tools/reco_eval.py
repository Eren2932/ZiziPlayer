#!/usr/bin/env python3
"""Artist-level holdout evaluation, offline. Not a measurement of satisfaction.

Input: {"cases":[{"train_artist_ids":["1"],"heldout_artist_ids":["2","3"],
                  "recommended_artist_ids":["4","2","5"],"expected_artist_ids":["2"]}]}
The ranked IDs must be generated using TRAIN ONLY (weights and hints too).
For a track ranking pass the artist of each track in the same order; repeats consume slots.
Hidden artists cannot also be in train. Do not hand a full profile to a server then hide IDs here.
We report artist Recall@K and NDCG@K, coverage, and missing-case counts, no user identifiers.
"""
import argparse
import json
import math
from pathlib import Path


def ids(value):
    if not isinstance(value,list): raise ValueError('artist IDs must be lists')
    if any(not isinstance(v,str) or not v.isascii() or not v.isdigit() or len(v)>12 for v in value):
        raise ValueError('IDs must be decimal strings of at most 12 digits')
    return value


def evaluate(cases,k=50):
    if not isinstance(cases,list) or k<=0: raise ValueError('cases must be a list and K positive')
    recalls,ndcgs,hits_all=[],[],0
    total_targets,empty,unique_targets,covered=0,0,set(),set()
    for c in cases:
        train=set(ids(c.get('train_artist_ids',[])))
        targets=set(ids(c.get('heldout_artist_ids',[])))
        if train & targets: raise ValueError('train/heldout overlap: evaluation leakage')
        rank=ids(c.get('recommended_artist_ids',[]))[:k]
        if not targets: empty+=1; continue
        seen=set();dcg=0.0
        for pos,aid in enumerate(rank,1):
            if aid in targets and aid not in seen: dcg+=1/math.log2(pos+1)
            seen.add(aid)
        hits=set(rank)&targets
        ideal=sum(1/math.log2(i+1) for i in range(1,min(k,len(targets))+1))
        recalls.append(len(hits)/len(targets));ndcgs.append(dcg/ideal)
        hits_all+=len(hits);total_targets+=len(targets)
        unique_targets|=targets;covered|=hits
    return {'k':k,'level':'artist','evaluated_cases':len(recalls),'empty_target_cases':empty,
            'recall_macro':sum(recalls)/len(recalls) if recalls else None,
            'recall_micro':hits_all/total_targets if total_targets else None,
            'ndcg_macro':sum(ndcgs)/len(ndcgs) if ndcgs else None,
            'heldout_artist_coverage':len(covered)/len(unique_targets) if unique_targets else None,
            'note':'Offline holdout, not user satisfaction. Profiles must be recomputed without heldout events.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path);p.add_argument('--k',default=50,type=int)
    args=p.parse_args()
    try:
        obj=json.loads(args.input.read_text(encoding='utf-8'))
        print(json.dumps(evaluate(obj['cases'],args.k),ensure_ascii=False,indent=2))
    except (ValueError,KeyError,TypeError) as e: p.error(str(e))

if __name__=='__main__':main()
