#!/usr/bin/env python3
"""Real production Java + source contracts. NOT Kotlin compilation or device execution."""
from pathlib import Path
import json
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'

def read(name): return (SRC/name).read_text()

class PlayerCorners6704(unittest.TestCase):
    def execute(self, mutation=None):
        source=read('ui/PlayerSheetGeometry.java')
        if mutation:
            old,new=mutation
            self.assertEqual(source.count(old),1)
            source=source.replace(old,new)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'PlayerSheetGeometry.java';path.write_text(source)
            compile=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',tmp,
                str(path),str(ROOT/'app/src/test/java/app/ziziplayer/ui/PlayerSheet6704Checks.java')],
                capture_output=True,text=True)
            self.assertEqual(compile.returncode,0,compile.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.PlayerSheet6704Checks'],capture_output=True,text=True)

    def test_real_java_geometry(self):
        result=self.execute();self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        print(result.stdout,flush=True)

    def test_linear_motion_mirrored_corners_and_missing_fit_are_rejected(self):
        for mutation in [('t * t * (3.0 - 2.0 * t)', 't'),
                         ('this.topLeft = positive(topLeft);','this.topLeft = positive(topRight);'),
                         ('Corners c = fit(target, width, height);','Corners c = target;')]:
            with self.subTest(mutation=mutation):
                result=self.execute(mutation)
                self.assertNotEqual(result.returncode,0,'Broken geometry escaped the checks')
                self.assertIn('AssertionError',result.stderr)

    def test_framework_api_gated_and_all_physical_corners_independent(self):
        s=read('ui/components/PlayerSheetCorners.kt')
        self.assertIn('if (Build.VERSION.SDK_INT >= 31)',s)
        self.assertIn('@RequiresApi(31)',s)
        for name in ['TOP_LEFT','TOP_RIGHT','BOTTOM_RIGHT','BOTTOM_LEFT']:
            self.assertIn('getRoundedCorner(RoundedCorner.POSITION_'+name+')?.radius?.toFloat() ?: 0f',s)
        for forbidden in ['getIdentifier(', 'getDeclared', 'Build.MODEL', 'displayCutout', 'statusBars', '.toPx()']:
            self.assertNotIn(forbidden,s)
        self.assertIn('else PlayerSheetGeometry.legacy(density)',s)

    def test_observer_does_not_replace_compose_insets_and_is_disposed(self):
        s=read('ui/components/PlayerSheetCorners.kt')
        self.assertNotIn('setOnApplyWindowInsetsListener(',s)
        self.assertNotIn('consumeSystemWindowInsets(',s)
        for text in ['OnPreDrawListener', 'removeOnPreDrawListener(listener)', 'onDispose',
                     'LocalConfiguration.current', 'root.width != previousWidth', 'rotation != previousRotation',
                     'insets != previousInsets']:
            self.assertIn(text,s)

    def test_whole_player_is_clipped_using_the_actual_shared_offset(self):
        s=read('MainActivity.kt');host=s.rsplit('if (mounted) {',1)[1].split('// Only the full player',1)[0]
        self.assertIn('val playerCorners = rememberPlayerSheetCorners()',host)
        self.assertIn('.playerSheetSurface(playerCorners) { slide.value + dragOffset }',host)
        self.assertLess(host.index('.playerSheetSurface('),host.index('ZiziBackdrop(palette)'))
        self.assertLess(host.index('ZiziBackdrop(palette)'),host.index('PlayerScreen('))
        self.assertIn('.nestedScroll(sheetScroll)',host)
        self.assertIn('.surfaceInputBoundary()',host)
        surface=read('ui/components/PlayerSheetSurface.kt')
        for text in ['val offset = offsetY()', 'translationY = offset', 'PlayerSheetShape(corners.value, offset)', 'clip = true']:
            self.assertIn(text,surface)
        for forbidden in ['animate', 'Animatable', 'delay(', '.blur(', 'RenderEffect']:
            self.assertNotIn(forbidden,surface)
        self.assertIn('topLeftCornerRadius = CornerRadius(c.topLeft)',surface)
        self.assertNotIn('LayoutDirection.Rtl',surface)

    def test_connected_preflight_unit_and_device_checks(self):
        self.assertIn('test_player_corners_6704.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('PlayerSheet6704Checks.runAll()', (ROOT/'app/src/test/java/app/ziziplayer/ui/PlayerSheet6704Test.java').read_text())
        inventory=json.loads((ROOT/'tools/camera_test_inventory.json').read_text())
        for api in ['28','35']:
            self.assertIn('app.ziziplayer.ui.PlayerSheet6704UiTest#movingLayerClipsBackdropAndChildrenAndRestoresFullscreen',inventory[api])
        self.assertIn('app.ziziplayer.ui.PlayerSheetInsets6704Test#readsFourIndependentFrameworkPixelRadii',inventory['35'])
        self.assertIn('PlayerSheet6704UiTest', (ROOT/'tools/run_camera_ci.sh').read_text())
        self.assertIn('PlayerSheetInsets6704Test', (ROOT/'tools/run_camera_ci.sh').read_text())
        from release_identity import assert_release_at_least
        assert_release_at_least(self,(ROOT/'app/build.gradle.kts').read_text(),150,'6.70.4')

if __name__ == '__main__': unittest.main(verbosity=2)
