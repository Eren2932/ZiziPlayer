"""6.70.3 compatibility guards. Android adapter regressions run in connected CI only."""
from pathlib import Path
import hashlib
import re
import unittest
ROOT = Path(__file__).resolve().parents[1]
UI = ROOT/'app/src/main/java/app/ziziplayer/ui'
LEGACY_HASHES = {'CameraMorphGeometry.java': '6793ad42b33826cb5aa22c8a26c11f42b77afa55c6ba4476bda1bec6f23ea33b', 'CameraGooeyGeometry.java': '6ebd568da6f1ba4dd109845385df7e82755f7eb2d393996e4467d36de4143560'}

def assert_legacy_order(test, source):
    call = 'val holeEstimate = CameraMorphGeometry.compactTopEstimate(raw,'
    test.assertIn(call, source, 'OEM Path presence must not disable the legacy reservation fallback')
    test.assertLess(source.index('if (!CameraMorphGeometry.supported('), source.index(call))
    test.assertLess(source.index(call), source.index('CameraNotchGeometry.anchor('))
    branch = source.split('if (holeEstimate != null) {', 1)[1].split('} else {', 1)[0]
    for statement in ['target = holeEstimate', 'box.set(target.left, target.top, target.right, target.bottom)',
                      'exact = false', 'estimated = true']:
        test.assertIn(statement, branch)
    test.assertNotIn('topAttached = true', branch)

class CameraCompatibility6703(unittest.TestCase):
    def test_legacy_classification_precedes_notch_for_exact_and_rect_only(self):
        assert_legacy_order(self, (UI/'components/CameraCutout.kt').read_text())

    def test_old_6702_regression_is_rejected(self):
        source = (UI/'components/CameraCutout.kt').read_text()
        mutant = source.replace('val holeEstimate = CameraMorphGeometry.compactTopEstimate(raw,',
                                'val holeEstimate = if (!exact) CameraMorphGeometry.compactTopEstimate(raw,')
        with self.assertRaises(AssertionError):
            assert_legacy_order(self, mutant)

    def test_existing_motion_and_seed_math_are_identical_to_6701(self):
        for name, digest in LEGACY_HASHES.items():
            self.assertEqual(hashlib.sha256((UI/name).read_bytes()).hexdigest(), digest, name)

    def test_notch_blur_and_clip_are_not_used_for_legacy_holes(self):
        gpu = (UI/'components/CameraGooeyOverlay.kt').read_text()
        self.assertRegex(gpu, r'if \(camera.topAttached && target != null\)\s*CameraNotchGeometry.blurRadius\(density.density\) else G.BLUR_RADIUS')
        helper = (UI/'components/CollectionCoverMorph.kt').read_text().split('internal fun cameraMorphSafetyPath(',1)[1]
        self.assertIn('if (topAttached && target != null && outline != null)', helper)
        self.assertIn('if (legacy) status else target?.top ?: status', helper)

    def test_device_regressions_are_in_ci_and_not_claimed_as_local_execution(self):
        import json
        inventory = json.loads((ROOT/'tools/camera_test_inventory.json').read_text())
        for method in ['exactTallReservationRetainsHoleMode6703',
                       'unsupportedExactDetachedPathRetainsHoleFallback6703']:
            self.assertIn('app.ziziplayer.ui.CameraNotch6702Test#'+method, inventory['35'])
        self.assertIn('test_camera_compat_6703.py', (ROOT/'tools/check_selftest.py').read_text())
        from release_identity import assert_release_at_least
        assert_release_at_least(self, (ROOT/'app/build.gradle.kts').read_text(), 149, '6.70.3')

if __name__ == '__main__': unittest.main(verbosity=2)
