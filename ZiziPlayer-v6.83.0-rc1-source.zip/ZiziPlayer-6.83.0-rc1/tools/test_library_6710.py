"""Actual Java geometry + source contracts. Does not claim Kotlin compilation or UI execution."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()

class Library6710(unittest.TestCase):
    def test_production_geometry(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', tmp,
                str(SRC/'ui/LibraryGeometry.java'), str(ROOT/'app/src/test/java/app/ziziplayer/ui/LibraryGeometry6710Checks.java')], capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            result = subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.ui.LibraryGeometry6710Checks'], capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            print(result.stdout.strip())
    def test_back_stays_with_root_owner(self):
        ui = read('ui/screens/LibraryScreen.kt')
        vm = read('ui/MainViewModel.kt')
        self.assertNotIn('BackHandler(', ui)
        self.assertIn('vm.libraryPanels.collectAsStateWithLifecycle()', ui)
        back = vm.split('fun handleBack(): Boolean')[1].split('// ---------------- playback')[0]
        self.assertLess(back.index('state.searchOpen'), back.index('_libraryPanels.value.isOpen'))
        self.assertLess(back.index('_libraryPanels.value.isOpen'), back.index('state.openPlaylist != null'))
        self.assertIn('_libraryPanels.update { it.dismissTop() }', back)
    def test_legacy_names_persist_without_ordinal_migration(self):
        s = read('data/SettingsStore.kt')
        self.assertIn('enum class LibraryView { GRID, LIST, COMPACT, LARGE_GRID;', s)
        self.assertIn('it[libraryViewKey] = value.name', s)
        self.assertIn('LibraryView.valueOf(p[libraryViewKey]', s)
    def test_one_grid_with_stable_item_keys_for_all_modes(self):
        s = read('ui/screens/LibraryScreen.kt').split('private fun CollectionSurface(')[1].split('private fun LibraryShortcut(')[0]
        self.assertEqual(1, s.count('LazyVerticalGrid('))
        self.assertIn('columns = GridCells.Fixed(view.columns), state = gridState', s)
        self.assertIn('items(body, key = { it.key }', s)
        self.assertIn('LocalBottomChromeInset.current + 20.dp', s)
        self.assertNotIn('chunked(', s)
    def test_two_shortcuts_are_excluded_from_body(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('cards.filter { it.pinned }', s)
        self.assertIn('cards.filterNot { it.pinned }', s)
        self.assertLess(s.index('item(key = "surface:shortcuts"'), s.index('item(key = "surface:sort"'))
    def test_import_is_hidden_until_plus_and_uses_existing_dialog(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('AnimatedVisibility(addExpanded', s)
        self.assertIn('vm::toggleLibraryAddPanel', s)
        self.assertIn('onImport = { if (vm.consumeLibraryAddAction()) importSource = true }', s)
        self.assertIn('pickPlaylistFile.launch(arrayOf("*/*"))', s)
        self.assertIn('vm.offerImport(it)', s)
    def test_tap_cycles_without_legacy_expanded_picker(self):
        s = read('ui/screens/LibraryControls.kt')
        self.assertIn('onClick = { onView(view.next()) }', s)
        self.assertNotIn('onLongClick', s)
        self.assertNotIn('onExpanded', s)
        self.assertIn('maxWidth - 192.dp', s)
        self.assertIn('horizontalScroll(rememberScrollState())', s)
    def test_avatar_uses_same_account_profile_as_home(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('AccountAvatar(account.userId.orEmpty(), profileName(account, profile), profile.avatar, 34.dp)', s)
        self.assertIn('onOpenAccount = onOpenAccountMenu', s)
        self.assertIn('onOpenAccountMenu = { accountDrawer = true }', read('MainActivity.kt'))
    def test_folder_menu_survives_removal_of_overlays(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('if (folderSelection.size == 1) RoundIconButton(', s)
        self.assertIn('onClick = { folderMenu = folderSelection.first() }', s)
        self.assertIn('CustomAccessibilityAction("Действия")', s)
        self.assertIn('actions.selectFolder(folder.name)', s)
    def test_search_ime_clear_and_cancellation(self):
        s = read('ui/screens/LibraryControls.kt')
        for text in ['ImeAction.Search', 'latestQuery(text); focus.clearFocus(); keyboard?.hide()',
                     'text = ""; latestQuery("")', 'if (!open) return@LaunchedEffect',
                     'onDispose { focus.clearFocus(); keyboard?.hide() }', 'requester.requestFocus()']:
            self.assertIn(text, s)
    def test_ci_runs_new_contracts_and_ui_cases_are_present(self):
        self.assertIn('test_library_6710.py', (ROOT/'tools/check_selftest.py').read_text())
        ui = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/Library6710UiTest.kt').read_text()
        for name in ['noLongClickAction', 'tapCycles', 'shuffleFollowsExternalPlayerState', 'searchClearsAndCloses', 'narrowToolbarDoesNotOverlap']:
            self.assertIn(name, ui)
        self.assertNotIn('@Ignore', ui)

if __name__ == '__main__': unittest.main(verbosity=2)
