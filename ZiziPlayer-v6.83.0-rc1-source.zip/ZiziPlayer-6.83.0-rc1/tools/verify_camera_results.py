#!/usr/bin/env python3
"""Fail closed on incomplete, duplicate, skipped or failed instrumentation results.
Inventory is explicit: update it when adding/removing tests, not to hide an interrupted run.
"""
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


def verify(results, expected):
    expected = set(expected)
    seen = set()
    problems = []
    files = sorted(Path(results).rglob('TEST-*.xml'))
    if not files:
        problems.append('No JUnit XML reports')
    for path in files:
        try:
            root = ET.parse(path).getroot()
        except (ET.ParseError, OSError) as exc:
            problems.append(f'Unreadable report {path.name}: {exc}')
            continue
        for suite in root.iter('testsuite'):
            for key in ('failures', 'errors', 'skipped'):
                try:
                    if int(suite.get(key, '0')) != 0:
                        problems.append(f'{path.name}: {key}={suite.get(key)}')
                except ValueError:
                    problems.append(f'{path.name}: invalid {key}')
        for case in root.iter('testcase'):
            key = case.get('classname', '') + '#' + case.get('name', '')
            if key in seen:
                problems.append('Duplicate test: ' + key)
            seen.add(key)
            if any(case.find(tag) is not None for tag in ('failure', 'error', 'skipped')):
                problems.append('Unsuccessful test: ' + key)
        for err in root.iter('system-err'):
            if ''.join(err.itertext()).strip():
                problems.append(f'{path.name}: nonempty system-err (inspect report)')
    missing = sorted(expected - seen)
    unexpected = sorted(seen - expected)
    if missing:
        problems.append('Missing tests: ' + ', '.join(missing))
    if unexpected:
        problems.append('Unexpected tests: ' + ', '.join(unexpected))
    return {'expected': len(expected), 'recorded': len(seen), 'complete_and_passed': not problems,
            'problems': problems}


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('28', '35'):
        raise SystemExit('Usage: verify_camera_results.py <28|35> <results-directory>')
    inventory = json.loads(Path(__file__).with_name('camera_test_inventory.json').read_text())
    result = verify(Path(sys.argv[2]), inventory[sys.argv[1]])
    print(json.dumps(result, indent=2))
    return 0 if result['complete_and_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
