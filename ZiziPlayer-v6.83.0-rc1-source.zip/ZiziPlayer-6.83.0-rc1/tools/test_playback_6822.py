#!/usr/bin/env python3
"""Run real production Java, without Android dependencies or policy reimplementations."""
from pathlib import Path
import os
import subprocess
import tempfile
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
paths = [
    'app/src/main/java/app/ziziplayer/playback/AudioInterruptionPolicy.java',
    'app/src/main/java/app/ziziplayer/playback/PlaybackReconnectPolicy.java',
    'app/src/main/java/app/ziziplayer/data/LibrarySourcePolicy.java',
    'app/src/test/java/app/ziziplayer/playback/Playback6822Checks.java',
]
if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='zizi-6822-') as output:
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                        *[str(ROOT / p) for p in paths]], check=True)
        subprocess.run(['java', '-cp', output, 'app.ziziplayer.playback.Playback6822Checks'], check=True)
