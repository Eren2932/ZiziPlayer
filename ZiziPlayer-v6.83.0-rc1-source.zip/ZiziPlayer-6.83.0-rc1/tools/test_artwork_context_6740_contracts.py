#!/usr/bin/env python3
"""Source wiring guards, not Kotlin execution. Runtime math is a separate suite."""
from pathlib import Path
import unittest
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()

class ContextContracts(unittest.TestCase):
    def test_cache_is_four_field_version_three(self):
        s = read('ui/components/Artwork.kt')
        for token in ('val body: Color = primary', '${body.toArgb()}', 'if (parts.size != 4) return null',
                      '!raw.startsWith(prefix)', 'Color(ints[3])'):
            self.assertIn(token, s)
        self.assertIn('SWATCH_VERSION = 3', read('ui/theme/ArtworkColorMath.java'))
    def test_no_thumbnail_or_no_art_reset(self):
        self.assertIn('no_art_ids_v2', read('ui/components/ArtworkIndex.kt'))
        s = read('ui/components/Artwork.kt')
        self.assertIn('File(base, "${hashOf(id)}-$px.webp")', s)
        self.assertIn('ArtworkSurfaceSampler.body(pixels, colors[0])', s)
        self.assertIn('withContext(Dispatchers.Default)', s)
    def test_all_playback_roles_use_body(self):
        s = read('ui/theme/ZiziTheme.kt')
        self.assertIn('val bodySwatch = swatches.body.toArgb()', s)
        for role in ('playerBackdrop', 'miniPlayer', 'chip'):
            self.assertIn(f'ArtworkSurfaceMath.{role}(primary, deepSwatch, bodySwatch)', s)
        self.assertIn('playerHeaderSubtext = Color(ArtworkSurfaceMath.PLAYER_HEADER_INK)', s)
    def test_both_artwork_headers_use_their_own_body(self):
        for name in ('ui/components/CollectionCover.kt', 'ui/screens/CollectionPageScreen.kt'):
            self.assertIn('collectionTop(it.primary.toArgb(), it.body.toArgb())', read(name))
    def test_accent_and_lyrics_keep_original_seed(self):
        theme = read('ui/theme/ZiziTheme.kt')
        self.assertIn('artworkPrimary = swatches.primary', theme)
        self.assertIn('swatches.primary.toOklch()', theme)
        self.assertIn('LyricsColorMath.create(primary?.toArgb())', read('ui/theme/LyricsPalette.kt'))
        self.assertNotIn('ArtworkSurfaceSampler', read('ui/theme/LyricsPalette.kt'))
        self.assertIn('val ZiziBrand = Color(0xFFF97316)', theme)
    def test_sampler_has_no_identity_or_external_work(self):
        s = read('ui/theme/ArtworkSurfaceSampler.java') + read('ui/theme/ArtworkSurfaceMath.java')
        for token in ('PASSO', 'MANDALA', 'RAYA', 'ABNORMAL', 'Bitmap', 'ArtworkCache', 'System.currentTimeMillis', 'java.net', 'android.', 'Random'):
            self.assertNotIn(token, s)
    def test_gradient_agrees_with_compose_stop_positions(self):
        self.assertIn('0.00f, 0.10f, 0.28f, 0.46f, 0.64f, 0.82f, 1.00f', read('ui/theme/ZiziTheme.kt'))
        self.assertIn('1f, .90f, .72f, .54f, .36f, .18f, 0f', read('ui/theme/ArtworkSurfaceMath.java'))
        self.assertIn('ArtworkColorMath.mix(BOTTOM, top, RAMP[i])', read('ui/theme/ArtworkSurfaceMath.java'))
    def test_ci_and_release(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        for name in ('test_artwork_context_6740.py', 'test_artwork_context_6740_contracts.py'):
            self.assertIn("'" + name + "'", s)
        assert_release_at_least(self, (ROOT / 'app/build.gradle.kts').read_text(), 157, '6.74.0')

if __name__ == '__main__': unittest.main(verbosity=2)
