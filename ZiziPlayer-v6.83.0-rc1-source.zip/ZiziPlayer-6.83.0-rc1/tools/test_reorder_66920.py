#!/usr/bin/env python3
"""Execute production Java; other checks are source wiring, NOT Kotlin/Android execution."""
from pathlib import Path
import subprocess
import tempfile
import unittest

R = Path(__file__).resolve().parents[1]
S = R/'app/src/main/java/app/ziziplayer'
def read(path): return (S/path).read_text()

class Reorder66920(unittest.TestCase):
    def test_production_geometry(self):
        with tempfile.TemporaryDirectory(prefix='reorder-66920-') as out:
            sources = [S/'ui/ReorderMath.java', R/'app/src/test/java/app/ziziplayer/ui/Reorder66920Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,sources)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Reorder66920Checks'],check=True)

    def test_bounds_use_physical_slots_during_pending_remeasure(self):
        s = read('ui/components/TrackReorder.kt')
        self.assertIn('it.index == firstRowIndex', s)
        self.assertIn('it.index == firstRowIndex + items.lastIndex', s)
        self.assertIn('return boundedTop(candidate, low, bottom) - row.offset', s)
        self.assertIn('top = boundedTop(pointerCenter - height / 2f, low, bottom)', s)
        self.assertIn('snapshotFlow {\n                            list.layoutInfo.visibleItemsInfo',s)
        self.assertIn('landingTop ?: (row.offset + settle.value)',s)
        self.assertIn('firstRowIndex = 2',read('ui/screens/LocalCollectionScreen.kt'))
        self.assertIn('if (values === external) return',s)

    def test_all_reorder_consumers_disable_placement_during_ordinary_scroll(self):
        for name,key in [('UnifiedLocalCollectionScreen.kt','track.id'),('LocalCollectionScreen.kt','track.id'),('Sheets.kt','entry.key')]:
            s = read('ui/screens/'+name)
            self.assertIn(f'if (reorder.animatePlacement({key}))',s)
            self.assertIn('fadeInSpec = null, fadeOutSpec = null',s)
            self.assertNotIn('placementSpec = if (lifted) null else spring',s)
        self.assertIn('ReorderMath.animatePlacement(',read('ui/components/TrackReorder.kt'))

    def test_cover_uses_preview_without_writing_during_gesture(self):
        s = read('ui/screens/UnifiedLocalCollectionScreen.kt')
        for text in ['reorder.previewChangesFirst', 'if (previewCover) previewTrack',
                     'state.collectionCoverTrack', 'followsReorderedCover', 'if (saved &&',
                     'remember(destination, playlist?.coverUri)', 'smooth = true', 'key(destination, coverMembers)']:
            self.assertIn(text,s)
        self.assertNotIn('state.playlistMeta[playlist.id]?.cover',s)
        self.assertIn('takeIf { it.id in coverMembers }',s)
        self.assertEqual(s.count('key(destination, coverMembers)'),2)
        vm = read('ui/MainViewModel.kt')
        for text in ['openPlaylist != null -> base.firstOrNull()', 'manualIds.firstNotNullOfOrNull { byId[it] }',
                     'collectionCoverTrack = collectionCoverTrack']:
            self.assertIn(text, vm)
        frame = read('ui/components/TrackReorder.kt').split('suspend fun frame(',1)[1].split('fun translation(',1)[0]
        self.assertNotIn('commit(',frame)

    def test_cover_pair_waits_for_decode_not_room_or_scroll_idle(self):
        s = read('ui/components/CollectionCover.kt')
        for text in ['LaunchedEffect(sourceKey)', 'currentCoroutineContext().ensureActive()',
                     'displayed = resolved ?: cached', 'collectionTop(it.primary.toArgb(), it.body.toArgb())',
                     'COLLECTION_COVER_FADE_MS = 180', 'animateColorAsState', 'Crossfade(targetState = cover.art']:
            self.assertIn(text,s)
        self.assertNotIn('ArtworkCache.awaitIdle()',s)
        self.assertEqual(s.count('tween(COLLECTION_COVER_FADE_MS)'),2)

if __name__ == '__main__': unittest.main(verbosity=2)
