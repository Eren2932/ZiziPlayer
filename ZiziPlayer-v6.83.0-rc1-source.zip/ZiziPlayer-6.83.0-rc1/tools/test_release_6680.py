#!/usr/bin/env python3
"""6.68.0 — фоновая синхронизация библиотеки, ползунок, реальная загрузка, блочный поиск.

UI source contracts (not Kotlin execution). Слияние участков загрузки исполняется JVM-тестом
app/src/test/java/app/ziziplayer/ui/components/MergeLoadedTest.kt в `gradle testDebugUnitTest`.
"""
import pathlib
import unittest

from release_identity import assert_release_at_least

R = pathlib.Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'


def read(name):
    return (S / name).read_text(encoding='utf-8')


class Release6680(unittest.TestCase):
    def test_library_choice_is_not_a_fullscreen_popup(self):
        main = read('MainActivity.kt')
        self.assertIn('LibraryChoiceNotice(', main)
        notice = read('ui/components/LibraryChoiceNotice.kt')
        self.assertNotIn('AlertDialog(', notice)
        self.assertNotIn('Dialog(', notice.replace('LibraryChoiceNotice', ''))
        sync = read('library/LibrarySync.kt')
        for needle in ('fun choiceNoticeSeen(', 'fun markChoiceNoticeSeen(',
                       'cloud != null && remoteHash == hash', 'private suspend fun saveResolving(',
                       'private suspend fun restoreQuietly(', 'expectedHash = hash'):
            self.assertIn(needle, sync)

    def test_real_conflict_still_pauses_sync(self):
        sync = read('library/LibrarySync.kt')
        block = sync.split('private suspend fun saveResolving(')[1].split('\n    }\n')[0]
        self.assertIn('else -> throw e', block)
        self.assertIn('e.status == 409', sync)

    def test_slider_gesture_uses_fresh_handlers(self):
        c = read('ui/components/Common.kt')
        for name in ('onScrubStart', 'onScrub', 'onScrubEnd', 'onScrubCancel'):
            self.assertIn('by rememberUpdatedState(%s)' % name, c)
        gesture = c.split('awaitFirstDown(requireUnconsumed = false)')[1].split('contentAlignment')[0]
        for stale in ('onScrubStart()', 'onScrub(local)', 'onScrub(next)', 'onScrubEnd(local)', 'onScrubCancel()'):
            self.assertNotIn(stale, gesture)

    def test_seek_retry_belongs_to_its_track(self):
        pc = read('playback/PlayerController.kt')
        self.assertIn('val seekOwned = seekTrackId != null && seekTrackId == p?.currentMediaItem?.mediaId', pc)
        self.assertIn('seekOwned && sinceSeek < SEEK_RETRY_WINDOW_MS', pc)

    def test_loaded_ranges_come_from_disk_cache_and_survive_seek(self):
        m = read('playback/StreamLoadMap.kt')
        self.assertIn('cache.getCachedSpans(key)', m)
        self.assertIn('StreamCache.peek()', m)
        self.assertNotIn('SimpleCache(', m)
        pc = read('playback/PlayerController.kt')
        self.assertIn('Progress(target, duration, target, currentId, keptLoaded)', pc)
        self.assertIn('loaded = if (seekable) progress.loaded else emptyList()', read('ui/screens/PlayerScreen.kt'))

    def test_search_all_is_mixed_since_6760(self):
        s = read('ui/screens/SearchScreen.kt')
        self.assertNotIn('sectionedResults(', s)
        self.assertIn('if (nearEnd && results.canLoadMore) onLoadMore()', s)
        self.assertIn('items(results.items, key = { keyOf(it) }', s)
        self.assertIn('SearchResultsPane(session = state.searchSession, tab = state.tab', s)
        self.assertIn('SearchFilterRail(selectedTab = tab', read('ui/screens/SearchResultsPane.kt'))
        self.assertIn('showKind = state.tab == SearchTab.ALL', s)

    def test_version(self):
        gradle = (R / 'app/build.gradle.kts').read_text(encoding='utf-8')
        assert_release_at_least(self, gradle, 124, '6.68.0')


if __name__ == '__main__':
    unittest.main(verbosity=2)
