#!/usr/bin/env python3
"""Execute production Java geometry and LRC timeline; no Android stubs or copied formulas."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-preview-6800-') as out:
    files = ['app/src/main/java/app/ziziplayer/ui/LyricsPreviewGeometry.java',
             'app/src/main/java/app/ziziplayer/lyrics/LrcTimeline.java',
             'app/src/test/java/app/ziziplayer/ui/LyricsPreview6800Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                    '-d', out, *[str(ROOT / p) for p in files]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.LyricsPreview6800Checks'], check=True)
