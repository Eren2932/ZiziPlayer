#!/usr/bin/env bash
# Keep failure gates strict. Diagnostics are best effort; Gradle/test errors are not.
set -euo pipefail
api="${1:-}"
case "$api" in 28|35) ;; *) echo 'Usage: run_camera_ci.sh <28|35>' >&2; exit 2 ;; esac
cd "$(dirname "$0")/.."
root="$PWD"
out="$root/build/ci/android-api-$api"
mkdir -p "$out"
export ANDROID_SERIAL=emulator-5554
logcat_pid=''
monitor_pid=''

host_snapshot() {
    date -u '+%Y-%m-%dT%H:%M:%SZ'
    for path in /proc/meminfo /proc/pressure/memory /sys/fs/cgroup/memory.events; do
        if [ -r "$path" ]; then echo "--- $path"; cat "$path"; fi
    done
    ps -eo pid,ppid,comm,rss --sort=-rss | head -25 || true
}

cleanup() {
    rc=$?
    trap - EXIT
    set +e
    if [ -n "$monitor_pid" ]; then kill "$monitor_pid" 2>/dev/null; wait "$monitor_pid" 2>/dev/null; fi
    if [ -n "$logcat_pid" ]; then kill "$logcat_pid" 2>/dev/null; wait "$logcat_pid" 2>/dev/null; fi
    host_snapshot > "$out/host-after.txt" 2>&1
    timeout 10s adb devices -l > "$out/adb-after.txt" 2>&1
    timeout 10s adb -s "$ANDROID_SERIAL" shell dumpsys meminfo app.ziziplayer > "$out/app-memory-after.txt" 2>&1
    # May be permission-denied on the runner; preserve that fact, never claim OOM without evidence.
    dmesg --ctime 2>&1 | tail -200 > "$out/kernel-tail.txt"
    printf '%s\n' "$rc" > "$out/exit-code.txt"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
host_snapshot > "$out/host-before.txt" 2>&1
adb version > "$out/adb-version.txt" 2>&1
adb devices -l > "$out/adb-before.txt" 2>&1
actual_api="$(timeout 10s adb -s "$ANDROID_SERIAL" shell getprop ro.build.version.sdk | tr -d '\r')"
[ "$actual_api" = "$api" ] || { echo "Expected API $api, found $actual_api" >&2; exit 1; }
boot="$(timeout 10s adb -s "$ANDROID_SERIAL" shell getprop sys.boot_completed | tr -d '\r')"
[ "$boot" = '1' ] || { echo 'Emulator has not finished booting' >&2; exit 1; }
timeout 10s adb -s "$ANDROID_SERIAL" shell getprop ro.hardware.egl > "$out/guest-egl.txt" 2>&1 || true
timeout 10s adb -s "$ANDROID_SERIAL" shell getprop debug.hwui.renderer > "$out/guest-hwui.txt" 2>&1 || true
adb -s "$ANDROID_SERIAL" logcat -v threadtime > "$out/logcat-full.txt" 2>&1 &
logcat_pid=$!
(while true; do host_snapshot; sleep 5; done) > "$out/host-timeline.txt" 2>&1 &
monitor_pid=$!
# Never accept API-28 XML as proof of API-35 success (same Gradle output directory).
rm -rf app/build/outputs/androidTest-results/connected app/build/reports/androidTests/connected
classes='app.ziziplayer.ui.CameraCutout6692Test,app.ziziplayer.ui.CameraMorph6692UiTest,app.ziziplayer.ui.CollectionHeader6600Test,app.ziziplayer.ui.CollectionHeader6601Test,app.ziziplayer.ui.CollectionHeader6602Test,app.ziziplayer.ui.TrackReorder66919Test,app.ziziplayer.ui.TrackReorder66920Test,app.ziziplayer.data.TrackOrder66919RoomTest,app.ziziplayer.ui.TrackReorder6700Test,app.ziziplayer.ui.Profile6700UiTest,app.ziziplayer.ui.Profile6701NavigationTest,app.ziziplayer.ui.CameraNotch6702Test,app.ziziplayer.ui.PlayerSheet6704UiTest,app.ziziplayer.ui.MiniPlayer6750UiTest'
if [ "$api" = "35" ]; then classes="$classes,app.ziziplayer.ui.CameraGooey66915UiTest,app.ziziplayer.ui.PlayerSheetInsets6704Test"; fi
set +e
# Gradle 8.11.1 task-specific --rerun: dependencies remain up-to-date; tests still execute.
gradle --no-daemon --max-workers=2 '-Dorg.gradle.jvmargs=-Xmx1536m -Dfile.encoding=UTF-8' \
    :app:connectedDebugAndroidTest --rerun \
    "-Pandroid.testInstrumentationRunnerArguments.class=$classes" --stacktrace 2>&1 | tee "$out/gradle.log"
statuses=("${PIPESTATUS[@]}")
# Validate and retain the partial inventory even when Gradle failed.
python3 tools/verify_camera_results.py "$api" app/build/outputs/androidTest-results/connected \
    | tee "$out/completeness.json"
verification=("${PIPESTATUS[@]}")
set -e
[ "${statuses[0]}" -eq 0 ] || exit "${statuses[0]}"
[ "${statuses[1]}" -eq 0 ] || exit "${statuses[1]}"
[ "${verification[0]}" -eq 0 ] || exit "${verification[0]}"
[ "${verification[1]}" -eq 0 ] || exit "${verification[1]}"
