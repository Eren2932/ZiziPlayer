#!/usr/bin/env python3
"""Exact client/server/smoke Reco HTTP contract. Source checks, not Kotlin compilation."""
import ast
from pathlib import Path
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from release_identity import assert_release_at_least  # noqa: E402


def assignment(path, name):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError('missing assignment: ' + name)


def registered_routes(method):
    tree = ast.parse((ROOT / 'server/zizi_reco.py').read_text(encoding='utf-8'))
    return {ast.literal_eval(decorator.args[0]) for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) for decorator in node.decorator_list
            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute)
            and isinstance(decorator.func.value, ast.Name) and decorator.func.value.id == 'router'
            and decorator.func.attr == method}


class RecoHTTPContract(unittest.TestCase):
    def client_paths(self):
        text = (ROOT / 'app/src/main/java/app/ziziplayer/data/remote/DeezerCatalog.kt').read_text(encoding='utf-8')
        return set(re.findall(r'post\("(/reco/[^"\s]+)"\s*,', text))

    def test_client_uses_canonical_post_paths(self):
        self.assertEqual(self.client_paths(), {'/reco/home', '/reco/feed'})

    def test_server_matches_the_exact_client_paths(self):
        self.assertEqual(registered_routes('post'), self.client_paths())

    def test_smoke_probes_the_exact_client_paths(self):
        paths = assignment(ROOT / 'server/tools/smoke_stage2.py', 'RECO_POST_PATHS')
        self.assertEqual(set(paths), self.client_paths())
        self.assertEqual(len(paths), 2)

    def test_smoke_health_matches_the_exact_server_get_route(self):
        path = assignment(ROOT / 'server/tools/smoke_stage2.py', 'RECO_HEALTH_PATH')
        self.assertEqual(registered_routes('get'), {path, '/reco/onboard'})
        self.assertEqual(path, '/reco/health')

    def test_installer_requires_the_regression_before_real_asgi_smoke(self):
        tests = assignment(ROOT / 'server/tools/deploy_server.py', 'TESTS')
        self.assertLess(tests.index('test_smoke_stage2.py'), tests.index('smoke_stage2.py'))

    def test_existing_repository_ci_is_connected_to_both_new_regressions(self):
        text = (ROOT / 'tools/check_selftest.py').read_text(encoding='utf-8')
        self.assertIn("'test_reco_http_contract_6821.py'", text)
        self.assertIn("'test_smoke_stage2.py'", text)

    def test_new_zip_has_unambiguous_patch_release_identity(self):
        text = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
        # A later version bump is not an HTTP regression. Also checks unique Gradle metadata.
        assert_release_at_least(self, text, 169, '6.82.1')


if __name__ == '__main__':
    unittest.main(verbosity=1)
