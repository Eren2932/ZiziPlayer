"""Whole-pixel regression using production geometry. Does not execute Kotlin or Android."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/ziziplayer/ui'
ANDROID = ROOT / 'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt'

class CameraPixelProbe6699(unittest.TestCase):
    def test_low_resolution_and_density_matrix(self):
        with tempfile.TemporaryDirectory() as tmp:
            compiled = subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17',
                '-target', '17', '-d', tmp, str(UI/'CameraMorphGeometry.java'),
                str(UI/'CollectionHeaderGeometry.java'),
                str(ROOT/'tools/visual/CameraDropPixelProbe6699.java')], capture_output=True, text=True)
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            run = subprocess.run(['java', '-Djava.awt.headless=true', '-cp', tmp,
                'CameraDropPixelProbe6699'], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            self.assertIn('241 fixtures OK', run.stdout)
            print(run.stdout, flush=True)

    def test_android_probe_keeps_strict_assertions(self):
        source = ANDROID.read_text()
        method = source.split('@Test fun cameraDropPrecedesConnection6699()', 1)[1].split(
            '@Test fun bodyDarkeningTracksContactAndReverses66910()', 1)[0]
        for required in ['ceil(t.bottom)', 'probeFits(inkPath, x, it, inside = true)',
                         'probeFits(inkPath, gx, gy, inside = false)',
                         'probeFits(fleshPath, gx, gy, inside = false)',
                         'g.u !in 3.10f..3.65f', 'drop.red < .03f', 'drop.green < .03f',
                         'drop.blue < .03f', 'reverseDrop.red', 'reverseDrop.green',
                         'reverseDrop.blue', 'No instant full-gap bridge', 'materialAt6696(.8f)']:
            self.assertIn(required, method)
        self.assertIn('x - .5f, y - .5f, x + 1.5f, y + 1.5f', source)
        self.assertIn('check(remainder.op(path, operation))', source)
        self.assertNotIn('pixels[', method[:method.index('val pixels =')])
        self.assertNotIn('@Ignore', source)

    def test_completion_contract_covers_whole_region_and_reverse(self):
        source = ANDROID.read_text()
        for required in ['listOf(1f, 1.2f)', 'No residual dot/drop',
                         'Color.DarkGray.red, c.red, .01f',
                         'Color.DarkGray.green, c.green, .01f',
                         'Color.DarkGray.blue, c.blue, .01f',
                         'CameraMorphGeometry.maxSwellPx(target) + 2f',
                         'fadeFrame.anchorAlpha', 'Fully restored sharpness']:
            self.assertIn(required, source)
        overlay = (ROOT/'app/src/main/java/app/ziziplayer/ui/components/CollectionCoverMorph.kt').read_text()
        self.assertIn('if (f.anchorAlpha > 0f) drawPath(outline, Color.Black, alpha = f.anchorAlpha)', overlay)

    def test_in_existing_preflight(self):
        self.assertIn('test_camera_pixel_probe_6699.py', (ROOT/'tools/check_selftest.py').read_text())

if __name__ == '__main__':
    unittest.main(verbosity=2)
