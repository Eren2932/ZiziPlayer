#!/usr/bin/env python3
"""Execute production Java geometry and source-wiring guards; NOT a Kotlin/Android build."""
from pathlib import Path
import ast
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'

class CameraMorph6692(unittest.TestCase):
    def test_production_geometry(self):
        files = [SRC/'ui/CameraMorphGeometry.java', SRC/'ui/CollectionCollapseMath.java',
                 SRC/'ui/CollectionGeometry.java', SRC/'ui/CollectionHeaderGeometry.java',
                 ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph6692Checks.java']
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.CameraMorph6692Checks'],check=True)

    def test_mutations_are_rejected(self):
        """Each mutant must compile and fail an assertion, not fail to launch the VM."""
        original=(SRC/'ui/CameraMorphGeometry.java').read_text()
        checks=ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph6692Checks.java'
        support=[SRC/('ui/'+name+'.java') for name in
                 ('CollectionCollapseMath','CollectionGeometry','CollectionHeaderGeometry')]
        mutations={
            'residual_camera_dot': ('smooth(p / .18f) * (1f - smoother((p - .90f) / .10f))', 'smooth(p / .18f)'),
            'camera_always_hidden': ('smooth(p / .18f) * (1f - smoother((p - .90f) / .10f))', '0f'),
            'camera_disappears_abruptly': ('smooth(p / .18f) * (1f - smoother((p - .90f) / .10f))', '(p < 1f ? smooth(p / .18f) : 0f)'),
            'wrong_camera_x': ('float endX = target == null ? centerX : target.cx();',
                               'float endX = centerX;'),
            'wrong_camera_width': ('float endW = target == null ? 0f : positive(target.width());',
                                   'float endW = 0f;'),
            'opaque_at_completion': ('float alpha = 1f - smooth(', 'float alpha = 2f - smooth('),
            'insufficient_rounding': ('startSize * .5f, smooth(f));', 'startSize * .25f, smooth(f));'),
            'missing_goo': ('f.progress <= .12f || f.progress >= 1',
                            'f.progress <= 1f || f.progress >= 1'),
            'unsafe_notch': ('t.top <= 0', 't.top < 0'),
            'estimate_wrong_bottom': ('float bottom = bounds.bottom;',
                                      'float bottom = bounds.bottom - 5f;'),
            'estimate_missing': ('return supported(estimate, width, height, status, density, false) ? estimate : null;',
                                 'return null;'),
        }
        for name,(before,after) in mutations.items():
            with self.subTest(mutation=name), tempfile.TemporaryDirectory() as tmp:
                self.assertEqual(original.count(before),1)
                source=Path(tmp)/'CameraMorphGeometry.java'
                source.write_text(original.replace(before,after))
                compile=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17',
                    '-d',tmp,str(source),*map(str,support),str(checks)],capture_output=True,text=True)
                self.assertEqual(compile.returncode,0,compile.stderr)
                run=subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraMorph6692Checks'],
                    capture_output=True,text=True)
                self.assertNotEqual(run.returncode,0,'Surviving mutant: '+name)
                self.assertIn('java.lang.AssertionError',run.stderr)
                print('Mutation rejected:',name,flush=True)

    def test_one_image_outside_lazy_list_and_no_new_scroll_owner(self):
        s=(SRC/'ui/screens/PinnedCollectionScaffold.kt').read_text()
        self.assertEqual(s.count('LazyColumn('),1)
        self.assertEqual(s.count('CollectionCoverMorphOverlay('),1)
        self.assertNotIn('{ artwork() }',s)
        self.assertIn('fraction = { collapseState.fraction }, scroll = { scrollPx() }',s)
        self.assertIn('.padding(top = status).nestedScroll(connection)',s)
        overlay=(SRC/'ui/components/CollectionCoverMorph.kt').read_text()
        self.assertEqual(overlay.count('{ artwork() }'),1)
        for banned in ['animateFloatAsState','animateDpAsState','pointerInput(','.clickable(',
                       'rememberUrlArtwork(', 'rememberArtwork(', 'RuntimeShader']:
            self.assertNotIn(banned,overlay)
        self.assertIn('target.left - edgePx',overlay)
        self.assertIn('this@onDrawWithContent.drawContent()',overlay)
        self.assertIn('Color.Cyan',overlay)

    def test_system_geometry_is_version_gated_copied_and_scoped(self):
        s=(SRC/'ui/components/CameraCutout.kt').read_text()
        for text in ['Build.VERSION.SDK_INT < 28', 'Build.VERSION.SDK_INT >= 31',
                     'cutout.cutoutPath?.let { AndroidPath(it) }', 'path.computeBounds(box, true)',
                     'CameraMorphGeometry.supported(', 'screenX != 0 || screenY != 0',
                     'isInMultiWindowMode', 'isInPictureInPictureMode', 'cutout.boundingRects.singleOrNull()', 'removeOnPreDrawListener(listener)']:
            self.assertIn(text,s)
        for banned in ['.boundingRectTop', 'setOnApplyWindowInsetsListener','CAMERA_PERMISSION', 'getIdentifier(', 'IQOO', 'iqoo']:
            self.assertNotIn(banned,s)
        activity=(SRC/'MainActivity.kt').read_text()
        for text in ['LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS', 'LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES']:
            self.assertIn(text,activity)

    def test_diagnostic_is_service_only_and_local(self):
        s=(SRC/'ui/screens/Sheets.kt').read_text()
        self.assertIn('label = "Слияние обложки с камерой"',s)
        self.assertIn('CameraMorphDiagnosticsDialog(',s)
        self.assertIn('if (app.ziziplayer.BuildConfig.DEBUG || devUnlocked) SettingRow(',s)
        d=(SRC/'ui/components/CameraMorphDiagnostics.kt').read_text()
        self.assertLess(d.index('val camera = rememberCameraCutout()'), d.index('AlertDialog('))
        self.assertIn('CameraMorphDebug.outlineEnabled = !CameraMorphDebug.outlineEnabled',d)
        self.assertNotIn('SettingsStore',d)
        self.assertIn('enabled = camera.target != null',d)
        self.assertNotIn(chr(65533),d)

    def test_continuous_background_and_player_only_glass(self):
        screen=(SRC/'ui/screens/PinnedCollectionScaffold.kt').read_text()
        self.assertIn('val top = statusPx - scrollPx()', screen)
        self.assertIn('startY = top, endY = top + heroPx', screen)
        self.assertNotIn('windowInsetsTopHeight(WindowInsets.statusBars).background(tint)',screen)
        main=(SRC/'MainActivity.kt').read_text()
        self.assertEqual(main.count('StatusBarTint('),1)
        self.assertNotIn('StatusBarTint(',main[:main.index('override fun onNewIntent')])
        player=main[main.index('if (mounted) {'):main.index('if (eqOpen) {',main.index('if (mounted) {'))]
        self.assertIn('StatusBarTint(',player)
        self.assertIn('(1f - (slide.value + dragOffset) / playerStatusPx)',player)

    def test_ci_runs_checks_and_version_is_new(self):
        source=(ROOT/'tools/check_selftest.py').read_text()
        main=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        self.assertIn('test_camera_morph_6692.py',ast.get_source_segment(source,main))
        from release_identity import assert_release_at_least
        assert_release_at_least(self,(ROOT/'app/build.gradle.kts').read_text(),127,'6.69.2')
        workflow=(ROOT/'.github/workflows/build.yml').read_text()
        self.assertIn('api-level: 28',workflow)
        self.assertIn('api-level: 35',workflow)
        runner=(ROOT/'tools/run_camera_ci.sh').read_text()
        self.assertIn(':app:connectedDebugAndroidTest',runner)
        self.assertIn('app.ziziplayer.ui.CameraCutout6692Test',runner)
        self.assertLess(workflow.index('script: bash tools/run_camera_ci.sh 35'),workflow.index('name: Assemble release'))

if __name__ == '__main__': unittest.main(verbosity=2)
