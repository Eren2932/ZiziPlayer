"""Shipping Java execution plus source contracts; not a Compose/Room runtime test."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (SRC / path).read_text()

class Search6760(unittest.TestCase):
    def test_shipping_java(self):
        with tempfile.TemporaryDirectory() as out:
            sources = [SRC/'ui/FilterRailGeometry.java', SRC/'ui/SearchResultGeometry.java', SRC/'data/remote/CollectionImportGuard.java',
                       SRC/'data/remote/SearchOverviewOrder.java',
                       ROOT/'app/src/test/java/app/ziziplayer/ui/Search6760Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                            *map(str, sources)], check=True, capture_output=True)
            result = subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.Search6760Checks'],
                                    check=True, capture_output=True, text=True)
            self.assertIn('production search/import assertions passed', result.stdout)
            print(result.stdout.strip())

    def test_persistent_rail_and_list_paging(self):
        s = read('ui/screens/SearchScreen.kt')
        pane = read('ui/screens/SearchResultsPane.kt')
        rail = pane.index('SearchFilterRail(selectedTab')
        holder = pane.index('scrollHolder.SaveableStateProvider(tab.name)')
        self.assertIn('SearchResultsPane(session = state.searchSession', s)
        self.assertLess(rail, holder)
        self.assertNotIn('sectionedResults', s)
        for value in ['info.totalItemsCount', 'results.canLoadMore', 'items(results.items, key = { keyOf(it) }',
                      'contentPadding = PaddingValues(bottom = LocalBottomChromeInset.current + 16.dp)',
                      'compactSearch: Boolean = false', 'onImport = vm::importSearchCollection']:
            self.assertIn(value, s)

    def test_animation_uses_measured_identity_not_replaced_chips(self):
        s = read('ui/components/SelectionFilterRail.kt')
        self.assertIn('SelectionFilterRail(', read('ui/components/SearchFilterRail.kt'))
        for value in ['Animatable(', 'progress.animateTo(', 'FilterRailGeometry.filterX(',
                      'placeRelativeWithLayer(', 'scroll.value', 'clearAndSetSemantics',
                      'val contentWidth = maxOf', 'enabled = expanded']:
            self.assertIn(value, s)
        self.assertNotIn('LazyRow(', s)
        self.assertNotIn('delay(', s)

    def test_import_is_complete_bounded_and_transactional(self):
        vm = read('ui/MainViewModel.kt').split('fun importSearchCollection(')[1].split('\n    /**')[0]
        for value in ['Semaphore(1)', 'val collectionImportKeys: StateFlow<Set<String>>']:
            self.assertIn(value, read('ui/MainViewModel.kt'))
        for value in ['withPermit', '120_000L', 'loadCompleteCollection', 'repo.importCompleteCollection',
                      'catch (e: CancellationException) { throw e }', 'finally', 'beginCollectionMutation(key)']:
            self.assertIn(value, vm)
        self.assertIn('size >= 3', read('ui/MainViewModel.kt').split('private fun beginCollectionMutation')[1].split('fun importSearchCollection')[0])
        self.assertLess(vm.index('loadCompleteCollection'), vm.index('repo.importCompleteCollection'))
        repo = read('data/MusicRepository.kt').split('suspend fun importCompleteCollection(')[1].split('suspend fun unlinkCollection')[0]
        for value in ['database.withTransaction', 'dao.collectionLink(key)', 'dao.playlistById',
                      'dao.createPlaylist', 'dao.addTracksToPlaylist', 'dao.linkCollection']:
            self.assertIn(value, repo)
        loader = read('data/remote/CompleteCollectionLoader.kt')
        for value in ['ensureActive()', 'guard.accept(', 'while (token != null)', 'putIfAbsent']:
            self.assertIn(value, loader)
        self.assertNotIn('rememberRemote', loader)

    def test_artist_rows_have_no_subscription(self):
        s = read('ui/screens/SearchScreen.kt').split('internal fun ResultGroupRow(')[1].split('private fun ActionButton')[0]
        self.assertIn('if (!artist) SearchSaveButton', s)
        self.assertNotIn('ChevronRight', s)
        self.assertNotIn('Подписаться', s)

    def test_all_keeps_same_request_budget(self):
        s = read('data/remote/DeezerCatalog.kt').split('override suspend fun search(')[1].split('override suspend fun suggest')[0]
        self.assertIn('kind != null || offset > 0', s)
        self.assertIn('SearchOverviewOrder.interleave<RemoteItem>', s)
        self.assertIn('browse(query, type, 0, 3)', s)
        self.assertIn('answers.first().first.nextToken', s)
        self.assertIn('catch (e: CancellationException) { throw e }', s)

if __name__ == '__main__': unittest.main(verbosity=2)
