#!/usr/bin/env bash
# Requires JDK 17+, Gradle 8.11.1, Android SDK 36 and a running device/emulator.
# Android animator duration scale must be 1x for the intermediate-frame test.
set -euo pipefail
cd "$(dirname "$0")/.."
classes='app.ziziplayer.ui.LyricsPreview6800UiTest,app.ziziplayer.ui.LyricsPaletteUiTest'
mkdir -p build/ci/lyrics-preview-6800
rm -rf app/build/outputs/androidTest-results/connected app/build/reports/androidTests/connected
set +e
gradle --no-daemon --max-workers=2 :app:connectedDebugAndroidTest --rerun \
  "-Pandroid.testInstrumentationRunnerArguments.class=$classes" --stacktrace \
  2>&1 | tee build/ci/lyrics-preview-6800/gradle.log
statuses=("${PIPESTATUS[@]}")
python3 tools/verify_lyrics_preview_android_6800.py app/build/outputs/androidTest-results/connected \
  | tee build/ci/lyrics-preview-6800/completeness.json
verification=("${PIPESTATUS[@]}")
set -e
[ "${statuses[0]}" -eq 0 ] || exit "${statuses[0]}"
[ "${statuses[1]}" -eq 0 ] || exit "${statuses[1]}"
[ "${verification[0]}" -eq 0 ] || exit "${verification[0]}"
[ "${verification[1]}" -eq 0 ] || exit "${verification[1]}"
