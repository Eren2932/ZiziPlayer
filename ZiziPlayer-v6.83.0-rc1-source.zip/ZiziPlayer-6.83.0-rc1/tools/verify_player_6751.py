#!/usr/bin/env python3
"""Portable offline suite runner. Executes all scripts registered by check_selftest, with logs.
Usage: python tools/verify_player_6751.py [--start 0 --end 32]
"""
from pathlib import Path
import argparse
import concurrent.futures
import json
import re
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--start', type=int, default=0)
parser.add_argument('--end', type=int, default=10000)
args = parser.parse_args()
text = (ROOT / 'tools/check_selftest.py').read_text()
suites = []
for s in re.findall(r"['\"]((?:server/tools/)?test_[a-zA-Z0-9_]+\.py)['\"]", text):
    p = s if s.startswith('server/') else 'tools/' + s
    if not (ROOT / p).exists():
        p = 'server/tools/' + s
    if (ROOT / p).exists() and p not in suites:
        suites.append(p)
out = ROOT / 'verification/v6.75.1'; out.mkdir(parents=True, exist_ok=True)
(out / 'suites.json').write_text(json.dumps(suites, indent=2))
def run(script):
    start = time.monotonic(); log = out / (Path(script).stem + '.log')
    with log.open('w') as f:
        try:
            code = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=100).returncode
        except subprocess.TimeoutExpired:
            code = 124
    result = dict(script=script, exit=code, seconds=round(time.monotonic()-start, 2))
    print(('PASS' if code == 0 else 'FAIL') + ' ' + script, flush=True)
    if code: print(log.read_text()[-4500:], flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(run, suites[args.start:args.end]))
(out / f'batch-{args.start}-{min(args.end,len(suites))}.json').write_text(json.dumps(results, indent=2))
print(f'Completed {len(results)}/{len(suites)} registered suites; failures={sum(x["exit"]!=0 for x in results)}')
sys.exit(1 if any(x['exit'] for x in results) else 0)
