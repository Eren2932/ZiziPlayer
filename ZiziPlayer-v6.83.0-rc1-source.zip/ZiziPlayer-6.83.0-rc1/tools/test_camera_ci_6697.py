#!/usr/bin/env python3
"""Offline fixtures only: real Bash/Python, fake adb/Gradle, no emulator claims."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

from verify_camera_results import verify

ROOT = Path(__file__).resolve().parents[1]
INVENTORY = json.loads((ROOT/'tools/camera_test_inventory.json').read_text())


def report(directory, cases, failure=None, skipped=None):
    directory.mkdir(parents=True, exist_ok=True)
    suite = ET.Element('testsuite', tests=str(len(cases)), failures='0', errors='0', skipped='0')
    for key in cases:
        cls, name = key.split('#')
        case = ET.SubElement(suite, 'testcase', classname=cls, name=name)
        if key == failure:
            ET.SubElement(case, 'failure')  # empty failure is still a failure
        if key == skipped:
            ET.SubElement(case, 'skipped')
    ET.ElementTree(suite).write(directory/'TEST-fixture.xml')


class CameraCi6697(unittest.TestCase):
    def test_inventory_matches_source_methods(self):
        cases = []
        for cls in sorted({k.split('#')[0] for k in INVENTORY['35']}):
            text = (ROOT/'app/src/androidTest/java'/Path(cls.replace('.', '/')+'.kt')).read_text()
            methods = re.findall(r'@Test\b(?:(?!\bfun\b).)*?\bfun\s+(\w+)\s*\(', text, re.S)
            cases.extend(cls+'#'+name for name in methods)
        self.assertEqual(sorted(cases), INVENTORY['35'])
        self.assertEqual(len(INVENTORY['28']), 78)
        self.assertEqual(len(INVENTORY['35']), 102)
        self.assertEqual(set(INVENTORY['35'])-set(INVENTORY['28']), {
            'app.ziziplayer.ui.PlayerSheetInsets6704Test#readsFourIndependentFrameworkPixelRadii',
            'app.ziziplayer.ui.PlayerSheetInsets6704Test#absentAndZeroCornersNeverReceiveTheLegacyGuess',
            'app.ziziplayer.ui.PlayerSheetInsets6704Test#freshWindowDoesNotReusePreviousPhysicalCorners',
            'app.ziziplayer.ui.CameraNotch6702Test#exactTallReservationRetainsHoleMode6703',
            'app.ziziplayer.ui.CameraNotch6702Test#unsupportedExactDetachedPathRetainsHoleFallback6703',
            'app.ziziplayer.ui.CameraGooey66915UiTest#topConnectedNotchReverseKeepsPixelsAndSingleArtwork6702',
            'app.ziziplayer.ui.CameraGooey66915UiTest#topConnectedUNotchGrowsAndAbsorbs6702',
            'app.ziziplayer.ui.CameraGooey66915UiTest#topConnectedVNotchGrowsAndAbsorbs6702',
            'app.ziziplayer.ui.CameraNotch6702Test#exactUNotchIsNotReplacedWithDetachedOval',
            'app.ziziplayer.ui.CameraNotch6702Test#exactVNotchUsesActualBottomInsteadOfBoundingBoxCentre',
            'app.ziziplayer.ui.CameraCutout6692Test#exactPathRefinesLooseBoundsWithoutMutatingTheFrameworkPath',
            'app.ziziplayer.ui.CameraMorph6692UiTest#blurReducesDetailWithoutDimming6696',
            'app.ziziplayer.ui.CameraGooey66915UiTest#centralGpuFirstBridgeIsThinAndGrows',
            'app.ziziplayer.ui.CameraGooey66915UiTest#centralPhysicalHoleGrowsItsOwnLobe66916',
            'app.ziziplayer.ui.CameraGooey66915UiTest#leftPhysicalHoleGrowsItsOwnLobe66916',
            'app.ziziplayer.ui.CameraGooey66915UiTest#rightPhysicalHoleGrowsItsOwnLobe66916',
            'app.ziziplayer.ui.CameraGooey66915UiTest#physicalHoleAndArtworkRemainJoinedUntilAbsorption66916',
            'app.ziziplayer.ui.CameraCutout6692Test#smallExactHoleIsNeverEnlargedToTheReservation66916',
            'app.ziziplayer.ui.CameraGooey66915UiTest#gpuBodyBothSidesRemainFilled',
            'app.ziziplayer.ui.CameraGooey66915UiTest#gpuCutoutDiscoveryDoesNotRemountArtwork',
            'app.ziziplayer.ui.CameraGooey66915UiTest#gpuHoldSubpixelReverseKeepsOneArtwork',
            'app.ziziplayer.ui.CameraGooey66915UiTest#gpuCompletionClearsCutoutAndReversalRestores',
            'app.ziziplayer.ui.CameraGooey66915UiTest#gpuDetailPassActuallyBlurs',
            'app.ziziplayer.ui.CameraGooey66915UiTest#cornerGpuRoundTripUsesCutoutNotScreenCenter',
        })

    def test_pass_requires_full_inventory(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            report(p, INVENTORY['35'])
            self.assertTrue(verify(p, INVENTORY['35'])['complete_and_passed'])
            report(p, INVENTORY['35'][:-1])
            self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])

    def test_api28_report_cannot_pass_api35(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); report(p, INVENTORY['28'])
            self.assertTrue(verify(p, INVENTORY['28'])['complete_and_passed'])
            self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])

    def test_empty_failure_and_skipped_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            for kwargs in ({'failure': INVENTORY['35'][0]}, {'skipped': INVENTORY['35'][0]}):
                report(p, INVENTORY['35'], **kwargs)
                self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])

    def test_missing_malformed_duplicate_and_unexpected_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])
            (p/'TEST-broken.xml').write_text('<testsuite')
            self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])
            (p/'TEST-broken.xml').unlink()
            for extra in (INVENTORY['35'][0], 'Other#test'):
                report(p, INVENTORY['35']+[extra])
                self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])

    def test_device_loss_in_system_err_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); report(p, INVENTORY['35'])
            file = p/'TEST-fixture.xml'; tree = ET.parse(file)
            ET.SubElement(tree.getroot(), 'system-err').text = "device 'emulator-5554' not found"
            tree.write(file)
            self.assertFalse(verify(p, INVENTORY['35'])['complete_and_passed'])

    def test_workflow_and_task_scope(self):
        workflow = (ROOT/'.github/workflows/build.yml').read_text()
        self.assertEqual(workflow, (ROOT/'repo-update/.github/workflows/build.yml').read_text())
        self.assertLess(workflow.index(':app:assembleDebugAndroidTest'), workflow.index('id: camera_api28'))
        runner = (ROOT/'tools/run_camera_ci.sh').read_text()
        self.assertNotIn('--rerun-tasks', workflow+runner)
        self.assertIn(':app:connectedDebugAndroidTest --rerun', runner)
        self.assertNotIn('continue-on-error:', workflow)
        for api in (28, 35):
            self.assertIn(f'script: bash tools/run_camera_ci.sh {api}', workflow)
            self.assertIn(f'_src/**/build/ci/android-api-{api}/', workflow)
            self.assertLess(workflow.index(f'script: bash tools/run_camera_ci.sh {api}'), workflow.index('name: Assemble release'))
        self.assertEqual(workflow.count('ram-size: 2048M'), 2)
        # 6.69.8: API 28 keeps its passing renderer; API 35 tests Lavapipe.
        self.assertEqual(workflow.count('-no-snapshot -feature -Vulkan'), 1)
        self.assertEqual(workflow.count('-gpu swiftshader_indirect'), 1)
        self.assertEqual(workflow.count('-gpu lavapipe'), 1)
        self.assertEqual(workflow.count("emulator-build: '15917651'"), 2)
        self.assertEqual(workflow.count('reactivecircus/android-emulator-runner@a421e43855164a8197daf9d8d40fe71c6996bb0d'), 2)
        api28 = workflow.split('id: camera_api28', 1)[1].split('name: Upload Android API 28', 1)[0]
        api35 = workflow.split('id: camera_api35', 1)[1].split('name: Collect Android API 35', 1)[0]
        self.assertIn('-gpu swiftshader_indirect', api28)
        self.assertIn('-gpu lavapipe', api35)
        self.assertNotIn('-feature -Vulkan', api35)
        self.assertIn('-verbose', api35)
        self.assertLess(workflow.index('name: Collect Android API 35 emulator host diagnostics'),
                        workflow.index('name: Upload Android API 35 results'))
        subprocess.run(['bash', '-n', str(ROOT/'tools/run_camera_ci.sh')], check=True)

    def run_fixture(self, exit_code=0, partial=False, wrong_api=False, stale=False):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); tools = p/'tools'; tools.mkdir(); bin_dir = p/'bin'; bin_dir.mkdir()
            for name in ('run_camera_ci.sh', 'verify_camera_results.py', 'camera_test_inventory.json'):
                shutil.copy2(ROOT/'tools'/name, tools/name)
            if stale:
                report(p/'app/build/outputs/androidTest-results/connected', INVENTORY['35'])
            adb = bin_dir/'adb'
            adb.write_text('#!/usr/bin/env bash\ncase "$*" in\n'
                ' *ro.build.version.sdk*) echo "${FIXTURE_API:-35}" ;;\n'
                ' *sys.boot_completed*) echo 1 ;;\n'
                ' *dumpsys*) exit 1 ;;\n'
                ' *) echo "fixture adb" ;;\nesac\n')
            adb.chmod(0o755)
            gradle = bin_dir/'gradle'
            gradle.write_text('#!'+sys.executable+'\n'+'''
import os, json, sys
from pathlib import Path
import xml.etree.ElementTree as ET
Path('gradle-args.json').write_text(json.dumps(sys.argv[1:]))
if os.environ['FIXTURE_STALE'] != '1':
    cases=json.loads(Path('tools/camera_test_inventory.json').read_text())['35']
    if os.environ['FIXTURE_PARTIAL']=='1': cases=cases[:9]
    root=ET.Element('testsuite',tests=str(len(cases)),failures='0',errors='0',skipped='0')
    for key in cases:
        cls,name=key.split('#'); ET.SubElement(root,'testcase',classname=cls,name=name)
    out=Path('app/build/outputs/androidTest-results/connected');out.mkdir(parents=True,exist_ok=True)
    ET.ElementTree(root).write(out/'TEST-fixture.xml')
print('fixture Gradle, not Android')
sys.exit(int(os.environ['FIXTURE_EXIT']))
''')
            gradle.chmod(0o755)
            env = dict(os.environ, PATH=str(bin_dir)+os.pathsep+os.environ['PATH'],
                FIXTURE_API='28' if wrong_api else '35', FIXTURE_EXIT=str(exit_code),
                FIXTURE_PARTIAL='1' if partial else '0', FIXTURE_STALE='1' if stale else '0')
            run = subprocess.run(['bash', str(tools/'run_camera_ci.sh'), '35'],
                env=env, capture_output=True, text=True, timeout=30)
            out = p/'build/ci/android-api-35'
            self.assertEqual(int((out/'exit-code.txt').read_text()), run.returncode, run.stderr)
            self.assertTrue((out/'host-after.txt').is_file())
            if not wrong_api:
                args = json.loads((p/'gradle-args.json').read_text())
                self.assertIn('--rerun', args)
                self.assertNotIn('--rerun-tasks', args)
            else:
                self.assertFalse((p/'gradle-args.json').exists())
            return run.returncode

    def test_runner_success_with_failing_optional_diagnostics(self):
        self.assertEqual(self.run_fixture(), 0)

    def test_runner_preserves_gradle_exit(self):
        self.assertEqual(self.run_fixture(exit_code=7), 7)

    def test_runner_rejects_incomplete_even_if_gradle_succeeds(self):
        self.assertNotEqual(self.run_fixture(partial=True), 0)

    def test_runner_rejects_wrong_device(self):
        self.assertNotEqual(self.run_fixture(wrong_api=True), 0)

    def test_runner_does_not_accept_stale_xml(self):
        self.assertNotEqual(self.run_fixture(stale=True), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
