#!/usr/bin/env python3
"""UI source contracts only; do not replace Compose rendering or an Android build."""
from pathlib import Path
import unittest
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (SRC / path).read_text()

class PlayerBrandContracts(unittest.TestCase):
    def test_all_connected_surfaces_share_existing_zizi_brand(self):
        ui = read('ui/components/AudioOutputUi.kt')
        self.assertIn('import app.ziziplayer.ui.theme.ZiziBrand', ui)
        self.assertIn('val ConnectedDeviceAccent = ZiziBrand', ui)
        self.assertIn('if (output.isKnown && !output.isPhone) ConnectedDeviceAccent else Color.White', ui)
        self.assertIn('val ZiziBrand = Color(0xFFF97316)', read('ui/theme/ZiziTheme.kt'))
        for path in ('ui/components/AudioOutputUi.kt', 'ui/components/MiniPlayerCard.kt',
                     'ui/screens/AudioOutputSheet.kt', 'ui/screens/PlayerScreen.kt'):
            s = read(path)
            self.assertNotIn('ConnectedDeviceGreen', s, path)
            self.assertNotIn('0xFF1ED760', s, path)
        self.assertIn('audioOutputTint(output)', read('ui/screens/PlayerScreen.kt'))
        self.assertIn('ConnectedDeviceAccent', read('ui/screens/AudioOutputSheet.kt'))

    def test_favorite_is_heart_not_add_or_check(self):
        s = read('ui/components/MiniPlayerCard.kt')
        self.assertIn('MiniFavoriteControl(favorite = favorite, onClick = onFavorite)', s)
        self.assertIn('if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart', s)
        self.assertNotIn('ZiziIcons.AddCircle', s)
        self.assertNotIn('ZiziIcons.AddedCircle', s)
        heart = s.split('private fun MiniFavoriteControl')[1]
        self.assertIn('Modifier.size(29.dp).clip(CircleShape)', heart)
        self.assertIn('modifier = Modifier.size(17.dp)', heart)
        self.assertIn('if (favorite) p.brand else Color.Transparent', heart)
        self.assertIn('if (favorite) p.onBrand else Color.White', heart)
        self.assertIn('tint = if (favorite) p.onBrand', read('ui/screens/PlayerScreen.kt'))

    def test_heart_keeps_separate_full_height_target_and_accessibility(self):
        s = read('ui/components/MiniPlayerCard.kt').split('private fun MiniFavoriteControl')[1]
        self.assertIn('Modifier.width(MiniPlayerGeometry.CONTROL.dp).fillMaxHeight()', s)
        self.assertEqual(s.count('.clickable('), 1)
        self.assertIn('.clickable(role = Role.Button, onClick = onClick)', s)
        self.assertIn('selected = favorite', s)
        self.assertIn('"mini-favorite"', s)
        for label in ('Убрать из избранного', 'Добавить в избранное'):
            self.assertIn(label, s)
        self.assertNotIn('IconButton(', s)
        self.assertNotIn('mutableStateOf', s)

    def test_android_regressions_cover_color_and_toggle_round_trip(self):
        s = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/MiniPlayer6750UiTest.kt').read_text()
        self.assertIn('colorPixels("mini-output", ZiziBrand)', s)
        self.assertIn('colorPixels("mini-output", Color.White)', s)
        self.assertIn('colorPixels("mini-favorite", basePalette().onBrand)', s)
        self.assertIn('colorPixels("connect-active", ZiziBrand)', s)
        self.assertIn('.assertIsSelected()', s)
        self.assertIn('.assertIsNotSelected()', s)

    def test_release_and_ci_registration(self):
        self.assertIn("'test_player_brand_6751_contracts.py'", (ROOT/'tools/check_selftest.py').read_text())
        assert_release_at_least(self, (ROOT/'app/build.gradle.kts').read_text(), 159, '6.75.1')

if __name__ == '__main__': unittest.main(verbosity=2)
