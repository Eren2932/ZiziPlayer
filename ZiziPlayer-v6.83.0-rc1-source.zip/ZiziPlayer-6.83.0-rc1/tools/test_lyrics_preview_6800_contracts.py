#!/usr/bin/env python3
"""Source integration guards only. They do not compile/execute Compose."""
from pathlib import Path
import unittest
import json
import re
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()

class LyricsPreviewContracts(unittest.TestCase):
    def test_same_lyrics_palette_without_player_chip_or_second_art_decode(self):
        card = read('ui/screens/LyricsPreviewCard.kt')
        for token in ['LyricsSurfaceTheme {', 'remember(p) { p.background }', '.background(background)',
                      'if (isActive) p.text else p.subtext', 'pendingInk = p.subtext']:
            self.assertIn(token, card)
        for token in ['p.chip', 'rememberArtSwatches', 'ArtworkCache', 'rememberInfiniteTransition',
                      'Color(0x', 'LocalBackdropBlend']:
            self.assertNotIn(token, card)
        self.assertIn('LyricsSurfaceTheme {', read('ui/screens/LyricsScreen.kt'))

    def test_saved_per_track_advance_is_shared_not_reimplemented(self):
        for name in ['LyricsPreview.kt', 'LyricsScreen.kt']:
            self.assertIn('rememberLyricsCursor', read('ui/screens/' + name))
        preview = read('ui/screens/LyricsPreview.kt')
        self.assertIn('key(track.id, doc)', preview)
        self.assertIn('rememberLyricsCursor(vm, track, doc, state.advanceMs)', preview)
        player = read('ui/screens/PlayerScreen.kt')
        self.assertIn('state = lyricsState', player)
        cursor = read('ui/screens/LyricsCursor.kt')
        self.assertIn('initialValue = resolve(vm.progress.value)', cursor)
        self.assertIn('vm.progress.map { resolve(it) }', cursor)
        state = read('ui/screens/LyricsUiState.kt')
        for token in ['advanceMs = repository.advance(current)', 'repository.saveAdvance(current, value)',
                      'advanceMs = value.coerceIn(-60000L, 60000L)']:
            self.assertIn(token, state)
        card = read('ui/screens/LyricsPreviewCard.kt')
        for token in ['delay(', 'System.currentTimeMillis', 'seekTo(', 'persistAdvance', 'rememberSaveable']:
            self.assertNotIn(token, card)

    def test_under_cover_caption_has_no_click_route(self):
        preview = read('ui/screens/LyricsPreview.kt')
        inline = preview.split('internal fun InlineLyrics(')[1]
        for forbidden in ['onOpen', 'clickable', 'pointerInput', 'detectTapGestures']:
            self.assertNotIn(forbidden, inline)
        self.assertIn('InlineLyricsCaption(doc, cursor, modifier)', inline)
        self.assertIn('AnimatedContent(targetState = cue', inline)
        player = read('ui/screens/PlayerScreen.kt')
        call = next(line for line in player.splitlines() if 'InlineLyrics(vm,' in line)
        self.assertNotIn('onOpen', call)
        self.assertEqual(player.count('onLyricsOpenChange(true)'), 2)

    def test_lazy_cues_are_stable_and_line_motion_ignores_word_updates(self):
        card = read('ui/screens/LyricsPreviewCard.kt')
        for token in ['LaunchedEffect(active, viewportPx, widthPx)', 'key(document)',
                      'key = { index, _ -> index }', 'list.scrollToItem(target)',
                      'list.animateScrollBy(visible.offset.toFloat()', 'G.shouldAnimate(previous, active)',
                      'userScrollEnabled = false', 'cursor.word', 'selected = isActive']:
            self.assertIn(token, card)
        self.assertNotIn('joinToString', card)
        self.assertNotIn('doc.lines.drop(', read('ui/screens/LyricsPreview.kt'))
        self.assertIn('G.activeIndex(cursor.sameTrack, cursor.matchesDuration,', card)
        self.assertIn('document.matchVerified, cursor.active, document.lines.size', card)

    def test_text_only_fade_and_accessibility_sizes(self):
        card = read('ui/screens/LyricsPreviewCard.kt')
        for token in ['.previewEdgeFade()', 'CompositingStrategy.Offscreen', 'BlendMode.DstIn',
                      'G.FADE_TOP to Color.Black', 'G.FADE_BOTTOM to Color.Black',
                      'bodyStyle.lineHeight.toDp()', 'maxOf(48.dp, buttonHeight)',
                      'role = Role.Button', 'includeFontPadding = false', 'Показать текст']:
            self.assertIn(token, card)
        self.assertLess(card.index('.background(background)'), card.index('LyricsPreviewViewport(document'))
        self.assertIn('if (!document.hasText) return', card)

    def test_compact_card_only_cta_can_open(self):
        card = read('ui/screens/LyricsPreviewCard.kt')
        self.assertEqual(card.count('.clickable('), 1)
        self.assertEqual(card.count('onClick = onOpen'), 1)
        cta = card.index('.testTag("lyrics-preview-open")')
        self.assertLess(cta, card.index('.clickable('))
        for forbidden in ['pointerInput', 'detectTapGestures', 'combinedClickable', 'onClick {']:
            self.assertNotIn(forbidden, card)
        self.assertIn('Modifier.heightIn(min = (G.HEADER_LINE * u).dp)', card)
        self.assertIn('.testTag("lyrics-preview-button-face")', card)
        self.assertIn('userScrollEnabled = false', card)

    def test_preflight_jvm_android_registration(self):
        text = (ROOT/'tools/check_selftest.py').read_text()
        for name in ['test_lyrics_preview_6800.py', 'test_lyrics_preview_6800_contracts.py']:
            self.assertIn(repr(name), text)
        assert_release_at_least(self, (ROOT/'app/build.gradle.kts').read_text(), 166, '6.80.1')
        self.assertIn('LyricsPreview6800Checks.runAll()',
                      (ROOT/'app/src/test/java/app/ziziplayer/ui/LyricsPreview6800Test.kt').read_text())
        ui = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/LyricsPreview6800UiTest.kt').read_text()
        for test in ['sharedGradientAndReferenceGeometry', 'repeatedCueSeekAndAdvanceKeepCurrentAnchor',
                     'oneCueAnimatesWithoutResizingCard', 'plainAndInvalidTimingHaveNoSelectedCue',
                     'buttonHasIndependent48dpTargetAndCaptionIsReadOnly', 'largeFontsGrowViewport',
                     'cardHeaderCuesAndEmptySpaceDoNotOpenLyrics',
                     'draggingCardOrButtonScrollsParentWithoutOpening',
                     'fourLineCurrentCueFitsAboveBottomFade']:
            self.assertIn('fun ' + test, ui)

    def test_android_inventory_covers_all_declared_methods(self):
        inventory = json.loads((ROOT/'tools/lyrics_preview_6800_android_inventory.json').read_text())
        found = []
        for cls in sorted({case.split('#')[0] for case in inventory}):
            source = (ROOT/'app/src/androidTest/java'/Path(cls.replace('.', '/') + '.kt')).read_text()
            found.extend(cls + '#' + method for method in re.findall(r'@Test\s+fun\s+(\w+)\(', source))
        self.assertEqual(sorted(found), sorted(inventory))
        self.assertEqual(len(inventory), 12)
        runner = (ROOT/'tools/run_lyrics_preview_ui_6800.sh').read_text()
        self.assertIn('verify_lyrics_preview_android_6800.py', runner)
        self.assertIn(':app:connectedDebugAndroidTest', runner)

if __name__ == '__main__': unittest.main(verbosity=2)
