"""Execute Java endpoint policy; source guards are not Kotlin/Gradle execution."""
from pathlib import Path
import subprocess
import tempfile
import unittest

from release_identity import assert_release_at_least

R = Path(__file__).resolve().parents[1]
S = R/'app/src/main/java/app/ziziplayer'

class Resolver6650(unittest.TestCase):
    def test_real_endpoint_policy(self):
        with tempfile.TemporaryDirectory() as d:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', d,
                str(S/'data/remote/ResolverEndpoint.java'),
                str(R/'app/src/test/java/app/ziziplayer/data/remote/ResolverEndpointChecks.java')], check=True)
            subprocess.run(['java', '-cp', d, 'app.ziziplayer.data.remote.ResolverEndpointChecks'], check=True)

    def test_both_initial_and_saved_settings_use_migration(self):
        text = (S/'data/SettingsStore.kt').read_text()
        self.assertIn('ResolverEndpoint.effective(null, BuildConfig.RESOLVER_URL)', text)
        self.assertIn('ResolverEndpoint.effective(p[resolverUrlKey], BuildConfig.RESOLVER_URL)', text)
        self.assertIn('resolverToken = (p[resolverTokenKey] ?: "").ifBlank { BuildConfig.RESOLVER_TOKEN }', text)
        self.assertIn('wifiOnly = p[wifiOnlyKey] ?: false', text)
        self.assertIn('resolverProxy = p[resolverProxyKey] ?: BuildConfig.RESOLVER_PROXY', text)

    def test_build_normalizes_empty_and_legacy_ci_values(self):
        text = (R/'app/build.gradle.kts').read_text()
        assert_release_at_least(self, text, 124, '6.68.0')
        block = text.split('val configuredResolverUrl =', 1)[1].split('val resolverToken =', 1)[0]
        self.assertIn('System.getenv("RESOLVER_URL") ?: ""', block)
        self.assertIn('configuredResolverUrl.trim().trimEnd', block)
        self.assertIn('"", "147.45.166.244:8080", "http://147.45.166.244:8080",', block)
        self.assertIn('"http://ziziplayer-audio.duckdns.org" -> "https://ziziplayer-audio.duckdns.org"', block)
        self.assertIn('else -> value', block)

    def test_parallel_cancel_unblocks_receiver(self):
        text = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        launch = text.split('val jobs = group.map', 1)[1].split('val collected', 1)[0]
        self.assertIn('catch (e: CancellationException)', launch)
        self.assertIn('channel.cancel(e)', launch)
        self.assertIn('throw e', launch)
        tests = (R/'app/src/test/java/app/ziziplayer/lyrics/LyricsHybridParallelTest.kt').read_text()
        self.assertIn('@Test(timeout = 5_000L) fun cancellationFromParallelPropagates()', tests)
        self.assertIn('assertEquals("track changed", e.message)', tests)

    def test_wired_to_zip_preflight(self):
        self.assertIn("'test_resolver_6650.py'", (R/'tools/check_selftest.py').read_text())

if __name__ == '__main__':
    unittest.main(verbosity=2)
