#!/usr/bin/env python3
"""Source-wiring regression guards. NOT Android execution or Kotlin compilation."""
from pathlib import Path
import unittest
import re
import sqlite3
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(p): return (SRC / p).read_text()
class PlaybackContracts(unittest.TestCase):
    def test_foreground_before_focus_acquisition(self):
        focus = read('playback/FocusPlayer.kt')
        mutation = focus.split('override fun setPlayWhenReady', 1)[1].split('override fun setMediaItems', 1)[0]
        self.assertLess(mutation.index('if (!beforePlay())'), mutation.index('if (acquire())'))
        acquire = focus.split('private fun acquire()', 1)[1].split('private fun focusChanged', 1)[0]
        self.assertIn('clearFocus(notify = false)', acquire)
        self.assertNotIn('interruptionChanged()', acquire)
        service = read('playback/PlaybackService.kt')
        self.assertIn('focusPlayer?.beforePlay = ::prepareForegroundForPlay', service)
        self.assertIn('if (!foreground) androidx.core.content.ContextCompat.startForegroundService', service)
    def test_transient_pause_and_permanent_loss_are_different(self):
        focus = read('playback/FocusPlayer.kt')
        transient = focus.split('AUDIOFOCUS_LOSS_TRANSIENT -> {', 1)[1].split('AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK', 1)[0]
        self.assertIn('policy.transientLoss(engine.playWhenReady)', transient)
        self.assertIn('AudioInterruptionPolicy.MAX_TRANSIENT_MS', transient)
        self.assertNotIn('abandon()', transient)
        self.assertIn('AUDIOFOCUS_LOSS -> { engine.pause(); abandon() }', focus)
        self.assertIn('handler.removeCallbacks(transientDeadline)', focus)
    def test_notification_has_single_owner_and_live_async_guard(self):
        service = read('playback/PlaybackService.kt')
        notification = service.split('override fun onUpdateNotification', 1)[1].split('private var engine', 1)[0]
        self.assertNotIn('super.onUpdateNotification', notification)
        self.assertIn('epoch == notificationEpoch && session === current', notification)
        self.assertIn('AudioInterruptionPolicy.keepForeground', notification)
        self.assertIn('catch (failure: RuntimeException)', notification)
        self.assertIn('override fun isPlaybackOngoing(): Boolean = foreground', service)
        task = service.split('override fun onTaskRemoved', 1)[1].split('override fun onStartCommand', 1)[0]
        self.assertNotIn('super.onTaskRemoved', task)
        self.assertIn('if (!isPlaybackOngoing()) stopSelf()', task)
    def test_transient_notification_pause_cancels_resume(self):
        action = read('playback/PlaybackNotificationActions.kt')
        self.assertIn('if (interrupted) KeyEvent.KEYCODE_MEDIA_PAUSE', action)
        provider = read('playback/PromotedNotificationProvider.kt')
        self.assertIn('showPauseButton || (session.player as? FocusPlayer)?.isResumePending == true', provider)
        self.assertIn('onNotificationChangedCallback.onNotificationChanged(decorate(updated, mediaSession))', provider)
    def test_reconnect_is_paused_and_user_queue_wins(self):
        pc = read('playback/PlayerController.kt')
        self.assertIn('override fun onDisconnected(c: MediaController)', pc)
        self.assertIn('PlaybackReconnectPolicy.shouldReconnect', pc)
        restore = pc.split('private fun restoreDisconnectedQueue', 1)[1].split('/** Suspends', 1)[0]
        self.assertIn('controller !== c || queueEpoch != epoch || pendingQueue != null', restore)
        self.assertIn('setQueue(tracks, index, play = false', restore)
        self.assertIn('buildingQueue != null) pendingQueue = buildingQueue', pc)
        self.assertIn('catch (cancelled: CancellationException)', restore)
        self.assertIn('closed = true', pc.split('fun release()', 1)[1])
    def test_delayed_source_retry_cannot_undo_focus_pause(self):
        pc = read('playback/PlayerController.kt')
        self.assertIn('live.currentMediaItem?.mediaId != failedId || !live.playWhenReady', pc)
        self.assertIn('p.playWhenReady && seekOwned', pc)
        pause = pc.split('fun playPause()', 1)[1].split('fun ', 1)[0]
        self.assertIn('retryJob?.cancel()', pause)
    def test_placeholder_excluded_from_both_query_and_probe(self):
        dao = read('data/MusicDao.kt')
        query = dao.split('suspend fun documentTrackSample', 1)[0].rsplit('@Query', 1)[1]
        self.assertIn("uri LIKE 'content://%' OR uri LIKE 'file://%'", query)
        self.assertIn('if (!LibrarySourcePolicy.isProbeUri(raw)) return SourceAvailability.UNKNOWN', read('data/MusicRepository.kt'))
    def test_actual_sample_query_excludes_restoration_placeholders(self):
        dao = read('data/MusicDao.kt')
        query = re.search(r'@Query\("([^"\n]+)"\)\s+suspend fun documentTrackSample', dao).group(1)
        db = sqlite3.connect(':memory:')
        self.addCleanup(db.close)
        db.execute('CREATE TABLE tracks(id TEXT PRIMARY KEY, source TEXT, uri TEXT)')
        db.executemany('INSERT INTO tracks VALUES (?, ?, ?)', [
            ('placeholder', 'local', 'zizi-missing:f:123'),
            ('remote', 'remote', 'zizi://yt/abc'),
            ('mislabelled-remote', 'local', 'https://host/audio'),
            ('media', 'local', 'content://media/external/audio/media/1'),
            ('document', 'local', 'content://documents/tree/music/document/song'),
            ('file', 'local', 'file:///storage/emulated/0/Music/song.mp3'),
            ('remote-content', 'remote', 'content://documents/remote'),
        ])
        self.assertEqual({row[0] for row in db.execute(query, {'limit': 40})}, {'document', 'file'})
    def test_loss_message_only_after_completed_scan_with_actual_removal(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('launchScan { verifySources() }', vm)
        verify = vm.split('private suspend fun verifySources()', 1)[1].split('fun rescan()', 1)[0]
        self.assertNotIn('launchScan', verify)
        self.assertIn('removed = repo.rescan(it).removedLocalTracks', verify)
        self.assertIn('failure != null || removed == 0', verify)
        self.assertLess(verify.index('withScanResult'), verify.index('_messages.send'))
        self.assertIn('LibrarySourcePolicy.shouldReportLoss', read('data/MusicRepository.kt'))
    def test_null_and_partial_scans_cannot_delete_library(self):
        scanner = read('data/MusicScanner.kt')
        self.assertIn('?: throw LibraryScanUnavailableException', scanner)
        self.assertIn('if (queue.isNotEmpty()) throw LibraryScanUnavailableException', scanner)
        self.assertIn('if (!mounted) throw LibraryScanUnavailableException', scanner)
        self.assertIn('Папка временно недоступна; сохранённая медиатека не удаляется', scanner)
        repo = read('data/MusicRepository.kt')
        rescan = repo.split('suspend fun rescan(', 1)[1].split('private suspend fun migrateLegacyIds', 1)[0]
        self.assertLess(rescan.index('scanner.scanTree'), rescan.index('return database.withTransaction'))
        self.assertIn('ScanSummary(stale.size)', rescan)
        self.assertIn('return@withTransaction ScanSummary(orphaned.size)', rescan)
    def test_saf_scans_without_global_permission_and_media_rows_are_protected(self):
        scanner = read('data/MusicScanner.kt')
        self.assertIn('fun canReadMediaStore()', scanner)
        self.assertIn('android.Manifest.permission.READ_MEDIA_AUDIO', scanner)
        repo = read('data/MusicRepository.kt')
        self.assertIn('val fromMediaStore = if (mediaStoreReadable)', repo)
        self.assertIn('val protectedMediaIds = if (mediaStoreReadable)', repo)
        self.assertIn('val stale = deletableIds.filterNot', repo)
        self.assertLess(repo.index('if (all.isNotEmpty()) migrateLegacyIds(all)'), repo.index('return database.withTransaction'))
    def test_ci_and_gradle_execute_new_core_suite(self):
        selftest = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn("'test_playback_6822.py'", selftest)
        self.assertIn("'test_playback_6822_contracts.py'", selftest)
        self.assertTrue((ROOT / 'app/src/test/java/app/ziziplayer/playback/Playback6822Test.java').exists())
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertGreaterEqual(int(re.search(r'^\s*versionCode\s*=\s*(\d+)\s*$', gradle, re.M).group(1)), 170)
if __name__ == '__main__': unittest.main(verbosity=2)
