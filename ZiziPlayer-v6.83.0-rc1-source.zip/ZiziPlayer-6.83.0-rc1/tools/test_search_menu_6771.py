#!/usr/bin/env python3
"""Production Java + source contracts. These do NOT execute Kotlin or Android Compose."""
from pathlib import Path
import json
import re
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'

class SearchMenu6771(unittest.TestCase):
    def test_actual_viewport_math(self):
        with tempfile.TemporaryDirectory() as out:
            files = [SRC/'ui/SearchMenuGeometry.java', ROOT/'app/src/test/java/app/ziziplayer/ui/SearchMenu6771Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out, *map(str, files)], check=True)
            run = subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.SearchMenu6771Checks'], check=True, capture_output=True, text=True)
            self.assertIn('production viewport assertions passed', run.stdout)
            print(run.stdout.strip())

    def test_no_loading_only_menu_and_no_io_on_open(self):
        host = (SRC/'ui/screens/SearchTrackActionsHost.kt').read_text()
        self.assertNotIn('Подготавливаем', host)
        self.assertNotIn('LaunchedEffect', host)
        self.assertNotIn('emptyList()', host)
        self.assertEqual(host.count('SearchTrackMenuSheet('), 1)
        self.assertIn('val preview = remember(remote) { remote.toEntity() }', host)
        self.assertIn('run(checkNotNull(prepared))', host)
        self.assertLess(host.index('prepareAction ='), host.index('vm.prepareRemoteTrack(remote)'))
        self.assertNotIn('if (!download.checking)', host)
        self.assertIn('enabled = !download.checking', host)
        self.assertIn('key(remote.trackId)', host)
        self.assertIn('remote == null && playlistTarget == null', host)

    def test_single_lifecycle_with_prepare_before_hide_and_error_retry(self):
        sheet = (SRC/'ui/screens/SearchTrackMenuSheet.kt').read_text()
        self.assertEqual(sheet.count('    Dialog('), 1)
        self.assertEqual(sheet.count('try { state.peekMenu() }'), 1)
        self.assertIn('rememberUpdatedState(onDismiss)', sheet)
        self.assertIn('rememberUpdatedState(prepareAction)', sheet)
        self.assertIn('if (!dispatched)', sheet)
        self.assertIn('preparation?.cancel()', sheet)
        self.assertIn('preparingId == null && !exiting', sheet)
        self.assertIn('preparingId == action.id) exit(run)', sheet)
        self.assertIn('catch (cancelled: CancellationException)', sheet)
        self.assertIn('if (!state.isVisible) finish(action)', sheet)
        self.assertIn('if (error != null) item("error")', sheet)
        self.assertNotIn('delay(', sheet)
        self.assertIn('window?.setWindowAnimations(0)', sheet)

    def test_bounded_viewport_and_common_theme(self):
        sheet = (SRC/'ui/screens/SearchTrackMenuSheet.kt').read_text()
        # 6.79.0 intentionally replaces Material's translated fixed-height shell.
        # Assert the real, constrained Surface and single inner bottom inset instead.
        for token in ['NeutralSurfaceTheme {', 'color = ZiziModalSurface', 'contentColor = p.text',
                      'WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)',
                      'WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom)',
                      'SearchMenuGeometry.top(constraints.maxHeight, state.drag.offset)',
                      'val visible = constraints.maxHeight - y',
                      'Constraints.fixed(constraints.maxWidth, visible)', 'clipToBounds()',
                      'state = listState', 'PaddingValues(bottom = 16.dp)', 'SearchMenuGeometry.scrollHeader',
                      'if (scrollHeader) item("header")', 'tonalElevation = 0.dp']:
            self.assertIn(token, sheet)
        self.assertNotIn('height(expandedHeight)', sheet)
        self.assertNotIn('0xFF1F1F1F', sheet)
        self.assertNotIn('navigationBars', sheet)  # no second bottom inset
        self.assertNotIn('detectDragGestures', sheet)

    def test_android_inventory_and_ci_registration(self):
        source = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/SearchMenu6771UiTest.kt').read_text()
        actual = ['app.ziziplayer.ui.SearchMenu6771UiTest#' + n for n in re.findall(r'@Test\s+fun\s+(\w+)\(', source)]
        inventory = json.loads((ROOT/'tools/search_menu_6771_android_inventory.json').read_text())
        previous = json.loads((ROOT/'tools/search_6770_android_inventory.json').read_text())
        self.assertEqual(sorted(inventory), sorted(previous + actual))
        self.assertGreaterEqual(len(actual), 8)
        self.assertIn("'test_search_menu_6771.py'", (ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('verify_search_menu_android_6771.py', (ROOT/'tools/run_search_menu_ui_6771.sh').read_text())

if __name__ == '__main__':
    unittest.main(verbosity=2)
