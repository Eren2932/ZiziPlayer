#!/usr/bin/env python3
"""Production Java execution + explicit source contracts. NOT Kotlin/Compose/Room execution."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(p): return (SRC / p).read_text()

class Search6770(unittest.TestCase):
    def test_shipping_geometry(self):
        with tempfile.TemporaryDirectory() as out:
            files = [SRC/'ui/FilterRailGeometry.java', SRC/'ui/SearchResultGeometry.java',
                     ROOT/'app/src/test/java/app/ziziplayer/ui/Search6770Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str, files)], check=True)
            run = subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Search6770Checks'],check=True,capture_output=True,text=True)
            self.assertIn('production geometry assertions passed', run.stdout)
            print(run.stdout.strip())

    def test_session_is_explicit_not_query_identity(self):
        vm = read('ui/SearchViewModel.kt')
        submit = vm.split('fun submit(')[1].split('fun setTab(')[0]
        self.assertEqual(submit.count('searchSession = _state.value.searchSession + 1L'), 1)
        self.assertIn('saved[KEY_SEARCH_SESSION] = current.searchSession', vm)
        self.assertIn('saved.get<Long>(KEY_SEARCH_SESSION)', vm)
        ui = read('ui/screens/SearchScreen.kt')
        self.assertIn('key(state.searchSession) { rememberSaveableStateHolder() }', ui)
        self.assertNotIn('key(state.query) { rememberSaveableStateHolder()', ui)
        pane = read('ui/screens/SearchResultsPane.kt')
        self.assertIn('key(session)', pane)
        self.assertIn('scrollHolder.SaveableStateProvider(tab.name)', pane)
        self.assertLess(pane.index('SearchFilterRail(selectedTab'), pane.index('SaveableStateProvider(tab.name)'))

    def test_checkmark_never_opens_collection(self):
        ui = read('ui/screens/SearchScreen.kt')
        row = ui.split('internal fun ResultGroupRow(')[1].split('private fun ActionButton')[0]
        self.assertIn('onClick = if (imported) onRemove else onImport', row)
        self.assertNotIn('onClick = if (imported) onClick', row)
        self.assertIn('in importedKeys) onRemove(it) else onImport(it)', ui)
        self.assertIn('CollectionRemovalRequest(collection, link, artistIds)', ui)
        self.assertIn('vm.removeCollection(request.collection, link, request.artistTrackIds)', ui)
        page = read('ui/screens/RemoteCollectionScreen.kt')
        self.assertIn('(imported || open.tracks.isNotEmpty())', page)
        self.assertIn('!collectionBusy', page)

    def test_delete_is_confirmed_atomic_and_paged(self):
        vm = read('ui/MainViewModel.kt').split('fun removeCollection(')[1].split('// ------------------------------------------------------- обмен')[0]
        for token in ['beginCollectionMutation(key)', 'expected.owned -> emptyList()', 'loadCompleteCollection',
                      '120_000L', 'repo.removeLinkedCollection(expected, ids)', 'finally',
                      'catch (e: CancellationException) { throw e }']:
            self.assertIn(token, vm)
        self.assertLess(vm.index('loadCompleteCollection'), vm.index('repo.removeLinkedCollection'))
        dao = read('data/MusicDao.kt')
        self.assertIn('@Transaction\n    suspend fun removeLinkedCollection', dao)
        delete = dao.split('suspend fun removeLinkedCollection')[1].split('@Query("SELECT * FROM playlist_links")')[0]
        for token in ['collectionLink(expected.collectionKey) != expected', 'deletePlaylistFull',
                      'require(trackIds.isNotEmpty())', 'chunked(500)', 'unlinkCollection(expected.collectionKey)']:
            self.assertIn(token, delete)
        self.assertNotIn('tracks WHERE', delete)
        self.assertNotIn('favorites', delete)

    def test_every_top_filter_uses_one_engine(self):
        for path in ['ui/screens/HomeScreen.kt','ui/screens/LibraryScreen.kt','ui/screens/Sheets.kt','ui/components/SearchFilterRail.kt']:
            self.assertIn('SelectionFilterRail(', read(path))
        rail = read('ui/components/SelectionFilterRail.kt')
        for token in ['key(item.id)', 'scroll.stopScroll()', 'FilterRailGeometry.filterX(', 'clearAndSetSemantics',
                      'tailMinWidth', 'if (settled) trailingContent()', 'if (selection == item.id || defaultId == item.id) null']:
            self.assertIn(token, rail)
        self.assertNotIn('delay(', rail)

    def test_search_editor_reference_contract_replaces_legacy_hash(self):
        # 6.78.0 intentionally redesigns the editor. Navigation/session guards remain above.
        ui = read('ui/screens/SearchScreen.kt')
        editor = ui.split('internal fun SearchField(', 1)[1].split('\n@Composable', 1)[0]
        for token in ['SearchEditorGeometry.HEADER_DP', 'SearchEditorGeometry.FIELD_DP',
                      'TextFieldValue(text, TextRange(text.length))', 'LaunchedEffect(requestFocusOnOpen)']:
            self.assertIn(token, editor)
        self.assertNotIn('.border(', editor)

    def test_real_menu_actions_and_reference_sheet(self):
        ui = read('ui/screens/SearchScreen.kt')
        self.assertIn('onMenu = { onTrackMenu(track) }', ui)
        row = ui.split('internal fun ResultTrackRow(')[1].split('internal fun ResultGroupRow(')[0]
        self.assertIn('IconButton(onClick = openMenu', row)
        self.assertIn('SearchResultGeometry.MORE_ICON_DP.dp', row)
        host = read('ui/screens/SearchTrackActionsHost.kt')
        for action in ['onShare(track)', 'vm.toggleFavorite(track)', 'vm.addToQueue(track)', 'vm.playNext(track)',
                       'PlaylistPickerSheet(', 'QueueSheet(', 'TrackInfoSheet(', 'vm.download(track)', 'FxSheet(']:
            self.assertIn(action, host)
        self.assertNotIn('vm.play(', host)
        self.assertNotIn('vm.playRemote(', host)
        sheet = read('ui/screens/SearchTrackMenuSheet.kt')
        for token in ['rememberSearchMenuMotionState()',
                      'MENU_PEEK_FRACTION', 'MENU_TOP_FRACTION', 'hasPartiallyExpandedState', 'state.peekMenu()',
                      'if (!state.isVisible) finish(action)', 'if (!dispatched)', 'LazyColumn(', '.anchoredDraggable(']:
            self.assertIn(token, sheet)
        self.assertNotIn('detectDragGestures', sheet)
        self.assertNotIn('Premium', host)

    def test_android_runtime_checks_are_present(self):
        tests = ROOT/'app/src/androidTest/java/app/ziziplayer'
        self.assertEqual((tests/'ui/Search6770UiTest.kt').read_text().count('@Test fun'), 5)
        self.assertEqual((tests/'data/CollectionRemoval6770Test.kt').read_text().count('@Test fun'), 5)
        self.assertIn('test_search_6770.py', (ROOT/'tools/check_selftest.py').read_text())
        inventory = json.loads((ROOT/'tools/search_6770_android_inventory.json').read_text())
        actual = []
        for path in [tests/'ui/SearchFilterRailTest.kt', tests/'ui/Search6770UiTest.kt', tests/'data/CollectionRemoval6770Test.kt']:
            text = path.read_text()
            package = re.search(r'^package ([\w.]+)', text, re.M)[1]
            cls = re.search(r'^class (\w+)', text, re.M)[1]
            actual += [package+'.'+cls+'#'+name for name in re.findall(r'@Test\s+fun\s+(\w+)\(', text)]
        self.assertEqual(sorted(inventory), sorted(actual))
        self.assertEqual(len(inventory), 13)
        self.assertIn('verify_search_android_6770.py', (ROOT/'tools/run_search_ui_6770.sh').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
