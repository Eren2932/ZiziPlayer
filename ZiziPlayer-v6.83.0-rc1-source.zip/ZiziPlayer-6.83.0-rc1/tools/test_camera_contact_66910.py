"""Production JVM math and wiring; not a Kotlin/Compose/Android compiler."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'app/src/main/java/app/ziziplayer/ui/CameraMorphGeometry.java'
CHECKS=ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph66910Checks.java'
class CameraContact66910(unittest.TestCase):
    def run_java(self,source):
        with tempfile.TemporaryDirectory() as tmp:
            local=Path(tmp)/'CameraMorphGeometry.java';local.write_text(source)
            compile=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',tmp,str(local),str(CHECKS)],capture_output=True,text=True)
            self.assertEqual(compile.returncode,0,compile.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraMorph66910Checks'],capture_output=True,text=True)
    def test_production(self):
        result=self.run_java(SOURCE.read_text())
        self.assertEqual(result.returncode,0,result.stderr)
        print(result.stdout,flush=True)
    def test_regressions(self):
        original=SOURCE.read_text()
        mutants={
            'undersized_reservation':('float diameter = w;','float diameter = .60f * w;'),
            'late_admission':('smoother((f.progress - .12f) / .20f)','smoother((f.progress - .12f) / .43f)'),
            'tube':('return table(WAIST_U, WAIST_V, u);','return 2.62f;'),
            'early_color_return':('g == null ? 0f : table(BODY_U, BODY_V, g.u)','g == null ? 0f : 0f * table(BODY_U, BODY_V, g.u)'),
        }
        for name,(old,new) in mutants.items():
            with self.subTest(name=name):
                self.assertEqual(original.count(old),1)
                run=self.run_java(original.replace(old,new))
                self.assertNotEqual(run.returncode,0,name)
                self.assertIn('AssertionError',run.stderr)
                print('Mutation rejected:',name,flush=True)
    def test_single_contour_single_shading(self):
        s=(ROOT/'app/src/main/java/app/ziziplayer/ui/components/CollectionCoverMorph.kt').read_text()
        for required in ['cameraMorphSilhouette(body, flesh)','clipPath(silhouette)',
                         'val bodyBlack = M.bodyBlack(f, g)','saveLayer(bounds, fadePaint)']:
            self.assertIn(required,s)
        self.assertNotIn('clipPath(body, ClipOp.Difference)',s)
        self.assertEqual(s.count('drawRect(ink,'),1)
        self.assertEqual(s.count('alpha = bodyBlack)'),1)
    def test_ci_wiring(self):
        self.assertIn('test_camera_contact_66910.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraMorph66910Checks.main',(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph66910Test.java').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
