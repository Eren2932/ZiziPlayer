"""Production JVM scroll tests + explicit source integration guards, NOT Android compilation."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/ziziplayer/ui'
CHECKS = ROOT / 'app/src/test/java/app/ziziplayer/ui/CollectionScroll66914Checks.java'

class CameraInput66914(unittest.TestCase):
    # The Computer runtime contains jdk.compiler, but not historical ct.sym for --release.
    # Emit Java 17 bytecode; the real Android/JDK 17 build remains a separate CI gate.
    def run_scroll(self, mutation=None):
        source = (UI/'CollectionScrollPrecision.java').read_text()
        if mutation:
            old, new = mutation
            self.assertEqual(source.count(old), 1)
            source = source.replace(old, new)
        with tempfile.TemporaryDirectory() as tmp:
            local = Path(tmp)/'CollectionScrollPrecision.java'
            local.write_text(source)
            files = [local, UI/'CollectionCollapseMath.java', UI/'CollectionGeometry.java',
                     UI/'CameraMorphGeometry.java', CHECKS]
            compiled = subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                                       '-d', tmp, *map(str, files)], capture_output=True, text=True)
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            return subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.ui.CollectionScroll66914Checks'],
                                  capture_output=True, text=True)

    def test_fractional_input_hold_and_restoration(self):
        result = self.run_scroll()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        print(result.stdout, flush=True)

    def test_return_to_integer_input_fails(self):
        result = self.run_scroll(('return (float) pixels;', 'return (float) offset;'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('subpixel reversal', result.stderr)

    def test_wrong_direction_fails(self):
        result = self.run_scroll(('pixels - (double) childConsumedY', 'pixels + (double) childConsumedY'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('AssertionError', result.stderr)

    def test_discarding_fraction_between_events_fails(self):
        result = self.run_scroll(('? this : at(currentIndex, currentOffset)',
                                 '? at(currentIndex, currentOffset) : at(currentIndex, currentOffset)'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('subpixel reversal', result.stderr)

    def run_winding(self, control=None):
        with tempfile.TemporaryDirectory() as tmp:
            check = ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMask66914Checks.java'
            compiled = subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                                       '-d', tmp, str(UI/'CameraMorphGeometry.java'), str(check)],
                                      capture_output=True, text=True)
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            return subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.ui.CameraMask66914Checks',
                                   *([control] if control else [])], capture_output=True, text=True)

    def test_extension_winding_preserves_union(self):
        result = self.run_winding()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        print(result.stdout, flush=True)

    def test_even_odd_negative_control_fails(self):
        result = self.run_winding('evenodd')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('compound mask must equal set union', result.stderr)

    def test_opposite_winding_negative_control_fails(self):
        result = self.run_winding('opposite')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('compound mask must equal set union', result.stderr)

    def test_real_scroll_wiring_and_no_second_owner(self):
        s = (UI/'screens/PinnedCollectionScaffold.kt').read_text()
        for part in ('before = preciseScroll.rebase(list.firstVisibleItemIndex,',
                     'preciseScroll = before.after(consumed.y, index, offset)',
                     'fun scrollPx(): Float = preciseScroll.visualScroll(list.firstVisibleItemIndex,',
                     'if (index == 0 && offset == 0 && collapseState.fraction < 1f)',
                     'return Offset(0f, expanded)', 'CameraMorphDebug.recordScroll(',
                     'remember(list, density, heroPx, expandedPx, pinnedPx, morphTravelPx)'):
            self.assertIn(part, s)
        self.assertNotIn('before.after(available.y', s)
        self.assertNotIn('dispatchRawDelta', s)
        self.assertNotIn('animateScrollBy', s)
        self.assertEqual(s.count('LazyColumn('), 1)
        self.assertNotIn('rememberSaveable(list', s)
        renderer = (UI/'components/CollectionCoverMorph.kt').read_text()
        self.assertIn('CameraMorphDebug.recordFrame(scroll(), f, g)', renderer)

    def test_one_winding_mask_and_one_shading_pass(self):
        s = (UI/'components/CollectionCoverMorph.kt').read_text()
        for part in ('val silhouette = cameraMorphSilhouette(body, flesh)',
                     'fillType = PathFillType.NonZero', 'addRoundRect(body, Path.Direction.Clockwise)',
                     'if (extension != null) addPath(extension)', 'clipPath(silhouette)'):
            self.assertIn(part, s)
        # The moving body/neck mask still avoids Boolean operations. 6.70.2's
        # static physical-notch safety clip is computed once, outside scroll drawing.
        moving = s.split('internal fun cameraMorphSafetyPath(', 1)[0]
        self.assertNotIn('Path.combine(', moving)
        self.assertNotIn('PathOperation', moving)
        safety = s.split('internal fun cameraMorphSafetyPath(', 1)[1]
        self.assertNotIn('progress', safety)
        self.assertNotIn('scroll()', safety)
        self.assertEqual(s.count('alpha = bodyBlack)'), 1)
        self.assertEqual(s.count('{ artwork() }'), 1)
        self.assertEqual(s.count('sourceLayer.record { this@onDrawWithContent.drawContent() }'), 1)

    def test_diagnostics_is_optional_bounded_and_local(self):
        s = (UI/'components/CameraCutout.kt').read_text()
        trace = s.split('internal object CameraMorphDebug {',1)[1].split('@Composable',1)[0]
        for part in ('traceEnabled by mutableStateOf(false)', 'TRACE_LIMIT = 240',
                     'if (!traceEnabled) return', 'trace.removeFirst()', 'trace.clear()'):
            self.assertIn(part, trace)
        for banned in ('android.util.Log', 'File(', 'OkHttp', 'SharedPreferences', 'SettingsStore'):
            self.assertNotIn(banned, trace)
        self.assertIn('SelectionContainer { Text(CameraMorphDebug.traceReport()) }',
                      (UI/'components/CameraMorphDiagnostics.kt').read_text())

    def test_ci_wiring(self):
        self.assertIn('test_camera_input_66914.py', (ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CollectionScroll66914Checks.main',
                      (ROOT/'app/src/test/java/app/ziziplayer/ui/CollectionScroll66914Test.java').read_text())
        self.assertIn('CameraMask66914Checks.main',
                      (ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMask66914Test.java').read_text())
        source = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        inventory = (ROOT/'tools/camera_test_inventory.json').read_text()
        for name in ('centralRealSubpixelContact66914', 'cornerRealSubpixelContact66914',
                     'compoundMaskEqualsUnion66914'):
            self.assertIn('fun '+name, source)
            self.assertEqual(inventory.count(name), 2)

if __name__ == '__main__':
    unittest.main(verbosity=2)
