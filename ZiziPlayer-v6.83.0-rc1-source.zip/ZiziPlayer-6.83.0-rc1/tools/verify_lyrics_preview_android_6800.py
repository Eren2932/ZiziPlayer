#!/usr/bin/env python3
"""Require all 12 lyrics palette/preview Android tests; missing/skipped is not a pass."""
import json
from pathlib import Path
import sys
from verify_camera_results import verify
if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: verify_lyrics_preview_android_6800.py <results-directory>')
    inventory = json.loads(Path(__file__).with_name('lyrics_preview_6800_android_inventory.json').read_text())
    result = verify(Path(sys.argv[1]), inventory)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['complete_and_passed'] else 1)
