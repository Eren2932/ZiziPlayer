#!/usr/bin/env python3
"""Require all 13 search/filter/Room device tests, without skipped or stale extra reports."""
import json
from pathlib import Path
import sys
from verify_camera_results import verify

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: verify_search_android_6770.py <results-directory>')
    inventory = json.loads(Path(__file__).with_name('search_6770_android_inventory.json').read_text())
    result = verify(Path(sys.argv[1]), inventory)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['complete_and_passed'] else 1)
