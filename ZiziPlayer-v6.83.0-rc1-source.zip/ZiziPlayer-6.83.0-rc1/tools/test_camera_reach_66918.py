"""Compile/run the production reach and reject disabling it or widening its base."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
UI=ROOT/'app/src/main/java/app/ziziplayer/ui'
CHECK=ROOT/'app/src/test/java/app/ziziplayer/ui/CameraReach66918Checks.java'

class CameraReach66918(unittest.TestCase):
    def execute(self, mutation=None):
        source=(UI/'CameraGooeyGeometry.java').read_text()
        if mutation:
            old,new=mutation
            self.assertEqual(source.count(old),1)
            source=source.replace(old,new)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'CameraGooeyGeometry.java';p.write_text(source)
            r=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',tmp,
                str(UI/'CameraMorphGeometry.java'),str(p),str(CHECK)],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraReach66918Checks'],capture_output=True,text=True)
    def test_production(self):
        r=self.execute();self.assertEqual(r.returncode,0,r.stdout+r.stderr);print(r.stdout,flush=True)
    def test_disabled_advance_rejected(self):
        r=self.execute(('float eased = t * (3f + t * (t - 3f));','float eased = t;'))
        self.assertNotEqual(r.returncode,0);self.assertIn('Earlier axial reach',r.stderr)
    def test_wider_camera_base_rejected(self):
        r=self.execute(('0f, h*.5f, cameraR+reach','0f, reach*.5f, cameraR+reach'))
        self.assertNotEqual(r.returncode,0);self.assertIn('Camera base not widened',r.stderr)
    def test_unwired_camera_reach_rejected(self):
        r=self.execute(('0f, h*.5f, cameraR+reach','0f, h*.5f, cameraR+h'))
        self.assertNotEqual(r.returncode,0);self.assertIn('Camera apex uses earlier reach',r.stderr)
    def test_unwired_artwork_reach_rejected(self):
        r=self.execute(('-r-reach*.25f','-r-h*.25f'))
        self.assertNotEqual(r.returncode,0);self.assertIn('Artwork apex uses earlier reach',r.stderr)
    def test_ci_hook(self):
        self.assertIn('test_camera_reach_66918.py',(ROOT/'tools/check_selftest.py').read_text())

if __name__=='__main__':unittest.main(verbosity=2)
