#!/usr/bin/env python3
"""Run real Android-independent DSP sources/tests on the JVM, with no source substitutions.

Optional diagnostic harness, NOT a Gradle/Android build. Compiler 1.6.21 is smaller
than the download limit of the offline environment; runtime stdlib matches the
project (2.1.0). The authoritative compiler remains Kotlin 2.1.0 in Gradle CI.
Supply the JAR files below via --deps. No downloads, installation or network here.
Example: python3 tools/run_dsp_jvm.py --deps /path/to/jars --out /tmp/dsp-results
Media3 adapter ZiziAudioProcessorTest is excluded here, but remains in Gradle CI.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
COMPILER = ['kotlin-compiler-embeddable-1.6.21.jar', 'kotlin-stdlib-1.6.21.jar',
            'kotlin-reflect-1.6.21.jar', 'trove4j-1.0.20200330.jar', 'annotations-13.0.jar']
COMMON = ['junit-4.13.2.jar', 'hamcrest-core-1.3.jar', 'annotations-13.0.jar']
COMPILE = COMMON + ['kotlin-stdlib-1.6.21.jar']
RUNTIME = COMMON + ['kotlin-stdlib-2.1.0.jar']
PRODUCTION = ['Biquad', 'DspConfig', 'DspEngine', 'DspPresets']
TESTS = ['DspEngineTest', 'DspPresetsTest', 'DspHeadroomTest']


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--deps', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--repeat', type=int, default=3)
    args = ap.parse_args()
    if not 1 <= args.repeat <= 100:
        ap.error('--repeat must be in 1..100')
    deps, out = args.deps.resolve(), args.out.resolve()
    names = sorted(set(COMPILER + COMPILE + RUNTIME))
    for name in names:
        if not (deps/name).is_file():
            ap.error('Missing JAR: ' + name)
    out.mkdir(parents=True, exist_ok=True)
    sources = [ROOT/'app/src/main/java/app/ziziplayer/playback/dsp'/f'{n}.kt' for n in PRODUCTION]
    sources += [ROOT/'app/src/test/java/app/ziziplayer/playback/dsp'/f'{n}.kt' for n in TESTS]
    cp = lambda ns: ':'.join(str(deps/n) for n in ns)
    env = {'scope': 'isolated real DSP JVM tests; NOT Gradle/Android',
           'compiler': '1.6.21', 'runtime_stdlib': '2.1.0',
           'java': subprocess.run(['java', '--version'], capture_output=True, text=True, check=True).stdout,
           'dependency_sha256': {n: hashlib.sha256((deps/n).read_bytes()).hexdigest() for n in names},
           'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
    (out/'environment.json').write_text(json.dumps(env, indent=2) + '\n')

    def run(command, name):
        result = subprocess.run(command, capture_output=True, text=True)
        text = result.stdout + result.stderr
        (out/name).write_text('COMMAND: ' + ' '.join(command) + '\n' + text)
        print(text, end='')
        if result.returncode:
            raise SystemExit(result.returncode)

    with tempfile.TemporaryDirectory(prefix='dsp-jvm-') as tmp:
        run(['java', '-cp', cp(COMPILER), 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
             '-no-stdlib', '-no-reflect', '-jvm-target', '17', '-classpath', cp(COMPILE),
             '-d', tmp, *map(str, sources)], 'compile.log')
        for i in range(args.repeat):
            run(['java', '-ea', '-cp', tmp + ':' + cp(RUNTIME), 'org.junit.runner.JUnitCore',
                 *['app.ziziplayer.playback.dsp.'+n for n in TESTS]], f'junit-{i+1}.log')
    print('PASS: DSP JVM tests only; full Android integration remains in Gradle CI.')


if __name__ == '__main__':
    main()
