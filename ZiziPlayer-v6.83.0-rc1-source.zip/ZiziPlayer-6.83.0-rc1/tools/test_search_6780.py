#!/usr/bin/env python3
"""Executed production Java + source/SQL contracts; not a Kotlin/Compose build."""
from pathlib import Path
import re, subprocess, tempfile, unittest, sqlite3
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(p): return (SRC/p).read_text()
class Search6780(unittest.TestCase):
    def test_production_policy_and_geometry(self):
        with tempfile.TemporaryDirectory() as out:
            files = [SRC/'ui/SearchSuggestionPolicy.java', SRC/'ui/SearchEditorGeometry.java',
                ROOT/'app/src/test/java/app/ziziplayer/ui/Search6780Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            run = subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Search6780Checks'],check=True,capture_output=True,text=True)
            self.assertIn('production suggestion/geometry assertions passed',run.stdout)
            print(run.stdout.strip())
    def test_kotlin_imports_follow_the_package_declaration(self):
        # A text-only import audit must catch file annotations before the package too.
        for path in (ROOT/'app/src').rglob('*.kt'):
            text = path.read_text()
            package = re.search(r'^package[ \t]+[\w.]+', text, re.M)
            self.assertIsNotNone(package, str(path))
            for imported in re.finditer(r'^import[ \t]+', text, re.M):
                self.assertGreater(imported.start(), package.start(), str(path))

    def test_sources_do_not_pollute_one_another(self):
        vm=read('ui/SearchViewModel.kt')
        self.assertIn('remoteSuggestions: List<String>',vm)
        self.assertIn('remoteSuggestions = fetched, suggestionsLoading = false',vm)
        self.assertIn('current.field, current.remoteSuggestions, current.history, metadata',vm)
        self.assertNotIn('completions(query, current.suggestions',vm)
        self.assertGreaterEqual(vm.count('isCurrentSuggestion(query, generation)'),3)
        self.assertIn('currentCoroutineContext().ensureActive()',vm)
        typing=vm.split('fun onField(text:')[1].split('private fun refreshSuggestions')[0]
        self.assertNotIn('repo.rememberQuery',typing)
    def test_history_is_atomic_and_clear_removes_query_recents_only(self):
        dao=read('data/MusicDao.kt')
        for name in ['rememberSearchQuery','forgetSearchQuery','clearSearchQueries','forgetSearchRecent','clearSearchRecents']:
            self.assertIn('@Transaction\n    suspend fun '+name,dao)
        self.assertIn('it.equals(text, ignoreCase = true)',dao)
        sql=re.search(r'@Query\("([^"]+)"\) suspend fun clearRecentQueries',dao)[1]
        db=sqlite3.connect(':memory:')
        db.execute('create table recents(kind text)')
        kind=re.search(r'const val QUERY = "([^"]+)"',read('data/Entities.kt'))[1]
        db.executemany('insert into recents values (?)',[(kind,),('track',),('album',)])
        db.execute(sql)
        self.assertEqual(db.execute('select kind from recents order by kind').fetchall(),[('album',),('track',)])
        repo=read('data/MusicRepository.kt')
        self.assertIn('dao.clearSearchRecents()',repo)
        self.assertIn('dao.forgetSearchRecent(key)',repo)
    def test_preview_has_bounded_mixed_metadata_and_menu(self):
        catalog=read('data/remote/DeezerCatalog.kt').split('override suspend fun preview')[1].split('override suspend fun discover')[0]
        self.assertIn('RemoteKind.TRACK to 6, RemoteKind.ALBUM to 2',catalog)
        self.assertIn('tracks.take(3) + albums + tracks.drop(3)',catalog)
        self.assertNotIn('resolveStream',catalog)
        ui=read('ui/screens/SearchScreen.kt').split('internal fun SuggestBody(')[1].split('// ------------------------------------------------------------------ results')[0]
        for token in ['ResultTrackRow(', 'ResultGroupRow(', 'onMenu = { onTrackMenu(track) }',
                      'rememberLazyListState()', 'key(SearchSuggestionPolicy.normalize(field))', 'SearchRecent', 'SearchFill',
                      'Недавний запрос', 'Modifier.size(48.dp)']:
            self.assertIn(token,ui)
        self.assertNotIn('rotationZ = 45f',ui)
    def test_shared_modal_color_not_amoled_or_artwork(self):
        theme=read('ui/theme/ZiziTheme.kt')
        self.assertIn('val ZiziModalSurface = Color(0xFF1F1F1F)',theme)
        self.assertIn('surface = Color(0xFF101010)',theme) # no broad player/page recoloring
        self.assertIn('surfaceContainerHigh = ZiziModalSurface',theme)
        for path in SRC.rglob('*.kt'):
            text=path.read_text()
            for call in re.finditer(r'\bAlertDialog\(',text):
                head=text[call.end():].split('title =',1)[0]
                self.assertIn('containerColor = ZiziModalSurface',head,str(path))
                self.assertIn('tonalElevation = 0.dp',head,str(path))
        self.assertIn('containerColor = ZiziModalSurface',read('ui/screens/Sheets.kt'))
        self.assertIn('color = ZiziModalSurface',read('ui/screens/SearchTrackMenuSheet.kt'))
        self.assertIn('private val ConnectSurface = ZiziModalSurface',read('ui/screens/AudioOutputSheet.kt'))
        self.assertIn('color = ZiziModalSurface',read('ui/components/VaultAuthDialog.kt'))
    def test_editor_keeps_selection_focus_and_accessible_targets(self):
        ui=read('ui/screens/SearchScreen.kt').split('internal fun SearchField(')[1].split('\n@Composable', 1)[0]
        self.assertIn('TextFieldValue(text, TextRange(text.length))',ui)
        self.assertIn('editing = it',ui)
        self.assertIn('if (it.text != text) onText(it.text)',ui)
        self.assertIn('fontWeight = FontWeight.Normal',ui)
        self.assertNotIn('.border(',ui)
        self.assertIn('keyboard?.show()',ui)
        self.assertNotIn('LaunchedEffect(ime',ui)
if __name__=='__main__': unittest.main(verbosity=2)
