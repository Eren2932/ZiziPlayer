#!/usr/bin/env python3
"""Regression for the 6.69.4 androidTest compile failure; not a Kotlin compiler.

Exercise the actual checker CLI, including the source-root argument and a mutation
of the production Android fixture. A wildcard in ui.test does NOT import ui.platform.
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / 'tools/check_imports.py'
CAMERA = ROOT / 'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt'
IMPORT = 'import androidx.compose.ui.platform.testTag\n'


class ImportRegression6695(unittest.TestCase):
    def run_fixture(self, source, scope='androidTest', args=('app/src',)):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'app/src/main/java').mkdir(parents=True)
            path = root/'app/src'/scope/'java/Fixture.kt'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(source, encoding='utf-8')
            return subprocess.run([sys.executable, str(CHECKER), *args], cwd=root,
                                  capture_output=True, text=True, timeout=20)

    def fixture(self, imports='', expression='Modifier.testTag("camera")'):
        return ('package fixture\nimport androidx.compose.ui.Modifier\n' + imports +
                '\nfun fixture() = ' + expression + '\n')

    def test_missing_import_is_rejected_in_every_source_set(self):
        for scope in ('main', 'test', 'androidTest'):
            with self.subTest(scope=scope):
                result = self.run_fixture(self.fixture(), scope=scope)
                self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
                self.assertIn('testTag', result.stdout)
                self.assertIn(scope, result.stdout)

    def test_ui_test_wildcard_does_not_import_platform_extension(self):
        result = self.run_fixture(self.fixture('import androidx.compose.ui.test.*\n'))
        self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
        self.assertIn('androidx.compose.ui.platform.testTag', result.stdout)

    def test_explicit_and_platform_wildcard_imports_are_accepted(self):
        for imports in (IMPORT, 'import androidx.compose.ui.platform.*\n'):
            with self.subTest(imports=imports):
                result = self.run_fixture(self.fixture(imports))
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_alias_does_not_import_the_original_name(self):
        imports = 'import androidx.compose.ui.platform.testTag as tagged\n'
        bad = self.run_fixture(self.fixture(imports))
        self.assertEqual(bad.returncode, 1, bad.stdout + bad.stderr)
        good = self.run_fixture(self.fixture(imports, 'Modifier.tagged("camera")'))
        self.assertEqual(good.returncode, 0, good.stdout + good.stderr)

    def test_strings_and_comments_do_not_trigger_a_diagnostic(self):
        source = '''package fixture
// Modifier.testTag("camera")
/* Modifier.testTag("camera") */
val text = "Modifier.testTag()"
val raw = """Modifier.testTag("camera")"""
'''
        result = self.run_fixture(source)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_default_remains_main_only_but_explicit_root_is_honoured(self):
        result = self.run_fixture(self.fixture(), args=())
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self.run_fixture(self.fixture(), args=('app/src/androidTest',))
        self.assertEqual(result.returncode, 1, result.stdout + result.stderr)

    def test_invalid_root_and_extra_arguments_fail(self):
        for args in (('missing',), ('app/src', 'ignored')):
            with self.subTest(args=args):
                result = self.run_fixture(self.fixture(), args=args)
                self.assertEqual(result.returncode, 2, result.stdout + result.stderr)

    def test_real_camera_fixture_passes_and_missing_import_mutation_fails(self):
        source = CAMERA.read_text(encoding='utf-8')
        self.assertEqual(source.count(IMPORT), 1)
        result = self.run_fixture(source)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self.run_fixture(source.replace(IMPORT, ''))
        self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
        self.assertIn('androidx.compose.ui.platform.testTag', result.stdout)

    def test_all_project_source_sets_pass(self):
        result = subprocess.run([sys.executable, str(CHECKER), 'app/src'], cwd=ROOT,
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
