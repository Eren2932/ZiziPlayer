#!/usr/bin/env python3
"""Execute production Java policies/parser against sanitized provider timings.
Kotlin networking checks below are source contracts, NOT a coroutine/HTTP runtime test.
"""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
F = R / 'tools/fixtures/lyrics_6611'

class Lyrics6611Tests(unittest.TestCase):
    def test_live_snapshot_with_production_java(self):
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', tmp,
                str(S/'lyrics/LrcTimeline.java'), str(S/'lyrics/LyricsMatchPolicy.java'),
                str(S/'lyrics/LyricsLookupTrace.java'), str(F/'Lyrics6611Checks.java')], check=True)
            subprocess.run(['java', '-cp', tmp, 'Lyrics6611Checks', str(F/'raya-synthetic.lrc')], check=True)

    def test_snapshot_distinguishes_tracks(self):
        evidence = json.loads((F/'provider-metadata.json').read_text())
        raya = evidence['raya']
        self.assertEqual(raya['id'], 38647172)
        self.assertEqual(raya['duration'], 130.0)
        self.assertGreater(raya['synced_chars'], 0)
        self.assertFalse(raya['instrumental'])
        self.assertEqual(evidence['senemene']['search_row_counts'], [0, 0, 0, 0])
        self.assertEqual(evidence['senemene']['exact_http_status'], 404)

    def test_exact_outage_fallback_is_bounded_and_not_negative_cache(self):
        source = (S/'lyrics/LyricsRepository.kt').read_text()
        exact = source.split('val exact = try')[1].split('if (candidates.none')[0]
        for text in ('catch (e: CancellationException) { throw e }',
                     'e is AudioBusy || e is DeferredLyrics -> throw e',
                     'e is HttpFailure && e.status < 500 -> throw e',
                     'exactFailure = e'):
            self.assertIn(text, exact)
        self.assertIn(').firstOrNull() ?: return if (exactFailure != null) throw exactFailure else null', source)
        self.assertEqual(source.count('misses[id] ='), 1)
        self.assertIn('if (e is NoLyrics) misses[id] =', source)
        self.assertEqual(source.count('http(request(builder.build()))'), 2)
        self.assertIn('for (includeArtist in listOf(true, false))', source)
        hybrid = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        self.assertIn('backoffUntil[provider.id] = clockMs() + 60_000L', hybrid)

    def test_copy_diagnostics_and_no_audio_auth(self):
        state = (S/'ui/screens/LyricsUiState.kt').read_text()
        self.assertIn('diagnostic = trace.render()', state)
        self.assertIn('Lookup durationMs=${current.durationMs}', state)
        self.assertIn('trace = trace', state)
        screen = (S/'ui/screens/LyricsScreen.kt').read_text()
        self.assertIn('Копировать диагностику', screen)
        self.assertIn('Catalogue durationMs=${track.durationMs}', screen)
        source = (S/'lyrics/LyricsRepository.kt').read_text()
        self.assertNotIn('authHeaders', source)
        self.assertNotIn('request.url.toString()', source)
        for reason in ('identity', 'text duration', 'empty text', 'invalid LRC'):
            self.assertIn('reject("Rejected: ' + reason + '")', source)
        self.assertIn("'test_lyrics_6611.py'", (R/'tools/check_selftest.py').read_text())

if __name__ == '__main__':
    unittest.main(verbosity=2)
