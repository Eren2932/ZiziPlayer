#!/usr/bin/env python3
"""Run production Java + SQL; source guards are NOT an Android/Compose test run."""
from pathlib import Path
import re
import sqlite3
import subprocess
import tempfile
import unittest
from test_home_6470_contracts import setup_old_database, migration_sql

R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
def read(path): return (S / path).read_text()
def query(method):
    match = re.search(r'@Query\("([^"\n]+)"\)\s+(?:suspend )?fun '+method+r'\(', read('data/MusicDao.kt'))
    assert match, method
    return match.group(1)

class Reorder66919(unittest.TestCase):
    def test_production_java_exhaustive_moves_and_edge_scroll(self):
        with tempfile.TemporaryDirectory(prefix='zizi-reorder-') as work:
            sources = [S/'ui/ReorderMath.java', R/'app/src/test/java/app/ziziplayer/ui/Reorder66919Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', work, *map(str, sources)], check=True)
            subprocess.run(['java', '-cp', work, 'app.ziziplayer.ui.Reorder66919Checks'], check=True)

    def database(self):
        db = setup_old_database(); self.addCleanup(db.close)
        for sql in migration_sql('9_10'): db.execute(sql)
        return db

    def test_migration_preserves_existing_data_and_matches_defaults(self):
        db = self.database()
        old_tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        old = {t: db.execute(f'SELECT * FROM {t}').fetchall() for t in old_tables}
        sql = migration_sql('10_11'); self.assertEqual(len(sql), 3)
        for statement in sql: db.execute(statement)
        for table, rows in old.items():
            actual = db.execute(f'SELECT * FROM {table}').fetchall()
            self.assertEqual(rows, [r[:-1] for r in actual] if table == 'playlists' else actual)
        columns = {r[1]: r for r in db.execute('PRAGMA table_info(collection_order)')}
        self.assertEqual(set(columns), {'scope', 'trackId', 'position'})
        self.assertEqual([columns[x][5] for x in ('scope', 'trackId', 'position')], [1, 2, 0])
        self.assertEqual([columns[x][3] for x in columns], [1, 1, 1])
        column = next(r for r in db.execute('PRAGMA table_info(playlists)') if r[1] == 'followFirstTrack')
        self.assertEqual(column[2:5], ('INTEGER', 1, '0'))
        self.assertIn('MIGRATION_10_11', read('ZiziApplication.kt'))
        self.assertNotIn('fallbackToDestructiveMigration', read('ZiziApplication.kt'))

    def test_orders_are_independent_and_survive_reopen(self):
        with tempfile.TemporaryDirectory() as work:
            filename = str(Path(work)/'order.db'); db = sqlite3.connect(filename)
            for statement in migration_sql('10_11')[:2]: db.execute(statement)
            db.executemany('INSERT INTO collection_order VALUES(?,?,?)', [('TRACKS','b',0),('TRACKS','a',1),('FAVORITES','a',0),('FAVORITES','b',1)])
            db.commit(); db.close(); db = sqlite3.connect(filename); self.addCleanup(db.close)
            self.assertEqual([('b',),('a',)], db.execute(query('observeCollectionOrder'), {'scope':'TRACKS'}).fetchall())
            self.assertEqual([('a',),('b',)], db.execute(query('observeCollectionOrder'), {'scope':'FAVORITES'}).fetchall())
            db.execute(query('clearCollectionOrder'), {'scope':'TRACKS'})
            self.assertEqual(2, db.execute('SELECT COUNT(*) FROM collection_order').fetchone()[0])

    def test_first_track_cover_follows_reorder_and_cannot_be_repinned_by_import(self):
        db = self.database()
        for statement in migration_sql('10_11'): db.execute(statement)
        db.execute("INSERT INTO playlists(id,name,createdAt,coverUri) VALUES(99,'test',123,'album-cover')")
        db.executemany('INSERT INTO playlist_tracks VALUES(?,?,?)', [(99,'a',0),(99,'b',1),(99,'c',2)])
        db.commit()
        with db:
            for i,key in enumerate(['c','a','b']): db.execute(query('setPlaylistPosition'), {'id':99,'trackId':key,'position':i})
            db.execute(query('followFirstPlaylistTrack'), {'id':99})
        self.assertEqual([('c',),('a',),('b',)], db.execute(query('orderedPlaylistIds'), {'id':99}).fetchall())
        self.assertEqual((None,1), db.execute('SELECT coverUri,followFirstTrack FROM playlists WHERE id=99').fetchone())
        db.execute(query('setPlaylistCoverIfEmpty'), {'id':99,'uri':'next-album'})
        self.assertEqual((None,), db.execute('SELECT coverUri FROM playlists WHERE id=99').fetchone())
        # Failed transaction must not expose partially renumbered rows.
        db.commit()
        try:
            with db:
                db.execute(query('setPlaylistPosition'), {'id':99,'trackId':'a','position':0})
                raise RuntimeError('injected write failure')
        except RuntimeError: pass
        self.assertEqual([('c',),('a',),('b',)], db.execute(query('orderedPlaylistIds'), {'id':99}).fetchall())

    def test_queue_mutates_timeline_without_restarting_playback(self):
        source = read('playback/PlayerController.kt')
        body = source.split('fun reorderQueue(',1)[1].split('fun seekToTrack(',1)[0]
        for forbidden in ('p.setMediaItems(', 'p.seekTo(', 'p.prepare(', 'p.stop(', 'p.pause('): self.assertNotIn(forbidden, body)
        self.assertIn('p.moveMediaItem(', body)
        self.assertIn('live.filter { it in members } != before', body)
        self.assertIn('zizi.queueEntry', source)
        self.assertIn('cachedQueueKeys', source)
        self.assertIn('queueUris = (0 until p.mediaItemCount)', source)

    def test_ui_owns_down_and_commits_only_on_release(self):
        source = read('ui/components/TrackReorder.kt')
        self.assertIn('down.consume()', source)
        self.assertIn('awaitPointerEvent(PointerEventPass.Main)', source)
        self.assertIn('awaitLongPressOrCancellation', source)
        frame = source.split('suspend fun frame(',1)[1].split('fun translation(',1)[0]
        self.assertNotIn('commit(', frame)
        self.assertIn('list.scrollBy(distance)', frame)
        self.assertIn('it.index == firstRowIndex', frame)
        self.assertIn('it.index == firstRowIndex + items.lastIndex', frame)
        self.assertIn('layout.beforeContentPadding, topInsetPx', frame)
        self.assertIn('layout.afterContentPadding, usableTop', frame)
        self.assertIn('last.offset + last.size - usableBottom', frame)
        self.assertIn('withFrameNanos', source)
        self.assertIn('CustomAccessibilityAction', source)
        self.assertIn('if (incoming != beforeKeys) cancel()', source)
        for name in ('UnifiedLocalCollectionScreen.kt','LocalCollectionScreen.kt','Sheets.kt'):
            screen = read('ui/screens/'+name)
            self.assertIn('rememberTrackReorder', screen)
            self.assertIn('.reorderHandle(', screen)
            self.assertIn('.reorderRow(', screen)
            self.assertIn('.animateItem(', screen)
        self.assertIn('reorderListState = list', read('ui/screens/UnifiedLocalCollectionScreen.kt'))
        self.assertIn('state.query.isBlank()', read('ui/screens/UnifiedLocalCollectionScreen.kt'))
        self.assertIn('firstChanged || next.firstOrNull()', read('data/MusicDao.kt'))

if __name__ == '__main__': unittest.main(verbosity=2)
