#!/usr/bin/env python3
"""Java validator execution + Kotlin source guards. NOT execution of coroutine tests/HTTP."""
from pathlib import Path
import subprocess
import tempfile
import unittest

R = Path(__file__).resolve().parents[1]
S = R/'app/src/main/java/app/ziziplayer'
T = R/'app/src/test/java/app/ziziplayer/lyrics'

class HybridContracts(unittest.TestCase):
    def test_production_java_validator(self):
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', tmp,
                str(S/'lyrics/LyricsFallbackText.java'), str(T/'LyricsFallbackChecks.java')], check=True)
            subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.lyrics.LyricsFallbackChecks'], check=True)

    def test_bounded_independent_sources(self):
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        hybrid = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        for value in ('LyricsHybridLookup(', 'OvhLyricsProvider()', 'override val requestLimit: Int = 3',
                      '26_000L', 'get(request, awaitNetworkSlot, trace, provider.id)'):
            self.assertIn(value, repo)
        for value in ('backoffUntil[provider.id]', '60_000L', 'withTimeoutOrNull(provider.budgetMs)',
                      'withTimeoutOrNull(provider.requestTimeoutMs)', '++requests > provider.requestLimit',
                      'catch (e: CancellationException)', 'catch (e: LyricsRepository.AudioBusy)',
                      'firstFailure ?: LyricsRepository.NoLyrics'):
            self.assertIn(value, hybrid)
        self.assertNotIn('providerBackoffUntil', repo)
        self.assertEqual(repo.count('misses[id] ='), 1)
        self.assertIn('if (e is NoLyrics) misses[id] =', repo)

    def test_plain_fallback_is_unverified_and_cannot_create_sync(self):
        provider = (S/'lyrics/OvhLyricsProvider.kt').read_text()
        for value in ('https://api.lyrics.ovh/v1', 'addPathSegment(track.artist.trim())',
                      'addPathSegment(track.title.trim())', 'e.status == 404',
                      'LyricsFallbackText.clean', 'json.opt("lyrics") as? String',
                      '.put("matchVerified", false)', '.put("syncedLyrics", "")', '.put("duration", 0)'):
            self.assertIn(value, provider)
        for bad in ('searchTitle(', 'LrcTimeline.parse', 'Authorization', 'Cookie', 'track.uri', 'removeSuffix'):
            self.assertNotIn(bad, provider)
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        branch = repo.split('val stored = if (!payload.optBoolean("matchVerified", true))')[1].split('} else try')[0]
        self.assertIn('CachedDocument(found, SystemClock.elapsedRealtime() + FALLBACK_AGE_MS)', branch)
        self.assertNotIn('store(', branch)
        self.assertIn('FALLBACK_AGE_MS = 10L * 60 * 1000', repo)
        self.assertIn('now < it.expiresAt', repo)

    def test_source_and_privacy_notice_are_visible(self):
        # 6.80.0: the preview warning moved into the extracted production card, not removed.
        for name, model in (('LyricsPreviewCard.kt', 'document'), ('LyricsScreen.kt', 'doc')):
            source = (S/'ui/screens'/name).read_text()
            self.assertIn('версия не проверена', source)
            self.assertIn(model + '.matchVerified', source)
        self.assertIn('LyricsPreviewCard(document = doc', (S/'ui/screens/LyricsPreview.kt').read_text())
        self.assertIn('!compact || !doc.matchVerified', (S/'ui/screens/LyricsScreen.kt').read_text())
        notice = (S/'ui/screens/Sheets.kt').read_text()
        self.assertIn('резерв lyrics.ovh', notice)
        self.assertIn('Аудио не отправляется', notice)
        ui = (S/'ui/screens/LyricsUiState.kt').read_text()
        self.assertIn('LRCLIB + lyrics.ovh', ui)
        self.assertIn('withTimeoutOrNull(45_000L)', ui)
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        self.assertIn('.followRedirects(false)', repo)
        self.assertIn('continuation.invokeOnCancellation { call.cancel() }', repo)
        self.assertNotIn('request.url.encodedPath', repo) # OVH path contains user metadata.
        self.assertNotIn('request.url.toString()', repo)

    def test_coroutine_tests_are_present_and_wired_to_gradle(self):
        tests = (T/'LyricsHybridTest.kt').read_text()
        self.assertEqual(tests.count('@Test fun'), 13)
        for method in ('primaryHitDoesNotContactFallback', 'primaryMissUsesRealOvhAdapter',
                       'primary429DoesNotBlockBackupOrNextSongAndExpires',
                       'cancellationAndAudioBusyNeverAdvanceToAnotherProvider',
                       'parentDeadlineIsNotMistakenForProviderTimeout', 'requestLimitIsEnforcedByCoordinator'):
            self.assertIn(method, tests)
        self.assertIn(':app:testDebugUnitTest', (R/'.github/workflows/build.yml').read_text())
        self.assertIn('testImplementation("org.json:json:20240303")', (R/'app/build.gradle.kts').read_text())
        self.assertIn("'test_lyrics_hybrid_6620.py'", (R/'tools/check_selftest.py').read_text())

    def test_cancellation_regressions_and_recovery_are_preserved(self):
        tests = (T/'LyricsHybridCancellationTest.kt').read_text()
        self.assertEqual(tests.count('@Test fun'), 8)
        for method in ('cancelledCallerDoesNotStartProvider', 'cancelledProviderCannotInvokeTransport',
                       'cancelledProviderCannotAdvanceAfterIoFailure',
                       'cancellingRunningRequestCleansUpAndNeverStartsBackup'):
            self.assertIn(method, tests)
        primary = (T/'LyricsHybridTest.kt').read_text()
        self.assertNotIn('assertSame(reason,', primary)
        self.assertIn('assertEquals(reason.javaClass, observed.javaClass)', primary)
        self.assertIn('assertEquals(reason.message, observed.message)', primary)
        coordinator = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        self.assertIn('currentCoroutineContext().ensureActive()', coordinator)
        gradle = (R/'app/build.gradle.kts').read_text()
        self.assertIn('it.systemProperty("kotlinx.coroutines.debug", "on")', gradle)
        self.assertIn('it.systemProperty("kotlinx.coroutines.stacktrace.recovery", "true")', gradle)

if __name__ == '__main__': unittest.main(verbosity=2)
