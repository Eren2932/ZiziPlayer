#!/usr/bin/env python3
"""Run real production Java colour math. Not an APK build or Compose rendering test."""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-lyrics-colour-') as out:
    files = ['app/src/main/java/app/ziziplayer/ui/theme/ArtworkColorMath.java',
             'app/src/main/java/app/ziziplayer/ui/theme/LyricsColorMath.java',
             'app/src/test/java/app/ziziplayer/ui/LyricsColorMathChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                    '-d', out, *[str(ROOT / p) for p in files]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.LyricsColorMathChecks',
                    str(ROOT / 'tools/fixtures/artwork')], check=True)
