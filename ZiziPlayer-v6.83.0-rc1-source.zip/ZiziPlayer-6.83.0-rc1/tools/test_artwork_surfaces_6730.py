#!/usr/bin/env python3
"""Run production Java. Requires JDK 17+, not Android SDK. Does not claim Kotlin compilation."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-surfaces-') as out:
    sources = ['app/src/main/java/app/ziziplayer/ui/theme/ArtworkColorMath.java',
               'app/src/main/java/app/ziziplayer/ui/theme/ArtworkSurfaceMath.java',
               'app/src/test/java/app/ziziplayer/ui/ArtworkSurfaceMathChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                    '-d', out, *[str(ROOT / p) for p in sources]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.ArtworkSurfaceMathChecks',
                    str(ROOT / 'tools/fixtures/surfaces-6730')], check=True)
