#!/usr/bin/env python3
"""Production Java execution + source wiring contracts. NOT an APK build or pixel-perfect proof."""
from pathlib import Path
import subprocess
import tempfile
import unittest

R = Path(__file__).resolve().parents[1]
S = R/'app/src/main/java/app/ziziplayer'
def read(p): return (S/p).read_text()

class Profile6700(unittest.TestCase):
    def test_production_math_dates_and_blur(self):
        with tempfile.TemporaryDirectory() as out:
            files = [S/f'ui/{name}.java' for name in ('CollectionGeometry','ProfileGeometry','ProfilePresentation','ProfileBlur')]
            files.append(R/'app/src/test/java/app/ziziplayer/ui/Profile6700Checks.java')
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Profile6700Checks'],check=True)

    def test_real_inline_tabs_and_lazy_membership(self):
        s=read('ui/screens/AccountScreen.kt')
        for text in ['when (tab)', 'ProfileTab.PLAYLISTS', 'ProfileTab.FAVORITES, ProfileTab.DOWNLOADS',
                     'ProfileTab.RECENT', 'rememberSaveable(state.userId)', 'onTrackPlay(track, tracks)',
                     'ProfilePresentation.tracks(', 'contentPadding = PaddingValues(bottom = bottom + 24.dp)']:
            self.assertIn(text,s)
        self.assertNotIn('Аккаунт ZiziPlayer',s)
        self.assertNotIn('Любимые',s)
        self.assertIn('FAVORITES("Избранные")',read('ui/screens/ProfileLibrary.kt'))
        self.assertIn('onTrackPlay = { track, tracks -> vm.play(track, tracks) }',read('MainActivity.kt'))
        self.assertEqual(s.count('ProfilePinnedHeader('),1)
        self.assertEqual(s.count('onClick = onClose'),0)

    def test_blur_bounded_off_main_exact_key_and_no_android31_dependency(self):
        s=read('ui/components/ProfileBackdrop.kt')
        for text in ['LruCache<String, ImageBitmap>(2)', 'key(avatar, source)', 'withContext(Dispatchers.Default)',
                     '128, 128', 'ProfileBlur.blur(pixels, 128, 128, ProfileBlur.BACKDROP_RADIUS)', 'rememberAccountAvatarBitmap(avatar)',
                     'if (small !== source.asAndroidBitmap()) small.recycle()', 'translate(top = -offset)']:
            self.assertIn(text,s)
        for text in ['RenderEffect', 'BlurEffect', 'Build.VERSION', 'Base64.decode', 'Modifier.blur(']:
            self.assertNotIn(text,s)
        screen=read('ui/screens/AccountScreen.kt')
        self.assertIn('profile.userId == state.userId',screen)
        self.assertIn('if (list.firstVisibleItemIndex > 0) maxOf(heroPx.toFloat(), coveredScrollPx)',screen)

    def test_stats_and_privacy_are_real_not_reference_constants(self):
        s=read('ui/screens/ProfileLibrary.kt')
        for text in ['repo.favoriteTracks', 'repo.allTracks', 'repo.hiddenIds', 'repo.vault.state',
                     'raw.hidden == hidden && raw.gate == gate', '!input.gate.blocks(track)',
                     'if (tab == ProfileTab.RECENT)', 'if (tab == ProfileTab.DOWNLOADS)',
                     'flowOn(Dispatchers.IO)', 'flowOn(Dispatchers.Default)',
                     'distinctBy { it.trackId }.take(200)', 'it.durationMs.coerceAtLeast(0)',
                     'it.value::class', 'distinctUntilChanged()']:
            self.assertIn(text,s)
        for text in ['312', '86L *', 'addListener(', 'MediaController']:
            self.assertNotIn(text,s)

    def test_cloud_owner_and_real_status_not_static_green(self):
        self.assertIn('LibrarySyncState(busy = true, ownerId = id)',read('library/LibrarySync.kt'))
        s=read('ui/screens/ProfileComponents.kt')
        self.assertIn('sync.ownerId == account.userId',s)
        self.assertIn('sync.savedAt, now, ZoneId.systemDefault()',s)
        self.assertIn('repeatOnLifecycle(Lifecycle.State.STARTED)',s)
        self.assertIn('derivedStateOf { progress() >= .99f }',s)
        self.assertIn('Modifier.clearAndSetSemantics',s)
        self.assertIn('Role.Tab',s)
        self.assertIn('heightIn(min = 48.dp)',s)

    def test_no_player_dock_or_font_replacement(self):
        for name in ['AccountScreen.kt','ProfileComponents.kt']:
            s=read('ui/screens/'+name)
            self.assertNotIn('FontFamily(',s)
            self.assertNotIn('Icons.Default',s)
            self.assertNotIn('MiniPlayer(',s)
            self.assertNotIn('MediaController',s)
        s=read('MainActivity.kt')
        self.assertEqual(s.count('MiniPlayer('),1)
        self.assertEqual(s.count('.bottomChrome()'),1)

if __name__ == '__main__': unittest.main(verbosity=2)
