#!/usr/bin/env python3
"""Compile and execute the actual production route policy and mini-player geometry."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-output-6750-') as out:
    sources = [ROOT / 'app/src/main/java/app/ziziplayer/playback/AudioRoutePolicy.java',
               ROOT / 'app/src/main/java/app/ziziplayer/ui/components/MiniPlayerGeometry.java',
               ROOT / 'app/src/test/java/app/ziziplayer/playback/AudioOutput6750Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                    *map(str, sources)], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.playback.AudioOutput6750Checks'], check=True)
