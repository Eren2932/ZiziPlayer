#!/usr/bin/env python3
"""Real JVM material tests and source wiring guards; does not compile Kotlin/Android."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'app/src/main/java/app/ziziplayer/ui/CameraMorphGeometry.java'
CHECKS = ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph6696Checks.java'
OVERLAY = ROOT/'app/src/main/java/app/ziziplayer/ui/components/CollectionCoverMorph.kt'

class CameraMaterial6696(unittest.TestCase):
    def run_java(self, source):
        with tempfile.TemporaryDirectory() as tmp:
            local = Path(tmp)/'CameraMorphGeometry.java'
            local.write_text(source)
            result = subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17',
                '-d',tmp,str(local),str(CHECKS)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraMorph6696Checks'],
                capture_output=True,text=True)

    def test_production_material(self):
        run=self.run_java(SOURCE.read_text())
        self.assertEqual(run.returncode,0,run.stderr)
        print(run.stdout,flush=True)

    def test_regressions_fail_assertions(self):
        original=SOURCE.read_text()
        mutations={
            'old_global_dimmer': ('smoother((p - .78f) / .20f)', 'smooth((p - .12f) / .70f)'),
            'no_blur': ('return .075f * smoother(', 'return 0f * smoother('),
            'blur_step_on_reverse': ('smoother(unit(progress) / .65f)', '(unit(progress) > .2f ? 1f : 0f)'),
            'artwork_leads': ('double cameraShare = lerp(1f, CAMERA_SHARE,', 'double cameraShare = lerp(.5f, CAMERA_SHARE,'),
            'sharp_waist': ('double trim = .20 * smoother(', 'double trim = 0 * smoother('),
            'instant_neck': ('return table(WAIST_U, WAIST_V, u);', 'return 2.62f + 0f * table(WAIST_U, WAIST_V, u);'),
            'collapsed_gradient': ('inkEnd - .8f * U);', 'inkEnd);'),
            'black_expanded_artwork': ('target == null ? 0f : smoother((p - .78f) / .20f)', '1f'),
        }
        for name,(before,after) in mutations.items():
            with self.subTest(name=name):
                self.assertEqual(original.count(before),1)
                result=self.run_java(original.replace(before,after))
                self.assertNotEqual(result.returncode,0,'Surviving mutation: '+name)
                self.assertIn('AssertionError',result.stderr)
                print('Mutation rejected:',name,flush=True)

    def test_blur_is_inside_parent_shape_and_contact_is_outside_blur(self):
        s=OVERLAY.read_text()
        self.assertLess(s.index('val silhouette = cameraMorphSilhouette(body, flesh)'),s.index('val ink = g?.let'))
        self.assertIn('sourceLayer.renderEffect =', s)
        self.assertLess(s.index('drawLayer(sourceLayer)'), s.index('drawRect(ink,'))
        self.assertEqual(s.count('sourceLayer.record { this@onDrawWithContent.drawContent() }'), 1)
        self.assertNotIn('.graphicsLayer {', s)
        for required in ['Build.VERSION.SDK_INT >= 31', 'size.minDimension * M.blurFraction(f.progress)',
                         'M.goo(target, frame.value)', 'M.maxSwellPx(target)', 'setGoo(commands',
                         'saveLayer(bounds, fadePaint)', 'drawContext.canvas.restore()',
                         'this@onDrawWithContent.drawContent()', '!g.joined']:
            self.assertIn(required,s)
        self.assertEqual(s.count('{ artwork() }'),1)
        for forbidden in ['animateFloatAsState', 'LaunchedEffect', 'Bitmap.createBitmap',
                          'rememberArtwork(', '.28f to Color.Black', 'Brush.verticalGradient(']:
            self.assertNotIn(forbidden,s)

    def test_ci_and_android_pixel_tests_are_wired(self):
        self.assertIn('test_camera_material_6696.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraMorph6696Checks.main',(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph6696Test.java').read_text())
        s=(ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        for method in ['bodyDarkeningTracksContactAndReverses66910','blurReducesDetailWithoutDimming6696',
                       'materialRoundTripRestoresTheSamePixels6696']:
            self.assertIn('fun '+method,s)
        self.assertIn('app.ziziplayer.ui.CameraMorph6692UiTest',(ROOT/'tools/run_camera_ci.sh').read_text())
        for api in (28, 35):
            self.assertIn(f'script: bash tools/run_camera_ci.sh {api}',(ROOT/'.github/workflows/build.yml').read_text())

if __name__=='__main__': unittest.main(verbosity=2)
