#!/usr/bin/env python3
"""Production Java execution and source wiring. Neither APK compilation nor device testing."""
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

R=Path(__file__).resolve().parents[1]
S=R/'app/src/main/java/app/ziziplayer'
def read(p): return (S/p).read_text()

class Profile6701(unittest.TestCase):
    def test_production_back_policy_and_blur(self):
        with tempfile.TemporaryDirectory() as out:
            files=[S/'ui/RootBackPolicy.java',S/'ui/ProfileBlur.java',
                   R/'app/src/test/java/app/ziziplayer/ui/Profile6701Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Profile6701Checks'],check=True)

    def test_open_and_close_player_never_dismiss_origin(self):
        main=read('MainActivity.kt')
        mini=main.split('MiniPlayer(',1)[1].split('animateTitle',1)[0]
        self.assertIn('onOpen = { playerOpen = true }',mini)
        for mutation in ('accountOpen =','accountSettings =','closeProfile()','tab ='):
            self.assertNotIn(mutation,mini)
        player=main.split('PlayerScreen(',1)[1].split('// Only the full player',1)[0]
        self.assertIn('onClose = { playerOpen = false }',player)
        self.assertIn('playerOpen = false',main.split('override suspend fun onPreFling',1)[1])
        self.assertIn('onPlayer = { playerOpen = false }',main)
        self.assertIn('eqOpen, playerOpen, mounted, accountSettings, accountOpen, profilePlaylistsOpen)',main)

    def test_covered_children_cannot_steal_back(self):
        main=read('MainActivity.kt')
        self.assertIn('RootBackHandler(target = backTarget,',main)
        self.assertIn('backEnabled = backTarget == RootBackPolicy.Target.CHILD && !accountSettings && !profileEdit',main)
        self.assertIn('backEnabled = backTarget == RootBackPolicy.Target.CHILD && !profileEdit,',main)
        self.assertIn('BackHandler(enabled = fullScreen && backEnabled)',read('ui/screens/Sheets.kt'))
        self.assertIn('BackHandler(enabled = backEnabled)',read('ui/screens/ProfilePlaylistsScreen.kt'))
        handler=read('ui/components/RootBackHandler.kt')
        self.assertIn('BackHandler(enabled = target != RootBackPolicy.Target.CHILD)',handler)
        for route in ('DRAWER -> onDrawer()', 'EQUALIZER -> onEqualizer()', 'PLAYER -> onPlayer()',
                      'PROFILE -> onProfile()', 'CONTENT -> onContent()', 'CHILD -> Unit'):
            self.assertIn(route,handler)

    def test_profile_stays_mounted_behind_manager(self):
        main=read('MainActivity.kt');host=read('ui/components/ProfileDestinationHost.kt')
        self.assertIn('ProfileDestinationHost(managerOpen = profilePlaylistsOpen, profile = {',main)
        self.assertIn('profile()',host)
        self.assertIn('if (managerOpen) Box',host)
        self.assertLess(host.index('profile()'),host.index('if (managerOpen) Box'))
        self.assertIn('if (!managerOpen) drawContent()',host)
        self.assertIn('Modifier.clearAndSetSemantics',host)
        self.assertIn('.surfaceInputBoundary()',host)
        self.assertIn('accountOpen = false; profilePlaylistsOpen = false; profilePlaylistMenu = null',main)

    def test_explicit_library_navigation_is_not_plain_dismiss(self):
        player=read('ui/screens/PlayerScreen.kt'); main=read('MainActivity.kt')
        self.assertEqual(player.count('onNavigateToLibrary()'),3)
        self.assertIn('vm.openArtist(track.artist); onNavigateToLibrary()',player)
        self.assertIn('vm.setFilter(LibraryFilter.FOLDERS); onNavigateToLibrary()',player)
        self.assertIn('closeProfile(); accountSettings = false; playerOpen = false; tab = ZiziTab.LIBRARY',main)
        settings=main.split('SettingsSheet(vm = vm',1)[1].split('onSignOut',1)[0]
        self.assertIn('onOpenEqualizer = { eqOpen = true }',settings)

    def test_blur_only_changes_spatial_radius(self):
        source=read('ui/components/ProfileBackdrop.kt')
        self.assertIn('ProfileBlur.blur(pixels, 128, 128, ProfileBlur.BACKDROP_RADIUS)',source)
        self.assertIn('Color.Black.copy(alpha = .24f)',source)
        self.assertIn('CollectionGeometry.smoothstep(t)',source)
        self.assertIn('withContext(Dispatchers.Default)',source)
        self.assertIn('LruCache<String, ImageBitmap>(2)',source)
        self.assertNotIn('RenderEffect',source)

    def test_ui_regressions_connected_to_existing_ci(self):
        runner=(R/'tools/run_camera_ci.sh').read_text()
        self.assertIn('app.ziziplayer.ui.Profile6701NavigationTest',runner)
        self.assertIn("'test_profile_6701.py'",(R/'tools/check_selftest.py').read_text())

if __name__=='__main__': unittest.main(verbosity=2)
