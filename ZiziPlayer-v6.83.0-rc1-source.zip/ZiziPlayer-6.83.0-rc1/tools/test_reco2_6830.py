#!/usr/bin/env python3
"""Reco 2: production Java arithmetic + Kotlin source wiring, not an Android build."""
import subprocess
import tempfile
import unittest
from pathlib import Path
from reco_eval import evaluate
ROOT=Path(__file__).resolve().parents[1]
J=ROOT/'app/src/main/java/app/ziziplayer'

class Reco2(unittest.TestCase):
    def test_real_java_math(self):
        with tempfile.TemporaryDirectory() as out:
            files=[J/'ui/HomeFeedPolicy.java',J/'ui/HomeRecoPolicy.java',J/'data/remote/RecoQuery.java',
                   ROOT/'app/src/test/java/app/ziziplayer/ui/HomeReco6830Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            result=subprocess.run(['java','-cp',out,'app.ziziplayer.ui.HomeReco6830Checks'],capture_output=True,text=True,check=True)
            self.assertIn('HomeReco6830Checks passed:',result.stdout)
    def test_onboarding_and_feedback_are_connected(self):
        vm=(J/'ui/HomeViewModel.kt').read_text()
        ui=(J/'ui/screens/HomeScreen.kt').read_text()
        for token in ('recoVault.savePicks(', 'recommendations.clear(); feedQueueNext = -1;', 'recoVault.dislikeTrack(', 'recoVault.dislikeArtist('):
            self.assertIn(token,vm)
        for token in ('HomeTasteSheet(taste,', 'home.dislike(track)', 'home.dislike(track, artist = true)', 'home::openTaste'):
            self.assertIn(token,ui)
        self.assertLess(ui.index('item("playlist-heading")'),ui.index('item("quick-actions")'))
    def test_hints_are_opt_in_and_snapshot_is_encrypted(self):
        load=(J/'ui/HomeRecommendations.kt').read_text();vault=(J/'ui/RecoVault.kt').read_text()
        self.assertIn('vaultState.allowTrackHints && it.id == null',load)
        self.assertIn('val allowTrackHints: Boolean = false',vault)
        for token in ('AES/GCM/NoPadding','noBackupFilesDir','AtomicFile','HOME_MAX_AGE_MS','o.optString("key") != privacyKey'):
            self.assertIn(token,vault)
        self.assertIn('vault.readHome(privacyKey(snapshot), now)',load)
        self.assertIn('feed.start(seedProfile, snapshot, builder::recoBlocked)',load)
    def test_small_covers_include_actual_shelf_size(self):
        art=(J/'ui/components/Artwork.kt').read_text()
        self.assertIn('private const val SMALL_NET_PX = 500',art)
        self.assertIn('px <= 500 -> 500',art)
        self.assertIn('CoroutineStart.LAZY',art)
        self.assertIn('ArtworkCache.prefetchUrls(cards.mapNotNull',(J/'ui/HomeRecommendations.kt').read_text())
    def test_eval_exact_numbers_and_leakage(self):
        r=evaluate([dict(train_artist_ids=['1'],heldout_artist_ids=['2','3'],recommended_artist_ids=['4','2','2','3'])],3)
        self.assertEqual(r['recall_macro'],0.5)
        self.assertAlmostEqual(r['ndcg_macro'],(1/( __import__('math').log2(3)))/(1+1/__import__('math').log2(3)))
        with self.assertRaises(ValueError):evaluate([dict(train_artist_ids=['1'],heldout_artist_ids=['1'])])
        self.assertIsNone(evaluate([])['recall_macro'])

if __name__=='__main__':unittest.main(verbosity=2)
