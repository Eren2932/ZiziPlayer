"""Production JVM math + renderer wiring. Android pixel tests run separately."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/ziziplayer/ui'

class CameraStability66912(unittest.TestCase):
    def run_math(self, old_waist=False):
        with tempfile.TemporaryDirectory() as tmp:
            source = (UI/'CameraMorphGeometry.java').read_text()
            if old_waist:
                source = source.replace('{2.45f, 2.62f, 2.83f, 3.07f}', '{2.45f, 2.62f, 2.83f, 3.01f, 3.07f}')
                source = source.replace('{2.62f, 2.20f, 1.10f, 0f}', '{2.62f, 2.43f, 2.00f, 1.30f, 0f}')
            local = Path(tmp)/'CameraMorphGeometry.java'
            local.write_text(source)
            compiled = subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,str(local),
                str(UI/'CollectionGeometry.java'),
                str(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph66912Checks.java')], capture_output=True,text=True)
            self.assertEqual(compiled.returncode,0,compiled.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraMorph66912Checks'],capture_output=True,text=True)

    def test_pixel_sensitivity_and_reversal(self):
        run = self.run_math()
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        print(run.stdout,flush=True)

    def test_old_contact_snap_is_rejected(self):
        run = self.run_math(True)
        self.assertNotEqual(run.returncode,0)
        self.assertIn('neck amplifies scroll too much',run.stderr)

    def test_atomic_transform_and_single_recording(self):
        s = (UI/'components/CollectionCoverMorph.kt').read_text()
        self.assertEqual(s.count('sourceLayer.record { this@onDrawWithContent.drawContent() }'),1)
        artwork = s.split('Box(Modifier.size(maximum)',1)[1]
        self.assertEqual(artwork.count('.drawContent()'),1)
        self.assertIn('val sourceLayer = rememberGraphicsLayer()',s)
        self.assertIn('translate(f.left(), f.top())',s)
        self.assertIn('scale(f.width / size.width, f.height / size.height, Offset.Zero)',s)
        self.assertIn('val g = M.goo(target, f)',s)
        self.assertNotIn('.graphicsLayer {',s)
        self.assertIn('drawLayer(layer)',s)
        self.assertIn('saveLayer(bounds, fadePaint)',s)
        self.assertIn('cameraMorphSilhouette(body, flesh)',s)
        self.assertNotIn('animateFloatAsState',s)

    def test_regressions_are_wired(self):
        self.assertIn('test_camera_stability_66912.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraMorph66912Checks.main',(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraMorph66912Test.java').read_text())
        s = (ROOT/'app/src/androidTest/java/app/ziziplayer/ui/CameraMorph6692UiTest.kt').read_text()
        self.assertIn('listOf(-.28f, 0f, .28f)',s)
        self.assertIn('steps + steps.reversed()',s)
        for name in ['centralBodyBothSidesSurviveContactAndReversal66912','cornerBodyBothSidesSurviveContactAndReversal66912']:
            self.assertIn(name,s)
            self.assertEqual((ROOT/'tools/camera_test_inventory.json').read_text().count(name),2)

if __name__ == '__main__': unittest.main(verbosity=2)
