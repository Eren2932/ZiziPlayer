#!/usr/bin/env python3
"""Kotlin source guards for 6.65.0 parallel LRCLIB/server fix.
These are NOT coroutine runtime or network tests; they verify source-code contracts only.
"""
from pathlib import Path
import unittest

from release_identity import assert_release_at_least

R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
T = R / 'app/src/test/java/app/ziziplayer/lyrics'

class ParallelTimingContracts(unittest.TestCase):

    def test_lrclib_runs_in_parallel_with_server(self):
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        hybrid = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        # parallelCount=2 means LRCLIB + Server launch simultaneously
        self.assertIn('parallelCount = if (server != null) 2 else 1', repo)
        self.assertIn('parallelCount = if (server != null) 2 else 1', repo)
        self.assertIn('parallelCount=2', repo)  # comment in source confirms value
        # Coordinator declares and honours the parameter
        self.assertIn('parallelCount: Int = 1', hybrid)
        self.assertIn('parallelCount in 1..providers.size', hybrid)
        # Budget check uses max of parallel group, not sum
        self.assertIn('maxOf { it.budgetMs }', hybrid)
        self.assertIn('effectiveBudget', hybrid)
        self.assertIn('effectiveBudget <= 34_000L', hybrid)
        # Parallel group uses structured concurrency via Channel
        self.assertIn('runParallelGroup', hybrid)
        self.assertIn('Channel<', hybrid)
        self.assertIn('coroutineScope', hybrid)
        self.assertIn('jobs.forEach { it.join() }', hybrid)

    def test_lrclib_budget_not_reduced_when_server_present(self):
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        # LRCLIB section must declare 26_000L unconditionally, never 20_000L
        lrclib_section = repo.split('override val id: String = "LRCLIB"')[1].split('override val requestLimit')[0]
        self.assertIn('26_000L', lrclib_section)
        self.assertNotIn('20_000L', lrclib_section)
        self.assertNotIn('if (server == null) 26_000L else', repo)

    def test_parallel_early_cancel_on_synced(self):
        hybrid = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        # Synced from any parallel provider triggers early cancellation of siblings
        cancel_block = hybrid.split('runParallelGroup')[1] if 'runParallelGroup' in hybrid else ''
        self.assertIn('jobs.forEach { it.cancel() }', cancel_block)
        # AudioBusy is not swallowed inside runProviderSafe (must propagate)
        self.assertIn('catch (e: LyricsRepository.AudioBusy) { throw e }', hybrid)
        # CancellationException propagates
        self.assertIn('catch (e: CancellationException) { throw e }', hybrid)

    def test_parallel_test_class_present_and_sufficient(self):
        tests = (T/'LyricsHybridParallelTest.kt').read_text()
        self.assertGreaterEqual(tests.count('@Test fun'), 10)
        for method in ('lrclibSyncedWinsImmediately',
                       'serverPlainWithLrclibMissReturnsServerPlain',
                       'bothParallelMissTriggersSequentialTail',
                       'audioBusyFromParallelStopsEverything',
                       'cancellationFromParallelPropagates',
                       'budgetConstraintUsesParallelMax'):
            self.assertIn(method, tests)
        self.assertIn('parallelCount = 2', tests)

    def test_version_updated_throughout(self):
        gradle = (R/'app/build.gradle.kts').read_text()
        assert_release_at_least(self, gradle, 124, '6.68.0')
        state = (S/'ui/screens/LyricsUiState.kt').read_text()
        self.assertIn('6.65.0', state)
        server = (S/'lyrics/ServerLyricsProvider.kt').read_text()
        self.assertIn('6.65.0', server)
        repo = (S/'lyrics/LyricsRepository.kt').read_text()
        self.assertIn('6.65.0', repo)
        self.assertIn("'test_lyrics_6640.py'", (R/'tools/check_selftest.py').read_text())

    def test_backwards_compatible_single_provider_unchanged(self):
        hybrid = (S/'lyrics/LyricsHybridLookup.kt').read_text()
        # parallelCount=1 path skips the channel and uses runProviderSafe directly
        self.assertIn('parallelGroup.size == 1', hybrid)
        self.assertIn('skip channel overhead', hybrid)
        # Sequential tail loop still honours upgradePlain semantics
        self.assertIn('sequentialTail', hybrid)

if __name__ == '__main__':
    unittest.main(verbosity=2)
