import cv2,numpy as np,json
from scipy.optimize import least_squares
from pathlib import Path
import argparse
parser=argparse.ArgumentParser(description='Reference-specific reverse-video measurement; requires OpenCV, numpy and scipy. NOT Android rendering.')
parser.add_argument('video', type=Path)
parser.add_argument('output', type=Path)
args=parser.parse_args()
c=cv2.VideoCapture(str(args.video));rows=[]
if not c.isOpened(): raise SystemExit('Cannot open reference video')
for i in range(1101):
 ok,f=c.read()
 if not ok:break
 if i<850 or i%5:continue
 rgb=f[:,:,::-1].astype(float)
 mask=((rgb[:,:,0]>rgb[:,:,1]*1.28)&(rgb[:,:,0]>80)).astype('uint8');mask[:120]=0;mask[450:]=0;mask[:,:420]=0;mask[:,660:]=0
 n,lab,stats,cents=cv2.connectedComponentsWithStats(mask)
 candidates=[k for k in range(1,n) if stats[k,4]>500 and abs(cents[k,0]-540)<30]
 if not candidates:continue
 k=max(candidates,key=lambda k:stats[k,4]);x,y,w,h,_=stats[k];cy_guess=y+h-w/2
 pts=[]
 for yy in range(int(cy_guess),y+h-3):
  xs=np.where(lab[yy]==k)[0]
  if len(xs)>20:pts.extend([(xs.min(),yy),(xs.max(),yy)])
 pts=np.array(pts)
 if len(pts)<8:continue
 def fun(p):return np.hypot(pts[:,0]-p[0],pts[:,1]-p[1])-p[2]
 res=least_squares(fun,[540,cy_guess,w/2],loss='soft_l1',f_scale=1)
 cx,cy,r=res.x;top=cy-r;u=(top-87)/18.5
 roi=rgb[int(cy+.30*r):int(cy+.65*r),int(cx-.3*r):int(cx+.3*r)]
 rows.append(dict(frame=i,t=c.get(cv2.CAP_PROP_POS_MSEC)/1000,cx=cx,cy=cy,radius=r,top=top,u=u,median_residual=float(np.median(abs(fun(res.x)))),lower_body_rgb=roi.mean(axis=(0,1)).round(2).tolist()))
if not rows or not any(4.1<=row['u']<=4.5 for row in rows): raise SystemExit('Expected reference frames not found')
baseline=np.mean([row['lower_body_rgb'] for row in rows if 4.1<=row['u']<=4.5],axis=0)
weights=np.array([.2126,.7152,.0722]);base=baseline@weights
for row in rows: row['relative_srgb_luma']=round(float(np.array(row['lower_body_rgb'])@weights/base),5)
args.output.write_text(json.dumps(dict(note='Sequential VFR decode; normalized gamma-encoded RGB luma, not physical luminance. Camera bottom=87px, radius=18.5px; fits from lower circular boundary. Compressed video and artwork/blur add uncertainty.',baseline_rgb=baseline.tolist(),frames=rows),indent=2))
for row in rows[::3]:print(row['frame'],round(row['t'],3),'u',round(row['u'],3),'dark',round(1-row['relative_srgb_luma'],3),'error',round(row['median_residual'],2))
