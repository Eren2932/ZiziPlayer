import app.ziziplayer.ui.CameraMorphGeometry;
import app.ziziplayer.ui.CollectionHeaderGeometry;
import java.awt.Color;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/** Desktop geometry/raster regression, NOT evidence of Android/Skia execution. */
public final class CameraDropPixelProbe6699 {
    private static int fixtures;
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static Path2D path(float[] commands) {
        Path2D result = new Path2D.Float();
        for (int i = 0; i < commands.length;) {
            int op = (int) commands[i++];
            if (op == 0) { result.moveTo(commands[i], commands[i+1]); i += 2; }
            else if (op == 1) {
                result.curveTo(commands[i], commands[i+1], commands[i+2], commands[i+3],
                    commands[i+4], commands[i+5]); i += 6;
            } else if (op == 2) result.closePath();
            else throw new AssertionError("Unknown opcode");
        }
        return result;
    }
    private static boolean fits(Path2D path, int x, int y, boolean inside) {
        Area remainder = new Area(new Rectangle2D.Float(x-.5f, y-.5f, 2f, 2f));
        if (inside) remainder.subtract(new Area(path));
        else remainder.intersect(new Area(path));
        return remainder.isEmpty();
    }
    private static int raster(Path2D path, int width, int height, int x, int y) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        var g = image.createGraphics();
        g.setColor(new Color(48,64,80)); g.fillRect(0,0,width,height);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Color.BLACK); g.fill(path); g.dispose();
        return image.getRGB(x,y) & 0xffffff;
    }
    private static void fixture(float width, float density, float status, boolean diagnostic) {
        float d = status * .55f;
        var target = new CameraMorphGeometry.Target(width/2-d/2, status*.5f-d/2,
            width/2+d/2, status*.5f+d/2);
        float unit = CollectionHeaderGeometry.unit(width/density);
        float maximum = CollectionHeaderGeometry.COVER_SIZE * unit * density;
        float minimum = Math.min(maximum, Math.max(maximum*.44f, 64*density));
        float top = CollectionHeaderGeometry.COVER_TOP * unit * density;
        float travel = minimum + top;
        boolean found = false;
        for (int step = 15; step <= 65; step++) {
            var frame = CameraMorphGeometry.frame(maximum, minimum, 1, step/100f*travel,
                width/2, status+top, 0, travel, status, target);
            var goo = CameraMorphGeometry.goo(target, frame);
            if (goo == null || goo.joined || goo.ink == null || goo.flesh == null ||
                goo.u < 3.10f || goo.u > 3.65f) continue;
            Path2D ink = path(goo.ink), flesh = path(goo.flesh);
            // The legacy rounded-pixel defect was specific to the 6.69.9 curve.
            // Current curves are validated by whole-pixel inclusion, not by requiring
            // an obsolete midpoint to fail on a different geometry.
            int x = (int)Math.floor(target.cx()), y = -1;
            for (int candidate = (int)Math.ceil(target.bottom); candidate < (int)Math.floor(goo.ink[9]); candidate++) {
                if (fits(ink,x,candidate,true)) { y = candidate; break; }
            }
            if (y < 0) continue;
            int gx = (int)Math.floor((goo.ink[8]+goo.flesh[1])*.5f);
            int gy = (int)Math.floor((goo.ink[9]+goo.flesh[2])*.5f);
            if (!fits(ink,gx,gy,false) || !fits(flesh,gx,gy,false)) continue;
            require(y >= target.bottom, "Static camera could satisfy the probe");
            require(ink.contains(x,y,1,1), "Not a whole interior pixel");
            require(!flesh.intersects(gx,gy,1,1) && !ink.intersects(gx,gy,1,1), "Gap covered");
            int rgb = raster(ink,(int)Math.ceil(width),(int)Math.ceil(status+100),x,y);
            require(rgb == 0, "Interior probe must be opaque black, got " + rgb);
            if (diagnostic) System.out.printf("New 320x640 probe: drop=(%d,%d) gap=(%d,%d) RGB=%06x%n",x,y,gx,gy,rgb);
            found = true; break;
        }
        require(found,"No safe probe: width="+width+" density="+density+" status="+status);
        // Mirror the new Android seam fixture: probes must actually exist even on
        // the 320x640 emulator, rather than accepting an unexercised assertion.
        var frame = CameraMorphGeometry.frame(maximum, minimum, 1, .5f*travel,
            width/2, status+top, 0, travel, status, target);
        var goo = CameraMorphGeometry.goo(target, frame);
        require(goo != null && goo.flesh != null, "Seam fixture requires extension");
        Path2D silhouette = path(goo.flesh);
        int seamProbes = 0;
        for (int y = (int)Math.ceil(Math.max(status+2,frame.top()-3)); y <= (int)Math.floor(frame.cy); y++) {
            for (int x = (int)Math.floor(frame.left()-2); x <= (int)Math.ceil(frame.left()+frame.width+2); x++) {
                double radial = Math.hypot(x+.5-frame.cx,y+.5-frame.cy);
                if (Math.abs(radial-frame.width*.5)>1.5 || !fits(silhouette,x,y,true)) continue;
                seamProbes++;
            }
        }
        require(seamProbes>0,"No safe seam probe: width="+width+" density="+density+" status="+status);
        fixtures++;
    }
    public static void main(String[] args) {
        fixture(320,1,24,true);
        for (float dpWidth : new float[]{240,320,360,411,420})
            for (float density : new float[]{.75f,1,1.5f,2,2.625f,3,3.5f,4})
                for (float statusDp : new float[]{24,28,32})
                    for (int extraPixel : new int[]{0,1})
                        fixture(Math.round(dpWidth*density)+extraPixel,density,Math.round(statusDp*density),false);
        System.out.println("Safe whole-pixel probes: " + fixtures + " fixtures OK (Java2D, not Android)");
    }
}
