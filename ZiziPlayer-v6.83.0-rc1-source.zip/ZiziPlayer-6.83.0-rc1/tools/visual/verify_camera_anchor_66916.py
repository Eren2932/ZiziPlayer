#!/usr/bin/env python3
"""Offline Gaussian model fed by production Java. NOT Android/Skia GPU verification.
Requires numpy, scipy, opencv-python and matplotlib. Not part of dependency-free CI.
Run: python tools/visual/verify_camera_anchor_66916.py [output-directory]
"""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import numpy as np
from scipy.ndimage import gaussian_filter
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'verification/v6.69.16/raster-model'
OUT.mkdir(parents=True,exist_ok=True)
UI=ROOT/'app/src/main/java/app/ziziplayer/ui'
with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,
        str(UI/'CameraMorphGeometry.java'),str(UI/'CameraGooeyGeometry.java'),
        str(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraAnchor66916Checks.java')],check=True)
    samples=subprocess.check_output(['java','-cp',tmp,'app.ziziplayer.ui.CameraAnchor66916Checks','samples'],text=True)
(OUT/'production-samples.txt').write_text(samples)
rows=np.array([[float(v) for v in line.split()] for line in samples.splitlines()])

# Supersample the reduced layer: do not round moving triangle vertices to integer px.
def field(row, old=False, sigma_mode='radius_to_sigma'):
    d,diam,xf,p,cx,cy,r,blur,*_=row
    scale=.75 # quarter of a production 3px reduced-layer pixel
    pad=max(130,55*d)
    count=int(np.ceil(2*pad/scale))|1
    coords=(np.arange(count)-count//2)*scale
    X,Y=np.meshgrid(coords,coords)
    source=((X*X+Y*Y)<=r*r).astype(np.float32)
    pts=(row[12:18].reshape(3,2)-[cx,cy])/scale+count//2
    cv2.fillPoly(source,[(pts*256).round().astype(np.int32)],1,shift=8)
    radius=15 if old else blur
    sigma=radius if sigma_mode=='sigma_equals_radius' else .57735*radius+.5
    blurred=gaussian_filter(source,sigma=sigma*3/scale,mode='constant')
    threshold=np.clip(51*blurred-25,0,1)
    return threshold,blurred,count//2,coords

checked=0; old_erased=0; failures=[]; min_new=1.
# Full device/position sample matrix, 7 progress samples per geometry and two kernels.
# The upper/side status corridor is a separate Android test; this probes CAMERA ONLY,
# so overlapping artwork cannot mask a dissolved camera lobe.
for row in rows:
    if not any(abs(row[3]-p)<1e-5 for p in [.05,.15,.25,.5,.75,.85,.95]): continue
    for mode in ['radius_to_sigma','sigma_equals_radius']:
        threshold,blurred,center,_=field(row,sigma_mode=mode)
        old,_,_,_=field(row,old=True,sigma_mode=mode)
        checked+=1
        min_new=min(min_new,float(blurred[center,center]))
        old_erased+=old[center,center]<.5
        if threshold[center,center]<.95:
            failures.append(dict(density=float(row[0]),diameterDp=float(row[1]),x=float(row[2]),p=float(row[3]),mode=mode))
report=dict(model='Camera-only Gaussian convolution; not Android RenderEffect',
    samples=checked,old_core_missing=int(old_erased),new_core_failures=failures,
    minimum_new_prethreshold_core_alpha=min_new,
    sigma_modes=['radius_to_sigma: 0.57735 * radius + 0.5','sigma_equals_radius: conservative alternative'],
    exclusions=['Hardware coordinates on user phone','Compose layer clipping','Actual GPU rasterization','Frame timing'])
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')

fig,axes=plt.subplots(2,3,figsize=(10,6))
for col,p in enumerate([.25,.5,.75]):
    row=next(row for row in rows if row[0]==3 and abs(row[1]-12.333333)<.0001 and row[2]==.5 and row[3]==p)
    for line,old in enumerate([True,False]):
        alpha,_,center,coords=field(row,old=old)
        ax=axes[line,col]
        ax.imshow(alpha,cmap='gray_r',vmin=0,vmax=1,extent=[coords[0],coords[-1],coords[-1],coords[0]])
        ax.add_patch(plt.Circle((0,0),row[6],fill=False,color='#e34f4f',linestyle='--',linewidth=1))
        ax.set(xlim=(-55,55),ylim=(100,-40),title=f'{"6.69.15" if old else "6.69.16"}: p={p}',xlabel='window px',ylabel='window px')
fig.suptitle('Camera-only Gaussian MODEL (not phone screenshots)\nDashed circle: reported hole; black: app-generated thresholded mask')
fig.tight_layout(rect=[0,0,1,.89]);fig.savefig(OUT/'camera-core-before-after.png',dpi=150);plt.close(fig)
print(json.dumps(report,indent=2))
assert not failures, 'Camera core lost in model'
