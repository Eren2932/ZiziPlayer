#!/usr/bin/env python3
"""Gaussian approximation from production Java seeds. NOT Skia/Android or phone captures.
Requires numpy/scipy/opencv/Pillow. Kept out of dependency-free CI; execute explicitly.
"""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'verification/v6.70.2/raster-model'
OUT.mkdir(parents=True,exist_ok=True)
UI=ROOT/'app/src/main/java/app/ziziplayer/ui'
with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,
        *[str(UI/(name+'.java')) for name in ['CameraMorphGeometry','CameraGooeyGeometry','CameraNotchGeometry']],
        str(ROOT/'app/src/test/java/app/ziziplayer/ui/CameraNotch6702Checks.java')],check=True)
    samples=subprocess.check_output(['java','-cp',tmp,'app.ziziplayer.ui.CameraNotch6702Checks','samples'],text=True)
(OUT/'production-samples.txt').write_text(samples)
rows=[(line.split()[0],np.array(list(map(float,line.split()[1:])))) for line in samples.splitlines()]

def raster(shape,row):
    d,p,left,top,right,bottom,tx,ty,diam,cx,cy,size,opacity=row[:13]
    # .5 window px at density 1, increasing with d: subpixel model, not screenshot resizing.
    step=.5*d; x0=tx-100*d; y0=-80*d
    X,Y=np.meshgrid(x0+np.arange(400)*step,y0+np.arange(620)*step)
    if shape=='v': physical=(Y>=0)&(Y<=bottom)&(np.abs(X-tx)<=(right-left)/2*(1-Y/bottom))
    else: physical=(Y>=0)&(Y<=bottom)&(((X-tx)/((right-left)/2))**2+(Y/bottom)**2<=1)
    camera=physical.astype('float32')
    art=((X-cx)**2+(Y-cy)**2<=(size/2)**2).astype('float32')
    for layer,points in [(camera,row[13:19]),(art,row[19:25])]:
        pts=(points.reshape(3,2)-[x0,y0])/step
        cv2.fillPoly(layer,[(pts*256).round().astype('int32')],1,shift=8)
    sigma=(.57735*row[25]+.5)*3/step
    camera=gaussian_filter(camera,sigma,mode='constant')
    art=gaussian_filter(art,sigma,mode='constant')
    alpha=np.clip(51*(art+camera*(1-art))-25,0,1)
    alpha*=((Y>=bottom)|physical)
    if opacity==0 or p==0: alpha[:]=0 # camera path is not painted at progress zero
    # App-only mask, separate hardware layer below.
    return alpha,physical,X,Y

report=[]
for d in [1.,1.75,3.]:
    for shape in ['u','v','wide']:
        group=[row for name,row in rows if name==shape and row[0]==d]
        first_tail=None;first_bridge=None
        for row in group:
            p=row[1]
            if p==0:continue
            alpha,physical,X,Y=raster(shape,row)
            col=200;bottom=row[5];body_top=row[10]-row[11]/2
            tail=(Y[:,col]>bottom)&(Y[:,col]<=bottom+2*d)
            if first_tail is None and tail.any() and (alpha[tail,col]>.5).all():first_tail=p
            gap=(Y[:,col]>bottom)&(Y[:,col]<body_top)
            if first_bridge is None and gap.any() and (alpha[gap,col]>.5).all():first_bridge=p
            assert not np.any(alpha[(Y<bottom)&~physical]),'Unphysical notch shoulders'
            if p>=1:assert not np.any(alpha),'Residual app ink at completion'
        assert first_tail is not None and first_tail<.8, f'No attached protrusion for {shape}/{d}'
        assert first_bridge is not None and first_bridge<.8, f'No liquid bridge for {shape}/{d}'
        # The common mask must remain connected after its measured contact, not spawn a dot.
        for row in group:
            if max(.6,first_bridge)<row[1]<.95:
                a,_,X,Y=raster(shape,row)
                gap=(Y[:,200]>row[5])&(Y[:,200]<row[10])
                assert (a[gap,200]>.5).all(),f'Detached neck for {shape}/{d}, p={row[1]}'
        report.append(dict(shape=shape,density=d,first_attached_2dp_tail=first_tail,first_gap_bridge=first_bridge))
result=dict(model='Gaussian approximation fed by production Java; NOT Android GPU validation',
    fixtures='Synthetic U / sharp V / wide U; not measured Samsung A04s cutout dimensions',
    progress_step=.01,results=report,checks=['Attached 2dp protrusion','Continuous common-alpha bridge',
    'No app pixels beside the physical notch above its bottom','Zero app mask at completion'],
    limits=['No APK/Kotlin compilation','No actual OEM DisplayCutout','No RenderEffect/Skia equivalence claim',
    'Detail-image pass excluded; this checks the shared silhouette only'])
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
# Model contact sheet for review only, hardware shape is added AFTER computing app alpha.
image=Image.new('RGB',(1000,710),'#283540');draw=ImageDraw.Draw(image)
draw.text((10,8),'SYNTHETIC Gaussian MODEL — not Android or Samsung screenshots',fill='white')
for i,shape in enumerate(['u','v','wide']):
    for j,p in enumerate([.15,.3,.45,.65,1.]):
        row=next(row for name,row in rows if name==shape and row[0]==1.75 and abs(row[1]-p)<1e-6)
        a,physical,X,Y=raster(shape,row)
        rgb=(1-a[:,:,None])*np.array([90,110,130]);rgb[physical]=0
        # Viewport crop removes only the transparent model padding above screen y=0.
        tile=Image.fromarray(rgb.astype('uint8')).crop((100,160,300,360))
        image.paste(tile,(j*200,35+i*225));draw.text((j*200+5,238+i*225),f'{shape}  p={p:.2f}',fill='white')
image.save(OUT/'notch-model.png')
print(json.dumps(result,indent=2))
