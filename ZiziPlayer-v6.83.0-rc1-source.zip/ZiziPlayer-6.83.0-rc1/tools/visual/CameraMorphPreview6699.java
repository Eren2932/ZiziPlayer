import app.ziziplayer.ui.CameraMorphGeometry;
import app.ziziplayer.ui.CameraMorphGeometry.*;
public class CameraMorphPreview6699 {
    static String arr(float[] a) {return a==null?"null":java.util.Arrays.toString(a);}
    public static void main(String[] args) {
        String mode=args.length>0?args[0]:"center";
        Target t=mode.equals("estimated")?CameraMorphGeometry.compactTopEstimate(new Target(508,0,572,91),1080,2400,110,3):mode.equals("corner")?new Target(30,48,84,102):mode.equals("pill")?new Target(478,48,602,102):new Target(521.5f,50,558.5f,87);
        System.out.print("[");
        for(int i=0;i<=1000;i++) {
            float p=i/1000f;
            Frame f=CameraMorphGeometry.frame(716,315.04f,1,369.04f*p,540,164,8,369.04f,110,t);
            Goo g=CameraMorphGeometry.goo(t,f);
            if(i>0)System.out.print(",");
            System.out.print("{\"p\":"+p+",\"cx\":"+f.cx+",\"cy\":"+f.cy+",\"w\":"+f.width+",\"h\":"+f.height+",\"r\":"+f.radius+",\"alpha\":"+f.imageAlpha+",\"anchor\":"+f.anchorAlpha+",\"body\":"+CameraMorphGeometry.bodyBlack(f,g)+",\"target\":["+t.left+","+t.top+","+t.right+","+t.bottom+"]");
            if(g!=null)System.out.print(",\"u\":"+g.u+",\"gap\":"+g.gap+",\"joined\":"+g.joined+",\"ink\":"+arr(g.ink)+",\"flesh\":"+arr(g.flesh)+",\"inkStart\":"+g.inkStart+",\"inkEnd\":"+g.inkEnd+",\"inkAlpha\":"+g.inkAlpha+",\"ax\":"+g.axisX+",\"ay\":"+g.axisY);
            System.out.print("}");
        }
        System.out.println("]");
    }
}
