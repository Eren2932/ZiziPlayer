#!/usr/bin/env python3
"""Compare production Java seeds with an unpacked 6.69.17 baseline.
Usage: python tools/visual/verify_camera_reach_66918.py /path/to/ZiziPlayer-6.69.17 [output]
Requires numpy/scipy/opencv/Pillow. Gaussian MODEL, not Android/Skia or a phone capture.
"""
from pathlib import Path
import subprocess, tempfile, sys, json
import numpy as np
import cv2
from scipy.ndimage import gaussian_filter
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[2]
BASE=Path(sys.argv[1]);OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'verification/v6.69.18/model'
OUT.mkdir(parents=True,exist_ok=True)
def samples(root):
    ui=root/'app/src/main/java/app/ziziplayer/ui'
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(['java','com.sun.tools.javac.Main','-d',tmp,str(ui/'CameraMorphGeometry.java'),
            str(ui/'CameraGooeyGeometry.java'),str(root/'app/src/test/java/app/ziziplayer/ui/CameraGooey66915Checks.java')],check=True)
        s=subprocess.check_output(['java','-cp',tmp,'app.ziziplayer.ui.CameraGooey66915Checks','samples'],text=True)
    return np.array([[float(v) for v in l.split()] for l in s.splitlines()])
a,b=samples(BASE),samples(ROOT)
assert np.array_equal(a[:,:6],b[:,:6]),'Body motion and seed width must stay identical'
assert np.array_equal(a[:,[6,7,10,11,12,13,16,17]],b[:,[6,7,10,11,12,13,16,17]]),'Seed bases changed'
assert np.array_equal(a[500:],b[500:]),'Second half must stay bit-identical in dumped samples'
assert np.array_equal(a[0],b[0]),'Initial frame changed'
S=1.5;X,Y=np.meshgrid(np.arange(240)*S+360,np.arange(280)*S)
def raster(row):
    p,cx,cy,w,r,h=row[:6]
    art=((X-cx)**2+(Y-cy)**2<=r*r).astype('float32')
    cam=((X-540)**2+(Y-68)**2<=18.5**2).astype('float32')
    def triangle(dst,v):
        pts=(v.reshape(3,2)-[360,0])/S
        cv2.fillPoly(dst,[(pts*256).round().astype('int32')],1,shift=8)
    triangle(cam,row[6:12]);triangle(art,row[12:18])
    sigma=(.57735*15+.5)*3/S
    cam=gaussian_filter(cam,sigma);art=gaussian_filter(art,sigma)
    raw=art+cam*(1-art)
    return np.clip(51*raw-25,0,1),np.clip(51*cam-25,0,1)
def measure(rows):
    first_tail=None;first_bridge=None
    for row in rows[:501]:
        p,cx,cy,w,r,h=row[:6];v,c=raster(row);y=Y[:,0];col=120
        # Visible extension attached to the physical hole in the COMMON mask, not
        # separately thresholded camera: overlap of both blurred fields matters.
        tail=(y>=86.5)&(y<=91)
        if first_tail is None and (v[tail,col]>.5).all():first_tail=float(p)
        gap=(y>=86.5)&(y<=cy-r)
        if first_bridge is None and gap.any() and (v[gap,col]>.5).all():first_bridge=float(p)
    return dict(camera_tail_3px=first_tail,full_gap_bridge=first_bridge)
old,new=measure(a),measure(b)
assert new['camera_tail_3px']<old['camera_tail_3px'],'Camera must emerge earlier in the nominal model'
assert new['full_gap_bridge']<old['full_gap_bridge'],'Bridge must form earlier in the nominal model'
report=dict(model='Gaussian approximation from production Java; NOT Android GPU validation',
    fixture='density 3; camera diameter 37px, centre (540,68); min cover 315.04px; top 148px',
    progress_step=.001,old=old,new=new,
    unchanged=['Body geometry at all sampled positions','Both seed bases at all sampled positions','All seeds for p >= 0.5'],
    limitations=['Actual GPU blur and neck width need a device check','No millisecond estimate: motion follows scroll, not time','Reference video and cropped user screenshots are different captures'])
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
out=Image.new('RGB',(5*240,2*305+35),'#283540');draw=ImageDraw.Draw(out)
draw.text((8,8),'Gaussian MODEL from Java seeds — not phone screenshots; nominal sigma mapping',fill='white')
for row,rows in enumerate([a,b]):
    for col,p in enumerate([.15,.25,.35,.4,.5]):
        v,_=raster(rows[round(p*1000)]);bg=np.array([76,93,78]);rgb=(1-v[:,:,None])*bg
        # Hardware hole is overlaid for orientation only, not part of measurements.
        rgb[((X-540)**2+(Y-68)**2)<=18.5**2]=0
        im=Image.fromarray(np.uint8(rgb));x=col*240;y=35+row*305;out.paste(im,(x,y))
        draw.text((x+3,y+281),f'{"6.69.17" if row==0 else "6.69.18"}  p={p:.2f}',fill='white')
out.save(OUT/'before-after-model.png')
print(json.dumps(report,indent=2))
