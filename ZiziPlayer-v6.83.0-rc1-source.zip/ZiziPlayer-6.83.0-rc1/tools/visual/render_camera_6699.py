import json,cv2,numpy as np,math
from pathlib import Path
import subprocess, argparse
ROOT = Path(__file__).resolve().parents[2]
def flatten(cmds):
    polys=[];cur=[];i=0;pos=None
    while i<len(cmds):
        op=int(cmds[i])
        if op==0:
            if cur: polys.append(cur)
            pos=(cmds[i+1],cmds[i+2]);cur=[pos];i+=3
        elif op==1:
            x1,y1,x2,y2,x,y=cmds[i+1:i+7]
            for t in np.linspace(0,1,24)[1:]:
                mt=1-t
                cur.append((mt**3*pos[0]+3*mt*mt*t*x1+3*mt*t*t*x2+t**3*x, mt**3*pos[1]+3*mt*mt*t*y1+3*mt*t*t*y2+t**3*y))
            pos=(x,y);i+=7
        else:
            i+=1
    if cur: polys.append(cur)
    return polys

SS=2

def pathmask(cmds,W,H,ox,oy):
 m=np.zeros((H*SS,W*SS),np.uint8)
 if cmds:
  for pts in flatten(cmds):
   a=np.rint((np.array(pts)-[ox,oy])*SS).astype(np.int32);cv2.fillPoly(m,[a],255)
 return cv2.resize(m,(W,H),interpolation=cv2.INTER_AREA).astype(np.float32)/255

def rounded(cx,cy,w,h,r,W,H,ox,oy):
 m=np.zeros((H*SS,W*SS),np.uint8)
 x0,y0,x1,y1=np.rint(np.array([cx-w/2-ox,cy-h/2-oy,cx+w/2-ox,cy+h/2-oy])*SS).astype(int);r=max(0,min(int(round(r*SS)),(x1-x0)//2,(y1-y0)//2))
 cv2.rectangle(m,(x0+r,y0),(x1-r,y1),255,-1);cv2.rectangle(m,(x0,y0+r),(x1,y1-r),255,-1)
 for x in (x0+r,x1-r):
  for y in (y0+r,y1-r):cv2.circle(m,(x,y),r,255,-1)
 return cv2.resize(m,(W,H),interpolation=cv2.INTER_AREA).astype(np.float32)/255

def render(g,W=300,H=380,ox=390,oy=0,coverage=False):
 Y,X=np.mgrid[0:H,0:W].astype(np.float32);X+=ox+.5;Y+=oy+.5
 l,t,r,b=g['target'];cx=(l+r)/2;cy=(t+b)/2;U=min(r-l,b-t)/2
 cam=rounded(cx,cy,r-l,b-t,U,W,H,ox,oy)
 bg=np.array([80,64,48],np.float32);im=np.ones((H,W,3),np.float32)*bg
 body=rounded(g['cx'],g['cy'],g['w'],g['h'],g['r'],W,H,ox,oy)
 flesh=pathmask(g.get('flesh'),W,H,ox,oy)
 im*=1-cam[...,None]*g['anchor']
 a=0
 if 'u' in g:
  if not g['joined']:
   im*=1-pathmask(g['ink'],W,H,ox,oy)[...,None]*g['alpha']*g['anchor']
  s=(X-cx)*g['ax']+(Y-cy)*g['ay'];a=g['inkAlpha']*np.clip((g['inkEnd']-s)/(g['inkEnd']-g['inkStart']),0,1)
  if coverage:
   sx=716/g['w'];sy=716/g['h'];lx=(X-g['cx']+g['w']/2)*sx;ly=(Y-g['cy']+g['h']/2)*sy
   nx=g['ax']*sx;ny=g['ay']*sy;L=math.hypot(nx,ny);nx/=L;ny/=L
   px=358-nx*358;py=358-ny*358;q=(lx-px)*nx+(ly-py)*ny
   srcx=lx-np.minimum(q,0)*(1+1/6)*nx;srcy=ly-np.minimum(q,0)*(1+1/6)*ny
   missing=(flesh>.9)&(body<.1)&((srcx<-716.1)|(srcx>1432.1)|(srcy<-716.1)|(srcy>1432.1))
   return int(missing.sum()),int(((flesh>.9)&(body<.1)).sum())
 yy=np.clip((Y-(g['cy']-g['h']/2))/max(g['h'],1),0,1)
 art=np.array([170,137,250])[None,None,:]*(1-yy[...,None])+np.array([113,82,220])[None,None,:]*yy[...,None]
 art*=1-g['body'];art*=1-np.asarray(a)[...,None]
 mask=np.maximum(body,flesh)*g['alpha'];im=im*(1-mask[...,None])+art*mask[...,None]
 safe=(Y>=110)|((X>=l-3-.3*U)&(X<=r+3+.3*U)&(Y>=t-3))
 im=np.where(safe[...,None],im,bg)
 return np.clip(im,0,255).astype(np.uint8)

if __name__=='__main__':
 parser=argparse.ArgumentParser(description='Production Java geometry + software preview; NOT Android rendering. Requires numpy and opencv-python.')
 parser.add_argument('--output',type=Path,default=ROOT/'build/camera-preview-6699')
 args=parser.parse_args(); OUT=args.output.resolve(); OUT.mkdir(parents=True,exist_ok=True)
 classes=OUT/'classes';classes.mkdir(exist_ok=True)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(classes),
  str(ROOT/'app/src/main/java/app/ziziplayer/ui/CameraMorphGeometry.java'),
  str(Path(__file__).with_name('CameraMorphPreview6699.java'))],check=True)
 for name in ['center','corner','pill']:
  with (OUT/(name+'.json')).open('w') as f:
   subprocess.run(['java','-cp',str(classes),'CameraMorphPreview6699',name],stdout=f,check=True)
 results={}
 for name in ['center','corner','pill']:
  gs=json.load(open(OUT/(name+'.json')));worst=0;extra=0
  for g in gs[::4]:
   if 'u' not in g: continue
   missing,total=render(g,W=1080,H=520,ox=0,oy=0,coverage=True)
   if missing>worst:worst=missing;wp=g['p']
   extra=max(extra,total)
  results[name]={'max_uncovered_texture_pixels':worst,'at_progress':locals().get('wp') if worst else None,'max_sampled_extension_pixels':extra}
 print(json.dumps(results,indent=2));(OUT/'texture-coverage.json').write_text(json.dumps(results,indent=2))
 gs=json.load(open(OUT/'center.json'))
 writer=cv2.VideoWriter(str(OUT/'preview.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),30,(600,860))
 idx=list(np.rint(np.linspace(0,1000,180)).astype(int))+list(np.rint(np.linspace(1000,0,180)).astype(int))
 for i in idx:
  g=gs[i];canvas=np.full((860,600,3),(30,26,23),np.uint8)
  frame=cv2.resize(render(g),(600,760),interpolation=cv2.INTER_CUBIC);canvas[55:815]=frame
  label='SEPARATE' if 'u'in g and not g['joined'] else 'CONNECTED' if g.get('joined') else 'REST'
  cv2.putText(canvas,'6.69.10 | geometry preview - NOT Android',(16,30),0,.59,(235,235,235),1,cv2.LINE_AA)
  cv2.putText(canvas,f'{label}   scroll={g["p"]:.3f}',(18,845),0,.65,(235,235,235),1,cv2.LINE_AA)
  writer.write(canvas)
 writer.release()
