"""Production Java + wiring guards, NOT a Kotlin build or a GPU/device test."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
UI = ROOT/'app/src/main/java/app/ziziplayer/ui'
CHECK = ROOT/'app/src/test/java/app/ziziplayer/ui/CameraNotch6702Checks.java'

class CameraNotch6702(unittest.TestCase):
    def execute(self, replacement=None):
        source = (UI/'CameraNotchGeometry.java').read_text()
        if replacement:
            old, new = replacement
            self.assertEqual(source.count(old), 1)
            source = source.replace(old, new)
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp)/'CameraNotchGeometry.java'; file.write_text(source)
            compile = subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17',
                '-d',tmp,str(UI/'CameraMorphGeometry.java'),str(UI/'CameraGooeyGeometry.java'),str(file),str(CHECK)],
                capture_output=True,text=True)
            self.assertEqual(compile.returncode, 0, compile.stderr)
            return subprocess.run(['java','-cp',tmp,'app.ziziplayer.ui.CameraNotch6702Checks'],capture_output=True,text=True)

    def test_production_geometry(self):
        run = self.execute()
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        print(run.stdout,flush=True)

    def test_wrong_width_bottom_and_position_are_rejected(self):
        for mutation in [
            ('Math.min(Math.min(w, h),','Math.min(w,'),
            ('tipX+diameter*.5f, bounds.bottom);','tipX+diameter*.5f, bounds.bottom + 1f);'),
            ('(left+right)*.5f : Float.NaN','bounds.cx() : Float.NaN')]:
            with self.subTest(mutation=mutation):
                run = self.execute(mutation)
                self.assertNotEqual(run.returncode,0,'Mutant survived')
                self.assertIn('AssertionError',run.stderr)

    def test_adapter_retains_system_path_and_distinguishes_rect_reservations(self):
        s=(UI/'components/CameraCutout.kt').read_text()
        self.assertIn('val holeEstimate = CameraMorphGeometry.compactTopEstimate(raw,',s)
        self.assertIn('CameraNotchGeometry.bottomCenter(',s)
        self.assertIn('CameraNotchGeometry.anchor(',s)
        self.assertIn('val notchOutline = if (exact) path!!',s)
        self.assertIn('physicalBounds = physical',s)
        self.assertIn('topAttached = true',s)
        self.assertNotIn('Build.MODEL ==',s)
        self.assertNotIn('getCameraCharacteristics',s)

    def test_both_renderers_share_physical_notch_clip(self):
        legacy=(UI/'components/CollectionCoverMorph.kt').read_text()
        gpu=(UI/'components/CameraGooeyOverlay.kt').read_text()
        for s in [legacy,gpu]:
            self.assertIn('cameraMorphSafetyPath(',s)
            self.assertIn('camera.topAttached',s)
        self.assertIn('PathOperation.Union, lower, outline',legacy)
        self.assertIn('addRect(Rect(0f, target.bottom, width, height))',legacy)
        self.assertIn('cameraGooLayer.renderEffect = gooBlur',gpu)
        self.assertIn('artworkGooLayer.renderEffect = gooBlur',gpu)
        self.assertIn('drawPath(outline, Color.Black)',gpu)
        self.assertIn('CameraNotchGeometry.blurRadius(density.density) else G.BLUR_RADIUS',gpu)
        self.assertIn('G.blurIntensity(f.progress)*gooRadius',gpu)
        self.assertIn('camera.physicalBounds ?: target else target',gpu)
        self.assertIn('minPx, reservoir, padding',gpu)
        # Clip path construction stays outside the per-frame drawing callback.
        self.assertLess(gpu.index('val safe = remember('),gpu.index('onDrawWithContent {'))

    def test_checks_are_connected_to_ci(self):
        self.assertIn('test_camera_notch_6702.py',(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('CameraNotch6702Test',(ROOT/'tools/run_camera_ci.sh').read_text())
        from release_identity import assert_release_at_least
        assert_release_at_least(self,(ROOT/'app/build.gradle.kts').read_text(),148,'6.70.2')

if __name__ == '__main__': unittest.main(verbosity=2)
