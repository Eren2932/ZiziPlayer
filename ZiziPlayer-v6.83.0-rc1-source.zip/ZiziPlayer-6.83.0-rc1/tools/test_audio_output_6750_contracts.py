#!/usr/bin/env python3
"""Source wiring guards, explicitly NOT Kotlin compilation or hardware integration tests."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()
class OutputContracts(unittest.TestCase):
    def test_default_media3_track_is_observed_not_replaced(self):
        monitor = read('playback/PlaybackRouteMonitor.kt')
        self.assertIn('AudioTrackProvider.DEFAULT.getAudioTrack', monitor)
        self.assertIn('if (!closed)', monitor)
        self.assertIn('AudioOutputs.detach(this)', monitor)
        service = read('playback/PlaybackService.kt')
        self.assertIn('.setAudioTrackProvider(routeMonitor.provider)', service)
        self.assertIn('DefaultAudioProcessorChain(dsp)', service)
        self.assertIn('routeMonitor.close()', service)
    def test_actual_identity_and_callback_ownership(self):
        source = read('playback/AudioOutput.kt')
        for expected in ('AudioTrack.PLAYSTATE_PLAYING', 'track === next && owner === token',
                         'removeOnRoutingChangedListener(callback)', 'unregisterAudioDeviceCallback(callback)',
                         'AudioRoutePolicy.select(actual?.id', 'Build.VERSION.SDK_INT >= 33'):
            self.assertIn(expected, source)
        for forbidden in ('minByOrNull', 'firstOrNull { it.type', 'bondedDevices', 'fun rank(', 'delay('):
            self.assertNotIn(forbidden, source.split('private fun describe')[0])
    def test_one_snapshot_and_shared_dialog_for_both_players(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('val audioOutput: StateFlow<AudioOutputState>', vm)
        for name in ('ui/screens/LibraryScreen.kt', 'ui/screens/PlayerScreen.kt'):
            s = read(name)
            self.assertIn('vm.audioOutput.collectAsStateWithLifecycle()', s)
            self.assertIn('AudioOutputSheet(vm = vm, track =', s)
        self.assertIn('AudioOutputs.refresh()', read('MainActivity.kt'))
    def test_real_settings_no_fake_discovery(self):
        source = read('ui/screens/AudioOutputSheet.kt')
        for token in ('Settings.ACTION_BLUETOOTH_SETTINGS', 'Settings.Panel.ACTION_VOLUME',
                      'ActivityResultContracts.RequestPermission()', 'Lifecycle.Event.ON_RESUME',
                      'skipPartiallyExpanded = true', 'navigationBarsPadding()', 'verticalScroll('):
            self.assertIn(token, source)
        self.assertNotIn('В этой сети устройства не найдены', source)
        self.assertNotIn('com.android.settings.panel.action.MEDIA_OUTPUT', source)
        self.assertIn('state.connected.any { it.isBluetooth }', source)
        self.assertNotIn('BLUETOOTH_SCAN', (ROOT/'app/src/main/AndroidManifest.xml').read_text())
    def test_compact_card_has_only_independent_actions(self):
        source = read('ui/components/MiniPlayerCard.kt')
        for tag in ('mini-output', 'mini-favorite', 'mini-play', 'mini-open'):
            self.assertIn('"'+tag+'"', source)
        self.assertNotIn('SkipNext', source)
        self.assertIn('.clip(RoundedCornerShape(MiniPlayerGeometry.RADIUS.dp))', source)
        self.assertNotIn('.clip(CircleShape)', source.split('private fun MiniFavoriteControl')[0])
        self.assertNotIn('MiniEqualizerBars', source)
        self.assertIn('.drawBehind', source)
        self.assertIn('progress().coerceIn(0f, 1f)', source)
        self.assertIn('MiniPlayerGeometry.progress(track.id, value.trackId', read('ui/screens/LibraryScreen.kt'))
    def test_phone_and_headset_glyphs_are_shared(self):
        s = read('ui/components/AudioOutputUi.kt')
        self.assertIn('ZiziIcons.ConnectPhone else ZiziIcons.ConnectDevices', s)
        self.assertIn('OutputKind.WIRED, OutputKind.BLUETOOTH -> ZiziIcons.Headphones', s)
        self.assertIn('output.isKnown && !output.isPhone', s)
        for name in ('ConnectPhone', 'ConnectDevices', 'MiniPause', 'MiniPlay', 'AddCircle', 'AddedCircle'):
            self.assertIn('val '+name+': ImageVector', read('ui/components/ZiziIcons.kt'))
if __name__ == '__main__': unittest.main(verbosity=2)
