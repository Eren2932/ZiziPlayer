#!/usr/bin/env python3
"""Source integration guards, NOT Kotlin compilation or Compose execution."""
from pathlib import Path
import unittest
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()

class LyricsPaletteContracts(unittest.TestCase):
    def test_original_swatch_survives_player_tone_mapping(self):
        theme = read('ui/theme/ZiziTheme.kt')
        self.assertIn('val artworkPrimary: Color? = null', theme)
        tinted = theme.split('fun ZiziPalette.tintedWith(')[1].split('fun ZiziPalette.withAccent')[0]
        self.assertIn('artworkPrimary = swatches.primary', tinted)
        self.assertIn('if (swatches == null || tintStrength <= 0.01f) return this', tinted)
        self.assertIn('ArtworkSurfaceMath.playerBackdrop(primary, deepSwatch, bodySwatch)', tinted)
        self.assertIn('subtext = subtext', tinted)

    def test_destination_only_scope_and_single_cached_derivation(self):
        theme = read('ui/theme/LyricsPalette.kt')
        for token in ['LocalPalette.current.artworkPrimary', 'remember(primary) { lyricsPalette(primary) }',
                      'CompositionLocalProvider(LocalPalette provides palette)', 'ZiziTheme(palette, content)',
                      'LyricsColorMath.create(primary?.toArgb())']:
            self.assertIn(token, theme)
        for forbidden in ['rememberArtSwatches', 'ArtworkCache', 'LocalBackdropBlend', 'Dispatchers', 'LaunchedEffect']:
            self.assertNotIn(forbidden, theme)
        lyrics = read('ui/screens/LyricsScreen.kt')
        self.assertIn(') = LyricsSurfaceTheme {', lyrics)
        self.assertIn('val background = remember(p) { p.background }', lyrics)
        self.assertLess(lyrics.index('.background(background)'), lyrics.index('.safeDrawingPadding()'))
        self.assertNotIn('Brush.verticalGradient(listOf(p.top, p.bottom))', lyrics)

    def test_surrounding_and_pending_words_are_opaque_roles(self):
        lyrics = read('ui/screens/LyricsScreen.kt')
        self.assertIn('if (selected) p.text else p.subtext', lyrics)
        self.assertIn('pendingInk = p.subtext', lyrics)
        self.assertIn('Text(line, color = p.subtext', lyrics)
        self.assertNotIn('0.34f else 0.52f', lyrics)
        words = read('ui/screens/LyricText.kt')
        self.assertIn('pendingInk: Color = ink.copy(alpha = 0.5f)', words)
        self.assertIn('SpanStyle(color = pendingInk)', words)

    def test_status_glass_uses_same_hoisted_visibility(self):
        main = read('MainActivity.kt')
        player = read('ui/screens/PlayerScreen.kt')
        self.assertIn('var showLyrics by remember { mutableStateOf(false) }', main)
        self.assertIn('onLyricsOpenChange = { showLyrics = it }', main)
        self.assertIn('if (showLyrics && current != null) 0f else if (playerStatusPx > 0f)', main)
        self.assertNotIn('var showLyrics by remember', player)
        self.assertIn('onClose = { onLyricsOpenChange(false) }', player)
        # 6.80.0: the under-cover caption is read-only; only preview + menu open lyrics.
        self.assertEqual(player.count('onLyricsOpenChange(true)'), 2)

    def test_no_song_specific_colour_override_or_new_clock(self):
        core = read('ui/theme/LyricsColorMath.java')
        for value in ['URANIUM', '887043', 'decd85', 'Math.random', 'System.currentTimeMillis']:
            self.assertNotIn(value, core)
        self.assertIn('fittingChroma', core)
        self.assertIn('contrast(ink, envelope) < 4.5', core)
        self.assertIn('sourceChroma', core)

    def test_existing_timing_import_and_follow_are_preserved(self):
        lyrics = read('ui/screens/LyricsScreen.kt')
        for value in ['rememberLyricsCursor', 'cursor.sameTrack && cursor.matchesDuration',
                      'vm.seekTo(LrcTimeline.seekPosition(line, advanceMs), track.id)',
                      'OpenDocument()', 'DragInteraction.Start', 'follow = false']:
            self.assertIn(value, lyrics)
        self.assertNotIn('speed', lyrics)

    def test_registered_preflight_and_android_tests(self):
        preflight = (ROOT / 'tools/check_selftest.py').read_text()
        for script in ['test_lyrics_palette_6720.py', 'test_lyrics_palette_6720_contracts.py']:
            self.assertIn(repr(script), preflight)
        assert_release_at_least(self, (ROOT / 'app/build.gradle.kts').read_text(), 155, '6.72.0')
        self.assertIn('LyricsColorMathChecks.runAll()', (ROOT / 'app/src/test/java/app/ziziplayer/ui/LyricsColorMathTest.kt').read_text())
        android = (ROOT / 'app/src/androidTest/java/app/ziziplayer/ui/LyricsPaletteUiTest.kt').read_text()
        for test in ['lyricsScopeUpdatesAndRestoresPlayerWithoutChangingNeutralLibrary',
                     'gradientPixelsRiseTowardBottomInsteadOfBlack',
                     'enhancedLrcUsesOpaquePendingInkWithoutInventingWordTiming']:
            self.assertIn('fun ' + test, android)

if __name__ == '__main__': unittest.main(verbosity=2)
