#!/usr/bin/env python3
"""6.67.0 — playlist creation redesign, stale dialogs unified, baseline profile.

UI source contracts (not Kotlin execution). The naming rule itself is executed by the JVM test
app/src/test/java/app/ziziplayer/ui/PlaylistNamingTest.kt in `gradle testDebugUnitTest`.
"""
import pathlib
import unittest

from release_identity import assert_release_at_least

R = pathlib.Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'


def read(name):
    return (S / name).read_text(encoding='utf-8')


class Ui6670(unittest.TestCase):
    def test_library_plus_opens_the_new_sheet(self):
        lib = read('ui/screens/LibraryScreen.kt')
        block = lib.split('if (creatingPlaylist) {')[1].split('\n    }\n')[0]
        self.assertIn('PlaylistCreateSheet(', block)
        self.assertNotIn('RenameDialog(', block)

    def test_form_has_preview_suggestions_duplicate_and_ime_done(self):
        f = read('ui/screens/PlaylistCreateSheet.kt')
        for needle in ('PlaylistCoverPreview(field.text', 'PlaylistNaming.suggestions(',
                       'PlaylistNaming.isDuplicate(field.text, existingNames)', 'imeAction = ImeAction.Done',
                       'KeyboardActions(onDone = { onDone() })', 'fontFamily = ZiziFontFamily',
                       'selection = TextRange(0, start.length)', 'if (canCreate && !submitted)'):
            self.assertIn(needle, f)
        self.assertNotIn('OutlinedTextField(', f)
        self.assertNotIn('AlertDialog(', f)

    def test_naming_rule_is_shared_and_outside_screens(self):
        n = read('ui/PlaylistNaming.kt')
        self.assertIn('package app.ziziplayer.ui\n', n)
        self.assertIn('const val MAX_LENGTH = 60', n)
        self.assertNotIn('androidx.compose', n)
        vm = read('ui/MainViewModel.kt')
        body = vm.split('fun createPlaylist(name: String')[1].split('\n    }\n')[0]
        self.assertIn('PlaylistNaming.clean(name)', body)
        self.assertIn('repo.addTracksToPlaylist(id, tracks.map { it.id })', body)
        self.assertNotIn('tracks.forEach', body)
        self.assertTrue((R / 'app/src/test/java/app/ziziplayer/ui/PlaylistNamingTest.kt').exists())

    def test_picker_is_lazy_keyed_and_embeds_the_form(self):
        s = read('ui/screens/Sheets.kt')
        body = s.split('fun PlaylistPickerSheet(')[1].split('private const val PICKER_SEARCH_FROM')[0]
        self.assertIn('items(shown, key = { it.id }', body)
        self.assertIn('PlaylistCreateForm(', body)
        self.assertIn('mutableStateOf(playlists.isEmpty())', body)
        self.assertNotIn('OutlinedTextField(', body)
        self.assertNotIn('verticalScroll', body)

    def test_home_has_no_raw_material_dialogs(self):
        home = read('ui/screens/HomeScreen.kt')
        self.assertNotIn('AlertDialog(', home)
        self.assertIn('PlaylistPickerSheet(', home)
        self.assertIn('HomePinsSheet(', home)
        pins = read('ui/screens/HomePinsSheet.kt')
        self.assertIn('private const val HOME_PIN_LIMIT = 6', pins)
        self.assertIn('items(playlists, key = { it.playlist.id }', pins)

    def test_import_and_copy_are_sheets(self):
        share = read('ui/screens/PlaylistShareSheets.kt')
        entry = share.split('fun ImportSourceDialog(')[1]
        self.assertIn('ZiziSheetScaffold(onDismiss)', entry)
        self.assertNotIn('AlertDialog(', entry)
        host = read('ui/screens/PlaylistActionsHost.kt')
        copy = host.split('"copy" ->')[1].split('"downloads" ->')[0]
        self.assertIn('ZiziSheetScaffold(', copy)
        self.assertIn('runAction { vm.copyPlaylistContents(playlist, target); onDismiss() }', copy)

    def test_baseline_profile_is_shipped_and_installed(self):
        prof = (R / 'app/src/main/baseline-prof.txt').read_text(encoding='utf-8')
        for rule in ('HSPLapp/ziziplayer/ui/**->**(**)**', 'HSPLapp/ziziplayer/MainActivity**->**(**)**',
                     'HSPLapp/ziziplayer/playback/**->**(**)**'):
            self.assertIn(rule, prof)
        gradle = (R / 'app/build.gradle.kts').read_text(encoding='utf-8')
        self.assertIn('implementation("androidx.profileinstaller:profileinstaller:1.4.1")', gradle)
        assert_release_at_least(self, gradle, 124, '6.68.0')


if __name__ == '__main__':
    unittest.main(verbosity=2)
