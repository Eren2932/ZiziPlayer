#!/usr/bin/env bash
# Requires JDK 17, Gradle 8.11.1, Android SDK 36 and one running emulator/device.
# Run with Android animator duration scale 1x; the filter tests inspect intermediate frames.
set -euo pipefail
cd "$(dirname "$0")/.."
classes='app.ziziplayer.ui.SearchFilterRailTest,app.ziziplayer.ui.Search6770UiTest,app.ziziplayer.data.CollectionRemoval6770Test,app.ziziplayer.ui.SearchMenu6771UiTest,app.ziziplayer.ui.Search6780UiTest,app.ziziplayer.data.SearchHistory6780Test,app.ziziplayer.ui.Search6790UiTest,app.ziziplayer.ui.SearchMenu6790UiTest'
mkdir -p build/ci/search-6790
rm -rf app/build/outputs/androidTest-results/connected app/build/reports/androidTests/connected
set +e
gradle --no-daemon --max-workers=2 :app:connectedDebugAndroidTest --rerun \
  "-Pandroid.testInstrumentationRunnerArguments.class=$classes" --stacktrace \
  2>&1 | tee build/ci/search-6790/gradle.log
statuses=("${PIPESTATUS[@]}")
python3 tools/verify_search_android_6790.py app/build/outputs/androidTest-results/connected \
  | tee build/ci/search-6790/completeness.json
verification=("${PIPESTATUS[@]}")
set -e
[ "${statuses[0]}" -eq 0 ] || exit "${statuses[0]}"
[ "${statuses[1]}" -eq 0 ] || exit "${statuses[1]}"
[ "${verification[0]}" -eq 0 ] || exit "${verification[0]}"
[ "${verification[1]}" -eq 0 ] || exit "${verification[1]}"
