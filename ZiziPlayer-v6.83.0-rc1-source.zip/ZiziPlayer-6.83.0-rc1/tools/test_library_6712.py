"""6.71.2: production Java execution + source contracts. Not Kotlin/Compose compilation."""
from pathlib import Path
import re
import subprocess
import tempfile
import unittest
from release_identity import assert_release_at_least

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (SRC / name).read_text()
SCREEN = read('ui/screens/LibraryScreen.kt')
CONTROLS = read('ui/screens/LibraryControls.kt')
VM = read('ui/MainViewModel.kt')
PLAYER = read('playback/PlayerController.kt')

class Library6712(unittest.TestCase):
    def test_production_uniform_start_policy(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', tmp,
                str(SRC/'playback/ShuffleStartPolicy.java'),
                str(ROOT/'app/src/test/java/app/ziziplayer/playback/ShuffleStart6712Checks.java')],
                capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            result = subprocess.run(['java', '-cp', tmp, 'app.ziziplayer.playback.ShuffleStart6712Checks'],
                capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            print(result.stdout.strip())
    def test_root_shuffle_uses_whole_library_not_card_search(self):
        body = VM.split('fun shuffleLibrary()')[1].split('fun shuffleTracks')[0]
        self.assertIn('player.shuffleAndPlay(library.value.tracks', body)
        self.assertNotIn('.visible', body)
        self.assertIn('sourceId = LibraryFilter.TRACKS.name', body)
        self.assertIn('onShuffle = vm::shuffleLibrary', SCREEN)
        self.assertNotIn('onShuffle = vm::toggleShuffle', SCREEN)
    def test_privacy_and_dedup_before_random_draw(self):
        body = PLAYER.split('fun shuffleAndPlay(')[1].split('fun setQueue(')[0]
        self.assertIn('tracks.filterNot(gate::blocks).distinctBy { it.id }', body)
        self.assertLess(body.index('filterNot'), body.index('ShuffleStartPolicy.chooseStartIndex'))
        self.assertIn('if (index >= 0) setQueue(safe, index, sourceId = sourceId, shuffle = true)', body)
    def test_pending_request_keeps_shuffle_intent(self):
        self.assertIn('val sourceId: String? = null, val shuffle: Boolean? = null', PLAYER)
        self.assertIn('setQueue(q.tracks, q.index, q.play, q.positionMs, q.sourceId, q.shuffle)', PLAYER)
        self.assertIn('PendingQueue(safeTracks, safeIndex, play, startPositionMs, sourceId, shuffle)', PLAYER)
    def test_queue_application_is_guarded_and_starts_audio(self):
        body = PLAYER.split('fun setQueue(')[1].split('private fun mediaItemOf')[0]
        for text in ['queueBuildJob?.cancel()', 'retryJob?.cancel()', 'epoch != queueEpoch',
                     'safeTracks.any(app.ziziplayer.privacy.FolderVault.get(context).state.value::blocks)',
                     'p.shuffleModeEnabled = enabled', 'if (enabled) p.repeatMode = Player.REPEAT_MODE_ALL',
                     'p.prepare()', 'p.playWhenReady = play']:
            self.assertIn(text, body)
        self.assertLess(body.index('epoch != queueEpoch'), body.index('p.shuffleModeEnabled = enabled'))
        self.assertLess(body.index('p.setMediaItems('), body.index('p.shuffleModeEnabled = enabled'))
        self.assertLess(body.index('p.shuffleModeEnabled = enabled'), body.index('p.prepare()'))
    def test_restore_cannot_override_pending_user_command(self):
        self.assertIn('pendingQueue != null || queueBuildJob?.isActive == true', PLAYER)
        tail = VM.split('val positionMs = repo.lastPositionMs()')[1].split('// Backup only.')[0]
        self.assertLess(tail.index('if (player.hasQueue()) return@launch'), tail.index('player.setQueue('))
    def test_detail_shuffle_uses_same_controller_path(self):
        detail = read('ui/screens/UnifiedLocalCollectionScreen.kt')
        self.assertIn('onShuffle = { vm.shuffleTracks(state.visible, destination) }', detail)
        self.assertNotIn('state.visible.shuffled()', detail)
        self.assertIn('fun toggleShuffle() = player.toggleShuffle()', VM)
        self.assertIn('onShuffle = vm::toggleShuffle', read('ui/screens/PlayerScreen.kt'))
    def test_add_panel_replaces_bottom_tiles(self):
        for old in ['act:new', 'act:folder', 'actionCard(', 'CardKind.ACTION']:
            self.assertNotIn(old, SCREEN)
        for text in ['"Новый плейлист"', '"Добавить папку"', '"Импорт плейлиста"']:
            self.assertIn(text, CONTROLS)
        self.assertIn('LibraryAddPanel(enabled = addExpanded', SCREEN)
        self.assertIn('item(key = "panel:add", span = { GridItemSpan(maxLineSpan) })', SCREEN)
    def test_action_consumed_before_sheet_or_system_picker(self):
        for text in ['if (vm.consumeLibraryAddAction()) creatingPlaylist = true',
                     'if (vm.consumeLibraryAddAction()) onPickFolder()',
                     'if (vm.consumeLibraryAddAction()) importSource = true']:
            self.assertIn(text, SCREEN)
        self.assertIn('_libraryPanels.compareAndSet(open, open.dismissTop())', VM)
        self.assertIn('.clickable(enabled = enabled, role = Role.Button', CONTROLS)
        self.assertIn('pickPlaylistFile.launch(arrayOf("*/*"))', SCREEN)
    def test_search_and_add_panel_exclude_each_other(self):
        add = VM.split('fun setLibraryAddExpanded(')[1].split('fun toggleLibraryAddPanel')[0]
        self.assertIn('if (open) setSearchOpen(false)', add)
        search = VM.split('fun setSearchOpen(')[1].split('fun openPlaylist')[0]
        self.assertIn('if (open) closeLibraryPanels()', search)
        self.assertIn('if (selectionMode || folderSelection.isNotEmpty()) vm.closeLibraryPanels()', SCREEN)
    def test_panel_rows_grow_and_toolbar_targets_are_48dp(self):
        row = CONTROLS.split('private fun LibraryAddAction(')[1].split('/** The four silhouettes')[0]
        self.assertIn('heightIn(min = 64.dp)', row)
        self.assertNotIn('maxLines', row)
        self.assertNotIn('.height(', row)
        toolbar = CONTROLS.split('internal fun LibraryToolbar(')[1].split('/** Fixed identities')[0]
        self.assertNotIn('size(36.dp, 48.dp)', toolbar)
        self.assertIn('maxWidth - 192.dp', toolbar)
    def test_cover_glyph_contrast_across_entire_gradients(self):
        palette = dict((name, int(value,16)) for name,value in
            re.findall(r'val (\w+) = Color\(0xFF([0-9A-F]{6})\)', CONTROLS))
        def rgb(c): return [(c >> b) & 255 for b in (16,8,0)]
        def lum(c):
            def lin(x):
                x /= 255
                return x / 12.92 if x <= .04045 else ((x+.055)/1.055)**2.4
            return sum(w*lin(v) for w,v in zip((.2126,.7152,.0722),c))
        minimum = 100
        for prefix in ['favorites','tracks']:
            a,b = rgb(palette[prefix+'Top']), rgb(palette[prefix+'Bottom'])
            for step in range(1001):
                t=step/1000
                back=lum([x+(y-x)*t for x,y in zip(a,b)])
                contrast=(lum(rgb(palette['glyph']))+.05)/(back+.05)
                minimum=min(minimum,contrast)
                self.assertGreaterEqual(contrast,4.5)
            # White primary text and a representative #A0A0A0 secondary label.
            for text in [0xF7F5FF,0xA0A0A0]:
                self.assertGreaterEqual((lum(rgb(text))+.05)/(lum(rgb(0x1B1B1B))+.05),4.5)
        print(f'Fixed cover glyph contrast: min {minimum:.3f}:1 over 2002 samples')
        self.assertNotIn('Color(0xFF345B79)', SCREEN)
    def test_release_and_checks_are_connected(self):
        gradle=(ROOT/'app/build.gradle.kts').read_text()
        assert_release_at_least(self, gradle, 153, '6.71.2')
        self.assertIn("'test_library_6712.py'",(ROOT/'tools/check_selftest.py').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
