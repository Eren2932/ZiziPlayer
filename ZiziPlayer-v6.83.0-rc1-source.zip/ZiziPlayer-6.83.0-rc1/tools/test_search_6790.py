#!/usr/bin/env python3
"""Actual Java execution + wiring contracts, NOT Android/Kotlin runtime verification."""
from pathlib import Path
import json, re, subprocess, tempfile, unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(p): return (SRC/p).read_text()
class Search6790(unittest.TestCase):
    def test_shipping_policies(self):
        with tempfile.TemporaryDirectory() as out:
            files = [SRC/'ui/SearchSuggestionPolicy.java', SRC/'ui/SearchMenuGeometry.java',
                     SRC/'ui/SearchPreviewCache.java', ROOT/'app/src/test/java/app/ziziplayer/ui/Search6790Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True,capture_output=True)
            result = subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Search6790Checks'],check=True,capture_output=True,text=True)
            self.assertIn('production search/cache/panel assertions passed',result.stdout)
            print(result.stdout.strip())
    def test_top_slot_is_stable_and_history_waits_below_catalog(self):
        ui=read('ui/screens/SearchScreen.kt').split('internal fun SuggestBody(')[1].split('internal fun SuggestRow')[0]
        self.assertIn('item("suggest:catalog", contentType = "completions")',ui)
        self.assertIn('key(SearchSuggestionPolicy.normalize(field)) { rememberLazyListState() }',ui)
        self.assertIn('if (!pending && history.isNotEmpty())',ui)
        self.assertLess(ui.index('items(matches,'),ui.index('item("suggest:history"'))
        self.assertNotIn('recents.filter',ui)
        self.assertNotIn('LaunchedEffect(field)',ui)
    def test_typing_has_generation_guard_and_cache_namespace(self):
        vm=read('ui/SearchViewModel.kt')
        for value in ['++suggestionGeneration','generation == suggestionGeneration','delay(140L)',
                      'SearchPreviewCache<TypingSnapshot>(32, 120_000L)', 'RemoteRuntime.youtubeDirect',
                      'SystemClock.elapsedRealtime()', 'flowOn(Dispatchers.IO)',
                      'previewUpdates(preferred, query)', 'SearchPresentation.matchesPreview(it, query)']:
            self.assertIn(value,vm)
        self.assertIn('TabResults(items = previewForQuery, loading = true)',vm)
        self.assertIn('results.loading && results.items.isEmpty()',read('ui/screens/SearchScreen.kt'))
    def test_progressive_lanes_do_not_await_all_before_publishing(self):
        remote=read('data/remote/DeezerCatalog.kt')
        self.assertEqual(remote.count('override fun previewUpdates('),2)
        self.assertIn('RemoteKind.TRACK to 6, RemoteKind.ALBUM to 2',remote)
        pipe=read('data/remote/ProgressivePreview.kt')
        self.assertIn('sources.forEachIndexed',pipe)
        self.assertIn('snapshots[event.index] = it',pipe)
        self.assertLess(pipe.index('if (items.isNotEmpty()) send(items)'),pipe.index('val final = merge(snapshots)'))
        self.assertIn('catch (e: CancellationException) { throw e }',pipe)
        self.assertNotIn('resolveStream',pipe)
    def test_sheet_is_a_real_visible_viewport_and_one_motion_clock(self):
        sheet=read('ui/screens/SearchTrackMenuSheet.kt')
        for token in ['Constraints.fixed(constraints.maxWidth, visible)', 'panel.placeRelative(0, y)',
                      'val visible = constraints.maxHeight - y', 'state.drag.updateAnchors(anchors, newTarget = state.drag.targetValue)',
                      'window?.setDimAmount(0f)', 'SearchMenuGeometry.reveal(', '.nestedScroll(nested)']:
            self.assertIn(token,sheet)
        self.assertNotIn('BottomSheetScaffold(',sheet)
        self.assertEqual(sheet.count('WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom)'),1)
        motion=read('ui/screens/SearchMenuMotion.kt')
        for token in ['drag.settledValue', 'AnchoredDraggableState.Saver<SheetValue>', 'dampingRatio = 1f',
                      'onPreScroll', 'onPostScroll', 'onPreFling', 'onPostFling']:
            self.assertIn(token,motion)
    def test_device_inventory_and_ci_are_connected(self):
        inventory=json.loads((ROOT/'tools/search_6790_android_inventory.json').read_text())
        old=json.loads((ROOT/'tools/search_6780_android_inventory.json').read_text())
        added=[]
        for name in ['Search6790UiTest','SearchMenu6790UiTest']:
            source=(ROOT/f'app/src/androidTest/java/app/ziziplayer/ui/{name}.kt').read_text()
            added += [f'app.ziziplayer.ui.{name}#{method}' for method in re.findall(r'@Test\s+fun\s+(\w+)\(',source)]
        self.assertEqual(sorted(inventory), sorted(old+added))
        self.assertGreaterEqual(len(added),10)
        self.assertIn("'test_search_6790.py'",(ROOT/'tools/check_selftest.py').read_text())
        self.assertIn('verify_search_android_6790.py',(ROOT/'tools/run_search_ui_6790.sh').read_text())
if __name__=='__main__': unittest.main(verbosity=2)
