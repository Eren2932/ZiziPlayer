#!/usr/bin/env python3
"""Контракты 6.66.0: ошибка воспроизведения НЕ двигает очередь.

Это проверки исходника, а не прогон Media3: они доказывают, что нужные строки стоят на
своих местах, и не доказывают поведение на устройстве. Смысл — не дать автопропуску
вернуться незаметно: он возвращался бы одной строкой и выглядел бы как безобидное
«не обрывать музыку».
"""
from pathlib import Path
import unittest

R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'


def read(p):
    return (S / p).read_text()


def strip_comments(text):
    """Только исполняемые строки: пояснение, которое НАЗЫВАЕТ убранный вызов, — не вызов."""
    return '\n'.join(l for l in text.splitlines() if not l.strip().startswith('//'))


def error_handler(src):
    """Тело handlePlayerError без хвоста файла."""
    body = src.split('private fun handlePlayerError(')[1]
    return strip_comments(body.split('private fun isTransient(')[0])


class QueueIsNotMovedByErrors(unittest.TestCase):
    def test_error_handler_never_advances_the_queue(self):
        body = error_handler(read('playback/PlayerController.kt'))
        for forbidden in ('seekToNextMediaItem', 'seekToNext(', 'hasNextMediaItem',
                          'seekToPreviousMediaItem', 'seekToDefaultPosition'):
            self.assertNotIn(forbidden, body,
                             f'{forbidden} в обработчике ошибок — это возвращённый автопропуск')

    def test_queue_advance_stays_in_explicit_user_commands(self):
        src = read('playback/PlayerController.kt')
        # Единственный вызов перехода вперёд — ручная кнопка «Следующий».
        lines = [l.strip() for l in src.splitlines()
                 if 'seekToNextMediaItem' in l and not l.strip().startswith('//')]
        self.assertEqual(lines, ['fun next() { dropSeekIntent(); controller?.seekToNextMediaItem(); publish(); publishProgress() }'])

    def test_old_autoskip_budget_is_gone_entirely(self):
        src = read('playback/PlayerController.kt')
        code = strip_comments(src)
        self.assertNotIn('MAX_AUTO_SKIPS', code)
        # Счётчик подряд идущих ошибок существовал только ради бюджета пропусков. Без бюджета
        # он становится состоянием, которое пишется и никем не читается.
        self.assertNotIn('consecutiveErrors', code)

    def test_retry_is_bounded_and_belongs_to_the_failed_item(self):
        src = read('playback/PlayerController.kt')
        body = error_handler(src)
        self.assertIn('itemRetries < MAX_ITEM_RETRIES', body)
        self.assertIn('isTransient(error)', body)
        # Повтор обязан проверить, что трек не сменился за время паузы.
        self.assertIn('live.currentMediaItem?.mediaId != failedId', body)
        self.assertIn('const val MAX_ITEM_RETRIES = 2', src)

    def test_permanent_failures_are_not_retried(self):
        src = read('playback/PlayerController.kt')
        gate = src.split('private fun isTransient(')[1].split('private fun describe(')[0]
        for code in ('ERROR_CODE_IO_FILE_NOT_FOUND', 'ERROR_CODE_DECODING_FAILED',
                     'ERROR_CODE_DECODER_INIT_FAILED'):
            self.assertIn(code, gate)
        self.assertIn('-> false', gate)

    def test_pending_retry_is_cancelled_by_item_change_and_manual_commands(self):
        src = read('playback/PlayerController.kt')
        self.assertIn('retryJob', src.split('private fun dropSeekIntent()')[0])
        drop = src.split('private fun dropSeekIntent()')[1].split('fun seekToIndex(')[0]
        self.assertIn('retryJob?.cancel()', drop)
        self.assertIn('itemRetries = 0', drop)


class FailureIsVisibleAndActionable(unittest.TestCase):
    """Остановка без объяснения хуже пропуска: человек не знает ни причины, ни что нажать."""

    def test_controller_exposes_manual_retry(self):
        src = read('playback/PlayerController.kt')
        self.assertIn('fun retryCurrent()', src)
        retry = strip_comments(src.split('fun retryCurrent()')[1].split('/**')[0])
        self.assertIn('itemRetries = 0', retry)
        self.assertIn('lastError = null', retry)
        self.assertIn('p.prepare()', retry)
        self.assertNotIn('seekToNextMediaItem', retry)

    def test_view_model_forwards_retry_and_dismiss(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('fun retryPlayback() = player.retryCurrent()', vm)
        self.assertIn('fun clearPlaybackError() = player.clearError()', vm)

    def test_player_screen_actually_renders_the_error(self):
        screen = read('ui/screens/PlayerScreen.kt')
        self.assertIn('playback.error?.let', screen)
        self.assertIn('onRetry = vm::retryPlayback', screen)
        self.assertIn('onDismiss = vm::clearPlaybackError', screen)
        self.assertIn('private fun PlaybackErrorStrip(', screen)

    def test_error_strip_does_not_offer_skip(self):
        screen = read('ui/screens/PlayerScreen.kt')
        strip = strip_comments(screen.split('private fun PlaybackErrorStrip(')[1])
        self.assertNotIn('vm::next', strip)
        self.assertNotIn('Следующий', strip)


if __name__ == '__main__':
    unittest.main(verbosity=2)
