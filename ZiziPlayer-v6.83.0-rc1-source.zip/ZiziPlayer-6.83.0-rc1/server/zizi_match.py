"""zizi_match.py — подбор YouTube-записи под трек из каталога (правила 6, «умный подбор»).

Чистые функции: ни сети, ни SQLite, ни yt-dlp. Всё, что ходит наружу, живёт в zizi_catalog.py;
здесь только решение «какой кандидат лучше и годится ли он вообще».

Почему не «ворота»
------------------
Правила 1.10–1.13 были набором булевых ворот (название целиком, артист подряд, длительность
±5 с, версия в точности). Любая осечка в любых воротах = 404. Для плеера, у которого каталог
берётся из Deezer, а звук из YouTube, это ошибка по построению: у свежих релизов (фонк, бразильский
фанк, религиозные записи) на YouTube нет «чистого» Topic-аплоада, есть перезаливы с произвольными
названиями и длительностями, и ворота отклоняют всё.

Здесь вместо ворот работают три разных механизма:

1. ВЕТО — только то, что точно ДРУГАЯ запись или не музыка: кавер/караоке/live/ремикс, которых
   не просили; обратное направление скорости; сборники и часовые петли; ролики-обзоры; кандидат
   по длительности «в разы» не тот. Вето не зависит от счёта и не обходится.
2. СЧЁТ — всё остальное складывается в число (название, артист, длительность, версия, источник).
   Каждая составляющая объяснима и лежит в таблице W ниже; нет скрытых порогов.
3. РАНГ ВЕРСИИ — «та же версия» всегда важнее «похожая». Подмена версии (оригинал вместо
   Ultra Slowed) возможна, но ТОЛЬКО если настоящей версии нет вовсе, и помечается в ответе.

Предпочтение аудио-дорожек: «Artist - Topic» (автозагруженные из дистрибьютора, звук как в mp3,
квадратная обложка) получают бонус, клипы и lyric-видео — штраф. Выбор остаётся разрешённым:
если кроме клипа ничего нет, играет клип.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field, replace

from zizi_versions import SPEED_TAGS, speed_compatible, speed_family, strip_version_phrases, version_tags

RULES = 6

# ── Таблица весов. Единственное место, где живут числа. ────────────────────────────────────────
W = dict(
    title=40.0,            # × доля совпавших слов названия (0..1)
    artist_strong=25.0,    # все слова имени артиста найдены в названии/канале
    artist_partial=12.0,   # часть слов, либо только гостевой артист
    topic_artist=8.0,      # канал «<артист> - Topic» (автозагрузка дистрибьютора)
    topic_other=3.0,       # Topic без подтверждённого артиста
    dur_tight=25.0, dur_ok=18.0, dur_loose=6.0, dur_far=-12.0,
    ver_exact=12.0,        # версия записи совпала (включая «обе без пометок»)
    ver_family=-8.0,       # то же направление, но степень не уточнена с одной из сторон
    ver_degree=-12.0,      # то же направление, степени разные (Ultra вместо Super)
    ver_plain=-20.0,       # подмена: просили версию, нашёлся оригинал
    extra_each=-2.5, extra_cap=-15.0,
    official_audio=4.0, video=-10.0, lyric=-8.0, visualizer=-3.0, vevo=2.0, reupload=-6.0,
    foreign_artist=-25.0,
)
PLAY_MIN = 45.0        # ниже — не играем
PLAY_MIN_NOARTIST = 60.0   # без подтверждения артиста нужен запас: тёзка с той же длительностью
PLAY_MIN_SUB = 40.0    # подмена версии: артист обязателен, длительность не штрафуется
PLAY_MIN_WEAK = 30.0   # strict=false (старый параметр): «хоть что-то похожее»

# Подмена версии, когда нужной записи на YouTube нет. "all" — играть другую степень («Super» вместо «Ultra»)
# и оригинал вместо «Slowed» с честной пометкой substituted; "degree" — только другую степень;
# "off" — только точную версию (прежнее поведение 6.66, чаще 404). Задаётся ZIZI_SUBSTITUTE в catalog.
SUBSTITUTE = "all"
CONFIDENT = 85.0
GOOD = 60.0
STOP_SCORE = 75.0      # охота прекращается, когда нашли настоящую версию с таким счётом
COV_MIN = 0.6          # «Police Attack» против «Cops Attack»: половина слов — это уже другая песня
SOFT_W = 0.3           # вес «служебных» слов названия (сура, часть, том): без них та же запись, но нужное имя обязано быть
MAX_EXTRAS_NOARTIST = 1   # артист не подтверждён: в названии кандидата допустимо не более одного постороннего слова

# ── Текст ───────────────────────────────────────────────────────────────────────────────────────
_SPECIAL = str.maketrans({"ø": "o", "ł": "l", "ß": "ss", "æ": "ae", "œ": "oe", "đ": "d", "ı": "i",
                          "ð": "d", "þ": "th", "ـ": "", "ى": "ي", "ة": "ه"})
_TOKEN = re.compile(r"[^\W_]+", re.UNICODE)


def fold(text) -> str:
    """Регистр, акценты, арабская огласовка и варианты алефа/йа/та-марбуты сводятся к одному виду."""
    s = unicodedata.normalize("NFKD", text or "").casefold()
    return "".join(ch for ch in s if not unicodedata.combining(ch)).translate(_SPECIAL)


_RU = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
               ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "i", "k", "l", "m", "n", "o", "p", "r", "s",
                "t", "u", "f", "h", "ts", "ch", "sh", "sch", "", "i", "", "e", "yu", "ya"]))

# Слова-синонимы, которые обязаны считаться одним словом в разных написаниях.
_ALIAS = {}
for _canon, _forms in {
    "surah": "surah surat sura sourate suresi surasi сура сурат سوره سورت",
    "ayah": "ayah ayat aya ayatul آيه ايه",
    "feat": "feat ft featuring",
}.items():
    for _f in _forms.split():
        _ALIAS[fold(_f)] = _canon

# Служебные слова: не требуются от кандидата и не считаются лишними.
STOP = frozenset("a an the of and or in on at to for with by from de la le les el los las del da do di du "
                 "al ul ad ar as ash en und et y и в на с по к из о за я".split())
# Слова-«рубрики»: сами по себе ничего не говорят о том, какая это запись. «Surah Al-Fatiha» без слова
# «сура» — та же запись; «Surah Al-Baqarah» вместо «Surah Al-Fatiha» — другая. Поэтому слово есть, но весит
# мало, а имя суры обязано совпасть.
SOFT_WORDS = frozenset("surah ayah juz para part pt vol volume chapter".split())
HONORIFIC = frozenset("dj mc dr sheikh shaykh sheik sheikh imam qari qaari hafiz ustaz ustad".split())
# Слова оформления: не дают очков названию и не считаются «лишними» в названии кандидата.
NOISE = frozenset((
    "official video audio lyrics lyric lyricvideo hd hq 4k 8k 1080p 720p music song songs topic vevo records "
    "recordings release new full version ver ft feat featuring prod remastered remaster explicit clean "
    "visualizer visualiser clip mv m v original art oficial letra officiel ofiicial clipe videoclip "
    "free download copyright no sound quality channel tv youtube yt by phonk funk brazilian drift bass "
    "trap rap hiphop hip hop edm house mix remix edit extended radio single album deluxe stereo mono "
    "bonus track digital standard main out now premiere exclusive world wide the a an and").split())
UPLOADER_NOISE = frozenset("topic vevo official music records recordings channel tv entertainment label "
                           "network media productions studio studios production".split())

_YEAR = re.compile(r"^(?:19|20)\d\d$")


def _lat(t: str) -> str:
    return "".join(_RU.get(ch, ch) for ch in t)


_LOOSE = (("sch", "s"), ("sh", "s"), ("ch", "c"), ("kh", "h"), ("zh", "j"), ("ts", "c"), ("ph", "f"),
          ("ck", "k"), ("q", "k"), ("w", "v"), ("x", "ks"), ("y", "i"))


def loose(t: str) -> str:
    """Ключ «на слух»: translit кириллицы + типовые расхождения написаний (fatiha/fatihah, mishary/mishari)."""
    s = _lat(t)
    for a, b in _LOOSE:
        s = s.replace(a, b)
    s = re.sub(r"(.)\1+", r"\1", s)
    if len(s) > 3 and s.endswith("h") and s[-2] in "aeiou":
        s = s[:-1]
    return s


def phon(t: str) -> str:
    s = loose(t)
    return s[:1] + re.sub(r"[aeiou]", "", s[1:])


def script_of(t: str) -> str:
    for ch in t:
        if ch.isalpha():
            o = ord(ch)
            if 0x0400 <= o <= 0x052F:
                return "cyr"
            if 0x0600 <= o <= 0x077F or 0xFB50 <= o <= 0xFEFF:
                return "ara"
            if 0x3040 <= o <= 0x30FF or 0x3400 <= o <= 0x9FFF or 0xAC00 <= o <= 0xD7AF:
                return "cjk"
            return "lat" if o < 0x250 else "oth"
    return "num"


@dataclass(frozen=True)
class Tok:
    t: str       # слово как есть (после fold и синонимов)
    l: str       # loose-ключ
    p: str       # согласный скелет
    s: str       # письменность
    w: float = 1.0


def mk_tok(t: str, w: float = 1.0) -> Tok:
    t = _ALIAS.get(t, t)
    return Tok(t, loose(t) if script_of(t) in ("lat", "cyr") else t, phon(t) if script_of(t) in ("lat", "cyr") else t,
               script_of(t), w)


def words(text) -> list[str]:
    return [_ALIAS.get(w, w) for w in _TOKEN.findall(fold(text))]


def _within1(a: str, b: str) -> bool:
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        return sum(x != y for x, y in zip(a, b)) <= 1
    if la > lb:
        a, b = b, a
    i = 0
    while i < len(a) and a[i] == b[i]:
        i += 1
    return a[i:] == b[i + 1:]


class TokSet:
    """Мешок слов кандидата с быстрым поиском точных/«на слух» совпадений."""

    def __init__(self, toks):
        self.toks = list(toks)
        self.t = {x.t for x in self.toks}
        self.l = {x.l for x in self.toks}
        self.p = {x.p for x in self.toks}
        self.joined = "".join(x.l for x in self.toks)

    def match(self, r: Tok, fuzzy: bool = True) -> float:
        if r.s == "num":
            return 1.0 if r.t in self.t else 0.0
        if r.t in self.t:
            return 1.0
        if r.l and r.l in self.l:
            return 0.95
        if not fuzzy:
            return 0.0
        if len(r.l) >= 5 and any(_within1(r.l, x) for x in self.l):
            return 0.85
        if len(r.l) == 4 and any(x[:1] == r.l[:1] and _within1(r.l, x) for x in self.l):
            return 0.7
        if len(r.l) >= 5 and len(r.p) >= 3 and r.p in self.p:
            return 0.75
        return 0.0


def _bag(tok: Tok) -> str:
    return "lat" if tok.s in ("lat", "cyr", "num") else tok.s


def coverage(req_toks, have: TokSet, fuzzy: bool = True) -> float:
    """Доля (по весам) слов запроса, найденных в кандидате. Письменности считаются раздельно:
    для «سورة الملك Al-Mulk» достаточно полного совпадения арабской ИЛИ латинской части."""
    toks = [t for t in req_toks if t.w > 0]
    content = [t for t in toks if t.t not in STOP] or toks
    if not content:
        return 0.0
    bags: dict[str, list[Tok]] = {}
    nums = [t for t in content if t.s == "num"]
    for t in content:
        if t.s != "num":
            bags.setdefault(_bag(t), []).append(t)
    if not bags:
        bags["lat"] = []
    best = 0.0
    for lst in bags.values():
        group = lst + nums
        total = sum(t.w for t in group)
        if total <= 0:
            continue
        got = sum(t.w * have.match(t, fuzzy) for t in group)
        cov = got / total
        # «Al Fatiha» ↔ «AlFatiha», «Sem Demora» ↔ «SemDemora»: склейка без пробелов.
        glued = "".join(t.l for t in group if t.w >= 1.0)
        if len(glued) >= 6 and glued in have.joined:
            cov = max(cov, 0.97)
        best = max(best, cov)
    return min(best, 1.0)


# ── Версии записи ───────────────────────────────────────────────────────────────────────────────
# Те же выражения, что и в 1.12/1.13: «слово учтено как версия» и «слово убрано из названия»
# не должны расходиться.
EXTRA_TAG_PATTERNS = (
    ("instrumental", r"\binstrumental\b"), ("acoustic", r"\b(?:acoustic|unplugged)\b"),
    ("remix", r"\b(?:flip|vip[\s_-]*mix|rmx)\b"),
    ("bass_boosted", r"\bbass[\s_-]*boost(?:ed)?\b"),
    ("8d", r"\b8d\b"), ("edit", r"\b(?:edit|extended)\b"),
    ("remaster", r"\bremaster(?:ed)?\b"),
    ("cover", r"\b(?:кавер|караоке)\b"),
)
# Эти пометки в кандидате, которых не было в запросе, = другая запись. Вето.
HARD_EXTRA = frozenset({"cover", "live", "remix", "instrumental", "acoustic", "bass_boosted", "8d"})
# Эти — та же песня в другой обработке: штраф, не вето.
SOFT_EXTRA = {"reverb": -18.0, "edit": -20.0, "remaster": -3.0}
# Скобка с этими пометками выбрасывается целиком из слов названия («Live at Wembley 1986»).
_DROP_GROUP = frozenset({"live", "acoustic", "instrumental", "remaster", "edit", "cover", "reverb",
                         "bass_boosted", "8d"})
# Слова в скобках, которые ничего не говорят об идентичности.
_PAREN_DROP = frozenset("album single original explicit clean version versions edition bonus track deluxe digital "
                        "standard main stereo mono audio official lp ep mix club radio vocal extended edit remaster "
                        "remastered".split())

_NORM_KEEP = re.compile(r"[\[(]([^\])]*)[\])]")


def _norm_text(text) -> str:
    return " ".join(unicodedata.normalize("NFKC", text or "").casefold().split())


def all_tags(text) -> set:
    tags = set(version_tags(text))
    norm = _norm_text(text)
    for tag, pattern in EXTRA_TAG_PATTERNS:
        if re.search(pattern, norm):
            tags.add(tag)
    return tags


def _strip_versions(text: str) -> str:
    text = strip_version_phrases(_norm_text(text))
    for _tag, pattern in EXTRA_TAG_PATTERNS:
        text = re.sub(pattern, " ", text)
    return text


_CREDIT = re.compile(r"[\[(]\s*(?:feat(?:uring)?|ft)\.?\s+([^\])]+)[\])]", re.I)
_FEATURE = re.compile(r"\b(?:feat(?:uring)?|ft)\.?\s+", re.I)
_DASH = re.compile(r"\s[-–—]\s")


def split_credits(title: str):
    """(название без «feat.», гости). Именованный ремикс после гостя не проглатывается."""
    guests = []

    def take(m):
        guests.append(m.group(1))
        return " "
    base = _CREDIT.sub(take, title or "")
    m = _FEATURE.search(base)
    if m and not all_tags(base[m.end():]):
        guests.append(base[m.end():])
        base = base[:m.start()]
    return base.strip(), " ".join(guests).strip()


def title_tokens(raw: str) -> tuple[list[Tok], set]:
    """Слова названия запроса с весами: основная часть 1.0, скобки 0.35, нейтральные пометки 0."""
    tags = all_tags(raw)
    base, _guests = split_credits(raw)
    parts = re.split(r"([\[(][^\])]*[\])])", base)
    out: list[Tok] = []
    for part in parts:
        if not part or not part.strip():
            continue
        if part[0] in "[(":
            inner = part[1:-1]
            itags = all_tags(inner)
            if itags & _DROP_GROUP and "remix" not in itags:
                continue
            weight = 1.0 if "remix" in itags else 0.35
            ws = [w for w in words(_strip_versions(inner)) if w not in _PAREN_DROP or "remix" in itags]
            out.extend(mk_tok(w, weight) for w in ws)
            continue
        m = _DASH.search(part)
        head, tail = (part[:m.start()], part[m.end():]) if m else (part, "")
        out.extend(mk_tok(w, 1.0) for w in words(_strip_versions(head)))
        if tail:
            twords = words(_strip_versions(tail))
            if all_tags(tail) & _DROP_GROUP:
                continue
            # «- Remastered 2011», «- Single Version»: нейтральный хвост не требуется целиком.
            keep = [w for w in twords if w not in _PAREN_DROP]
            weight = 0.35 if m else 1.0
            out.extend(mk_tok(w, weight) for w in keep)
    out = [t for t in out if t.t and not (len(t.t) == 1 and t.s == "lat" and len(out) > 1)]
    # Служебное слово смягчается, только если рядом есть настоящее имя; название из одной «Part 2» не трогаем.
    if any(t.w >= 1.0 and t.t not in SOFT_WORDS and t.t not in STOP for t in out):
        out = [replace(t, w=t.w * SOFT_W) if t.t in SOFT_WORDS else t for t in out]
    return out, tags


def clean_query_title(raw: str) -> str:
    """Название для поискового запроса: без «(feat. X)» и «(Album Version)», версия и имя ремиксера остаются."""
    base, _g = split_credits(raw)

    def drop(m):
        ws = [w for w in _TOKEN.findall(fold(m.group(1)))]
        return " " if ws and all(w in _PAREN_DROP for w in ws) else m.group(0)
    return " ".join(_NORM_KEEP.sub(drop, base).split())


_NAME_SPLIT = re.compile(r"\s*(?:,|;|&|\+|\s/\s|\s×\s|\sx\s|\bfeat\.?\s|\bft\.?\s|\bfeaturing\b|\bvs\.?\s|\bwith\b|\band\b)\s*", re.I)


def artist_names(artist: str, extra=()) -> list[list[Tok]]:
    names = []
    for raw in [artist or ""] + list(extra or ()):
        for piece in _NAME_SPLIT.split(raw):
            ws = words(piece)
            core = [w for w in ws if w not in HONORIFIC] or ws
            toks = [mk_tok(w) for w in core if w]
            if toks and toks not in names:
                names.append(toks)
    return names


@dataclass
class Request:
    title: str
    artist: str
    dur: float
    isrc: str = ""
    tags: set = field(default_factory=set)
    toks: list = field(default_factory=list)
    names: list = field(default_factory=list)
    guests: list = field(default_factory=list)
    qtitle: str = ""

    @property
    def speed(self):
        return self.tags & SPEED_TAGS

    @property
    def distinctive(self) -> bool:
        """Название достаточно редкое, чтобы по нему искать без артиста."""
        content = [t for t in self.toks if t.w >= 1.0 and t.t not in STOP]
        return len(content) >= 2 or any(len(t.t) >= 7 for t in content)


def make_request(title, artist, dur=0, isrc="", alt_artists=()) -> Request:
    toks, tags = title_tokens(title or "")
    _base, guest_text = split_credits(title or "")
    try:
        dur = float(dur or 0)
    except (TypeError, ValueError):
        dur = 0.0
    return Request(title=title or "", artist=artist or "", dur=max(dur, 0.0), isrc=isrc or "", tags=tags,
                   toks=toks, names=artist_names(artist, alt_artists),
                   guests=[mk_tok(w) for w in words(guest_text)], qtitle=clean_query_title(title or ""))


# ── Признаки кандидата ──────────────────────────────────────────────────────────────────────────
def _rx(pattern):
    return re.compile(pattern, re.I)


# Класс «точно не та запись / не музыка». Срабатывает, только если в НАЗВАНИИ ЗАПРОСА такого слова нет.
JUNK = {
    "compilation": _rx(r"\b(?:\d+(?:[.,]\d+)?[\s-]*(?:hours?|hrs?|ч(?:ас(?:а|ов)?)?)\b|full[\s-]+album|complete[\s-]+album|"
                       r"greatest[\s-]+hits|best[\s-]+of\b|top[\s-]+\d+|non[\s-]?stop|mega[\s-]?mix|playlist|"
                       r"compilation|discography|\d+[\s-]+songs|all[\s-]+songs|сборник|подборка|весь[\s-]+альбом|"
                       r"mix[\s-]+20\d\d|mashup)\b"),
    "loop": _rx(r"\b(?:loop(?:ed)?|on[\s-]+repeat)\b"),
    "non_music": _rx(r"\b(?:reaction|reacts?|reacting|tutorial|lesson|how[\s-]+to|explained|interview|"
                     r"behind[\s-]+the[\s-]+scenes|making[\s-]+of|trailer|unboxing|gameplay|walkthrough|asmr|"
                     r"podcast|news|review|разбор|урок|реакция|обзор)\b"),
    "type_beat": _rx(r"\b(?:type[\s-]+beat|free[\s-]+beat|beat[\s-]+for[\s-]+sale|backing[\s-]+track|минусовка)\b"),
    "ringtone": _rx(r"(?:\b(?:ringtone|рингтон|whatsapp[\s-]+status|status[\s-]+video)\b|#shorts?\b)"),
    "cover_ish": _rx(r"\b(?:cover[\s-]+by|covered[\s-]+by|tribute|originally[\s-]+performed|in[\s-]+the[\s-]+style[\s-]+of|"
                     r"made[\s-]+famous|piano[\s-]+(?:version|cover)|guitar[\s-]+cover|drum[\s-]+cover|"
                     r"bass[\s-]+cover|violin[\s-]+cover|ukulele|female[\s-]+version|male[\s-]+version|parody)\b"),
    "gaming_news": _rx(r"\b(?:cs2|cs[\s:-]?go|csgo|valorant|fortnite|minecraft|roblox|pubg|warzone|dota\s?2|"
                       r"highlights?|montage|funny[\s-]+moments|bodycam|body[\s-]?cam|dashcam|cctv|footage|"
                       r"breaking[\s-]+news|news|livestream|full[\s-]+episode|episode[\s-]+\d+|season[\s-]+\d+|"
                       r"gameplay|stream[\s-]+highlights?|1v[1-5])\b"),
    "preview": _rx(r"\b(?:preview|snippet|teaser|short[\s-]+version|30[\s-]*sec(?:onds?)?)\b"),
}
_VIDEO = _rx(r"\b(?:official[\s-]+(?:music[\s-]+)?video|music[\s-]+video|video[\s-]+oficial|clip[\s-]+officiel|"
             r"videoclip|official[\s-]+m/?v|клип|official[\s-]+hd[\s-]+video|video[\s-]+clip|\(mv\)|\[mv\])")
_LYRIC = _rx(r"\b(?:lyrics?(?:[\s-]+video)?|lyric[\s-]+video|letra|с[\s-]+текстом|with[\s-]+lyrics)\b")
_VISUAL = _rx(r"\b(?:visuali[sz]er|audio[\s-]+visual)\b")
_AUDIO = _rx(r"\b(?:official[\s-]+audio|audio[\s-]+oficial|audio[\s-]+officiel|provided[\s-]+to[\s-]+youtube)\b")
_REUPLOAD = _rx(r"\b(?:re-?upload|copyright[\s-]+free|no[\s-]+copyright|free[\s-]+download)\b")
_TOPIC = _rx(r"\s-\s*topic\s*$")
_VEVO = _rx(r"vevo\s*$")


@dataclass
class Verdict:
    vid: str
    title: str
    uploader: str
    dur: float
    score: float = 0.0
    rank: int = 0                 # 0 та же версия, 1 другая степень, 2 подмена
    tier: str = "reject"          # exact | good | loose | variant | reject
    veto: str = ""
    substituted: bool = False
    confident: bool = False
    source: str = "upload"        # topic | video | lyric | upload
    parts: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.tier != "reject"

    def as_dict(self) -> dict:
        d = dict(vid=self.vid, title=self.title[:120], uploader=self.uploader[:60], dur=round(self.dur or 0),
                 score=round(self.score, 1), rank=self.rank, tier=self.tier, source=self.source,
                 substituted=self.substituted, parts={k: round(v, 2) for k, v in self.parts.items()})
        if self.veto:
            d["veto"] = self.veto
        if self.notes:
            d["notes"] = self.notes[:6]
        return d


# ── Оценка одного кандидата ─────────────────────────────────────────────────────────────────────
_VID = re.compile(r"^[A-Za-z0-9_-]{11}$")


def _name_cov(name, have: TokSet) -> float:
    content = [t for t in name if t.t not in STOP] or name
    if not content:
        return 0.0
    got = sum(have.match(t, fuzzy=False) for t in content) / len(content)
    glued = "".join(t.l for t in content)
    if len(glued) >= 6 and glued in have.joined:
        got = max(got, 0.97)
    return got


def artist_level(names, have: TokSet) -> str:
    """strong — все слова главного артиста найдены; partial — часть слов либо только гостевой артист."""
    if not names:
        return "unknown"
    if _name_cov(names[0], have) >= 0.97:
        return "strong"
    if _name_cov(names[0], have) >= 0.5 or any(_name_cov(n, have) >= 0.97 for n in names[1:]):
        return "partial"
    return "none"


def _foreign_artist(title: str, req: Request) -> bool:
    """«Другой Артист - Название»: слева от тире стоит чужое имя. Справа («Название | канал») — нет."""
    parts = re.split(r"\s[-–—]\s", title, maxsplit=1)
    if len(parts) != 2:
        return False
    left = [mk_tok(w) for w in words(_strip_versions(parts[0]))
            if w not in NOISE and w not in STOP and not _YEAR.match(w)]
    right = TokSet(mk_tok(w) for w in words(_strip_versions(parts[1])))
    if not left or coverage(req.toks, right) < 0.8:
        return False
    return not any(TokSet(req.toks).match(t, fuzzy=False) >= 0.95 for t in left)


def _dur_points(req: Request, dur: float, rank: int):
    E, G = req.dur, dur
    if E <= 0 or G <= 0:
        return 0.0, "unknown", ""
    d = abs(G - E)
    if G > max(2.2 * E, E + 120) or (G < 0.35 * E and E - G > 25):
        return 0.0, "wild", f"duration {G:.0f}s vs {E:.0f}s"
    if rank >= 2:
        return 0.0, "n/a", ""        # подмена: длительность оригинала у другой обработки другая
    if d <= max(3.0, 0.03 * E):
        return W["dur_tight"], "tight", ""
    if d <= max(8.0, 0.08 * E):
        return W["dur_ok"], "ok", ""
    if d <= max(20.0, 0.20 * E):
        return W["dur_loose"], "loose", ""
    return W["dur_far"], "far", ""


def judge(req: Request, cand: dict, weak: bool = False) -> Verdict:
    vid = str(cand.get("vid") or "")
    title = str(cand.get("title") or "")
    up = str(cand.get("uploader") or "")
    try:
        dur = float(cand.get("dur") or 0)
    except (TypeError, ValueError):
        dur = 0.0
    v = Verdict(vid, title, up, dur)

    def reject(reason):
        v.veto, v.tier = reason, "reject"
        return v

    if not _VID.match(vid):
        return reject("bad id")
    if not title.strip():
        return reject("no title")
    if not req.toks:
        return reject("request has no title words")

    # В «запросе» и артист: группа «Breaking Benjamin» не должна браковаться словом «breaking».
    norm_title, norm_req = _norm_text(title), _norm_text(req.title + " " + req.artist)
    for name, rx in JUNK.items():
        if rx.search(norm_title) and not rx.search(norm_req):
            return reject(f"junk:{name}")

    ctags = all_tags(title)
    wt = req.tags
    ws, cs = wt & SPEED_TAGS, ctags & SPEED_TAGS
    fam_w, fam_c = speed_family(ws), speed_family(cs)
    if ws == cs:
        rel = "exact"
    elif fam_w and fam_w == fam_c:
        rel = "family" if speed_compatible(ws, cs) else "degree"
    elif not ws and cs:
        return reject("speed variant, original requested")
    elif ws and not cs:
        rel = "plain"
    else:
        return reject("opposite speed direction")
    ver = {"exact": W["ver_exact"], "family": W["ver_family"], "degree": W["ver_degree"], "plain": W["ver_plain"]}[rel]
    rank = {"exact": 0, "family": 0, "degree": 1, "plain": 2}[rel]
    for t in ctags - wt - SPEED_TAGS:
        if t in HARD_EXTRA:
            return reject(f"unrequested version:{t}")
        ver += SOFT_EXTRA.get(t, -8.0)
    for t in wt - ctags - SPEED_TAGS:
        if t in HARD_EXTRA:
            rank = 2
            ver = min(ver, W["ver_plain"])
            v.notes.append(f"requested {t} not found")
        else:
            ver -= 3.0
    v.rank, v.substituted = rank, rank >= 1
    if rank >= 1 and not weak and SUBSTITUTE != "all" and not (rank == 1 and SUBSTITUTE == "degree"):
        return reject("version substitution disabled")
    if rel != "exact":
        v.notes.append(f"version:{rel}")

    # название
    ctoks = [mk_tok(w) for w in words(_strip_versions(title))]
    cset = TokSet(ctoks)
    cov = coverage(req.toks, cset)
    if cov < (0.34 if weak else COV_MIN):
        return reject(f"title coverage {cov:.2f}")

    # артист
    all_title = TokSet(mk_tok(w) for w in words(title))
    up_words = [w for w in words(_TOPIC.sub("", up)) if w not in UPLOADER_NOISE]
    up_set = TokSet(mk_tok(w) for w in up_words)
    have = TokSet(list(all_title.toks) + list(up_set.toks))
    level = artist_level(req.names, have)
    is_topic = bool(_TOPIC.search(up))
    topic_artist = is_topic and bool(req.names) and (
        _name_cov(req.names[0], up_set) >= 0.97 or any(_name_cov(n, up_set) >= 0.97 for n in req.names[1:]))
    artist_pts = {"strong": W["artist_strong"], "partial": W["artist_partial"]}.get(level, 0.0)
    known_artist = level in ("strong", "partial")
    if not known_artist and not weak and not req.distinctive and not topic_artist:
        return reject("generic title needs a confirmed artist")
    foreign = (not known_artist) and _foreign_artist(title, req)

    # источник
    source = "topic" if is_topic else "upload"
    src_pts = 0.0
    if is_topic:
        src_pts += W["topic_artist"] if topic_artist else W["topic_other"]
    elif _VIDEO.search(norm_title) and not _VIDEO.search(norm_req):
        source, src_pts = "video", W["video"]
    elif _LYRIC.search(norm_title) and not _LYRIC.search(norm_req):
        source, src_pts = "lyric", W["lyric"]
    if _VISUAL.search(norm_title):
        src_pts += W["visualizer"]
    if _AUDIO.search(norm_title):
        src_pts += W["official_audio"]
    if _VEVO.search(_norm_text(up)) and known_artist:
        src_pts += W["vevo"]
    if _REUPLOAD.search(norm_title):
        src_pts += W["reupload"]
    v.source = source

    # длительность
    dur_pts, band, bad = _dur_points(req, dur, rank)
    if bad:
        return reject(bad)

    # лишние слова в названии кандидата
    known = TokSet(list(req.toks) + list(req.guests) + [t for n in req.names for t in n])
    extras = [t.t for t in ctoks if t.t not in NOISE and t.t not in STOP and t.t not in HONORIFIC and not _YEAR.match(t.t)
              and len(t.t) > 1 and known.match(t, fuzzy=False) < 0.95]
    extra_pts = max(W["extra_cap"], W["extra_each"] * len(extras))
    # Артист нигде не подтверждён: единственное, что связывает кандидата с запросом, — название. Тогда оно
    # обязано быть почти чистым. «Bodycam footage shows attack on two female cops | 7NEWS» содержит слова
    # «cops» и «attack», но семь посторонних слов — это ролик, а не трек. Брак по одному слову прощаем
    # («Название | канал»), по двум и больше — нет.
    if not known_artist and not weak and len(extras) > MAX_EXTRAS_NOARTIST:
        return reject(f"unexplained words with no confirmed artist: {','.join(extras[:4])}")

    parts = dict(title=W["title"] * cov, artist=artist_pts, source=src_pts, dur=dur_pts, version=ver,
                 extras=extra_pts, foreign=W["foreign_artist"] if foreign else 0.0)
    v.parts = parts
    v.score = sum(parts.values())
    v.notes += ([f"extra:{','.join(extras[:4])}"] if extras else []) + ([f"dur:{band}"] if band != "n/a" else [])
    v.notes.append(f"artist:{level}")

    if weak:
        floor = PLAY_MIN_WEAK
    elif rank == 2:
        if not known_artist:
            return reject("substitution needs a confirmed artist")
        floor = PLAY_MIN_SUB
    elif not known_artist:
        floor = PLAY_MIN_NOARTIST
    else:
        floor = PLAY_MIN
    if v.score < floor:
        return reject(f"score {v.score:.0f} < {floor:.0f}")

    # «Чистый Topic»: автозагрузка дистрибьютора (мастер-файл, квадратная обложка), название слово в слово и
    # длительность в пределах трёх процентов. Имя артиста на YouTube может быть другим (H2HELL → FORGET777),
    # но запись та же, и дальше охотиться незачем: обычный трек стоит один вызов yt-dlp.
    topic_clean = (rank == 0 and is_topic and band == "tight" and cov >= 0.97 and not extras and v.score >= STOP_SCORE)
    v.confident = (rank == 0 and v.score >= CONFIDENT and known_artist and band in ("tight", "ok")) or topic_clean
    v.tier = ("variant" if rank >= 1 else "exact" if v.confident else "good" if v.score >= GOOD else "loose")
    return v


# ── Выбор среди кандидатов и план поиска ────────────────────────────────────────────────────────
class Selector:
    """Копит кандидатов по ходу охоты. Ранг версии главнее счёта; внутри ранга — лучший счёт."""

    def __init__(self, req: Request, weak: bool = False):
        self.req, self.weak = req, weak
        self.all: dict[str, Verdict] = {}
        self.seen = 0

    def add(self, cands) -> None:
        for c in cands or ():
            self.seen += 1
            v = judge(self.req, c, self.weak)
            old = self.all.get(v.vid)
            if v.vid and (old is None or (v.ok, v.score) > (old.ok, old.score)):
                self.all[v.vid] = v

    def viable(self):
        return [v for v in self.all.values() if v.ok]

    def best(self):
        ok = self.viable()
        if not ok:
            return None
        rank = min(v.rank for v in ok)
        pool = [v for v in ok if v.rank == rank]
        E = self.req.dur
        return max(pool, key=lambda v: (round(v.score, 3), -(abs(v.dur - E) if E > 0 and v.dur > 0 else 1e9)))

    def done(self, queries_run: int) -> bool:
        b = self.best()
        if not b or b.rank != 0:
            return False
        return b.confident or (b.score >= STOP_SCORE and queries_run >= 2)

    def report(self, limit: int = 12) -> list:
        order = sorted(self.all.values(), key=lambda v: (not v.ok, v.rank, -v.score))
        return [v.as_dict() for v in order[:limit]]

    def why_missed(self) -> str:
        if not self.all:
            return "no results"
        worst = sorted(self.all.values(), key=lambda v: -v.score)[:3]
        return "; ".join(f"{v.title[:50]!r}→{v.veto or v.tier}" for v in worst)[:300]


def primary_artist(req: Request) -> str:
    return (_NAME_SPLIT.split(req.artist or "")[0] if req.artist else "").strip()


def build_queries(req: Request):
    """[(метка, текст, сколько результатов)] в порядке «сначала то, что даёт аудио-дорожку»."""
    a, t = primary_artist(req), req.qtitle
    plan = []
    if a:
        plan.append(("topic", f"{a} - Topic {t}", 6))
    plan.append(("plain", f"{req.artist} {t}".strip() if req.artist else t, 8))
    if req.distinctive or not a:
        plan.append(("title", t, 8))
    if req.isrc:
        plan.append(("isrc", req.isrc, 3))
    seen, out = set(), []
    for label, text, n in plan:
        key = " ".join(fold(text).split())
        if key and key not in seen:
            seen.add(key)
            out.append((label, text, n))
    return out
