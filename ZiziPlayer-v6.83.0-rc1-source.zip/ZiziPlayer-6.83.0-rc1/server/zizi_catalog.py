"""
zizi_catalog.py — слой каталога для ZiziPlayer.
Метаданные: Spotify (плейлисты/поиск) + Deezer (безключевой запасной).
Звук: НЕ ТРОГАЕМ. Модуль отдаёт youtube_id, дальше работает старый /resolve + /stream.

Ставится рядом с zizi_resolver.py:
    from zizi_catalog import router as catalog_router
    app.include_router(catalog_router)

Переменные окружения (в /opt/zizi/zizi.env):
    ZIZI_SP_ID=...            # Spotify Client ID     (необязательно, без него работает Deezer)
    ZIZI_SP_SECRET=...        # Spotify Client Secret
    ZIZI_CATALOG_DB=/opt/zizi/catalog.db

1.14. Подбор записи вынесен в zizi_match.py (чистые функции, без сети): счёт и ранг версии вместо
булевых ворот. См. SERVER_UPDATE_1.14.md.
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
import sqlite3
import subprocess
import time
import json
import math
import unicodedata
from contextlib import closing
import threading
from typing import Optional

import requests
from concurrent.futures import ThreadPoolExecutor
from zizi_scheduler import SCHEDULER, SchedulerBusy
from zizi_process import run_text, ProcessError
import logging
import zizi_match as zm
from zizi_versions import normalized
from fastapi import (APIRouter, BackgroundTasks, Depends, Header, HTTPException, Query,
                     Request, Response)

# 1.7. Граница «клиент -> каталог». Импорт жёсткий и это намеренно: если zizi_guard.py не
# доехал на VPS, сервис обязан не подняться. Мягкий импорт с молчаливым отключением защиты —
# это ровно патология «написано, но не подключено», из-за которой каталог и стоял открытым.
from zizi_guard import (ExtractBusy, Guard, device_mode, device_ttl, issue_device_token)

_guard = Guard()


def guard_dep(request: Request,
              authorization: Optional[str] = Header(None),
              x_zizi_install: Optional[str] = Header(None)) -> None:
    """Проверка на входе КАЖДОГО роута этого модуля.

    Повешена на сам APIRouter, а не расставлена по эндпоинтам руками. Причина ровно та же,
    по которой мы здесь оказались: список из одиннадцати роутов, который надо не забыть
    дополнить при добавлении двенадцатого, — это не защита, а обещание не ошибиться.
    Новый роут закрыт по умолчанию; исключения перечислены в zizi_guard.OPEN_PATHS.
    """
    d = _guard.admit(
        path=request.url.path,
        authorization=authorization,
        q_token=request.query_params.get("token"),
        # Обложки грузит картиночный загрузчик, который своих заголовков не ставит: там
        # installId приезжает параметром `i`. Заголовок всё равно главнее параметра.
        install_id=x_zizi_install or request.query_params.get("i"),
        client_ip=request.client.host if request.client else None,
    )
    if not d.allowed:
        headers = {"Retry-After": str(d.retry_after)} if d.retry_after else None
        raise HTTPException(d.status, d.reason, headers=headers)


router = APIRouter(dependencies=[Depends(guard_dep)])

# Видно в /catalog/health. Без него нельзя отличить «файл залит» от «сервис не перезапущен» —
# ровно та неопределённость, которая стоила нам целого релиза 6.36.0.
VERSION = "1.15-smart-reco"

SP_ID = os.getenv("ZIZI_SP_ID", "")
SP_SECRET = os.getenv("ZIZI_SP_SECRET", "")
DB_PATH = os.getenv("ZIZI_CATALOG_DB", "/opt/zizi/catalog.db")
IMG_DIR = os.getenv("ZIZI_IMG_DIR", "/opt/zizi/img")
IMG_QUOTA = int(os.getenv("ZIZI_IMG_QUOTA_MB", "512")) * 1024 * 1024
IMG_MAX = 3 * 1024 * 1024
UA = "Mozilla/5.0 (Linux; Android 13) ZiziPlayer/7.0"

# Optional isolated contract: never feed YouTube IDs into the old Deezer route.
from zizi_extra import ExtraCatalog, ExtraError
_extra = ExtraCatalog(os.getenv("ZIZI_EXTRA_DB", DB_PATH + ".extra"), _guard.gate)

_db_lock = threading.Lock()


# ---------------------------------------------------------------- база сопоставлений

def _db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    con.execute(
        """CREATE TABLE IF NOT EXISTS match (
               key   TEXT PRIMARY KEY,   -- isrc, либо 'q:artist - title'
               vid   TEXT NOT NULL,
               score REAL,
               ts    INTEGER
           )"""
    )
    # 1.6 — отрицательный кэш.
    #
    # До 1.6 «не нашли» не запоминалось нигде. Один и тот же трек, по которому охота провалилась,
    # запускал три процесса yt-dlp КАЖДЫЙ раз, когда по нему тапнули. Для клиента это выглядит как
    # «трек думает минуту и скипается», и цена платится заново при каждом нажатии, хотя ответ уже
    # известен. Промах живёт [MISS_TTL] и стоит один SELECT.
    con.execute(
        """CREATE TABLE IF NOT EXISTS miss (
               key  TEXT PRIMARY KEY,
               ts   INTEGER,
               why  TEXT
           )"""
    )
    # Additive migration: legacy matches remain available for rollback, never trusted
    # without the metadata proof produced by this policy.
    con.execute("""CREATE TABLE IF NOT EXISTS match_proof (
        key TEXT PRIMARY KEY, policy INTEGER NOT NULL, metadata TEXT NOT NULL
    )""")
    return con


# 1.14 → 6. Правила подбора переписаны (счёт + ранг версии вместо булевых ворот), поэтому все
# прежние доказательства и, главное, все прежние записи «miss» больше не читаются: новый номер
# заводит отдельное пространство ключей. Чистить базу не нужно и вредно.
MATCH_POLICY = zm.RULES
MATCH_TTL = 7 * 24 * 60 * 60  # Metadata identity TTL; NOT an audio-availability promise.

# Срок жизни найденного зависит от того, насколько ответ надёжен: точное попадание живёт неделю,
# «хорошее» — сутки, остальное (запасная версия, слабое совпадение) — пару часов, чтобы настоящая
# запись, как только появится на YouTube (свежие релизы!), получила шанс заменить временную.
FALLBACK_TTL = int(os.getenv("ZIZI_FALLBACK_TTL", "7200"))
TIER_TTL = {"exact": MATCH_TTL, "good": 24 * 60 * 60, "loose": FALLBACK_TTL, "variant": FALLBACK_TTL}

# Бюджет охоты, секунд. Клиент ждёт ответ до 75 с, но человек — несколько. Охота идёт по плану
# запросов (zm.build_queries) и останавливается на первом достаточно хорошем кандидате, поэтому
# обычный трек стоит ОДИН вызов yt-dlp; остальной бюджет тратится только на трудные треки.
HUNT_BUDGET = float(os.getenv("ZIZI_HUNT_BUDGET", "14"))
HUNT_BUDGET_BG = float(os.getenv("ZIZI_HUNT_BUDGET_BG", "25"))

log = logging.getLogger("zizi.match")

# Подмена версии (см. zizi_match.SUBSTITUTE): all | degree | off. Неизвестное значение = all, а не падение сервиса.
_sub = os.getenv("ZIZI_SUBSTITUTE", "all").strip().lower()
zm.SUBSTITUTE = _sub if _sub in ("all", "degree", "off") else "all"


def cache_get(key: str, max_age: Optional[float] = None) -> Optional[dict]:
    with _db_lock, closing(_db()) as con, con:
        row = con.execute("""SELECT m.vid,m.score,m.ts,p.policy,p.metadata
            FROM match m LEFT JOIN match_proof p ON m.key=p.key WHERE m.key=?""", (key,)).fetchone()
    if not row or row[3] != MATCH_POLICY:
        return None  # old rows contain no evidence of the recording's version
    try:
        age = time.time() - float(row[2])
        saved_score = float(row[1])
        candidate = json.loads(row[4])
        if (not math.isfinite(age) or not 0 <= age <= (MATCH_TTL if max_age is None else max_age)
                or not math.isfinite(saved_score) or not isinstance(candidate, dict)
                or candidate.get("vid") != row[0]):
            return None
        return {"candidate": candidate, "score": saved_score, "age": age}
    except (TypeError, ValueError, OverflowError):
        return None


def cache_put(key: str, vid: str, score: float, candidate: Optional[dict] = None) -> None:
    with _db_lock, closing(_db()) as con, con:
        con.execute("INSERT OR REPLACE INTO match(key,vid,score,ts) VALUES(?,?,?,?)",
                    (key, vid, score, int(time.time())))
        if candidate is not None:
            con.execute("INSERT OR REPLACE INTO match_proof VALUES(?,?,?)",
                        (key, MATCH_POLICY, json.dumps(candidate, ensure_ascii=False)))
        else:
            con.execute("DELETE FROM match_proof WHERE key=?", (key,))


# Промах подбора — утверждение о ВЫДАЧЕ ИСТОЧНИКА в конкретную минуту, а не свойство трека.
# 1.14: минуты, а не часы, и верхний предел зашит в код. Раньше срок брался из ZIZI_MISS_TTL, и
# значение «21600», когда-то вписанное в zizi.env, годами держало живые треки в 404 после любых
# обновлений. Кэш промахов нужен только чтобы повторный тап не жёг CPU, — для этого двух минут хватает.
MISS_TTL = max(0, min(int(os.getenv("ZIZI_MISS_TTL", "120") or 120), 600))


def miss_get(key: str) -> Optional[str]:
    with _db_lock, closing(_db()) as con, con:
        row = con.execute("SELECT ts, why FROM miss WHERE key=?", (key,)).fetchone()
    if not row:
        return None
    if time.time() - (row[0] or 0) > MISS_TTL:
        with _db_lock, closing(_db()) as con, con:
            con.execute("DELETE FROM miss WHERE key=?", (key,))
        return None
    return row[1] or "no confident match"


def miss_put(key: str, why: str) -> None:
    with _db_lock, closing(_db()) as con, con:
        con.execute("INSERT OR REPLACE INTO miss(key,ts,why) VALUES(?,?,?)",
                    (key, int(time.time()), why[:200]))


# ---------------------------------------------------------------- Spotify (только метаданные)

_sp_tok = {"v": "", "exp": 0.0}


def sp_token() -> str:
    if not (SP_ID and SP_SECRET):
        raise HTTPException(501, "spotify credentials not configured")
    if _sp_tok["v"] and _sp_tok["exp"] > time.time() + 30:
        return _sp_tok["v"]
    basic = base64.b64encode(f"{SP_ID}:{SP_SECRET}".encode()).decode()
    r = requests.post(
        "https://accounts.spotify.com/api/token",
        data={"grant_type": "client_credentials"},
        headers={"Authorization": f"Basic {basic}"},
        timeout=12,
    )
    r.raise_for_status()
    j = r.json()
    _sp_tok["v"] = j["access_token"]
    _sp_tok["exp"] = time.time() + float(j.get("expires_in", 3600))
    return _sp_tok["v"]


def sp_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.spotify.com/v1/{path}",
        headers={"Authorization": f"Bearer {sp_token()}"},
        params=params,
        timeout=15,
    )
    if r.status_code == 429:
        raise HTTPException(429, f"spotify rate limit, retry after {r.headers.get('Retry-After','?')}s")
    r.raise_for_status()
    return r.json()


def sp_track(t: dict) -> dict:
    return {
        "src": "spotify",
        "id": t.get("id"),
        "isrc": (t.get("external_ids") or {}).get("isrc"),
        "title": t.get("name"),
        "artist": ", ".join(a["name"] for a in t.get("artists", [])),
        "album": (t.get("album") or {}).get("name"),
        "dur": int((t.get("duration_ms") or 0) / 1000),
        "art": next((i["url"] for i in ((t.get("album") or {}).get("images") or [])), None),
    }


# ---------------------------------------------------------------- Deezer (без ключа, запасной)

def dz_track(t: dict) -> dict:
    return {
        "src": "deezer",
        "id": str(t.get("id")),
        "isrc": t.get("isrc"),
        "artist_id": str((t.get("artist") or {}).get("id") or "") or None,
        "album_id": str((t.get("album") or {}).get("id") or "") or None,
        "title": t.get("title"),
        "artist": (t.get("artist") or {}).get("name"),
        "album": (t.get("album") or {}).get("title"),
        "dur": int(t.get("duration") or 0),
        "art": (t.get("album") or {}).get("cover_big"),
    }


def dz_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.deezer.com/{path}",
        params=params,
        headers={"User-Agent": UA},
        timeout=15,
    )
    r.raise_for_status()
    j = r.json()
    if isinstance(j, dict) and "error" in j:
        e = j["error"]
        raise HTTPException(502, f"deezer: {e.get('type')} {e.get('message')}")
    return j


def dz_search(q: str, limit: int, offset: int = 0) -> list[dict]:
    j = dz_get("search", q=q, limit=limit, index=offset)
    return [dz_track(t) for t in j.get("data", [])]


# ---------------------------------------------------------------- сопоставление -> youtube_id

class MatchUnavailable(Exception):
    """Upstream/deadline failure is NOT a negative catalog result."""


def yt_search(query: str, n: int = 6, budget: float = 5.0, foreground: bool = True) -> list[dict]:
    deadline = time.monotonic() + budget
    cmd = ["yt-dlp", "--ignore-config", "--quiet", "--no-warnings", "--flat-playlist",
           "--skip-download", "--socket-timeout", "3", "--retries", "0",
           "--extractor-retries", "0", "--dump-json", "--", f"ytsearch{n}:{query}"]
    if not _guard.gate.acquire(timeout=min(_guard.gate.wait, max(0, budget))):
        raise ExtractBusy(_guard.gate.wait)
    try:
        try:
            lease = SCHEDULER.acquire('match' if foreground else 'match-prefetch',
                                      1 if foreground else 2,
                                      timeout=min(2, max(0, deadline-time.monotonic())) if foreground else 0)
        except SchedulerBusy:
            raise ExtractBusy(2) from None
        with lease:
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise MatchUnavailable('matching time budget exhausted')
            try:
                raw = run_text(cmd, timeout=remaining, cancel=lease.cancel)
            except ProcessError as e:
                if e.status == 429:
                    raise ExtractBusy(2) from None
                raise MatchUnavailable(e.reason) from None
    finally:
        _guard.gate.release()
    res = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            j = json.loads(line)
            if not isinstance(j, dict):
                raise ValueError()
            vid = j.get('id')
            if not isinstance(vid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
                continue
            duration = j.get('duration')
            res.append({'vid': vid, 'title': j.get('title') or '',
                        'uploader': j.get('uploader') or j.get('channel') or '',
                        'dur': int(duration) if type(duration) in (int, float)
                               and 0 <= duration <= 604800 else 0})
        except (ValueError, TypeError, OverflowError):
            raise MatchUnavailable('invalid matching metadata') from None
    return res


# Version tags have one production implementation in zizi_versions.py.
# Removed unused legacy _MARKERS/markers, formerly a competing definition.
# ---------------------------------------------------------------- подбор (правила 6)

def valid_candidate(candidate: object) -> bool:
    return (isinstance(candidate, dict)
            and isinstance(candidate.get("vid"), str)
            and re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate["vid"]) is not None
            and all(isinstance(candidate.get(k), str) for k in ("title", "uploader"))
            and len(candidate["title"]) <= 400 and len(candidate["uploader"]) <= 200
            and isinstance(candidate.get("dur"), (int, float))
            and not isinstance(candidate.get("dur"), bool)
            and math.isfinite(candidate["dur"]) and candidate["dur"] >= 0)


def miss_key(key: str, alt_artists=()) -> str:
    """Ключ отрицательного кэша. Совпадает с match_key, если соисполнителей нет.

    Прогрев по выдаче поиска знает только главного артиста, а тап по треку (/match/deezer) добавляет
    соисполнителей из Deezer. Промах прогрева («артиста нет в выдаче») нельзя показывать человеку, у
    которого на руках больше имён: у него охота может закончиться иначе.
    """
    names = sorted({" ".join((a or "").casefold().split()) for a in (alt_artists or ()) if a})
    if not names:
        return key
    return key + "+" + hashlib.sha1("|".join(names).encode("utf-8")).hexdigest()[:10]


def match_key(title: str, artist: str, dur: int, isrc: str = "", mode="smart") -> str:
    """Ключ подбора. ISRC в него НЕ входит (1.14).

    Раньше входил, и это ломало прогрев: выдача поиска и альбома приходит без ISRC, а /match/deezer
    добирает его из track/{id}. Один и тот же трек получал два разных ключа, и прогрев по выдаче
    не мог сработать на тап. Версии записи при этом по-прежнему не склеиваются: название с пометкой
    версии и длительность входят в ключ целиком.
    """
    if isinstance(mode, bool):  # совместимость со старыми вызовами match_key(..., allow_weak)
        mode = "weak" if mode else "smart"
    if mode not in ("smart", "weak"):
        raise ValueError("unknown match mode")
    payload = [MATCH_POLICY, mode, normalized(artist), normalized(title), int(dur)]
    # Префикс вычисляется из номера политики и обязан говорить правду о пространстве ключей.
    return f"q{MATCH_POLICY}:" + hashlib.sha256(
        json.dumps(payload, ensure_ascii=False).encode()).hexdigest()


def _hunt(req: "zm.Request", weak: bool, foreground: bool, trace: Optional[list] = None):
    """Последовательная ограниченная охота по плану запросов. Одно ядро: параллелить нечего.

    Останавливается на первом кандидате, которого достаточно (Selector.done): обычный трек стоит
    один вызов yt-dlp. Возвращает (selector, complete, запросов выполнено). complete=False, если
    хоть один запрос не отработал (занят экстрактор, таймаут): отсутствие результата тогда не
    является отрицательным ответом и не пишется в кэш промахов.
    """
    sel = zm.Selector(req, weak)
    deadline = time.monotonic() + (HUNT_BUDGET if foreground else HUNT_BUDGET_BG)
    plan = zm.build_queries(req)
    complete, busy, ran = True, 0, 0
    for label, text, n in plan:
        remaining = deadline - time.monotonic()
        if remaining <= 0.5:
            complete = False
            break
        try:
            found = [c for c in yt_search(text, n, budget=min(6.0, remaining), foreground=foreground)
                     if valid_candidate(c)]
        except ExtractBusy:
            busy += 1
            complete = False
            continue
        except MatchUnavailable:
            complete = False
            continue
        ran += 1
        sel.add(found)
        if trace is not None:
            trace.append({"q": label, "text": text, "found": len(found)})
        if sel.done(ran):
            break
    if ran == 0 and busy:
        raise ExtractBusy(2)
    return sel, complete, ran


def _candidate_json(v: "zm.Verdict") -> dict:
    return {"vid": v.vid, "title": v.title, "uploader": v.uploader, "dur": int(v.dur or 0),
            "tier": v.tier, "src": v.source}


def _result(v: "zm.Verdict", key: str, cached: bool) -> dict:
    return {"vid": v.vid, "cached": cached, "key": key, "score": round(v.score, 1),
            "confident": v.confident, "fallback": v.tier != "exact", "strict": v.tier == "exact",
            "policy": MATCH_POLICY, "picked": v.title, "by": v.uploader,
            "tier": v.tier, "source": v.source, "substituted": v.substituted}


def match_track(title: str, artist: str, dur: int, isrc: str = "", allow_weak: bool = False,
                foreground: bool = True, alt_artists=(), explain: bool = False) -> dict:
    """Метаданные -> youtube_id.

    Порядок: кэш (с повторной оценкой — правила могли измениться) -> охота -> выбор. 404 только
    если охота прошла полностью и ни один кандидат не годится; всё остальное — 503/429 с
    Retry-After либо рабочий ответ с честным tier. explain=True: кэши не читаются и не пишутся,
    в ответе таблица кандидатов с причинами отказа — чтобы любой 404 разбирался одним запросом.
    """
    title, artist = (title or "").strip(), (artist or "").strip()
    if not title or not artist or dur < 0 or len(title) > 500 or len(artist) > 500 or len(isrc) > 100:
        raise HTTPException(422, "invalid matching metadata")
    req = zm.make_request(title, artist, dur, isrc, alt_artists)
    key = match_key(title, artist, dur, isrc, "weak" if allow_weak else "smart")
    mkey = miss_key(key, alt_artists)

    if not explain:
        hit = cache_get(key)
        if isinstance(hit, dict) and valid_candidate(hit.get("candidate")):
            cand = hit["candidate"]
            ttl = TIER_TTL.get(str(cand.get("tier") or "loose"), FALLBACK_TTL)
            if hit["age"] <= ttl:
                # Кэш не истина: оценка перечитывается текущими правилами. Если правила ужесточились
                # (или кэш побит), запись игнорируется и подбор идёт заново.
                v = zm.judge(req, cand, allow_weak)
                if v.ok:
                    return _result(v, key, True)
        stale = miss_get(mkey)
        if stale:
            raise HTTPException(404, stale)

    trace: list = []
    try:
        sel, complete, ran = _hunt(req, allow_weak, foreground, trace)
    except ExtractBusy as e:
        raise HTTPException(429, "extractor busy", headers={"Retry-After": str(e.retry_after)})

    best = sel.best()
    if explain:
        return {"vid": best.vid if best else None, "tier": best.tier if best else None,
                "complete": complete, "queries": trace, "seen": sel.seen,
                "request": {"title": req.title, "artist": req.artist, "dur": req.dur,
                            "tags": sorted(req.tags), "words": [t.t for t in req.toks],
                            "artists": [[t.t for t in n] for n in req.names], "rules": zm.RULES},
                "candidates": sel.report(25)}

    if best is not None:
        # Слабый ответ из неполной охоты не отдаём и не кэшируем: половина выдачи — это «то, что
        # успело прийти», а не «лучшее из найденного».
        if best.tier in ("variant", "loose") and not complete:
            raise HTTPException(503, "matching incomplete; retry later", headers={"Retry-After": "2"})
        cache_put(key, best.vid, best.score, _candidate_json(best))
        if best.tier != "exact":
            log.info("MATCH-%s %s | %s | %ds -> %s (%s, %.0f)", best.tier.upper(), artist, title, dur,
                     best.title[:60], best.source, best.score)
        return _result(best, key, False)

    if not complete:
        raise HTTPException(503, "matching incomplete; retry later", headers={"Retry-After": "2"})
    why = sel.why_missed()
    log.warning("MATCH-MISS %s | %s | %ds | seen=%d | %s", artist, title, dur, sel.seen, why)
    miss_put(mkey, "no playable candidate")
    raise HTTPException(404, "no playable candidate")


# ---------------------------------------------------------------- эндпоинты

def _extra_call(fn, *args):
    try:
        return fn(*args)
    except ExtraError as e:
        raise HTTPException(e.status, e.reason,
                            headers={"Retry-After": str(e.retry)} if e.retry else None)


@router.get("/catalog/extra/search")
def catalog_extra_search(q: str, limit: int = Query(10, ge=1, le=20)):
    return _extra_call(_extra.search, q, limit)


@router.get("/catalog/extra/playlist")
def catalog_extra_playlist(id: str, limit: int = Query(20, ge=1, le=20),
                           offset: int = Query(0, ge=0, le=480)):
    return _extra_call(_extra.playlist, id, limit, offset)


@router.get("/catalog/search")
def catalog_search(q: str, limit: int = Query(20, le=50), offset: int = 0, src: str = "auto"):
    if src in ("spotify", "auto") and SP_ID:
        try:
            j = sp_get("search", q=q, type="track", limit=limit)
            items = [sp_track(t) for t in j["tracks"]["items"]]
            _autowarm(items)
            return {"src": "spotify", "items": items}
        except HTTPException:
            if src == "spotify":
                raise
    items = dz_search(q, limit, offset)
    if offset == 0:
        _autowarm(items)
    return {"src": "deezer", "offset": offset, "items": items}


@router.get("/catalog/playlist")
def catalog_playlist(id: str, limit: int = Query(100, le=300), offset: int = 0,
                     src: str = "auto"):
    """Плейлист по id. Deezer — без ключей; Spotify — только если заданы ZIZI_SP_ID/SECRET."""
    if src == "spotify" or (src == "auto" and SP_ID and not id.isdigit()):
        j = sp_get(f"playlists/{id}/tracks", limit=min(limit, 100), offset=offset)
        items = [sp_track(it["track"]) for it in j.get("items", []) if it.get("track")]
        if offset == 0:
            _autowarm(items)
        return {"src": "spotify", "total": j.get("total"), "offset": offset, "items": items}
    j = dz_get(f"playlist/{id}/tracks", limit=limit, index=offset)
    items = [dz_track(t) for t in j.get("data", [])]
    if offset == 0:
        _autowarm(items)
    return {"src": "deezer", "total": j.get("total"), "offset": offset, "items": items}


@router.get("/catalog/album")
def catalog_album(id: str):
    """Альбом Deezer целиком. У треков в этой выдаче нет isrc — сопоставление пойдёт по artist+title+dur."""
    j = dz_get(f"album/{id}")
    art = j.get("cover_big")
    items = []
    for t in (j.get("tracks") or {}).get("data", []):
        d = dz_track(t)
        d["album"] = j.get("title")
        d["art"] = d["art"] or art
        items.append(d)
    _autowarm(items)
    return {"src": "deezer", "album": j.get("title"),
            "artist": (j.get("artist") or {}).get("name"), "art": art, "items": items}


@router.get("/catalog/artist")
def catalog_artist(id: str, limit: int = Query(50, le=100)):
    """Топ-треки артиста — то, чем в Спотифае открывается страница исполнителя."""
    j = dz_get(f"artist/{id}/top", limit=limit)
    items = [dz_track(t) for t in j.get("data", [])]
    _autowarm(items)
    return {"src": "deezer", "items": items}


@router.get("/catalog/chart")
def catalog_chart(limit: int = Query(50, le=100)):
    """Главный экран: чарт треков + подборка плейлистов. Ничего не требует."""
    j = dz_get("chart", limit=limit)
    return {
        "src": "deezer",
        "tracks": [dz_track(t) for t in (j.get("tracks") or {}).get("data", [])],
        "playlists": [
            {"id": str(p["id"]), "title": p.get("title"), "art": p.get("picture_big"),
             "n": p.get("nb_tracks")}
            for p in (j.get("playlists") or {}).get("data", [])
        ],
        "artists": [
            {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
            for a in (j.get("artists") or {}).get("data", [])
        ],
    }


@router.get("/catalog/similar")
def catalog_similar(id: str, limit: int = Query(30, le=100)):
    """«Похожие артисты» — основа радио и автоплея."""
    j = dz_get(f"artist/{id}/related", limit=limit)
    return {"src": "deezer", "items": [
        {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
        for a in j.get("data", [])
    ]}


@router.get("/match")
def match(title: str, artist: str, dur: int = 0, isrc: str = "", strict: bool = True, explain: int = 0):
    """Сердце гибрида: метаданные -> youtube_id. Дальше клиент идёт в /resolve?id=<vid>.

    strict оставлен ради совместимости с клиентами: true — обычный «умный» режим (единственный, что
    шлёт приложение), false — «хоть что-то похожее». explain=1 — разбор вместо ответа: кэши не
    читаются и не пишутся, вернётся таблица кандидатов с причинами отказа.
    """
    return match_track(title, artist, dur, isrc, allow_weak=not strict, explain=bool(explain))


def _dz_alt_artists(raw: dict) -> list:
    return [c["name"] for c in (raw.get("contributors") or []) if isinstance(c, dict) and c.get("name")]


@router.get("/match/deezer")
def match_deezer(id: str, strict: bool = True, explain: int = 0):
    """Сопоставление по одному лишь id каталога.

    Клиент на этом этапе знает только remoteId, поэтому метаданные (и, главное, ISRC)
    добираем здесь: `track/{id}` отдаёт их всегда, в отличие от выдачи альбома и плейлиста.
    Соисполнители (contributors) идут в подбор как запасные имена артиста: на YouTube трек часто
    подписан вторым исполнителем.
    """
    raw = dz_get(f"track/{id}")
    d = dz_track(raw)
    r = match_track(d["title"], d["artist"], d["dur"], d["isrc"] or "", allow_weak=not strict,
                    alt_artists=_dz_alt_artists(raw), explain=bool(explain))
    r["meta"] = d
    return r


# Сколько сопоставлений греется одновременно. Ядро на VPS одно, и прогрев обязан уступать дорогу
# живому запросу: один работник и не более восьми принятых фоновых задач.
_warm_pool = ThreadPoolExecutor(max_workers=1)
_warm_pending = threading.BoundedSemaphore(8)
_warm_seen: dict[str, tuple] = {}   # id -> (время, поколение|None)
_warm_gen = [0]
_warm_lock = threading.Lock()

# 1.14. Прогрев по выдаче сервера: поиск, альбом и плейлист сами ставят в очередь верхние треки.
# Раньше греть мог только клиент и только пять первых id; всё, что ниже, при тапе шло в холодную
# охоту. Метаданные у сервера уже на руках, лишний запрос к Deezer не нужен. Каждое новое действие
# человека (поколение) отменяет ещё не начатые задачи предыдущего: набор «a», «ab», «abc» не должен
# забить очередь прогрева устаревшими запросами.
AUTOWARM = os.getenv("ZIZI_AUTOWARM", "1").strip().lower() not in ("0", "false", "no", "off", "")
AUTOWARM_N = max(0, min(int(os.getenv("ZIZI_AUTOWARM_N", "8") or 8), 12))


def _warm_forget(key: str) -> None:
    with _warm_lock:
        _warm_seen.pop(key, None)


def _warm_one(track_id: str, gen=None) -> None:
    if gen is not None and gen != _warm_gen[0]:
        return _warm_forget(track_id)
    try:
        raw = dz_get(f"track/{track_id}")
        d = dz_track(raw)
        match_track(d["title"], d["artist"], d["dur"], d["isrc"] or "", foreground=False,
                    alt_artists=_dz_alt_artists(raw))
    except HTTPException as e:
        if e.status_code in (429, 503):
            _warm_forget(track_id)   # не удалось из-за занятости: следующий показ может повторить
    except Exception:
        # Прогрев молчит по определению: не удался — трек отрезолвится вживую, как раньше.
        _warm_forget(track_id)


def _warm_meta(key: str, d: dict, gen=None) -> None:
    if gen is not None and gen != _warm_gen[0]:
        return _warm_forget(key)
    try:
        match_track(d["title"], d["artist"], int(d.get("dur") or 0), d.get("isrc") or "", foreground=False)
    except HTTPException as e:
        if e.status_code in (429, 503):
            _warm_forget(key)
    except Exception:
        _warm_forget(key)


def _warm_submit(key: str, fn, *args, gen=None) -> bool:
    now = time.time()
    with _warm_lock:
        if len(_warm_seen) > 512:
            _warm_seen.clear()
        e = _warm_seen.get(key)
        if e and now - e[0] <= 300 and (e[1] is None or e[1] == _warm_gen[0]):
            return False
        _warm_seen[key] = (now, gen)
    if not _warm_pending.acquire(blocking=False):
        _warm_forget(key)
        return False
    try:
        future = _warm_pool.submit(fn, key, *args, gen=gen)
    except BaseException:
        _warm_pending.release()
        raise
    future.add_done_callback(lambda _: _warm_pending.release())
    return True


def _autowarm(items) -> int:
    """Поставить в прогрев верхние треки выдачи. Ошибки прогрева не должны ломать выдачу."""
    if not AUTOWARM or not AUTOWARM_N:
        return 0
    try:
        picked = [d for d in (items or []) if isinstance(d, dict) and d.get("id") and d.get("title")
                  and d.get("artist") and int(d.get("dur") or 0) > 0][:AUTOWARM_N]
        if not picked:
            return 0
        with _warm_lock:
            _warm_gen[0] += 1
            gen = _warm_gen[0]
        return sum(1 for d in picked if _warm_submit(f"{d.get('src', '')}:{d['id']}" if d.get("src") != "deezer"
                                                      else str(d["id"]), _warm_meta, d, gen=gen))
    except Exception:
        return 0


@router.get("/match/warm")
def match_warm(ids: str):
    """Сопоставить треки ЗАРАНЕЕ и ответить немедленно (1.6).

    Смысл в одной фразе: сопоставление должно происходить, пока человек читает список результатов,
    а не после того, как он нажал на трек. Приложение зовёт этот адрес сразу после отрисовки
    поиска; ответ приходит через миллисекунды, работа идёт в фоне, и к моменту тапа videoId уже
    лежит в SQLite.

    Дедупликация по пятиминутному окну: открытый и закрытый пять раз экран поиска не должен
    ставить в очередь один и тот же трек пять раз.
    """
    wanted = [x.strip() for x in (ids or "").split(",") if x.strip()][:8]
    queued = sum(1 for t in wanted if _warm_submit(t, _warm_one))
    return {"ok": True, "queued": queued}


# ---------------------------------------------------------------- обложки

# Только хосты каталогов, и по суффиксу домена, а не по вхождению подстроки: без этой проверки
# /img — открытый прокси наружу, и первый же чужой бот утащит канал VPS на что угодно.
IMG_HOSTS = (
    ".dzcdn.net", ".deezer.com",
    ".scdn.co", ".spotifycdn.com",
    ".ytimg.com", ".ggpht.com", ".googleusercontent.com",
)


def _img_allowed(url: str) -> bool:
    m = re.match(r"^https?://([^/:?#]+)", url or "")
    if not m:
        return False
    host = m.group(1).lower()
    return any(host == h.lstrip(".") or host.endswith(h) for h in IMG_HOSTS)


def _img_purge() -> None:
    """LRU по времени доступа. Считается только при переполнении, а не на каждой картинке."""
    try:
        files = []
        total = 0
        for name in os.listdir(IMG_DIR):
            path = os.path.join(IMG_DIR, name)
            try:
                st = os.stat(path)
            except FileNotFoundError:
                continue
            files.append((st.st_atime, st.st_size, path))
            total += st.st_size
        if total <= IMG_QUOTA:
            return
        files.sort()
        for _, size, path in files:
            try:
                os.remove(path)
            except OSError:
                pass
            total -= size
            if total <= IMG_QUOTA * 0.8:
                break
    except OSError:
        pass


# 1.14. Миниатюры видео с YouTube (i.ytimg.com/vi/<id>/hqdefault.jpg) — 4:3 с чёрными полосами
# или 16:9. В квадратной плитке обложки такая картинка выглядит «уменьшенной», по ней сразу видно,
# что трек приехал прямо с YouTube. Если установлен Pillow, срезаем чёрные поля и берём центральный
# квадрат. Без Pillow ничего не меняется (не обязательная зависимость: pip install pillow).
IMG_SQUARE = os.getenv("ZIZI_IMG_SQUARE", "1").strip().lower() not in ("0", "false", "no", "off", "")
_YT_VIDEO_THUMB = re.compile(r"^https?://[^/?#]*\.ytimg\.com/vi(?:_webp)?/[^/?#]+/[a-z0-9_]*default(?:_live)?\.(?:jpg|webp)",
                             re.I)
try:  # pragma: no cover - наличие Pillow зависит от VPS
    from PIL import Image as _PILImage, ImageChops as _PILChops
except Exception:  # noqa: BLE001
    _PILImage = _PILChops = None
_SQUARE_OK = bool(IMG_SQUARE and _PILImage is not None)  # в /catalog/health: видно, что crop реально работает


def square_art(body: bytes) -> Optional[bytes]:
    """JPEG-квадрат из миниатюры видео или None, если Pillow нет / картинка не читается."""
    if _PILImage is None:
        return None
    try:
        import io
        im = _PILImage.open(io.BytesIO(body)).convert("RGB")
        w, h = im.size
        if min(w, h) < 32:
            return None
        mask = _PILChops.difference(im, _PILImage.new("RGB", im.size, (0, 0, 0))).convert("L").point(
            lambda px: 255 if px > 24 else 0)
        box = mask.getbbox()
        if box:
            bw, bh = box[2] - box[0], box[3] - box[1]
            # Полосы — это заметная часть кадра по одной из осей, и содержимое остаётся крупным.
            if (bw < w * 0.96 or bh < h * 0.96) and bw * bh >= 0.2 * w * h:
                im = im.crop(box)
                w, h = im.size
        side = min(w, h)
        left, top = (w - side) // 2, (h - side) // 2
        im = im.crop((left, top, left + side, top + side))
        if side > 720:
            im = im.resize((720, 720), _PILImage.LANCZOS)
        out = io.BytesIO()
        im.save(out, "JPEG", quality=88)
        return out.getvalue()
    except Exception:  # noqa: BLE001
        return None


@router.get("/img")
def img(u: str):
    """Обложка чужого CDN, забранная сервером и отданная с диска.

    Существует не ради экономии, а ради одной фразы: телефон не обращается к Google и к чужим
    CDN вообще. Пока картинки шли напрямую, «работает без VPN» означало «текст есть, обложек нет».

    Кэш на диске бессрочный: адрес обложки у Deezer и YouTube содержит идентификатор записи и
    меняется вместе с картинкой, поэтому протухнуть тут нечему.
    """
    if not _img_allowed(u):
        raise HTTPException(400, "host not allowed")
    os.makedirs(IMG_DIR, exist_ok=True)
    square = bool(IMG_SQUARE and _PILImage is not None and _YT_VIDEO_THUMB.match(u))
    # Соль в ключе: обработанная картинка не должна подменять сырую, оставшуюся в кэше с прошлых версий.
    key = hashlib.sha1((("sq1\n" if square else "") + u).encode("utf-8")).hexdigest()
    path = os.path.join(IMG_DIR, key)
    headers = {"Cache-Control": "public, max-age=2592000, immutable"}
    if os.path.exists(path):
        os.utime(path, None)          # отметка доступа для LRU
        with open(path, "rb") as f:
            return Response(f.read(), media_type="image/jpeg", headers=headers)

    try:
        r = requests.get(u, headers={"User-Agent": UA}, timeout=15, stream=True)
    except requests.RequestException as e:
        raise HTTPException(502, f"image fetch failed: {e}")
    if r.status_code != 200:
        raise HTTPException(r.status_code if r.status_code < 500 else 502, "image not available")

    body = b""
    for chunk in r.iter_content(64 * 1024):
        body += chunk
        if len(body) > IMG_MAX:
            raise HTTPException(413, "image too large")
    if not body:
        raise HTTPException(502, "empty image")
    squared = square_art(body) if square else None
    if squared:
        body = squared

    # Через временный файл: два телефона, открывшие один чарт, пишут один и тот же путь, и без
    # этого один прочитал бы половину картинки другого.
    tmp = path + ".part"
    try:
        with open(tmp, "wb") as f:
            f.write(body)
        os.replace(tmp, path)
    except OSError:
        pass
    _img_purge()
    ctype = "image/jpeg" if squared else r.headers.get("Content-Type", "image/jpeg").split(";")[0].strip()
    if not ctype.startswith("image/"):
        ctype = "image/jpeg"
    return Response(body, media_type=ctype, headers=headers)


@router.get("/auth/device")
def auth_device(request: Request, x_zizi_install: Optional[str] = Header(None)):
    """Обмен бутстрап-токена из APK на короткоживущий ключ этого устройства (1.8).

    Роут закрыт бутстрап-токеном в ЛЮБОМ режиме (zizi_guard.TOKEN_REQUIRED) и стоит в самом
    узком классе квоты. Ключ подписан секретом, которого в APK нет; внутри него installId,
    поэтому дальше квота считается на устройство, а не на подделываемый заголовок.

    Сам installId сервер не хранит: ни в базе, ни в логах. Он нужен как единица учёта и как
    единица отзыва, а не как личность — по нему нельзя узнать ни устройство, ни человека.
    """
    install = (x_zizi_install or request.query_params.get("i") or "").strip()
    # Границы и алфавит: installId уезжает в подпись и в ключи квоты. Пускать туда произвольную
    # строку с телефона — это разрешить чужому клиенту раздувать память ключами по 4 КБ.
    if not (8 <= len(install) <= 64) or not re.fullmatch(r"[A-Za-z0-9._:-]+", install):
        raise HTTPException(400, "bad install id")
    token, ttl = issue_device_token(install)
    if not token:
        # Подписывать нечем: ZIZI_TOKEN и ZIZI_DEVICE_KEY оба пусты. Это конфигурация, а не
        # запрос, поэтому 503 и честный текст, а не 401 — иначе клиент будет ломиться в цикле.
        raise HTTPException(503, "device tokens disabled: ни ZIZI_TOKEN, ни ZIZI_DEVICE_KEY не заданы")
    return {"token": token, "expires_in": ttl, "install_id": install,
            "mode": device_mode(), "ttl_hours": round(device_ttl() / 3600.0, 1)}


@router.get("/catalog/health")
def catalog_health():
    with _db_lock, closing(_db()) as con, con:
        n = con.execute("SELECT COUNT(*) FROM match").fetchone()[0]
    try:
        cached_images = len(os.listdir(IMG_DIR))
    except OSError:
        cached_images = 0
    with _db_lock, closing(_db()) as con, con:
        misses = con.execute("SELECT COUNT(*) FROM miss").fetchone()[0]
    return {"ok": True, "version": VERSION, "browse_contract": 1, "reco_contract": RECO_CONTRACT,
            "reco_feed": RECO_FEED, "spotify": bool(SP_ID), "deezer": True,
            # 1.14. «Строгий» режим снят: подбор идёт по баллам (zizi_match), а не по воротам.
            # Ключ "fallback" оставлен, потому что телефон печатает его в диагностике и без него
            # пишет «не указан»; значение True значит «подмена версии разрешена по правилам».
            # strict_default теперь False — это правда, а не наследие: жёсткого режима нет.
            "match_policy": MATCH_POLICY, "match_engine": "smart", "match_rules": zm.RULES,
            "strict_default": False, "fallback": True, "miss_ttl": MISS_TTL, "substitute": zm.SUBSTITUTE,
            "matches_cached": n, "misses_cached": misses, "images_cached": cached_images,
            "square_art": _SQUARE_OK,
            # 1.7. Здесь смотрят, когда решают, пора ли переключать токен в require:
            # guard.anon_pct == 0 означает, что все живые клиенты уже присылают токен.
            # Без этой цифры переключение делается на глаз, то есть выключает сервис кому-то.
            "guard": _guard.stats(), "extra": _extra.stats(), "scheduler": SCHEDULER.stats()}

# 6.39: additive metadata-only routes; inherit this router's auth and rate limits.
from zizi_browse import install_routes as _install_browse_routes
_install_browse_routes(router, dz_get, dz_track)

# 6.81: персональная главная. Метаданные Deezer, без аудио; роуты висят на том же защищённом
# router (токен, квоты). Это надстройка: отсутствие или сбой zizi_reco не должны ронять резолвер,
# поэтому импорт и установка в try. RECO_CONTRACT=0 — клиент тихо идёт прежним путём главной.
RECO_CONTRACT = 0
RECO_FEED = 0           # POST /reco/feed (бесконечная лента); 0 — клиент не показывает ленту и не ходит за ней
try:
    from zizi_reco import FEED_CONTRACT as _RECO_FEED_CONTRACT
    from zizi_reco import install_routes as _install_reco_routes
    _install_reco_routes(router, dz_get, dz_track, os.getenv("ZIZI_RECO_DB", DB_PATH + ".reco"))
    RECO_CONTRACT = 1
    RECO_FEED = _RECO_FEED_CONTRACT
except Exception:  # noqa: BLE001
    import logging as _logging
    _logging.getLogger("zizi.reco").exception("reco disabled: import or install failed")
