"""zizi_reco.py — персональная «Главная»: генерация кандидатов и сборка полок (Reco 1).

Зачем это на сервере, а не на телефоне
--------------------------------------
До 6.81 главная делала до семи запросов с телефона и искала артиста ПО ИМЕНИ: «Zaylo» -> поиск
треков -> фильтр «имя совпало». Из этого выходят только его же собственные треки и альбомы, то есть
«рекомендации своих треков». Открытие нового идёт через граф: кто звучит как мои артисты. Этот
граф у Deezer есть и открыт без ключа (/artist/{id}/related, /artist/{id}/radio), но обход графа —
это десятки запросов, и делать их с телефона на мобильной сети нельзя. На VPS они дёшевы: ответы
кэшируются на часы и одинаковы для всех пользователей, потому что это публичные метаданные.

Что уходит на сервер и чего нет
-------------------------------
Приходит КОМПАКТНЫЙ профиль вкуса: до 8 артистов с весами, имена известных артистов (чтобы не
рекомендовать то, что уже есть), артисты с пропусками, последние 3 артиста, предпочтение версии.
Не приходят: названия треков, время, длительности, идентификаторы устройства.

Профиль едет в ТЕЛЕ POST, а не в строке запроса: access-лог uvicorn (в юните установщика он включён)
пишет путь вместе с query, тело не пишет. Этот модуль профиль не сохраняет и не логирует. Кэш хранит
публичные ответы Deezer; в ключах кэша есть имена артистов, но без идентификатора пользователя,
устройства или адреса. Канал до сервера — тот же, что у остального приложения (http к резолверу):
шифрование транспорта этим модулем не решается.

Математика
----------
Сид s имеет вес w_s in (0, 1] (клиент нормирует по максимуму). Deezer отдаёт related(s) в порядке
убывания близости, позиция r (с нуля). Оценка кандидата-артиста c:

    score(c) = sum_s  w_s * (1 + r_s(c))^(-1/2) * psi(fans_c)         psi(f) = min(1, 0.6 + 0.4 f / 300)

Корень из ранга — мягкое затухание: первый сосед весит 1, четвёртый 0.45, двадцать пятый 0.2.
Сумма по сидам даёт пересечение: артист, близкий сразу к двум любимым, обгоняет близкого к одному.
psi гасит пустые профили (fans около 0), но не наказывает нишу: с 300 фанатов штраф исчезает.

Новые релизы: v = score(a) * exp(-age_days / 21), age <= 60. Собственные релизы сида получают
score = 1.5 * w_s: свежий EP любимого артиста должен быть выше свежего EP незнакомого.

Треки: value(t) = 0.55 * pop(t) + 0.45 * fit(t) + tie(t), pop = min(1, log10(1 + rank) / 6),
fit = совпадение семейства версии (slowed / sped_up / оригинал) с предпочтением профиля.
Выбор жадный (MMR): штраф 0.30 за каждый уже взятый трек артиста и 0.50 за соседа-повтор.
tie — детерминированный дневной хеш < 0.01: ротация по дням без случайности в тестах.

Лента (1.1, POST /reco/feed). Бесконечность — это не «ещё сто треков из того же списка», а обход графа
вширь. Состояние на сервере (сессия, LRU, 3 часа): кандидаты с весами, раскрытые артисты, выданные
треки. Страница делает три шага:
  1. Раскрытие. Пока живых кандидатов меньше 3 * FEED_ARTISTS_PER_PAGE — берём у лучших нераскрытых
     related и добавляем соседей с весом  score(parent)/max_score * phi(r) * psi(fans) * 0.6  — каждый
     шаг вглубь ослабляет вес в 0.6 раза, поэтому ближние артисты идут раньше, но граф не кончается.
  2. Выбор артистов: priority(a) = score(a) * (0.55 если известен) / (1 + уже_взято(a))^1.8.
     Знаменатель «остужает» тех, кого уже играли, и очередь сама уходит к следующим кругам графа.
  3. Треки: топ выбранных артистов -> дедупликация версий -> MMR с бонусом 0.15 * priority/max.
Повторов нет: id трека и ключ (artist_id, название без пометок версии) помнятся на всю сессию.
Курсор «<sid>.<страница>». Повторный запрос той же страницы отдаёт ту же страницу (обрыв связи не
съедает треки). Сессия потеряна — лента начинается заново (restarted: true), клиент дедуплицирует.

Дедупликация версий: ключ (artist_id, название без пометок версии). «Loucura Letal (Slowed)» и
«(Ultra Slowed)» — одна песня; остаётся версия нужного семейства, при равенстве — популярнее.

Reco 2 (сервер 1.16, "2.0-reco2")
---------------------------------
Профиль шире: до 30 сидов (s + s2: старый сервер читает только s и молча игнорирует s2/h), подсказки h
«имя~название трека» для точной привязки артиста (search/track artist:"…" track:"…" — тёзки больше не
путаются), в ответе seeds[].ref — исходная строка сида, клиент запоминает «имя -> id» и дальше шлёт id.

Соответствие сцене вместо штрафа за нишу. mu, sigma — взвешенные среднее и разброс log10(fans + 10)
соседей первого шага (это «популярность сцены» пользователя, а не его собственных артистов):

    fit(c) = psi(fans_c) * max(0.35, exp(-(log10(fans_c + 10) - mu)^2 / (2 sigma^2))),  sigma >= 0.6

fit <= psi, поэтому все прежние верхние оценки сохраняются.

Второй шаг графа (главная): у HOP2 лучших соседей берётся related и добавляется
    score2(c) = 0.5 * score(b) / max score * phi(r_bc) * fit(c)
Второй шаг — улучшение, а не условие полноты: его сбой не делает ответ неполным.

Коллаборативный сигнал (анонимно). Сервер копит только пары id артистов из сидов (без пользователя,
устройства, адреса; повтор того же набора за неделю не считается, отпечатки наборов живут в памяти):
    sim(a, b) = n_ab / sqrt(n_a * n_b),  n_ab >= COOC_MIN
и добавляет COOC_GAMMA * w_s * sim(s, c) к оценке кандидата.

Треки: value = 0.40 pop + 0.45 fit_версии + 0.15 близость артиста + tie. «Начни с этой музыки»
сортируется по близости артиста, а не по голой популярности.

Устаревшее-пока-обновляется: истёк кэш ответа, но есть полная главная этого профиля моложе STALE_TTL —
она уходит сразу, пересборка идёт в фоне.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import threading
import time
import unicodedata
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, wait
from contextlib import closing
from datetime import datetime, timezone
from typing import Callable, Optional

from fastapi import Body, HTTPException

from zizi_versions import SLOWED, SPED_UP, normalized, speed_family, strip_version_phrases, version_tags

CONTRACT = 1
FEED_CONTRACT = 1             # POST /reco/feed: бесконечная лента страницами (1.1)
VERSION = "2.0-reco2"
ENGINE_REV = 2

# ----------------------------------------------------------------------------- пределы

MAX_SEEDS = 30
MAX_KNOWN = 60
MAX_NEG = 40
MAX_RECENT = 3
MAX_QUERY = 8000            # символов во всех полях вместе; длиннее — 422
FIELD_MAX = {"s": 1200, "k": 1400, "x": 500, "r": 300, "v": 8, "s2": 2000, "h": 3200}
MAX_HINTS = 30
HINT_MAX = 80   # по полям; длиннее — 422
CURSOR_MAX = 40             # «<sid>.<страница>»; длиннее или не по формату — лента начинается заново
ANCHORS = 3                 # полок «Похоже на»
RELATED_USED = 10           # у скольких сидов берём граф для агрегата
PER_ANCHOR = 8              # артистов на полку «Похоже на»
DEADLINE_S = 5.0            # общий бюджет запроса; остаток достраивается в кэше фоном (1.1: было 7)
RETRY_HINT_MS = 2000        # через сколько клиенту просить снова, если ответ неполный
FRESH_DAYS = 60
FRESH_TAU = 21.0
HOP2 = 6                    # Reco 2: у скольких лучших соседей главная делает второй шаг графа
HOP2_BETA = 0.5
HOP2_BUDGET_S = 1.5
FIT_FLOOR = 0.35
FIT_SIGMA_MIN = 0.6
COOC_MIN = 3                # пара засчитывается, когда её видели минимум в трёх разных наборах сидов
COOC_GAMMA = 0.6
COOC_PER_SEED = 20
COOC_SEEDS = 15             # сколько сидов профиля идёт в статистику пар
POP_W, VFIT_W, AFF_W = 0.40, 0.45, 0.15
ALBUM_WINDOW_DAYS = 400     # «актуальный» релиз для карточки «Похоже на»

TTL = {
    "resolve": 30 * 86400,
    "onboard": 6 * 3600,
    "artist": 7 * 86400,
    "related": 24 * 3600,
    "albums": 6 * 3600,
    "radio": 3 * 3600,
    "top": 3 * 3600,
    "miss": 15 * 60,
}
RESPONSE_TTL = 15 * 60
STALE_TTL = 6 * 3600        # последняя ПОЛНАЯ главная: отдаётся вместо слабого неполного ответа

# Лента (1.1). Страница = до FEED_PAGE треков; граф раскрывается вширь по мере прокрутки.
FEED_PAGE = 30
FEED_PAGE_MIN, FEED_PAGE_MAX = 10, 50
FEED_ARTISTS_PER_PAGE = 10  # у скольких артистов берём топ на одну страницу
FEED_EXPAND_PER_PAGE = 3    # у скольких артистов раскрываем related на одну страницу
FEED_TOP_LIMIT = 25
FEED_PER_ARTIST_PAGE = 3    # не больше трёх треков одного артиста на страницу
FEED_DECAY = 0.6            # множитель веса на каждый шаг по графу вглубь
FEED_SEED_BOOST = 0.9       # знакомое тоже звучит: сид получает вес 0.9 * w_s, но не выше «близкого соседа»
FEED_KNOWN_FACTOR = 0.55    # известный артист уступает незнакомому
FEED_REPEAT_POWER = 1.8     # priority = score / (1 + взято)^1.8: артист «остывает», граф расширяется (замер: 1.2 -> до 12 треков
                            # на артиста за 40 страниц, 1.8 -> не больше 6 и ~400 артистов на 1200 треков)
FEED_MAX_CANDS = 1500
FEED_MAX_EMITTED = 8000
FEED_SESSIONS = 96
FEED_TTL = 3 * 3600

TYPE_LABEL = {"album": "Альбом", "ep": "Мини-альбом", "single": "Сингл"}

# ----------------------------------------------------------------------------- нормализация


def fold(text: str) -> str:
    """Регистр, акценты и пунктуация убраны; это сравнение имён, а не транслитерация."""
    base = unicodedata.normalize("NFKD", normalized(text))
    base = "".join(ch for ch in base if not unicodedata.combining(ch))
    return " ".join(re.sub(r"[\W_]+", " ", base).split())


def day_number(now: float) -> int:
    return int(now // 86400)


def daily_tie(key: str, day: int) -> float:
    h = int.from_bytes(hashlib.sha1(f"{key}:{day}".encode()).digest()[:4], "big")
    return (h % 10000) / 1_000_000.0          # [0, 0.01)


def phi(rank: int) -> float:
    return (1.0 + max(0, rank)) ** -0.5


def psi(fans: int) -> float:
    return min(1.0, 0.6 + 0.4 * max(0, fans) / 300.0)


def pop_of(rank: int) -> float:
    return min(1.0, math.log10(1.0 + max(0, rank)) / 6.0)


def fan_x(fans: int) -> float:
    return math.log10(10.0 + max(0, fans or 0))


def scene_of(weighted: list) -> Optional[tuple]:
    """[(вес, fans)] -> (mu, sigma) взвешенного log10(fans + 10); None — данных нет."""
    total = sum(w for w, _ in weighted if w > 0)
    if total <= 0:
        return None
    mu = sum(w * fan_x(f) for w, f in weighted if w > 0) / total
    var = sum(w * (fan_x(f) - mu) ** 2 for w, f in weighted if w > 0) / total
    return mu, max(FIT_SIGMA_MIN, math.sqrt(var))


def fit_of(fans: int, scene: Optional[tuple]) -> float:
    """psi * соответствие сцене. Без сцены — ровно psi (поведение Reco 1)."""
    base = psi(fans)
    if not scene:
        return base
    mu, sigma = scene
    return base * max(FIT_FLOOR, math.exp(-((fan_x(fans) - mu) ** 2) / (2.0 * sigma * sigma)))


def age_days(date: str, now: float) -> Optional[float]:
    try:
        stamp = datetime.strptime(date[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp()
    except (ValueError, TypeError):
        return None
    return (now - stamp) / 86400.0


# ----------------------------------------------------------------------------- профиль


class Profile:
    __slots__ = ("seeds", "known_names", "known_ids", "neg_names", "neg_ids", "recent", "version", "hints", "raw")

    def __init__(self, seeds, known_names, known_ids, neg_names, neg_ids, recent, version, hints=None, raw=None):
        self.seeds = seeds                  # [(ref, weight)], ref = ('id', '123') | ('name', 'zaylo')
        self.known_names, self.known_ids = known_names, known_ids
        self.neg_names, self.neg_ids = neg_names, neg_ids
        self.recent = recent                # [ref]
        self.version = version              # '' | 'slowed' | 'sped'
        self.hints = hints or {}            # имя (fold) -> название трека для точной привязки
        self.raw = raw or {}                # ref -> строка, как её прислал клиент (эхо в seeds[].ref)

    def key(self, day: int) -> str:
        body = json.dumps([self.seeds, sorted(self.known_names), sorted(self.known_ids),
                           sorted(self.neg_names), sorted(self.neg_ids), self.recent, self.version, day,
                           sorted(self.hints.items())],
                          ensure_ascii=False, sort_keys=True)
        return hashlib.sha1(body.encode()).hexdigest()


def _ref(text: str):
    text = (text or "").strip()
    if not text or len(text) > 80:
        return None
    if text.startswith("n:"):                    # имя из одних цифр: «n:070» — это имя, а не id
        name = fold(text[2:])
        return ("name", name) if name else None
    if text.isascii() and text.isdigit() and len(text) <= 12:
        return ("id", text)
    name = fold(text)
    return ("name", name) if name else None


def _split(text: str, limit: int):
    return [p for p in (text or "").split("|") if p.strip()][:limit]


def parse_profile(s: str = "", k: str = "", x: str = "", r: str = "", v: str = "",
                  h: str = "", s2: str = "") -> Profile:
    if len(s) + len(k) + len(x) + len(r) + len(v) + len(h) + len(s2) > MAX_QUERY:
        raise HTTPException(422, "profile too large")
    seeds, seen, raw = [], set(), {}
    for part in _split(s, MAX_SEEDS * 2) + _split(s2, MAX_SEEDS * 2):
        ref_text, _, weight_text = part.partition("~")
        ref = _ref(ref_text)
        try:
            weight = float(weight_text) if weight_text else 1.0
        except ValueError:
            weight = 1.0
        if ref is None or ref in seen or not math.isfinite(weight):
            continue
        seen.add(ref)
        raw[ref] = ref_text.strip()
        seeds.append((ref, min(1.0, max(0.05, weight))))
    seeds.sort(key=lambda it: (-it[1], it[0]))
    seeds = seeds[:MAX_SEEDS]

    def names_and_ids(text: str, limit: int):
        names, ids = set(), set()
        for part in _split(text, limit):
            ref = _ref(part)
            if ref:
                (ids if ref[0] == "id" else names).add(ref[1])
        return names, ids

    known_names, known_ids = names_and_ids(k, MAX_KNOWN)
    neg_names, neg_ids = names_and_ids(x, MAX_NEG)
    recent = [ref for ref in (_ref(p) for p in _split(r, MAX_RECENT)) if ref]
    version = v if v in ("slowed", "sped") else ""
    hints = {}
    for part in _split(h, MAX_HINTS * 2):
        name_text, _, title = part.partition("~")
        ref = _ref(name_text)
        title = " ".join(title.replace('"', " ").split())[:HINT_MAX]
        if ref and ref[0] == "name" and title and ref[1] not in hints and len(hints) < MAX_HINTS:
            hints[ref[1]] = title
    return Profile(seeds, known_names, known_ids, neg_names, neg_ids, recent, version, hints, raw)


def profile_from_body(payload) -> Profile:
    """Тело POST /reco/home: объект со строками s, k, x, r, v (компактная запись профиля)."""
    if not isinstance(payload, dict):
        raise HTTPException(422, "body must be an object")
    fields = {}
    for key, limit in FIELD_MAX.items():
        value = payload.get(key, "")
        if not isinstance(value, str):
            raise HTTPException(422, "field %s must be a string" % key)
        if len(value) > limit:
            raise HTTPException(422, "field %s too long" % key)
        fields[key] = value
    return parse_profile(fields["s"], fields["k"], fields["x"], fields["r"], fields["v"], fields["h"], fields["s2"])


# ----------------------------------------------------------------------------- апстрим


class Bucket:
    """Токен-бакет на все походы в Deezer. У Deezer лимит 50 запросов за 5 секунд на IP: берём 8/с."""

    def __init__(self, rate: float, burst: float, clock: Callable[[], float] = time.monotonic,
                 sleep: Callable[[float], None] = time.sleep):
        self.rate, self.burst, self.clock, self.sleep = rate, burst, clock, sleep
        self.tokens, self.stamp = burst, clock()
        self.lock = threading.Lock()

    def take(self, budget: float) -> bool:
        end = self.clock() + budget
        while True:
            with self.lock:
                now = self.clock()
                self.tokens = min(self.burst, self.tokens + (now - self.stamp) * self.rate)
                self.stamp = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return True
                wait_s = (1.0 - self.tokens) / self.rate
            if self.clock() + wait_s > end:
                return False
            self.sleep(wait_s)


class Upstream:
    """Кэш и защита вокруг dz_get: память + SQLite, склейка одинаковых запросов, устаревшее при сбое."""

    def __init__(self, dz_get, db_path: Optional[str], clock: Callable[[], float] = time.time,
                 bucket: Optional[Bucket] = None):
        self.dz_get, self.db_path, self.clock = dz_get, db_path, clock
        self.bucket = bucket or Bucket(8.0, 8.0)
        self.mem: dict[str, tuple[float, object]] = {}
        self.locks: dict[str, threading.Lock] = {}
        self.guard = threading.Lock()
        self.db_lock = threading.Lock()
        self.cooldown_until = 0.0
        self.calls = 0
        self.hits = 0
        self.stale = 0
        self.failures = 0
        self.db_errors = 0
        if db_path:
            # Кэш не критичен: если диск недоступен, главная живёт на памяти, а резолвер не падает при импорте.
            try:
                with closing(self._db()) as con, con:
                    con.execute("DELETE FROM reco_cache WHERE ts < ?", (self.clock() - 14 * 86400,))
            except (sqlite3.Error, OSError):
                self.db_errors += 1
                self.db_path = None

    # -- хранилище
    def _db(self):
        con = sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)
        con.execute("CREATE TABLE IF NOT EXISTS reco_cache (key TEXT PRIMARY KEY, ts REAL NOT NULL, body TEXT NOT NULL)")
        return con

    def _read(self, key: str):
        item = self.mem.get(key)
        if item:
            return item
        if not self.db_path:
            return None
        try:
            with self.db_lock, closing(self._db()) as con, con:
                row = con.execute("SELECT ts, body FROM reco_cache WHERE key=?", (key,)).fetchone()
        except (sqlite3.Error, OSError):          # заблокирована/повреждена/нет места: считаем «в кэше нет»
            self.db_errors += 1
            return None
        if not row:
            return None
        try:
            item = (float(row[0]), json.loads(row[1]))
        except (ValueError, TypeError):
            return None
        self.mem[key] = item
        return item

    def _write(self, key: str, value) -> None:
        ts = self.clock()
        if len(self.mem) > 6000:
            self.mem.clear()                      # дёшево и честно: диск всё равно держит копию
        self.mem[key] = (ts, value)
        if self.db_path:
            try:
                with self.db_lock, closing(self._db()) as con, con:
                    con.execute("INSERT OR REPLACE INTO reco_cache VALUES(?,?,?)",
                                (key, ts, json.dumps(value, ensure_ascii=False)))
            except (sqlite3.Error, OSError):      # ответ уже в памяти; диск догонит на следующем запросе
                self.db_errors += 1

    def peek(self, kind: str, path: str, params: dict):
        item = self._read(self._key(kind, path, params))
        return item[1] if item and self.clock() - item[0] <= TTL[kind] else None

    @staticmethod
    def _key(kind: str, path: str, params: dict) -> str:
        return kind + ":" + path + ":" + json.dumps(sorted(params.items()), ensure_ascii=False)

    # -- основной вызов
    def get(self, kind: str, path: str, params: Optional[dict] = None, budget: float = 4.0):
        """Ответ Deezer или None. None — «не знаем», не «пусто»: пустой ответ кэшируется как есть."""
        params = params or {}
        key = self._key(kind, path, params)
        now = self.clock()
        item = self._read(key)
        if item and now - item[0] <= TTL[kind]:
            self.hits += 1
            return item[1]
        with self.guard:
            lock = self.locks.setdefault(key, threading.Lock())
        # Склейка: пока первый поток ходит за ответом, остальные ждут его и читают из кэша.
        if not lock.acquire(timeout=max(0.0, budget)):
            return item[1] if item else None
        try:
            item = self._read(key)
            if item and self.clock() - item[0] <= TTL[kind]:
                self.hits += 1
                return item[1]
            if self.clock() < self.cooldown_until:
                return self._fallback(item)
            if not self.bucket.take(min(budget, 3.0)):
                return self._fallback(item)
            self.calls += 1
            try:
                value = self.dz_get(path, **params)
            except HTTPException as e:
                self.failures += 1
                if "quota" in str(getattr(e, "detail", "")).lower():
                    self.cooldown_until = self.clock() + 5.0
                return self._fallback(item)
            except Exception:                      # сеть, JSON, таймаут: апстрим не отвечает
                self.failures += 1
                return self._fallback(item)
            self._write(key, value)
            return value
        finally:
            lock.release()
            with self.guard:
                if len(self.locks) > 4000:
                    self.locks.clear()

    def _fallback(self, item):
        if item:
            self.stale += 1
            return item[1]                         # устаревшее лучше пустого экрана
        return None

    def stats(self) -> dict:
        return {"calls": self.calls, "hits": self.hits, "stale": self.stale, "failures": self.failures,
                "mem": len(self.mem), "db": "on" if self.db_path else "off", "db_errors": self.db_errors}


# ----------------------------------------------------------------------------- движок


def _image(row: dict, artist: bool = False) -> Optional[str]:
    prefix = "picture" if artist else "cover"
    for key in (prefix + "_xl", prefix + "_big", "picture_xl", "picture_big", prefix):
        value = row.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _artist_row(row: dict) -> Optional[dict]:
    if not isinstance(row, dict) or not row.get("id"):
        return None
    name = row.get("name")
    if not isinstance(name, str) or not name:
        return None
    fans = row.get("nb_fan")
    return {"id": str(row["id"]), "name": name, "fans": fans if isinstance(fans, int) else 0,
            "art": _image(row, True)}


class FeedSession:
    """Состояние одной ленты. Живёт в памяти процесса; на диск не пишется, профиль не сохраняется."""
    __slots__ = ("scene", "sid", "stable", "profile", "cands", "score", "explored", "used", "ids", "keys", "page",
                 "last", "last_page", "ts", "lock", "ready", "seed_ids", "weight_of", "day", "dry")

    def __init__(self, sid: str, stable: str, profile: Profile, now: float, day: int):
        self.sid, self.stable, self.profile, self.ts, self.day = sid, stable, profile, now, day
        self.cands: dict[str, dict] = {}          # id -> строка артиста
        self.score: dict[str, float] = {}
        self.explored: set = set()
        self.used: dict[str, int] = {}
        self.ids: "OrderedDict[str, None]" = OrderedDict()
        self.keys: "OrderedDict[tuple, None]" = OrderedDict()
        self.page = 0                             # сколько страниц выдано
        self.last: Optional[dict] = None          # последняя выданная страница (для повторного запроса)
        self.last_page = -1
        self.lock = threading.Lock()
        self.ready = False
        self.scene = None                         # Reco 2: (mu, sigma) сцены, считается при посеве
        self.seed_ids: set = set()
        self.weight_of: dict[str, float] = {}
        self.dry: set = set()                     # артисты, у которых новых треков уже не осталось


def parse_cursor(text) -> Optional[tuple]:
    if not isinstance(text, str) or not text or len(text) > CURSOR_MAX:
        return None
    sid, dot, page = text.partition(".")
    if not dot or len(sid) != 12 or any(ch not in "0123456789abcdef" for ch in sid) or not page.isdigit() or len(page) > 5:
        return None
    return sid, int(page)


def page_size_of(payload) -> int:
    raw = payload.get("n", FEED_PAGE) if isinstance(payload, dict) else FEED_PAGE
    if isinstance(raw, bool):
        return FEED_PAGE
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return FEED_PAGE
    return min(FEED_PAGE_MAX, max(FEED_PAGE_MIN, value))


class CoStats:
    """Анонимная статистика пар «артист–артист» из наборов сидов (Reco 2).

    На диске только id артистов и счётчики. Отпечаток набора (sha1 от отсортированных id и номера недели)
    живёт в памяти и нужен лишь затем, чтобы один и тот же профиль, открывший главную десять раз, не
    засчитывался десять раз. Перезапуск сервера его забывает — худший случай: набор посчитан дважды.
    """

    def __init__(self, db_path: Optional[str], clock: Callable[[], float] = time.time):
        self.db_path, self.clock = db_path, clock
        self.lock = threading.Lock()
        self.seen: "OrderedDict[str, int]" = OrderedDict()
        self.mem_pairs: dict[tuple, int] = {}
        self.mem_single: dict[str, int] = {}
        self.errors = 0
        if db_path:
            try:
                with closing(self._db()) as con, con:
                    pass
            except (sqlite3.Error, OSError):
                self.errors += 1
                self.db_path = None

    def _db(self):
        con = sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)
        con.execute("CREATE TABLE IF NOT EXISTS reco_pair (a TEXT NOT NULL, b TEXT NOT NULL, n INTEGER NOT NULL,"
                    " PRIMARY KEY (a, b))")
        con.execute("CREATE TABLE IF NOT EXISTS reco_single (a TEXT PRIMARY KEY, n INTEGER NOT NULL)")
        return con

    def record(self, ids: list) -> bool:
        ids = sorted({i for i in ids if isinstance(i, str) and i.isdigit()})[:COOC_SEEDS]
        if len(ids) < 2:
            return False
        week = int(self.clock() // (7 * 86400))
        mark = hashlib.sha1((",".join(ids) + "|%d" % week).encode()).hexdigest()
        with self.lock:
            if mark in self.seen:
                return False
            self.seen[mark] = week
            while len(self.seen) > 50000:
                self.seen.popitem(last=False)
            pairs = [(ids[i], ids[j]) for i in range(len(ids)) for j in range(i + 1, len(ids))]
            if not self.db_path:
                for p in pairs:
                    self.mem_pairs[p] = self.mem_pairs.get(p, 0) + 1
                for a in ids:
                    self.mem_single[a] = self.mem_single.get(a, 0) + 1
                return True
            try:
                with closing(self._db()) as con, con:
                    con.executemany("INSERT INTO reco_pair (a, b, n) VALUES (?, ?, 1) "
                                    "ON CONFLICT(a, b) DO UPDATE SET n = n + 1", pairs)
                    con.executemany("INSERT INTO reco_single (a, n) VALUES (?, 1) "
                                    "ON CONFLICT(a) DO UPDATE SET n = n + 1", [(a,) for a in ids])
            except (sqlite3.Error, OSError):
                self.errors += 1
                return False
        return True

    def neighbours(self, artist_id: str, limit: int = COOC_PER_SEED) -> list:
        """[(id, sim)] по убыванию sim; только пары с n_ab >= COOC_MIN."""
        with self.lock:
            if not self.db_path:
                rows = [(b if a == artist_id else a, n) for (a, b), n in self.mem_pairs.items()
                        if artist_id in (a, b) and n >= COOC_MIN]
                single = self.mem_single
                n_a = single.get(artist_id, 0)
                out = [(other, n / math.sqrt(max(1, n_a) * max(1, single.get(other, 0)))) for other, n in rows]
            else:
                try:
                    with closing(self._db()) as con:
                        rows = con.execute(
                            "SELECT CASE WHEN p.a = ? THEN p.b ELSE p.a END AS o, p.n, s.n FROM reco_pair p "
                            "JOIN reco_single s ON s.a = (CASE WHEN p.a = ? THEN p.b ELSE p.a END) "
                            "WHERE (p.a = ? OR p.b = ?) AND p.n >= ? ORDER BY p.n DESC LIMIT 200",
                            (artist_id, artist_id, artist_id, artist_id, COOC_MIN)).fetchall()
                        own = con.execute("SELECT n FROM reco_single WHERE a = ?", (artist_id,)).fetchone()
                except (sqlite3.Error, OSError):
                    self.errors += 1
                    return []
                n_a = own[0] if own else 0
                out = [(o, n / math.sqrt(max(1, n_a) * max(1, n_o))) for o, n, n_o in rows]
        out.sort(key=lambda it: (-it[1], it[0]))
        return out[:limit]


class Engine:
    def __init__(self, upstream: Upstream, dz_track: Callable[[dict], dict],
                 clock: Callable[[], float] = time.time, pool: Optional[ThreadPoolExecutor] = None,
                 costats: Optional[CoStats] = None):
        self.up, self.dz_track, self.clock = upstream, dz_track, clock
        self.co = costats if costats is not None else CoStats(None, clock)
        self.refreshing: set = set()
        self.pool = pool or ThreadPoolExecutor(max_workers=8, thread_name_prefix="zizi-reco")
        self.cache: dict[str, tuple[float, dict]] = {}
        self.cache_lock = threading.Lock()
        self.last_good: dict[str, tuple[float, dict]] = {}     # ключ без дня: ротация дня не обнуляет «запас»
        self.sessions: "OrderedDict[str, FeedSession]" = OrderedDict()
        self.sessions_lock = threading.Lock()
        self.stale_served = 0

    # -- параллельный map с общим дедлайном
    def pmap(self, fn, items, deadline: float):
        futures = [self.pool.submit(fn, item) for item in items]
        remaining = max(0.0, deadline - self.clock())
        done, _ = wait(futures, timeout=remaining)
        out, complete = [], True
        for future in futures:
            if future in done and future.exception() is None:
                out.append(future.result())
            else:
                out.append(None)
                complete = False
        return out, complete

    def pmap_flags(self, fn, items, deadline: float):
        """Как pmap, но с флагом «успел без исключения» на каждый элемент."""
        futures = [self.pool.submit(fn, item) for item in items]
        done, _ = wait(futures, timeout=max(0.0, deadline - self.clock()))
        out, flags = [], []
        for future in futures:
            good = future in done and future.exception() is None
            out.append(future.result() if good else None)
            flags.append(good)
        return out, flags

    def onboard(self, artist_id: str = "") -> dict:
        """Публичные карточки для знакомства. Ни профиль, ни история не участвуют."""
        if artist_id and (not artist_id.isascii() or not artist_id.isdigit() or len(artist_id) > 12):
            raise HTTPException(422, "invalid artist id")
        deadline = self.clock() + DEADLINE_S
        if artist_id:
            rows = self.related(artist_id, DEADLINE_S) or []
            artists = [dict(id=a["id"], name=a["name"], art=a["art"], genre="") for a in rows if a["id"] != artist_id]
        else:
            # Не один мировой чарт: несколько разных музыкальных направлений + общий чарт.
            genres = [("132", "Поп"), ("152", "Рок"), ("116", "Хип-хоп"), ("106", "Электроника"),
                      ("165", "R&B"), ("129", "Джаз"), ("98", "Классика"), ("", "Сейчас слушают")]
            def fetch(job):
                gid, label = job
                path = "genre/%s/artists" % gid if gid else "chart/0/artists"
                data = self.up.get("onboard", path, {"limit": 12}, max(0.3, deadline - self.clock()))
                result = []
                for raw in (data or {}).get("data", []):
                    a = _artist_row(raw)
                    if a:
                        result.append(dict(id=a["id"], name=a["name"], art=a["art"], genre=label))
                return result
            lanes, _ = self.pmap(fetch, genres, deadline)
            # Round robin: первая страница не состоит целиком из попа.
            artists = [lane[i] for i in range(12) for lane in lanes if lane and i < len(lane)]
        unique, seen = [], set()
        for a in artists:
            if a["id"] not in seen:
                seen.add(a["id"]); unique.append(a)
        return {"contract": CONTRACT, "artists": unique[:72]}

    # -- справочник артистов
    def resolve(self, ref, budget: float, need_info: bool = True, hint: Optional[str] = None):
        kind, value = ref
        if kind == "name" and hint:
            # Reco 2: «артист + трек» однозначнее имени. Берём артиста первого трека с тем же именем.
            found = self.up.get("resolve", "search/track", {"q": 'artist:"%s" track:"%s"' % (value, hint), "limit": 10},
                                budget)
            for row in (found or {}).get("data", []) if isinstance(found, dict) else []:
                art = row.get("artist") if isinstance(row, dict) else None
                if not isinstance(art, dict) or not art.get("id") or fold(str(art.get("name") or "")) != value:
                    continue
                if need_info:
                    full = self.up.get("artist", "artist/%s" % art["id"], {}, budget)
                    full_row = _artist_row(full) if isinstance(full, dict) else None
                    if full_row:
                        return full_row
                return {"id": str(art["id"]), "name": str(art.get("name") or ""), "fans": 0, "art": _image(art, True)}
        if kind == "id":
            if not need_info:
                # Сид за пределами якорей: имя и портрет не нужны, хватит самого id. Это минус
                # один запрос на сид — в холодном старте именно они съедают бюджет.
                return {"id": value, "name": "", "fans": 0, "art": None}
            row = self.up.get("artist", f"artist/{value}", {}, budget)
            return _artist_row(row) if isinstance(row, dict) else None
        found = self.up.get("resolve", "search/artist", {"q": value, "limit": 5}, budget)
        rows = [a for a in (_artist_row(r) for r in (found or {}).get("data", [])) if a]
        # Только точное совпадение нормализованного имени. «Waylon» не становится «Zaylo»,
        # а из нескольких тёзок берётся самый слушаемый.
        same = [a for a in rows if fold(a["name"]) == value]
        return max(same, key=lambda a: a["fans"]) if same else None

    def related(self, artist_id: str, budget: float):
        data = self.up.get("related", f"artist/{artist_id}/related", {"limit": 25}, budget)
        out = []
        for rank, row in enumerate((data or {}).get("data", [])):
            artist = _artist_row(row)
            if artist:
                artist["rank"] = rank
                out.append(artist)
        return out if data is not None else None

    def albums(self, artist: dict, budget: float):
        data = self.up.get("albums", f"artist/{artist['id']}/albums", {"limit": 8}, budget)
        if data is None:
            return None
        out = []
        for row in data.get("data", []):
            if not isinstance(row, dict) or not row.get("id"):
                continue
            record = row.get("record_type")
            date = row.get("release_date")
            art = _image(row)
            if record not in TYPE_LABEL or not isinstance(date, str) or not art:
                continue
            out.append({"id": str(row["id"]), "title": str(row.get("title") or ""), "date": date,
                        "type": record, "art": art, "artist_id": artist["id"], "artist": artist["name"]})
        out.sort(key=lambda a: (a["date"], a["id"]), reverse=True)
        return out

    def radio(self, artist_id: str, budget: float):
        data = self.up.get("radio", f"artist/{artist_id}/radio", {"limit": 40}, budget)
        if data is None:
            return None
        out = []
        for row in data.get("data", []):
            if not isinstance(row, dict) or not row.get("id") or not isinstance(row.get("artist"), dict):
                continue
            track = self.dz_track(row)
            track["kind"] = "track"
            track["explicit"] = bool(row.get("explicit_lyrics", False))
            track["rank"] = row.get("rank") if isinstance(row.get("rank"), int) else 0
            track["_short"] = str(row.get("title_short") or row.get("title") or "")
            out.append(track)
        return out

    def top(self, artist_id: str, budget: float):
        """Топ-треки артиста для ленты. Та же форма строки, что у радио; None — «не знаем»."""
        data = self.up.get("top", f"artist/{artist_id}/top", {"limit": FEED_TOP_LIMIT}, budget)
        if data is None:
            return None
        out = []
        for row in data.get("data", []):
            if not isinstance(row, dict) or not row.get("id") or not isinstance(row.get("artist"), dict):
                continue
            track = self.dz_track(row)
            track["kind"] = "track"
            track["explicit"] = bool(row.get("explicit_lyrics", False))
            track["rank"] = row.get("rank") if isinstance(row.get("rank"), int) else 0
            track["_short"] = str(row.get("title_short") or row.get("title") or "")
            out.append(track)
        return out

    # -- вспомогательные предикаты
    @staticmethod
    def _hint(profile: Profile, ref) -> Optional[str]:
        return profile.hints.get(ref[1]) if ref and ref[0] == "name" else None

    def _cooc_boost(self, score: dict, seed_artists: list, add: bool) -> int:
        """score[c] += COOC_GAMMA * w_s * sim(s, c). add=False — только уже известные графу кандидаты."""
        seed_ids = {a["id"] for a, _ in seed_artists}
        touched = 0
        for artist, weight in seed_artists[:COOC_SEEDS]:
            for other, sim in self.co.neighbours(artist["id"]):
                if other in seed_ids or (not add and other not in score):
                    continue
                score[other] = score.get(other, 0.0) + COOC_GAMMA * weight * sim
                touched += 1
        return touched

    @staticmethod
    def _is_known(profile: Profile, artist_id: str, name: str, extra_ids: set) -> bool:
        return (artist_id in profile.known_ids or artist_id in extra_ids
                or fold(name) in profile.known_names)

    @staticmethod
    def _is_negative(profile: Profile, artist_id: str, name: str) -> bool:
        return artist_id in profile.neg_ids or fold(name) in profile.neg_names

    # -- сборка
    def home(self, profile: Profile) -> dict:
        now = self.clock()
        day = day_number(now)
        key = profile.key(day)
        stable = profile.key(0)
        with self.cache_lock:
            hit = self.cache.get(key)
            if hit and now - hit[0] <= RESPONSE_TTL:
                return hit[1]
            old = self.last_good.get(stable)
        # Reco 2: устаревшее-пока-обновляется. Полная главная этого профиля моложе STALE_TTL уходит сразу,
        # пересборка — в фоне (одна на профиль). Человек не ждёт сборки ради того, что уже видел.
        if old and now - old[0] <= STALE_TTL:
            self._refresh_later(profile, key, stable)
            self.stale_served += 1
            return dict(old[1], stale=True, complete=True)
        deadline = now + DEADLINE_S
        result = self._build(profile, now, day, deadline)
        self._remember(key, stable, now, result)
        if result["complete"] and result["shelves"]:
            return result
        if not result["complete"]:
            result["retry_ms"] = RETRY_HINT_MS
        return result

    def _remember(self, key: str, stable: str, now: float, result: dict) -> None:
        if result.get("complete") and result.get("seeds"):
            self.co.record([s["id"] for s in result["seeds"]])
        if result["complete"] and result["shelves"]:
            with self.cache_lock:
                if len(self.cache) > 64:
                    self.cache.clear()
                if len(self.last_good) > 64:
                    self.last_good.clear()
                self.cache[key] = (now, result)
                self.last_good[stable] = (now, result)

    def _refresh_later(self, profile: Profile, key: str, stable: str) -> None:
        with self.cache_lock:
            if key in self.refreshing:
                return
            self.refreshing.add(key)

        def run():
            try:
                now = self.clock()
                self._remember(key, stable, now, self._build(profile, now, day_number(now), now + DEADLINE_S))
            except Exception:  # noqa: BLE001 — фоновая пересборка не должна ронять пул
                pass
            finally:
                with self.cache_lock:
                    self.refreshing.discard(key)
        threading.Thread(target=run, name="zizi-reco-refresh", daemon=True).start()

    def _build(self, profile: Profile, now: float, day: int, deadline: float) -> dict:
        complete = True
        failures_before = self.up.failures
        budget = lambda: max(0.3, deadline - self.clock())

        # 1. Сиды -> артисты Deezer.
        wanted = list(profile.seeds)
        for ref in profile.recent:
            if all(ref != seed[0] for seed in wanted):
                wanted.append((ref, 0.0))
        info_for = {ref for ref, _ in wanted[:ANCHORS]} | set(profile.recent)
        resolved, ok = self.pmap(lambda item: self.resolve(item[0], budget(), item[0] in info_for,
                                                           self._hint(profile, item[0])), wanted, deadline)
        complete &= ok
        seed_artists = []                          # [(artist, weight)]
        recent_artists = []
        by_ref = {}
        ref_of = {}                                # id артиста -> строка сида, как её прислал клиент
        for (ref, weight), artist in zip(wanted, resolved):
            if not artist:
                continue
            by_ref[ref] = artist
            if weight > 0 and all(artist["id"] != a["id"] for a, _ in seed_artists):
                seed_artists.append((artist, weight))
                ref_of[artist["id"]] = profile.raw.get(ref, "")
        for ref in profile.recent:
            artist = by_ref.get(ref)
            if artist and all(artist["id"] != a["id"] for a in recent_artists):
                recent_artists.append(artist)
        seed_artists = [s for s in seed_artists if not self._is_negative(profile, s[0]["id"], s[0]["name"])]
        if not seed_artists:
            complete = complete and self.up.failures == failures_before
            return {"contract": CONTRACT, "src": "deezer", "complete": complete, "cold": True,
                    "generated": int(now), "seeds": [], "shelves": []}
        seed_artists.sort(key=lambda s: (-s[1], s[0]["id"]))
        seed_ids = {a["id"] for a, _ in seed_artists}
        weight_of = {a["id"]: w for a, w in seed_artists}

        # 2. Граф (related) и радио ОДНИМ параллельным этапом. Раньше радио ждало конца альбомов, а
        # в холодном старте альбомы съедают весь бюджет: полки с треками не появлялись вовсе, и
        # главная выглядела пустой. Теперь станция и «Начни с этой музыки» готовы раньше альбомов.
        graph_sources = [a for a, _ in seed_artists[:RELATED_USED]]
        for artist in recent_artists[:1]:
            if artist["id"] not in {a["id"] for a in graph_sources}:
                graph_sources.append(artist)
        radio_sources = [a for a, _ in seed_artists[:2]]
        for artist in recent_artists[:1]:
            if artist["id"] not in {a["id"] for a in radio_sources}:
                radio_sources.append(artist)
        jobs = [("related", a) for a in graph_sources] + [("radio", a) for a in radio_sources]
        got, ok = self.pmap(lambda job: (self.related if job[0] == "related" else self.radio)(job[1]["id"], budget()),
                            jobs, deadline)
        complete &= ok
        graphs, pools = got[:len(graph_sources)], got[len(graph_sources):]
        related = {a["id"]: g for a, g in zip(graph_sources, graphs) if g}

        # 3. Агрегат: score(c) = sum_s w_s * phi(r) * fit(fans) (Reco 2: fit = psi * соответствие сцене).
        scene = scene_of([(weight_of.get(src["id"], 0.5) * phi(c["rank"]), c["fans"])
                          for src in graph_sources for c in related.get(src["id"], [])])
        score: dict[str, float] = {}
        info: dict[str, dict] = {}
        for source in graph_sources:
            weight = weight_of.get(source["id"], 0.5)      # последний прослушанный без веса считается за 0.5
            for cand in related.get(source["id"], []):
                if cand["id"] in seed_ids or self._is_negative(profile, cand["id"], cand["name"]):
                    continue
                score[cand["id"]] = score.get(cand["id"], 0.0) + weight * phi(cand["rank"]) * fit_of(cand["fans"], scene)
                info[cand["id"]] = cand
        self._cooc_boost(score, seed_artists, add=False)

        def is_known(cid: str) -> bool:
            return self._is_known(profile, cid, info[cid]["name"], seed_ids)

        # 4. Якоря «Похоже на»: два главных сида + последний прослушанный, если это другой артист.
        anchors = [a for a, _ in seed_artists[:2]]
        for artist in recent_artists:
            if len(anchors) >= ANCHORS:
                break
            if artist["id"] not in {a["id"] for a in anchors} and artist["id"] in related:
                anchors.append(artist)
        anchors = [a for a in anchors if related.get(a["id"])][:ANCHORS]

        wanted_albums: dict[str, dict] = {}
        anchor_rows: dict[str, list] = {}
        for anchor in anchors:
            rows = []
            for cand in related[anchor["id"]]:
                if self._is_negative(profile, cand["id"], cand["name"]) or cand["id"] in seed_ids:
                    continue
                # Известные артисты остаются в «Похоже на», но уступают место незнакомым (x0.6).
                rank_value = phi(cand["rank"]) * psi(cand["fans"]) * (0.6 if self._is_known(profile, cand["id"], cand["name"], seed_ids) else 1.0)
                rows.append((rank_value, cand))
            rows.sort(key=lambda it: (-it[0], it[1]["id"]))
            anchor_rows[anchor["id"]] = [c for _, c in rows[:PER_ANCHOR]]
            for cand in anchor_rows[anchor["id"]]:
                wanted_albums[cand["id"]] = cand
        for artist, _ in seed_artists[:3]:
            wanted_albums[artist["id"]] = artist       # собственные релизы сидов нужны для «Новой музыки»
        # Кандидаты в полку «Новая музыка» берём из топа агрегата, пока бюджет позволяет.
        for cid, _ in sorted(score.items(), key=lambda it: (-it[1], it[0]))[:6]:
            wanted_albums.setdefault(cid, info[cid])

        # Reco 2: второй шаг графа идёт тем же параллельным этапом, что и альбомы, и полноту не определяет.
        hop_from = [cid for cid, _ in sorted(score.items(), key=lambda it: (-it[1], it[0]))
                    if cid not in related][:HOP2]
        album_jobs = list(wanted_albums.values())
        hop_deadline = min(deadline, self.clock() + HOP2_BUDGET_S)
        failures_mid = self.up.failures
        jobs = [("albums", a) for a in album_jobs] + [("hop", cid) for cid in hop_from]
        got, flags = self.pmap_flags(
            lambda job: self.albums(job[1], budget()) if job[0] == "albums"
            else self.related(job[1], max(0.3, hop_deadline - self.clock())), jobs, deadline)
        complete &= all(flags[:len(album_jobs)])
        album_lists, hop_graphs = got[:len(album_jobs)], got[len(album_jobs):]
        albums_of = {a["id"]: lst for a, lst in zip(album_jobs, album_lists) if lst is not None}
        hop_failures = 0
        if hop_from:
            # Сбои второго шага не считаются сбоем сборки: вычитаем их из счётчика ниже.
            hop_failures = sum(1 for g in hop_graphs if g is None)
            hop_failures = min(hop_failures, max(0, self.up.failures - failures_mid))
            top1 = max(score.values()) if score else 1.0
            gains: dict[str, float] = {}
            for cid, graph in zip(hop_from, hop_graphs):
                if not graph:
                    continue
                parent = score.get(cid, 0.0) / (top1 or 1.0)
                for cand in graph:
                    if cand["id"] in seed_ids or self._is_negative(profile, cand["id"], cand["name"]):
                        continue
                    gains[cand["id"]] = gains.get(cand["id"], 0.0) + HOP2_BETA * parent * phi(cand["rank"]) * fit_of(cand["fans"], scene)
                    info.setdefault(cand["id"], cand)
            for cid, gain in gains.items():
                score[cid] = score.get(cid, 0.0) + gain

        shelves: list[dict] = []
        shown_albums: set[str] = set()

        # 5. Полки «Похоже на».
        for anchor in anchors:
            items = []
            for cand in anchor_rows[anchor["id"]]:
                lst = albums_of.get(cand["id"])
                if not lst:
                    continue
                recent = [a for a in lst if (age_days(a["date"], now) or 1e9) <= ALBUM_WINDOW_DAYS]
                pick = next((a for a in (recent or lst) if a["id"] not in shown_albums), None)
                if pick is None:
                    continue
                shown_albums.add(pick["id"])
                items.append(self._album_card(pick))
            if len(items) >= 3:
                shelves.append({"id": f"similar:{anchor['id']}", "kind": "albums", "title": "Похоже на",
                                "anchor": {"id": anchor["id"], "name": anchor["name"], "art": anchor["art"]},
                                "items": items})

        # 6. Радио: пул уже получен на этапе 2.
        pool = self._merge_pool([p for p in pools if p], profile, seed_ids)
        top_score = max(score.values()) if score else 1.0
        def affinity(track: dict) -> float:
            aid = track.get("artist_id") or ""
            if aid in weight_of:
                return weight_of[aid]
            return min(1.0, score.get(aid, 0.0) / (top_score or 1.0))
        aff_bonus = lambda track: AFF_W * affinity(track)
        station = self._select(pool, 15, profile, day, per_artist=2, bonus=aff_bonus)
        used = {t["id"] for t in station}
        if len(station) >= 5:
            shelves.append({"id": "station", "kind": "tracks", "title": "Включи станцию с треками в твоём вкусе",
                            "items": station})

        # 7. Новая музыка.
        fresh = []
        for cid, lst in albums_of.items():
            base = 1.5 * weight_of[cid] if cid in weight_of else score.get(cid, 0.0)
            if base <= 0:
                continue
            for album in lst:
                age = age_days(album["date"], now)
                if age is None or age < -1 or age > FRESH_DAYS:
                    continue
                fresh.append((base * math.exp(-max(0.0, age) / FRESH_TAU), album["id"], album))
        fresh.sort(key=lambda it: (-it[0], it[1]))
        picked, per_artist = [], {}
        for value, _, album in fresh:
            if per_artist.get(album["artist_id"], 0) >= 2:
                continue
            per_artist[album["artist_id"]] = per_artist.get(album["artist_id"], 0) + 1
            picked.append(self._album_card(album))
            if len(picked) >= 12:
                break
        if len(picked) >= 2:
            shelves.append({"id": "fresh", "kind": "albums", "title": "Новая музыка специально для тебя", "items": picked})

        # 8. Рекомендованные исполнители: только незнакомые.
        ranked = [cid for cid, _ in sorted(score.items(), key=lambda it: (-it[1], it[0])) if not is_known(cid)]
        artists = [{"id": cid, "kind": "artist", "title": info[cid]["name"], "subtitle": "Исполнитель",
                    "art": info[cid]["art"]} for cid in ranked if info[cid]["art"]][:12]
        if len(artists) >= 4:
            shelves.append({"id": "artists", "kind": "artists", "title": "Рекомендованные исполнители", "items": artists})

        # 9. Начни с этой музыки: незнакомые артисты из того же пула, по одному треку, популярнее выше.
        starters, seen = [], set()
        for track in sorted(pool, key=lambda t: (-affinity(t), -t["rank"], t["id"])):
            artist_id = track.get("artist_id") or ""
            if (track["id"] in used or artist_id in seen or artist_id in seed_ids
                    or self._is_known(profile, artist_id, track.get("artist") or "", seed_ids)):
                continue
            seen.add(artist_id)
            starters.append(track)
        starters = self._select(starters, 10, profile, day, per_artist=1, bonus=aff_bonus)
        if len(starters) >= 4:
            shelves.append({"id": "start", "kind": "tracks", "title": "Начни с этой музыки", "items": starters})

        # Любой сбой апстрима за время сборки (в том числе спасённый устаревшим кэшем) — это
        # неполный ответ: он не кэшируется целиком, и клиент через 15 секунд просит снова.
        complete = complete and self.up.failures - hop_failures == failures_before
        return {
            "contract": CONTRACT, "engine": ENGINE_REV, "src": "deezer", "complete": complete, "cold": False,
            "generated": int(now),
            "seeds": [{"id": a["id"], "name": a["name"], "art": a["art"], "w": round(w, 3),
                       "ref": ref_of.get(a["id"], "")} for a, w in seed_artists],
            "shelves": [self._clean(s) for s in shelves],
        }

    # -- лента (1.1)
    def feed(self, profile: Profile, cursor, n: int) -> dict:
        """Страница бесконечной ленты. Курсор «<sid>.<страница>»; потеряна сессия — начинаем заново."""
        now = self.clock()
        day = day_number(now)
        stable = profile.key(0)
        parsed = parse_cursor(cursor)
        session, restarted = None, False
        if parsed:
            with self.sessions_lock:
                session = self.sessions.get(parsed[0])
                if session is not None and (session.stable != stable or now - session.ts > FEED_TTL):
                    session = None
                if session is not None:
                    self.sessions.move_to_end(parsed[0])
            restarted = session is None
        if session is None:
            session = self._new_session(profile, stable, now, day)
        # Одна критическая секция на сессию: проверка курсора и выдача страницы неделимы, иначе два
        # одновременных запроса одной страницы съели бы по странице каждый.
        mismatch = False
        with session.lock:
            if parsed and not restarted:
                if parsed[1] == session.last_page and session.last is not None:
                    return session.last                      # повтор уже выданной страницы: тот же ответ
                mismatch = parsed[1] != session.page         # курсор «из другой жизни»
            if not mismatch:
                return self._serve_locked(session, n, now, restarted)
        session = self._new_session(profile, stable, now, day)
        with session.lock:
            return self._serve_locked(session, n, now, True)

    def _serve_locked(self, session: FeedSession, n: int, now: float, restarted: bool) -> dict:
        """Выдать очередную страницу. Вызывающий держит session.lock."""
        session.ts = now
        page = self._feed_page(session, n, now, now + DEADLINE_S)
        page["restarted"] = restarted
        if page["items"]:
            session.last_page = session.page
            session.page += 1
            page["cursor"] = "%s.%d" % (session.sid, session.page)
            session.last = page
        else:
            page["cursor"] = "%s.%d" % (session.sid, session.page)
        return page

    def _new_session(self, profile: Profile, stable: str, now: float, day: int) -> FeedSession:
        session = FeedSession(uuid.uuid4().hex[:12], stable, profile, now, day)
        with self.sessions_lock:
            self.sessions[session.sid] = session
            for sid in [k for k, v in self.sessions.items() if now - v.ts > FEED_TTL]:
                self.sessions.pop(sid, None)
            while len(self.sessions) > FEED_SESSIONS:
                self.sessions.popitem(last=False)
        return session

    @staticmethod
    def _track_key(track: dict) -> tuple:
        base = fold(strip_version_phrases(normalized(track.get("_short") or track.get("title") or "")))
        return (track.get("artist_id") or fold(track.get("artist") or ""), base)

    def _feed_seed(self, s: FeedSession, deadline: float) -> bool:
        """Первый шаг сессии: сиды -> артисты, related верхних сидов -> стартовые оценки."""
        profile = s.profile
        # Повторный вызов после неполного первого не должен удваивать оценки: начинаем с чистого листа.
        s.cands, s.score, s.explored, s.seed_ids, s.weight_of = {}, {}, set(), set(), {}
        failures_before = self.up.failures
        budget = lambda: max(0.3, deadline - self.clock())
        wanted = list(profile.seeds)
        for ref in profile.recent:
            if all(ref != seed[0] for seed in wanted):
                wanted.append((ref, 0.0))
        resolved, ok = self.pmap(lambda item: self.resolve(item[0], budget(), False, self._hint(profile, item[0])),
                                 wanted, deadline)
        seeds, recent = [], []
        for (ref, weight), artist in zip(wanted, resolved):
            if not artist or self._is_negative(profile, artist["id"], artist["name"]):
                continue
            if weight > 0 and all(artist["id"] != a["id"] for a, _ in seeds):
                seeds.append((artist, weight))
            if ref in profile.recent and all(artist["id"] != a["id"] for a in recent):
                recent.append(artist)
        if not seeds and not recent:
            # pmap видит только исключения, а сбой апстрима Upstream.get превращает в None и считает сам:
            # «сиды не нашлись» (cold, окончательно) и «сеть лежала» (повторить) различаются по счётчику.
            s.ready = self.up.failures == failures_before
            return s.ready
        seeds.sort(key=lambda it: (-it[1], it[0]["id"]))
        for artist, weight in seeds:
            s.cands[artist["id"]] = artist
            s.score[artist["id"]] = FEED_SEED_BOOST * weight
            s.seed_ids.add(artist["id"])
            s.weight_of[artist["id"]] = weight
        sources = [a for a, _ in seeds[:RELATED_USED]]
        for artist in recent[:1]:
            if artist["id"] not in {a["id"] for a in sources}:
                sources.append(artist)
        graphs, ok2 = self.pmap(lambda a: self.related(a["id"], budget()), sources, deadline)
        s.scene = scene_of([(s.weight_of.get(src["id"], 0.5) * phi(c["rank"]), c["fans"])
                            for src, g in zip(sources, graphs) if g for c in g])
        for source, graph in zip(sources, graphs):
            if graph is None:
                continue
            s.explored.add(source["id"])
            weight = s.weight_of.get(source["id"], 0.5)
            for cand in graph:
                if cand["id"] in s.seed_ids or self._is_negative(profile, cand["id"], cand["name"]):
                    continue
                s.cands.setdefault(cand["id"], cand)
                s.score[cand["id"]] = s.score.get(cand["id"], 0.0) + weight * phi(cand["rank"]) * fit_of(cand["fans"], s.scene)
        # Reco 2: коллаборативные соседи входят в ленту и сами, без графа Deezer (имя не нужно — нужен id для top).
        before = set(s.score)
        self._cooc_boost(s.score, seeds, add=True)
        for cid in set(s.score) - before:
            if cid not in s.seed_ids:
                s.cands.setdefault(cid, {"id": cid, "name": "", "fans": 0, "art": None, "rank": 0})
        s.ready = bool(s.cands) and ok and ok2 and self.up.failures == failures_before
        return s.ready

    def _feed_alive(self, s: FeedSession) -> list:
        return [cid for cid in s.cands if cid not in s.dry]

    def _feed_fresh(self, s: FeedSession) -> int:
        """Живые артисты, у которых ещё не взят ни один трек: это «запас впереди» ленты."""
        return sum(1 for cid in s.cands if cid not in s.dry and not s.used.get(cid))

    def _feed_expand(self, s: FeedSession, deadline: float) -> bool:
        """Раскрытие графа вширь: related лучших нераскрытых артистов, вес соседей затухает в 0.6 раза."""
        # Граф раскрываем ЗАРАНЕЕ: пока впереди меньше трёх страниц нетронутых артистов. Условие «живых
        # меньше N» растягивало первый круг на сотни треков и до второго круга дело не доходило.
        if self._feed_fresh(s) >= 3 * FEED_ARTISTS_PER_PAGE:
            return True
        todo = sorted((cid for cid in s.cands if cid not in s.explored), key=lambda cid: (-s.score.get(cid, 0.0), cid))
        todo = todo[:FEED_EXPAND_PER_PAGE]
        if not todo:
            return True
        budget = lambda: max(0.3, deadline - self.clock())
        graphs, ok = self.pmap(lambda cid: self.related(cid, budget()), todo, deadline)
        top_score = max(s.score.values()) if s.score else 1.0
        for cid, graph in zip(todo, graphs):
            if graph is None:
                continue                                      # не раскрыт: попробуем на следующей странице
            s.explored.add(cid)
            parent = s.score.get(cid, 0.0) / (top_score or 1.0)
            for cand in graph:
                if cand["id"] in s.seed_ids or self._is_negative(s.profile, cand["id"], cand["name"]):
                    continue
                gain = parent * phi(cand["rank"]) * fit_of(cand["fans"], s.scene) * FEED_DECAY
                if gain <= 0.0:
                    continue
                s.cands.setdefault(cand["id"], cand)
                s.score[cand["id"]] = s.score.get(cand["id"], 0.0) + gain
        if len(s.cands) > FEED_MAX_CANDS:
            keep = sorted(s.cands, key=lambda cid: (-s.score.get(cid, 0.0), cid))[:FEED_MAX_CANDS]
            keep_set = set(keep) | s.seed_ids
            s.cands = {cid: row for cid, row in s.cands.items() if cid in keep_set}
            s.score = {cid: v for cid, v in s.score.items() if cid in keep_set}
        return ok

    def _feed_priority(self, s: FeedSession, cid: str) -> float:
        row = s.cands[cid]
        known = cid not in s.seed_ids and self._is_known(s.profile, cid, row.get("name") or "", set())
        base = s.score.get(cid, 0.0) * (FEED_KNOWN_FACTOR if known else 1.0)
        return base / (1.0 + s.used.get(cid, 0)) ** FEED_REPEAT_POWER

    def _feed_page(self, s: FeedSession, n: int, now: float, deadline: float) -> dict:
        failures_before = self.up.failures
        budget = lambda: max(0.3, deadline - self.clock())
        complete = True
        if not s.ready:
            complete &= self._feed_seed(s, deadline)
        taken: list[dict] = []
        page_counts: dict[str, int] = {}
        for _ in range(3):                                    # недобор страницы -> ещё круг, пока есть время
            if len(taken) >= n or not s.cands or self.clock() >= deadline - 0.2:
                break
            complete &= self._feed_expand(s, deadline)
            ranked = sorted(self._feed_alive(s), key=lambda cid: (-self._feed_priority(s, cid), cid))
            chosen = [cid for cid in ranked if page_counts.get(cid, 0) < FEED_PER_ARTIST_PAGE][:FEED_ARTISTS_PER_PAGE]
            if not chosen:
                break
            priorities = {cid: self._feed_priority(s, cid) for cid in chosen}
            top_priority = max(priorities.values()) or 1.0
            tops, ok = self.pmap(lambda cid: self.top(cid, budget()), chosen, deadline)
            complete &= ok
            raw = []
            for cid, tracks in zip(chosen, tops):
                if tracks is None:
                    continue
                fresh = [tr for tr in tracks if tr["id"] not in s.ids and self._track_key(tr) not in s.keys
                         and not self._is_negative(s.profile, tr.get("artist_id") or "", tr.get("artist") or "")]
                if not fresh:
                    s.dry.add(cid)
                raw.extend(tracks)
            pool = [tr for tr in self._merge_pool([raw], s.profile, s.seed_ids)
                    if tr["id"] not in s.ids and self._track_key(tr) not in s.keys]
            per_artist: dict[str, int] = {}
            trimmed = []
            for tr in pool:                                   # места по артисту с учётом уже взятого на странице
                artist = tr.get("artist_id") or tr.get("artist") or ""
                if page_counts.get(artist, 0) + per_artist.get(artist, 0) >= FEED_PER_ARTIST_PAGE:
                    continue
                per_artist[artist] = per_artist.get(artist, 0) + 1
                trimmed.append(tr)
            bonus = lambda tr: 0.15 * priorities.get(tr.get("artist_id") or "", 0.0) / top_priority
            batch = self._select(trimmed, n - len(taken), s.profile, s.day, FEED_PER_ARTIST_PAGE, bonus)
            if not batch and not ok:
                break
            for tr in batch:
                artist = tr.get("artist_id") or tr.get("artist") or ""
                page_counts[artist] = page_counts.get(artist, 0) + 1
                s.used[artist] = s.used.get(artist, 0) + 1
                s.ids[tr["id"]] = None
                s.keys[self._track_key(tr)] = None
                taken.append(tr)
            while len(s.ids) > FEED_MAX_EMITTED:
                s.ids.popitem(last=False)
            while len(s.keys) > FEED_MAX_EMITTED:
                s.keys.popitem(last=False)
        for tr in taken:
            tr.pop("_short", None)
            tr.pop("rank", None)
        complete = complete and self.up.failures == failures_before
        exhausted = s.ready and not self._feed_alive(s) and all(cid in s.explored for cid in s.cands)
        page = {"contract": FEED_CONTRACT, "items": taken, "complete": complete,
                "more": not exhausted, "n": len(taken), "generated": int(now)}
        if not s.cands and complete:
            page["cold"] = True
            page["more"] = False
        if not complete and len(taken) < n:
            page["retry_ms"] = RETRY_HINT_MS
        return page

    # -- карточки и треки
    @staticmethod
    def _album_card(album: dict) -> dict:
        card = {"id": album["id"], "kind": "album", "title": album["title"], "subtitle": album["artist"],
                "art": album["art"], "label": TYPE_LABEL.get(album["type"], "Альбом"),
                "released": album["date"], "artist_id": album["artist_id"]}
        return card

    @staticmethod
    def _clean(shelf: dict) -> dict:
        for item in shelf["items"]:
            item.pop("_short", None)
            item.pop("rank", None)
        return shelf

    def _merge_pool(self, pools, profile: Profile, seed_ids: set) -> list[dict]:
        """Объединение радио с дедупликацией версий: ключ (artist_id, название без пометок версии)."""
        best: dict[tuple, dict] = {}
        for pool in pools:
            for track in pool:
                artist_id = track.get("artist_id") or ""
                if self._is_negative(profile, artist_id, track.get("artist") or ""):
                    continue
                base = fold(strip_version_phrases(normalized(track["_short"] or track.get("title") or "")))
                if not base:
                    continue
                key = (artist_id or fold(track.get("artist") or ""), base)
                current = best.get(key)
                if current is None or self._version_fit(track, profile) > self._version_fit(current, profile) or (
                        self._version_fit(track, profile) == self._version_fit(current, profile)
                        and (track["rank"], track["id"]) > (current["rank"], current["id"])):
                    best[key] = track
        return sorted(best.values(), key=lambda t: (-t["rank"], t["id"]))

    @staticmethod
    def _version_fit(track: dict, profile: Profile) -> float:
        family = speed_family(version_tags(track.get("title") or ""))
        want = {"slowed": SLOWED, "sped": SPED_UP}.get(profile.version)
        if want:
            return 1.0 if want in family else 0.0
        return 0.5 if not family else 0.0          # без предпочтения оригинал лучше обработки

    def _select(self, pool, limit: int, profile: Profile, day: int, per_artist: int,
                bonus: Optional[Callable[[dict], float]] = None) -> list[dict]:
        """Жадный MMR: value - 0.30 * (уже взято у артиста) - 0.50 * (сосед-повтор)."""
        remaining = [dict(t) for t in pool]
        for t in remaining:
            t["_value"] = (POP_W * pop_of(t["rank"]) + VFIT_W * self._version_fit(t, profile)
                           + daily_tie(t["id"], day) + (bonus(t) if bonus else 0.0))
        taken, counts, previous = [], {}, None
        while remaining and len(taken) < limit:
            best, best_value = None, -1e9
            for t in remaining:
                artist = t.get("artist_id") or t.get("artist") or ""
                if counts.get(artist, 0) >= per_artist:
                    continue
                value = t["_value"] - 0.30 * counts.get(artist, 0) - (0.50 if artist == previous else 0.0)
                if value > best_value or (value == best_value and best is not None and t["id"] < best["id"]):
                    best, best_value = t, value
            if best is None:
                break
            remaining.remove(best)
            artist = best.get("artist_id") or best.get("artist") or ""
            counts[artist] = counts.get(artist, 0) + 1
            previous = artist
            best.pop("_value", None)
            taken.append(best)
        return taken


# ----------------------------------------------------------------------------- маршруты

ENGINE: Optional[Engine] = None


def install_routes(router, dz_get, dz_track, db_path: Optional[str] = None):
    """Врезка в УЖЕ защищённый router: guard висит на нём целиком, новый роут закрыт по умолчанию."""
    global ENGINE
    ENGINE = Engine(Upstream(dz_get, db_path), dz_track, costats=CoStats(db_path))

    @router.post("/reco/home")
    def reco_home(payload: dict = Body(...)):
        profile = profile_from_body(payload)
        if not profile.seeds and not profile.recent:
            raise HTTPException(422, "profile needs at least one seed")
        return ENGINE.home(profile)

    @router.post("/reco/feed")
    def reco_feed(payload: dict = Body(...)):
        profile = profile_from_body(payload)
        if not profile.seeds and not profile.recent:
            raise HTTPException(422, "profile needs at least one seed")
        return ENGINE.feed(profile, payload.get("c"), page_size_of(payload))

    @router.get("/reco/onboard")
    def reco_onboard(a: str = ""):
        return ENGINE.onboard(a)

    @router.get("/reco/health")
    def reco_health():
        return {"ok": True, "version": VERSION, "contract": CONTRACT, "feed_contract": FEED_CONTRACT,
                "engine": ENGINE_REV, "sessions": len(ENGINE.sessions), "stale_served": ENGINE.stale_served,
                "cooc_errors": ENGINE.co.errors,
                "upstream": ENGINE.up.stats()}

    return ENGINE
