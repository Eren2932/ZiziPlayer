#!/usr/bin/env python3
"""Real ASGI startup on loopback with temporary state; no upstream requests.

Requires FastAPI, uvicorn, httpx, yt-dlp and requests in this Python environment.
Does not read zizi.env or touch the production service/databases.
Reco paths are the public client contract: /reco/*, NOT /catalog/reco/*.
"""
import json
import os
import re
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

RECO_POST_PATHS = ("/reco/home", "/reco/feed")
RECO_HEALTH_PATH = "/reco/health"
LOG_TAIL_BYTES = 8192


def require(condition, reason):
    """Checks must also run when Python is invoked with optimization enabled."""
    if not condition:
        raise AssertionError(reason)


def catalog_version_ok(value):
    # Accept the existing major.minor labels and future patch releases, not a fixed release number.
    return isinstance(value, str) and bool(re.fullmatch(r'\d+\.\d+(?:\.\d+)?-[a-z0-9-]+', value))


def smoke_environment(tmp):
    """Explicit fixtures only: never inherit production ZIZI_*, proxies or PYTHONPATH."""
    return {
        'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'HOME': str(tmp),
        'PYTHONUNBUFFERED': '1', 'PYTHONIOENCODING': 'utf-8',
        'ZIZI_TOKEN': 'smoke-test-not-a-secret',
        'ZIZI_ADMIN_TOKEN': 'smoke-admin-not-a-secret',
        'ZIZI_DEVICE_KEY': 'smoke-device-not-a-secret', 'ZIZI_DEVICE_MODE': 'require',
        'ZIZI_CATALOG_TOKEN_MODE': 'require', 'ZIZI_EXTRA_ENABLED': '0',
        'ZIZI_CATALOG_DB': str(tmp) + '/catalog.db',
        'ZIZI_RECO_DB': str(tmp) + '/reco.db',
        'ZIZI_EXTRA_DB': str(tmp) + '/extra.db',
        'ZIZI_IMG_DIR': str(tmp) + '/img', 'ZIZI_AUDIO_DIR': str(tmp) + '/audio',
        'ZIZI_CACHE_FILE': str(tmp) + '/cache.json', 'ZIZI_PROXY_MODE': 'off',
    }


def fetch_json(opener, base, path, headers=None, timeout=2):
    req = urllib.request.Request(base + path, headers=headers or {})
    with opener.open(req, timeout=timeout) as response:
        return json.load(response)


def expect_status(opener, base, path, expected, *, method='GET', headers=None, data=None):
    req = urllib.request.Request(base + path, data=data, method=method, headers=headers or {})
    try:
        with opener.open(req, timeout=2) as response:
            actual = response.status
    except urllib.error.HTTPError as error:
        with error:
            actual = error.code
    require(actual == expected, '%s %s: expected HTTP %s, got %s' % (method, path, expected, actual))


def log_tail(log, limit=LOG_TAIL_BYTES):
    """Do not seek the file descriptor shared with the ASGI child."""
    log.flush()
    size = os.fstat(log.fileno()).st_size
    return os.pread(log.fileno(), limit, max(0, size - limit)).decode('utf-8', 'replace')


def stop_child(child):
    if child.poll() is None:
        child.terminate()
    try:
        child.wait(5)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait()


def main():
    root = Path(__file__).resolve().parent.parent
    # A developer shell may export HTTP(S)_PROXY. Smoke must still talk only to loopback.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with tempfile.TemporaryDirectory(prefix='zizi-stage2-smoke-') as tmp:
        # Keep the listening socket reserved; uvicorn inherits it via --fd.
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            sock.listen(32)
            base = 'http://127.0.0.1:%d' % sock.getsockname()[1]
            with tempfile.TemporaryFile() as log:
                child = subprocess.Popen(
                    [sys.executable, '-m', 'uvicorn', 'zizi_resolver:app',
                     '--fd', str(sock.fileno()), '--workers', '1', '--no-access-log'],
                    cwd=root, env=smoke_environment(tmp), pass_fds=(sock.fileno(),), stdout=log, stderr=log)
                checks = []
                try:
                    deadline = time.monotonic() + 12
                    while True:
                        if child.poll() is not None:
                            raise RuntimeError('ASGI startup failed (exit %s)' % child.returncode)
                        try:
                            health = fetch_json(opener, base, '/health', timeout=.5)
                            break
                        except (OSError, ValueError):
                            if time.monotonic() >= deadline:
                                raise RuntimeError('ASGI startup timeout')
                            time.sleep(.05)
                    require(health['version'] == '1.7-stage2', health.get('version'))
                    require(health['scheduler']['resolver_attached'] and health['scheduler']['slots'] == 1,
                            health.get('scheduler'))
                    checks.append('resolver health + shared scheduler')
                    health = fetch_json(opener, base, '/catalog/health')
                    version = health.get('version')
                    require(catalog_version_ok(version), version)
                    require(not health['extra']['enabled'], health.get('extra'))
                    for key, expected in (('browse_contract', 1), ('match_engine', 'smart'),
                                          ('reco_contract', 1), ('reco_feed', 1)):
                        require(health.get(key) == expected, (key, health.get(key)))
                    checks.append('catalog mounted + Browse 1 + smart match + Reco 1 + feed + extra disabled')
                    for path in ('/catalog/browse?q=test&kind=artist',
                                 '/catalog/browse/collection?id=1&kind=album',
                                 '/resolve?id=abcdefghijk', '/catalog/extra/search?q=test',
                                 '/match?title=test&artist=fixture', RECO_HEALTH_PATH):
                        expect_status(opener, base, path, 401)
                    for path in RECO_POST_PATHS:
                        expect_status(opener, base, path, 401, method='POST', data=b'{"s":"1~1"}',
                                      headers={'Content-Type': 'application/json'})
                    checks.append('resolve/match/extra/reco reject unauthenticated requests')
                    device = fetch_json(opener, base, '/auth/device', headers={
                        'Authorization': 'Bearer smoke-test-not-a-secret', 'X-Zizi-Install': 'stage2-smoke-install'})
                    headers = {'Authorization': 'Bearer ' + device['token'],
                               'X-Zizi-Install': 'stage2-smoke-install'}
                    expect_status(opener, base, '/catalog/extra/search?q=test', 503, headers=headers)
                    checks.append('device auth + disabled feature returns 503')
                    reco_health = fetch_json(opener, base, RECO_HEALTH_PATH, headers=headers)
                    require(reco_health.get('ok') and reco_health.get('contract') == 1
                            and reco_health.get('feed_contract') == 1, reco_health)
                    checks.append('authenticated /reco/health reports home + feed contracts')
                    # No valid profile is sent: validation exercises the routes without a Deezer request.
                    for path in RECO_POST_PATHS:
                        expect_status(opener, base, path, 422, method='POST', data=b'{}',
                                      headers=dict(headers, **{'Content-Type': 'application/json'}))
                    checks.append('canonical POST /reco/home + /reco/feed mounted, empty profile = 422')
                    for path in RECO_POST_PATHS:
                        expect_status(opener, base, path, 405, headers=headers)
                    checks.append('Reco profile endpoints reject GET (body-only contract)')
                finally:
                    failed = sys.exc_info()[0] is not None
                    stop_child(child)
                    if failed:
                        tail = log_tail(log)
                        if tail:
                            print('ASGI log (last %d bytes):\n%s' % (LOG_TAIL_BYTES, tail), file=sys.stderr)
    print(json.dumps({'ok': True, 'network': 'loopback-only', 'checks': checks}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({'ok': False, 'error': type(error).__name__, 'reason': str(error)}))
        raise SystemExit(1)
