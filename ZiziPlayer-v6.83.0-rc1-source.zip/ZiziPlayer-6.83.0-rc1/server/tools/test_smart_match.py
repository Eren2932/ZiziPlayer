#!/usr/bin/env python3
"""Умный подбор 1.14 (zizi_match + zizi_catalog.match_track) на заглушках и замороженных снимках.

Что это доказывает: наши правила на реальных страницах поиска YouTube, снятых 2026-10-02
(server/tools/fixtures/ytsearch_real.json), не дают ни 404 на то, что на YouTube есть, ни мусор
вместо трека. Чего это НЕ доказывает: что конкретный трек найдётся завтра — это свойство выдачи.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tools/_stub'))
import zizi_catalog as c      # noqa: E402
import zizi_match as zm       # noqa: E402

FIXTURE = json.loads((Path(__file__).resolve().parent / 'fixtures/ytsearch_real.json').read_text(encoding='utf-8'))['queries']


def cand(title='Artist - Song', uploader='Artist - Topic', dur=180, vid='abcdefghijk'):
    return dict(vid=vid, title=title, uploader=uploader, dur=dur)


def count(table):
    con = c._db()
    try:
        return con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
    finally:
        con.close()


class SmartBase(unittest.TestCase):
    """Общая обвязка: настоящий SQLite во временной папке, yt-dlp заменён выдачей из теста."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        p = patch.object(c, 'DB_PATH', self.tmp.name + '/catalog.db')
        p.start()
        self.addCleanup(p.stop)

    def match(self, candidates, title='Song', artist='Artist', dur=180, **kw):
        with patch.object(c, 'yt_search', return_value=list(candidates)):
            return c.match_track(title, artist, dur, **kw)

    def miss(self, candidates, title='Song', artist='Artist', dur=180, **kw):
        with self.assertRaises(c.HTTPException) as ctx:
            self.match(candidates, title, artist, dur, **kw)
        self.assertEqual(ctx.exception.status_code, 404)

    def judge(self, title, up='Artist - Topic', dur=180, req=('Song', 'Artist', 180), **kw):
        r = zm.make_request(*req)
        return zm.judge(r, cand(title, up, dur), **kw)


class RealYouTubeSnapshotTests(SmartBase):
    """Жалобы пользователя на живых данных. Артист в Deezer и канал на YouTube могут не совпадать."""

    def run_plan(self, title, artist, dur):
        def fake(text, n=6, budget=5.0, foreground=True):
            return list(FIXTURE.get(text, []))[:n]
        with patch.object(c, 'yt_search', fake):
            return c.match_track(title, artist, dur, explain=True)

    def pick(self, title, artist, dur):
        r = self.run_plan(title, artist, dur)
        best = next((x for x in r['candidates'] if x['vid'] == r['vid']), None)
        self.assertIsNotNone(best, f'нет победителя: {title!r}')
        return r, best

    def test_cops_attack_resolves_although_youtube_credits_another_name(self):
        # 1.13 отвечала 404: «H2HELL» нет ни в названии, ни в канале (канал «FORGET777 - Topic»).
        for title, dur, want in (('COPS ATTACK', 82, 'COPS ATTACK'),
                                 ('COPS ATTACK (Slowed)', 99, 'COPS ATTACK (SLOWED)'),
                                 ('COPS ATTACK (Sped Up)', 79, 'COPS ATTACK (SPEED UP)')):
            with self.subTest(title=title):
                r, best = self.pick(title, 'H2HELL', dur)
                self.assertEqual(best['title'].upper(), want)
                self.assertLessEqual(abs(best['dur'] - dur), 3)
                self.assertTrue(best['uploader'].endswith('Topic'), best)   # звук, а не клип
                self.assertIn(r['tier'], ('exact', 'good'))

    def test_ultra_slowed_gets_the_ultra_slowed_recording(self):
        r, best = self.pick('SEM DEMORA (Ultra Slowed)', 'DJ Samir', 130)
        self.assertEqual(r['vid'], '0bzYj7SdewA')
        self.assertEqual(r['tier'], 'exact')
        self.assertEqual(len(r['queries']), 1, 'точная версия находится с первого запроса')

    def test_slowed_never_lands_on_ultra_when_slowed_exists(self):
        r, best = self.pick('SEM DEMORA (Slowed)', 'DJ Samir', 116)
        low = best['title'].lower()
        self.assertIn('slowed', low)
        self.assertNotIn('ultra', low)
        self.assertNotIn('super', low)
        self.assertLessEqual(abs(best['dur'] - 116), 3)

    def test_quran_recitation_is_found_with_a_different_transliteration(self):
        r, best = self.pick('Surah Al-Fatiha', 'Saad Al ghamdi', 46)
        self.assertIn('fatiha', zm.fold(best['title']))
        self.assertLessEqual(abs(best['dur'] - 46), 5)

    def test_snapshot_rows_that_pass_are_short_tracks_never_news_or_mixes(self):
        req = zm.make_request('COPS ATTACK', 'H2HELL', 82)
        accepted = [row for rows in FIXTURE.values() for row in rows if zm.judge(req, row).ok]
        self.assertTrue(accepted)
        for row in accepted:
            self.assertLess(row['dur'], 200, row)
            self.assertNotIn('bodycam', row['title'].lower())
            self.assertNotIn('active attack', row['title'].lower())


class VersionPolicyTests(SmartBase):
    def test_exact_version_beats_any_substitute(self):
        sel = zm.Selector(zm.make_request('Song (Ultra Slowed)', 'Artist', 130))
        sel.add([cand('Artist - Song', 'Artist - Topic', 103, 'aaaaaaaaaaa'),
                 cand('Artist - Song (Super Slowed)', 'Artist - Topic', 123, 'bbbbbbbbbbb'),
                 cand('Artist - Song (Ultra Slowed)', 'Random Uploader', 131, 'ccccccccccc')])
        self.assertEqual(sel.best().vid, 'ccccccccccc')
        self.assertEqual(sel.best().tier, 'exact')

    def test_one_word_title_without_any_artist_evidence_is_not_served(self):
        # Не ошибка, а политика: «Song» от «Random Uploader» — это любая из сотни песен с таким названием.
        j = self.judge('Song (Ultra Slowed)', 'Random Uploader', 131, req=('Song (Ultra Slowed)', 'Artist', 130))
        self.assertFalse(j.ok)
        self.assertIn('confirmed artist', j.veto)

    def test_other_degree_is_a_variant_not_a_404(self):
        r = self.match([cand('Artist - Song (Super Slowed)', dur=123)], title='Song (Ultra Slowed)', dur=130)
        self.assertEqual(r['tier'], 'variant')
        self.assertTrue(r['substituted'])
        self.assertFalse(r['strict'])

    def test_original_is_served_for_missing_slowed_when_artist_is_confirmed(self):
        r = self.match([cand('Artist - Song', dur=103)], title='Song (Slowed)', dur=116)
        self.assertEqual(r['tier'], 'variant')
        self.assertTrue(r['fallback'])

    def test_substitution_without_confirmed_artist_is_refused(self):
        self.miss([cand('Song', 'Random Channel', 103)], title='Song (Slowed)', dur=116)

    def test_opposite_direction_is_never_served(self):
        self.miss([cand('Artist - Song (Sped Up)', dur=90)], title='Song (Slowed)', dur=116)
        self.miss([cand('Artist - Song (Slowed)', dur=130)], title='Song (Sped Up)', dur=90)

    def test_original_request_never_gets_a_speed_variant(self):
        for v in ('Slowed', 'Super Slowed', 'Ultra Slowed', 'Sped Up', 'Speed Up', 'Nightcore', 'Super Speed'):
            with self.subTest(version=v):
                self.assertFalse(self.judge(f'Artist - Song ({v})', dur=150).ok, v)

    def test_unrequested_hard_versions_are_refused_requested_ones_are_allowed(self):
        for v in ('Remix', 'Live', 'Karaoke', 'Instrumental', 'Acoustic', 'Cover', '8D Audio', 'Bass Boosted'):
            with self.subTest(version=v):
                self.assertFalse(self.judge(f'Artist - Song ({v})').ok, v)
        for v in ('Remix', 'Acoustic', 'Live'):
            with self.subTest(requested=v):
                j = self.judge(f'Artist - Song ({v})', req=(f'Song ({v})', 'Artist', 180))
                self.assertTrue(j.ok, v)
                self.assertEqual(j.tier, 'exact')

    def test_degree_words_of_the_same_family_do_not_block_playback(self):
        j = self.judge('Artist - Song (Slowed)', dur=129, req=('Song (Mega Slowed)', 'Artist', 129))
        self.assertTrue(j.ok)


class GarbageTests(SmartBase):
    def test_non_tracks_are_rejected_even_with_perfect_title_and_artist(self):
        for title, up, dur in (('Artist - Song 1 HOUR', 'Loops', 3600),
                               ('Artist - Song [Full Album]', 'X', 3000),
                               ('Top 10 songs 2024 ft Artist - Song', 'X', 1800),
                               ('Artist - Song | reaction', 'React', 300),
                               ('Artist Song tutorial piano', 'X', 180),
                               ('Artist - Song (Cover by Bob)', 'Bob', 180),
                               ('Artist - Song - 10 hours', 'x', 36000)):
            with self.subTest(title=title):
                self.assertFalse(self.judge(title, up, dur).ok, title)

    def test_wild_duration_is_a_veto_not_a_penalty(self):
        self.assertFalse(self.judge('Artist - Song', 'Artist - Topic', 959).ok)
        self.assertFalse(self.judge('Artist - Song', 'Artist - Topic', 5).ok)

    def test_different_song_with_same_artist_is_rejected(self):
        self.assertFalse(self.judge('Artist - Completely Different Tune').ok)

    def test_generic_title_needs_a_confirmed_artist(self):
        self.assertFalse(self.judge('Song', 'Random Channel', 180, req=('Intro', 'Artist', 180)).ok)
        self.assertTrue(self.judge('Artist - Intro', 'Artist - Topic', 180, req=('Intro', 'Artist', 180)).ok)

    def test_topic_audio_is_preferred_over_official_video_and_reupload(self):
        sel = zm.Selector(zm.make_request('Song', 'Artist', 180))
        sel.add([cand('Artist - Song (Official Video)', 'ArtistVEVO', 180, 'aaaaaaaaaaa'),
                 cand('Artist - Song', 'Some Reuploader', 180, 'bbbbbbbbbbb'),
                 cand('Song', 'Artist - Topic', 180, 'ccccccccccc')])
        self.assertEqual(sel.best().vid, 'ccccccccccc')

    def test_miss_is_cached_only_after_a_complete_empty_hunt(self):
        self.miss([])
        self.assertEqual(count('miss'), 1)

    def test_incomplete_hunt_is_503_and_writes_nothing(self):
        with patch.object(c, 'yt_search', side_effect=c.MatchUnavailable('timeout')):
            with self.assertRaises(c.HTTPException) as ctx:
                c.match_track('Song', 'Artist', 180)
            self.assertEqual(ctx.exception.status_code, 503)
        self.assertEqual((count('miss'), count('match')), (0, 0))

    def test_weak_variant_from_incomplete_hunt_is_not_cached(self):
        side = [[cand('Artist - Song (Super Slowed)', dur=123)], c.MatchUnavailable('x'), c.MatchUnavailable('x')]
        with patch.object(c, 'yt_search', side_effect=side):
            with self.assertRaises(c.HTTPException) as ctx:
                c.match_track('Song (Ultra Slowed)', 'Artist', 130)
            self.assertEqual(ctx.exception.status_code, 503)
        self.assertEqual(count('match'), 0)

    def test_miss_ttl_is_short_and_capped(self):
        self.assertLessEqual(c.MISS_TTL, 600)


class CacheAndKeyTests(SmartBase):
    def test_key_ignores_isrc_but_not_versions_or_duration(self):
        a = c.match_key('Song', 'Artist', 180, 'ISRC1')
        self.assertEqual(a, c.match_key('Song', 'Artist', 180, 'ISRC2'))
        self.assertNotEqual(a, c.match_key('Song (Slowed)', 'Artist', 180))
        self.assertNotEqual(c.match_key('Song (Super Slowed)', 'Artist', 120),
                            c.match_key('Song (Ultra Slowed)', 'Artist', 120))
        self.assertNotEqual(a, c.match_key('Song', 'Artist', 120))
        self.assertTrue(a.startswith(f'q{c.MATCH_POLICY}:'))

    def test_cache_hit_skips_the_hunt_and_is_rejudged(self):
        r1 = self.match([cand('Artist - Song')])
        self.assertFalse(r1['cached'])
        with patch.object(c, 'yt_search', side_effect=AssertionError('hunt must not run')):
            r2 = c.match_track('Song', 'Artist', 180)
        self.assertTrue(r2['cached'])
        self.assertEqual(r2['vid'], r1['vid'])

    def test_poisoned_cache_row_is_ignored_and_rehunted(self):
        key = c.match_key('Song', 'Artist', 180)
        c.cache_put(key, 'zzzzzzzzzzz', 99.0, cand('Artist - Song (Karaoke)', 'x', 180, 'zzzzzzzzzzz'))
        r = self.match([cand('Artist - Song', vid='yyyyyyyyyyy')])
        self.assertEqual(r['vid'], 'yyyyyyyyyyy')

    def test_explain_touches_no_cache(self):
        r = self.match([cand('Artist - Song')], explain=True)
        self.assertEqual(r['vid'], 'abcdefghijk')
        self.assertIn('candidates', r)
        self.assertEqual(count('match'), 0)

    def test_validation_errors_are_422(self):
        for t, a, d in (('', 'A', 1), ('T', '', 1), ('T', 'A', -1)):
            with self.assertRaises(c.HTTPException) as ctx:
                c.match_track(t, a, d)
            self.assertEqual(ctx.exception.status_code, 422)


class ScriptTests(SmartBase):
    """Кириллица, арабица и латиница одной записи должны сходиться; чужие — нет."""

    def test_transliteration_of_surah_names(self):
        for yt in ('Surat Al-Fatiha-Sheikh Saad Al Ghamdi', 'Surah Al Fatihah - Saad Al-Ghamdi',
                   'Сура Аль-Фатиха - Saad Al Ghamdi'):
            with self.subTest(title=yt):
                j = self.judge(yt, 'Quran Channel', 46, req=('Surah Al-Fatiha', 'Saad Al ghamdi', 46))
                self.assertTrue(j.ok, (yt, j.veto, j.score))

    def test_other_surah_is_not_accepted_for_fatiha(self):
        j = self.judge('Surah Al-Baqarah - Saad Al Ghamdi', 'Quran Channel', 46,
                       req=('Surah Al-Fatiha', 'Saad Al ghamdi', 46))
        self.assertFalse(j.ok)

    def test_arabic_script_title_matches_itself(self):
        j = self.judge('سورة الملك Al-Mulk', 'Sheikh Abdulrahman Al Ansari - Topic', 483,
                       req=('سورة الملك Al-Mulk', 'Sheikh Abdulrahman Al Ansari', 483))
        self.assertEqual(j.tier, 'exact')


class HealthAndWarmTests(SmartBase):
    def test_health_reports_the_real_engine_and_keeps_client_keys(self):
        h = c.catalog_health()
        self.assertTrue(h['ok'])
        self.assertEqual(h['version'], c.VERSION)
        self.assertEqual(h['match_engine'], 'smart')
        self.assertIs(h['strict_default'], False)
        self.assertIs(h['fallback'], True)       # телефон печатает этот ключ в диагностике
        for key in ('match_policy', 'match_rules', 'miss_ttl', 'square_art', 'matches_cached', 'misses_cached'):
            self.assertIn(key, h)

    def test_autowarm_is_bounded_and_survives_garbage(self):
        items = [dict(id=str(i), title=f'T{i}', artist='A', dur=100, src='deezer') for i in range(30)]
        items += [None, {}, {'id': 1}, {'id': '9', 'title': 'x', 'artist': 'y', 'dur': 'bad'}]
        with patch.object(c, '_warm_submit', return_value=True) as sub:
            n = c._autowarm(items)
        self.assertLessEqual(n, c.AUTOWARM_N)
        self.assertEqual(sub.call_count, n)

    def test_square_art_crops_letterboxed_thumbnail_to_a_square(self):
        if c._PILImage is None:
            self.skipTest('Pillow не установлен: crop выключен, остальное работает как раньше')
        import io
        im = c._PILImage.new('RGB', (640, 480), (0, 0, 0))
        im.paste(c._PILImage.new('RGB', (360, 360), (200, 40, 40)), (140, 60))
        buf = io.BytesIO()
        im.save(buf, 'JPEG')
        out = c.square_art(buf.getvalue())
        self.assertIsNotNone(out)
        w, h = c._PILImage.open(io.BytesIO(out)).size
        self.assertEqual(w, h)
        self.assertGreaterEqual(w, 340)
        self.assertIsNone(c.square_art(b'not an image'))


class PrecisionTests(SmartBase):
    """Что отсекает правило, а что нет. Строки взяты из реальной выдачи по «COPS ATTACK» и сурам."""

    REQ = ('COPS ATTACK', 'H2HELL', 82)

    def test_news_report_with_matching_words_is_rejected(self):
        j = self.judge('Bodycam footage shows attack on two female cops in Bankstown | 7NEWS',
                       '7NEWS Australia', 81, req=self.REQ)
        self.assertFalse(j.ok)

    def test_gaming_clip_with_the_song_is_rejected_without_a_confirmed_artist(self):
        j = self.judge('COPS ATTACK - m0NESY Cs2 clip', 'RAWKORE', 82, req=self.REQ)
        self.assertFalse(j.ok, (j.veto, j.score))

    def test_gaming_montage_is_rejected_even_when_the_artist_is_named(self):
        # Изолирует маску мусора: артист подтверждён, лишних слов мало, длительность точная.
        j = self.judge('H2HELL - COPS ATTACK (CS2 montage)', 'Some Channel', 82, req=self.REQ)
        self.assertFalse(j.ok, (j.veto, j.score))
        self.assertIn('junk', j.veto)

    def test_junk_word_inside_artist_name_is_not_junk(self):
        j = self.judge('Cs2 Crew - Night Drive', 'Cs2 Crew - Topic', 200, req=('Night Drive', 'Cs2 Crew', 200))
        self.assertTrue(j.ok, (j.veto, j.score))

    def test_half_of_a_two_word_title_is_a_different_song(self):
        j = self.judge('Police Attack', 'The Horribles - Topic', 82, req=self.REQ)
        self.assertFalse(j.ok)

    def test_same_artist_half_of_the_title_is_another_song(self):
        # Изолирует порог покрытия: артист, Topic и длительность идеальны, не совпало только слово «cops».
        j = self.judge('H2HELL - Police Attack', 'H2HELL - Topic', 82, req=self.REQ)
        self.assertFalse(j.ok, (j.veto, j.score))
        self.assertIn('coverage', j.veto)

    def test_many_extra_words_without_artist_is_a_video_not_a_track(self):
        # Изолирует правило лишних слов: мусорных слов в названии нет, артист не назван.
        j = self.judge('Cops attack on the old highway bridge', 'Some Channel', 82, req=self.REQ)
        self.assertFalse(j.ok, (j.veto, j.score))
        self.assertIn('unexplained', j.veto)

    def test_clean_reupload_without_artist_still_plays(self):
        j = self.judge('COPS ATTACK', 'ASGARD FAMQ | immortaltears666', 83, req=self.REQ)
        self.assertTrue(j.ok, (j.veto, j.score))

    def test_surah_word_is_optional_but_the_name_is_not(self):
        req = ('Surah Al-Mulk', 'Abdulrahman Al Ansari', 483)
        self.assertTrue(self.judge('Al-Mulk - Abdulrahman Al Ansari', 'Quran Hub', 483, req=req).ok)
        self.assertFalse(self.judge('Surah Al-Baqarah - Abdulrahman Al Ansari', 'Quran Hub', 483, req=req).ok)

    def test_honorifics_are_not_unexplained_words(self):
        j = self.judge('Dj Samir - SEM DEMORA', 'Random Uploader', 103, req=('SEM DEMORA', 'Samir', 103))
        self.assertNotIn('extra:dj', ','.join(j.notes))

    def test_clean_topic_upload_ends_the_hunt_after_one_query(self):
        calls = []
        def fake(text, n=6, budget=5.0, foreground=True):
            calls.append(text)
            return [cand('COPS ATTACK', 'FORGET777 - Topic', 82, 'aXXCGG1o9xw')]
        with patch.object(c, 'yt_search', fake):
            r = c.match_track(*self.REQ)
        self.assertEqual(r['vid'], 'aXXCGG1o9xw')
        self.assertEqual(len(calls), 1, calls)


class SubstituteModeTests(SmartBase):
    CANDS = [cand('Artist - Song', 'Artist - Topic', 120, 'aaaaaaaaaaa'),
             cand('Artist - Song (Super Slowed)', 'Artist - Topic', 123, 'bbbbbbbbbbb')]

    def run_mode(self, mode, title):
        with patch.object(zm, 'SUBSTITUTE', mode):
            return self.match(self.CANDS, title=title, dur=130)

    def test_all_serves_other_degree_or_original_with_a_flag(self):
        self.assertEqual(self.run_mode('all', 'Song (Ultra Slowed)')['vid'], 'bbbbbbbbbbb')
        r = self.run_mode('all', 'Song (Slowed)')
        self.assertTrue(r['substituted'] or r['vid'] == 'bbbbbbbbbbb')

    def test_degree_mode_refuses_the_original_but_keeps_other_degree(self):
        self.assertEqual(self.run_mode('degree', 'Song (Ultra Slowed)')['vid'], 'bbbbbbbbbbb')
        with patch.object(zm, 'SUBSTITUTE', 'degree'):
            self.miss(self.CANDS[:1], title='Song (Ultra Slowed)', dur=129)   # другой ключ кэша; одни оригиналы: 404

    def test_off_mode_wants_the_exact_version(self):
        with patch.object(zm, 'SUBSTITUTE', 'off'):
            self.miss(self.CANDS[:1], title='Song (Ultra Slowed)', dur=130)
            self.miss(self.CANDS[1:], title='Song (Ultra Slowed)', dur=130)


class WarmAndMissKeyTests(SmartBase):
    def test_warm_generation_reaches_the_job_and_stale_jobs_do_nothing(self):
        seen = {}
        class Pool:
            def submit(self, fn, *a, **kw):
                seen['fn'], seen['a'], seen['kw'] = fn, a, kw
                class F:
                    def add_done_callback(self, cb): cb(None)
                return F()
        d = dict(id='1', title='T', artist='A', dur=100, src='deezer')
        with patch.object(c, '_warm_pool', Pool()):
            c._warm_seen.clear()
            self.assertTrue(c._warm_submit('k-gen', c._warm_meta, d, gen=7))
        self.assertEqual(seen['kw'].get('gen'), 7, 'gen обязан доехать до задачи')
        c._warm_gen[0] = 8
        with patch.object(c, 'match_track') as mt:
            c._warm_meta('k-gen', d, gen=7)      # поколение устарело
        mt.assert_not_called()

    def test_warm_miss_without_alt_artists_does_not_block_the_tap_with_them(self):
        key = c.match_key('Song', 'Artist', 180)
        c.miss_put(c.miss_key(key), 'no playable candidate')          # промах прогрева
        with patch.object(c, 'yt_search', return_value=[cand('Song', 'Other - Topic', 180, 'zzzzzzzzzzz')]) as ys:
            with self.assertRaises(c.HTTPException):
                c.match_track('Song', 'Artist', 180)                  # тот же запрос: кэш промаха жив
            ys.assert_not_called()
            c.match_track('Song', 'Artist', 180, alt_artists=['Other'])   # у тапа больше имён: охота идёт
            ys.assert_called()

    def test_miss_key_is_stable_and_order_independent(self):
        k = 'q6:abc'
        self.assertEqual(c.miss_key(k), k)
        self.assertEqual(c.miss_key(k, ['B', 'a']), c.miss_key(k, ['A', 'b']))
        self.assertNotEqual(c.miss_key(k, ['x']), k)


if __name__ == '__main__':
    unittest.main(verbosity=2)
