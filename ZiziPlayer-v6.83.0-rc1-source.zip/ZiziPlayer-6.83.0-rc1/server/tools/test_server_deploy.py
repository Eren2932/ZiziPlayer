#!/usr/bin/env python3
"""Единый установщик сервера: печать комплекта, план, откат, и ровно тот сбой, который был на проде.

Прод-инцидент 2026-10-02: установщик Reco, собранный на 6.80.1, не знал про 1.14 и поставил каталог без неё;
по health было видно только «ok». Теперь успех = match_engine smart + reco_contract 1 + reco_feed 1 + версия.
"""
import contextlib
import io
import json
import os
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
import deploy_server as deploy  # noqa: E402
import seal_server_bundle as sealer  # noqa: E402

OLD_114 = b'# old 1.14 catalog\nVERSION = "1.14-smart-match"\n'
OLD_113 = b'# old 1.13 catalog\nVERSION = "1.13-version-family"\n'
OLD_VERSIONS_NO_API = b'# versions without speed api\n'
OLD_BROWSE_RC1 = b'# browse rc1 stand-in (the real one is registered by sha256 in server_known.json)\n'
PROD_BROWSE_RC1_SHA = 'd4c07d162a2af35b25b68c67e826db96a2c8dc098e8067a355f6e662e090c42b'   # sha256 /opt/zizi/zizi_browse.py на проде


def sha(data):
    return deploy.sha_bytes(data)


def fake_server(root, catalog=OLD_113, versions=None, extra_known=None, browse=OLD_BROWSE_RC1):
    """Каталог сервера «как был»: чужие модули как в релизе, каталог — условная старая база."""
    known = json.loads(deploy.KNOWN.read_text(encoding='utf-8'))
    for name in known['unchanged']:
        (root / name).write_bytes((deploy.ROOT / name).read_bytes())
    (root / 'zizi_catalog.py').write_bytes(catalog)
    (root / 'zizi_browse.py').write_bytes(browse)
    known['browse_bases'][sha(OLD_BROWSE_RC1)] = 'test-browse-rc1'
    (root / 'zizi_versions.py').write_bytes(versions if versions is not None else (deploy.ROOT / 'zizi_versions.py').read_bytes())
    known['catalog_bases'][sha(OLD_113)] = 'test-1.13'
    known['catalog_bases'][sha(OLD_114)] = 'test-1.14'
    known.update(extra_known or {})
    return known


class Seal(unittest.TestCase):
    def test_seal_matches_the_files_in_this_bundle(self):
        # Упало? Правили zizi_match/reco/catalog/versions: python3 tools/seal_server_bundle.py
        self.assertEqual(json.loads(deploy.SEAL.read_text())['files'], sealer.build()['files'])
        deploy.load_seal()

    def test_modified_bundle_file_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in deploy.MANAGED:
                (root / name).write_bytes((deploy.ROOT / name).read_bytes())
            (root / 'zizi_reco.py').write_bytes((root / 'zizi_reco.py').read_bytes() + b'\n# tampered\n')
            with self.assertRaisesRegex(deploy.DeployError, 'zizi_reco.py.*печат'):
                deploy.load_seal(root)

    def test_every_listed_test_exists(self):
        for name in deploy.TESTS:
            self.assertTrue((deploy.ROOT / 'tools' / name).is_file(), name)

    def test_bundle_reports_the_three_facts_the_installer_demands(self):
        _, payloads = deploy.load_seal()
        text = payloads['zizi_catalog.py'].decode()
        for needle in ('"match_engine": "smart"', '"reco_contract": RECO_CONTRACT', '"reco_feed": RECO_FEED'):
            self.assertIn(needle, text)
        self.assertEqual(deploy.expectations(payloads)['version'], deploy.bundle_version(payloads))


class Plan(unittest.TestCase):
    def setUp(self):
        _, self.payloads = deploy.load_seal()

    def test_every_known_base_is_replaceable_and_names_itself(self):
        for catalog, label in ((OLD_113, 'test-1.13'), (OLD_114, 'test-1.14')):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                known = fake_server(root, catalog)
                steps = {n: (a, why) for n, a, why in deploy.plan(root, self.payloads, known)}
                self.assertEqual(steps['zizi_catalog.py'][0], 'replace')
                self.assertIn(label, steps['zizi_catalog.py'][1])
                self.assertEqual(steps['zizi_match.py'][0], 'install')      # его нет на сервере без 1.14
                self.assertEqual(steps['zizi_reco.py'][0], 'install')

    def test_server_with_114_gets_reco_and_keeps_match(self):
        """Ровно прод-сценарий наоборот: на сервере стоит 1.14, ставим Reco, умный подбор обязан остаться."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, OLD_114)
            (root / 'zizi_match.py').write_bytes((deploy.ROOT / 'zizi_match.py').read_bytes())
            steps = {n: a for n, a, _ in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_match.py'], 'skip')
            self.assertEqual(steps['zizi_catalog.py'], 'replace')
            self.assertIn('zizi_match.py', deploy.BUNDLE)

    def test_sealed_release_is_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            for name in deploy.BUNDLE:
                (root / name).write_bytes(self.payloads[name])
            self.assertTrue(all(a == 'skip' for _, a, _ in deploy.plan(root, self.payloads, known)))

    def test_unknown_hotfix_is_refused_with_digest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, b'# hand edited')
            with self.assertRaisesRegex(deploy.DeployError, 'unknown server edit.*' + sha(b'# hand edited')):
                deploy.plan(root, self.payloads, known)

    def test_unknown_reco_module_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            (root / 'zizi_reco.py').write_bytes(b'# hand edited reco')
            with self.assertRaisesRegex(deploy.DeployError, 'zizi_reco.py'):
                deploy.plan(root, self.payloads, known)

    def test_missing_catalog_means_no_stage2(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            (root / 'zizi_catalog.py').unlink()
            with self.assertRaisesRegex(deploy.DeployError, 'не найден'):
                deploy.plan(root, self.payloads, known)

    def test_tampered_or_missing_neighbour_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            (root / 'zizi_guard.py').write_text('# hotfix')
            with self.assertRaisesRegex(deploy.DeployError, 'zizi_guard.py'):
                deploy.plan(root, self.payloads, known)

    def test_browse_rc1_from_prod_is_a_known_base_and_gets_replaced(self):
        """Инцидент 2026-10-02: на проде zizi_browse.py = Browse 1 RC1 (d4c07d16…), а 6.47.0 на сервер не ставился.
        Раньше он числился «неизменным» с хешем из репозитория и установка отказывала."""
        known = json.loads(deploy.KNOWN.read_text())
        self.assertIn(PROD_BROWSE_RC1_SHA, known['browse_bases'])
        self.assertNotIn('zizi_browse.py', known['unchanged'])
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            steps = {n: (a, why) for n, a, why in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_browse.py'][0], 'replace')
            self.assertIn('test-browse-rc1', steps['zizi_browse.py'][1])

    def test_browse_current_is_skipped_unknown_is_refused_missing_is_installed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, browse=(deploy.ROOT / 'zizi_browse.py').read_bytes())
            steps = {n: a for n, a, _ in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_browse.py'], 'skip')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, browse=b'# hand edited browse')
            with self.assertRaisesRegex(deploy.DeployError, 'unknown server edit.*zizi_browse.py.*' + sha(b'# hand edited browse')):
                deploy.plan(root, self.payloads, known)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            (root / 'zizi_browse.py').unlink()
            steps = {n: a for n, a, _ in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_browse.py'], 'install')

    def test_browse_is_written_before_the_catalog_that_imports_it(self):
        self.assertLess(deploy.BUNDLE.index('zizi_browse.py'), deploy.BUNDLE.index('zizi_catalog.py'))

    @unittest.skipUnless(hasattr(os, 'symlink'), 'symlinks')
    def test_symlink_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root)
            (root / 'zizi_match.py').symlink_to(deploy.ROOT / 'zizi_match.py')
            with self.assertRaisesRegex(deploy.DeployError, 'symlink'):
                deploy.plan(root, self.payloads, known)

    def test_versions_module_is_replaced_only_when_api_is_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, versions=OLD_VERSIONS_NO_API)
            steps = {n: a for n, a, _ in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_versions.py'], 'replace')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = fake_server(root, versions=(deploy.ROOT / 'zizi_versions.py').read_bytes() + b'\n# local note\n')
            steps = {n: a for n, a, _ in deploy.plan(root, self.payloads, known)}
            self.assertEqual(steps['zizi_versions.py'], 'skip')

    def test_pins_cover_every_neighbour_the_catalog_imports(self):
        known = json.loads(deploy.KNOWN.read_text())
        text = (deploy.ROOT / 'zizi_catalog.py').read_text(encoding='utf-8')
        for name in ('zizi_browse', 'zizi_reco', 'zizi_guard', 'zizi_versions', 'zizi_match'):
            if ('from %s import' % name) in text or ('import %s' % name) in text:
                self.assertIn(name + '.py', list(known['unchanged']) + list(deploy.MANAGED), name)


class Backup(unittest.TestCase):
    def test_restore_removes_new_modules_and_restores_catalog(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dest, backup = root / 'dest', root / 'backup'
            dest.mkdir(); backup.mkdir()
            for name in deploy.MANAGED:
                (dest / name).write_text('new')
            (backup / 'zizi_catalog.py').write_text('old')
            (backup / 'manifest.json').write_text(json.dumps(
                {'zizi_catalog.py': deploy.digest(backup / 'zizi_catalog.py'), 'zizi_match.py': None, 'zizi_reco.py': None}))
            deploy.restore(dest, backup)
            self.assertEqual((dest / 'zizi_catalog.py').read_text(), 'old')
            self.assertFalse((dest / 'zizi_match.py').exists())
            self.assertFalse((dest / 'zizi_reco.py').exists())
            self.assertEqual((dest / 'zizi_versions.py').read_text(), 'new')      # чужое не трогаем

    def test_corrupt_backup_writes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in deploy.MANAGED:
                (root / name).write_text('untouched')
            (root / 'manifest.json').write_text(json.dumps({name: 'bad' for name in deploy.MANAGED}))
            with self.assertRaises(deploy.DeployError):
                deploy.restore(root, root)
            for name in deploy.MANAGED:
                self.assertEqual((root / name).read_text(), 'untouched')

    def test_manifest_cannot_name_files_outside_the_bundle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'manifest.json').write_text('{"../outside": null}')
            with self.assertRaises(deploy.DeployError):
                deploy.validate_backup(root)


class Apply(unittest.TestCase):
    def run_main(self, dest, known, healthy, tests_ok=True):
        calls = []

        def fake_tests(*a, **k):
            if not tests_ok:
                raise deploy.DeployError('test_x.py не прошёл (код 1). Вывод:\nboom')

        with mock.patch.object(deploy, 'KNOWN', deploy.KNOWN), \
             mock.patch.object(deploy.json, 'loads', side_effect=lambda text, _real=json.loads: known
                               if 'catalog_bases' in text else _real(text)), \
             mock.patch.object(deploy, 'service', lambda action: calls.append(action)), \
             mock.patch.object(deploy, 'check_health', lambda expect, base=None: (healthy, 'fake') if expect else (True, 'ok')), \
             mock.patch.object(deploy, 'run_tests', fake_tests), \
             mock.patch.object(deploy.os, 'geteuid', lambda: 0), \
             mock.patch.object(deploy.subprocess, 'check_output', lambda *a, **k: str(dest)):
            with contextlib.redirect_stdout(io.StringIO()) as out:
                try:
                    code = deploy.main(['--apply', '--dest', str(dest)])
                    return code, calls, out.getvalue(), None
                except BaseException as exc:                       # noqa: BLE001
                    return None, calls, out.getvalue(), exc

    def test_success_installs_all_three_modules_and_restarts_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            known = fake_server(dest, OLD_114)
            code, calls, out, err = self.run_main(dest, known, True)
            self.assertIsNone(err, err)
            self.assertEqual(code, 0)
            self.assertEqual(calls, ['stop', 'start'])
            for name in deploy.BUNDLE:
                self.assertEqual((dest / name).read_bytes(), (deploy.ROOT / name).read_bytes(), name)
            self.assertIn('match_engine=smart, reco_contract=1, reco_feed=1', out)
            self.assertTrue(list((dest / deploy.BACKUPS).iterdir()))

    def test_failed_health_restores_everything_including_new_modules(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            known = fake_server(dest, OLD_113)
            code, calls, out, err = self.run_main(dest, known, False)
            self.assertIsInstance(err, deploy.DeployError)
            self.assertIn('Server health failed', str(err))
            self.assertEqual((dest / 'zizi_catalog.py').read_bytes(), OLD_113)
            self.assertEqual((dest / 'zizi_browse.py').read_bytes(), OLD_BROWSE_RC1)
            self.assertFalse((dest / 'zizi_match.py').exists())
            self.assertFalse((dest / 'zizi_reco.py').exists())
            self.assertEqual(calls, ['stop', 'start', 'stop', 'start'])    # применили, не поднялось, откатили

    def test_failed_test_stops_before_anything_is_written_or_stopped(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            known = fake_server(dest, OLD_113)
            code, calls, out, err = self.run_main(dest, known, True, tests_ok=False)
            self.assertIsInstance(err, deploy.DeployError)
            self.assertIn('boom', str(err))
            self.assertEqual(calls, [])
            self.assertEqual((dest / 'zizi_catalog.py').read_bytes(), OLD_113)
            self.assertFalse((dest / deploy.BACKUPS).exists())

    def test_check_mode_writes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            known = fake_server(dest, OLD_113)
            calls = []
            with mock.patch.object(deploy.json, 'loads', side_effect=lambda text, _real=json.loads: known
                                   if 'catalog_bases' in text else _real(text)), \
                 mock.patch.object(deploy, 'service', lambda action: calls.append(action)), \
                 mock.patch.object(deploy, 'run_tests', lambda *a, **k: None), \
                 mock.patch.object(deploy.subprocess, 'check_output', lambda *a, **k: str(dest)), \
                 contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(deploy.main(['--dest', str(dest)]), 0)
            self.assertEqual(calls, [])
            self.assertEqual((dest / 'zizi_catalog.py').read_bytes(), OLD_113)
            self.assertIn('CHECK ONLY', out.getvalue())


class Health(unittest.TestCase):
    """Настоящий HTTP: «служба ответила» без match_engine/reco не считается успехом."""

    def serve(self, catalog, schema=None):
        resolver = {'version': deploy.RESOLVER_VERSION, 'scheduler': {'resolver_attached': True, 'slots': 1}}
        if schema is None:
            schema = {'paths': {path: {'post': {}} for path in deploy.RECO_POST_PATHS}}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):                                       # noqa: N802
                if self.path == '/health':
                    value = resolver
                elif self.path == '/catalog/health':
                    value = catalog
                elif self.path == '/openapi.json':
                    value = schema
                else:
                    self.send_response(404); self.end_headers(); return
                body = json.dumps(value).encode()
                self.send_response(200); self.send_header('Content-Length', str(len(body))); self.end_headers()
                self.wfile.write(body)

            def log_message(self, *a):
                pass

        server = HTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return 'http://127.0.0.1:%d' % server.server_port

    def check(self, catalog, schema=None):
        _, payloads = deploy.load_seal()
        with mock.patch.object(deploy, 'HEALTH_TRIES', 2), mock.patch.object(deploy.time, 'sleep', lambda s: None):
            return deploy.check_health(deploy.expectations(payloads), self.serve(catalog, schema))

    def good(self):
        _, payloads = deploy.load_seal()
        return {'ok': True, 'version': deploy.bundle_version(payloads), 'browse_contract': 1,
                'match_engine': 'smart', 'reco_contract': 1, 'reco_feed': 1}

    def test_the_incident_health_is_a_failure(self):
        # Ровно тот ответ, что был на проде после деплоя Reco на 1.13: ok, reco есть, а умного подбора нет.
        bad = dict(self.good(), version='1.13-version-family', match_policy=5, strict_default=True)
        bad.pop('match_engine')
        ok, why = self.check(bad)
        self.assertFalse(ok)
        self.assertIn('match_engine', why)

    def test_reco_without_feed_is_a_failure(self):
        ok, why = self.check(dict(self.good(), reco_feed=0))
        self.assertFalse(ok)
        self.assertIn('reco_feed', why)

    def test_full_health_passes(self):
        self.assertEqual(self.check(self.good()), (True, 'ok'))

    def test_flags_do_not_hide_missing_routes(self):
        ok, why = self.check(self.good(), {'paths': {}})
        self.assertFalse(ok)
        self.assertIn('POST /reco/home', why)
        self.assertIn('POST /reco/feed', why)

    def test_wrong_catalog_prefix_is_not_a_valid_client_contract(self):
        schema = {'paths': {'/catalog/reco/home': {'post': {}}, '/catalog/reco/feed': {'post': {}}}}
        ok, why = self.check(self.good(), schema)
        self.assertFalse(ok)
        self.assertIn('POST /reco/home', why)

    def test_get_does_not_satisfy_the_post_contract(self):
        schema = {'paths': {'/reco/home': {'post': {}}, '/reco/feed': {'get': {}}}}
        ok, why = self.check(self.good(), schema)
        self.assertFalse(ok)
        self.assertIn('POST /reco/feed', why)

    def test_bad_openapi_shape_is_a_failure_not_an_exception(self):
        ok, why = self.check(self.good(), {'paths': []})
        self.assertFalse(ok)
        self.assertIn('POST /reco/home', why)

    def test_rollback_health_does_not_require_new_reco_routes(self):
        catalog = {'ok': True, 'version': '1.13-version-family', 'browse_contract': 1}
        with mock.patch.object(deploy, 'HEALTH_TRIES', 1):
            self.assertEqual(deploy.check_health(None, self.serve(catalog, {'paths': {}})), (True, 'ok'))


class Tests(unittest.TestCase):
    def test_failing_test_reports_its_own_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'tools').mkdir()
            (root / 'tools' / 'test_bad.py').write_text('import sys\nprint("expected 1.9, got 1.15")\nsys.exit(1)\n')
            with self.assertRaisesRegex(deploy.DeployError, '(?s)test_bad.py.*expected 1.9, got 1.15'):
                deploy.run_tests(['test_bad.py'], root)


    def test_timeout_is_a_readable_refusal_with_partial_output(self):
        error = deploy.subprocess.TimeoutExpired('fixture', 180, output=b'partial stdout', stderr=b'partial stderr')
        with mock.patch.object(deploy.subprocess, 'run', side_effect=error):
            with self.assertRaisesRegex(deploy.DeployError, '(?s)test_slow.py.*180.*partial stdout.*partial stderr'):
                deploy.run_tests(['test_slow.py'])

    def test_tests_cannot_touch_inherited_production_paths_or_credentials(self):
        homes = []

        def run(args, **kw):
            env = kw['env']
            home = Path(env['HOME'])
            self.assertTrue(home.is_dir())
            homes.append(home)
            for key in ('ZIZI_TOKEN', 'ZIZI_DEVICE_KEY', 'ZIZI_OUTBOUND_PROXY', 'HTTP_PROXY', 'PYTHONPATH'):
                self.assertNotIn(key, env)
            for key in ('ZIZI_CATALOG_DB', 'ZIZI_RECO_DB', 'ZIZI_EXTRA_DB', 'ZIZI_IMG_DIR',
                        'ZIZI_AUDIO_DIR', 'ZIZI_CACHE_FILE'):
                self.assertEqual(Path(env[key]).parent, home, key)
            self.assertEqual(env['TMPDIR'], str(home))
            return subprocess_result()

        def subprocess_result():
            return deploy.subprocess.CompletedProcess([], 0, stdout='fixture success', stderr='')

        with mock.patch.dict(os.environ, {'ZIZI_TOKEN': 'fixture-prod-value',
                                         'ZIZI_CATALOG_DB': '/opt/zizi/production.db',
                                         'HTTP_PROXY': 'http://fixture.invalid', 'PYTHONPATH': '/fixture'}), \
             mock.patch.object(deploy.subprocess, 'run', side_effect=run), \
             contextlib.redirect_stdout(io.StringIO()):
            deploy.run_tests(['test_one.py', 'test_two.py'])
        self.assertEqual(len(set(homes)), 2)
        self.assertTrue(all(not home.exists() for home in homes))

    def test_regression_is_mandatory_and_precedes_real_smoke(self):
        self.assertIn('test_smoke_stage2.py', deploy.TESTS)
        self.assertLess(deploy.TESTS.index('test_smoke_stage2.py'), deploy.TESTS.index('smoke_stage2.py'))

    def test_output_tail_is_bounded_and_accepts_timeout_bytes(self):
        tail = deploy.test_output(b'first line\n' * 40, b'last diagnostic')
        self.assertEqual(len(tail.splitlines()), 30)
        self.assertTrue(tail.endswith('last diagnostic'))


if __name__ == '__main__':
    unittest.main(verbosity=1)
