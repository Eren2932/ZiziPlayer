#!/usr/bin/env python3
"""Пересобирает печать комплекта (server_bundle_seal.json). Запускать после ЛЮБОЙ правки файлов комплекта:
zizi_match.py, zizi_reco.py, zizi_browse.py, zizi_catalog.py, zizi_versions.py. test_server_deploy.py падает, если забыли."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NAMES = ('zizi_match.py', 'zizi_reco.py', 'zizi_browse.py', 'zizi_catalog.py', 'zizi_versions.py')


def build():
    return {'files': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in NAMES}}


if __name__ == '__main__':
    seal = build()
    (ROOT / 'tools' / 'server_bundle_seal.json').write_text(json.dumps(seal, indent=2) + '\n', encoding='utf-8')
    for name, value in seal['files'].items():
        print('%-18s %s' % (name, value))
