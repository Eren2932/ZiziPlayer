#!/usr/bin/env python3
"""Reco 1.1: бесконечная лента, быстрый неполный ответ и «запас» последней полной главной.

Сеть не нужна. Граф артистов синтетический, но бесконечный: у артиста X соседи X*25+1 .. X*25+25,
у каждого артиста 25 треков. Это модель «граф Deezer не кончается», а не снимок живого API:
живые фикстуры главной лежат в test_zizi_reco.py. Часы инъектированы.
"""
import sys
import threading
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "_stub"))
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import zizi_reco as reco                       # noqa: E402
from fastapi import APIRouter, HTTPException  # noqa: E402
from test_zizi_reco import Clock, FakeDeezer, NOW, SAMIR, ZAYLO, dz_track, profile, shelf  # noqa: E402


class GraphDeezer:
    """Бесконечный синтетический граф. Считает вызовы по видам, умеет ломать отдельные пути."""

    def __init__(self):
        self.calls = []
        self.lock = threading.Lock()
        self.broken = set()                    # виды вызовов, которые сейчас падают: {"top", "related", ...}
        self.names = {"zaylo": "1", "rubikdice": "2"}

    @staticmethod
    def kind(path):
        return path.rsplit("/", 1)[-1] if path.count("/") == 2 else path

    def __call__(self, path, **params):
        with self.lock:
            self.calls.append(path)
        if self.kind(path) in self.broken:
            raise RuntimeError("upstream down: " + path)
        if path == "search/artist":
            aid = self.names.get(str(params.get("q")).lower())
            return {"data": [{"id": int(aid), "name": str(params["q"]).title(), "nb_fan": 900}]} if aid else {"data": []}
        parts = path.split("/")
        if parts[0] == "artist" and len(parts) == 2:
            return {"id": int(parts[1]), "name": f"Artist {parts[1]}", "nb_fan": 900,
                    "picture_big": f"https://img/{parts[1]}.jpg"}
        if parts[0] == "artist" and parts[2] == "related":
            aid = int(parts[1])
            return {"data": [{"id": aid * 25 + k, "name": f"Artist {aid * 25 + k}", "nb_fan": 900,
                              "picture_big": f"https://img/{aid * 25 + k}.jpg"} for k in range(1, 26)]}
        if parts[0] == "artist" and parts[2] == "top":
            aid = int(parts[1])
            rows = []
            for j in range(1, 26):
                title = f"Song {j}" if j != 4 else "Song 1 (Slowed)"      # 4-й — версия 1-го: должна склеиться
                rows.append({"id": aid * 1000 + j, "title": title, "title_short": title, "duration": 180,
                             "rank": 900000 - j * 1000 + (aid % 7) * 100, "explicit_lyrics": False,
                             "artist": {"id": aid, "name": f"Artist {aid}"},
                             "album": {"id": aid, "title": f"Album {aid}", "cover_big": f"https://img/al/{aid}.jpg"}})
            return {"data": rows}
        if parts[0] == "artist" and parts[2] in ("radio", "albums"):
            return {"data": []}
        raise HTTPException(404, "unknown " + path)

    def count(self, kind):
        return sum(1 for p in self.calls if self.kind(p) == kind)


def engine_with(fake=None, clock=None):
    fake = fake or GraphDeezer()
    clock = clock or Clock()
    up = reco.Upstream(fake, None, clock, reco.Bucket(1000.0, 1000.0))
    return reco.Engine(up, dz_track, clock), fake, clock


def prof(**kw):
    return reco.parse_profile(kw.pop("s", "1~1|2~0.6"), kw.pop("k", ""), kw.pop("x", ""), kw.pop("r", ""), kw.pop("v", ""))


def walk(engine, profile_, pages, n=30):
    cursor, out = None, []
    for _ in range(pages):
        page = engine.feed(profile_, cursor, n)
        out.append(page)
        cursor = page["cursor"]
    return out


class FeedPaging(unittest.TestCase):
    def test_first_page_is_full_clean_and_json_safe(self):
        engine, _, _ = engine_with()
        page = engine.feed(prof(), None, 30)
        self.assertEqual(len(page["items"]), 30)
        self.assertEqual(page["n"], 30)
        self.assertTrue(page["complete"] and page["more"] and not page["restarted"])
        self.assertEqual(page["contract"], 1)
        for track in page["items"]:
            self.assertNotIn("_short", track)
            self.assertNotIn("rank", track)
            self.assertNotIn("_value", track)
            self.assertEqual(track["kind"], "track")
        import json
        json.dumps(page)

    def test_per_artist_cap_on_a_page(self):
        engine, _, _ = engine_with()
        for page in walk(engine, prof(), 6):
            counts = {}
            for t in page["items"]:
                counts[t["artist_id"]] = counts.get(t["artist_id"], 0) + 1
            self.assertLessEqual(max(counts.values()), reco.FEED_PER_ARTIST_PAGE)

    def test_feed_is_effectively_endless_and_never_repeats(self):
        engine, fake, _ = engine_with()
        pages = walk(engine, prof(), 40)                      # 40 * 30 = 1200 треков
        ids = [t["id"] for p in pages for t in p["items"]]
        self.assertGreaterEqual(len(ids), 1150)               # страницы не «усыхают»
        self.assertEqual(len(ids), len(set(ids)))             # ни одного повтора id
        keys = [(t["artist_id"], t["title"].replace(" (Slowed)", "")) for p in pages for t in p["items"]]
        self.assertEqual(len(keys), len(set(keys)))           # ни одной песни в двух версиях
        self.assertTrue(all(p["more"] for p in pages))
        artists = {t["artist_id"] for p in pages for t in p["items"]}
        self.assertGreater(len(artists), 100)                 # граф раскрылся вширь, а не крутит один круг
        # граф раскрывался постепенно: у страницы ограниченное число запросов
        self.assertLess(fake.count("top") + fake.count("related"), 40 * (reco.FEED_ARTISTS_PER_PAGE + reco.FEED_EXPAND_PER_PAGE) + 20)

    def test_graph_goes_deeper_than_first_ring(self):
        engine, _, _ = engine_with()
        walk(engine, prof(), 25)
        session = next(iter(engine.sessions.values()))
        depth2 = [cid for cid in session.cands if int(cid) > 2 * 25 + 25]    # внуки сидов
        self.assertGreater(len(depth2), 20)
        # вес затухает с глубиной: любой внук слабее лучшего соседа первого круга
        first_ring = [session.score[cid] for cid in session.cands if 25 < int(cid) <= 75]
        self.assertTrue(max(session.score[cid] for cid in depth2) < max(first_ring))

    def test_same_cursor_returns_same_page_after_a_dropped_connection(self):
        engine, fake, _ = engine_with()
        first = engine.feed(prof(), None, 30)
        second = engine.feed(prof(), first["cursor"], 30)
        calls = len(fake.calls)
        again = engine.feed(prof(), first["cursor"], 30)       # ответ потерялся, клиент повторил тот же курсор
        self.assertEqual([t["id"] for t in again["items"]], [t["id"] for t in second["items"]])
        self.assertEqual(len(fake.calls), calls)               # повтор бесплатный
        third = engine.feed(prof(), second["cursor"], 30)
        self.assertFalse(set(t["id"] for t in third["items"]) & set(t["id"] for t in second["items"]))

    def test_lost_session_restarts_instead_of_failing(self):
        engine, _, _ = engine_with()
        first = engine.feed(prof(), None, 30)
        engine.sessions.clear()                                # рестарт сервера
        page = engine.feed(prof(), first["cursor"], 30)
        self.assertTrue(page["restarted"])
        self.assertEqual(len(page["items"]), 30)
        self.assertNotEqual(page["cursor"].split(".")[0], first["cursor"].split(".")[0])

    def test_cursor_from_other_profile_is_not_honoured(self):
        engine, _, _ = engine_with()
        mine = engine.feed(prof(), None, 30)
        other = engine.feed(prof(s="2~1"), mine["cursor"], 30)
        self.assertTrue(other["restarted"])

    def test_garbage_cursor_starts_a_fresh_feed(self):
        engine, _, _ = engine_with()
        for bad in ("", "x", "abc.def", "zzzzzzzzzzzz.1", "a" * 200, 17, [], {"a": 1}, None):
            page = engine.feed(prof(), bad, 30)
            self.assertEqual(len(page["items"]), 30, bad)
            self.assertFalse(page["restarted"], bad)           # курсора по сути не было

    def test_skipped_page_number_restarts(self):
        engine, _, _ = engine_with()
        first = engine.feed(prof(), None, 30)
        sid = first["cursor"].split(".")[0]
        page = engine.feed(prof(), sid + ".9", 30)
        self.assertTrue(page["restarted"])

    def test_negative_artists_never_appear(self):
        engine, _, _ = engine_with()
        ids = {t["artist_id"] for p in walk(engine, prof(x="26|27|28"), 10) for t in p["items"]}
        self.assertFalse(ids & {"26", "27", "28"})

    def test_version_preference_decides_the_variant_of_one_song(self):
        engine, _, _ = engine_with()
        plain = [t["title"] for p in walk(engine, prof(), 3) for t in p["items"]]
        self.assertFalse(any("Slowed" in t for t in plain))    # без предпочтения оригинал лучше обработки
        engine2, _, _ = engine_with()
        slowed = [t["title"] for p in walk(engine2, prof(v="slowed"), 3) for t in p["items"]]
        self.assertTrue(any("Slowed" in t for t in slowed))
        self.assertFalse(any(t == "Song 1" for t in slowed))   # одна песня — одна версия

    def test_page_size_is_clamped(self):
        self.assertEqual(reco.page_size_of({"n": 5}), reco.FEED_PAGE_MIN)
        self.assertEqual(reco.page_size_of({"n": 5000}), reco.FEED_PAGE_MAX)
        self.assertEqual(reco.page_size_of({"n": "25"}), 25)
        for junk in ({"n": "x"}, {"n": None}, {"n": True}, {"n": [1]}, {}, None, "n"):
            self.assertEqual(reco.page_size_of(junk), reco.FEED_PAGE, junk)
        engine, _, _ = engine_with()
        self.assertEqual(len(engine.feed(prof(), None, 12)["items"]), 12)

    def test_second_user_with_same_taste_costs_no_upstream_calls(self):
        engine, fake, _ = engine_with()
        walk(engine, prof(), 3)
        calls = len(fake.calls)
        walk(engine, prof(), 3)                                # новая сессия, тот же профиль: всё из кэша апстрима
        self.assertEqual(len(fake.calls), calls)

    def test_sessions_are_bounded(self):
        engine, _, _ = engine_with()
        for i in range(reco.FEED_SESSIONS + 20):
            engine.feed(prof(s=f"{1 + i % 2}~1", r=""), None, 10)
        self.assertLessEqual(len(engine.sessions), reco.FEED_SESSIONS)

    def test_session_expires(self):
        engine, _, clock = engine_with()
        first = engine.feed(prof(), None, 30)
        clock.t += reco.FEED_TTL + 5
        page = engine.feed(prof(), first["cursor"], 30)
        self.assertTrue(page["restarted"])

    def test_concurrent_requests_for_one_cursor_consume_one_page(self):
        engine, _, _ = engine_with()
        first = engine.feed(prof(), None, 30)
        results = []

        def ask():
            results.append(engine.feed(prof(), first["cursor"], 30))

        threads = [threading.Thread(target=ask) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        ids = {tuple(x["id"] for x in r["items"]) for r in results}
        self.assertEqual(len(ids), 1)                               # все четверо получили одну и ту же страницу
        session = next(iter(engine.sessions.values()))
        self.assertEqual(session.page, 2)                           # а страница сессии продвинулась ровно один раз

    def test_hot_artists_cool_down_and_the_graph_keeps_widening(self):
        engine, _, _ = engine_with()
        items = [t for p in walk(engine, prof(), 40) for t in p["items"]]
        counts = {}
        for t in items:
            counts[t["artist_id"]] = counts.get(t["artist_id"], 0) + 1
        self.assertLessEqual(max(counts.values()), 6)               # FEED_REPEAT_POWER 1.8: 1.2 давал до 12
        self.assertGreaterEqual(len(counts), 350)                   # 1200 треков = не меньше 350 разных артистов


class FeedFailures(unittest.TestCase):
    def test_top_outage_gives_incomplete_page_and_keeps_cursor_usable(self):
        engine, fake, _ = engine_with()
        first = engine.feed(prof(), None, 30)
        fake.broken.add("top")
        bad = engine.feed(prof(), first["cursor"], 30)
        self.assertFalse(bad["complete"])
        self.assertEqual(bad["items"], [])
        self.assertEqual(bad["retry_ms"], reco.RETRY_HINT_MS)
        self.assertEqual(bad["cursor"], first["cursor"])        # страница не потрачена
        fake.broken.clear()
        good = engine.feed(prof(), bad["cursor"], 30)
        self.assertEqual(len(good["items"]), 30)
        self.assertTrue(good["complete"])
        self.assertFalse(set(t["id"] for t in good["items"]) & set(t["id"] for t in first["items"]))

    def test_total_outage_on_first_page_is_retryable_not_cold(self):
        engine, fake, _ = engine_with()
        fake.broken.update({"top", "related", "artist/1", "artist/2"})
        fake.broken.add("search/artist")
        page = engine.feed(prof(s="zaylo~1"), None, 30)
        self.assertEqual(page["items"], [])
        self.assertFalse(page["complete"])
        self.assertTrue(page["more"])
        self.assertNotIn("cold", page)

    def test_unknown_seeds_report_cold_and_stop(self):
        engine, _, _ = engine_with()
        page = engine.feed(prof(s="nobody at all~1"), None, 30)
        self.assertEqual(page["items"], [])
        self.assertTrue(page["complete"] and page.get("cold") and not page["more"])

    def test_related_outage_still_serves_seed_tracks(self):
        engine, fake, _ = engine_with()
        fake.broken.add("related")
        page = engine.feed(prof(), None, 30)
        self.assertGreaterEqual(len(page["items"]), 6)           # знакомое звучит, даже когда граф недоступен
        self.assertFalse(page["complete"])
        self.assertTrue({t["artist_id"] for t in page["items"]} <= {"1", "2"})

    def test_failed_seed_step_is_redone_without_double_counting(self):
        engine, fake, _ = engine_with()
        fake.broken.add("related")
        engine.feed(prof(), None, 30)
        fake.broken.clear()
        session = next(iter(engine.sessions.values()))
        self.assertFalse(session.ready)
        engine.feed(prof(), "%s.%d" % (session.sid, session.page), 30)
        top = max(session.score.values())
        self.assertLessEqual(top, 1.0 + 1e-9)                    # 1.0 = w * phi(0) * psi(900): без удвоения


class FeedRoute(unittest.TestCase):
    def test_route_roundtrip_and_validation(self):
        router = APIRouter(dependencies=["guard"])
        reco.install_routes(router, GraphDeezer(), dz_track, None)
        handler = next(fn for p, fn, _ in router.routes if p == "/reco/feed")
        body = {"s": "1~1|2~0.6", "k": "", "x": "", "r": "", "v": "", "n": 20}
        first = handler(payload=dict(body))
        self.assertEqual(len(first["items"]), 20)
        second = handler(payload=dict(body, c=first["cursor"]))
        self.assertFalse(set(t["id"] for t in first["items"]) & set(t["id"] for t in second["items"]))
        with self.assertRaises(HTTPException) as ctx:
            handler(payload={"s": ""})
        self.assertEqual(ctx.exception.status_code, 422)
        with self.assertRaises(HTTPException) as ctx:
            handler(payload={"s": 5})
        self.assertEqual(ctx.exception.status_code, 422)
        health = next(fn for p, fn, _ in router.routes if p == "/reco/health")()
        self.assertEqual(health["feed_contract"], 1)
        self.assertGreaterEqual(health["sessions"], 1)


class HomeSpeed(unittest.TestCase):
    """Главная: станция не ждёт альбомов, неполный ответ несёт подсказку, запас спасает от слабого ответа."""

    def make(self, fake=None):
        fake = fake or FakeDeezer()
        clock = Clock()
        up = reco.Upstream(fake, None, clock, reco.Bucket(1000.0, 1000.0))
        return reco.Engine(up, dz_track, clock), fake, clock

    def test_tracks_shelves_exist_even_when_albums_are_down(self):
        class NoAlbums(FakeDeezer):
            def __call__(self, path, **params):
                if path.endswith("/albums"):
                    raise RuntimeError("albums down")
                return super().__call__(path, **params)
        engine, fake, _ = self.make(NoAlbums())
        r = engine.home(profile())
        self.assertFalse(r["complete"])
        self.assertEqual(r["retry_ms"], reco.RETRY_HINT_MS)
        self.assertIsNotNone(shelf(r, "station"))              # раньше альбомы отнимали бюджет у радио
        self.assertIsNone(shelf(r, "similar:"))

    def test_related_and_radio_run_in_one_stage(self):
        class Slow(FakeDeezer):
            """Каждый вызов 0.25 с: последовательные этапы не уложились бы в 1.0 с, параллельный — да."""
        slow = Slow(delay=0.25)
        engine, _, _ = self.make(slow)
        import time
        old = reco.DEADLINE_S
        reco.DEADLINE_S = 20
        try:
            t0 = time.monotonic()
            engine.clock = time.time
            engine.up.clock = time.time
            r = engine.home(profile())
            spent = time.monotonic() - t0
        finally:
            reco.DEADLINE_S = old
        self.assertTrue(r["complete"])
        # резолв (1 шаг) + related/radio (1 шаг) + альбомы (1-2 шага при 8 потоках): заведомо меньше 5 с
        self.assertLess(spent, 5.0)

    def test_stale_complete_home_beats_a_weaker_incomplete_one(self):
        engine, fake, clock = self.make()
        good = engine.home(profile())
        self.assertTrue(good["complete"] and good["shelves"])
        clock.t += 4 * 3600 + 60                                # кэш главной и радио протухли, альбомы (6 ч) живы

        class Down(FakeDeezer):
            pass
        fake.fail = lambda path: RuntimeError("down " + path)
        weaker = engine.home(profile())
        self.assertTrue(weaker.get("stale"))
        self.assertTrue(weaker["complete"])                      # клиент не будет дёргать повторно
        self.assertEqual([s["id"] for s in weaker["shelves"]], [s["id"] for s in good["shelves"]])
        self.assertEqual(engine.stale_served, 1)

    def test_stale_is_not_served_after_stale_ttl(self):
        engine, fake, clock = self.make()
        engine.home(profile())
        clock.t += reco.STALE_TTL + 60
        fake.fail = lambda path: RuntimeError("down " + path)
        r = engine.home(profile())
        self.assertFalse(r.get("stale"))
        self.assertFalse(r["complete"])

    def test_day_rotation_does_not_drop_the_stale_copy(self):
        engine, fake, clock = self.make()
        engine.home(profile())
        clock.t += 86400                                         # другой день -> другой ключ кэша ответа
        fake.fail = lambda path: RuntimeError("down " + path)
        r = engine.home(profile())
        self.assertTrue(r.get("stale") or r["complete"] is False)


if __name__ == "__main__":
    unittest.main(verbosity=1)
