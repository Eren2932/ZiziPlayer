#!/usr/bin/env python3
"""Regression for the 2026-10-02 false failure: /catalog/reco/home returned 404.

Checks the exact paths/methods registered by the real catalog over the existing
project stub. The separate smoke_stage2.py is still mandatory and uses real ASGI.
"""
import ast
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import urllib.error

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import smoke_stage2 as smoke  # noqa: E402


class Contract(unittest.TestCase):
    def test_canonical_client_paths(self):
        self.assertEqual(smoke.RECO_POST_PATHS, ('/reco/home', '/reco/feed'))
        self.assertEqual(smoke.RECO_HEALTH_PATH, '/reco/health')

    def test_smoke_paths_exist_once_on_the_guarded_catalog_router(self):
        probe = '''
import json, sys
from pathlib import Path
root = Path(sys.argv[1])
sys.path[:0] = [str(root), str(root / 'tools' / '_stub')]
import zizi_catalog as catalog
print(json.dumps({'methods': catalog.router.methods,
                  'guarded': len(catalog.router.dependencies) == 1 and
                             catalog.router.dependencies[0].dependency is catalog.guard_dep,
                  'home': catalog.RECO_CONTRACT, 'feed': catalog.RECO_FEED}))
'''
        with tempfile.TemporaryDirectory(prefix='zizi-smoke-contract-') as tmp:
            result = subprocess.run([sys.executable, '-c', probe, str(HERE.parent)],
                                    env=smoke.smoke_environment(tmp), capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertTrue(data['guarded'])
        self.assertEqual((data['home'], data['feed']), (1, 1))
        for path in smoke.RECO_POST_PATHS:
            self.assertEqual(data['methods'].count(['POST', path]), 1, path)
            self.assertNotIn(['GET', path], data['methods'])
        self.assertEqual(data['methods'].count(['GET', smoke.RECO_HEALTH_PATH]), 1)
        self.assertFalse(any(path.startswith('/catalog/reco/') for _, path in data['methods']))

    def test_all_reco_status_probes_use_the_same_contract(self):
        tree = ast.parse(Path(smoke.__file__).read_text(encoding='utf-8'))
        statuses = set()
        for node in ast.walk(tree):
            if not isinstance(node, ast.For) or not isinstance(node.iter, ast.Name):
                continue
            if node.iter.id != 'RECO_POST_PATHS':
                continue
            for call in ast.walk(node):
                if isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == 'expect_status':
                    self.assertIsInstance(call.args[2], ast.Name)
                    self.assertEqual(call.args[2].id, 'path')
                    method = next((ast.literal_eval(k.value) for k in call.keywords if k.arg == 'method'), 'GET')
                    statuses.add((method, ast.literal_eval(call.args[3])))
        self.assertEqual(statuses, {('POST', 401), ('POST', 422), ('GET', 405)})

    def test_catalog_version_is_a_shape_not_a_fixed_release_number(self):
        for value in ('1.9-stage2', '1.15-smart-reco', '1.16-smart-reco', '1.15.1-smart-reco'):
            self.assertTrue(smoke.catalog_version_ok(value), value)
        for value in (None, 15, '', '1.15', 'garbage', '1.15 smart reco'):
            self.assertFalse(smoke.catalog_version_ok(value), value)

    def test_checks_cannot_be_disabled_by_python_optimization(self):
        tree = ast.parse(Path(smoke.__file__).read_text(encoding='utf-8'))
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))
        with self.assertRaisesRegex(AssertionError, 'not optional'):
            smoke.require(False, 'not optional')

    def test_http_probes_ignore_shell_proxies(self):
        tree = ast.parse(Path(smoke.__file__).read_text(encoding='utf-8'))
        handlers = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute) and node.func.attr == 'ProxyHandler']
        self.assertEqual(len(handlers), 1)
        self.assertEqual(ast.literal_eval(handlers[0].args[0]), {})
        self.assertFalse(any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                             and node.func.attr == 'urlopen' for node in ast.walk(tree)))


class Isolation(unittest.TestCase):
    def test_production_environment_is_not_inherited(self):
        with mock.patch.dict(os.environ, {
            'ZIZI_TOKEN': 'fixture-production-value', 'ZIZI_RECO_DB': '/opt/zizi/production.db',
            'ZIZI_OUTBOUND_PROXY': 'http://fixture.invalid', 'HTTP_PROXY': 'http://fixture.invalid',
            'HTTPS_PROXY': 'http://fixture.invalid', 'PYTHONPATH': '/fixture/pythonpath',
        }):
            env = smoke.smoke_environment('/tmp/isolated-smoke')
        self.assertEqual(env['ZIZI_TOKEN'], 'smoke-test-not-a-secret')
        for key in ('ZIZI_OUTBOUND_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'PYTHONPATH'):
            self.assertNotIn(key, env)
        self.assertFalse(any(key.startswith(('DST_', 'DSEC_')) for key in env))

    def test_every_state_path_is_under_the_temporary_directory(self):
        root = Path('/tmp/isolated-smoke')
        env = smoke.smoke_environment(root)
        for key in ('ZIZI_CATALOG_DB', 'ZIZI_RECO_DB', 'ZIZI_EXTRA_DB', 'ZIZI_IMG_DIR',
                    'ZIZI_AUDIO_DIR', 'ZIZI_CACHE_FILE'):
            self.assertEqual(Path(env[key]).parent, root, key)
        self.assertEqual(env['HOME'], str(root))

    def test_auth_is_enforced_and_upstream_feature_is_disabled(self):
        env = smoke.smoke_environment('/tmp/isolated-smoke')
        self.assertEqual(env['ZIZI_DEVICE_MODE'], 'require')
        self.assertEqual(env['ZIZI_CATALOG_TOKEN_MODE'], 'require')
        self.assertEqual(env['ZIZI_EXTRA_ENABLED'], '0')
        self.assertEqual(env['ZIZI_PROXY_MODE'], 'off')


class HTTPChecks(unittest.TestCase):
    def test_expected_http_error_is_closed(self):
        body = io.BytesIO(b'{"detail":"unauthorized"}')
        error = urllib.error.HTTPError('http://127.0.0.1/reco/home', 401, 'fixture', {}, body)
        opener = mock.Mock()
        opener.open.side_effect = error
        smoke.expect_status(opener, 'http://127.0.0.1', '/reco/home', 401, method='POST', data=b'{}')
        self.assertTrue(body.closed)
        request = opener.open.call_args.args[0]
        self.assertEqual((request.full_url, request.method, request.data),
                         ('http://127.0.0.1/reco/home', 'POST', b'{}'))

    def test_the_original_404_is_a_hard_failure_with_path_and_status(self):
        opener = mock.Mock()
        opener.open.side_effect = urllib.error.HTTPError('http://127.0.0.1/reco/home', 404, 'fixture', {}, io.BytesIO())
        with self.assertRaisesRegex(AssertionError, 'POST /reco/home: expected HTTP 401, got 404'):
            smoke.expect_status(opener, 'http://127.0.0.1', '/reco/home', 401, method='POST', data=b'{}')

    def test_unexpected_success_does_not_hide_missing_auth(self):
        opener = mock.MagicMock()
        opener.open.return_value.__enter__.return_value.status = 200
        with self.assertRaisesRegex(AssertionError, 'expected HTTP 401, got 200'):
            smoke.expect_status(opener, 'http://127.0.0.1', '/reco/feed', 401, method='POST')

    def test_expected_success_closes_the_response(self):
        opener = mock.MagicMock()
        opener.open.return_value.__enter__.return_value.status = 200
        smoke.expect_status(opener, 'http://127.0.0.1', '/health', 200)
        opener.open.return_value.__exit__.assert_called_once()

    def test_json_fetch_closes_the_response(self):
        response = io.BytesIO(b'{"contract":1,"feed_contract":1}')
        opener = mock.Mock()
        opener.open.return_value = response
        self.assertEqual(smoke.fetch_json(opener, 'http://127.0.0.1', '/reco/health'),
                         {'contract': 1, 'feed_contract': 1})
        self.assertTrue(response.closed)


class LifecycleAndLogs(unittest.TestCase):
    def test_running_child_is_terminated_and_reaped(self):
        child = mock.Mock()
        child.poll.return_value = None
        smoke.stop_child(child)
        child.terminate.assert_called_once()
        child.wait.assert_called_once_with(5)
        child.kill.assert_not_called()

    def test_exited_child_is_only_reaped(self):
        child = mock.Mock()
        child.poll.return_value = 1
        smoke.stop_child(child)
        child.terminate.assert_not_called()
        child.wait.assert_called_once_with(5)

    def test_hung_child_is_killed_and_reaped(self):
        child = mock.Mock()
        child.poll.return_value = None
        child.wait.side_effect = [subprocess.TimeoutExpired('uvicorn', 5), 0]
        smoke.stop_child(child)
        child.kill.assert_called_once()
        self.assertEqual(child.wait.call_count, 2)

    def test_diagnostic_log_tail_is_bounded_and_does_not_move_the_shared_offset(self):
        data = b'old-log\n' * 2000 + b'ModuleNotFoundError: fixture_dependency\n'
        with tempfile.TemporaryFile() as log:
            log.write(data)
            before = log.tell()
            tail = smoke.log_tail(log)
            self.assertEqual(log.tell(), before)
        self.assertEqual(tail.encode(), data[-smoke.LOG_TAIL_BYTES:])
        self.assertIn('ModuleNotFoundError: fixture_dependency', tail)

    def test_non_utf8_logs_do_not_mask_the_failure(self):
        with tempfile.TemporaryFile() as log:
            log.write(b'fixture\xfffailure')
            self.assertIn('failure', smoke.log_tail(log))


if __name__ == '__main__':
    unittest.main(verbosity=1)
