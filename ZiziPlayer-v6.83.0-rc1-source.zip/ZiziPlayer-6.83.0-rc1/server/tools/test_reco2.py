#!/usr/bin/env python3
"""Reco 2: offline real engine tests, no FastAPI/network claim."""
import sys
import unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'_stub'),str(HERE.parent),str(HERE)]
import zizi_reco as reco
from test_zizi_reco import dz_track, NOW
from fastapi import APIRouter, HTTPException

class Onboard(unittest.TestCase):
    def make(self):
        calls=[]
        def fake(path,**params):
            calls.append(path)
            if path.endswith('/related'):
                return {'data':[{'id':100,'name':'Seed','picture_big':'https://img/a'},
                                {'id':101,'name':'Related','picture_big':'https://img/b'}]}
            lane=path.split('/')[1]
            return {'data':[{'id':int(lane or 0)*100+i+1000,'name':lane+' artist '+str(i),
                            'picture_big':'https://img/'+lane+'/'+str(i)} for i in range(3)]}
        return reco.Engine(reco.Upstream(fake, None), dz_track), calls

    def test_invalid_ids_are_rejected_without_upstream(self):
        e,calls=self.make()
        for bad in ('../secrets','x','１２','1/2','1'*13):
            with self.assertRaises(HTTPException) as x: e.onboard(bad)
            self.assertEqual(x.exception.status_code,422)
        self.assertEqual(calls,[])

    def test_genres_are_interleaved_deduped_and_cached(self):
        e,calls=self.make()
        result=e.onboard()
        self.assertEqual(result['contract'],1)
        artists=result['artists']
        self.assertGreater(len(artists),16)
        self.assertEqual(len({a['id'] for a in artists}),len(artists))
        self.assertGreater(len({a['genre'] for a in artists[:8]}),5)
        before=len(calls)
        self.assertEqual(e.onboard(),result)
        self.assertEqual(len(calls),before)

    def test_related_excludes_the_selected_artist(self):
        e,_=self.make()
        self.assertEqual([a['id'] for a in e.onboard('100')['artists']],['101'])

    def test_onboard_inherits_guard_and_is_get(self):
        r=APIRouter(dependencies=['guard'])
        reco.install_routes(r,lambda *a,**kw:{'data':[]},dz_track)
        self.assertIn(('GET','/reco/onboard'),r.methods)
        self.assertEqual(r.dependencies,['guard'])
        fn=next(f for p,f,_ in r.routes if p=='/reco/onboard')
        self.assertEqual(fn()['artists'],[])

    def test_forty_negatives_and_thirty_seeds_are_understood(self):
        p=reco.profile_from_body({'s':'|'.join(str(i)+'~1' for i in range(1,9)),
                                 's2':'|'.join(str(i)+'~.5' for i in range(9,31)),
                                 'x':'|'.join(str(i) for i in range(200,240))})
        self.assertEqual(len(p.seeds),30)
        self.assertEqual(len(p.neg_ids),40)

    def test_sparse_graph_does_not_produce_nan(self):
        self.assertGreaterEqual(reco.fit_of(0,reco.scene_of([])),0)
        self.assertLessEqual(reco.fit_of(0,reco.scene_of([])),1)

if __name__=='__main__': unittest.main(verbosity=2)
