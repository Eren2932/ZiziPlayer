#!/usr/bin/env python3
"""Usage: python measure_screenshots.py <directory-containing-original-jpgs>.
Requires Pillow, numpy, opencv-python. Analysis only, not part of Android/CI.
Chroma component bounds are threshold-dependent, NOT exact layout bounds.
"""
from pathlib import Path
import hashlib,json,sys
from PIL import Image
import numpy as np
import cv2

def measure(path,edge_windows):
 raw=path.read_bytes(); image=Image.open(path).convert('RGB'); a=np.asarray(image).astype(int)
 red=((a[:,:,0]>70)&(a[:,:,0]>1.5*a[:,:,1])&(a[:,:,0]>1.5*a[:,:,2])).astype('uint8')
 _,_,stats,_=cv2.connectedComponentsWithStats(red,8)
 components=[s.tolist() for s in stats[1:] if s[4]>100000]
 white=(np.min(a,axis=2)>215).astype('uint8');white[:1700]=0
 _,_,stats,_=cv2.connectedComponentsWithStats(white,8)
 buttons=[s.tolist() for s in stats[1:] if s[4]>2000]
 stripe=np.median(a[:,350:730],axis=1)
 gradient=np.linalg.norm(np.diff(stripe,axis=0),axis=1)
 transitions=[max(range(lo,hi+1),key=lambda y:gradient[y-1]) for lo,hi in edge_windows]
 return {'file':path.name,'sha256':hashlib.sha256(raw).hexdigest(),'size_px':list(image.size),
         'red_component_xywh_area':components,'white_button_xywh_area':buttons,
         'strongest_center_stripe_edge_y':transitions,
         'strong_edge_height_px':transitions[1]-transitions[0]}

if __name__=='__main__':
 folder=Path(sys.argv[1])
 result={'method':'RGB chroma connected components and median-stripe edge magnitude; original JPEGs, no resizing',
         'boundary_uncertainty_px':2,
         'reference':measure(folder/'Screenshot_20261002_063729.jpg',[(1052,1062),(2104,2112)]),
         'zizi_6_80_0':measure(folder/'Screenshot_20261002_063746.jpg',[(1196,1206),(2350,2360)]),
         'selected_nominal_reference':{'screen_width':1080,'card_width':990,'card_height':1052,
                                       'visible_button_top_relative_to_card':890,'visible_button_height':92,'bottom':70},
         'note':'1052 is the chosen layout target within JPEG edge uncertainty, not a claimed exact measured Android result.'}
 print(json.dumps(result,indent=2,ensure_ascii=False))
