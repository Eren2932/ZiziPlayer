#!/usr/bin/env python3
"""Run registered scripts in batches: python verification/v6.81.0/run_local_suites.py 0 40 (then 40 80, 80 110)."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import ast, subprocess, time, json, sys
root=Path(__file__).resolve().parents[2]
out=root/'verification/v6.81.0'; out.mkdir(parents=True,exist_ok=True)
source=ast.parse((root/'tools/check_selftest.py').read_text())
names=sorted({n.value for n in ast.walk(source) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('test_') and n.value.endswith('.py')})
suites=[]
for name in names:
 paths=[p for p in [root/'tools'/name,root/'server/tools'/name] if p.exists()]
 if len(paths)!=1: raise ValueError((name,paths))
 suites.append(str(paths[0].relative_to(root)))
(out/'suites.json').write_text(json.dumps(suites,indent=2)+'\n')
start=int(sys.argv[1]);end=int(sys.argv[2]);results=[]
def run(rel):
 t=time.monotonic()
 try:
  result=subprocess.run([sys.executable,rel],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=80)
  content=result.stdout;code=result.returncode
 except subprocess.TimeoutExpired as e:
  content=(e.stdout or b'')+b'\nTIMEOUT after 80s\n';code=124
 (out/(Path(rel).stem+'.log')).write_bytes(content)
 return {'suite':rel,'exit_code':code,'seconds':round(time.monotonic()-t,3)}
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(run,s) for s in suites[start:end]]):
  r=f.result();results.append(r)
  print(r,flush=True)
(out/f'batch-{start}-{end}.json').write_text(json.dumps(sorted(results,key=lambda x:x['suite']),indent=2)+'\n')
print('BATCH',len(results),'PASS',sum(r['exit_code']==0 for r in results),'TOTAL SUITES',len(suites))
sys.exit(any(r['exit_code']!=0 for r in results))
