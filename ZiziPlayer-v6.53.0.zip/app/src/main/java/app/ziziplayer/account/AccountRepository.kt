package app.ziziplayer.account

import android.content.Context
import app.ziziplayer.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class AccountApiException(val status: Int, val reason: String) : IOException(reason)

/** No shared catalog client/interceptors/WebView/cookies. No redirects or implicit POST retry.
 * One process-wide lane serializes cookie rotation, restore, login and logout. Access stays in RAM.
 */
class AccountRepository private constructor(context: Context) {
    private val origin = AccountGate.normalizeServiceUrl(BuildConfig.ACCOUNT_URL)
    private val vault = AccountSessionVault(context.applicationContext, origin)
    private val lane = Mutex()
    private val http = OkHttpClient.Builder()
        .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false)
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS).build()
    private var loaded = false
    private var access: Cookie? = null
    private var refresh: Cookie? = null

    private fun load() {
        if (loaded) return
        loaded = true
        if (origin.isEmpty()) return
        val raw = vault.read() ?: return
        refresh = Cookie.parse(origin.toHttpUrl(), raw)?.takeIf { allowed(it, REFRESH) }
        if (refresh == null) vault.clear()
    }

    private fun allowed(cookie: Cookie, name: String): Boolean =
        cookie.name == name && cookie.secure && cookie.httpOnly && cookie.hostOnly &&
            cookie.path == "/" && cookie.domain == origin.toHttpUrl().host &&
            cookie.expiresAt > System.currentTimeMillis()

    private fun clear() { access = null; refresh = null; vault.clear() }

    /** No coroutine cancellation between a successful rotation and durable cookie replacement.
     * A lost response is NOT retried: next restore may require a fresh login (fail closed).
     */
    private suspend fun <T> serial(action: () -> T): T = lane.withLock {
        withContext(Dispatchers.IO + NonCancellable) { load(); action() }
    }

    private fun request(path: String, data: JSONObject? = null): JSONObject {
        if (origin.isEmpty()) throw AccountApiException(503, "not_configured")
        val url = (origin + path).toHttpUrl()
        val request = Request.Builder().url(url).header("Accept", "application/json")
        if (data != null) request.header("X-Zizi-Account", "1")
            .post(data.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        val selected = if (path in setOf("/auth/refresh", "/auth/logout", "/auth/logout-all")) refresh else access
        if (selected != null && selected.matches(url) && selected.expiresAt > System.currentTimeMillis()) {
            request.header("Cookie", selected.name + "=" + selected.value)
        }
        http.newCall(request.build()).execute().use { response ->
            val body = response.body ?: throw IOException("Empty account response")
            val limit = if (path == "/auth/library") 9L * 1024 * 1024 else 32768L
            if (body.contentLength() > limit) throw IOException("Account response too large")
            val source = body.source()
            source.request(limit + 1)
            if (source.buffer.size > limit) throw IOException("Account response too large")
            val json = try { JSONObject(source.readUtf8()) } catch (_: Exception) {
                throw IOException("Invalid account response")
            }
            if (!response.isSuccessful) {
                if (response.code == 401 && path == "/auth/refresh") clear()
                throw AccountApiException(response.code, json.optString("error", "request_failed"))
            }
            if (path in setOf("/auth/login", "/auth/refresh", "/auth/google")) {
                val raw = response.headers.values("Set-Cookie")
                fun extract(name: String): Cookie {
                    val matching = raw.filter { it.substringBefore('=').trim() == name }
                    if (matching.size != 1 || !Regex("(?i)(?:^|;)\\s*SameSite=Strict\\s*(?:;|$)").containsMatchIn(matching.single())) {
                        throw IOException("Unsafe account cookie")
                    }
                    return Cookie.parse(url, matching.single())?.takeIf { allowed(it, name) }
                        ?: throw IOException("Invalid account cookie")
                }
                val nextAccess = extract(ACCESS)
                val nextRefresh = extract(REFRESH)
                try {
                    vault.write(nextRefresh.toString())
                    refresh = nextRefresh
                    access = nextAccess
                } catch (error: Exception) {
                    clear()
                    throw IOException("Cannot protect account session", error)
                }
            }
            return json
        }
    }

    suspend fun submit(action: String, email: String, password: String, code: String): JSONObject = serial {
        require(action in setOf("register", "login", "resend", "forgot", "verify", "reset"))
        val data = JSONObject()
        if (action in setOf("register", "login", "resend", "forgot")) data.put("email", email.trim())
        if (action in setOf("register", "login", "reset")) data.put("password", password)
        if (action in setOf("verify", "reset")) data.put("code", code.trim())
        request("/auth/" + action, data)
    }

    suspend fun restore(): JSONObject? = serial {
        if (origin.isEmpty() || refresh == null) return@serial null
        try {
            if (access == null || access!!.expiresAt <= System.currentTimeMillis()) {
                request("/auth/refresh", JSONObject())
            } else {
                try { request("/auth/me") } catch (error: AccountApiException) {
                    if (error.status != 401) throw error
                    request("/auth/refresh", JSONObject())
                }
            }
        } catch (error: AccountApiException) {
            if (error.status == 401) { clear(); null } else throw error
        }
    }

    /** Same lane as login/logout: a library request can never silently switch account midway. */
    private fun libraryIdentity(expectedUid: String) {
        require(expectedUid.isNotBlank())
        val user = try { request("/auth/me") } catch (error: AccountApiException) {
            if (error.status != 401 || refresh == null) throw error
            request("/auth/refresh", JSONObject())
        }
        if (user.getString("id") != expectedUid) throw AccountApiException(409, "account_changed")
    }

    suspend fun libraryGet(expectedUid: String): JSONObject = serial {
        libraryIdentity(expectedUid)
        request("/auth/library")
    }

    suspend fun librarySave(expectedUid: String, revision: Long, document: JSONObject): JSONObject = serial {
        libraryIdentity(expectedUid)
        request("/auth/library", JSONObject().put("expected_revision", revision.toString())
            .put("document", document.toString()))
    }

    suspend fun capabilities(): JSONObject = serial { request("/auth/health") }

    suspend fun googleChallenge(): JSONObject = serial { request("/auth/google/challenge", JSONObject()) }

    suspend fun googleLogin(challenge: String, token: String): JSONObject = serial {
        request("/auth/google", JSONObject().put("challenge", challenge).put("id_token", token))
    }

    /** Local logout always succeeds. false explicitly means server revocation was not confirmed. */
    suspend fun signOut(allSessions: Boolean = false): Boolean = serial {
        try {
            if (allSessions && refresh == null) return@serial false
            if (refresh != null) request(if (allSessions) "/auth/logout-all" else "/auth/logout", JSONObject())
            true
        } catch (_: IOException) { false } finally { clear() }
    }

    companion object {
        private const val ACCESS = "__Host-zizi_access"
        private const val REFRESH = "__Host-zizi_refresh"
        @Volatile private var instance: AccountRepository? = null
        fun get(context: Context): AccountRepository = instance ?: synchronized(this) {
            instance ?: AccountRepository(context.applicationContext).also { instance = it }
        }
    }
}
