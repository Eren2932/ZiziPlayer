package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

/**
 * 6.50.0 — экран аккаунта.
 *
 * ЧТО ЭТОТ ЭКРАН ОБЯЗАН ГОВОРИТЬ ПРАВДУ О
 *
 * Состояние хранения. Человек приходит сюда с одним вопросом: «моя медиатека в безопасности?» —
 * и ответ должен быть однозначным. Поэтому здесь нет слов «синхронизировано» и «сохранено в
 * облаке» до того, как сервер это подтвердил. Гость видит прямым текстом, что данные только на
 * телефоне и что очистка данных приложения их удалит.
 *
 * ПОЧЕМУ ВХОД МОЖЕТ БЫТЬ НЕДОСТУПЕН
 *
 * Адрес сервиса аккаунтов задаётся при сборке (BuildConfig.ACCOUNT_URL) и проверяется
 * [app.ziziplayer.account.AccountGate.normalizeServiceUrl]: только https, только непустой хост.
 * Пока адреса нет, экран честно показывает «готовится» и объясняет, что это значит, вместо
 * неработающей кнопки.
 */
@Composable
fun AccountScreen(
    state: AccountLocalState,
    signInOffered: Boolean,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onSignOutAll: () -> Unit,
    onClose: () -> Unit,
    onOpenLibrary: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(ZiziIcons.ArrowBack, contentDescription = "Назад", tint = p.text)
            }
            Spacer(Modifier.width(4.dp))
            Text("Аккаунт", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // Шапка состояния: кто вошёл или что мы гость. Без домыслов о синхронизации.
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.chip.copy(alpha = 0.38f))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(ZiziIcons.Person, contentDescription = null, tint = p.accent, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (state.isGuest) "Гостевой режим" else state.displayName ?: "Аккаунт ZiziPlayer",
                        color = p.text,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (state.isGuest) "Медиатека хранится только на этом телефоне"
                        else "Вход выполнен",
                        color = p.subtext,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(22.dp))
            AccountSectionTitle("Состояние хранения")

            AccountFact(
                icon = ZiziIcons.Phone,
                title = "Библиотека на телефоне и в аккаунте",
                text = "Сохранённые треки каталога, избранное, плейлисты и история могут восстанавливаться после переустановки. Сначала подключите облачную библиотеку."
            )
            AccountButton("Библиотека и облачное сохранение", primary = true, onClick = onOpenLibrary)
            Spacer(Modifier.height(10.dp))
            Text("Статус и дату сохранения проверяйте на экране библиотеки. Сам вход ещё не означает, что данные отправлены.", color = p.subtext, fontSize = 12.5.sp)

            Spacer(Modifier.height(18.dp))
            AccountSectionTitle("Вход")

            if (signInOffered) {
                if (state.isGuest) {
                    AccountButton("Войти в аккаунт", primary = true, onClick = onSignIn)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "После входа подключите библиотеку. До подтверждения сохранения данные остаются только на телефоне.",
                        color = p.subtext,
                        fontSize = 12.5.sp
                    )
                } else {
                    AccountButton("Выйти на этом устройстве", primary = false, onClick = onSignOut)
                    Spacer(Modifier.height(10.dp))
                    AccountButton("Выйти на всех устройствах", primary = false, onClick = onSignOutAll)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Выход не удаляет музыку и плейлисты с телефона.",
                        color = p.subtext,
                        fontSize = 12.5.sp
                    )
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(p.chip.copy(alpha = 0.3f))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(ZiziIcons.Hourglass, contentDescription = null, tint = p.subtext, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Вход готовится", color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "Сервис аккаунтов ещё не подключён к этой сборке, поэтому кнопки входа здесь нет. " +
                                "Для входа нужна новая сборка с настроенным HTTPS-адресом сервиса.",
                            color = p.subtext,
                            fontSize = 12.5.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(28.dp))
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
private fun AccountSectionTitle(text: String) {
    val p = LocalPalette.current
    Text(
        text.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
    )
}

@Composable
private fun AccountFact(icon: ImageVector, title: String, text: String) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(3.dp))
            Text(text, color = p.subtext, fontSize = 12.5.sp)
        }
    }
}

@Composable
private fun AccountButton(label: String, primary: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (primary) p.brand else p.chip.copy(alpha = 0.55f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (primary) p.onBrand else p.text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
