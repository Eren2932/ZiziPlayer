#!/usr/bin/env python3
"""Fail-closed source update. Never touches env, SMTP settings, keys, service or database.
Run --check first. --apply stages all sources, backs up existing ones, then replaces atomically
per file. Stop the service before --apply; start it only after all files are installed.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
import tempfile
import time

BASELINE = {'core.py': 'a3768376680e520cf74048da368fd96116bce9e99ea00737592e2cf391d6faa0', 'web.py': '45dfc2c6a662e42e77ecfefb4d3da5545ea2d1d3722fb4ea292c837201a0f5c4'}
FILES = ('core.py','web.py','library.py')

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def install(target, apply=False):
    target=Path(target).resolve()
    payload=Path(__file__).resolve().parent
    if target == payload: raise ValueError('Refusing to install over the release payload')
    if not target.is_dir(): raise ValueError('Target directory does not exist')
    for name in FILES:
        if not (payload/name).is_file(): raise ValueError('Incomplete release: '+name)
        current=target/name
        if current.is_symlink(): raise ValueError('Refusing symlink: '+name)
        if current.exists():
            allowed={digest(payload/name)}
            if name in BASELINE: allowed.add(BASELINE[name])
            if digest(current) not in allowed:
                raise ValueError('Modified live file: '+name+'. Refusing to overwrite; preserve live SMTP/custom fixes and merge manually.')
        elif name in BASELINE: raise ValueError('Required live file missing: '+name)
    if not apply:
        print('Preflight OK. env, keys, SMTP settings and database will not be modified.')
        return
    backup=Path(tempfile.mkdtemp(prefix='accounts-before-1.1-',dir=target.parent))
    existed=[]
    for name in FILES:
        if (target/name).exists(): shutil.copy2(target/name,backup/name);existed.append(name)
    replaced=[]
    try:
        for name in FILES:
            staged=target/(name+'.library-update-tmp')
            # Exclusive creation refuses stale/symlink temp files.
            with staged.open('xb') as stream: stream.write((payload/name).read_bytes())
            staged.chmod(0o644)
            staged.replace(target/name);replaced.append(name)
    except BaseException:
        for name in reversed(replaced):
            if name in existed: shutil.copy2(backup/name,target/name)
            else: (target/name).unlink()
        raise
    print('Sources installed. Backup: '+str(backup))
    print('Start the accounts service, then verify /auth/health: version 1.1.0, sync_enabled true.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target',required=True)
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true');mode.add_argument('--apply',action='store_true')
    args=p.parse_args()
    try: install(args.target,args.apply)
    except (ValueError,OSError) as error: p.exit(1,str(error)+'\n')
if __name__=='__main__':main()
