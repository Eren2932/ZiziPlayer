"""Zizi accounts 1.0: isolated from catalog/device tokens and Android media DB.
RS256 only, cryptography primitives, transactional SQLite session families.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from urllib.parse import urlsplit
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

ACCESS_SECONDS = 15 * 60
REFRESH_SECONDS = 7 * 24 * 60 * 60
MAIL_SECONDS = 30 * 60
PERMISSIONS = {'user': frozenset({'profile:read', 'sessions:revoke'}),
               'admin': frozenset({'profile:read', 'sessions:revoke', 'service:inspect'})}

class AuthError(Exception):
    def __init__(self, code='unauthorized', status=401):
        super().__init__(code)
        self.code, self.status = code, status


def origin(value):
    u = urlsplit(value)
    if (u.scheme != 'https' or not u.hostname or u.username or u.password
            or u.path not in ('', '/') or u.query or u.fragment or u.port not in (None, 443)
            or not re.fullmatch(r'[A-Za-z0-9.-]+',u.hostname)
            or any(ord(c) <= 32 or ord(c) > 126 for c in value)):
        raise ValueError('Public origin must be an HTTPS origin on port 443')
    return 'https://' + u.hostname.lower()


def b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')


def unb64(value):
    if not isinstance(value, str) or not re.fullmatch('[A-Za-z0-9_-]+', value):
        raise ValueError('Invalid base64url')
    raw = base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
    if b64(raw) != value:
        raise ValueError('Noncanonical base64url')
    return raw


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def email_address(value):
    if not isinstance(value, str):
        raise AuthError('invalid_email', 400)
    value = value.strip().lower()
    # Deliberately modest ASCII contract. No Gmail dot/plus rewriting.
    if len(value) > 254 or not re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?\.[a-z]{2,63}", value):
        raise AuthError('invalid_email', 400)
    if '..' in value or value.startswith('.') or '.@' in value:
        raise AuthError('invalid_email', 400)
    return value


def password_valid(value):
    if not isinstance(value, str) or not 12 <= len(value) <= 128:
        raise AuthError('password_length', 400)
    return value


class Passwords:
    """32 MiB per hash; at most one KDF per process on the 1-core VPS."""
    def __init__(self):
        self.slot = threading.BoundedSemaphore(1)
        self.dummy = self.hash(secrets.token_urlsafe(32))

    def derive(self, value, salt):
        if not self.slot.acquire(blocking=False):
            raise AuthError('busy', 429)
        try:
            return hashlib.scrypt(value.encode('utf-8'), salt=salt, n=32768, r=8, p=1,
                                  maxmem=64 * 1024 * 1024, dklen=32)
        finally:
            self.slot.release()

    def hash(self, value):
        salt = secrets.token_bytes(16)
        return 'scrypt-v1$' + b64(salt) + '$' + b64(self.derive(value, salt))

    def verify(self, value, stored):
        target = stored or self.dummy
        try:
            version, salt, expected = target.split('$')
            if version != 'scrypt-v1':
                return False
            match = hmac.compare_digest(self.derive(value, unb64(salt)), unb64(expected))
            return bool(stored) and match
        except ValueError:
            return False


class Tokens:
    """Narrow JWT profile: no alg negotiation, URLs, embedded keys or header trust.
    Public key can be SubjectPublicKeyInfo PEM or X.509 certificate PEM.
    Certificate is a local key container, not a substitute for the HTTPS certificate.
    """
    def __init__(self, private_pem, public_pem, issuer, clock=time.time):
        self.private = serialization.load_pem_private_key(private_pem, password=None)
        self.public = (x509.load_pem_x509_certificate(public_pem).public_key()
                       if b'BEGIN CERTIFICATE' in public_pem
                       else serialization.load_pem_public_key(public_pem))
        if not isinstance(self.private, rsa.RSAPrivateKey) or not isinstance(self.public, rsa.RSAPublicKey):
            raise ValueError('RSA keys required')
        if self.private.key_size < 2048 or self.private.public_key().public_numbers() != self.public.public_numbers():
            raise ValueError('RSA keys must match and be at least 2048 bits')
        self.issuer, self.clock = origin(issuer), clock
        self.kid = digest(b64(self.public.public_bytes(serialization.Encoding.DER,
                                  serialization.PublicFormat.SubjectPublicKeyInfo)))[:16]

    def issue(self, kind, uid, sid, expiry):
        now = int(self.clock())
        claims = dict(iss=self.issuer, aud='zizi-accounts', sub=uid, sid=sid,
                      jti=uuid.uuid4().hex, iat=now, nbf=now, exp=expiry, token_use=kind)
        header = dict(alg='RS256', typ='JWT', kid=self.kid)
        data = '.'.join(b64(json.dumps(x, separators=(',', ':'), sort_keys=True).encode())
                        for x in (header, claims))
        return data + '.' + b64(self.private.sign(data.encode('ascii'), padding.PKCS1v15(), hashes.SHA256()))

    def verify(self, token, kind):
        try:
            if not isinstance(token, str) or len(token) > 4096:
                raise ValueError()
            h, p, sig = token.split('.')
            header = json.loads(unb64(h))
            if header != dict(alg='RS256', typ='JWT', kid=self.kid):
                raise ValueError()
            self.public.verify(unb64(sig), (h + '.' + p).encode('ascii'), padding.PKCS1v15(), hashes.SHA256())
            c = json.loads(unb64(p))
            now = int(self.clock())
            if (not isinstance(c, dict) or c.get('iss') != self.issuer
                    or c.get('aud') != 'zizi-accounts' or c.get('token_use') != kind
                    or any(type(c.get(k)) is not int for k in ('iat', 'nbf', 'exp'))
                    or not (c['iat'] == c['nbf'] <= now < c['exp'])
                    or c['exp'] - c['iat'] > (ACCESS_SECONDS if kind == 'access' else REFRESH_SECONDS)
                    or any(not isinstance(c.get(k), str) or not re.fullmatch('[a-f0-9]{32}', c[k])
                           for k in ('sub', 'sid', 'jti'))):
                raise ValueError()
            return c
        except (ValueError, TypeError, KeyError, InvalidSignature, UnicodeError, RecursionError):
            raise AuthError() from None


SCHEMA = '''
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, password TEXT,
 verified INTEGER NOT NULL DEFAULT 0, role TEXT NOT NULL DEFAULT 'user'
 CHECK(role IN ('user','admin')), disabled INTEGER NOT NULL DEFAULT 0,
 google_sub TEXT UNIQUE, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
 id TEXT PRIMARY KEY, uid TEXT NOT NULL REFERENCES users(id),
 current_hash TEXT NOT NULL UNIQUE, expires INTEGER NOT NULL,
 revoked INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS sessions_uid ON sessions(uid);
CREATE TABLE IF NOT EXISTS spent_refresh(
 hash TEXT PRIMARY KEY, sid TEXT NOT NULL REFERENCES sessions(id));
CREATE TABLE IF NOT EXISTS tickets(
 hash TEXT PRIMARY KEY, uid TEXT NOT NULL REFERENCES users(id),
 purpose TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS challenges(
 id TEXT PRIMARY KEY, nonce TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS library_snapshots(
 uid TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 revision INTEGER NOT NULL, document TEXT NOT NULL, digest TEXT NOT NULL,
 saved_at INTEGER NOT NULL, PRIMARY KEY(uid,revision));
CREATE TABLE IF NOT EXISTS limits(
 key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS limits_expires ON limits(expires);
CREATE INDEX IF NOT EXISTS tickets_expires ON tickets(expires);
CREATE INDEX IF NOT EXISTS tickets_user_purpose ON tickets(uid,purpose);
CREATE INDEX IF NOT EXISTS challenges_expires ON challenges(expires);
CREATE INDEX IF NOT EXISTS sessions_expires ON sessions(expires);
CREATE INDEX IF NOT EXISTS spent_refresh_sid ON spent_refresh(sid);
'''


class Accounts:
    def __init__(self, db, tokens, clock=time.time):
        self.db, self.tokens, self.clock = str(db), tokens, clock
        with self.connection() as c:
            c.executescript(SCHEMA)
        self.passwords = Passwords()

    @contextmanager
    def connection(self):
        c = sqlite3.connect(self.db, timeout=5, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON')
        try:
            yield c
        finally:
            c.close()

    @contextmanager
    def transaction(self):
        with self.connection() as c:
            c.execute('BEGIN IMMEDIATE')
            try:
                yield c
                c.commit()
            except BaseException:
                c.rollback()
                raise

    def now(self):
        return int(self.clock())

    def rate(self, key, maximum=10, window=600):
        # Values hashed: no raw email/IP in the limiter DB. Fixed-window boundary burst documented.
        key = digest(key)
        with self.transaction() as c:
            c.execute('DELETE FROM limits WHERE expires<=?', (self.now(),))
            row = c.execute('SELECT count FROM limits WHERE key=?', (key,)).fetchone()
            if row and row['count'] >= maximum:
                raise AuthError('rate_limited', 429)
            c.execute('INSERT INTO limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1',
                      (key, self.now() + window))

    def ticket(self, c, uid, purpose):
        value = secrets.token_urlsafe(32)
        c.execute('DELETE FROM tickets WHERE uid=? AND purpose=?', (uid, purpose))
        c.execute('INSERT INTO tickets VALUES(?,?,?,?)', (digest(value), uid, purpose, self.now()+MAIL_SECONDS))
        return value

    def register(self, email, password):
        email, password = email_address(email), password_valid(password)
        hashed = self.passwords.hash(password)
        with self.transaction() as c:
            if c.execute('SELECT 1 FROM users WHERE email=?', (email,)).fetchone():
                return None  # Same public response, never overwrite an existing registration.
            uid = uuid.uuid4().hex
            c.execute('INSERT INTO users(id,email,password,created) VALUES(?,?,?,?)', (uid,email,hashed,self.now()))
            return self.ticket(c, uid, 'verify')

    def request_ticket(self, email, purpose):
        email = email_address(email)
        if purpose not in ('verify', 'reset'):
            raise AuthError('bad_request', 400)
        with self.transaction() as c:
            u = c.execute('SELECT * FROM users WHERE email=? AND disabled=0', (email,)).fetchone()
            if not u or (purpose == 'verify' and u['verified']) or (purpose == 'reset' and not u['verified']):
                return None
            return self.ticket(c, u['id'], purpose)

    def redeem(self, token, purpose, password=None):
        if not isinstance(token, str) or not 20 <= len(token) <= 100:
            raise AuthError('invalid_code', 400)
        hashed = self.passwords.hash(password_valid(password)) if purpose == 'reset' else None
        with self.transaction() as c:
            t = c.execute('SELECT * FROM tickets WHERE hash=? AND purpose=? AND expires>?',
                          (digest(token),purpose,self.now())).fetchone()
            if not t:
                raise AuthError('invalid_code',400)
            c.execute('DELETE FROM tickets WHERE uid=?', (t['uid'],))
            if purpose == 'verify':
                c.execute('UPDATE users SET verified=1 WHERE id=?', (t['uid'],))
            elif purpose == 'reset':
                c.execute('UPDATE users SET password=? WHERE id=?', (hashed,t['uid']))
                c.execute('UPDATE sessions SET revoked=1 WHERE uid=?', (t['uid'],))
            else:
                raise AuthError('bad_request',400)

    def pair(self, c, uid, sid=None, expiry=None):
        sid, expiry = sid or uuid.uuid4().hex, expiry or self.now()+REFRESH_SECONDS
        access = self.tokens.issue('access', uid, sid, min(self.now()+ACCESS_SECONDS, expiry))
        refresh = self.tokens.issue('refresh', uid, sid, expiry)
        c.execute('INSERT INTO sessions(id,uid,current_hash,expires) VALUES(?,?,?,?) '
                  'ON CONFLICT(id) DO UPDATE SET current_hash=excluded.current_hash',
                  (sid,uid,digest(refresh),expiry))
        u = c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
        return dict(access=access, refresh=refresh, expires=expiry, user=self.profile(u))

    @staticmethod
    def profile(u):
        return dict(id=u['id'], email=u['email'], role=u['role'])

    def login(self, email, password):
        email, password = email_address(email), password_valid(password)
        with self.connection() as c:
            u = c.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
        if not self.passwords.verify(password, u['password'] if u else None) or not u or u['disabled']:
            raise AuthError('invalid_credentials')
        if not u['verified']:
            raise AuthError('email_not_verified', 403)
        with self.transaction() as c:
            # Prevent reset/disable races while KDF was running outside the transaction.
            live = c.execute('SELECT * FROM users WHERE id=?', (u['id'],)).fetchone()
            if live['password'] != u['password'] or live['disabled'] or not live['verified']:
                raise AuthError()
            # Bound each user's active sessions; most recent login displaces oldest.
            c.execute('UPDATE sessions SET revoked=1 WHERE id IN '
                      '(SELECT id FROM sessions WHERE uid=? AND revoked=0 ORDER BY expires DESC, rowid DESC LIMIT -1 OFFSET 9)',(u['id'],))
            return self.pair(c,u['id'])

    def refresh(self, token):
        claims = self.tokens.verify(token,'refresh')
        hashed, reused, result = digest(token), False, None
        with self.transaction() as c:
            s = c.execute('SELECT s.*,u.disabled FROM sessions s JOIN users u ON u.id=s.uid WHERE s.id=?',
                          (claims['sid'],)).fetchone()
            if not s or s['uid'] != claims['sub'] or s['revoked'] or s['disabled'] or s['expires'] <= self.now():
                raise AuthError()
            if not hmac.compare_digest(s['current_hash'], hashed):
                if c.execute('SELECT 1 FROM spent_refresh WHERE hash=? AND sid=?', (hashed,s['id'])).fetchone():
                    c.execute('UPDATE sessions SET revoked=1 WHERE id=?', (s['id'],))
                    reused = True  # Commit revocation BEFORE raising. No rollback of reuse detection.
                else:
                    raise AuthError()
            else:
                c.execute('INSERT INTO spent_refresh VALUES(?,?)', (hashed,s['id']))
                result = self.pair(c,s['uid'],s['id'],s['expires'])
        if reused:
            raise AuthError('session_reused')
        return result

    def authenticate(self, token, permission='profile:read'):
        claim = self.tokens.verify(token, 'access')
        with self.connection() as c:
            u = c.execute('SELECT u.* FROM users u JOIN sessions s ON s.uid=u.id '
                          'WHERE s.id=? AND u.id=? AND s.revoked=0 AND u.disabled=0 AND s.expires>?',
                          (claim['sid'],claim['sub'],self.now())).fetchone()
        if not u:
            raise AuthError()
        if permission not in PERMISSIONS.get(u['role'], frozenset()):
            raise AuthError('forbidden',403)
        return dict(user=self.profile(u),sid=claim['sid'])

    def logout(self, refresh, all_sessions=False):
        claims = self.tokens.verify(refresh,'refresh')
        with self.transaction() as c:
            # A spent signed token is also allowed to revoke ITS OWN family, but not other sessions.
            s = c.execute('SELECT * FROM sessions WHERE id=? AND uid=?', (claims['sid'],claims['sub'])).fetchone()
            if not s:
                raise AuthError()
            if all_sessions:
                if s['revoked'] or not hmac.compare_digest(s['current_hash'],digest(refresh)):
                    raise AuthError()
                c.execute('UPDATE sessions SET revoked=1 WHERE uid=?', (claims['sub'],))
            else:
                c.execute('UPDATE sessions SET revoked=1 WHERE id=?', (claims['sid'],))

    def challenge(self):
        cid, nonce = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        with self.transaction() as c:
            c.execute('DELETE FROM challenges WHERE expires<=?', (self.now(),))
            c.execute('INSERT INTO challenges VALUES(?,?,?)', (digest(cid),digest(nonce),self.now()+300))
        return dict(challenge=cid, nonce=nonce)

    def google_login(self, challenge, claims):
        """claims MUST come from the Google signature/audience verifier, never request JSON."""
        sub, nonce = claims.get('sub'), claims.get('nonce')
        if not isinstance(sub,str) or not 1 <= len(sub) <= 255 or not isinstance(nonce,str):
            raise AuthError()
        email = email_address(claims.get('email'))
        # No implicit email-based linking. External Google emails must use email/password
        # until a separate email-ownership/linking flow exists.
        if claims.get('email_verified') is not True or not (email.endswith('@gmail.com') or claims.get('hd')):
            raise AuthError('google_email_use_password',409)
        with self.transaction() as c:
            row = c.execute('SELECT * FROM challenges WHERE id=? AND expires>?', (digest(challenge),self.now())).fetchone()
            if not row or not hmac.compare_digest(row['nonce'],digest(nonce)):
                raise AuthError()
            c.execute('DELETE FROM challenges WHERE id=?', (digest(challenge),))
            u = c.execute('SELECT * FROM users WHERE google_sub=?', (sub,)).fetchone()
            if u:
                if u['disabled']:
                    raise AuthError()
                uid = u['id']
            else:
                if c.execute('SELECT 1 FROM users WHERE email=?', (email,)).fetchone():
                    raise AuthError('use_existing_sign_in',409)
                uid=uuid.uuid4().hex
                c.execute('INSERT INTO users(id,email,google_sub,verified,created) VALUES(?,?,?,1,?)',(uid,email,sub,self.now()))
            c.execute('UPDATE sessions SET revoked=1 WHERE id IN '
                      '(SELECT id FROM sessions WHERE uid=? AND revoked=0 ORDER BY expires DESC, rowid DESC LIMIT -1 OFFSET 9)',(uid,))
            return self.pair(c,uid)

    def prune(self):
        with self.transaction() as c:
            c.execute('DELETE FROM spent_refresh WHERE sid IN (SELECT id FROM sessions WHERE expires<=?)',(self.now(),))
            c.execute('DELETE FROM sessions WHERE expires<=?',(self.now(),))
            c.execute('DELETE FROM tickets WHERE expires<=?',(self.now(),))
            c.execute('DELETE FROM challenges WHERE expires<=?',(self.now(),))
            c.execute('DELETE FROM limits WHERE expires<=?',(self.now(),))
