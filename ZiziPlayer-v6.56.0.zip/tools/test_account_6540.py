"""Production Java failure mapping execution + Kotlin source wiring, NOT Android compilation."""
from pathlib import Path
import subprocess
import tempfile
import unittest
R=Path(__file__).resolve().parents[1]
S=R/'app/src/main/java/app/ziziplayer'
class Account6540(unittest.TestCase):
    def test_real_java_error_mapping(self):
        with tempfile.TemporaryDirectory() as d:
            check=Path(d)/'Check.java'
            check.write_text('''import app.ziziplayer.account.AccountProblem;
public class Check {
 static void check(boolean b) { if (!b) throw new AssertionError(); }
 public static void main(String[] args) {
   check(AccountProblem.library(413,"body_size").contains("17m"));
   check(AccountProblem.library(413,"library_too_large").contains("8 МиБ"));
   check(!AccountProblem.library(413,"library_too_large").contains("nginx"));
   check(AccountProblem.library(404,"not_found").contains("1.1"));
   check(AccountProblem.library(401,"expired").contains("Войдите"));
   check(AccountProblem.library(409,"conflict").contains("приостановлено"));
   for (int i=400;i<=599;i++) check(AccountProblem.retryable(i)==(i==429 || i>=500));
   check(!AccountProblem.library(500,"secret").contains("secret"));
   System.out.println("207 production Java assertions passed");
 }
}''')
            subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(S/'account/AccountProblem.java'),str(check)],check=True)
            subprocess.run(['java','-cp',d,'Check'],check=True)
    def test_status_before_json_and_extended_library_timeout(self):
        t=(S/'account/AccountRepository.kt').read_text()
        self.assertLess(t.index('if (!response.isSuccessful)'),t.index('JSONObject(source.readUtf8())'))
        for s in ('response.peekBody(4096)', 'callTimeout(90, TimeUnit.SECONDS)', 'writeTimeout(60, TimeUnit.SECONDS)', 'libraryIdentity(expectedUid)'):
            self.assertIn(s,t)
    def test_retry_after_failed_connect_and_manual_bypass(self):
        t=(S/'library/LibrarySync.kt').read_text()
        for s in ('retryConnect = true','elapsedRealtime() >= retryAfter', 'if (manual) retryAfter = 0L', 'api.capabilities()', 'sync_enabled', 'LibrarySnapshot.FORMAT'):
            self.assertIn(s,t)
        self.assertIn('sync.flush(manual = true)',(S/'ui/screens/LibraryStorageScreen.kt').read_text())
    def test_profile_is_confirmed_not_optimistic(self):
        t=(S/'account/AccountProfileStore.kt').read_text()
        self.assertIn('mutable.value = read(id, api.profileSave',t)
        self.assertIn('mutable.value.userId != id',t)
        self.assertNotIn('SharedPreferences',t)
        self.assertIn('rawProfile.takeIf { it.userId == account.userId }',(S/'MainActivity.kt').read_text())
    def test_edit_photo_and_back_discard(self):
        t=(S/'ui/screens/AccountEditScreen.kt').read_text()
        for s in ('ActivityResultContracts.OpenDocument()', 'AvatarImage.load', 'BackHandler { close() }', 'if (dirty) discard = true', 'fontFamily = ZiziFontFamily', 'profile.loaded'):
            self.assertIn(s,t)
        self.assertNotIn('rememberSaveable',t)
    def test_single_fullscreen_settings_entry_and_real_controls(self):
        main=(S/'MainActivity.kt').read_text();settings=(S/'ui/screens/Sheets.kt').read_text()
        for s in ('onOpenSettings = { accountSettings = true }', 'fullScreen = true', 'BackHandler(enabled = !profileEdit && !accountSettings)'):
            self.assertIn(s,main)
        for s in ('vm.setWifiOnly(!state.settings.wifiOnly)', 'vm.setStreamCacheEnabled(!state.settings.streamCacheEnabled)', 'BackHandler(enabled = fullScreen)', 'onText = { query = it; section = null }'):
            self.assertIn(s,settings)
    def test_avatar_geometry_and_account_scope(self):
        home=(S/'ui/screens/HomeScreen.kt').read_text();screen=(S/'ui/screens/AccountScreen.kt').read_text();edit=(S/'ui/screens/AccountEditScreen.kt').read_text()
        self.assertIn('if (!account.isGuest)',home);self.assertIn('(30.7f * accountScale()).dp',home)
        self.assertIn('(108*scale).dp',screen);self.assertIn('fillMaxWidth(AccountUiGeometry.DRAWER_FRACTION)',(S/'ui/components/AccountDrawerHost.kt').read_text());self.assertIn('DRAWER_FRACTION = 0.9f',(S/'ui/AccountUiGeometry.java').read_text());self.assertIn('(127*scale).dp',edit)
        for s in ('Premium','подписчиков','Spotify Connect'):
            self.assertNotIn(s,screen)
if __name__=='__main__':unittest.main(verbosity=2)
