"""Current wiring contracts; actual pointer dispatch tests live in androidTest."""
from pathlib import Path
import re
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(p): return (SRC/p).read_text()
class Ui6560(unittest.TestCase):
    def test_observer_does_not_consume_child_scroll(self):
        s=read('ui/components/SurfaceInput.kt').split('fun Modifier.surfaceInputBoundary()')[1]
        self.assertNotIn('.consume()',s)
        self.assertIn('awaitPointerEvent(PointerEventPass.Main)',s)
        main=read('MainActivity.kt')
        self.assertEqual(main.count('.surfaceInputBoundary()'),3)
        self.assertNotIn('.blockSurfaceInput()',main)
        self.assertIn('.surfaceInputBoundary().statusBarsPadding().verticalScroll',read('ui/screens/AccountScreen.kt'))
        self.assertIn('if (!open) Box(Modifier.fillMaxSize().blockSurfaceInput())',read('ui/components/AccountDrawerHost.kt'))
    def test_only_player_has_additional_status_tint(self):
        main=read('MainActivity.kt')
        self.assertRegex(main,r'if \(mounted && !eqOpen && !profileEdit\) \{\s*StatusBarTint\(')
        self.assertEqual(main.count('StatusBarTint('),1)
        self.assertIn('0.24f',read('ui/components/TopChrome.kt').split('fun StatusBarTint')[1].split('fun Modifier.libraryChrome')[0])
    def test_profile_status_follows_collapse_in_draw(self):
        s=read('ui/screens/AccountScreen.kt')
        self.assertIn('drawRect(lerp(color, p.surface, progress().coerceIn(0f, 1f)))',s)
        self.assertNotIn('WindowInsets.statusBars).background(color)',s)
        self.assertIn('TOP_SCRIM_ALPHA = 0.85f',read('ui/AccountUiGeometry.java'))
        self.assertIn('.pinnedPageChrome(progress).blockSurfaceInput().statusBarsPadding()',read('ui/components/PinnedPageHeader.kt'))
    def test_full_bleed_restores_exact_width(self):
        self.assertIn('.fullBleedHorizontal(inset).fillMaxWidth().background(p.surface)',read('ui/screens/HomeScreen.kt'))
        s=read('ui/components/FullBleed.kt')
        self.assertIn('constraints.offset(horizontal = edge * 2)',s)
        self.assertIn('child.placeRelative(-edge, 0)',s)
        # Integer placement invariant including fractional densities / rounded insets.
        for width in (320,360,692,1080,1440,2400):
            for edge in range(0,41):
                child=width-2*edge+2*edge
                self.assertEqual(edge-edge,0)
                self.assertEqual(edge-edge+child,width)
    def test_settings_and_other_headers_own_status_inset(self):
        s=read('ui/screens/Sheets.kt')
        self.assertIn('.then(if (fullScreen) Modifier.statusBarsPadding() else Modifier)',s)
        self.assertIn('.heightIn(min = 56.dp).padding(horizontal = 8.dp)',s)
        self.assertIn('IconButton(modifier = Modifier.size(48.dp), onClick = { searching',s)
        self.assertIn('.libraryChrome().statusBarsPadding()',read('ui/screens/LibraryScreen.kt'))
        self.assertIn('.searchChrome(p.brand, p.top).statusBarsPadding()',read('ui/screens/SearchScreen.kt'))
        self.assertNotIn('if (search.collection == null) Modifier.statusBarsPadding()',read('MainActivity.kt'))
    def test_device_regressions_are_present_not_simulated(self):
        s=(ROOT/'app/src/androidTest/java/app/ziziplayer/ui/SurfaceGestureTest.kt').read_text()
        self.assertEqual(s.count('@Test fun'),5)
        self.assertIn('performTouchInput { swipeUp() }',s)
        self.assertIn('assertEquals(0, underlyingClicks)',s)
if __name__=='__main__': unittest.main(verbosity=2)
