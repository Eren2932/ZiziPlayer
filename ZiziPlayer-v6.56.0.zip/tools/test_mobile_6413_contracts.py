#!/usr/bin/env python3
"""Source and numeric contracts. NOT Kotlin compilation or Compose/device execution."""
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (SRC / path).read_text()

def block_end(text, start):
    """Enough Kotlin lexical masking to locate layout braces (not a Kotlin parser)."""
    masked = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"',
                    lambda m: ' ' * len(m.group()), text, flags=re.S)
    depth = 0
    for i in range(start, len(masked)):
        if masked[i] == '{': depth += 1
        elif masked[i] == '}':
            depth -= 1
            if depth == 0: return i
    raise AssertionError('Unclosed layout block')

class Mobile6413Contracts(unittest.TestCase):
    def test_version_and_test_wiring(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 107', gradle)
        self.assertIn('versionName = "6.56.0"', gradle)
        self.assertIn('test_mobile_6413_contracts.py', (ROOT/'tools/check_selftest.py').read_text())
        self.assertEqual(sum(p.read_text().count('@Test fun') for p in [
            ROOT/'app/src/test/java/app/ziziplayer/ui/HubRefreshControllerTest.kt',
            ROOT/'app/src/test/java/app/ziziplayer/ui/HubContentTest.kt',
            ROOT/'app/src/test/java/app/ziziplayer/data/remote/MixDiscoverTest.kt']), 27)

    def test_dock_is_a_permanent_sibling_not_inside_ime_padding(self):
        host = read('MainActivity.kt')
        pos = host.index('Box(Modifier.fillMaxSize().imePadding()) {')
        end = block_end(host, host.index('{', pos))
        dock = host.index('.bottomChrome()')
        self.assertLess(end, dock)
        self.assertNotIn('if (!imeVisible) Column(', host)
        self.assertIn('derivedStateOf { imeInsets.getBottom(density) > 0 }', host)
        self.assertIn('.onSizeChanged { dockHeightPx = it.height }', host)
        self.assertIn('if (imeInsets.getBottom(density).toFloat() < size.height) drawContent()', host)
        self.assertIn('LocalBottomChromeInset = compositionLocalOf', read('ui/components/TopChrome.kt'))
        manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
        android = '{http://schemas.android.com/apk/res/android}'
        activity = manifest.find('.//activity')
        self.assertEqual(activity.get(android+'windowSoftInputMode'), 'adjustResize')

    def test_chrome_keeps_children_opaque_and_has_no_blur(self):
        body = read('ui/components/TopChrome.kt').split('fun Modifier.bottomChrome')[1]
        self.assertIn('CollectionGeometry.scrimAlpha(t)', body)
        self.assertIn('Brush.verticalGradient', body)
        self.assertNotIn('hasPlayer', body)
        self.assertEqual(body.count('drawRect('), 1)
        self.assertIn('onDrawBehind', body)
        for expensive in ['RenderEffect', 'graphicsLayer', 'blur(', 'saveLayer']:
            self.assertNotIn(expensive, body)
        self.assertIn('idle = p.subtext', read('ui/components/TabBar.kt'))
        self.assertIn('active = p.text', read('ui/components/TabBar.kt'))

    def test_user_selected_opacity_preserves_35_percent_at_maximum(self):
        # Source wiring only; the production Java math is executed in test_collection_6420.py.
        core = read('ui/CollectionGeometry.java')
        self.assertIn('return 0.65f * smoothstep(progress)', core)
        chrome = read('ui/components/TopChrome.kt').split('fun Modifier.bottomChrome')[1]
        self.assertIn('val start = -lead', chrome)
        self.assertIn('CollectionGeometry.scrimAlpha(t)', chrome)

    def test_hub_entry_is_not_an_editor_and_opens_history(self):
        ui = read('ui/screens/SearchScreen.kt')
        start = ui.index('if (state.stage == SearchStage.HUB) {')
        end = block_end(ui, ui.index('{', start))
        hub = ui[start:end]
        self.assertIn('HubSearchEntry(onOpen = {', hub)
        self.assertIn('search.openSearch()', hub)
        self.assertNotIn('SearchField(', hub)
        entry = ui.split('private fun HubSearchEntry')[1].split('private fun SearchField')[0]
        self.assertNotIn('BasicTextField', entry)
        self.assertNotIn('VoiceSearchButton', entry)
        self.assertIn('.clickable(role = Role.Button', entry)
        vm = read('ui/SearchViewModel.kt')
        self.assertIn('fun openSearch() {', vm)
        self.assertIn('editorReturnStage = SearchStage.HUB\n        onField("")', vm)

    def test_focus_is_requested_once_on_explicit_entry_not_on_stage_changes(self):
        ui = read('ui/screens/SearchScreen.kt')
        field = ui.split('private fun SearchField')[1].split('// ------------------------------------------------------------------ хаб')[0]
        self.assertIn('LaunchedEffect(requestFocusOnOpen)', field)
        self.assertIn('if (requestFocusOnOpen)', field)
        self.assertLess(field.index('withFrameNanos { }'), field.index('focus.requestFocus()'))
        self.assertIn('onFocusRequestHandled()', field)
        self.assertIn('onFocusRequestHandled = { focusEditorOnEntry = false }', ui)
        self.assertNotIn('LaunchedEffect(state.stage)', ui)
        self.assertNotIn('LaunchedEffect(ime', field)
        self.assertEqual(len(re.findall(r'^\s+SearchField\(', ui, re.M)), 1)

    def test_editor_back_uses_origin_and_does_not_erase_results(self):
        vm = read('ui/SearchViewModel.kt')
        self.assertIn('SearchNavigation.editOrigin(_state.value.stage, editorReturnStage)', vm)
        self.assertIn('SearchNavigation.backFromEditor(editorReturnStage, current.query)', vm)
        entry = vm.split('fun openSearch()')[1].split('fun onField(')[0]
        self.assertNotIn('results =', entry)
        self.assertNotIn('query =', entry)
        tests = ROOT/'app/src/test/java/app/ziziplayer/ui/SearchNavigationTest.kt'
        self.assertEqual(tests.read_text().count('@Test fun'), 6)

    def test_search_filters_have_real_layout_spacing_and_aligned_targets(self):
        body = read('ui/screens/SearchScreen.kt').split('private fun ResultsBody(')[1]
        self.assertIn('Spacer(Modifier.height(12.dp))\n    LazyRow(', body)
        self.assertIn('PaddingValues(horizontal = 14.dp, vertical = 4.dp)', body)
        self.assertIn('verticalAlignment = Alignment.CenterVertically', body)

    def test_busy_animation_yields_and_obeys_lifecycle_and_reduced_motion(self):
        body = read('ui/screens/SearchScreen.kt').split('private fun HubRefreshButton')[1]
        for clause in ['repeatOnLifecycle(Lifecycle.State.STARTED)', 'withFrameNanos { }',
                       '[MotionDurationScale]?.scaleFactor == 0f', 'break',
                       'clickable(enabled = !refreshing', 'stateDescription =', '.size(48.dp)']:
            self.assertIn(clause, body)

    def test_controller_is_single_flight_and_all_io_is_guarded(self):
        controller = read('ui/HubRefreshController.kt')
        self.assertIn('if (_state.value.refreshing)', controller)
        self.assertIn('forceRequested = forceRequested || force', controller)
        self.assertNotIn('.cancel()', controller)
        self.assertLess(controller.index('refreshing = true'), controller.index('scope.launch'))
        self.assertLess(controller.index('try {', controller.index('scope.launch')), controller.index('preferred()'))
        self.assertIn('withTimeoutOrNull(timeoutMs)', controller)
        self.assertIn('catch (e: CancellationException)', controller)
        self.assertIn('finally {\n                _state.value = _state.value.copy(loading = false, refreshing = false)', controller)
        self.assertIn('if (!unchanged)', controller)
        self.assertIn('if (fresh.isEmpty()) return@withTimeoutOrNull Outcome.EMPTY', controller)
        self.assertIn('withContext(Dispatchers.Default)', controller)

    def test_view_model_uses_controller_and_reports_results_without_resetting_search(self):
        vm = read('ui/SearchViewModel.kt')
        self.assertIn('HubRefreshController(', vm)
        self.assertIn('fun loadHub(force: Boolean = false) = hub.load(force)', vm)
        self.assertIn('hub.state.collect', vm)
        self.assertIn('withTimeoutOrNull(8_000L)', vm)
        self.assertIn('Channel<String>(Channel.CONFLATED)', vm)
        host = read('MainActivity.kt')
        self.assertIn('searchVm.messages.collect', host)
        self.assertIn('.padding(bottom = dockInset + 8.dp)', host)

    def test_mix_does_not_silently_convert_outages_to_empty_success(self):
        mix = read('data/remote/DeezerCatalog.kt').split('class MixCatalog')[1]
        body = mix.split('override suspend fun discover()')[1].split('override suspend fun collection(')[0]
        self.assertNotIn('runCatching', body)
        self.assertIn('catch (e: CancellationException)', body)
        self.assertIn('catch (e: Exception)', body)
        self.assertIn('if (shelves.isEmpty()) results.mapNotNull { it.second }.lastOrNull()?.let { throw it }', body)

    def test_cache_counts_utf8_bytes_and_keeps_last_good_file(self):
        cache = read('data/remote/HubCache.kt')
        self.assertIn('text.toByteArray(Charsets.UTF_8)', cache)
        self.assertIn('bytes.size <= MAX_BYTES', cache)
        self.assertNotIn('target.delete()', cache)
        self.assertIn('if (!tmp.renameTo(target)) tmp.delete()', cache)

    def test_ui_and_normalizer_share_item_keys(self):
        self.assertIn('private fun keyOf(item: RemoteItem): String = HubContent.itemKey(item)', read('ui/screens/SearchScreen.kt'))
        normalizer = read('ui/HubRefreshController.kt').split('internal data class HubSnapshot')[0]
        self.assertIn('getOrPut(title)', normalizer)
        self.assertIn('val key = itemKey(item)', normalizer)
        self.assertIn('items.size < MAX_ITEMS', normalizer)

if __name__ == '__main__': unittest.main(verbosity=2)
