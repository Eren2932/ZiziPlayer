package app.ziziplayer.ui

import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.remote.*
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

internal enum class HomeShelfLayout { COVERS, TRACKS, ARTISTS }
internal data class HomeFeedCard(
    val id: String, val title: String, val subtitle: String,
    val tracks: List<TrackEntity> = emptyList(), val remote: RemoteCollection? = null
) {
    val cover: TrackEntity? get() = tracks.firstOrNull()
}
internal data class HomeFeedShelf(val id: String, val title: String, val subtitle: String,
    val layout: HomeShelfLayout, val cards: List<HomeFeedCard>, val seed: TrackEntity? = null,
    /** Полка «Похоже на»: заголовок строится вокруг артиста-якоря, а не вокруг названия полки. */
    val anchorName: String? = null, val anchorArt: String? = null)
internal data class HomeFeedState(
    val shelves: List<HomeFeedShelf> = emptyList(), val wave: List<TrackEntity> = emptyList(),
    val loading: Boolean = false, val error: String? = null,
    val folders: Set<String> = emptySet(), val hidden: Set<String> = emptySet(), val loadedAt: Long = 0L
)

/** No new HTTP client, audio resolver, listener or timer. One metadata request at a time.
 * A snapshot lives only in this ViewModel, never in an unencrypted personalized disk cache. */
internal class HomeRecommendations(private val app: ZiziApplication, private val scope: CoroutineScope,
    private val hidden: StateFlow<Set<String>?>) {
    private val _state = MutableStateFlow(HomeFeedState())
    val state = _state.asStateFlow()
    private var job: Job? = null
    private var retry: Job? = null
    private var attempt = 0
    /** Быстрые повторы прогревающегося сервера (2/4/8 с); отдельный счётчик от лестницы 15/45/135 с. */
    private var quickAttempt = 0
    private var lastAttempt = 0L
    private var generation = 0
    /**
     * 6.82.0. Последний ответ сервера, только в памяти. Каждое обновление собирает FeedBuilder заново,
     * и без этого полки Reco исчезали с экрана до ответа сервера: человек видел пустую главную при
     * каждом возвращении в приложение. Сбрасывается вместе со всем при смене приватности.
     */
    private var lastReco: RecoResult? = null
    /** Бесконечная лента «Для тебя» под полками; живёт и переживает уход с главной. */
    val feed = HomeRecoFeed(app, scope)

    fun clear() {
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        attempt = 0; quickAttempt = 0; lastAttempt = 0L; lastReco = null
        feed.clear()
        _state.value = HomeFeedState()
    }
    fun cancel() {
        val interrupted = job?.isActive == true
        generation++; job?.cancel(); job = null; retry?.cancel(); retry = null
        feed.cancel()
        if (interrupted) lastAttempt = 0L
        _state.value = _state.value.copy(loading = false, loadedAt = if (interrupted) 0L else _state.value.loadedAt)
    }
    private fun safe(snapshot: HomeState) = snapshot.vaultFolders == app.repository.vault.state.value.folders &&
        snapshot.hiddenIds == hidden.value

    fun load(snapshot: HomeState, force: Boolean = false, gapMs: Long = HomeFeedRefreshPolicy.ATTEMPT_GAP_MS) {
        if (snapshot.loading || !safe(snapshot)) return
        if (_state.value.folders != snapshot.vaultFolders || _state.value.hidden != snapshot.hiddenIds) clear()
        if (job?.isActive == true) return
        val now = System.currentTimeMillis()
        // Одна арифметика на всё: срок свежести, минимальный интервал и бюджет автоповторов.
        if (!HomeFeedRefreshPolicy.shouldLoad(now, _state.value.loadedAt, lastAttempt, force, gapMs)) return
        retry?.cancel(); retry = null
        lastAttempt = now
        val epoch = ++generation
        _state.value = _state.value.copy(loading = true, error = null,
            folders = snapshot.vaultFolders, hidden = snapshot.hiddenIds)
        job = scope.launch {
            try {
                val favorites = app.database.musicDao().observeFavoriteIds().first().toSet()
                val known = snapshot.tracks.associateBy { it.id }
                val sessions = app.database.listeningDao().recommendationSnapshot().filter { row ->
                    row.trackId in known && row.trackId !in snapshot.hiddenIds &&
                        (row.source != "local" || row.sourceFolder !in snapshot.vaultFolders)
                }
                val builder = withContext(Dispatchers.Default) { FeedBuilder(snapshot, favorites, sessions, now) }
                // Полки прошлого ответа остаются на экране, пока идёт обновление: первый publish() ниже
                // рисует их мгновенно. Если сервер ответит иначе, builder.reco просто заменится.
                builder.reco = lastReco
                suspend fun publish(error: String? = null) {
                    val built = withContext(Dispatchers.Default) { builder.build() }
                    if (epoch == generation && safe(snapshot)) _state.value = built.copy(
                        loading = true, error = error, folders = snapshot.vaultFolders,
                        hidden = snapshot.hiddenIds, loadedAt = now)
                }
                publish()
                // The server-backed metadata catalog respects the user's existing resolver config.
                // Do not silently enable direct YouTube / Google access for a Home visit.
                val catalog = RemoteRuntime.registry.byId("dz")
                var failure: String? = null
                var partial = false // сервер ответил не целиком: тихий быстрый повтор, без сообщения об ошибке
                var warming = false // сервер ответил ПУСТО и НЕПОЛНО: он прогревается, спросим снова через 2/4/8 с
                var retryHintMs = 0L
                var feedProfile: RecoProfile? = null
                var stopNetwork = false
                suspend fun request(block: suspend () -> Unit) {
                    if (stopNetwork) return
                    try {
                        // Бюджет считается только на сам запрос: ожидание плеера в него больше не входит.
                        val done = withTimeoutOrNull(HomeFeedRefreshPolicy.REQUEST_TIMEOUT_MS) { block(); true }
                        if (done == null) { failure = "Каталог не успел ответить. Локальные подборки доступны"; stopNetwork = true }
                    } catch (e: CancellationException) { throw e }
                    catch (e: Exception) {
                        failure = if (e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED)
                            "Каталог просит паузу, подборки вернутся сами" else "Каталог недоступен. Локальные подборки сохранены"
                        stopNetwork = true // no retry storm when the first request fails
                    }
                }
                val complete = withTimeoutOrNull(HomeFeedRefreshPolicy.TOTAL_TIMEOUT_MS) {
                    // 6.81.0 ждал здесь `!isLoadingAudio` без предела и перед КАЖДЫМ запросом: пока трек грузился
                    // или контроллер не подключился (по умолчанию isLoadingAudio = true), подборки стояли, а потом
                    // сдавались по тайм-ауту. Метаданные плееру не мешают: ждём один раз и недолго.
                    withTimeoutOrNull(HomeFeedRefreshPolicy.AUDIO_GRACE_MS) { app.playerController.state.first { !it.isLoadingAudio } }
                    if (catalog == null) failure = "Каталог не настроен"
                    else {
                        // Reco 1: одна просьба к серверу вместо семи с телефона. Сервер строит граф «кто звучит
                        // как твои артисты», кэширует его и отдаёт готовые полки. Старый сервер или пустой полный
                        // ответ — тихий откат на прежний путь ниже, без сообщения об ошибке.
                        val identities = withContext(Dispatchers.IO) {
                            builder.identityCandidates().chunked(400).flatMap { app.database.listeningDao().catalogIdentities(it) }
                                .filter { it.provider == "dz" && !it.artistId.isNullOrBlank() }
                                .associate { it.trackId to it.artistId!! }
                        }
                        val profile = withContext(Dispatchers.Default) { builder.recoProfile(identities) }
                        feedProfile = profile
                        if (profile != null) {
                            try {
                                var recoAnswered = false // null от recommendHome (старый сервер) != «не успел ответить»
                                val reco = withTimeoutOrNull(HomeFeedRefreshPolicy.RECO_TIMEOUT_MS) {
                                    catalog.recommendHome(profile).also { recoAnswered = true }
                                }
                                when (HomeRecoPolicy.outcome(recoAnswered, reco?.shelves?.size ?: 0, reco?.complete ?: true)) {
                                    HomeRecoPolicy.SHOW -> {
                                        lastReco = reco; builder.reco = reco; publish()
                                        // Неполный ответ: сервер достраивает остаток в кэше, быстрый повтор его заберёт.
                                        partial = reco?.complete == false
                                        retryHintMs = reco?.retryMs ?: 0L
                                    }
                                    // 6.81.0 принимал пустой неполный ответ за успех, шёл на прежний путь и 30 минут молчал.
                                    HomeRecoPolicy.RETRY -> { warming = true; retryHintMs = reco?.retryMs ?: 0L }
                                    HomeRecoPolicy.TIMEOUT -> {
                                        failure = "Каталог не успел ответить. Локальные подборки доступны"; stopNetwork = true
                                    }
                                    // FALLBACK: старый сервер или нечего предложить. Молча идём прежним путём ниже.
                                    else -> Unit
                                }
                            } catch (e: CancellationException) { throw e }
                            catch (e: Exception) {
                                failure = if (e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED)
                                    "Каталог просит паузу, подборки вернутся сами" else "Каталог недоступен. Локальные подборки сохранены"
                                stopNetwork = true
                            }
                        }
                    }
                    if (catalog != null && builder.reco == null) {
                        request { builder.discover = HubContent.normalize(catalog.discover()); publish() }
                        // Прогревающемуся серверу поиск по артистам только мешает достраивать граф: ждём повтор.
                        // Maximum seven logical calls per refresh: chart + 3 artists × (tracks + albums).
                        if (!warming) for (artist in builder.seeds.take(3)) {
                            request {
                                val songs = catalog.search(artist, RemoteKind.TRACK, null).items
                                    .filterIsInstance<RemoteItem.Song>().map { it.track }
                                    .filter { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) }
                                builder.artistTracks[artist] = songs.take(30); publish()
                            }
                            request {
                                builder.albums[artist] = catalog.search(artist, RemoteKind.ALBUM, null).items
                                    .filterIsInstance<RemoteItem.Group>().map { it.collection }
                                    .filter { it.kind == RemoteKind.ALBUM }.take(10)
                                publish()
                            }
                        }
                    }
                    true
                }
                if (complete == null) failure = "Обновление остановлено по тайм-ауту. Полученные подборки сохранены"
                publish(failure)
                if (epoch == generation) {
                    if (failure != null) {
                        _state.value = _state.value.copy(loadedAt = 0L)
                        scheduleRetry(snapshot, epoch)
                    } else if (warming || partial) {
                        _state.value = _state.value.copy(loadedAt = 0L)
                        scheduleRetry(snapshot, epoch, retryHintMs)
                    } else {
                        attempt = 0; quickAttempt = 0
                    }
                    // Лента стартует, когда сервер прогрет: на холодном кэше она лишь отняла бы у главной запросы к Deezer.
                    val seedProfile = feedProfile
                    if (failure == null && !warming && seedProfile != null) feed.start(seedProfile, snapshot)
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                if (epoch == generation) {
                    _state.value = _state.value.copy(error = "Подборки соберутся сами, как только появится связь")
                    scheduleRetry(snapshot, epoch)
                }
            } finally {
                if (epoch == generation) _state.value = _state.value.copy(loading = false)
            }
        }
    }

    /**
     * Неудача не требует действий пользователя: 15 c, 45 c, 135 c — и тишина.
     * Это не таймер обновления и не фоновая служба: корутина живёт в скоупе экрана,
     * уходит вместе с ним (cancel/clear) и имеет жёсткий бюджет попыток.
     *
     * 6.82.0. [quickHintMs] >= 0 — повтор прогревающегося сервера: 2, 4, 8 секунд (не быстрее подсказки
     * `retry_ms`), а когда они кончились — обычная лестница. Сообщения об ошибке при этом нет.
     */
    private fun scheduleRetry(snapshot: HomeState, epoch: Int, quickHintMs: Long = -1L) {
        if (epoch != generation) return
        val quick = quickHintMs >= 0L && HomeFeedRefreshPolicy.canQuickRetry(quickAttempt + 1)
        val wait: Long
        if (quick) {
            quickAttempt += 1
            wait = HomeFeedRefreshPolicy.quickRetryDelayMs(quickAttempt, quickHintMs)
        } else {
            if (!HomeFeedRefreshPolicy.canRetry(attempt + 1)) return
            attempt += 1
            wait = HomeFeedRefreshPolicy.retryDelayMs(attempt)
        }
        retry?.cancel()
        retry = scope.launch {
            // Запас к паузе: минимальный интервал попыток считается по стенным часам.
            delay(wait + 250L)
            if (epoch == generation) load(snapshot, force = true,
                gapMs = if (quick) HomeFeedRefreshPolicy.QUICK_GAP_MS else HomeFeedRefreshPolicy.ATTEMPT_GAP_MS)
        }
    }
}

/** All scoring and shelf assembly happens on Default, not on a playback tick. */
private class FeedBuilder(private val source: HomeState, favorites: Set<String>,
    sessions: List<ListeningSessionEntity>, private val now: Long) {
    private val known = source.tracks.associateBy { it.id }
    private val evidence = sessions.groupBy { it.trackId }.mapValues { (_, rows) -> rows.sumOf {
        HomeFeedPolicy.sessionWeight(it.qualified, it.completed, it.outcome == "skipped" && it.listenedMs < 10_000L,
            (now - it.startedAt).coerceAtLeast(0L) / 86_400_000.0)
    } }
    private val scores = source.tracks.associate { it.id to HomeFeedPolicy.score(it.id in favorites, evidence[it.id] ?: 0.0) }
    private val artistScores = source.tracks.groupBy { HomeFeedPolicy.normalize(it.artist) }
        .mapValues { (_, tracks) -> tracks.sumOf { scores[it.id] ?: 0.0 } }
    val seeds = source.tracks.filter { it.artist.isNotBlank() && (scores[it.id] ?: 0.0) > 0.0 }
        .distinctBy { HomeFeedPolicy.normalize(it.artist) }
        .sortedWith(compareByDescending<TrackEntity> { artistScores[HomeFeedPolicy.normalize(it.artist)] ?: 0.0 }.thenBy { it.id })
        .map { it.artist }.take(3)
    var discover: List<DiscoverShelf> = emptyList()
    /** Reco 1: готовые полки с сервера. null — сервер недоступен или старше 6.81, работает прежний путь. */
    var reco: RecoResult? = null
    val artistTracks = linkedMapOf<String, List<RemoteTrack>>()
    val albums = linkedMapOf<String, List<RemoteCollection>>()
    private val recentIds = sessions.sortedByDescending { it.startedAt }.map { it.trackId }.distinct().take(12)

    /** Remote-треки с ненулевой оценкой: только для них id артиста Deezer ищется в track_catalog. */
    fun identityCandidates(): List<String> = source.tracks.asSequence()
        .filter { it.isRemote && (scores[it.id] ?: 0.0) != 0.0 }
        .sortedByDescending { kotlin.math.abs(scores[it.id] ?: 0.0) }
        .map { it.id }.take(400).toList()

    private class Credit(val name: String) { var score = 0.0; var tracks = 0; var id: String? = null }

    /**
     * Профиль вкуса для сервера. Оценка артиста — та же, что и в «Твоих миксах»: избранное +
     * зачтённые прослушивания с полураспадом 14 дней − ранние пропуски. Сид с весом 1 — главный артист,
     * остальные — доля от него. Соисполнители получают 60% оценки трека. Название трека не уходит.
     */
    fun recoProfile(identities: Map<String, String>): RecoProfile? {
        val credits = LinkedHashMap<String, Credit>()
        var slowedMass = 0.0; var spedMass = 0.0; var totalMass = 0.0
        for (t in source.tracks) {
            val parts = HomeRecoPolicy.splitArtists(t.artist)
            if (parts.isEmpty()) continue
            val score = scores[t.id] ?: 0.0
            parts.forEachIndexed { index, part ->
                val key = HomeFeedPolicy.normalize(part)
                if (key.isEmpty()) return@forEachIndexed
                val credit = credits.getOrPut(key) { Credit(RecoQuery.safeName(part)) }
                credit.tracks += 1
                credit.score += if (index == 0) score else score * HomeRecoPolicy.SECONDARY_SHARE
                // id Deezer принадлежит первому из перечисленных артистов: так его присылает каталог.
                if (index == 0 && score > 0.0 && credit.id == null) credit.id = identities[t.id]
            }
            if (score > 0.0) {
                totalMass += score
                if (HomeRecoPolicy.slowed(t.title)) slowedMass += score
                if (HomeRecoPolicy.spedUp(t.title)) spedMass += score
            }
        }
        val seeds = credits.values.filter { it.score > 0.0 && it.name.isNotEmpty() }
            .sortedWith(compareByDescending<Credit> { it.score }.thenBy { it.name })
            .take(HomeRecoPolicy.MAX_SEEDS)
        val seedKeys = seeds.mapTo(HashSet()) { HomeFeedPolicy.normalize(it.name) }
        val top = seeds.firstOrNull()?.score ?: 0.0
        val knownNames = credits.values.filter { it.name.isNotEmpty() && it.score > HomeRecoPolicy.NEGATIVE_SCORE &&
                HomeFeedPolicy.normalize(it.name) !in seedKeys }
            .sortedWith(compareByDescending<Credit> { it.score }.thenByDescending { it.tracks }.thenBy { it.name })
            .take(HomeRecoPolicy.MAX_KNOWN).map { RecoQuery.name(it.name) }
        val negativeNames = credits.values.filter { it.name.isNotEmpty() && it.score <= HomeRecoPolicy.NEGATIVE_SCORE }
            .sortedBy { it.score }.take(HomeRecoPolicy.MAX_NEGATIVE).map { RecoQuery.name(it.name) }
        val recent = recentIds.mapNotNull(this.known::get).mapNotNull { t ->
            HomeRecoPolicy.splitArtists(t.artist).firstOrNull()?.let { identities[t.id] ?: RecoQuery.name(it) }
        }.distinct().take(HomeRecoPolicy.MAX_RECENT)
        if (seeds.isEmpty() && recent.isEmpty()) return null
        return RecoProfile(
            seeds.map { RecoSeed(it.id ?: RecoQuery.name(it.name), HomeRecoPolicy.weight(it.score, top)) },
            knownNames, negativeNames, recent, HomeRecoPolicy.versionPreference(slowedMass, spedMass, totalMass))
    }
    private val favoriteTracks = source.tracks.filter { it.id in favorites }
    private fun canonical(t: TrackEntity): String = if (t.provider == "mix") "r:${t.remoteId}" else t.id
    private val knownCanonical = known.values.mapTo(HashSet(), ::canonical)
    private val hiddenCanonical = source.hiddenIds.mapTo(HashSet()) { if (it.startsWith("r:mix:")) "r:" + it.removePrefix("r:mix:") else it }
    private fun unique(tracks: List<TrackEntity>): List<TrackEntity> {
        val result = ArrayList<TrackEntity>(); val ids = HashSet<String>()
        val metadata = HashMap<String, MutableList<Long>>()
        for (t in tracks.take(600)) {
            if (t.title.isBlank() || t.id in source.hiddenIds || canonical(t) in hiddenCanonical ||
                (t.isRemote && !CatalogPolicy.supports(t.provider, t.remoteId))) continue
            val key = HomeFeedPolicy.normalize(t.artist) + "|" + HomeFeedPolicy.normalize(t.title)
            val durations = metadata.getOrPut(key) { mutableListOf() }
            if (!ids.add(canonical(t)) || (t.durationMs > 0L && durations.any { it > 0L && kotlin.math.abs(it - t.durationMs) <= 2000L })) continue
            durations += t.durationMs; result += t
            if (result.size >= 300) break
        }
        return result
    }
    private fun rank(tracks: List<TrackEntity>, limit: Int, novel: Boolean = false): List<TrackEntity> {
        fun value(t: TrackEntity): Double {
            val affinity = artistScores[HomeFeedPolicy.normalize(t.artist)]?.coerceIn(-4.0, 8.0) ?: 0.0
            return (scores[t.id] ?: 0.0) + affinity * 0.35 +
                (if (novel && canonical(t) !in knownCanonical) 3.0 else 0.0) -
                (if (t.id in recentIds) 2.0 else 0.0) + HomeFeedPolicy.dailyTie(t.id, now / 86_400_000L)
        }
        // Bound after scoring, not after alphabetical database order: a large library
        // must not permanently starve favourites whose titles start near the end.
        val values = tracks.associate { it.id to value(it) }
        val list = unique(tracks.sortedWith(compareByDescending<TrackEntity> { values[it.id] ?: 0.0 }.thenBy { it.id }))
        val byId = list.associateBy { it.id }
        return HomeFeedPolicy.rank(list.map { HomeFeedPolicy.Candidate(it.id, it.artist, values[it.id] ?: 0.0) }, limit)
            .mapNotNull(byId::get)
    }
    fun build(): HomeFeedState {
        val out = mutableListOf<HomeFeedShelf>()
        val exposures = HashMap<String, Int>()
        val shownGroups = HashSet<String>()
        val remote = unique(artistTracks.values.flatten().map { it.toEntity(now) })
        val chart = unique(discover.flatMap { it.items }.filterIsInstance<RemoteItem.Song>().map { it.track.toEntity(now) })
        val catalog = discover.flatMap { it.items }.filterIsInstance<RemoteItem.Group>().map { it.collection }
            .filter { CatalogPolicy.supports(it.provider, it.remoteId) }.distinctBy { "${it.provider}:${it.remoteId}" }
        fun songs(id: String, title: String, detail: String, tracks: List<TrackEntity>, layout: HomeShelfLayout = HomeShelfLayout.COVERS, seed: TrackEntity? = null) {
            val visible = unique(tracks).filter { (exposures[canonical(it)] ?: 0) < 2 }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                val key = canonical(it); exposures[key] = (exposures[key] ?: 0) + 1
                HomeFeedCard(it.id, it.title, it.artist, listOf(it))
            }, seed)
        }
        fun groups(id: String, title: String, detail: String, groups: List<RemoteCollection>, layout: HomeShelfLayout = HomeShelfLayout.COVERS,
            anchorName: String? = null, anchorArt: String? = null) {
            val visible = groups.filter { shownGroups.add("${it.provider}:${it.remoteId}") }.take(12)
            if (visible.isEmpty()) return
            out += HomeFeedShelf(id, title, detail, layout, visible.map {
                HomeFeedCard("${it.provider}:${it.remoteId}", it.title, it.subtitle, remote = it)
            }, anchorName = anchorName, anchorArt = anchorArt)
        }
        // Reco 1. Порядок как у эталона: «Недавние» -> «Похоже на X» -> станция -> новое -> артисты -> «Начни с…».
        // Сначала треки, затем альбомы, затем артисты. Сортировка устойчивая: внутри вида порядок сервера цел.
        val recoShelves = reco?.shelves.orEmpty().sortedBy { HomeRecoPolicy.shelfRank(it.kind.name) }
        val recoMode = recoShelves.isNotEmpty()
        if (recoMode) {
            songs("continue-listening", "Слушаем дальше?", "Недавние прослушивания", recentIds.mapNotNull(known::get))
            for (shelf in recoShelves) {
                val collections = shelf.cards.mapNotNull { it.collection }
                    .filter { CatalogPolicy.supports(it.provider, it.remoteId) }
                when (shelf.kind) {
                    RecoShelfKind.TRACKS -> songs(shelf.id, shelf.title, "По твоим прослушиваниям и избранному",
                        shelf.cards.mapNotNull { it.track?.toEntity(now) }, HomeShelfLayout.TRACKS)
                    RecoShelfKind.ALBUMS -> groups(shelf.id, shelf.title, "", collections, HomeShelfLayout.COVERS,
                        shelf.anchorName, shelf.anchorArt)
                    RecoShelfKind.ARTISTS -> groups(shelf.id, shelf.title, "На основе того, что ты слушаешь",
                        collections, HomeShelfLayout.ARTISTS)
                }
            }
        }
        val wave = rank(source.tracks.filter { it.id in source.availableOfflineIds }, 50)
        val mixes = seeds.mapNotNull { artist ->
            val tracks = rank(source.tracks.filter { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) } +
                artistTracks[artist].orEmpty().map { it.toEntity(now) }, 40)
            if (tracks.isEmpty()) null else HomeFeedCard("mix:${HomeFeedPolicy.normalize(artist)}", "$artist: микс",
                "${tracks.size} треков · по твоим прослушиваниям и избранному", tracks)
        }.toMutableList()
        if (favoriteTracks.isNotEmpty()) mixes += HomeFeedCard("favorites-mix", "Любимое вперемешку", "Из твоего избранного", rank(favoriteTracks, 40))
        mixes.forEach { it.cover?.let { track -> exposures[canonical(track)] = 1 } }
        if (mixes.isNotEmpty()) out += HomeFeedShelf("mixes", "Твои миксы", "На основе избранного и зачтённых прослушиваний", HomeShelfLayout.COVERS, mixes)
        songs("today", "Послушай сегодня", if (remote.isEmpty()) "Из твоей музыки" else "Знакомые исполнители и твоя музыка",
            rank(remote + source.tracks, 12, novel = true))
        groups("catalog-playlists", "Подборки каталога", "Редакционные подборки · не персональный рейтинг", catalog.filter { it.kind == RemoteKind.PLAYLIST })
        if (!recoMode) songs("continue-listening", "Слушаем дальше?", "Недавние прослушивания", recentIds.mapNotNull(known::get))
        for ((artist, tracks) in artistTracks) songs("artist:$artist", "Ещё от $artist", "Найдено в каталоге по исполнителю",
            rank(tracks.map { it.toEntity(now) }, 12, novel = true), seed = source.tracks.firstOrNull { HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist) })
        songs("new-to-you", "Незнакомое у знакомых", "Треки исполнителей из твоих предпочтений, которых нет в медиатеке",
            rank(remote.filter { canonical(it) !in knownCanonical }, 12, novel = true))
        for ((artist, albumGroups) in albums) groups("albums:$artist", "Альбомы: $artist", "Результаты каталога по запросу исполнителя", albumGroups)
        songs("chart", "Сейчас слушают", "Общий чарт каталога · не твой персональный топ", chart.take(12), HomeShelfLayout.TRACKS)
        val artists = mixes.filter { it.id.startsWith("mix:") }.map { it.copy(title = it.title.removeSuffix(": микс"), subtitle = "Твоя подборка") }
        if (artists.isNotEmpty()) out += HomeFeedShelf("your-artists", "Твои любимые исполнители", "По избранному и истории", HomeShelfLayout.ARTISTS, artists)
        groups("catalog-artists", "Исполнители в каталоге", "Популярные сейчас", catalog.filter { it.kind == RemoteKind.ARTIST }, HomeShelfLayout.ARTISTS)
        songs("offline", "Всегда с тобой", "Доступно без интернета", wave.take(12))
        return HomeFeedState(out.take(18), wave)
    }
}
