package app.ziziplayer.ui

import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.data.remote.RecoProfile
import app.ziziplayer.data.remote.toEntity
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 6.82.0. Лента «Для тебя»: растущий только вперёд список треков, который подгружается страницами.
 *
 * [folders] и [hidden] — снимок приватности на момент старта; экран показывает ленту, только если он
 * совпадает с текущим (как и для полок). [stalled] — лента остановилась и ждёт «Повторить»: ошибка сети
 * или несколько пустых страниц подряд. Автоподгрузка при этом молчит, чтобы не долбить сервер.
 */
internal data class RecoFeedState(
    val tracks: List<TrackEntity> = emptyList(),
    val loading: Boolean = false,
    val more: Boolean = false,
    val stalled: Boolean = false,
    val error: String? = null,
    val folders: Set<String> = emptySet(),
    val hidden: Set<String> = emptySet()
)

/**
 * Один источник правды для двух потребителей: экран (прокрутка) и очередь плеера (дозаправка).
 * Страницы тянутся строго по одной под [lock]: курсор сервера однопоточный, а параллельный запрос
 * той же страницы лишь вернул бы то же самое.
 *
 * Профиль вкуса закрепляется на старте ленты и не меняется до [clear]: сервер сверяет его отпечаток
 * с сессией, и свежий профиль каждые 30 минут перезапускал бы ленту с головы.
 *
 * Всё состояние меняется на главном потоке (viewModelScope). Память, не диск: лента персональна.
 */
internal class HomeRecoFeed(private val app: ZiziApplication, private val scope: CoroutineScope) {
    private val _state = MutableStateFlow(RecoFeedState())
    val state: StateFlow<RecoFeedState> = _state.asStateFlow()

    private val lock = Mutex()
    private val seen = HomeFeedStreamPolicy.Seen()
    private var profile: RecoProfile? = null
    private var cursor: String? = null
    private var hiddenIds: Set<String> = emptySet()
    private var emptyStreak = 0
    private var generation = 0
    private var inFlight = 0
    private var startedAt = 0L
    private var job: Job? = null

    /** Поколение ленты. Меняется при clear() и перезапуске: потребитель с указателем из прошлого поколения обязан его сбросить. */
    val epoch: Int get() = generation

    /** Забыть всё: смена приватности, очистка истории. Незавершённые страницы отбрасываются по поколению. */
    fun clear() {
        generation += 1
        job?.cancel(); job = null
        seen.clear(); cursor = null; emptyStreak = 0
        profile = null; hiddenIds = emptySet(); startedAt = 0L
        _state.value = RecoFeedState()
    }

    /** Уход с главной: обрываем запрос экрана, но не стираем уже набранное. Очередь плеера не страдает. */
    fun cancel() {
        job?.cancel(); job = null
    }

    /**
     * Запуск ленты. Повторный вызов с рабочей лентой ничего не делает и профиль не меняет. Пустую
     * ленту (сервер был холодным или без кандидатов) можно перезапустить свежим профилем, но не чаще раза в минуту.
     */
    fun start(profile: RecoProfile, snapshot: HomeState) {
        val now = System.currentTimeMillis()
        if (this.profile != null) {
            val s = _state.value
            val idle = s.tracks.isEmpty() && !s.loading && job?.isActive != true
            if (!idle || now - startedAt < RESTART_GAP_MS) return
        }
        generation += 1
        job?.cancel(); job = null
        seen.clear(); cursor = null; emptyStreak = 0
        this.profile = profile; hiddenIds = snapshot.hiddenIds; startedAt = now
        _state.value = RecoFeedState(more = true, folders = snapshot.vaultFolders, hidden = snapshot.hiddenIds)
        loadMore()
    }

    /** Прокрутка дошла до порога: следующая страница. Лишние вызовы безвредны. */
    fun loadMore() {
        val s = _state.value
        if (profile == null || !s.more || s.stalled || job?.isActive == true) return
        val epoch = generation
        val target = s.tracks.size + 1
        job = scope.launch { pump(epoch, target) }
    }

    /** Кнопка «Повторить» после остановки. */
    fun retry() {
        if (profile == null) return
        emptyStreak = 0
        _state.update { it.copy(stalled = false, error = null) }
        loadMore()
    }

    /**
     * Треки ленты с позиции [from] для очереди плеера, до [count] штук; при необходимости докачивает
     * страницы (не больше [MAX_QUEUE_ROUNDS] за вызов). Пусто, если ленту сбросили по дороге.
     */
    suspend fun takeForQueue(from: Int, count: Int): List<TrackEntity> {
        if (from < 0 || count <= 0) return emptyList()
        val epoch = generation
        var rounds = 0
        while (epoch == generation && rounds < MAX_QUEUE_ROUNDS) {
            val s = _state.value
            if (profile == null || s.tracks.size >= from + count || !s.more || s.stalled) break
            pump(epoch, s.tracks.size + 1)
            rounds += 1
        }
        val tracks = _state.value.tracks
        if (epoch != generation || from >= tracks.size) return emptyList()
        return tracks.subList(from, minOf(tracks.size, from + count)).toList()
    }

    /**
     * Тянет страницы, пока лента не вырастет до [target] треков либо не остановится. Повторная проверка
     * внутри замка важна: пока мы ждали его, соседний потребитель мог уже подгрузить нужное.
     */
    private suspend fun pump(epoch: Int, target: Int) {
        inFlight += 1
        _state.update { it.copy(loading = true) }
        try {
            lock.withLock {
                while (epoch == generation) {
                    val s = _state.value
                    if (s.tracks.size >= target || !s.more || s.stalled) break
                    val outcome = fetchOne(epoch)
                    if (outcome != HomeFeedStreamPolicy.PAGE_OK && outcome != HomeFeedStreamPolicy.PAGE_RETRY) break
                }
            }
        } finally {
            inFlight -= 1
            if (inFlight == 0 && epoch == generation) _state.update { it.copy(loading = false) }
        }
    }

    /** Одна страница целиком: запрос, дедупликация, фильтры приватности, обновление состояния. */
    private suspend fun fetchOne(epoch: Int): Int {
        val pinned = profile ?: return HomeFeedStreamPolicy.PAGE_END
        val catalog = RemoteRuntime.registry.byId("dz")
        if (catalog == null) {
            // Каталог не настроен: ленты нет, и это не повод что-то писать. Про каталог скажет сама главная.
            _state.update { it.copy(more = false) }
            return HomeFeedStreamPolicy.PAGE_END
        }
        // Метаданные плееру не мешают. Ждём тишины не дольше AUDIO_GRACE_MS и идём в сеть в любом случае:
        // в 6.81.0 это ожидание было бесконечным и съедало бюджет запроса.
        withTimeoutOrNull(HomeFeedRefreshPolicy.AUDIO_GRACE_MS) { app.playerController.state.first { !it.isLoadingAudio } }
        var answered = false
        val page = try {
            withTimeoutOrNull(HomeFeedRefreshPolicy.RECO_TIMEOUT_MS) {
                catalog.recommendFeed(pinned, cursor, HomeFeedStreamPolicy.PAGE_SIZE).also { answered = true }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val limited = e is CatalogException && e.reason == CatalogException.Reason.RATE_LIMITED
            return fail(epoch, if (limited) "Каталог просит паузу. Нажми «Повторить»" else "Не удалось загрузить ленту. Нажми «Повторить»")
        }
        if (epoch != generation) return HomeFeedStreamPolicy.PAGE_END
        if (!answered) return fail(epoch, "Лента не успела загрузиться. Нажми «Повторить»")
        if (page == null) {
            // Сервер старше 1.15 или профиль пуст: ленты нет, это не ошибка.
            _state.update { it.copy(more = false) }
            return HomeFeedStreamPolicy.PAGE_END
        }
        page.cursor?.let { cursor = it }
        val now = System.currentTimeMillis()
        val room = HomeFeedStreamPolicy.roomLeft(_state.value.tracks.size)
        val fresh = page.tracks
            .filter { seen.offer(it.trackId, it.artist, it.title) }
            .map { it.toEntity(now) }
            .filter { it.id !in hiddenIds && CatalogPolicy.supports(it.provider, it.remoteId) }
            .take(room)
        val outcome = HomeFeedStreamPolicy.pageOutcome(fresh.size, page.more, emptyStreak)
        val capped = _state.value.tracks.size + fresh.size >= HomeFeedStreamPolicy.MAX_TRACKS
        _state.update {
            it.copy(
                tracks = if (fresh.isEmpty()) it.tracks else it.tracks + fresh,
                more = page.more && outcome != HomeFeedStreamPolicy.PAGE_END && !capped,
                stalled = outcome == HomeFeedStreamPolicy.PAGE_STALL,
                error = null
            )
        }
        if (outcome == HomeFeedStreamPolicy.PAGE_OK) emptyStreak = 0
        if (outcome == HomeFeedStreamPolicy.PAGE_RETRY) {
            emptyStreak += 1
            val wait = HomeFeedStreamPolicy.emptyPageDelayMs(page.retryMs)
            if (wait > 0L) delay(wait)
        }
        return outcome
    }

    private fun fail(epoch: Int, message: String): Int {
        if (epoch == generation) _state.update { it.copy(stalled = true, error = message) }
        return PAGE_ERROR
    }

    private companion object {
        const val RESTART_GAP_MS = 60_000L
        const val MAX_QUEUE_ROUNDS = 3
        const val PAGE_ERROR = -1
    }
}
