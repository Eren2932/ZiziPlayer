package app.ziziplayer.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.HomeFeedStreamPolicy
import app.ziziplayer.ui.RecoFeedState
import app.ziziplayer.ui.theme.LocalPalette

/**
 * 6.82.0. Лента «Для тебя»: треки подряд, подгружаются по мере прокрутки.
 *
 * Ключ строки — «reco-feed:индекс»: лента растёт только вперёд, индекс стабилен, а по ключу экран
 * узнаёт, до какой строки ленты человек доскроллил (HomeFeedStreamPolicy.indexOfKey).
 */
internal fun LazyListScope.homeRecoFeed(
    feed: RecoFeedState, currentTrackId: String?, unit: Float, sectionTop: Dp,
    onPlay: (Int) -> Unit, onMenu: (TrackEntity) -> Unit, onRetry: () -> Unit
) {
    val tracks = feed.tracks
    if (tracks.isEmpty() && !feed.stalled) return
    item(key = "reco-feed-heading", contentType = "reco-heading") {
        HomeHeading("Для тебя", Modifier.padding(top = sectionTop, bottom = 4.dp))
    }
    itemsIndexed(tracks, key = { index, _ -> HomeFeedStreamPolicy.keyOf(index) },
        contentType = { _, _ -> "reco-track" }) { index, track ->
        CollectionTrackRow(track, unit, track.id == currentTrackId,
            selected = false, picking = false,
            onPlay = { onPlay(index) }, onSelect = {},
            onLongPress = { onMenu(track) }, onMenu = { onMenu(track) }, horizontalInset = 0.dp)
    }
    if (feed.stalled) {
        item(key = "reco-feed-retry", contentType = "reco-retry") { FeedRetry(feed.error, onRetry) }
    } else if (feed.loading && tracks.isNotEmpty()) {
        item(key = "reco-feed-more", contentType = "reco-skeleton") { SkeletonRows(3) }
    }
}

/** Пока подборок ещё нет, на их месте скелетон, а не строка текста: экран сразу имеет форму. */
internal fun LazyListScope.homeFeedSkeleton(sectionTop: Dp) {
    item(key = "feed-skeleton", contentType = "feed-skeleton") {
        Column(Modifier.fillMaxWidth().padding(top = sectionTop)
            .semantics { contentDescription = "Загружаем подборки" }) {
            SkeletonBar(Modifier.fillMaxWidth(0.45f).height(20.dp))
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(3) { SkeletonBar(Modifier.weight(1f).height(108.dp)) }
            }
            SkeletonRows(3)
        }
    }
}

@Composable
private fun SkeletonRows(count: Int) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        repeat(count) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SkeletonBar(Modifier.size(52.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SkeletonBar(Modifier.fillMaxWidth(0.62f).height(14.dp))
                    SkeletonBar(Modifier.fillMaxWidth(0.34f).height(12.dp))
                }
            }
        }
    }
}

/** Пульсация идёт через infinite transition: она уважает системный масштаб анимаций, включая «выкл». */
@Composable
private fun SkeletonBar(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "feed-skeleton")
    val alpha by transition.animateFloat(
        initialValue = 0.10f, targetValue = 0.22f,
        animationSpec = infiniteRepeatable(animation = tween(900, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "feed-skeleton-alpha")
    Box(modifier.clip(RoundedCornerShape(6.dp)).background(LocalPalette.current.text.copy(alpha = alpha)))
}

@Composable
private fun FeedRetry(error: String?, onRetry: () -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!error.isNullOrEmpty()) Text(error, color = p.subtext, fontSize = 13.sp, lineHeight = 17.sp)
        TextButton(onClick = onRetry) { Text("Повторить", color = p.text) }
    }
}
