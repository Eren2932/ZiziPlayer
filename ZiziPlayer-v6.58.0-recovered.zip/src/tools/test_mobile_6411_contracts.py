#!/usr/bin/env python3
"""Source/asset contracts only, NOT Compose execution or an Android build."""
from pathlib import Path
import os
import re
import unittest
import xml.etree.ElementTree as ET
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(p): return (SRC / p).read_text()

class Mobile6411Contracts(unittest.TestCase):
    def test_second_surface_keeps_one_editor_and_fixed_field_geometry(self):
        s = read('ui/screens/SearchScreen.kt')
        self.assertEqual(len(re.findall(r'^\s+SearchField\(', s, re.M)), 1)
        self.assertNotIn('focusedSurface', s)
        self.assertNotIn('LaunchedEffect(focused', s)
        self.assertIn('onFocused = search::onFieldFocused', s)
        self.assertIn('.heightIn(min = 51.5.dp)', s)
        self.assertIn('fontSize = 14.sp', s)
        self.assertIn('modifier = Modifier.size(21.dp)', s)
    def test_focus_dismissal_observes_before_buttons_without_consuming(self):
        s = read('MainActivity.kt')
        observer = s.split('.pointerInput(focusManager, keyboard)')[1].split('// No wash')[0]
        self.assertIn('PointerEventPass.Initial', observer)
        self.assertIn('!bounds.contains(it.position)', observer)
        self.assertIn('clearFocus(force = true)', observer)
        self.assertNotIn('.consume()', observer)
        self.assertIn('onGloballyPositioned { focusRegion.bounds = it.boundsInRoot() }', read('ui/screens/SearchScreen.kt'))
    def test_capsule_targets_separate_and_named(self):
        s = read('ui/screens/LibraryScreen.kt').split('fun MiniPlayer(')[1].split('private fun MiniProgressLine')[0]
        self.assertIn('IconButton(onClick = vm::playPause, modifier = Modifier.size(48.dp))', s)
        self.assertIn('IconButton(onClick = vm::next, modifier = Modifier.size(48.dp))', s)
        self.assertIn('Spacer(Modifier.width(2.dp))', s)
        self.assertIn('"Следующий трек"', s)
        self.assertIn('.shadow(10.dp, CircleShape, clip = false)', s)
        self.assertNotIn('size = 25', s)
    def test_dock_overlay_has_smooth_58_percent_tint_and_scroll_insets(self):
        chrome = read('ui/components/TopChrome.kt').split('fun Modifier.bottomChrome')[1]
        self.assertIn('CollectionGeometry.scrimAlpha(t)', chrome)  # 6.42.0: zero-to-58% ramp
        self.assertIn('Brush.verticalGradient', chrome)
        self.assertIn('onDrawBehind', chrome)
        self.assertNotIn('graphicsLayer', chrome)
        host = read('MainActivity.kt')
        self.assertNotIn('if (!imeVisible) Column(', host)  # Dock stays mounted behind IME
        self.assertIn('.bottomChrome()', host)
        self.assertIn('.onSizeChanged { dockHeightPx = it.height }', host)
        self.assertIn('.imePadding()', host)
        for screen in ['SearchScreen.kt', 'LibraryScreen.kt', 'CollectionPageScreen.kt']:
            self.assertIn('bottom = LocalBottomChromeInset.current +', read('ui/screens/' + screen))
    def test_bundled_fonts_and_explicit_editing_styles(self):
        typography = read('ui/theme/ZiziTypography.kt')
        self.assertEqual(typography.count('copy(fontFamily = ZiziFontFamily)'), 15)
        self.assertEqual(len(list((ROOT / 'app/src/main/res/font').glob('*.ttf'))), 5)
        self.assertTrue((ROOT / 'app/src/main/assets/Roboto-OFL.txt').is_file())
        for path in SRC.rglob('*.kt'):
            s = path.read_text()
            if 'BasicTextField(' in s:
                for style in re.findall(r'TextStyle\(([^)]*)\)', s, re.S):
                    self.assertIn('fontFamily = ZiziFontFamily', style, path.name)
        self.assertNotIn('fontScale = 1', read('MainActivity.kt'))
    def test_force_dark_opt_out_and_no_new_microphone_permission(self):
        styles = ET.parse(ROOT / 'app/src/main/res/values/styles.xml')
        self.assertEqual(styles.find(".//item[@name='android:forceDarkAllowed']").text, 'false')
        self.assertIn('window.decorView.isForceDarkAllowed = false', read('MainActivity.kt'))
        manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text()
        self.assertNotIn('android.permission.RECORD_AUDIO', manifest)
    def test_decorative_badges_and_real_eq_are_separate(self):
        s = read('ui/components/Common.kt')
        self.assertNotIn('rememberInfiniteTransition', s)
        self.assertNotIn('infiniteRepeatable', s)
        self.assertNotIn('LocalAudioSpectrum.current', s)
        self.assertEqual(s.count('val phase = LocalPlaybackIndicatorPhase.current'), 2)
        self.assertIn('val spectrumState = LocalAudioSpectrum.current', read('ui/screens/EqualizerScreen.kt'))
        joined = '\n'.join(p.read_text() for p in SRC.rglob('*.kt'))
        self.assertEqual(joined.count('ZiziSpectrum.frame.collectAsStateWithLifecycle()'), 1)
        self.assertNotIn('setSpectrumListening(', joined)
    def test_pcm_neutral_path_is_byte_identical(self):
        s = read('playback/dsp/ZiziAudioProcessor.kt')
        self.assertIn('if (neutral && !listening)', s)
        neutral = s.split('if (neutral) {')[1].split('// ---- обратно ----')[0]
        self.assertIn('output.put(inputBuffer)', neutral)
        self.assertNotIn('putShort', neutral)
        self.assertNotIn('process(', neutral)
        self.assertIn('if (!neutral) dsp?.process(buf, frames)', s)
        self.assertIn('analyzer?.feed(buf, frames)', s)
    def test_lifecycle_and_playback_both_gate_meter(self):
        s = read('playback/dsp/ZiziSpectrum.kt')
        self.assertIn('uiVisible && playbackActive', s)
        self.assertIn('compareAndSet', s)
        self.assertIn('240_000_000L', s)
        service = read('playback/PlaybackService.kt')
        self.assertIn('ZiziSpectrum.setPlaybackActive(isPlaying)', service)
        self.assertIn('ZiziSpectrum.setPlaybackActive(false)', service)
        ui = read('ui/components/AudioSpectrum.kt')
        self.assertIn('lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED)', ui)
        self.assertIn('lifecycle.removeObserver(observer)', ui)
        self.assertIn('if (!playing) return@LaunchedEffect', ui)
    def test_build_identity(self):
        s = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionName = "6.58.0"', s)
        self.assertIn('versionCode = 109', s)
        self.assertIn('applicationId = "app.ziziplayer"', s)

if __name__ == '__main__': unittest.main(verbosity=2)
