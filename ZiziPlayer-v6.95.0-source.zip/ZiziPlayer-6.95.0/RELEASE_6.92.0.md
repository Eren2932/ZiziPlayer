# ZiziPlayer 6.92.0 (230) + сервер 1.28-import-rc1 (hotfix 1.28.1)

Порядок выкладки: **сначала сервер, потом клиент.** Контракт импорта остаётся `import_contract == 1`, клиент 6.91.0 работает с сервером 1.28.

## Почему первая выкладка 1.28 откатилась (HTTP 500)
Комплект был собран на сервере из архива 6.91.0, а там `zizi_import.py` ещё без исправления 1.27.2.
В нём `Request` импортировался только внутри `install_routes`, а в модуле стоит `from __future__ import annotations`.
FastAPI разворачивает такие аннотации через `globals()` модуля, имя не находилось, и `/openapi.json` отвечал 500
при здоровых `/health` и `/catalog/health`. Health-check деплоя дошёл до `/openapi.json`, увидел 500 и откатил.
Это тот же баг, что был в 1.27.0.

Исправление: `Request` импортируется на уровне модуля. Страж в `server/tools/test_import_128.py` (раздел 6)
проверяет это и исполнением (`typing.get_type_hints` на каждом обработчике), и по AST для всех серверных модулей.
Проверено: на коде без исправления страж краснеет, на исправленном зелёный.

Диагностика деплоя: при сбое `deploy_server.py` теперь печатает путь и тело ответа (`HTTP 500 на /openapi.json: ...`)
и ДО отката сохраняет хвост журнала службы в `<backup>/failure.log` с последней трассировкой.

## Сервер
1. `python3 server/tools/deploy_server.py` (проверка), затем `--apply`.
2. `python3 server/tools/probe_import_spotify.py`: какая ступень Spotify (pathfinder v2 / v1 / Web API / embed) ответила.
3. В `/catalog/health` смотреть `import.sources` и `import.sources_last`.

## Не проверено вживую (в Computer нет сети и нет настоящего FastAPI)
- Вывод про `/openapi.json` сделан по коду и по воспроизведению на заглушках, а не по журналу VPS.
  Подтверждение: `journalctl -u zizi-resolver` за время неудачной выкладки.
- Принимает ли pathfinder анонимный токен из embed, нужен ли `client-token`, жив ли хеш `queryPlaylist`.
- Разметка VK-плейлиста в WebView (проверено только на фальшивом DOM).
- Что `primaryClipDescription` не вызывает плашку Android.
- Kotlin здесь не компилируется: компиляцию подтвердит CI.
