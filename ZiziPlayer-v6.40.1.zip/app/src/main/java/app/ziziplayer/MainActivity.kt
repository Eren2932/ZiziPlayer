package app.ziziplayer

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadEvent
import app.ziziplayer.playback.DownloadEvents
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.playback.RemoteUri
import app.ziziplayer.share.PlaylistShare
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.SearchViewModel
import app.ziziplayer.ui.components.StatusBarTint
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ArtworkPrefetcher
import app.ziziplayer.ui.components.rememberArtSwatches
import app.ziziplayer.ui.components.ZiziTab
import app.ziziplayer.ui.components.ZiziTabBar
import app.ziziplayer.ui.screens.EqualizerScreen
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.MiniPlayer
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.screens.PlaylistImportSheet
import app.ziziplayer.ui.screens.SearchScreen
import app.ziziplayer.ui.theme.BackdropBlend
import app.ziziplayer.ui.theme.LocalBackdropBlend
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.SyncBackdropPalette
import app.ziziplayer.ui.theme.ZiziBackdrop
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.prefersDarkSystemIcons
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.launch

/** Метка «этот интент мы уже разобрали». Живёт в самом интенте, поэтому переживает поворот. */
private const val EXTRA_HANDLED = "app.ziziplayer.intent.handled"

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private val searchVm: SearchViewModel by viewModels()

    private var deleteTarget: TrackEntity? = null
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>

    /** Разрешение на чтение локальной музыки: с Android 13 оно точечное, до неё — общее. */
    private fun readAudioPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 6.40.1: only VaultAuthDialog owns a secure window. Folder configuration must
        // never disable screenshots or blank recents for the whole Activity.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // 6.17.0 — системные полосы больше не красятся сами.
        //
        // Прозрачность задана и в теме, но OEM-прошивки любят подставить свой «контрастный» скрим
        // под навбар и статус-бар: именно он и выглядел как чёрная плашка поверх нашего градиента.
        // Отключаем его явно; цвет иконок ставится в ZiziApp по светлоте гребня.
        @Suppress("DEPRECATION")
        run {
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        ArtworkCache.attach(this)

        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { vm.addFolder(it) }
        }
        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = deleteTarget
            deleteTarget = null
            if (result.resultCode == RESULT_OK && target != null) vm.onFileDeleted(target)
        }
        // 6.24.1: разрешения запрашиваются пачкой, потому что их стало три, и два из них нужны
        // именно загрузкам. Система показывает диалоги по очереди сама — два отдельных launcher'а
        // подряд, наоборот, гонятся друг с другом и второй молча теряется.
        val permissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
                if (granted[readAudioPermission()] == true) vm.rescan()
            }
        val wanted = buildList {
            add(readAudioPermission())
            // Без POST_NOTIFICATIONS уведомление загрузки на Android 13+ просто не появляется:
            // foreground-сервис живёт, процент идёт, а человек не видит ни прогресса, ни отмены.
            // Разрешение было объявлено в манифесте с 6.20.0 и ни разу не запрошено.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
            // До Android 10 запись в общую «Музыку» требует разрешения. 6.24.0 его ПРОВЕРЯЛА и
            // отказывалась качать, но никогда не просила — на Android 8 и 9 скачать было нельзя
            // вообще, и сделать с этим из приложения было нельзя ничего.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionLauncher.launch(wanted.toTypedArray())

        // 6.24.1: итог загрузки говорится вслух ровно один раз. Раньше он существовал только
        // подписью внутри меню трека — то есть исчезал вместе с закрытым меню, и «ничего не
        // произошло» было единственным, что видел человек.
        lifecycleScope.launch {
            DownloadEvents.stream.collect { event ->
                val text = when (event) {
                    is DownloadEvent.Saved ->
                        if (event.visible) "Сохранено: " + event.where
                        // Публичной папки прошивка не дала: файл есть и играет, но в «Музыке» его
                        // не будет. Честно сказать это сразу дешевле, чем поиски в проводнике.
                        else "Сохранено внутри приложения: " + event.where
                    is DownloadEvent.Failed -> event.title + " — " + event.reason
                }
                Toast.makeText(this@MainActivity, text, Toast.LENGTH_LONG).show()
            }
        }

        handleShareIntent(intent)

        setContent {
            val gate by vm.folderVault.state.collectAsStateWithLifecycle()
            androidx.compose.runtime.key(if (gate.folders.isEmpty()) "public" else vm.folderVault.uiSessionKey, gate.lockRevision) { ZiziApp(
                vm = vm,
                searchVm = searchVm,
                onPickFolder = { folderLauncher.launch(null) },
                onShare = ::shareTrack,
                onDeleteFile = ::deleteTrackFile,
                onExit = { finish() }
            ) }
        }
    }

    /**
     * Приложение уже живо, а нам прислали плейлист.
     *
     * `launchMode="singleTop"` в манифесте гарантирует, что мы попадём сюда, а не создадим вторую
     * копию экрана. `setIntent` обязателен: без него `getIntent()` до конца жизни активити
     * возвращает тот интент, с которым её запустили в самый первый раз.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    /**
     * Разбирает, принесли ли нам плейлист, и в каком виде: ссылкой, файлом или текстом.
     *
     * Интент помечается как обработанный. Без метки поворот экрана или возврат приложения из фона
     * заново открывал бы предпросмотр импорта того же плейлиста — с точки зрения человека
     * приложение просто «липнет» к одному и тому же чужому плейлисту и не даёт от него уйти.
     */
    private fun handleShareIntent(intent: Intent?) {
        if (intent == null || intent.getBooleanExtra(EXTRA_HANDLED, false)) return
        val data = intent.data
        val handled = when {
            intent.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true -> {
                vm.offerImport(intent.getStringExtra(Intent.EXTRA_TEXT)); true
            }
            intent.action != Intent.ACTION_VIEW || data == null -> false
            data.scheme == PlaylistShare.URI_SCHEME -> {
                vm.offerImport(data.toString()); true
            }
            else -> {
                vm.offerImportFile(data); true
            }
        }
        if (handled) intent.putExtra(EXTRA_HANDLED, true)
    }

    /** No position polling and no artwork work at all while the UI is off screen. */
    override fun onStart() {
        super.onStart()
        vm.setUiActive(true)
        // The composition survives backgrounding, so cover indexing has to be woken up by hand.
        ArtworkPrefetcher.resume()
    }

    override fun onStop() {
        app.ziziplayer.privacy.FolderVault.get(this).lock()
        vm.setUiActive(false)
        vm.savePosition()
        // Nothing may keep parsing audio files once the UI is gone.
        ArtworkPrefetcher.stop()
        ArtworkCache.flushIndex()
        super.onStop()
    }

    /**
     * 6.19.0: сетевой трек отправляется текстом, а не как файл.
     *
     * У сетевого трека в `uri` лежит `zizi://<источник>/<id>` — наша внутренняя схема, которую не
     * понимает ни одно приложение на телефоне. Отправка её в EXTRA_STREAM с MIME-типом audio выглядела
     * для человека так: выбрал мессенджер, получил либо пустое вложение, либо ошибку от
     * мессенджера, и ни малейшего намёка на причину. Файла не существует — отдавать нечего, и
     * честнее отдать то, что действительно есть: название и исполнителя.
     */
    private fun shareTrack(track: TrackEntity) {
        if (vm.folderVault.state.value.blocks(track)) return
        // 1. Скачанный сетевой трек — теперь это НАСТОЯЩИЙ файл в «Музыка/Zizi», и уходит он
        //    вложением. Ровно то, чего ждёт человек, нажимая «поделиться» у скачанного трека:
        //    до 6.24.0 файла не существовало (байты лежали фрагментами внутри кэша), поэтому
        //    отправлялся текст — и это выглядело как «приложение не умеет отправлять музыку».
        val downloaded = OfflineStore.shareTarget(this, track)
        val intent = when {
            downloaded != null -> Intent(Intent.ACTION_SEND).apply {
                val (uri, mime) = downloaded
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, track.title)
                // clipData вместе с EXTRA_STREAM: часть приложений (в том числе несколько
                // мессенджеров) читает разрешение на чтение именно оттуда, и без него получает
                // SecurityException уже у себя — снаружи это «отправилось пустое вложение».
                clipData = ClipData.newUri(contentResolver, track.title, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            // 2. Сетевой и не скачанный: в `uri` лежит `zizi://<источник>/<id>` — наша внутренняя
            //    схема, которую не понимает ни одно приложение на телефоне. Отдавать её как
            //    вложение значит отдать пустоту, поэтому уходит то, что действительно есть.
            RemoteUri.isRemote(track.uri) -> Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "${track.artist} — ${track.title}")
                putExtra(Intent.EXTRA_SUBJECT, track.title)
            }
            // 3. Свой файл из медиатеки — как было.
            else -> Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                val uri = Uri.parse(track.uri)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(contentResolver, track.title, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        runCatching { startActivity(Intent.createChooser(intent, track.title)) }
    }

    private fun deleteTrackFile(track: TrackEntity) {
        if (vm.folderVault.state.value.blocks(track)) return
        vm.requestDeleteFile(track) { sender ->
            if (sender == null) return@requestDeleteFile
            deleteTarget = track
            runCatching { deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
        }
    }
}

@Composable
private fun ZiziApp(
    vm: MainViewModel,
    searchVm: SearchViewModel,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit,
    onExit: () -> Unit
) {
    val rawLibrary by vm.library.collectAsStateWithLifecycle()
    val vaultGate by vm.folderVault.state.collectAsStateWithLifecycle()
    // StateFlow pipelines may deliver their database projections one frame after a lock.
    // Apply the gate synchronously at the render boundary as well.
    val library = remember(rawLibrary, vaultGate) {
        if (vaultGate.unlocked || vaultGate.folders.isEmpty()) rawLibrary else {
            val allowed = rawLibrary.tracks.filterNot(vaultGate::blocks)
            val allowedArtists = allowed.mapTo(HashSet()) { it.artist }
            val blockedIds = rawLibrary.tracks.filter(vaultGate::blocks).mapTo(HashSet()) { it.id }
            rawLibrary.copy(
                tracks = allowed,
                visible = rawLibrary.visible.filterNot(vaultGate::blocks),
                favoriteIds = rawLibrary.favoriteIds - blockedIds,
                playlistMeta = rawLibrary.playlistMeta.mapValues { (_, meta) -> meta.copy(cover = meta.cover?.takeUnless(vaultGate::blocks)) },
                folders = rawLibrary.folders.filterNot { it.name in vaultGate.folders },
                artists = rawLibrary.artists.filter { it.name in allowedArtists }.map { it.copy(cover = it.cover?.takeUnless(vaultGate::blocks)) },
                openFolder = rawLibrary.openFolder?.takeUnless { it in vaultGate.folders },
                openArtist = rawLibrary.openArtist?.takeIf { it in allowedArtists }
            )
        }
    }
    val playback by vm.playback.collectAsStateWithLifecycle()
    val rawCurrent by vm.currentTrack.collectAsStateWithLifecycle()
    val current = rawCurrent?.takeUnless(vaultGate::blocks)
    val search by searchVm.state.collectAsStateWithLifecycle()
    val pendingImport by vm.import.collectAsStateWithLifecycle()
    val savedRemoteIds by searchVm.savedIds.collectAsStateWithLifecycle()

    /**
     * The artists the hub offers as starting points.
     *
     * Local rows only, most-frequent first, and recomputed only when the library's SIZE changes -
     * not on every emission. The list flow re-emits on a favourite toggle and on every play count
     * bump, and grouping 3000 rows on the main thread each time would be a stutter you could feel
     * in the tab bar. Sixteen names is two screens of tiles; nobody scrolls further for a seed.
     */
    val seeds = remember(library.tracks.size) {
        library.tracks.asSequence()
            .filter { !it.isRemote }
            .map { it.artist.trim() }
            .filter { it.isNotEmpty() && !it.equals("<unknown>", ignoreCase = true) }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(16)
            .map { it.key }
    }

    // Three cover shades drive the whole app: one hue, one chroma level, one brightness. They
    // only change when the track changes.
    val swatches = rememberArtSwatches(current, library.settings.accentFromArtwork)
    val palette = remember(swatches) {
        basePalette().tintedWith(swatches).withAccent(swatches)
    }

    // Цвет часов и батареи следует за обложкой, а не за строкой в styles.xml.
    val view = LocalView.current
    val darkSystemIcons = palette.prefersDarkSystemIcons()
    LaunchedEffect(darkSystemIcons, view) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        // The fixed tint layer keeps the status bar dark, even during a cover transition.
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = darkSystemIcons
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(vm) {
        vm.messages.collect { message ->
            val result = snackbar.showSnackbar(
                message = message.text,
                actionLabel = message.actionLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) message.action?.invoke()
        }
    }

    // One blend per process, shared by both backdrops: the library's and the player's ramps stay
    // on the same colour, so sliding the player down never crosses a seam.
    val blend = remember { BackdropBlend(palette) }
    SyncBackdropPalette(blend, palette, current?.id ?: playback.currentTrackId, playback.currentTrackId)

    CompositionLocalProvider(LocalPalette provides palette, LocalBackdropBlend provides blend) {
        ZiziTheme(palette) {
            // Saveable, same reasoning as `tab` below: a process death while the player sheet was
            // open used to land the user on the library with the music still playing.
            var playerOpen by rememberSaveable { mutableStateOf(false) }
            /**
             * 6.24.4. Эквалайзер живёт ЗДЕСЬ, а не внутри PlayerScreen, хотя открывается оттуда.
             *
             * Причина ровно одна и она про кнопку «назад». BackHandler'ы складываются в стек
             * диспетчера, и выигрывает добавленный последним; корневой обработчик этого экрана
             * добавляется после всего, что нарисовано выше, поэтому «назад» из эквалайзера,
             * объявленного внутри плеера, закрыл бы ПЛЕЕР, а эквалайзер остался бы висеть поверх
             * медиатеки. Один стек навигации на приложение, одна ветка в одном обработчике —
             * и ошибиться негде.
             */
            var eqOpen by rememberSaveable { mutableStateOf(false) }
            // Saveable: a rotation or a process death that lands the user back on the library
            // after they had opened search is a small betrayal, and it costs one Parcelable int.
            var tab by rememberSaveable { mutableStateOf(ZiziTab.LIBRARY) }
            var screenHeight by remember { mutableFloatStateOf(0f) }
            val slide = remember { Animatable(0f) }
            var mounted by remember { mutableStateOf(false) }
            // Read inside the draw phase only, so toggling it costs no recomposition.
            val libraryDrawn = remember { mutableStateOf(true) }

            LaunchedEffect(playerOpen, screenHeight) {
                if (screenHeight <= 0f) return@LaunchedEffect
                if (playerOpen) {
                    if (!mounted) { slide.snapTo(screenHeight); mounted = true }
                    libraryDrawn.value = true
                    slide.animateTo(0f, spring(dampingRatio = 0.88f, stiffness = Spring.StiffnessMediumLow))
                    // Fully covered: stop drawing the library underneath.
                    if (slide.value == 0f) libraryDrawn.value = false
                } else if (mounted) {
                    libraryDrawn.value = true
                    slide.animateTo(screenHeight, tween(210, easing = FastOutLinearInEasing))
                    mounted = false
                }
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { screenHeight = it.height.toFloat() }
            ) {
                // No wash, no halo: the crest at y = 0.20 carries the cover's colour on its own.
                ZiziBackdrop(palette)

                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent { if (libraryDrawn.value) drawContent() }
                ) {
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f)) {
                            // Both destinations stay in the composition; only one is shown.
                            //
                            // A `when` that swaps them would throw away the library's scroll
                            // position, its drill-down and its cover cache every time the user
                            // glances at search - and would restart the hub request every time
                            // they come back. Keeping both alive costs two LazyLists worth of
                            // state and buys instant, lossless tab switching.
                            if (tab == ZiziTab.LIBRARY) {
                                LibraryScreen(
                                    vm = vm,
                                    state = library,
                                    playback = playback,
                                    currentTrack = current,
                                    onOpenPlayer = { playerOpen = true },
                                    onPickFolder = onPickFolder,
                                    onShare = onShare,
                                    onDeleteFile = onDeleteFile,
                                    onOpenEqualizer = { eqOpen = true }
                                )
                            } else {
                                Column(Modifier.fillMaxSize().then(
                                    if (search.collection == null) Modifier.statusBarsPadding() else Modifier
                                )) {
                                    SearchScreen(
                                        vm = vm,
                                        search = searchVm,
                                        state = search,
                                        savedIds = savedRemoteIds,
                                        currentTrackId = playback.currentTrackId,
                                        isPlaying = playback.isPlaying,
                                        seeds = seeds
                                    )
                                }
                            }
                        }

                        current?.let { track ->
                            MiniPlayer(
                                vm = vm,
                                track = track,
                                isPlaying = playback.isPlaying,
                                onOpen = { playerOpen = true }
                            )
                        }
                        ZiziTabBar(current = tab, onPick = { tab = it })
                        Spacer(Modifier.navigationBarsPadding())
                    }
                }

                if (mounted) {
                    val dragState = rememberDraggableState { delta ->
                        scope.launch { slide.snapTo((slide.value + delta).coerceIn(0f, screenHeight)) }
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer { translationY = slide.value }
                            .draggable(
                                state = dragState,
                                orientation = Orientation.Vertical,
                                onDragStarted = { libraryDrawn.value = true },
                                onDragStopped = { velocity ->
                                    val shouldClose = slide.value > screenHeight * 0.16f || velocity > 1400f
                                    if (shouldClose) playerOpen = false
                                    else {
                                        slide.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium))
                                        if (slide.value == 0f) libraryDrawn.value = false
                                    }
                                }
                            )
                    ) {
                        ZiziBackdrop(palette)
                        PlayerScreen(
                            vm = vm,
                            state = library,
                            playback = playback,
                            currentTrack = current,
                            onClose = { playerOpen = false },
                            onOpenEqualizer = { eqOpen = true },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    }
                }

                // Поверх всего, включая плеер: эквалайзер открывается из него и обязан его
                // перекрыть, иначе жест закрытия плеера ловится сквозь экран настройки звука.
                if (eqOpen) {
                    Box(Modifier.fillMaxSize()) {
                        ZiziBackdrop(palette)
                        EqualizerScreen(vm = vm, onClose = { eqOpen = false })
                    }
                }

                // Fixed window layer: never moves with the player sheet or future lyrics.
                StatusBarTint(Modifier.align(Alignment.TopCenter))

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 84.dp)
                )
            }

            // Предпросмотр импорта живёт здесь, а не в медиатеке: плейлист может прийти из
            // мессенджера в любой момент, в том числе когда открыт плеер или поиск.
            pendingImport?.let { PlaylistImportSheet(vm, it) { vm.cancelImport() } }

            // Single back path: player -> drill-down -> app exit. The system side swipe follows it too.
            BackHandler(enabled = true) {
                when {
                    eqOpen -> eqOpen = false
                    playerOpen -> playerOpen = false
                    // Inside search, back unwinds the section's own stack first (collection ->
                    // results -> hub) and only then leaves the tab. Dropping straight to the
                    // library from a result list is the behaviour every user reads as a bug.
                    tab == ZiziTab.SEARCH && searchVm.back() -> Unit
                    tab == ZiziTab.SEARCH -> tab = ZiziTab.LIBRARY
                    vm.handleBack() -> Unit
                    else -> onExit()
                }
            }
        }
    }
}
