package app.ziziplayer.privacy;

/** Platform-free gesture state; only the top-of-list nested-scroll remainder enters pull(). */
public final class VaultPullPolicy {
    private final float threshold;
    private float distance;
    private boolean dragging, buzzed, haptic, swallowFling;
    public VaultPullPolicy(float threshold) {
        if (!(threshold > 0f) || !Float.isFinite(threshold)) throw new IllegalArgumentException();
        this.threshold = threshold;
    }
    public float getDistance() { return distance; }
    public boolean isDragging() { return dragging; }
    public void begin() { cancel(); dragging = true; }
    public float pull(float remainder) {
        if (!dragging || remainder <= 0f || !Float.isFinite(remainder)) return 0f;
        distance = Math.min(threshold * 1.55f, distance + remainder * 0.55f);
        if (distance >= threshold && !buzzed) { buzzed = true; haptic = true; }
        return remainder;
    }
    public float retract(float delta) {
        if (!dragging || distance <= 0f || delta >= 0f || !Float.isFinite(delta)) return 0f;
        float used = Math.max(delta, -distance / 0.55f);
        distance = Math.max(0f, distance + used * 0.55f);
        return used;
    }
    public boolean takeHaptic() { boolean value = haptic; haptic = false; return value; }
    public boolean release() {
        if (!dragging) return false;
        boolean open = distance >= threshold;
        swallowFling = distance > 0f;
        distance = 0f; dragging = false; buzzed = false; haptic = false;
        return open;
    }
    public boolean consumeFling() {
        // A child may enter onPreFling before/after the observer sees the final up event.
        boolean value = swallowFling || distance > 0f;
        swallowFling = false;
        return value;
    }
    public void cancel() { distance = 0f; dragging = false; buzzed = false; haptic = false; swallowFling = false; }
}
