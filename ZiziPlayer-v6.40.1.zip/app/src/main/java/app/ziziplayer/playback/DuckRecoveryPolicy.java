package app.ziziplayer.playback;

/** Event-driven recovery during a CAN_DUCK focus lease. No waveform/speech detection. */
public final class DuckRecoveryPolicy {
    public static final int HOLD = 0, DUCK = 1, RESTORE = 2;
    public static final long QUIET_MS = 240L;
    private boolean watching, sawCompetitor, attenuated;
    private long quietSince = -1L;
    public void begin() { watching = true; sawCompetitor = false; attenuated = true; quietSince = -1L; }
    public void cancel() { watching = false; sawCompetitor = false; attenuated = false; quietSince = -1L; }
    public boolean isWatching() { return watching; }
    public int observe(int competitors, long now) {
        if (!watching) return HOLD;
        if (competitors < 0) { quietSince = -1L; return HOLD; }
        if (competitors > 0) {
            sawCompetitor = true; quietSince = -1L;
            if (!attenuated) { attenuated = true; return DUCK; }
            return HOLD;
        }
        // If Android never exposed the competing player, absence is not proof of its stop.
        if (!sawCompetitor || !attenuated) return HOLD;
        if (quietSince < 0L || now < quietSince) quietSince = now;
        if (now - quietSince < QUIET_MS) return HOLD;
        attenuated = false; quietSince = -1L;
        return RESTORE;
    }
    /** Schedule one confirmation, not a forever-running volume watchdog. */
    public long confirmationDelay(long now) {
        return watching && attenuated && quietSince >= 0L
                ? Math.max(1L, QUIET_MS - Math.max(0L, now - quietSince)) : -1L;
    }
    /** Public Android configurations are anonymous. Account for exactly one own MEDIA/MUSIC
     * player only while ExoPlayer really plays and at least one such configuration is visible.
     * Unknown/missing observations and call mode never justify raising volume.
     */
    public static int competitors(boolean ownPlaying, boolean normalMode, int total, int mediaMusic) {
        if (!ownPlaying || !normalMode || total < 1 || mediaMusic < 1 || mediaMusic > total) return -1;
        return total - 1;
    }
}
