package app.ziziplayer.playback

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Handler
import android.os.SystemClock
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

/** Single focus owner. Anonymous playback activity supplements, never steals, audio focus.
 * This observes started/stopped players, NOT foreign PCM, package names or speech silence.
 */
@UnstableApi
class FocusPlayer(
    context: Context,
    private val engine: ExoPlayer,
    private val mayPlay: (MediaItem) -> Boolean
) : ForwardingPlayer(engine) {
    private val audio = requireNotNull(context.getSystemService(AudioManager::class.java))
    private val handler = Handler(engine.applicationLooper)
    private var request: AudioFocusRequest? = null
    private var generation = 0
    private val policy = AudioInterruptionPolicy()
    private var baseVolume = engine.volume
    private var gain = 1f
    private var ramp: Runnable? = null
    private var released = false
    private val recovery = DuckRecoveryPolicy()
    private var playbackObserverRegistered = false
    private val confirmQuiet = Runnable { samplePlaybackActivity() }
    private val playbackObserver = object : AudioManager.AudioPlaybackCallback() {
        override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
            // Re-read the current snapshot: an in-flight callback from an old duck lease must
            // not act on its old list after a new lease has started.
            samplePlaybackActivity()
        }
    }

    private fun stopDuckMonitoring() {
        recovery.cancel()
        handler.removeCallbacks(confirmQuiet)
        if (playbackObserverRegistered) {
            playbackObserverRegistered = false
            runCatching { audio.unregisterAudioPlaybackCallback(playbackObserver) }
        }
    }
    private fun startDuckMonitoring() {
        stopDuckMonitoring()
        recovery.begin()
        playbackObserverRegistered = runCatching {
            audio.registerAudioPlaybackCallback(playbackObserver, handler)
            true
        }.getOrDefault(false)
        // Unsupported/denied monitoring falls back to the normal audio-focus policy.
        if (playbackObserverRegistered) samplePlaybackActivity() else recovery.cancel()
    }
    private fun samplePlaybackActivity() {
        if (released || !playbackObserverRegistered || !recovery.isWatching) return
        handler.removeCallbacks(confirmQuiet)
        val competitors = runCatching {
            // Without privileged permissions this API returns only active, anonymized players.
            // Do NOT use hidden isActive/clientUid/sessionId methods or assume package identity.
            val configs = audio.activePlaybackConfigurations
            val ownCandidates = configs.count {
                it.audioAttributes.usage == android.media.AudioAttributes.USAGE_MEDIA &&
                    it.audioAttributes.contentType == android.media.AudioAttributes.CONTENT_TYPE_MUSIC
            }
            DuckRecoveryPolicy.competitors(engine.isPlaying, audio.mode == AudioManager.MODE_NORMAL,
                configs.size, ownCandidates)
        }.getOrDefault(-1)
        val now = SystemClock.uptimeMillis()
        when (recovery.observe(competitors, now)) {
            DuckRecoveryPolicy.DUCK -> fade(AudioInterruptionPolicy.DUCK_GAIN, AudioInterruptionPolicy.ATTACK_MS)
            DuckRecoveryPolicy.RESTORE -> fade(1f, AudioInterruptionPolicy.RELEASE_MS)
        }
        val delay = recovery.confirmationDelay(now)
        if (delay >= 0) handler.postDelayed(confirmQuiet, delay)
    }

    init {
        engine.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { samplePlaybackActivity() }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) abandon()
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady && (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY ||
                    reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM)) abandon()
            }
        })
    }
    private fun fade(target: Float, duration: Long) {
        ramp?.let(handler::removeCallbacks)
        val startGain = gain
        val start = SystemClock.uptimeMillis()
        val task = object : Runnable {
            override fun run() {
                if (released) return
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / duration).coerceIn(0f, 1f)
                gain = AudioInterruptionPolicy.interpolate(startGain, target, t)
                engine.volume = baseVolume * gain
                if (t < 1f) handler.postDelayed(this, 16) else ramp = null
            }
        }
        ramp = task
        handler.post(task)
    }
    private fun resetGain() {
        ramp?.let(handler::removeCallbacks); ramp = null
        gain = 1f
        if (!released) engine.volume = baseVolume
    }
    private fun abandon() {
        stopDuckMonitoring()
        generation++
        policy.cancel()
        request?.let { audio.abandonAudioFocusRequest(it) }
        request = null
        resetGain()
    }
    private fun acquire(): Boolean {
        // Explicit play while transiently interrupted is a fresh user request, not a stale gain.
        if (request != null && !policy.isResumePending) return true
        abandon()
        val epoch = ++generation
        val next = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build())
            // API 26+ otherwise ducks automatically without delivering CAN_DUCK to the app.
            .setWillPauseWhenDucked(true)
            .setAcceptsDelayedFocusGain(false)
            .setOnAudioFocusChangeListener({ change -> if (epoch == generation && !released) focusChanged(change) }, handler)
            .build()
        val result = runCatching { audio.requestAudioFocus(next) }.getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            audio.abandonAudioFocusRequest(next)
            return false
        }
        request = next
        return true
    }
    private fun focusChanged(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { engine.pause(); abandon() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                stopDuckMonitoring()
                policy.transientLoss(engine.playWhenReady)
                engine.pause()
                resetGain()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (engine.playWhenReady) {
                    fade(AudioInterruptionPolicy.DUCK_GAIN, AudioInterruptionPolicy.ATTACK_MS)
                    startDuckMonitoring()
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                stopDuckMonitoring()
                if (policy.gain()) {
                    gain = AudioInterruptionPolicy.DUCK_GAIN; engine.volume = baseVolume * gain
                    engine.play()
                }
                fade(1f, AudioInterruptionPolicy.RELEASE_MS)
            }
        }
    }
    override fun play() { setPlayWhenReady(true) }
    override fun pause() { setPlayWhenReady(false) }
    override fun setPlayWhenReady(playWhenReady: Boolean) {
        if (playWhenReady) {
            // Futures from session validation can complete before a lock but apply after it.
            // Check again at the actual player mutation/play boundary, without database I/O.
            if (released || engine.mediaItemCount == 0) return
            if (engine.currentMediaItem?.let { !mayPlay(it) } == true) { pause(); return }
            if (acquire()) engine.play() else engine.pause()
        } else {
            engine.pause()
            abandon()
        }
    }
    override fun setMediaItems(mediaItems: List<MediaItem>, startIndex: Int, startPositionMs: Long) {
        val requested = mediaItems.getOrNull(startIndex.coerceAtLeast(0))
        if (requested != null && !mayPlay(requested)) { pause(); engine.clearMediaItems(); return }
        val safe = mediaItems.filter(mayPlay)
        if (safe.isEmpty()) { pause(); engine.clearMediaItems(); return }
        val index = mediaItems.take(startIndex.coerceAtLeast(0)).count(mayPlay).coerceIn(safe.indices)
        engine.setMediaItems(safe, index, startPositionMs)
    }
    override fun setMediaItems(mediaItems: List<MediaItem>) { setMediaItems(mediaItems, 0, 0L) }
    override fun setMediaItems(mediaItems: List<MediaItem>, resetPosition: Boolean) {
        val index = if (resetPosition) 0 else mediaItems.indexOfFirst { it.mediaId == engine.currentMediaItem?.mediaId }.coerceAtLeast(0)
        setMediaItems(mediaItems, index, if (resetPosition) 0L else engine.currentPosition)
    }
    override fun setMediaItem(mediaItem: MediaItem) { setMediaItems(listOf(mediaItem), 0, 0L) }
    override fun setMediaItem(mediaItem: MediaItem, startPositionMs: Long) { setMediaItems(listOf(mediaItem), 0, startPositionMs) }
    override fun setMediaItem(mediaItem: MediaItem, resetPosition: Boolean) { setMediaItems(listOf(mediaItem), resetPosition) }
    override fun addMediaItems(index: Int, mediaItems: List<MediaItem>) { engine.addMediaItems(index, mediaItems.filter(mayPlay)) }
    override fun addMediaItems(mediaItems: List<MediaItem>) { addMediaItems(engine.mediaItemCount, mediaItems) }
    override fun addMediaItem(index: Int, mediaItem: MediaItem) { addMediaItems(index, listOf(mediaItem)) }
    override fun addMediaItem(mediaItem: MediaItem) { addMediaItems(listOf(mediaItem)) }
    override fun replaceMediaItems(fromIndex: Int, toIndex: Int, mediaItems: List<MediaItem>) {
        engine.replaceMediaItems(fromIndex, toIndex, mediaItems.filter(mayPlay))
    }
    override fun replaceMediaItem(index: Int, mediaItem: MediaItem) { replaceMediaItems(index, index + 1, listOf(mediaItem)) }
    override fun stop() { engine.stop(); abandon() }
    override fun setVolume(volume: Float) {
        baseVolume = volume.coerceIn(0f, 1f)
        engine.volume = baseVolume * gain
    }
    override fun getVolume(): Float = baseVolume
    override fun release() { abandon(); released = true; engine.release() }
}
