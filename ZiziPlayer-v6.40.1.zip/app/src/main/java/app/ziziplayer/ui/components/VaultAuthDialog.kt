package app.ziziplayer.ui.components

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.password
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.ziziplayer.privacy.FolderVault
import app.ziziplayer.privacy.PatternPath
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activity()
    else -> null
}

/** No DEVICE_CREDENTIAL fallback: the digits below verify the Zizi key, never the phone PIN. */
private fun canUseBiometrics(context: Context): Boolean = runCatching {
    when {
        Build.VERSION.SDK_INT >= 30 -> context.getSystemService(BiometricManager::class.java)
            ?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        Build.VERSION.SDK_INT >= 29 -> {
            @Suppress("DEPRECATION")
            val result = context.getSystemService(BiometricManager::class.java)?.canAuthenticate()
            result == BiometricManager.BIOMETRIC_SUCCESS
        }
        Build.VERSION.SDK_INT == 28 -> context.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT) &&
            context.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true
        else -> false // API 26–27 retain the existing Zizi PIN / pattern, without a duplicate phone-code button.
    }
}.getOrDefault(false)

@Composable
fun VaultAuthDialog(vault: FolderVault, onSuccess: () -> Unit, onDismiss: () -> Unit) {
    val setup = remember(vault) { !vault.configured }
    var pattern by remember { mutableStateOf(vault.pattern) }
    var input by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var biometricActive by remember { mutableStateOf(false) }
    var retrySeconds by remember { mutableLongStateOf(vault.remainingSeconds()) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = context.activity()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val biometricAvailable = remember(context) { canUseBiometrics(context) }
    val success by rememberUpdatedState(onSuccess)
    val dismiss by rememberUpdatedState(onDismiss)
    var cancellation by remember { mutableStateOf<CancellationSignal?>(null) }
    var live by remember { mutableStateOf(true) }
    var authEpoch by remember { mutableIntStateOf(0) }
    fun active() = live && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
    fun cancelAuthentication() {
        live = false; authEpoch++
        cancellation?.cancel(); cancellation = null
        input = ""; first = null
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                // No saved PIN and no late biometric callback can unlock a background Activity.
                cancelAuthentication(); dismiss()
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); cancelAuthentication() }
    }
    LaunchedEffect(retrySeconds) {
        if (retrySeconds > 0) { delay(1_000); retrySeconds = vault.remainingSeconds() }
    }
    fun submit() {
        if (busy || biometricActive || !active() || retrySeconds > 0) return
        val valid = if (pattern) input.length in 4..9 else input.length in 6..12
        if (!valid) { error = if (pattern) "Соедини минимум 4 точки" else "PIN: от 6 до 12 цифр"; return }
        if (setup && first == null) { first = input; input = ""; error = null; return }
        if (setup && first != input) { first = null; input = ""; error = "Не совпало. Задай ключ заново"; return }
        val secret = input
        input = ""; error = null; busy = true
        scope.launch {
            try {
                if (setup) { vault.configure(secret, pattern); if (active()) success() }
                else if (vault.verify(secret)) {
                    if (active()) success() else vault.lock()
                } else {
                    retrySeconds = vault.remainingSeconds()
                    error = if (retrySeconds == 0L) "Неверный ключ. Попробуй ещё раз" else null
                }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (_: Exception) { if (live) error = "Не удалось проверить или сохранить ключ. Попробуй снова" }
            finally { busy = false }
        }
    }
    fun biometric() {
        if (Build.VERSION.SDK_INT < 28 || activity == null || setup || busy || biometricActive || !active()) return
        val epoch = ++authEpoch
        input = ""; error = null; biometricActive = true
        val signal = CancellationSignal(); cancellation = signal
        try {
            val builder = BiometricPrompt.Builder(activity)
                .setTitle("Скрытые папки Zizi")
                .setSubtitle("Подтверди доступ биометрией устройства")
                .setNegativeButton(if (pattern) "Ввести рисунок Zizi" else "Ввести PIN Zizi", activity.mainExecutor) { _, _ ->
                    if (live && epoch == authEpoch) { biometricActive = false; cancellation = null }
                }
            if (Build.VERSION.SDK_INT >= 30) builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            builder.build().authenticate(signal, activity.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    if (active() && epoch == authEpoch && biometricActive) {
                        biometricActive = false; cancellation = null
                        vault.unlockWithDevice(); success()
                    }
                }
                override fun onAuthenticationError(code: Int, message: CharSequence) {
                    if (live && epoch == authEpoch) {
                        biometricActive = false; cancellation = null
                        error = "Биометрия закрыта или недоступна. Используй ключ Zizi"
                    }
                }
                override fun onAuthenticationFailed() {
                    // A rejected finger is not success; Android keeps its own prompt open.
                }
            })
        } catch (_: Exception) {
            biometricActive = false; cancellation = null
            error = "Биометрия недоступна. Используй ключ Zizi"
        }
    }
    val p = LocalPalette.current
    val enabled = !busy && !biometricActive && retrySeconds == 0L
    val maxHeight = (LocalConfiguration.current.screenHeightDp - 48).coerceAtLeast(160).dp
    Dialog(
        onDismissRequest = { if (!busy) { cancelAuthentication(); dismiss() } },
        properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn, usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.padding(horizontal = 20.dp, vertical = 12.dp).widthIn(max = 360.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp), color = p.surface, tonalElevation = 6.dp) {
            Column(Modifier.heightIn(max = maxHeight).verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (setup) (if (first == null) "Защита папок" else "Повтори ключ") else "Скрытые папки",
                    color = p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(if (setup) "Ключ Zizi защищает доступ в приложении, но не шифрует файлы. Запомни его: восстановления нет."
                    else if (pattern) "Введи графический ключ Zizi" else "Введи PIN Zizi",
                    color = p.subtext, fontSize = 13.sp, textAlign = TextAlign.Center)
                if (setup && first == null) Row {
                    TextButton(enabled = enabled, onClick = { pattern = false; input = ""; error = null }) {
                        Text(if (!pattern) "✓ PIN" else "PIN", color = p.brand)
                    }
                    TextButton(enabled = enabled, onClick = { pattern = true; input = ""; error = null }) {
                        Text(if (pattern) "✓ Рисунок" else "Рисунок", color = p.brand)
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (pattern) {
                    Box(Modifier.widthIn(max = 272.dp)) { PatternPad(input, enabled, { input = it; error = null }, p.brand) }
                    TextButton(enabled = enabled, onClick = { input = "" }) { Text("Очистить рисунок", color = p.brand) }
                } else {
                    PinPad(input, enabled, onChange = { input = it; error = null })
                }
                if (retrySeconds > 0) Text("Повтори через $retrySeconds с", color = p.brand, textAlign = TextAlign.Center)
                error?.let { Text(it, color = p.brand, textAlign = TextAlign.Center) }
                Spacer(Modifier.height(12.dp))
                Button(onClick = ::submit, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = p.brand, contentColor = p.onBrand)) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = p.onBrand, strokeWidth = 2.dp)
                    else Text(if (setup && first == null) "Далее" else if (setup) "Сохранить ключ" else "Открыть")
                }
                if (!setup && biometricAvailable && activity != null) {
                    TextButton(enabled = !busy && !biometricActive, onClick = ::biometric, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Fingerprint, null, tint = p.brand, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp)); Text("Биометрия", color = p.brand)
                    }
                }
                TextButton(enabled = !busy, onClick = { cancelAuthentication(); dismiss() }) { Text("Отмена", color = p.subtext) }
            }
        }
    }
}

/** App-owned PIN keypad. No IME, clipboard, saved state or plaintext accessibility value. */
@Composable
private fun PinPad(value: String, enabled: Boolean, onChange: (String) -> Unit) {
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    Row(Modifier.fillMaxWidth().heightIn(min = 28.dp).clearAndSetSemantics {
        password(); contentDescription = "PIN Zizi, введено ${value.length} цифр"
    }, horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        repeat(maxOf(6, value.length)) { index ->
            Box(Modifier.size(10.dp).background(if (index < value.length) p.brand else p.subtext.copy(alpha = 0.25f), CircleShape))
        }
    }
    Text("6–12 цифр", color = p.subtext, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Spacer(Modifier.height(12.dp))
    val keys = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "erase"))
    keys.forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { key ->
                if (key.isEmpty()) Spacer(Modifier.weight(1f))
                else TextButton(
                    onClick = {
                        if (key == "erase") onChange(value.dropLast(1))
                        else if (value.length < 12) onChange(value + key)
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    },
                    enabled = enabled && (if (key == "erase") value.isNotEmpty() else value.length < 12),
                    modifier = Modifier.weight(1f).heightIn(min = 56.dp), shape = CircleShape,
                    colors = ButtonDefaults.textButtonColors(contentColor = p.text), contentPadding = PaddingValues(0.dp)
                ) {
                    if (key == "erase") Icon(Icons.Outlined.Backspace, "Удалить цифру", modifier = Modifier.size(24.dp))
                    else Text(key, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun PatternPad(value: String, enabled: Boolean, onChange: (String) -> Unit, color: Color) {
    val livePath = remember { mutableStateOf(value) }
    SideEffect { livePath.value = value }
    val change by rememberUpdatedState(onChange)
    val haptics = LocalHapticFeedback.current
    fun append(node: Int) {
        val next = PatternPath.append(livePath.value, node)
        if (next != livePath.value) { livePath.value = next; change(next); haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).semantics {
        contentDescription = "Графический ключ, выбрано ${value.length} точек"
        customActions = (0..8).map { node -> CustomAccessibilityAction("Точка ${node + 1}") { if (enabled) append(node); enabled } }
    }.pointerInput(enabled) {
        if (!enabled) return@pointerInput
        fun hit(pos: Offset): Int? = (0..8).minByOrNull { i ->
            (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance()
        }?.takeIf { i -> (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance() < size.width / 7f }
        detectDragGestures(onDragStart = { pos -> livePath.value = ""; change(""); hit(pos)?.let { append(it) } },
            onDrag = { event, _ -> event.consume(); hit(event.position)?.let(::append) })
    }.pointerInput(enabled) {
        if (enabled) detectTapGestures { pos ->
            val col = (pos.x / (size.width / 3f)).toInt().coerceIn(0, 2)
            val row = (pos.y / (size.height / 3f)).toInt().coerceIn(0, 2)
            append(row * 3 + col)
        }
    }) {
        fun center(i: Int) = Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)
        value.zipWithNext().forEach { (a, b) -> drawLine(color.copy(alpha = 0.6f), center(a - '0'), center(b - '0'), 5.dp.toPx()) }
        for (i in 0..8) drawCircle(if (('0' + i) in value) color else Color.Gray, 9.dp.toPx(), center(i))
    }
}
