package app.ziziplayer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import app.ziziplayer.privacy.VaultPullPolicy
import app.ziziplayer.ui.theme.LocalPalette

/** Pull only the scroll remainder at the top, including an empty LazyColumn.
 * Release, not a fling callback, commits the gesture. There is no header lock button.
 */
@Composable
fun VaultPullSurface(enabled: Boolean, unlocked: Boolean, onOpen: () -> Unit, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val threshold = with(density) { 72.dp.toPx() }
    val haptic = LocalHapticFeedback.current
    val openVaultAction by rememberUpdatedState(onOpen)
    val gesture = remember(enabled, threshold) { VaultPullPolicy(threshold) }
    var pull by remember(gesture) { mutableFloatStateOf(0f) }
    var dragging by remember(gesture) { mutableStateOf(false) }
    fun sync() { pull = gesture.distance; dragging = gesture.isDragging }
    val connection = remember(enabled, gesture) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.retract(available.y)
                sync()
                return Offset(0f, used)
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.pull(available.y)
                sync()
                if (gesture.takeHaptic()) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                return Offset(0f, used)
            }
            override suspend fun onPreFling(available: Velocity): Velocity =
                if (gesture.consumeFling()) available else Velocity.Zero
        }
    }
    val height by animateFloatAsState(pull, tween(if (dragging) 0 else 200), label = "vault-pull")
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize().nestedScroll(connection).semantics {
        // TalkBack has the same action without adding a visible alternative entry point.
        if (enabled) customActions = listOf(CustomAccessibilityAction("Открыть скрытые папки") {
            openVaultAction.invoke(); true
        })
    }.pointerInput(enabled, gesture) {
        if (enabled) awaitEachGesture {
            var normalEnd = false
            try {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                gesture.begin(); sync()
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val pressed = event.changes.any { it.pressed }
                    if (!pressed) {
                        normalEnd = true
                        val shouldOpen = gesture.release()
                        sync()
                        if (shouldOpen) openVaultAction.invoke()
                    }
                } while (pressed)
            } finally {
                if (!normalEnd) { gesture.cancel(); sync() }
            }
        }
    }) {
        Box(Modifier.fillMaxWidth().height(with(density) { height.toDp() })
            .background(if (unlocked) p.brand else p.surface), contentAlignment = Alignment.Center) {
            if (height > threshold * 0.3f) Text(
                if (pull >= threshold) "Отпусти для открытия" else "Потяни для скрытых папок",
                color = if (unlocked) p.onBrand else p.text, maxLines = 1
            )
        }
        Box(Modifier.weight(1f)) { content.invoke() }
    }
}
