# API review (source inspection, not device execution)

Inspected public AOSP Android 15 framework sources:

- https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/android-15.0.0_r1/media/java/android/media/AudioManager.java
  AudioPlaybackCallback.onPlaybackConfigChanged(List<AudioPlaybackConfiguration>),
  registerAudioPlaybackCallback(callback, Handler), unregisterAudioPlaybackCallback,
  getActivePlaybackConfigurations() are public APIs. Monitoring exists from API 26.
- https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/android-15.0.0_r1/media/java/android/media/AudioPlaybackConfiguration.java
  getAudioAttributes() is public. anonymizedCopy retains usage/content/public flags,
  strips client UID/PID and session identity. isActive(), getClientUid(), getSessionId()
  are hidden/system APIs, so the patch deliberately does not call them.

The observer counts the already-active anonymous list; it must not identify
Telegram by a UID/session or assume that AudioManager.isMusicActive excludes Zizi.
It subtracts one MEDIA/MUSIC candidate only while ExoPlayer.isPlaying is true.
This is a conservative activity heuristic, not sample-level silence detection.
The original API contract for Media3 ForwardingPlayer (1.5.1) is recorded in
verification/v6.40.0/media3-references.md; its override surface was not extended.

No new permissions or dependencies. No modified Android stubs or fake SDK used to
claim compilation. Actual Android compilation and runtime behavior remain pending CI/device.
