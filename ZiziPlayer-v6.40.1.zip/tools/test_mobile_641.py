#!/usr/bin/env python3
"""Compile/run production Java, without Android dependencies or Python policy copies."""
from pathlib import Path
import os
import subprocess
import tempfile
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
if __name__ == '__main__':
    paths = ['app/src/main/java/app/ziziplayer/playback/AudioInterruptionPolicy.java',
             'app/src/main/java/app/ziziplayer/playback/DuckRecoveryPolicy.java',
             'app/src/main/java/app/ziziplayer/privacy/VaultPullPolicy.java',
             'app/src/test/java/app/ziziplayer/privacy/Mobile641Checks.java']
    with tempfile.TemporaryDirectory(prefix='zizi-641-') as output:
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                        *[str(ROOT / p) for p in paths]], check=True)
        subprocess.run(['java', '-cp', output, 'app.ziziplayer.privacy.Mobile641Checks'], check=True)
