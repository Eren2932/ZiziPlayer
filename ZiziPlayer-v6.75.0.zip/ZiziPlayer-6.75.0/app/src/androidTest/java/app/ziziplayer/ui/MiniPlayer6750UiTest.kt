package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.AudioOutput
import app.ziziplayer.playback.AudioOutputState
import app.ziziplayer.playback.OutputKind
import app.ziziplayer.ui.components.MiniPlayerCard
import app.ziziplayer.ui.components.MiniPlayerGeometry
import app.ziziplayer.ui.screens.AudioOutputSheetContent
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Production Compose widgets. Needs an emulator/device; Python guards are NOT these tests. */
class MiniPlayer6750UiTest {
    @get:Rule val compose = createComposeRule()
    private val phone = AudioOutput(OutputKind.PHONE, "Этот телефон", 1)
    private val buds = AudioOutput(OutputKind.BLUETOOTH, "REDMI Buds 8 Active", 2)
    private val track = TrackEntity(id = "mini-fixture", uri = "", title = "MONTAGEM RANHURA",
        artist = "Rushex, Avenxir", durationMs = 180_000)

    @Composable private fun TestTheme(content: @Composable () -> Unit) {
        ZiziTheme(basePalette().copy(miniPlayer = Color(0xFF301354)), content = content)
    }

    @Test fun physicalTapsHaveFourIndependentOwners() {
        val calls = IntArray(4)
        compose.setContent {
            TestTheme {
                Box(Modifier.width(360.dp)) {
                    MiniPlayerCard(track, false, phone, false,
                        onOpen = { calls[0]++ }, onOutput = { calls[1]++ },
                        onFavorite = { calls[2]++ }, onPlayPause = { calls[3]++ },
                        progress = { 0f }, animateTitle = false)
                }
            }
        }
        val tags = listOf("mini-open", "mini-output", "mini-favorite", "mini-play")
        for ((index, tag) in tags.withIndex()) {
            compose.onNodeWithTag(tag).performTouchInput { click(center) }
            compose.runOnIdle { for (i in calls.indices) assertEquals(if (i <= index) 1 else 0, calls[i]) }
        }
        val bounds = tags.map { compose.onNodeWithTag(it).fetchSemanticsNode().boundsInRoot }
        for (i in 0 until bounds.lastIndex) assertTrue(bounds[i].right <= bounds[i + 1].left + 0.1f)
    }

    @Test fun headsetDisconnectReplacesNameAndActionTogether() {
        val output = mutableStateOf(buds)
        val favorite = mutableStateOf(false)
        val playing = mutableStateOf(true)
        compose.setContent {
            TestTheme {
                Box(Modifier.width(360.dp)) {
                    MiniPlayerCard(track, playing.value, output.value, favorite.value,
                        {}, {}, { favorite.value = !favorite.value }, { playing.value = !playing.value },
                        { 0f }, animateTitle = false)
                }
            }
        }
        compose.onNodeWithText(buds.name, useUnmergedTree = true).assertIsDisplayed()
        compose.onNodeWithContentDescription("Устройства: ${buds.name}").assertIsDisplayed()
        compose.onNodeWithTag("mini-favorite").performClick()
        compose.onNodeWithContentDescription("Убрать из избранного").assertIsDisplayed()
        compose.onNodeWithTag("mini-play").performClick()
        compose.onNodeWithContentDescription("Воспроизвести").assertIsDisplayed()
        compose.runOnIdle { output.value = phone }
        compose.onNodeWithText(buds.name, useUnmergedTree = true).assertDoesNotExist()
        compose.onNodeWithContentDescription("Устройства: Этот телефон").assertIsDisplayed()
        compose.onNodeWithText(track.artist, useUnmergedTree = true).assertIsDisplayed()
    }

    @Test fun narrowCardKeepsTargetsAndGrowsWithFontScale() {
        val scale = mutableFloatStateOf(1f)
        var pixelsPerDp = 1f
        compose.setContent {
            val physical = LocalDensity.current.density
            pixelsPerDp = physical
            CompositionLocalProvider(LocalDensity provides Density(physical, scale.floatValue)) {
                TestTheme {
                    Box(Modifier.width(280.dp)) {
                        MiniPlayerCard(track.copy(title = "Очень длинное название трека без конца"), false,
                            buds.copy(name = "Наушники с очень длинным Bluetooth-именем"), false,
                            {}, {}, {}, {}, { 0f }, animateTitle = false)
                    }
                }
            }
        }
        for (value in listOf(1f, 1.8f, 2f)) {
            compose.runOnIdle { scale.floatValue = value }
            val bounds = compose.onNodeWithTag("mini-card").fetchSemanticsNode().boundsInRoot
            assertEquals(MiniPlayerGeometry.height(value) * pixelsPerDp, bounds.height, 1.1f)
            for (tag in listOf("mini-output", "mini-favorite", "mini-play")) {
                compose.onNodeWithTag(tag).assertIsDisplayed()
                val action = compose.onNodeWithTag(tag).fetchSemanticsNode().boundsInRoot
                assertEquals(40f * pixelsPerDp, action.width, 1.1f)
                assertTrue(action.left >= bounds.left && action.right <= bounds.right)
            }
        }
    }

    @Test fun progressDrawTracksNewValuesWithoutChangingTheTitle() {
        val progress = mutableFloatStateOf(0.25f)
        compose.setContent {
            TestTheme {
                Box(Modifier.width(360.dp)) {
                    MiniPlayerCard(track, false, phone, false, {}, {}, {}, {},
                        progress = { progress.floatValue }, animateTitle = false)
                }
            }
        }
        fun centrePixel(): Int {
            val image = compose.onNodeWithTag("mini-progress", useUnmergedTree = true).captureToImage()
            return image.toPixelMap()[image.width / 2, image.height / 2].toArgb()
        }
        assertNotEquals(Color.White.toArgb(), centrePixel())
        compose.runOnIdle { progress.floatValue = 0.75f }
        assertEquals(Color.White.toArgb(), centrePixel())
        compose.onNodeWithText(track.title, useUnmergedTree = true).assertIsDisplayed()
    }

    @Test fun connectSeparatesActiveFromOtherConnectedDevices() {
        val other = buds.copy(name = "Вторая гарнитура", id = 3)
        val state = mutableStateOf(AudioOutputState(buds, listOf(phone, buds, other)))
        compose.setContent {
            TestTheme {
                AudioOutputSheetContent(state.value, track, Modifier.width(360.dp).height(580.dp),
                    onSystemOutput = {}, onBluetooth = {})
            }
        }
        compose.onNodeWithTag("connect-active", useUnmergedTree = true).assert(hasAnyDescendant(hasText(buds.name)))
        compose.onAllNodesWithText(other.name, useUnmergedTree = true).assertCountEquals(1)
        compose.runOnIdle { state.value = AudioOutputState(phone, listOf(phone)) }
        compose.onNodeWithTag("connect-active", useUnmergedTree = true).assert(hasAnyDescendant(hasText(phone.name)))
        compose.onNodeWithText(other.name, useUnmergedTree = true).assertDoesNotExist()
        compose.onNodeWithText("Другие аудиоустройства не подключены").assertIsDisplayed()
        compose.onNodeWithText("В этой сети устройства не найдены").assertDoesNotExist()
    }

    @Test fun connectButtonsInvokeRealHandlersEvenWithLongNames() {
        val calls = IntArray(3)
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 1.6f)) {
                TestTheme {
                    AudioOutputSheetContent(
                        AudioOutputState(buds.copy(name = "Очень длинное имя подключённой гарнитуры")),
                        track, Modifier.width(300.dp).height(420.dp),
                        requestNames = { calls[1]++ }, onSystemOutput = { calls[0]++ },
                        onBluetooth = { calls[2]++ })
                }
            }
        }
        compose.onNodeWithTag("connect-active").performScrollTo().performClick()
        compose.onNodeWithText("Разрешить имена Bluetooth-устройств").performScrollTo().performClick()
        compose.onNodeWithTag("connect-bluetooth").assertIsDisplayed().performTouchInput { click(center) }
        compose.runOnIdle { for (count in calls) assertEquals(1, count) }
    }
}
