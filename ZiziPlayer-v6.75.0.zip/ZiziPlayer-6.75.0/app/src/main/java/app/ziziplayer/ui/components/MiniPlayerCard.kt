package app.ziziplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.AudioOutput
import app.ziziplayer.ui.theme.LocalPalette

/** Stateless production widget: real actions and rendering can be tested without a ViewModel. */
@Composable
fun MiniPlayerCard(
    track: TrackEntity,
    isPlaying: Boolean,
    output: AudioOutput,
    favorite: Boolean,
    onOpen: () -> Unit,
    onOutput: () -> Unit,
    onFavorite: () -> Unit,
    onPlayPause: () -> Unit,
    progress: () -> Float,
    animateTitle: Boolean = true
) {
    val p = LocalPalette.current
    // Reference artist pixel (191,183,204) over (40,13,84) is white at 70% alpha.
    val secondary = Color.White.copy(alpha = 0.70f)
    val external = output.isKnown && !output.isPhone
    Box(
        Modifier.fillMaxWidth().padding(horizontal = MiniPlayerGeometry.EDGE.dp)
            .padding(bottom = MiniPlayerGeometry.DOCK_GAP.dp)
            .height(MiniPlayerGeometry.height(LocalDensity.current.fontScale).dp)
            .clip(RoundedCornerShape(MiniPlayerGeometry.RADIUS.dp))
            .background(p.miniPlayer)
            .testTag("mini-card")
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).fillMaxHeight().clickable(role = Role.Button, onClick = onOpen)
                .testTag("mini-open"), verticalAlignment = Alignment.CenterVertically) {
                TrackArtwork(track = track, maxPx = ARTWORK_ROW_PX,
                    modifier = Modifier.size(MiniPlayerGeometry.ART.dp).clip(RoundedCornerShape(4.dp)), glyphSize = 18)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f).padding(end = 4.dp), verticalArrangement = Arrangement.Center) {
                    MarqueeText(text = track.title, color = Color.White, dim = secondary,
                        suffix = if (external) " • ${track.artist}" else null,
                        fontSize = 14.sp, fontWeight = FontWeight.Bold, enabled = animateTitle,
                        resetKey = track.id, speedDpPerSecond = 24f, gap = 32.dp)
                    if (external) Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (output.isBluetooth) ZiziIcons.BluetoothAudio else audioOutputIcon(output),
                            null, tint = ConnectedDeviceGreen, modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(output.name, color = ConnectedDeviceGreen, fontSize = 11.sp, lineHeight = 16.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else Text(track.artist, color = secondary, fontSize = 14.sp, lineHeight = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            MiniControl(audioOutputIcon(output), "Устройства: ${output.name}", audioOutputTint(output),
                "mini-output", onOutput)
            MiniControl(if (favorite) ZiziIcons.AddedCircle else ZiziIcons.AddCircle,
                if (favorite) "Убрать из избранного" else "Добавить в избранное",
                if (favorite) ConnectedDeviceGreen else Color.White, "mini-favorite", onFavorite)
            MiniControl(if (isPlaying) ZiziIcons.MiniPause else ZiziIcons.MiniPlay,
                if (isPlaying) "Пауза" else "Воспроизвести", Color.White, "mini-play", onPlayPause)
        }
        // Draw-phase read: progress ticks do not recompose the title/artwork/control row.
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 8.dp)
            .height(2.dp).clip(RoundedCornerShape(1.dp)).testTag("mini-progress").drawBehind {
                drawRect(Color.White.copy(alpha = 0.20f))
                drawRect(Color.White, size = size.copy(width = size.width * progress().coerceIn(0f, 1f)))
            })
    }
}

@Composable
private fun MiniControl(icon: ImageVector, label: String, tint: Color, tag: String, onClick: () -> Unit) {
    // The reference has 40 dp pitch. Explicit non-overlapping 40 x >=56 targets, not IconButton's
    // implicit 48 dp expansion, which would steal neighbouring taps. Font scaling grows height.
    Box(Modifier.width(MiniPlayerGeometry.CONTROL.dp).fillMaxHeight()
        .clickable(role = Role.Button, onClick = onClick)
        .semantics { contentDescription = label }.testTag(tag), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
    }
}
