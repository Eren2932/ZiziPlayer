package app.ziziplayer.ui

import app.ziziplayer.data.profileKey

import androidx.compose.runtime.Immutable
import android.app.Application
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.data.FolderAccessException
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.ZiziHttp
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteQuality
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.share.PlaylistFiles
import app.ziziplayer.share.PlaylistShare
import app.ziziplayer.playback.AudioOutputState
import app.ziziplayer.playback.AudioOutputs
import app.ziziplayer.playback.ResolvedStreams
import app.ziziplayer.playback.StreamCache
import app.ziziplayer.playback.StartupTrace
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import app.ziziplayer.data.*
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.CrashLog
import app.ziziplayer.playback.OfflineDownloads
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.dsp.DspCodec
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPreset
import app.ziziplayer.playback.dsp.DspResolve
import app.ziziplayer.playback.Progress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import app.ziziplayer.data.remote.HubCache

/**
 * Разрез медиатеки.
 *
 * 6.29.0: первым стоит [COLLECTION] — единый поток карточек (избранное, все треки, плейлисты,
 * папки, исполнители), и он же теперь точка входа. До этого медиатека открывалась плоским списком
 * из трёх тысяч строк: чтобы попасть в свой плейлист, человек начинал с того, что было ему в этот
 * момент не нужно. [ARTISTS] — локальные исполнители, собранные из тегов, а не из сети.
 *
 * Порядок элементов = порядок чипов на экране, и это единственное место, где он задан.
 */
enum class LibraryFilter { COLLECTION, TRACKS, FAVORITES, PLAYLISTS, FOLDERS, ARTISTS }

/*
 * Ключи «недавних» (6.29.0). Префикс, а не пара (тип, id): в DataStore это одна строка, и
 * разбирать её на экране должно быть можно без знания о том, как она собиралась.
 */
const val RECENT_FAVORITES = "fav"
const val RECENT_TRACKS = "tracks"
const val RECENT_PLAYLIST = "pl:"
const val RECENT_FOLDER = "dir:"
const val RECENT_ARTIST = "art:"

/**
 * Имя исполнителя, за которым стоит живой человек, а не заглушка сканера.
 *
 * MusicScanner подставляет «Неизвестный артист» там, где тега нет вообще (см. MusicScanner:159),
 * а MediaStore на части прошивок отдаёт «<unknown>». Обе строки собирают в одну карточку сотни
 * никак не связанных файлов, и толку от неё ноль — в разрез «Исполнители» они не попадают.
 */
private fun isRealArtist(name: String): Boolean =
    name.isNotBlank() &&
        !name.equals("<unknown>", ignoreCase = true) &&
        !name.equals("Неизвестный артист", ignoreCase = true) &&
        !name.equals("Неизвестный исполнитель", ignoreCase = true)

@Immutable
/**
 * [name] — то, как папка называется на диске: по нему фильтруются треки и по нему её узнаёт
 * сканер. [label] — то, как она называется на экране. Совпадают, пока человек не переименовал.
 */
data class FolderInfo(
    val name: String,
    val count: Int,
    val label: String = name,
    /**
     * 6.29.0: самый свежий трек папки. Нужен ровно для сортировки коллекции «по дате добавления»
     * — у папки нет своей даты, и единственная честная её дата это дата того, что в ней появилось
     * последним. Считается в том же проходе, что и счётчик, то есть бесплатно.
     */
    val addedAt: Long = 0L
)

/**
 * Локальный исполнитель (6.29.0).
 *
 * Собирается из тегов медиатеки — это НЕ страница артиста из каталога. Отсюда и [cover]: своей
 * картинки у такой сущности нет, поэтому в круге показывается обложка самого свежего его трека.
 * Пустое имя и «<unknown>» от MediaStore отбрасываются на этапе сборки: карточка «неизвестный
 * исполнитель» из 200 случайных треков не помогает никому.
 */
@Immutable
data class ArtistInfo(
    val name: String,
    val count: Int,
    val cover: TrackEntity?,
    val totalMs: Long,
    val addedAt: Long
)

/**
 * Ход долгой уборки: очистка кэша потоков, удаление всех загрузок (6.27.1).
 *
 * Одно состояние на все «удалить много»: у них одинаковая проблема и одинаковое решение. Нажатие
 * без отклика человек трактует однозначно — «не сработало» — и жмёт второй раз, третий, а потом
 * пишет, что кнопка не работает. Поэтому в состоянии есть не только [running], но и [freedBytes]
 * с [finishedAt]: сообщить, что дело сделано и сколько именно освободилось, важнее, чем показать
 * крутилку, — крутилка при пустом кэше мигнёт за 20 мс и не скажет ничего.
 */
enum class WipeKind { NONE, STREAM_CACHE, DOWNLOADS }

data class WipeProgress(
    /**
     * Кто именно убирается. Состояние одно на две операции, но строк в настройках две, и
     * показывать ход обеих сразу нельзя: человек увидел бы, что нажатие на «Очистить кэш»
     * запустило заодно и удаление загрузок, чего он не просил.
     */
    val kind: WipeKind = WipeKind.NONE,
    val running: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val freedBytes: Long = 0L,
    val error: String? = null,
    /** Момент завершения; UI держит итог несколько секунд и гасит его сам. */
    val finishedAt: Long = 0L
) {
    val fraction: Float get() = if (total <= 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f)
    val finished: Boolean get() = !running && finishedAt > 0L
}

/** Что лежит в «Скачанных треках». Поток, а не функция, — см. [MainViewModel.downloadsInfo]. */
data class DownloadsInfo(val count: Int = 0, val bytes: Long = 0L)

/** Нижняя граница видимости индикатора уборки. См. [MainViewModel.runWipe]. */
private const val MIN_WIPE_MS = 420L

/** One-off message for the snackbar (used by "removed from the app" + undo). */
data class UiMessage(val text: String, val actionLabel: String? = null, val action: (() -> Unit)? = null)

/**
 * Library state ONLY. Playback position deliberately lives in a separate flow: in v3 everything
 * was one object, so the 4 Hz position tick rebuilt this state, re-sorted 450 tracks on the main
 * thread and recomposed every row of the list. That was the real source of the lag.
 */
@Immutable
data class LibraryUiState(
    val loading: Boolean = true,
    val scanning: Boolean = false,
    val tracks: List<TrackEntity> = emptyList(),
    val visible: List<TrackEntity> = emptyList(),
    /** Full destination membership, independent of the search query; used for bulk downloads. */
    val collectionTracks: List<TrackEntity> = emptyList(),
    /** Full-membership cover: manual first track, never a filtered search result. */
    val collectionCoverTrack: TrackEntity? = null,
    val favoriteIds: Set<String> = emptySet(),
    val playlists: List<PlaylistEntity> = emptyList(),
    /** Количество треков и общее время каждого плейлиста (6.17.0). */
    val playlistMeta: Map<Long, PlaylistMeta> = emptyMap(),
    val folders: List<FolderInfo> = emptyList(),
    /** 6.29.0: локальные исполнители для разреза «Исполнители». */
    val artists: List<ArtistInfo> = emptyList(),
    val hiddenCount: Int = 0,
    val settings: UserSettings = UserSettings(),
    val filter: LibraryFilter = LibraryFilter.COLLECTION,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylist: PlaylistEntity? = null,
    val openFolder: String? = null,
    /** 6.29.0: открытый локальный исполнитель. */
    val openArtist: String? = null,
    /**
     * Суммарное время того, что сейчас в списке. Считается там же, где список — на фоновом
     * диспетчере: складывать 3000 длительностей в композиции значит делать это на каждый кадр
     * прокрутки.
     */
    val visibleMs: Long = 0L,
    /**
     * Счётчики прослушиваний (6.18.0). Они и так считались — на них построена сортировка
     * «по популярности», — но в меню трека прокинуты не были, и «0 прослушиваний» стояло там
     * всегда. Это карта, а не поле трека: статистика меняется на каждом воспроизведении, и
     * перекладывать её в TrackEntity значило бы переписывать весь список ради одного числа.
     */
    val stats: Map<String, PlayStatEntity> = emptyMap()
) {
    val orderScope: String get() = openPlaylist?.id?.let { "playlist:$it" }
        ?: openFolder?.let { "folder:$it" } ?: openArtist?.let { "artist:$it" } ?: filter.name
    val isDrilledIn: Boolean get() = openPlaylist != null || openFolder != null || openArtist != null
}

/**
 * Одна строка предпросмотра импорта (6.15.0).
 *
 * Три исхода на трек, и пользователь должен видеть, какой именно: нашёлся у него локально, нашёлся
 * в каталоге, не нашёлся вообще. Импорт, который молча создаёт плейлист с дырами, ломает доверие
 * сильнее, чем импорт, который честно сказал «два трека не нашёл».
 */
@Immutable
data class ImportRow(
    val entry: PlaylistShare.Entry,
    /** Тот же трек уже есть на устройстве — тогда играть будем его, без сети. */
    val local: TrackEntity? = null,
    /** Найден в каталоге по названию и длительности. */
    val found: RemoteTrack? = null,
    /** Прогон по каталогу для этой строки уже был (и, возможно, безрезультатно). */
    val looked: Boolean = false
) {
    val ready: Boolean get() = local != null || found != null || entry.resolvable
}

@Immutable
data class ImportState(
    val name: String,
    val rows: List<ImportRow>,
    /** Сколько строк ещё предстоит проверить по каталогу. */
    val looking: Int = 0,
    val busy: Boolean = false
) {
    val readyCount: Int get() = rows.count { it.ready }
    val missing: Int get() = rows.size - readyCount
}

data class QueueTrack(val key: String, val track: TrackEntity)

private data class ScopedTrackOrder(val scope: String, val ids: List<String>)

private data class Selection(
    val filter: LibraryFilter = LibraryFilter.COLLECTION,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylistId: Long? = null,
    val openFolder: String? = null,
    val openArtist: String? = null,
    val playlistSortChosen: Boolean = false
)

private data class LibrarySources(
    val tracks: List<TrackEntity>,
    val favorites: Set<String>,
    /** Избранное СПИСКОМ, а не фильтром медиатеки. См. [MusicDao.observeFavoriteTracks]. */
    val favoriteTracks: List<TrackEntity>,
    val hidden: Set<String>,
    val playlists: List<PlaylistEntity>,
    val meta: Map<Long, PlaylistMeta>
)

/** Пара «id избранного + сами треки» — только чтобы уложиться в пять аргументов combine. */
private data class FavoriteState(val ids: Set<String>, val tracks: List<TrackEntity>)

private data class LibraryContext(
    val stats: Map<String, PlayStatEntity>,
    val settings: UserSettings,
    val selection: Selection,
    val playlistTracks: List<TrackEntity>,
    val scanning: Boolean
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    application: Application,
    private val saved: SavedStateHandle
) : AndroidViewModel(application) {

    val lyrics by lazy { app.ziziplayer.lyrics.LyricsRepository(application) }

    private val repo: MusicRepository = (application as ZiziApplication).repository
    private val player: PlayerController = (application as ZiziApplication).playerController

    /**
     * Restored from [saved], so a process death while the app sat in the background brings the user
     * back to the playlist or the folder they had open instead of dropping them on Tracks.
     *
     * `SavedStateHandle` and not a preference file, on purpose: the platform already wipes this when
     * the task is finished and keeps it when the process is merely reclaimed, which is precisely the
     * rule we want ("closed the app - start clean, minimised it - come back to my place") without
     * inventing a staleness timeout.
     */
    private val selection = MutableStateFlow(restoreSelection())
    private val _libraryPanels = MutableStateFlow(LibraryPanelState())
    val libraryPanels: StateFlow<LibraryPanelState> = _libraryPanels.asStateFlow()
    private val scanning = MutableStateFlow(false)

    init {
        // One writer instead of a `saved[...] =` inside setFilter / openPlaylist / openFolder /
        // setQuery / setSearchOpen. A StateFlow conflates, so this is a few string writes per user
        // action, and no future call site can forget to record itself.
        viewModelScope.launch { selection.collect { rememberSelection(it) } }
    }

    private fun rememberSelection(current: Selection) {
        saved[KEY_FILTER] = current.filter.name
        saved[KEY_QUERY] = current.query
        saved[KEY_SEARCH_OPEN] = current.searchOpen
        // Longs and nulls both go in as-is: the handle is Bundle backed and both are Bundle native.
        saved[KEY_PLAYLIST] = current.openPlaylistId
        saved[KEY_FOLDER] = current.openFolder
        saved[KEY_ARTIST] = current.openArtist
        saved["playlistSortChosen"] = current.playlistSortChosen
    }

    private fun restoreSelection(): Selection {
        val filterName = saved.get<String>(KEY_FILTER) ?: return Selection()
        val filter = runCatching { LibraryFilter.valueOf(filterName) }.getOrDefault(LibraryFilter.COLLECTION)
        // A playlist that was deleted from another entry point, or a folder the user has since
        // detached, simply resolves to no drill-in: the library pipeline treats an unknown id as an
        // empty selection, so there is nothing to validate here and nothing to crash on.
        return Selection(
            filter = filter,
            query = saved.get<String>(KEY_QUERY).orEmpty(),
            searchOpen = saved.get<Boolean>(KEY_SEARCH_OPEN) ?: false,
            openPlaylistId = saved.get<Long>(KEY_PLAYLIST),
            openFolder = saved.get<String>(KEY_FOLDER),
            openArtist = saved.get<String>(KEY_ARTIST),
            playlistSortChosen = saved.get<Boolean>("playlistSortChosen") ?: false
        )
    }

    /**
     * Scan progress is exposed as its own flow and deliberately kept **out** of [LibraryUiState].
     *
     * It ticks every 25 files. Folding it into the library state would push the whole pipeline -
     * filter, search, folder counting, a full sort of the library - through `Dispatchers.Default`
     * dozens of times per scan and hand Compose a brand new list each time. That is exactly the
     * mistake v3 made with the playback position, and it is what made the list stutter.
     *
     * A `StateFlow` also conflates by nature, so the four worker threads reporting progress cannot
     * outrun the UI.
     */
    private val _scanProgress = MutableStateFlow<ScanProgress?>(null)
    val scanProgress: StateFlow<ScanProgress?> = _scanProgress.asStateFlow()
    private val _messages = Channel<UiMessage>(Channel.BUFFERED)
    val messages: Flow<UiMessage> = _messages.receiveAsFlow()

    /**
     * 6.27.1: избранное приходит двумя потоками и склеивается заранее.
     *
     * Множество id нужно каждой строке списка — по нему горит сердце. Список треков нужен разделу
     * «Избранное»: там лежит и то, чего нет в медиатеке (лайкнутый сетевой трек без `savedAt`),
     * поэтому фильтровать медиатеку по id было нельзя — именно это и давало пустой экран при
     * горящих сердцах. Склейка отдельным потоком, а не шестым аргументом ниже: типизированных
     * перегрузок combine ровно пять.
     */
    private val favoriteState = combine(repo.favoriteIds, repo.favoriteTracks) { ids, tracks ->
        FavoriteState(ids, tracks)
    }

    private val sources = combine(
        repo.tracks, favoriteState, repo.hiddenIds, repo.playlists, repo.playlistMeta
    ) { tracks, favorites, hidden, playlists, meta ->
        LibrarySources(tracks, favorites.ids, favorites.tracks, hidden, playlists, meta)
    }

    private val openPlaylistTracks = selection
        .map { it.openPlaylistId }
        .distinctUntilChanged()
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observePlaylistTracks(id) }

    private val libraryContext = combine(
        repo.stats, repo.settings,
        // Opening the editor is presentation, not a reason to sort the entire library.
        selection.map { it.copy(searchOpen = false) }.distinctUntilChanged(),
        openPlaylistTracks, scanning
    ) { stats, settings, sel, playlistTracks, isScanning ->
        LibraryContext(stats, settings, sel, playlistTracks, isScanning)
    }

    private fun orderScope(sel: Selection): String = sel.openPlaylistId?.let { "playlist:$it" }
        ?: sel.openFolder?.let { "folder:$it" } ?: sel.openArtist?.let { "artist:$it" } ?: sel.filter.name

    private val collectionOrder = selection.map(::orderScope).distinctUntilChanged().flatMapLatest { scope ->
        repo.observeCollectionOrder(scope).map { ScopedTrackOrder(scope, it) }
    }
    private val orderWriteMutex = kotlinx.coroutines.sync.Mutex()

    /** Everything heavy (filter, search, sort, folder counting) happens off the main thread. */
    private val libraryContent = combine(sources, libraryContext, collectionOrder) { source, ctx, order ->
        build(source, ctx, order.takeIf { it.scope == orderScope(ctx.selection) }?.ids.orEmpty())
    }.flowOn(Dispatchers.Default)

    val library: StateFlow<LibraryUiState> = combine(
        libraryContent,
        selection
    ) { content, sel -> content.copy(searchOpen = sel.searchOpen, query = sel.query) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibraryUiState())

    val playback: StateFlow<PlaybackState> = player.state
    val progress: StateFlow<Progress> = player.progress

    /**
     * repo.allTracks, not repo.tracks.
     *
     * A remote track that is playing but not saved is deliberately absent from the library list, so
     * resolving the current id against that list would leave the mini player and the full player
     * blank for exactly the tracks the search screen just started. Same reason for the queue below.
     */
    val currentTrack: StateFlow<TrackEntity?> = combine(
        repo.allTracks, player.state.map { it.currentTrackId }.distinctUntilChanged()
    ) { tracks, id -> if (id == null) null else tracks.firstOrNull { it.id == id } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val queue: StateFlow<List<TrackEntity>> = combine(
        repo.allTracks, player.state.map { it.queueIds }.distinctUntilChanged()
    ) { tracks, ids ->
        if (ids.isEmpty()) emptyList() else {
            val byId = HashMap<String, TrackEntity>(tracks.size)
            tracks.forEach { byId[it.id] = it }
            ids.mapNotNull { byId[it] }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val queueEntries: StateFlow<List<QueueTrack>> = combine(repo.allTracks,
        player.state.map { it.queueIds to it.queueEntryKeys }.distinctUntilChanged()) { tracks, snapshot ->
        val byId = tracks.associateBy { it.id }
        snapshot.first.mapIndexedNotNull { index, id ->
            val key = snapshot.second.getOrNull(index) ?: return@mapIndexedNotNull null
            byId[id]?.let { QueueTrack(key, it) }
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun playQueueEntry(key: String) = player.seekToQueueEntry(key)
    fun reorderQueue(before: List<String>, after: List<String>): Boolean {
        val applied = player.reorderQueue(before, after)
        if (!applied) _messages.trySend(UiMessage("Очередь изменилась — повторите перенос"))
        return applied
    }

    /** Capture destination identity, never write whichever screen happens to be open on release. */
    suspend fun reorderCollection(snapshot: LibraryUiState, before: List<String>, after: List<String>): Boolean =
        viewModelScope.async { persistCollectionOrder(snapshot, before, after) }.await()

    private suspend fun persistCollectionOrder(snapshot: LibraryUiState, before: List<String>, after: List<String>): Boolean {
        if (before == after) return true
        if (snapshot.query.isNotBlank() || before.size != after.size || before.toSet() != after.toSet()) return false
        orderWriteMutex.lock()
        try {
            val playlist = snapshot.openPlaylist
            if (playlist != null) {
                if (!repo.reorderPlaylist(playlist.id, playlist.createdAt, after, before.firstOrNull() != after.firstOrNull())) return false
                selection.update { if (orderScope(it) == snapshot.orderScope) it.copy(playlistSortChosen = false) else it }
            } else repo.saveCollectionOrder(snapshot.orderScope, after)
            return true
        } catch (cancel: kotlinx.coroutines.CancellationException) {
            throw cancel
        } catch (error: Exception) {
            _messages.trySend(UiMessage("Не удалось сохранить порядок треков"))
            return false
        } finally { orderWriteMutex.unlock() }
    }

    private val _fx = MutableStateFlow(TrackFxEntity(""))
    val fx: StateFlow<TrackFxEntity> = _fx

    /**
     * 6.24.4. То, что СЕЙЧАС звучит. Экран эквалайзера читает отсюда и больше ниоткуда.
     *
     * Это не копия настройки трека: при включённом глобальном режиме здесь лежит глобальный
     * тракт. Один источник правды на экран — иначе неизбежен день, когда ползунок показывает
     * одно, а звучит другое.
     */
    private val _dsp = MutableStateFlow(DspConfig.NEUTRAL)
    val dsp: StateFlow<DspConfig> = _dsp

    /**
     * Настройки отдельным потоком, а не только внутри [library].
     *
     * `library` — тяжёлое комбинирование пяти источников с сортировкой всей фонотеки; экрану
     * эквалайзера из него нужны два поля, и подписывать его на пересборку списка из трёх тысяч
     * треков ради одного boolean было бы дорого и странно.
     */
    val folderVault = repo.vault
    private val _selectedFolders = MutableStateFlow<Set<String>>(emptySet())
    val selectedFolders = _selectedFolders.asStateFlow()
    fun selectFolders(names: Set<String>) { _selectedFolders.value = names }
    fun hideFolders(names: Set<String>) { repo.vault.hide(names); clearSelection(); selectFolders(emptySet()) }
    fun restoreFolders(names: Set<String>) { repo.vault.restore(names) }

    val settings: StateFlow<UserSettings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

    private val _lyricsUi = MutableStateFlow(app.ziziplayer.ui.screens.LyricsUiState())
    internal val lyricsUi = _lyricsUi.asStateFlow()

    init {
        viewModelScope.launch {
            combine(currentTrack, repo.settings.map { it.autoLyrics }.distinctUntilChanged(),
                progress.map { it.trackId to it.durationMs }.distinctUntilChanged()) { track, automatic, timing ->
                // A resolved media duration takes precedence over incomplete catalogue metadata.
                val resolved = if (track != null && timing.first == track.id && timing.second > 0L)
                    track.copy(durationMs = timing.second) else track
                resolved to automatic
            }.distinctUntilChangedBy { (track, automatic) ->
                listOf(track?.id, track?.title, track?.artist, track?.album, track?.durationMs, automatic)
            }.collectLatest { (track, automatic) ->
                val previous = _lyricsUi.value
                val sameMetadata = track != null && previous.track?.let {
                    it.id == track.id && it.title == track.title && it.artist == track.artist && it.album == track.album
                } == true
                val owner = app.ziziplayer.ui.screens.LyricsUiState(track)
                // Media3 may refine duration after the catalogue result. Keep the text visible
                // while validating the refined identity; never carry it into a different song.
                if (sameMetadata) owner.seed(previous)
                _lyricsUi.value = owner
                owner.observe(lyrics, automatic, viewModelScope) {
                    awaitLyricsNetworkSlot(track?.id)
                }
            }
        }
    }
    /** Reuse the existing controller StateFlow; no new Media3 listener or polling timer.
     * Every provider request waits for a stable, connected, non-loading current item.
     * collectLatest in the owner cancels this wait when track/settings change.
     */
    private suspend fun awaitLyricsNetworkSlot(trackId: String?) {
        val span = StartupTrace.begin(StartupTrace.Stage.LYRICS_WAIT)
        try {
            val ready = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                playback.map { state ->
                    trackId != null && state.connected && state.currentTrackId == trackId && !state.isLoadingAudio
                }.distinctUntilChanged().transformLatest { ready ->
                    if (ready) {
                        delay(750L)
                        emit(Unit)
                    }
                }.first()
            }
            if (ready == null) {
                StartupTrace.finish(span, StartupTrace.Outcome.ERROR)
                throw app.ziziplayer.lyrics.LyricsRepository.AudioBusy()
            }
            StartupTrace.finish(span, StartupTrace.Outcome.OK)
        } catch (e: kotlinx.coroutines.CancellationException) {
            StartupTrace.finish(span, StartupTrace.Outcome.CANCELLED)
            throw e
        }
    }
    fun retainLyricsClock(): () -> Unit = player.retainLyricsClock()

    val eqProfiles: StateFlow<List<EqProfileEntity>> = repo.eqProfiles()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private var scanJob: Job? = null

    init {
        viewModelScope.launch {
            kotlinx.coroutines.yield()
            repo.vault.state.collect { gate ->
                if (!gate.unlocked && gate.folders.isNotEmpty()) {
                    selection.update { it.copy(
                        openFolder = it.openFolder?.takeUnless { name -> name in gate.folders },
                        openArtist = null
                    ) }
                    clearSelection()
                    cancelImport()
                }
            }
        }
        launchScan { withScan { repo.rescan(it) } }
        // 6.27.1: диск живёт своей жизнью, и узнавать об этом надо на входе. См. verifySources().
        verifySources()
        // 6.27.1: избранное, у которого пропала строка трека, возвращается на место; лайкам
        // старых версий дописывается тень. Один раз за запуск, в фоне, до первого открытия
        // раздела — человек не должен видеть пустой список и потом его наполнение.
        viewModelScope.launch {
            val restored = runCatching { repo.repairFavorites() }.getOrDefault(0)
            if (restored > 0) _messages.send(UiMessage("Избранное восстановлено: $restored"))
        }
        // Связи со сборниками, чей плейлист удалили в обход приложения (импорт, ручная правка базы).
        viewModelScope.launch { runCatching { repo.pruneCollectionLinks() } }
        // FX are per track: load them the moment the track changes and push them to the player.
        viewModelScope.launch {
            player.state.map { it.currentTrackId }.distinctUntilChanged().collect { id ->
                if (id == null) return@collect
                val saved = repo.fx(id)
                _fx.value = saved
                applyFx(saved)

            }
        }
        viewModelScope.launch {
            repo.settings.map { it.skipSilence }.distinctUntilChanged().collect { player.setSkipSilence(it) }
        }
        // 6.24.4: настройки тракта держим под рукой и пере-применяем, когда они меняются извне
        // (переключён глобальный режим, правка на другом экране).
        viewModelScope.launch {
            // distinctUntilChanged по паре полей: DataStore шлёт весь UserSettings на любую
            // правку, а пере-применять тракт из-за смены темы незачем.
            settings.map { it.dspGlobal to it.dspConfig }.distinctUntilChanged().drop(1).collect {
                applyFx(_fx.value)
            }
        }
        // Resume where the user stopped, without autoplay.
        //
        // THE "TRACK RESTARTS FROM THE BEGINNING" BUG.
        // The playback session outlives the Activity, but this ViewModel is recreated every time
        // the Activity is (screen off, rotation, coming back after a while in another app). v4 then
        // rebuilt the queue on top of a session that was happily playing, rewinding it to whatever
        // position had been saved earlier. Waiting for the connection and bailing out when a queue
        // already exists means the running session is never touched.
        viewModelScope.launch {
            player.awaitConnected()
            if (player.hasQueue()) return@launch
            val lastId = repo.lastTrackId() ?: return@launch
            val tracks = withTimeoutOrNull(20_000) { repo.tracks.first { it.isNotEmpty() } } ?: return@launch
            if (player.hasQueue()) return@launch
            val hidden = repo.hiddenIds.first()
            val list = tracks.filterNot { hidden.contains(it.id) }
            val index = list.indexOfFirst { it.id == lastId }
            val positionMs = repo.lastPositionMs()
            // A user command may arrive while Room/DataStore is suspended above.
            if (player.hasQueue()) return@launch
            if (index >= 0) player.setQueue(list, index, play = false, startPositionMs = positionMs)
        }
        // Backup only. The service persists the position every four seconds and on every state
        // change, which is what keeps it correct while the screen is off and the UI is dead.
        viewModelScope.launch {
            while (true) {
                delay(5_000)
                val state = player.state.value
                if (!state.isPlaying) continue
                val id = state.currentTrackId ?: continue
                val snapshot = player.progress.value
                // 6.32.0. Позиция пишется только если она ПРО ЭТОТ трек. Резервная запись шла
                // раз в пять секунд и вполне могла попасть в окно смены трека: в базу уезжало
                // время предыдущей песни, и при следующем запуске новый трек начинался с
                // середины. Ошибка редкая по частоте и стопроцентная по неприятности.
                if (snapshot.trackId != null && snapshot.trackId != id) continue
                repo.saveLastPosition(id, snapshot.positionMs)
            }
        }
    }

    /**
     * lowercase() allocates a brand new String on every call. v4 called it up to four times per
     * track for every keystroke and on every sort, which is tens of thousands of allocations per
     * typed character on a 450 track library - the search felt sticky and the GC churned. The keys
     * are computed once per track. build() always runs on the same background dispatcher, so a
     * plain HashMap needs no synchronisation.
     */
    private class SearchKeys(val title: String, val artist: String)
    private val searchKeys = HashMap<String, SearchKeys>()
    private fun keysOf(track: TrackEntity): SearchKeys =
        searchKeys.getOrPut(track.id) {
            // Locale.ROOT и здесь, и для запроса ниже: важно не «правильно по-турецки», а
            // одинаково с двух сторон сравнения. Разные локали в ключе и в запросе = поиск,
            // который не находит то, что видно на экране.
            SearchKeys(track.title.lowercase(java.util.Locale.ROOT), track.artist.lowercase(java.util.Locale.ROOT))
        }

    // Folder counts only change when the library itself changes, not on every keystroke.
    private var foldersForTracks: List<TrackEntity>? = null
    private var foldersForHidden: Set<String>? = null
    private var foldersCache: List<FolderInfo> = emptyList()
    private var foldersForLabels: Map<String, String>? = null

    // 6.29.0: исполнители кэшируются по той же схеме и по той же причине, что папки — набор
    // меняется только вместе с самой медиатекой, а не на каждое нажатие буквы в поиске. Ключ —
    // идентичность списков (===), а не их содержимое: сравнивать 3000 треков поэлементно дороже,
    // чем пересобрать группировку.
    private var artistsForTracks: List<TrackEntity>? = null
    private var artistsForHidden: Set<String>? = null
    private var artistsCache: List<ArtistInfo> = emptyList()

    private fun build(source: LibrarySources, ctx: LibraryContext, manualIds: List<String>): LibraryUiState {
        val sel = ctx.selection
        val available = if (source.hidden.isEmpty()) source.tracks
        else source.tracks.filterNot { source.hidden.contains(it.id) }

        if (searchKeys.size > available.size * 2) searchKeys.clear()

        val labels = ctx.settings.folderLabels
        val folders = if (
            foldersForTracks === source.tracks && foldersForHidden === source.hidden && foldersForLabels == labels
        ) {
            foldersCache
        } else {
            available
                .groupingBy { it.sourceFolder }
                // Счётчик и самая свежая дата за ОДИН проход. Раньше здесь был eachCount(), и
                // добавление даты вторым проходом стоило бы ещё одной группировки всей медиатеки.
                .fold(0 to 0L) { acc, track -> (acc.first + 1) to maxOf(acc.second, track.dateAdded) }
                .map { (name, agg) -> FolderInfo(name, agg.first, labels[name] ?: name, agg.second) }
                .sortedWith(compareByDescending<FolderInfo> { it.count }.thenBy { it.label.lowercase() })
                .also {
                    foldersForTracks = source.tracks
                    foldersForHidden = source.hidden
                    foldersForLabels = labels
                    foldersCache = it
                }
        }

        val artists = if (artistsForTracks === source.tracks && artistsForHidden === source.hidden) {
            artistsCache
        } else {
            available
                .filter { isRealArtist(it.artist) }
                .groupBy { it.artist }
                .map { (name, list) ->
                    ArtistInfo(
                        name = name,
                        count = list.size,
                        // Обложка круга — самый свежий трек исполнителя. Не первый по алфавиту:
                        // свежий чаще всего и есть тот, из-за которого исполнитель тут появился.
                        cover = list.maxByOrNull { it.dateAdded },
                        totalMs = list.sumOf { it.durationMs },
                        addedAt = list.maxOf { it.dateAdded }
                    )
                }
                .sortedWith(compareByDescending<ArtistInfo> { it.count }.thenBy { it.name.lowercase(java.util.Locale.ROOT) })
                .also {
                    artistsForTracks = source.tracks
                    artistsForHidden = source.hidden
                    artistsCache = it
                }
        }

        val openPlaylist = source.playlists.firstOrNull { it.id == sel.openPlaylistId }
        val base = when {
            openPlaylist != null -> ctx.playlistTracks.filterNot { source.hidden.contains(it.id) }
            sel.openFolder != null -> available.filter { it.sourceFolder == sel.openFolder }
            // 6.29.0: страница локального исполнителя. Сравнение точное, а не по регистру: имя
            // берётся из той же группировки, что построила карточку, — расходиться им негде.
            sel.openArtist != null -> available.filter { it.artist == sel.openArtist }
            // 6.27.1: не `available.filter { ... }`. Медиатека не содержит лайкнутых сетевых
            // треков by design, и фильтрация по ней теряла ровно то, что человек отметил руками.
            sel.filter == LibraryFilter.FAVORITES ->
                source.favoriteTracks.filterNot { source.hidden.contains(it.id) }
            else -> available
        }

        val searched = if (sel.query.isBlank()) base else {
            val needle = sel.query.trim().lowercase(java.util.Locale.ROOT)
            base.filter { track ->
                val keys = keysOf(track)
                keys.title.contains(needle) || keys.artist.contains(needle)
            }
        }

        // A playlist keeps its manual order; everything else follows the chosen sort mode.
        val normallySorted = if (openPlaylist != null && !sel.playlistSortChosen) searched else when (ctx.settings.sortMode) {
            SortMode.TITLE -> searched.sortedBy { keysOf(it).title }
            SortMode.ARTIST -> searched.sortedWith(compareBy({ keysOf(it).artist }, { keysOf(it).title }))
            SortMode.DURATION -> searched.sortedByDescending { it.durationMs }
            SortMode.RECENT -> searched.sortedByDescending { it.dateAdded }
            SortMode.PLAYS -> searched.sortedWith(
                compareByDescending<TrackEntity> { ctx.stats[it.id]?.playCount ?: 0 }
                    .thenByDescending { ctx.stats[it.id]?.lastPlayedAt ?: 0L }
                    .thenBy { keysOf(it).title }
            )
        }

        val sorted = if (openPlaylist == null && manualIds.isNotEmpty()) {
            val byId = normallySorted.associateBy { it.id }
            ReorderMath.applyOrder(normallySorted.map { it.id }, manualIds).mapNotNull { byId[it] }
        } else normallySorted

        val collectionCoverTrack = when {
            openPlaylist != null -> base.firstOrNull()
            manualIds.isNotEmpty() -> {
                val byId = base.associateBy { it.id }
                val known = manualIds.toHashSet()
                // Cover follows a new arrival too; search must not change its membership.
                base.asSequence().filter { it.id !in known }.maxByOrNull { it.dateAdded }
                    ?: manualIds.firstNotNullOfOrNull { byId[it] }
            }
            else -> base.maxByOrNull { it.dateAdded }
        }

        return LibraryUiState(
            loading = false,
            scanning = ctx.scanning,
            tracks = available,
            visible = sorted,
            collectionTracks = base,
            collectionCoverTrack = collectionCoverTrack,
            favoriteIds = source.favorites,
            playlists = source.playlists,
            playlistMeta = source.meta,
            folders = folders,
            artists = artists,
            hiddenCount = source.hidden.size,
            settings = ctx.settings,
            filter = sel.filter,
            query = sel.query,
            searchOpen = sel.searchOpen,
            openPlaylist = openPlaylist,
            openFolder = sel.openFolder,
            openArtist = sel.openArtist,
            visibleMs = sorted.sumOf { it.durationMs },
            stats = ctx.stats
        )
    }

    // ---------------- navigation ----------------

    fun setLibraryAddExpanded(open: Boolean) {
        if (open) setSearchOpen(false)
        _libraryPanels.update { it.copy(addExpanded = open) }
    }
    fun toggleLibraryAddPanel() = setLibraryAddExpanded(!_libraryPanels.value.addExpanded)

    /** Close synchronously before launching a sheet or SAF. Reject taps during the exit animation. */
    fun consumeLibraryAddAction(): Boolean {
        val open = _libraryPanels.value
        return open.addExpanded && _libraryPanels.compareAndSet(open, open.dismissTop())
    }
    fun closeLibraryPanels() { _libraryPanels.value = LibraryPanelState() }

    fun setFilter(filter: LibraryFilter) {
        closeLibraryPanels()
        clearSelection()
        // 6.29.0: «Избранное» и «Все треки» — такие же карточки коллекции, как плейлист, поэтому
        // и в «недавних» они отмечаются наравне с ним. Иначе порядок «по последнему открытию»
        // врал бы ровно про те две карточки, которые открывают чаще всего.
        when (filter) {
            LibraryFilter.FAVORITES -> noteRecent(RECENT_FAVORITES)
            LibraryFilter.TRACKS -> noteRecent(RECENT_TRACKS)
            else -> Unit
        }
        selection.update { it.copy(filter = filter, openPlaylistId = null, openFolder = null, openArtist = null, query = "", searchOpen = false) }
    }
    fun setQuery(query: String) = selection.update {
        // An outgoing editor may still exist for its fade-out. Never resurrect its query.
        if (it.searchOpen) it.copy(query = query) else it
    }
    fun setSearchOpen(open: Boolean) {
        if (open) closeLibraryPanels()
        selection.update { it.copy(searchOpen = open, query = if (open) it.query else "") }
    }
    fun openPlaylist(id: Long) {
        closeLibraryPanels()
        clearSelection()
        noteRecent("$RECENT_PLAYLIST$id")
        selection.update { it.copy(openPlaylistId = id, openFolder = null, openArtist = null, query = "", searchOpen = false, playlistSortChosen = false) }
    }
    fun openFolder(name: String) {
        closeLibraryPanels()
        clearSelection()
        noteRecent("$RECENT_FOLDER$name")
        selection.update { it.copy(openFolder = name, openPlaylistId = null, openArtist = null, query = "", searchOpen = false) }
    }

    /**
     * Страница локального исполнителя (6.29.0).
     *
     * Отдельный вход, а не `setQuery(имя)`: поиск по подстроке склеил бы «Юпи» с «Юпитер», а
     * фильтр по полю artist показывает ровно то, что подписано на карточке.
     */
    fun openLocalArtist(name: String) {
        closeLibraryPanels()
        clearSelection()
        noteRecent("$RECENT_ARTIST$name")
        selection.update { it.copy(openArtist = name, openPlaylistId = null, openFolder = null, query = "", searchOpen = false) }
    }

    /** Одна запись в «недавних». Пишется в DataStore, поэтому переживает перезапуск. */
    private fun noteRecent(key: String) { viewModelScope.launch { repo.noteRecent(key) } }

    /** Single back entry point, so the system side-swipe never quits the app by accident. */
    fun handleBack(): Boolean {
        val state = library.value
        return when {
            _selectedFolders.value.isNotEmpty() -> { selectFolders(emptySet()); true }
            // Выделение — первый уровень «назад»: выйти из режима выбора люди ждут именно так,
            // и без этого системный свайп выкидывал бы из плейлиста вместе с выбранными треками.
            _selectedIds.value.isNotEmpty() -> { clearSelection(); true }
            state.searchOpen -> { setSearchOpen(false); true }
            _libraryPanels.value.isOpen -> { _libraryPanels.update { it.dismissTop() }; true }
            state.openPlaylist != null -> { selection.update { it.copy(openPlaylistId = null, query = "", searchOpen = false) }; true }
            state.openFolder != null -> { selection.update { it.copy(openFolder = null, query = "", searchOpen = false) }; true }
            state.openArtist != null -> { selection.update { it.copy(openArtist = null, query = "", searchOpen = false) }; true }
            // 6.29.0: «назад» из любого разреза ведёт в коллекцию, а не в список треков.
            state.filter != LibraryFilter.COLLECTION -> { setFilter(LibraryFilter.COLLECTION); true }
            else -> false
        }
    }

    // ---------------- playback ----------------

    fun play(track: TrackEntity, list: List<TrackEntity>? = null, sourceId: String? = null) {
        val source = list ?: library.value.visible.ifEmpty { library.value.tracks }
        val index = source.indexOfFirst { it.id == track.id }
        if (index < 0) player.setQueue(listOf(track), 0, sourceId = sourceId) else player.setQueue(source, index, sourceId = sourceId)
    }

    /** Root toolbar acts on the library, not the names currently matched by card search. */
    fun shuffleLibrary() {
        player.shuffleAndPlay(library.value.tracks, sourceId = LibraryFilter.TRACKS.name)
    }

    fun shuffleTracks(tracks: List<TrackEntity>, sourceId: String? = null) =
        player.shuffleAndPlay(tracks, sourceId)

    fun shuffleAll() {
        val state = library.value
        player.shuffleAndPlay(state.visible.ifEmpty { state.tracks })
    }

    fun playPause() = player.playPause()
    fun next() = player.next()
    fun previous() = player.previous()
    /** [trackId] — трек, который человек видел в момент жеста. См. PlayerController.seekTo. */
    fun seekTo(positionMs: Long, trackId: String? = null) = player.seekTo(positionMs, trackId)
    fun seekToIndex(index: Int) = player.seekToIndex(index)

    /** Тап по строке очереди. По id, а не по номеру строки — почему, см. PlayerController. */
    fun playFromQueue(trackId: String) = player.seekToTrack(trackId)
    fun playNext(track: TrackEntity) = player.enqueue(track, playNext = true)
    fun addToQueue(track: TrackEntity) = player.enqueue(track, playNext = false)

    /**
     * «Перейти к исполнителю».
     *
     * Полноценной страницы артиста ещё нет, и подделывать её пустым экраном хуже, чем не делать:
     * поиск по имени в библиотеке отвечает на тот же вопрос («что у меня есть этого артиста»)
     * и работает офлайн. Экран артиста заменит это место, не меняя вызов.
     */
    fun openArtist(name: String) {
        // 6.29.0: если исполнитель есть в медиатеке — открываем его страницу, а не поиск по имени.
        // Полноценной страницы не было именно потому, что её нечем было наполнить; теперь есть.
        val local = library.value.artists.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (local != null) {
            openLocalArtist(local.name)
            return
        }
        clearSelection()
        selection.update {
            it.copy(
                filter = LibraryFilter.TRACKS,
                openPlaylistId = null,
                openFolder = null,
                openArtist = null,
                searchOpen = true,
                query = name
            )
        }
    }

    // ---------------- офлайн-загрузки ----------------

    /** Живые состояния загрузок; всё остальное [downloadStatus] читает прямо из кэша. */
    @OptIn(androidx.media3.common.util.UnstableApi::class)
    /**
     * 6.33.0. КУДА СЕЙЧАС ИДЁТ ЗВУК.
     *
     * Нижняя строка плеера показывает реальный маршрут вывода — наушники, колонку, динамик — и
     * их настоящее имя. Данные приходят от системы по событию (см. [AudioOutputs]), а не опросом,
     * поэтому подписка ничего не стоит, пока экран закрыт: WhileSubscribed снимает
     * AudioDeviceCallback через пять секунд после ухода последнего читателя и ставит обратно при
     * возврате. Стартовое значение — мгновенный снимок, чтобы строка не мигала «динамиком» на
     * первом кадре, если человек в наушниках.
     */
    val audioOutput: StateFlow<AudioOutputState> = AudioOutputs.flow(application)
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            AudioOutputs.current(application)
        )

    val downloads: StateFlow<Map<String, DownloadStatus>> = OfflineDownloads.states

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun downloadStatus(track: TrackEntity): DownloadStatus =
        OfflineDownloads.statusOf(getApplication<Application>(), track)

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun cancelCollectionDownloads(tracks: List<TrackEntity>) = OfflineDownloads.cancelCollection(tracks)

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun downloadCollection(tracks: List<TrackEntity>) {
        val snapshot = tracks.distinctBy { it.id }.toList()
        viewModelScope.launch(Dispatchers.IO) {
            OfflineDownloads.startAll(getApplication<Application>(), snapshot)
        }
    }

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun download(track: TrackEntity) = OfflineDownloads.start(getApplication<Application>(), track)

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun cancelDownload(track: TrackEntity) = OfflineDownloads.cancel(track.id)

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun removeDownload(track: TrackEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                OfflineDownloads.remove(getApplication<Application>(), track)
                _messages.trySend(UiMessage("Загрузка удалена"))
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { _messages.trySend(UiMessage("Не удалось удалить загрузку. Проверь доступ к файлу")) }
            finally { refreshDownloadsInfo() }
        }
    }

    /**
     * «Скачанные треки» — состояние, а не вызов функции (6.27.1).
     *
     * Было `fun downloadsLabel(): String`, и строка в настройках не обновлялась никогда: композиция
     * не подписана на результат обычного вызова, поэтому цифра застывала в том виде, в каком её
     * прочитали при открытии списка, и менялась только если этот список перерисовывался по другой
     * причине. Снаружи это выглядело как «данные в настройках не обновляются» — ровно так, как
     * ты и написал. Теперь это поток, и он пересчитывается на каждое изменение состояний загрузок
     * и после удаления.
     */
    private val _downloadsInfo = MutableStateFlow(DownloadsInfo())
    val downloadsInfo: StateFlow<DownloadsInfo> = _downloadsInfo.asStateFlow()

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun refreshDownloadsInfo() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val info = runCatching {
                DownloadsInfo(OfflineStore.count(app), OfflineStore.sizeBytes(app))
            }.getOrDefault(DownloadsInfo())
            _downloadsInfo.value = info
        }
    }

    /** Ход очистки кэша и удаления загрузок; см. [WipeProgress]. */
    private val _wipe = MutableStateFlow(WipeProgress())
    val wipe: StateFlow<WipeProgress> = _wipe.asStateFlow()

    /**
     * Отдельный init, и стоит он здесь не случайно.
     *
     * Инициализаторы в Kotlin выполняются в порядке объявления, а `viewModelScope` работает на
     * `Main.immediate`: `launch` из конструктора на главном потоке начинает тело СРАЗУ, не
     * дожидаясь конца конструктора. Поставь эту подписку в верхний init — и она обратится к
     * `downloads` и `_downloadsInfo`, до которых инициализация ещё не дошла, то есть к null в
     * поле ненулевого типа. Такой сбой не воспроизводится «иногда»: он падает всегда и сразу,
     * но обнаруживается только запуском, а не компилятором. Поэтому — после объявлений.
     */
    init {
        refreshDownloadsInfo()
        viewModelScope.launch { downloads.collect { refreshDownloadsInfo() } }
    }

    @OptIn(androidx.media3.common.util.UnstableApi::class)
    fun removeAllDownloads() {
        if (_wipe.value.running) return
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            runWipe(WipeKind.DOWNLOADS, { OfflineStore.sizeBytes(app) }) { report ->
                OfflineDownloads.removeAll(app, report)
            }
            refreshDownloadsInfo()
        }
    }

    /**
     * Общий каркас обеих уборок: показать, вести, договорить.
     *
     * Нижняя граница видимости 420 мс — не украшение. Обе операции при пустом или почти пустом
     * хранилище заканчиваются за десятки миллисекунд: без задержки индикатор появлялся и
     * исчезал в одном кадре, то есть человек не видел НИЧЕГО и делал единственный доступный
     * вывод — «кнопка мёртвая». Именно на это и была жалоба.
     */
    private suspend fun runWipe(
        kind: WipeKind,
        measureBytes: () -> Long,
        block: suspend ((Int, Int) -> Unit) -> Unit
    ) {
        // Claim before touching storage; racing taps must not start two cleanup workers.
        val previous = _wipe.value
        if (previous.running || !_wipe.compareAndSet(previous, WipeProgress(kind = kind, running = true))) return
        val startedAt = android.os.SystemClock.elapsedRealtime()
        var freed = 0L
        var failure: String? = null
        try {
            val before = measureBytes()
            block { done, total -> _wipe.value = _wipe.value.copy(done = done, total = total) }
            freed = (before - measureBytes()).coerceAtLeast(0L)
        } catch (e: CancellationException) {
            _wipe.value = WipeProgress()
            throw e
        } catch (e: Exception) {
            failure = "Не удалось завершить очистку. Попробуй ещё раз."
        }
        try {
            val elapsed = android.os.SystemClock.elapsedRealtime() - startedAt
            if (elapsed < MIN_WIPE_MS) delay(MIN_WIPE_MS - elapsed)
            _wipe.value = _wipe.value.copy(
                running = false, freedBytes = freed, error = failure,
                finishedAt = System.currentTimeMillis()
            )
        } catch (e: CancellationException) {
            _wipe.value = WipeProgress()
            throw e
        }
    }

    /** Итог со экрана убирает сам UI; здесь — только по запросу, чтобы не висел до перезапуска. */
    fun dismissWipeResult() {
        if (!_wipe.value.running) _wipe.value = WipeProgress()
    }

    /** Стек последнего падения; `null` — приложение не падало (нормальное состояние). */
    fun crashReport(): String? = CrashLog.report(getApplication<Application>())

    fun clearCrashReport() = CrashLog.clear(getApplication<Application>())

    fun toggleShuffle() = player.toggleShuffle()
    fun cycleRepeat() = player.cycleRepeat()
    fun setSleepTimer(minutes: Int?) = player.setSleepTimer(minutes)

    fun setFx(speed: Float, pitch: Float, reverb: Int) {
        val id = playback.value.currentTrackId ?: return
        val fx = _fx.value.copy(trackId = id, speed = speed, pitch = pitch, reverb = reverb)
        _fx.value = fx
        applyFx(fx)
        viewModelScope.launch { repo.saveFx(fx) }
    }

    fun resetFx() = setFx(1f, 1f, 0)

    suspend fun loadFx(id: String): TrackFxEntity = repo.fx(id)

    fun saveFx(id: String, speed: Float, pitch: Float, reverb: Int) {
        viewModelScope.launch {
            val fx = repo.fx(id).copy(speed = speed, pitch = pitch, reverb = reverb)
            if (id == playback.value.currentTrackId) {
                _fx.value = fx
                applyFx(fx)
            }
            repo.saveFx(fx)
        }
    }

    // ---------------- эквалайзер (6.24.4) ----------------

    /**
     * Раскладка «что играет» из сохранённого состояния трека и настроек. Порядок ветвей и есть
     * весь смысл гибридного режима:
     *
     * 1. Глобальный режим включён -> звучит глобальный тракт, настройка трека не читается вовсе
     *    (но и НЕ стирается: выключил глобальный — вернулась своя).
     * 2. У трека есть своя строка -> звучит она.
     * 3. Строки нет, но остался старый «Реверб %» из 6.x -> он переносится в наш ревер один раз.
     * 4. Нет ничего -> нейтраль, ноль умножений в аудиопотоке.
     */
    private fun resolveDsp(fx: TrackFxEntity, s: UserSettings): DspConfig =
        DspResolve.forTrack(fx.eqConfig, fx.reverb, s.dspGlobal, s.dspConfig)

    /** Скорость/тональность — в плеер, тракт — в наш процессор. Две разные подсистемы. */
    private fun applyFx(fx: TrackFxEntity) {
        player.setPlayback(fx.speed, fx.pitch)
        val cfg = resolveDsp(fx, settings.value)
        _dsp.value = cfg
        player.setDsp(cfg)
    }

    /**
     * Правка тракта с экрана эквалайзера. Летит сюда десятками в секунду, поэтому в базу и в
     * DataStore пишется отложенно ([dspSaveJob]), а в звук — немедленно. Человек слышит движение
     * ползунка мгновенно, а диск получает одну запись через 400 мс после того, как палец убран.
     */
    fun setDsp(config: DspConfig) {
        val cfg = config.sanitized()
        _dsp.value = cfg
        player.setDsp(cfg)
        val encoded = DspCodec.encode(cfg)
        val global = settings.value.dspGlobal
        val id = playback.value.currentTrackId
        dspSaveJob?.cancel()
        dspSaveJob = viewModelScope.launch {
            delay(DSP_SAVE_DELAY_MS)
            if (global) {
                repo.setGlobalDsp(encoded)
            } else if (id != null) {
                val fx = repo.fx(id).copy(eqConfig = encoded)
                _fx.value = fx
                repo.saveFx(fx)
            }
        }
    }

    private var dspSaveJob: Job? = null

    /** Сброс тракта в ноль. Скорость и тональность не трогаются: это соседняя ручка, не эта. */
    fun resetDsp() = setDsp(DspConfig.NEUTRAL.copy(enabled = _dsp.value.enabled))

    /** 6.69.0. Сброс только кривой и модулей тембра: эффекты сцены остаются. */
    fun resetDspTimbre() = setDsp(_dsp.value.clearedTimbre())

    /** 6.69.0. Сброс только сцены: ревер/8D/«под водой» в ноль, кривая остаётся. */
    fun resetDspScene() = setDsp(_dsp.value.clearedScene())

    /** 6.69.0. Одна полоса. Движение полосы включает тракт: «двигаю — ничего не меняется» хуже. */
    fun setDspBand(index: Int, db: Float) {
        val cur = _dsp.value
        if (index !in 0 until DspConfig.BAND_COUNT) return
        val next = cur.bandsDb.toMutableList()
        while (next.size < DspConfig.BAND_COUNT) next.add(0f)
        if (next[index] == db && cur.enabled) return
        next[index] = db
        setDsp(cur.copy(enabled = true, bandsDb = next))
    }

    /** 6.69.0. Правка одного поля с включением тракта — все ползунки модулей идут через неё. */
    fun editDsp(transform: (DspConfig) -> DspConfig) {
        val cur = _dsp.value
        val next = transform(cur)
        if (next == cur) return
        setDsp(if (next.isNeutral) next else next.copy(enabled = true))
    }

    fun setDspGlobal(enabled: Boolean) {
        viewModelScope.launch {
            // Сначала переносим то, что сейчас звучит, в ту сторону, куда переключаемся, — иначе
            // тумблер «на все треки» означал бы «выключить звук, который я только что настроил».
            if (enabled) repo.setGlobalDsp(DspCodec.encode(_dsp.value))
            repo.setDspGlobal(enabled)
        }
    }

    fun saveEqProfile(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch { repo.saveEqProfile(clean, DspCodec.encode(_dsp.value)) }
    }

    fun deleteEqProfile(name: String) {
        viewModelScope.launch { repo.deleteEqProfile(name) }
    }

    /** Применение пресета — это обычная правка тракта, поэтому идёт через тот же [setDsp]. */
    fun applyEqProfile(profile: EqProfileEntity) = setDsp(DspCodec.decode(profile.config))

    /**
     * 6.69.0. Пресет владеет одним слоем тракта (тембр или сцена) и задаёт его целиком, поэтому
     * «Наушники» + «Под водой» складываются, а «Рок» после «Бас+» заменяет его без остатков.
     * Повторное нажатие активного пресета снимает его: слой возвращается в ноль.
     */
    fun applyDspPreset(preset: DspPreset) {
        val cur = _dsp.value
        val next = if (cur.enabled && preset.isActive(cur)) {
            when (preset.layer) {
                DspPreset.Layer.TIMBRE -> cur.clearedTimbre()
                DspPreset.Layer.SCENE -> cur.clearedScene()
            }
        } else preset.applyTo(cur)
        setDsp(next)
    }

    /** Экран эквалайзера включает анализатор на время жизни композиции и гасит при уходе. */

    // ---------------- library actions ----------------

    /**
     * 6.19.0: состояние «было ли избранным» больше не читается здесь.
     *
     * Читать его из `library.value` означало смотреть в снимок, который отстаёт от базы на весь
     * путь Room -> Flow -> combine -> Dispatchers.Default. Двойной тап по сердцу укладывался в это
     * отставание целиком и ставил избранное дважды вместо «поставить и снять». Решает не задержка
     * и не блокировка кнопки, а перенос чтения туда же, где происходит запись — в транзакцию.
     */
    fun toggleFavorite(track: TrackEntity) {
        viewModelScope.launch { repo.toggleFavorite(track.id) }
    }

    /**
     * "Remove from the app": the file stays on the phone, the track just leaves the library and
     * the running queue. Reversible from the snackbar, and from Settings for older removals.
     */
    fun removeFromApp(track: TrackEntity) {
        viewModelScope.launch {
            repo.hideTrack(track.id)
            player.removeFromQueue(track.id)
            _messages.trySend(
                UiMessage(
                    text = "Убрано из приложения: ${track.title}",
                    actionLabel = "Вернуть",
                    action = { restoreTrack(track.id) }
                )
            )
        }
    }

    fun restoreTrack(id: String) { viewModelScope.launch { repo.unhideTrack(id) } }

    fun restoreAllHidden() {
        viewModelScope.launch {
            repo.clearHidden()
            _messages.trySend(UiMessage("Скрытые треки возвращены"))
        }
    }

    /** Real file deletion, kept separate and always behind the system confirmation dialog. */
    fun requestDeleteFile(track: TrackEntity, onReady: (IntentSender?) -> Unit) {
        viewModelScope.launch {
            val sender = runCatching { repo.requestFileDeletion(track) }.getOrNull()
            if (sender == null) {
                // Below Android 11 the file is deleted right away, nothing to confirm.
                onFileDeleted(track)
                onReady(null)
            } else onReady(sender)
        }
    }

    fun onFileDeleted(track: TrackEntity) {
        viewModelScope.launch {
            player.removeFromQueue(track.id)
            repo.forgetTrack(track.id)
            _messages.trySend(UiMessage("Файл удалён: ${track.title}"))
        }
    }

    /**
     * 6.19.0: отказ доступа больше не пропадает молча.
     *
     * `withScan` глотает любой Throwable, чтобы сбой сканирования не уносил ViewModel, — и это
     * правильно для сканирования, но не для подключения папки: там сбой означает «папку не
     * подключили», и об этом обязан узнать человек. Ошибка ловится ДО withScan, отдельно.
     */
    fun addFolder(uri: Uri) {
        launchScan {
            val failure = withScanResult { repo.addFolder(uri, it) }
            when (failure) {
                null -> Unit
                is FolderAccessException -> _messages.send(UiMessage(failure.message ?: "Нет доступа к папке"))
                else -> _messages.send(UiMessage("Не удалось прочитать папку"))
            }
        }
    }

    fun removeFolder(uri: String) {
        launchScan { withScan { repo.removeFolder(uri, it) } }
    }

    /**
     * Переименование папки — экранное. Причина в [UserSettings.folderLabels], и она техническая:
     * настоящее переименование дерева отбирает у нас же доступ к нему.
     */
    fun renameFolder(name: String, label: String) {
        viewModelScope.launch {
            repo.setFolderLabel(name, label)
            val trimmed = label.trim()
            _messages.send(
                if (trimmed.isBlank() || trimmed == name) UiMessage("Имя папки сброшено")
                else UiMessage("Папка переименована: $trimmed")
            )
        }
    }

    /** Треки папки — то, что уйдёт с устройства при её удалении. Показывается в подтверждении. */
    fun folderTracks(folder: String): List<TrackEntity> =
        library.value.tracks.filter { it.sourceFolder == folder }

    /**
     * Удаление папки с устройства. Системный диалог — один на всю папку, а не на файл.
     */
    fun requestFolderDeletion(folder: String, onReady: (IntentSender?) -> Unit) {
        viewModelScope.launch {
            val tracks = folderTracks(folder)
            if (tracks.isEmpty()) { onReady(null); return@launch }
            val sender = runCatching { repo.requestFolderDeletion(tracks) }.getOrNull()
            if (sender == null) {
                onFolderDeleted(folder)
                onReady(null)
            } else onReady(sender)
        }
    }

    fun onFolderDeleted(folder: String) {
        viewModelScope.launch {
            val ids = folderTracks(folder).map { it.id }
            ids.forEach { player.removeFromQueue(it) }
            selection.update { if (it.openFolder == folder) it.copy(openFolder = null) else it }
            launchScan { withScan { repo.rescan(it) } }
            _messages.send(UiMessage("Папка «$folder» удалена"))
        }
    }

    /**
     * Проверка состояния источников на входе в приложение (6.27.1).
     *
     * Ставится ПОСЛЕ стартового пересканирования, а не вместо него: пересканирование теперь
     * отбрасывает мёртвые строки MediaStore (см. MusicScanner), а эта проверка отвечает на другой
     * вопрос — не пропала ли целиком подключённая папка, и не разошлось ли количество. Если
     * разошлось, запускается ещё один проход и человеку говорится словами, что именно случилось:
     * молча менять содержимое медиатеки на глазах у человека — это тот же баг с другой стороны.
     */
    private fun verifySources() {
        viewModelScope.launch {
            val check = runCatching { repo.checkSources() }.getOrNull() ?: return@launch
            if (!check.stale) return@launch
            launchScan { withScan { repo.rescan(it) } }
            when {
                check.lostFolders.isNotEmpty() -> _messages.send(
                    UiMessage(
                        if (check.lostFolders.size == 1) "Одна подключённая папка больше не доступна — медиатека обновлена"
                        else "Папок больше нет: ${check.lostFolders.size} — медиатека обновлена"
                    )
                )
                check.lostSomething -> _messages.send(UiMessage("Часть файлов пропала с устройства — медиатека обновлена"))
                else -> Unit
            }
        }
    }

    fun rescan() {
        launchScan {
            withScan { repo.rescan(it) }
            _messages.trySend(UiMessage("Библиотека обновлена"))
        }
    }

    /**
     * Serialises scans, latest request wins.
     *
     * Two passes must never run at once: they write the same rows, compete for the same four tag
     * readers, and whichever finishes first clears the badge while the other is still going. But
     * *dropping* the newer request is equally wrong, and in one specific case it would be a visible
     * bug: the startup scan begins before the storage permission is granted, so it finds nothing,
     * and the `rescan()` fired the moment the user taps "Allow" is exactly the one that matters. If
     * that were ignored, the library would stay empty until a manual refresh.
     *
     * So the previous scan is cancelled and **joined** - awaited to a full stop - before the new one
     * touches the database. Cancellation is honoured per directory and per file now, so this returns
     * promptly instead of waiting out the whole pass.
     */
    private fun launchScan(block: suspend () -> Unit) {
        val previous = scanJob
        scanJob = viewModelScope.launch {
            previous?.cancelAndJoin()
            block()
        }
    }

    /**
     * Single owner of the scanning flags. Every entry point used to duplicate the set/clear pair,
     * and one of them forgetting the clear on an early return would have left the badge on screen
     * forever. `finally` also covers cancellation - the scan is now cancellable, so that is a real
     * path, not a theoretical one.
     */
    private suspend fun withScan(block: suspend ((ScanProgress) -> Unit) -> Unit) {
        withScanResult(block)
    }

    /**
     * То же самое, но возвращает причину отказа вместо того, чтобы её потерять (6.19.0).
     *
     * Флаги сканирования по-прежнему снимаются в `finally`, отмена по-прежнему пробрасывается —
     * меняется только одно: вызывающий вправе узнать, что именно не получилось, и сказать это
     * пользователю. Раньше такой возможности не было ни у кого, и «папка не подключилась без
     * единого слова» было прямым следствием.
     */
    private suspend fun withScanResult(block: suspend ((ScanProgress) -> Unit) -> Unit): Throwable? {
        scanning.value = true
        try {
            block { progress -> _scanProgress.value = progress }
            return null
        } catch (cancelled: CancellationException) {
            // Never swallowed: swallowing it leaves the parent scope believing the child is alive.
            throw cancelled
        } catch (failure: Throwable) {
            // Any other failure must not take the ViewModel down; the library stays as it was.
            return failure
        } finally {
            _scanProgress.value = null
            scanning.value = false
        }
    }

    /* ==================================================================== выбор треков (6.17.0)
     *
     * Множественный выбор живёт ОТДЕЛЬНЫМ потоком, а не полем LibraryUiState. Причина ровно та же,
     * по которой из состояния когда-то вынесли позицию воспроизведения: тап по чекбоксу обязан
     * перекрасить одну строку, а не прогнать заново фильтр, поиск, сортировку и подсчёт папок для
     * трёх тысяч треков.
     */

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds.asStateFlow()

    fun toggleSelected(id: String) = _selectedIds.update { current ->
        if (current.contains(id)) current - id else current + id
    }

    fun startSelection(id: String) = _selectedIds.update { current ->
        if (current.isEmpty()) setOf(id) else current + id
    }

    fun clearSelection() { _selectedIds.value = emptySet() }

    /** Второе нажатие на «выделить всё» снимает выделение — как в любом файловом менеджере. */
    fun toggleSelectAllVisible() {
        val ids = library.value.visible.map { it.id }
        val current = _selectedIds.value
        _selectedIds.value = if (ids.isNotEmpty() && current.containsAll(ids)) emptySet() else ids.toSet()
    }

    /**
     * Выбранное В ПОРЯДКЕ ЭКРАНА, а не в порядке тапов и не в порядке хеш-множества. Именно этот
     * порядок уедет в плейлист, и «как на экране» — единственный, который человек может предсказать.
     */
    private fun selectedInOrder(): List<String> {
        val selected = _selectedIds.value
        if (selected.isEmpty()) return emptyList()
        return library.value.visible.asSequence().map { it.id }.filter { selected.contains(it) }.toList()
    }

    /**
     * Общий путь для всех «добавить/перенести»: и для множественного выбора, и для «перенести всю
     * папку» из меню папки.
     *
     * [move] означает разные вещи для разных источников, и обе — то, что человек имеет в виду:
     *  - из плейлиста в плейлист это настоящий перенос (добавили в приёмник, убрали из источника);
     *  - из папки «YouTube Music» переносить нечего — папка это не хранилище, а группировка по
     *    источнику. Треки уходят в плейлист и перестают быть «сохранёнными в медиатеку», то есть
     *    исчезают из папки, но остаются играбельными в плейлисте;
     *  - локальный файл не двигается никогда: перекладывать чужие mp3 по диску player не должен.
     */
    fun addTracksToPlaylist(
        playlistId: Long,
        trackIds: List<String>,
        move: Boolean = false,
        fromPlaylistId: Long? = null
    ) {
        if (trackIds.isEmpty()) return
        viewModelScope.launch {
            val name = library.value.playlists.firstOrNull { it.id == playlistId }?.name.orEmpty()
            var localKept = 0
            if (move && fromPlaylistId != null && fromPlaylistId != playlistId) {
                repo.moveTracksBetweenPlaylists(fromPlaylistId, playlistId, trackIds)
            } else {
                repo.addTracksToPlaylist(playlistId, trackIds)
                if (move) {
                    val known = library.value.tracks.filter { trackIds.contains(it.id) }
                    val remote = known.filter { it.isRemote }.map { it.id }
                    localKept = known.size - remote.size
                    if (remote.isNotEmpty()) repo.setRemoteSavedMany(remote, false)
                }
            }
            clearSelection()
            val what = if (move) "Перенесено" else "Добавлено"
            val tail = if (localKept > 0) " · локальные файлы остались в папке: $localKept" else ""
            _messages.send(UiMessage("$what в «$name»: ${trackIds.size}$tail"))
        }
    }

    fun createPlaylistWithTracks(
        name: String,
        trackIds: List<String>,
        move: Boolean = false,
        fromPlaylistId: Long? = null
    ) {
        val clean = name.trim()
        if (clean.isEmpty() || trackIds.isEmpty()) return
        viewModelScope.launch {
            val id = repo.createPlaylist(clean)
            addTracksToPlaylist(id, trackIds, move, fromPlaylistId)
        }
    }

    fun addSelectedToPlaylist(playlistId: Long, move: Boolean = false) =
        addTracksToPlaylist(playlistId, selectedInOrder(), move, library.value.openPlaylist?.id)

    fun createPlaylistFromSelection(name: String, move: Boolean = false) =
        createPlaylistWithTracks(name, selectedInOrder(), move, library.value.openPlaylist?.id)

    /** Убрать выбранное из открытого плейлиста. С отменой: список порядок не теряет. */
    fun removeSelectedFromPlaylist() {
        val playlistId = library.value.openPlaylist?.id ?: return
        val ids = selectedInOrder()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repo.removeTracksFromPlaylist(playlistId, ids)
            clearSelection()
            _messages.send(
                UiMessage(
                    text = "Убрано из плейлиста: ${ids.size}",
                    actionLabel = "Вернуть",
                    action = { viewModelScope.launch { repo.addTracksToPlaylist(playlistId, ids) } }
                )
            )
        }
    }

    /** «Убрать из Zizi» пачкой: файлы на месте, строки скрыты, отмена возвращает всё разом. */
    fun hideSelected() {
        val ids = selectedInOrder()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            ids.forEach { repo.hideTrack(it) }
            clearSelection()
            _messages.send(
                UiMessage(
                    text = "Убрано из медиатеки: ${ids.size}",
                    actionLabel = "Вернуть",
                    action = { viewModelScope.launch { ids.forEach { repo.unhideTrack(it) } } }
                )
            )
        }
    }

    /** Пачка сетевых треков уходит из медиатеки: строка остаётся, метка сохранения снимается. */
    fun unsaveSelected() {
        val ids = selectedInOrder().filter { id -> library.value.tracks.firstOrNull { it.id == id }?.isRemote == true }
        if (ids.isEmpty()) {
            viewModelScope.launch { _messages.send(UiMessage("Здесь только локальные файлы")) }
            return
        }
        viewModelScope.launch {
            repo.setRemoteSavedMany(ids, false)
            clearSelection()
            _messages.send(
                UiMessage(
                    text = "Убрано из медиатеки: ${ids.size}",
                    actionLabel = "Вернуть",
                    action = { viewModelScope.launch { repo.setRemoteSavedMany(ids, true) } }
                )
            )
        }
    }

    fun favoriteSelected() {
        val ids = selectedInOrder()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            // Если выбранное уже целиком в избранном — снимаем. Иначе добавляем недостающее: это
            // ровно то, что человек ждёт от одной кнопки на пачке.
            //
            // 6.19.0: и решение, и запись — одной транзакцией в базе. Было пятьсот отдельных
            // операций и пятьсот перерисовок списка подряд, каждая с полной сортировкой.
            val nowFavorite = repo.toggleFavorites(ids)
            clearSelection()
            _messages.send(UiMessage(if (nowFavorite) "В избранном: ${ids.size}" else "Убрано из избранного: ${ids.size}"))
        }
    }

    fun playSelected() {
        val ids = selectedInOrder()
        if (ids.isEmpty()) return
        val byId = library.value.tracks.associateBy { it.id }
        val tracks = ids.mapNotNull { byId[it] }
        if (tracks.isEmpty()) return
        clearSelection()
        player.setQueue(tracks, 0)
    }

    fun createPlaylist(name: String, tracks: List<TrackEntity> = emptyList()) {
        // 6.67.0: то же правило имени, что и у формы (края, двойные пробелы, 60 символов), и
        // одна пакетная вставка вместо транзакции на каждый трек. Плюс подтверждение снеком:
        // раньше создание из меню трека проходило молча, и человек шёл проверять в медиатеку.
        val clean = PlaylistNaming.clean(name)
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val id = repo.createPlaylist(clean)
            if (tracks.isNotEmpty()) repo.addTracksToPlaylist(id, tracks.map { it.id })
            _messages.trySend(UiMessage(
                if (tracks.isEmpty()) "Плейлист «$clean» создан" else "Создан «$clean» · добавлено: ${tracks.size}"
            ))
        }
    }

    fun addToPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repo.addToPlaylist(playlistId, trackId)
            _messages.trySend(UiMessage("Добавлено в плейлист"))
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch { repo.removeFromPlaylist(playlistId, trackId) }
    }

    suspend fun setProfilePlaylistsHidden(items: List<PlaylistEntity>, hidden: Boolean) {
        val current = library.value.playlists.map { it.profileKey }.toSet()
        val keys = items.map { it.profileKey }.filter { it in current }.toSet()
        repo.setProfilePlaylistsHidden(keys, hidden)
    }

    suspend fun playlistActionTracks(playlist: PlaylistEntity): List<TrackEntity> {
        if (library.value.playlists.none { it.profileKey == playlist.profileKey })
            throw IllegalStateException("Плейлист больше не существует")
        val hidden = repo.hiddenIds.first()
        return repo.playlistTracks(playlist.id).filterNot { it.id in hidden }
    }

    suspend fun renamePlaylistConfirmed(playlist: PlaylistEntity, name: String) {
        require(name.isNotBlank()) { "Введите название" }
        if (!repo.renamePlaylistConfirmed(playlist, name.trim())) throw IllegalStateException("Плейлист уже изменён или удалён")
    }

    suspend fun copyPlaylistContents(source: PlaylistEntity, target: PlaylistEntity) {
        repo.copyPlaylistContents(source, target)
        _messages.trySend(UiMessage("Добавлено в «${target.name}»"))
    }

    suspend fun deletePlaylistConfirmed(playlist: PlaylistEntity) {
        if (!repo.deletePlaylistConfirmed(playlist)) throw IllegalStateException("Плейлист уже изменён или удалён")
        selection.update { if (it.openPlaylistId == playlist.id) it.copy(openPlaylistId = null) else it }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repo.deletePlaylist(id)
            selection.update { if (it.openPlaylistId == id) it.copy(openPlaylistId = null) else it }
        }
    }

    fun renamePlaylist(id: Long, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { repo.renamePlaylist(id, name.trim()) }
    }

    fun saveQueueAsPlaylist(name: String) = createPlaylist(name, queue.value)

    /* ------------------------------------------------- сборники из поиска (6.17.0) ---- */

    /** Список плейлистов сам по себе: экрану поиска не нужно всё состояние медиатеки. */
    val playlistsForPicker: StateFlow<List<PlaylistEntity>> = repo.playlists
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Ключ сборника -> связь с плейлистом. Пусто, если сборник ещё не добавляли. */
    val collectionLinks: StateFlow<Map<String, PlaylistLinkEntity>> = repo.collectionLinks
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun collectionKey(provider: String, remoteId: String): String = "$provider:$remoteId"

    /**
     * «Добавить к себе» для альбома или плейлиста из поиска.
     *
     * До 6.17.0 это была кнопка «+ всё», и она делала единственное, что умела: помечала каждый трек
     * как сохранённый. Библиотека группирует сетевые треки по источнику, поэтому ВСЁ добавленное
     * из поиска сваливалось в одну папку «YouTube Music» — пять разных плейлистов превращались в
     * одну кучу из двухсот треков, и разложить её обратно было нечем.
     *
     * Теперь сборник становится тем, чем он и был у источника — плейлистом. Треки пишутся в базу
     * (иначе их нечем играть), но НЕ помечаются сохранёнными: в «Треках» и в папках их нет,
     * они живут в своём плейлисте.
     */
    fun saveCollectionAsPlaylist(
        key: String,
        title: String,
        tracks: List<RemoteTrack>,
        intoPlaylistId: Long? = null,
        newName: String? = null,
        /** Обложка сборника. Достаётся плейлисту, если своей у него ещё нет. */
        artworkUrl: String? = null
    ) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            val entities = repo.rememberRemote(tracks)
            if (entities.isEmpty()) {
                _messages.send(UiMessage("Не удалось сохранить сборник"))
                return@launch
            }
            val ids = entities.map { it.id }
            val owned = intoPlaylistId == null
            val name = (newName ?: title).trim().ifBlank { title }
            val playlistId = intoPlaylistId ?: repo.createPlaylist(name)
            repo.addTracksToPlaylist(playlistId, ids)
            repo.linkCollection(key, playlistId, title, owned)
            // Обложку получает ПЕРВЫЙ добавленный сборник и только он: закинули в плейлист второй
            // и третий — иконка не меняется. Плейлист человек узнаёт в списке по картинке, и
            // картинка, прыгающая при каждом добавлении, перестаёт быть опознавательным знаком.
            repo.noteFirstCover(playlistId, artworkUrl ?: entities.firstOrNull { it.artworkUri != null }?.artworkUri)
            val target = library.value.playlists.firstOrNull { it.id == playlistId }?.name ?: name
            _messages.send(UiMessage("«$target»: добавлено ${ids.size}"))
        }
    }

    /**
     * Повторное нажатие на уже добавленный сборник.
     *
     * Созданный нами плейлист удаляется целиком. В чужой, выбранный пользователем, приложение не
     * лезет: оттуда убираются только треки сборника, остальное остаётся как было.
     */
    fun removeCollection(key: String, trackIds: List<String>) {
        val link = collectionLinks.value[key] ?: return
        viewModelScope.launch {
            if (link.owned) {
                repo.deletePlaylist(link.playlistId)
                selection.update { if (it.openPlaylistId == link.playlistId) it.copy(openPlaylistId = null) else it }
                _messages.send(UiMessage("Плейлист «${link.title}» удалён"))
            } else {
                if (trackIds.isNotEmpty()) repo.removeTracksFromPlaylist(link.playlistId, trackIds)
                repo.unlinkCollection(key)
                _messages.send(UiMessage("Треки сборника убраны из плейлиста"))
            }
        }
    }

    // ------------------------------------------------------- обмен плейлистами (6.15.0)

    private val _import = MutableStateFlow<ImportState?>(null)
    val import: StateFlow<ImportState?> = _import.asStateFlow()
    private var importJob: Job? = null

    /** Паспорта треков для отправки. Локальные едут без provider/remoteId — их ищут на приёме. */
    suspend fun playlistPayload(playlist: PlaylistEntity): PlaylistShare.Payload {
        val tracks = repo.playlistTracks(playlist.id)
        return PlaylistShare.Payload(
            name = playlist.name,
            entries = tracks.map { t ->
                PlaylistShare.Entry(
                    provider = t.provider,
                    remoteId = t.remoteId,
                    title = t.title,
                    artist = t.artist,
                    durationMs = t.durationMs
                )
            }
        )
    }

    /** Текст: сырой JSON, строка ZIZI1:, ссылка zizi://p/, или письмо, внутри которого она лежит. */
    fun offerImport(text: String?) {
        val payload = PlaylistShare.decode(text)
        if (payload == null) {
            _messages.trySend(UiMessage("Файл не похож на наш плейлист"))
            return
        }
        if (payload.entries.isEmpty()) {
            _messages.trySend(UiMessage("Плейлист «${payload.name}» пустой"))
            return
        }
        startPreview(payload)
    }

    /** Файл .zizi: из системного выбора внутри приложения или присланный извне. */
    fun offerImportFile(uri: Uri) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                PlaylistFiles.read(getApplication<Application>(), uri)
            }
            if (text == null) {
                _messages.trySend(UiMessage("Файл не читается или слишком большой"))
                return@launch
            }
            offerImport(text)
        }
    }

    fun cancelImport() {
        importJob?.cancel()
        importJob = null
        _import.value = null
    }

    private fun startPreview(payload: PlaylistShare.Payload) {
        importJob?.cancel()
        val known = library.value.tracks
        val rows = payload.entries.map { entry ->
            ImportRow(entry = entry, local = matchLocal(entry, known))
        }
        _import.value = ImportState(
            name = payload.name,
            rows = rows,
            looking = rows.count { !it.ready }
        )
        importJob = viewModelScope.launch { resolveMissing() }
    }

    /**
     * Есть ли этот трек у меня уже.
     *
     * Сначала точное совпадение по паспорту (`r:provider:id`) — если отправитель слушает тот же
     * каталог, это попадание без единого сетевого запроса. Потом локальные файлы: сверка по
     * названию и длительности с допуском из [PlaylistShare]. Приоритет своего файла перед сетью
     * здесь принципиален: свой файл играет офлайн и не зависит от того, жив ли каталог.
     */
    private fun matchLocal(entry: PlaylistShare.Entry, known: List<TrackEntity>): TrackEntity? {
        if (entry.resolvable) {
            val id = "r:${entry.provider}:${entry.remoteId}"
            known.firstOrNull { it.id == id }?.let { return it }
        }
        return known.firstOrNull { t ->
            t.source == TrackSource.LOCAL && PlaylistShare.matches(entry, t.title, t.durationMs)
        }
    }

    /**
     * Догоняет каталогом то, что не приехало с паспортом и не нашлось локально.
     *
     * Последовательно и с паузой: пачка параллельных запросов по плейлисту на 300 треков — это
     * ровно тот трафик, за который провайдер отвечает рейт-лимитом, и тогда не найдётся ничего.
     * Ищем не больше [LOOKUP_LIMIT] строк: остальное пользователь увидит как «не найдено» и решит
     * сам, а не будет минуту смотреть на прогресс.
     */
    private suspend fun resolveMissing() {
        val preferred = repo.settings.first().catalogProvider
        var budget = LOOKUP_LIMIT
        while (true) {
            val state = _import.value ?: return
            val index = state.rows.indexOfFirst { !it.ready && !it.looked }
            if (index < 0 || budget <= 0) break
            budget--
            val entry = state.rows[index].entry
            val query = listOf(entry.artist, entry.title).filter { it.isNotBlank() }.joinToString(" ")
            val found = runCatching {
                repo.catalogs.withFallback(preferred) { it.search(query, RemoteKind.TRACK, null) }
                    .items
                    .filterIsInstance<RemoteItem.Song>()
                    .map { it.track }
                    .firstOrNull { PlaylistShare.matches(entry, it.title, it.durationMs) }
            }.getOrNull()
            // Состояние могло смениться, пока мы ждали сеть: пользователь закрыл лист или прислал
            // другой плейлист. Тогда результат просто выбрасывается.
            val current = _import.value ?: return
            if (current !== state) return
            _import.value = current.copy(
                rows = current.rows.toMutableList().also {
                    it[index] = it[index].copy(found = found, looked = true)
                },
                looking = (current.looking - 1).coerceAtLeast(0)
            )
            delay(120)
        }
        _import.value?.let { _import.value = it.copy(looking = 0) }
    }

    /**
     * Создаёт плейлист из предпросмотра.
     *
     * Сетевые треки пишутся в `tracks` без `savedAt`: они нужны, чтобы плейлист играл, но чужой
     * плейлист не должен подсыпать треки в мои «Треки». Из подметания их спасает то, что они лежат
     * в `playlist_tracks` — это уже учтено в запросе `forgettableRemoteIds`.
     */
    fun confirmImport(name: String) {
        val state = _import.value ?: return
        if (state.busy) return
        importJob?.cancel()
        _import.value = state.copy(busy = true)
        viewModelScope.launch {
            val remote = state.rows.mapNotNull { row ->
                when {
                    row.local != null -> null
                    row.found != null -> row.found
                    row.entry.resolvable -> RemoteTrack(
                        provider = row.entry.provider!!,
                        remoteId = row.entry.remoteId!!,
                        title = row.entry.title,
                        artist = row.entry.artist,
                        durationMs = row.entry.durationMs
                    )
                    else -> null
                }
            }
            if (remote.isNotEmpty()) repo.rememberRemote(remote)
            val title = name.trim().ifBlank { state.name }
            val id = repo.createPlaylist(title)
            // 6.19.0: сначала собрать список, потом одна пакетная вставка.
            //
            // Было по вызову на трек, и каждый из них — отдельная транзакция плюс отдельный эмит
            // Flow, на который экран плейлистов отвечал полной пересборкой. Импорт чужого
            // плейлиста на 200 треков означал 400 обращений к базе и 200 перерисовок подряд:
            // видно как «приложение подвисло на импорте», хотя работы там на десятые доли секунды.
            val trackIds = state.rows.mapNotNull { row ->
                row.local?.id
                    ?: row.found?.trackId
                    ?: row.entry.takeIf { it.resolvable }?.let { "r:${it.provider}:${it.remoteId}" }
            }
            repo.addTracksToPlaylist(id, trackIds)
            val added = trackIds.size
            _import.value = null
            selection.update {
                it.copy(filter = LibraryFilter.PLAYLISTS, openPlaylistId = id, openFolder = null, openArtist = null)
            }
            val skipped = state.rows.size - added
            _messages.trySend(
                UiMessage(
                    if (skipped == 0) "«$title»: $added треков"
                    else "«$title»: $added из ${state.rows.size}, не найдено $skipped"
                )
            )
        }
    }

    fun setAutoLyrics(value: Boolean) { viewModelScope.launch { repo.setAutoLyrics(value) } }
    fun setDynamicAccent(value: Boolean) { viewModelScope.launch { repo.setDynamicAccent(value) } }
    fun setSkipSilence(value: Boolean) { viewModelScope.launch { repo.setSkipSilence(value) } }
    fun setSortMode(mode: SortMode) {
        val scope = orderScope(selection.value)
        viewModelScope.launch {
            orderWriteMutex.lock()
            try {
                repo.clearCollectionOrder(scope)
                repo.setSortMode(mode)
                selection.update { if (orderScope(it) == scope) it.copy(playlistSortChosen = it.openPlaylistId != null) else it }
            } finally { orderWriteMutex.unlock() }
        }
    }
    /** 6.29.0: вид коллекции и порядок карточек — настройки, а не состояние экрана. */
    fun setLibraryView(view: LibraryView) { viewModelScope.launch { repo.setLibraryView(view) } }
    fun setCollectionSort(sort: CollectionSort) { viewModelScope.launch { repo.setCollectionSort(sort) } }

    // ---------------------------------------------------------------- network catalogue (6.6.0)

    fun setCatalogProvider(id: String) { viewModelScope.launch { repo.setCatalogProvider(id) } }
    /** 6.36.0: единственный переключатель источника, который вообще имеет смысл нажать. */
    fun setYoutubeDirect(value: Boolean) { viewModelScope.launch { repo.setYoutubeDirect(value) } }
    fun setWifiOnly(value: Boolean) { viewModelScope.launch { repo.setWifiOnly(value) } }
    fun setStreamCacheEnabled(value: Boolean) { viewModelScope.launch { repo.setStreamCacheEnabled(value) } }

    // ---- own resolver (6.10.0) ----
    fun setResolverUrl(value: String) { viewModelScope.launch { repo.setResolverUrl(value) } }
    fun setResolverToken(value: String) { viewModelScope.launch { repo.setResolverToken(value) } }
    fun setResolverProxy(value: Boolean) { viewModelScope.launch { repo.setResolverProxy(value) } }

    /** 6.11.0: unlocks the technical rows. See the version row in SettingsSheet. */
    fun setDevMode(value: Boolean) { viewModelScope.launch { repo.setDevMode(value) } }

    /* ------------------------------------------------- служебный доступ (6.17.0) ---- */

    /**
     * Сессия служебного доступа. Живёт в памяти ViewModel и умирает вместе с процессом — это и
     * есть половина защиты: «случайно открыл» больше не значит «открыто до переустановки».
     */
    private val _devSession = MutableStateFlow(false)
    private var devSessionJob: Job? = null

    val devUnlocked: StateFlow<Boolean> = combine(
        repo.settings.map { it.devMode }.distinctUntilChanged(), _devSession
    ) { persisted, session -> persisted || session }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** true — код принят. Ни причин отказа, ни счётчика попыток наружу не отдаём. */
    fun unlockDev(code: String): Boolean {
        if (!DevAccess.check(code)) return false
        _devSession.value = true
        devSessionJob?.cancel()
        devSessionJob = viewModelScope.launch {
            delay(DevAccess.SESSION_MS)
            _devSession.value = false
        }
        return true
    }

    fun lockDev() {
        devSessionJob?.cancel()
        _devSession.value = false
        if (!DevAccess.protected) setDevMode(false)
    }

    private val _resolverStatus = MutableStateFlow<String?>(null)
    val resolverStatus: StateFlow<String?> = _resolverStatus.asStateFlow()

    /**
     * Asks the server whether it is alive, separately from resolving a track.
     *
     * The two failures are different and must not be confused: an unreachable server is a network
     * or firewall question (port 8080), while a server that answers /health and fails /resolve is
     * yt-dlp or the IP reputation. One row per question.
     */
    fun probeResolver() {
        viewModelScope.launch {
            if (!app.ziziplayer.data.remote.ZiziResolve.configured) {
                _resolverStatus.value = "Адрес сервера не задан"
                return@launch
            }
            _resolverStatus.value = "Проверяю сервер…"
            _resolverStatus.value = app.ziziplayer.data.remote.ZiziResolve.health()
        }
    }

    fun setStreamQuality(quality: RemoteQuality) { viewModelScope.launch { repo.setStreamQuality(quality) } }

    fun cycleStreamQuality() {
        viewModelScope.launch {
            val next = when (repo.settings.first().streamQuality) {
                RemoteQuality.LOW -> RemoteQuality.NORMAL
                RemoteQuality.NORMAL -> RemoteQuality.HIGH
                RemoteQuality.HIGH -> RemoteQuality.LOW
            }
            repo.setStreamQuality(next)
        }
    }

    @OptIn(UnstableApi::class)
    /**
     * What the last resolved stream actually was, or null before anything has played.
     *
     * Read straight from [ResolvedStreams] rather than mirrored into a StateFlow: it is a
     * diagnostic that is only ever looked at while the settings sheet is open, and giving it a flow
     * would mean the resolver publishing to the UI from the Media3 loader thread for no reader.
     */
    fun streamStatusLabel(): String? = ResolvedStreams.lastLabel

    fun streamCacheLabel(): String {
        val bytes = StreamCache.sizeBytes()
        return if (bytes <= 0) "Кэш пуст" else "Занято %.1f МБ".format(bytes / 1024.0 / 1024.0)
    }

    @OptIn(UnstableApi::class)
    fun clearStreamCache() {
        if (_wipe.value.running) return
        viewModelScope.launch(Dispatchers.IO) {
            runWipe(WipeKind.STREAM_CACHE, { StreamCache.sizeBytes() }) { report ->
                StreamCache.clear(report)
                // The hub snapshot goes with it. It is the same promise to the user - "clear what you
                // downloaded for me" - and leaving a 30 minute old shelf list behind after they asked
                // for a clean slate is the kind of small lie that costs trust in a settings screen.
                HubCache.clear(getApplication<Application>())
            }
        }
    }

    /**
     * Starts playback of remote tracks.
     *
     * The rows are written to the database first, and only then handed to the player: the queue,
     * the mini player and the play counters all work by resolving a track id, so a track that is
     * playing has to exist as a row. It is written unsaved - listening is not keeping.
     */
    fun playRemote(tracks: List<RemoteTrack>, index: Int = 0) {
        if (tracks.isEmpty()) return
        StartupTrace.mark(StartupTrace.Stage.TAP_REMOTE)
        viewModelScope.launch {
            val entities = repo.rememberRemote(tracks)
            if (entities.isEmpty()) return@launch
            player.setQueue(entities, index.coerceIn(entities.indices))
        }
    }

    fun setRemoteSaved(trackId: String, saved: Boolean) {
        viewModelScope.launch { repo.setRemoteSaved(trackId, saved) }
    }

    /**
     * "+ в медиатеку" from a search result.
     *
     * Two steps, in this order, and the order is the whole function: a result the user has only
     * looked at may not have a row yet, and `setRemoteSaved` is an UPDATE - on a missing row it
     * succeeds, changes nothing, and the plus silently stays a plus. Writing the row first makes
     * the operation work on a track the user never played.
     */
    fun saveRemote(track: RemoteTrack) {
        viewModelScope.launch {
            repo.rememberRemote(listOf(track))
            repo.setRemoteSaved(track.trackId, true)
            _messages.send(
                UiMessage(
                    text = "«${track.title}» в медиатеке",
                    actionLabel = "Отменить",
                    action = { setRemoteSaved(track.trackId, false) }
                )
            )
        }
    }

    /** Saves a whole album or playlist. One database pass, one message. */
    fun saveRemoteAll(tracks: List<RemoteTrack>) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            repo.rememberRemote(tracks)
            tracks.forEach { repo.setRemoteSaved(it.trackId, true) }
            _messages.send(UiMessage("Добавлено: ${tracks.size}"))
        }
    }

    fun clearPlaybackError() = player.clearError()

    /** Повторить текущий трек после ошибки. 6.66.0: очередь больше не уезжает сама, поэтому
     *  у остановки должен быть явный выход, а не только сообщение. */
    fun retryPlayback() = player.retryCurrent()

    /**
     * The connection probe behind "Проверить подключение" in settings.
     *
     * It exists because this feature depends on somebody else's private API, which will break, and
     * when it does the only question that matters is WHICH layer broke. So the probe reports the
     * failure reason verbatim - the provider, the CatalogException reason, the message - instead of
     * a friendly "что-то пошло не так" that carries no information to whoever has to fix it.
     */
    private val _catalogProbe = MutableStateFlow<String?>(null)
    val catalogProbe: StateFlow<String?> = _catalogProbe.asStateFlow()
    private var probeResults: List<RemoteTrack> = emptyList()

    /**
     * 6.7.0 asked for ONE page here and reported its size, which is why the probe said "20 шт." on
     * a catalogue that was in fact paging correctly - and said exactly the same thing on a
     * catalogue whose paging was broken. A probe that cannot tell those two apart is decoration.
     *
     * Three pages, following the token the way the results screen does, so this row now exercises
     * the pagination itself: the count, the number of pages walked, and whether there is more after
     * them are three separate facts and all three are printed.
     */
    fun probeCatalog(query: String = "phonk") {
        viewModelScope.launch {
            _catalogProbe.value = "Проверяю…"
            val preferred = repo.settings.first().catalogProvider
            try {
                val collected = ArrayList<RemoteTrack>()
                var provider = preferred
                var token: String? = null
                var pages = 0
                while (pages < 3) {
                    val cursor = token
                    val page = repo.catalogs.withFallback(preferred) { catalog ->
                        catalog.search(query, RemoteKind.TRACK, cursor) to catalog.id
                    }
                    provider = page.second
                    collected.addAll(page.first.items.filterIsInstance<RemoteItem.Song>().map { it.track })
                    pages++
                    token = page.first.nextToken
                    if (token == null) break
                }
                probeResults = collected.distinctBy { it.trackId }
                val first = probeResults.firstOrNull()
                val more = if (token == null) "конец" else "есть ещё"
                _catalogProbe.value = when {
                    first == null -> "[$provider] ответ разобран, но треков 0"
                    else -> "[$provider] ${probeResults.size} шт. за $pages стр. ($more). " +
                        "Первый: ${first.title} — ${first.artist}"
                }
            } catch (e: CatalogException) {
                probeResults = emptyList()
                _catalogProbe.value = "Отказ ${e.reason}: ${e.message}"
            } catch (e: Throwable) {
                probeResults = emptyList()
                _catalogProbe.value = "Сбой ${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }

    /** Plays what the probe found: the only way to exercise resolve -> cache -> decoder end to end. */
    fun playProbeResults() = playRemote(probeResults, 0)

    /**
     * The probe that 6.6.0 was missing, and the reason YouTube looked "broken" with no error.
     *
     * [probeCatalog] proves the catalogue parses. It says nothing about whether the URL it produced
     * can actually be fetched - and that is exactly where YouTube failed: search worked, resolve
     * worked, and the GET came back 403 because the app clients now require attestation. From
     * inside the player that is indistinguishable from a corrupt file, so the queue skipped, which
     * is what "сам свайпает треки" was.
     *
     * This resolves one real track and asks the CDN for two bytes of it. The answer names the
     * internal client that succeeded and the HTTP code, so a failure is one line long and points at
     * exactly one layer instead of three.
     */
    fun probeStream() {
        viewModelScope.launch {
            val track = probeResults.firstOrNull()
            if (track == null) {
                _catalogProbe.value = "Сначала «Проверить подключение»"
                return@launch
            }
            _catalogProbe.value = "Резолвлю поток…"
            try {
                val quality = repo.settings.first().streamQuality
                val catalog = repo.catalogs.byId(track.provider)
                    ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник не найден")
                val info = catalog.resolveStream(track.remoteId, quality)
                val verdict = ZiziHttp.probeStream(info.url, info.userAgent)
                _catalogProbe.value = buildString {
                    append("[").append(track.provider)
                    info.client?.let { append(" · ").append(it) }
                    append("] ").append(info.bitrateKbps).append(" кбит/с ").append(info.mimeType)
                    append("\n").append(verdict)
                }
            } catch (e: CatalogException) {
                _catalogProbe.value = "Резолв отказал ${e.reason}: ${e.message}"
            } catch (e: Throwable) {
                _catalogProbe.value = "Сбой резолва ${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }

    /**
     * THE ROW THAT SHOULD HAVE EXISTED IN 6.8.0.
     *
     * [probeStream] prints its verdict into a settings subtitle. A subtitle is two lines wide, so
     * the sentence that mattered - `ANDROID_VR: Войдите, чтобы подтвердить, что вы не робот` - was
     * cut off mid-word, and the verdicts of the four other clients were never shown at all. A
     * diagnostic you cannot read is not a diagnostic, and it cost us a whole release.
     *
     * This one runs [RemoteCatalog.streamReport] - every client, every status, verbatim - and puts
     * the result in a dialog with a copy button. It is deliberately slow and deliberately loud.
     */
    private val _streamReport = MutableStateFlow<List<String>?>(null)
    val streamReport: StateFlow<List<String>?> = _streamReport.asStateFlow()
    private val _reportRunning = MutableStateFlow(false)
    val reportRunning: StateFlow<Boolean> = _reportRunning.asStateFlow()

    fun runStreamReport() {
        if (_reportRunning.value) return
        viewModelScope.launch {
            _reportRunning.value = true
            try {
                val track = probeResults.firstOrNull()
                if (track == null) {
                    // The report needs a real track id, so it takes one the same way the user would:
                    // it searches. That also means the row works on a fresh install, without having
                    // to remember to tap "Проверить подключение" first.
                    _streamReport.value = listOf(
                        "Нет трека для проверки.",
                        "Сначала нажми «Проверить подключение» - отчёту нужен реальный id."
                    )
                    return@launch
                }
                val quality = repo.settings.first().streamQuality
                val catalog = repo.catalogs.byId(track.provider)
                if (catalog == null) {
                    _streamReport.value = listOf("Источник ${track.provider} не найден")
                    return@launch
                }
                val header = listOf(
                    "Отчёт по потоку",
                    "провайдер: ${track.provider} · трек: ${track.title} — ${track.artist}",
                    "качество: ${quality.targetKbps} кбит/с",
                    "—"
                )
                _streamReport.value = header + catalog.streamReport(track.remoteId, quality)
            } catch (e: CatalogException) {
                _streamReport.value = listOf("Отчёт оборвался: ${e.reason} · ${e.message}")
            } catch (e: Throwable) {
                _streamReport.value = listOf("Отчёт оборвался: ${e.javaClass.simpleName} · ${e.message}")
            } finally {
                _reportRunning.value = false
            }
        }
    }

    fun dismissStreamReport() { _streamReport.value = null }

    fun setUiActive(active: Boolean) = player.setUiActive(active)

    /** Called from Activity.onStop, while the scope is still alive. */
    fun savePosition() {
        val id = playback.value.currentTrackId ?: return
        val snapshot = progress.value
        if (snapshot.trackId != null && snapshot.trackId != id) return
        val position = snapshot.positionMs
        viewModelScope.launch { repo.saveLastPosition(id, position) }
    }

    private companion object {
        /**
         * Пауза перед записью тракта на диск. 400 мс — это заметно дольше паузы между двумя
         * кадрами перетаскивания ползунка (16 мс) и заметно короче того, что человек воспримет
         * как «не сохранилось». Меньше — и на каждое движение пальца летит запись в Room.
         */
        const val DSP_SAVE_DELAY_MS = 400L
        /** 6.15.0: потолок сетевых догонок на один импорт. 60 запросов по 120 мс — минута.
         *  Больше — это уже не «подожди секунду», а зависший экран. */
        const val LOOKUP_LIMIT = 60

        const val KEY_FILTER = "library.filter"
        const val KEY_QUERY = "library.query"
        const val KEY_SEARCH_OPEN = "library.searchOpen"
        const val KEY_PLAYLIST = "library.openPlaylist"
        const val KEY_FOLDER = "library.openFolder"
        const val KEY_ARTIST = "library.openArtist"
    }
}
