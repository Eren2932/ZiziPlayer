package app.ziziplayer.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue
import androidx.media3.common.Player

@Composable
fun PlayerScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onClose: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    val queue by vm.queue.collectAsStateWithLifecycle()
    val fx by vm.fx.collectAsStateWithLifecycle()

    var showFx by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        PlayerHeader(
            source = currentTrack?.sourceFolder ?: "ZIZI",
            onClose = onClose,
            onShare = { currentTrack?.let(onShare) }
        )

        Spacer(Modifier.height(6.dp))

        CoverCarousel(
            queue = queue,
            playback = playback,
            accent = p.accent,
            onPageSettled = { vm.seekToIndex(it) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.weight(1f))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 22.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = currentTrack?.title ?: "Ничего не играет",
                    color = p.text,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = currentTrack?.artist ?: "—",
                    color = p.subtext,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(10.dp))
            val favorite = currentTrack != null && state.favoriteIds.contains(currentTrack.id)
            RoundIconButton(
                icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                tint = if (favorite) p.accent else p.text,
                background = p.chip.copy(alpha = 0.55f),
                size = 46,
                iconSize = 22,
                onClick = { currentTrack?.let { vm.toggleFavorite(it) } }
            )
            Spacer(Modifier.width(8.dp))
            RoundIconButton(
                icon = Icons.Filled.MoreVert,
                tint = p.text,
                background = p.chip.copy(alpha = 0.55f),
                size = 46,
                iconSize = 22,
                onClick = { if (currentTrack != null) showMenu = true }
            )
        }

        Spacer(Modifier.height(14.dp))

        val chipColors = remember(p.chip, p.text, p.accent, p.onAccent) {
            ChipColors(p.chip, p.text, p.accent, p.onAccent)
        }
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                val fxActive = fx.speed != 1f || fx.pitch != 1f || fx.reverb > 0
                PillChip(
                    label = if (fxActive) "×%.2f".format(fx.speed) else "Скорость и тон",
                    icon = Icons.Filled.Speed,
                    active = fxActive,
                    palette = chipColors,
                    onClick = { if (currentTrack != null) showFx = true }
                )
            }
            item {
                val left = playback.sleepMinutesLeft
                PillChip(
                    label = if (left != null) "Сон · $left мин" else "Таймер сна",
                    icon = Icons.Filled.Bedtime,
                    active = left != null,
                    palette = chipColors,
                    onClick = { showSleep = true }
                )
            }
            item {
                PillChip(
                    label = "В плейлист",
                    icon = Icons.Filled.PlaylistAdd,
                    active = false,
                    palette = chipColors,
                    onClick = { if (currentTrack != null) showPlaylists = true }
                )
            }
            item {
                PillChip(
                    label = "Папки",
                    icon = Icons.Filled.FolderOpen,
                    active = false,
                    palette = chipColors,
                    onClick = { vm.setFilter(LibraryFilter.FOLDERS); onClose() }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Isolated: the position updates twice per second and must not touch the rest of the screen.
        PlayerProgress(vm)

        Spacer(Modifier.height(6.dp))

        PlayerControls(
            isPlaying = playback.isPlaying,
            shuffle = playback.shuffle,
            repeatMode = playback.repeatMode,
            onShuffle = vm::toggleShuffle,
            onPrevious = vm::previous,
            onPlayPause = vm::playPause,
            onNext = vm::next,
            onRepeat = vm::cycleRepeat
        )

        Spacer(Modifier.height(10.dp))

        PlayerBottomBar(
            queueSize = queue.size,
            onQueue = { showQueue = true },
            onFolders = { vm.setFilter(LibraryFilter.FOLDERS); onClose() }
        )
    }

    val track = currentTrack
    if (showFx && track != null) FxSheet(vm, track) { showFx = false }
    if (showSleep) SleepSheet(playback.sleepMinutesLeft, { vm.setSleepTimer(it); showSleep = false }) { showSleep = false }
    if (showQueue) QueueSheet(
        tracks = queue,
        currentTrackId = playback.currentTrackId,
        isPlaying = playback.isPlaying,
        onPick = { vm.seekToIndex(it) },
        onSaveAsPlaylist = { vm.saveQueueAsPlaylist("Очередь ${queue.size}"); showQueue = false },
        onDismiss = { showQueue = false }
    )
    if (showPlaylists && track != null) PlaylistPickerSheet(
        playlists = state.playlists,
        onPick = { vm.addToPlaylist(it, track.id); showPlaylists = false },
        onCreate = { vm.createPlaylist(it, listOf(track)); showPlaylists = false },
        onDismiss = { showPlaylists = false }
    )
    if (showMenu && track != null) TrackMenuSheet(
        favorite = state.favoriteIds.contains(track.id),
        plays = 0,
        sleepMinutesLeft = playback.sleepMinutesLeft,
        track = track,
        inPlaylist = state.openPlaylist,
        onDismiss = { showMenu = false },
        onFx = { showMenu = false; showFx = true },
        onSleep = { showMenu = false; showSleep = true },
        onAddToPlaylist = { showMenu = false; showPlaylists = true },
        onRemoveFromPlaylist = {
            state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
            showMenu = false
        },
        onToggleFavorite = { vm.toggleFavorite(track); showMenu = false },
        onHide = { vm.removeFromApp(track); showMenu = false },
        onDeleteFile = { showMenu = false; confirmDelete = track },
        onShare = { onShare(track); showMenu = false }
    )
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Это действие нельзя отменить.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
}

@Composable
private fun PlayerHeader(source: String, onClose: () -> Unit, onShare: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(
            icon = Icons.Filled.KeyboardArrowDown,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            iconSize = 30,
            onClick = onClose
        )
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "ПАПКА НА УСТРОЙСТВЕ",
                color = p.subtext.copy(alpha = 0.85f),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp
            )
            Text(
                text = source,
                color = p.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
        RoundIconButton(
            icon = Icons.Filled.Share,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            iconSize = 22,
            onClick = onShare
        )
    }
}

/**
 * Cover carousel.
 *
 * Geometry is measured from the VK reference on a 1080 px screen: the paused cover is 808 px
 * (74.6 % of the width) and its neighbours peek out by 89 px. So the pager is laid out at the
 * PAUSED size and the playing state only scales the focused page up by 1.114 inside a
 * graphicsLayer. Nothing is re-measured when playback starts or stops, which is why the
 * transition cannot stutter, and the side covers become clearly visible on pause.
 */
@Composable
private fun CoverCarousel(
    queue: List<TrackEntity>,
    playback: PlaybackState,
    accent: Color,
    onPageSettled: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (queue.isEmpty()) {
        BoxWithConstraints(modifier) {
            val size = maxWidth * 0.746f
            Box(
                Modifier
                    .size(maxWidth * 0.831f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                TrackArtwork(
                    track = null,
                    maxPx = ARTWORK_FULL_PX,
                    modifier = Modifier
                        .size(size)
                        .clip(RoundedCornerShape(size * 0.085f)),
                    glyphSize = 64
                )
            }
        }
        return
    }

    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = playback.currentIndex.coerceIn(queue.indices)) { queue.size }
    var programmatic by remember { mutableStateOf(false) }

    // Playing/paused factor: animated as a plain Animatable and read only inside graphicsLayer,
    // so the whole 320 ms transition happens in the draw phase without a single recomposition.
    val playFactor = remember { Animatable(if (playback.isPlaying) 1f else 0f) }
    LaunchedEffect(playback.isPlaying) {
        playFactor.animateTo(
            if (playback.isPlaying) 1f else 0f,
            spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium)
        )
    }

    // Finger wins: the player follows the pager only once the page has actually settled.
    LaunchedEffect(pagerState, queue.size) {
        snapshotFlow { pagerState.settledPage }
            .drop(1)
            .distinctUntilChanged()
            .collect { page ->
                if (programmatic) return@collect
                if (page !in queue.indices) return@collect
                if (page == playback.currentIndex) return@collect
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onPageSettled(page)
            }
    }
    // Player wins when the track changed elsewhere (notification, auto next) - but never mid-swipe.
    LaunchedEffect(playback.currentIndex, queue.size) {
        val target = playback.currentIndex
        if (target !in queue.indices) return@LaunchedEffect
        if (pagerState.isScrollInProgress || pagerState.currentPage == target) return@LaunchedEffect
        programmatic = true
        if ((pagerState.currentPage - target).absoluteValue > 2) pagerState.scrollToPage(target)
        else pagerState.animateScrollToPage(target)
        programmatic = false
    }

    BoxWithConstraints(modifier) {
        val screenWidth = maxWidth
        val pausedCover = screenWidth * 0.746f
        val playingCover = screenWidth * 0.831f
        val sidePadding = (screenWidth - pausedCover) / 2
        val corner = pausedCover * 0.085f
        val shape = remember(corner) { RoundedCornerShape(corner) }

        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = sidePadding),
            pageSpacing = 17.dp,
            beyondViewportPageCount = 1,
            key = { index -> queue.getOrNull(index)?.id ?: index.toString() },
            modifier = Modifier
                .fillMaxWidth()
                .height(playingCover)
        ) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(pausedCover)
                        .graphicsLayer {
                            // Deferred reads: scroll offset and play factor only trigger a redraw.
                            val distance = ((pagerState.currentPage - page) +
                                pagerState.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            val focus = 1f - distance
                            val play = playFactor.value
                            val scale = lerp(0.94f, lerp(1f, 1.114f, play), focus)
                            scaleX = scale
                            scaleY = scale
                            // Paused: neighbours are clearly visible.
                            // Playing: neighbours are fully transparent AT REST and fade in
                            // proportionally to the swipe, so exactly one cover is on screen while
                            // the music plays without making the gesture feel unresponsive.
                            val drag = pagerState.currentPageOffsetFraction.absoluteValue.coerceIn(0f, 1f)
                            val neighbour = lerp(0.92f, 0.95f * drag, play)
                            alpha = lerp(neighbour, 1f, focus)
                        }
                        .shadow(18.dp, shape, ambientColor = accent, spotColor = accent)
                        .clip(shape)
                ) {
                    TrackArtwork(
                        track = queue.getOrNull(page),
                        maxPx = ARTWORK_FULL_PX,
                        modifier = Modifier.fillMaxSize(),
                        glyphSize = 62
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerProgress(vm: MainViewModel) {
    val p = LocalPalette.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var scrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }
    var releaseJob by remember { mutableStateOf<Job?>(null) }

    // The controller now falls back to the duration stored in our own database, so this is never
    // the bogus 1 ms that used to send a seek straight to the end of the track.
    val duration = progress.durationMs.coerceAtLeast(1L)
    val seekable = progress.durationMs > 0L
    val fraction = if (scrubbing) scrubFraction
    else (progress.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    val shownPosition = if (scrubbing) (scrubFraction * duration).toLong() else progress.positionMs

    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        ZiziSlider(
            fraction = fraction,
            accent = p.accent,
            inactive = p.chip,
            onScrubStart = { scrubbing = true; scrubFraction = fraction },
            onScrub = { scrubFraction = it },
            onScrubEnd = { value ->
                // Covers taps too: hold the thumb where the finger left it, no jump back.
                scrubbing = true
                scrubFraction = value
                if (seekable) vm.seekTo((value * duration).toLong())
                // The controller latches the new position for a second, so a short hold is enough.
                // The previous release is cancelled, otherwise overlapping gestures fought over it.
                releaseJob?.cancel()
                releaseJob = scope.launch { delay(260); scrubbing = false }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            Text(formatTime(shownPosition), color = p.subtext, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(
                "-" + formatTime((duration - shownPosition).coerceAtLeast(0)),
                color = p.subtext,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun PlayerControls(
    isPlaying: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    onShuffle: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        RoundIconButton(
            icon = Icons.Filled.Shuffle,
            tint = if (shuffle) p.accent else p.text,
            background = Color.Transparent,
            size = 50,
            iconSize = 24,
            onClick = onShuffle
        )
        RoundIconButton(
            icon = Icons.Filled.SkipPrevious,
            tint = p.text,
            background = Color.Transparent,
            size = 58,
            iconSize = 34,
            onClick = onPrevious
        )
        RoundIconButton(
            icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            tint = p.text,
            background = Color.Transparent,
            size = 74,
            iconSize = 52,
            onClick = onPlayPause
        )
        RoundIconButton(
            icon = Icons.Filled.SkipNext,
            tint = p.text,
            background = Color.Transparent,
            size = 58,
            iconSize = 34,
            onClick = onNext
        )
        RoundIconButton(
            icon = when (repeatMode) {
                Player.REPEAT_MODE_ONE -> Icons.Filled.RepeatOne
                else -> Icons.Filled.Repeat
            },
            tint = if (repeatMode == Player.REPEAT_MODE_OFF) p.text else p.accent,
            background = Color.Transparent,
            size = 50,
            iconSize = 24,
            onClick = onRepeat
        )
    }
}

@Composable
private fun PlayerBottomBar(queueSize: Int, onQueue: () -> Unit, onFolders: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.22f))
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .clickable(onClick = onQueue)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.QueueMusic, null, tint = p.text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Очередь", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text("$queueSize", color = p.subtext, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Row(
            Modifier
                .weight(1f)
                .clickable(onClick = onFolders)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.FolderOpen, null, tint = p.text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Папки", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}
