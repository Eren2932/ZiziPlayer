package app.ziziplayer.ui;

import java.time.Instant;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Random;

/** Executes production math/pixels/dates without Android. Not screenshot or gesture testing. */
public final class Profile6700Checks {
    private static int checks;
    private static void check(boolean value) { checks++; if (!value) throw new AssertionError("check " + checks); }
    private static void near(float a, float b) { check(Math.abs(a - b) < .0001f); }
    private static long ms(String value) { return Instant.parse(value).toEpochMilli(); }
    public static void main(String[] args) {
        near(ProfileGeometry.scale(360), 1); near(ProfileGeometry.scale(720), 1.6f);
        for (float width : new float[] {280,320,360,393,411,480,600,840}) {
            float scale = ProfileGeometry.scale(width);
            float previous = 0;
            for (int y = 0; y <= 1600; y++) {
                float opacity = ProfileGeometry.sheetOpacity(0, y, scale);
                check(opacity >= previous && opacity >= 0 && opacity <= 1); previous = opacity;
                near(ProfileGeometry.sheetOpacity(40, y, scale), ProfileGeometry.sheetOpacity(0, y + 40, scale));
                check(ProfileGeometry.backgroundOffset(y) <= 0);
            }
            near(ProfileGeometry.sheetOpacity(0, ProfileGeometry.SHEET_END * scale, scale), 1);
            near(ProfileGeometry.sheetOpacity(0, ProfileGeometry.SHEET_START * scale, scale), 0);
            // Header/curtain continuity when the first lazy item is disposed.
            float hero = 431 * scale;
            near(ProfileGeometry.sheetOpacity(0, hero - 1, scale), 1);
            near(ProfileGeometry.sheetOpacity(0, hero, scale), 1);
            for (float nameHeight : new float[] {38,76,114,152}) {
                float bottom = (200 + 120 + 16 + nameHeight) * scale - 24;
                float toolbar = 56;
                float previousProgress = 0;
                for (int s = 0; s <= 1500; s++) {
                    float progress = ProfileGeometry.collapse(s, bottom, toolbar);
                    check(progress >= previousProgress && progress >= 0 && progress <= 1);
                    previousProgress = progress;
                }
                near(ProfileGeometry.collapse(bottom - toolbar, bottom, toolbar), 1);
                near(ProfileGeometry.collapse(bottom - toolbar - 24, bottom, toolbar), 0);
            }
        }
        near(ProfileGeometry.collapse(200, 0, 56), 0);
        check(ProfilePresentation.tracks(1).equals("1 трек"));
        check(ProfilePresentation.tracks(2).equals("2 трека"));
        check(ProfilePresentation.tracks(11).equals("11 треков"));
        check(ProfilePresentation.tracks(21).equals("21 трек"));
        check(ProfilePresentation.tracks(112).equals("112 треков"));
        check(ProfilePresentation.tracks(-1).equals("0 треков"));
        check(ProfilePresentation.musicTime(-2).equals("0 мин"));
        check(ProfilePresentation.musicTime(86L * 3600000).equals("86 ч"));
        long now = ms("2026-09-28T21:30:00Z");
        long saved = ms("2026-09-28T20:00:00Z") / 1000;
        ZoneId moscow = ZoneId.of("Europe/Moscow"), utc = ZoneId.of("UTC");
        check(ProfilePresentation.cloud(false,true,false,false,false,true,true,saved,now,utc).text.equals("сохранено сегодня"));
        check(ProfilePresentation.cloud(false,true,false,false,false,true,true,saved,now,moscow).text.equals("сохранено вчера"));
        check(ProfilePresentation.cloud(false,true,false,false,false,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(true,true,false,false,false,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,false,false,false,false,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,true,false,false,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,true,false,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,true,true,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,false,false,true,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,false,true,false,saved,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,false,true,true,0,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,false,true,true,Long.MAX_VALUE,now,utc).confirmed);
        check(!ProfilePresentation.cloud(false,true,false,false,false,true,true,saved+86400*5,now,utc).confirmed);
        check(ProfilePresentation.cloud(false,true,false,false,false,true,true,ms("2025-02-03T12:00:00Z")/1000,now,utc).text.equals("сохранено 03.02.2025"));
        // Pixel core versus deliberately slow, independent convolution oracle.
        Random random = new Random(6700);
        for (int w : new int[] {1,2,9,16}) for (int h : new int[] {1,3,12}) for (int radius : new int[] {0,1,5,32}) {
            int[] input = new int[w*h]; for (int i=0;i<input.length;i++) input[i] = random.nextInt();
            int[] copy = input.clone();
            check(Arrays.equals(ProfileBlur.blur(input,w,h,radius), oracle(input,w,h,radius)));
            check(Arrays.equals(input,copy));
        }
        int[] uniform = new int[128*128]; Arrays.fill(uniform,0xffabcdee);
        check(Arrays.equals(uniform,ProfileBlur.blur(uniform,128,128,5)));
        try { ProfileBlur.blur(new int[4], 3, 2, 5); throw new AssertionError("bad dimensions accepted"); }
        catch (IllegalArgumentException expected) { checks++; }
        System.out.println("PASS: " + checks + " production geometry/date/blur assertions; no Android execution.");
    }
    private static int[] oracle(int[] input,int w,int h,int r) {
        int[] a=input.clone();
        for(int pass=0;pass<3;pass++) for(boolean horizontal:new boolean[]{true,false}) {
            int[] out=new int[a.length];
            for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
                int value=0;
                for(int shift:new int[]{0,8,16,24}) {
                    int sum=0;
                    for(int k=-r;k<=r;k++) {
                        int xx=horizontal?Math.max(0,Math.min(w-1,x+k)):x;
                        int yy=horizontal?y:Math.max(0,Math.min(h-1,y+k));
                        sum+=a[yy*w+xx]>>>shift&255;
                    }
                    value|=(sum/(r*2+1))<<shift;
                }
                out[y*w+x]=value;
            }
            a=out;
        }
        return a;
    }
}
