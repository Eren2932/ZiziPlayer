package app.ziziplayer.ui;

import java.util.*;

/** Runs the production projection, not a translated Python implementation. */
public final class LiveOrder6700Checks {
    static long assertions;
    static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        List<String> saved = List.of("c", "a", "b");
        check(ReorderMath.applyOrder(List.of("new", "a", "b", "c"), saved)
            .equals(List.of("new", "c", "a", "b")), "new arrival is first without resetting saved order");
        check(ReorderMath.applyOrder(List.of("new2", "new", "a", "b", "c"), saved)
            .equals(List.of("new2", "new", "c", "a", "b")), "successive batches stay live");
        check(ReorderMath.applyOrder(List.of("new2", "new", "a", "b"), saved)
            .equals(List.of("new2", "new", "a", "b")), "deleted first never resurrected");
        check(ReorderMath.applyOrder(List.of("a", "a", "new"), List.of("gone", "a", "a"))
            .equals(List.of("new", "a")), "duplicates and missing ids safe");
        check(ReorderMath.applyOrder(List.of(), saved).isEmpty(), "empty source overrides order");
        check(ReorderMath.applyOrder(List.of("a", "b"), List.of()).equals(List.of("a", "b")), "no override");
        Random random = new Random(6700);
        for (int trial = 0; trial < 20000; trial++) {
            ArrayList<Integer> current = new ArrayList<>(), order = new ArrayList<>();
            for (int id = 0; id < 100; id++) {
                if (random.nextBoolean()) current.add(id);
                if (random.nextBoolean()) order.add(id);
            }
            Collections.shuffle(current, random); Collections.shuffle(order, random);
            List<Integer> currentBefore = List.copyOf(current), orderBefore = List.copyOf(order);
            List<Integer> result = ReorderMath.applyOrder(current, order);
            Set<Integer> known = new HashSet<>(order), available = new HashSet<>(current);
            List<Integer> newcomers = current.stream().filter(id -> !known.contains(id)).toList();
            List<Integer> old = order.stream().filter(available::contains).toList();
            check(result.subList(0, newcomers.size()).equals(newcomers), "newcomer sort preserved");
            check(result.subList(newcomers.size(), result.size()).equals(old), "manual relative order preserved");
            check(result.size() == current.size(), "all members present exactly once");
            check(new HashSet<>(result).equals(available), "no resurrection/loss");
            check(ReorderMath.applyOrder(result, order).equals(result), "idempotent source update");
            check(current.equals(currentBefore) && order.equals(orderBefore), "immutable inputs");
            List<Integer> filtered = current.stream().filter(id -> id % 3 == 0).toList();
            check(ReorderMath.applyOrder(filtered, order).equals(result.stream().filter(id -> id % 3 == 0).toList()),
                "search/privacy filters cannot alter surviving relative order");
        }
        // Playlist/queue semantics deliberately unchanged: additions retain their own slots.
        check(ReorderMath.mergeSlots(List.of("a", "b", "new"), List.of("b", "a"))
            .equals(List.of("b", "a", "new")), "playlist append contract unchanged");
        System.out.println("PASS: " + assertions + " live-order production assertions; no Android execution.");
    }
}
