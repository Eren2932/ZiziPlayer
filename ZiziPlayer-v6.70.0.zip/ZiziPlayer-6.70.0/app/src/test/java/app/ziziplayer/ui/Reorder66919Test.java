package app.ziziplayer.ui;
import org.junit.Test;
public class Reorder66919Test {
    @Test public void productionOrderAndGeometry() { Reorder66919Checks.main(new String[0]); }
}
