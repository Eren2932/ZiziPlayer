package app.ziziplayer.ui;

import java.util.*;

/** Executes production Java. Does not claim to measure Compose rendering or Media3 playback. */
public final class Reorder66919Checks {
    static long assertions;
    static void check(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for (int n = 1; n <= 60; n++) {
            List<Integer> base = new ArrayList<>();
            for (int i = 0; i < n; i++) base.add(i);
            for (int from = 0; from < n; from++) for (int to = 0; to < n; to++) {
                List<Integer> moved = ReorderMath.move(base, from, to);
                check(moved.size() == n, "size");
                check(new HashSet<>(moved).size() == n, "membership");
                check(moved.get(to) == from, "exact destination");
                check(ReorderMath.move(moved, to, from).equals(base), "inverse");
                List<Integer> others = new ArrayList<>(moved); others.remove(Integer.valueOf(from));
                List<Integer> original = new ArrayList<>(base); original.remove(Integer.valueOf(from));
                check(others.equals(original), "other rows retain order");
                check(base.get(from) == from, "input immutable");
            }
        }
        check(ReorderMath.mergeSlots(List.of("a", "hidden", "b", "new", "c"), List.of("c", "a", "b"))
            .equals(List.of("c", "hidden", "a", "new", "b")), "unseen slots");
        check(ReorderMath.mergeSlots(List.of("a", "c"), List.of("c", "deleted", "a"))
            .equals(List.of("c", "a")), "deleted not resurrected");
        check(ReorderMath.applyOrder(List.of("new", "a", "c"), List.of("c", "deleted", "a"))
            .equals(List.of("new", "c", "a")), "new tracks visible before saved order");
        // Same song twice; occurrence keys, not song IDs, identify the queue row.
        check(ReorderMath.move(List.of("song#1", "b#1", "song#2"), 2, 0)
            .equals(List.of("song#2", "song#1", "b#1")), "duplicate songs");
        boolean rejected = false;
        try { ReorderMath.mergeSlots(List.of("a", "b"), List.of("b", "b")); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "duplicate keys rejected");
        for (int height : new int[]{48, 64, 192, 288}) {
            // Start in slot 1 and move towards slot 0. A little over half a row is enough.
            check(!ReorderMath.crossesNeighbour(height * .5f, height, 0, height, false), "hold deadband");
            check(ReorderMath.crossesNeighbour(height * .4f, height, 0, height, false), "half-row threshold");
            // After that swap, a stationary finger must not immediately swap it back.
            for (int jitter = -3; jitter <= 3; jitter++)
                check(!ReorderMath.crossesNeighbour(height * .4f + jitter, height, height, height, true), "no reversal jitter");
            check(ReorderMath.crossesNeighbour(0, height, 0, height, false), "exact first slot reachable");
            check(ReorderMath.crossesNeighbour(height, height, height, height, true), "exact last slot reachable");
        }
        check(ReorderMath.crossesNeighbour(90, 100, 100, 150, true), "variable-height row");
        Random random = new Random(66919);
        for (int trial = 0; trial < 10000; trial++) {
            List<Integer> current = new ArrayList<>(), chosen = new ArrayList<>();
            for (int i = 0; i < 100; i++) { current.add(i); if (random.nextBoolean()) chosen.add(i); }
            Collections.shuffle(chosen, random);
            List<Integer> merged = ReorderMath.mergeSlots(current, chosen);
            check(new HashSet<>(merged).equals(new HashSet<>(current)), "random membership");
            for (int i = 0; i < 100; i++) if (!chosen.contains(i))
                check(merged.get(i) == i, "random unseen position");
        }
        for (int y = -100; y <= 1100; y++) {
            float speed = ReorderMath.edgeSpeed(y, 0, 1000, 72, 1100);
            check(Math.abs(speed) <= 1100, "bounded speed");
            check(Math.abs(speed + ReorderMath.edgeSpeed(1000-y, 0, 1000, 72, 1100)) < .01f, "symmetry");
            if (y >= 72 && y <= 928) check(speed == 0, "no scrolling in centre");
        }
        check(ReorderMath.viewportStart(-8, 8, 56) == 56, "padding and toolbar are excluded");
        check(ReorderMath.viewportEnd(800, 124, 56) == 676, "mini-player/navigation reserve is excluded");
        check(ReorderMath.edgeSpeed(660, 56, ReorderMath.viewportEnd(800, 124, 56), 72, 1100) > 0,
            "bottom scroll starts ABOVE the mini-player");
        check(ReorderMath.viewportEnd(40, 124, 56) == 56, "short viewport is nonnegative");
        check(ReorderMath.viewportStart(0, 0, 0) == 0 && ReorderMath.viewportEnd(640, 0, 0) == 640,
            "queue viewport unchanged without padding");
        for (int hz : new int[]{60, 90, 120}) {
            float distance = 0;
            long previous = 1;
            for (int i = 1; i <= hz; i++) {
                long now = 1 + Math.round(i * 1_000_000_000.0 / hz);
                distance += ReorderMath.edgeSpeed(0, 0, 1000, 72, 1100) * ReorderMath.frameSeconds(previous, now);
                previous = now;
            }
            check(Math.abs(distance + 1100) < .01f, "refresh independent at " + hz);
        }
        check(ReorderMath.frameSeconds(1, 1_000_000_001) == .032f, "long-frame cap");
        check(ReorderMath.frameSeconds(0, 1) == 0, "first frame");
        check(ReorderMath.edgeSpeed(0, 10, 10, 72, 1100) == 0, "zero viewport");
        System.out.println("PASS: " + assertions + " production reorder assertions (not Android rendering)");
    }
}
