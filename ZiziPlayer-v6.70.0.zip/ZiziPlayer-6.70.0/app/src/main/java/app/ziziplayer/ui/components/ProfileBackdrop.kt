package app.ziziplayer.ui.components

import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.CollectionGeometry
import app.ziziplayer.ui.ProfileBlur
import app.ziziplayer.ui.ProfileGeometry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private object ProfileBackdropCache {
    // Exact avatar payload: never a hash-only identity or a retained previous-account image.
    val images = LruCache<String, ImageBitmap>(2)
    val lock = Mutex()
    suspend fun load(avatar: String, source: ImageBitmap): ImageBitmap = lock.withLock {
        images.get(avatar)?.let { return@withLock it }
        val small = Bitmap.createScaledBitmap(source.asAndroidBitmap(), 128, 128, true)
        val pixels = IntArray(128 * 128)
        small.getPixels(pixels, 0, 128, 0, 0, 128, 128)
        val result = Bitmap.createBitmap(ProfileBlur.blur(pixels, 128, 128, 5), 128, 128,
            Bitmap.Config.ARGB_8888).asImageBitmap()
        // createScaledBitmap can return its input. Never recycle the shared avatar cache.
        if (small !== source.asAndroidBitmap()) small.recycle()
        images.put(avatar, result)
        result
    }
}

@Composable
internal fun rememberProfileBackdrop(avatar: String): ImageBitmap? {
    val source = rememberAccountAvatarBitmap(avatar)
    val result by key(avatar, source) {
        produceState(ProfileBackdropCache.images.get(avatar), avatar, source) {
            if (value == null && avatar.isNotBlank() && source != null) {
                value = withContext(Dispatchers.Default) { ProfileBackdropCache.load(avatar, source) }
            }
        }
    }
    return result
}

/** Image moves slowly; the opaque page ramp moves 1:1 with the list, ABOVE the image.
 * This is real occlusion, not translating a rectangular blurred card or blurring each frame.
 * Covers the status region too, so a fast fling/deep restored offset cannot leave a coloured seam.
 */
@Composable
internal fun ProfileBackdrop(avatar: String, color: Color, surface: Color, scale: Float,
    scroll: () -> Float, modifier: Modifier = Modifier) {
    val image = rememberProfileBackdrop(avatar)
    Box(modifier.fillMaxSize().clipToBounds().background(surface)) {
        Box(Modifier.fillMaxWidth().height((ProfileGeometry.BACKDROP_HEIGHT * scale).dp)
            .graphicsLayer { translationY = ProfileGeometry.backgroundOffset(scroll()) }
            .background(if (image == null) color else surface)) {
            if (image != null) {
                Image(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .24f)))
            }
        }
        Box(Modifier.fillMaxSize().drawWithCache {
            val start = (ProfileGeometry.SHEET_START * scale).dp.toPx()
            val end = (ProfileGeometry.SHEET_END * scale).dp.toPx()
            val stops = (0..32).map { index ->
                val t = index / 32f
                t to surface.copy(alpha = CollectionGeometry.smoothstep(t))
            }.toTypedArray()
            val curtain = Brush.verticalGradient(*stops, startY = start, endY = end)
            // No-avatar mode retains the original account-colour -> surface gradient.
            val fallback = Brush.verticalGradient(listOf(color, surface), endY = end)
            onDrawBehind {
                val offset = scroll().coerceAtLeast(0f)
                translate(top = -offset) {
                    drawRect(if (image == null) fallback else curtain,
                        size = Size(size.width, size.height + offset))
                }
            }
        })
    }
}
