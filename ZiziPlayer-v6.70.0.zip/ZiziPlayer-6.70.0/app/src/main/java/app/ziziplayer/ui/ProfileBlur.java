package app.ziziplayer.ui;

/** Three separable box passes approximate Gaussian blur. Clamp edges; immutable input.
 * The caller downsamples to 128px BEFORE this CPU work, and runs it off the main thread. */
public final class ProfileBlur {
    private ProfileBlur() {}
    public static int[] blur(int[] input, int width, int height, int radius) {
        if (width < 1 || height < 1 || (long) width * height != input.length || width > 256 || height > 256)
            throw new IllegalArgumentException("Expected a bounded avatar bitmap");
        int r = Math.max(0, Math.min(radius, 32));
        int[] a = input.clone(), b = new int[a.length];
        if (r == 0) return a;
        for (int pass = 0; pass < 3; pass++) {
            box(a, b, width, height, r, true);
            box(b, a, width, height, r, false);
        }
        return a;
    }
    private static void box(int[] in, int[] out, int w, int h, int r, boolean horizontal) {
        int lines = horizontal ? h : w, length = horizontal ? w : h, divisor = r * 2 + 1;
        for (int line = 0; line < lines; line++) {
            int a = 0, red = 0, green = 0, blue = 0;
            for (int k = -r; k <= r; k++) {
                int p = at(in, line, clamp(k, length), w, horizontal);
                a += p >>> 24; red += p >>> 16 & 255; green += p >>> 8 & 255; blue += p & 255;
            }
            for (int x = 0; x < length; x++) {
                out[horizontal ? line * w + x : x * w + line] =
                    (a / divisor << 24) | (red / divisor << 16) | (green / divisor << 8) | blue / divisor;
                int remove = at(in, line, clamp(x - r, length), w, horizontal);
                int add = at(in, line, clamp(x + r + 1, length), w, horizontal);
                a += (add >>> 24) - (remove >>> 24);
                red += (add >>> 16 & 255) - (remove >>> 16 & 255);
                green += (add >>> 8 & 255) - (remove >>> 8 & 255);
                blue += (add & 255) - (remove & 255);
            }
        }
    }
    private static int clamp(int x, int size) { return Math.max(0, Math.min(x, size - 1)); }
    private static int at(int[] p, int line, int x, int w, boolean horizontal) {
        return p[horizontal ? line * w + x : x * w + line];
    }
}
