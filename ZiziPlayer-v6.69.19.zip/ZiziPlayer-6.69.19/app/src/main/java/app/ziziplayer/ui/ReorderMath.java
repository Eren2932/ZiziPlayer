package app.ziziplayer.ui;

import java.util.*;

/** Pure order/geometry policy. No UI, database, timing or Android dependencies. */
public final class ReorderMath {
    private ReorderMath() {}

    public static <T> List<T> move(List<T> items, int from, int to) {
        ArrayList<T> result = new ArrayList<>(items);
        if (from < 0 || to < 0 || from >= items.size() || to >= items.size()) return result;
        if (from != to) result.add(to, result.remove(from));
        return result;
    }

    /** Replace only the requested slots; unseen/new/locked members stay in place. */
    public static <T> List<T> mergeSlots(List<T> current, List<T> requested) {
        Set<T> wanted = new HashSet<>(requested);
        if (wanted.size() != requested.size()) throw new IllegalArgumentException("Duplicate keys");
        ArrayList<T> present = new ArrayList<>();
        Set<T> available = new HashSet<>(current);
        for (T key : requested) if (available.contains(key)) present.add(key);
        Iterator<T> ordered = present.iterator();
        ArrayList<T> result = new ArrayList<>(current.size());
        for (T key : current) result.add(wanted.contains(key) ? ordered.next() : key);
        return result;
    }

    /** Saved members first, newcomers afterwards in their normal sort order. O(n). */
    public static <T> List<T> applyOrder(List<T> current, List<T> saved) {
        LinkedHashSet<T> remaining = new LinkedHashSet<>(current);
        ArrayList<T> result = new ArrayList<>(current.size());
        for (T key : saved) if (remaining.remove(key)) result.add(key);
        result.addAll(remaining);
        return result;
    }

    /** Leading edge crosses the neighbour's centre, with 8% hysteresis against jitter.
     * Using the dragged CENTRE here would require a whole-row movement and miss first/last slots.
     */
    public static boolean crossesNeighbour(float top, float height, float otherTop, float otherHeight, boolean down) {
        float midpoint = otherTop + otherHeight / 2f;
        float hysteresis = Math.min(height, otherHeight) * 0.08f;
        return down ? top + height > midpoint + hysteresis : top < midpoint - hysteresis;
    }

    /** The drag viewport excludes the pinned toolbar and content padding reserved for bottom chrome. */
    public static float viewportStart(int offset, int beforePadding, float overlay) {
        return offset + beforePadding + Math.max(0f, overlay);
    }

    public static float viewportEnd(int offset, int afterPadding, float start) {
        return Math.max(start, offset - Math.max(0, afterPadding));
    }

    /** Pixels/second, quadratic edge acceleration; independent of refresh rate. */
    public static float edgeSpeed(float center, float top, float bottom, float band, float maxSpeed) {
        if (!(bottom > top) || !(band > 0f)) return 0f;
        band = Math.min(band, (bottom - top) / 2f);
        float start = Math.max(0f, Math.min(1f, (top + band - center) / band));
        float end = Math.max(0f, Math.min(1f, (center - bottom + band) / band));
        return (end * end - start * start) * maxSpeed;
    }

    public static float frameSeconds(long previous, long now) {
        if (previous == 0L || now <= previous) return 0f;
        return Math.min((now - previous) / 1_000_000_000f, 0.032f);
    }
}
