#!/usr/bin/env python3
"""Быстрая проверка исходников до сборки: незакрытые блочные комментарии,
строки и скобки. Ловит именно тот класс ошибок, который сломал 6.19.0:
последовательность "/*" внутри KDoc открывает ВЛОЖЕННЫЙ комментарий
(в Kotlin блочные комментарии вкладываются), и файл молча съедается до конца.

Запуск:  python3 tools/check_kotlin_syntax.py app/src
Код возврата 1, если найдены проблемы, — годится для CI-шага перед gradle.
"""
import sys,glob,os
def check(p):
    s=open(p,encoding='utf-8').read()
    i=0;n=len(s);depth=0;brace=0;paren=0;issues=[]
    line=1
    while i<n:
        c=s[i]
        if c=='\n': line+=1;i+=1;continue
        if depth>0:
            if s.startswith('/*',i): depth+=1;i+=2;continue
            if s.startswith('*/',i): depth-=1;i+=2;continue
            i+=1;continue
        if s.startswith('/*',i):
            depth=1;i+=2;continue
        if s.startswith('//',i):
            j=s.find('\n',i); i=n if j<0 else j; continue
        if s.startswith('"""',i):
            j=s.find('"""',i+3)
            if j<0: issues.append((line,'unclosed raw string'));break
            line+=s.count('\n',i,j+3); i=j+3; continue
        if c=='"':
            i+=1
            while i<n:
                if s[i]=='\\': i+=2; continue
                if s[i]=='"': i+=1; break
                if s[i]=='\n': issues.append((line,'unclosed string'));break
                i+=1
            continue
        if c=="'":
            i+=1
            while i<n:
                if s[i]=='\\': i+=2;continue
                if s[i]=="'": i+=1;break
                i+=1
            continue
        if c=='{': brace+=1
        elif c=='}': brace-=1
        elif c=='(': paren+=1
        elif c==')': paren-=1
        if brace<0 or paren<0:
            issues.append((line,'negative balance'));break
        i+=1
    if depth!=0: issues.append(('EOF','unclosed block comment depth=%d'%depth))
    if brace!=0: issues.append(('EOF','brace balance %d'%brace))
    if paren!=0: issues.append(('EOF','paren balance %d'%paren))
    return issues
bad=0
root = sys.argv[1] if len(sys.argv) > 1 else 'app/src'
for p in glob.glob(root+'/**/*.kt',recursive=True)+glob.glob(root+'/**/*.kts',recursive=True):
    iss=check(p)
    if iss:
        bad+=1
        print(p)
        for l,m in iss: print('   ',l,m)
print('files with issues:',bad)
raise SystemExit(1 if bad else 0)
