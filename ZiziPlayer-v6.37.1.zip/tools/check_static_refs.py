#!/usr/bin/env python3
"""Проверка квалифицированных ссылок Type.member по исходникам проекта.

Ловит класс ошибок, который сломал 6.19.1: обращение к члену ЭКЗЕМПЛЯРА через имя класса
(`InnertubeCatalog.id`, где `id` — override val из интерфейса, а не companion-константа).
Компилятор говорит про это «Unresolved reference», но узнать об этом можно за секунду здесь,
а не через минуту сборки в CI.

Запуск: python3 tools/check_static_refs.py app/src/main
"""
import re,glob,sys
from collections import defaultdict

def strip(s):
    out=[];i=0;n=len(s);depth=0
    while i<n:
        if depth>0:
            if s.startswith('/*',i): depth+=1;i+=2;out.append('  ');continue
            if s.startswith('*/',i): depth-=1;i+=2;out.append('  ');continue
            out.append('\n' if s[i]=='\n' else ' ');i+=1;continue
        if s.startswith('/*',i): depth=1;i+=2;out.append('  ');continue
        if s.startswith('//',i):
            j=s.find('\n',i); j=n if j<0 else j; out.append(' '*(j-i)); i=j; continue
        if s.startswith('"""',i):
            j=s.find('"""',i+3); j=n-3 if j<0 else j
            out.append(''.join('\n' if c=='\n' else ' ' for c in s[i:j+3])); i=j+3; continue
        if s[i]=='"':
            j=i+1
            while j<n and s[j]!='"':
                if s[j]=='\\': j+=1
                j+=1
            out.append(' '*(min(j,n-1)-i+1)); i=j+1; continue
        out.append(s[i]); i+=1
    return ''.join(out)

root=sys.argv[1] if len(sys.argv)>1 else 'app/src/main'
src={p:strip(open(p,encoding='utf-8').read()) for p in glob.glob(root+'/**/*.kt',recursive=True)}

decl_re=re.compile(r'(?P<mods>(?:\b(?:public|internal|private|protected|abstract|open|sealed|data|value|inner|enum|annotation|external|final|expect|actual)\s+)*)\b(?P<kind>class|object|interface)\s+(?P<name>[A-Z]\w*)')
member_re=re.compile(r'\n[ \t]*(?:@\w+(?:\([^)\n]*\))?[ \t]*)*(?:\b(?:public|internal|private|protected|override|open|abstract|lateinit|const|suspend|inline|operator|external|final|actual|expect|tailrec|infix|vararg|companion)\b[ \t]+)*(?:val|var|fun|class|object|interface|typealias)[ \t]+(?:<[^>\n]*>[ \t]*)?(?P<n>[A-Za-z_]\w*)')

def body_span(s,pos):
    """Границы тела объявления, начиная с позиции ключевого слова. Фигурные скобки учитываются
    только на нулевой глубине круглых — иначе лямбда в параметре конструктора
    (`= x.ifEmpty { "ru" }`) обрывает тело на первой же строке."""
    i=pos;n=len(s);par=0;ang=0
    while i<n:
        c=s[i]
        if c=='(': par+=1
        elif c==')': par-=1
        elif c=='{' and par==0:
            depth=0
            j=i
            while j<n:
                if s[j]=='{': depth+=1
                elif s[j]=='}':
                    depth-=1
                    if depth==0: return i,j
                j+=1
            return i,n
        elif c=='\n' and par==0 and i+1<n:
            # объявление без тела (интерфейсный метод, class X : Y без скобок)
            rest=s[i+1:i+400]
            if re.match(r'\s*(?:@\w|\b(?:public|internal|private|protected|abstract|open|sealed|data|value|inner|enum|annotation|external|final|expect|actual)\b\s+)*\b(?:class|object|interface|fun|val|var)\b',rest) and '{' not in s[pos:i]:
                return i,i
        i+=1
    return pos,n

types={};spans={}
for p,s in src.items():
    for m in decl_re.finditer(s):
        name=m.group('name');kind=m.group('kind')
        if re.search(r'\benum\b',m.group('mods')): kind='enum'
        a,b=body_span(s,m.start())
        types.setdefault(name,{'kind':kind,'file':p,'line':s[:m.start()].count('\n')+1})
        spans.setdefault(name,(p,a,b))

static_members=defaultdict(set);instance_members=defaultdict(set)
for name,(p,a,b) in spans.items():
    body=src[p][a:b]
    comp=set()
    for cm in re.finditer(r'\bcompanion object\b',body):
        ca,cb=body_span(body,cm.start())
        for mm in member_re.finditer('\n'+body[ca:cb]): comp.add(mm.group('n'))
    direct=set(mm.group('n') for mm in member_re.finditer('\n'+body))
    if types[name]['kind']=='object': static_members[name]|=direct|comp
    else:
        static_members[name]|=comp
        instance_members[name]|=direct
    if types[name]['kind']=='enum':
        head=body[:body.find(';')%(len(body)+1)] if ';' in body else body
        for e in re.findall(r'\b([A-Z][A-Z0-9_]{2,})\b',head): static_members[name].add(e)

ref_re=re.compile(r'(?<![\w.$])([A-Z]\w*)\.([a-zA-Z_]\w*)')
problems=[]
for p,s in src.items():
    for m in ref_re.finditer(s):
        t,mem=m.group(1),m.group(2)
        if t not in types or mem in static_members[t] or mem in types: continue
        kind=types[t]['kind']
        ln=s[:m.start()].count('\n')+1
        if kind!='object' and mem in instance_members[t]:
            problems.append((p,ln,t,mem,f'член экземпляра, а {t} — {kind}: нужна companion-константа или экземпляр'))
        elif kind=='object':
            problems.append((p,ln,t,mem,f'нет такого члена в object {t}'))
for x in problems: print('%s:%d  %s.%s  -> %s'%x)
print('подозрений:',len(problems))
raise SystemExit(1 if problems else 0)
