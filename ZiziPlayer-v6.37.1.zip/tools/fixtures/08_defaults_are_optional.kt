// expect: clean
// Параметры со значениями по умолчанию пропускать можно, и это не повод для претензии.
private fun fx08Box(a: Int, b: Int = 1, c: String = "x", d: Boolean = false) {
    println("" + a + b + c + d)
}

private fun fx08Use() {
    fx08Box(1)
    fx08Box(a = 1, c = "y")
}
