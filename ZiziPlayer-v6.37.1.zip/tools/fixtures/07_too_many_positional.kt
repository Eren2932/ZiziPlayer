// expect: позиционных аргументов
// Лишний позиционный аргумент.
private fun fx07Pair(a: Int, b: Int) {
    println(a + b)
}

private fun fx07Use() {
    fx07Pair(1, 2, 3)
}
