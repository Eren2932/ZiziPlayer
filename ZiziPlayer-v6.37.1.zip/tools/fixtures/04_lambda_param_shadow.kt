// expect: clean
// Имя, объявленное параметром объемлющей функции, не является одноимённой функцией проекта.
// Воспроизводит ложняк PlayerScreen:1015 буквально: параметр `content` внутри слота против
// верхнеуровневой `content(videoId: String)` из другого места проекта.
private fun content(videoId: String): String = videoId

private fun fx04Slot(width: Int, content: () -> Unit) {
    if (width > 0) content()
    println(width)
}

private fun fx04Use() {
    fx04Slot(width = 1, content = { println("x") })
}
