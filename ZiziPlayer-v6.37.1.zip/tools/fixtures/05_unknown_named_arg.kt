// expect: неизвестный именованный аргумент 'labell'
// Опечатка в имени именованного аргумента - то, ради чего проверка вообще существует.
private fun fx05Row(label: String, value: Int) {
    println(label + value)
}

private fun fx05Use() {
    fx05Row(labell = "a", value = 1)
}
