// expect: не передан обязательный 'onChange: (Float) -> Unit'
// Тот же оператор сравнения, но обязательный аргумент ДЕЙСТВИТЕЛЬНО не передан.
// Проверка обязана ругаться: усечение разбора не должно ни прятать ошибку, ни выдумывать её.
private fun fx02Slider(label: String, display: String? = null, onChange: (Float) -> Unit) {
    onChange(0f)
    println(label + display.orEmpty())
}

private fun fx02Use(v: Float) {
    fx02Slider(
        label = "a",
        display = if (v < 0.3f) "низ" else "верх"
    )
}
