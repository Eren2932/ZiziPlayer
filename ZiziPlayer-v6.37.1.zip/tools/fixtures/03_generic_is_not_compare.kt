// expect: clean
// Обратная сторона фикса: настоящий generic в аргументе разбор ломать не должен.
private fun fx03Take(items: List<Map<String, Int>>, limit: Int = 10, sink: (String) -> Unit) {
    sink(items.size.toString() + limit.toString())
}

private fun fx03Use() {
    fx03Take(
        items = listOf(mapOf("a" to 1), mapOf("b" to 2)),
        limit = 3,
        sink = { println(it) }
    )
}
