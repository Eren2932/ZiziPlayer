// expect: clean
// 6.37.1. Оператор сравнения в аргументе не должен открывать угловую скобку.
// До 6.37.1 разбор обрывался на этом аргументе и терял всё правее (EqualizerScreen:272/280).
private fun fx01Slider(label: String, display: String? = null, onChange: (Float) -> Unit) {
    onChange(0f)
    println(label + display.orEmpty())
}

private fun fx01Use(v: Float) {
    fx01Slider(
        label = "a",
        display = if (v < 0.3f) "низ" else if (v < 0.7f) "серёдка" else "верх",
        onChange = { println(it) }
    )
}
