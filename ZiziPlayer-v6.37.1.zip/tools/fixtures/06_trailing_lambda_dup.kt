// expect: хвостовая лямбда дублирует уже заданный 'onDone'
// Хвостовая лямбда при уже переданном том же параметре: компилятор это поймает, но
// проверка обязана поймать раньше, потому что Gradle здесь запустить нечем.
private fun fx06Run(tag: String, onDone: () -> Unit) {
    onDone()
    println(tag)
}

private fun fx06Use() {
    fx06Run(tag = "t", onDone = { println(1) }) { println(2) }
}
