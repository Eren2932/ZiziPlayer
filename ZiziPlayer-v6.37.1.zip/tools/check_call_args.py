#!/usr/bin/env python3
"""
check_call_args.py — сверка вызовов с объявлениями (6.27.2).

Ставится в один ряд с check_kotlin_syntax.py и check_static_refs.py и закрывает класс ошибок,
который те два не видели и которым была утоплена сборка 6.27.1:

    @Composable fun PillChip(label, icon, active, palette, onClick: () -> Unit, modifier = Modifier)
    PillChip("Все", null, active == null, colors) { onPick(null) }

В Kotlin хвостовая лямбда садится на ПОСЛЕДНИЙ параметр, даже если у того есть значение по
умолчанию. Лямбда ушла в modifier, onClick остался незаполненным, и компилятор выдал
«No value passed for parameter 'onClick'» + «Argument type mismatch ... Modifier was expected».
Синтаксис при этом безупречен, ссылки все живые — обе прежние проверки честно молчали.

Что проверяется для функций проекта, объявленных ровно один раз (перегрузки пропускаются):
  * хвостовая лямбда не садится на нефункциональный параметр;
  * хвостовая лямбда не дублирует уже переданный аргумент;
  * именованные аргументы существуют в объявлении;
  * позиционных аргументов не больше, чем параметров (vararg пропускается);
  * все параметры без значения по умолчанию заполнены.

Парсер намеренно грубый (регулярки + балансировка скобок): цель — не типизировать Kotlin, а
поймать расхождение имён и арности за две секунды до Gradle. Аргументы, где встречается
сравнение вида `a < b` без парной `>`, разбираются неточно — такие вызовы могут дать шум;
считать их отказом сборки нельзя, поэтому код возврата всегда 0, а решает человек.
Запуск: python3 tools/check_call_args.py [корень исходников]
"""
import os


def strip_noise(s):
    out=[];i=0;n=len(s)
    while i<n:
        c=s[i]
        if c=='"':
            if s[i:i+3]=='"""':
                j=s.find('"""',i+3); j=n if j<0 else j+3
            else:
                j=i+1
                while j<n and s[j]!='"':
                    if s[j]=='\\': j+=1
                    j+=1
                j=min(j+1,n)
            out.append(''.join('\n' if ch=='\n' else 'S' for ch in s[i:j])); i=j; continue
        if s[i:i+2]=='//':
            j=s.find('\n',i); j=n if j<0 else j
            out.append(' '*(j-i)); i=j; continue
        if s[i:i+2]=='/*':
            j=s.find('*/',i); j=n if j<0 else j+2
            out.append(''.join(ch if ch=='\n' else ' ' for ch in s[i:j])); i=j; continue
        out.append(c); i+=1
    return ''.join(out)

def balanced(s,i,op='(',cl=')'):
    d=0
    for j in range(i,len(s)):
        if s[j]==op:d+=1
        elif s[j]==cl:
            d-=1
            if d==0:return j
    return -1

def split_top(p):
    p=p.replace('->','\x01').replace('>=','\x02').replace('<=','\x03')
    # Kotlin generics пишутся без пробелов (List<String>), сравнение - с пробелами (a < b).
    # Без этой нормализации 'cfg.width < 0.3f' открывает угловую скобку, которая никогда
    # не закрывается, и все аргументы правее теряются (EqualizerScreen:272/280 на 6.35.0-6.37.0).
    p=re.sub(r'(?<=\s)<(?=\s)','\x04',p)
    p=re.sub(r'(?<=\s)>(?=\s)','\x05',p)
    out=[];d=0;ang=0;cur='';prev=''
    for ch in p:
        if ch in '([{':d+=1
        elif ch in ')]}':d-=1
        elif ch=='<':
            if prev.isalnum() or prev in '_>': ang+=1
        elif ch=='>':
            if ang>0: ang-=1
        if ch==',' and d==0 and ang==0: out.append(cur.strip());cur=''
        else: cur+=ch
        if not ch.isspace(): prev=ch
    if cur.strip():out.append(cur.strip())
    if ang>0:
        # Угловые скобки не сошлись - значит, это было сравнение, а не generic.
        # Разбор без учёта углов надёжнее, чем молча потерянный хвост аргументов.
        return split_top_noang(p)
    return [x.replace('\x01','->').replace('\x02','>=').replace('\x03','<=')
             .replace('\x04','<').replace('\x05','>') for x in out]

def split_top_noang(p):
    out=[];d=0;cur=''
    for ch in p:
        if ch in '([{':d+=1
        elif ch in ')]}':d-=1
        if ch==',' and d==0: out.append(cur.strip());cur=''
        else: cur+=ch
    if cur.strip():out.append(cur.strip())
    return [x.replace('\x01','->').replace('\x02','>=').replace('\x03','<=')
             .replace('\x04','<').replace('\x05','>') for x in out]

import re, glob, sys
root = sys.argv[1] if len(sys.argv) > 1 else 'app/src/main'
files=sorted(glob.glob(os.path.join(root,'**','*.kt'),recursive=True))
src={f:strip_noise(open(f).read()) for f in files}
raw={f:open(f).read() for f in files}

sigs={}
vararg_defs={}
for f,s in src.items():
    for m in re.finditer(r'\bfun\s+(?:<[^>]+>\s*)?([A-Za-z_]\w*)\s*\(', s):
        i=m.end()-1; j=balanced(s,i)
        if j<0: continue
        params=[]
        for p in split_top(s[i+1:j]):
            pm=re.match(r'(?:vararg\s+)?(?:crossinline\s+|noinline\s+)?([A-Za-z_]\w*)\s*:\s*(.+)$', p, re.S)
            if not pm: params.append(('?','?',True)); continue
            name=pm.group(1); rest=pm.group(2)
            has_def = bool(re.search(r'(?<![!<>=])=(?!=)', rest))
            typ = re.split(r'(?<![!<>=])=(?!=)', rest)[0].strip()
            params.append((name,typ,has_def))
        sigs.setdefault(m.group(1),[]).append((f,s[:m.start()].count('\n')+1,params))
        if 'vararg' in s[i+1:j]: vararg_defs[m.group(1)]=True

def shadowed_by_param(s, at, name):
    """True, если [name] - параметр объемлющей функции, а не одноимённая функция проекта.

    Так ловился PlayerScreen:1015: `content()` внутри
    TransportSlot(content: @Composable () -> Unit) сверялся с сигнатурой
    PoTokenMinter.content(videoId: String) из другого файла.
    """
    for mm in reversed([x for x in re.finditer(r'\bfun\s', s) if x.start() < at]):
        op = s.find('(', mm.start())
        if op < 0:
            continue
        cl = balanced(s, op)
        if cl < 0 or cl > at:
            continue
        for a in split_top(s[op + 1:cl]):
            if ':' in a and a.split(':')[0].strip().split()[-1] == name:
                return True
        return False
    return False

def is_fn_type(t):
    t=t.strip().rstrip('?')
    return '->' in t or t.startswith('suspend')

issues=0
for f,s in src.items():
    for m in re.finditer(r'(?<![\w.])([A-Za-z_]\w*)\s*\(', s):
        name=m.group(1)
        if name not in sigs: continue
        if re.search(r'\bfun\s+(?:<[^>]+>\s*)?$', s[:m.start()]): continue
        if shadowed_by_param(s, m.start(), name): continue
        if len(sigs[name])!=1: continue
        _,_,params=sigs[name][0]
        i=m.end()-1; j=balanced(s,i)
        if j<0: continue
        args=split_top(s[i+1:j])
        k=j+1
        while k<len(s) and s[k] in ' \t\n': k+=1
        trailing = k<len(s) and s[k]=='{'
        line=s[:m.start()].count('\n')+1
        named=[a.split('=')[0].strip() for a in args if re.match(r'^[A-Za-z_]\w*\s*=(?!=)',a)]
        pos=[a for a in args if not re.match(r'^[A-Za-z_]\w*\s*=(?!=)',a)]
        pnames=[p[0] for p in params]
        prob=[]
        for nm in named:
            if nm not in pnames: prob.append(f"неизвестный именованный аргумент '{nm}'")
        if len(pos)>len(params) and 'vararg' not in ' '.join(p[1] for p in params) and not vararg_defs.get(name):
            prob.append(f"позиционных аргументов {len(pos)} > параметров {len(params)}")
        filled=set(pnames[:len(pos)])|set(named)
        if trailing:
            if not params: prob.append("хвостовая лямбда, а параметров нет")
            else:
                lastn,lastt,_=params[-1]
                if not is_fn_type(lastt):
                    prob.append(f"хвостовая лямбда сядет на '{lastn}: {lastt}' (не функциональный тип)")
                elif lastn in filled:
                    prob.append(f"хвостовая лямбда дублирует уже заданный '{lastn}'")
                filled.add(lastn)
        for pn,pt,pd in params:
            if not pd and pn not in filled and pn!='?':
                prob.append(f"не передан обязательный '{pn}: {pt}'")
        if prob:
            issues+=1
            print(f"{f}:{line}  {name}()  -> " + "; ".join(prob))
print("подозрительных вызовов:", issues)
# Код возврата всегда 0: проверка эвристическая, отказ сборки за шум был бы хуже шума.
sys.exit(0)
