package app.ziziplayer.playback

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/**
 * The on-disk cache for network audio.
 *
 * A single instance, and it has to be: SimpleCache locks its directory and throws if a second
 * instance is created for the same folder. That is a real crash - it happens the moment the service
 * is recreated by the system while the old one is still finishing, which is precisely when nobody
 * is watching logcat.
 *
 * It lives in `cacheDir` on purpose. This is a convenience cache, not a download folder: the system
 * is allowed to reclaim it under storage pressure, and losing it costs bandwidth, not content. The
 * "Скачать" feature, when it arrives, gets its own directory in `filesDir` that Android may not
 * touch - conflating the two is how apps end up "losing" downloads.
 *
 * What the cache buys, beyond saving data:
 *  - seeking backwards inside a track is instant instead of a fresh range request;
 *  - replaying what you just listened to works with no network at all;
 *  - a brief tunnel does not kill playback of the part already fetched.
 */
@UnstableApi
object StreamCache {

    private const val DIR = "zizi-stream"

    @Volatile private var instance: SimpleCache? = null

    fun get(context: Context): SimpleCache {
        instance?.let { return it }
        synchronized(this) {
            instance?.let { return it }
            val dir = File(context.cacheDir, DIR)
            val created = SimpleCache(
                dir,
                LeastRecentlyUsedCacheEvictor(RemoteRuntime.cacheBytes),
                StandaloneDatabaseProvider(context)
            )
            instance = created
            return created
        }
    }

    /** Bytes currently held. Shown in settings; cheap, it is an in-memory counter. */
    fun sizeBytes(): Long = instance?.cacheSpace ?: 0L

    /**
     * Drops every cached byte.
     *
     * Keys are removed one by one rather than by deleting the folder: the folder still has an open
     * index and a lock behind it, and wiping it underneath SimpleCache corrupts that index instead
     * of clearing it.
     */
    fun clear(onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }) {
        val cache = instance ?: run { onProgress(0, 0); return }
        runCatching {
            val keys = cache.keys.toList()
            onProgress(0, keys.size)
            keys.forEachIndexed { index, key ->
                cache.getCachedSpans(key).forEach { span -> runCatching { cache.removeSpan(span) } }
                onProgress(index + 1, keys.size)
            }
        }
    }

    fun release() {
        synchronized(this) {
            runCatching { instance?.release() }
            instance = null
        }
    }
}
