package app.ziziplayer.playback.dsp

/**
 * Библиотека пресетов (6.24.4).
 *
 * Разделены на три группы не для красоты списка, а потому что это три разных действия:
 * ЖАНР правит тембр под музыку, ОБЪЁМ правит пространство (то, чем пользуются эдиторы),
 * УСТРОЙСТВО компенсирует то, на чём слушают. Их можно комбинировать: жанр задаёт кривую,
 * объём — модули, поэтому применение пресета из группы «объём» кривую НЕ трогает.
 */
data class DspPreset(
    val name: String,
    val group: Group,
    /**
     * Что именно пресет меняет — остальное у текущей настройки остаётся как было.
     *
     * Имя НЕ `apply`: одноимённое расширение есть в kotlin-stdlib для любого типа, и вызов
     * `preset.apply(config)` разрешался бы неоднозначно (или молча не туда) — тот класс ошибок,
     * который компилятор пропускает, а поведение ломает.
     */
    val transform: (DspConfig) -> DspConfig
) {
    enum class Group { CURVE, SPACE, DEVICE }
}

object DspPresets {

    private fun bands(vararg v: Float): List<Float> {
        require(v.size == DspConfig.BAND_COUNT)
        return v.toList()
    }

    /** Пресеты кривой: меняют только 10 полос, пре-амп и добротность. */
    val curve: List<DspPreset> = listOf(
        DspPreset("Ровно", DspPreset.Group.CURVE) {
            it.copy(enabled = true, bandsDb = bands(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f), preampDb = 0f)
        },
        DspPreset("Бас+", DspPreset.Group.CURVE) {
            // Пре-амп -3 дБ не декорация: без него +8 на двух нижних полосах гарантированно
            // упирается в лимитер на каждой бочке, и трек начинает «дышать».
            it.copy(enabled = true, preampDb = -3f, bandQ = 1f,
                bandsDb = bands(8f, 7f, 4f, 1f, -1f, 0f, 0f, 1f, 2f, 2f))
        },
        DspPreset("Глубокий низ", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = -4f, bandQ = 0.9f, bassDrive = 0.35f,
                bandsDb = bands(10f, 8f, 3f, 0f, -2f, -2f, 0f, 1f, 1f, 0f))
        },
        DspPreset("Вокал вперёд", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = -1f, bandQ = 1.2f,
                bandsDb = bands(-3f, -2f, 0f, 1f, 3f, 4f, 3f, 1f, 0f, -1f))
        },
        DspPreset("Хип-хоп", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = -3f, bandQ = 1f, bassDrive = 0.25f,
                bandsDb = bands(7f, 6f, 3f, 0f, -2f, 0f, 2f, 3f, 3f, 2f))
        },
        DspPreset("Рок", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = -2f, bandQ = 1f, drive = 0.12f,
                bandsDb = bands(4f, 3f, 1f, -1f, -2f, 0f, 3f, 4f, 3f, 1f))
        },
        DspPreset("Электроника", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = -3f, bandQ = 1.1f, width = 0.25f,
                bandsDb = bands(6f, 5f, 2f, 0f, -2f, -1f, 1f, 3f, 4f, 4f))
        },
        DspPreset("Классика", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = 0f, bandQ = 0.8f, air = 0.2f,
                bandsDb = bands(2f, 2f, 1f, 0f, 0f, 0f, 1f, 2f, 2f, 3f))
        },
        DspPreset("Голос/подкаст", DspPreset.Group.CURVE) {
            it.copy(enabled = true, preampDb = 0f, bandQ = 1.4f,
                bandsDb = bands(-8f, -6f, -2f, 1f, 4f, 4f, 3f, 2f, -1f, -3f))
        },
        DspPreset("Ночь", DspPreset.Group.CURVE) {
            // Тише слушаешь — хуже слышно края (кривые равной громкости). Компенсируем краями.
            it.copy(enabled = true, preampDb = -2f, bandQ = 0.9f,
                bandsDb = bands(5f, 4f, 2f, 0f, -1f, -1f, 0f, 2f, 3f, 4f))
        }
    )

    /** Пресеты пространства: кривую не трогают вообще. Это и есть «эдиторские» варианты. */
    val space: List<DspPreset> = listOf(
        DspPreset("Без эффектов", DspPreset.Group.SPACE) {
            it.copy(underwater = 0f, rotation = 0f, reverbMix = 0f, width = 0f, drive = 0f)
        },
        DspPreset("Под водой", DspPreset.Group.SPACE) {
            it.copy(enabled = true, underwater = 0.62f, reverbMix = 0.28f, reverbSize = 0.7f,
                reverbDamp = 0.75f, width = 0.2f, rotation = 0f)
        },
        DspPreset("Глубоко под водой", DspPreset.Group.SPACE) {
            it.copy(enabled = true, underwater = 0.88f, reverbMix = 0.4f, reverbSize = 0.85f,
                reverbDamp = 0.85f, width = 0.1f, rotation = 0f)
        },
        DspPreset("8D вокруг головы", DspPreset.Group.SPACE) {
            it.copy(enabled = true, rotation = 0.85f, rotationHz = 0.12f, reverbMix = 0.22f,
                reverbSize = 0.55f, width = 0.35f, underwater = 0f)
        },
        DspPreset("8D медленное", DspPreset.Group.SPACE) {
            it.copy(enabled = true, rotation = 0.7f, rotationHz = 0.05f, reverbMix = 0.18f, width = 0.3f)
        },
        DspPreset("Slowed + reverb", DspPreset.Group.SPACE) {
            it.copy(enabled = true, reverbMix = 0.45f, reverbSize = 0.72f, reverbDamp = 0.45f,
                width = 0.3f, air = 0.15f, underwater = 0f, rotation = 0f)
        },
        DspPreset("Собор", DspPreset.Group.SPACE) {
            it.copy(enabled = true, reverbMix = 0.6f, reverbSize = 0.95f, reverbDamp = 0.25f, width = 0.4f)
        },
        DspPreset("Клуб", DspPreset.Group.SPACE) {
            it.copy(enabled = true, reverbMix = 0.25f, reverbSize = 0.45f, reverbDamp = 0.6f,
                bassDrive = 0.3f, drive = 0.18f, width = 0.25f)
        },
        DspPreset("Ламповый", DspPreset.Group.SPACE) {
            it.copy(enabled = true, drive = 0.35f, air = 0.1f, reverbMix = 0.12f, width = 0.15f)
        },
        DspPreset("Широкое стерео", DspPreset.Group.SPACE) {
            it.copy(enabled = true, width = 0.8f, air = 0.2f)
        },
        DspPreset("Моно", DspPreset.Group.SPACE) { it.copy(enabled = true, width = -1f) },
        DspPreset("Старое радио", DspPreset.Group.SPACE) {
            it.copy(enabled = true, width = -1f, drive = 0.3f, underwater = 0.2f,
                bandsDb = bands(-12f, -10f, -4f, 2f, 4f, 4f, 2f, -4f, -10f, -12f), bandQ = 1.2f)
        }
    )

    /** Компенсация устройства: только кривая и «воздух», пространство не трогается. */
    val device: List<DspPreset> = listOf(
        DspPreset("Наушники", DspPreset.Group.DEVICE) {
            it.copy(enabled = true, preampDb = -1f, air = 0.15f, width = 0.1f,
                bandsDb = bands(3f, 2f, 0f, -1f, -1f, 0f, 1f, 2f, 2f, 1f))
        },
        DspPreset("Динамик телефона", DspPreset.Group.DEVICE) {
            // Ниже 300 Гц телефонный динамик не воспроизводит НИЧЕГО. Поднимать там бас — значит
            // тратить весь запас по уровню на то, что физически не прозвучит. Поэтому низ
            // срезается, а его присутствие имитируется гармониками через bassDrive.
            it.copy(enabled = true, preampDb = -2f, bassDrive = 0.55f, air = 0.1f, width = 0f,
                bandsDb = bands(-12f, -10f, -2f, 2f, 3f, 2f, 1f, 2f, 1f, -2f))
        },
        DspPreset("Колонка Bluetooth", DspPreset.Group.DEVICE) {
            it.copy(enabled = true, preampDb = -2f, bassDrive = 0.2f,
                bandsDb = bands(2f, 4f, 2f, -1f, -2f, 0f, 2f, 2f, 1f, 0f))
        },
        DspPreset("В машине", DspPreset.Group.DEVICE) {
            it.copy(enabled = true, preampDb = -2f, bandQ = 1.1f,
                bandsDb = bands(4f, 3f, -1f, -3f, -1f, 1f, 3f, 3f, 2f, 1f))
        }
    )

    val all: List<DspPreset> = curve + space + device
}
