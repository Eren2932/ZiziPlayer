package app.ziziplayer.playback.dsp

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Звуковой движок Zizi (6.24.4). Чистый Kotlin: ни одного импорта android.* —
 * поэтому он целиком проверяется JVM-тестами, а не «на телефоне на слух».
 *
 * Работает по месту, в интерливнутом Float-буфере (L,R,L,R...), блоками по [BLOCK] сэмплов.
 * Блочность — не оптимизация, а способ не щёлкать: коэффициенты фильтров пересчитываются один
 * раз на блок (1.3 мс при 48 кГц) по СГЛАЖЕННЫМ значениям параметров, а не по тем, что прилетели
 * из UI. Палец на ползунке даёт скачок +6 дБ мгновенно; фильтр доезжает до него за ~40 мс, и
 * человек слышит подъём, а не хлопок.
 *
 * Порядок обработки зафиксирован и важен:
 *
 *  1. пре-амп        — до всего, чтобы EQ работал с уже нужным уровнем;
 *  2. 10 полос EQ    — пиковые биквады, только те, у которых усиление не ноль;
 *  3. сатуратор баса — генерирует гармоники низа (слышно на телефонном динамике, где 60 Гц нет);
 *  4. воздух         — верхняя полка;
 *  5. «подводный»    — ФНЧ с плавающим срезом (он ДОЛЖЕН стоять после EQ: иначе поднятый верх
 *                      сразу же срезается, и ползунки EQ выглядят сломанными);
 *  6. насыщение      — мягкая нелинейность на весь сигнал;
 *  7. ширина         — M/S, чистая математика над стерео;
 *  8. вращение 8D    — панорама + межушная задержка, требует УЖЕ готовой ширины;
 *  9. ревер          — последний из эффектов: он озвучивает результат, а не исходник;
 * 10. лимитер        — страховка на выходе, единственное, что нельзя убрать из хвоста.
 *
 * Цена: ~20 биквадов и 22 линии задержки на сэмпл при полностью загруженном тракте.
 * На Snapdragon это единицы процентов одного ядра; при нейтральном конфиге — ноль (буфер
 * копируется в процессоре и до движка не доходит).
 */
class DspEngine(private val sampleRate: Int, private val channels: Int) {

    companion object {
        /** 64 сэмпла — компромисс: реже пересчёт коэффициентов, чем период LFO «подводного». */
        private const val BLOCK = 64

        /** Постоянная сглаживания параметров, мс. Ниже 20 слышен щелчок, выше 80 — «резина». */
        private const val SMOOTH_MS = 40f

        /** Потолок лимитера. -0.4 дБFS: запас на межсэмпловые пики после ЦАП. */
        private const val CEILING = 0.955f
    }

    private val stereo = channels >= 2
    private val smoothing = exp(-1f / (SMOOTH_MS * 0.001f * sampleRate / BLOCK)).coerceIn(0f, 0.99f)

    // ---- цель (пришла из UI) и текущее сглаженное состояние ----
    private var target: DspConfig = DspConfig.NEUTRAL
    private val bandsNow = FloatArray(DspConfig.BAND_COUNT)
    private var preampNow = 0f
    private var airNow = 0f
    private var waterNow = 0f
    private var widthNow = 0f
    private var rotationNow = 0f
    private var reverbNow = 0f
    private var driveNow = 0f
    private var bassNow = 0f
    private var qNow = 1f
    /** Сглаженный линейный множитель пре-ампа — считается из [preampNow] раз в блок. */
    private var preampGain = 1f

    // ---- фильтры ----
    private val eq = Array(DspConfig.BAND_COUNT) { Biquad(channels) }
    private val airShelf = Biquad(channels)
    private val waterLp = Biquad(channels)
    private val bassSplit = Biquad(channels)
    private val bassTame = Biquad(channels)

    // ---- ревер, вращение, лимитер ----
    private val reverb = Reverb(sampleRate)
    private val rotate = Rotator(sampleRate)
    private var limiterGain = 1f
    private var limiterEnv = 0f

    private var lfoPhase = 0.0
    private var rotPhase = 0.0
    private var configDirty = true

    /** Новая цель от UI. Вызывается из любого потока, обработка увидит её на следующем блоке. */
    fun setConfig(config: DspConfig) {
        target = config.sanitized()
        configDirty = true
    }

    fun currentConfig(): DspConfig = target

    /**
     * Сброс всей памяти тракта: перемотка, смена трека, смена формата.
     *
     * Не сбросить — значит услышать хвост ревера предыдущего места трека поверх нового и
     * получить щелчок от состояния фильтров, которое к новому сигналу отношения не имеет.
     */
    fun reset() {
        eq.forEach { it.reset() }
        airShelf.reset(); waterLp.reset(); bassSplit.reset(); bassTame.reset()
        reverb.reset(); rotate.reset()
        limiterGain = 1f; limiterEnv = 0f
        lfoPhase = 0.0; rotPhase = 0.0
    }

    /**
     * Обрабатывает [frames] кадров по месту. Возвращает пиковый уровень выхода (0..1) —
     * им живёт индикатор перегруза на экране, считать его отдельно было бы вторым проходом.
     */
    fun process(pcm: FloatArray, frames: Int): Float {
        var peak = 0f
        var frame = 0
        while (frame < frames) {
            val block = minOf(BLOCK, frames - frame)
            advanceSmoothing()
            updateCoefficients()
            peak = maxOf(peak, processBlock(pcm, frame, block))
            frame += block
        }
        return peak
    }

    /** Один шаг экспоненциального сглаживания всех параметров к цели. */
    private fun advanceSmoothing() {
        val t = target
        val k = smoothing
        for (i in bandsNow.indices) bandsNow[i] = glide(bandsNow[i], t.bandsDb[i], k)
        preampNow = glide(preampNow, t.preampDb, k)
        airNow = glide(airNow, t.air, k)
        waterNow = glide(waterNow, t.underwater, k)
        widthNow = glide(widthNow, t.width, k)
        rotationNow = glide(rotationNow, t.rotation, k)
        reverbNow = glide(reverbNow, t.reverbMix, k)
        driveNow = glide(driveNow, t.drive, k)
        bassNow = glide(bassNow, t.bassDrive, k)
        qNow = glide(qNow, t.bandQ, k)
        preampGain = 10f.pow(preampNow / 20f)
    }

    private fun glide(now: Float, to: Float, k: Float): Float {
        val next = to + (now - to) * k
        // Дотягиваем до цели вручную: экспонента приближается бесконечно, а нам нужен ровно 0,
        // иначе «выключенный» модуль вечно остаётся включённым на 0.0001 и стоит такты.
        return if (abs(next - to) < 1e-4f) to else next
    }

    private fun updateCoefficients() {
        for (i in 0 until DspConfig.BAND_COUNT) {
            eq[i].setPeaking(sampleRate, DspConfig.BAND_FREQUENCIES[i], bandsNow[i], qNow)
        }
        airShelf.setHighShelf(sampleRate, 11000f, airNow * 7f)
        if (bassNow > 0f) {
            bassSplit.setLowPass(sampleRate, 140f, 0.8f)
            bassTame.setLowPass(sampleRate, 900f, 0.7f)
        }
        reverb.configure(target.reverbSize, target.reverbDamp)
        configDirty = false
    }

    private fun processBlock(pcm: FloatArray, startFrame: Int, frames: Int): Float {
        var peak = 0f
        // «Подводный» — единственный модуль, чей фильтр движется ВНУТРИ блока: срез гуляет по
        // синусу, и пересчёт раз в 64 сэмпла даёт ровно ту плавность, которая нужна (0.08 Гц).
        if (waterNow > 0f) {
            val depth = waterNow
            val base = 5200f - 4550f * depth
            val sweep = (280f + 420f * depth) * sin(lfoPhase).toFloat()
            waterLp.setLowPass(sampleRate, (base + sweep).coerceAtLeast(180f), 0.9f + 0.5f * depth)
            lfoPhase += 2.0 * PI * 0.08 * frames / sampleRate
            if (lfoPhase > 2 * PI) lfoPhase -= 2 * PI
        }

        val rotDepth = rotationNow
        val step = 2.0 * PI * target.rotationHz / sampleRate

        var i = 0
        while (i < frames) {
            val idx = (startFrame + i) * channels
            var l = pcm[idx] * preampGain
            var r = if (stereo) pcm[idx + 1] * preampGain else l

            // 2. эквалайзер
            for (b in 0 until DspConfig.BAND_COUNT) {
                if (bandsNow[b] == 0f) continue
                l = eq[b].process(0, l)
                if (stereo) r = eq[b].process(1, r)
            }

            // 3. гармоники низа
            if (bassNow > 0f) {
                val lowL = bassSplit.process(0, l)
                val harmL = bassTame.process(0, tanh(lowL * (1f + 6f * bassNow)))
                l += harmL * bassNow * 0.7f
                if (stereo) {
                    val lowR = bassSplit.process(1, r)
                    val harmR = bassTame.process(1, tanh(lowR * (1f + 6f * bassNow)))
                    r += harmR * bassNow * 0.7f
                }
            }

            // 4. воздух
            if (airNow > 0f) {
                l = airShelf.process(0, l)
                if (stereo) r = airShelf.process(1, r)
            }

            // 5. подводный: мокрый/сухой, чтобы на 50% сохранялась разборчивость
            if (waterNow > 0f) {
                val wl = waterLp.process(0, l)
                l = l * (1f - waterNow) + wl * waterNow * 1.25f
                if (stereo) {
                    val wr = waterLp.process(1, r)
                    r = r * (1f - waterNow) + wr * waterNow * 1.25f
                }
            }

            // 6. насыщение с компенсацией уровня: громкость не должна расти вместе с характером
            if (driveNow > 0f) {
                val k = 1f + 7f * driveNow
                val comp = 1f / tanh(k * 0.7f)
                l = l * (1f - driveNow) + tanh(l * k) * comp * driveNow
                if (stereo) r = r * (1f - driveNow) + tanh(r * k) * comp * driveNow
            }

            // 7. ширина через M/S
            if (stereo && widthNow != 0f) {
                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f * (1f + widthNow * 1.6f).coerceAtLeast(0f)
                l = mid + side
                r = mid - side
            }

            // 8. вращение 8D
            if (stereo && rotDepth > 0f) {
                rotPhase += step
                if (rotPhase > 2 * PI) rotPhase -= 2 * PI
                val pair = rotate.process(l, r, rotPhase, rotDepth)
                l = pair[0]; r = pair[1]
            }

            // 9. ревер
            if (reverbNow > 0f) {
                val wet = reverb.process(l, r, reverbNow)
                // Сухой убирается на mix*0.5: суммарная громкость трека при любом положении
                // ползунка держится в пределах ±1 дБ (проверено на шуме), то есть «добавить
                // объём» не означает «сделать громче».
                l = l * (1f - reverbNow * 0.5f) + wet[0]
                r = r * (1f - reverbNow * 0.5f) + wet[1]
            }

            // 10. лимитер и запись обратно
            if (target.limiter) {
                val instant = maxOf(abs(l), abs(r))
                limiterEnv = maxOf(instant, limiterEnv * 0.9995f)
                val want = if (limiterEnv > CEILING) CEILING / limiterEnv else 1f
                // Вниз мгновенно (иначе перегруз пролезет), вверх — за ~150 мс, иначе «дыхание».
                limiterGain = if (want < limiterGain) want else limiterGain + (want - limiterGain) * 0.0002f
                l *= limiterGain
                r *= limiterGain
            }
            // Жёсткая страховка: за пределы [-1,1] не выходит ничто и ни при каких параметрах.
            if (l > 1f) l = 1f else if (l < -1f) l = -1f
            if (r > 1f) r = 1f else if (r < -1f) r = -1f

            pcm[idx] = l
            if (stereo) pcm[idx + 1] = r
            for (c in 2 until channels) pcm[idx + c] = pcm[idx + c] * preampGain

            val p = maxOf(abs(l), abs(r))
            if (p > peak) peak = p
            i++
        }
        return peak
    }
}

/**
 * Ревер на схеме Шрёдера—Мурера (та же топология, что у freeverb): 8 гребёнчатых фильтров с
 * демпфированием в петле обратной связи + 4 фазовых звена на канал.
 *
 * Задержки — взаимно простые числа сэмплов при 44.1 кГц, пересчитанные под фактическую частоту
 * дискретизации. Взаимная простота здесь не эстетика: у кратных задержек резонансы складываются
 * и ревер начинает звенеть на одной ноте. Правый канал сдвинут на 23 сэмпла — этим и создаётся
 * стереокартина помещения.
 */
private class Reverb(sampleRate: Int) {

    private val combTuning = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val allpassTuning = intArrayOf(556, 441, 341, 225)
    private val spread = 23

    private val scale = sampleRate / 44100.0

    private val combL = combTuning.map { Comb(sized(it)) }
    private val combR = combTuning.map { Comb(sized(it + spread)) }
    private val apL = allpassTuning.map { Allpass(sized(it)) }
    private val apR = allpassTuning.map { Allpass(sized(it + spread)) }

    private var feedback = 0.84f
    private var damp = 0.4f
    private val out = FloatArray(2)

    private fun sized(base: Int): Int = maxOf(8, (base * scale).toInt())

    fun configure(size: Float, dampness: Float) {
        // 0.70..0.98: выше 0.98 хвост перестаёт затухать и ревер уходит в самовозбуждение.
        feedback = 0.70f + 0.28f * size.coerceIn(0f, 1f)
        damp = (0.15f + 0.65f * dampness.coerceIn(0f, 1f))
    }

    fun reset() {
        combL.forEach { it.reset() }; combR.forEach { it.reset() }
        apL.forEach { it.reset() }; apR.forEach { it.reset() }
    }

    /** Возвращает ТОЛЬКО мокрый сигнал; смешивает вызывающий. */
    fun process(l: Float, r: Float, mix: Float): FloatArray {
        val input = (l + r) * 0.015f
        var wetL = 0f
        var wetR = 0f
        for (i in combL.indices) {
            wetL += combL[i].process(input, feedback, damp)
            wetR += combR[i].process(input, feedback, damp)
        }
        for (i in apL.indices) {
            wetL = apL[i].process(wetL)
            wetR = apR[i].process(wetR)
        }
        // 1.75, а не 3.0. Множитель подобран замером, не на слух: при 3.0 «влажность 30%»
        // давала ревер громкостью 51% от сухого сигнала, а на 100% выход был на +5 дБ выше
        // входа — то есть лимитер работал ВСЕГДА, когда включён ревер, и съедал динамику
        // всего трека. При 1.75 отношение wet/dry численно равно положению ползунка.
        out[0] = wetL * mix * 1.75f
        out[1] = wetR * mix * 1.75f
        return out
    }

    private class Comb(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        private var store = 0f
        fun reset() { buf.fill(0f); store = 0f; idx = 0 }
        fun process(input: Float, feedback: Float, damp: Float): Float {
            val output = buf[idx]
            store = output * (1f - damp) + store * damp
            buf[idx] = input + store * feedback
            idx++
            if (idx >= buf.size) idx = 0
            return output
        }
    }

    private class Allpass(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        fun reset() { buf.fill(0f); idx = 0 }
        fun process(input: Float): Float {
            val buffered = buf[idx]
            val output = -input + buffered
            buf[idx] = input + buffered * 0.5f
            idx++
            if (idx >= buf.size) idx = 0
            return output
        }
    }
}

/**
 * Вращение источника вокруг головы — то, что в интернете называют «8D audio».
 *
 * Обычные «8D»-обработки — это просто автопан по громкости, и он слышен как «звук ездит по
 * колонкам». Здесь добавлены две вещи, которые и дают ощущение, что источник обходит голову:
 *
 * - межушная задержка (ITD): до 0.66 мс, ровно столько звук идёт от одного уха до другого;
 * - панорама с постоянной мощностью (sin/cos), а не линейная: иначе в центре проседает громкость.
 */
private class Rotator(sampleRate: Int) {

    private val maxDelay = maxOf(4, (sampleRate * 0.00066f).toInt())
    private val lineL = FloatArray(maxDelay + 2)
    private val lineR = FloatArray(maxDelay + 2)
    private var idx = 0
    private val out = FloatArray(2)

    fun reset() { lineL.fill(0f); lineR.fill(0f); idx = 0 }

    fun process(l: Float, r: Float, phase: Double, depth: Float): FloatArray {
        lineL[idx] = l
        lineR[idx] = r
        val angle = phase
        val pan = sin(angle).toFloat() * depth
        // Постоянная мощность: сумма квадратов усилений остаётся единицей на любой панораме.
        val theta = (pan + 1f) * (PI / 4).toFloat()
        val gainL = cos(theta)
        val gainR = sin(theta)
        // Дальнее ухо получает сигнал позже. Задержка целочисленная: интерполяция здесь не нужна,
        // один сэмпл при 48 кГц это 0.02 мс, а весь эффект живёт на 0.66 мс.
        val delaySamples = (abs(pan) * maxDelay).toInt().coerceIn(0, maxDelay)
        val delayedIdx = (idx - delaySamples + lineL.size) % lineL.size
        val delayedL = lineL[delayedIdx]
        val delayedR = lineR[delayedIdx]
        val dry = 1f - depth
        // БЕЗ множителя sqrt(2). Он был в первой редакции, чтобы центр панорамы звучал в
        // единицу, и давал ×2 по мощности на краях — то есть +3 дБ и лимитер на каждом обороте.
        // Здесь сумма квадратов усилений равна единице при любой панораме: суммарная мощность
        // постоянна, а разница между ушами и есть сам эффект.
        out[0] = (if (pan > 0f) delayedL else l) * gainL * depth + l * dry
        out[1] = (if (pan < 0f) delayedR else r) * gainR * depth + r * dry
        idx++
        if (idx >= lineL.size) idx = 0
        return out
    }
}
