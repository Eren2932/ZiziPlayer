package app.ziziplayer.playback

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import java.io.File

/**
 * Итог загрузки, сказанный вслух. 6.24.1.
 *
 * ## Зачем отдельный файл
 *
 * До 6.24.1 результат загрузки существовал ровно в одном месте — подписью внутри меню трека.
 * Закрыл меню — и «не удалось скачать: нет связи» исчезло вместе с ним; перезапустил приложение —
 * исчезло и состояние. Снаружи это выглядело как «нажал скачать, оно подумало и ничего не
 * сделало», без единой подсказки, что пошло не так. Ровно с этого началась история про
 * «у меня нет скачанного трека нигде».
 *
 * Событие показывается один раз тостом из [app.ziziplayer.MainActivity] и не хранится: это
 * сообщение, а не состояние экрана. Состояние по-прежнему живёт в [OfflineDownloads.states] и в
 * индексе [OfflineStore].
 *
 * Живёт здесь, а не внутри [OfflineDownloads], по скучной, но важной причине: тот объект помечен
 * `@UnstableApi` (Media3), и любой, кто читает его типы, обязан подписаться на opt-in. Activity
 * подписываться на нестабильное API Media3 ради строки тоста не должна.
 */
sealed interface DownloadEvent {
    /**
     * @param where человеческий путь: «Музыка/Zizi/Артист - Трек.m4a».
     * @param visible виден ли файл файловому менеджеру и чужим плеерам. false — легли в папку
     *   приложения, потому что прошивка не дала ни одной публичной цели; человек должен знать
     *   об этом сразу, а не искать файл, которого в «Музыке» нет.
     */
    data class Saved(val title: String, val where: String, val visible: Boolean) : DownloadEvent

    data class Failed(val title: String, val reason: String) : DownloadEvent
}

object DownloadEvents {

    /**
     * `extraBufferCapacity` не ноль: `tryEmit` в буфер не блокирует загрузчик, даже если экрана
     * в этот момент нет вовсе (процесс без Activity, загрузка из уведомления). Потерянный тост
     * не страшен — файл на диске от этого никуда не денется.
     */
    private val _stream = MutableSharedFlow<DownloadEvent>(replay = 0, extraBufferCapacity = 8)
    val stream: SharedFlow<DownloadEvent> = _stream

    fun emit(event: DownloadEvent) { _stream.tryEmit(event) }
}

/**
 * Папка недокачанных файлов.
 *
 * Загрузка сначала пишется во временный файл и только потом публикуется (см. [OfflineDownloads]).
 * Убитый в середине процесс оставляет `*.part` в кэше, а кэш система чистит только когда память
 * кончится — то есть мусор мог лежать месяцами. Чистится на старте приложения.
 *
 * Отдельный объект, а не метод [OfflineDownloads], снова из-за `@UnstableApi`: `Application` не
 * должен подписываться на нестабильное API Media3, чтобы удалить папку.
 */
object DownloadTemp {

    const val DIR = "zizi-dl"

    fun dir(context: Context): File = File(context.cacheDir, DIR)

    fun purge(context: Context) {
        runCatching { dir(context).deleteRecursively() }
    }
}
