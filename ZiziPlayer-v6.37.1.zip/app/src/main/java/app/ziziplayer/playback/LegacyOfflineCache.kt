package app.ziziplayer.playback

import android.content.Context
import java.io.File

/**
 * Уборка за версиями 6.20-6.23.
 *
 * Там «Скачать» писало байты в SimpleCache `filesDir/zizi-offline`. С 6.24.0 загрузки лежат
 * настоящими файлами в «Музыка/Zizi» (см. [OfflineStore]), а старая папка остаётся на диске
 * мёртвым грузом — у активного слушателя это легко пара гигабайт, которые не видно ни в одном
 * экране приложения и не удалить ничем, кроме сброса данных.
 *
 * Поэтому папка сносится один раз, на первом запуске 6.24.0. Восстанавливать из неё нечего:
 * фрагменты `*.exo` без индекса Media3 бесполезны, а индекс привязан к внутренней схеме кэша.
 * Единственная плата — треки, скачанные до обновления, придётся скачать заново; зато теперь у
 * них будет файл, который видно.
 */
object LegacyOfflineCache {

    private const val DIR = "zizi-offline"
    private const val MARKER = "zizi-offline.purged"

    /** Идемпотентно и молча. Вызывается из Application, не блокирует запуск. */
    fun purgeOnce(context: Context) {
        val marker = File(context.filesDir, MARKER)
        if (marker.exists()) return
        runCatching { File(context.filesDir, DIR).deleteRecursively() }
        runCatching { marker.writeText(System.currentTimeMillis().toString()) }
    }
}
