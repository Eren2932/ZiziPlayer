package app.ziziplayer.playback.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Биквадратный фильтр второго порядка (Direct Form I) — рабочая лошадь всего эквалайзера.
 *
 * Почему Direct Form I, а не более экономная DF2: DF1 хранит историю ВХОДА и ВЫХОДА раздельно и
 * поэтому терпит смену коэффициентов на ходу. DF2 хранит внутреннее состояние, физический смысл
 * которого зависит от коэффициентов, и при их смене выдаёт щелчок. Мы меняем коэффициенты каждые
 * 64 сэмпла (полоса едет под пальцем, LFO «подводного» крутит срез), поэтому выбор не
 * стилистический.
 *
 * Состояние — Double, а не Float, при том что сигнал у нас Float. Это тоже не украшательство:
 * у пикового фильтра с Q=1 на 31 Гц при 48 кГц полюса стоят в 0.996 от единичной окружности,
 * и в одинарной точности такой фильтр накапливает шум квантования коэффициентов, слышимый на
 * тихом басу. Double стоит здесь ноль: умножений столько же, а память — 4 числа на канал.
 *
 * Ненормализованные числа (denormals) обнуляются вручную в [process]: на ARM они не вызывают
 * ловушку, как на x86, но в хвосте затухания дают лишние такты, а нам их считать по 20 фильтров
 * на сэмпл.
 */
class Biquad(private val channels: Int = 2) {

    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0

    private val x1 = DoubleArray(channels)
    private val x2 = DoubleArray(channels)
    private val y1 = DoubleArray(channels)
    private val y2 = DoubleArray(channels)

    /** Порог, ниже которого состояние считается нулём. 1e-20 — глубже любого слышимого хвоста. */
    private val floor = 1e-20

    fun reset() {
        x1.fill(0.0); x2.fill(0.0); y1.fill(0.0); y2.fill(0.0)
    }

    /** Пропускает один сэмпл канала [ch]. Каналы независимы, состояние у каждого своё. */
    fun process(ch: Int, input: Float): Float {
        val x = input.toDouble()
        var y = b0 * x + b1 * x1[ch] + b2 * x2[ch] - a1 * y1[ch] - a2 * y2[ch]
        if (y > -floor && y < floor) y = 0.0
        x2[ch] = x1[ch]; x1[ch] = x
        y2[ch] = y1[ch]; y1[ch] = y
        return y.toFloat()
    }

    /** Нормализация по a0 — единственное место, где коэффициенты попадают в поля. */
    private fun set(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
        val inv = 1.0 / a0
        this.b0 = b0 * inv; this.b1 = b1 * inv; this.b2 = b2 * inv
        this.a1 = a1 * inv; this.a2 = a2 * inv
    }

    /** Единичный коэффициент передачи: фильтр есть, но он ничего не делает. */
    fun setBypass() = set(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

    /**
     * Частоту зажимаем на 45% от частоты дискретизации.
     *
     * Это не перестраховка. Полоса 16 кГц при 22.05 кГц потока (а такие приходят: старые mp3,
     * низкое качество из каталога) лежит ЗА Найквистом, и cos(w0) уходит за -1 — фильтр
     * становится неустойчивым и отдаёт NaN, то есть тишину или треск до конца трека.
     */
    private fun omega(sampleRate: Int, freq: Float): Double {
        val nyquistLimit = sampleRate * 0.45f
        val f = freq.coerceIn(10f, nyquistLimit)
        return 2.0 * PI * f / sampleRate
    }

    /** Пиковый (колокол) — то, чем работают все 10 полос эквалайзера. */
    fun setPeaking(sampleRate: Int, freq: Float, gainDb: Float, q: Float) {
        if (gainDb > -0.01f && gainDb < 0.01f) { setBypass(); return }
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = omega(sampleRate, freq)
        val cosW = cos(w0)
        val alpha = sin(w0) / (2.0 * q.coerceIn(0.2f, 12f))
        set(
            1.0 + alpha * a, -2.0 * cosW, 1.0 - alpha * a,
            1.0 + alpha / a, -2.0 * cosW, 1.0 - alpha / a
        )
    }

    /** Полка снизу: поднимает/срезает всё, что ниже [freq], без «ямы» на самом краю. */
    fun setLowShelf(sampleRate: Int, freq: Float, gainDb: Float, slope: Float = 1f) {
        if (gainDb > -0.01f && gainDb < 0.01f) { setBypass(); return }
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = omega(sampleRate, freq)
        val cosW = cos(w0)
        val alpha = sin(w0) / 2.0 * sqrt((a + 1 / a) * (1.0 / slope.coerceIn(0.3f, 2f) - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) - (a - 1) * cosW + twoSqrtAAlpha),
            2 * a * ((a - 1) - (a + 1) * cosW),
            a * ((a + 1) - (a - 1) * cosW - twoSqrtAAlpha),
            (a + 1) + (a - 1) * cosW + twoSqrtAAlpha,
            -2 * ((a - 1) + (a + 1) * cosW),
            (a + 1) + (a - 1) * cosW - twoSqrtAAlpha
        )
    }

    /** Полка сверху — «воздух». */
    fun setHighShelf(sampleRate: Int, freq: Float, gainDb: Float, slope: Float = 1f) {
        if (gainDb > -0.01f && gainDb < 0.01f) { setBypass(); return }
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = omega(sampleRate, freq)
        val cosW = cos(w0)
        val alpha = sin(w0) / 2.0 * sqrt((a + 1 / a) * (1.0 / slope.coerceIn(0.3f, 2f) - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) + (a - 1) * cosW + twoSqrtAAlpha),
            -2 * a * ((a - 1) + (a + 1) * cosW),
            a * ((a + 1) + (a - 1) * cosW - twoSqrtAAlpha),
            (a + 1) - (a - 1) * cosW + twoSqrtAAlpha,
            2 * ((a - 1) - (a + 1) * cosW),
            (a + 1) - (a - 1) * cosW - twoSqrtAAlpha
        )
    }

    /** Фильтр низких частот — основа «подводного» режима. */
    fun setLowPass(sampleRate: Int, freq: Float, q: Float = 0.707f) {
        val w0 = omega(sampleRate, freq)
        val cosW = cos(w0)
        val alpha = sin(w0) / (2.0 * q.coerceIn(0.2f, 12f))
        set((1 - cosW) / 2, 1 - cosW, (1 - cosW) / 2, 1 + alpha, -2 * cosW, 1 - alpha)
    }

    /** Полосовой с единичным усилением в центре — используется анализатором спектра. */
    fun setBandPass(sampleRate: Int, freq: Float, q: Float = 1.4f) {
        val w0 = omega(sampleRate, freq)
        val cosW = cos(w0)
        val alpha = sin(w0) / (2.0 * q.coerceIn(0.2f, 12f))
        set(alpha, 0.0, -alpha, 1 + alpha, -2 * cosW, 1 - alpha)
    }

    /**
     * Модуль передаточной функции на частоте [freq] в дБ. В тракте не участвует —
     * нужен тестам (проверить, что полоса даёт ровно тот подъём, который просили) и
     * экрану эквалайзера (нарисовать РЕАЛЬНУЮ суммарную кривую, а не сплайн по точкам).
     */
    fun magnitudeDb(sampleRate: Int, freq: Float): Float {
        val w = 2.0 * PI * freq / sampleRate
        val cosW = cos(w); val cos2W = cos(2 * w)
        val sinW = sin(w); val sin2W = sin(2 * w)
        val numRe = b0 + b1 * cosW + b2 * cos2W
        val numIm = -(b1 * sinW + b2 * sin2W)
        val denRe = 1.0 + a1 * cosW + a2 * cos2W
        val denIm = -(a1 * sinW + a2 * sin2W)
        val num = sqrt(numRe * numRe + numIm * numIm)
        val den = sqrt(denRe * denRe + denIm * denIm)
        if (den < 1e-12 || num < 1e-12) return -120f
        return (20.0 * kotlin.math.log10(num / den)).toFloat()
    }
}
