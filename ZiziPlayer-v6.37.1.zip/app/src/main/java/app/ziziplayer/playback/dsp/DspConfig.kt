package app.ziziplayer.playback.dsp

/**
 * Полное состояние звукового тракта Zizi — одна неизменяемая структура (6.24.4).
 *
 * Всё, что слышит человек, описывается ЭТИМ объектом и больше ничем. Такое решение принято
 * осознанно, взамен прежней россыпи «percent реверба в одну сторону, PlaybackParameters в
 * другую, PresetReverb в третью»: у той схемы не было состояния, которое можно сравнить,
 * сохранить, передать в сервис одной строкой и сравнить обратно. Здесь есть.
 *
 * Диапазоны намеренно узкие. `bandsDb` ±12 дБ, а не ±30, потому что +30 дБ на 62 Гц — это не
 * «мощный бас», это перегруз тракта и мгновенное срабатывание лимитера на каждой бочке. Все
 * значения зажимаются в [sanitized] — до движка невалидное состояние не доходит в принципе,
 * даже если пришло из старой базы или из битой строки.
 */
data class DspConfig(
    /** Общий выключатель: false — тракт отдаёт байты как есть, без единого умножения. */
    val enabled: Boolean = false,
    /** Пре-амп, дБ. Нужен, чтобы поднятые полосы не били в лимитер: подняли бас — убрали общее. */
    val preampDb: Float = 0f,
    /** Усиление 10 полос в дБ, порядок соответствует [BAND_FREQUENCIES]. */
    val bandsDb: List<Float> = List(BAND_COUNT) { 0f },
    /** Добротность полос: 0.7 — широкие мягкие колокола, 3.0 — хирургические. */
    val bandQ: Float = 1.0f,

    // ---- модули объёма и характера ----
    /** Сатуратор низа: добавляет ГАРМОНИКИ баса, а не сам бас. 0..1 */
    val bassDrive: Float = 0f,
    /** «Воздух»: полка на 11 кГц, 0..1 -> 0..+7 дБ. */
    val air: Float = 0f,
    /** Ширина стерео: -1 — моно, 0 — как записано, +1 — расширение через M/S. */
    val width: Float = 0f,
    /** «Подводный»: ФНЧ с плавающим срезом. 0..1 — глубина погружения. */
    val underwater: Float = 0f,
    /** 8D: вращение источника вокруг головы. 0..1 — радиус. */
    val rotation: Float = 0f,
    /** Скорость вращения 8D, оборотов в секунду. 0.12 — примерно 8 секунд на круг. */
    val rotationHz: Float = 0.12f,
    /** Доля ревера в сигнале, 0..1. */
    val reverbMix: Float = 0f,
    /** Размер помещения: 0 — комната, 1 — собор. */
    val reverbSize: Float = 0.5f,
    /** Поглощение верха стенами: 0 — кафель, 1 — вата. */
    val reverbDamp: Float = 0.5f,
    /** Ламповое насыщение всего сигнала, 0..1. */
    val drive: Float = 0f,
    /** Лимитер на выходе. Выключать можно, но незачем: он ничего не делает, пока нет перегруза. */
    val limiter: Boolean = true
) {

    /**
     * Тракт реально что-то меняет? Если нет — процессор в сервисе копирует буфер напрямую.
     * Проверяется именно результат, а не только флаг [enabled]: включённый эквалайзер с нулевой
     * кривой не должен стоить ни одного умножения.
     */
    val isNeutral: Boolean
        get() = !enabled || (
            preampDb == 0f && bandsDb.all { it == 0f } && bassDrive == 0f && air == 0f &&
                width == 0f && underwater == 0f && rotation == 0f && reverbMix == 0f && drive == 0f
            )

    /** Единственная дверь в движок: всё зажато, ничего не NaN, длина полос всегда [BAND_COUNT]. */
    fun sanitized(): DspConfig {
        val bands = ArrayList<Float>(BAND_COUNT)
        for (i in 0 until BAND_COUNT) {
            bands.add(bandsDb.getOrElse(i) { 0f }.finiteOr(0f).coerceIn(-12f, 12f))
        }
        return copy(
            preampDb = preampDb.finiteOr(0f).coerceIn(-12f, 6f),
            bandsDb = bands,
            bandQ = bandQ.finiteOr(1f).coerceIn(0.5f, 4f),
            bassDrive = bassDrive.unit(),
            air = air.unit(),
            width = width.finiteOr(0f).coerceIn(-1f, 1f),
            underwater = underwater.unit(),
            rotation = rotation.unit(),
            rotationHz = rotationHz.finiteOr(0.12f).coerceIn(0.02f, 1.5f),
            reverbMix = reverbMix.unit(),
            reverbSize = reverbSize.unit(),
            reverbDamp = reverbDamp.unit(),
            drive = drive.unit()
        )
    }

    /**
     * Наследие: «Реверб %» из старого FX-листа (6.x до 6.24.3).
     *
     * У людей в базе лежат значения 0..100, выставленные ползунком, который дёргал
     * `PresetReverb` прошивки. Выбрасывать их нельзя — человек настраивал их руками для своих
     * треков. Поэтому процент переносится в наш ревер: 100% старого «LARGEHALL» это примерно
     * 0.55 нашей влажности и большой зал. Звучать будет ИНАЧЕ (наш ревер одинаков на всех
     * телефонах, а прошивочный — нет), но никогда не «ничем».
     */
    fun withLegacyReverb(percent: Int): DspConfig {
        if (percent <= 0) return this
        val p = percent.coerceIn(0, 100) / 100f
        return copy(
            enabled = true,
            reverbMix = maxOf(reverbMix, p * 0.55f),
            reverbSize = maxOf(reverbSize, 0.35f + p * 0.5f)
        )
    }

    companion object {
        const val BAND_COUNT = 10

        /**
         * Центры полос — стандартная октавная сетка ISO. Не «красивые» числа: каждая следующая
         * ровно в два раза выше, поэтому пиковые фильтры с Q=1 стыкуются без ям и горбов между
         * полосами. Сдвинешь одну — суммарная кривая перестанет быть предсказуемой.
         */
        val BAND_FREQUENCIES = floatArrayOf(
            31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f
        )

        /** Короткие подписи под полосами на экране. */
        val BAND_LABELS = arrayOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

        val NEUTRAL = DspConfig()

        private fun Float.finiteOr(fallback: Float): Float =
            if (isNaN() || isInfinite()) fallback else this

        private fun Float.unit(): Float = finiteOr(0f).coerceIn(0f, 1f)
    }
}

/**
 * Сериализация конфигурации в строку и обратно.
 *
 * Формат свой, а не JSON, и вот почему. Строка едет в трёх местах: в колонке Room, в DataStore и
 * в `Bundle` кастомной команды медиасессии. JSON тянул бы `org.json`, которого НЕТ в JVM-тестах
 * (в android.jar-заглушке все методы бросают исключение) — то есть самая опасная часть, разбор
 * чужих данных, осталась бы непокрытой. Здесь же кодек — чистый Kotlin и тестируется полностью.
 *
 * `v1|k=v;k=v;...`. Неизвестные ключи игнорируются, отсутствующие берут значение по умолчанию:
 * старая версия приложения не упадёт на конфиге из новой, а новая прочитает старый.
 */
object DspCodec {

    private const val VERSION = "v1"

    fun encode(c: DspConfig): String {
        val s = c.sanitized()
        val sb = StringBuilder(VERSION).append('|')
        fun put(k: String, v: Any) { sb.append(k).append('=').append(v).append(';') }
        put("on", if (s.enabled) 1 else 0)
        put("pre", fmt(s.preampDb))
        put("bands", s.bandsDb.joinToString(",") { fmt(it) })
        put("q", fmt(s.bandQ))
        put("bass", fmt(s.bassDrive))
        put("air", fmt(s.air))
        put("wide", fmt(s.width))
        put("water", fmt(s.underwater))
        put("rot", fmt(s.rotation))
        put("rothz", fmt(s.rotationHz))
        put("rvmix", fmt(s.reverbMix))
        put("rvsize", fmt(s.reverbSize))
        put("rvdamp", fmt(s.reverbDamp))
        put("drive", fmt(s.drive))
        put("lim", if (s.limiter) 1 else 0)
        return sb.toString()
    }

    /** Ничего не бросает никогда: битая строка — это нейтральный тракт, а не падение плеера. */
    fun decode(raw: String?): DspConfig {
        if (raw.isNullOrBlank()) return DspConfig.NEUTRAL
        val body = raw.substringAfter('|', raw)
        val map = HashMap<String, String>()
        for (part in body.split(';')) {
            if (part.isBlank()) continue
            val i = part.indexOf('=')
            if (i <= 0) continue
            map[part.substring(0, i).trim()] = part.substring(i + 1).trim()
        }
        fun f(k: String, d: Float): Float = map[k]?.toFloatOrNull() ?: d
        fun b(k: String, d: Boolean): Boolean = map[k]?.let { it == "1" || it == "true" } ?: d
        val bands = map["bands"]?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: emptyList()
        return DspConfig(
            enabled = b("on", false),
            preampDb = f("pre", 0f),
            bandsDb = bands,
            bandQ = f("q", 1f),
            bassDrive = f("bass", 0f),
            air = f("air", 0f),
            width = f("wide", 0f),
            underwater = f("water", 0f),
            rotation = f("rot", 0f),
            rotationHz = f("rothz", 0.12f),
            reverbMix = f("rvmix", 0f),
            reverbSize = f("rvsize", 0.5f),
            reverbDamp = f("rvdamp", 0.5f),
            drive = f("drive", 0f),
            limiter = b("lim", true)
        ).sanitized()
    }

    /** Два знака после точки: слух не различает, а строка короче почти вдвое. */
    private fun fmt(v: Float): String {
        val r = Math.round(v * 100f) / 100f
        return if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()
    }
}
