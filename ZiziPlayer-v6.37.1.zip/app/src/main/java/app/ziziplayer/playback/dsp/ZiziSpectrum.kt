package app.ziziplayer.playback.dsp

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Спектр для экрана эквалайзера — 10 чисел 0..1 под теми же полосами, что и ползунки.
 *
 * ПОЧЕМУ НЕ `android.media.audiofx.Visualizer`, хотя это «штатный» способ. Visualizer — это
 * системный ОТВОД аудиопотока, и Android совершенно справедливо считает его записью звука:
 * на многих прошивках он требует `RECORD_AUDIO`. Просить у человека разрешение на микрофон
 * ради анимации в эквалайзере — это то, за что приложения справедливо удаляют. Плюс Visualizer
 * показывает то, что уходит в динамик ЦЕЛИКОМ, включая чужие приложения, и на части устройств
 * он просто отдаёт нули.
 *
 * Здесь спектр снимается там, где сигнал уже и так в руках — внутри нашего процессора. Ни одного
 * разрешения, ноль системных вызовов, и показывается ровно наш трек после нашей обработки.
 *
 * [listening] — вентиль: пока экран эквалайзера закрыт, анализатор не считает вообще ничего.
 */
object ZiziSpectrum {

    private val _bands = MutableStateFlow(FloatArray(DspConfig.BAND_COUNT))
    val bands: StateFlow<FloatArray> = _bands

    private val _peak = MutableStateFlow(0f)
    val peak: StateFlow<Float> = _peak

    /** Ставится экраном эквалайзера на время жизни композиции. */
    @Volatile
    var listening: Boolean = false

    internal fun publish(values: FloatArray, peakLevel: Float) {
        _bands.value = values
        _peak.value = peakLevel
    }

    fun silence() {
        if (_bands.value.any { it != 0f }) _bands.value = FloatArray(DspConfig.BAND_COUNT)
        if (_peak.value != 0f) _peak.value = 0f
    }
}

/**
 * Анализатор: 10 полосовых фильтров по монофонической сумме + детектор среднеквадратичного
 * уровня с медленным спадом.
 *
 * Не FFT. Осознанно: FFT на 1024 точки дал бы 47 Гц на бин при 48 кГц — то есть первые ТРИ полосы
 * эквалайзера (31, 62, 125 Гц) попали бы в один-два бина, и низ рисовался бы неправдой. Октавная
 * гребёнка биквадов даёт по фильтру ровно на полосу, стоит 10 умножений на сэмпл и показывает
 * именно то, что делают ползунки.
 */
internal class SpectrumAnalyzer(sampleRate: Int) {

    private val filters = Array(DspConfig.BAND_COUNT) { i ->
        Biquad(1).also { it.setBandPass(sampleRate, DspConfig.BAND_FREQUENCIES[i], 2.0f) }
    }
    private val sums = DoubleArray(DspConfig.BAND_COUNT)
    private val display = FloatArray(DspConfig.BAND_COUNT)
    private var counted = 0
    private var peak = 0f

    /** ~40 мс при 48 кГц: 25 обновлений в секунду, ровно под кадры экрана. */
    private val window = maxOf(256, sampleRate / 25)

    fun reset() {
        filters.forEach { it.reset() }
        sums.fill(0.0); display.fill(0f); counted = 0; peak = 0f
    }

    fun feed(pcm: FloatArray, frames: Int, channels: Int, blockPeak: Float) {
        peak = maxOf(peak, blockPeak)
        var f = 0
        while (f < frames) {
            val idx = f * channels
            val mono = if (channels >= 2) (pcm[idx] + pcm[idx + 1]) * 0.5f else pcm[idx]
            for (b in filters.indices) {
                val v = filters[b].process(0, mono)
                sums[b] += (v * v).toDouble()
            }
            counted++
            if (counted >= window) flushWindow()
            f++
        }
    }

    private fun flushWindow() {
        val out = FloatArray(DspConfig.BAND_COUNT)
        for (b in sums.indices) {
            val rms = sqrt(sums[b] / counted).toFloat()
            // -60..0 дБ -> 0..1. Логарифм обязателен: в линейной шкале всё, кроме бочки,
            // прижато к нулю и «эквалайзер не показывает музыку».
            val db = 20f * log10(maxOf(rms, 1e-6f))
            val norm = ((db + 60f) / 60f).coerceIn(0f, 1f)
            // Вверх мгновенно, вниз плавно — иначе полосы дрожат и читать их невозможно.
            display[b] = if (norm > display[b]) norm else display[b] * 0.82f + norm * 0.18f
            out[b] = display[b]
            sums[b] = 0.0
        }
        counted = 0
        ZiziSpectrum.publish(out, peak)
        peak = abs(peak) * 0.7f
    }
}
