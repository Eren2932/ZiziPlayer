package app.ziziplayer.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Пока что-то качается — приложение имеет право жить. 6.24.0.
 *
 * До этой версии загрузка была обычной корутиной в процессе приложения: свернул, система решила
 * освободить память — загрузка исчезла без следа и без сообщения. Для «скачать на дорогу» это
 * ровно тот случай, когда человек обнаруживает проблему в метро, то есть когда починить уже
 * нельзя.
 *
 * Сервис ничего не качает сам. Он существует ради двух вещей, которых нельзя получить иначе:
 * foreground-приоритета для процесса и честного уведомления с процентом и кнопкой «Отменить».
 * Гаснет сам, как только [OfflineDownloads] сообщает, что активных загрузок больше нет — висящее
 * уведомление «0 загрузок» раздражает сильнее, чем отсутствие уведомления вообще.
 */
@UnstableApi
class DownloadService : Service() {

    companion object {
        private const val CHANNEL_ID = "zizi-downloads"
        private const val NOTIFICATION_ID = 0x21212
        const val ACTION_CANCEL_ALL = "app.ziziplayer.action.CANCEL_DOWNLOADS"

        /**
         * Запуск обёрнут в runCatching намеренно: на Android 12+ старт foreground-сервиса из
         * фона запрещён и бросает исключение. Загрузка всегда начинается с тапа, то есть из
         * переднего плана, но падать из-за уведомления — последнее, что должен делать плеер.
         */
        fun start(context: Context) {
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        // startForeground в onCreate, а не по первому событию: система даёт на это пять секунд.
        startForeground(NOTIFICATION_ID, buildNotification(active = OfflineDownloads.activeCount(), percent = -1))
        scope.launch {
            OfflineDownloads.states.collect { states ->
                val running = states.values.filterIsInstance<DownloadStatus.Running>()
                val queued = states.values.count { it is DownloadStatus.Queued }
                val active = running.size + queued
                if (active == 0) { finish(); return@collect }
                val known = running.mapNotNull { it.percent.takeIf { p -> p >= 0 } }
                val percent = if (known.isEmpty()) -1 else known.sum() / known.size
                notify(buildNotification(active, percent))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL_ALL) {
            OfflineDownloads.cancelAll()
            finish()
            return START_NOT_STICKY
        }
        // NOT_STICKY: перезапускать сервис без самих загрузок бессмысленно.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun finish() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notify(notification: Notification) {
        runCatching {
            (getSystemService(NotificationManager::class.java))?.notify(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(active: Int, percent: Int): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val cancel = PendingIntent.getService(
            this,
            1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val title = when {
            active <= 1 -> "Скачивание трека"
            else -> "Скачивание: $active трека"
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            // 6.24.1: своя иконка вместо системной stat_sys_download. Системную рисует прошивка,
            // и на части устройств это стрелка из Android 4 рядом с нашим интерфейсом.
            .setSmallIcon(app.ziziplayer.R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentText(if (percent >= 0) "$percent% · сохраняется в " + OfflineStore.FOLDER_LABEL else OfflineStore.FOLDER_LABEL)
            .setProgress(100, percent.coerceAtLeast(0), percent < 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Отменить", cancel)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(CHANNEL_ID, "Загрузки", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Прогресс скачивания треков"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }
}
