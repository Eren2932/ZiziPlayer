package app.ziziplayer.playback

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * КУДА СЕЙЧАС РЕАЛЬНО ИДЁТ ЗВУК. 6.33.0.
 *
 * Строка внизу плеера обязана быть фактом, а не украшением: если она говорит «REDMI Buds 8
 * Active», значит система именно туда и отдаёт медиапоток. Поэтому здесь нет ни одной догадки
 * по состоянию Bluetooth-адаптера и ни одного «подключено — значит играет»: наушники могут быть
 * соединены с телефоном и при этом не быть маршрутом вывода (звонок, второе устройство, режим
 * «только звонки»).
 *
 * Источник правды — [AudioManager]:
 *  - на Android 12+ спрашиваем прямо: `getAudioDevicesForAttributes(USAGE_MEDIA)` возвращает то
 *    устройство, на которое система ПОЛОЖИТ медиапоток прямо сейчас;
 *  - ниже 12 такого вопроса в API нет, поэтому берём список выходов и выбираем по приоритету —
 *    гарнитура важнее динамика, ровно так же, как это делает сам микшер.
 *
 * Обновление — по событию, а не опросом: [AudioDeviceCallback] будит поток на каждом втыкании
 * и отваливании. Экран, который опрашивает железо в цикле, стоит батарею; здесь между событиями
 * не выполняется ни одной инструкции.
 */
enum class OutputKind {
    /** Собственный динамик или разговорный капсюль телефона. */
    PHONE,

    /** Провод: 3.5 мм или гарнитура с микрофоном. */
    WIRED,

    /** Bluetooth-наушники и вкладыши (A2DP, LE Audio, SCO). */
    BLUETOOTH,

    /** Bluetooth-колонка: «наушники» тут были бы враньём. */
    BLUETOOTH_SPEAKER,

    /** USB-C наушники, ЦАП, звуковая карта. */
    USB,

    /** HDMI, док, автомагнитола и всё остальное «внешнее». */
    EXTERNAL
}

/**
 * Устройство вывода в том виде, в каком его показывает интерфейс: род (он выбирает знак) и имя
 * (его показываем человеку). Имя уже очищено: пустых строк и «null» здесь не бывает.
 */
data class AudioOutput(
    val kind: OutputKind,
    val name: String
) {
    /** Динамик телефона — состояние по умолчанию, а не «неизвестно». */
    val isPhone: Boolean get() = kind == OutputKind.PHONE
}

object AudioOutputs {

    private val PHONE_FALLBACK = AudioOutput(OutputKind.PHONE, "Динамик телефона")

    /** Мгновенный снимок. Нужен как стартовое значение состояния до первой подписки. */
    fun current(context: Context): AudioOutput {
        val am = context.applicationContext
            .getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return PHONE_FALLBACK
        val outputs = runCatching {
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.isSink }
        }.getOrNull().orEmpty()
        if (outputs.isEmpty()) return PHONE_FALLBACK

        // Android 12+: спрашиваем систему напрямую, куда уйдёт МЕДИА. Ответ приходит списком
        // атрибутов, а не устройств, поэтому по типу находим то же устройство в списке выходов —
        // только у него есть человеческое имя.
        val routedType: Int? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
                am.getAudioDevicesForAttributes(attrs).firstOrNull()?.type
            }.getOrNull()
        } else null

        val device = outputs.firstOrNull { routedType != null && it.type == routedType }
            ?: outputs.minByOrNull { rank(kindOf(it.type)) }
            ?: return PHONE_FALLBACK

        val kind = kindOf(device.type)
        return AudioOutput(kind, nameOf(device, kind))
    }

    /**
     * Поток состояния вывода. Первое значение отдаётся сразу, дальше — только по событиям
     * системы. [distinctUntilChanged] отсекает дубли: пересчёт после «устройство добавлено» и
     * «устройство удалено» на одном и том же переключении даёт один и тот же ответ дважды.
     */
    fun flow(context: Context): Flow<AudioOutput> = callbackFlow {
        val app = context.applicationContext
        val am = app.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        trySend(current(app))
        if (am == null) {
            awaitClose { }
            return@callbackFlow
        }
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                trySend(current(app))
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                trySend(current(app))
            }
        }
        am.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
        awaitClose { runCatching { am.unregisterAudioDeviceCallback(callback) } }
    }.distinctUntilChanged()

    /**
     * Приоритет при выборе «на слух»: чем меньше число, тем правдоподобнее, что играет туда.
     * Порядок повторяет поведение системного микшера — подключённая гарнитура всегда перебивает
     * встроенный динамик.
     */
    private fun rank(kind: OutputKind): Int = when (kind) {
        OutputKind.BLUETOOTH -> 0
        OutputKind.BLUETOOTH_SPEAKER -> 1
        OutputKind.USB -> 2
        OutputKind.WIRED -> 3
        OutputKind.EXTERNAL -> 4
        OutputKind.PHONE -> 5
    }

    private fun kindOf(type: Int): OutputKind = when (type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET -> OutputKind.BLUETOOTH

        AudioDeviceInfo.TYPE_BLE_SPEAKER,
        AudioDeviceInfo.TYPE_BLE_BROADCAST -> OutputKind.BLUETOOTH_SPEAKER

        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_LINE_ANALOG,
        AudioDeviceInfo.TYPE_AUX_LINE -> OutputKind.WIRED

        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> OutputKind.USB

        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER,
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER_SAFE,
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> OutputKind.PHONE

        else -> OutputKind.EXTERNAL
    }

    /**
     * Имя устройства.
     *
     * `productName` у встроенного динамика — это модель телефона («Redmi Note 12»), то есть
     * ответ не на тот вопрос: человеку нужен ВЫВОД, а не название аппарата. Поэтому для динамика
     * имя всегда своё, и для любого устройства, чьё имя совпало с моделью, — тоже.
     *
     * У Bluetooth-устройств имя может прийти пустым: с Android 12 системное имя чужого
     * устройства отдаётся только приложению с разрешением BLUETOOTH_CONNECT. Тогда показываем
     * честное родовое слово, а не пустоту и не выдуманную модель.
     */
    private fun nameOf(device: AudioDeviceInfo, kind: OutputKind): String {
        val product = runCatching { device.productName?.toString()?.trim() }.getOrNull().orEmpty()
        val generic = when (kind) {
            OutputKind.PHONE -> "Динамик телефона"
            OutputKind.WIRED -> "Проводные наушники"
            OutputKind.BLUETOOTH -> "Bluetooth-наушники"
            OutputKind.BLUETOOTH_SPEAKER -> "Bluetooth-колонка"
            OutputKind.USB -> "USB-звук"
            OutputKind.EXTERNAL -> "Внешний выход"
        }
        val useless = product.isEmpty() ||
            product.equals(Build.MODEL, ignoreCase = true) ||
            product.equals(Build.DEVICE, ignoreCase = true) ||
            product.equals("null", ignoreCase = true)
        return if (kind == OutputKind.PHONE || useless) generic else product
    }
}
