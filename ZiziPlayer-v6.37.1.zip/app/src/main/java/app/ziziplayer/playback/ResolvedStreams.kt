package app.ziziplayer.playback

import app.ziziplayer.data.remote.StreamInfo
import java.util.concurrent.ConcurrentHashMap

/**
 * The addresses we have already resolved, for as long as they are worth keeping.
 *
 * Media3 does not open a stream once. It opens it again after every rebuffer, after every seek
 * outside the buffer, and once more when the cache decides it wants a different range - and each of
 * those used to walk the whole client ladder in [app.ziziplayer.data.remote.InnertubeCatalog] from
 * scratch. On a lift-and-tunnel connection that is three Innertube round trips per minute per
 * track, which is both slow and the fastest known way to get rate limited by a private API.
 *
 * So a resolved address is kept, keyed by the stable `zizi://` URI plus the quality it was resolved
 * for, and reused while it is fresh. Two ceilings apply, not one: the provider's own TTL (parsed out
 * of `expire=` in the URL), and a flat thirty minutes of our own - a googlevideo link is bound to
 * the IP that asked for it, and a phone changes IP without telling anybody. Trusting a six hour TTL
 * across a Wi-Fi to LTE hand-off is how a track dies mid-play.
 *
 * [clear] is called by the load error policy the moment playback is refused, so the retry resolves
 * from zero instead of being handed the very address that just failed.
 */
object ResolvedStreams {

    private const val MAX_AGE_MS = 30 * 60 * 1000L

    private val entries = ConcurrentHashMap<String, StreamInfo>()

    /**
     * What is playing right now, in one line, for the diagnostics row in settings.
     *
     * It exists because "не работает" is not a bug report. `yt · ANDROID_VR · 141 кбит/с ·
     * audio/mp4` is: it names the provider, the internal client that survived attestation, and the
     * format - so the day it breaks, one glance says which layer moved.
     */
    @Volatile
    var lastLabel: String? = null
        private set

    fun get(key: String): StreamInfo? {
        val info = entries[key] ?: return null
        val now = System.currentTimeMillis()
        if (!info.isFresh(now) || now - info.resolvedAtMs > MAX_AGE_MS) {
            entries.remove(key)
            return null
        }
        return info
    }

    fun put(key: String, info: StreamInfo) {
        // Bounded by hand: the queue can be long, the map must not become a leak.
        if (entries.size > 64) entries.clear()
        entries[key] = info
    }

    fun remember(provider: String, info: StreamInfo) {
        lastLabel = buildString {
            append(provider)
            info.client?.let { append(" · ").append(it) }
            append(" · ").append(info.bitrateKbps).append(" кбит/с · ").append(info.mimeType)
        }
    }

    fun clear() { entries.clear() }

    /**
     * Выбрасывает адреса одного источника, не трогая остальные (6.19.0).
     *
     * Раньше на любой отказ звался [clear], и это было слишком грубо: в очереди рядом с треком
     * YouTube лежат треки Audius, чьи адреса никто не отзывал и чей прогрев стоил реальных секунд.
     * Один 403 от googlevideo сносил всё разом, и следующие три перехода снова платили за резолв —
     * то есть лечение одного трека делало плохо всей очереди.
     *
     * Ключ построен как `zizi://<источник>/<id>|<качество>|<режим>`, поэтому префикс однозначно
     * отделяет один источник от другого.
     */
    fun clearProvider(provider: String) {
        val prefix = "zizi://" + provider + "/"
        entries.keys.filter { it.startsWith(prefix) }.forEach { entries.remove(it) }
    }
}
