package app.ziziplayer.playback

/**
 * Состояние офлайн-копии одного трека.
 *
 * Живёт в отдельном файле и БЕЗ @UnstableApi намеренно: на него смотрит UI, а таскать
 * media3-optin через весь Compose-слой ради одного sealed-типа — плохая сделка.
 */
sealed interface DownloadStatus {
    /** Локальный файл: он и так на устройстве, качать нечего. */
    data object Local : DownloadStatus
    /** Сетевой трек, копии нет. */
    data object None : DownloadStatus
    /**
     * 6.24.0: ждёт своей очереди.
     *
     * Одновременно качаются два трека, не десять: десять параллельных потоков на LTE — это
     * десять медленных загрузок вместо двух быстрых, и гарантированный таймаут на слабой связи.
     * Отдельное состояние нужно, чтобы третий трек не выглядел «нажал и ничего не произошло».
     */
    data object Queued : DownloadStatus
    /** Качается прямо сейчас. [percent] = -1, когда сервер не отдал длину. */
    data class Running(val percent: Int, val bytes: Long = 0L) : DownloadStatus
    /** Скачан целиком, лежит файлом в «Музыка/Zizi», играет без сети. */
    data object Done : DownloadStatus
    /** Сорвалось. Текст короткий — он идёт второй строкой в меню. */
    data class Failed(val message: String) : DownloadStatus
}
