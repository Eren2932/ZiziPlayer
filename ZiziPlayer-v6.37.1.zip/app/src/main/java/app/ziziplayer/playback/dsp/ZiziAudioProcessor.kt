package app.ziziplayer.playback.dsp

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Мост между тактом Media3 и нашим движком (6.24.4).
 *
 * ГЛАВНАЯ ЛОВУШКА, из-за которой этот класс написан так, а не «как в примерах».
 * `AudioProcessor.isActive()` спрашивают ОДИН раз — когда аудиотракт конфигурируется под формат
 * трека. Если вернуть здесь `config.enabled`, то включение эквалайзера посреди трека не даст
 * ничего: цепочка уже собрана без нас, и пересоберётся она только на смене формата (то есть на
 * следующем треке с другой частотой дискретизации — может, никогда). Классический баг всех
 * самодельных эквалайзеров на ExoPlayer: «работает только после переключения трека».
 *
 * Поэтому процессор активен ВСЕГДА, пока формат нам понятен, а выключение реализовано внутри:
 * при нейтральном конфиге буфер копируется на выход одним `put` без единого умножения. Цена
 * такого решения — одно копирование памяти на буфер (~4 КБ раз в 20 мс, то есть ничто), а
 * взамен эквалайзер включается там, где на него нажали.
 *
 * Второе: `queueInput` зовут из аудиопотока, у которого дедлайн порядка миллисекунд. Здесь нет
 * ни одной аллокации на буфер (массивы переиспользуются), ни одного лока, ни одного обращения к
 * диску. Конфиг приходит через `@Volatile`-ссылку: аудиопоток читает её без блокировки, а
 * неизменяемость [DspConfig] гарантирует, что он никогда не увидит полуприменённое состояние.
 */
@UnstableApi
class ZiziAudioProcessor : BaseAudioProcessor() {

    @Volatile
    private var pending: DspConfig = DspConfig.NEUTRAL

    private var engine: DspEngine? = null
    private var analyzer: SpectrumAnalyzer? = null
    private var scratch = FloatArray(0)
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    /** Простой генератор шума дизеринга. Свой, чтобы не платить за Random на аудиопотоке. */
    private var noiseState = 0x2545F491u

    /** Зовётся из UI/сервиса. Движок подхватит на следующем блоке — без разрывов и щелчков. */
    fun setConfig(config: DspConfig) {
        val safe = config.sanitized()
        pending = safe
        engine?.setConfig(safe)
    }

    /**
     * Форматы, которые мы умеем. Неизвестный не роняет воспроизведение и не «глушит» трек:
     * возвращаем NOT_SET, и Media3 просто пропускает нас в цепочке.
     */
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val supported = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        if (!supported || inputAudioFormat.channelCount < 1) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        channels = inputAudioFormat.channelCount
        encoding = inputAudioFormat.encoding
        engine = DspEngine(inputAudioFormat.sampleRate, channels).also { it.setConfig(pending) }
        analyzer = SpectrumAnalyzer(inputAudioFormat.sampleRate)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val position = inputBuffer.position()
        val limit = inputBuffer.limit()
        val bytes = limit - position
        if (bytes == 0) return

        val output = replaceOutputBuffer(bytes)
        val dsp = engine
        val config = pending

        // Быстрый путь: тракт нейтрален — отдаём байты как пришли.
        if (dsp == null || config.isNeutral) {
            output.put(inputBuffer)
            output.flip()
            ZiziSpectrum.silence()
            return
        }

        val bytesPerSample = if (encoding == C.ENCODING_PCM_FLOAT) 4 else 2
        val frames = bytes / (bytesPerSample * channels)
        val needed = frames * channels
        if (scratch.size < needed) scratch = FloatArray(needed)
        val buf = scratch

        // ---- в float ----
        if (encoding == C.ENCODING_PCM_FLOAT) {
            for (i in 0 until needed) buf[i] = inputBuffer.getFloat(position + i * 4)
        } else {
            for (i in 0 until needed) buf[i] = inputBuffer.getShort(position + i * 2) / 32768f
        }

        // ---- обработка ----
        val peak = dsp.process(buf, frames)
        analyzer?.let { if (ZiziSpectrum.listening) it.feed(buf, frames, channels, peak) }

        // ---- обратно ----
        if (encoding == C.ENCODING_PCM_FLOAT) {
            for (i in 0 until needed) output.putFloat(buf[i])
        } else {
            for (i in 0 until needed) {
                // TPDF-дизеринг в пол-младшего-разряда: без него тихий хвост ревера садится на
                // сетку 16 бит и слышен как «песок». Стоит два сдвига и сложение.
                val dither = (nextNoise() + nextNoise()) * 0.5f
                var v = buf[i] * 32767f + dither
                if (v > 32767f) v = 32767f else if (v < -32768f) v = -32768f
                output.putShort(v.toInt().toShort())
            }
        }
        inputBuffer.position(limit)
        output.flip()
    }

    /** xorshift32 в диапазоне ±0.5 младшего разряда. */
    private fun nextNoise(): Float {
        var x = noiseState
        x = x xor (x shl 13)
        x = x xor (x shr 17)
        x = x xor (x shl 5)
        noiseState = x
        return (x.toInt() / 2.147483647e9f) * 0.5f
    }

    override fun onFlush() {
        engine?.reset()
        analyzer?.reset()
        ZiziSpectrum.silence()
    }

    override fun onReset() {
        engine = null
        analyzer = null
        scratch = FloatArray(0)
        ZiziSpectrum.silence()
    }
}
