package app.ziziplayer.playback

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import app.ziziplayer.data.remote.CatalogRegistry
import app.ziziplayer.data.remote.RemoteQuality

/**
 * The few pieces of network state that the Media3 loading thread needs and cannot ask a ViewModel
 * for.
 *
 * A process-wide holder is a deliberate, narrow exception to how the rest of this app passes
 * dependencies. The resolver runs inside ExoPlayer's loader, has no lifecycle, no scope and no
 * Application reference, and must answer synchronously - and the playback service lives in the same
 * process as the UI, so `ZiziApplication.onCreate` is guaranteed to have run first. Everything here
 * is a plain snapshot written by the settings collector and read by the loader; there is no logic,
 * so there is nothing to get out of sync.
 */
object RemoteRuntime {

    @Volatile var registry: CatalogRegistry = CatalogRegistry(emptyList())
    @Volatile var quality: RemoteQuality = RemoteQuality.NORMAL
    /** Quality used when the connection is metered, if a cheaper one is asked for. */
    @Volatile var meteredQuality: RemoteQuality = RemoteQuality.LOW
    @Volatile var wifiOnly: Boolean = false
    /**
     * 6.36.0. Можно ли обращаться к Google с телефона. Читается [app.ziziplayer.data.remote.MixCatalog]
     * при каждом поиске, поэтому живёт здесь, а не в ViewModel: каталог зовут и из фонового прогрева.
     */
    @Volatile var youtubeDirect: Boolean = false
    @Volatile var cacheEnabled: Boolean = true
    @Volatile var cacheBytes: Long = DEFAULT_CACHE_BYTES

    const val DEFAULT_CACHE_BYTES = 512L * 1024 * 1024

    /**
     * True when the active network charges for bytes.
     *
     * `NET_CAPABILITY_NOT_METERED` is asked for directly instead of using the long deprecated
     * `isActiveNetworkMetered`, and a missing network counts as metered: refusing to spend the
     * user's data when we are not sure is the polite failure, and there is nothing to play anyway.
     */
    fun isMetered(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = manager.activeNetwork ?: return true
        val capabilities = manager.getNetworkCapabilities(network) ?: return true
        return !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    fun effectiveQuality(context: Context): RemoteQuality =
        if (isMetered(context) && meteredQuality.targetKbps < quality.targetKbps) meteredQuality else quality
}
