package app.ziziplayer

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Стек последнего падения — на диск, 6.24.0.
 *
 * Причина появления этого файла простая: три вылета подряд разбирались по описанию «нажал
 * „Играть следующим“ и вылетело». По такому описанию причина УГАДЫВАЕТСЯ, а угаданная причина
 * лечится заплаткой рядом с настоящей. Стек снимает вопрос за секунду.
 *
 * Что здесь сознательно НЕ делается: ничего не отправляется само. Никакой сети, никакого
 * Crashlytics, никакого идентификатора устройства. Файл лежит в песочнице приложения, и уходит
 * он только тогда, когда человек сам нажал «Отправить» в настройках. Плеер, который тихо шлёт
 * телеметрию, — это уже не плеер.
 *
 * Хранится ровно один, последний: архив падений нужен серверу аналитики, а не человеку с
 * телефоном.
 */
object CrashLog {

    private const val FILE = "crash-last.txt"

    @Volatile private var cached: String? = null
    @Volatile private var read = false

    /** Ставится первым делом в Application: обработчик не должен ничего инициализировать. */
    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { write(app, thread, error) }
            // Родной обработчик обязан получить своё: без него не будет ни системного диалога,
            // ни записи в logcat, ни отчёта в Play Console — то есть станет ХУЖЕ, чем было.
            previous?.uncaughtException(thread, error)
        }
    }

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val stack = StringWriter().also { out -> error.printStackTrace(PrintWriter(out)) }.toString()
        val text = buildString {
            appendLine("ZiziPlayer " + BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")")
            appendLine("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
            appendLine(Build.MANUFACTURER + " " + Build.MODEL)
            appendLine("Поток: " + thread.name)
            appendLine("Время: " + java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date()))
            appendLine()
            append(stack)
        }
        File(context.filesDir, FILE).writeText(text.take(24_000))
        cached = text
        read = true
    }

    /** Кэширует: строка читается из композиции настроек, лезть на диск на каждый кадр незачем. */
    fun report(context: Context): String? {
        if (read) return cached
        read = true
        cached = runCatching {
            val file = File(context.filesDir, FILE)
            if (file.exists()) file.readText().ifBlank { null } else null
        }.getOrNull()
        return cached
    }

    fun clear(context: Context) {
        cached = null
        read = true
        runCatching { File(context.filesDir, FILE).delete() }
    }
}
