package app.ziziplayer.share

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Формат обмена плейлистами ZiziPlayer. Версионирован с первого дня: поле "v".
 *
 * Плейлист едет не музыкой, а паспортами треков (provider + remoteId). 300 треков — около 30 КБ
 * текста. Треки из локальной библиотеки отправителя едут без remoteId: название, артист и
 * длительность. На приёме они ищутся в каталоге, длительность сверяется с допуском ±3 с.
 *
 * Два транспорта:
 *   1) файл .zizi — обычный JSON, уходит системной шторкой Android;
 *   2) строка "ZIZI1:<base64(gzip(json))>" — страховка на случай мессенджеров, которые
 *      переименовывают файлы и ломают MIME. Работает через простой копипаст.
 *
 * Этот файл — чистая логика без Android UI, его поведение проверяется без эмулятора.
 */
object PlaylistShare {

    const val VERSION = 1
    const val MIME = "application/octet-stream"
    const val EXTENSION = "zizi"
    const val TEXT_PREFIX = "ZIZI1:"
    const val URI_SCHEME = "zizi"

    /** Максимумы: защита от того, чтобы кто-то прислал 40 МБ «плейлиста». */
    const val MAX_TRACKS = 300
    const val MAX_BYTES = 256 * 1024
    const val DURATION_TOLERANCE_MS = 3_000L

    data class Entry(
        val provider: String?,   // "ytm" и т.п.; null — трек был локальным у отправителя
        val remoteId: String?,   // id, по которому резолвится поток
        val title: String,
        val artist: String,
        val durationMs: Long
    ) {
        val resolvable: Boolean get() = !provider.isNullOrBlank() && !remoteId.isNullOrBlank()
    }

    data class Payload(val name: String, val entries: List<Entry>) {
        val readyCount: Int get() = entries.count { it.resolvable }
        val searchCount: Int get() = entries.size - readyCount
    }

    fun encodeJson(payload: Payload): String {
        val arr = JSONArray()
        payload.entries.take(MAX_TRACKS).forEach { e ->
            val o = JSONObject()
            e.provider?.takeIf { it.isNotBlank() }?.let { o.put("p", it) }
            e.remoteId?.takeIf { it.isNotBlank() }?.let { o.put("r", it) }
            o.put("t", e.title)
            o.put("a", e.artist)
            if (e.durationMs > 0) o.put("d", e.durationMs / 1000)
            arr.put(o)
        }
        return JSONObject()
            .put("v", VERSION)
            .put("name", payload.name)
            .put("tracks", arr)
            .toString()
    }

    /** Компактная строка для мессенджеров и буфера обмена. */
    fun encodeText(payload: Payload): String {
        val raw = encodeJson(payload).toByteArray()
        val out = ByteArrayOutputStream()
        GZIPOutputStream(out).use { it.write(raw) }
        return TEXT_PREFIX + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)
    }

    /**
     * Принимает всё, что мог прислать человек: сырой JSON, строку ZIZI1:, ссылку zizi://p/<blob>,
     * а также текст, внутри которого эта строка просто где-то лежит (подпись мессенджера, «смотри»).
     * Возвращает null, если это не плейлист — тихо, без исключений: на входе чужие данные.
     */
    fun decode(input: String?): Payload? {
        val text = input?.trim().orEmpty()
        if (text.isEmpty() || text.length > MAX_BYTES * 2) return null

        BLOB_PATTERN.find(text)?.let { m ->
            runCatching {
                val blob = m.groupValues[1]
                // Сжатие gzip реально даёт под тысячу к одному на однообразных данных, поэтому по
                // размеру base64 сразу видно, что распаковывать нечего: наш собственный кодировщик
                // при MAX_TRACKS никогда не выдаёт такую строку.
                if (blob.length > MAX_BLOB_CHARS) return null
                val bytes = Base64.decode(blob, Base64.NO_WRAP or Base64.URL_SAFE)
                val json = GZIPInputStream(bytes.inputStream()).use { it.readAtMost(MAX_BYTES) } ?: return null
                return parseJson(String(json))
            }
        }
        return parseJson(text)
    }

    fun parseJson(text: String): Payload? = runCatching {
        val root = JSONObject(text)
        if (root.optInt("v", 0) > VERSION) return null   // прислали формат из будущего
        val arr = root.optJSONArray("tracks") ?: return null
        val entries = ArrayList<Entry>(minOf(arr.length(), MAX_TRACKS))
        for (i in 0 until minOf(arr.length(), MAX_TRACKS)) {
            val o = arr.optJSONObject(i) ?: continue
            val title = o.optString("t").trim()
            if (title.isEmpty()) continue
            entries += Entry(
                provider = o.optString("p").takeIf { it.isNotBlank() },
                remoteId = o.optString("r").takeIf { it.isNotBlank() },
                title = title,
                artist = o.optString("a").trim(),
                durationMs = o.optLong("d", 0L) * 1000L
            )
        }
        if (entries.isEmpty()) return null
        Payload(root.optString("name").ifBlank { "Плейлист" }, entries)
    }.getOrNull()

    /**
     * Регулярное выражение собирается один раз (6.19.0).
     *
     * Внутри метода `Regex(...)` компилировался заново на каждый вызов, а вызывается он на каждую
     * вставку из буфера обмена и на каждый входящий Intent.
     */
    private val BLOB_PATTERN = Regex(Regex.escape(TEXT_PREFIX) + "([A-Za-z0-9_\\-=]+)")

    /**
     * Потолок длины сжатого блока. Ровно тот же MAX_BYTES, только в символах base64 (плюс запас на
     * padding): распакованный результат физически не может быть больше, чем нам разрешено принять,
     * а вход больше этого — заведомо не наш плейлист.
     */
    private const val MAX_BLOB_CHARS = MAX_BYTES / 3 * 4 + 16

    /**
     * Читает не больше [limit] байт и возвращает null, если данных оказалось больше (6.19.0).
     *
     * Это защита от gzip-бомбы, и она не теоретическая: `readBytes()` на распаковывающем потоке
     * читает до конца, каким бы этот конец ни был. Двести килобайт архива, присланные в буфере
     * обмена, разворачиваются в двести мегабайт нулей и убивают процесс раньше, чем кто-либо
     * успеет проверить размер результата — проверка `if (json.size > MAX_BYTES)` стояла ПОСЛЕ
     * распаковки, то есть после падения. А данные тут всегда чужие: их прислали в мессенджере.
     */
    private fun java.io.InputStream.readAtMost(limit: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        while (true) {
            val read = read(buffer)
            if (read <= 0) break
            if (out.size() + read > limit) return null
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    /** Имя файла без сюрпризов: мессенджеры и файловые менеджеры не любят слэши и кавычки. */
    fun fileName(name: String): String {
        val safe = name.replace(Regex("""[^\p{L}\p{N} _-]"""), "").trim().take(40)
        return (if (safe.isEmpty()) "playlist" else safe) + "." + EXTENSION
    }

    /** Совпал ли найденный в каталоге трек с паспортом отправителя. */
    fun matches(entry: Entry, foundTitle: String, foundDurationMs: Long): Boolean {
        if (entry.durationMs > 0 && foundDurationMs > 0 &&
            Math.abs(entry.durationMs - foundDurationMs) > DURATION_TOLERANCE_MS
        ) return false
        val a = foundTitle.lowercase(java.util.Locale.ROOT).filter { it.isLetterOrDigit() }
        val b = entry.title.lowercase(java.util.Locale.ROOT).filter { it.isLetterOrDigit() }
        return a.contains(b) || b.contains(a)
    }
}
