package app.ziziplayer.data.remote

import android.util.Log
import android.os.SystemClock
import app.ziziplayer.BuildConfig
import java.io.IOException
import java.util.Locale
import okhttp3.Interceptor
import okhttp3.Response

/** Immutable request policy shared by WebView, API calls and Media3's OkHttpDataSource. */
object SessionRequestPolicy {
    val userAgent: String = BuildConfig.SESSION_USER_AGENT
        .replace("\r", " ")
        .replace("\n", " ")
        .trim()
        .ifEmpty { "ZiziPlayer/${BuildConfig.VERSION_NAME} (Android)" }

    val tokenHeader: String = BuildConfig.SESSION_TOKEN_HEADER.trim()
        .takeIf { it.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+")) }
        ?: "X-Session-Payload"

    private val bootstrapHost: String? = runCatching {
        java.net.URI(BuildConfig.SESSION_BOOTSTRAP_URL).host?.lowercase(Locale.US)
    }.getOrNull()

    val protectedHosts: Set<String> = BuildConfig.SESSION_PROTECTED_HOSTS
        .split(',')
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.isNotEmpty() }
        .toMutableSet()
        .apply { if (isEmpty()) bootstrapHost?.let(::add) }

    val waitMs: Long = BuildConfig.SESSION_TOKEN_WAIT_MS.coerceIn(1_000L, 30_000L)

    /**
     * 6.24.3. Внутренняя метка «этот запрос можно не выполнять». Ставит её только загрузчик
     * обложек; до сети она не доходит — интерсептор её снимает.
     */
    const val deferrableHeader: String = "X-Zizi-Deferrable"

    /** Сколько ждать токен для некритичного запроса. Обложка не стоит двенадцати секунд. */
    const val deferrableWaitMs: Long = 1_500L

    fun protects(host: String): Boolean = matches(host, protectedHosts)

    /**
     * Чистая функция сопоставления, вынесенная ради тестов (6.19.0).
     *
     * Это правило решает единственный вопрос: уходит ли токен сессии на этот хост. Ошибка в нём в
     * одну сторону — токен не приходит туда, где нужен (треки не играют), в другую — токен уходит
     * туда, куда не надо (утечка). Такое правило обязано быть проверяемым без телефона и без
     * BuildConfig, поэтому оно принимает список правил аргументом.
     *
     * Тонкость, которую тест и закрепляет: `*.example.com` НЕ покрывает сам `example.com`.
     * Сравнение идёт по `endsWith(".example.com")`, то есть поддомены — да, корень — нет. Это
     * осознанно (правило про поддомены не должно молча расширяться на домен), и без теста такое
     * поведение живёт до первого «а почему не работает».
     */
    fun matches(host: String, rules: Set<String>): Boolean {
        val normalized = host.lowercase(Locale.US)
        return rules.any { rule ->
            rule == "*" || normalized == rule ||
                (rule.startsWith("*.") && normalized.endsWith(rule.removePrefix("*")))
        }
    }
}

/**
 * Enforces one User-Agent on every request and adds the in-memory payload only to allowlisted
 * hosts. If a protected request arrives before the WebView finishes, the OkHttp worker waits for
 * the configured bounded interval and then fails closed instead of leaking an unauthenticated call.
 */
class SessionHeadersInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val isProtected = SessionRequestPolicy.protects(original.url.host)
        // 6.24.3. Метка снимается ВСЕГДА и до отправки: наружу она уходить не должна.
        val deferrable = original.header(SessionRequestPolicy.deferrableHeader) != null
        val builder = original.newBuilder()
            .removeHeader(SessionRequestPolicy.deferrableHeader)
            // header(), not addHeader(): caller-provided values cannot bypass the policy.
            .header("User-Agent", SessionRequestPolicy.userAgent)

        if (isProtected) {
            // 6.18.0: ожидание токена блокирует поток OkHttp — по умолчанию до 12 секунд, и
            // снаружи это выглядит как «поиск тупит». Само ожидание убрать нельзя (уйти в сеть
            // без payload = отдать запрос без авторизации), но молчать о нём нельзя тем более:
            // без этой строки в логе долгий старт WebView неотличим от медленной сети.
            val startedAt = SystemClock.elapsedRealtime()
            // 6.24.3. Каталог и звук ждут токен полностью — без него запрос бессмыслен. Обложка
            // ждёт полторы секунды и отступается: до этой правки десяток плиток мог занять
            // потоки OkHttp на двенадцать секунд каждая, и снаружи это выглядело ровно как
            // «поиск тупит» — при том что запрос поиска стоял в той же очереди.
            val limitMs =
                if (deferrable) SessionRequestPolicy.deferrableWaitMs else SessionRequestPolicy.waitMs
            val payload = SessionWebToken.await(limitMs)
            val waited = SystemClock.elapsedRealtime() - startedAt
            if (waited > SLOW_WAIT_MS) {
                Log.w("ZiziSession", "ждали payload ${waited} мс для ${original.url.host}")
            }
            builder.header(SessionRequestPolicy.tokenHeader, payload)
        } else {
            // Do not let an accidentally supplied session payload escape to third-party hosts.
            builder.removeHeader(SessionRequestPolicy.tokenHeader)
        }

        val response = chain.proceed(builder.build())
        if (isProtected && (response.code == 401 || response.code == 403)) {
            SessionWebToken.invalidate()
            SessionWebToken.start(force = true)
        }
        return response
    }

    private companion object {
        /** Порог «это уже заметно человеку»: дольше двух секунд ждать нечего. */
        const val SLOW_WAIT_MS = 2_000L
    }
}
