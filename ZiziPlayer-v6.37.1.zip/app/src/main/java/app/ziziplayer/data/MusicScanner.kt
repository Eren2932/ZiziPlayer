package app.ziziplayer.data

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/** How far a scan has got. [total] is 0 while the file list is still being built. */
data class ScanProgress(val done: Int, val total: Int, val label: String)

/**
 * Tag reading is IO bound (open container, seek, parse), so several files at once is a real win,
 * but each `MediaMetadataRetriever` holds a native decoder. Four is enough to saturate storage on a
 * mid-range phone without inviting an OEM media-server stall.
 */
private const val METADATA_WORKERS = 4

/** Reporting every file would spam the UI state; every 25th is smooth at any list length. */
private const val PROGRESS_STEP = 25

/** Сколько файлов обрабатывается одной пачкой корутин. См. scanTree. */
private const val SCAN_CHUNK = 500

/** A malformed provider can present a directory tree that loops. Bound the walk. */
private const val MAX_DIRECTORIES = 20_000

/**
 * Отбор в MediaStore (6.19.0).
 *
 * Было просто `IS_MUSIC != 0`. В SQL это трёхзначная логика: для строки, где IS_MUSIC равен NULL,
 * условие не истинно и не ложно — оно неизвестно, и строка не попадает в результат. А NULL там
 * встречается: часть прошивок и часть способов положить файл на телефон (adb push, распаковка
 * архива, копирование через MTP) оставляют флаг незаполненным до полного пересканирования
 * медиа-хранилища. Симптом ровно тот, который трудно поверить: «файл лежит в папке, плеер его не
 * видит, а после перезагрузки увидел».
 *
 * NULL теперь считается музыкой, явный ноль — нет: рингтоны, будильники и уведомления
 * по-прежнему остаются за бортом, потому что у них флаг выставлен осознанно.
 */
private val MEDIASTORE_SELECTION =
    "(" + MediaStore.Audio.Media.IS_MUSIC + " != 0 OR " + MediaStore.Audio.Media.IS_MUSIC + " IS NULL)"

private val AUDIO_EXTENSIONS = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "wav", "opus", "wma", "mp4", "m4b", "aif", "aiff", "mka")

class MusicScanner(private val context: Context) {

    /**
     * MediaStore in one query. Nothing here opens a file: title, artist, album, duration, size and
     * album art are all columns, which is why this path was never the slow one.
     *
     * Two corrections against v6.2:
     *
     * 1. `RELATIVE_PATH` only exists from API 29. v6.2 asked for it with `getColumnIndexOrThrow` on
     *    every API level, so on Android 8 and 9 the scan threw `IllegalArgumentException`, the
     *    exception was swallowed by the caller's `runCatching`, and the library came up **empty**
     *    with no error shown - on a minSdk 26 app. Optional columns are now resolved with
     *    `getColumnIndex` and the folder falls back to the parent directory of `DATA`.
     * 2. `DISPLAY_NAME` and `SIZE` are read because they, not the provider row id, form the key.
     */
    /**
     * Сколько музыкальных строк видит система прямо сейчас. `-1` — спросить не удалось.
     *
     * Отдельный запрос ровно за одним числом, без колонок и без чтения тегов: он существует для
     * проверки «медиатека разошлась с диском?» на входе в приложение и обязан стоить миллисекунды.
     * Отбор тот же, что у полного сканирования, иначе числа было бы бессмысленно сравнивать.
     */
    suspend fun mediaStoreCount(): Int = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID),
                MEDIASTORE_SELECTION, null, null
            )?.use { it.count } ?: -1
        }.getOrDefault(-1)
    }

    @Suppress("DEPRECATION") // MediaStore.Audio.Media.DATA: the only folder source before API 29.
    suspend fun scanMediaStore(): List<TrackEntity> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val columns = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DATE_ADDED)
            add(MediaStore.Audio.Media.ALBUM_ID)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.DATA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) add(MediaStore.Audio.Media.RELATIVE_PATH)
        }.toTypedArray()

        val result = ArrayList<TrackEntity>()
        val cursor = runCatching {
            context.contentResolver.query(collection, columns, MEDIASTORE_SELECTION, null, null)
        }.getOrNull() ?: return@withContext result

        cursor.use { c ->
            val idI = c.getColumnIndex(MediaStore.Audio.Media._ID)
            val titleI = c.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val artistI = c.getColumnIndex(MediaStore.Audio.Media.ARTIST)
            val albumI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM)
            val durationI = c.getColumnIndex(MediaStore.Audio.Media.DURATION)
            val dateI = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            val albumIdI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
            val nameI = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeI = c.getColumnIndex(MediaStore.Audio.Media.SIZE)
            val dataI = c.getColumnIndex(MediaStore.Audio.Media.DATA)
            val pathI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            } else -1
            if (idI < 0) return@use

            while (c.moveToNext()) {
                currentCoroutineContext().ensureActive()
                val mediaId = c.longOrZero(idI)
                val uri = ContentUris.withAppendedId(collection, mediaId)
                val displayName = c.string(nameI)
                // 6.27.1 — MediaStore врёт, и это надо проверять.
                //
                // Жалоба тестировщика («удалил папку проводником, в плеере она осталась») не про
                // наше кэширование. Файл удаляют мимо MediaStore — проводником без уведомления,
                // «умной очисткой» производителя, снятием карты, adb — и строка в системном
                // индексе живёт до его собственного пересканирования, которое может не случиться
                // до перезагрузки. Пересканирование медиатеки в этом случае не помогало и не
                // могло помочь: сканер добросовестно получал от системы удалённый файл и
                // добросовестно возвращал его в базу.
                //
                // Один stat() на строку — это единицы микросекунд, и это единственный источник
                // правды, который у нас есть. Пустой DATA (Android 10+ вправе его не отдавать)
                // трактуется как «проверить нечем» и пропускается: лучше лишний трек, чем
                // потерянная библиотека на устройстве, которое скрывает пути.
                val data = c.string(dataI)
                if (data != null && data.isNotBlank() && !java.io.File(data).exists()) continue
                val size = c.longOrZero(sizeI)
                val albumId = c.longOrZero(albumIdI)
                result += TrackEntity(
                    id = TrackId.forFile(displayName, size, uri.toString()),
                    uri = uri.toString(),
                    title = c.string(titleI) ?: displayName?.substringBeforeLast('.') ?: "Без названия",
                    artist = (c.string(artistI) ?: "Неизвестный артист").replace("<unknown>", "Неизвестный артист"),
                    album = c.string(albumI) ?: "",
                    durationMs = c.longOrZero(durationI),
                    artworkUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString(),
                    sourceFolder = folderName(c.string(pathI), c.string(dataI)),
                    dateAdded = c.longOrZero(dateI).let { if (it > 0L) it * 1000 else System.currentTimeMillis() },
                    sizeBytes = size,
                    legacyId = "media:$mediaId"
                )
            }
        }
        result
    }

    /**
     * A user-picked folder tree.
     *
     * v6.2 walked it with `DocumentFile` and read tags inline, on one thread, with no way to stop.
     * Both halves of that were expensive:
     *
     * - **`DocumentFile` is one query per property.** `listFiles()` queries the directory, then
     *   every `.name`, `.type`, `.isDirectory` and `.length()` issues *another* IPC round trip to
     *   the document provider. For 3400 files that is well over ten thousand binder calls before a
     *   single tag is read. Here each directory is queried exactly once, with a projection, and
     *   every value comes out of that one row.
     * - **`MediaMetadataRetriever` on the walking thread.** It is now off the walk, capped at
     *   [METADATA_WORKERS] in parallel, and - crucially - **skipped entirely for files already in
     *   the database with the same byte size**. After the first scan a rescan touches no decoder at
     *   all, so "refresh library" goes from tens of seconds to roughly the cost of the walk.
     *
     * The walk is iterative rather than recursive: a deep tree used to grow the stack in lockstep
     * with its depth, and a provider that reports a cycle would have overflowed it.
     *
     * Cancellation is honoured per directory and per file, so leaving the screen or removing the
     * folder stops the work instead of letting it run to completion in the background.
     *
     * [onProgress] is invoked from the metadata workers, i.e. from several threads - the receiver
     * must be safe for that (the ViewModel funnels it into a `MutableStateFlow`, which is).
     */
    suspend fun scanTree(
        treeUri: Uri,
        known: Map<String, TrackEntity> = emptyMap(),
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): List<TrackEntity> = withContext(Dispatchers.IO) {
        val docs = walk(treeUri)
        if (docs.isEmpty()) return@withContext emptyList()

        val total = docs.size
        val counter = AtomicInteger(0)
        val gate = Semaphore(METADATA_WORKERS)

        // 6.19.0: пачками по [SCAN_CHUNK], а не все файлы разом.
        //
        // `docs.map { async { ... } }` на дереве из 20 000 файлов создаёт 20 000 объектов Deferred
        // и 20 000 продолжений одновременно, и все они живут до конца awaitAll, потому что каждый
        // держит ссылку на свой результат. Одновременность при этом всё равно ограничена
        // семафором на четырёх читателях тегов — то есть память тратилась не на скорость, а
        // впустую. На слабом телефоне с большой коллекцией это заканчивалось OutOfMemory ровно на
        // подключении большой папки, то есть в самый неудачный момент.
        val collected = ArrayList<TrackEntity>(total)
        for (chunk in docs.chunked(SCAN_CHUNK)) {
            coroutineScope {
                currentCoroutineContext().ensureActive()
                collected += chunk.map { doc ->
                async {
                    val uriText = doc.uri.toString()
                    val id = TrackId.forFile(doc.name, doc.size, uriText)
                    val legacy = "saf:" + UUID.nameUUIDFromBytes(uriText.toByteArray())
                    val cached = known[id]

                    val entity = if (cached != null && cached.sizeBytes == doc.size && doc.size > 0L && cached.durationMs > 0L) {
                        // Same file, same bytes: its tags cannot have changed. Only the things that
                        // describe *where* it currently lives are refreshed.
                        cached.copy(uri = uriText, sourceFolder = doc.folder, legacyId = legacy)
                    } else {
                        gate.withPermit {
                            currentCoroutineContext().ensureActive()
                            val meta = readMeta(doc.uri)
                            TrackEntity(
                                id = id,
                                uri = uriText,
                                title = meta.title?.takeIf { it.isNotBlank() }
                                    ?: doc.name.substringBeforeLast('.').ifBlank { "Без названия" },
                                artist = meta.artist?.takeIf { it.isNotBlank() } ?: "Неизвестный артист",
                                album = meta.album.orEmpty(),
                                durationMs = meta.duration,
                                sourceFolder = doc.folder,
                                dateAdded = if (doc.modified > 0L) doc.modified else System.currentTimeMillis(),
                                sizeBytes = doc.size,
                                legacyId = legacy
                            )
                        }
                    }

                    val done = counter.incrementAndGet()
                    if (done % PROGRESS_STEP == 0 || done == total) onProgress(done, total)
                    entity
                }
                }.awaitAll()
            }
        }
        collected
    }

    // ---------------- tree walk ----------------

    private class RawDoc(val uri: Uri, val name: String, val size: Long, val folder: String, val modified: Long)

    private suspend fun walk(treeUri: Uri): List<RawDoc> {
        val resolver = context.contentResolver
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: return emptyList()
        val out = ArrayList<RawDoc>()
        val queue = ArrayDeque<Pair<String, String>>()
        val visited = HashSet<String>()
        queue.add(rootId to (rootDisplayName(treeUri, rootId) ?: "Выбранная папка"))

        var directories = 0
        val projection = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
        )

        while (queue.isNotEmpty() && directories < MAX_DIRECTORIES) {
            currentCoroutineContext().ensureActive()
            val (docId, folder) = queue.poll() ?: break
            if (!visited.add(docId)) continue
            directories++

            val children = runCatching { DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId) }.getOrNull() ?: continue
            runCatching {
                resolver.query(children, projection, null, null, null)?.use { c ->
                    val idI = c.getColumnIndex(Document.COLUMN_DOCUMENT_ID)
                    val nameI = c.getColumnIndex(Document.COLUMN_DISPLAY_NAME)
                    val mimeI = c.getColumnIndex(Document.COLUMN_MIME_TYPE)
                    val sizeI = c.getColumnIndex(Document.COLUMN_SIZE)
                    val modI = c.getColumnIndex(Document.COLUMN_LAST_MODIFIED)
                    if (idI < 0) return@use
                    while (c.moveToNext()) {
                        val childId = c.string(idI) ?: continue
                        val name = c.string(nameI) ?: ""
                        val mime = c.string(mimeI)
                        if (mime == Document.MIME_TYPE_DIR) {
                            queue.add(childId to name.ifBlank { folder })
                        } else if (isAudio(name, mime)) {
                            out += RawDoc(
                                uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId),
                                name = name,
                                size = c.longOrZero(sizeI),
                                folder = folder,
                                modified = c.longOrZero(modI)
                            )
                        }
                    }
                }
            }
        }
        return out
    }

    private fun rootDisplayName(treeUri: Uri, rootId: String): String? = runCatching {
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        context.contentResolver.query(uri, arrayOf(Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.string(0) else null
        }
    }.getOrNull()

    private fun isAudio(name: String, mime: String?): Boolean {
        if (mime != null && mime.startsWith("audio/")) return true
        // Providers hand back application/octet-stream for flac and opus more often than not.
        // Locale.ROOT: см. TrackId. Файл «TRACK.FLAC» на турецком телефоне давал расширение
        // «flac» с точечной 'ı' и не проходил проверку — то есть не считался музыкой вообще.
        val extension = name.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)
        return extension.isNotEmpty() && extension in AUDIO_EXTENSIONS
    }

    // ---------------- tags ----------------

    private data class AudioMeta(val title: String?, val artist: String?, val album: String?, val duration: Long)

    private fun readMeta(uri: Uri): AudioMeta = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            AudioMeta(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally {
            // release() throws on some OEM builds when setDataSource failed; it must not take the
            // whole scan down with it.
            runCatching { retriever.release() }
        }
    }.getOrDefault(AudioMeta(null, null, null, 0L))

    // ---------------- helpers ----------------

    /** Folder label: RELATIVE_PATH on API 29+, otherwise the parent directory of the legacy path. */
    private fun folderName(relativePath: String?, data: String?): String {
        relativePath?.trimEnd('/')?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let { return it }
        data?.substringBeforeLast('/', "")?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let { return it }
        return "Устройство"
    }
}

/** `getString` on a column index that may be -1, without the try/catch at every call site. */
private fun Cursor.string(index: Int): String? = if (index < 0) null else runCatching { getString(index) }.getOrNull()

/**
 * Число из курсора, которое не может уронить сканирование (6.19.0).
 *
 * `Cursor.getLong` на строковой или пустой ячейке бросает NumberFormatException, и это не
 * гипотеза: колонку SIZE в SAF заполняет провайдер документов, а провайдером может быть что угодно
 * — от файлового менеджера до облака, — и часть их отдаёт там пустую строку или NULL. Исключение
 * летело из рабочего потока сканера и обрывало ВСЁ сканирование на этом файле: библиотека
 * оставалась наполовину прочитанной, а причина была не видна нигде.
 *
 * Ноль — корректный ответ для всех, кто это читает: [TrackId] считает хеш и от нулевого размера, а
 * нулевая длительность просто означает «прочитаем теги, а не возьмём из кэша».
 */
private fun Cursor.longOrZero(index: Int): Long =
    if (index < 0) 0L else runCatching { getLong(index) }.getOrDefault(0L)
