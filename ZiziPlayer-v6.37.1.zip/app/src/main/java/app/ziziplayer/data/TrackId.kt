package app.ziziplayer.data

import java.security.MessageDigest

/**
 * The identity of a track.
 *
 * Up to v6.2 the primary key was whatever the source handed us: `"media:$mediaStoreId"` for
 * MediaStore rows and a UUID over the document URI for SAF rows. Neither is stable.
 *
 * - `MediaStore.Audio.Media._ID` is a row id in the media provider, not a property of the file. It
 *   changes whenever the file is re-indexed: moving it, renaming its folder, clearing the media
 *   store cache, restoring a backup, or a system update that triggers a full rescan. It is also
 *   reused for a *different* file after the original is deleted.
 * - A SAF document URI embeds the tree grant. Re-picking the same folder can produce a different
 *   grant, and the whole URI changes if the provider authority changes (SD card remount).
 *
 * Everything the user has invested in - favourites, playlist membership, per-track speed/pitch/
 * reverb, "removed from my set", play counts - is keyed by that id. So a re-index silently wiped
 * all of it. That is the single most damaging bug in the app: it destroys user data, it does it
 * quietly, and no amount of care in the UI can compensate for it.
 *
 * The fix is to derive the key from the file itself:
 *
 *     id = "f:" + sha1("<display name lowercased>|<size in bytes>")[0..23]
 *
 * **Why name + size and nothing else.** Both values are exact and available from both sources
 * (`DISPLAY_NAME`/`SIZE` on MediaStore, `COLUMN_DISPLAY_NAME`/`COLUMN_SIZE` on SAF) without opening
 * the file. Duration is deliberately *not* part of the key: MediaStore reports it from the container
 * header while `MediaMetadataRetriever` computes it from the stream, and the two disagree by a few
 * milliseconds on plenty of files - straddling a rounding boundary would produce two different ids
 * for one file. The full path is also excluded, so moving a file between folders keeps its identity.
 *
 * A hash rather than the raw string keeps the key short and fixed-width - it is stored in six tables
 * and compared on every list build.
 *
 * **Collisions.** Two files can share a name and a byte size only if they are byte-identical
 * duplicates in different folders, in which case merging them is the desired behaviour anyway: the
 * old code already collapsed those with a much looser `title|artist|duration` heuristic. 96 bits of
 * hash makes an accidental collision between genuinely different files a non-event.
 *
 * **Degenerate input.** Some document providers return 0 or -1 for `COLUMN_SIZE`. Hashing that
 * would collapse every such file into one id and the library would appear to hold a single track, so
 * those fall back to the URI form `"u:"` - not stable across re-grants, but correct.
 */
object TrackId {

    fun forFile(displayName: String?, sizeBytes: Long, fallbackUri: String): String {
        // 6.19.0: Locale.ROOT обязателен именно здесь.
        //
        // lowercase() без локали берёт локаль устройства, а турецкая раскладка переводит 'I' не в
        // 'i', а в 'ı'. Идентификатор трека считается хешем от этой строки — значит, у человека с
        // турецким языком системы вся библиотека получала другие id, и смена языка телефона
        // отвязывала избранное, плейлисты, эффекты и счётчики от треков разом. Тихо и необратимо.
        val name = displayName?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
        return if (name.isNotEmpty() && sizeBytes > 0L) "f:" + sha1("$name|$sizeBytes")
        else "u:" + sha1(fallbackUri)
    }

    /** 24 hex chars = 96 bits. */
    private fun sha1(input: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(input.toByteArray(Charsets.UTF_8))
        val out = StringBuilder(24)
        for (i in 0 until 12) {
            val b = digest[i].toInt() and 0xFF
            out.append(HEX[b ushr 4]).append(HEX[b and 0x0F])
        }
        return out.toString()
    }

    private val HEX = "0123456789abcdef".toCharArray()
}
