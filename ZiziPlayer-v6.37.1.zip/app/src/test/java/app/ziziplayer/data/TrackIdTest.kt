package app.ziziplayer.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import java.util.Locale
import org.junit.Test

/**
 * Тесты на идентичность трека.
 *
 * Это самое дорогое место в приложении: по этому id связаны избранное, состав плейлистов,
 * эффекты, скрытые треки и счётчики прослушиваний. Ошибка здесь не роняет приложение — она тихо
 * отвязывает от треков всё, что человек нажимал месяцами. Поэтому проверяется не «работает ли
 * хеш», а именно те свойства, на которые опирается остальной код.
 */
class TrackIdTest {

    @Test
    fun `один и тот же файл даёт один и тот же id`() {
        val a = TrackId.forFile("Track.mp3", 4_200_000L, "content://a/1")
        val b = TrackId.forFile("Track.mp3", 4_200_000L, "content://совсем/другой/uri")
        assertEquals(a, b)
    }

    @Test
    fun `регистр имени не влияет на id`() {
        assertEquals(
            TrackId.forFile("TRACK.MP3", 100L, "u"),
            TrackId.forFile("track.mp3", 100L, "u")
        )
    }

    /**
     * Главное, ради чего тест вообще написан (6.19.0).
     *
     * `lowercase()` без локали в турецкой локали переводит 'I' в 'ı', а не в 'i'. Идентификатор —
     * хеш от этой строки, то есть смена языка телефона переписывала id всей библиотеки и рвала
     * связь с пользовательскими данными. Тест меняет локаль JVM по умолчанию — ровно то, что
     * делает Android при смене языка системы.
     */
    @Test
    fun `id не зависит от локали устройства`() {
        val original = Locale.getDefault()
        try {
            Locale.setDefault(Locale.US)
            val inUs = TrackId.forFile("INTRO I.flac", 999L, "u")
            Locale.setDefault(Locale("tr", "TR"))
            val inTurkish = TrackId.forFile("INTRO I.flac", 999L, "u")
            assertEquals("id разъехался при смене локали", inUs, inTurkish)
        } finally {
            Locale.setDefault(original)
        }
    }

    @Test
    fun `размер входит в идентичность`() {
        assertNotEquals(
            TrackId.forFile("Track.mp3", 100L, "u"),
            TrackId.forFile("Track.mp3", 101L, "u")
        )
    }

    /**
     * Провайдеры документов, отдающие 0 или -1 в COLUMN_SIZE, существуют. Без этой ветки все такие
     * файлы схлопнулись бы в один id и медиатека показала бы один трек вместо тысячи.
     */
    @Test
    fun `без размера идентичность считается от uri`() {
        val zero = TrackId.forFile("Track.mp3", 0L, "content://x/1")
        val negative = TrackId.forFile("Track.mp3", -1L, "content://x/1")
        val other = TrackId.forFile("Track.mp3", 0L, "content://x/2")
        assertTrue(zero.startsWith("u:"))
        assertEquals(zero, negative)
        assertNotEquals(zero, other)
    }

    @Test
    fun `пустое имя не считается именем`() {
        assertTrue(TrackId.forFile("   ", 500L, "content://x/1").startsWith("u:"))
        assertTrue(TrackId.forFile(null, 500L, "content://x/1").startsWith("u:"))
    }

    @Test
    fun `длина id фиксирована и коротка`() {
        // 2 символа префикса + 24 hex. На этот размер рассчитаны все шесть таблиц.
        assertEquals(26, TrackId.forFile("Track.mp3", 123L, "u").length)
        assertEquals(26, TrackId.forFile(null, 0L, "u").length)
    }
}
