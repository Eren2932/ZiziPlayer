package app.ziziplayer.data.remote

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Кому уходит токен сессии.
 *
 * Ошибка в этом правиле стоит либо неработающего воспроизведения, либо утечки секрета на чужой
 * хост. Проверяется чистая [SessionRequestPolicy.matches], которой список правил передаётся
 * аргументом, — поэтому тест не зависит ни от BuildConfig, ни от того, чем собран билд.
 */
class SessionRequestPolicyTest {

    @Test
    fun `точное совпадение хоста`() {
        val rules = setOf("music.youtube.com")
        assertTrue(SessionRequestPolicy.matches("music.youtube.com", rules))
        assertTrue(SessionRequestPolicy.matches("MUSIC.YOUTUBE.COM", rules))
        assertFalse(SessionRequestPolicy.matches("youtube.com", rules))
    }

    @Test
    fun `маска покрывает поддомены и не покрывает корень`() {
        val rules = setOf("*.youtube.com")
        assertTrue(SessionRequestPolicy.matches("music.youtube.com", rules))
        assertTrue(SessionRequestPolicy.matches("rr1---sn-x.youtube.com", rules))
        // Осознанно: правило про поддомены не расширяется на сам домен.
        assertFalse(SessionRequestPolicy.matches("youtube.com", rules))
    }

    @Test
    fun `маска не должна ловить похожий чужой домен`() {
        // Самая опасная ошибка в таких правилах — суффиксное сравнение без точки:
        // "evil-youtube.com" заканчивается на "youtube.com", но своим не является.
        assertFalse(SessionRequestPolicy.matches("evil-youtube.com", setOf("*.youtube.com")))
    }

    @Test
    fun `звёздочка означает все`() {
        assertTrue(SessionRequestPolicy.matches("example.org", setOf("*")))
    }

    @Test
    fun `пустой список не отдаёт токен никому`() {
        assertFalse(SessionRequestPolicy.matches("music.youtube.com", emptySet()))
    }
}
