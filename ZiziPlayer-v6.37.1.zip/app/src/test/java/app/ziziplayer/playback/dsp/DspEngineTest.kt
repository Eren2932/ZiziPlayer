package app.ziziplayer.playback.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.sin

/**
 * Тесты движка (6.24.4). Возможны только потому, что в [DspEngine], [Biquad] и [DspCodec] нет ни
 * одного импорта android.* — иначе всё это проверялось бы «на слух на телефоне», как до 6.24.4.
 *
 * Проверяется ровно то, что ломает плеер у пользователя, а не то, что легко проверить:
 * NaN в буфере (тишина или треск до конца трека), выход за пределы -1..1 (клиппинг),
 * незатухающий ревер (самовозбуждение), битая строка настроек (падение при старте).
 */
class DspEngineTest {

    private val sr = 48000

    /** Шум ровно в пределах ±amp. Первая редакция делила на 1000 без вычитания смещения и
     *  давала ±2*amp — тест «выход не покидает -1..1» падал на СВОЁМ ЖЕ входе, а не на движке. */
    private fun noise(frames: Int, amp: Float = 0.3f): FloatArray {
        var seed = 12345
        return FloatArray(frames * 2) {
            seed = seed * 1103515245 + 12345
            (((seed ushr 16) % 2001) - 1000) / 1000f * amp
        }
    }

    private fun tone(frames: Int, freq: Float, amp: Float = 0.5f): FloatArray {
        val out = FloatArray(frames * 2)
        for (i in 0 until frames) {
            val v = (amp * sin(2.0 * Math.PI * freq * i / sr)).toFloat()
            out[i * 2] = v; out[i * 2 + 1] = v
        }
        return out
    }

    private fun rms(a: FloatArray, from: Int = 0): Float {
        var s = 0.0
        for (i in from until a.size) s += a[i].toDouble() * a[i]
        return Math.sqrt(s / (a.size - from)).toFloat()
    }

    // ---------------------------------------------------------------- фильтры

    @Test fun `peaking band gives exactly the requested gain`() {
        for (rate in intArrayOf(22050, 44100, 48000)) {
            for (i in 0 until DspConfig.BAND_COUNT) {
                val f = DspConfig.BAND_FREQUENCIES[i]
                if (f > rate * 0.4f) continue
                for (g in floatArrayOf(-12f, -6f, 6f, 12f)) {
                    val b = Biquad(1)
                    b.setPeaking(rate, f, g, 1f)
                    assertEquals("$rate Гц, полоса $f, $g дБ", g, b.magnitudeDb(rate, f), 0.05f)
                }
            }
        }
    }

    @Test fun `band above nyquist stays stable instead of producing NaN`() {
        // 16 кГц при 22.05 кГц потока — то, на чём наивная реализация отдаёт NaN.
        val b = Biquad(1)
        b.setPeaking(22050, 16000f, 12f, 1f)
        var v = 0f
        for (i in 0 until 4096) v = b.process(0, sin(i * 0.1).toFloat())
        assertFalse(v.isNaN())
        assertTrue(abs(v) < 100f)
    }

    @Test fun `zero gain band is a true bypass`() {
        val b = Biquad(1)
        b.setPeaking(sr, 1000f, 0f, 1f)
        assertEquals(0.5f, b.process(0, 0.5f), 1e-6f)
        assertEquals(-0.25f, b.process(0, -0.25f), 1e-6f)
    }

    // ---------------------------------------------------------------- движок

    @Test fun `neutral config does not change a single sample`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(DspConfig(enabled = true))
        val input = noise(4096)
        val work = input.copyOf()
        engine.process(work, 2048)
        for (i in work.indices) assertEquals(input[i], work[i], 1e-6f)
    }

    @Test fun `everything at maximum never leaves the valid range and never produces NaN`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(
            DspConfig(
                enabled = true, preampDb = 6f, bandsDb = List(DspConfig.BAND_COUNT) { 12f },
                bandQ = 4f, bassDrive = 1f, air = 1f, width = 1f, underwater = 1f,
                rotation = 1f, reverbMix = 1f, reverbSize = 1f, reverbDamp = 0f, drive = 1f
            )
        )
        val work = noise(sr, amp = 0.9f)
        val processed = sr / 2
        engine.process(work, processed)
        for (v in work.copyOfRange(0, processed * 2)) {
            assertFalse("NaN в буфере", v.isNaN())
            assertFalse("бесконечность в буфере", v.isInfinite())
            assertTrue("выход за пределы: $v", v >= -1.0001f && v <= 1.0001f)
        }
    }

    @Test fun `bass boost actually raises low frequencies and leaves the top alone`() {
        fun level(freq: Float, config: DspConfig): Float {
            val engine = DspEngine(sr, 2)
            engine.setConfig(config)
            val buf = tone(sr, freq, 0.3f)
            engine.process(buf, sr / 2)
            return rms(buf, sr / 2) // вторую половину, когда сглаживание уже доехало
        }
        val flat = DspConfig(enabled = true)
        val boosted = flat.copy(bandsDb = listOf(10f, 10f, 6f, 0f, 0f, 0f, 0f, 0f, 0f, 0f))
        val lowFlat = level(60f, flat)
        val lowBoost = level(60f, boosted)
        val highFlat = level(6000f, flat)
        val highBoost = level(6000f, boosted)
        assertTrue("низ должен вырасти: $lowFlat -> $lowBoost", lowBoost > lowFlat * 2.5f)
        assertEquals("верх трогать не должно", highFlat, highBoost, highFlat * 0.05f)
    }

    @Test fun `limiter keeps the output under the ceiling on an absurd input`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(DspConfig(enabled = true, preampDb = 6f, limiter = true))
        val work = FloatArray(sr * 2) { if (it % 2 == 0) 8f else -8f }
        engine.process(work, sr)
        for (v in work) assertTrue("пик $v", abs(v) <= 1.0f)
    }

    @Test fun `reverb tail decays instead of ringing forever`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(DspConfig(enabled = true, reverbMix = 1f, reverbSize = 1f, reverbDamp = 0f))
        // Импульс, дальше тишина: если хвост не затухает — самовозбуждение.
        val work = FloatArray(sr * 12 * 2)
        work[0] = 1f; work[1] = 1f
        engine.process(work, sr * 12)
        val early = rms(work.copyOfRange(0, sr * 2))
        val late = rms(work.copyOfRange(sr * 20, sr * 24))
        assertTrue("ранний хвост должен быть слышен", early > 1e-5f)
        assertTrue("поздний хвост должен быть тише раннего: $early -> $late", late < early * 0.2f)
    }

    @Test fun `mono width collapses the stereo difference`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(DspConfig(enabled = true, width = -1f))
        val work = FloatArray(sr * 2)
        for (i in 0 until sr) { work[i * 2] = 0.4f; work[i * 2 + 1] = -0.4f }
        engine.process(work, sr)
        // Хвост буфера: сглаживание ширины уже доехало до -1.
        for (i in sr - 100 until sr) {
            assertEquals(work[i * 2], work[i * 2 + 1], 1e-3f)
        }
    }

    @Test fun `mono track survives every stereo module`() {
        val engine = DspEngine(sr, 1)
        engine.setConfig(DspConfig(enabled = true, rotation = 1f, width = 1f, reverbMix = 0.5f))
        val work = FloatArray(sr) { (0.3 * sin(it * 0.05)).toFloat() }
        engine.process(work, sr)
        for (v in work) assertFalse(v.isNaN())
    }

    @Test fun `parameter change is smoothed and not applied as a jump`() {
        val engine = DspEngine(sr, 2)
        engine.setConfig(DspConfig(enabled = true))
        val warm = tone(1024, 1000f)
        engine.process(warm, 512)
        // Резкий скачок: -12 дБ по всем полосам сразу.
        engine.setConfig(DspConfig(enabled = true, preampDb = -12f))
        val work = tone(64, 1000f, 0.5f)
        engine.process(work, 64)
        // За первые 64 сэмпла (1.3 мс) уровень не может упасть до цели: это и был бы щелчок.
        assertTrue("сглаживание не работает", abs(work[0]) > 0.0f)
        assertTrue(rms(work) > 0.2f)
    }

    // ---------------------------------------------------------------- конфиг и кодек

    @Test fun `codec survives a full round trip`() {
        val original = DspConfig(
            enabled = true, preampDb = -3.5f, bandsDb = listOf(1f, -2f, 3f, -4f, 5f, -6f, 7f, -8f, 9f, -10f),
            bandQ = 2.5f, bassDrive = 0.33f, air = 0.5f, width = -0.75f, underwater = 0.62f,
            rotation = 0.85f, rotationHz = 0.07f, reverbMix = 0.45f, reverbSize = 0.9f,
            reverbDamp = 0.15f, drive = 0.2f, limiter = false
        )
        val decoded = DspCodec.decode(DspCodec.encode(original))
        assertEquals(original.sanitized(), decoded)
    }

    @Test fun `codec never throws on garbage`() {
        for (bad in listOf("", "   ", "v1|", "мусор", "v1|bands=;q=abc", "v9|on=1;bands=1,2,x", "=;=;=")) {
            val c = DspCodec.decode(bad)
            assertEquals(DspConfig.BAND_COUNT, c.bandsDb.size)
            assertFalse(c.preampDb.isNaN())
        }
        assertEquals(DspConfig.NEUTRAL, DspCodec.decode(null))
    }

    @Test fun `codec is locale independent`() {
        // Ловушка: String.format("%.2f") в русской локали пишет "0,55", и такая строка
        // не читается обратно. Кодек обязан быть независим от локали.
        val previous = java.util.Locale.getDefault()
        try {
            java.util.Locale.setDefault(java.util.Locale.forLanguageTag("ru-RU"))
            val c = DspConfig(enabled = true, reverbMix = 0.55f, preampDb = -1.25f)
            assertEquals(0.55f, DspCodec.decode(DspCodec.encode(c)).reverbMix, 1e-4f)
        } finally {
            java.util.Locale.setDefault(previous)
        }
    }

    @Test fun `sanitize repairs NaN infinity and a short band list`() {
        val broken = DspConfig(
            enabled = true, preampDb = Float.NaN, bandsDb = listOf(100f, Float.POSITIVE_INFINITY),
            bandQ = -5f, reverbMix = 42f, width = -9f
        ).sanitized()
        assertEquals(DspConfig.BAND_COUNT, broken.bandsDb.size)
        assertEquals(0f, broken.preampDb, 0f)
        assertEquals(12f, broken.bandsDb[0], 0f)
        assertEquals(0f, broken.bandsDb[1], 0f)
        assertEquals(1f, broken.reverbMix, 0f)
        assertEquals(-1f, broken.width, 0f)
        assertTrue(broken.bandQ >= 0.5f)
    }

    @Test fun `neutral detection is about the result not the flag`() {
        assertTrue(DspConfig(enabled = true).isNeutral)
        assertTrue(DspConfig(enabled = false, reverbMix = 1f).isNeutral)
        assertFalse(DspConfig(enabled = true, reverbMix = 0.1f).isNeutral)
        assertFalse(DspConfig(enabled = true, bandsDb = listOf(1f) + List(9) { 0f }).isNeutral)
    }

    @Test fun `legacy per-track reverb percent is carried over not dropped`() {
        val migrated = DspConfig().withLegacyReverb(100)
        assertTrue(migrated.enabled)
        assertTrue(migrated.reverbMix > 0.5f)
        assertEquals(DspConfig.NEUTRAL, DspConfig().withLegacyReverb(0))
    }

    @Test fun `every preset produces a valid and audible configuration`() {
        for (preset in DspPresets.all) {
            val c = preset.transform(DspConfig()).sanitized()
            assertEquals(preset.name, DspConfig.BAND_COUNT, c.bandsDb.size)
            for (v in c.bandsDb) assertTrue(preset.name, v >= -12f && v <= 12f)
            val engine = DspEngine(sr, 2)
            engine.setConfig(c)
            val work = noise(4096, 0.6f)
            engine.process(work, 2048)
            for (v in work) assertFalse(preset.name + ": NaN", v.isNaN())
        }
    }
}
