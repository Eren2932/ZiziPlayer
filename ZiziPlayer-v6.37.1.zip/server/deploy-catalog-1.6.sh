#!/usr/bin/env bash
# Выкатка zizi_catalog 1.6. Запускать НА СЕРВЕРЕ, из папки, куда положен zizi_catalog.py.
set -euo pipefail
DEST=${DEST:-/opt/zizi}
SRC=${1:-./zizi_catalog.py}

[ -f "$SRC" ] || { echo "нет файла $SRC"; exit 1; }
python3 -c "import ast,sys;ast.parse(open(sys.argv[1],encoding='utf-8').read())" "$SRC"

ts=$(date +%Y%m%d-%H%M%S)
[ -f "$DEST/zizi_catalog.py" ] && cp "$DEST/zizi_catalog.py" "$DEST/zizi_catalog.py.bak-$ts" && echo "бэкап: zizi_catalog.py.bak-$ts"
install -m 644 "$SRC" "$DEST/zizi_catalog.py"
mkdir -p "$DEST/img"

# Модуль подключается к FastAPI одной строкой. Если её нет — 1.6 не заработает молча.
if ! grep -q "catalog_router" "$DEST/zizi_resolver.py" 2>/dev/null; then
  echo "ВНИМАНИЕ: в zizi_resolver.py не найдено include_router(catalog_router)."
  echo "Добавьте:  from zizi_catalog import router as catalog_router"
  echo "           app.include_router(catalog_router)"
fi

systemctl restart zizi-resolver
sleep 2
echo -n "health: "; curl -s http://127.0.0.1:8080/catalog/health; echo
