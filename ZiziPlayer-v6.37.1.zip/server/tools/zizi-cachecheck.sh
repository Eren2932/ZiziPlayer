#!/usr/bin/env bash
# Проверка склада (ZiziResolve 1.5). Ничего не меняет, только мерит.
#
#   bash zizi-cachecheck.sh ID_ТРЕКА
#
# Что должно получиться на исправном сервере:
#   холодный /stream  — быстрее 5 с на трек 3-4 МБ и заметно больше 500 КБ/с
#   тёплый /stream    — сотни МБ/с (это чтение с диска, сети в нём нет вообще)
#   x-zizi-source     — disk или disk-filling; passthrough означает, что склад не сработал
set -u
ID="${1:?дай id трека, 11 символов}"
set -a; . /opt/zizi/zizi.env; set +a
H="Authorization: Bearer ${ZIZI_TOKEN:-}"
J(){ command -v jq >/dev/null && jq "$@" || cat; }

echo "== версия и политика"
curl -s localhost:8080/health | J '{version, disk_cache, audio_dir, quota_mb, fetch_chunk_kb, fetch_workers, prefetch_bytes, pot}'

echo "== склад до"
curl -s -H "$H" localhost:8080/cache | J '{files, bytes, used_pct, last_fetch_kbs}'

echo "== выбрасываем трек из склада, чтобы замер был честно холодным"
rm -f /opt/zizi/audio/"$ID".* 2>/dev/null
curl -s -H "$H" "localhost:8080/flush?neg_only=1" >/dev/null

for pass in холодный тёплый; do
  echo "== $pass /stream"
  curl -s -o /dev/null -D /tmp/zizi-h.$$ \
    -w "  код %{http_code}  скорость %{speed_download} Б/с  байт %{size_download}  ttfb %{time_starttransfer}s  всего %{time_total}s\n" \
    -H "$H" "localhost:8080/stream?id=$ID"
  awk 'BEGIN{IGNORECASE=1} /^x-zizi-|^content-length|^accept-ranges/ {print "  "$0}' /tmp/zizi-h.$$ | tr -d '\r'
  rm -f /tmp/zizi-h.$$
done

echo "== перемотка: Range на середину"
curl -s -o /dev/null -w "  код %{http_code}  байт %{size_download}  всего %{time_total}s\n" \
  -H "$H" -H "Range: bytes=1000000-1262143" "localhost:8080/stream?id=$ID"

echo "== склад после"
curl -s -H "$H" localhost:8080/cache | J '{files, bytes, used_pct, last_fetch_kbs, filling}'
echo "== что в логе про этот трек"
journalctl -u zizi-resolver --since "-5min" --no-pager | grep -E "cached|cache |stream" | tail -5
