#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zizi-doctor-183.py — ответ на один вопрос: НАС УБИЛИ ИЛИ МЫ САМИ СЛОМАЛИСЬ.

Скрипт НИЧЕГО не чинит и ничего не меняет на сервере. Он гоняет yt-dlp
по нашей лестнице клиентов из ZIZI_CLIENTS и отдельно проверяет, что
googlevideo вообще отдаёт байты. Три исхода различаются по-разному лечатся:

  A. РЕЗОЛВ ПАДАЕТ У ВСЕХ КЛИЕНТОВ, текст вида
     "Requested format is not available" / "only images are available" /
     "player response ... SABR"
        → YouTube снял с наших клиентов аудио-онли с прямым URL.
          Лечение: свежий yt-dlp + другая лестница + PO token, НЕ переезд.

  B. РЕЗОЛВ ПАДАЕТ с "Sign in to confirm you're not a bot" / 429
        → прижали наш IP, а не наш код.
          Лечение: cookies живого аккаунта и/или другой выходной адрес.

  C. РЕЗОЛВ ПРОХОДИТ, А ЗА БАЙТАМИ 403
        → URL живой, но выдан не тому, кто за ним пришёл: разошлись
          User-Agent/заголовки/адрес, либо URL требует PO token.
          Лечение: тянуть байты ровно теми заголовками, что вернул клиент.

Запуск на сервере (под тем же пользователем, что и сервис!):
    python3 zizi-doctor-183.py                       # возьмёт видео по умолчанию
    python3 zizi-doctor-183.py dQw4w9WgXcQ VIDEO_ID2 # свои id
    ZIZI_CLIENTS=ios_music,tv,web_safari python3 zizi-doctor-183.py

Важно: под тем же пользователем — иначе не увидишь его кэш, cookies и его IP.
"""

import json
import os
import shutil
import subprocess
import sys

CLIENTS = [c.strip() for c in os.environ.get(
    "ZIZI_CLIENTS", "ios_music,ios,tv,web_safari,visionos,web_music").split(",") if c.strip()]
VIDEOS = sys.argv[1:] or ["dQw4w9WgXcQ"]
YTDLP = os.environ.get("ZIZI_YTDLP", "yt-dlp")
COOKIES = os.environ.get("ZIZI_COOKIES", "")          # путь к cookies.txt, если есть
# Тракт держится на VLESS-узле: проверять надо ТОТ ЖЕ выход, которым ходит сервис,
# иначе доктор скажет «всё хорошо» из прямого канала, а сервис будет ходить через труп.
PROXY = os.environ.get("ZIZI_PROXY", "")              # напр. socks5h://127.0.0.1:1080
TIMEOUT = int(os.environ.get("ZIZI_DOCTOR_TIMEOUT", "45"))


def sh(cmd, timeout=TIMEOUT):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "TIMEOUT после %ss" % timeout
    except FileNotFoundError as e:
        return -2, "", str(e)


def verdict(err):
    e = err.lower()
    if "sign in to confirm" in e or "not a bot" in e or "http error 429" in e:
        return "B: прижали IP (бот-чек/429)"
    if "sabr" in e or "only images are available" in e or "requested format is not available" in e:
        return "A: клиент больше не отдаёт аудио-онли (SABR/формат)"
    if "http error 403" in e:
        return "C: 403 уже на резолве"
    if "unable to extract" in e or "nsig" in e or "signature" in e:
        return "A': сломана распаковка плеера — почти всегда лечится обновлением yt-dlp"
    return "?: см. текст ошибки"


def probe(vid, client):
    cmd = [YTDLP, "--no-warnings", "--no-playlist", "-f", "bestaudio[acodec!=none]",
           "--extractor-args", "youtube:player_client=%s" % client,
           "-J", "https://www.youtube.com/watch?v=%s" % vid]
    if COOKIES:
        cmd[1:1] = ["--cookies", COOKIES]
    if PROXY:
        cmd[1:1] = ["--proxy", PROXY]
    rc, out, err = sh(cmd)
    if rc != 0 or not out.strip():
        return {"client": client, "ok": False, "why": verdict(err),
                "err": (err.strip().splitlines() or [""])[-1][:200]}
    info = json.loads(out)
    fmts = [f for f in info.get("formats", [])
            if f.get("acodec") not in (None, "none") and f.get("vcodec") in ("none", None)
            and f.get("url")]
    if not fmts:
        return {"client": client, "ok": False, "why": "A: аудио-онли с URL нет (SABR)",
                "err": "форматов с прямым url: 0"}
    f = sorted(fmts, key=lambda x: x.get("abr") or 0)[-1]
    # проверка «дают ли байты» — ровно теми заголовками, что вернул клиент
    hdr = []
    for k, v in (f.get("http_headers") or {}).items():
        hdr += ["-H", "%s: %s" % (k, v)]
    ccmd = ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code} %{size_download}",
            "-r", "0-65535", *hdr, f["url"]]
    if PROXY:
        ccmd[1:1] = ["-x", PROXY]
    rc2, out2, err2 = sh(ccmd, timeout=30)
    code = (out2 or "000 0").split()[0]
    return {"client": client, "ok": code.startswith("2"), "itag": f.get("format_id"),
            "abr": f.get("abr"), "byte_code": code, "bytes": (out2 or "").split()[-1],
            "why": "" if code.startswith("2") else "C: резолв прошёл, за байтами %s" % code}


print("yt-dlp:", (sh([YTDLP, "--version"])[1] or "НЕ НАЙДЕН").strip(),
      "| curl:", "есть" if shutil.which("curl") else "НЕТ",
      "| cookies:", COOKIES or "нет")
print("лестница:", ",".join(CLIENTS), "| прокси:", PROXY or "нет (прямой выход!)")
# GL — единственный честный критерий живости узла: что о нас думает САМ youtube.com
_g = ["curl", "-s", "--max-time", "20", "https://www.youtube.com/"]
if PROXY:
    _g[1:1] = ["-x", PROXY]
_rc, _out, _ = sh(_g, timeout=25)
import re as _re
_m = _re.search(r'"countryCode":"([A-Z]{2})"|"gl":"([A-Z]{2})"', _out or "")
print("YouTube видит нас как GL =", (_m.group(1) or _m.group(2)) if _m else "не определился",
      "(RU здесь = узел умер или подменился)")
for vid in VIDEOS:
    print("\n=== %s ===" % vid)
    for c in CLIENTS:
        r = probe(vid, c)
        mark = "OK " if r["ok"] else "FAIL"
        line = "  %-12s %s" % (c, mark)
        if r["ok"]:
            line += "  itag=%s abr=%s байты=%s (%s)" % (
                r.get("itag"), r.get("abr"), r.get("byte_code"), r.get("bytes"))
        else:
            line += "  %s\n               %s" % (r.get("why"), r.get("err", ""))
        print(line)
print("\nЕсли ВЕЗДЕ A — обновляй yt-dlp и пробуй новую лестницу, это не повод переезжать.")
print("Если ВЕЗДЕ B — дело в адресе/аккаунте, код цел.")
print("Если C — байты режут по заголовкам/токену, чинится в _open_range, а не в резолве.")
