#!/usr/bin/env python3
"""Замер v2: чем именно душит googlevideo. Запуск на сервере:

    /opt/zizi/venv/bin/python zizi-speedcheck2.py pgN-vvVVxMA

Почему v2 существует: в v1 я не печатал HTTP-код на ноге A, и «0 Б/с за 0,06 с»
выглядело как «моментально». Это был не успех, это был отказ. Здесь код печатается
всегда, а байты считаются вручную, а не берутся из статистики curl.

Ничего не меняет. Ссылку и токен не печатает.
"""
import asyncio, os, sys, time, json

sys.path.insert(0, "/opt/zizi")
import httpx  # из venv резолвера

ID = sys.argv[1] if len(sys.argv) > 1 else sys.exit("дай 11-символьный id")
ENV = {}
for line in open("/opt/zizi/zizi.env"):
    if "=" in line and not line.strip().startswith("#"):
        k, v = line.strip().split("=", 1)
        ENV[k] = v
TOKEN = ENV.get("ZIZI_TOKEN", "")
PROXY = ENV.get("ZIZI_PROXY", "") or None
TARGET = 2 * 1024 * 1024   # сколько байт хотим получить в каждом тесте
MB = 1024 * 1024


def mbs(n, sec):
    return f"{n/1024/max(sec,1e-6):8.1f} КБ/с" + (f" ({n/1024/1024:.2f} МБ за {sec:.2f} с)")


async def fresh_url():
    """Берём СВЕЖУЮ ссылку: старая из кэша могла истечь — именно этим и объясняется
    ноль байт в v1, пока /stream рядом работал (он умеет перерезолвить на 403)."""
    async with httpx.AsyncClient(timeout=30) as c:
        await c.get(f"http://127.0.0.1:8080/flush?neg_only=0",
                    headers={"Authorization": f"Bearer {TOKEN}"})
        r = await c.get(f"http://127.0.0.1:8080/resolve?id={ID}",
                        headers={"Authorization": f"Bearer {TOKEN}"})
        r.raise_for_status()
        d = r.json()
    print(f"резолв: via={d.get('via')} itag/mime={d.get('mime')} abr={d.get('abr')} "
          f"clen={d.get('filesize')}")
    return d["url"], d.get("via") == "proxy"


def client(via_proxy):
    kw = {"timeout": httpx.Timeout(30.0, read=30.0), "follow_redirects": True}
    if via_proxy and PROXY:
        kw["proxy"] = PROXY
    return httpx.AsyncClient(**kw)


async def t_stream_no_range(url, via):
    """Ровно то, что делает /stream сегодня: один GET без Range, читаем до TARGET."""
    async with client(via) as c:
        t0 = time.time(); got = 0; code = None
        async with c.stream("GET", url) as r:
            code = r.status_code
            if code >= 400:
                return f"HTTP {code} — байтов нет"
            async for chunk in r.aiter_bytes(256 * 1024):
                got += len(chunk)
                if got >= TARGET:
                    break
        return f"HTTP {code}  " + mbs(got, time.time() - t0)


async def t_single_range(url, via, size=MB):
    async with client(via) as c:
        t0 = time.time()
        r = await c.get(url, headers={"Range": f"bytes=0-{size-1}"})
        if r.status_code >= 400:
            return f"HTTP {r.status_code} — байтов нет"
        return f"HTTP {r.status_code}  " + mbs(len(r.content), time.time() - t0)


async def t_parallel_ranges(url, via, workers=4, chunk=512 * 1024):
    async with client(via) as c:
        async def one(i):
            a = i * chunk; b = a + chunk - 1
            r = await c.get(url, headers={"Range": f"bytes={a}-{b}"})
            return r.status_code, len(r.content)
        t0 = time.time()
        res = await asyncio.gather(*[one(i) for i in range(workers)],
                                   return_exceptions=True)
        sec = time.time() - t0
        ok = [x for x in res if isinstance(x, tuple) and x[0] < 400]
        got = sum(x[1] for x in ok)
        codes = sorted({x[0] for x in res if isinstance(x, tuple)})
        bad = [repr(x)[:60] for x in res if not isinstance(x, tuple)]
        return (f"HTTP {codes} ok={len(ok)}/{workers}  " + mbs(got, sec)
                + ("  ошибки: " + "; ".join(bad) if bad else ""))


async def t_sequential_ranges(url, via, n=8, chunk=256 * 1024):
    async with client(via) as c:
        t0 = time.time(); got = 0; codes = set()
        for i in range(n):
            a = i * chunk; b = a + chunk - 1
            r = await c.get(url, headers={"Range": f"bytes={a}-{b}"})
            codes.add(r.status_code)
            if r.status_code >= 400:
                break
            got += len(r.content)
        return f"HTTP {sorted(codes)}  " + mbs(got, time.time() - t0)


async def main():
    url, via = await fresh_url()
    print(f"маршрут теста: {'proxy' if via else 'direct'}\n")
    tests = [
        ("1. один GET без Range (как /stream сейчас)", t_stream_no_range),
        ("2. один Range 0-1 МБ                      ", t_single_range),
        ("3. 4 × Range 512 КБ параллельно           ", t_parallel_ranges),
        ("4. 8 × Range 256 КБ последовательно       ", t_sequential_ranges),
    ]
    for name, fn in tests:
        try:
            print(f"{name}: {await fn(url, via)}")
        except Exception as e:
            print(f"{name}: ИСКЛЮЧЕНИЕ {type(e).__name__}: {e}")
        await asyncio.sleep(1)
    print("\nЧитать так: если тест 3 даёт в разы больше КБ/с, чем тест 1 —")
    print("душат соединение, и параллельный загрузчик на диск решает задачу.")
    print("Если 1, 2, 3, 4 примерно равны — душат сессию/IP, и тогда план другой.")


asyncio.run(main())
