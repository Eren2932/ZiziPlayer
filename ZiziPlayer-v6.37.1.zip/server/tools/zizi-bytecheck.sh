#!/usr/bin/env bash
# ZiziPlayer: правда о байтах, которые получает телефон.
#
# Отвечает ровно на три вопроса и ничего не меняет:
#   1. совпадает ли размер, который обещает yt-dlp, с настоящим clen у Google;
#   2. совпадает ли обещанный нами content-length с числом реально отданных байт;
#   3. валидный ли это аудиофайл (и какая у него длительность).
#
#   bash zizi-bytecheck.sh ID_ТРЕКА
set -u
ID="${1:?использование: bash zizi-bytecheck.sh ID_ТРЕКА}"
set -a; . /opt/zizi/zizi.env; set +a
H="Authorization: Bearer ${ZIZI_TOKEN:-}"
B=localhost:8080
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

echo "== 0. версия сервиса"
curl -s $B/health | jq -r '"version=\(.version) disk_cache=\(.disk_cache) chunk_kb=\(.fetch_chunk_kb) workers=\(.fetch_workers)"'

echo
echo "== 1. размер: обещание yt-dlp против clen самого Google"
curl -s -H "$H" "$B/resolve?id=$ID" > "$TMP/r.json" || { echo "resolve не ответил"; exit 1; }
jq -e . "$TMP/r.json" >/dev/null 2>&1 || { echo "resolve отдал не JSON:"; head -c 300 "$TMP/r.json"; exit 1; }
FS=$(jq -r '.filesize // 0' "$TMP/r.json")
URL=$(jq -r '.url // ""' "$TMP/r.json")
MIME=$(jq -r '.mime // "?"' "$TMP/r.json")
CLEN=$(printf '%s' "$URL" | grep -oP '(?<=[?&])clen=\K[0-9]+' || true)
echo "  mime=$MIME  filesize(yt-dlp)=$FS  clen(URL)=${CLEN:-НЕТ}"
if [ -n "${CLEN:-}" ] && [ "$FS" != "0" ]; then
  if [ "$CLEN" = "$FS" ]; then echo "  ВЕРДИКТ: размер точный, совпадает."
  else echo "  ВЕРДИКТ: РАСХОЖДЕНИЕ $((FS - CLEN)) байт — yt-dlp дал ОЦЕНКУ (filesize_approx)."; fi
fi

echo
echo "== 2. что реально отдаёт /stream (полная закачка с диска сервера)"
# первый прогон греет кэш, второй меряем — как это видит телефон на втором нажатии
curl -s -o /dev/null -H "$H" "$B/stream?id=$ID"
curl -s -D "$TMP/hdr" -o "$TMP/body" -w '  время=%{time_total}s скорость=%{speed_download} Б/с код=%{http_code}\n' \
     -H "$H" "$B/stream?id=$ID"
echo "  --- заголовки ответа ---"
grep -iE '^(HTTP/|content-length|content-type|content-range|transfer-encoding|accept-ranges|x-zizi)' "$TMP/hdr" | sed 's/^/  /'
CL=$(grep -i '^content-length:' "$TMP/hdr" | tail -1 | tr -dc '0-9' || true)
GOT=$(stat -c %s "$TMP/body")
echo "  обещано content-length=${CL:-НЕТ}   получено байт=$GOT"
if [ -n "${CL:-}" ] && [ "$CL" != "$GOT" ]; then
  echo "  ВЕРДИКТ: ТЕЛО КОРОЧЕ ОБЕЩАНИЯ на $((CL - GOT)) байт. Для ExoPlayer это битый ресурс."
else
  echo "  ВЕРДИКТ: тело равно обещанию — на этом уровне ответ честный."
fi
if grep -qi '^transfer-encoding: *chunked' "$TMP/hdr"; then
  echo "  ВНИМАНИЕ: ответ пошёл chunked, content-length не выставился."
fi

echo
echo "== 3. это вообще играбельный файл?"
file -b "$TMP/body" | sed 's/^/  /'
if command -v ffprobe >/dev/null 2>&1; then
  ffprobe -v error -show_entries format=duration,format_name,size -of default=nw=1 "$TMP/body" | sed 's/^/  /'
else
  echo "  ffprobe нет (apt install -y ffmpeg — только для этой проверки, сервису он не нужен)"
fi
echo "  ожидаемая длительность по резолву: $(jq -r '.duration // "?"' "$TMP/r.json") с"

echo
echo "== 4. телефон приходил за этим треком сколько раз? (цикл повторов = >2)"
journalctl -u zizi-resolver --since "-2h" --no-pager 2>/dev/null \
  | grep -c "GET /stream?id=$ID" | sed 's/^/  запросов \/stream за 2 ч: /'
echo "  топ треков по числу запросов /stream за 2 ч:"
journalctl -u zizi-resolver --since "-2h" --no-pager 2>/dev/null \
  | grep -oP 'GET /stream\?id=\K[A-Za-z0-9_-]{11}' | sort | uniq -c | sort -rn | head -5 | sed 's/^/    /'

echo
echo "== 5. ошибки закачки на диск за 2 ч (short chunk / incomplete / size unknown)"
journalctl -u zizi-resolver --since "-2h" --no-pager 2>/dev/null \
  | grep -E 'short chunk|incomplete|size unknown|диск отказал|size .*CDN отдаёт' | tail -10 | cut -c1-200 | sed 's/^/  /'
echo "(пусто = таких ошибок не было)"
