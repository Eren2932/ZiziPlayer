#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ZiziResolve 1.5 → 1.5.1. Одна болезнь: РАЗМЕР ФАЙЛА БРАЛСЯ НА ВЕРУ.

    "filesize": fmt.get("filesize") or fmt.get("filesize_approx")

filesize_approx — это не размер, это abr × duration / 8, то есть оценка. Дальше 1.5
делала на её основе три необратимые вещи:

  1. ftruncate .part ровно на этот размер и нарезка Range по нему;
  2. content-length: str(end - start + 1) в ответе плееру — то есть ОБЕЩАНИЕ;
  3. последний кусок просился как bytes=X-(approx-1). Если approx больше настоящего clen,
     CDN отдаёт меньше, чем want → "short chunk" → dl.error уже ПОСЛЕ того, как ответ
     с обещанным content-length ушёл в сеть. Плеер получает тело короче обещанного.

Для ExoPlayer это не "медленно", а битый ресурс: таймлайн не готовится, длительность
остаётся неизвестной (-0:00), позиция стоит на 0:00, а байты при этом честно летят.
И запись об этом ложится в CacheDataSource на телефоне вместе с неверной длиной.

Лечение: размер всегда подтверждается у самого CDN (Content-Range на запрос двух байт),
и /stream не отвечает, пока размер не подтверждён. Обещание content-length перестаёт
быть догадкой. Один лишний запрос на два байта на трек — это единицы миллисекунд.

Идемпотентно, делает бэкап, проверяет результат через ast.parse и сам откатывается.

    python3 zizi-hotfix-1.5.1.py /opt/zizi/zizi_resolver.py
"""
import ast
import os
import shutil
import sys

PATCHES = [
    # 1. новое поле в __slots__
    ('__slots__ = ("video_id", "size", "path", "part", "prefix", "done", "error",\n'
     '                 "waiters", "started", "finished", "task", "ext")',
     '__slots__ = ("video_id", "size", "path", "part", "prefix", "done", "error",\n'
     '                 "waiters", "started", "finished", "task", "ext", "size_ok")'),

    # 2. инициализация
    ('        self.size = size                 # 0 = ещё не знаем, узнаём из Content-Range',
     '        self.size = size                 # 0 = ещё не знаем, узнаём из Content-Range\n'
     '        self.size_ok = False             # 1.5.1: размер ПОДТВЕРЖДЁН самим CDN, не yt-dlp'),

    # 3. размер подтверждаем у CDN всегда
    ('        if dl.size <= 0:\n'
     '            dl.size = await _probe_size(dl.video_id, box)\n'
     '            _notify(dl)\n'
     '        if dl.size <= 0:\n'
     '            dl.error = "size unknown"\n'
     '            _notify(dl)\n'
     '            return',
     '        # 1.5.1: размер спрашиваем у CDN ВСЕГДА, а не только когда yt-dlp промолчал.\n'
     '        # yt-dlp отдаёт filesize_approx (оценка по битрейту) там, где точного clen нет,\n'
     '        # и на этой оценке строились и нарезка Range, и обещанный content-length.\n'
     '        real = await _probe_size(dl.video_id, box)\n'
     '        if real > 0:\n'
     '            if dl.size > 0 and real != dl.size:\n'
     '                log.warning("size %s: yt-dlp обещал %d, CDN отдаёт %d (разница %+d) "\n'
     '                            "— верим CDN", dl.video_id, dl.size, real, real - dl.size)\n'
     '            dl.size = real\n'
     '            dl.size_ok = True\n'
     '        elif dl.size > 0:\n'
     '            # Проба не прошла, но оценка есть. Идём с ней, только честно скажем об этом:\n'
     '            # тело может оказаться короче обещанного content-length.\n'
     '            log.warning("size %s: проба размера не удалась, иду с оценкой %d",\n'
     '                        dl.video_id, dl.size)\n'
     '        _notify(dl)\n'
     '        if dl.size <= 0:\n'
     '            dl.error = "size unknown"\n'
     '            _notify(dl)\n'
     '            return'),

    # 4. /stream ждёт ПОДТВЕРЖДЁННЫЙ размер, иначе обещание — догадка
    ('            while dl.size <= 0 and dl.error is None and time.time() - t0 < 20.0:',
     '            while (dl.size <= 0 or not (dl.size_ok or dl.done)) \\\n'
     '                    and dl.error is None and time.time() - t0 < 20.0:'),

    # 5. готовый файл на диске: его размер и есть правда
    ('                dl.prefix = st.st_size\n'
     '                dl.done = True',
     '                dl.prefix = st.st_size\n'
     '                dl.size_ok = True\n'
     '                dl.done = True'),

    # 6. версия
    ('return {"ok": True, "version": "1.5",',
     'return {"ok": True, "version": "1.5.1",'),
]


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else "/opt/zizi/zizi_resolver.py"
    if not os.path.exists(path):
        print("нет файла: %s" % path)
        return 2
    src = open(path, encoding="utf-8").read()

    if '"size_ok"' in src and '"version": "1.5.1"' in src:
        print("уже 1.5.1, делать нечего")
        return 0

    out = src
    applied, skipped = [], []
    for i, (old, new) in enumerate(PATCHES, 1):
        if new in out:
            skipped.append(i)
            continue
        if old not in out:
            print("ОТКАЗ: якорь %d не найден. Файл не 1.5 или уже правился руками." % i)
            return 3
        if out.count(old) != 1:
            print("ОТКАЗ: якорь %d встречается %d раз." % (i, out.count(old)))
            return 3
        out = out.replace(old, new, 1)
        applied.append(i)

    try:
        ast.parse(out)
    except SyntaxError as e:
        print("ОТКАЗ: результат не парсится (%s). Файл не тронут." % e)
        return 4

    backup = path + ".bak-1.5"
    shutil.copy2(path, backup)
    open(path, "w", encoding="utf-8").write(out)
    try:
        ast.parse(open(path, encoding="utf-8").read())
    except SyntaxError:
        shutil.copy2(backup, path)
        print("ОТКАЗ: файл на диске не парсится, откатил из %s" % backup)
        return 5

    print("готово: применено %s, пропущено (уже было) %s" % (applied or "—", skipped or "—"))
    print("бэкап:  %s" % backup)
    print("дальше: systemctl restart zizi-resolver")
    return 0


if __name__ == "__main__":
    sys.exit(main())
