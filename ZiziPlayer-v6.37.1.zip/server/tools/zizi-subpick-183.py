#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zizi-subpick-183.py — выбрать узел из НОВОЙ подписки и накатить его в рабочий xray.

ЗАЧЕМ ОТДЕЛЬНЫЙ СКРИПТ, ЕСЛИ ЕСТЬ zizi-geoscan.py.
Старый geoscan умеет ровно одно: читать строки `vless://...`. Новая подписка
отдаёт СОВСЕМ ДРУГОЕ — JSON-массив готовых конфигов xray (39 штук, у каждого
свой outbound с тегом "proxy"). geoscan на ней молча найдёт ноль узлов. Этот
скрипт понимает оба формата.

КРИТЕРИЙ ОТБОРА — ТОЛЬКО GL ОТ САМОГО YOUTUBE (доказано в STATUS.md 2.7:
14 узлов из 15 показывали ipinfo=EU/US и при этом GL=RU). Никаким «страна в
названии узла» верить нельзя: половина узлов в подписке идёт «через РФ», и
что Google увидит на выходе — заранее не знает никто.

БЕЗОПАСНОСТЬ: рабочий xray на 1080 при сканировании НЕ трогается. Пробный
процесс поднимается на 127.0.0.1:10801 с конфигом в /tmp и убивается после
каждой проверки. Изменения вносятся только по явному --apply, с бэкапом.

ИСПОЛЬЗОВАНИЕ:
    # 1. забрать подписку (ссылка приватная — НЕ КОММИТИТЬ в публичный репозиторий!)
    curl -fsSL 'https://sub.accessbyme.com/sub/ТВОЙ_ID?fmt=best' -o /root/sub.json
    chmod 600 /root/sub.json

    # 2. посмотреть, что вообще в подписке
    python3 zizi-subpick-183.py --sub /root/sub.json --list

    # 3. прогнать все узлы и увидеть GL глазами YouTube
    python3 zizi-subpick-183.py --sub /root/sub.json --scan

    # 4. накатить победителя (или конкретный номер: --apply 2)
    python3 zizi-subpick-183.py --sub /root/sub.json --scan --apply best

После --apply скрипт сам перезапустит xray, проверит GL уже через рабочий 1080
и сбросит приговоры резолвера, чтобы тракт узнал о новом узле сразу.
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

XRAY_CFG = os.environ.get("XRAY_CFG", "/usr/local/etc/xray/config.json")
XRAY_SVC = os.environ.get("XRAY_SVC", "xray")
SOCKS_PORT = int(os.environ.get("ZIZI_SOCKS_PORT", "1080"))
ZIZI_URL = os.environ.get("ZIZI_URL", "http://127.0.0.1:8080")
ZIZI_ENV = os.environ.get("ZIZI_ENV", "/opt/zizi/zizi.env")


def find_xray():
    for p in ("/usr/local/bin/xray", "/usr/bin/xray", shutil.which("xray") or ""):
        if p and os.path.exists(p):
            return p
    sys.exit("xray не найден (искал /usr/local/bin/xray, /usr/bin/xray, PATH)")


def sh(cmd, timeout=30):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except FileNotFoundError as e:
        return -2, "", str(e)


# ── разбор подписки: JSON-конфиги ИЛИ старые vless:// ────────────────────────
def load_nodes(path):
    raw = open(path, encoding="utf-8", errors="replace").read().strip()
    nodes = []
    if raw.startswith("[") or raw.startswith("{"):
        data = json.loads(raw)
        if isinstance(data, dict):
            data = [data]
        for cfg in data:
            name = str(cfg.get("remarks") or "?")
            ob = next((o for o in cfg.get("outbounds", [])
                       if o.get("protocol") in ("vless", "vmess", "trojan", "shadowsocks")), None)
            if not ob:
                continue
            addr = ""
            st = ob.get("settings", {})
            for key in ("vnext", "servers"):
                if st.get(key):
                    addr = "%s:%s" % (st[key][0].get("address"), st[key][0].get("port"))
                    break
            # служебные строки подписки (срок, новости) — это не узлы
            if addr.startswith("127.0.0.1"):
                continue
            ob = dict(ob)
            ob["tag"] = "proxy"
            nodes.append({"name": name, "addr": addr, "outbound": ob,
                          "net": (ob.get("streamSettings") or {}).get("network", "tcp")})
        return nodes
    if "vless://" in raw:
        sys.exit("это старый формат (vless://) — для него у нас уже есть "
                 "zizi-geoscan.py, он ничем не хуже")
    sys.exit("не понял формат подписки: ни JSON-конфиги, ни vless://")


def probe_cfg(outbound, port):
    return {"log": {"loglevel": "error"},
            "inbounds": [{"listen": "127.0.0.1", "port": port, "protocol": "socks",
                          "settings": {"udp": True, "auth": "noauth"}}],
            "outbounds": [outbound]}


GL_RE = re.compile(r'"countryCode":"([A-Z]{2})"|"gl":"([A-Z]{2})"|"GL":"([A-Z]{2})"')


def ask_youtube(proxy, timeout):
    """Что Google думает о нашей стране. Единственный честный критерий."""
    t0 = time.time()
    rc, out, err = sh(["curl", "-s", "--max-time", str(timeout), "-x", proxy,
                       "-H", "Accept-Language: en-US,en",
                       "https://www.youtube.com/"], timeout=timeout + 5)
    ms = int((time.time() - t0) * 1000)
    if rc != 0 or not out:
        return {"gl": "нет ответа", "ms": ms}
    m = GL_RE.search(out)
    gl = next((g for g in (m.groups() if m else []) if g), "?") if m else "?"
    bot = "не робот" if "confirm you" not in out.lower() else "БОТ-ЧЕК"
    return {"gl": gl, "ms": ms, "bot": bot}


def speed(proxy, timeout):
    """Грубая проба скорости по статике самого ютуба. Не замена bytecheck,
    но узел, который тут даёт единицы КБ/с, до музыки допускать незачем."""
    rc, out, _ = sh(["curl", "-s", "-o", "/dev/null", "-w", "%{speed_download}",
                     "--max-time", str(timeout), "-x", proxy,
                     "https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg"],
                    timeout=timeout + 5)
    try:
        return int(float(out or 0) / 1024)
    except ValueError:
        return 0


def scan(nodes, xray, port, timeout, only=None):
    proxy = "socks5h://127.0.0.1:%d" % port
    results = []
    for i, n in enumerate(nodes):
        if only is not None and i != only:
            continue
        cfg_path = os.path.join(tempfile.gettempdir(), "zizi-subpick-%d.json" % port)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(probe_cfg(n["outbound"], port), f)
        proc = subprocess.Popen([xray, "-c", cfg_path],
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        time.sleep(1.2)
        r = dict(n)
        if proc.poll() is not None:
            err = (proc.stderr.read() or b"").decode("utf-8", "replace").strip().splitlines()
            r.update({"gl": "xray не поднялся", "ms": 0, "kbs": 0,
                      "why": (err[-1][:90] if err else "")})
        else:
            r.update(ask_youtube(proxy, timeout))
            r["kbs"] = speed(proxy, timeout) if r.get("gl") not in ("нет ответа",) else 0
            proc.terminate()
            try:
                proc.wait(5)
            except subprocess.TimeoutExpired:
                proc.kill()
        results.append((i, r))
        print("  [%2d/%d] %-34s %-16s GL=%-14s %5s мс  %6s КБ/с %s" % (
            i + 1, len(nodes), r["name"][:34], r["addr"][:16], r.get("gl"),
            r.get("ms", 0), r.get("kbs", 0),
            "← ГОДЕН" if good(r) else ("· " + reject(r))))
        try:
            os.unlink(cfg_path)
        except OSError:
            pass
    return results


def good(r):
    return not reject(r)


def reject(r):
    """Почему узел не годится. 1.8.3: раньше скрипт молча не ставил «ГОДЕН» и
    узел с бот-чеком выглядел неотличимо от узла с GL=RU. Это враньё умолчанием:
    бот-чек — это приговор Google КОНКРЕТНО этому IP, и лечится он сменой узла,
    а GL=RU — это вообще не заграница. Разные болезни, пишем разными словами."""
    gl = r.get("gl")
    if gl in ("нет ответа", "xray не поднялся"):
        return "узел молчит"
    if gl in ("RU", "?"):
        return "GL=%s — это не заграница" % gl
    if r.get("bot") == "БОТ-ЧЕК":
        return "БОТ-ЧЕК на этом IP"
    if r.get("kbs", 0) <= 50:
        return "медленно (%s КБ/с)" % r.get("kbs", 0)
    return ""


def apply_node(node, xray):
    """Подменить ТОЛЬКО outbound в рабочем конфиге. Инбаунд 1080 и всё
    остальное остаётся как было: меняем узел, а не схему."""
    if not os.path.exists(XRAY_CFG):
        sys.exit("рабочий конфиг %s не найден — задай XRAY_CFG=" % XRAY_CFG)
    cfg = json.load(open(XRAY_CFG, encoding="utf-8"))
    bak = "%s.bak-%s" % (XRAY_CFG, time.strftime("%F-%H%M%S"))
    shutil.copy2(XRAY_CFG, bak)
    keep = [o for o in cfg.get("outbounds", []) if o.get("tag") not in (None, "proxy")]
    cfg["outbounds"] = [node["outbound"]] + keep
    tmp = XRAY_CFG + ".new"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    rc, _, err = sh([xray, "-test", "-c", tmp])
    if rc != 0:
        os.unlink(tmp)
        sys.exit("xray -test забраковал новый конфиг, НИЧЕГО не меняю:\n" + (err or "")[-400:])
    os.replace(tmp, XRAY_CFG)
    print("бэкап:", bak)
    sh(["systemctl", "restart", XRAY_SVC])
    time.sleep(2)
    live = ask_youtube("socks5h://127.0.0.1:%d" % SOCKS_PORT, 20)
    print("через рабочий 1080: GL=%s  %s мс  %s" % (live.get("gl"), live.get("ms"),
                                                    live.get("bot", "")))
    if live.get("gl") in ("RU", "?", "нет ответа"):
        print("ВНИМАНИЕ: рабочий выход не подтвердил страну. Откат: cp %s %s && systemctl restart %s"
              % (bak, XRAY_CFG, XRAY_SVC))
        return
    # приговоры резолвера про старый узел больше не действительны
    token = ""
    if os.path.exists(ZIZI_ENV):
        for line in open(ZIZI_ENV, encoding="utf-8", errors="replace"):
            if line.startswith("ZIZI_TOKEN="):
                token = line.split("=", 1)[1].strip()
    rc, out, _ = sh(["curl", "-s", "--max-time", "10",
                     "%s/flush?token=%s" % (ZIZI_URL, token)])
    print("flush резолвера:", (out or "нет ответа")[:200])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sub", required=True, help="файл подписки (JSON-конфиги или vless://)")
    ap.add_argument("--list", action="store_true", help="показать узлы и выйти")
    ap.add_argument("--scan", action="store_true", help="прогнать узлы через YouTube")
    ap.add_argument("--only", type=int, help="проверить один узел по номеру из --list")
    ap.add_argument("--apply", help="'best' или номер узла из --list")
    ap.add_argument("--port", type=int, default=10801, help="порт пробного xray")
    ap.add_argument("--timeout", type=int, default=20)
    a = ap.parse_args()

    nodes = load_nodes(a.sub)
    xray = find_xray()
    print("xray: %s · узлов в подписке: %d\n" % (xray, len(nodes)))

    if a.list or not (a.scan or a.apply):
        for i, n in enumerate(nodes):
            print("  %2d. %-36s %-24s %s" % (i, n["name"][:36], n["addr"][:24], n["net"]))
        print("\nСтрана в названии НИЧЕГО не значит: половина узлов идёт «через РФ».")
        print("Кто из них годен, показывает только --scan.")
        return

    results = []
    if a.scan:
        print("Спрашиваю страну у самого youtube.com через каждый узел:\n")
        results = scan(nodes, xray, a.port, a.timeout, a.only)

    if not a.apply:
        if results:
            ok = [(i, r) for i, r in results if good(r)]
            ok.sort(key=lambda x: (-x[1]["kbs"], x[1]["ms"]))
            print("\nГодных узлов: %d" % len(ok))
            for i, r in ok[:5]:
                print("  %2d. %-34s GL=%-4s %5s мс %6s КБ/с" % (i, r["name"][:34], r["gl"],
                                                                r["ms"], r["kbs"]))
            if ok:
                print("\nНакатить лучший:  --scan --apply best   (или --apply %d)" % ok[0][0])
        return

    if a.apply == "best":
        ok = [(i, r) for i, r in results if good(r)]
        if not ok:
            sys.exit("годных узлов не нашлось — накатывать нечего")
        ok.sort(key=lambda x: (-x[1]["kbs"], x[1]["ms"]))
        idx = ok[0][0]
    else:
        idx = int(a.apply)
    print("\nСтавлю узел %d: %s (%s)" % (idx, nodes[idx]["name"], nodes[idx]["addr"]))
    apply_node(nodes[idx], xray)


if __name__ == "__main__":
    main()
