#!/usr/bin/env python3
# ZiziResolve 1.3 -> 1.4 (хотфикс 6.19.3). Правит /opt/zizi/zizi_resolver.py на месте.
# Идемпотентен: повторный запуск ничего не сломает, скажет "уже 1.4".
# Делает бэкап, проверяет синтаксис, при ошибке откатывает.
import ast, os, shutil, sys, time

P = sys.argv[1] if len(sys.argv) > 1 else "/opt/zizi/zizi_resolver.py"
s = open(P, encoding="utf-8").read()
if 'version="1.4"' in s:
    print("уже 1.4 — выхожу"); sys.exit(0)
if 'RETRY_VIA_PROXY = (451, 404, 402, 502)' not in s:
    print("это не 1.3: не нашёл RETRY_VIA_PROXY = (451, 404, 402, 502). Ничего не менял."); sys.exit(1)

def rep(a, b):
    global s
    if s.count(a) != 1:
        print("не найден (или неоднозначен) фрагмент:\n" + a[:120]); sys.exit(1)
    s = s.replace(a, b)

rep('''RETRY_VIA_PROXY = (451, 404, 402, 502)''',
'''RETRY_VIA_PROXY = tuple(
    int(c) for c in re.split(r"[,\\s]+", os.environ.get("ZIZI_RETRY_CODES", "451,402").strip())
    if c.isdigit()
)
VISITOR_DATA = os.environ.get("ZIZI_VISITOR_DATA", "").strip()
PLAYER_SKIP = [x for x in re.split(r"[,\\s]+", os.environ.get("ZIZI_PLAYER_SKIP", "").strip()) if x]
THROTTLE_COOLDOWN = int(os.environ.get("ZIZI_THROTTLE_COOLDOWN", "300"))''')

rep('''_stat = {"direct": 0, "proxy": 0, "failed": 0, "cache_hits": 0,
         "soft_neg": 0, "hard_neg": 0}''',
'''_stat = {"direct": 0, "proxy": 0, "failed": 0, "cache_hits": 0,
         "soft_neg": 0, "hard_neg": 0, "throttled": 0}
_throttle: Dict[str, float] = {"direct": 0.0, "proxy": 0.0}


def _throttled(via_proxy: bool) -> bool:
    return time.time() < _throttle["proxy" if via_proxy else "direct"]''')

rep('''    m = msg.lower()
    # Бот-чек проверяем первым''',
'''    m = msg.lower()
    # 429 первым: "Too Many Requests" не попадал ни в один шаблон и уходил в 502, а 502
    # старый RETRY_VIA_PROXY переспрашивал через прокси. Нас лимитируют — мы удваиваем запросы.
    if "429" in m and "too many requests" in m:
        return 429
    # Бот-чек проверяем первым''')

rep('''    return {
        451: "трек недоступен из региона сервера",''',
'''    return {
        429: "источник временно лимитирует сервер, попробуй через минуту",
        451: "трек недоступен из региона сервера",''')

rep('''                "player_client": [c.strip() for c in CLIENTS if c.strip()],
                "player_skip": ["configs"],''',
'''                "player_client": [c.strip() for c in CLIENTS if c.strip()],''')

rep('''    if PO_PROVIDER:
        opts["extractor_args"]["youtubepot-bgutilhttp"] = {"base_url": [PO_PROVIDER]}
    return opts''',
'''    yt = opts["extractor_args"]["youtube"]
    if PLAYER_SKIP:
        yt["player_skip"] = PLAYER_SKIP
    if VISITOR_DATA:
        yt["visitor_data"] = [VISITOR_DATA]
    if PO_PROVIDER:
        opts["extractor_args"]["youtubepot-bgutilhttp"] = {"base_url": [PO_PROVIDER]}
    return opts''')

rep('''def _routes() -> List[bool]:''',
'''def _routes_possible() -> List[bool]:
    return [False, True] if OUT_PROXY else [False]


def _routes() -> List[bool]:''')

rep('''        for via_proxy in _routes():
            # На прокси идём только если прямой путь дал именно тот отказ,''',
'''        routes = _routes()
        if routes and routes[0] is False and _throttled(False) and True in _routes_possible():
            routes = [True] + [r for r in routes if r is not True]
            log.info("resolve %s: прямой путь под 429-паузой, идём сразу через прокси", video_id)

        for via_proxy in routes:
            if _throttled(via_proxy):
                if first_code is None:
                    first_code, first_raw = 429, "throttled route skipped"
                continue
            # На прокси идём только если прямой путь дал именно тот отказ,''')

rep('''            data, code, raw = await _try_route(video_id, via_proxy)
            if data:''',
'''            data, code, raw = await _try_route(video_id, via_proxy)
            if code == 429:
                _throttle["proxy" if via_proxy else "direct"] = time.time() + THROTTLE_COOLDOWN
                _stat["throttled"] += 1
                log.warning("429 на маршруте %s: пауза %s с",
                            "proxy" if via_proxy else "direct", THROTTLE_COOLDOWN)
            if data:''')

rep('''        soft = code == 451  ''', '''        soft = code in (451, 429)  ''')

rep('''            "neg_ttl_soft": NEG_TTL_SOFT, "ts": int(time.time())}''',
'''            "neg_ttl_soft": NEG_TTL_SOFT,
            "retry_codes": list(RETRY_VIA_PROXY),
            "visitor_data": bool(VISITOR_DATA),
            "player_skip": PLAYER_SKIP,
            "throttled": {k: max(0, int(v - time.time())) for k, v in _throttle.items()},
            "ts": int(time.time())}''')

rep('''        "hard_neg": _stat["hard_neg"],''',
'''        "hard_neg": _stat["hard_neg"],
        "throttle_events": _stat["throttled"],
        "throttled_now": {k: max(0, int(v - time.time())) for k, v in _throttle.items()},''')

s = s.replace('version="1.3"', 'version="1.4"').replace('"version": "1.3"', '"version": "1.4"')

bak = P + ".bak-" + time.strftime("%F-%H%M")
shutil.copy2(P, bak)
open(P, "w", encoding="utf-8").write(s)
try:
    ast.parse(open(P, encoding="utf-8").read())
except SyntaxError as e:
    shutil.copy2(bak, P)
    print("синтаксис сломался, откатил из " + bak + ": " + str(e)); sys.exit(1)
print("готово: 1.4. бэкап: " + bak)
