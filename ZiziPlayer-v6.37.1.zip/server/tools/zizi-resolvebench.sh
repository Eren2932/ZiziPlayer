#!/usr/bin/env bash
# ZiziPlayer: из чего состоят те самые секунды ожидания ПЕРЕД первым байтом.
#
# Байты мы уже вылечили (17 МБ/с с диска). Осталось время резолва: пока yt-dlp
# опрашивает клиентов, минтит PO-токен и гоняет Deno на n-challenge, телефон
# держит пустой таймлайн и показывает 0:00 / -0:00.
#
# Скрипт НИЧЕГО не меняет. Он мерит каждый клиент по отдельности, чтобы стало видно,
# кто в списке стоит зря.
#
#   bash zizi-resolvebench.sh ID_ТРЕКА
set -u
ID="${1:?использование: bash zizi-resolvebench.sh ID_СВЕЖЕГО_ТРЕКА}"
set -a; . /opt/zizi/zizi.env; set +a
YT=/opt/zizi/venv/bin/yt-dlp
H="Authorization: Bearer ${ZIZI_TOKEN:-}"
B=localhost:8080
CLIENTS="${ZIZI_CLIENTS:-web_safari,mweb,tv,android_vr}"
POT="${ZIZI_POT_URL:-}"
CD=/opt/zizi/ytdlp-cache/direct

ms() { date +%s%3N; }
run() {  # run <описание> <extractor-args>
  local label="$1" args="$2" t0 t1 out
  t0=$(ms)
  out=$($YT --cache-dir "$CD" -f 'bestaudio[ext=m4a]/bestaudio' --skip-download \
        --extractor-args "$args" --print '%(format_id)s|%(abr)s|%(filesize,filesize_approx)s' \
        "https://youtu.be/$ID" 2>/tmp/bench.err)
  t1=$(ms)
  if [ -n "$out" ]; then
    printf '  %-28s %6d мс   %s\n' "$label" "$((t1-t0))" "$out"
  else
    printf '  %-28s %6d мс   ОТКАЗ: %s\n' "$label" "$((t1-t0))" \
      "$(grep -m1 ERROR /tmp/bench.err | cut -c1-90)"
  fi
}

echo "== 0. окружение"
echo "  клиенты в бою: $CLIENTS"
echo "  PO-провайдер:  ${POT:-ПУСТО}"
$YT --version | sed 's/^/  yt-dlp: /'
echo "  JS-runtime:    $($YT --version >/dev/null 2>&1; command -v deno >/dev/null && deno --version | head -1 || echo 'deno не в PATH')"

echo
echo "== 1. свежий резолв через наш сервис (как его видит телефон)"
# у /flush нет параметра id: neg_only=0 чистит весь кэш резолвов (30 записей, недорого),
# иначе "холодный" замер был бы попаданием в кэш и врал бы в нашу пользу
curl -s -o /dev/null -H "$H" "$B/flush?neg_only=0"
curl -s -o /dev/null -w '  холодный /resolve: %{time_total}s (код %{http_code})\n' -H "$H" "$B/resolve?id=$ID"
curl -s -o /dev/null -w '  тёплый   /resolve: %{time_total}s (код %{http_code})\n' -H "$H" "$B/resolve?id=$ID"

POTARG=""
[ -n "$POT" ] && POTARG=";youtubepot-bgutilhttp:base_url=$POT"

echo
echo "== 2. каждый клиент по отдельности (первый прогон: JS плеера ещё не в кэше)"
IFS=',' read -ra CL <<< "$CLIENTS"
for c in "${CL[@]}"; do run "$c" "youtube:player_client=$c$POTARG"; done

echo
echo "== 3. те же клиенты повторно (JS и nsig уже в кэше — это и есть рабочая цена)"
for c in "${CL[@]}"; do run "$c (2-й раз)" "youtube:player_client=$c$POTARG"; done

echo
echo "== 4. весь список сразу — так делает сервис сейчас"
run "весь список" "youtube:player_client=$CLIENTS$POTARG"
run "весь список (2-й раз)" "youtube:player_client=$CLIENTS$POTARG"

echo
echo "== 5. сколько живёт ссылка (expire) против нашего ZIZI_CACHE_TTL"
U=$(curl -s -H "$H" "$B/resolve?id=$ID" | jq -r '.url // ""')
EXP=$(printf '%s' "$U" | grep -oP '(?<=[?&])expire=\K[0-9]+' || true)
NOW=$(date +%s)
if [ -n "${EXP:-}" ]; then
  echo "  ссылка живёт ещё $(( (EXP - NOW) / 60 )) мин ( $(( (EXP-NOW)/3600 )) ч )"
  echo "  ZIZI_CACHE_TTL = ${ZIZI_CACHE_TTL:-10800} с ( $(( ${ZIZI_CACHE_TTL:-10800} / 3600 )) ч )"
  echo "  ВЫВОД: всё, что между этими числами, — резолвы, которых можно было не делать."
fi

echo
echo "== 6. распределение времени удачных резолвов за сутки"
journalctl -u zizi-resolver --since "-24h" --no-pager 2>/dev/null \
  | grep -oP 'resolved \S+ via \w+ in \K[0-9.]+' \
  | awk '{n++; s+=$1; if($1>m)m=$1; if($1>5)slow++}
         END{ if(n) printf "  удачных: %d, среднее: %.1f с, максимум: %.1f с, дольше 5 с: %d\n", n, s/n, m, slow+0;
              else print "  за сутки ни одного удачного резолва в журнале" }'
echo "  топ-5 самых долгих:"
journalctl -u zizi-resolver --since "-24h" --no-pager 2>/dev/null \
  | grep -oP 'resolved \S+ via \w+ in [0-9.]+s.*' | sort -t' ' -k5 -rn | head -5 | sed 's/^/    /'
