#!/usr/bin/env bash
# ZiziResolve 1.5 — установка/обновление сервиса на Ubuntu 22.04.
#
# Собран из правок, которые 28-29.08.2026 применялись на 147.45.166.244 руками.
# Каждый шаг идемпотентен: скрипт можно гонять повторно на живом сервере.
#
# ВАЖНО, честно: по частям все шаги проверены на живом сервере, целиком на ЧИСТОЙ
# машине скрипт ещё не прогонялся. Первый раз запускать с --dry-run и читать вывод.
#
#   bash install-zizi-resolver.sh --dry-run
#   bash install-zizi-resolver.sh
#
set -euo pipefail

DRY=0; [[ "${1:-}" == "--dry-run" ]] && DRY=1
run(){ if [[ $DRY == 1 ]]; then echo "DRY: $*"; else eval "$@"; fi; }
say(){ printf '\n\033[1m== %s\033[0m\n' "$*"; }

ZIZI_DIR=/opt/zizi
SRC="$(cd "$(dirname "$0")" && pwd)/zizi_resolver.py"
[[ -f "$SRC" ]] || { echo "нет $SRC — запускай скрипт из каталога server/"; exit 1; }

say "1. пакеты"
run "apt-get update -qq"
run "apt-get install -y -qq python3-venv python3-pip curl unzip jq git"

say "2. своп 2 ГБ (лечение OOM Deno: на машине 890 МБ RAM, V8 просил 18 ГБ адресного)"
if [[ ! -f /swapfile ]]; then
  run "fallocate -l 2G /swapfile"
  run "chmod 600 /swapfile"
  run "mkswap /swapfile"
  run "swapon /swapfile"
else
  echo "   /swapfile уже есть — пропускаю"
fi
grep -q '^/swapfile' /etc/fstab || run "echo '/swapfile none swap sw 0 0' >> /etc/fstab"

say "3. python-окружение и yt-dlp (yt-dlp-ejs обязателен: без него n-challenge не решается)"
[[ -d $ZIZI_DIR/venv ]] || run "python3 -m venv $ZIZI_DIR/venv"
run "$ZIZI_DIR/venv/bin/pip install -q -U pip"
run "$ZIZI_DIR/venv/bin/pip install -q -U 'yt-dlp[default]' yt-dlp-ejs fastapi uvicorn httpx"

say "4. Deno (JS-движок для решателя; без него часть треков выглядит как удалённая)"
if ! command -v deno >/dev/null 2>&1; then
  run "curl -fsSL https://deno.land/install.sh | DENO_INSTALL=/usr/local sh"
else
  echo "   deno $(deno --version 2>/dev/null | head -1) уже есть"
fi

say "5. код сервиса (с бэкапом старого)"
run "mkdir -p $ZIZI_DIR/ytdlp-cache/direct $ZIZI_DIR/ytdlp-cache/proxy"
# 6.21.0: склад аудио. Квота 3 ГБ на диске 15 ГБ — проверь df, если диск другой.
run "mkdir -p $ZIZI_DIR/audio"
run "mkdir -p $ZIZI_DIR/tools"
for t in "$(cd "$(dirname "$0")" && pwd)"/tools/*.py; do
  [[ -f "$t" ]] && run "install -m 644 '$t' $ZIZI_DIR/tools/"
done
if [[ -f $ZIZI_DIR/zizi_resolver.py ]]; then
  run "cp $ZIZI_DIR/zizi_resolver.py '$ZIZI_DIR/zizi_resolver.py.bak-\$(date +%F-%H%M)'"
fi
run "install -m 644 '$SRC' $ZIZI_DIR/zizi_resolver.py"

say "6. zizi.env (токен генерируется один раз и больше не трогается)"
if [[ ! -f $ZIZI_DIR/zizi.env ]]; then
  TOKEN="$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 32)"
  run "cat > $ZIZI_DIR/zizi.env <<ENV
ZIZI_TOKEN=$TOKEN
ZIZI_PROXY=socks5h://127.0.0.1:1080
ZIZI_PROXY_MODE=fallback
ZIZI_CACHE_TTL=10800
ZIZI_NEG_TTL=600
ZIZI_NEG_TTL_SOFT=60
ZIZI_CLIENTS=mweb,android_vr
ZIZI_POT_URL=http://127.0.0.1:4416
ZIZI_RETRY_CODES=451,402
ZIZI_THROTTLE_COOLDOWN=300
ZIZI_DISK_CACHE=1
ZIZI_AUDIO_DIR=/opt/zizi/audio
ZIZI_AUDIO_QUOTA_MB=3072
ZIZI_FETCH_CHUNK_KB=1024
ZIZI_FETCH_WORKERS=4
ZIZI_PREFETCH_BYTES=1
ZIZI_EXTRACT_SLOTS=1
ZIZI_STOP_ON_FIRST=1
ZIZI_CACHE_MARGIN=600
ZIZI_CACHE_FILE=/opt/zizi/resolve-cache.json
ZIZI_SOCKET_TIMEOUT=12
ZIZI_YDL_RETRIES=1
ZIZI_FETCH_WORKERS_BG=2
ZIZI_FILL_SLOTS=1
ZIZI_BG_YIELD_MAX=45
ENV"
  run "chmod 600 $ZIZI_DIR/zizi.env"
  echo "   токен записан в $ZIZI_DIR/zizi.env — вбей его в приложение"
else
  echo "   zizi.env уже есть — токен не трогаю, дописываю только отсутствующие ключи"
  # 6.20.0: старые установки не имеют ни PO-провайдера, ни политики ретраев. Дописываем
  # ТОЛЬКО отсутствующие ключи: то, что человек выставил руками, важнее наших значений.
  for kv in \
    "ZIZI_CLIENTS=mweb,android_vr" \
    "ZIZI_POT_URL=http://127.0.0.1:4416" \
    "ZIZI_RETRY_CODES=451,402" \
    "ZIZI_THROTTLE_COOLDOWN=300" \
    "ZIZI_DISK_CACHE=1" \
    "ZIZI_AUDIO_DIR=/opt/zizi/audio" \
    "ZIZI_AUDIO_QUOTA_MB=3072" \
    "ZIZI_FETCH_CHUNK_KB=1024" \
    "ZIZI_FETCH_WORKERS=4" \
    "ZIZI_PREFETCH_BYTES=1" \
    "ZIZI_EXTRACT_SLOTS=1" \
    "ZIZI_STOP_ON_FIRST=1" \
    "ZIZI_CACHE_MARGIN=600" \
    "ZIZI_CACHE_FILE=/opt/zizi/resolve-cache.json" \
    "ZIZI_SOCKET_TIMEOUT=12" \
    "ZIZI_YDL_RETRIES=1" \
    "ZIZI_FETCH_WORKERS_BG=2" \
    "ZIZI_FILL_SLOTS=1" \
    "ZIZI_BG_YIELD_MAX=45"; do
    key="${kv%%=*}"
    grep -q "^${key}=" $ZIZI_DIR/zizi.env || run "echo '$kv' >> $ZIZI_DIR/zizi.env"
  done
fi

say "6b. PO-токен провайдер bgutil (аттестация YouTube; без него часть треков выглядит удалённой)"
# Почему не Docker: демон Docker на машине с 890 МБ RAM стоит дороже самого провайдера.
# node с --max-old-space-size=192 держится в ~90-130 МБ и этого достаточно.
if ! command -v node >/dev/null 2>&1; then
  run "curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
  run "apt-get install -y -qq nodejs"
else
  echo "   node $(node -v 2>/dev/null) уже есть"
fi
if [[ ! -d /opt/bgutil ]]; then
  run "git clone -q https://github.com/Brainicism/bgutil-ytdlp-pot-provider.git /opt/bgutil"
else
  run "git -C /opt/bgutil pull -q --ff-only || true"
fi
run "cd /opt/bgutil/server && npm install --silent && npx tsc"
# Плагин в venv yt-dlp. Мажорная версия плагина обязана совпадать с версией провайдера,
# иначе провайдер отвечает, а yt-dlp не понимает ответ и молча идёт без токена.
run "$ZIZI_DIR/venv/bin/pip install -q -U bgutil-ytdlp-pot-provider"
run "cat > /etc/systemd/system/bgutil-pot.service <<UNIT
[Unit]
Description=bgutil PO token provider (attestation for ZiziResolve)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/bgutil/server
Environment=NODE_OPTIONS=--max-old-space-size=192
ExecStart=/usr/bin/node build/main.js --port 4416
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT"
run "systemctl daemon-reload"
run "systemctl enable --now bgutil-pot"

say "7. systemd-юнит (--workers 1: два воркера = два кэша и две статистики)"
run "cat > /etc/systemd/system/zizi-resolver.service <<UNIT
[Unit]
Description=ZiziResolve (audio resolver for ZiziPlayer)
After=network-online.target bgutil-pot.service
Wants=network-online.target bgutil-pot.service

[Service]
Type=simple
WorkingDirectory=$ZIZI_DIR
EnvironmentFile=$ZIZI_DIR/zizi.env
Environment=PATH=/usr/local/bin:/usr/bin:/bin
ExecStart=$ZIZI_DIR/venv/bin/uvicorn zizi_resolver:app --host 0.0.0.0 --port 8080 --workers 1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT"

say "8. лимит памяти V8 (иначе Deno просит 18 ГБ адресного и ловит OOM-killer)"
run "mkdir -p /etc/systemd/system/zizi-resolver.service.d"
run "printf '[Service]\nEnvironment=DENO_V8_FLAGS=--max-old-space-size=256\n' > /etc/systemd/system/zizi-resolver.service.d/10-deno.conf"

say "9. ночное обновление yt-dlp (гонка с Google выигрывается кроном, а не пересборкой APK)"
run "cat > /etc/cron.daily/zizi-ytdlp-update <<CRON
#!/bin/sh
$ZIZI_DIR/venv/bin/pip install -q -U 'yt-dlp[default]' yt-dlp-ejs && systemctl restart zizi-resolver
CRON"
run "chmod +x /etc/cron.daily/zizi-ytdlp-update"

say "10. запуск"
run "systemctl daemon-reload"
run "systemctl enable --now zizi-resolver"
run "sleep 3"

if [[ $DRY == 0 ]]; then
  set -a; . $ZIZI_DIR/zizi.env; set +a
  echo; echo "pot-провайдер:"; curl -s --max-time 5 localhost:4416/ping || echo "  НЕ ОТВЕТИЛ — смотри journalctl -u bgutil-pot"; echo
  echo; echo "health:"; curl -s localhost:8080/health; echo
  echo "cache:";  curl -s "localhost:8080/cache?token=$ZIZI_TOKEN"; echo
  echo "geo:";    curl -s "localhost:8080/geo?token=$ZIZI_TOKEN"; echo
  echo
  echo "Если в geo direct.gl == proxy.gl == RU — прокси не помогает, ищи узел:"
  echo "  python3 $ZIZI_DIR/tools/zizi-geoscan.py --limit 3"
fi
