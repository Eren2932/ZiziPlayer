# Как выпустить подписанный релиз ZiziPlayer

Коротко: ключ создаётся **один раз в жизни проекта**, кладётся в секреты GitHub,
и дальше релиз = один тег. Собирать на своей машине не обязательно — CI собирает сам.

---

## 0. Почему ключ важнее самого APK

Android опознаёт приложение **по подписи**, а не по имени. Правило жёсткое:

- потерял ключ → следующая версия **не установится поверх** старой; только удалить
  приложение вместе со всеми данными и поставить заново;
- отдал ключ кому-то → он может выпустить «обновление» твоего плеера.

Поэтому: `release.jks` и пароли — в менеджер паролей и в оффлайн-копию (флешка, бумага).
В репозиторий — **никогда**. `.gitignore` уже содержит `*.jks`.

---

## 1. Создать ключ (один раз, на своей машине)

Нужен JDK (есть в Android Studio: `...\jbr\bin\keytool.exe`).

````powershell
keytool -genkeypair -v `
  -keystore release.jks `
  -alias zizi `
  -keyalg RSA -keysize 4096 `
  -validity 10000 `
  -storetype PKCS12
````

- `-validity 10000` — примерно 27 лет. Меньше не ставь: истёкший ключ = тот же тупик, что потерянный.
- Пароль хранилища и пароль ключа можно сделать одинаковыми, это нормально.
- На вопрос «Как вас зовут» (`CN`) можно написать что угодно, например `ZiziPlayer`.
  Это видно всем, кто посмотрит сертификат.

Проверить, что получилось:

````powershell
keytool -list -v -keystore release.jks
````

`SHA-256` отпечаток из вывода стоит записать: по нему потом проверяется, что APK подписан
тем самым ключом, а не подменённым.

---

## 2. Превратить ключ в текст для секрета

Бинарный файл в секрет GitHub положить нельзя, поэтому base64:

````powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.jks")) | Set-Clipboard
````

(в буфере теперь одна длинная строка — она и пойдёт в секрет)

---

## 3. Секреты в GitHub

`Settings → Secrets and variables → Actions`

**Secrets → New repository secret** (4 штуки, как ты и говорил):

| Имя | Значение |
|---|---|
| `SIGNING_KEYSTORE_BASE64` | строка из шага 2 |
| `SIGNING_STORE_PASSWORD` | пароль хранилища |
| `SIGNING_KEY_ALIAS` | `zizi` |
| `SIGNING_KEY_PASSWORD` | пароль ключа |

Плюс пятый, уже не про подпись, а про сервер:

| Имя | Значение |
|---|---|
| `RESOLVER_TOKEN` | `ZIZI_TOKEN` из `/opt/zizi/zizi.env` |

И одна **переменная** (`Variables`, не секрет — адрес не тайна):

| Имя | Значение |
|---|---|
| `RESOLVER_URL` | `147.45.166.244:8080` |

Если `RESOLVER_TOKEN` не задать — сборка не падает: APK соберётся, но в настройках
останутся видимыми поля «Свой резолвер» и «Токен», как в 6.10.2.

---

## 4. Выпуск

````bash
git add -A
git commit -m "6.11.0: вшитый резолвер, скрытые технические настройки, подписанный релиз"
git tag v6.11.0
git push origin main --tags
````

Дальше CI сам: соберёт, подпишет, **проверит подпись** (`Verify signature`) и выложит
`ZiziPlayer-v6.11.0.apk` в раздел Releases.

Шаг `Verify signature` специально валит сборку, если в сертификате оказался `CN=Android Debug`.
Это защита от самой поганой ошибки: выложить debug-подписанный APK, а через неделю
выпустить нормальный — и обнаружить, что он не ставится поверх ни у кого.

---

## 5. Если хочется собрать локально

````powershell
$env:SIGNING_STORE_FILE="C:\keys\release.jks"
$env:SIGNING_STORE_PASSWORD="..."
$env:SIGNING_KEY_ALIAS="zizi"
$env:SIGNING_KEY_PASSWORD="..."
.\gradlew assembleRelease -PresolverUrl=147.45.166.244:8080 -PresolverToken=ТОКЕН
````

APK: `app\build\outputs\apk\release\`.

Без переменных подписи сборка тоже пройдёт — на debug-ключе. Такой APK годится
только «посмотреть у себя», раздавать его нельзя (см. шаг 4).

---

## 6. Режим отладки в собранном релизе

Технические настройки (адрес резолвера, токен, `/health`, полная диагностика, отчёт о потоке)
в релизе скрыты. Открыть: **Настройки → «О приложении» → семь тапов по строке с версией.**
Выключить — один тап по ней же.

Это нужно, когда у пользователя что-то не играет: строка `/health` и «Полная диагностика»
за секунду отличают «сервер лежит» от «трек удалён», а без них диагноз ставится только
пересборкой APK.

## 6.20.0 — обновление сервера (без переустановки)

```bash
apt-get update -qq && apt-get install -y -qq jq git
set -a; . /opt/zizi/zizi.env; set +a
H="Authorization: Bearer $ZIZI_TOKEN"

# снимок "до"
curl -s localhost:8080/health | jq
curl -s -H "$H" localhost:8080/geo | jq

# код 1.3 -> 1.4
systemctl stop zizi-resolver
python3 /opt/zizi/tools/zizi-hotfix-1.4.py /opt/zizi/zizi_resolver.py
systemctl start zizi-resolver

# PO-провайдер и переменные: проще всего прогнать установщик целиком, он идемпотентен
bash server/install-zizi-resolver.sh --dry-run
bash server/install-zizi-resolver.sh

# проверка
curl -s localhost:4416/ping | jq
curl -s localhost:8080/health | jq '.version, .pot, .clients, .retry_codes'
curl -s -H "$H" "localhost:8080/flush?neg_only=1" | jq
```
