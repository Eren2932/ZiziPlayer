package app.ziziplayer.data.remote

import androidx.compose.runtime.Immutable

/**
 * Серверная «Главная» (Reco 1): профиль вкуса уходит одним запросом, полки приходят готовыми.
 *
 * Профиль компактен намеренно: артисты и веса, а не история. Названий треков, времени и
 * длительностей на сервере нет ни в запросе, ни в логе.
 */
@Immutable
data class RecoSeed(val ref: String, val weight: Double)

@Immutable
data class RecoProfile(
    val seeds: List<RecoSeed>,
    val known: List<String>,
    val negative: List<String>,
    val recent: List<String>,
    /** "slowed" | "sped" | "" */
    val version: String
) {
    /** Поля тела POST `/reco/home` (не query: см. BrowseHttp.post). Значения очищены от разделителей протокола. */
    fun queryParams(): Map<String, String> = linkedMapOf(
        "s" to seeds.take(8).joinToString("|") { RecoQuery.seed(it.ref, it.weight) },
        "k" to RecoQuery.join(known, 40),
        "x" to RecoQuery.join(negative, 20),
        "r" to RecoQuery.join(recent, 3),
        "v" to version
    ).filterValues { it.isNotEmpty() }
}

enum class RecoShelfKind { ALBUMS, TRACKS, ARTISTS }

@Immutable
data class RecoCard(val track: RemoteTrack? = null, val collection: RemoteCollection? = null)

@Immutable
data class RecoShelf(
    val id: String,
    val kind: RecoShelfKind,
    val title: String,
    /** Артист-якорь полки «Похоже на»; у остальных полок null. */
    val anchorName: String?,
    val anchorArt: String?,
    val cards: List<RecoCard>
)

/** [complete] = false: сервер уложился в бюджет не целиком; остаток он достроит в кэше, повтор через 15 с. */
@Immutable
data class RecoResult(val shelves: List<RecoShelf>, val complete: Boolean, val cold: Boolean)
