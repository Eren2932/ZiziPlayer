package app.ziziplayer.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Профиль вкуса для серверной «Главной» (Reco 1). Чистая арифметика и текст, без Android.
 *
 * На сервер уходит ровно то, что нужно графу: до 8 артистов с весами, имена известных, пропущенные
 * и последние артисты, предпочтение версии. Не уходят названия треков, время и длительности.
 */
public final class HomeRecoPolicy {
    private HomeRecoPolicy() {}

    public static final int MAX_SEEDS = 8;
    public static final int MAX_KNOWN = 40;
    public static final int MAX_NEGATIVE = 20;
    public static final int MAX_RECENT = 3;
    /** Артист с суммарной оценкой не выше этого порога считается нежеланным (ранние пропуски). */
    public static final double NEGATIVE_SCORE = -3.0;
    /** Соисполнитель получает 60% оценки трека: вклад есть, но он не главный. */
    public static final double SECONDARY_SHARE = 0.6;
    /** Минимальная доля версии в прослушанном, чтобы считать её предпочтением вкуса. */
    public static final double VERSION_SHARE = 0.4;

    private static final Pattern CREDIT_SPLIT = Pattern.compile(
        "\\s*(?:,|;|\\s&\\s|\\sx\\s|\\s(?:feat|ft|featuring|with)\\.?\\s)\\s*", Pattern.CASE_INSENSITIVE);
    private static final Pattern SLOWED = Pattern.compile("\\bslow(?:ed|ing)?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SPED_UP = Pattern.compile(
        "\\b(?:sped|speed)[\\s_-]*up\\b|\\bnightcore\\b|\\b(?:ultra|super|mega|hiper|hyper|extreme|extra)[\\s_+-]*speed\\b",
        Pattern.CASE_INSENSITIVE);

    /** «A, B & C feat. D» -> [A, B, C, D]. Пустые и дубли выбрасываются, порядок сохраняется. */
    public static List<String> splitArtists(String credited) {
        List<String> result = new ArrayList<>();
        if (credited == null) return result;
        for (String part : CREDIT_SPLIT.split(credited.trim())) {
            String clean = part.trim();
            if (clean.length() < 2) continue;
            boolean seen = false;
            for (String old : result) if (HomeFeedPolicy.normalize(old).equals(HomeFeedPolicy.normalize(clean))) seen = true;
            if (!seen) result.add(clean);
        }
        return result;
    }

    /** Вес сида: score / max, зажатый в [0.05, 1]. Не положительный вклад весом не обладает. */
    public static double weight(double score, double maxScore) {
        if (!(score > 0.0) || !(maxScore > 0.0)) return 0.0;
        return Math.max(0.05, Math.min(1.0, score / maxScore));
    }

    public static boolean slowed(String title) {
        return title != null && SLOWED.matcher(title).find();
    }

    public static boolean spedUp(String title) {
        return title != null && SPED_UP.matcher(title).find();
    }

    /** "slowed" | "sped" | "" — какой обработке записей отдаёт предпочтение вкус. */
    public static String versionPreference(double slowedMass, double spedMass, double totalMass) {
        if (!(totalMass > 0.0)) return "";
        double slow = slowedMass / totalMass, sped = spedMass / totalMass;
        if (slow >= VERSION_SHARE && slow >= sped) return "slowed";
        if (sped >= VERSION_SHARE) return "sped";
        return "";
    }

    /** Сервер ответил и есть что показать: рисуем полки Reco. */
    public static final int SHOW = 0;
    /** Сервер ответил, но Reco нет (старше 6.81 или нечего предложить): тихо идём прежним путём. */
    public static final int FALLBACK = 1;
    /** Сервер не ответил за отведённое время: как у любого другого запроса главной (сообщение, без шторма). */
    public static final int TIMEOUT = 2;

    /**
     * Что делать с результатом запроса Reco. «Не ответил» и «ответил null» нельзя путать: первое означает
     * проблемы сети, и прежний путь по ней же не пройдёт; второе означает старый сервер, и прежний путь
     * обязан отработать без единого слова об ошибке.
     */
    public static int outcome(boolean answered, int shelves) {
        if (!answered) return TIMEOUT;
        return shelves > 0 ? SHOW : FALLBACK;
    }
}
