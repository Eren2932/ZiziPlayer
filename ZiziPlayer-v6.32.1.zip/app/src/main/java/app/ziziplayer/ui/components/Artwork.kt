package app.ziziplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.ZiziHttp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

const val ARTWORK_ROW_PX = 160
const val ARTWORK_FULL_PX = 640

/** Quantiser tuning. 24 buckets = 15 deg apart, finer than the eye separates on a backdrop. */
private const val HUE_BINS = 24
private const val SAMPLE_SIDE = 64
private const val MIN_HUE_GAP = 28f

/**
 * Three colours pulled out of one cover: the accent, a second shade for depth, and a deep one for
 * the far ends of the gradient. v5 used a single seed, so the whole screen was one flat wash of
 * colour. Reference players build the backdrop out of several shades of the same cover, which is
 * why it reads as "the cover flew across the screen" instead of "someone tinted the app brown".
 */
@Immutable
data class ArtSwatches(val primary: Color, val secondary: Color, val deep: Color) {
    fun pack(): String = "${primary.toArgb()},${secondary.toArgb()},${deep.toArgb()}"

    companion object {
        fun unpack(raw: String?): ArtSwatches? {
            val parts = raw?.split(',') ?: return null
            if (parts.size != 3) return null
            val ints = parts.map { it.toIntOrNull() ?: return null }
            return ArtSwatches(Color(ints[0]), Color(ints[1]), Color(ints[2]))
        }
    }
}

/** One decoded cover. The ImageBitmap wrapper is built once, not on every recomposition. */
@Immutable
class Art(val image: ImageBitmap, val kb: Int, val swatches: ArtSwatches?)

/**
 * Artwork pipeline, third rewrite - this time for a 3000 track library.
 *
 * The order of attempts:
 *   1. in-memory LruCache                       (instant, no allocation)
 *   2. on-disk thumbnail cache                  (~1 ms, survives app restarts)
 *   3. MediaStore album art / loadThumbnail     (cheap, system side cache)
 *   4. MediaMetadataRetriever                   (20-120 ms - NEVER from a visible row)
 *
 * The single most important rule: a scrolling row is only ever allowed to use steps 1-3.
 * v5 let every row start step 4, so scrolling a 400 track list queued 400 file parses behind a
 * one-permit semaphore - the list could not be smooth, whatever else was optimised. Step 4 now
 * belongs to [ArtworkPrefetcher], which walks the library in the background, pauses while the
 * finger is down, and writes the result to disk so it is paid exactly once per file, ever.
 */
object ArtworkCache {
    // Floor raised from 6 MB in 6.5: at 160 px a cover is ~100 KB, so 6 MB held barely 60 of
    // them. Flicking a long list evicted rows faster than it drew them and every one of them came
    // back through a disk decode - a cache that small is a cache that guarantees jank.
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceIn(12 * 1024, 64 * 1024)
    private val memory = object : LruCache<String, Art>(maxKb) {
        override fun sizeOf(key: String, value: Art): Int = value.kb
    }
    private val swatchMemory = LruCache<String, ArtSwatches>(2048)
    private val noArt = Collections.synchronizedSet(HashSet<String>())
    private val fastGate = Semaphore(2)
    private val slowGate = Semaphore(1)

    /**
     * Network covers get their own gate, four wide.
     *
     * They must not share [fastGate]: a cover fetch is 150-600 ms of waiting on a socket, and two
     * of them holding the two fast permits would stall every LOCAL cover behind them - a search
     * result list would freeze the library's thumbnails. Four at a time keeps a screenful of
     * remote rows filling in at once without opening a connection per row.
     */
    /**
     * 6.24.3. Свой scope для загрузок и карта уже идущих. Живут столько же, сколько процесс:
     * начатая загрузка обложки обязана доехать до диска, даже если строка ушла за экран.
     */
    private val fetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inflight = ConcurrentHashMap<String, Deferred<Art?>>()

    /**
     * 6.24.3: на медленном канале четыре параллельных запроса делят его на четыре и не
     * доезжает ни один; вдобавок они стоят в той же очереди, что запрос поиска и звук. Два
     * потока на мобильном — это «две обложки приехали», а не «четыре недокачаны».
     */
    private val netGate = Semaphore(2)

    /** `/150x150.jpg` and friends, at the end of an Audius cover path. */
    private val AUDIUS_SIZE = Regex("""/\d{2,4}x\d{2,4}\.jpg$""")

    /** `/hqdefault.jpg` and friends at the end of an i.ytimg.com thumbnail path. */
    private val YT_THUMB = Regex("""/(default|mqdefault|hqdefault|sddefault|maxresdefault)\.jpg""")

    /**
     * THE SCROLL BUG. Steps 1-3 were described as "cheap", so step 2 - the disk decode - ran with
     * no gate at all on Dispatchers.IO, which is 64 threads wide. Flicking a 400 row list started
     * up to 64 concurrent BitmapFactory.decodeFile calls; they do not block on IO, they burn CPU
     * and allocate, so they competed with the very frames they were decoding for. The list could
     * not be smooth no matter what else was optimised. Three at a time saturates the decode
     * throughput of a mid-range phone and leaves the render thread alone.
     */
    private val diskGate = Semaphore(3)

    /**
     * WHY COVERS GOT *WORSE* IN 6.8.0, not better.
     *
     * 6.8.0 versioned the "this file has no cover" key, which was the right call - the old set was
     * poisoned - but it also threw away the verdict for all 449 local files at once. The background
     * pass then re-probed every one of them, and each probe takes a [diskGate] permit before it can
     * even look for a cached thumbnail. There are three permits. A remote row on screen needed one
     * of the same three, so network tiles queued behind hundreds of local re-probes and filled in
     * minutes later, if at all. Nothing was broken; the traffic light was.
     *
     * Two gates fix it, and both halves are needed:
     *
     *  - remote rows read the disk through their own two permits, so they can never be starved by a
     *    local indexing pass;
     *  - the background pass holds at most ONE [diskGate] permit at a time ([prefetchGate]), so it
     *    can no longer occupy the whole disk stage. Indexing gets slower on paper and finishes at
     *    the same time in practice - it was never disk bound, it was contending with itself.
     *
     * The index key is deliberately NOT bumped again in 6.8.1: bumping it is what triggered the
     * storm, and the v2 set now holds correct answers.
     */
    private val remoteDiskGate = Semaphore(2)
    private val prefetchGate = Semaphore(1)

    @Volatile private var busyUntilMs = 0L
    @Volatile private var index: ArtworkIndex? = null
    @Volatile private var dir: File? = null

    private fun key(id: String, px: Int) = "$id@$px"

    fun attach(context: Context) {
        if (index != null) return
        val app = context.applicationContext
        val store = ArtworkIndex(app)
        index = store
        noArt.addAll(store.noArtIds())
        store.swatches().forEach { (id, swatches) -> swatchMemory.put(id, swatches) }
        val cacheDir = File(app.cacheDir, "artwork").apply { mkdirs() }
        dir = cacheDir
        // Keep the thumbnail cache bounded: oldest files go first.
        CoroutineScope(Dispatchers.IO).launch { prune(cacheDir) }
    }

    /** Called by every scrollable list: while the finger moves, nothing expensive may start. */
    fun markBusy() { busyUntilMs = System.currentTimeMillis() + 260 }
    fun isBusy(): Boolean = System.currentTimeMillis() < busyUntilMs

    /**
     * Sleeps until the busy window actually expires, instead of waking up every 60 ms to ask.
     *
     * Every visible row waits on this. With a 60 ms poll, twenty rows on screen meant ~200 pointless
     * coroutine resumes per flick, all of them landing on the main dispatcher while the frames they
     * were waiting for were being drawn. The busy window has a known end, so one sleep is enough.
     */
    suspend fun awaitIdle(maxWaitMs: Long = 900L) {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (true) {
            val now = System.currentTimeMillis()
            val remaining = busyUntilMs - now
            if (remaining <= 0L || now >= deadline) return
            delay(remaining.coerceIn(16L, 200L))
        }
    }

    /** Exactly the requested size, or nothing. */
    fun peekExact(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px))
    }

    /**
     * Anything usable right now, including a smaller thumbnail of the same cover. Used purely as a
     * stand-in for the first frame so nothing ever flashes a grey placeholder while the full size
     * decodes - it never replaces the real load.
     */
    fun peek(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px)) ?: if (px > ARTWORK_ROW_PX) memory.get(key(id, ARTWORK_ROW_PX)) else null
    }

    fun peekSwatches(track: TrackEntity?): ArtSwatches? = track?.let { swatchMemory.get(it.id) }

    /** Flushes the batched "no art" / colour verdicts to disk. */
    fun flushIndex() { index?.flush() }

    /**
     * Re-applies the 40 MB cap. v6.0 only did this at startup, so a full indexing pass could leave
     * the cache well over the cap until the next launch.
     */
    suspend fun pruneNow() {
        val base = dir ?: return
        withContext(Dispatchers.IO) { prune(base) }
    }

    fun hasNoArt(track: TrackEntity?): Boolean = track != null && noArt.contains(track.id)

    /** True when this track needs no further work at all - used to skip cheaply while prefetching. */
    fun isSettled(id: String): Boolean =
        memory.get(key(id, ARTWORK_ROW_PX)) != null || noArt.contains(id) || fileFor(id, ARTWORK_ROW_PX)?.exists() == true

    /**
     * The background pass enters through here, never through [load] directly: one permit, so the
     * indexer occupies a third of the disk stage instead of all of it. See [prefetchGate].
     */
    internal suspend fun loadIndexed(context: Context, track: TrackEntity, px: Int): Art? =
        prefetchGate.withPermit { load(context, track, px, allowSlow = true) }

    /**
     * 6.24.3. Загрузка, которая НЕ умирает вместе со строкой списка.
     *
     * Так выглядела причина «обложки грузятся по новой на каждом проходе». Сетевой запрос жил в
     * LaunchedEffect строки, а LazyColumn уничтожает ушедшую за экран строку вместе с её
     * корутиной. На Wi-Fi обложка успевала за 200 мс и это было незаметно. На мобильном 20 КБ/с
     * запрос отменялся на середине: скачанные байты выбрасывались, на диск не попадало НИЧЕГО,
     * и следующий заход начинался с нуля. Список физически не мог сойтись.
     *
     * Здесь запрос запускается в scope приложения, поэтому отмена читателя больше не отменяет
     * саму загрузку: она доезжает, ложится в память и на диск, и следующий взгляд на строку
     * получает готовое. Плюс дедупликация: десять возвратов к одной строке присоединяются к
     * ОДНОМУ запросу, а не запускают десять.
     */
    suspend fun loadDetached(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        peekExact(track, px)?.let { return it }
        val app = context.applicationContext
        val k = key(track.id, px)
        val task = inflight.computeIfAbsent(k) {
            fetchScope.async {
                try { load(app, track, px, allowSlow) } finally { inflight.remove(k) }
            }
        }
        return try {
            task.await()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            null
        }
    }

    suspend fun load(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        val cacheKey = key(track.id, px)
        memory.get(cacheKey)?.let { return it }
        // The `noArt` verdict is about a FILE and must never apply to a network row: its cover is
        // an HTTP request, and a request that failed once has to be allowed to succeed later. This
        // one condition is the other half of the grey-tile bug described in ArtworkIndex.
        if (!track.isRemote && noArt.contains(track.id)) return null

        // 2. disk (gated - see diskGate). withPermit is inline, so the non-local return below is
        // legal and the permit is still released through its finally block.
        val cached: Bitmap? = (if (track.isRemote) remoteDiskGate else diskGate).withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { readDisk(track.id, px) }
        }
        if (cached != null) return finish(track, px, cached, writeDisk = false)

        // 2b. THE MISSING BRANCH (6.6.1). Why remote covers were blank.
        //
        // A remote row carries an https artwork URL, and step 3 below handed it to
        // ContentResolver.openInputStream, which understands content:// and file:// and nothing
        // else. It returned null, silently. Step 4 then pointed MediaMetadataRetriever at a
        // zizi:// uri, which it also cannot open. So every network track fell through the entire
        // pipeline to `noArt` - and because the verdict is cached and persisted, the tile stayed
        // grey even after the network came back. There was no code path that could ever have
        // fetched them; nothing was misconfigured, the fetch simply did not exist.
        //
        // Remote rows take this branch and return from it either way: the two local decoders below
        // have nothing to offer something with no file behind it, and running them costs two failed
        // syscalls per tile.
        if (track.isRemote) {
            /*
             * 6.8.1: the missing URL is not always missing.
             *
             * Innertube does not put a thumbnail on every row it returns - deep search shelves and
             * album track lists frequently come back without one, which is why "обложки не везде"
             * was real and not a caching illusion. But a YouTube track always has a thumbnail at a
             * derivable address: /vi/<id>/mqdefault.jpg. Deriving it costs nothing and turns a grey
             * tile into a cover for every row the API was too terse to describe.
             */
            val url = track.artworkUri?.takeIf { it.isNotBlank() }
                ?: track.remoteId
                    ?.takeIf { track.provider == "yt" && it.isNotBlank() }
                    ?.let { "https://i.ytimg.com/vi/" + it + "/mqdefault.jpg" }
            if (url.isNullOrBlank()) {
                // Not remembered, not even in memory: a saved remote row can get its artwork URL
                // filled in by the next search that returns it, and a cached "no" would outlive
                // that. Two skipped syscalls are not worth a permanently grey tile.
                return null
            }
            val fetched: Bitmap? = netGate.withPermit {
                memory.get(cacheKey)?.let { return it }
                withContext(Dispatchers.IO) { fromNetwork(url, px) }
            }
            if (fetched != null) return finish(track, px, fetched, writeDisk = true)
            // Deliberately NOT marked as coverless. A cover that failed while the phone was in a
            // lift is not a cover that does not exist, and `noArt` is written to disk - one bad
            // minute would blank the tile permanently.
            return null
        }

        // 3. fast system paths
        //
        // THE v6.0 COMPILE ERROR LIVED HERE.
        // The elvis had `Art?` on the left (the memory cache) and `Bitmap?` on the right (the
        // decoders), so Kotlin inferred their only common supertype - `Any` - and the call below
        // failed with "Argument type mismatch: actual type is 'kotlin.Any'" at Artwork.kt:167:52.
        // A cache hit now returns the finished Art immediately (withPermit is inline, so the
        // non-local return is legal and still releases the permit through its finally block) and
        // the remaining expression is a plain `Bitmap?`, which is what finish() wants.
        //
        // The re-check is not just there to satisfy the compiler: this permit is contended, and by
        // the time it is granted another coroutine may have decoded the very same cover already.
        val fast: Bitmap? = fastGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) {
                fromArtworkUri(context, track, px) ?: fromThumbnail(context, track, px)
            }
        }
        if (fast != null) return finish(track, px, fast, writeDisk = true)
        if (!allowSlow) return null

        // 4. the expensive one, one at a time, never while scrolling
        val slow = fromEmbedded(context, track, px)
        if (slow != null) return finish(track, px, slow, writeDisk = true)
        noArt.add(track.id)
        index?.rememberNoArt(track.id)
        return null
    }

    private fun finish(track: TrackEntity, px: Int, bitmap: Bitmap, writeDisk: Boolean): Art =
        finishId(track.id, px, bitmap, writeDisk, persistSwatches = true)

    private fun finishId(
        id: String,
        px: Int,
        bitmap: Bitmap,
        writeDisk: Boolean,
        persistSwatches: Boolean
    ): Art {
        var swatches = swatchMemory.get(id)
        if (swatches == null) {
            swatches = extract(bitmap)
            if (swatches != null) {
                swatchMemory.put(id, swatches)
                if (persistSwatches) index?.rememberSwatches(id, swatches)
            }
        }
        val art = Art(bitmap.asImageBitmap(), (bitmap.byteCount / 1024).coerceAtLeast(1), swatches)
        memory.put(key(id, px), art)
        if (writeDisk) CoroutineScope(Dispatchers.IO).launch { writeDisk(id, px, bitmap) }
        return art
    }

    // ---------------- covers that belong to a URL, not to a row ----------------

    /**
     * Search results are not library rows.
     *
     * A result exists in the UI long before - and very often instead of - a database row, so it has
     * no track id to key a cover on. Keying on the URL instead lets the hub, the result list and
     * the collection sheet share one cache with the player, and it means opening the same album
     * twice costs one fetch, ever: the second time the tiles are already on disk.
     *
     * The `u:` prefix keeps this namespace apart from track ids (`f:`, `u:`... note `u:` is a
     * legitimate local prefix, hence the full `url:` spelling below) so a cover can never be
     * mistaken for a track's own artwork.
     */
    private fun urlId(url: String): String = "url:$url"

    fun peekUrl(url: String?, px: Int): Art? {
        val target = url ?: return null
        return memory.get(key(urlId(target), px))
    }

    suspend fun loadUrl(url: String?, px: Int): Art? {
        val target = url?.takeIf { it.isNotBlank() } ?: return null
        val id = urlId(target)
        val cacheKey = key(id, px)
        memory.get(cacheKey)?.let { return it }

        val cached: Bitmap? = diskGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { readDisk(id, px) }
        }
        if (cached != null) return finishId(id, px, cached, writeDisk = false, persistSwatches = false)

        val fetched: Bitmap? = netGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { fromNetwork(target, px) }
        }
        // Swatches are extracted (they are nearly free once the bitmap is decoded and the player
        // may want them) but never written to the on-disk index: that index is keyed by track id
        // and is swept against the tracks table, so URL entries in it would leak forever.
        return fetched?.let { finishId(id, px, it, writeDisk = true, persistSwatches = false) }
    }

    /**
     * Cover colours, own quantiser (v6.2).
     *
     * v6.1 asked AndroidX Palette for vibrantSwatch / mutedSwatch. On a photographic cover that
     * picks a MINORITY accent - one bright petal, a logo corner - and mutedSwatch very often lands
     * on the same hue as vibrant, so three "different" shades collapsed into one. That is what made
     * the app look like it had a handful of canned palettes instead of reading the artwork.
     *
     * Here the thumbnail is walked at a stride, background-ish pixels are dropped, and the rest is
     * binned into 24 hue buckets weighted by coverage AND colourfulness. Circular mean per bucket,
     * so a hue straddling the 0/360 seam is not averaged into its own complement.
     *
     * Cost: ~4096 samples, no allocation per pixel, 1-3 ms on a mid-range phone, once per track for
     * the lifetime of the install (the result is persisted next to the thumbnail).
     */
    private fun extract(source: Bitmap): ArtSwatches? {
        val soft = source.softwareForSampling() ?: return null
        return try {
            sample(soft)
        } finally {
            if (soft !== source) soft.recycle()
        }
    }

    /**
     * `getPixels` throws on `Config.HARDWARE`, and `ContentResolver.loadThumbnail` is entitled to
     * hand one back - it decodes through `ImageDecoder`, which prefers a hardware buffer whenever
     * the device supports it. The old code called `getPixels` straight away inside `runCatching`, so
     * on those devices the throw was swallowed, `extract` returned null, and the UI quietly fell
     * back to the canned palette. That is exactly the "only a handful of fixed palettes" symptom.
     *
     * `Bitmap.copy` to a software config is the one operation that is documented to work on a
     * hardware bitmap, so it is used here rather than `createScaledBitmap`, which would go through a
     * software `Canvas` and throw "Software rendering doesn't support hardware bitmaps".
     */
    private fun Bitmap.softwareForSampling(): Bitmap? {
        val cfg = config
        val needsCopy = cfg == null ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && cfg == Bitmap.Config.HARDWARE)
        if (!needsCopy) return this
        return runCatching { copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
    }

    private fun sample(bitmap: Bitmap): ArtSwatches? = runCatching {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return@runCatching null

        val step = (maxOf(w, h) / SAMPLE_SIDE).coerceAtLeast(1)
        // One row at a time. A 512x512 cover would otherwise need a 1 MB IntArray up front while
        // only every `step`-th row is ever read - on a 3381-track library that is a lot of churn in
        // the young generation for nothing.
        val rowPixels = IntArray(w)

        val weight = FloatArray(HUE_BINS)
        val cosSum = FloatArray(HUE_BINS)
        val sinSum = FloatArray(HUE_BINS)
        val satSum = FloatArray(HUE_BINS)
        val valSum = FloatArray(HUE_BINS)
        val darkWeight = FloatArray(HUE_BINS)
        val darkCos = FloatArray(HUE_BINS)
        val darkSin = FloatArray(HUE_BINS)
        val darkSat = FloatArray(HUE_BINS)
        val darkVal = FloatArray(HUE_BINS)
        var greyWeight = 0f
        var greyValue = 0f

        val hsv = FloatArray(3)
        var y = 0
        while (y < h) {
            bitmap.getPixels(rowPixels, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                android.graphics.Color.colorToHSV(rowPixels[x], hsv)
                val hue = hsv[0]
                val sat = hsv[1]
                val value = hsv[2]
                if (sat < 0.10f || value < 0.05f || (value > 0.97f && sat < 0.16f)) {
                    // Letterboxing, white studio backgrounds and black bars are not identity.
                    greyWeight += 1f
                    greyValue += value
                } else {
                    // Colourfulness times a mid-brightness preference: a colour the eye actually
                    // reads sits away from both ends of the brightness range.
                    val wgt = (0.35f + sat) * (0.45f + 1.10f * value * (1f - 0.55f * value))
                    val bin = ((hue / 360f) * HUE_BINS).toInt().coerceIn(0, HUE_BINS - 1)
                    val rad = hue * 0.017453292f
                    val dx = cos(rad) * wgt
                    val dy = sin(rad) * wgt
                    weight[bin] += wgt
                    cosSum[bin] += dx
                    sinSum[bin] += dy
                    satSum[bin] += sat * wgt
                    valSum[bin] += value * wgt
                    if (value < 0.48f) {
                        darkWeight[bin] += wgt
                        darkCos[bin] += dx
                        darkSin[bin] += dy
                        darkSat[bin] += sat * wgt
                        darkVal[bin] += value * wgt
                    }
                }
                x += step
            }
            y += step
        }

        // A dominant colour that straddles a bucket edge used to lose to its own other half.
        // 15 deg buckets, and a cover's main hue is almost never centred in one: the red sleeve
        // split across two buckets could be beaten by a smaller, perfectly centred accent, and the
        // hue that survived was the edge of the real one. Buckets are now scored together with
        // their two neighbours, and the winner's hue, saturation and value come from all three.
        fun spread(bin: Int, ws: FloatArray): Float =
            ws[(bin + HUE_BINS - 1) % HUE_BINS] + ws[bin] + ws[(bin + 1) % HUE_BINS]

        fun merge(bin: Int, ws: FloatArray, xs: FloatArray, ys: FloatArray, ss: FloatArray, vs: FloatArray): FloatArray {
            val prev = (bin + HUE_BINS - 1) % HUE_BINS
            val next = (bin + 1) % HUE_BINS
            val w = ws[prev] + ws[bin] + ws[next]
            var deg = atan2(ys[prev] + ys[bin] + ys[next], xs[prev] + xs[bin] + xs[next]) * 57.29578f
            if (deg < 0f) deg += 360f
            val safe = if (w > 0f) w else 1f
            return floatArrayOf(deg, (ss[prev] + ss[bin] + ss[next]) / safe, (vs[prev] + vs[bin] + vs[next]) / safe, w)
        }

        var best = -1
        var bestSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (weight[i] <= 0f) continue
            val score = spread(i, weight)
            if (best < 0 || score > bestSpread) { best = i; bestSpread = score }
        }
        if (best < 0) {
            // Monochrome cover: hand back a neutral triple. Inventing a hue out of sensor noise is
            // exactly how a black-and-white sleeve used to end up painting the screen teal.
            val level = (if (greyWeight > 0f) greyValue / greyWeight else 0.24f).coerceIn(0.10f, 0.62f)
            val grey = Color(android.graphics.Color.HSVToColor(floatArrayOf(0f, 0f, level)))
            return@runCatching ArtSwatches(grey, grey, grey)
        }

        fun hueOf(bin: Int, xs: FloatArray, ys: FloatArray): Float {
            var deg = atan2(ys[bin], xs[bin]) * 57.29578f
            if (deg < 0f) deg += 360f
            return deg
        }
        fun colour(hue: Float, sat: Float, value: Float) = Color(
            android.graphics.Color.HSVToColor(
                floatArrayOf(
                    ((hue % 360f) + 360f) % 360f,
                    sat.coerceIn(0f, 1f),
                    value.coerceIn(0.06f, 1f)
                )
            )
        )

        val primary = merge(best, weight, cosSum, sinSum, satSum, valSum)
        val primaryHue = primary[0]
        val primarySat = primary[1]
        val primaryVal = primary[2]

        // A second hue at least MIN_HUE_GAP away, so the backdrop actually travels across the
        // screen the way the reference does instead of being one flat wash. The gap is wider than
        // a bucket, so this can never pick a neighbour that was just merged into the primary.
        var second = -1
        var secondSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (i == best || weight[i] <= 0f) continue
            val delta = abs(((hueOf(i, cosSum, sinSum) - primaryHue + 540f) % 360f) - 180f)
            if (delta < MIN_HUE_GAP) continue
            val score = spread(i, weight)
            if (second < 0 || score > secondSpread) { second = i; secondSpread = score }
        }
        var dark = -1
        var darkSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (darkWeight[i] <= 0f) continue
            val score = spread(i, darkWeight)
            if (dark < 0 || score > darkSpread) { dark = i; darkSpread = score }
        }

        ArtSwatches(
            primary = colour(primaryHue, primarySat, primaryVal),
            secondary = if (second >= 0) {
                val s2 = merge(second, weight, cosSum, sinSum, satSum, valSum)
                colour(s2[0], s2[1], s2[2])
            } else {
                colour(primaryHue + 16f, primarySat * 0.90f, primaryVal * 0.82f)
            },
            // The deep swatch carries the DARK region's own saturation, not the primary's. It drives
            // the top and bottom of the backdrop, and borrowing a vivid primary's saturation is what
            // made the ends of the gradient scream on photographic covers.
            deep = if (dark >= 0) {
                val d2 = merge(dark, darkWeight, darkCos, darkSin, darkSat, darkVal)
                colour(d2[0], d2[1], d2[2])
            } else {
                colour(primaryHue - 10f, primarySat * 0.85f, primaryVal * 0.50f)
            }
        )
    }.getOrNull()

    // ---------------- sources ----------------

    private fun fromArtworkUri(context: Context, track: TrackEntity, px: Int): Bitmap? {
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { decode(it.readBytes(), px) }
        }.getOrNull()
    }

    /**
     * A cover over HTTP, on the app's one OkHttp client.
     *
     * The client is shared with the catalogue and with playback, so a cover fetch reuses the TLS
     * session that search already opened to the same host instead of paying for a handshake per
     * tile.
     */
    private fun fromNetwork(url: String, px: Int): Bitmap? {
        val sized = sizedUrl(url, px)
        // The rewritten URL is an optimisation, not a requirement. If the CDN does not like the
        // crop we asked for (a video thumbnail with no `maxresdefault`, a host that changed its
        // path scheme), the original address is still valid - falling back to it costs one request
        // on a cover that would otherwise simply be missing.
        val bytes = ZiziHttp.fetchBytes(sized)
            ?: (if (sized != url) ZiziHttp.fetchBytes(url) else null)
            ?: return null
        return decode(bytes, px)
    }

    /**
     * Asks the CDN for the size we are actually going to draw.
     *
     * Both providers hand out one canonical URL with the crop encoded in the path:
     * `...=w544-h544-l90-rj` on Google's image host, `/150x150.jpg` on an Audius storage node. A
     * 160 dp row does not need 544 px, and on a screen of results the difference is roughly a
     * megabyte per screenful versus a hundred kilobytes - on mobile data, that is the whole
     * experience. Anything we do not recognise is fetched untouched and simply downsampled during
     * decode, so an unknown host costs bandwidth but never correctness.
     */
    private fun sizedUrl(url: String, px: Int): String {
        // 6.24.3. Было `240` в `-l90-rj` (JPEG качества 90) — это 15–25 КБ на одну строку
        // списка. `-rw` на том же хосте Google отдаёт WebP: те же 192 px весят 5–8 КБ. На
        // строке 48 dp разницу не видит никто, а на 20 КБ/с это разница между «обложки
        // приехали» и «обложки не приехали».
        val size = when {
            px <= ARTWORK_ROW_PX -> 192
            px <= 320 -> 480
            else -> 720
        }
        // Google's image host: everything from "=w" onwards is the crop spec, and it is rewritable.
        val marker = url.lastIndexOf("=w")
        if (marker > 0 && (url.contains("googleusercontent") || url.contains("ytimg"))) {
            return url.substring(0, marker) + "=w" + size + "-h" + size + "-l85-rw"
        }
        // Video thumbnails (i.ytimg.com) name their crop instead of parameterising it. Anything
        // above hqdefault is deliberately not requested: maxresdefault does not exist for most
        // uploads and answers 404, which would cost a wasted round trip per tile.
        if (url.contains("i.ytimg.com")) {
            val name = if (size <= 240) "mqdefault.jpg" else "hqdefault.jpg"
            // The `?sqp=...` crop signature is minted for the file name it came with, so it is
            // dropped along with the name rather than carried over onto a different one.
            val bare = url.substringBefore('?')
            if (YT_THUMB.containsMatchIn(bare)) return YT_THUMB.replace(bare) { "/" + name }
            return url
        }
        // Audius storage nodes: the size is a path segment.
        return AUDIUS_SIZE.replace(url) { "/" + size + "x" + size + ".jpg" }
    }

    private fun fromThumbnail(context: Context, track: TrackEntity, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            context.contentResolver.loadThumbnail(Uri.parse(track.uri), android.util.Size(px, px), null)
        }.getOrNull()
    }

    private suspend fun fromEmbedded(context: Context, track: TrackEntity, px: Int): Bitmap? =
        slowGate.withPermit {
            var guard = 0
            while (isBusy() && guard < 60) { delay(80); guard++ }
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(track.uri))
                        retriever.embeddedPicture
                    } finally {
                        runCatching { retriever.release() }
                    }
                }.getOrNull()
            } ?: return@withPermit null
            decode(bytes, px)
        }

    // ---------------- disk ----------------

    private val hexDigits = "0123456789abcdef".toCharArray()

    /**
     * Cache file names, memoised.
     *
     * The old version ran a full `String.format` per byte - twenty of them - plus a fresh SHA-1
     * instance, and it did that for EVERY track on every isSettled/read/write. On a 3400 track
     * library the indexing pass alone paid it ten thousand times. Manual hex over a memoised
     * digest is roughly two orders of magnitude cheaper and allocates one String per track, once.
     */
    private val nameCache = LruCache<String, String>(4096)

    private fun hashOf(id: String): String {
        nameCache.get(id)?.let { return it }
        val digest = MessageDigest.getInstance("SHA-1").digest(id.toByteArray())
        val chars = CharArray(digest.size * 2)
        for (i in digest.indices) {
            val value = digest[i].toInt() and 0xFF
            chars[i * 2] = hexDigits[value ushr 4]
            chars[i * 2 + 1] = hexDigits[value and 0x0F]
        }
        val hex = String(chars)
        nameCache.put(id, hex)
        return hex
    }

    private fun fileFor(id: String, px: Int): File? {
        val base = dir ?: return null
        return File(base, "${hashOf(id)}-$px.webp")
    }

    private fun readDisk(id: String, px: Int): Bitmap? {
        val file = fileFor(id, px)?.takeIf { it.exists() } ?: return null
        val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
        val bitmap = runCatching { BitmapFactory.decodeFile(file.absolutePath, options) }.getOrNull()
        if (bitmap == null) runCatching { file.delete() }
        return bitmap
    }

    private fun writeDisk(id: String, px: Int, bitmap: Bitmap) {
        val file = fileFor(id, px) ?: return
        runCatching {
            val tmp = File(file.absolutePath + ".tmp")
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            }
            tmp.outputStream().use { bitmap.compress(format, 82, it) }
            if (!tmp.renameTo(file)) tmp.delete()
        }
    }

    private fun prune(base: File) {
        runCatching {
            val files = base.listFiles() ?: return
            var total = files.sumOf { it.length() }
            val cap = 40L * 1024 * 1024
            if (total <= cap) return
            files.sortedBy { it.lastModified() }.forEach { file ->
                if (total <= cap / 2) return
                total -= file.length()
                file.delete()
            }
        }
    }

    private fun decode(bytes: ByteArray, px: Int): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        var sample = 1
        while (largest / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

/**
 * Walks the library in the background and pays the expensive cover probe once per file, writing
 * both the thumbnail and the extracted colours to disk. Pauses whenever a list is being scrolled,
 * so it can never compete with the finger.
 */
object ArtworkPrefetcher {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastTracks: List<TrackEntity> = emptyList()
    private var appContext: Context? = null

    /**
     * Where the user is actually looking. The pass used to start at track 0 and walk to the end,
     * so scrolling to track 2000 meant waiting for 2000 covers you will never see before the ones
     * on screen were even queued - which is why the list "never finished loading" on a big library.
     */
    @Volatile private var focus = 0

    fun focusOn(index: Int) {
        if (index >= 0) focus = index
    }

    fun submit(context: Context, tracks: List<TrackEntity>) {
        job?.cancel()
        if (tracks.isEmpty()) return
        val app = context.applicationContext
        appContext = app
        lastTracks = tracks
        val unmetered = isUnmetered(app)
        job = scope.launch {
            val total = tracks.size
            val taken = BooleanArray(total)
            var processed = 0
            var done = 0
            while (processed < total) {
                if (!isActive) return@launch
                // Re-aimed on every item, not once at the start: the window the user is looking at
                // is always served next, wherever they scrolled to in the meantime.
                val aim = focus.coerceIn(0, total - 1)
                var index = -1
                var probe = aim
                var steps = 0
                while (steps < total) {
                    if (!taken[probe]) { index = probe; break }
                    probe = (probe + 1) % total
                    steps++
                }
                if (index < 0) break
                taken[index] = true
                processed++
                val track = tracks[index]
                // Remote rows are skipped by the background pass. The pass exists to pay for
                // MediaMetadataRetriever once per FILE; a remote row has no file, and letting the
                // indexer walk a saved network library would mean hundreds of cover downloads the
                // user never asked for, on mobile data, in the background. Their covers are
                // fetched by the rows that are actually on screen.
                // 6.24.3. Раньше здесь стояло безусловное `if (track.isRemote) continue`, и
                // для полностью сетевой медиатеки это означало, что фоновый прогрев не делает
                // НИЧЕГО: обложки добывались только теми строками, что прямо сейчас на экране,
                // и на медленном канале не добывались вообще. Опасение в старом комментарии
                // («сотни загрузок на мобильных данных») справедливо — поэтому remote греется
                // только на нелимитированной сети. На Wi-Fi медиатека сходится один раз и
                // навсегда, на мобильном поведение остаётся прежним.
                if (track.isRemote && !unmetered) continue
                if (ArtworkCache.isSettled(track.id)) continue
                while (ArtworkCache.isBusy()) {
                    if (!isActive) return@launch
                    delay(160)
                }
                ArtworkCache.loadIndexed(app, track, ARTWORK_ROW_PX)
                done++
                if (done % 24 == 0) ArtworkCache.flushIndex()
                delay(8)
            }
            ArtworkCache.flushIndex()
            ArtworkCache.pruneNow()
        }
    }

    /**
     * 6.24.3. «Можно ли сейчас тратить байты на то, чего пользователь не просил». Wi-Fi без
     * тарификации — да; мобильный, роуминг, точка доступа с лимитом — нет. Ошибка чтения
     * трактуется как «лимит есть»: тратить чужой трафик по недоразумению хуже, чем не прогреть.
     */
    private fun isUnmetered(context: Context): Boolean = runCatching {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return@runCatching false)
            ?: return@runCatching false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }.getOrDefault(false)

    fun stop() { job?.cancel(); job = null }

    /**
     * Restarts indexing after the app comes back to the foreground. Without this the composition
     * survives backgrounding, the LaunchedEffect never re-runs, and indexing would stay dead for
     * the rest of the process.
     */
    fun resume() {
        val app = appContext ?: return
        if (job?.isActive == true) return
        submit(app, lastTracks)
    }
}

/**
 * Placeholder colours for a track with no cover at all.
 *
 * v5 picked one of eight hardcoded pairs, so in a folder of 400 untagged files every eighth tile
 * was literally the same green. The hue is now derived from the file identity across the full
 * circle: two different tracks share a shade only by accident, and the player backdrop built from
 * this pair is unique too.
 */
fun fallbackSwatches(track: TrackEntity?): ArtSwatches = fallbackSwatchesFor(track?.id)

/**
 * The same deterministic palette, addressable by any stable string.
 *
 * Search results need it before they have a track id: the placeholder a result shows in the list
 * must be the same one it shows in the player two taps later, or the screen flickers colour on
 * every navigation. Keying on the provider's own id makes that automatic.
 */
fun fallbackSwatchesFor(key: String?): ArtSwatches {
    val id = key ?: "zizi"
    var hash = 0x811C9DC5.toInt()
    for (index in id.indices) hash = (hash xor id[index].code) * 0x01000193
    val hue = ((hash ushr 8) % 360 + 360) % 360
    val drift = 18 + ((hash ushr 3) and 0x1F)
    fun hsv(h: Int, s: Float, v: Float) =
        Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360) + 360f) % 360f, s, v)))
    // Neutral BY DESIGN (v6.2). Until now a track with no cover got a fully saturated hue, so an
    // untagged folder turned the library into a paintbox and the player backdrop into lime green.
    // Only a few degrees of hue and a hint of saturation survive: tiles stay distinguishable from
    // each other, the screen still reads as the graphite base.
    return ArtSwatches(
        primary = hsv(hue, 0.11f, 0.44f),
        secondary = hsv(hue + drift, 0.13f, 0.32f),
        deep = hsv(hue - drift / 2, 0.15f, 0.21f)
    )
}

fun fallbackColors(track: TrackEntity?): Pair<Color, Color> {
    val swatches = fallbackSwatches(track)
    return swatches.primary to swatches.deep
}

/**
 * Deliberately NOT produceState.
 *
 * produceState keeps the previous value when its keys change - it only restarts the producer. In a
 * recycled list row, and in the player when the track changes, that means the widget would keep
 * showing the cover of the *previous* track until the new one finished decoding, and if the new
 * track had no cover at all it would show the wrong artwork forever.
 *
 * remember(key) re-seeds synchronously from the in-memory cache instead: a cached cover appears on
 * the very first frame (no grey flash while scrolling) and a cache miss starts exactly one load.
 */
@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int, allowSlow: Boolean = false): Art? {
    val context = LocalContext.current
    val id = track?.id
    val holder = remember(id, maxPx) { mutableStateOf(ArtworkCache.peekExact(track, maxPx)) }
    LaunchedEffect(id, maxPx, allowSlow) {
        val target = track ?: return@LaunchedEffect
        if (holder.value != null) return@LaunchedEffect
        // A track we already know has no cover used to start a full load anyway: 400 coroutines,
        // 400 cache lookups, 400 cancellations per flick, all to return null.
        if (ArtworkCache.hasNoArt(target)) return@LaunchedEffect
        // A row that is only passing under the finger must not decode at all. Rows that are still
        // on screen when the scroll settles decode ~60 ms later; rows that flew past are cancelled
        // by leaving the composition and cost nothing. The guard is bounded so a stuck busy flag
        // can never leave the list grey.
        if (!allowSlow) ArtworkCache.awaitIdle()
        holder.value = ArtworkCache.loadDetached(context, target, maxPx, allowSlow)
    }
    // While a bigger size decodes, the smaller thumbnail of the same cover stands in for it.
    return holder.value ?: ArtworkCache.peek(track, maxPx)
}

/** Colours that drive the whole backdrop. Never blocks: falls back to the per-track hue. */
@Composable
fun rememberArtSwatches(track: TrackEntity?, enabled: Boolean): ArtSwatches? {
    if (!enabled) return null
    val art = rememberArtwork(track, ARTWORK_ROW_PX, allowSlow = true)
    val fallback = remember(track?.id) { fallbackSwatches(track) }
    val cached = ArtworkCache.peekSwatches(track)
    return when {
        art?.swatches != null -> art.swatches
        cached != null -> cached
        track == null -> null
        else -> fallback
    }
}

/**
 * The eighth note that stands in for a missing cover, built out of primitives.
 *
 * Not an ImageVector: a vector drawable is parsed into a node tree and re-rendered per tile, and
 * this is the one glyph in the app that can appear on 3000 rows. Two rounded quads and an ellipse
 * cost one cached Path.
 *
 * Laid out in units of the note's own height inside a 0.86 x 1.0 box, then centred.
 */
private fun notePath(height: Float, canvas: Size): Path {
    val h = height
    val w = h * 0.86f
    val left = (canvas.width - w) / 2f
    val topY = (canvas.height - h) / 2f
    fun x(v: Float) = left + v * h
    fun y(v: Float) = topY + v * h

    return Path().apply {
        // Stem.
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                left = x(0.46f),
                top = y(0.02f),
                right = x(0.57f),
                bottom = y(0.84f),
                radiusX = h * 0.055f,
                radiusY = h * 0.055f
            )
        )
        // Head: an oval, tilted the way a printed note is, which is what makes it read as music
        // rather than as a lollipop.
        addOval(
            androidx.compose.ui.geometry.Rect(
                left = x(0.02f),
                top = y(0.66f),
                right = x(0.50f),
                bottom = y(0.99f)
            )
        )
        // Flag.
        moveTo(x(0.57f), y(0.02f))
        quadraticBezierTo(x(0.90f), y(0.12f), x(0.84f), y(0.42f))
        quadraticBezierTo(x(0.80f), y(0.18f), x(0.57f), y(0.17f))
        close()
    }
}

private fun DrawScope.drawNote(path: Path, color: Color) {
    drawPath(path, color)
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44,
    allowSlow: Boolean = false
) {
    val art = rememberArtwork(track, maxPx, allowSlow)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val colors = remember(track?.id) { fallbackSwatches(track) }
            // 6.5: a music glyph, not a letter.
            //
            // The monogram was a stand-in from v6, and it is the single most obvious "this was
            // never designed" detail in the app: a wall of tiles reading A, K, N, C, P is a
            // debugging aid, not an interface. Every reference player draws a note.
            //
            // It also pays for itself on the scroll path. The letter was a Text, so a row without
            // a cover cost a full text layout - measure, shape, cache lookup - every time it was
            // recycled, and an untagged folder is nothing but rows without covers. The gradient,
            // the path and the colours are now built once per tile SIZE inside drawWithCache: the
            // row draws two cached objects and allocates nothing per frame.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawWithCache {
                        val brush = Brush.linearGradient(
                            listOf(colors.secondary, colors.deep),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height)
                        )
                        // The caller's glyph hint is honoured, but never allowed to grow past a
                        // proportion of the tile: one rule for a 48 dp row and a 300 dp cover.
                        val noteHeight = minOf(size.minDimension * 0.44f, glyphSize.dp.toPx() * 1.5f)
                        val path = notePath(noteHeight, size)
                        val glyphColor = Color.White.copy(alpha = 0.58f)
                        onDrawBehind {
                            drawRect(brush)
                            drawNote(path, glyphColor)
                        }
                    }
            )
        }
    }
}


/**
 * A cover that belongs to a URL rather than to a library row.
 *
 * Deliberately a separate composable from [TrackArtwork] instead of a flag on it. The two have
 * different failure modes and different placeholders: a library row without a cover is settled and
 * will never change, a search result without one is usually just early. Folding them together would
 * mean one of the two cases carrying the other's rules.
 */
@Composable
fun rememberUrlArtwork(url: String?, maxPx: Int): Art? {
    val holder = remember(url, maxPx) { mutableStateOf(ArtworkCache.peekUrl(url, maxPx)) }
    LaunchedEffect(url, maxPx) {
        if (holder.value != null) return@LaunchedEffect
        if (url.isNullOrBlank()) return@LaunchedEffect
        // Same courtesy as the local path: a tile flying past under the finger does not open a
        // socket. Rows still on screen when the flick settles fetch ~60 ms later, and rows that
        // left the composition are cancelled before the request is made.
        ArtworkCache.awaitIdle()
        holder.value = ArtworkCache.loadUrl(url, maxPx)
    }
    return holder.value
}

@Composable
fun RemoteArtwork(
    url: String?,
    seed: String?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44
) {
    val art = rememberUrlArtwork(url, maxPx)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val colors = remember(seed) { fallbackSwatchesFor(seed) }
            Box(
                Modifier
                    .fillMaxSize()
                    .drawWithCache {
                        val brush = Brush.linearGradient(
                            listOf(colors.secondary, colors.deep),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height)
                        )
                        val noteHeight = minOf(size.minDimension * 0.44f, glyphSize.dp.toPx() * 1.5f)
                        val path = notePath(noteHeight, size)
                        val glyphColor = Color.White.copy(alpha = 0.5f)
                        onDrawBehind {
                            drawRect(brush)
                            drawNote(path, glyphColor)
                        }
                    }
            )
        }
    }
}
