"""
zizi_catalog.py — слой каталога для ZiziPlayer.
Метаданные: Spotify (плейлисты/поиск) + Deezer (безключевой запасной).
Звук: НЕ ТРОГАЕМ. Модуль отдаёт youtube_id, дальше работает старый /resolve + /stream.

Ставится рядом с zizi_resolver.py:
    from zizi_catalog import router as catalog_router
    app.include_router(catalog_router)

Переменные окружения (в /opt/zizi/zizi.env):
    ZIZI_SP_ID=...            # Spotify Client ID     (необязательно, без него работает Deezer)
    ZIZI_SP_SECRET=...        # Spotify Client Secret
    ZIZI_CATALOG_DB=/opt/zizi/catalog.db
"""

from __future__ import annotations

import base64
import os
import re
import sqlite3
import subprocess
import time
import json
import threading
from typing import Optional

import requests
from fastapi import APIRouter, HTTPException, Query

router = APIRouter()

SP_ID = os.getenv("ZIZI_SP_ID", "")
SP_SECRET = os.getenv("ZIZI_SP_SECRET", "")
DB_PATH = os.getenv("ZIZI_CATALOG_DB", "/opt/zizi/catalog.db")
UA = "Mozilla/5.0 (Linux; Android 13) ZiziPlayer/7.0"

_db_lock = threading.Lock()


# ---------------------------------------------------------------- база сопоставлений

def _db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    con.execute(
        """CREATE TABLE IF NOT EXISTS match (
               key   TEXT PRIMARY KEY,   -- isrc, либо 'q:artist - title'
               vid   TEXT NOT NULL,
               score REAL,
               ts    INTEGER
           )"""
    )
    return con


def cache_get(key: str) -> Optional[str]:
    with _db_lock, _db() as con:
        row = con.execute("SELECT vid FROM match WHERE key=?", (key,)).fetchone()
    return row[0] if row else None


def cache_put(key: str, vid: str, score: float) -> None:
    with _db_lock, _db() as con:
        con.execute(
            "INSERT OR REPLACE INTO match(key,vid,score,ts) VALUES(?,?,?,?)",
            (key, vid, score, int(time.time())),
        )


# ---------------------------------------------------------------- Spotify (только метаданные)

_sp_tok = {"v": "", "exp": 0.0}


def sp_token() -> str:
    if not (SP_ID and SP_SECRET):
        raise HTTPException(501, "spotify credentials not configured")
    if _sp_tok["v"] and _sp_tok["exp"] > time.time() + 30:
        return _sp_tok["v"]
    basic = base64.b64encode(f"{SP_ID}:{SP_SECRET}".encode()).decode()
    r = requests.post(
        "https://accounts.spotify.com/api/token",
        data={"grant_type": "client_credentials"},
        headers={"Authorization": f"Basic {basic}"},
        timeout=12,
    )
    r.raise_for_status()
    j = r.json()
    _sp_tok["v"] = j["access_token"]
    _sp_tok["exp"] = time.time() + float(j.get("expires_in", 3600))
    return _sp_tok["v"]


def sp_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.spotify.com/v1/{path}",
        headers={"Authorization": f"Bearer {sp_token()}"},
        params=params,
        timeout=15,
    )
    if r.status_code == 429:
        raise HTTPException(429, f"spotify rate limit, retry after {r.headers.get('Retry-After','?')}s")
    r.raise_for_status()
    return r.json()


def sp_track(t: dict) -> dict:
    return {
        "src": "spotify",
        "id": t.get("id"),
        "isrc": (t.get("external_ids") or {}).get("isrc"),
        "title": t.get("name"),
        "artist": ", ".join(a["name"] for a in t.get("artists", [])),
        "album": (t.get("album") or {}).get("name"),
        "dur": int((t.get("duration_ms") or 0) / 1000),
        "art": next((i["url"] for i in ((t.get("album") or {}).get("images") or [])), None),
    }


# ---------------------------------------------------------------- Deezer (без ключа, запасной)

def dz_track(t: dict) -> dict:
    return {
        "src": "deezer",
        "id": str(t.get("id")),
        "isrc": t.get("isrc"),
        "title": t.get("title"),
        "artist": (t.get("artist") or {}).get("name"),
        "album": (t.get("album") or {}).get("title"),
        "dur": int(t.get("duration") or 0),
        "art": (t.get("album") or {}).get("cover_big"),
    }


def dz_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.deezer.com/{path}",
        params=params,
        headers={"User-Agent": UA},
        timeout=15,
    )
    r.raise_for_status()
    j = r.json()
    if isinstance(j, dict) and "error" in j:
        e = j["error"]
        raise HTTPException(502, f"deezer: {e.get('type')} {e.get('message')}")
    return j


def dz_search(q: str, limit: int, offset: int = 0) -> list[dict]:
    j = dz_get("search", q=q, limit=limit, index=offset)
    return [dz_track(t) for t in j.get("data", [])]


# ---------------------------------------------------------------- сопоставление -> youtube_id

_PAREN = re.compile(r"\((?:official|lyric|audio|video|hd|mv)[^)]*\)", re.I)
_JUNK = re.compile(r"\b(official|video|audio|lyrics?|hd|4k|mv|remaster(ed)?)\b", re.I)


def _norm(s: str) -> str:
    s = _PAREN.sub(" ", s or "")
    s = _JUNK.sub(" ", s)
    return re.sub(r"[^\w\s]", " ", s.lower()).strip()


def yt_search(query: str, n: int = 6) -> list[dict]:
    """Плоский поиск через yt-dlp. Без скачивания, только метаданные."""
    cmd = [
        "yt-dlp", "--quiet", "--no-warnings", "--flat-playlist",
        "--dump-json", "--extractor-args", "youtube:player_skip=configs",
        f"ytsearch{n}:{query}",
    ]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
    res = []
    for line in out.stdout.splitlines():
        try:
            j = json.loads(line)
        except Exception:
            continue
        res.append({
            "vid": j.get("id"),
            "title": j.get("title") or "",
            "uploader": j.get("uploader") or j.get("channel") or "",
            "dur": int(j.get("duration") or 0),
        })
    return res


def score(cand: dict, title: str, artist: str, dur: int) -> float:
    """Длительность — главный критерий. Каналы '- Topic' это официальное аудио от лейбла."""
    s = 0.0
    if dur and cand["dur"]:
        d = abs(cand["dur"] - dur)
        if d <= 2:
            s += 50
        elif d <= 5:
            s += 35
        elif d <= 12:
            s += 10
        else:
            s -= 40          # не тот трек: лайв, ремикс, час музыки
    ct, nt, na = _norm(cand["title"]), _norm(title), _norm(artist)
    if nt and nt in ct:
        s += 25
    if na and (na in ct or na in _norm(cand["uploader"])):
        s += 20
    if cand["uploader"].endswith("- Topic"):
        s += 30
    if re.search(r"\b(live|cover|remix|sped up|slowed|nightcore|8d|karaoke)\b", ct):
        s -= 25
    if re.search(r"\b(lyric|lyrics|visualizer)\b", (cand["title"] or "").lower()):
        s -= 10          # перезалив: своя громкость, часто интро. Уступает Topic, но лучше чем ничего
    return s


def match_track(title: str, artist: str, dur: int, isrc: str = "") -> dict:
    key = isrc or f"q:{_norm(artist)} - {_norm(title)}"
    hit = cache_get(key)
    if hit:
        return {"vid": hit, "cached": True, "key": key}

    # Три захода. Официальное аудио лейбла ('- Topic') почти никогда не всплывает
    # в обычной выдаче — его надо просить отдельно, иначе выигрывают лирик-видео.
    cands: list[dict] = []
    if isrc:
        cands += yt_search(f'"{isrc}"', 3)
    cands += yt_search(f"{artist} - Topic {title}", 5)
    cands += yt_search(f"{artist} {title}", 6)

    seen: set[str] = set()
    best, best_s = None, -1e9
    for c in cands:
        if not c["vid"] or c["vid"] in seen:
            continue
        seen.add(c["vid"])
        sc = score(c, title, artist, dur)
        if sc > best_s:
            best, best_s = c, sc

    if not best or best_s < 20:
        raise HTTPException(404, "no confident match")
    cache_put(key, best["vid"], best_s)
    return {"vid": best["vid"], "cached": False, "key": key, "score": best_s,
            "picked": best["title"], "by": best["uploader"]}


# ---------------------------------------------------------------- эндпоинты

@router.get("/catalog/search")
def catalog_search(q: str, limit: int = Query(20, le=50), offset: int = 0, src: str = "auto"):
    if src in ("spotify", "auto") and SP_ID:
        try:
            j = sp_get("search", q=q, type="track", limit=limit)
            return {"src": "spotify", "items": [sp_track(t) for t in j["tracks"]["items"]]}
        except HTTPException:
            if src == "spotify":
                raise
    return {"src": "deezer", "offset": offset, "items": dz_search(q, limit, offset)}


@router.get("/catalog/playlist")
def catalog_playlist(id: str, limit: int = Query(100, le=300), offset: int = 0,
                     src: str = "auto"):
    """Плейлист по id. Deezer — без ключей; Spotify — только если заданы ZIZI_SP_ID/SECRET."""
    if src == "spotify" or (src == "auto" and SP_ID and not id.isdigit()):
        j = sp_get(f"playlists/{id}/tracks", limit=min(limit, 100), offset=offset)
        items = [sp_track(it["track"]) for it in j.get("items", []) if it.get("track")]
        return {"src": "spotify", "total": j.get("total"), "offset": offset, "items": items}
    j = dz_get(f"playlist/{id}/tracks", limit=limit, index=offset)
    return {"src": "deezer", "total": j.get("total"), "offset": offset,
            "items": [dz_track(t) for t in j.get("data", [])]}


@router.get("/catalog/album")
def catalog_album(id: str):
    """Альбом Deezer целиком. У треков в этой выдаче нет isrc — сопоставление пойдёт по artist+title+dur."""
    j = dz_get(f"album/{id}")
    art = j.get("cover_big")
    items = []
    for t in (j.get("tracks") or {}).get("data", []):
        d = dz_track(t)
        d["album"] = j.get("title")
        d["art"] = d["art"] or art
        items.append(d)
    return {"src": "deezer", "album": j.get("title"),
            "artist": (j.get("artist") or {}).get("name"), "art": art, "items": items}


@router.get("/catalog/artist")
def catalog_artist(id: str, limit: int = Query(50, le=100)):
    """Топ-треки артиста — то, чем в Спотифае открывается страница исполнителя."""
    j = dz_get(f"artist/{id}/top", limit=limit)
    return {"src": "deezer", "items": [dz_track(t) for t in j.get("data", [])]}


@router.get("/catalog/chart")
def catalog_chart(limit: int = Query(50, le=100)):
    """Главный экран: чарт треков + подборка плейлистов. Ничего не требует."""
    j = dz_get("chart", limit=limit)
    return {
        "src": "deezer",
        "tracks": [dz_track(t) for t in (j.get("tracks") or {}).get("data", [])],
        "playlists": [
            {"id": str(p["id"]), "title": p.get("title"), "art": p.get("picture_big"),
             "n": p.get("nb_tracks")}
            for p in (j.get("playlists") or {}).get("data", [])
        ],
        "artists": [
            {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
            for a in (j.get("artists") or {}).get("data", [])
        ],
    }


@router.get("/catalog/similar")
def catalog_similar(id: str, limit: int = Query(30, le=100)):
    """«Похожие артисты» — основа радио и автоплея."""
    j = dz_get(f"artist/{id}/related", limit=limit)
    return {"src": "deezer", "items": [
        {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
        for a in j.get("data", [])
    ]}


@router.get("/match")
def match(title: str, artist: str, dur: int = 0, isrc: str = ""):
    """Сердце гибрида: метаданные -> youtube_id. Дальше клиент идёт в /resolve?id=<vid>."""
    return match_track(title, artist, dur, isrc)


@router.get("/match/deezer")
def match_deezer(id: str):
    """Сопоставление по одному лишь id каталога.

    Клиент на этом этапе знает только remoteId, поэтому метаданные (и, главное, ISRC)
    добираем здесь: `track/{id}` отдаёт их всегда, в отличие от выдачи альбома и плейлиста.
    """
    d = dz_track(dz_get(f"track/{id}"))
    r = match_track(d["title"], d["artist"], d["dur"], d["isrc"] or "")
    r["meta"] = d
    return r


@router.get("/catalog/health")
def catalog_health():
    with _db_lock, _db() as con:
        n = con.execute("SELECT COUNT(*) FROM match").fetchone()[0]
    return {"ok": True, "spotify": bool(SP_ID), "deezer": True, "matches_cached": n}
