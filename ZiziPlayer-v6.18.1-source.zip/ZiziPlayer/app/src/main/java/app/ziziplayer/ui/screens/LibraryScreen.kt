package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.ScanProgress
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.FolderInfo
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import app.ziziplayer.ui.components.formatTotalTime
import app.ziziplayer.ui.components.trackCountLabel

/**
 * Row metrics measured off the reference player: 48 dp cover, 8 dp corner, 62 dp row pitch.
 * v5 used a 52 dp cover inside a 66 dp row with a 13 dp radius, which is why the list looked
 * heavier and less dense than the reference.
 */
// Geometry lifted off the reference screenshot rather than eyeballed. The shot is 576 px wide on a
// 360 dp screen, i.e. 1.6 px/dp: row pitch measured 90 px = 56 dp (we were at 62), artwork 76 px =
// 48 dp (already right), corner radius ~10 px = 6 dp (we were at 8), right icon inset 32 px = 20 dp.
private val rowShape = RoundedCornerShape(8.dp)
private val artShape = RoundedCornerShape(6.dp)
private val ROW_HEIGHT = 56.dp
private val ART_SIZE = 48.dp
private val MINI_HEIGHT = 46.dp

/**
 * 6.18.0 — фиксированная высота шапки.
 *
 * Дёрганье при входе в выбор было не «анимации не хватает», а честный скачок раскладки: обычная
 * шапка складывалась из кнопок 44 dp и отступов 10/6 (62 dp), шапка выбора — из кнопок 42 dp
 * (58 dp), и в момент подмены весь экран прыгал на 4 dp вверх, а следом на ~52 dp ещё раз, потому
 * что мгновенно исчезал ряд фильтров. Теперь высота шапки одна и та же всегда, содержимое внутри
 * меняется перекрёстным затуханием, а ряд фильтров не пропадает, а сворачивается по той же кривой.
 */
private val HEADER_HEIGHT = 62.dp
private const val SELECTION_MS = 190

/**
 * 6.18.1 — правый слот строки.
 *
 * Ширина ровно 38 + 34 = 72 dp, то есть сумма кнопок «сердце» и «⋮». Кружок выбора рисуется в
 * той же коробке 34 dp, что и «⋮», и прижат к правому краю, поэтому его центр совпадает с центром
 * «⋮» до пикселя: при входе в выбор ничего не переезжает по горизонтали.
 */
private val TRAILING_W = 72.dp
private val TRAILING_SLOT = 34.dp

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onOpenPlayer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    var menuTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var renamePlaylistId by remember { mutableStateOf<Long?>(null) }
    // 6.15.0: обмен плейлистами.
    var sharePlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    // 6.17.0: множественный выбор, меню папки и подтверждение удаления плейлиста.
    var confirmDeletePlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var folderMenu by remember { mutableStateOf<String?>(null) }
    var selectionMenu by remember { mutableStateOf(false) }
    /** Не null — открыт выбор плейлиста для выделенного; true = переносим, false = копируем. */
    var selectionTarget by remember { mutableStateOf<Boolean?>(null) }
    val selected by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode = selected.isNotEmpty()
    var importSource by remember { mutableStateOf(false) }
    var pasting by remember { mutableStateOf(false) }
    // Системный выбор файла — путь, который работает всегда, в отличие от intent-filter: не всякий
    // провайдер отдаёт имя файла в пути, а значит не всякий .zizi долетит до нашего фильтра.
    val pickPlaylistFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.offerImportFile(uri)
    }

    val listState = rememberLazyListState()
    val context = LocalContext.current
    // Короткий отклик в момент входа в выбор. Долгое нажатие — единственный жест приложения без
    // видимого «нажалось»: без вибрации человек не понимает, сработало или он просто держит палец.
    val haptics = LocalHapticFeedback.current

    // While the finger is moving, nothing expensive may start.
    //
    // v5 collected the scroll offset itself, which allocated a Pair on every single frame of every
    // scroll. One boolean and a 120 ms heartbeat do the same job for free.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collectLatest { scrolling ->
            while (scrolling) {
                ArtworkCache.markBusy()
                ArtworkPrefetcher.focusOn(listState.firstVisibleItemIndex)
                delay(120)
            }
        }
    }

    // ...and where they stopped. Without this, scrolling to track 2000 left the indexer grinding
    // through tracks 0..1999 first - covers you will never look at - so the rows in front of you
    // stayed grey for minutes on a big library.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .collectLatest { first ->
                ArtworkPrefetcher.focusOn(first)
            }
    }

    // Covers are indexed in the background, once per file, and persisted to disk. This is what
    // makes the second launch instant and keeps MediaMetadataRetriever away from the scroll.
    // Keyed on a cheap signature instead of the list identity: toggling a favourite rebuilds the
    // list object, and restarting the whole indexing pass for that would be pure waste.
    val prefetchKey = state.visible.size to state.visible.firstOrNull()?.id
    LaunchedEffect(prefetchKey) {
        delay(450)
        ArtworkPrefetcher.submit(context, state.visible)
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Шапка выбора ЗАМЕЩАЕТ обычную, а не встаёт над ней: экран не должен прыгать вниз на
        // 56 dp в момент, когда человек только что попал пальцем по строке.
        //
        // 6.18.0: обе шапки живут в контейнере постоянной высоты и меняются Crossfade'ом. Высота
        // не пересчитывается вообще, поэтому ни список, ни мини-плеер под ним не двигаются —
        // человек видит только смену содержимого, а не перестройку экрана.
        Box(Modifier.fillMaxWidth().height(HEADER_HEIGHT)) {
            Crossfade(
                targetState = selectionMode,
                animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
                label = "library-header"
            ) { picking ->
                if (picking) {
                    SelectionHeader(
                        count = selected.size,
                        allSelected = state.visible.isNotEmpty() && selected.containsAll(state.visible.map { it.id }),
                        onClose = vm::clearSelection,
                        onSelectAll = vm::toggleSelectAllVisible,
                        onPlay = vm::playSelected,
                        onFavorite = vm::favoriteSelected,
                        onAdd = { selectionTarget = false },
                        onMore = { selectionMenu = true }
                    )
                } else {
                    LibraryHeader(
                        state = state,
                        onSearch = { vm.setSearchOpen(!state.searchOpen) },
                        onQuery = vm::setQuery,
                        onShuffle = vm::shuffleAll,
                        onSettings = { showSettings = true },
                        onBack = { vm.handleBack() }
                    )
                }
            }
        }

        // Фильтры не исчезают кадром, а сворачиваются по высоте той же длительностью, что и
        // затухание шапки: список уезжает вверх плавно и ровно один раз.
        AnimatedVisibility(
            visible = !state.isDrilledIn && !selectionMode,
            enter = expandVertically(tween(SELECTION_MS, easing = FastOutSlowInEasing)) +
                fadeIn(tween(SELECTION_MS, easing = FastOutSlowInEasing)),
            exit = shrinkVertically(tween(SELECTION_MS, easing = FastOutSlowInEasing)) +
                fadeOut(tween(SELECTION_MS / 2, easing = FastOutSlowInEasing))
        ) {
            Column {
                FilterRow(state.filter) { vm.setFilter(it) }
                Spacer(Modifier.height(4.dp))
            }
        }

        Box(Modifier.weight(1f)) {
            when {
                state.loading -> CenterNote("Загружаем библиотеку…")
                state.filter == LibraryFilter.PLAYLISTS && state.openPlaylist == null ->
                    PlaylistList(
                        state = state,
                        onOpen = vm::openPlaylist,
                        onRename = { renamePlaylistId = it },
                        // 6.17.0: удаление плейлиста больше не мгновенное. Пять добавленных треков
                        // и один промах по иконке корзины стоили тестеру всего плейлиста разом.
                        onDelete = { id -> confirmDeletePlaylist = state.playlists.firstOrNull { it.id == id } },
                        onCreate = { vm.createPlaylist(it) },
                        onShare = { sharePlaylist = it },
                        onImport = { importSource = true }
                    )
                state.filter == LibraryFilter.FOLDERS && state.openFolder == null ->
                    FolderList(
                        folders = state.folders,
                        settingsFolders = remember(state.settings.folderUris) { state.settings.folderUris.toList() },
                        onOpen = vm::openFolder,
                        onAdd = onPickFolder,
                        onRemove = vm::removeFolder,
                        onMenu = { folderMenu = it }
                    )
                state.visible.isEmpty() -> CenterNote(
                    when {
                        state.query.isNotBlank() -> "Ничего не найдено"
                        state.filter == LibraryFilter.FAVORITES -> "Пока нет избранных треков"
                        else -> "Треков нет. Добавь папку через «Папки»"
                    }
                )
                else -> {
                    // These lambdas used to be allocated fresh on every recomposition, which made
                    // every single row unstable: one state change repainted the whole list.
                    val visible = state.visible
                    val onPlay = remember(visible) { { track: TrackEntity -> vm.play(track, visible) } }
                    val onMenu = remember { { track: TrackEntity -> menuTrack = track } }
                    TrackList(
                        listState = listState,
                        tracks = visible,
                        favoriteIds = state.favoriteIds,
                        currentTrackId = playback.currentTrackId,
                        isPlaying = playback.isPlaying,
                        hasMiniPlayer = true,
                        onPlay = onPlay,
                        onFavorite = vm::toggleFavorite,
                        onMenu = onMenu,
                        selected = selected,
                        selectionMode = selectionMode,
                        onToggleSelect = { track -> vm.toggleSelected(track.id) },
                        onLongPress = { track ->
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            vm.startSelection(track.id)
                        },
                        // Итог списка внизу, как в VK: цифра нужна ровно в тот момент, когда
                        // человек долистал плейлист до конца и спрашивает себя «а сколько тут».
                        footer = if (state.isDrilledIn || state.filter == LibraryFilter.FAVORITES)
                            trackCountLabel(visible.size) + " · " + formatTotalTime(state.visibleMs)
                        else null
                    )
                }
            }

            if (state.scanning) {
                // Collected here, not lifted into LibraryUiState: see MainViewModel.scanProgress.
                val progress by vm.scanProgress.collectAsStateWithLifecycle()
                ScanningBadge(progress, Modifier.align(Alignment.TopCenter))
            }
        }

        // The mini player and the tab bar used to be drawn here, at the bottom of the library.
        // They are now drawn once by the host (see ZiziApp) because they belong to the APP, not to
        // this screen: the moment there is a second destination, a bar owned by one of them either
        // disappears when you leave it or gets duplicated on the other. The parameters stay -
        // `currentTrack` still decides the list's bottom inset - so nothing else in this file moved.
    }

    menuTrack?.let { track ->
        TrackMenuSheet(
            favorite = state.favoriteIds.contains(track.id),
            // 6.18.0: настоящий счётчик вместо константы — статистика в базе была, в меню не доходила.
            plays = state.stats[track.id]?.playCount ?: 0,
            sleepMinutesLeft = playback.sleepMinutesLeft,
            track = track,
            inPlaylist = state.openPlaylist,
            onDismiss = { menuTrack = null },
            onFx = { menuTrack = null; vm.play(track, state.visible); onOpenPlayer() },
            onSleep = { menuTrack = null },
            onAddToPlaylist = { menuTrack = null; playlistTarget = track },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                menuTrack = null
            },
            onToggleFavorite = { vm.toggleFavorite(track); menuTrack = null },
            onHide = { vm.removeFromApp(track); menuTrack = null },
            onDeleteFile = { menuTrack = null; confirmDelete = track },
            onShare = { onShare(track); menuTrack = null }
        )
    }
    playlistTarget?.let { track ->
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id); playlistTarget = null },
            onCreate = { vm.createPlaylist(it, listOf(track)); playlistTarget = null },
            onDismiss = { playlistTarget = null }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Отменить это будет нельзя.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
    if (showSettings) SettingsSheet(vm, state, { showSettings = false }, onPickFolder)
    renamePlaylistId?.let { id ->
        val playlist = state.playlists.firstOrNull { it.id == id }
        if (playlist == null) renamePlaylistId = null
        else RenameDialog(
            initial = playlist.name,
            onConfirm = { vm.renamePlaylist(id, it); renamePlaylistId = null },
            onDismiss = { renamePlaylistId = null }
        )
    }
    sharePlaylist?.let { playlist ->
        PlaylistShareSheet(vm, playlist) { sharePlaylist = null }
    }
    if (importSource) ImportSourceDialog(
        // MIME берём широкий: половина файловых менеджеров отдаёт .zizi как octet-stream,
        // другая половина — как text/plain, и фильтр по типу отрезал бы половину пользователей.
        onFile = { pickPlaylistFile.launch(arrayOf("*/*")) },
        onPaste = { pasting = true },
        onDismiss = { importSource = false }
    )
    if (pasting) PastePlaylistDialog(
        onConfirm = { vm.offerImport(it) },
        onDismiss = { pasting = false }
    )

    /* ------------------------------------------------------------------ 6.17.0 ---- */

    confirmDeletePlaylist?.let { playlist ->
        val count = state.playlistMeta[playlist.id]?.count ?: 0
        ConfirmDialog(
            title = "Удалить плейлист?",
            message = if (count == 0) "«${playlist.name}» пуст — удалить его?"
            else "«${playlist.name}» и ${trackCountLabel(count)} внутри. Сами треки останутся в медиатеке, но порядок и состав плейлиста вернуть будет нельзя.",
            confirm = "Удалить",
            onConfirm = { vm.deletePlaylist(playlist.id); confirmDeletePlaylist = null },
            onDismiss = { confirmDeletePlaylist = null }
        )
    }

    folderMenu?.let { folder ->
        val tracks = remember(folder, state.tracks) { state.tracks.filter { it.sourceFolder == folder } }
        FolderMenuSheet(
            folder = folder,
            count = tracks.size,
            remote = tracks.isNotEmpty() && tracks.all { it.isRemote },
            onOpenSelection = {
                vm.openFolder(folder)
                tracks.firstOrNull()?.let { vm.startSelection(it.id) }
                folderMenu = null
            },
            onMoveAll = { vm.openFolder(folder); selectionTarget = true; folderMenu = null },
            onDismiss = { folderMenu = null }
        )
    }

    if (selectionMenu) {
        SelectionMenuSheet(
            count = selected.size,
            inPlaylist = state.openPlaylist,
            onMove = { selectionMenu = false; selectionTarget = true },
            onRemoveFromPlaylist = { selectionMenu = false; vm.removeSelectedFromPlaylist() },
            onUnsave = { selectionMenu = false; vm.unsaveSelected() },
            onHide = { selectionMenu = false; vm.hideSelected() },
            onDismiss = { selectionMenu = false }
        )
    }

    selectionTarget?.let { move ->
        // Один и тот же лист и для «добавить», и для «перенести»: разница только в подписи и в
        // том, что перенос убирает треки из источника.
        val fromFolder = state.openFolder
        val ids = remember(selected, state.visible, fromFolder) {
            if (selected.isNotEmpty()) state.visible.filter { selected.contains(it.id) }.map { it.id }
            else state.visible.map { it.id }
        }
        PlaylistPickerSheet(
            playlists = state.playlists,
            title = if (move) "Перенести в плейлист" else "Добавить в плейлист",
            subtitle = trackCountLabel(ids.size) +
                if (move && fromFolder != null) " · из папки «$fromFolder»" else "",
            defaultName = state.openPlaylist?.name ?: fromFolder.orEmpty(),
            onPick = { id ->
                vm.addTracksToPlaylist(id, ids, move, state.openPlaylist?.id)
                selectionTarget = null
            },
            onCreate = { name ->
                vm.createPlaylistWithTracks(name, ids, move, state.openPlaylist?.id)
                selectionTarget = null
            },
            onDismiss = { selectionTarget = null }
        )
    }
}

/**
 * Шапка режима выбора (6.17.0).
 *
 * Пять действий и ни одного скрытого: сыграть, в избранное, в плейлист, «ещё» (перенос и три вида
 * удаления) и выход. Всё, что удаляет, живёт под «ещё» намеренно — рядом с «в плейлист» им не
 * место, промах пальцем там стоит дороже одного лишнего тапа.
 */
@Composable
private fun SelectionHeader(
    count: Int,
    allSelected: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onAdd: () -> Unit,
    onMore: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(HEADER_HEIGHT)
            .padding(start = 8.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(Icons.Filled.Close, p.text, Color.Transparent, 42, 22, onClose)
        Text(
            text = "Выбрано $count",
            color = p.text,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            modifier = Modifier.weight(1f).padding(start = 4.dp)
        )
        RoundIconButton(
            icon = if (allSelected) Icons.Filled.CheckBox else Icons.Filled.SelectAll,
            tint = p.text, background = Color.Transparent, size = 42, iconSize = 21, onClick = onSelectAll
        )
        RoundIconButton(Icons.Rounded.PlayArrow, p.text, Color.Transparent, 42, 23, onPlay)
        RoundIconButton(Icons.Filled.FavoriteBorder, p.text, Color.Transparent, 42, 21, onFavorite)
        RoundIconButton(Icons.Filled.PlaylistAdd, p.accent, Color.Transparent, 42, 23, onAdd)
        RoundIconButton(Icons.Filled.MoreVert, p.text, Color.Transparent, 38, 20, onMore)
    }
}

@Composable
private fun LibraryHeader(
    state: LibraryUiState,
    onSearch: () -> Unit,
    onQuery: (String) -> Unit,
    onShuffle: () -> Unit,
    onSettings: () -> Unit,
    onBack: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(HEADER_HEIGHT)
            .padding(start = 18.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state.isDrilledIn) {
            RoundIconButton(
                icon = Icons.AutoMirrored.Filled.ArrowBack,
                tint = p.text,
                background = Color.Transparent,
                size = 40,
                iconSize = 24,
                onClick = onBack
            )
            Spacer(Modifier.width(4.dp))
        }
        if (state.searchOpen) {
            // The field owns its text.
            //
            // v4 fed the field from the library flow: every character travelled to the ViewModel,
            // through the whole combine pipeline and back, so characters arrived late or vanished
            // and the entire library was refiltered on each keystroke. Now typing is instant and
            // the query is only published once the finger has rested for 130 ms.
            var text by remember { mutableStateOf(state.query) }
            LaunchedEffect(text) {
                delay(130)
                if (text != state.query) onQuery(text)
            }
            Row(
                Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.chip.copy(alpha = 0.75f))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = TextStyle(color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(p.accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (text.isEmpty()) {
                                Text("Поиск по трекам", color = p.subtext, fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            }
            RoundIconButton(Icons.Filled.Close, p.text, Color.Transparent, 44, 24, onSearch)
        } else {
            Text(
                text = state.openPlaylist?.name ?: state.openFolder ?: "Zizi",
                color = p.text,
                fontSize = if (state.isDrilledIn) 20.sp else 27.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            RoundIconButton(Icons.Filled.Search, p.text, Color.Transparent, 44, 24, onSearch)
            RoundIconButton(ZiziIcons.Shuffle, p.text, Color.Transparent, 44, 24, onShuffle)
            RoundIconButton(Icons.Filled.Tune, p.text, Color.Transparent, 44, 24, onSettings)
        }
    }
}

@Composable
private fun FilterRow(current: LibraryFilter, onPick: (LibraryFilter) -> Unit) {
    val p = LocalPalette.current
    val chipColors = remember(p.chip, p.text, p.accent, p.onAccent) {
        ChipColors(p.chip, p.text, p.accent, p.onAccent)
    }
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PillChip("Треки", null, current == LibraryFilter.TRACKS, chipColors, { onPick(LibraryFilter.TRACKS) }) }
        item { PillChip("Избранное", null, current == LibraryFilter.FAVORITES, chipColors, { onPick(LibraryFilter.FAVORITES) }) }
        item { PillChip("Плейлисты", null, current == LibraryFilter.PLAYLISTS, chipColors, { onPick(LibraryFilter.PLAYLISTS) }) }
        item { PillChip("Папки", null, current == LibraryFilter.FOLDERS, chipColors, { onPick(LibraryFilter.FOLDERS) }) }
    }
}

@Composable
private fun TrackList(
    listState: androidx.compose.foundation.lazy.LazyListState,
    tracks: List<TrackEntity>,
    favoriteIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    hasMiniPlayer: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit,
    selected: Set<String> = emptySet(),
    selectionMode: Boolean = false,
    onToggleSelect: (TrackEntity) -> Unit = {},
    onLongPress: (TrackEntity) -> Unit = {},
    footer: String? = null
) {
    val p = LocalPalette.current
    // Вход в режим выбора анимируется ОДНИМ числом на весь список.
    //
    // В 6.18.0 у каждой строки был свой Crossfade: двенадцать видимых строк заводили двенадцать
    // переходов, держали по два поддерева и по три анимации каждая — и всё это в том самом кадре,
    // где палец только что отпустил долгое нажатие. Кадры не успевали, кружки «дёргались».
    // Теперь анимация одна, а строки читают её на фазе отрисовки слоя (graphicsLayer), то есть при
    // переходе не происходит ни одной рекомпозиции списка.
    val pick = animateFloatAsState(
        targetValue = if (selectionMode) 1f else 0f,
        animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
        label = "selection-progress"
    )
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 10.dp, end = 8.dp, top = 2.dp, bottom = if (hasMiniPlayer) 8.dp else 20.dp)
    ) {
        items(
            items = tracks,
            key = { it.id },
            contentType = { "track" }
        ) { track ->
            // Only primitives are passed down, so a row recomposes exclusively when ITS state changes.
            TrackRow(
                track = track,
                favorite = favoriteIds.contains(track.id),
                current = track.id == currentTrackId,
                playing = isPlaying && track.id == currentTrackId,
                onPlay = onPlay,
                onFavorite = onFavorite,
                onMenu = onMenu,
                selectionMode = selectionMode,
                pick = pick,
                selected = selected.contains(track.id),
                onToggleSelect = onToggleSelect,
                onLongPress = onLongPress
            )
        }
        if (footer != null) {
            item(key = "footer", contentType = "footer") {
                Text(
                    text = footer,
                    color = p.subtext,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp, start = 6.dp)
                )
            }
        }
    }
}

private val rowArtistStyle = TextStyle(fontSize = 13.5.sp, fontWeight = FontWeight.Normal)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    track: TrackEntity,
    favorite: Boolean,
    current: Boolean,
    playing: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit,
    selectionMode: Boolean = false,
    /** Общий на весь список прогресс входа в выбор: 0 — обычные кнопки, 1 — кружок. */
    pick: State<Float>,
    selected: Boolean = false,
    onToggleSelect: (TrackEntity) -> Unit = {},
    onLongPress: (TrackEntity) -> Unit = {}
) {
    val p = LocalPalette.current
    val accentColor = p.accent
    // Единственная анимация самой строки, и заводится она только когда меняется ЕЁ галочка.
    // Тем же числом рисуется и кружок: заливка, «щелчок» масштаба и цвет — одно значение.
    val mark = animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
        label = "row-mark"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(ROW_HEIGHT)
            .clip(rowShape)
            // Долгое нажатие входит в выбор, обычное — играет; в режиме выбора обычное нажатие
            // переключает галочку. Ровно так ведёт себя любая галерея, и учить этому не нужно.
            .combinedClickable(
                onClick = { if (selectionMode) onToggleSelect(track) else onPlay(track) },
                onLongClick = { onLongPress(track) }
            )
            // Подсветка выбранной строки въезжает цветом, а не подменяется кадром: при быстром
            // проставлении галочек список перестаёт мигать. Читается в .drawBehind, то есть на
            // фазе отрисовки: строка НЕ рекомпозится 11 кадров подряд ради заливки фона.
            .drawBehind {
                val a = mark.value
                if (a > 0f) drawRect(color = accentColor, alpha = 0.16f * a)
            }
            .padding(start = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // One clip for the whole tile instead of one per child (6.5). A rounded clip is a
        // graphics layer, and the playing row was paying for three of them - artwork, scrim and
        // the tile itself - on every frame of a scroll it appeared in.
        Box(Modifier.size(ART_SIZE).clip(artShape)) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier.fillMaxSize(),
                glyphSize = 18
            )
            // 6.14.0: тот же самый маркер, что в поиске и очереди, а не его копия. Раньше здесь
            // лежал свой затемняющий Box со своим эквалайзером — правило «строка показывает
            // состояние» жило в трёх местах и в одном из них разъехалось. Размер полосок оставлен
            // прежним (17.dp), чтобы строка медиатеки визуально не менялась.
            NowPlayingBadge(
                current = current,
                playing = playing,
                size = ART_SIZE,
                corner = 6.dp,
                barSize = 17.dp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            TrackTitle(
                title = track.title,
                color = if (current) p.accent else p.text,
                dim = if (current) p.accent.copy(alpha = 0.55f) else p.text.copy(alpha = 0.42f),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(1.dp))
            // Style hoisted to a file-level constant: passing fontSize/fontWeight makes Text
            // merge a fresh TextStyle on every composition, and this line exists 3000 times.
            Text(
                text = track.artist,
                color = p.subtext,
                style = rowArtistStyle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        // Правый край строки — слот постоянной ширины (6.18.1).
        //
        // Оба состояния лежат в раскладке ВСЕГДА и никогда не пересобираются: меняется только
        // альфа их слоёв. Ни Crossfade, ни появления/исчезновения узлов, ни рекомпозиции — поэтому
        // вход в выбор стоит ровно один кадр разметки и дальше едет на композиторе.
        //
        // Кружок стоит в коробке 34 dp у правого края — там же, где центр «⋮». Раньше он
        // центрировался по всему слоту (74 dp), то есть вылезал ровно между «сердцем» и «⋮», и
        // перекрёстное затухание двух картинок в разных точках читалось как рывок.
        Box(Modifier.width(TRAILING_W)) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .graphicsLayer { alpha = 1f - pick.value },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(
                    icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    tint = if (favorite) p.accent else p.subtext,
                    background = Color.Transparent,
                    size = 38,
                    iconSize = 19,
                    onClick = { onFavorite(track) }
                )
                RoundIconButton(
                    icon = Icons.Filled.MoreVert,
                    tint = p.subtext,
                    background = Color.Transparent,
                    size = 34,
                    iconSize = 18,
                    onClick = { onMenu(track) }
                )
            }
            SelectDot(
                mark = mark,
                ring = p.subtext,
                accent = p.accent,
                onAccent = p.onAccent,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(TRAILING_SLOT)
                    .graphicsLayer { alpha = pick.value }
            )
            // В режиме выбора весь слот — одна большая мишень «переключить», и она же закрывает
            // невидимые «сердце» и «⋮»: попасть в чужое действие пальцем стало нечем. Узел
            // добавляется один раз на переключение режима, а не каждый кадр.
            if (selectionMode) {
                val slotTap = remember { MutableInteractionSource() }
                Spacer(
                    Modifier
                        .matchParentSize()
                        .clickable(
                            interactionSource = slotTap,
                            indication = null,
                            onClick = { onToggleSelect(track) }
                        )
                )
            }
        }
    }
}

/**
 * Кружок выбора — один Canvas вместо пары иконок Material.
 *
 * Почему не `RadioButtonUnchecked` → `CheckCircle`: это два разных рисунка, и подмена вектора
 * происходит мгновенно, посреди анимации масштаба. Глаз видит не «галочка щёлкнула», а «иконка
 * прыгнула и заменилась». Здесь кольцо и заливка — одна фигура: кольцо гаснет, диск проявляется и
 * подрастает с 0.9 до 1, галочка прочерчивается тем же числом. Всё в фазе отрисовки: пока палец
 * бежит по списку и щёлкает строки, ни одна из них не рекомпозится.
 */
@Composable
private fun SelectDot(
    mark: State<Float>,
    ring: Color,
    accent: Color,
    onAccent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val a = mark.value
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = 10.5.dp.toPx() * (0.9f + 0.1f * a)
        if (a < 1f) {
            drawCircle(color = ring, radius = r, center = c, alpha = 1f - a, style = Stroke(width = 1.8.dp.toPx()))
        }
        if (a > 0f) {
            drawCircle(color = accent, radius = r, center = c, alpha = a)
            // Галочка: три точки в долях радиуса, поэтому она не разъезжается ни при каком размере.
            val w = 2.0.dp.toPx()
            val p1 = Offset(c.x - 0.44f * r, c.y + 0.02f * r)
            val p2 = Offset(c.x - 0.12f * r, c.y + 0.34f * r)
            val p3 = Offset(c.x + 0.46f * r, c.y - 0.32f * r)
            drawLine(onAccent, p1, p2, strokeWidth = w, cap = StrokeCap.Round, alpha = a)
            drawLine(onAccent, p2, p3, strokeWidth = w, cap = StrokeCap.Round, alpha = a)
        }
    }
}

@Composable
private fun PlaylistList(
    state: LibraryUiState,
    onOpen: (Long) -> Unit,
    onRename: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onShare: (PlaylistEntity) -> Unit,
    onImport: () -> Unit
) {
    val p = LocalPalette.current
    var creating by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable { creating = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("Новый плейлист", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
            }
        }
        // Приём рядом с созданием, а не в настройках: чужой плейлист — это такой же способ
        // завести у себя плейлист, и искать его в другом углу приложения человек не станет.
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable(onClick = onImport),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(CircleShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Download, null, tint = p.accent, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("Импорт плейлиста", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(state.playlists, key = { it.id }) { playlist ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_HEIGHT)
                    .clip(rowShape)
                    .clickable { onOpen(playlist.id) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(artShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.QueueMusic, null, tint = p.accent, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    // 6.17.0: под именем плейлиста теперь и количество, и общее время.
                    val meta = state.playlistMeta[playlist.id]
                    Text(
                        text = trackCountLabel(meta?.count ?: 0) +
                            if ((meta?.totalMs ?: 0L) > 0L) " · " + formatTotalTime(meta!!.totalMs) else "",
                        color = p.subtext,
                        fontSize = 12.5.sp
                    )
                }
                RoundIconButton(Icons.Filled.IosShare, p.subtext, Color.Transparent, 40, 19, { onShare(playlist) })
                RoundIconButton(Icons.Filled.Edit, p.subtext, Color.Transparent, 40, 19, { onRename(playlist.id) })
                RoundIconButton(Icons.Filled.DeleteOutline, p.subtext, Color.Transparent, 40, 20, { onDelete(playlist.id) })
            }
        }
    }
    if (creating) RenameDialog(
        initial = "",
        title = "Новый плейлист",
        onConfirm = { onCreate(it); creating = false },
        onDismiss = { creating = false }
    )
}

@Composable
private fun FolderList(
    folders: List<FolderInfo>,
    settingsFolders: List<String>,
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit,
    onMenu: (String) -> Unit = {}
) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable(onClick = onAdd),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.CreateNewFolder, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Добавить папку", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
                    Text("Через файловый менеджер", color = p.subtext, fontSize = 12.sp)
                }
            }
        }
        items(folders, key = { it.name }) { folder ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_HEIGHT)
                    .clip(rowShape)
                    .clickable { onOpen(folder.name) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(artShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.FolderOpen, null, tint = p.accent, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(folder.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(trackCountLabel(folder.count), color = p.subtext, fontSize = 12.5.sp)
                }
                // 6.17.0: у папки появилось своё меню — отсюда её содержимое уходит в плейлист.
                RoundIconButton(
                    icon = Icons.Filled.MoreVert,
                    tint = p.subtext,
                    background = Color.Transparent,
                    size = 38,
                    iconSize = 19,
                    onClick = { onMenu(folder.name) }
                )
            }
        }
        if (settingsFolders.isNotEmpty()) {
            item {
                Text(
                    "Подключённые папки",
                    color = p.subtext,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 6.dp, start = 4.dp)
                )
            }
            itemsIndexed(settingsFolders, key = { _, uri -> uri }) { _, uri ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Link, null, tint = p.subtext, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = Uri.decode(uri).substringAfterLast('/'),
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    RoundIconButton(Icons.Filled.Close, p.subtext, Color.Transparent, 34, 16, { onRemove(uri) })
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, track: TrackEntity, isPlaying: Boolean, onOpen: () -> Unit) {
    val p = LocalPalette.current
    // v6.1 drew a floating rounded card with 10/6 dp margins, 8 dp inner padding, a 44 dp cover and
    // 46 dp buttons - about 68 dp of screen for a strip the reference does in 40. It is now a
    // full-bleed bar sitting flush on the navigation bar, with the progress line doubling as the
    // divider (measured: 63 px = 39 dp tall; 46 dp keeps the two buttons at a legal touch target).
    Column(
        Modifier
            .fillMaxWidth()
            .background(p.surface.copy(alpha = 0.97f))
            .clickable(onClick = onOpen)
    ) {
        MiniProgressLine(vm)
        Row(
            Modifier
                .fillMaxWidth()
                .height(MINI_HEIGHT)
                .padding(start = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(5.dp)),
                glyphSize = 15
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                TrackTitle(
                    title = track.title,
                    color = p.text,
                    dim = p.text.copy(alpha = 0.45f),
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(track.artist, color = p.subtext, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RoundIconButton(
                icon = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                tint = p.text,
                background = Color.Transparent,
                size = 38,
                iconSize = 24,
                onClick = vm::playPause
            )
            RoundIconButton(Icons.Rounded.SkipNext, p.text, Color.Transparent, 36, 22, vm::next)
        }
    }
}

/** Separate composable on purpose: the position ticks twice a second and stops here. */
@Composable
private fun MiniProgressLine(vm: MainViewModel) {
    val p = LocalPalette.current
    // The state object is held, NOT unwrapped with `by`: reading .value inside drawBehind keeps the
    // twice-a-second position tick in the draw phase. Unwrapping it here made this composable - and
    // therefore the whole mini player row - recompose two times a second, forever, while playing.
    val progress = vm.progress.collectAsStateWithLifecycle()
    val inactive = remember(p.chip) { p.chip.copy(alpha = 0.65f) }
    val accent = p.accent
    Box(
        Modifier
            .fillMaxWidth()
            .height(2.dp)
            .drawBehind {
                val state = progress.value
                val fraction = if (state.durationMs <= 0) 0f
                else (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f)
                drawRect(inactive)
                drawRect(accent, size = size.copy(width = size.width * fraction))
            }
    )
}

@Composable
private fun ScanningBadge(progress: ScanProgress?, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    // "Сканируем…" with no end in sight is indistinguishable from a hang, and on a large folder the
    // wait used to be tens of seconds. The badge now says what is happening and how far it has got.
    val label = when {
        progress == null -> "Сканируем…"
        progress.total > 0 -> "${progress.label} · ${progress.done} / ${progress.total}"
        else -> progress.label
    }
    Row(
        modifier
            .padding(top = 8.dp)
            .clip(CircleShape)
            .background(p.accent)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = p.onAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CenterNote(text: String) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = p.subtext, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
    }
}
