package app.ziziplayer.ui

import app.ziziplayer.data.remote.RemoteTrack

/**
 * 6.85.0. Единственное место, где Kotlin-список треков исполнителя превращается в порядок показа.
 *
 * Вся логика — в чистой Java ([ArtistPopularPolicy]); здесь только переходник. Порядок хранится в
 * самом списке `OpenCollection.tracks`, поэтому «Популярное», «Сохранить треки», «Перемешать» и
 * очередь воспроизведения видят один и тот же порядок и индекс строки == индекс очереди.
 */
internal object ArtistTrackOrder {
    /** Старые + новые треки: без повторов, по популярности (если сервер её прислал). */
    fun merge(existing: List<RemoteTrack>, incoming: List<RemoteTrack>): List<RemoteTrack> {
        val all = if (existing.isEmpty()) incoming else existing + incoming
        if (all.isEmpty()) return all
        val order = ArtistPopularPolicy.order(
            IntArray(all.size) { all[it].rank },
            Array(all.size) { all[it].remoteId }
        )
        return List(order.size) { all[order[it]] }
    }

    /** Сколько первых строк относится к «Популярному». Список уже упорядочен [merge]. */
    fun popularCount(tracks: List<RemoteTrack>): Int =
        ArtistPopularPolicy.popularCount(IntArray(tracks.size) { tracks[it].rank })
}
