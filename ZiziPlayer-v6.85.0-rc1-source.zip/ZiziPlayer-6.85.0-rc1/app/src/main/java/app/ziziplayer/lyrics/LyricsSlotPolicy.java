package app.ziziplayer.lyrics;

/**
 * 6.84.14-rc4. Сколько ждать после того, как текущий трек стал «стабильным» (подключён, не грузит звук), прежде чем
 * лирика получит право на сеть.
 *
 * До rc4 каждый запрос к провайдеру выжидал 750 мс заново. В трассе это видно как цепочка
 * LYRICS_WAIT 751 мс -> LYRICS_HTTP -> LYRICS_WAIT 751 мс -> ..., до пяти звеньев на один трек: три секунды
 * искусственной паузы, когда первые провайдеры отвечают 404.
 *
 * Теперь пауза нужна один раз на трек и короткая: она лишь отсекает мигание состояния «грузит / не грузит» в момент
 * смены трека. Если слот уже пройден для этого трека, следующие запросы идут сразу: условие готовности по-прежнему
 * проверяется (первый же эмит из StateFlow), так что на загрузку звука лирика не влезает.
 */
public final class LyricsSlotPolicy {
    private LyricsSlotPolicy() {}

    public static final long FIRST_SETTLE_MS = 150L;
    public static final long REPEAT_SETTLE_MS = 0L;

    /** [passedForThisTrack] = true, если этот же трек уже прошёл слот раньше (идёт следующая попытка провайдера). */
    public static long settleMs(boolean passedForThisTrack) {
        return passedForThisTrack ? REPEAT_SETTLE_MS : FIRST_SETTLE_MS;
    }
}
