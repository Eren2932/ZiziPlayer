package app.ziziplayer.ui;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * 6.84.13 (H0). Локальная трасса главной: что произошло со снимком и с ответом сервера и когда пользователь
 * реально увидел полки. Правило то же, что у StartupTrace: никаких названий, id, адресов и токенов. В строку
 * попадают только имена событий и причин из фиксированных перечислений и одно число с ключом из белого списка.
 * Потокобезопасно, без Android-зависимостей (проверяется на JVM).
 *
 * 6.84.14-rc4. Буфер из двух частей: первые {@value #HEAD_LIMIT} событий живут весь процесс (холодный старт нельзя
 * вытеснить), а за ними идёт кольцо на {@value #TAIL_LIMIT} последних. Раньше было одно кольцо на 64 события, и семь
 * заходов на главную подряд выталкивали холодный старт.
 */
public final class HomeTrace {
    private HomeTrace() {}

    public enum Event {
        /** Создан HomeRecommendations (старт главной в процессе). */
        HOME_INIT,
        /** Приватный шлюз экрана открыт: пока он закрыт, экран не рисует ни снимок, ни полки. */
        PRIVACY_GATE_OPEN,
        /** Room и офлайн-файлы загружены: с этого момента экран зовёт refreshFeed. */
        LIBRARY_READY,
        /** Чтение локального снимка: причина промаха или HIT. */
        SNAPSHOT_READ,
        /** Снимок разобран и показан (число полок). */
        SNAPSHOT_SHOWN,
        /** load() стартовал или пропущен (причина). */
        LOAD,
        /** Профиль для запроса собран (число сидов). */
        PROFILE_READY,
        /** Запрос /reco/home ушёл. */
        REQUEST,
        /** Ответ получен: исход и время запроса. */
        RESPONSE,
        /** 6.84.13. Ранний запрос чарта (параллельно с /reco/home): исход. */
        DISCOVER,
        /** Что с записью снимка после ответа. */
        SNAPSHOT_WRITE,
        /** Серверные полки опубликованы в состоянии (число полок). */
        PUBLISHED,
        /** Первые серверные полки реально дошли до экрана: из снимка или с живого ответа. */
        SHELVES_VISIBLE,
        /** Кольцо загрузки нужно экрану (в причине: ждём библиотеку или ждём подборки). */
        LOADER_ON,
        LOADER_OFF,
        /** 6.84.14-rc3. Этапы restoreSnapshot: время от входа в функцию (ключ ms). */
        SNAPSHOT_STAGE,
        /** 6.84.14-rc3. Этапы задачи load() до первых запросов к серверу: время от старта задачи (ключ ms). */
        LOAD_STAGE
    }

    public enum Gate {
        NONE,
        // чтение снимка
        HIT, NO_FILE, PENDING_TASTE, PRIVACY_CHANGED, EXPIRED, TRANSIENT_ERROR, CORRUPT, PARSE_ERROR,
        EMPTY, NO_CATALOG, UNSAFE, ALREADY_SHOWN, RACE,
        // load()
        STARTED, SKIPPED_ACTIVE, SKIPPED_FRESH, SKIPPED_LOADING,
        // исход ответа
        COMPLETE, PARTIAL, NULL_REPLY, TIMEOUT, ERROR,
        // запись снимка
        WRITTEN, WRITE_FAILED, TOO_BIG, NOT_BETTER, TASTE_SETUP, NO_RAW,
        // откуда полки / что ждёт кольцо
        SNAPSHOT, LIVE, LIBRARY, FEED,
        // 6.84.14-rc3: этапы восстановления снимка и старта load()
        READ_DONE, PARSE_DONE, BUILD_DONE, BUILD_SKIPPED, SIZE,
        RESTORED, ROOM_DONE, BUILDER_READY, FIRST_PUBLISHED,
        // 6.84.14-rc4: где именно уходит время на Dispatchers.Default. Все значения (ключ ms) это длительность
        // отрезка, а не время от старта задачи.
        //   *_WAIT: от вызова withContext до первой строки блока (очередь потоков Default);
        //   *_RUN:  стенное время самого блока;
        //   *_CPU:  процессорное время потока на блоке (RUN много больше CPU: поток вытесняли, считать нечего);
        //   *_BACK: от конца блока до возврата в скоуп экрана (занятый главный поток виден тут).
        // BUILDER_* это конструктор FeedBuilder в load(), BUILD_* это builder.build() в publish().
        BUILDER_WAIT, BUILDER_RUN, BUILDER_CPU, BUILDER_BACK,
        BUILD_WAIT, BUILD_RUN, BUILD_CPU, BUILD_BACK,
        /** Задачу load() отменили до конца (ключ ms: сколько она прожила). Отмена до REQUEST значит, что живых полок не будет. */
        CANCELLED
    }

    public static final String K_MS = "ms";
    public static final String K_AGE_H = "age_h";
    public static final String K_SHELVES = "shelves";
    public static final String K_SEEDS = "seeds";
    /** 6.84.14-rc3. Размер локальной библиотеки (число треков): цена FeedBuilder растёт с ним. */
    public static final String K_TRACKS = "tracks";
    /** 6.84.14-rc4. Число строк истории прослушивания, которые разбирает FeedBuilder. */
    public static final String K_ROWS = "rows";

    public static final int HEAD_LIMIT = 32;
    public static final int TAIL_LIMIT = 48;
    private static final Object LOCK = new Object();
    private static final ArrayList<String> HEAD = new ArrayList<>(HEAD_LIMIT);
    private static final ArrayDeque<String> TAIL = new ArrayDeque<>();
    /** Сколько событий было всего (в том числе вытесненных из кольца). */
    private static long total = 0L;
    private static final Set<Event> ONCE_DONE = EnumSet.noneOf(Event.class);
    private static long origin = System.nanoTime();

    public static void mark(Event event) { add(event, Gate.NONE, null, 0L); }

    public static void mark(Event event, Gate gate) { add(event, gate, null, 0L); }

    public static void mark(Event event, Gate gate, String key, long value) {
        add(event, gate, allowed(key) ? key : null, value);
    }

    private static boolean allowed(String key) {
        return K_MS.equals(key) || K_AGE_H.equals(key) || K_SHELVES.equals(key) || K_SEEDS.equals(key)
            || K_TRACKS.equals(key) || K_ROWS.equals(key);
    }

    /** Событие, которое имеет смысл только один раз за процесс (первые полки, открытие шлюза). */
    public static void markOnce(Event event, Gate gate) {
        synchronized (LOCK) {
            if (!ONCE_DONE.add(event)) return;
        }
        add(event, gate, null, 0L);
    }

    /** 6.84.14. Общие часы для SyncTrace: строки обеих трасс сравнимы по времени. */
    public static long elapsedMs() { return (System.nanoTime() - origin) / 1_000_000L; }

    private static void add(Event event, Gate gate, String key, long value) {
        long ms = elapsedMs();
        StringBuilder line = new StringBuilder(48).append(ms).append(" ms | ").append(event.name());
        if (gate != null && gate != Gate.NONE) line.append(' ').append(gate.name());
        if (key != null) line.append(' ').append(key).append('=').append(value);
        synchronized (LOCK) {
            total++;
            if (HEAD.size() < HEAD_LIMIT) { HEAD.add(line.toString()); return; }
            if (TAIL.size() >= TAIL_LIMIT) TAIL.pollFirst();
            TAIL.addLast(line.toString());
        }
    }

    /** Сохранённые события по порядку: сначала голова (холодный старт), потом кольцо. Маркера пропуска здесь нет. */
    public static List<String> lines() {
        synchronized (LOCK) {
            List<String> all = new ArrayList<>(HEAD.size() + TAIL.size());
            all.addAll(HEAD);
            all.addAll(TAIL);
            return all;
        }
    }

    public static String snapshot() {
        List<String> head;
        List<String> tail;
        long omitted;
        synchronized (LOCK) {
            head = new ArrayList<>(HEAD);
            tail = new ArrayList<>(TAIL);
            omitted = total - head.size() - tail.size();
        }
        StringBuilder out = new StringBuilder(
            "Home timings; milliseconds since this class was first used in the process. First " + HEAD_LIMIT
                + " events of the process and last " + TAIL_LIMIT + " events.\n");
        if (head.isEmpty()) out.append("(no events)\n");
        for (String line : head) out.append(line).append('\n');
        if (omitted > 0L) out.append("... ").append(omitted).append(" events omitted ...\n");
        for (String line : tail) out.append(line).append('\n');
        return out.toString();
    }

    /** Только для проверок на JVM. */
    static void resetForTest() {
        synchronized (LOCK) { HEAD.clear(); TAIL.clear(); total = 0L; ONCE_DONE.clear(); origin = System.nanoTime(); }
    }
}
