package app.ziziplayer.ui;

/**
 * Страница исполнителя: геометрия, снятая с референса (Spotify, 576 x 1280, image-1..3.png)
 * и с нашего экрана на том же устройстве (image.png).
 *
 * Все числа ниже — физические пиксели референса шириной 576. Скриншот не содержит плотности,
 * поэтому единственная честная операция та же, что и на главной (HomeHeaderGeometry):
 * dp = px * viewportDp / 576. На эталонном экране это даёт ровно измеренные пиксели при любой
 * плотности, на других ширинах сохраняется пропорция. Ширина для планшетов ограничена, иначе
 * строка списка раздувалась бы до 140 dp.
 *
 * Вертикальные позиции текста считаются от метрик ПОСТАВЛЯЕМОГО Roboto (hhea ascent 0.9277,
 * descent 0.2441, capHeight 0.7109 — из res/font/zizi_roboto_*.ttf), а не «на глаз»:
 * верх заглавной буквы лежит на 0.2168 em ниже верха строки при lineHeight == ascent + descent.
 *
 * Чистая Java: проверяется без Android и Compose (ArtistPage6815Checks).
 */
public final class ArtistPageGeometry {
    private ArtistPageGeometry() {}

    public static final float REFERENCE_WIDTH = 576f;
    public static final float MIN_VIEWPORT_DP = 300f;
    public static final float MAX_VIEWPORT_DP = 480f;

    /* --- метрики Roboto (em) -------------------------------------------------------- */
    public static final float ASCENT = 0.927734375f;
    public static final float DESCENT = 0.244140625f;
    public static final float CAP = 0.7109375f;
    public static final float LINE = ASCENT + DESCENT;
    public static final float CAP_TOP = ASCENT - CAP;
    /** Центр заглавной буквы / цифры от верха строки. */
    public static final float CAP_CENTER = CAP_TOP + CAP / 2f;

    /* --- фото -------------------------------------------------------------------- */
    /** Фото вместе со статусбаром: 432 / 576. Было ширина * 0.66 + статусбар (439 на эталоне). */
    public static final float PHOTO_RATIO = 0.75f;

    /* --- сведения под фото -------------------------------------------------------- */
    /** Кегль строки «Исполнитель · N»: высота заглавной 19 px у референса (было 15). */
    public static final float META_TEXT = 25.3f;
    /** Фото -> верх заглавной буквы строки сведений: 451 - 432. */
    public static final float META_CAP_TOP = 19f;
    /** Фото -> верх кнопки Play: 490 - 432. */
    public static final float CONTROLS_TOP = 58f;
    /** Play и кнопка перемешивания: диаметр 74 (было 85). */
    public static final float PLAY = 74f;
    public static final float PLAY_ICON = 37f;
    public static final float SHUFFLE_BOX = 74f;
    /** Глиф перемешивания 32 px при коробке иконки 42.7 (глиф = 0.75 коробки). */
    public static final float SHUFFLE_ICON = 42.7f;
    /** Центры: перемешивание 434.5, Play 511.5 -> 77 между центрами при коробках по 74. */
    public static final float SHUFFLE_GAP = 3f;
    /** Контурная кнопка: высота 49 (было 78), кегль 21.1 (заглавная 15). */
    public static final float PILL_HEIGHT = 49f;
    public static final float PILL_TEXT = 21.1f;
    public static final float PILL_PAD_X = 23f;
    /** Низ Play -> низ градиента. Подобран так, чтобы длина градиента осталась прежней (181 px). */
    public static final float DETAILS_BOTTOM = 49f;

    /* --- «Популярное» ------------------------------------------------------------- */
    /** Заглавная «П» 23 px у референса (было 26): 32.35 px кегля. */
    public static final float SECTION_TEXT = 32.35f;
    /** Низ Play -> верх заглавной «П». У референса между ними карточка «новый релиз» (её у нас нет). */
    public static final float SECTION_GAP_FROM_PLAY = 70f;
    /** Верх заглавной «П» -> верх первой строки: 304 - 260. */
    public static final float SECTION_CAP_TO_ROW = 44f;
    /** Кнопка (или последняя строка) -> верх заглавной следующего заголовка: 1015 - 932. */
    public static final float SECTION_GAP = 83f;

    /* --- строка трека ------------------------------------------------------------- */
    /** Шаг строк 98.6 (было 109). */
    public static final float ROW_HEIGHT = 98.6f;
    /** Обложка 74 (было 82). */
    public static final float ART = 74f;
    public static final float EDGE = 26f;
    public static final float ART_LEFT = 72f;
    /** Обложка -> текст: 165 - 146. */
    public static final float TEXT_GAP = 19f;
    public static final float RANK_TEXT = 22.5f;
    public static final float TITLE_TEXT = 27.7f;
    public static final float SUB_TEXT = 21.6f;
    /** Центр заглавной названия -> центр цифр второй строки: 34.5. */
    public static final float TITLE_SUB_SEPARATION = 34.5f;
    /** Зона кнопки справа: 74 коробка, 14 от края; центр = 576 - 14 - 37 = 525. */
    public static final float TRAILING_BOX = 74f;
    public static final float TRAILING_END = 14f;

    /* --- «Еще» / «Свернуть» -------------------------------------------------------- */
    public static final float MORE_HEIGHT = 47f;
    public static final float MORE_PAD_X = 26f;
    public static final float MORE_TEXT = 21.1f;
    /** Развёрнутый список: низ десятой строки -> верх кнопки: 1020 - 1004.8. */
    public static final float MORE_GAP_EXPANDED = 15.2f;
    /** Свёрнутый список: кнопка начинается сразу под обрезом шестой строки. */
    public static final float MORE_GAP_COLLAPSED = 0f;
    /** Шестая строка видна на 86.3 px (отступ 12.3 + обложка 74) и гаснет. */
    public static final float PEEK_ALPHA_TOP = 0.89f;
    /** Прозрачность падает до нуля на 74.3 px от верха шестой строки (замер alpha по пикселям обложки). */
    public static final float PEEK_FADE_LENGTH = 74.3f;

    public static final String REST_TITLE = "Другие треки";

    /* ============================================================================== */

    private static boolean ok(float v) { return Float.isFinite(v); }

    /** Ширина, по которой масштабируется геометрия. */
    public static float viewport(float widthDp) {
        float w = ok(widthDp) && widthDp > 0f ? widthDp : 360f;
        return Math.max(MIN_VIEWPORT_DP, Math.min(MAX_VIEWPORT_DP, w));
    }

    /** Множитель «пиксель референса -> dp». */
    public static float scale(float widthDp) {
        return viewport(widthDp) / REFERENCE_WIDTH;
    }

    public static float dp(float referencePx, float widthDp) {
        return referencePx * scale(widthDp);
    }

    /** Высота фото: доля ширины экрана, но не меньше, чем нужно тулбару. */
    public static float photoHeightDp(float widthDp, float statusDp, float toolbarDp, float fontScale) {
        float w = ok(widthDp) && widthDp > 0f ? widthDp : 360f;
        float fs = ok(fontScale) && fontScale > 0f ? fontScale : 1f;
        return Math.max(w * PHOTO_RATIO, statusDp + toolbarDp + 104f * fs);
    }

    public static float lineHeight(float fontPx) { return fontPx * LINE; }
    public static float capTopOffset(float fontPx) { return fontPx * CAP_TOP; }
    /** Расстояние от верха заглавной буквы до низа строки. */
    public static float belowCapTop(float fontPx) { return fontPx * (LINE - CAP_TOP); }

    /** Верхний отступ под фото, при котором верх заглавной буквы строки сведений на 19 px ниже фото. */
    public static float metaTopPad() { return META_CAP_TOP - capTopOffset(META_TEXT); }

    /** Зазор между строкой сведений и рядом кнопок. */
    public static float metaToControlsGap() {
        return CONTROLS_TOP - (metaTopPad() + lineHeight(META_TEXT));
    }

    /** Отступ над заголовком «Популярное» внутри его элемента списка (элемент начинается там, где кончается шапка). */
    public static float sectionPadTop() {
        return SECTION_GAP_FROM_PLAY - DETAILS_BOTTOM - capTopOffset(SECTION_TEXT);
    }

    /** Отступ под заголовком: от низа строки заголовка до верха первой строки. */
    public static float sectionPadBottom() {
        return SECTION_CAP_TO_ROW - belowCapTop(SECTION_TEXT);
    }

    /** Отступ над следующим заголовком (после кнопки или последней строки). */
    public static float nextSectionPadTop() {
        return SECTION_GAP - capTopOffset(SECTION_TEXT);
    }

    public static float rowPadV() { return (ROW_HEIGHT - ART) / 2f; }
    public static float rankWidth() { return ART_LEFT - EDGE; }

    /** Просвет между строкой названия и второй строкой, дающий ровно 34.5 между центрами заглавных. */
    public static float titleSubGap() {
        return TITLE_SUB_SEPARATION
                - (lineHeight(TITLE_TEXT) - CAP_CENTER * TITLE_TEXT)
                - CAP_CENTER * SUB_TEXT;
    }

    /** Высота видимого куска шестой строки. */
    public static float peekClip() { return rowPadV() + ART; }

    /**
     * Оценка высоты всего, что лежит под шапкой, в px референса. Нужна только для хвоста
     * прокрутки короткой страницы (ArtistHeaderMotion.minimumTail): занижать её нельзя, иначе
     * хвост раздувается, завышать тоже нельзя — шапка перестанет сворачиваться до конца.
     */
    public static float contentPx(int totalTracks, int popular, boolean expanded) {
        int total = Math.max(0, totalTracks);
        int pop = Math.max(0, Math.min(popular, total));
        float h = sectionPadTop() + lineHeight(SECTION_TEXT) + sectionPadBottom();
        int shown = ArtistPopularPolicy.visibleCount(pop, expanded);
        h += shown * ROW_HEIGHT;
        if (ArtistPopularPolicy.hasPeek(pop, expanded)) h += peekClip();
        if (ArtistPopularPolicy.hasToggle(pop)) {
            h += (expanded ? MORE_GAP_EXPANDED : MORE_GAP_COLLAPSED) + MORE_HEIGHT;
        }
        int rest = total - pop;
        if (rest > 0) {
            h += nextSectionPadTop() + lineHeight(SECTION_TEXT) + sectionPadBottom() + rest * ROW_HEIGHT;
        }
        return h;
    }
}
