package app.ziziplayer.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Страница исполнителя: что считается «Популярным» и сколько строк видно.
 *
 * Источник правды о популярности — поле `rank` Deezer (оно глобальное для трека, а не для
 * страницы выдачи). Прослушиваний Deezer не отдаёт вообще, поэтому счётчиков на странице нет
 * и придумывать их нельзя.
 *
 * Правила:
 *  - порядок: по rank по убыванию, при равенстве — прежний порядок (стабильно). Если ни у одного
 *    трека rank неизвестен (старый сервер), порядок сервера не трогаем — он уже отсортирован;
 *  - один трек — одна строка (ключ = remoteId); при повторе остаётся экземпляр с большим rank;
 *  - «Популярное» = min(10, число треков с rank > 0). Если rank'ов нет или все нули — min(10, всего);
 *  - видно 5 строк; шестая видна затухающей «подглядкой», пока список свёрнут;
 *    кнопка «Еще»/«Свернуть» появляется только если популярных больше 5;
 *  - все остальные треки идут ниже отдельным блоком с продолжающейся нумерацией.
 *
 * Чистая Java: проверяется без Android и Compose (ArtistPage6815Checks).
 */
public final class ArtistPopularPolicy {
    private ArtistPopularPolicy() {}

    public static final int COLLAPSED = 5;
    public static final int EXPANDED = 10;
    public static final int UNKNOWN = -1;
    /** Тихие перезапросы первой страницы, пока сервер собирает пул артиста (мс). */
    public static final long[] REFRESH_DELAYS_MS = {2500L, 5000L, 9000L};

    /** Индексы входа в порядке показа. ranks[i] < 0 — неизвестно. keys[i] — идентичность трека. */
    public static int[] order(int[] ranks, String[] keys) {
        int n = ranks == null ? 0 : ranks.length;
        if (n == 0) return new int[0];
        if (keys == null || keys.length != n) throw new IllegalArgumentException("keys.length != ranks.length");
        Map<String, Integer> best = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String key = keys[i] == null ? "#" + i : keys[i];
            Integer at = best.get(key);
            if (at == null || norm(ranks[i]) > norm(ranks[at])) best.put(key, i);
        }
        List<Integer> kept = new ArrayList<>(best.size());
        for (int i = 0; i < n; i++) {
            String key = keys[i] == null ? "#" + i : keys[i];
            Integer at = best.get(key);
            if (at != null && at == i) kept.add(i);
        }
        boolean anyKnown = false;
        for (int i : kept) if (ranks[i] >= 0) { anyKnown = true; break; }
        Integer[] boxed = kept.toArray(new Integer[0]);
        if (anyKnown) {
            // Arrays.sort на объектах стабилен (TimSort): равные rank сохраняют прежний порядок.
            Arrays.sort(boxed, (a, b) -> Integer.compare(norm(ranks[b]), norm(ranks[a])));
        }
        int[] out = new int[boxed.length];
        for (int i = 0; i < out.length; i++) out[i] = boxed[i];
        return out;
    }

    private static int norm(int rank) { return rank < 0 ? UNKNOWN : rank; }

    /** Сколько строк относится к «Популярному». ranks — уже в порядке показа. */
    public static int popularCount(int[] orderedRanks) {
        int n = orderedRanks == null ? 0 : orderedRanks.length;
        if (n == 0) return 0;
        int positive = 0;
        for (int r : orderedRanks) if (r > 0) positive++;
        return Math.min(EXPANDED, positive > 0 ? positive : n);
    }

    public static int visibleCount(int popular, boolean expanded) {
        int p = Math.max(0, popular);
        return expanded ? Math.min(p, EXPANDED) : Math.min(p, COLLAPSED);
    }

    public static boolean hasToggle(int popular) { return popular > COLLAPSED; }

    public static boolean hasPeek(int popular, boolean expanded) { return !expanded && popular > COLLAPSED; }

    /** Первая страница, которую сервер отдал по недособранному пулу, нужна ещё раз. */
    public static boolean needsRefresh(boolean complete) { return !complete; }

    /** Токен следующей страницы после слияния: берём тот, что дальше (числовые смещения). */
    public static String laterToken(String current, String refreshed) {
        if (current == null) return refreshed;
        if (refreshed == null) return current;
        try {
            return Integer.parseInt(refreshed.trim()) > Integer.parseInt(current.trim()) ? refreshed : current;
        } catch (NumberFormatException e) {
            return current;
        }
    }

    /** «1 трек», «2 трека», «5 треков», «21 трек», «11 треков». */
    public static String tracksWord(int n) {
        int a = Math.abs(n);
        int last = a % 10, two = a % 100;
        if (two >= 11 && two <= 14) return "треков";
        if (last == 1) return "трек";
        if (last >= 2 && last <= 4) return "трека";
        return "треков";
    }
}
