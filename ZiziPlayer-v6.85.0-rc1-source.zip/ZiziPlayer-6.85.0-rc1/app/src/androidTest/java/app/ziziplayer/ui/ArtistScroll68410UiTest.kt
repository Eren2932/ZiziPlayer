package app.ziziplayer.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.screens.ArtistPageScaffold
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Actual layout, gestures and restoration. Requires emulator/device; not a source-contract test. */
class ArtistScroll68410UiTest {
    @get:Rule val compose = createComposeRule()
    private var d = 1f
    private var back = 0
    private var saved = 0
    private var shuffled = 0
    private var refreshed = 0
    private var played = 0
    private val name = "Artist motion reference"

    @Composable private fun Fixture(state: LazyListState? = null, count: Int = 40, font: Float = 1f) {
        val physical = LocalDensity.current.density
        d = physical
        // 6.85.0: Play и нижний отступ шапки — те же числа, по которым считает сам scaffold (ArtistPageGeometry).
        val geo = ArtistPageGeometry.scale(LocalConfiguration.current.screenWidthDp.toFloat())
        val playDp = ArtistPageGeometry.PLAY * geo
        val bottomDp = ArtistPageGeometry.DETAILS_BOTTOM * geo
        CompositionLocalProvider(LocalDensity provides Density(physical, font)) {
            NeutralSurfaceTheme {
                ArtistPageScaffold(destination = "artist:42", title = name, tint = Color(0xFF382524),
                    hasPlay = count > 0, trackCount = count, onBack = { back++ },
                    saveLabel = "Сохранить треки", saveEnabled = count > 0,
                    onSave = { saved++ }, onShuffle = { shuffled++ }, onRetry = { refreshed++ },
                    artwork = { Box(Modifier.fillMaxSize().background(Color.DarkGray)) },
                    details = {
                        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = bottomDp.dp)) {
                            Text("Исполнитель · $count треков")
                            if (count > 0) {
                                Spacer(Modifier.height(14.dp))
                                Box(Modifier.align(Alignment.CenterHorizontally).size(playDp.dp)
                                    .background(Color.Green).clickable { played++ }.testTag("artist:fixture-play"))
                            }
                        }
                    }, listState = state
                ) {
                    item("popular") { Text("Популярное", Modifier.fillMaxWidth().height(52.dp).background(Color.Black)) }
                    items(count) { Text("Track $it", Modifier.fillMaxWidth().height(71.dp)
                        .background(Color.Black).testTag("artist:test-track:$it")) }
                }
            }
        }
    }

    private fun jump(state: LazyListState, index: Int, offset: Int = 0) {
        compose.runOnIdle { runBlocking { state.scrollToItem(index, offset) } }
        compose.waitForIdle()
    }
    private fun bounds(tag: String) = compose.onNodeWithTag(tag, useUnmergedTree = true).fetchSemanticsNode().boundsInRoot

    @Test fun portraitViewportStaysFixedWhileForegroundScrolls() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        val portrait = bounds("artist:portrait")
        val title = bounds("artist:large-title")
        jump(state, 0, (32*d).toInt())
        assertEquals(portrait, bounds("artist:portrait"))
        assertEquals(title.top - (32*d).toInt(), bounds("artist:large-title").top, 1.1f)
    }

    @Test fun sideButtonsMoveOnlyEightDpHorizontallyAndReverseExactly() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        val backTop = bounds("artist:back")
        val menuTop = bounds("artist:menu")
        jump(state, 18)
        val backDeep = bounds("artist:back")
        val menuDeep = bounds("artist:menu")
        assertEquals(8*d, backTop.center.x-backDeep.center.x, 1.1f)
        assertEquals(8*d, menuDeep.center.x-menuTop.center.x, 1.1f)
        assertEquals(backTop.center.y, backDeep.center.y, .1f)
        assertEquals(menuTop.center.y, menuDeep.center.y, .1f)
        jump(state, 0)
        assertEquals(backTop, bounds("artist:back"))
        assertEquals(menuTop, bounds("artist:menu"))
    }

    @Test fun compactTitleIsCenteredBetweenPersistentControls() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        jump(state, 20)
        val title = bounds("artist:compact-title")
        val toolbar = bounds("artist:toolbar")
        assertEquals(toolbar.center.x, title.center.x, 1.1f)
        assertTrue(title.left >= bounds("artist:back").right)
        assertTrue(title.right <= bounds("artist:menu").left)
        compose.onNodeWithTag("artist:compact-title", useUnmergedTree = true).assertTextEquals(name)
    }

    @Test fun backAndMenuActionsWorkAtBothEndsOfTheScroll() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        for (index in listOf(0, 20, 0)) {
            jump(state, index)
            compose.onNodeWithTag("artist:back").performTouchInput { click() }
            compose.onNodeWithTag("artist:menu").performTouchInput { click() }
            compose.onNodeWithText("Сохранить треки").performClick()
        }
        compose.runOnIdle { assertEquals(3, back); assertEquals(3, saved) }
        compose.onNodeWithTag("artist:menu").performClick()
        compose.onNodeWithText("Перемешать загруженные треки").performClick()
        compose.onNodeWithTag("artist:menu").performClick()
        compose.onNodeWithText("Обновить страницу").performClick()
        compose.runOnIdle { assertEquals(1, shuffled); assertEquals(1, refreshed) }
    }

    @Test fun restoredDeepListDoesNotResurrectExpandedHeader() {
        val restoration = StateRestorationTester(compose)
        restoration.setContent { Fixture() }
        compose.onNodeWithTag("artist:list").performScrollToIndex(20)
        val before = bounds("artist:back")
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithTag("artist:compact-title", useUnmergedTree = true).assertTextEquals(name)
        assertEquals(before, bounds("artist:back"))
        compose.onNodeWithTag("artist:list").performScrollToIndex(0)
        assertEquals(8*d, bounds("artist:back").center.x-before.center.x, 1.1f)
    }

    @Test fun rapidGestureReversalsKeepListAndButtonsInAgreement() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        val before = bounds("artist:back")
        repeat(3) {
            compose.onNodeWithTag("artist:list").performTouchInput {
                swipeUp(startY = height*.8f, endY = height*.3f, durationMillis = 160)
            }
            compose.onNodeWithTag("artist:list").performTouchInput {
                swipeDown(startY = height*.3f, endY = height*.8f, durationMillis = 160)
            }
        }
        jump(state, 0)
        assertEquals(before, bounds("artist:back"))
        compose.runOnIdle { assertEquals(0, state.firstVisibleItemScrollOffset) }
    }

    @Test fun toolbarDoesNotPassTouchesToTheCoveredPlay() {
        val state = LazyListState()
        compose.setContent { Fixture(state) }
        val play = bounds("artist:fixture-play")
        val toolbarButton = bounds("artist:back")
        jump(state, 0, (play.center.y-toolbarButton.center.y).toInt())
        val root = bounds("artist:viewport")
        compose.onNodeWithTag("artist:viewport").performTouchInput {
            click(Offset(play.center.x-root.left, toolbarButton.center.y-root.top))
        }
        compose.runOnIdle { assertEquals(0, played) }
        jump(state, 0)
        compose.onNodeWithTag("artist:fixture-play").performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, played) }
    }

    @Test fun emptyPageHasNoEnabledPhantomPlayOrSave() {
        val state = LazyListState()
        compose.setContent { Fixture(state, count = 0) }
        compose.onNodeWithTag("artist:menu").performClick()
        compose.onNodeWithText("Сохранить треки").assertIsNotEnabled()
        compose.onNodeWithText("Перемешать загруженные треки").assertIsNotEnabled()
        compose.onNodeWithText("Обновить страницу").performClick()
        compose.runOnIdle { assertEquals(1, refreshed) }
    }

    @Test fun largeFontAndMetadataRemeasurePreserveCollapsedControls() {
        val state = LazyListState()
        val font = mutableStateOf(1f)
        compose.setContent { Fixture(state, font = font.value) }
        jump(state, 20)
        for (scale in listOf(1.8f, 2.5f, 1f)) {
            compose.runOnIdle { font.value = scale }
            val back = bounds("artist:back")
            assertTrue(back.width >= 48*d-1.1f)
            assertEquals(bounds("artist:toolbar").center.x, bounds("artist:compact-title").center.x, 1.1f)
            compose.onNodeWithTag("artist:compact-title", useUnmergedTree = true).assertTextEquals(name)
        }
    }
}
