# YouTube session WebView integration (6.9.3)

## Конфигурация

Корневой `gradle.properties` уже содержит:

````properties
sessionBootstrapUrl=https://music.youtube.com
sessionProtectedHosts=youtubei.googleapis.com,googlevideo.com,music.youtube.com
sessionTokenHeader=X-Youtube-Identity-Token
sessionUserAgent=Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36
sessionTokenWaitMs=12000
````

Правило хоста включает сам домен и его поддомены, поэтому `googlevideo.com` также покрывает адреса
вида `rr1---sn-....googlevideo.com`.

## WebView и JS-мост

WebView открывает только исходный HTTPS origin. В `onPageFinished` приложение выполняет probe,
который до десяти секунд ищет строковый payload в следующих источниках:

1. `window.__ZIZI_PAYLOAD__` — явный интеграционный контракт;
2. `ytcfg.INNERTUBE_CONTEXT.client.poToken`;
3. `ytcfg.PO_TOKEN` или `ytcfg.PLAYER_PO_TOKEN`;
4. `ytInitialPlayerResponse.serviceIntegrityDimensions.poToken`;
5. `ytcfg.ID_TOKEN`;
6. meta-теги `po-token` и `youtube-identity-token`.

Найденное значение передаётся вызовом:

````javascript
window.AndroidTokenBridge.postToken(payload);
````

Скрипт не читает cookies и localStorage. Payload остаётся только в памяти процесса.

## OkHttp

Для защищённых запросов перехватчик всегда заменяет `User-Agent` и заголовок
`X-Youtube-Identity-Token`. Для POST JSON дополнительно формируется структура:

````json
{
  "context": {
    "client": {
      "poToken": "<payload>"
    }
  }
}
````

Существующие поля `context` и `client` сохраняются. Если эти поля присутствуют, но не являются
JSON-объектами, запрос не отправляется.

## Ограничение протокола

Identity token и poToken не взаимозаменяемы. Если страница отдаёт `ID_TOKEN`, сервер может принять
заголовок, но отклонить `context.client.poToken`. Для стабильной работы страница должна предоставить
именно актуальный poToken либо отдельные значения для заголовка и тела; текущая версия по запросу
использует одну payload-строку в обоих местах.
