package app.ziziplayer.data.remote

import app.ziziplayer.BuildConfig
import java.io.IOException
import java.util.Locale
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.Buffer
import org.json.JSONObject

/** Immutable request policy shared by WebView, API calls and Media3's OkHttpDataSource. */
object SessionRequestPolicy {
    val userAgent: String = BuildConfig.SESSION_USER_AGENT
        .replace("\r", " ")
        .replace("\n", " ")
        .trim()
        .ifEmpty { "ZiziPlayer/${BuildConfig.VERSION_NAME} (Android)" }

    val tokenHeader: String = BuildConfig.SESSION_TOKEN_HEADER.trim()
        .takeIf { it.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+")) }
        ?: "X-Session-Payload"

    private val bootstrapHost: String? = runCatching {
        java.net.URI(BuildConfig.SESSION_BOOTSTRAP_URL).host?.lowercase(Locale.US)
    }.getOrNull()

    val protectedHosts: Set<String> = BuildConfig.SESSION_PROTECTED_HOSTS
        .split(',')
        .map { it.trim().lowercase(Locale.US).removePrefix("*.") }
        .filter { it.isNotEmpty() }
        .toMutableSet()
        .apply { if (isEmpty()) bootstrapHost?.let(::add) }

    val waitMs: Long = BuildConfig.SESSION_TOKEN_WAIT_MS.coerceIn(1_000L, 30_000L)

    /** A rule covers both the apex and its subdomains, without matching not-example.com. */
    fun protects(host: String): Boolean {
        val normalized = host.lowercase(Locale.US)
        return protectedHosts.any { rule ->
            rule == "*" || normalized == rule || normalized.endsWith(".$rule")
        }
    }
}

/** Injects the same payload into context.client.poToken for protected POST JSON calls. */
private object PoTokenJsonInjector {
    private const val MAX_BODY_BYTES = 2L * 1024L * 1024L

    @Throws(IOException::class)
    fun inject(request: Request, payload: String): Request {
        if (!request.method.equals("POST", ignoreCase = true)) return request
        val body = request.body ?: return request
        val type = body.contentType() ?: return request
        val jsonType = type.subtype.equals("json", ignoreCase = true) ||
            type.subtype.endsWith("+json", ignoreCase = true)
        if (!jsonType) return request
        if (body.isDuplex() || body.isOneShot()) {
            throw IOException("Cannot inject poToken into a one-shot or duplex JSON body")
        }
        val declared = body.contentLength()
        if (declared > MAX_BODY_BYTES) throw IOException("JSON request body is too large for poToken injection")

        val buffer = Buffer()
        body.writeTo(buffer)
        if (buffer.size > MAX_BODY_BYTES) throw IOException("JSON request body is too large for poToken injection")
        val text = buffer.readUtf8()

        val root = try {
            JSONObject(text)
        } catch (e: Throwable) {
            throw IOException("Protected POST body is not a JSON object", e)
        }
        val context = objectAt(root, "context")
        val client = objectAt(context, "client")
        client.put("poToken", payload)

        return request.newBuilder()
            .method(request.method, root.toString().toRequestBody(type))
            .build()
    }

    @Throws(IOException::class)
    private fun objectAt(parent: JSONObject, key: String): JSONObject {
        if (!parent.has(key) || parent.isNull(key)) {
            return JSONObject().also { parent.put(key, it) }
        }
        return parent.optJSONObject(key)
            ?: throw IOException("JSON field '$key' must be an object for poToken injection")
    }
}

/**
 * Enforces one User-Agent on every request and adds the in-memory payload only to allowlisted
 * hosts. Protected POST JSON calls additionally receive context.client.poToken.
 */
class SessionHeadersInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val isProtected = SessionRequestPolicy.protects(original.url.host)
        var request = original.newBuilder()
            // header(), not addHeader(): caller-provided values cannot bypass the policy.
            .header("User-Agent", SessionRequestPolicy.userAgent)
            .build()

        if (isProtected) {
            val payload = SessionWebToken.await(SessionRequestPolicy.waitMs)
            request = request.newBuilder()
                .header(SessionRequestPolicy.tokenHeader, payload)
                .build()
            request = PoTokenJsonInjector.inject(request, payload)
        } else {
            // Do not let an accidentally supplied session payload escape to third-party hosts.
            request = request.newBuilder()
                .removeHeader(SessionRequestPolicy.tokenHeader)
                .build()
        }

        val response = chain.proceed(request)
        if (isProtected && (response.code == 401 || response.code == 403)) {
            SessionWebToken.invalidate()
            SessionWebToken.start(force = true)
        }
        return response
    }
}
