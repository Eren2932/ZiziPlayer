package app.ziziplayer.data.remote

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.IOException
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Loads one trusted HTTPS page in an off-screen WebView and accepts a session payload through:
 *
 *     AndroidTokenBridge.postToken(payload)
 *
 * The payload lives in memory only. The bridge is accepted only while the main frame is on the
 * configured origin; cross-origin main-frame navigation is blocked. Never log the payload here.
 */
object SessionWebToken {

    /**
     * Injected after the trusted page finishes loading. It deliberately reads only explicit page
     * configuration locations; it does not inspect cookies, localStorage or network responses.
     * The polling window covers ytcfg values populated shortly after onPageFinished.
     */
    private val PAGE_TOKEN_EXTRACTOR = """
        (function () {
          if (window.__ziziTokenProbeStarted) return;
          window.__ziziTokenProbeStarted = true;

          function ytcfgValue(key) {
            try {
              if (window.ytcfg && typeof window.ytcfg.get === 'function') {
                var value = window.ytcfg.get(key);
                if (value != null) return value;
              }
              if (window.ytcfg && window.ytcfg.data_) return window.ytcfg.data_[key];
            } catch (_) {}
            return null;
          }

          function clean(value) {
            if (typeof value !== 'string') return '';
            value = value.trim();
            return value.length > 0 && value.length <= 16384 ? value : '';
          }

          function findPayload() {
            var context = ytcfgValue('INNERTUBE_CONTEXT') || {};
            var player = window.ytInitialPlayerResponse || {};
            var candidates = [
              window.__ZIZI_PAYLOAD__,
              context.client && context.client.poToken,
              ytcfgValue('PO_TOKEN'),
              ytcfgValue('PLAYER_PO_TOKEN'),
              player.serviceIntegrityDimensions && player.serviceIntegrityDimensions.poToken,
              ytcfgValue('ID_TOKEN'),
              document.querySelector('meta[name="po-token"]') &&
                document.querySelector('meta[name="po-token"]').content,
              document.querySelector('meta[name="youtube-identity-token"]') &&
                document.querySelector('meta[name="youtube-identity-token"]').content
            ];
            for (var i = 0; i < candidates.length; i++) {
              var payload = clean(candidates[i]);
              if (payload) return payload;
            }
            return '';
          }

          var attempts = 0;
          var timer = setInterval(function () {
            attempts++;
            var payload = findPayload();
            if (payload) {
              clearInterval(timer);
              window.AndroidTokenBridge.postToken(payload);
            } else if (attempts >= 40) {
              clearInterval(timer);
            }
          }, 250);
        })();
    """.trimIndent()

    data class Config(
        val bootstrapUrl: String,
        val maxAgeMs: Long = TimeUnit.HOURS.toMillis(6),
        val loadTimeoutMs: Long = 20_000L,
        val maxPayloadLength: Int = 16_384
    )

    private data class Value(val payload: String, val createdAtMs: Long)

    @Volatile private var appContext: Context? = null
    @Volatile private var config: Config? = null
    @Volatile private var trustedOrigin: Origin? = null
    @Volatile private var webView: WebView? = null
    @Volatile private var mainFrameTrusted = false
    @Volatile private var loading = false
    @Volatile private var waiter = CountDownLatch(0)
    @Volatile private var lastError: String? = null

    private val value = AtomicReference<Value?>()
    private val main = Handler(Looper.getMainLooper())

    val enabled: Boolean get() = config != null && trustedOrigin != null

    fun install(context: Context, config: Config) {
        val origin = Origin.parse(config.bootstrapUrl)
        appContext = context.applicationContext
        this.config = if (origin == null) null else config
        trustedOrigin = origin
        if (origin == null && config.bootstrapUrl.isNotBlank()) {
            lastError = "Session bootstrap URL must be an absolute HTTPS URL"
        }
    }

    /** Starts acquisition without blocking application startup. Safe to call repeatedly. */
    fun start(force: Boolean = false) {
        if (!enabled) return
        if (!force && current() != null) return
        main.post { startOnMain(force) }
    }

    /**
     * Called by OkHttp worker threads. Waits only for protected requests and never blocks the UI.
     */
    @Throws(IOException::class)
    fun await(timeoutMs: Long): String {
        current()?.let { return it }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw IOException("Session payload cannot be awaited on the main thread")
        }
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs.coerceAtLeast(1L))
        start()
        while (true) {
            current()?.let { return it }
            val remainingNs = deadline - System.nanoTime()
            if (remainingNs <= 0L) throw IOException("Timed out waiting for the session payload")

            // start() posts to the main looper. The short loop closes the race where this worker
            // reaches await() before startOnMain() has installed the new run latch.
            val latch = waiter
            if (loading || latch.count > 0L) {
                latch.await(remainingNs, TimeUnit.NANOSECONDS)
                current()?.let { return it }
                if (!loading && lastError != null) {
                    throw IOException(lastError ?: "Session page returned no payload")
                }
            } else {
                Thread.sleep(minOf(25L, TimeUnit.NANOSECONDS.toMillis(remainingNs).coerceAtLeast(1L)))
                start()
            }
        }
    }

    fun invalidate() {
        value.set(null)
        mainFrameTrusted = false
    }

    fun diagnostics(): String {
        val token = current()
        return when {
            token != null -> "payload ready (${token.length} chars)"
            loading -> "session page is loading"
            lastError != null -> "payload unavailable: $lastError"
            !enabled -> "session bridge disabled"
            else -> "payload not requested"
        }
    }

    private fun current(): String? {
        val item = value.get() ?: return null
        val ttl = config?.maxAgeMs ?: return null
        if (System.currentTimeMillis() - item.createdAtMs < ttl) return item.payload
        value.compareAndSet(item, null)
        return null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun startOnMain(force: Boolean) {
        if (!enabled || loading || (!force && current() != null)) return
        val context = appContext ?: return
        val cfg = config ?: return
        val origin = trustedOrigin ?: return

        loading = true
        lastError = null
        mainFrameTrusted = false
        val runWaiter = CountDownLatch(1)
        waiter = runWaiter

        val view = webView ?: WebView(context).also { created ->
            created.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = false
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_NO_CACHE
            }
            webView = created
        }

        view.settings.userAgentString = SessionRequestPolicy.userAgent
        view.clearHistory()
        // A bridge instance belongs to exactly one navigation. A late callback from an older page
        // cannot complete a newer run.
        view.removeJavascriptInterface("AndroidTokenBridge")
        view.addJavascriptInterface(Bridge(runWaiter), "AndroidTokenBridge")
        view.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                mainFrameTrusted = origin.matches(url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (loading && origin.matches(url)) {
                    view.evaluateJavascript(PAGE_TOKEN_EXTRACTOR, null)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val allowed = origin.matches(request.url.toString())
                if (!allowed) finishFailure("Cross-origin navigation was blocked")
                return !allowed
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) finishFailure("WebView load error: ${error.errorCode}")
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    finishFailure("Session page returned HTTP ${errorResponse.statusCode}")
                }
            }
        }

        main.postDelayed({
            if (waiter === runWaiter && loading) finishFailure("Session page timed out")
        }, cfg.loadTimeoutMs)
        view.loadUrl(cfg.bootstrapUrl, mapOf("Cache-Control" to "no-cache"))
    }

    private fun finishSuccess(payload: String) {
        if (!loading) return
        val cfg = config ?: return
        if (!mainFrameTrusted) {
            finishFailure("Payload was rejected outside the trusted origin")
            return
        }
        if (payload.isBlank() || payload.length > cfg.maxPayloadLength ||
            payload.any { it.code !in 0x20..0x7e }
        ) {
            finishFailure("Session page returned an invalid payload")
            return
        }
        value.set(Value(payload, System.currentTimeMillis()))
        lastError = null
        finishRun()
    }

    private fun finishFailure(message: String) {
        if (!loading) return
        lastError = message.take(200)
        finishRun()
    }

    private fun finishRun() {
        loading = false
        mainFrameTrusted = false
        waiter.countDown()
        webView?.stopLoading()
    }

    private class Bridge(private val runWaiter: CountDownLatch) {
        @JavascriptInterface
        fun postToken(payload: String?) {
            val clean = payload ?: ""
            main.post {
                if (waiter === runWaiter && loading) finishSuccess(clean)
            }
        }
    }

    private data class Origin(val scheme: String, val host: String, val port: Int) {
        fun matches(url: String?): Boolean {
            if (url.isNullOrBlank()) return false
            val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
            val candidateHost = uri.host?.lowercase(Locale.US) ?: return false
            val candidateScheme = uri.scheme?.lowercase(Locale.US) ?: return false
            val candidatePort = if (uri.port == -1) 443 else uri.port
            return candidateScheme == scheme && candidateHost == host && candidatePort == port
        }

        companion object {
            fun parse(url: String): Origin? {
                if (url.isBlank()) return null
                val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return null
                val scheme = uri.scheme?.lowercase(Locale.US) ?: return null
                val host = uri.host?.lowercase(Locale.US) ?: return null
                if (scheme != "https") return null
                return Origin(scheme, host, if (uri.port == -1) 443 else uri.port)
            }
        }
    }
}
