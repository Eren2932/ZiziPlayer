package app.ziziplayer.data

import app.ziziplayer.data.remote.CatalogRegistry
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.toEntity
import app.ziziplayer.playback.RemoteRuntime

import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Папка выбрана, но долговременного доступа к ней нет (6.19.0).
 *
 * Отдельный тип, а не общий Throwable: наверху их обрабатывают по-разному — эту показываем
 * пользователю как понятный текст, любую другую как «не удалось прочитать папку».
 */
class FolderAccessException(message: String) : Exception(message)

/**
 * Что показала проверка источников на входе в приложение (6.27.1).
 *
 * Появилось по жалобе тестировщика: «удалил папку через проводник, в плеере она осталась». До
 * этой версии медиатека обновлялась ИСКЛЮЧИТЕЛЬНО по действию человека — подключил папку, отключил
 * папку, нажал «Пересканировать». Диск при этом живёт своей жизнью: файлы удаляют проводником,
 * переносят на карту, чистят «умной очисткой» от производителя. Приложение узнавало об этом
 * последним, и выглядело это ровно как «плеер показывает то, чего нет».
 *
 * Проверка нарочно не является сканированием. Три дешёвых вопроса вместо обхода дерева:
 * читается ли ещё каждая подключённая папка, столько ли музыки видит система, сколько лежит у нас,
 * и жив ли хоть один документ из выборки. Любое расхождение — повод запустить настоящее
 * пересканирование в фоне, и только оно меняет базу.
 */
data class SourceCheck(
    /** Подключённые папки, которые больше не читаются: удалены или доступ отозван. */
    val lostFolders: List<String> = emptyList(),
    /** Сколько документов из выборки не открылось. Это признак, а не счёт всех пропавших файлов. */
    val missingDocuments: Int = 0,
    /** Разница «сколько видит MediaStore» минус «сколько его строк у нас». */
    val mediaStoreDrift: Int = 0
) {
    val stale: Boolean get() = lostFolders.isNotEmpty() || missingDocuments > 0 || mediaStoreDrift != 0

    /** Пропало ли что-то на диске — то есть надо ли говорить об этом человеку словами. */
    val lostSomething: Boolean get() = lostFolders.isNotEmpty() || missingDocuments > 0 || mediaStoreDrift < 0
}

/** Сколько документов проверяется на существование за одну проверку. См. [SourceCheck]. */
private const val DOCUMENT_PROBE_LIMIT = 40

/** SQLite refuses more than 999 bound variables in one statement; stay well below it. */
private const val DELETE_CHUNK = 400

/** Потолок параметров в `IN (...)`: у SQLite их 999, берём с запасом. */
private const val IN_CHUNK = 400
        /** Unsaved remote rows are kept this long after they were last touched. */
        const val REMOTE_RETENTION_DAYS = 30

class MusicRepository(
    private val context: Context,
    private val dao: MusicDao,
    private val settingsStore: SettingsStore,
    private val scanner: MusicScanner,
    private val playbackMemory: PlaybackMemory
) {
    /** The library. Local files plus saved remote tracks; see [MusicDao.observeTracks]. */
    val tracks = dao.observeTracks()

    /** Id resolution only: includes remote tracks that were played but not saved. */
    val allTracks = dao.observeAllTracks()

    val searchHistory = dao.observeSearchHistory()

    /** Недавно открытое: треки, сборники и запросы. Поверхность «Недавние» в поиске. */
    val recents = dao.observeRecents()

    /** The configured catalogues. Held in [RemoteRuntime] because the loader thread needs them too. */
    val catalogs: CatalogRegistry get() = RemoteRuntime.registry

    // ---------------------------------------------------------------- network catalogue

    /**
     * Writes remote tracks into `tracks` so the rest of the app can treat them as tracks.
     *
     * Called on the way to playback, never on the way to a search result list. Search results are a
     * screenful of strangers that live in memory and disappear with the screen; a row in the
     * database means the player, the queue, the FX table and the play counters can resolve the id -
     * and that is only needed once the user actually presses play or save.
     */
    suspend fun rememberRemote(tracks: List<RemoteTrack>): List<TrackEntity> {
        if (tracks.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val entities = tracks.map { it.toEntity(now) }
        dao.rememberRemote(entities, now)
        // Re-read: a track that was already saved keeps its savedAt, and the row on disk may hold
        // better metadata than the search result we were handed.
        return entities.mapNotNull { dao.track(it.id) ?: it }
    }

    suspend fun setRemoteSaved(trackId: String, saved: Boolean) {
        if (saved) dao.markSaved(trackId, System.currentTimeMillis()) else dao.markUnsaved(trackId)
    }

    /**
     * Drops browsing leftovers. Cheap, and it has to happen somewhere: a table fed by a search
     * screen grows forever otherwise.
     */
    suspend fun sweepRemote(retentionDays: Int = REMOTE_RETENTION_DAYS) {
        val before = System.currentTimeMillis() - retentionDays * 24L * 60 * 60 * 1000
        val stale = dao.forgettableRemoteIds(before)
        if (stale.isEmpty()) return
        stale.chunked(DELETE_CHUNK).forEach { dao.deleteTracks(it) }
    }

    suspend fun rememberQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.length < 2) return
        dao.rememberQuery(SearchQueryEntity(trimmed))
        dao.trimSearchHistory()
    }

    suspend fun forgetQuery(query: String) = dao.forgetQuery(query)
    suspend fun clearSearchHistory() = dao.clearSearchHistory()

    /**
     * Записать недавнее и тут же подрезать хвост.
     *
     * Подрезка стоит здесь, а не в отдельной уборке по расписанию, ровно по той же причине, что и
     * у trimSearchHistory: таблица растёт только в этой точке, значит и ограничивать её дешевле
     * всего в ней же — один DELETE по индексированному полю против фонового обхода базы.
     */
    suspend fun rememberRecent(item: RecentEntity) {
        if (item.title.isBlank()) return
        dao.rememberRecent(item)
        dao.trimRecents()
    }

    suspend fun forgetRecent(key: String) = dao.forgetRecent(key)
    suspend fun clearRecents() = dao.clearRecents()
    /**
     * distinctUntilChanged после map — не украшение (6.19.0).
     *
     * Room уведомляет подписчиков по факту записи в таблицу, а не по факту изменения результата
     * запроса: снять избранное и тут же поставить обратно — это два эмита с одинаковым содержимым.
     * Каждый из них создавал новый Set, новый Set давал новое состояние экрана, а новое состояние
     * заставляло Compose пересобрать список. Сравнение множеств стоит микросекунды, пересборка
     * списка на 3000 треков — кадр.
     */
    val favoriteIds = dao.observeFavoriteIds().map { it.toSet() }.distinctUntilChanged()

    /**
     * Избранное списком треков (6.27.1). См. [MusicDao.observeFavoriteTracks] — там причина.
     */
    val favoriteTracks = dao.observeFavoriteTracks()
    val hiddenIds = dao.observeHiddenIds().map { it.toSet() }.distinctUntilChanged()
    val playlists = dao.observePlaylists()
    val playlistCounts: Flow<Map<Long, Int>> = dao.observePlaylistCounts().map { list -> list.associate { it.playlistId to it.total } }

    /**
     * Количество и общее время в одном потоке (6.17.0).
     *
     * Именно потоком, а не парой значений на запрос: подпись под плейлистом обязана меняться сразу
     * после добавления трека, а не после перехода на другой экран и обратно.
     */
    val playlistMeta: Flow<Map<Long, PlaylistMeta>> = combine(
        dao.observePlaylistCounts(),
        dao.observePlaylistDurations(),
        dao.observePlaylistCovers()
    ) { counts, durations, covers ->
        val byId = HashMap<Long, PlaylistMeta>(counts.size)
        counts.forEach { byId[it.playlistId] = PlaylistMeta(count = it.total) }
        durations.forEach { row ->
            val current = byId[row.playlistId] ?: PlaylistMeta()
            byId[row.playlistId] = current.copy(totalMs = row.totalMs)
        }
        covers.forEach { row ->
            val current = byId[row.playlistId] ?: PlaylistMeta()
            byId[row.playlistId] = current.copy(cover = row.track)
        }
        byId
    }

    /** Сборники из поиска, уже добавленные к себе: ключ сборника -> связь с плейлистом. */
    val collectionLinks: Flow<Map<String, PlaylistLinkEntity>> =
        dao.observePlaylistLinks().map { list -> list.associateBy { it.collectionKey } }
    val stats: Flow<Map<String, PlayStatEntity>> = dao.observeStats().map { list -> list.associateBy { it.trackId } }
    val settings = settingsStore.settings

    /**
     * Rebuilds the library.
     *
     * Order is load-bearing:
     *
     * 1. scan every source;
     * 2. **remap ids before anything is deleted** - the old rows are still in place, so the child
     *    tables can be moved onto the new keys while both ends of the mapping exist;
     * 3. upsert the fresh rows;
     * 4. delete the rows that no longer match a file;
     * 5. prune child rows whose track is gone.
     *
     * Step 5 used to be unreachable whenever nothing had gone stale (the function returned early),
     * so orphan favourites and playlist entries accumulated forever. It now always runs.
     *
     * [onProgress] is called from the scanner's worker threads.
     */
    suspend fun rescan(onProgress: (ScanProgress) -> Unit = {}) {
        // Browsing leftovers are swept on the library's own schedule: once per launch, off the main
        // thread, nowhere near anything the user is waiting for.
        runCatching { sweepRemote() }
        val folders = settings.first().folderUris
        onProgress(ScanProgress(0, 0, "Поиск музыки"))

        val fromMediaStore = scanner.scanMediaStore()
        onProgress(ScanProgress(fromMediaStore.size, 0, "Папки"))

        // Handed to the scanner so unchanged files skip tag reading entirely.
        val known = if (folders.isEmpty()) emptyMap() else dao.allTracks().associateBy { it.id }

        val fromFolders = ArrayList<TrackEntity>()
        folders.forEach { folder ->
            val uri = runCatching { Uri.parse(folder) }.getOrNull() ?: return@forEach
            fromFolders += scanner.scanTree(uri, known) { done, total ->
                onProgress(ScanProgress(done, total, "Чтение тегов"))
            }
        }

        // MediaStore comes first, so when the same file is reachable both ways the richer row wins:
        // it carries album art and did not need a decoder. Deduplication is now by identity rather
        // than by the old "title|artist|duration" guess, which merged genuinely different tracks
        // that happened to share a name and length (live versions, remasters, sped-up edits - of
        // which this library has a great many).
        val all = (fromMediaStore + fromFolders).distinctBy { it.id }

        // 6.19.0. Здесь стоял `if (all.isEmpty()) return`, и он ломал ровно тот сценарий, для
        // которого шаги 4 и 5 существуют: человек убрал последнюю подключённую папку (или отозвал
        // разрешение на память) — искать стало негде, ноль треков — и функция уходила, не удалив
        // ни одной устаревшей строки. Медиатека оставалась полна треков, которых больше нет ни в
        // одном источнике: тапаешь — «файл не найден», и убрать их нечем, потому что каждое
        // следующее сканирование выходило на том же самом `return`.
        //
        // Пустой результат — это не «ничего не делать», это «источников не осталось». Разница в
        // одном: пустой список нельзя пропускать через upsert и remap (нечего вставлять и нечего
        // сопоставлять), а вот удаление устаревшего и уборку сирот выполнить обязательно.
        if (all.isEmpty()) {
            val orphaned = dao.allTrackIds()
            orphaned.chunked(DELETE_CHUNK).forEach { dao.deleteTracks(it) }
            pruneOrphans()
            onProgress(ScanProgress(0, 0, "Источников не осталось"))
            return
        }

        migrateLegacyIds(all)

        dao.upsertTracks(all)
        // Stale ids are computed here instead of inside SQL: see MusicDao.deleteTracks.
        val keep = HashSet<String>(all.size * 2)
        all.forEach { keep.add(it.id) }
        val stale = dao.allTrackIds().filterNot { keep.contains(it) }
        stale.chunked(DELETE_CHUNK).forEach { dao.deleteTracks(it) }
        pruneOrphans()
        onProgress(ScanProgress(all.size, all.size, "Готово"))
    }

    /**
     * Moves the user's data from the old provider-derived ids onto the content-derived ones, once.
     *
     * The work is bounded by what the user actually has, not by the library size: only ids that
     * appear in favourites, playlists, FX, hidden or stats are touched. A 3000-track library with 40
     * favourites and 3 playlists does a few dozen updates.
     *
     * The flag is set only after the remap completes, so a process death half way through means the
     * next launch simply tries again - the old rows are still there, and every UPDATE is idempotent.
     */
    private suspend fun migrateLegacyIds(scanned: List<TrackEntity>) {
        if (settingsStore.idsMigrated()) return
        val referenced = dao.referencedTrackIds().toHashSet()
        if (referenced.isNotEmpty()) {
            scanned.forEach { track ->
                val legacy = track.legacyId
                if (legacy != null && legacy != track.id && referenced.contains(legacy)) {
                    dao.remapTrackId(legacy, track.id)
                    playbackMemory.remapLastTrack(legacy, track.id)
                }
            }
        }
        settingsStore.setIdsMigrated()
    }

    /** Favourites, playlist entries, FX and stats that outlived their track. */
    private suspend fun pruneOrphans() {
        dao.pruneFavorites()
        dao.prunePlaylistTracks()
        dao.pruneFx()
        dao.pruneStats()
        dao.pruneHidden()
    }

    /**
     * Подключает папку. Бросает [FolderAccessException], если провайдер не дал долговременный доступ.
     *
     * 6.19.0: `takePersistableUriPermission` стоял без всякой обработки, а он умеет бросать
     * SecurityException — некоторые файловые менеджеры и облачные провайдеры (Dropbox, часть
     * прошивок Samsung) отдают дерево на один раз и долговременный доступ не выдают. Дальше
     * происходило самое неприятное, что вообще может произойти: исключение всплывало наверх, где
     * `withScan` глотал любой Throwable, бейдж сканирования просто гас, и человек получал ноль
     * информации. Папка не подключилась, ошибки нет, объяснения нет.
     *
     * Теперь отказ доезжает до пользователя словами, а в настройках не остаётся папки-пустышки,
     * которую нельзя прочитать.
     */
    suspend fun addFolder(uri: Uri, onProgress: (ScanProgress) -> Unit = {}) {
        val taken = runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (taken.isFailure) {
            throw FolderAccessException(
                "Эта папка выдаёт доступ только на один раз — приложение не сможет читать её после перезапуска. " +
                    "Выбери папку во «Внутренней памяти» или на карте."
            )
        }
        settingsStore.addFolder(uri)
        rescan(onProgress)
    }

    /**
     * Отключает папку и отдаёт долговременный доступ обратно системе.
     *
     * Без `releasePersistableUriPermission` запись оставалась в
     * `ContentResolver.persistedUriPermissions` навсегда: на приложение есть системный лимит таких
     * записей (128 на большинстве прошивок), и десяток циклов «подключил — отключил» его заметно
     * подъедает. Отказ отпустить доступ игнорируем сознательно: если система его уже отозвала
     * сама, отключение папки всё равно должно состояться.
     */
    suspend fun removeFolder(uri: String, onProgress: (ScanProgress) -> Unit = {}) {
        settingsStore.removeFolder(uri)
        runCatching {
            val parsed = Uri.parse(uri)
            context.contentResolver.releasePersistableUriPermission(parsed, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        rescan(onProgress)
    }

    /**
     * Переключает избранное. Возвращает состояние ПОСЛЕ переключения.
     *
     * 6.19.0: состояние «до» больше не приходит аргументом из UI — см. [MusicDao.toggleFavorite].
     */
    suspend fun toggleFavorite(id: String): Boolean = dao.toggleFavorite(id)

    /** Пачкой, одной транзакцией. Возвращает true, если выбранное стало избранным. */
    suspend fun toggleFavorites(ids: List<String>): Boolean = dao.toggleFavorites(ids)

    suspend fun saveFx(fx: TrackFxEntity) = dao.saveFx(fx)
    suspend fun fx(id: String) = dao.fx(id) ?: TrackFxEntity(id)

    // ---- эквалайзер (6.24.4) ----
    fun eqProfiles() = dao.observeEqProfiles()
    suspend fun saveEqProfile(name: String, config: String) =
        dao.saveEqProfile(EqProfileEntity(name.trim().take(40), config))
    suspend fun deleteEqProfile(name: String) = dao.deleteEqProfile(name)
    suspend fun eqProfileCount() = dao.eqProfileCount()

    suspend fun createPlaylist(name: String) = dao.createPlaylist(PlaylistEntity(name = name))
    /**
     * 6.19.0: через транзакционный пакетный метод, а не «прочитать nextPosition, потом вставить».
     * Два быстрых добавления подряд (двойной тап по «в плейлист») успевали прочитать одну и ту же
     * позицию и вставить два трека с одинаковым position — порядок в плейлисте становился
     * неопределённым. Заодно повторное добавление того же трека больше не переставляет его в конец.
     */
    suspend fun addToPlaylist(playlistId: Long, trackId: String) =
        dao.addTracksToPlaylist(playlistId, listOf(trackId))
    suspend fun removeFromPlaylist(playlistId: Long, trackId: String) = dao.removeFromPlaylist(playlistId, trackId)

    /* ------------------------------------------------------------ пакетные операции (6.17.0) */

    /**
     * Кусками по [IN_CHUNK]: SQLite отказывается разбирать запрос больше чем с 999 параметрами, и
     * «выделить всё» в медиатеке на 3000 треков — это ровно тот случай, когда лимит достигается.
     */
    suspend fun addTracksToPlaylist(playlistId: Long, trackIds: List<String>) {
        trackIds.chunked(IN_CHUNK).forEach { dao.addTracksToPlaylist(playlistId, it) }
    }

    suspend fun removeTracksFromPlaylist(playlistId: Long, trackIds: List<String>) {
        trackIds.chunked(IN_CHUNK).forEach { dao.removeTracksFromPlaylist(playlistId, it) }
    }

    suspend fun moveTracksBetweenPlaylists(fromPlaylistId: Long, toPlaylistId: Long, trackIds: List<String>) {
        trackIds.chunked(IN_CHUNK).forEach { dao.moveTracksBetweenPlaylists(fromPlaylistId, toPlaylistId, it) }
    }

    /** «Убрать из медиатеки» для пачки сетевых треков: строки остаются, метка сохранения снимается. */
    suspend fun setRemoteSavedMany(trackIds: List<String>, saved: Boolean) {
        val now = System.currentTimeMillis()
        trackIds.chunked(IN_CHUNK).forEach {
            if (saved) dao.markSavedMany(it, now) else dao.markUnsavedMany(it)
        }
    }

    suspend fun linkCollection(collectionKey: String, playlistId: Long, title: String, owned: Boolean) =
        dao.linkCollection(PlaylistLinkEntity(collectionKey, playlistId, title, owned))

    suspend fun unlinkCollection(collectionKey: String) = dao.unlinkCollection(collectionKey)
    suspend fun pruneCollectionLinks() = dao.pruneLinks()

    suspend fun deletePlaylist(id: Long) = dao.deletePlaylistFull(id)
    suspend fun renamePlaylist(id: Long, name: String) = dao.renamePlaylist(id, name)
    suspend fun playlistTracks(playlistId: Long) = dao.playlistTracks(playlistId)
    fun observePlaylistTracks(playlistId: Long) = dao.observePlaylistTracks(playlistId)

    /** "Remove from my set": the track stays on the phone, it just never shows up again. */
    suspend fun hideTrack(id: String) = dao.hide(HiddenEntity(id))
    suspend fun unhideTrack(id: String) = dao.unhide(id)
    suspend fun clearHidden() = dao.clearHidden()

    suspend fun registerPlay(id: String) {
        dao.ensureStat(PlayStatEntity(id))
        dao.bumpStat(id, System.currentTimeMillis())
    }

    /** Forgets a row after its file is gone. */
    suspend fun forgetTrack(id: String) {
        dao.unfavorite(id)
        dao.deleteTrack(id)
    }

    /**
     * Deletes the real file. Android 11+ requires user confirmation for MediaStore items,
     * so we hand the IntentSender back to the activity instead of failing silently.
     */
    suspend fun requestFileDeletion(track: TrackEntity): IntentSender? {
        val uri = runCatching { Uri.parse(track.uri) }.getOrNull() ?: return null
        val resolver = context.contentResolver
        if (DocumentsContract.isDocumentUri(context, uri)) {
            runCatching { DocumentsContract.deleteDocument(resolver, uri) }
            forgetTrack(track.id)
            return null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return runCatching { MediaStore.createDeleteRequest(resolver, listOf(uri)).intentSender }.getOrNull()
        }
        runCatching { resolver.delete(uri, null, null) }
        forgetTrack(track.id)
        return null
    }

    // ---------------------------------------------------------------- избранное (6.27.1)

    /**
     * Восстанавливает избранное, у которого пропала строка трека, и досоздаёт тени тем лайкам,
     * которые появились до 6.27.1. Возвращает, сколько треков вернулось.
     *
     * Локальный трек восстанавливается только если файл действительно на месте: иначе следующее
     * пересканирование удалило бы его снова, а следующий запуск снова восстановил — призрак,
     * который мигает в списке и не поддаётся объяснению. Сетевой возвращается всегда: он не
     * привязан к файлу, а `savedAt` ему проставляется сознательно (см. [FavoriteShadowEntity]),
     * потому что «я это отметил» — и есть решение хранить.
     */
    suspend fun repairFavorites(): Int = withContext(Dispatchers.IO) {
        val orphans = dao.orphanedFavoriteShadows()
        val restorable = orphans.filter { it.source == TrackSource.REMOTE || documentAlive(it.uri) }
        if (restorable.isNotEmpty()) {
            val now = System.currentTimeMillis()
            restorable.chunked(DELETE_CHUNK).forEach { chunk ->
                dao.insertIgnoreTracks(chunk.map { it.toTrack(now) })
            }
        }
        // Догоняем тех, кто обновляется с 6.27.0 и раньше: у их лайков тени ещё нет, и до первого
        // повторного нажатия сердца они остались бы незащищёнными.
        val backfill = dao.favoriteTracksWithoutShadow()
        if (backfill.isNotEmpty()) dao.writeFavoriteShadows(backfill)
        restorable.size
    }

    // ---------------------------------------------------------------- состояние источников

    /**
     * Три дешёвых вопроса к системе. Ничего не пишет — только смотрит. См. [SourceCheck].
     */
    suspend fun checkSources(): SourceCheck = withContext(Dispatchers.IO) {
        val folders = settings.first().folderUris
        val lost = folders.filter { folder ->
            val uri = runCatching { Uri.parse(folder) }.getOrNull() ?: return@filter true
            !treeReadable(uri)
        }
        val seen = scanner.mediaStoreCount()
        val ours = runCatching { dao.mediaStoreTrackCount() }.getOrDefault(0)
        val drift = if (seen < 0) 0 else seen - ours
        val missing = runCatching {
            dao.documentTrackSample(DOCUMENT_PROBE_LIMIT).count { !documentAlive(it.uri) }
        }.getOrDefault(0)
        SourceCheck(lostFolders = lost, missingDocuments = missing, mediaStoreDrift = drift)
    }

    /**
     * Дерево ещё наше и ещё существует?
     *
     * Проверяется не разрешением, а запросом к содержимому: разрешение остаётся в
     * `persistedUriPermissions` и после того, как папку удалили — система не обязана его снимать.
     * Единственный честный признак — отдаёт ли провайдер список детей.
     */
    private fun treeReadable(tree: Uri): Boolean = runCatching {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        context.contentResolver.query(
            children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null
        )?.use { true } ?: false
    }.getOrDefault(false)

    /** Открывается ли ещё файл по этому адресу. Одна строка курсора, никакого чтения байтов. */
    private fun documentAlive(raw: String): Boolean = runCatching {
        val uri = Uri.parse(raw)
        if (uri.scheme == "zizi") return@runCatching true
        context.contentResolver.query(uri, null, null, null, null)?.use { it.count > 0 } ?: false
    }.getOrDefault(false)

    // ---------------------------------------------------------------- папки: имя и удаление

    suspend fun setFolderLabel(name: String, label: String) = settingsStore.setFolderLabel(name, label)

    /**
     * Удаление папки НАСОВСЕМ: файлы уходят с устройства.
     *
     * Документы подключённого дерева удаляются здесь же, строкой за строкой — у SAF нет пакетного
     * удаления. Для того, что пришло из MediaStore, возвращается [IntentSender]: с Android 11
     * приложение не вправе удалить чужой файл без системного подтверждения, и это правильно.
     * Пачкой, одним диалогом на всю папку, а не по файлу — иначе удаление папки из сорока треков
     * это сорок нажатий «Разрешить».
     */
    suspend fun requestFolderDeletion(tracks: List<TrackEntity>): IntentSender? {
        if (tracks.isEmpty()) return null
        val resolver = context.contentResolver
        val mediaUris = ArrayList<Uri>(tracks.size)
        tracks.forEach { track ->
            val uri = runCatching { Uri.parse(track.uri) }.getOrNull() ?: return@forEach
            if (DocumentsContract.isDocumentUri(context, uri)) {
                runCatching { DocumentsContract.deleteDocument(resolver, uri) }
                forgetTrack(track.id)
            } else mediaUris += uri
        }
        if (mediaUris.isEmpty()) return null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return runCatching { MediaStore.createDeleteRequest(resolver, mediaUris).intentSender }.getOrNull()
        }
        mediaUris.forEach { runCatching { resolver.delete(it, null, null) } }
        tracks.forEach { forgetTrack(it.id) }
        return null
    }

    // ---------------------------------------------------------------- обложка плейлиста

    suspend fun setPlaylistCover(playlistId: Long, uri: String?) = dao.setPlaylistCover(playlistId, uri)

    /** Обложку получает первый добавленный сборник; см. [MusicDao.setPlaylistCoverIfEmpty]. */
    suspend fun noteFirstCover(playlistId: Long, artworkUrl: String?) {
        val url = artworkUrl?.trim()?.takeIf { it.isNotEmpty() } ?: return
        dao.setPlaylistCoverIfEmpty(playlistId, url)
    }

    suspend fun setTheme(theme: AppTheme) = settingsStore.setTheme(theme)
    suspend fun setDynamicAccent(value: Boolean) = settingsStore.setDynamicAccent(value)
    suspend fun setSkipSilence(value: Boolean) = settingsStore.setSkipSilence(value)
    suspend fun setDspGlobal(value: Boolean) = settingsStore.setDspGlobal(value)
    suspend fun setGlobalDsp(config: String) = settingsStore.setGlobalDsp(config)
    suspend fun setSortMode(value: SortMode) = settingsStore.setSortMode(value)
    suspend fun setCatalogProvider(value: String) = settingsStore.setCatalogProvider(value)
    suspend fun setWifiOnly(value: Boolean) = settingsStore.setWifiOnly(value)
    suspend fun setStreamQuality(value: app.ziziplayer.data.remote.RemoteQuality) = settingsStore.setStreamQuality(value)
    suspend fun setStreamCacheEnabled(value: Boolean) = settingsStore.setStreamCacheEnabled(value)
    suspend fun setResolverUrl(value: String) = settingsStore.setResolverUrl(value)
    suspend fun setResolverToken(value: String) = settingsStore.setResolverToken(value)
    suspend fun setResolverProxy(value: Boolean) = settingsStore.setResolverProxy(value)
    suspend fun setDevMode(value: Boolean) = settingsStore.setDevMode(value)
    /** Cheap, flow-free write: saving the position must never touch the library pipeline. */
    fun saveLastPosition(trackId: String, positionMs: Long) = playbackMemory.save(trackId, positionMs)
    fun lastTrackId(): String? = playbackMemory.lastTrackId()
    fun lastPositionMs(): Long = playbackMemory.lastPositionMs()
}
