package app.ziziplayer.ui;

import javax.crypto.AEADBadTagException;

/**
 * 6.84.13 (H1). Когда зашифрованный файл RecoVault можно удалять. Раньше удалялся при ЛЮБОМ исключении чтения, и
 * кратковременный сбой AndroidKeyStore на холодном процессе стирал снимок главной (и состояние выбора вкуса)
 * навсегда. Теперь удаляем только если файл гарантированно непригоден: тег GCM не сошёлся (ключ другой или данные
 * повреждены) или размер не годится. Всё остальное (KeyStore, IO, провайдер) считаем временным: файл остаётся,
 * чтение возвращает «пусто», повтор не раньше чем через RETRY_BACKOFF_MS.
 */
public final class VaultReadPolicy {
    private VaultReadPolicy() {}

    public static final long RETRY_BACKOFF_MS = 30_000L;

    public static boolean isPermanent(Throwable error) {
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            if (t instanceof AEADBadTagException) return true;
            if (t instanceof IllegalArgumentException) return true;   // наш размер/формат файла
        }
        return false;
    }

    public static boolean isTransient(Throwable error) { return !isPermanent(error); }

    /** Размер шифртекста с учётом nonce (12) и тега (16): всё, что вне диапазона, повреждено навсегда. */
    public static boolean sizeAcceptable(int size, int maxBytes) { return size >= 29 && size <= maxBytes; }

    /** Читать ли файл сейчас: после временного сбоя ждём RETRY_BACKOFF_MS, чтобы не долбить KeyStore. */
    public static boolean mayRetry(long nowMs, long blockedUntilMs) { return nowMs >= blockedUntilMs; }

}
