package app.ziziplayer.playback;

/** Bounded retry scheduling; rebinding is never an automatic playback request. */
public final class PlaybackReconnectPolicy {
    private PlaybackReconnectPolicy() {}
    public static long retryDelay(int attempt) {
        return Math.min(5000L, 500L << Math.min(4, Math.max(0, attempt)));
    }
    public static boolean shouldReconnect(boolean visible, boolean pendingUserQueue, boolean closed) {
        return !closed && (visible || pendingUserQueue);
    }
}
