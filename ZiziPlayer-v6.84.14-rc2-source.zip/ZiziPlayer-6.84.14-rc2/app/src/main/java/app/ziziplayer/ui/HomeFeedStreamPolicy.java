package app.ziziplayer.ui;

import java.util.HashSet;

/**
 * 6.82.0. Арифметика бесконечной ленты «Для тебя» и дозаправки очереди плеера.
 *
 * Всё решение «грузить ли дальше», «что считать повтором» и «пора ли добавить треки в очередь»
 * живёт здесь, на чистой Java без Android: Kotlin в песочнице не компилируется, а эта логика
 * гоняется на JVM (HomeFeed6820Checks). Kotlin-часть только исполняет решения.
 *
 * Лента — одна растущая только вперёд последовательность. Очередь плеера — её потребитель со своим
 * указателем; экран — второй потребитель. Поэтому страница, подгруженная прокруткой, не теряется
 * для очереди, а страница, добавленная в очередь, видна в ленте.
 */
public final class HomeFeedStreamPolicy {
    private HomeFeedStreamPolicy() {}

    /** Идентификатор источника очереди: по нему плеер знает, что очередь — это лента. */
    public static final String SOURCE_ID = "home:reco-feed";
    /** Префикс ключа строки в LazyColumn; за ним идёт индекс в ленте. */
    public static final String KEY_PREFIX = "reco-feed:";
    /** Сколько треков просим на страницу (сервер зажимает в 10..50). */
    public static final int PAGE_SIZE = 30;
    /** Подгружаем, когда до конца ленты осталось не больше стольких строк. */
    public static final int PREFETCH_ROWS = 8;
    /** Потолок ленты в памяти. Сервер держит 8000 выданных; телефону столько не нужно. */
    public static final int MAX_TRACKS = 1500;
    /** Возраст буфера/профиля ленты: 3 часа, как FEED_TTL серверной сессии. */
    public static final long PROFILE_AGE_MS = 3L * 60L * 60_000L;
    /** MainViewModel.useTracks берёт максимум 200 треков: очередь из ленты не длиннее. */
    public static final int QUEUE_WINDOW = 200;
    /** Дозаправляем очередь, когда впереди осталось не больше стольких треков. */
    public static final int QUEUE_LOW_WATER = 5;
    /** Сколько треков добавляем за одну дозаправку. */
    public static final int QUEUE_BATCH = 20;
    /** Подряд пустых страниц при more=true, после которых лента останавливается с кнопкой «Повторить». */
    public static final int MAX_EMPTY_PAGES = 3;

    /** Страница дала новые треки. */
    public static final int PAGE_OK = 0;
    /** Новых треков нет, но лента не кончилась: просим ещё раз. */
    public static final int PAGE_RETRY = 1;
    /** Лента закончилась: сервер сказал more=false и ничего нового не дал. */
    public static final int PAGE_END = 2;
    /** Несколько страниц подряд без новых треков при more=true: останавливаемся, ждём действия. */
    public static final int PAGE_STALL = 3;

    /**
     * Исход страницы. [accepted] — треков после дедупликации и фильтров, [emptyStreak] — сколько
     * страниц ПЕРЕД этой подряд не дали ничего нового.
     */
    public static int pageOutcome(int accepted, boolean more, int emptyStreak) {
        if (accepted > 0) return PAGE_OK;
        if (!more) return PAGE_END;
        return emptyStreak + 1 >= MAX_EMPTY_PAGES ? PAGE_STALL : PAGE_RETRY;
    }

    /**
     * Пауза перед повтором пустой страницы. Сервер на холодном кэше сам просит подождать (`retry_ms`);
     * если он молчит, а страница пустая из-за дедупликации, ждать незачем — следующая страница другая.
     */
    public static long emptyPageDelayMs(long hintMs) {
        if (hintMs <= 0L) return 0L;
        return Math.max(1_000L, Math.min(10_000L, hintMs));
    }

    /** Индекс в ленте по ключу строки LazyColumn; -1, если это не строка ленты. */
    public static int indexOfKey(Object key) {
        if (!(key instanceof String)) return -1;
        String text = (String) key;
        if (!text.startsWith(KEY_PREFIX)) return -1;
        String tail = text.substring(KEY_PREFIX.length());
        if (tail.isEmpty() || tail.length() > 9) return -1;
        for (int i = 0; i < tail.length(); i++) {
            char c = tail.charAt(i);
            if (c < '0' || c > '9') return -1;
        }
        return Integer.parseInt(tail);
    }

    public static String keyOf(int index) {
        return KEY_PREFIX + index;
    }

    /**
     * Пора ли просить следующую страницу. [lastVisibleFeedIndex] — индекс последней видимой строки
     * ленты (-1, если на экране ни одной нет). Не грузим, пока идёт загрузка, и не долбим сервер после
     * ошибки: после неё ждём явного «Повторить».
     */
    public static boolean shouldLoadMore(int lastVisibleFeedIndex, int feedSize, boolean more,
                                         boolean loading, boolean failed) {
        if (!more || loading || failed) return false;
        if (feedSize >= MAX_TRACKS) return false;
        if (lastVisibleFeedIndex < 0) return false;
        if (feedSize <= 0) return false;
        return lastVisibleFeedIndex >= feedSize - PREFETCH_ROWS;
    }

    /** Сколько ещё треков влезет в ленту до потолка MAX_TRACKS. */
    public static int roomLeft(int size) {
        return Math.max(0, MAX_TRACKS - Math.max(0, size));
    }

    /**
     * Окно очереди плеера для тапа по строке [tapIndex]: от тапнутого трека вперёд, не больше
     * QUEUE_WINDOW. Треки ДО тапнутого в очередь не идут: лента — радио, она играет вперёд.
     * Возвращает {from, to} (to не включается); пустое окно — {0, 0}.
     */
    public static int[] queueWindow(int tapIndex, int size) {
        if (size <= 0 || tapIndex < 0 || tapIndex >= size) return new int[] {0, 0};
        return new int[] {tapIndex, Math.min(size, tapIndex + QUEUE_WINDOW)};
    }

    /**
     * Нужна ли очереди дозаправка. [fedUpTo] — индекс в ленте, с которого брать следующие треки
     * (-1: очередь не из ленты или неизвестно, что уже в ней). Не при shuffle: перемешанная очередь
     * не имеет «конца впереди», добавка улетела бы в случайное место.
     */
    public static boolean queueNeedsMore(String queueSource, boolean shuffle, int queueSize,
                                         int currentIndex, int fedUpTo) {
        if (!SOURCE_ID.equals(queueSource) || shuffle || fedUpTo < 0) return false;
        if (queueSize <= 0 || currentIndex < 0 || currentIndex >= queueSize) return false;
        int remaining = queueSize - currentIndex - 1;
        return remaining <= QUEUE_LOW_WATER;
    }

    /** Ключ «тот же трек под другим id»: перезапуск сессии на сервере не должен вернуть уже виденное. */
    public static String dedupeKey(String artist, String title) {
        return HomeFeedPolicy.normalize(artist) + "|" + HomeFeedPolicy.normalize(title);
    }

    /**
     * Память «что уже в ленте». Повтор по id ИЛИ по паре «артист|название»: сервер дедуплицирует
     * внутри сессии, но после перезапуска сессии (restarted) присылает всё с начала, и без этого
     * фильтра человек увидел бы свои же треки второй раз.
     */
    public static final class Seen {
        private final HashSet<String> ids = new HashSet<>();
        private final HashSet<String> keys = new HashSet<>();

        /** true — трек новый и теперь запомнен; false — повтор. Пустой id повтором не считается по id. */
        public boolean offer(String id, String artist, String title) {
            String key = dedupeKey(artist, title);
            boolean idNew = id == null || id.isEmpty() || !ids.contains(id);
            boolean keyNew = key.length() <= 1 || !keys.contains(key);
            if (!idNew || !keyNew) return false;
            if (id != null && !id.isEmpty()) ids.add(id);
            if (key.length() > 1) keys.add(key);
            return true;
        }

        public int size() { return ids.size(); }

        public void clear() { ids.clear(); keys.clear(); }
    }
}
