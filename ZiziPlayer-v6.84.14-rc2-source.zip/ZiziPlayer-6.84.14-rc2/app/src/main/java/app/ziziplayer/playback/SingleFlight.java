package app.ziziplayer.playback;

import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

/**
 * 6.84.12. Один запрос на ключ, остальные ждут его результат.
 *
 * Media3 зовёт [StreamResolver] из нескольких загрузочных потоков (открытие потока, повторное
 * открытие диапазона, прогрев кэша), и каждый делал свой `/match/deezer` и `/resolve` для того же
 * трека: в серверном логе один и тот же id приходил дважды с разницей в секунду.
 *
 * Правила:
 *  - успех лидера читается из внешнего кэша ([cached]) или из его же результата;
 *  - ошибка лидера уходит всем ждущим тем же объектом (повторять то же самое здесь бессмысленно);
 *  - ЕСЛИ ЛИДЕРА ОТМЕНИЛИ (пользователь пропустил трек — прерывание потока), ждущие не наследуют
 *    чужую отмену, а берут работу на себя: их трек никто не пропускал.
 */
public final class SingleFlight<K, V> {
    public interface Loader<V> {
        V load() throws Exception;
    }

    private final ConcurrentHashMap<K, CompletableFuture<V>> inflight = new ConcurrentHashMap<>();

    public int inflightCount() {
        return inflight.size();
    }

    public V run(K key, Supplier<V> cached, Loader<V> loader) throws Exception {
        while (true) {
            V hit = cached.get();
            if (hit != null) return hit;
            CompletableFuture<V> mine = new CompletableFuture<>();
            CompletableFuture<V> leader = inflight.putIfAbsent(key, mine);
            if (leader == null) {
                try {
                    V value = loader.load();
                    mine.complete(value);
                    return value;
                } catch (Throwable t) {
                    mine.completeExceptionally(t);
                    throw t;
                } finally {
                    inflight.remove(key, mine);
                }
            }
            try {
                return leader.get();
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof InterruptedException || cause instanceof CancellationException) continue;
                if (cause instanceof Exception) throw (Exception) cause;
                if (cause instanceof Error) throw (Error) cause;
                throw e;
            }
        }
    }
}
