package app.ziziplayer.playback

import android.app.Notification
import android.content.Context
import android.os.Bundle
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList

/**
 * Wraps the standard Media3 notification and asks the system to promote it.
 *
 * Android 16 introduced FLAG_PROMOTED_ONGOING ("Live Updates"): a promoted ongoing notification is
 * allowed to surface as a status bar chip that expands. The constant does not exist in compileSdk
 * 35, so it is read reflectively - on older systems the lookup simply fails and nothing changes.
 *
 * Honest scope: the island itself is drawn by the system. We can only make our notification a valid
 * candidate. Everything the system needs (media session, artwork, duration, seek support) is
 * provided; whether it renders as a pill, a chip or a plain notification is the system's call.
 */
@UnstableApi
class PromotedNotificationProvider(context: Context) : MediaNotification.Provider {

    private val delegate = object : DefaultMediaNotificationProvider(context) {
        override fun getMediaButtons(session: MediaSession, commands: Player.Commands,
                                     preferences: ImmutableList<CommandButton>, showPauseButton: Boolean): ImmutableList<CommandButton> =
            super.getMediaButtons(session, commands, preferences,
                showPauseButton || (session.player as? FocusPlayer)?.isResumePending == true)
    }

    private val promotedFlag: Int? = runCatching {
        Notification::class.java.getField("FLAG_PROMOTED_ONGOING").getInt(null)
    }.getOrNull()

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val callback = MediaNotification.Provider.Callback { updated ->
            onNotificationChangedCallback.onNotificationChanged(decorate(updated, mediaSession))
        }
        return decorate(delegate.createNotification(mediaSession, customLayout, actionFactory, callback), mediaSession)
    }

    private fun decorate(media: MediaNotification, session: MediaSession): MediaNotification {
        val player = session.player
        val ongoing = (player.playWhenReady || (player as? FocusPlayer)?.isResumePending == true) &&
            player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED
        val flags = (promotedFlag ?: 0) or Notification.FLAG_ONGOING_EVENT
        media.notification.flags = if (ongoing) media.notification.flags or flags else media.notification.flags and flags.inv()
        return media
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        delegate.handleCustomCommand(session, action, extras)
}
