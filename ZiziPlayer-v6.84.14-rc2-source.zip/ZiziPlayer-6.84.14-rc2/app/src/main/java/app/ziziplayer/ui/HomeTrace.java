package app.ziziplayer.ui;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * 6.84.13 (H0). Локальная трасса главной: что произошло со снимком и с ответом сервера и когда пользователь
 * реально увидел полки. Правило то же, что у StartupTrace: никаких названий, id, адресов и токенов. В строку
 * попадают только имена событий и причин из фиксированных перечислений и одно число с ключом из белого списка.
 * Кольцо на 64 события, потокобезопасно, без Android-зависимостей (проверяется на JVM).
 */
public final class HomeTrace {
    private HomeTrace() {}

    public enum Event {
        /** Создан HomeRecommendations (старт главной в процессе). */
        HOME_INIT,
        /** Приватный шлюз экрана открыт: пока он закрыт, экран не рисует ни снимок, ни полки. */
        PRIVACY_GATE_OPEN,
        /** Room и офлайн-файлы загружены: с этого момента экран зовёт refreshFeed. */
        LIBRARY_READY,
        /** Чтение локального снимка: причина промаха или HIT. */
        SNAPSHOT_READ,
        /** Снимок разобран и показан (число полок). */
        SNAPSHOT_SHOWN,
        /** load() стартовал или пропущен (причина). */
        LOAD,
        /** Профиль для запроса собран (число сидов). */
        PROFILE_READY,
        /** Запрос /reco/home ушёл. */
        REQUEST,
        /** Ответ получен: исход и время запроса. */
        RESPONSE,
        /** 6.84.13. Ранний запрос чарта (параллельно с /reco/home): исход. */
        DISCOVER,
        /** Что с записью снимка после ответа. */
        SNAPSHOT_WRITE,
        /** Серверные полки опубликованы в состоянии (число полок). */
        PUBLISHED,
        /** Первые серверные полки реально дошли до экрана: из снимка или с живого ответа. */
        SHELVES_VISIBLE,
        /** Кольцо загрузки нужно экрану (в причине: ждём библиотеку или ждём подборки). */
        LOADER_ON,
        LOADER_OFF
    }

    public enum Gate {
        NONE,
        // чтение снимка
        HIT, NO_FILE, PENDING_TASTE, PRIVACY_CHANGED, EXPIRED, TRANSIENT_ERROR, CORRUPT, PARSE_ERROR,
        EMPTY, NO_CATALOG, UNSAFE, ALREADY_SHOWN, RACE,
        // load()
        STARTED, SKIPPED_ACTIVE, SKIPPED_FRESH, SKIPPED_LOADING,
        // исход ответа
        COMPLETE, PARTIAL, NULL_REPLY, TIMEOUT, ERROR,
        // запись снимка
        WRITTEN, WRITE_FAILED, TOO_BIG, NOT_BETTER, TASTE_SETUP, NO_RAW,
        // откуда полки / что ждёт кольцо
        SNAPSHOT, LIVE, LIBRARY, FEED
    }

    public static final String K_MS = "ms";
    public static final String K_AGE_H = "age_h";
    public static final String K_SHELVES = "shelves";
    public static final String K_SEEDS = "seeds";

    private static final int LIMIT = 64;
    private static final Object LOCK = new Object();
    private static final ArrayDeque<String> RING = new ArrayDeque<>();
    private static final Set<Event> ONCE_DONE = EnumSet.noneOf(Event.class);
    private static long origin = System.nanoTime();

    public static void mark(Event event) { add(event, Gate.NONE, null, 0L); }

    public static void mark(Event event, Gate gate) { add(event, gate, null, 0L); }

    public static void mark(Event event, Gate gate, String key, long value) {
        add(event, gate, allowed(key) ? key : null, value);
    }

    private static boolean allowed(String key) {
        return K_MS.equals(key) || K_AGE_H.equals(key) || K_SHELVES.equals(key) || K_SEEDS.equals(key);
    }

    /** Событие, которое имеет смысл только один раз за процесс (первые полки, открытие шлюза). */
    public static void markOnce(Event event, Gate gate) {
        synchronized (LOCK) {
            if (!ONCE_DONE.add(event)) return;
        }
        add(event, gate, null, 0L);
    }

    /** 6.84.14. Общие часы для SyncTrace: строки обеих трасс сравнимы по времени. */
    public static long elapsedMs() { return (System.nanoTime() - origin) / 1_000_000L; }

    private static void add(Event event, Gate gate, String key, long value) {
        long ms = elapsedMs();
        StringBuilder line = new StringBuilder(48).append(ms).append(" ms | ").append(event.name());
        if (gate != null && gate != Gate.NONE) line.append(' ').append(gate.name());
        if (key != null) line.append(' ').append(key).append('=').append(value);
        synchronized (LOCK) {
            if (RING.size() >= LIMIT) RING.pollFirst();
            RING.addLast(line.toString());
        }
    }

    public static List<String> lines() {
        synchronized (LOCK) { return new ArrayList<>(RING); }
    }

    public static String snapshot() {
        StringBuilder out = new StringBuilder(
            "Home timings; milliseconds since this class was first used in the process. Last " + LIMIT + " events.\n");
        List<String> lines = lines();
        if (lines.isEmpty()) out.append("(no events)\n");
        for (String line : lines) out.append(line).append('\n');
        return out.toString();
    }

    /** Только для проверок на JVM. */
    static void resetForTest() {
        synchronized (LOCK) { RING.clear(); ONCE_DONE.clear(); origin = System.nanoTime(); }
    }
}
