package app.ziziplayer.playback;

/**
 * 6.84.12. Что серверу можно отдать на прогрев по адресу трека очереди (`zizi://provider/id`).
 *
 * Каталог пишет составные id: `zizi://mix/dz:3135556` и `zizi://mix/yt:VIDEO`, а также прямые
 * `zizi://dz/ID` и `zizi://yt/VIDEO`. Раньше прогревалось только прямое `yt`, то есть для основного
 * (смешанного) каталога не прогревалось ничего. Чистая Java, чтобы проверяться без Android.
 */
public final class PrefetchRef {
    public enum Kind { YT, DZ }

    public final Kind kind;
    public final String id;

    private PrefetchRef(Kind kind, String id) {
        this.kind = kind;
        this.id = id;
    }

    /** null, если эту запись прогревать нечем или нечего (чужой провайдер, мусор, пустой id). */
    public static PrefetchRef of(String provider, String remoteId) {
        if (provider == null || remoteId == null) return null;
        switch (provider) {
            case "yt":
                return isVideoId(remoteId) ? new PrefetchRef(Kind.YT, remoteId) : null;
            case "dz":
                return isDeezerId(remoteId) ? new PrefetchRef(Kind.DZ, remoteId) : null;
            case "mix": {
                int colon = remoteId.indexOf(':');
                if (colon <= 0) return null;
                String inner = remoteId.substring(0, colon);
                // Вложенный mix не бывает; не рекурсируем, чтобы мусорный id не крутил разбор.
                if (inner.equals("mix")) return null;
                return of(inner, remoteId.substring(colon + 1));
            }
            default:
                return null;
        }
    }

    // Те же границы, что у сервера: videoId 5..32 знака, id Deezer 1..20 цифр.
    static boolean isVideoId(String s) {
        int n = s.length();
        if (n < 5 || n > 32) return false;
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
            if (!ok) return false;
        }
        return true;
    }

    static boolean isDeezerId(String s) {
        int n = s.length();
        if (n < 1 || n > 20) return false;
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        return true;
    }
}
