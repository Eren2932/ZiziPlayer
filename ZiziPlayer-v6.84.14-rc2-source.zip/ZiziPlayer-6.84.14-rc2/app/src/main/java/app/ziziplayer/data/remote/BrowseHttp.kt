package app.ziziplayer.data.remote

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Cancellable metadata calls only. Playback keeps its original client/timeouts. */
internal object BrowseHttp {
    private val client by lazy {
        ZiziHttp.client.newBuilder().callTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false).build()
    }

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun get(url: String): JSONObject = sendRequest(url, null)

    /**
     * Тело, а не строка запроса: access-лог сервера пишет путь вместе с query, тело — нет.
     * Так уходит профиль вкуса `/reco/home`. Повторов нет: `retryOnConnectionFailure(false)`.
     */
    suspend fun post(url: String, body: JSONObject): JSONObject = sendRequest(url, body)

    private suspend fun sendRequest(url: String, body: JSONObject?): JSONObject = suspendCancellableCoroutine { continuation ->
        val request = Request.Builder().url(url).header("User-Agent", ZiziHttp.USER_AGENT)
            .apply {
                ZiziResolve.authHeaders().forEach { (key, value) -> header(key, value) }
                if (body != null) post(body.toString().toRequestBody(jsonType))
            }.build()
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWithException(
                    CatalogException(CatalogException.Reason.OFFLINE, "Каталог не ответил", e)
                )
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    if (!continuation.isActive) return
                    try {
                        if (!r.isSuccessful) {
                            val reason = when (r.code) {
                                429 -> CatalogException.Reason.RATE_LIMITED
                                404 -> CatalogException.Reason.PROTOCOL
                                else -> CatalogException.Reason.OFFLINE
                            }
                            throw CatalogException(reason, if (r.code == 404)
                                "Нужно обновить каталог сервера до Browse 1" else "Каталог временно недоступен")
                        }
                        val json = JSONObject(r.body?.string().orEmpty())
                        if (json.optInt("contract") != 1) throw CatalogException(
                            CatalogException.Reason.PROTOCOL, "Неизвестная версия каталога")
                        continuation.resume(json)
                    } catch (e: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(
                            if (e is CatalogException) e else CatalogException(
                                CatalogException.Reason.PROTOCOL, "Не удалось прочитать каталог", e))
                    }
                }
            }
        })
    }
}
