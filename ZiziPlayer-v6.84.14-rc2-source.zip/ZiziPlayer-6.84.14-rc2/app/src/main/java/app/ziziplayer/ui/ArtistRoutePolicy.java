package app.ziziplayer.ui;

import app.ziziplayer.data.remote.DeezerArtistRef;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 6.84.5. «К исполнителю»: чистая логика выбора адресата, без Android и без сети.
 *
 * До этого каждый вход (главная, плеер, медиатека) вызывал `openArtist(name)`, а тот искал артиста
 * в МЕДИАТЕКЕ по строке имени и, не найдя, вписывал имя в локальный поиск по трекам. Для сетевого
 * трека это всегда заканчивалось пустым экраном «Все треки — 0 треков — Ничего не найдено».
 *
 * Правила:
 *  1. Адрес артиста — только id каталога. Он приходит с самим треком (`track_catalog.artistId`) и
 *     никогда не выводится из отображаемого имени.
 *  2. Если id нет, имя используется как ЗАПРОС к каталогу, а результат принимается лишь при точном
 *     совпадении нормализованного имени. «Почти тот же» артист хуже, чем честное «не нашёл».
 *  3. Локальная страница — только для локальных файлов без id.
 */
public final class ArtistRoutePolicy {
    private ArtistRoutePolicy() {}

    /** Сколько треков медиатеки просматриваем, когда ищем id по имени карточки. Верхняя граница запроса к БД. */
    public static final int IDENTITY_SCAN = 200;

    /** Канонический числовой id артиста Deezer либо null. Любой другой провайдер и мусор отбрасываются. */
    public static String validId(String raw) {
        if (raw == null) return null;
        String id = DeezerArtistRef.parse("dz", raw.trim());
        return id == null || id.equals("0") ? null : id;
    }

    /** Имя для заголовка и запроса: без хвостов канала и заглушек. Пустая строка — это не артист. */
    public static String lookupName(String credited) {
        return HomeRecoPolicy.cleanArtist(credited);
    }

    /**
     * Запросы к каталогу по убыванию строгости: полная строка, затем главный артист из «A feat. B».
     * Полная строка идёт первой, потому что «Tyler, The Creator» режется запятой неверно.
     */
    public static List<String> nameCandidates(String credited) {
        List<String> out = new ArrayList<>();
        String full = lookupName(credited);
        if (full.isEmpty()) return out;
        out.add(full);
        List<String> parts = HomeRecoPolicy.splitArtists(full);
        if (parts.size() > 1) {
            String first = HomeRecoPolicy.cleanArtist(parts.get(0));
            if (!first.isEmpty() && !HomeFeedPolicy.normalize(first).equals(HomeFeedPolicy.normalize(full))) out.add(first);
        }
        return out;
    }

    /** Индекс первого названия, точно равного искомому имени после нормализации; -1, если такого нет. */
    public static int exactMatch(String wanted, List<String> titles) {
        String key = HomeFeedPolicy.normalize(wanted);
        if (key.isEmpty() || titles == null) return -1;
        for (int i = 0; i < titles.size(); i++) {
            if (key.equals(HomeFeedPolicy.normalize(titles.get(i)))) return i;
        }
        return -1;
    }

    /**
     * Самый частый корректный id; при равенстве побеждает встреченный раньше (порядок = свежесть
     * трека в вызывающем коде). Нужен карточке исполнителя: у неё нет одного трека, есть набор.
     */
    public static String majorityId(List<String> rawIds) {
        Map<String, Integer> votes = new LinkedHashMap<>();
        if (rawIds != null) {
            for (String raw : rawIds) {
                String id = validId(raw);
                if (id != null) votes.merge(id, 1, Integer::sum);
            }
        }
        String best = null;
        int bestVotes = 0;
        for (Map.Entry<String, Integer> e : votes.entrySet()) {
            if (e.getValue() > bestVotes) { best = e.getKey(); bestVotes = e.getValue(); }
        }
        return best;
    }

    /** Адрес страницы артиста в формате каталога: `artist:<id>`. */
    public static String remoteId(String id) { return "artist:" + id; }

    /** Заглушка, пока имя ещё превращается в id. Не равна ни одному настоящему адресу. */
    public static final String PENDING_REMOTE_ID = "artist:";

    public static boolean isPending(String remoteId) { return PENDING_REMOTE_ID.equals(remoteId); }
}
