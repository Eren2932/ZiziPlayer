package app.ziziplayer.data

/** One aggregate row. No positions, updatedAt, names or per-tick progress. */
data class RecoListeningSignal(
    val qualifiedCount: Long, val skippedCount: Long,
    val qualifiedAt: Long, val skippedAt: Long
)
