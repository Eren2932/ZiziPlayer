package app.ziziplayer.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ListeningDao {
    @Query("SELECT * FROM listening_sessions ORDER BY startedAt DESC LIMIT 10000")
    fun observeSessions(): Flow<List<ListeningSessionEntity>>

    /** Bounded one-shot recommendation input, never a checkpoint subscription. */
    @Query("SELECT * FROM listening_sessions ORDER BY startedAt DESC LIMIT 500")
    suspend fun recommendationSnapshot(): List<ListeningSessionEntity>

    /** Same bounded input as recommendationSnapshot; checkpoint ticks do not change the signal. */
    @Query("""
        SELECT COALESCE(SUM(CASE WHEN qualified = 1 THEN 1 ELSE 0 END), 0) AS qualifiedCount,
               COALESCE(SUM(CASE WHEN outcome = 'skipped' THEN 1 ELSE 0 END), 0) AS skippedCount,
               COALESCE(MAX(CASE WHEN qualified = 1 THEN startedAt ELSE 0 END), 0) AS qualifiedAt,
               COALESCE(MAX(CASE WHEN outcome = 'skipped' THEN startedAt ELSE 0 END), 0) AS skippedAt
        FROM (SELECT qualified, outcome, startedAt FROM listening_sessions ORDER BY startedAt DESC LIMIT 500)
    """)
    fun observeRecoListeningSignal(): Flow<RecoListeningSignal>

    @Query("SELECT * FROM listening_sessions WHERE sessionId = :id")
    suspend fun session(id: String): ListeningSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSession(row: ListeningSessionEntity)

    @Query("INSERT OR IGNORE INTO play_stats (trackId, playCount, lastPlayedAt) VALUES (:id, 0, 0)")
    suspend fun ensureLegacyStat(id: String)

    @Query("UPDATE play_stats SET playCount = playCount + 1, lastPlayedAt = MAX(lastPlayedAt, :at) WHERE trackId = :id")
    suspend fun countQualified(id: String, at: Long)

    /** Absolute checkpoints + transaction make retries idempotent, including the old counter. */
    @Transaction
    suspend fun checkpoint(row: ListeningSessionEntity) {
        val previous = session(row.sessionId)
        if (previous != null && (previous.listenedMs > row.listenedMs ||
                (previous.outcome != "active" && row.outcome == "active"))) return
        if (row.qualified && previous?.qualified != true) {
            ensureLegacyStat(row.trackId)
            countQualified(row.trackId, row.startedAt)
        }
        putSession(row)
    }

    @Query("UPDATE listening_sessions SET outcome = 'interrupted', endedAt = updatedAt WHERE outcome = 'active'")
    suspend fun recoverInterrupted()

    @Query("DELETE FROM listening_sessions WHERE outcome != 'active' AND (startedAt < :before OR sessionId NOT IN (SELECT sessionId FROM listening_sessions ORDER BY startedAt DESC LIMIT 10000))")
    suspend fun trim(before: Long)

    @Query("DELETE FROM listening_sessions")
    suspend fun clearHistory()

    @Query("SELECT * FROM home_pins ORDER BY pinnedAt DESC, playlistId DESC")
    fun observePins(): Flow<List<HomePinEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun pin(pin: HomePinEntity)
    @Query("DELETE FROM home_pins WHERE playlistId = :id")
    suspend fun unpin(id: Long)
    @Query("DELETE FROM home_pins WHERE playlistId NOT IN (SELECT id FROM playlists)")
    suspend fun prunePins()

    @Query("SELECT COUNT(*) FROM home_pins")
    suspend fun pinCount(): Int
    @Query("SELECT COUNT(*) FROM home_pins WHERE playlistId = :id")
    suspend fun isPinned(id: Long): Int
    @Query("SELECT COUNT(*) FROM playlists WHERE id = :id")
    suspend fun playlistExists(id: Long): Int
    @Transaction
    suspend fun setPinned(id: Long, pinned: Boolean, at: Long): Boolean {
        prunePins()
        if (!pinned) { unpin(id); return true }
        if (playlistExists(id) == 0) return false
        if (isPinned(id) == 0 && pinCount() >= 6) return false
        pin(HomePinEntity(id, at)); return true
    }

    @Query("SELECT * FROM track_catalog WHERE trackId = :id")
    suspend fun catalogIdentity(id: String): TrackCatalogEntity?
    /** Reco 1: id артиста Deezer для треков профиля; вызывающий режет список на куски по 400. */
    @Query("SELECT * FROM track_catalog WHERE trackId IN (:ids)")
    suspend fun catalogIdentities(ids: List<String>): List<TrackCatalogEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putCatalogIdentity(row: TrackCatalogEntity)
}
