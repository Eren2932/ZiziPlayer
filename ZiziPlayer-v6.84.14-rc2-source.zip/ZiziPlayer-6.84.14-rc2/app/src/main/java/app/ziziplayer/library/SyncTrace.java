package app.ziziplayer.library;

import app.ziziplayer.ui.HomeTrace;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * 6.84.14 (A0). Трасса аккаунта и облачной библиотеки: сколько стоит каждый запрос к серверу аккаунтов и сколько
 * байт он несёт. Правило то же, что у HomeTrace и StartupTrace: никаких id, адресов, имён и токенов, только
 * имена событий из перечисления, миллисекунды и размер в байтах. Часы общие с HomeTrace, поэтому строки двух
 * трасс сравнимы. Отдельное кольцо, чтобы периодические события синхронизации не вытесняли события главной.
 * Без Android-зависимостей (проверяется на JVM).
 */
public final class SyncTrace {
    private SyncTrace() {}

    public enum Event {
        /** POST /auth/refresh либо GET /auth/me при старте приложения. */
        ACCT_RESTORE,
        /** GET /auth/me перед операцией с библиотекой (проверка, что аккаунт тот же). */
        ACCT_ME,
        /** Снимок локальной библиотеки: транзакция Room + JSON (без сети). */
        LIB_CAPTURE,
        /** GET /auth/library: время и размер ответа. */
        LIB_GET,
        /** POST /auth/library: время и размер тела запроса. */
        LIB_SAVE,
        /** Синхронизация ждала главную: сколько и чем кончилось. */
        SYNC_GATE
    }

    public enum Gate { NONE, OK, FAILED, WAITED, CAPPED }

    private static final int LIMIT = 48;
    private static final Object LOCK = new Object();
    private static final ArrayDeque<String> RING = new ArrayDeque<>();

    /** [bytes] меньше нуля = размер неизвестен или не нужен. */
    public static void mark(Event event, Gate gate, long ms, long bytes) {
        StringBuilder line = new StringBuilder(56).append(HomeTrace.elapsedMs()).append(" ms | ").append(event.name());
        if (gate != null && gate != Gate.NONE) line.append(' ').append(gate.name());
        line.append(" took=").append(Math.max(0L, ms));
        if (bytes >= 0L) line.append(" bytes=").append(bytes);
        synchronized (LOCK) {
            if (RING.size() >= LIMIT) RING.pollFirst();
            RING.addLast(line.toString());
        }
    }

    public static List<String> lines() {
        synchronized (LOCK) { return new ArrayList<>(RING); }
    }

    public static String snapshot() {
        StringBuilder out = new StringBuilder(
            "Account/library timings; same clock as Home timings. Last " + LIMIT + " events.\n");
        List<String> lines = lines();
        if (lines.isEmpty()) out.append("(no events)\n");
        for (String line : lines) out.append(line).append('\n');
        return out.toString();
    }

    /** Только для проверок на JVM. */
    static void resetForTest() {
        synchronized (LOCK) { RING.clear(); }
    }
}
