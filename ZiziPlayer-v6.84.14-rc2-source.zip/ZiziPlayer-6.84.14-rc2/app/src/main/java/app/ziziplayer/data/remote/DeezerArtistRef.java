package app.ziziplayer.data.remote;

/** Strict catalogue identity, never infer a Deezer artist ID from another provider. */
public final class DeezerArtistRef {
    private DeezerArtistRef() {}

    /** Accept bare/onboard IDs, dz artist:<id>, and mix dz:artist:<id>. */
    public static String parse(String provider, String remoteId) {
        if (remoteId == null || provider == null) return null;
        String value = remoteId;
        if ("mix".equals(provider)) {
            if (!value.startsWith("dz:artist:")) return null;
            value = value.substring(3);
        } else if (!"dz".equals(provider)) return null;
        if (value.startsWith("artist:")) value = value.substring(7);
        if (value.isEmpty() || value.length() > 12) return null;
        for (int i = 0; i < value.length(); i++)
            if (value.charAt(i) < '0' || value.charAt(i) > '9') return null;
        // Canonical decimal identity: two spellings of the same artist must not split the profile.
        int first = 0;
        while (first < value.length() - 1 && value.charAt(first) == '0') first++;
        return value.substring(first);
    }
}
