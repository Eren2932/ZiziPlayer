package app.ziziplayer.ui;

/**
 * Обновление подборок без кнопки «Обновить».
 *
 * Пользователь не должен нажимать ничего: свежесть определяется временем, а неудача
 * повторяется сама с ограниченным числом попыток и растущей паузой. Это детерминированная
 * арифметика, а не таймер и не фоновая служба: вызывающий код сам решает, когда спросить.
 */
public final class HomeFeedRefreshPolicy {
    private HomeFeedRefreshPolicy() {}

    /** Снимок считается свежим 30 минут. */
    public static final long STALE_MS = 30L * 60_000L;
    /** Минимальная пауза между любыми двумя попытками. */
    public static final long ATTEMPT_GAP_MS = 15_000L;
    /** Максимум автоматических повторов после ошибки. */
    public static final int MAX_RETRIES = 3;
    /** Верхняя граница паузы автоповтора. */
    public static final long MAX_RETRY_MS = 300_000L;

    /** 15 c, 45 c, 135 c ... с потолком 5 минут. Ноль — когда повторять уже нельзя. */
    public static long retryDelayMs(int attempt) {
        if (attempt < 1 || attempt > MAX_RETRIES) return 0L;
        double delay = ATTEMPT_GAP_MS * Math.pow(3.0, attempt - 1);
        return (long) Math.min(MAX_RETRY_MS, delay);
    }

    /** Есть ли ещё право на автоповтор. */
    public static boolean canRetry(int attempt) {
        return attempt >= 1 && attempt <= MAX_RETRIES;
    }

    /** Данные устарели: снимка нет вовсе либо он старше STALE_MS. */
    public static boolean stale(long now, long loadedAt) {
        return loadedAt <= 0L || now - loadedAt >= STALE_MS || now < loadedAt;
    }

    /**
     * Ручное обновление исчезло, поэтому решение принимается здесь:
     * грузим при устаревании или по явному force, но не чаще ATTEMPT_GAP_MS.
     */
    public static boolean shouldLoad(long now, long loadedAt, long lastAttempt, boolean force) {
        return shouldLoad(now, loadedAt, lastAttempt, force, ATTEMPT_GAP_MS);
    }

    /** То же с явным зазором: быстрый повтор прогревающегося сервера ждёт [QUICK_GAP_MS], а не 15 с. */
    public static boolean shouldLoad(long now, long loadedAt, long lastAttempt, boolean force, long gapMs) {
        if (lastAttempt > 0L && now - lastAttempt < gapMs && now >= lastAttempt) return false;
        return force || stale(now, loadedAt);
    }

    // ---- 6.82.0: быстрый старт ----------------------------------------------------------------

    /**
     * Сколько главная ждёт, пока плеер дозагрузит аудио, прежде чем всё равно идти в сеть.
     * До 6.82.0 ожидание было бесконечным и входило в тайм-аут запроса: пока трек грузился, а
     * контроллер ещё не подключился (isLoadingAudio по умолчанию true), подборки стояли и
     * сдавались по тайм-ауту. Метаданные — несколько килобайт JSON, они аудио не мешают.
     */
    public static final long AUDIO_GRACE_MS = 1_500L;
    /** Запрос к серверу рекомендаций: серверный бюджет 5 с плюс сеть. Отсчёт идёт ПОСЛЕ ожидания аудио. */
    public static final long RECO_TIMEOUT_MS = 9_000L;
    /** Один запрос прежнего пути (чарт, поиск артиста). */
    public static final long REQUEST_TIMEOUT_MS = 8_000L;
    /** Весь проход обновления, включая прежний путь. Было 45 с. */
    public static final long TOTAL_TIMEOUT_MS = 30_000L;

    /** Зазор между попытками при быстром повторе: достаточно, чтобы не устроить шторм. */
    public static final long QUICK_GAP_MS = 1_000L;
    /** Быстрые повторы неполного ответа: 2 с, 4 с, 8 с. После них работает обычная лестница. */
    public static final int MAX_QUICK_RETRIES = 3;
    public static final long QUICK_BASE_MS = 2_000L;
    public static final long QUICK_MAX_MS = 10_000L;

    public static boolean canQuickRetry(int attempt) {
        return attempt >= 1 && attempt <= MAX_QUICK_RETRIES;
    }

    /**
     * 2/4/8 с, но не быстрее подсказки сервера [hintMs] (`retry_ms`) и не медленнее QUICK_MAX_MS.
     * Ноль — быстрые попытки кончились. Отрицательная и мусорная подсказка игнорируется.
     */
    public static long quickRetryDelayMs(int attempt, long hintMs) {
        if (!canQuickRetry(attempt)) return 0L;
        long ladder = QUICK_BASE_MS << (attempt - 1);
        long hint = Math.max(0L, Math.min(QUICK_MAX_MS, hintMs));
        return Math.min(QUICK_MAX_MS, Math.max(ladder, hint));
    }
}
