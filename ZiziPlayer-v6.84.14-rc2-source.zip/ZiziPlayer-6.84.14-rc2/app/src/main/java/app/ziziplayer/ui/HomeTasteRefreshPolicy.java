package app.ziziplayer.ui;

/** Fast local refresh; outgoing refreshes coalesce without a request for every tap. */
public final class HomeTasteRefreshPolicy {
    private HomeTasteRefreshPolicy() {}
    public static final long COALESCE_MS = 300L;
    public static final long NETWORK_GAP_MS = 1_000L;
    public static long networkWaitMs(long now, long lastAttempt) {
        if (lastAttempt <= 0L || now < lastAttempt) return COALESCE_MS;
        long elapsed = now - lastAttempt;
        return Math.max(COALESCE_MS, Math.max(0L, NETWORK_GAP_MS - elapsed));
    }
}
