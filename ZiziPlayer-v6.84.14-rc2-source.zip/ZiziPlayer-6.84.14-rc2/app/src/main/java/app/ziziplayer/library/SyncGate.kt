package app.ziziplayer.library

import android.os.SystemClock
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay

/**
 * 6.84.14 (A1). Главная сообщает, что грузится; синхронизация библиотеки ждёт её, но не дольше
 * [LibrarySyncSchedule.START_MAX_WAIT_MS]. Счётчик, а не флаг: load() может отменить прежнюю задачу и сразу
 * запустить новую, а завершение старой не должно гасить «занято» новой.
 */
object SyncGate {
    private val active = AtomicInteger(0)
    @Volatile private var started = false

    fun homeBusy(): Boolean = active.get() > 0

    /** invokeOnCompletion срабатывает ровно один раз, в том числе у задачи, отменённой до первой строки тела. */
    fun trackHomeLoad(job: Job) {
        started = true
        active.incrementAndGet()
        job.invokeOnCompletion { active.decrementAndGet() }
    }

    /** Ждёт, пока главная освободится, и пишет в SyncTrace, сколько ждали и почему вышли. */
    suspend fun awaitHomeIdle() {
        val startedAt = SystemClock.elapsedRealtime()
        while (true) {
            val waited = SystemClock.elapsedRealtime() - startedAt
            if (LibrarySyncSchedule.mayStart(started, homeBusy(), waited)) {
                if (waited >= 200L) SyncTrace.mark(SyncTrace.Event.SYNC_GATE,
                    if (waited >= LibrarySyncSchedule.START_MAX_WAIT_MS) SyncTrace.Gate.CAPPED else SyncTrace.Gate.WAITED, waited, -1L)
                return
            }
            delay(200L)
        }
    }
}
