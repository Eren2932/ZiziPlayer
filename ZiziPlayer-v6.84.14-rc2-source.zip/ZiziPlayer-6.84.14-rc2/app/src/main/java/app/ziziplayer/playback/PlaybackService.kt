package app.ziziplayer.playback

import android.app.PendingIntent
import android.app.Notification
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.media3.session.MediaController
import androidx.media3.session.MediaNotification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.ziziplayer.MainActivity
import app.ziziplayer.data.PlaybackMemory
import app.ziziplayer.playback.dsp.DspCodec
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.ZiziSpectrum
import app.ziziplayer.playback.dsp.ZiziAudioProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private val routeMonitor = PlaybackRouteMonitor()

    companion object {
        /**
         * 6.24.4. Весь звуковой тракт приезжает сюда ОДНОЙ строкой в `args.getString("config")`.
         *
         * Не пятнадцать команд на пятнадцать ручек и не Parcelable: строка кодека — единственный
         * формат, который одинаково едет через Bundle медиасессии, лежит в Room и в DataStore, и
         * не может приехать «наполовину применённым». Одна команда — одно целостное состояние
         * тракта, поэтому рассинхрона между ползунком и звуком не бывает в принципе.
         */
        const val CMD_DSP = "app.ziziplayer.SET_DSP"
        /**
         * Наследие. Команда остаётся принимаемой, хотя `PresetReverb` больше нет: контроллер
         * старой версии, переживший обновление в памяти, не должен получать RESULT_ERROR. Процент
         * молча переводится в наш ревер.
         */
        const val CMD_REVERB = "app.ziziplayer.SET_REVERB"
        const val CMD_SKIP_SILENCE = "app.ziziplayer.SKIP_SILENCE"
        /** The UI is dead while the screen is off, so the service is the only one who can save. */
        private const val PERSIST_INTERVAL_MS = 4_000L
        /**
         * 6.18.0. onPositionDiscontinuity прилетает на КАЖДЫЙ шаг перемотки: одно движение пальца
         * по полосе — это десятки коллбэков, и раньше каждый из них шёл в SharedPreferences.
         * Запись асинхронная, но не бесплатная: файл переписывается целиком и фоново fsync'ится.
         * Позиция нужна с точностью до секунды, поэтому чаще чем раз в 700 мс писать нечего.
         * Важные моменты (смена трека, уход в фон, смерть сервиса) сохраняются в обход порога.
         */
        private const val PERSIST_MIN_GAP_MS = 700L
    }

    private var session: MediaSession? = null
    private var focusPlayer: FocusPlayer? = null
    private lateinit var notificationProvider: PromotedNotificationProvider
    private val notificationActions by lazy { PlaybackNotificationActions(this) }
    private var notificationEpoch = 0
    private var notificationId: Int? = null
    private var foreground = false
    private var destroying = false

    /** One notification/foreground owner. Media3 1.5.1 demotes a transient pause immediately;
     * its asynchronous artwork callback also recomputes that decision behind an override.
     * Use its public provider, but publish every update using CURRENT interruption intent.
     */
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        // The manager's controller can lag a user pause. Its hint is not new play intent;
        // only beforePlay is allowed to request an explicit foreground promotion.
        updatePlaybackNotification(session)
    }
    private fun updatePlaybackNotification(current: MediaSession, explicitPlay: Boolean = false): Boolean {
        if (destroying) return false
        val epoch = ++notificationEpoch
        return try {
            val media = notificationProvider.createNotification(current, current.mediaButtonPreferences,
                notificationActions, MediaNotification.Provider.Callback { updated ->
                    if (!destroying && epoch == notificationEpoch && session === current)
                        publishNotification(current, updated, false)
                })
            publishNotification(current, media, explicitPlay)
        } catch (failure: RuntimeException) {
            Log.w("ZiziPlayback", "Could not create playback notification", failure)
            false
        }
    }
    private fun publishNotification(current: MediaSession, media: MediaNotification, explicitPlay: Boolean): Boolean {
        val p = current.player
        val playable = p.mediaItemCount > 0 && (p.playbackState == Player.STATE_READY || p.playbackState == Player.STATE_BUFFERING)
        val keep = AudioInterruptionPolicy.keepForeground(playable, p.playWhenReady || explicitPlay,
            focusPlayer?.isResumePending == true)
        media.notification.extras.putParcelable(Notification.EXTRA_MEDIA_SESSION, current.platformToken)
        notificationId = media.notificationId
        return try {
            if (keep) {
                // Start ownership as well as bound ownership, so unbinding the UI cannot kill
                // playback. Transient losses retain foreground and never restart this service.
                if (!foreground) androidx.core.content.ContextCompat.startForegroundService(
                    this, Intent(this, PlaybackService::class.java))
                ServiceCompat.startForeground(this, media.notificationId, media.notification,
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)
                foreground = true
            } else {
                NotificationManagerCompat.from(this).notify(media.notificationId, media.notification)
                if (foreground) { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH); foreground = false }
            }
            true
        } catch (failure: RuntimeException) {
            Log.w("ZiziPlayback", "Notification/foreground unavailable; keep playback paused", failure)
            false
        }
    }
    private fun prepareForegroundForPlay(): Boolean = session?.let { updatePlaybackNotification(it, true) && foreground } ?: false
    override fun isPlaybackOngoing(): Boolean = foreground

    private var engine: ExoPlayer? = null
    private var listening: app.ziziplayer.listening.ListeningManager? = null
    private lateinit var vault: app.ziziplayer.privacy.FolderVault
    private val vaultListener: () -> Unit = { purgeLockedQueue() }
    private fun mayPlay(item: MediaItem): Boolean {
        val gate = vault.state.value
        val folder = item.mediaMetadata.extras?.getString("vaultFolder")
        return gate.unlocked || folder == null || folder !in gate.folders
    }
    private fun purgeLockedQueue() {
        val p = session?.player ?: return
        val gate = vault.state.value
        if (gate.unlocked || gate.folders.isEmpty()) return
        fun blocked(item: MediaItem): Boolean = item.mediaMetadata.extras?.getString("vaultFolder") in gate.folders
        if (p.currentMediaItem?.let(::blocked) == true) p.pause()
        for (i in p.mediaItemCount - 1 downTo 0) if (blocked(p.getMediaItemAt(i))) p.removeMediaItem(i)
    }
    private fun <T> checkedItems(block: suspend () -> T): ListenableFuture<T> {
        val result = com.google.common.util.concurrent.SettableFuture.create<T>()
        val job = scope.launch {
            try { result.set(block()) }
            catch (e: Exception) { result.setException(e) }
        }
        job.invokeOnCompletion { cause -> if (cause != null) result.cancel(false) }
        return result
    }
    private suspend fun permittedItems(items: List<MediaItem>): List<MediaItem> {
        val dao = (application as app.ziziplayer.ZiziApplication).database.musicDao()
        val tracks = HashMap<String, app.ziziplayer.data.TrackEntity>()
        // SQLite has a binding limit; no per-item round trip on a queue of thousands of songs.
        for (ids in items.map { it.mediaId }.distinct().chunked(400)) {
            dao.vaultTracksByIds(ids).forEach { tracks[it.id] = it }
        }
        val gate = vault.state.value
        return items.mapNotNull { item ->
            val track = tracks[item.mediaId] ?: return@mapNotNull null
            if (gate.blocks(track)) return@mapNotNull null
            val uri = item.localConfiguration?.uri ?: item.requestMetadata.mediaUri
            if (uri?.toString() != track.uri) return@mapNotNull null
            val extras = Bundle(item.mediaMetadata.extras ?: Bundle.EMPTY)
            if (extras.getString("zizi.queueEntry").isNullOrBlank())
                extras.putString("zizi.queueEntry", java.util.UUID.randomUUID().toString())
            if (!track.isRemote) extras.putString("vaultFolder", track.sourceFolder)
            else extras.remove("vaultFolder")
            withUri(item).buildUpon().setMediaMetadata(item.mediaMetadata.buildUpon().setExtras(extras).build()).build()
        }
    }

    /**
     * Живёт столько же, сколько сервис, и переживает пересоздание аудиотракта: Media3 сама зовёт
     * `onConfigure`/`onFlush` на смене формата, а конфиг внутри процессора остаётся. Поэтому
     * настройки НЕ надо пересылать на каждом треке — они уже там.
     */
    private val dsp = ZiziAudioProcessor()
    private var dspConfig: DspConfig = DspConfig.NEUTRAL
    private lateinit var memory: PlaybackMemory
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** 6.69.0: своя настройка трека применяется и без живого экрана. */
    private val dspDirector by lazy {
        val app = application as app.ziziplayer.ZiziApplication
        DspDirector(
            scope = scope,
            loadFx = { id -> app.database.musicDao().fx(id) },
            loadSettings = { app.repository.settings.first() },
            applyConfig = ::applyDsp
        )
    }

    override fun onCreate() {
        super.onCreate()
        memory = PlaybackMemory(this)
        vault = app.ziziplayer.privacy.FolderVault.get(this)

        /**
         * Наш процессор врезается в аудиотракт ЗДЕСЬ, и другого места нет.
         *
         * `DefaultAudioProcessorChain(dsp)` — не «список из одного элемента», а конструктор,
         * который сам дописывает в хвост штатные `SilenceSkippingAudioProcessor` и
         * `SonicAudioProcessor`. Именно поэтому пропуск тишины и скорость/тональность продолжают
         * работать. Если собрать цепочку руками через массив, они молча исчезнут: скорость
         * перестанет меняться, а «пропускать тишину» станет мёртвым переключателем — и связь с
         * эквалайзером никто не найдёт.
         *
         * Порядок тоже не случаен: сначала мы, потом Sonic. Эквалайзер работает на исходном
         * материале, а растяжение времени применяется к уже обработанному — иначе фильтры
         * считались бы по частоте, которой в сигнале уже нет.
         *
         * Аудиовыгрузка (offload) здесь не включается сознательно. В режиме offload сжатый поток
         * уходит в DSP телефона мимо ВСЕЙ цепочки процессоров — эквалайзер просто не звучал бы,
         * и только на части устройств. Экономия батареи не стоит эффекта «у меня не работает».
         */
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessorChain(DefaultAudioSink.DefaultAudioProcessorChain(dsp))
                .setAudioTrackProvider(routeMonitor.provider)
                .build()
        }.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(),
                false // FocusPlayer is the only audio-focus owner.
            )
            .setHandleAudioBecomingNoisy(true)
            // 6.19.0: режим пробуждения теперь зависит от того, что играет.
            //
            // WAKE_MODE_NETWORK берёт не только CPU wake lock (без него процессор засыпает с
            // погашенным экраном и воспроизведение рвётся), но ещё и WifiLock. Для сетевого трека
            // это обязательно: без wifi-локи трек умирает через две минуты прогулки с телефоном в
            // кармане. Для локального файла это чистый вред — Wi-Fi держится включённым всё время,
            // пока играет музыка с диска, и сеть тут не нужна ни на байт.
            //
            // Стартуем с LOCAL и поднимаем до NETWORK ровно тогда, когда в текущем элементе стоит
            // zizi://-адрес. См. [updateWakeMode].
            .setWakeMode(C.WAKE_MODE_LOCAL)
            // zizi:// -> resolved URL -> cache -> OkHttp. Local files bypass all of it: see
            // ZiziDataSources for why the wrapper order is not interchangeable.
            .setMediaSourceFactory(ZiziDataSources.mediaSourceFactory(this))
            .setLoadControl(ZiziDataSources.loadControl())
            .build()

        engine = player
        listening = app.ziziplayer.listening.ListeningManager(
            player, (application as app.ziziplayer.ZiziApplication).listeningStore, { vault.state.value.folders }
        )
        updateWakeMode(player)

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                ZiziSpectrum.setPlaybackActive(isPlaying)
                AudioOutputs.refresh()
                persistPosition(force = true)
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                ZiziSpectrum.reset()
                dspDirector.onTrack(mediaItem?.mediaId)
                persistPosition(force = true)
                updateWakeMode(player)
            }
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) { ZiziSpectrum.reset(); persistPosition() }
        })

        val callback = object : MediaSession.Callback {
            override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
                val base = super.onConnect(session, controller)
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(
                        base.availableSessionCommands.buildUpon()
                            .add(SessionCommand(CMD_DSP, Bundle.EMPTY))
                            .add(SessionCommand(CMD_REVERB, Bundle.EMPTY))
                            .add(SessionCommand(CMD_SKIP_SILENCE, Bundle.EMPTY))
                            .build()
                    )
                    .setAvailablePlayerCommands(base.availablePlayerCommands)
                    .build()
            }

            /**
             * ВОТ ЭТО и роняло «Играть следующим» (6.24.0).
             *
             * `MediaController.addMediaItem` не кладёт элемент в плеер напрямую: запрос идёт через
             * сессию, и сессия обязана спросить у колбэка, ЧТО именно добавить. Дефолтная
             * реализация `onAddMediaItems` в Media3 возвращает провалившийся future с
             * UnsupportedOperationException — то есть библиотека прямым текстом требует
             * переопределить этот метод, если элементы приходят со стороны контроллера. До 6.24.0
             * его здесь не было вообще: очередь собиралась только через setMediaItems, и пока в
             * меню не появились «Играть следующим» и «Добавить в очередь», дыры не было видно.
             *
             * Вторая половина той же проблемы: MediaItem, прошедший через сессию, теряет
             * localConfiguration, то есть URI. Даже если бы падения не было, в очередь лёг бы
             * элемент, который нечем играть. Поэтому адрес переезжает в requestMetadata
             * (см. PlayerController.mediaItemOf) — эта часть границу переживает — и здесь
             * возвращается на место.
             */
            override fun onAddMediaItems(
                mediaSession: MediaSession,
                controller: MediaSession.ControllerInfo,
                mediaItems: MutableList<MediaItem>
            ): ListenableFuture<MutableList<MediaItem>> = checkedItems {
                permittedItems(mediaItems).toMutableList()
            }

            /**
             * Тот же ремонт для замены очереди целиком.
             *
             * Дефолтный `onSetMediaItems` реализован ЧЕРЕЗ `onAddMediaItems`, так что без этого
             * переопределения он унаследовал бы ровно то же поведение. Стартовый индекс и позиция
             * передаются как пришли: это запрос пользователя, а не предложение.
             */
            override fun onSetMediaItems(
                mediaSession: MediaSession,
                controller: MediaSession.ControllerInfo,
                mediaItems: MutableList<MediaItem>,
                startIndex: Int,
                startPositionMs: Long
            ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> = checkedItems {
                val requested = mediaItems.getOrNull(startIndex.takeIf { it >= 0 } ?: 0)?.mediaId
                val safe = permittedItems(mediaItems)
                val index = safe.indexOfFirst { it.mediaId == requested }
                require(mediaItems.isEmpty() || index >= 0) { "Папка заблокирована или трек недоступен" }
                MediaSession.MediaItemsWithStartPosition(safe, if (safe.isEmpty()) 0 else index, startPositionMs)
            }

            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                command: SessionCommand,
                args: Bundle
            ): ListenableFuture<SessionResult> {
                if (command.customAction == CMD_DSP) {
                    dspDirector.onUiCommand()
                    applyDsp(DspCodec.decode(args.getString("config")))
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                if (command.customAction == CMD_REVERB) {
                    dspDirector.onUiCommand()
                    applyDsp(DspConfig.NEUTRAL.withLegacyReverb(args.getInt("percent", 0)))
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                if (command.customAction == CMD_SKIP_SILENCE) {
                    engine?.skipSilenceEnabled = args.getBoolean("enabled", false)
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                return super.onCustomCommand(session, controller, command, args)
            }
        }

        // Tapping the notification (or the island) must open the player, not a blank task.
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        session = MediaSession.Builder(this, FocusPlayer(this, player, ::mayPlay))
            .setCallback(callback)
            .setBitmapLoader(ZiziBitmapLoader(this))
            .setSessionActivity(openApp)
            .build()

        notificationProvider = PromotedNotificationProvider(this)
        focusPlayer = session?.player as? FocusPlayer
        focusPlayer?.beforePlay = ::prepareForegroundForPlay
        focusPlayer?.interruptionChanged = {
            session?.let { updatePlaybackNotification(it) }
        }
        vault.addListener(vaultListener)
        // Retain Media3 command dispatch / notification-controller plumbing, but the public
        // onUpdateNotification override above owns publishing and foreground transitions.
        setMediaNotificationProvider(notificationProvider)

        scope.launch {
            while (isActive) {
                delay(PERSIST_INTERVAL_MS)
                if (session?.player?.isPlaying == true) persistPosition()
                listening?.checkpoint()
            }
        }
    }

    /**
     * Возвращает элементу адрес, потерянный на границе сессии.
     *
     * Если localConfiguration уцелел (контроллер в том же процессе — обычный случай для нашего
     * приложения), элемент отдаётся как есть: перекладывать его заново значило бы придумать
     * третий путь сборки MediaItem, а он уже есть ровно один.
     */
    private fun withUri(item: MediaItem): MediaItem {
        if (item.localConfiguration != null) return item
        val uri = item.requestMetadata.mediaUri ?: return item
        return item.buildUpon().setUri(uri).build()
    }

    /** Survives screen off, app switching and a service kill by the system. */
    private var lastPersistAt = 0L

    private fun persistPosition(force: Boolean = false) {
        val player = session?.player ?: return
        val id = player.currentMediaItem?.mediaId ?: return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPersistAt < PERSIST_MIN_GAP_MS) return
        lastPersistAt = now
        memory.save(id, player.currentPosition)
    }

    @Suppress("DEPRECATION")
    /**
     * Держит wifi-локу только под сетевой трек (6.19.0).
     *
     * Проверяется адрес текущего элемента, а не «есть ли в очереди сетевые треки»: очередь может
     * быть смешанной, и пока играет файл с диска, Wi-Fi незачем держать включённым даже если
     * следующий трек сетевой. На переходе метод позовут снова.
     *
     * CPU wake lock есть в обоих режимах — его терять нельзя ни на секунду, иначе музыка с диска
     * начнёт рваться с погашенным экраном.
     */
    private fun updateWakeMode(player: ExoPlayer) {
        val uri = player.currentMediaItem?.localConfiguration?.uri
        val needsNetwork = RemoteUri.isRemote(uri)
        player.setWakeMode(if (needsNetwork) C.WAKE_MODE_NETWORK else C.WAKE_MODE_LOCAL)
    }

    /**
     * Единственная точка конфигурации DSP; громкостью фокуса управляет FocusPlayer. Сравнение с текущим — не микрооптимизация: экран
     * эквалайзера шлёт команду на каждое движение пальца по ползунку (десятки в секунду), и без
     * этой проверки процессор дёргался бы впустую на каждом кадре анимации.
     */
    private fun applyDsp(config: DspConfig) {
        val safe = config.sanitized()
        if (safe == dspConfig) return
        dspConfig = safe
        dsp.setConfig(safe)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        persistPosition(force = true)
        // A transient focus pause is ongoing playback intent, not a user stop.
        // Do not call the superclass's independent stop decision a second time.
        if (!isPlaybackOngoing()) stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        // Do not restart an empty paused service in a START_STICKY loop after a process kill.
        if (intent?.action != PlaybackNotificationActions.CUSTOM) return START_NOT_STICKY
        val active = session ?: return START_NOT_STICKY
        val action = intent.getStringExtra(PlaybackNotificationActions.ACTION) ?: return START_NOT_STICKY
        val extras = intent.getBundleExtra(PlaybackNotificationActions.EXTRAS) ?: Bundle.EMPTY
        val f = MediaController.Builder(this, active.token).buildAsync()
        f.addListener({
            val controller = runCatching { f.get() }.getOrNull()
            if (controller == null || destroying) { MediaController.releaseFuture(f) }
            else {
                val result = controller.sendCustomCommand(SessionCommand(action, Bundle.EMPTY), extras)
                result.addListener({ MediaController.releaseFuture(f) }, androidx.core.content.ContextCompat.getMainExecutor(this))
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        destroying = true
        notificationEpoch++
        if (foreground) { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); foreground = false }
        notificationId?.let { NotificationManagerCompat.from(this).cancel(it) }
        routeMonitor.close()
        ZiziSpectrum.setPlaybackActive(false)
        persistPosition(force = true)
        listening?.close()
        listening = null
        vault.removeListener(vaultListener)
        dspDirector.cancel()
        scope.cancel()
        // Stop/cancel loaders before closing their cache; otherwise an in-flight read can race
        // a closed SimpleCache. Then release its directory lock for the next service instance.
        session?.run { player.release(); release() }
        StreamCache.release()
        session = null
        focusPlayer = null
        engine = null
        super.onDestroy()
    }
}
