package app.ziziplayer.ui;

/** Pure startup/cache policy; no Android, filesystem or network dependencies. */
public final class HomeSnapshotPolicy {
    private HomeSnapshotPolicy() {}
    /** A transient empty/partial response must not erase a useful complete snapshot. */
    public static boolean shouldReplace(int oldCards, boolean oldComplete, int newCards, boolean newComplete) {
        if (newCards <= 0) return false;
        if (newComplete || oldCards <= 0) return true;
        if (oldComplete) return false;
        return newCards >= oldCards;
    }
}
