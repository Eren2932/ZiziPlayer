package app.ziziplayer.data.remote;

import java.util.List;
import java.util.Locale;

/**
 * Запись профиля вкуса в параметры `/reco/home`. Чистый текст без Android: проверяется на JVM.
 *
 * Разделители протокола — `|` между элементами и `~` между ссылкой и весом. Они вычищаются из
 * имён ДО склейки, иначе артист «A|B» превратился бы в двух. Вес всегда с точкой, иначе в русской
 * локали сервер получил бы «0,873» и молча заменил его единицей.
 */
public final class RecoQuery {
    private RecoQuery() {}

    /** Имя для передачи по сети: без разделителей и управляющих символов, не длиннее 60. */
    public static String safeName(String name) {
        if (name == null) return "";
        String clean = name.replaceAll("[|~\\p{Cntrl}]+", " ").replaceAll("\\s+", " ").trim();
        return clean.length() <= 60 ? clean : clean.substring(0, 60).trim();
    }

    /**
     * Ссылка на артиста по имени. Имя из одних цифр («070», «50») сервер принял бы за id Deezer,
     * поэтому оно уходит с префиксом `n:`.
     */
    public static String name(String name) {
        String clean = safeName(name);
        return !clean.isEmpty() && clean.chars().allMatch(c -> c >= '0' && c <= '9') ? "n:" + clean : clean;
    }

    /** Строка сида: `ref~0.873`. */
    public static String seed(String ref, double weight) {
        double clamped = Double.isNaN(weight) ? 1.0 : Math.max(0.05, Math.min(1.0, weight));
        return safeName(ref) + "~" + String.format(Locale.ROOT, "%.3f", clamped);
    }

    /** Склейка элементов через `|`; пустые отбрасываются, длина списка ограничена. */
    public static String join(List<String> items, int limit) {
        StringBuilder out = new StringBuilder();
        int taken = 0;
        for (String item : items) {
            String clean = safeName(item);
            if (clean.isEmpty()) continue;
            if (taken++ >= limit) break;
            if (out.length() > 0) out.append('|');
            out.append(clean);
        }
        return out.toString();
    }

    /** Склейка с бюджетом символов: сервер 1.15 отвечает 422 на слишком длинное поле, лучше потерять хвост. */
    public static String join(List<String> items, int limit, int maxChars) {
        StringBuilder out = new StringBuilder();
        int taken = 0;
        for (String item : items) {
            String clean = safeName(item);
            if (clean.isEmpty()) continue;
            if (taken >= limit) break;
            int extra = clean.length() + (out.length() > 0 ? 1 : 0);
            if (out.length() + extra > maxChars) break;
            if (out.length() > 0) out.append('|');
            out.append(clean);
            taken++;
        }
        return out.toString();
    }

    /** Подсказка «имя~название трека» для точной привязки артиста на сервере (поле h). */
    public static String hint(String artist, String title) {
        String a = name(artist), t = safeName(title);
        if (a.isEmpty() || t.isEmpty()) return "";
        return a + "~" + (t.length() <= 80 ? t : t.substring(0, 80).trim());
    }

    /** Склейка уже готовых записей (сидов, подсказок) через `|` с бюджетом символов; записи не чистятся повторно. */
    public static String joinRaw(List<String> items, int limit, int maxChars) {
        StringBuilder out = new StringBuilder();
        int taken = 0;
        for (String item : items) {
            if (item == null || item.isEmpty()) continue;
            if (taken >= limit) break;
            int extra = item.length() + (out.length() > 0 ? 1 : 0);
            if (out.length() + extra > maxChars) break;
            if (out.length() > 0) out.append('|');
            out.append(item);
            taken++;
        }
        return out.toString();
    }
}
