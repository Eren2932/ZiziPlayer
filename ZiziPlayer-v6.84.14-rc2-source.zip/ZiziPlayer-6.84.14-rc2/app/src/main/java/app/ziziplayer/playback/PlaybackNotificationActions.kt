package app.ziziplayer.playback

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession

/** Explicit intents to our one service. Standard keys are handled by MediaSessionService. */
@UnstableApi
internal class PlaybackNotificationActions(private val service: PlaybackService) : MediaNotification.ActionFactory {
    companion object {
        const val CUSTOM = "app.ziziplayer.NOTIFICATION_COMMAND"
        const val ACTION = "command"
        const val EXTRAS = "extras"
    }
    override fun createMediaAction(session: MediaSession, icon: IconCompat, title: CharSequence, command: Int) =
        NotificationCompat.Action(icon, title, createMediaActionPendingIntent(session, command.toLong()))

    override fun createMediaActionPendingIntent(session: MediaSession, command: Long): PendingIntent {
        val interrupted = (session.player as? FocusPlayer)?.isResumePending == true
        val key = when (command.toInt()) {
            Player.COMMAND_PLAY_PAUSE -> if (interrupted) KeyEvent.KEYCODE_MEDIA_PAUSE else KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM -> KeyEvent.KEYCODE_MEDIA_NEXT
            Player.COMMAND_SEEK_TO_PREVIOUS, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            Player.COMMAND_SEEK_FORWARD -> KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
            Player.COMMAND_SEEK_BACK -> KeyEvent.KEYCODE_MEDIA_REWIND
            Player.COMMAND_STOP -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_UNKNOWN
        }
        val intent = Intent(Intent.ACTION_MEDIA_BUTTON).setClass(service, PlaybackService::class.java)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, key))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (command.toInt() == Player.COMMAND_PLAY_PAUSE && !session.player.playWhenReady && !interrupted)
            PendingIntent.getForegroundService(service, key, intent, flags)
        else PendingIntent.getService(service, key, intent, flags)
    }
    override fun createCustomAction(session: MediaSession, icon: IconCompat, title: CharSequence,
                                    customAction: String, extras: Bundle): NotificationCompat.Action {
        val intent = Intent(CUSTOM).setClass(service, PlaybackService::class.java)
            .setData(Uri.Builder().scheme("zizi-notification").authority("command")
                .appendPath(session.id).appendPath(customAction).build())
            .putExtra(ACTION, customAction).putExtra(EXTRAS, extras)
        return NotificationCompat.Action(icon, title, PendingIntent.getService(service, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
    }
    override fun createCustomActionFromCustomCommandButton(session: MediaSession, button: CommandButton): NotificationCompat.Action {
        val command = requireNotNull(button.sessionCommand)
        return createCustomAction(session, IconCompat.createWithResource(service, button.iconResId),
            button.displayName, command.customAction, command.customExtras)
    }
}
