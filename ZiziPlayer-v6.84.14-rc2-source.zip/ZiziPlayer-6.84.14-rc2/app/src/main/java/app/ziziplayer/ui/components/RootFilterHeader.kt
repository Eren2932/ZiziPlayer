package app.ziziplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.LibraryGeometry

// One contract for Home and Library. Insets belong to the screen, not this row.
internal val RootHeaderHeight = 62.dp
internal val RootHeaderAvatarSize = 34.dp
internal val RootHeaderChipHeight = 34.dp
internal val RootHeaderChipGap = 9.dp
internal val RootHeaderChipPadding = 17.dp
internal val RootHeaderFontSize = 13.5.sp

/** 48 dp touch rail + 7 dp above/below = 62 dp. Grow for accessibility text, never clip it. */
@Composable
internal fun RootFilterHeader(
    tag: String,
    modifier: Modifier = Modifier,
    avatar: @Composable () -> Unit,
    filters: @Composable RowScope.() -> Unit
) {
    BoxWithConstraints(modifier.fillMaxWidth().background(Color.Black).testTag(tag)) {
        val edge = LibraryGeometry.edge(maxWidth.value).dp
        Row(Modifier.fillMaxWidth().heightIn(min = RootHeaderHeight)
            .padding(horizontal = edge, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically) {
            avatar()
            Spacer(Modifier.width(13.dp))
            filters()
        }
    }
}
