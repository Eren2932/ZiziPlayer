package app.ziziplayer.ui;

/** User-supplied 576x1280 PNG. The card is x=24, y=146, w=528, h=438.
 * Every position below is local to that card; scale from its actual available width, once.
 * FontScale != 1 uses an expanding accessible layout instead of clipping into these fixed bounds. */
public final class HomeTasteInviteGeometry {
    private HomeTasteInviteGeometry() {}
    public static final float REF_WIDTH = 528f;
    public static final float HEIGHT = 438f;
    public static final float RADIUS = 24f;
    public static final float TOP_GAP = 24f;
    public static final float HERO_WIDTH = 286f;
    public static final float HERO_HEIGHT = 115f;
    public static final float HERO_TOP = 36f;
    public static final float TITLE_TOP = 173f;
    public static final float TITLE_FONT = 31.2f;
    public static final float TITLE_LINE = 40f;
    public static final float BODY_TOP = 220f;
    public static final float BODY_WIDTH = 464f;
    public static final float BODY_FONT = 20f;
    public static final float BODY_LINE = 28f;
    public static final float BUTTON_TOP = 336f;
    public static final float BUTTON_WIDTH = 134f;
    public static final float BUTTON_HEIGHT = 54f;
    public static final float BUTTON_FONT = 20f;
    public static final float CLOSE_FROM_RIGHT = 38f;
    public static final float CLOSE_CENTER_Y = 36f;
    public static final float CLOSE_ICON = 32f; // Zizi icon's drawn cross is ~19 reference pixels.

    public static float width(float availableDp) {
        return !Float.isFinite(availableDp) || availableDp <= 0f ? 300f : Math.min(520f, availableDp);
    }
    public static float scale(float availableDp, float referencePx) {
        return width(availableDp) * referencePx / REF_WIDTH;
    }
    public static boolean fixedLayout(float fontScale) {
        return Float.isFinite(fontScale) && fontScale >= 0.98f && fontScale <= 1.05f;
    }
}
