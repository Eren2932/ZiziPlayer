package app.ziziplayer.ui;

/** Artist-only, distance-driven motion. All geometry arguments use physical pixels.
 * A single LazyColumn owns input/fling/restoration. There is no second scroll accumulator,
 * spring, snap threshold or direction-dependent state to diverge on reversal.
 */
public final class ArtistHeaderMotion {
    private ArtistHeaderMotion() {}
    public static final float TOOLBAR_DP = 56f;
    public static final float PLAY_DP = 56f;
    public static final float DETAILS_BOTTOM_DP = 12f;
    public static final float BUTTON_DRIFT_DP = 8f;
    public static final float PORTRAIT_SHRINK = .06f;

    public static final class Frame {
        public final float portraitScale, portraitDim, toolbarAlpha, titleAlpha;
        public final float buttonInsetDp, buttonDiscAlpha;
        private Frame(float scale, float dim, float bar, float title, float inset, float disc) {
            portraitScale = scale; portraitDim = dim; toolbarAlpha = bar; titleAlpha = title;
            buttonInsetDp = inset; buttonDiscAlpha = disc;
        }
    }

    private static float positive(float v, float fallback) {
        return Float.isFinite(v) && v > 0f ? v : fallback;
    }
    private static float unit(float v) {
        return Float.isFinite(v) ? Math.max(0f, Math.min(1f, v)) : 0f;
    }
    private static float smooth(float v) {
        float x = unit(v);
        return x * x * (3f - 2f * x);
    }

    /** Only the missing scroll range, never a full blank screen after a long discography. */
    public static float minimumTail(float viewportDp, float toolbarBottomDp, float bottomDp,
            float minimumRowsDp, boolean hasPlay) {
        float view = positive(viewportDp, 0f);
        float bar = positive(toolbarBottomDp, TOOLBAR_DP);
        float bottom = positive(bottomDp, 0f);
        float rows = positive(minimumRowsDp, 0f);
        float endBeyondHero = hasPlay ? PLAY_DP - DETAILS_BOTTOM_DP - 8f : TOOLBAR_DP - 8f;
        return Math.max(0f, view - bar - bottom - rows + endBeyondHero);
    }

    /** Title begins as Play meets the lower edge of the toolbar; it fades over two Play
     * diameters, as in the supplied recording. The opaque toolbar arrives before the title.
     * heroPx is the measured SIZE of lazy item zero, not its moving viewport coordinate.
     * Empty/loading pages use the metadata bottom as the anchor instead of a phantom Play.
     */
    public static Frame frame(int firstIndex, int firstOffset, float heroPx,
            float portraitPx, float toolbarBottomPx, float density, boolean hasPlay) {
        float d = positive(density, 1f);
        float photo = positive(portraitPx, 280f * d);
        float barBottom = positive(toolbarBottomPx, TOOLBAR_DP * d);
        float hero = positive(heroPx, photo + (hasPlay ? 120f : 64f) * d);
        float play = PLAY_DP * d;
        float anchor = hasPlay ? hero - DETAILS_BOTTOM_DP * d - play : hero;
        float titleStart = Math.max(1f, anchor - barBottom - 8f * d);
        float titleTravel = hasPlay ? 2f * play : TOOLBAR_DP * d;
        float titleEnd = titleStart + titleTravel;
        // Lazy item zero can be absent after restoration or a programmatic deep jump.
        // Saturate ALL layers, irrespective of unavailable/stale hero measurements.
        float scroll = firstIndex > 0 ? Math.max(hero, Math.max(photo, titleEnd))
                : Math.max(0, firstOffset);
        float shrink = unit(scroll / photo);
        float bar = smooth((scroll - (titleStart - play)) / play);
        float title = unit((scroll - titleStart) / titleTravel);
        float buttonProgress = unit(scroll / titleEnd);
        return new Frame((1f - PORTRAIT_SHRINK * shrink) / (1f - PORTRAIT_SHRINK),
                .55f * unit(scroll / (photo * .6f)), bar, title,
                BUTTON_DRIFT_DP * (1f - buttonProgress),
                .28f * smooth(scroll / (photo * .25f)) * (1f - bar));
    }
}
