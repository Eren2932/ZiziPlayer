package app.ziziplayer.ui.components

import androidx.compose.ui.graphics.Color
import app.ziziplayer.playback.AudioOutput
import app.ziziplayer.playback.OutputKind
import app.ziziplayer.ui.theme.ZiziBrand

/** Stable Zizi brand colour, never sampled from artwork or copied from a reference app. */
val ConnectedDeviceAccent = ZiziBrand

fun audioOutputIcon(output: AudioOutput, large: Boolean = false) = when (output.kind) {
    OutputKind.PHONE -> if (large) ZiziIcons.ConnectPhone else ZiziIcons.ConnectDevices
    OutputKind.WIRED, OutputKind.BLUETOOTH -> ZiziIcons.Headphones
    OutputKind.BLUETOOTH_SPEAKER -> ZiziIcons.ConnectSpeaker
    // A2DP does not identify a headset vs another Bluetooth sink. If class/permission is
    // unavailable, retain the legacy listening glyph; do not change actual route metadata.
    OutputKind.BLUETOOTH_OTHER -> ZiziIcons.Headphones
    OutputKind.USB, OutputKind.EXTERNAL, OutputKind.UNKNOWN -> ZiziIcons.ConnectDevices
}

fun audioOutputTint(output: AudioOutput): Color =
    if (output.isKnown && !output.isPhone) ConnectedDeviceAccent else Color.White

fun audioOutputTransport(output: AudioOutput): String = when (output.kind) {
    OutputKind.PHONE -> "Медиа"
    OutputKind.WIRED -> "Кабель"
    OutputKind.BLUETOOTH, OutputKind.BLUETOOTH_SPEAKER, OutputKind.BLUETOOTH_OTHER -> "Bluetooth"
    OutputKind.USB -> "USB"
    OutputKind.EXTERNAL -> "Аудиовыход"
    OutputKind.UNKNOWN -> "Не определён"
}
