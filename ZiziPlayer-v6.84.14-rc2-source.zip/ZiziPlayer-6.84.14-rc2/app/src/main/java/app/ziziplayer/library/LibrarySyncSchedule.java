package app.ziziplayer.library;

/**
 * 6.84.14 (A1, A2). Когда облачной библиотеке можно ходить в сеть. Чистые функции, без Android.
 *
 * Причина: синхронизация стартовала одновременно с холодной загрузкой главной и делила с ней мобильный канал.
 * Каждый вход делал две полные проверки подряд (connect и refresh: снимок всей библиотеки, хеш, /auth/me,
 * /auth/library до 8 МиБ), а потом каждые 15 секунд снова снимок и скачивание документа. Метаданные и
 * подборки важнее копии: копия подождёт, но не дольше потолков ниже.
 */
public final class LibrarySyncSchedule {
    private LibrarySyncSchedule() {}

    /** Дольше этого главную не ждём: синхронизация стартует в любом случае. */
    public static final long START_MAX_WAIT_MS = 10_000L;
    /** Шаг проверки «пора отправлять». */
    public static final long FLUSH_TICK_MS = 5_000L;
    /** Периодическая отправка: было 15 с. Уход в фон по-прежнему отправляет сразу. */
    public static final long FLUSH_INTERVAL_MS = 60_000L;
    /** Если главная или загрузка звука держат отправку, потолок откладывания. */
    public static final long FLUSH_MAX_DEFER_MS = 180_000L;
    /** Как часто, если локально ничего не изменилось, спрашивать облако о чужих правках (было: каждые 15 с). */
    public static final long REMOTE_POLL_MS = 300_000L;
    /** refresh() сразу после connect() не повторяет полную проверку. */
    public static final long RECENT_CHECK_MS = 30_000L;

    /** Можно ли начинать синхронизацию. [homeStarted] false = главная ещё не просила загрузку в этом процессе. */
    public static boolean mayStart(boolean homeStarted, boolean homeBusy, long waitedMs) {
        if (waitedMs >= START_MAX_WAIT_MS) return true;
        return homeStarted && !homeBusy;
    }

    /** Пора ли вызывать flush: прошёл интервал и ни главная, ни загрузка звука не заняты, либо вышел потолок. */
    public static boolean flushDue(long sinceLastMs, boolean homeBusy, boolean audioLoading) {
        if (sinceLastMs >= FLUSH_MAX_DEFER_MS) return true;
        return sinceLastMs >= FLUSH_INTERVAL_MS && !homeBusy && !audioLoading;
    }

    /** Нужно ли сходить в облако за чужими правками, когда локально ничего не изменилось. */
    public static boolean remotePollDue(long nowMs, long lastRemoteMs) {
        return lastRemoteMs <= 0L || nowMs - lastRemoteMs >= REMOTE_POLL_MS;
    }

    /** Облако только что проверено: повторять полную проверку незачем. */
    public static boolean recentlyChecked(long nowMs, long lastRemoteMs) {
        return lastRemoteMs > 0L && nowMs - lastRemoteMs >= 0L && nowMs - lastRemoteMs < RECENT_CHECK_MS;
    }
}
