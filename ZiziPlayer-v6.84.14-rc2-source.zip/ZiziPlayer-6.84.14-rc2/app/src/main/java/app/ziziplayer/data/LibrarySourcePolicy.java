package app.ziziplayer.data;

/** Platform-free classification used by source probes; a placeholder is NOT a lost file. */
public final class LibrarySourcePolicy {
    private LibrarySourcePolicy() {}
    public static boolean isProbeUri(String raw) {
        return raw != null && (raw.startsWith("content://") || raw.startsWith("file://"));
    }
    public static boolean shouldReportLoss(int lostFolders, int confirmedMissingDocuments) {
        // MediaStore count drift is a rescan hint, not proof of deletion (dedupe/index churn).
        return lostFolders > 0 || confirmedMissingDocuments > 0;
    }
}
