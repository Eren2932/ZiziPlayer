package app.ziziplayer.ui;

import app.ziziplayer.data.remote.DeezerArtistRef;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Pure, bounded rules shared by the picker, encrypted state and delivery gate. */
public final class HomeTastePolicy {
    private HomeTastePolicy() {}
    public static final int MIN_PICKS = 3;
    public static final int MAX_PICKS = 30;
    public static final int RELATED_LIMIT = 6;
    // Keep the upstream candidate pool. Six is the DISPLAY limit, not the fetch limit.
    public static final int RELATED_POOL_LIMIT = 25;
    public static final int CATALOG_PAGE_SIZE = 23;
    /** 6.84.6: «Другие рекомендации» ДОБАВЛЯЕТ страницы в конец сетки, а не подменяет её, поэтому потолок
     * выше прежних 144: около тринадцати страниц по 23. Выбранные артисты не вытесняются никогда. */
    public static final int DECK_LIMIT = 300;
    /** Сколько соседей запрашивается у графа за один раунд. */
    public static final int EXPAND_ANCHORS = 4;
    public static final int EXPANSION_CACHE_LIMIT = 96;
    /** 6.84.7: граф отвечает дольше 5 секунд на холодном кэше (бюджет сервера сам 5 с), поэтому клиент ждёт
     * дольше и не обрывает запрос, который сервер вот-вот достроит. Это фон, пользователь не ждёт. */
    public static final long EXPANSION_TIMEOUT_MS = 12_000L;
    /** «Похожие» на выбранного: общий таймаут (внутри основной запрос и запасной маршрут). */
    public static final long RELATED_TIMEOUT_MS = 12_000L;
    /** Сколько раз тихо повторяем «похожих» на выбранного, прежде чем показать значок «повторить». */
    public static final int RELATED_ATTEMPTS = 3;
    /** 6.84.7: одно нажатие «Других рекомендаций» добавляет ровно столько карточек (как в референсе). 6 делится на
     * 1, 2 и 3 колонки, поэтому плитка остаётся в той же колонке, а новые карточки занимают целые ряды. */
    public static final int MORE_PAGE = 6;
    /** Запас свежих кандидатов: ниже минимума фон добирает соседей до цели, поэтому нажатие почти всегда мгновенное. */
    public static final int RESERVE_MIN = 18;
    public static final int RESERVE_TARGET = 36;
    /** Сколько раундов соседей подряд (без паузы после успешного) делает фон или нажатие, если свежих нет. */
    public static final int EXPAND_ROUNDS = 3;
    public static final int GROUP_LIMIT = 64;
    public static final int SEARCH_LIMIT = 180;
    public static final long SEARCH_DEBOUNCE_MS = 300L;
    public static final long BUILD_TIMEOUT_MS = 30_000L;
    public static final int MAX_BUILD_POLLS = 12;
    /** Foreground setup does not fall into the normal 15/45/135-second refresh ladder.
     * One call at a time, finite count, respect the same bounded server hint as Home. */
    public static long buildPollDelayMs(long hintMs) {
        return Math.max(2_000L, Math.min(10_000L, hintMs));
    }
    /** 6.84.11. Искусственные паузы экрана «Ищем для тебя музыку…» убраны: раньше пол был 900 + 650 + 650 = 2.2 с,
     * даже когда сервер отвечал за 200 мс. Теперь экран держится ровно столько, сколько идёт настоящая сборка.
     * INTRO и BUILDING_MIN равны нулю (delay(0) возвращается сразу), READY_HOLD оставлен коротким, чтобы
     * галочка «Твоя музыка готова» успела считаться глазом, а не мигнула. */
    public static final long INTRO_MS = 0L;
    public static final long BUILDING_MIN_MS = 0L;
    public static final long READY_HOLD_MS = 250L;

    public static String artistId(String raw) {
        String id = DeezerArtistRef.parse("dz", raw);
        return "0".equals(id) ? null : id;
    }

    public static List<String> uniqueIds(Collection<String> raw) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        if (raw != null) for (String value : raw) {
            String id = artistId(value);
            if (id != null) ids.add(id);
        }
        return new ArrayList<>(ids);
    }

    /** Order-independent; leading zeros/duplicate catalogue spellings do not make a new taste. */
    public static String selectionKey(Collection<String> raw) {
        List<String> ids = uniqueIds(raw);
        if (ids.size() < MIN_PICKS || ids.size() > MAX_PICKS) return "";
        ids.sort((a, b) -> a.length() == b.length() ? a.compareTo(b) : Integer.compare(a.length(), b.length()));
        return "taste-v1:" + String.join(",", ids);
    }

    public static List<String> trimDeck(Collection<String> deck, Collection<String> selected, int limit) {
        List<String> out = uniqueIds(deck);
        if (limit <= 0) return out;
        Set<String> picks = new LinkedHashSet<>(uniqueIds(selected));
        for (int i = out.size() - 1; out.size() > limit && i >= 0; i--)
            if (!picks.contains(out.get(i))) out.remove(i);
        return out;
    }

    /** Insert neighbours immediately after the tapped cell, not at an arbitrary global index 12.
     * Prefix and selected cells never move. Existing unselected neighbours are promoted once.
     * Trimming evicts unselected tail cells only, so a far-away pick cannot disappear. */
    public static List<String> insertRelated(Collection<String> deck, String rawAnchor,
            Collection<String> neighbours, Collection<String> selected, int limit) {
        List<String> base = uniqueIds(deck);
        String anchor = artistId(rawAnchor);
        int index = base.indexOf(anchor);
        if (index < 0 || limit <= 0) return trimDeck(base, selected, limit);
        Set<String> picks = new LinkedHashSet<>(uniqueIds(selected));
        Set<String> prefix = new LinkedHashSet<>(base.subList(0, index + 1));
        List<String> insert = new ArrayList<>();
        for (String id : uniqueIds(neighbours)) {
            if (!prefix.contains(id) && (!picks.contains(id) || !base.contains(id))) insert.add(id);
            if (insert.size() >= RELATED_LIMIT) break;
        }
        if (insert.isEmpty()) return trimDeck(base, selected, limit);
        List<String> out = new ArrayList<>(base.size() + insert.size());
        out.addAll(base.subList(0, index + 1)); out.addAll(insert);
        Set<String> incoming = new LinkedHashSet<>(insert);
        for (String id : base.subList(index + 1, base.size())) if (!incoming.contains(id)) out.add(id);
        return trimDeck(out, picks, limit);
    }

    /** Preserve the tapped row. Six neighbours appear as two new rows, not between its cells.
     * Column count comes from the rendered grid, including font accessibility and rotation. */
    public static List<String> insertRelatedRows(Collection<String> deck, String rawAnchor,
            Collection<String> neighbours, Collection<String> selected, int limit, int columns) {
        List<String> base = uniqueIds(deck);
        int index = base.indexOf(artistId(rawAnchor));
        if (index < 0) return trimDeck(base, selected, limit);
        int cols = Math.max(1, Math.min(3, columns));
        int end = Math.min(base.size(), (index / cols + 1) * cols);
        return insertRelated(base, base.get(end - 1), neighbours, selected, limit);
    }

    /** Filter BEFORE taking six: selected artists, the tapped row and older batches cannot
     * consume the visible quota. Pure replay makes reverse network completion deterministic. */
    public static List<String> replayRelatedRows(Collection<String> deck,
            Map<String, ? extends Collection<String>> batches, Collection<String> selected,
            int limit, int columns) {
        List<String> out = trimDeck(deck, selected, limit);
        Set<String> reserved = new LinkedHashSet<>();
        Set<String> picks = new LinkedHashSet<>(uniqueIds(selected));
        int cols = Math.max(1, Math.min(3, columns));
        for (Map.Entry<String, ? extends Collection<String>> batch : batches.entrySet()) {
            int index = out.indexOf(artistId(batch.getKey()));
            if (index < 0) continue;
            int end = Math.min(out.size(), (index / cols + 1) * cols);
            Set<String> prefix = new LinkedHashSet<>(out.subList(0, end));
            List<String> fresh = new ArrayList<>();
            for (String id : uniqueIds(batch.getValue())) {
                if (prefix.contains(id) || reserved.contains(id) || (picks.contains(id) && out.contains(id))) continue;
                fresh.add(id);
                if (fresh.size() == RELATED_LIMIT) break;
            }
            out = insertRelatedRows(out, batch.getKey(), fresh, selected, limit, cols);
            reserved.addAll(fresh);
        }
        return out;
    }

    /** A new page, not another request for the same cached first 72 artists. Selected IDs stay
     * pinned; unseen candidates win, then old pages cycle. The current page is the last resort. */
    public static List<String> recommendationPage(Collection<String> pool, Collection<String> selected,
            Collection<String> seen, Collection<String> currentPage) {
        List<String> picks = uniqueIds(selected);
        Set<String> selectedSet = new LinkedHashSet<>(picks);
        Set<String> visited = new LinkedHashSet<>(uniqueIds(seen));
        Set<String> current = new LinkedHashSet<>(uniqueIds(currentPage));
        List<String> candidates = uniqueIds(pool);
        List<String> out = new ArrayList<>(picks);
        int target = Math.min(DECK_LIMIT, picks.size() + CATALOG_PAGE_SIZE);
        for (int pass = 0; pass < 3; pass++) {
            for (String id : candidates) {
                if (out.size() >= target) return out;
                if (selectedSet.contains(id) || out.contains(id)) continue;
                int bucket = current.contains(id) ? 2 : visited.contains(id) ? 1 : 0;
                if (bucket == pass) out.add(id);
            }
        }
        return out;
    }

    /** 6.84.7. Сколько карточек добавить за одно нажатие «Других рекомендаций»: не больше [MORE_PAGE], не больше
     * [available] (артистов не выдумываем) и не больше места до [DECK_LIMIT]. 0 — добавлять нечего. Число колонок
     * в расчёте не участвует: 6 кратно 1, 2 и 3, ряд с плиткой не «ломается». Параметр оставлен ради совместимости. */
    public static int appendPageSize(int shown, int columns, int available) {
        int room = DECK_LIMIT - Math.max(0, shown);
        int avail = Math.min(Math.max(0, available), room);
        return Math.max(0, Math.min(MORE_PAGE, avail));
    }

    /** Пауза перед повтором «похожих» на выбранного: 0 -> 1.2 с, 1 -> 2.4 с, дальше 3.6 с. */
    public static long relatedRetryDelayMs(int attempt) {
        return 1_200L * (Math.max(0, Math.min(2, attempt)) + 1);
    }

    /** Пауза между раундами соседей после раунда без единого ответа сети: 1.5 с, 3 с, 4.5 с. */
    public static long expandRetryDelayMs(int round) {
        return 1_500L * Math.max(1, Math.min(3, round));
    }

    /** Нужен ли фоновой подкачке ещё один раунд: свежих меньше запаса и сессия не упёрлась в потолок. */
    public static boolean needsReserve(int fresh, int shown) {
        return fresh < RESERVE_MIN && shown < DECK_LIMIT;
    }

    /** 6.84.6. Кандидаты следующей страницы: порядок пула сохраняется, выбранные, уже показанные в этой
     * сессии и уже стоящие в сетке артисты исключаются. Ничего не «ротируется»: показанное не вернётся. */
    public static List<String> freshCandidates(Collection<String> pool, Collection<String> selected,
            Collection<String> seen, Collection<String> shown) {
        Set<String> excluded = new LinkedHashSet<>(uniqueIds(selected));
        excluded.addAll(uniqueIds(seen));
        excluded.addAll(uniqueIds(shown));
        List<String> out = new ArrayList<>();
        for (String id : uniqueIds(pool)) if (!excluded.contains(id)) out.add(id);
        return out;
    }

    /** 6.84.6. У кого спрашивать соседей, когда свежих кандидатов мало: сначала то, что человек видел
     * последним (конец сетки), потом остальное. Выбранные уже имеют свой список «похожих», уже
     * опрошенные пропускаются. */
    public static List<String> expansionAnchors(Collection<String> shown, Collection<String> alreadyAsked, int limit) {
        Set<String> asked = new LinkedHashSet<>(uniqueIds(alreadyAsked));
        List<String> order = uniqueIds(shown);
        List<String> out = new ArrayList<>();
        for (int i = order.size() - 1; i >= 0 && out.size() < limit; i--)
            if (!asked.contains(order.get(i))) out.add(order.get(i));
        return out;
    }

    public static boolean recoverFailed(boolean open, boolean failed, boolean ready, String selection, String deliveredKey) {
        return open && failed && ready && selection != null && !selection.isEmpty() && selection.equals(deliveredKey);
    }

    /** First useful delivery, NOT completion of every optional enrichment job.
     * A partial graph is usable when this live response echoes ALL confirmed IDs and its own
     * musical cards are displayed. Empty/artist-only, snapshot and wrong-profile data still fail.
     * complete remains in the signature for callers; it controls background refresh, not entry. */
    public static boolean delivered(String expectedKey, String responseKey, boolean live,
            boolean complete, int playableCards, Collection<String> selected, Collection<String> echoed) {
        if (!live || playableCards <= 0 || expectedKey == null || expectedKey.isEmpty()
                || !expectedKey.equals(responseKey) || !expectedKey.equals(selectionKey(selected))) return false;
        Set<String> recognized = new LinkedHashSet<>(uniqueIds(echoed));
        return recognized.containsAll(uniqueIds(selected));
    }
}
