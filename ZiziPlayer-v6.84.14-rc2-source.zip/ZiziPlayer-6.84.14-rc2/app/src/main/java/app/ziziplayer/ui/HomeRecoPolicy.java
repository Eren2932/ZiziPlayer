package app.ziziplayer.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Профиль вкуса для серверной «Главной» (Reco 1). Чистая арифметика и текст, без Android.
 *
 * На сервер уходит ровно то, что нужно графу: до 8 артистов с весами, имена известных, пропущенные
 * и последние артисты, предпочтение версии. Не уходят названия треков, время и длительности.
 */
public final class HomeRecoPolicy {
    private HomeRecoPolicy() {}

    /** Reco 2: сидов до 30. Первые [LEGACY_SEEDS] уходят полем s (его читает и сервер 1.15), остальные — s2. */
    public static final int MAX_SEEDS = 30;
    public static final int LEGACY_SEEDS = 8;
    public static final int MAX_KNOWN = 60;
    public static final int MAX_NEGATIVE = 40;
    public static final int MAX_RECENT = 3;
    /** Подсказок «имя~трек» за запрос: только для артистов, у которых ещё нет id Deezer. */
    public static final int MAX_HINTS = 30;
    /** Бюджет символов полей, которые читает и сервер 1.15 (у него 422 на k > 1400, x > 500, сумма > 3200). */
    public static final int KNOWN_CHARS = 1400;
    public static final int NEGATIVE_CHARS = 500;
    public static final int SEEDS_CHARS = 1200;
    public static final int SEEDS2_CHARS = 2000;
    public static final int HINTS_CHARS = 3200;
    /** Артист с суммарной оценкой не выше этого порога считается нежеланным (ранние пропуски). */
    public static final double NEGATIVE_SCORE = -3.0;
    /** Соисполнитель получает 60% оценки трека: вклад есть, но он не главный. */
    public static final double SECONDARY_SHARE = 0.6;
    /** Минимальная доля версии в прослушанном, чтобы считать её предпочтением вкуса. */
    public static final double VERSION_SHARE = 0.4;

    private static final Pattern CREDIT_SPLIT = Pattern.compile(
        "\\s*(?:,|;|\\s&\\s|\\sx\\s|\\s(?:feat|ft|featuring|with)\\.?\\s)\\s*", Pattern.CASE_INSENSITIVE);
    private static final Pattern SLOWED = Pattern.compile("\\bslow(?:ed|ing)?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SPED_UP = Pattern.compile(
        "\\b(?:sped|speed)[\\s_-]*up\\b|\\bnightcore\\b|\\b(?:ultra|super|mega|hiper|hyper|extreme|extra)[\\s_+-]*speed\\b",
        Pattern.CASE_INSENSITIVE);

    /** «A, B & C feat. D» -> [A, B, C, D]. Пустые и дубли выбрасываются, порядок сохраняется. */
    public static List<String> splitArtists(String credited) {
        List<String> result = new ArrayList<>();
        if (credited == null) return result;
        for (String part : CREDIT_SPLIT.split(credited.trim())) {
            String clean = part.trim();
            if (clean.length() < 2) continue;
            boolean seen = false;
            for (String old : result) if (HomeFeedPolicy.normalize(old).equals(HomeFeedPolicy.normalize(clean))) seen = true;
            if (!seen) result.add(clean);
        }
        return result;
    }

    /** Вес сида: score / max, зажатый в [0.05, 1]. Не положительный вклад весом не обладает. */
    public static double weight(double score, double maxScore) {
        if (!(score > 0.0) || !(maxScore > 0.0)) return 0.0;
        return Math.max(0.05, Math.min(1.0, score / maxScore));
    }

    public static boolean slowed(String title) {
        return title != null && SLOWED.matcher(title).find();
    }

    public static boolean spedUp(String title) {
        return title != null && SPED_UP.matcher(title).find();
    }

    /** "slowed" | "sped" | "" — какой обработке записей отдаёт предпочтение вкус. */
    public static String versionPreference(double slowedMass, double spedMass, double totalMass) {
        if (!(totalMass > 0.0)) return "";
        double slow = slowedMass / totalMass, sped = spedMass / totalMass;
        if (slow >= VERSION_SHARE && slow >= sped) return "slowed";
        if (sped >= VERSION_SHARE) return "sped";
        return "";
    }

    /** Сервер ответил и есть что показать: рисуем полки Reco. */
    public static final int SHOW = 0;
    /** Сервер ответил, но Reco нет (старше 6.81 или нечего предложить): тихо идём прежним путём. */
    public static final int FALLBACK = 1;
    /** Сервер не ответил за отведённое время: как у любого другого запроса главной (сообщение, без шторма). */
    public static final int TIMEOUT = 2;

    /**
     * Что делать с результатом запроса Reco. «Не ответил» и «ответил null» нельзя путать: первое означает
     * проблемы сети, и прежний путь по ней же не пройдёт; второе означает старый сервер, и прежний путь
     * обязан отработать без единого слова об ошибке.
     */
    public static int outcome(boolean answered, int shelves) {
        if (!answered) return TIMEOUT;
        return shelves > 0 ? SHOW : FALLBACK;
    }

    /**
     * 6.82.0. Сервер ответил ПУСТО и НЕПОЛНО: он ещё достраивает граф в кэше (холодный старт).
     * Это не «старый сервер»: 6.81.0 принимал такой ответ за успех, уходил на прежний путь, считал
     * обновление удавшимся и молчал 30 минут. Теперь это отдельный исход: быстрый повтор через 2/4/8 с.
     */
    public static final int RETRY = 3;

    /**
     * Исход с учётом полноты ответа. Пустой и полный ответ — это FALLBACK как раньше (старый сервер,
     * новый пользователь без истории); пустой и неполный — RETRY. Полки есть — SHOW при любой полноте.
     */
    public static int outcome(boolean answered, int shelves, boolean complete) {
        if (!answered) return TIMEOUT;
        if (shelves > 0) return SHOW;
        return complete ? FALLBACK : RETRY;
    }

    /**
     * Порядок полок Reco на экране: сначала треки, затем альбомы, затем артисты. Сервер на холодном
     * кэше отдавал альбомы раньше треков, и первый экран получался без единой полки с музыкой.
     * Сортировка устойчивая (в Kotlin sortedBy): внутри вида порядок сервера сохраняется.
     */
    public static int shelfRank(String kind) {
        if (kind == null) return 3;
        switch (kind.toUpperCase(java.util.Locale.ROOT)) {
            case "TRACKS": return 0;
            case "ALBUMS": return 1;
            case "ARTISTS": return 2;
            default: return 3;
        }
    }

    // ───────────────────────────── Reco 2: чистка сидов и оценка артиста ─────────────────────────────

    /** Хвосты, которые YouTube и агрегаторы приклеивают к имени: «Artist - Topic», «ArtistVEVO». */
    private static final Pattern CHANNEL_TAIL = Pattern.compile(
        "(?:\\s*[-–—]\\s*topic|\\s*vevo|\\s+official(?:\\s+(?:channel|music|audio))?|\\s+music\\s+channel)\\s*$",
        Pattern.CASE_INSENSITIVE);
    /** Имя-заглушка, а не артист: граф по нему ведёт к случайному тёзке. Сравнивается после normalize(). */
    private static final java.util.Set<String> PLACEHOLDERS = new java.util.HashSet<>(java.util.Arrays.asList(
        "unknown", "unknown artist", "unknown artists", "artist", "various", "various artists", "va", "v a",
        "неизвестный артист", "неизвестный исполнитель", "неизвестен", "исполнитель", "без исполнителя",
        "сборник", "разные исполнители", "null", "none", "youtube", "youtube music", "music", "topic")
        .stream().map(HomeFeedPolicy::normalize).collect(java.util.stream.Collectors.toSet()));
    /** Канал-перезаливщик: в имени служебные слова обработки. Настоящий артист так себя не называет. */
    private static final Pattern REUPLOADER = Pattern.compile(
        "\\b(?:slowed|reverb|sped\\s*up|nightcore|bass\\s*boost(?:ed)?|8d\\s*audio|lyrics?|lyric\\s*video|"
            + "youtube|records?\\s+channel|music\\s+channel|playlist|compilation|mix(?:es)?\\s+channel|tiktok\\s+songs?)\\b",
        Pattern.CASE_INSENSITIVE);

    /**
     * Имя артиста для профиля: без хвостов канала. Пустая строка — это не артист (заглушка «unknown»,
     * «Неизвестный артист», «Various Artists», канал-перезаливщик), его нельзя ни сидом, ни миксом.
     */
    public static String cleanArtist(String name) {
        if (name == null) return "";
        String clean = name.trim();
        if (clean.startsWith("<") && clean.endsWith(">")) return "";
        clean = CHANNEL_TAIL.matcher(clean).replaceAll("").trim();
        String key = HomeFeedPolicy.normalize(clean);
        if (key.isEmpty() || PLACEHOLDERS.contains(key)) return "";
        if (REUPLOADER.matcher(clean).find()) return "";
        return clean;
    }

    public static boolean isRealArtist(String name) { return !cleanArtist(name).isEmpty(); }

    /** Вклад трека: 4·избранное + слушания (как в «Твоих миксах») + 1.5·в плейлисте + 1·в медиатеке. */
    public static final double PLAYLIST_CREDIT = 1.5;
    public static final double LIBRARY_CREDIT = 1.0;
    public static double trackAffinity(double listeningScore, boolean inPlaylist, boolean inLibrary) {
        double base = Double.isFinite(listeningScore) ? listeningScore : 0.0;
        return base + (inPlaylist ? PLAYLIST_CREDIT : 0.0) + (inLibrary ? LIBRARY_CREDIT : 0.0);
    }

    /** Открытие артиста или его трека из поиска: 1.5 с полураспадом 7 дней, старше 30 дней — ноль. */
    public static double searchCredit(double ageDays) {
        if (!(ageDays >= 0.0) || ageDays > 30.0) return ageDays < 0.0 ? 1.5 : 0.0;
        return 1.5 * Math.pow(0.5, ageDays / 7.0);
    }

    /** Выбор при знакомстве: 6, тает линейно к 50 зачтённым прослушиваниям — дальше говорит история. */
    public static final double ONBOARDING_CREDIT = 6.0;
    public static final int ONBOARDING_FADE_PLAYS = 50;
    public static double onboardingCredit(int qualifiedPlays) {
        int n = Math.max(0, qualifiedPlays);
        return ONBOARDING_CREDIT * Math.max(0.0, 1.0 - n / (double) ONBOARDING_FADE_PLAYS);
    }
    /** Минимум, ниже которого выбор при знакомстве не опускается: человек сам сказал, что любит. */
    public static final double ONBOARDING_FLOOR = 1.0;

    /**
     * Вес сида с убывающей отдачей: ln(1 + A) / ln(1 + A_max) в [0.05, 1]. Линейная доля давала
     * артисту с 200 лайками вес 1, а всем остальным 0.05 — граф видел одного человека.
     */
    public static double logWeight(double score, double maxScore) {
        if (!(score > 0.0) || !(maxScore > 0.0) || !Double.isFinite(score) || !Double.isFinite(maxScore)) return 0.0;
        double w = Math.log1p(score) / Math.log1p(Math.max(score, maxScore));
        return Math.max(0.05, Math.min(1.0, w));
    }

    /** Ключ «артист|название» для исключения уже сохранённого. Версии (slowed/live/instrumental) остаются различными. */
    public static String songKey(String artist, String title) {
        String a = HomeFeedPolicy.normalize(splitArtists(artist).isEmpty() ? artist : splitArtists(artist).get(0));
        String t = HomeFeedPolicy.normalize(title);
        return a + "|" + t;
    }

    /** Знакомство нужно, пока у человека нет ни одного сида и он не прошёл/не закрыл окно. */
    public static boolean needsOnboarding(int seeds, int picks, boolean dismissed) {
        return seeds == 0 && picks == 0 && !dismissed;
    }
    public static final int ONBOARDING_MIN = 3;
}
