package app.ziziplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.toEntity
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import app.ziziplayer.data.remote.RecoArtist
import app.ziziplayer.data.remote.DeezerArtistRef
import app.ziziplayer.data.RecoListeningSignal
import app.ziziplayer.data.RecentKind
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import kotlinx.coroutines.withTimeoutOrNull
import app.ziziplayer.data.HomePinEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.PlaylistVaultRow
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.OfflineDownloads
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

internal data class HomePlaylist(val playlist: PlaylistEntity, val cover: TrackEntity?, val count: Int, val pinned: Boolean)
internal data class HomeHistory(val session: ListeningSessionEntity, val track: TrackEntity?)
internal enum class HomeCollectionKind(val title: String, val sourceId: String) {
    WAVE("Моя волна", "home:wave-local-v1"),
    RECENT_ADDED("Недавно добавлено", "home:recent-added"),
    DISCOVERY("Подборка", "home:discovery")
}
internal data class HomeCollection(val kind: HomeCollectionKind, val trackIds: List<String>,
    val title: String = kind.title, val sourceId: String = kind.sourceId, val offlineOnly: Boolean = false)
internal data class HomeState(
    val loading: Boolean = true,
    val hiddenIds: Set<String> = emptySet(),
    val vaultFolders: Set<String> = emptySet(),
    val playlists: List<HomePlaylist> = emptyList(),
    val recentAdded: List<TrackEntity> = emptyList(),
    val offline: List<TrackEntity> = emptyList(),
    val tracks: List<TrackEntity> = emptyList(),
    val availableOfflineIds: Set<String> = emptySet(),
    val history: List<HomeHistory> = emptyList(),
    val listenedMs: Long = 0,
    val qualified: Int = 0,
    val completed: Int = 0,
    val skipped: Int = 0,
    /** Reco 2: треки, лежащие хотя бы в одном плейлисте (+1.5 к артисту). Только разрешённые приватностью. */
    val playlistTrackIds: Set<String> = emptySet(),
    /** Changes only on meaningful taste signals, never playback progress ticks. */
    val tasteRevision: Long = 0L
)
internal enum class HomeTastePhase { PICKING, INTRO, BUILDING, READY, FAILED }
internal data class HomeTasteState(
    val open: Boolean = false, val loading: Boolean = false, val catalogLoading: Boolean = false,
    val catalogError: String? = null, val columns: Int = 3,
    val artists: List<RecoArtist> = emptyList(), val browseArtists: List<RecoArtist> = emptyList(),
    val picks: List<RecoArtist> = emptyList(), val query: String = "", val error: String? = null,
    val allowTrackHints: Boolean = false, val searchOpen: Boolean = false,
    val loadingMore: Boolean = false, val hasMore: Boolean = false,
    val relatedLoading: Set<String> = emptySet(), val relatedErrors: Map<String, String> = emptyMap(),
    val moreError: String? = null, val moreLoading: Boolean = false, val appendRevision: Long = 0L, val revealId: String? = null, val revealRevision: Long = 0L,
    val phase: HomeTastePhase = HomeTastePhase.PICKING, val buildPartial: Boolean = false
) {
    val saving: Boolean get() = phase == HomeTastePhase.INTRO || phase == HomeTastePhase.BUILDING || phase == HomeTastePhase.READY
}
private data class HomeSources(
    val tracks: List<TrackEntity>, val playlists: List<PlaylistEntity>,
    val membership: List<PlaylistVaultRow>, val hidden: Set<String>, val pins: List<HomePinEntity>
)
private data class HomeLibrary(val sources: HomeSources, val offlineIds: Set<String>)
private data class HomeTasteTrackKey(val id: String, val artist: String, val title: String,
    val provider: String?, val remoteId: String?, val kept: Boolean)
private data class HomeTasteLibraryKey(val tracks: List<HomeTasteTrackKey>, val playlistIds: Set<String>)
private data class HomeTasteSignals(val favorites: Set<String>, val listening: RecoListeningSignal,
    val recents: List<Pair<String, Long>>, val library: HomeTasteLibraryKey)

/** Local-first projections. No playback clock, network calls or mutable player state here. */
@OptIn(UnstableApi::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as ZiziApplication
    private val music = app.database.musicDao()
    private val dao = app.database.listeningDao()
    private val refresh = MutableStateFlow(0L)
    private val tasteRevision = MutableStateFlow(0L)
    private val hiddenSource = app.repository.hiddenIds.shareIn(viewModelScope, SharingStarted.Eagerly, replay = 1)
    internal val hidden = hiddenSource.stateIn<Set<String>?>(viewModelScope, SharingStarted.Eagerly, null)
    internal val recommendations = HomeRecommendations(app, viewModelScope, hidden)
    private val recoVault = RecoVault.get(app)
    private val _taste = MutableStateFlow(HomeTasteState())
    internal val taste = _taste.asStateFlow()
    private val _tasteInviteSuppressed = MutableStateFlow(false)
    internal val tasteInviteSuppressed = _tasteInviteSuppressed.asStateFlow()
    internal fun dismissTasteInvite() { _tasteInviteSuppressed.value = true }
    private var tasteJob: Job? = null
    private var tasteSearchJob: Job? = null
    private var tasteSaveJob: Job? = null
    private var tasteEpoch = 0
    private var tasteSearchEpoch = 0
    private var tasteSearchNext: String? = null
    private var tasteRelatedSerial = 0L
    private val tasteRelatedGate = Semaphore(2)
    private val tasteRelatedJobs = mutableMapOf<String, Job>()
    private val tasteRelatedTokens = mutableMapOf<String, Long>()
    private val tasteRelatedBatches = linkedMapOf<String, List<RecoArtist>>()
    private val tasteRelatedCache = linkedMapOf<String, List<RecoArtist>>()
    private val tasteSeenArtists = linkedSetOf<String>()
    // 6.84.6: соседи уже показанных артистов (граф), на которых строятся следующие страницы «Других рекомендаций».
    private val tasteExpansion = linkedMapOf<String, List<RecoArtist>>()
    private val tasteExpandedAnchors = linkedSetOf<String>()
    private var tasteMoreJob: Job? = null
    private var tasteReserveJob: Job? = null
    private var tasteCatalogCache: List<RecoArtist> = emptyList()
    private var tasteBaseArtists: List<RecoArtist> = emptyList()
    private val _catalogTracks = MutableStateFlow<List<TrackEntity>>(emptyList())
    internal val catalogTracks = _catalogTracks.asStateFlow()
    private val _collectionBusy = MutableStateFlow(false)
    internal val collectionBusy = _collectionBusy.asStateFlow()
    private val _collectionError = MutableStateFlow<String?>(null)
    internal val collectionError = _collectionError.asStateFlow()
    private val _hasMore = MutableStateFlow(false)
    internal val hasMore = _hasMore.asStateFlow()
    private var collectionJob: Job? = null
    private var collectionEpoch = 0
    private var remoteCollection: RemoteCollection? = null
    private var nextPage: String? = null
    private val _historyOpen = MutableStateFlow(false)
    val historyOpen = _historyOpen.asStateFlow()
    private val _collection = MutableStateFlow<HomeCollection?>(null)
    internal val collection = _collection.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    val storageProblem = app.listeningStore.problem

    private val sources = combine(music.observeAllTracks(), music.observePlaylists(),
        music.observePlaylistVaultRows(), hiddenSource, dao.observePins()) { tracks, playlists, membership, hidden, pins ->
        HomeSources(tracks, playlists, membership, hidden, pins)
    }.distinctUntilChanged()
    // File existence is checked off-main and NOT on each listening checkpoint.
    private val local = combine(sources, OfflineDownloads.states, refresh) { source, _, _ ->
        HomeLibrary(source, source.tracks.filter { !it.isRemote || OfflineDownloads.isComplete(app, it) }
            .mapTo(HashSet()) { it.id })
    }.flowOn(Dispatchers.IO)

    // Opening Home must not deserialize 10,000 listening sessions. History owns
    // that subscription; Stage 1 shelves only use library projections.
    private val historySessions = _historyOpen.flatMapLatest { open ->
        if (open) dao.observeSessions() else flowOf(emptyList<ListeningSessionEntity>())
    }
    internal val state = combine(local, historySessions, app.repository.vault.state, tasteRevision) { library, sessions, gate, revision ->
        val source = library.sources
        fun allowed(t: TrackEntity) = t.id !in source.hidden &&
            (!t.isRemote || CatalogPolicy.supports(t.provider, t.remoteId)) &&
            (t.isRemote || t.sourceFolder !in gate.folders)
        val tracks = source.tracks.filter(::allowed)
        val byId = tracks.associateBy { it.id }
        val knownIds = source.tracks.mapTo(HashSet()) { it.id }
        val members = source.membership.groupBy { it.playlistId }
        val pins = source.pins.associateBy { it.playlistId }
        val playlists = source.playlists.mapNotNull { playlist ->
            val rows = members[playlist.id].orEmpty()
            // Do not reveal a protected playlist's title/cover through a new home surface.
            if (rows.any { !allowed(it.track) }) return@mapNotNull null
            HomePlaylist(playlist, rows.firstOrNull()?.track, rows.size, playlist.id in pins)
        }.sortedWith(compareByDescending<HomePlaylist> { pins[it.playlist.id]?.pinnedAt ?: 0L }
            .thenByDescending { it.playlist.createdAt })
        val history = sessions.filter { row -> row.trackId !in source.hidden &&
            (row.source != "local" || row.sourceFolder !in gate.folders) &&
            (row.trackId !in knownIds || byId.containsKey(row.trackId))
        }.map { HomeHistory(it, byId[it.trackId]) }
        HomeState(loading = false, hiddenIds = source.hidden, vaultFolders = gate.folders, playlists = playlists,
            tracks = tracks, availableOfflineIds = tracks.filter { it.id in library.offlineIds }.mapTo(HashSet()) { it.id },
            recentAdded = tracks.filter { !it.isRemote || it.savedAt != null }
                .sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(100),
            offline = tracks.filter { it.id in library.offlineIds }.sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(50),
            history = history, listenedMs = history.sumOf { it.session.listenedMs },
            qualified = history.count { it.session.qualified }, completed = history.count { it.session.completed },
            skipped = history.count { it.session.outcome == "skipped" },
            playlistTrackIds = source.membership.filter { allowed(it.track) }.mapTo(HashSet()) { it.track.id },
            tasteRevision = revision)
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState())

    /**
     * 6.82.0. Очередь плеера как потребитель ленты «Для тебя»: индекс в ленте, с которого брать следующие
     * треки (-1 — очередь не из ленты либо указатель устарел), и поколение ленты, к которому он относится.
     */
    private var feedQueueNext = -1
    private var feedQueueEpoch = -1
    private var extendingQueue = false

    init {
        viewModelScope.launch {
            recommendations.tasteDelivery.collectLatest { result ->
                val current = _taste.value
                val key = HomeTastePolicy.selectionKey(current.picks.map { it.id })
                if (HomeTastePolicy.recoverFailed(current.open, current.phase == HomeTastePhase.FAILED,
                        result.ready, key, result.key)) {
                    val epoch = tasteEpoch
                    _taste.value = current.copy(phase = HomeTastePhase.READY, error = null)
                    delay(HomeTastePolicy.READY_HOLD_MS)
                    if (epoch == tasteEpoch && _taste.value.phase == HomeTastePhase.READY) { resetTasteSession(); _taste.value = HomeTasteState() }
                }
            }
        }
        // A one-row aggregate is invalidated by Room, but distinctUntilChanged ignores
        // ordinary checkpoints. No subscription/deserialization of the session history.
        viewModelScope.launch {
            var previous: HomeTasteSignals? = null
            combine(music.observeFavoriteIds().map { it.toSet() }, dao.observeRecoListeningSignal(),
                music.observeRecents().map { rows -> rows.filter { it.kind != RecentKind.QUERY }
                    .map { it.key to it.openedAt } }, local) { favorites, listening, recents, library ->
                val playlistIds = library.sources.membership.mapTo(HashSet()) { it.track.id }
                // IDs and track rows are independent Room flows: a newly inserted favorite's
                // row can arrive later. That arrival must invalidate the earlier profile too.
                // Merely queued/unsaved remote rows and lastSeenAt/positions are not signals.
                val tracks = library.sources.tracks.filter { !it.isRemote || it.savedAt != null ||
                    it.id in favorites || it.id in playlistIds }.map { track ->
                    HomeTasteTrackKey(track.id, track.artist, track.title, track.provider, track.remoteId,
                        !track.isRemote || track.savedAt != null)
                }
                HomeTasteSignals(favorites, listening, recents, HomeTasteLibraryKey(tracks, playlistIds))
            }.flowOn(Dispatchers.Default).distinctUntilChanged().collect { signals ->
                if (previous != signals) tasteRevision.value += 1L // includes the initial-load race
                previous = signals
            }
        }
        // Watch privacy even while another tab owns the screen. Both flows are shared
        // with the existing projection; never retain a protected seed across re-entry.
        viewModelScope.launch {
            var previous: Pair<Set<String>, Set<String>>? = null
            combine(hidden.filterNotNull(), app.repository.vault.state.map { it.folders }) { ids, folders -> ids to folders }
                .distinctUntilChanged().collect { privacy ->
                    if (previous != null && previous != privacy) privacyChanged()
                    previous = privacy
                }
        }
        // Лента не кончается и под музыкой: когда в очереди из ленты остаётся пять треков, дописываем
        // следующие. Ключ — (позиция, размер): каждая смена трека, пока дописать не удалось, даёт новую попытку.
        viewModelScope.launch {
            app.playerController.state
                .map { st ->
                    val low = st.connected && HomeFeedStreamPolicy.queueNeedsMore(
                        st.queueSourceId, st.shuffle, st.queueIds.size, st.currentIndex, feedQueueNext)
                    if (low) st.currentIndex to st.queueIds.size else null
                }
                .distinctUntilChanged()
                .collect { key -> if (key != null) extendFeedQueue() }
        }
    }
    /** No automatic modal: the one-time invitation is owned by HomeScreen. */
    internal fun openTaste() {
        if (_taste.value.open) return
        cancelTasteLookups()
        val epoch = ++tasteEpoch
        resetTasteSession()
        _taste.value = HomeTasteState(open = true, loading = true, catalogLoading = true)
        tasteJob = viewModelScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) { recoVault.state() }
                if (epoch != tasteEpoch) return@launch
                // 6.84.6: каждый вход начинается с ЧИСТОГО выбора. Раньше сюда подставлялись сохранённые
                // исполнители (на скриншоте «Выбрано 22» сразу после открытия). Сохранённый профиль в
                // хранилище не трогается: он заменяется только подтверждением «Готово» с новым выбором.
                val picks = emptyList<RecoArtist>()
                val metadata = (tasteCatalogCache + picks).associateBy { it.id }
                tasteBaseArtists = HomeTastePolicy.recommendationPage(tasteCatalogCache.map { it.id },
                    picks.map { it.id }, emptyList(), emptyList()).mapNotNull(metadata::get)
                _taste.value = _taste.value.copy(picks = picks, allowTrackHints = saved.allowTrackHints)
                rebuildTasteDeck()
                if (tasteCatalogCache.isNotEmpty()) {
                    _taste.update { it.copy(catalogLoading = false, loading = if (it.searchOpen) it.loading else false) }
                    launchTasteReserve()
                } else loadTasteCatalog(epoch)
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == tasteEpoch) _taste.update {
                it.copy(loading = false, catalogLoading = false, error = "Каталог недоступен. Поиск и повтор доступны ниже.")
            } }
        }
    }

    /** Всё, что накопила одна сессия выбора. Следующее открытие не должно наследовать ни выбор,
     * ни «похожих» на прошлые выбранные, ни показанные страницы. Общий каталог (tasteCatalogCache) остаётся. */
    private fun resetTasteSession() {
        tasteMoreJob?.cancel(); tasteMoreJob = null
        tasteReserveJob?.cancel(); tasteReserveJob = null
        tasteBaseArtists = emptyList()
        tasteRelatedBatches.clear(); tasteRelatedCache.clear(); tasteSeenArtists.clear()
        tasteExpansion.clear(); tasteExpandedAnchors.clear()
    }

    private fun validTasteArtists(rows: List<RecoArtist>): List<RecoArtist> = rows.mapNotNull { artist ->
        HomeTastePolicy.artistId(artist.id)?.takeIf { HomeRecoPolicy.isRealArtist(artist.name) }
            ?.let { artist.copy(id = it, name = artist.name.take(180)) }
    }.distinctBy { it.id }

    private fun cancelTasteLookups() {
        tasteJob?.cancel(); tasteSearchJob?.cancel(); tasteMoreJob?.cancel(); tasteReserveJob?.cancel(); tasteSearchEpoch++
        tasteRelatedTokens.clear()
        tasteRelatedJobs.values.toList().forEach { it.cancel() }
        tasteRelatedJobs.clear()
    }

    private suspend fun loadTasteCatalog(epoch: Int) {
        try {
            val artists = validTasteArtists(withTimeoutOrNull(HomeFeedRefreshPolicy.REQUEST_TIMEOUT_MS) {
                RemoteRuntime.registry.byId("dz")?.onboardArtists()
            }.orEmpty())
            if (epoch != tasteEpoch || !_taste.value.open) return
            if (artists.isNotEmpty()) tasteCatalogCache = artists.take(72)
            if (artists.isNotEmpty()) {
                val picks = _taste.value.picks
                val metadata = (artists + tasteBaseArtists + picks).associateBy { it.id }
                tasteBaseArtists = HomeTastePolicy.recommendationPage(
                    (tasteBaseArtists + artists).map { it.id }, picks.map { it.id },
                    emptyList(), emptyList()).mapNotNull(metadata::get)
            }
            rebuildTasteDeck()
            val problem = if (artists.isEmpty()) "Список пока недоступен. Найди исполнителя через поиск или повтори загрузку." else null
            _taste.update { it.copy(catalogLoading = false, catalogError = problem,
                loading = if (it.searchOpen) it.loading else false, error = if (it.searchOpen) it.error else problem) }
            launchTasteReserve()
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { if (epoch == tasteEpoch) _taste.update {
            it.copy(catalogLoading = false, catalogError = "Не удалось загрузить исполнителей. Проверь соединение и попробуй ещё раз.",
                loading = if (it.searchOpen) it.loading else false,
                error = if (it.searchOpen) it.error else "Не удалось загрузить исполнителей. Проверь соединение и попробуй ещё раз.")
        } }
    }

    internal fun retryTasteArtists() {
        val current = _taste.value
        if (!current.open || current.saving) return
        if (current.searchOpen) { searchTaste(current.query); return }
        tasteJob?.cancel()
        _taste.update { it.copy(loading = true, catalogLoading = true, error = null, moreError = null) }
        val epoch = tasteEpoch
        tasteJob = viewModelScope.launch { loadTasteCatalog(epoch) }
    }

    /** Related batches replay in tap order, not HTTP completion order. Search never replaces this deck. */
    private fun rebuildTasteDeck() {
        val current = _taste.value
        val metadata = (tasteBaseArtists + tasteRelatedBatches.values.flatten() + current.picks).associateBy { it.id }
        val pickedIds = current.picks.map { it.id }
        var base = HomeTastePolicy.trimDeck(tasteBaseArtists.map { it.id }, pickedIds, HomeTastePolicy.DECK_LIMIT)
        fun replay(start: List<String>): List<String> = HomeTastePolicy.replayRelatedRows(start,
            tasteRelatedBatches.mapValues { (_, artists) -> artists.map { it.id } },
            pickedIds, HomeTastePolicy.DECK_LIMIT, current.columns)
        var ids = replay(base)
        val missing = pickedIds.filterNot { it in ids }
        if (missing.isNotEmpty()) {
            base = HomeTastePolicy.trimDeck(base + missing, pickedIds, HomeTastePolicy.DECK_LIMIT)
            ids = replay(base)
        }
        tasteBaseArtists = base.mapNotNull(metadata::get)
        val artists = ids.mapNotNull(metadata::get)
        _taste.value = current.copy(browseArtists = artists, artists = if (current.searchOpen) current.artists else artists)
    }

    internal fun openTasteSearch(open: Boolean) {
        val current = _taste.value
        if (!current.open || current.saving) return
        tasteSearchJob?.cancel(); tasteSearchEpoch++; tasteSearchNext = null
        _taste.value = current.copy(searchOpen = open, query = "", loading = !open && current.catalogLoading, loadingMore = false,
            hasMore = false, error = if (open) null else current.catalogError, artists = if (open) emptyList() else current.browseArtists)
    }

    internal fun searchTaste(query: String) {
        val current = _taste.value
        if (!current.open || current.saving) return
        tasteSearchJob?.cancel(); tasteSearchNext = null
        val epoch = ++tasteSearchEpoch
        val session = tasteEpoch
        val display = query.filter { it >= ' ' }.take(120)
        val clean = display.trim()
        _taste.value = current.copy(searchOpen = true, query = display, artists = emptyList(),
            loading = clean.isNotEmpty(), loadingMore = false, hasMore = false, error = null)
        if (clean.isEmpty()) return
        tasteSearchJob = viewModelScope.launch {
            try {
                delay(HomeTastePolicy.SEARCH_DEBOUNCE_MS)
                val page = withTimeoutOrNull(HomeFeedRefreshPolicy.REQUEST_TIMEOUT_MS) {
                    RemoteRuntime.registry.byId("dz")?.search(clean, RemoteKind.ARTIST, null)
                }
                if (session != tasteEpoch || epoch != tasteSearchEpoch || !_taste.value.searchOpen) return@launch
                if (page == null) {
                    _taste.update { it.copy(loading = false, error = "Поиск не ответил. Проверь соединение и повтори.") }
                    return@launch
                }
                val artists = tasteSearchArtists(page.items)
                tasteSearchNext = page.nextToken
                _taste.update { it.copy(loading = false, artists = artists, hasMore = !page.nextToken.isNullOrBlank(),
                    error = if (artists.isEmpty()) "Ничего не найдено. Попробуй другое имя." else null) }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (session == tasteEpoch && epoch == tasteSearchEpoch) _taste.update {
                it.copy(loading = false, error = "Не удалось выполнить поиск. Попробуй ещё раз.")
            } }
        }
    }

    private fun tasteSearchArtists(items: List<RemoteItem>): List<RecoArtist> = validTasteArtists(items
        .filterIsInstance<RemoteItem.Group>().map { it.collection }.filter { it.kind == RemoteKind.ARTIST }
        .mapNotNull { artist -> DeezerArtistRef.parse(artist.provider, artist.remoteId)?.let { artistId ->
            RecoArtist(artistId, artist.title, artist.artworkUrl)
        } })

    internal fun moreTasteSearch() {
        val current = _taste.value
        val token = tasteSearchNext ?: return
        if (!current.searchOpen || current.saving || current.loading || current.loadingMore ||
            current.artists.size >= HomeTastePolicy.SEARCH_LIMIT) return
        val epoch = tasteSearchEpoch; val session = tasteEpoch
        val query = current.query.trim()
        _taste.value = current.copy(loadingMore = true, error = null)
        tasteSearchJob = viewModelScope.launch {
            try {
                val page = withTimeoutOrNull(HomeFeedRefreshPolicy.REQUEST_TIMEOUT_MS) {
                    RemoteRuntime.registry.byId("dz")?.search(query, RemoteKind.ARTIST, token)
                }
                if (epoch != tasteSearchEpoch || session != tasteEpoch || !_taste.value.searchOpen) return@launch
                if (page == null) {
                    _taste.update { it.copy(loadingMore = false, error = "Не удалось загрузить следующую страницу.") }
                    return@launch
                }
                val added = tasteSearchArtists(page.items)
                val merged = (_taste.value.artists + added).distinctBy { it.id }.take(HomeTastePolicy.SEARCH_LIMIT)
                tasteSearchNext = page.nextToken?.takeIf { it.isNotBlank() && it != token &&
                    merged.size < HomeTastePolicy.SEARCH_LIMIT && merged.size > _taste.value.artists.size }
                _taste.update { it.copy(loadingMore = false, artists = merged, hasMore = tasteSearchNext != null) }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == tasteSearchEpoch && session == tasteEpoch) _taste.update {
                it.copy(loadingMore = false, error = "Не удалось загрузить следующую страницу.")
            } }
        }
    }

    internal fun toggleTaste(raw: RecoArtist) {
        val current = _taste.value
        if (!current.open || current.saving) return
        val artist = validTasteArtists(listOf(raw)).firstOrNull() ?: return
        val selected = current.picks.any { it.id == artist.id }
        if (!selected && current.picks.size >= HomeTastePolicy.MAX_PICKS) {
            _taste.update { it.copy(error = "Можно выбрать до ${HomeTastePolicy.MAX_PICKS} исполнителей.") }; return
        }
        val picks = if (selected) current.picks.filterNot { it.id == artist.id } else current.picks + artist
        // Like the reference: choosing a search hit returns to the deck and reveals that exact artist.
        if (current.searchOpen && !selected) {
            tasteSearchJob?.cancel(); tasteSearchEpoch++; tasteSearchNext = null
            tasteBaseArtists = (listOf(artist) + tasteBaseArtists).distinctBy { it.id }
            _taste.value = current.copy(picks = picks, searchOpen = false, query = "", error = null,
                loading = current.catalogLoading, loadingMore = false, hasMore = false,
                revealId = artist.id, revealRevision = current.revealRevision + 1L)
        } else _taste.value = current.copy(picks = picks, error = null)
        if (selected) {
            tasteRelatedTokens.remove(artist.id); tasteRelatedJobs.remove(artist.id)?.cancel()
            _taste.update { it.copy(relatedLoading = it.relatedLoading - artist.id, relatedErrors = it.relatedErrors - artist.id) }
            rebuildTasteDeck(); return
        }
        requestTasteRelated(artist)
    }

    internal fun retryTasteRelated(id: String) {
        val current = _taste.value
        if (!current.open || current.saving) return
        current.picks.firstOrNull { it.id == id }?.let { requestTasteRelated(it, force = true) }
    }

    private fun requestTasteRelated(artist: RecoArtist, force: Boolean = false) {
        // Empty slots record tap order before a response exists. Cached expansion does not re-request.
        if (tasteRelatedBatches.size >= HomeTastePolicy.GROUP_LIMIT && artist.id !in tasteRelatedBatches) {
            // An unusually long session freezes the current bounded deck, keeping every selected cell.
            tasteBaseArtists = _taste.value.browseArtists
            val pending = tasteRelatedBatches.keys.filter { tasteRelatedJobs[it]?.isActive == true }
            tasteRelatedBatches.clear()
            pending.forEach { tasteRelatedBatches[it] = emptyList() }
        }
        tasteRelatedBatches.putIfAbsent(artist.id, emptyList())
        rebuildTasteDeck()
        val cached = if (force) null else tasteRelatedCache[artist.id]
        if (cached != null) {
            tasteRelatedBatches[artist.id] = cached
            _taste.update { it.copy(relatedErrors = it.relatedErrors - artist.id) }
            rebuildTasteDeck(); return
        }
        if (tasteRelatedJobs[artist.id]?.isActive == true) return
        val session = tasteEpoch; val token = ++tasteRelatedSerial
        tasteRelatedTokens[artist.id] = token
        _taste.update { it.copy(relatedLoading = it.relatedLoading + artist.id, relatedErrors = it.relatedErrors - artist.id) }
        tasteRelatedJobs[artist.id] = viewModelScope.launch {
            try {
                // 6.84.7: тихие повторы. Один холодный ответ или обрыв сети не должен сразу превращаться в значок
                // «повторить»: сервер достраивает граф в кэше, и вторая попытка обычно получает готовый ответ.
                var related: List<RecoArtist>? = null
                for (attempt in 0 until HomeTastePolicy.RELATED_ATTEMPTS) {
                    try {
                        related = tasteRelatedGate.withPermit {
                            validTasteArtists(withTimeoutOrNull(HomeTastePolicy.RELATED_TIMEOUT_MS) {
                                RemoteRuntime.registry.byId("dz")?.onboardArtists(artist.id)
                            } ?: throw IllegalStateException("related lookup timed out or provider unavailable"))
                                .filterNot { it.id == artist.id }.take(HomeTastePolicy.RELATED_POOL_LIMIT)
                        }
                        break
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) {
                        if (attempt + 1 < HomeTastePolicy.RELATED_ATTEMPTS) delay(HomeTastePolicy.relatedRetryDelayMs(attempt))
                    }
                }
                if (session != tasteEpoch || tasteRelatedTokens[artist.id] != token || !_taste.value.open ||
                    _taste.value.picks.none { it.id == artist.id }) return@launch
                if (related == null) {
                    _taste.update {
                        it.copy(relatedErrors = it.relatedErrors +
                            (artist.id to "Не удалось загрузить похожих на «${artist.name}». Выбор сохранён."))
                    }
                    return@launch
                }
                if (related.isNotEmpty()) tasteRelatedCache[artist.id] = related else tasteRelatedCache.remove(artist.id)
                while (tasteRelatedCache.size > 48) tasteRelatedCache.remove(tasteRelatedCache.keys.first())
                tasteRelatedBatches[artist.id] = related
                rebuildTasteDeck()
                if (related.isEmpty()) _taste.update { it.copy(relatedErrors = it.relatedErrors +
                    (artist.id to "Для «${artist.name}» каталог пока не вернул похожих исполнителей.")) }
                launchTasteReserve()
            } catch (e: CancellationException) { throw e }
            finally {
                if (session == tasteEpoch && tasteRelatedTokens[artist.id] == token) {
                    tasteRelatedJobs.remove(artist.id); tasteRelatedTokens.remove(artist.id)
                    _taste.update { it.copy(relatedLoading = it.relatedLoading - artist.id) }
                }
            }
        }
    }

    /** 6.84.7. «Другие рекомендации» ДОБАВЛЯЕТ по 6 карточек в конец сетки (как в референсе). Ничего не подменяется и
     * не прокручивается наверх: выбранные, их «похожие» и позиция прокрутки остаются на месте, новые карточки
     * появляются там, где только что стояла плитка. Кандидаты лежат в запасе (см. [launchTasteReserve]): фон
     * заранее спрашивает соседей показанных артистов, поэтому нажатие обычно мгновенное. Если запас пуст, плитка
     * показывает кольцо, пока граф отвечает (до [HomeTastePolicy.EXPAND_ROUNDS] раундов с паузами).
     * Показанные карточки не возвращаются. Не сохраняет профиль и не завершает настройку. */
    internal fun moreTasteRecommendations() {
        val current = _taste.value
        if (!current.open || current.saving || current.searchOpen || current.catalogLoading || current.moreLoading) return
        if (tasteCandidatePool().isEmpty()) { retryTasteArtists(); return }
        tasteSeenArtists.addAll(current.browseArtists.map { it.id })
        // Bounded session memory; shown cards stay in the grid, selection stays in state.
        while (tasteSeenArtists.size > 512) tasteSeenArtists.remove(tasteSeenArtists.first())
        if (HomeTastePolicy.appendPageSize(current.browseArtists.size, current.columns, Int.MAX_VALUE) <= 0) {
            _taste.update { it.copy(moreError = "Список уже длинный. Найди нужного исполнителя через поиск.") }
            return
        }
        if (tasteFreshCandidates().isNotEmpty()) { appendTastePage(); return }
        val epoch = tasteEpoch
        _taste.update { it.copy(moreLoading = true, moreError = null) }
        tasteMoreJob?.cancel()
        // Один исполнитель запросов: фоновый добор уступает дорогу нажатию.
        tasteReserveJob?.cancel()
        tasteMoreJob = viewModelScope.launch {
            try {
                var answered = 0
                var noAnchors = false
                var round = 0
                while (tasteFreshCandidates().isEmpty() && round < HomeTastePolicy.EXPAND_ROUNDS) {
                    round++
                    val got = expandTastePool(epoch)
                    if (epoch != tasteEpoch || !_taste.value.open) return@launch
                    if (got < 0) { noAnchors = true; break }
                    answered += got
                    if (got == 0 && round < HomeTastePolicy.EXPAND_ROUNDS) delay(HomeTastePolicy.expandRetryDelayMs(round))
                }
                if (tasteFreshCandidates().isNotEmpty()) appendTastePage()
                else if (answered > 0 || noAnchors) _taste.update { it.copy(
                    moreError = "Новых исполнителей пока нет. Найди нужного через поиск.") }
                else _taste.update { it.copy(
                    moreError = "Не удалось загрузить исполнителей. Нажми «Другие рекомендации» ещё раз.") }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == tasteEpoch) _taste.update { it.copy(
                moreError = "Не удалось загрузить исполнителей. Нажми «Другие рекомендации» ещё раз.") } }
            finally { if (epoch == tasteEpoch) _taste.update { it.copy(moreLoading = false) } }
        }
    }

    /** Фоновая подкачка запаса: пока свежих кандидатов меньше [HomeTastePolicy.RESERVE_MIN], спрашиваем соседей
     * показанных артистов, пока не наберётся [HomeTastePolicy.RESERVE_TARGET]. Без индикаторов; сбой молча
     * ждёт паузу и повторяется, раундов не больше [HomeTastePolicy.EXPAND_ROUNDS]. Сбрасывается вместе с сессией. */
    private fun launchTasteReserve(afterAppend: Boolean = false) {
        val current = _taste.value
        if (!current.open || current.saving || tasteReserveJob?.isActive == true) return
        // Пока нажатие само ждёт граф, фон его не дублирует; сразу после добавления страницы можно.
        if (!afterAppend && tasteMoreJob?.isActive == true) return
        if (!HomeTastePolicy.needsReserve(tasteFreshCandidates().size, current.browseArtists.size)) return
        val epoch = tasteEpoch
        tasteReserveJob = viewModelScope.launch {
            try {
                var round = 0
                while (round < HomeTastePolicy.EXPAND_ROUNDS && epoch == tasteEpoch && _taste.value.open &&
                    tasteFreshCandidates().size < HomeTastePolicy.RESERVE_TARGET) {
                    round++
                    val got = expandTastePool(epoch)
                    if (got < 0) break
                    if (got == 0) delay(HomeTastePolicy.expandRetryDelayMs(round))
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { /* запас необязателен: нажатие само спросит граф */ }
        }
    }

    /** Порядок: «похожие» на выбранных (самые близкие к вкусу), общий каталог, затем соседи показанных. */
    private fun tasteCandidatePool(): List<RecoArtist> = validTasteArtists(
        tasteRelatedCache.values.flatten() + tasteCatalogCache + tasteExpansion.values.flatten())

    private fun tasteFreshCandidates(): List<RecoArtist> {
        val current = _taste.value
        val pool = tasteCandidatePool()
        val byId = pool.associateBy { it.id }
        return HomeTastePolicy.freshCandidates(pool.map { it.id }, current.picks.map { it.id },
            tasteSeenArtists, current.browseArtists.map { it.id }).mapNotNull(byId::get)
    }

    private fun appendTastePage() {
        val current = _taste.value
        val fresh = tasteFreshCandidates()
        val count = HomeTastePolicy.appendPageSize(current.browseArtists.size, current.columns, fresh.size)
        if (count <= 0) {
            _taste.update { it.copy(moreError = "Новых исполнителей пока нет. Найди нужного через поиск.") }
            return
        }
        val page = fresh.take(count)
        tasteSeenArtists.addAll(page.map { it.id })
        tasteBaseArtists = (tasteBaseArtists + page).distinctBy { it.id }
        _taste.value = current.copy(error = null, moreError = null, revealId = null,
            appendRevision = current.appendRevision + 1L)
        rebuildTasteDeck()
        launchTasteReserve(afterAppend = true)
    }

    /** Спрашивает соседей у последних показанных артистов. Возвращает, сколько запросов получили ответ
     * (пустой ответ тоже ответ), 0 — ни один не ответил, -1 — спрашивать больше не у кого. Упавшие запросы не
     * помечаются спрошенными и повторятся. */
    private suspend fun expandTastePool(epoch: Int): Int {
        val current = _taste.value
        val anchors = HomeTastePolicy.expansionAnchors(current.browseArtists.map { it.id },
            tasteExpandedAnchors + tasteRelatedCache.keys, HomeTastePolicy.EXPAND_ANCHORS)
        if (anchors.isEmpty()) return -1
        val answers = coroutineScope {
            anchors.map { id ->
                async<Pair<String, List<RecoArtist>?>> {
                    try {
                        val rows = tasteRelatedGate.withPermit {
                            withTimeoutOrNull(HomeTastePolicy.EXPANSION_TIMEOUT_MS) {
                                RemoteRuntime.registry.byId("dz")?.onboardArtists(id)
                            }
                        }
                        id to rows?.let { list -> validTasteArtists(list).filterNot { it.id == id }
                            .take(HomeTastePolicy.RELATED_POOL_LIMIT) }
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) { id to null }
                }
            }.awaitAll()
        }
        if (epoch != tasteEpoch || !_taste.value.open) return 0
        var answered = 0
        for ((id, rows) in answers) {
            if (rows == null) continue
            answered++
            tasteExpandedAnchors.add(id)
            if (rows.isNotEmpty()) tasteExpansion[id] = rows
        }
        while (tasteExpansion.size > HomeTastePolicy.EXPANSION_CACHE_LIMIT) tasteExpansion.remove(tasteExpansion.keys.first())
        return answered
    }

    internal fun setTasteColumns(columns: Int) {
        val value = columns.coerceIn(1, 3)
        if (_taste.value.columns == value) return
        _taste.update { it.copy(columns = value) }
        rebuildTasteDeck()
    }

    internal fun setTasteHints(allow: Boolean) { if (!_taste.value.saving) _taste.update { it.copy(allowTrackHints = allow) } }

    internal fun saveTaste() {
        val current = _taste.value
        val picks = validTasteArtists(current.picks)
        val key = HomeTastePolicy.selectionKey(picks.map { it.id })
        if (key.isEmpty() || current.saving || !current.open) return
        cancelTasteLookups(); tasteSaveJob?.cancel()
        val epoch = ++tasteEpoch
        _taste.value = current.copy(picks = picks, phase = HomeTastePhase.INTRO, loading = false, catalogLoading = false,
            loadingMore = false, hasMore = false, searchOpen = false, error = null, relatedLoading = emptySet(), buildPartial = false,
            moreLoading = false, moreError = null)
        tasteSaveJob = viewModelScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) {
                    val updated = recoVault.savePicks(picks.map { RecoVault.Pick(it.id, it.name, it.art) }, current.allowTrackHints)
                    recoVault.dropHome(); updated
                }
                recommendations.clear(); feedQueueNext = -1
                recommendations.beginTaste(key, saved.picks, saved.onboardingCompleted)
                val snapshot = withTimeoutOrNull(5_000L) { state.first { !it.loading &&
                    hidden.value != null && it.hiddenIds == hidden.value && it.vaultFolders == app.repository.vault.state.value.folders } }
                if (snapshot == null) {
                    if (epoch == tasteEpoch) _taste.update { it.copy(phase = HomeTastePhase.FAILED,
                        error = "Медиатека ещё загружается. Выбор сохранён — попробуй продолжить через несколько секунд.") }
                    return@launch
                }
                recommendations.load(snapshot, force = true, gapMs = 0L)
                delay(HomeTastePolicy.INTRO_MS)
                if (epoch != tasteEpoch || !_taste.value.open) return@launch
                _taste.update { it.copy(phase = HomeTastePhase.BUILDING) }
                val buildingAt = android.os.SystemClock.elapsedRealtime()
                val delivered = withTimeoutOrNull(HomeTastePolicy.BUILD_TIMEOUT_MS) {
                    recommendations.tasteDelivery.onEach { result ->
                        if (epoch == tasteEpoch && result.key == key) _taste.update { it.copy(buildPartial = result.partial) }
                    }.first { it.key == key && (it.ready || it.error != null) }
                }
                if (epoch != tasteEpoch || !_taste.value.open) return@launch
                if (delivered?.ready == true) {
                    val remaining = (HomeTastePolicy.BUILDING_MIN_MS - (android.os.SystemClock.elapsedRealtime() - buildingAt)).coerceAtLeast(0L)
                    if (remaining > 0L) delay(remaining)
                    if (epoch != tasteEpoch || !_taste.value.open) return@launch
                    _taste.update { it.copy(phase = HomeTastePhase.READY, error = null) }
                    delay(HomeTastePolicy.READY_HOLD_MS)
                    if (epoch == tasteEpoch) { resetTasteSession(); _taste.value = HomeTasteState() }
                } else _taste.update { it.copy(phase = HomeTastePhase.FAILED, error = delivered?.error ?:
                    "Не удалось получить музыку для всех выбранных исполнителей. Выбор сохранён. Повтори попытку или выйди кнопкой «Назад».") }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == tasteEpoch) _taste.update { it.copy(phase = HomeTastePhase.FAILED,
                error = "Не удалось сохранить выбор на устройстве. Попробуй ещё раз.") } }
        }
    }

    internal fun editTaste() {
        if (!_taste.value.open || _taste.value.saving) return
        _taste.update { it.copy(phase = HomeTastePhase.PICKING, error = null, searchOpen = false, query = "",
            artists = it.browseArtists, buildPartial = false, moreLoading = false, moreError = null) }
        launchTasteReserve()
    }

    internal fun closeTaste() {
        // Closing is not completion. A confirmed request may finish behind the Home invitation.
        ++tasteEpoch; cancelTasteLookups()
        resetTasteSession()
        _taste.value = HomeTasteState()
    }
    internal fun dislike(track: TrackEntity, artist: Boolean = false) = viewModelScope.launch {
        if (!permitted(track)) return@launch
        try {
        withContext(Dispatchers.IO) {
            if (artist) {
                val name = HomeRecoPolicy.cleanArtist(HomeRecoPolicy.splitArtists(track.artist).firstOrNull() ?: track.artist)
                if (name.isNotBlank()) {
                    val identity = app.database.listeningDao().catalogIdentities(listOf(track.id)).firstOrNull { it.provider == "dz" }?.artistId
                        ?: recoVault.state().ids[HomeFeedPolicy.normalize(name)]
                    recoVault.dislikeArtist(identity, name)
                }
            } else {
                recoVault.dislikeTrack(track.id)
                recoVault.dislikeTrack("song:" + HomeRecoPolicy.songKey(track.artist, track.title))
            }
            recoVault.dropHome()
        }
        recommendations.clear(); feedQueueNext = -1
        _message.value = if (artist) "Исполнитель исключён из рекомендаций" else "Трек исключён из рекомендаций"
        refreshFeed(force = true)
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось сохранить оценку" }
    }

    fun entered() { refresh.value += 1 }
    fun openHistory() { _historyOpen.value = true }
    internal fun openCollection(kind: HomeCollectionKind, offlineOnly: Boolean = false) {
        val tracks = when (kind) {
            HomeCollectionKind.WAVE -> recommendations.state.value.wave.ifEmpty { state.value.offline }
            HomeCollectionKind.RECENT_ADDED -> state.value.recentAdded
            HomeCollectionKind.DISCOVERY -> emptyList()
        }
        // Stable ordering while open. Later changes can remove forbidden/deleted
        // IDs but never reorder a list under the user's finger.
        val visible = tracks.filter { !offlineOnly || it.id in state.value.availableOfflineIds }
        _collection.value = HomeCollection(kind, visible.map { it.id }, offlineOnly = offlineOnly)
    }
    internal fun refreshFeed(force: Boolean = false) { recommendations.load(state.value, force) }
    /** Лента «Для тебя»: прокрутка дошла до порога. Лишние вызовы безвредны. */
    internal fun loadMoreFeed() = recommendations.feed.loadMore()
    internal fun retryFeed() = recommendations.feed.retry()

    /**
     * Тап по строке ленты: очередь — от этого трека вперёд, не длиннее 200 (useTracks берёт максимум 200,
     * и без окна трек №450 терялся, а воспроизведение не начиналось). Лента — радио, назад не играет.
     */
    internal fun playFeed(index: Int, play: (TrackEntity, List<TrackEntity>, String) -> Unit) {
        val tracks = recommendations.feed.state.value.tracks
        val window = HomeFeedStreamPolicy.queueWindow(index, tracks.size)
        if (window[1] <= window[0]) return
        val tapped = tracks[index]
        val slice = tracks.subList(window[0], window[1]).toList()
        val epoch = recommendations.feed.epoch
        useTracks(slice) { ready ->
            val start = ready.firstOrNull { it.id == tapped.id }
            if (start != null) {
                play(start, ready, HomeFeedStreamPolicy.SOURCE_ID)
                feedQueueNext = window[1]; feedQueueEpoch = epoch
            }
        }
    }

    private fun extendFeedQueue() {
        if (extendingQueue || feedQueueNext < 0) return
        val feed = recommendations.feed
        if (feed.epoch != feedQueueEpoch) { feedQueueNext = -1; return }
        val from = feedQueueNext
        extendingQueue = true
        viewModelScope.launch {
            try {
                val batch = feed.takeForQueue(from, HomeFeedStreamPolicy.QUEUE_BATCH)
                // Пока ждали сеть, человек мог включить другое или сбросить ленту: тогда добавлять нельзя.
                val st = app.playerController.state.value
                if (batch.isEmpty() || feedQueueNext != from || feed.epoch != feedQueueEpoch ||
                    st.queueSourceId != HomeFeedStreamPolicy.SOURCE_ID || st.shuffle) return@launch
                val allowed = batch.filter(::permitted)
                music.rememberRemote(allowed.filter { it.isRemote })
                feedQueueNext = from + batch.size
                allowed.filter(::permitted).forEach { app.playerController.enqueue(it, false) }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { /* тихо: следующая смена трека попробует снова */ }
            finally { extendingQueue = false }
        }
    }
    internal fun leaveHome() {
        _tasteInviteSuppressed.value = false // This visit only; encrypted completion is never changed here.
        recommendations.cancel(keepRecoRequest = true); collectionEpoch++; collectionJob?.cancel()
        if (_collectionBusy.value && remoteCollection != null) _collectionError.value = "Загрузка приостановлена. Нажми «Повторить»"
        _collectionBusy.value = false
    }
    internal fun privacyChanged() {
        recommendations.clear(); feedQueueNext = -1; collectionEpoch++; collectionJob?.cancel(); remoteCollection = null
        _catalogTracks.value = emptyList(); _collection.value = null; _collectionBusy.value = false
        _hasMore.value = false; _collectionError.value = null
    }
    private fun permitted(track: TrackEntity): Boolean = hidden.value != null && track.id !in hidden.value.orEmpty() &&
        (if (track.provider == "mix") "r:${track.remoteId}" else track.id) !in hidden.value.orEmpty().map { if (it.startsWith("r:mix:")) "r:" + it.removePrefix("r:mix:") else it } &&
        (if (track.isRemote) CatalogPolicy.supports(track.provider, track.remoteId)
         else track.sourceFolder !in app.repository.vault.state.value.folders)

    /** Persist only after an explicit user action, never just because a tile was visible. */
    internal fun useTracks(tracks: List<TrackEntity>, action: (List<TrackEntity>) -> Unit) = viewModelScope.launch {
        try {
            val allowed = tracks.filter(::permitted).distinctBy { it.id }.take(200)
            music.rememberRemote(allowed.filter { it.isRemote })
            val current = allowed.filter(::permitted)
            if (current.isNotEmpty()) action(current)
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось открыть треки" }
    }
    internal fun openFeed(card: HomeFeedCard) {
        recommendations.cancel()
        collectionEpoch++; collectionJob?.cancel(); _catalogTracks.value = emptyList(); _collectionError.value = null
        nextPage = null; _hasMore.value = false; remoteCollection = card.remote
        _collection.value = HomeCollection(HomeCollectionKind.DISCOVERY, card.tracks.map { it.id },
            card.title, "home:feed:${card.id}")
        _catalogTracks.value = card.tracks.filter(::permitted)
        if (card.remote != null) loadCollectionPage()
    }
    internal fun loadCollectionPage() {
        val group = remoteCollection ?: return
        val selected = _collection.value ?: return
        if (collectionJob?.isActive == true || _catalogTracks.value.size >= 200) return
        _collectionBusy.value = true; _collectionError.value = null
        val epoch = ++collectionEpoch
        collectionJob = viewModelScope.launch {
            try {
                val page = withTimeoutOrNull(12_000L) {
                    RemoteRuntime.registry.byId(group.provider)?.collectionPage(group, nextPage)
                }
                if (epoch != collectionEpoch || _collection.value?.sourceId != selected.sourceId) return@launch
                if (page == null) { _collectionError.value = "Каталог не успел ответить. Повтори загрузку"; return@launch }
                val tracks = (_catalogTracks.value + page.tracks.map { it.toEntity() })
                    .filter(::permitted).distinctBy { it.id }.take(200)
                _catalogTracks.value = tracks
                _collection.value = selected.copy(trackIds = tracks.map { it.id })
                val previous = nextPage
                nextPage = page.nextToken?.takeIf { it != previous }
                _hasMore.value = nextPage != null && tracks.size < 200
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (epoch == collectionEpoch) _collectionError.value = "Не удалось загрузить подборку. Попробуй ещё раз" }
            finally { if (epoch == collectionEpoch) _collectionBusy.value = false }
        }
    }
    fun back(): Boolean {
        if (_collection.value != null) {
            collectionEpoch++; collectionJob?.cancel(); remoteCollection = null; _collectionBusy.value = false
            _collection.value = null; _catalogTracks.value = emptyList(); return true
        }
        if (!_historyOpen.value) return false
        _historyOpen.value = false
        return true
    }
    fun dismissMessage() { _message.value = null }
    fun setPinned(id: Long, pinned: Boolean) = viewModelScope.launch {
        try {
            if (state.value.playlists.none { it.playlist.id == id }) return@launch
            if (!dao.setPinned(id, pinned, System.currentTimeMillis())) _message.value = "Можно закрепить до шести плейлистов"
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось изменить закрепления" }
    }
    fun clearHistory() = viewModelScope.launch {
        try { app.listeningStore.clearHistory(); withContext(Dispatchers.IO) { recoVault.clearAll() }; recommendations.clear(); feedQueueNext = -1; _message.value = "История очищена. Старые счётчики медиатеки сохранены" }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось очистить историю" }
    }
}
