package app.ziziplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.account.AccountGate
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.ui.screens.HomeFeedShelfHeader
import app.ziziplayer.ui.screens.HomeFeedShelfView
import app.ziziplayer.ui.screens.HomeFilterHeader
import app.ziziplayer.ui.screens.LibraryHeader
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Real Compose hit-testing and layout; executed by Android CI, not Python source checks. */
class HomeNavigation6849UiTest {
    @get:Rule val compose = createComposeRule()
    private val profile = AccountProfile()
    private fun shelf() = HomeFeedShelf("similar:42", "Похоже на", "", HomeShelfLayout.COVERS,
        emptyList(), anchorName = "Andromeda", anchorId = "42")

    @Test fun homeAndLibraryHaveIdenticalHeaderAndRailBounds() {
        val width = mutableStateOf(320.dp)
        val font = mutableStateOf(1f)
        val account = mutableStateOf(AccountLocalState())
        var density = 1f
        compose.setContent {
            val physical = LocalDensity.current.density
            density = physical
            CompositionLocalProvider(LocalDensity provides Density(physical, font.value)) {
                NeutralSurfaceTheme {
                    Column(Modifier.width(width.value)) {
                        HomeFilterHeader(account.value, profile, 0, {}, {})
                        LibraryHeader(LibraryUiState(), null, account.value, profile, {}, {}, {}, {})
                    }
                }
            }
        }
        for (w in listOf(320.dp, 393.dp)) for (scale in listOf(1f, 1.8f, 2.5f)) {
            compose.runOnIdle { width.value = w; font.value = scale }
            for (a in listOf(AccountLocalState(), AccountLocalState(mode = AccountGate.Mode.SIGNED_IN, userId = "test"))) {
                compose.runOnIdle { account.value = a }
                val home = compose.onNodeWithTag("home-root-header").fetchSemanticsNode().boundsInRoot
                val lib = compose.onNodeWithTag("library-root-header").fetchSemanticsNode().boundsInRoot
                val homeRail = compose.onNodeWithTag("home-filter-rail").fetchSemanticsNode().boundsInRoot
                val libRail = compose.onNodeWithTag("library-filter-rail").fetchSemanticsNode().boundsInRoot
                assertEquals(home.width, lib.width, 1.1f)
                assertEquals(home.height, lib.height, 1.1f)
                assertEquals(homeRail.top - home.top, libRail.top - lib.top, 1.1f)
                assertEquals(home.bottom - homeRail.bottom, lib.bottom - libRail.bottom, 1.1f)
                assertTrue(homeRail.top - home.top >= 7f * density - 1.1f)
                assertTrue(home.bottom - homeRail.bottom >= 7f * density - 1.1f)
                if (scale == 1f) assertEquals(62f * density, home.height, 1.1f)
            }
        }
    }

    @Test fun homeHeaderDoesNotMoveWhenFeedScrolls() {
        compose.setContent {
            NeutralSurfaceTheme {
                Column(Modifier.fillMaxSize()) {
                    HomeFilterHeader(AccountLocalState(), profile, 0, {}, {})
                    LazyColumn(Modifier.weight(1f).testTag("test-feed")) {
                        items(60) { Text("Track $it", Modifier.fillMaxWidth().height(60.dp)) }
                    }
                }
            }
        }
        val before = compose.onNodeWithTag("home-root-header").fetchSemanticsNode().boundsInRoot
        compose.onNodeWithTag("test-feed").performScrollToIndex(40)
        assertEquals(before, compose.onNodeWithTag("home-root-header").fetchSemanticsNode().boundsInRoot)
    }

    @Test fun filtersSelectAndResetAndGuestAvatarStillOpensAccount() {
        val filter = mutableStateOf(0)
        var accountOpens = 0
        compose.setContent {
            NeutralSurfaceTheme {
                HomeFilterHeader(AccountLocalState(), profile, filter.value,
                    { filter.value = it }, { accountOpens++ })
            }
        }
        compose.onNodeWithTag("home-filter-1").performClick()
        compose.onNodeWithTag("home-filter-1").assertIsSelected()
        compose.runOnIdle { assertEquals(1, filter.value) }
        compose.onNodeWithTag("home-filter-reset").performClick()
        compose.onNodeWithTag("home-filter-0").assertIsSelected()
        compose.runOnIdle { assertEquals(0, filter.value) }
        compose.onNodeWithTag("home-account-avatar").performClick()
        compose.runOnIdle { assertEquals(1, accountOpens) }
    }

    @Test fun bothHeadingTextAndPortraitOpenAnchorNotAlbum() {
        val routes = mutableListOf<ArtistRoute>()
        compose.setContent {
            NeutralSurfaceTheme { HomeFeedShelfHeader(shelf(), { routes += it }) }
        }
        compose.onNodeWithTag("home-shelf-header:similar:42").performTouchInput {
            click(Offset(10f, center.y)) // portrait hit
        }
        compose.onNodeWithText("Andromeda", useUnmergedTree = true).performTouchInput { click() }
        compose.onNodeWithText("Похоже на", useUnmergedTree = true).performTouchInput { click() }
        compose.runOnIdle {
            assertEquals(3, routes.size)
            routes.forEach { assertEquals("artist:42", (it as ArtistRoute.Catalog).collection.remoteId) }
        }
    }

    @Test fun ordinaryShelfHeadingHasNoDeadClickAction() {
        compose.setContent {
            NeutralSurfaceTheme {
                HomeFeedShelfHeader(shelf().copy(anchorName = null, anchorId = null, title = "Новая музыка"), {})
            }
        }
        compose.onNodeWithTag("home-shelf-header:similar:42")
            .assert(SemanticsMatcher.keyNotDefined(SemanticsActions.OnClick))
    }

    @Test fun albumClickRemainsSeparateFromArtistHeading() {
        val album = HomeFeedCard("dz:album:999", "Dividing Lines", "Threshold", remote = RemoteCollection(
            provider = "dz", remoteId = "album:999", kind = RemoteKind.ALBUM, title = "Dividing Lines"))
        var opened: HomeFeedCard? = null
        var artistOpens = 0
        compose.setContent {
            NeutralSurfaceTheme {
                Box(Modifier.width(320.dp).padding(horizontal = 14.dp)) {
                    HomeFeedShelfView(shelf().copy(cards = listOf(album)), { opened = it },
                        { artistOpens++ }, { _, _, _ -> }, {})
                }
            }
        }
        compose.onNodeWithText("Dividing Lines").performClick()
        compose.runOnIdle { assertEquals(album, opened); assertEquals(0, artistOpens) }
        compose.onNodeWithTag("home-shelf-header:similar:42").performClick()
        compose.runOnIdle { assertEquals(1, artistOpens); assertEquals(album, opened) }
    }
}
