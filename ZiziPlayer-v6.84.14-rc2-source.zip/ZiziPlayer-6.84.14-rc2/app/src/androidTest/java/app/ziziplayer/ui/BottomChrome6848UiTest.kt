package app.ziziplayer.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.BottomChromeLeadIn
import app.ziziplayer.ui.components.bottomChrome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import kotlin.math.roundToInt

/** Renderer/layer pixel probes on a known white backdrop, no HTTP or artwork dependency.
 * Footer wiring and measured body ownership are additionally covered by source contracts.
 * Run on Android; these are not replaced by the offline Java curve checks. */
class BottomChrome6848UiTest {
    @get:Rule val compose = createComposeRule()
    private val visible = mutableStateOf(true)
    private var density = 1f

    private fun fixture() {
        compose.setContent {
            density = LocalDensity.current.density
            Box(Modifier.size(200.dp, 240.dp).background(Color.White).testTag("chrome-window")) {
                AnimatedVisibility(visible = visible.value, modifier = Modifier.align(Alignment.BottomCenter),
                    enter = fadeIn(tween(180)), exit = fadeOut(tween(120))) {
                    Box(Modifier.padding(top = BottomChromeLeadIn)) {
                        Box(Modifier.fillMaxWidth().height(100.dp).bottomChrome().testTag("chrome-body")) {
                            // Represents an opaque control painted after the scrim.
                            Box(Modifier.align(Alignment.Center).size(40.dp).background(Color.White))
                        }
                    }
                }
            }
        }
        compose.waitForIdle()
    }

    @Test fun restingScrimTransmitsTwentyPercentAndKeepsControlsOpaque() {
        fixture()
        val image = compose.onNodeWithTag("chrome-window").captureToImage()
        val pixels = image.toPixelMap()
        assertEquals(.2f, pixels[2, image.height - 2].red, .012f)
        assertEquals(1f, pixels[image.width / 2, image.height - (50f * density).roundToInt()].red, .012f)
        // Halfway through the 48dp lead: t = 24 / (48 + 100 * .72) = .2.
        val leadY = image.height - (124f * density).roundToInt()
        assertEquals(1f - CollectionGeometry.scrimAlpha(.2f), pixels[2, leadY].red, .015f)
    }

    private fun assertLeadPresentDuringFade() {
        val image = compose.onNodeWithTag("chrome-window").captureToImage()
        val y = image.height - (124f * density).roundToInt()
        val red = image.toPixelMap()[2, y].red
        // Clipped overflow would be pure white. A single fading scrim must still be lighter
        // than its fully visible value (~.917), and not vanish at the body boundary.
        assertTrue("lead clipped or stacked: red=$red", red > .91f && red < .995f)
    }

    @Test fun enteringLeadIsNotClipped() {
        visible.value = false
        fixture()
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { visible.value = true }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(90)
        assertLeadPresentDuringFade()
        compose.mainClock.autoAdvance = true
    }

    @Test fun exitingLeadIsNotClipped() {
        fixture()
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { visible.value = false }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(60)
        assertLeadPresentDuringFade()
        compose.mainClock.autoAdvance = true
    }
}
