package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.remote.RecoArtist
import app.ziziplayer.ui.screens.HomeTasteInvite
import app.ziziplayer.ui.screens.HomeTasteSheet
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Native Compose coverage; no live HTTP and no invented server-success timer in these tests. */
class HomeTasteOnboarding6840UiTest {
    @get:Rule val compose = createComposeRule()
    private val artists = (1..6).map { RecoArtist(it.toString(), "Исполнитель $it", null) }

    @Composable
    private fun Fixture(initial: HomeTasteState, onSaved: () -> Unit = {}, onClosed: () -> Unit = {},
        onMore: () -> Unit = {}, onRetryRelated: (String) -> Unit = {}) {
        var state by remember { mutableStateOf(initial) }
        if (state.open) HomeTasteSheet(state,
            onQuery = { q -> state = state.copy(query = q, loading = false, artists = if (q.isBlank()) emptyList() else artists.takeLast(2)) },
            onToggle = { artist ->
                val picked = state.picks.any { it.id == artist.id }
                val picks = if (picked) state.picks.filterNot { it.id == artist.id } else state.picks + artist
                val fromSearch = state.searchOpen && !picked
                state = state.copy(picks = picks, searchOpen = if (fromSearch) false else state.searchOpen,
                    query = if (fromSearch) "" else state.query,
                    artists = if (fromSearch) state.browseArtists else state.artists)
            }, onHints = { state = state.copy(allowTrackHints = it) },
            onSave = { onSaved(); state = state.copy(phase = HomeTastePhase.INTRO, searchOpen = false) },
            onDismiss = { onClosed(); state = state.copy(open = false) },
            onSearchOpen = { search -> state = state.copy(searchOpen = search, query = "", loading = false,
                artists = if (search) emptyList() else state.browseArtists) },
            onMoreSearch = {}, onRetryArtists = {},
            onEdit = { state = state.copy(phase = HomeTastePhase.PICKING, error = null) },
            onMoreRecommendations = onMore, onRetryRelated = onRetryRelated)
    }
    private fun picking(picks: List<RecoArtist> = emptyList()) = HomeTasteState(open = true,
        artists = artists, browseArtists = artists, picks = picks)

    @Test fun threeDistinctArtistsUnlockConfirmation() {
        var saved = 0
        compose.setContent { Fixture(picking(), onSaved = { saved++ }) }
        compose.onNodeWithTag("taste-confirm").assertDoesNotExist()
        compose.onNodeWithTag("taste-artist-1").performClick()
        compose.onNodeWithTag("taste-confirm").assertDoesNotExist()
        compose.onNodeWithTag("taste-artist-2").performClick()
        compose.onNodeWithTag("taste-confirm").assertDoesNotExist()
        compose.onNodeWithTag("taste-artist-3").performClick()
        compose.onNodeWithTag("taste-confirm").assertExists().performClick()
        compose.runOnIdle { assertEquals(1, saved) }
        compose.onNodeWithTag("taste-stage").assertTextEquals("Отличный выбор!")
    }

    @Test fun unselectingThirdArtistHidesConfirmation() {
        compose.setContent { Fixture(picking(artists.take(3))) }
        compose.onNodeWithTag("taste-confirm").assertExists()
        compose.onNodeWithTag("taste-artist-3").performClick()
        compose.onNodeWithTag("taste-confirm").assertDoesNotExist()
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 2 · минимум 3")
    }

    @Test fun duplicateSpellingDoesNotSatisfyMinimum() {
        val picks = listOf(artists[0], artists[0].copy(id = "01"), artists[1])
        compose.setContent { Fixture(picking(picks)) }
        compose.onNodeWithTag("taste-confirm").assertDoesNotExist()
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 2 · минимум 3")
    }

    @Test fun closingPickerDoesNotSaveSelection() {
        var saved = 0; var closed = 0
        compose.setContent { Fixture(picking(), { saved++ }, { closed++ }) }
        compose.onNodeWithTag("taste-close").performClick()
        // 6.84.7: крестик сначала спрашивает «Точно?», ничего не закрывая и не сохраняя
        compose.onNodeWithTag("taste-exit-dialog").assertIsDisplayed()
        compose.runOnIdle { assertEquals(0, saved); assertEquals(0, closed) }
        compose.onNodeWithTag("taste-exit-skip").performClick()
        compose.runOnIdle { assertEquals(0, saved); assertEquals(1, closed) }
        compose.onNodeWithTag("taste-screen").assertDoesNotExist()
    }

    @Test fun exitDialogStayKeepsSelectionAndPicker6847() {
        var closed = 0
        compose.setContent { Fixture(picking(artists.take(3)), onClosed = { closed++ }) }
        compose.onNodeWithTag("taste-close").performClick()
        compose.onNodeWithTag("taste-exit-title").assertTextEquals("Точно?")
        compose.onNodeWithTag("taste-exit-stay").performClick()
        compose.onNodeWithTag("taste-exit-dialog").assertDoesNotExist()
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 3")
        compose.runOnIdle { assertEquals(0, closed) }
    }

    @Test fun gatheringHasNoHomeButtonAndNoExit6847() {
        compose.setContent { Fixture(picking(artists.take(3)).copy(phase = HomeTastePhase.BUILDING)) }
        compose.onNodeWithTag("taste-gather-close").assertDoesNotExist()
        compose.onNodeWithTag("taste-actions").assertDoesNotExist()
    }

    @Test fun searchBackKeepsExistingSelection() {
        compose.setContent { Fixture(picking(artists.take(2))) }
        compose.onNodeWithTag("taste-open-search").performClick()
        compose.onNodeWithTag("taste-query").performTextInput("DJ")
        compose.onNodeWithTag("taste-search-back").performClick()
        compose.onNodeWithTag("taste-grid").assertExists()
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 2 · минимум 3")
    }

    @Test fun choosingSearchResultReturnsToDeckWithoutLosingPicks() {
        compose.setContent { Fixture(picking(artists.take(2))) }
        compose.onNodeWithTag("taste-open-search").performClick()
        compose.onNodeWithTag("taste-query").performTextInput("DJ")
        compose.onNodeWithTag("taste-search-artist-5").performClick()
        compose.onNodeWithTag("taste-grid").assertExists()
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 3")
        compose.onNodeWithTag("taste-confirm").assertExists()
    }

    @Test fun networkFailureOffersRetryEditAndExitNotFakeSuccess() {
        var retries = 0
        compose.setContent { Fixture(picking(artists.take(3)).copy(phase = HomeTastePhase.FAILED,
            error = "Сервер недоступен"), onSaved = { retries++ }) }
        compose.onNodeWithTag("taste-delivery-error").assertTextEquals("Сервер недоступен")
        compose.onNodeWithTag("taste-retry-delivery").assertIsDisplayed()
        compose.onNodeWithTag("taste-edit").assertIsDisplayed()
        compose.onNodeWithTag("taste-gather-close").assertDoesNotExist()
        compose.onNodeWithText("Твоя музыка готова").assertDoesNotExist()
        compose.onNodeWithTag("taste-retry-delivery").performClick()
        compose.runOnIdle { assertEquals(1, retries) }
    }

    @Test fun homeCardRequiresExplicitOpenAndCrossIsSeparate() {
        var opened = 0; var dismissed = 0
        compose.setContent {
            MaterialTheme { CompositionLocalProvider(LocalPalette provides basePalette()) {
                Box(Modifier.width(360.dp)) { HomeTasteInvite({ opened++ }, { dismissed++ }) }
            } }
        }
        compose.onNodeWithTag("home-taste-title").assertTextEquals("Получи точные рекомендации")
        compose.onNodeWithTag("taste-screen").assertDoesNotExist()
        compose.onNodeWithTag("home-taste-start").performClick()
        compose.runOnIdle { assertEquals(1, opened); assertEquals(0, dismissed) }
        compose.onNodeWithTag("home-taste-dismiss").performClick()
        compose.runOnIdle { assertEquals(1, opened); assertEquals(1, dismissed) }
    }

    @Test fun nativeCardAndWhiteButtonFollowMeasuredRatios() {
        var density = 1f
        compose.setContent {
            density = LocalDensity.current.density
            MaterialTheme { CompositionLocalProvider(LocalPalette provides basePalette()) {
                Box(Modifier.width(360.dp)) { HomeTasteInvite({}, {}) }
            } }
        }
        val card = compose.onNodeWithTag("home-taste-invite").fetchSemanticsNode().boundsInRoot
        val button = compose.onNodeWithTag("home-taste-start").fetchSemanticsNode().boundsInRoot
        assertEquals(360f * density, card.width, 1.1f)
        assertEquals(360f * density * 438f / 528f, card.height, 1.1f)
        assertEquals(360f * density * 134f / 528f, button.width, 1.1f)
        assertEquals(360f * density * 54f / 528f, button.height, 1.1f)
        assertEquals(card.center.x, button.center.x, 1.1f)
    }

    @Test fun largeFontExpandsCardInsteadOfClippingText() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 2f), LocalPalette provides basePalette()) {
                MaterialTheme { LazyColumn(Modifier.width(360.dp)) { item { HomeTasteInvite({}, {}) } } }
            }
        }
        compose.onNodeWithTag("home-taste-title").assertTextEquals("Получи точные рекомендации")
        compose.onNodeWithTag("home-taste-body").assertTextContains("Расскажи, музыку каких исполнителей")
        compose.onNodeWithTag("home-taste-invite").assertExists()
    }

    @Test fun confirmStaysInsideSafeWindowWhenGridScrolls() {
        val many = (1..60).map { RecoArtist(it.toString(), "Исполнитель $it", null) }
        compose.setContent { Fixture(picking(many.take(3)).copy(artists = many, browseArtists = many)) }
        val before = compose.onNodeWithTag("taste-open-search").fetchSemanticsNode().boundsInRoot.top
        compose.onNodeWithTag("taste-grid").performTouchInput { swipeUp() }
        compose.waitForIdle()
        val after = compose.onNodeWithTag("taste-open-search").fetchSemanticsNode().boundsInRoot.top
        assertTrue("Title collapses but search remains pinned", after < before)
        compose.onNodeWithTag("taste-open-search").assertIsDisplayed()
        compose.onNodeWithTag("taste-confirm").assertIsDisplayed()
        val screen = compose.onNodeWithTag("taste-screen").getUnclippedBoundsInRoot()
        val confirm = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        assertTrue("Confirm below safe bottom", confirm.bottom <= screen.bottom)
        compose.onNodeWithTag("taste-grid").performScrollToIndex(many.lastIndex)
        compose.waitForIdle()
        val lastCell = compose.onNodeWithTag("taste-artist-60").getUnclippedBoundsInRoot()
        val button = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        assertTrue("Last row hidden behind confirmation", lastCell.bottom <= button.top)
    }

    @Test fun recommendationOptionsAreAlignedAndDismissible() {
        compose.setContent { Fixture(picking()) }
        compose.onNodeWithTag("taste-options").performClick()
        compose.onNodeWithTag("taste-options-hints").assertIsOff().performClick().assertIsOn()
        compose.onNodeWithTag("taste-options-done").assertIsDisplayed().performClick()
        compose.onNodeWithTag("taste-options-sheet").assertDoesNotExist()
        compose.onNodeWithTag("taste-grid").assertIsDisplayed()
    }

    @Test fun largeFontFailureKeepsExitReachable() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 2f)) {
                Fixture(picking(artists.take(3)).copy(phase = HomeTastePhase.FAILED,
                    error = "Соединение прервано. Выбор сохранён на устройстве. Повтори попытку или выйди кнопкой «Назад»."))
            }
        }
        compose.onNodeWithTag("taste-edit").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("taste-retry-delivery").performScrollTo().assertIsDisplayed()
    }

    @Test fun footer6842DoesNotMoveWhenHeaderCollapsesOrGridKeepsScrolling() {
        val many = (1..60).map { RecoArtist(it.toString(), "Исполнитель $it", null) }
        compose.setContent { Fixture(picking(many.take(3)).copy(artists = many, browseArtists = many)) }
        val footerBefore = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        val searchBefore = compose.onNodeWithTag("taste-open-search").getUnclippedBoundsInRoot()
        compose.onNodeWithTag("taste-grid").performTouchInput { swipeUp() }
        compose.waitForIdle()
        val searchCollapsed = compose.onNodeWithTag("taste-open-search").getUnclippedBoundsInRoot()
        assertTrue(searchCollapsed.top < searchBefore.top)
        compose.onNodeWithTag("taste-compact-title", useUnmergedTree = true).assertIsDisplayed()
        compose.onNodeWithTag("taste-grid").performTouchInput { swipeUp() }
        compose.waitForIdle()
        val footerAfter = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        val searchAfter = compose.onNodeWithTag("taste-open-search").getUnclippedBoundsInRoot()
        assertEquals(footerBefore.bottom.value, footerAfter.bottom.value, .5f)
        assertEquals(footerBefore.left.value + footerBefore.right.value, footerAfter.left.value + footerAfter.right.value, 1f)
        assertEquals(searchCollapsed.top.value, searchAfter.top.value, .5f)
        compose.onNodeWithTag("taste-confirm").assertTextEquals("Готово")
    }

    @Test fun other6842RecommendationsAreReachableAboveFooterAndNeverConfirm() {
        var more = 0; var saved = 0
        val many = (1..23).map { RecoArtist(it.toString(), "Исполнитель $it", null) }
        compose.setContent { Fixture(picking(many.take(3)).copy(artists = many, browseArtists = many),
            onSaved = { saved++ }, onMore = { more++ }) }
        compose.onNodeWithTag("taste-grid").performScrollToIndex(many.size)
        compose.waitForIdle()
        val tile = compose.onNodeWithTag("taste-other-recommendations").getUnclippedBoundsInRoot()
        val footer = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        assertTrue("More tile must not be hidden by confirmation", tile.bottom <= footer.top)
        compose.onNodeWithTag("taste-other-recommendations").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(1, more); assertEquals(0, saved) }
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 3")
    }

    @Test fun related6842RetryDoesNotToggleSelectedArtist() {
        var retried = ""
        compose.setContent { Fixture(picking(artists.take(3)).copy(relatedErrors = mapOf("1" to "Нет сети")),
            onRetryRelated = { retried = it }) }
        compose.onNodeWithTag("taste-related-retry-1").performClick()
        compose.runOnIdle { assertEquals("1", retried) }
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 3")
        compose.onNodeWithTag("taste-artist-1").assertIsOn()
    }

    @Test fun search6842BackDoesNotExpandCollapsedHeader() {
        val many = (1..60).map { RecoArtist(it.toString(), "Исполнитель $it", null) }
        compose.setContent { Fixture(picking(many.take(3)).copy(artists = many, browseArtists = many)) }
        compose.onNodeWithTag("taste-grid").performTouchInput { swipeUp() }
        compose.waitForIdle()
        val before = compose.onNodeWithTag("taste-open-search").getUnclippedBoundsInRoot().top
        compose.onNodeWithTag("taste-open-search").performClick()
        compose.onNodeWithTag("taste-search-back").performClick()
        compose.waitForIdle()
        val after = compose.onNodeWithTag("taste-open-search").getUnclippedBoundsInRoot().top
        assertEquals(before.value, after.value, .5f)
        compose.onNodeWithTag("taste-count").assertTextEquals("Выбрано 3")
    }

    @Test fun footer6842LargeFontRemainsInsideWindow() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 2f)) {
                Fixture(picking(artists.take(3)))
            }
        }
        compose.onNodeWithTag("taste-confirm").assertIsDisplayed()
        val safe = compose.onNodeWithTag("taste-picker-viewport").getUnclippedBoundsInRoot()
        val footer = compose.onNodeWithTag("taste-confirm").getUnclippedBoundsInRoot()
        assertTrue(footer.top >= safe.top && footer.bottom <= safe.bottom)
        assertTrue(footer.left >= safe.left && footer.right <= safe.right)
    }
}
