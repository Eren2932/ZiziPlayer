package app.ziziplayer.ui

import android.content.Context
import android.content.ContextWrapper
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID

/** AndroidKeyStore + AtomicFile round-trip, not a JSON stub. Isolated directory, same real cipher. */
class HomeTasteVault6840DeviceTest {
    private fun isolated(block: (Context, File) -> Unit) {
        val parent = ApplicationProvider.getApplicationContext<Context>()
        val dir = File(parent.cacheDir, "taste-6840-${UUID.randomUUID()}").apply { mkdirs() }
        val context = object : ContextWrapper(parent) {
            override fun getNoBackupFilesDir(): File = dir
            override fun getFilesDir(): File = dir
            override fun getApplicationContext(): Context = this
        }
        try { block(context, dir) } finally { dir.deleteRecursively() }
    }
    private fun picks() = listOf(
        RecoVault.Pick("01", "Eminem", null),
        RecoVault.Pick("2", "Billie Eilish", null),
        RecoVault.Pick("3", "ABBA", null))

    @Test fun confirmedSelectionAndCompletionSurviveEncryptedReload() = isolated { context, dir ->
        val first = RecoVault(context)
        val saved = first.savePicks(picks())
        val key = HomeTastePolicy.selectionKey(saved.picks.map { it.id })
        assertEquals("taste-v1:1,2,3", key)
        assertEquals(key, saved.pendingTasteKey)
        assertFalse(saved.onboardingCompleted)
        val second = RecoVault(context)
        assertEquals(key, second.state().pendingTasteKey)
        assertFalse(second.state().onboardingCompleted)
        assertFalse(second.completeOnboarding("taste-v1:1,2,4"))
        val now = System.currentTimeMillis()
        val gate = "a".repeat(64)
        val raw = """{"complete":true,"shelves":[{"kind":"tracks","cards":[{"id":"123"}]}]}"""
        assertTrue(second.writeHome(gate, raw, now))
        assertTrue(second.completeOnboarding(key))
        val third = RecoVault(context)
        assertTrue(third.state().onboardingCompleted)
        assertEquals("", third.state().pendingTasteKey)
        assertEquals(raw, third.readHome(gate, now))
        val bytes = File(dir, "reco-state-v1").readBytes()
        assertFalse(String(bytes, Charsets.ISO_8859_1).contains("Billie Eilish"))
    }

    @Test fun laterAndTwoDuplicateArtistsCannotCompleteOnboarding() = isolated { context, _ ->
        val vault = RecoVault(context)
        vault.dismissOnboarding()
        assertFalse(RecoVault(context).state().onboardingCompleted)
        try {
            vault.savePicks(listOf(RecoVault.Pick("1", "Eminem", null),
                RecoVault.Pick("01", "Eminem", null), RecoVault.Pick("2", "ABBA", null)))
            fail("Two distinct IDs must not be accepted")
        } catch (_: IllegalArgumentException) { }
        assertFalse(RecoVault(context).state().onboardingCompleted)
        assertEquals("", vault.state().pendingTasteKey)
    }

    @Test fun changedConfirmedSelectionRejectsOldDeliveryKey() = isolated { context, _ ->
        val vault = RecoVault(context)
        val old = vault.savePicks(picks()).pendingTasteKey
        val newPicks = listOf(RecoVault.Pick("4", "Depeche Mode", null),
            RecoVault.Pick("5", "Massive Attack", null), RecoVault.Pick("6", "Radiohead", null))
        val current = vault.savePicks(newPicks).pendingTasteKey
        assertFalse(vault.completeOnboarding(old))
        val reloaded = RecoVault(context).state()
        assertEquals(current, reloaded.pendingTasteKey)
        assertFalse(reloaded.onboardingCompleted)
    }
}
