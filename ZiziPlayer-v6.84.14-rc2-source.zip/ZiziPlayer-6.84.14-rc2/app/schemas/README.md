# Room schema history

Room 2.7.1 exports through the `androidx.room` Gradle plugin. Processing tasks
write to separate `app/build/intermediates/room/schemas/<task>/` directories;
`copyRoomSchemas` consolidates their exports here and rejects conflicting content.
Do not restore a shared `ksp { arg("room.schemaLocation", ...) }` setting.

The 6.84.1-rc1 source archive did not contain schema JSON history. This hotfix does
not invent historical schemas or an identity hash. After a successful Android
build, run:

````sh
python3 tools/check_room_schema_config.py --require-current
````

Then preserve the generated `app.ziziplayer.data.ZiziDatabase/11.json` in source
control/the next source archive. Versions 1–10 remain missing until recovered
from genuine corresponding source builds/artifacts; this is not proof of migration
correctness. Existing application DB version and migrations are unchanged.

A malformed JSON in this directory fails preflight. Never delete genuine history
silently to make a build green. Restore a damaged file from a verified source.
Two independent Gradle processes must not build in the same checkout concurrently.
