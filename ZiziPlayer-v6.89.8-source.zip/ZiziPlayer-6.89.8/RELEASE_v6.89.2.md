# ZiziPlayer 6.89.2 (versionCode 219): зазор между словами в полном плеере и в предпросмотре текста

Основа: 6.89.1 (fastpath). Правка только шрифтовая; сервер, данные и логика не затронуты.

## Что было
Видимый зазор между словами, отнесённый к x-height (R, см. `tools/fonts/word_gap.py`):

| Где | Шрифт | Пробел | R до | R после |
|---|---|---|---|---|
| Мини-плеер (эталон) | zizi_mix_text_bold, 14 sp | 148 | 0.407 | 0.407 |
| Название в полном плеере | zizi_mix_player_title, 21.5 sp | 115 -> 191 | 0.255 | 0.408 |
| Строки «Предпросмотра текста» | zizi_mix_preview_title (новая), трекинг -1u | 115 -> 208 | 0.222 | 0.407 |

В полном плеере абсолютный зазор (≈2.7 dp) был таким же, как у мини-плеера (≈2.8 dp), хотя строчные крупнее
в 1.5 раза; в предпросмотре трекинг -1u уменьшал ещё и пробел. Слова читались слитно.

## Что сделано
* `zizi_mix_player_title.ttf`: пересобран, меняется только advance пробела и неразрывного пробела.
* `zizi_mix_preview_title.ttf` (новая): zizi_mix_title без изменений контуров/кернинга, пробел под трекинг предпросмотра.
  `zizi_mix_title` не тронута: на ней откалиброваны заголовки, плитки и шапки.
* `ZiziPreviewTitleFont` в ZiziTypography.kt, используется в LyricsPreviewCard.
* Инструменты: `tools/fonts/word_gap.py`, `build_zizi_player_title.py` (дополнен), `build_zizi_preview_title.py`,
  `word_gap_report.py`, замеры `tools/fonts/zizi_word_gap_6892.json`.
* Тесты: новый `tools/test_word_gap_6892.py` (подключён в check_selftest); обновлены `test_font_6877.py`
  (список файлов, семейство предпросмотра) и `test_mobile_6411_contracts.py` (шрифтов 9).

## Как подстроить
Целевая мера - R мини-плеера. Если зазор кажется тесным или широким, меняется целевое отношение в
`word_gap.py` (solve_space), затем пересобираются оба шрифта и `word_gap_report.py`.
Изменится трекинг предпросмотра (`letterSpacing` в LyricsPreviewCard / BODY_FONT) - обновите
`TRACKING_EM` в build_zizi_preview_title.py; тест это ловит.

## Не проверено
Рендер Compose на устройстве. Проверены: модель кернинга против HarfBuzz (13 456 пар, расхождений нет),
python-контракты tools/test_*.py (148 из 148), check_imports / kotlin_syntax / static_refs / package_shadow.
