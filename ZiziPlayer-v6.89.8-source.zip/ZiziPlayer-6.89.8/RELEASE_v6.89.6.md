# ZiziPlayer 6.89.6 (versionCode 223): хотфикс сборки 6.89.5

Основа: 6.89.5. Только клиент.

## Что упало
`:app:compileDebugKotlin` и `:app:compileReleaseKotlin`, `AccountScreen.kt`:
`96:9` и `135:9` Conflicting declarations (`local val inset: Dp` и `local val inset: () -> Float`) плюс 8 `Argument type mismatch` там, где `inset` использовался как `Dp`.

## Исправление
Лямбда сдвига боковых кнопок переименована `inset` -> `buttonInset` и передаётся в `ProfilePinnedHeader(inset = buttonInset)`. `inset` (Dp) остался отступом контента. Логика и значения те же.

## Почему пропустили
Статические проверки смотрели синтаксис, импорты и вызовы, но не повторные объявления в одной области. Добавлен `tools/test_kotlin_local_dupes_6896.py`.

## Чек-лист
Тот же, что в `RELEASE_v6.89.5.md`.
