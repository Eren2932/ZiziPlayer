package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import app.ziziplayer.data.AppTheme
import app.ziziplayer.ui.components.ArtSwatches
import kotlinx.coroutines.launch

/**
 * Seven vertical stops built from five cover shades, plus a separate glow colour.
 *
 * A cover is not one colour. The reference players build the backdrop out of several shades of the
 * same artwork - deep at the very top, opening up behind the cover, brightest behind the title and
 * the controls, closing down again at the bottom bar. Measuring the reference screenshot gives
 * value 0.10 -> 0.26 and saturation around 0.3: dark and quiet. v5 lit the top stop up to value
 * 0.42 with almost no cap on saturation, which is why a warm cover turned the whole screen muddy
 * brown instead of looking like the artwork.
 */
@Immutable
data class ZiziPalette(
    val top: Color,
    val upper: Color,
    val upperMid: Color,
    val middle: Color,
    val lower: Color,
    val lowerMid: Color,
    val bottom: Color,
    val glow: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    val tintStrength: Float
) {
    /**
     * Stop positions are lifted straight off the reference: brightness climbs from 0.05 at the
     * status bar to a peak of 0.24 at 0.67 of the height - behind the controls, not behind the
     * cover - and closes back down to 0.13 at the bottom bar. v6.1 put the peak at 0.80 and lit the
     * very top stop to 0.135, which is why the screen read as "tinted dark grey" instead of as the
     * cover itself.
     */
    val background: Brush
        get() = Brush.verticalGradient(
            0f to top,
            0.16f to upper,
            0.34f to upperMid,
            0.50f to middle,
            0.67f to lower,
            0.83f to lowerMid,
            1f to bottom
        )
}

private val Graphite = ZiziPalette(
    top = Color(0xFF14161A),
    upper = Color(0xFF1A1C20),
    upperMid = Color(0xFF1F2226),
    middle = Color(0xFF23262B),
    lower = Color(0xFF282C31),
    lowerMid = Color(0xFF1C1F23),
    bottom = Color(0xFF0B0C0E),
    glow = Color(0xFF3C4550),
    surface = Color(0xFF1D1F23),
    chip = Color(0xFF2C2F34),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF8FD3FF),
    onAccent = Color(0xFF06121A),
    tintStrength = 1f
)

private val Midnight = Graphite.copy(
    top = Color(0xFF090C16),
    upper = Color(0xFF101728),
    upperMid = Color(0xFF161F36),
    middle = Color(0xFF1A2440),
    lower = Color(0xFF1F2B4C),
    lowerMid = Color(0xFF141B2E),
    bottom = Color(0xFF06080F),
    glow = Color(0xFF31406E),
    surface = Color(0xFF161E33),
    chip = Color(0xFF223054),
    accent = Color(0xFF9EB8FF),
    tintStrength = 0.92f
)

private val Amoled = Graphite.copy(
    top = Color(0xFF000000),
    upper = Color(0xFF070707),
    upperMid = Color(0xFF0C0C0C),
    middle = Color(0xFF101010),
    lower = Color(0xFF141414),
    lowerMid = Color(0xFF090909),
    bottom = Color(0xFF000000),
    glow = Color(0xFF1C1C1C),
    surface = Color(0xFF121212),
    chip = Color(0xFF1E1E1E),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000),
    tintStrength = 0.45f
)

private val Sunset = Graphite.copy(
    top = Color(0xFF130A0E),
    upper = Color(0xFF1F1218),
    upperMid = Color(0xFF2A181F),
    middle = Color(0xFF321C25),
    lower = Color(0xFF3B212B),
    lowerMid = Color(0xFF23141A),
    bottom = Color(0xFF0C0608),
    glow = Color(0xFF5C3340),
    surface = Color(0xFF291921),
    chip = Color(0xFF3E242D),
    accent = Color(0xFFFFA36B),
    onAccent = Color(0xFF25100A),
    tintStrength = 1f
)

fun basePalette(theme: AppTheme): ZiziPalette = when (theme) {
    AppTheme.GRAPHITE -> Graphite
    AppTheme.MIDNIGHT -> Midnight
    AppTheme.AMOLED -> Amoled
    AppTheme.SUNSET -> Sunset
}

val LocalPalette = compositionLocalOf { Graphite }

/** Keeps the hue of a cover colour and re-maps saturation and brightness onto a target. */
private fun Color.shade(saturation: Float, value: Float, cap: Float = 0.55f): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(this.toArgb(), hsv)
    hsv[1] = (hsv[1] * saturation).coerceIn(0f, cap)
    hsv[2] = value.coerceIn(0f, 1f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

private fun Color.luminance(): Float = 0.299f * red + 0.587f * green + 0.114f * blue

/**
 * Builds the backdrop out of the three cover shades. Every stop keeps the hue of the artwork but
 * lands on a fixed brightness ramp, so a bright pop cover and a dark ambient one produce equally
 * readable screens - only the hue changes.
 */
fun ZiziPalette.tintedWith(swatches: ArtSwatches?): ZiziPalette {
    val strength = tintStrength
    if (swatches == null || strength <= 0.01f) return this
    val primary = swatches.primary
    val secondary = swatches.secondary
    val deep = swatches.deep
    val light = swatches.light
    val vivid = swatches.vivid
    // Every stop takes its hue from a DIFFERENT shade of the same cover and lands on the measured
    // brightness ramp. That is the whole trick: five hues over seven stops read as "the cover spilled
    // across the screen", one hue reads as a colour filter. Saturation is capped at 0.32 because the
    // reference sits at 0.26-0.30 - above that a warm cover turns the screen muddy brown.
    return copy(
        top = lerp(top, deep.shade(0.82f, 0.050f, 0.32f), 0.95f * strength),
        upper = lerp(upper, secondary.shade(0.86f, 0.115f, 0.32f), 0.93f * strength),
        upperMid = lerp(upperMid, light.shade(0.72f, 0.160f, 0.30f), 0.92f * strength),
        middle = lerp(middle, primary.shade(0.80f, 0.195f, 0.32f), 0.92f * strength),
        lower = lerp(lower, vivid.shade(0.88f, 0.240f, 0.34f), 0.92f * strength),
        lowerMid = lerp(lowerMid, secondary.shade(0.78f, 0.185f, 0.31f), 0.90f * strength),
        bottom = lerp(bottom, deep.shade(0.72f, 0.130f, 0.28f), 0.85f * strength),
        glow = lerp(glow, vivid.shade(1.00f, 0.600f, 0.78f), 0.95f * strength),
        surface = lerp(surface, primary.shade(0.62f, 0.200f, 0.30f), 0.85f * strength),
        chip = lerp(chip, light.shade(0.55f, 0.265f, 0.28f), 0.82f * strength),
        subtext = lerp(subtext, primary.shade(0.25f, 0.80f), 0.50f * strength),
        text = lerp(text, primary.shade(0.08f, 0.99f), 0.30f * strength)
    )
}

fun ZiziPalette.withAccent(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null) return this
    val bright = swatches.primary.shade(0.95f, 0.95f, 0.90f)
    return copy(accent = bright, onAccent = if (bright.luminance() > 0.55f) Color(0xFF0B0B0C) else Color.White)
}

/**
 * The gradient is animated in the DRAW phase only: the Animatable values are read inside
 * drawBehind, so a track change costs a repaint, never a recomposition of the tree.
 *
 * [glowAlpha] adds the radial highlight sitting behind the cover - that is what makes the artwork
 * colour look like it spilled over the whole screen. The library gets a faint one, the player a
 * strong one.
 */
@Composable
fun ZiziBackdrop(
    palette: ZiziPalette,
    modifier: Modifier = Modifier,
    durationMs: Int = 480,
    glowAlpha: Float = 0f,
    glowCenter: Float = 0.30f
) {
    val top = remember { Animatable(palette.top) }
    val upper = remember { Animatable(palette.upper) }
    val upperMid = remember { Animatable(palette.upperMid) }
    val middle = remember { Animatable(palette.middle) }
    val lower = remember { Animatable(palette.lower) }
    val lowerMid = remember { Animatable(palette.lowerMid) }
    val bottom = remember { Animatable(palette.bottom) }
    val glow = remember { Animatable(palette.glow) }
    LaunchedEffect(palette) {
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(palette.top, spec) }
        launch { upper.animateTo(palette.upper, spec) }
        launch { upperMid.animateTo(palette.upperMid, spec) }
        launch { middle.animateTo(palette.middle, spec) }
        launch { lower.animateTo(palette.lower, spec) }
        launch { lowerMid.animateTo(palette.lowerMid, spec) }
        launch { bottom.animateTo(palette.bottom, spec) }
        launch { glow.animateTo(palette.glow, spec) }
    }
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to top.value,
                        0.16f to upper.value,
                        0.34f to upperMid.value,
                        0.50f to middle.value,
                        0.67f to lower.value,
                        0.83f to lowerMid.value,
                        1f to bottom.value
                    )
                )
                if (glowAlpha > 0.01f) {
                    val tint = glow.value
                    // Two washes, both from the cover: a tight one behind the artwork and a wide,
                    // half strength one under the controls. The reference has its brightest band
                    // there, and a single radial cannot produce both without washing out the top.
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(
                                tint.copy(alpha = glowAlpha),
                                tint.copy(alpha = glowAlpha * 0.45f),
                                tint.copy(alpha = 0f)
                            ),
                            center = Offset(size.width * 0.5f, size.height * glowCenter),
                            radius = size.width * 1.15f
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(
                                tint.copy(alpha = glowAlpha * 0.55f),
                                tint.copy(alpha = glowAlpha * 0.22f),
                                tint.copy(alpha = 0f)
                            ),
                            center = Offset(size.width * 0.5f, size.height * 0.70f),
                            radius = size.width * 1.45f
                        )
                    )
                }
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = Typography(),
        content = content
    )
}
