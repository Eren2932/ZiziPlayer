package app.ziziplayer.playback

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import app.ziziplayer.data.TrackEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/**
 * Хранилище СКАЧАННОГО. 6.24.0: настоящий файл, а не кэш.
 *
 * До 6.24.0 «Скачать» писало байты в [SimpleCache] внутри `filesDir`: набор фрагментов `*.exo`
 * с бинарным индексом. Формально трек играл офлайн, фактически файла не существовало —
 * ни в файловом менеджере, ни в системном медиа-каталоге, ни для «Поделиться», ни после
 * переустановки приложения. Пользователь нажимал «Скачать» и получал нечто, что нельзя ни
 * найти, ни отправить, ни услышать в другом плеере. Это не загрузка, это кэш с другим именем.
 *
 * Теперь загрузка кладёт ОДИН файл в публичную папку `Музыка/Zizi`:
 *
 *   API 29+   MediaStore.Audio, RELATIVE_PATH=Music/Zizi, запись под IS_PENDING=1 и снятие
 *             флага только после последнего байта. Недокачанный файл не виден никому: ни нам,
 *             ни другим плеерам, ни галерее — поэтому «оборванная загрузка» физически не может
 *             стать «битым треком в медиатеке».
 *   API 26-28 обычный файл в /Music/Zizi + MediaScanner, потому что RELATIVE_PATH и IS_PENDING
 *             появились только в Q. Нужен WRITE_EXTERNAL_STORAGE (в манифесте он ограничен
 *             maxSdkVersion=28 — на новых версиях его никто не спрашивает).
 *
 * Индекс (trackId → файл) лежит в `filesDir/offline-index.json`, но истина — на диске:
 * любая выдача наружу проверяется обращением к файлу, и запись, у которой файла больше нет
 * (пользователь удалил его проводником), молча выпадает из индекса. Второго источника истины,
 * который «через месяц разойдётся с диском», здесь нет намеренно.
 */
object OfflineStore {

    /** Папка внутри «Музыки». Видна пользователю, поэтому названа так, как называется приложение. */
    const val FOLDER = "Zizi"
    const val FOLDER_LABEL = "Музыка/Zizi"

    private const val INDEX_FILE = "offline-index.json"
    private const val NAME_LIMIT = 84

    data class Entry(
        val trackId: String,
        val trackUri: String,
        /** `content://…` на API 29+, абсолютный путь на 26-28. */
        val location: String,
        val name: String,
        val mime: String,
        val bytes: Long,
        val savedAt: Long
    )

    /** Открытая на запись цель. Живёт только внутри одной загрузки. */
    class Pending internal constructor(
        internal val row: Uri?,
        internal val file: File?,
        val name: String,
        val mime: String,
        val stream: OutputStream
    )

    private val lock = Any()
    private var loaded = false
    /**
     * Когда файл записи последний раз проверялся на существование.
     *
     * Проверка — это обращение к ContentResolver, то есть IPC. Статус загрузки читается из
     * композиции (меню трека перерисовывается на каждый шаг прогресса), и без этого кэша каждый
     * шаг стоил бы походом в другой процесс на главном потоке. Пять секунд — компромисс: файл,
     * удалённый проводником прямо сейчас, заметится почти сразу, а сотня перерисовок подряд
     * обойдётся одной проверкой.
     */
    private val checkedAt = HashMap<String, Long>()
    private val byId = LinkedHashMap<String, Entry>()
    private val byUri = HashMap<String, Entry>()

    /* ------------------------------------------------------------------ индекс */

    private fun indexFile(context: Context) = File(context.filesDir, INDEX_FILE)

    private fun ensureLoaded(context: Context) {
        synchronized(lock) { ensureLoadedLocked(context) }
    }

    private fun persist(context: Context) {
        val snapshot = synchronized(lock) { byId.values.toList() }
        val array = JSONArray()
        snapshot.forEach { e ->
            array.put(
                JSONObject()
                    .put("id", e.trackId)
                    .put("track", e.trackUri)
                    .put("at", e.location)
                    .put("name", e.name)
                    .put("mime", e.mime)
                    .put("bytes", e.bytes)
                    .put("saved", e.savedAt)
            )
        }
        // Через временный файл: обрыв на записи индекса не должен превращать все загрузки в «нет».
        runCatching {
            val target = indexFile(context)
            val tmp = File(target.parentFile, "$INDEX_FILE.tmp")
            tmp.writeText(array.toString())
            if (!tmp.renameTo(target)) { target.writeText(array.toString()); tmp.delete() }
        }
    }

    /* ------------------------------------------------------------------ чтение */

    /** Запись, ФАЙЛ КОТОРОЙ существует. Пропавший файл вычищается из индекса здесь же. */
    fun entryOf(context: Context, trackId: String): Entry? {
        ensureLoaded(context)
        val entry = synchronized(lock) { byId[trackId] } ?: return null
        if (verified(context, entry)) return entry
        forget(context, entry)
        return null
    }

    fun entryForUri(context: Context, trackUri: String): Entry? {
        ensureLoaded(context)
        val entry = synchronized(lock) { byUri[trackUri] } ?: return null
        if (verified(context, entry)) return entry
        forget(context, entry)
        return null
    }

    /** Файла больше нет на диске: убрать запись, дальше играем из сети. */
    fun forgetUri(context: Context, trackUri: Uri) {
        ensureLoaded(context)
        val entry = synchronized(lock) { byUri[trackUri.toString()] } ?: return
        forget(context, entry)
    }

    fun isDownloaded(context: Context, track: TrackEntity): Boolean = entryOf(context, track.id) != null

    /** Адрес, из которого играть офлайн. `null` — качать ещё нечего. */
    fun playbackUri(context: Context, trackUri: Uri): Uri? {
        val entry = entryForUri(context, trackUri.toString()) ?: return null
        return locationUri(entry)
    }

    private fun locationUri(entry: Entry): Uri =
        if (entry.location.startsWith("content://")) Uri.parse(entry.location)
        else Uri.fromFile(File(entry.location))

    private fun verified(context: Context, entry: Entry): Boolean {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val last = checkedAt[entry.trackId]
            if (last != null && now - last < CHECK_TTL_MS) return true
        }
        if (!exists(context, entry)) {
            synchronized(lock) { checkedAt.remove(entry.trackId) }
            return false
        }
        synchronized(lock) { checkedAt[entry.trackId] = now }
        return true
    }

    private const val CHECK_TTL_MS = 5_000L

    private fun exists(context: Context, entry: Entry): Boolean = runCatching {
        if (entry.location.startsWith("content://")) {
            context.contentResolver.openAssetFileDescriptor(Uri.parse(entry.location), "r")?.use { true } ?: false
        } else {
            val file = File(entry.location)
            file.isFile && file.length() > 0L
        }
    }.getOrDefault(false)

    fun count(context: Context): Int { ensureLoaded(context); return synchronized(lock) { byId.size } }

    fun sizeBytes(context: Context): Long {
        ensureLoaded(context)
        return synchronized(lock) { byId.values.sumOf { it.bytes } }
    }

    /**
     * Что отправить в «Поделиться». `null` — файла нет, и врать вложением нельзя.
     *
     * MediaStore-адрес уходит наружу как есть: он и так `content://`, и разовое разрешение на
     * чтение выдаётся системой. Легаси-путь заворачивается в FileProvider — прямой `file://`
     * в чужое приложение с Android 7 запрещён (FileUriExposedException, то есть падение).
     */
    fun shareTarget(context: Context, track: TrackEntity): Pair<Uri, String>? {
        val entry = entryOf(context, track.id) ?: return null
        val uri = if (entry.location.startsWith("content://")) {
            Uri.parse(entry.location)
        } else {
            runCatching {
                FileProvider.getUriForFile(context, context.packageName + ".files", File(entry.location))
            }.getOrNull() ?: return null
        }
        return uri to entry.mime
    }

    /* ------------------------------------------------------------------ запись */

    /** true — на этой версии Android для загрузки нужно разрешение, и его нет. */
    fun needsLegacyPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return false
        return context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun create(context: Context, track: TrackEntity, mime: String, extension: String): Pending {
        val base = fileName(track, extension)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) createViaMediaStore(context, track, base, mime)
        else createLegacy(base, mime)
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.Q)
    private fun createViaMediaStore(context: Context, track: TrackEntity, name: String, mime: String): Pending {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/" + FOLDER)
            put(MediaStore.Audio.Media.TITLE, track.title)
            put(MediaStore.Audio.Media.ARTIST, track.artist)
            if (track.album.isNotBlank()) put(MediaStore.Audio.Media.ALBUM, track.album)
            if (track.durationMs > 0L) put(MediaStore.Audio.Media.DURATION, track.durationMs)
            put(MediaStore.Audio.Media.IS_MUSIC, 1)
            // Невидим для всей системы, пока не дописан. Это и есть защита от «битого трека».
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val row = context.contentResolver.insert(collection, values)
            ?: throw IOException("система не дала записать в «Музыку»")
        val stream = runCatching { context.contentResolver.openOutputStream(row, "w") }.getOrNull()
        if (stream == null) {
            runCatching { context.contentResolver.delete(row, null, null) }
            throw IOException("система не дала записать в «Музыку»")
        }
        return Pending(row = row, file = null, name = name, mime = mime, stream = stream)
    }

    private fun createLegacy(name: String, mime: String): Pending {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), FOLDER)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("нет доступа к папке «Музыка»")
        var target = File(dir, name)
        var n = 2
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        while (target.exists()) { target = File(dir, "$stem ($n)$ext"); n++ }
        return Pending(row = null, file = target, name = target.name, mime = mime, stream = FileOutputStream(target))
    }

    /** Последний байт записан: снимаем IS_PENDING (или зовём сканер) и заводим запись индекса. */
    fun publish(context: Context, track: TrackEntity, pending: Pending, bytes: Long): Entry {
        runCatching { pending.stream.flush() }
        runCatching { pending.stream.close() }
        val location: String
        if (pending.row != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                context.contentResolver.update(pending.row, done, null, null)
            }
            location = pending.row.toString()
        } else {
            val file = pending.file ?: throw IOException("некуда сохранять")
            location = file.absolutePath
            // Без сканера файл есть, а в медиатеке телефона его нет до перезагрузки.
            runCatching {
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(pending.mime), null)
            }
        }
        val entry = Entry(
            trackId = track.id,
            trackUri = track.uri,
            location = location,
            name = pending.name,
            mime = pending.mime,
            bytes = bytes,
            savedAt = System.currentTimeMillis()
        )
        synchronized(lock) {
            ensureLoadedLocked(context)
            byId[entry.trackId] = entry
            byUri[entry.trackUri] = entry
        }
        persist(context)
        return entry
    }

    private fun ensureLoadedLocked(context: Context) {
        if (!loaded) { loaded = true; runCatching { loadInto(context) } }
    }

    private fun loadInto(context: Context) {
        val file = indexFile(context)
        if (!file.exists()) return
        val array = JSONArray(file.readText())
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val entry = Entry(
                trackId = o.optString("id"),
                trackUri = o.optString("track"),
                location = o.optString("at"),
                name = o.optString("name"),
                mime = o.optString("mime", "audio/mp4"),
                bytes = o.optLong("bytes"),
                savedAt = o.optLong("saved")
            )
            if (entry.trackId.isBlank() || entry.location.isBlank()) continue
            byId[entry.trackId] = entry
            byUri[entry.trackUri] = entry
        }
    }

    /** Оборвалось: недописанный файл не должен остаться ни в папке, ни в медиатеке. */
    fun abandon(context: Context, pending: Pending?) {
        if (pending == null) return
        runCatching { pending.stream.close() }
        if (pending.row != null) runCatching { context.contentResolver.delete(pending.row, null, null) }
        pending.file?.let { runCatching { it.delete() } }
    }

    /** «Удалить загрузку»: файла больше нет, трек остаётся в библиотеке и играет из сети. */
    fun delete(context: Context, trackId: String) {
        val entry = run { ensureLoaded(context); synchronized(lock) { byId[trackId] } } ?: return
        if (entry.location.startsWith("content://")) {
            runCatching { context.contentResolver.delete(Uri.parse(entry.location), null, null) }
        } else {
            val file = File(entry.location)
            runCatching { file.delete() }
            runCatching {
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(entry.mime), null)
            }
        }
        forget(context, entry)
    }

    fun deleteAll(context: Context) {
        ensureLoaded(context)
        synchronized(lock) { byId.keys.toList() }.forEach { delete(context, it) }
    }

    private fun forget(context: Context, entry: Entry) {
        synchronized(lock) {
            checkedAt.remove(entry.trackId)
            byId.remove(entry.trackId)
            if (byUri[entry.trackUri]?.trackId == entry.trackId) byUri.remove(entry.trackUri)
        }
        persist(context)
    }

    /**
     * Уборка за прошлым запуском: строки, которые остались PENDING после убитого процесса.
     *
     * Такая строка занимает место и не видна нигде, то есть без этой уборки «скачал половину и
     * закрыл приложение» медленно съедало бы память телефона невидимым мусором.
     */
    fun cleanupPending(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        runCatching {
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val where = MediaStore.Audio.Media.IS_PENDING + "=1 AND " +
                MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("%" + Environment.DIRECTORY_MUSIC + "/" + FOLDER + "%")
            context.contentResolver.delete(collection, where, args)
        }
    }

    /* ------------------------------------------------------------------ имя файла */

    private fun fileName(track: TrackEntity, extension: String): String {
        val artist = sanitize(track.artist)
        val title = sanitize(track.title).ifBlank { "track" }
        val stem = if (artist.isBlank() || artist == "—") title else "$artist - $title"
        return stem.take(NAME_LIMIT).trimEnd('.', ' ') + "." + extension
    }

    private fun sanitize(raw: String): String = raw
        .replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

/**
 * Чем оказались скачанные байты.
 *
 * Расширение не угадывается по настройкам качества и не берётся из ответа сервера: и то и другое
 * врёт (резолвер может отдать webm там, где просили m4a). Смотрим на первые байты — это и есть
 * единственный честный источник. Неправильное расширение стоит дорого: файл лежит в общей папке
 * «Музыка», и его будут открывать чужие приложения, которые верят расширению, а не содержимому.
 */
internal object AudioFormatSniffer {

    data class Format(val mime: String, val extension: String)

    private val M4A = Format("audio/mp4", "m4a")

    fun of(buffer: ByteArray, length: Int): Format {
        if (length < 12) return M4A
        fun ascii(from: Int, text: String): Boolean {
            if (from + text.length > length) return false
            for (i in text.indices) if (buffer[from + i] != text[i].code.toByte()) return false
            return true
        }
        return when {
            ascii(4, "ftyp") -> M4A
            ascii(0, "OggS") -> Format("audio/ogg", "ogg")
            ascii(0, "ID3") -> Format("audio/mpeg", "mp3")
            ascii(0, "RIFF") -> Format("audio/wav", "wav")
            ascii(0, "fLaC") -> Format("audio/flac", "flac")
            buffer[0] == 0x1A.toByte() && buffer[1] == 0x45.toByte() &&
                buffer[2] == 0xDF.toByte() && buffer[3] == 0xA3.toByte() -> Format("audio/webm", "webm")
            (buffer[0].toInt() and 0xFF) == 0xFF && (buffer[1].toInt() and 0xE0) == 0xE0 ->
                Format("audio/mpeg", "mp3")
            else -> M4A
        }
    }
}
