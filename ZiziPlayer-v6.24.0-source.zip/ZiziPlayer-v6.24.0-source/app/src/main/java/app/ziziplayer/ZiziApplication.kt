package app.ziziplayer

import android.app.Application
import androidx.room.Room
import app.ziziplayer.data.*
import app.ziziplayer.data.remote.AudiusCatalog
import app.ziziplayer.data.remote.CatalogRegistry
import app.ziziplayer.data.remote.InnertubeCatalog
import app.ziziplayer.data.remote.PoTokenMinter
import app.ziziplayer.data.remote.SessionWebToken
import app.ziziplayer.data.remote.ZiziResolve
import app.ziziplayer.playback.LegacyOfflineCache
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class ZiziApplication : Application() {
    lateinit var database: ZiziDatabase; private set
    lateinit var repository: MusicRepository; private set
    lateinit var playerController: PlayerController; private set

    override fun onCreate() {
        super.onCreate()
        // Первым делом и до всего остального: обработчик падений не имеет права зависеть от
        // того, успела ли подняться база, резолвер или плеер.
        CrashLog.install(this)
        // No destructive fallback: a schema change must never wipe playlists, favourites and FX.
        database = Room.databaseBuilder(this, ZiziDatabase::class.java, "zizi.db")
            .addMigrations(
                ZiziDatabase.MIGRATION_1_2,
                ZiziDatabase.MIGRATION_2_3,
                ZiziDatabase.MIGRATION_3_4,
                ZiziDatabase.MIGRATION_4_5,
                ZiziDatabase.MIGRATION_5_6
            )
            .build()
        val settings = SettingsStore(this)
        repository = MusicRepository(
            this,
            database.musicDao(),
            settings,
            MusicScanner(this),
            PlaybackMemory(this)
        )
        // Innertube first because it is the only catalogue that actually has this music; Audius
        // second because it is the one that keeps working when YouTube changes something. Order in
        // this list is only the fallback order - the active provider comes from settings.
        // The attestation minter needs an Application context to build its off-screen WebView and
        // to read its asset. It builds nothing here: the WebView appears on first use, and only if
        // remote playback actually happens.
        PoTokenMinter.install(this)
        SessionWebToken.install(
            this,
            SessionWebToken.Config(bootstrapUrl = BuildConfig.SESSION_BOOTSTRAP_URL)
        )
        // The WebView is never attached to a window. It starts immediately so protected OkHttp
        // requests normally find the payload ready; the interceptor still has a bounded wait for
        // the launch race.
        SessionWebToken.start()
        RemoteRuntime.registry = CatalogRegistry(
            listOf(
                InnertubeCatalog(apiKey = BuildConfig.INNERTUBE_KEY),
                AudiusCatalog()
            )
        )

        // Attestation takes a second or three. Spent here, at launch, off any user-visible path, it
        // costs nothing; spent on the first track it is a track that takes three seconds to start.
        // Failure is deliberately ignored - prewarm is an optimisation, not a step.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            RemoteRuntime.registry.all.forEach { catalog ->
                try {
                    catalog.prewarm()
                } catch (e: Throwable) {
                    // A provider that cannot warm up still works on demand.
                }
            }
        }

        // The Media3 loading thread cannot ask a ViewModel for settings, so the handful of values it
        // needs are mirrored into RemoteRuntime as they change. Application scope, because the
        // playback service outlives every screen.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            settings.settings
                .map {
                    NetworkPrefs(
                        it.wifiOnly, it.streamQuality, it.meteredQuality, it.streamCacheEnabled, it.streamCacheMb,
                        it.resolverUrl, it.resolverToken, it.resolverProxy
                    )
                }
                .distinctUntilChanged()
                .collect { prefs ->
                    RemoteRuntime.wifiOnly = prefs.wifiOnly
                    RemoteRuntime.quality = prefs.quality
                    RemoteRuntime.meteredQuality = prefs.meteredQuality
                    RemoteRuntime.cacheEnabled = prefs.cacheEnabled
                    RemoteRuntime.cacheBytes = prefs.cacheMb.toLong() * 1024 * 1024
                    // 6.10.0: the resolver is read on the Media3 loading thread too, so it is
                    // mirrored here next to the other playback-path values, not fetched per track.
                    ZiziResolve.baseUrl = prefs.resolverUrl
                    ZiziResolve.token = prefs.resolverToken
                    ZiziResolve.proxyStream = prefs.resolverProxy
                }
        }

        playerController = PlayerController(this)

        // 6.24.0: разовая уборка кэша загрузок 6.20-6.23 и брошенных PENDING-строк в «Музыке».
        // На IO и после всего остального: это гигиена, а не часть запуска.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            LegacyOfflineCache.purgeOnce(this@ZiziApplication)
            OfflineStore.cleanupPending(this@ZiziApplication)
        }
    }

    /** Only so distinctUntilChanged has something small to compare. */
    private data class NetworkPrefs(
        val wifiOnly: Boolean,
        val quality: app.ziziplayer.data.remote.RemoteQuality,
        val meteredQuality: app.ziziplayer.data.remote.RemoteQuality,
        val cacheEnabled: Boolean,
        val cacheMb: Int,
        val resolverUrl: String,
        val resolverToken: String,
        val resolverProxy: Boolean
    )
}
