@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.DevAccess
import app.ziziplayer.data.remote.RemoteQuality
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.SortMode
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.NowPlayingBadge
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
internal fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
internal fun MenuItem(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    trailing: String? = null,
    /** 6.17.0: вторая строка — там, где одного глагола мало, чтобы понять последствия. */
    subtitle: String? = null,
    /** 6.17.0: пункт что-то убирает. Красный не для красоты: он тормозит палец. */
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val color = tint ?: if (danger) DANGER else p.text
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = if (subtitle == null) 15.dp else 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
        }
        if (trailing != null) Text(trailing, color = p.subtext, fontSize = 14.sp)
    }
}

/** Один красный на всё приложение: он уже был тремя копиями в диалогах. */
internal val DANGER = Color(0xFFFF6B6B)

/**
 * [scrollable] exists for the queue. A LazyColumn nested inside a verticalScroll parent is the
 * classic Compose performance trap: the two scrollables fight over the same gesture and the lazy
 * list loses most of its item reuse, so a 100 track queue scrolled worse than the 3000 track
 * library. The queue passes false and drives its own LazyColumn.
 */
/**
 * 6.24.0: у листа ОДНО состояние, и закрывается он одним движением.
 *
 * Меню трека открывалось с `partial = true`, то есть с двумя якорями: раскрытый и половинный.
 * Системный жест «назад» в такой шторке сначала сжимает её до половины и только вторым жестом
 * закрывает. Со стороны это выглядит как заедание — человек сделал жест закрытия, окно осталось
 * на экране, и он делает жест ещё раз. Двух логик закрытия у одного окна быть не должно, поэтому
 * половинный якорь убран вместе с параметром: любое раскрытие теперь уезжает вниз с первого
 * жеста, и уезжает анимацией Material (её проигрывает сам ModalBottomSheet перед
 * onDismissRequest), а не мгновенным исчезновением.
 */
@Composable
internal fun ZiziSheetScaffold(
    onDismiss: () -> Unit,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        contentColor = p.text,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        dragHandle = {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(p.subtext.copy(alpha = 0.45f)))
            }
        }
    ) {
        // Content scrolls: the settings sheet is taller than a phone screen in landscape and the
        // v5 version simply clipped the last rows away.
        Column(
            Modifier
                .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(bottom = 26.dp),
            content = content
        )
    }
}

/**
 * Строка «Скачать» — 6.24.0, переписана целиком.
 *
 * Было так: пять разных [MenuItem] в `when`. Смена состояния меняла ОДНОВРЕМЕННО иконку, текст,
 * наличие второй строки и, из-за второй строки, высоту ряда — мгновенно, без перехода. Список под
 * ним подпрыгивал, проценты дёргались рывками (загрузчик публиковал их десятки раз в секунду).
 * Именно это «режет глаза»: глаз ловит не анимацию, а скачок.
 *
 * Стало так:
 *  - ряд ОДИН и высота у него фиксированная, вторая строка есть всегда. Прыгать больше нечему;
 *  - смена фазы (нет копии → в очереди → качается → скачано) — это crossfade иконки и текста,
 *    ~200 мс. Внутри фазы текст меняется обычной перерисовкой: анимировать каждый процент значит
 *    мигать двадцать раз в секунду;
 *  - прогресс нарисован кольцом вокруг иконки и едет через animateFloatAsState, поэтому шаг
 *    процента виден как движение, а не как подмена цифры. Когда длина неизвестна, кольцо
 *    крутится — это честное «идёт, длину не сказали», а не мёртвое «…».
 */
@Composable
private fun DownloadMenuItem(
    status: DownloadStatus,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onRemove: () -> Unit
) {
    // Локальный файл: качать нечего, и пункт-заглушка тут был бы враньём.
    if (status is DownloadStatus.Local) return

    val p = LocalPalette.current
    val phase = when (status) {
        is DownloadStatus.Running -> DownloadPhase.WORKING
        DownloadStatus.Queued -> DownloadPhase.QUEUED
        DownloadStatus.Done -> DownloadPhase.READY
        is DownloadStatus.Failed -> DownloadPhase.BROKEN
        else -> DownloadPhase.IDLE
    }
    val percent = (status as? DownloadStatus.Running)?.percent ?: -1

    val progress by animateFloatAsState(
        targetValue = when (phase) {
            DownloadPhase.READY -> 1f
            DownloadPhase.WORKING -> if (percent >= 0) percent / 100f else 0f
            else -> 0f
        },
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "download-progress"
    )
    val ring by animateFloatAsState(
        targetValue = if (phase == DownloadPhase.WORKING || phase == DownloadPhase.QUEUED) 1f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "download-ring"
    )
    val tint by animateColorAsState(
        targetValue = when (phase) {
            DownloadPhase.READY -> p.accent
            DownloadPhase.BROKEN -> DANGER
            else -> p.text
        },
        animationSpec = tween(durationMillis = 260),
        label = "download-tint"
    )
    val spin = rememberInfiniteTransition(label = "download-spin")
    val sweepStart by spin.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1100, easing = LinearEasing)),
        label = "download-sweep"
    )

    val onClick: () -> Unit = when (phase) {
        DownloadPhase.WORKING, DownloadPhase.QUEUED -> onCancel
        DownloadPhase.READY -> onRemove
        else -> onDownload
    }

    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            if (ring > 0.01f) Canvas(Modifier.size(24.dp).alpha(ring)) {
                val stroke = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
                drawArc(
                    color = p.subtext.copy(alpha = 0.28f),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = stroke
                )
                if (percent >= 0) drawArc(
                    color = p.accent,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = stroke
                ) else drawArc(
                    color = p.accent,
                    startAngle = sweepStart,
                    sweepAngle = 96f,
                    useCenter = false,
                    style = stroke
                )
            }
            Crossfade(targetState = phase, animationSpec = tween(durationMillis = 200), label = "download-icon") { current ->
                Icon(
                    imageVector = when (current) {
                        DownloadPhase.WORKING, DownloadPhase.QUEUED -> Icons.Filled.Stop
                        DownloadPhase.READY -> Icons.Filled.DownloadDone
                        else -> Icons.Filled.Download
                    },
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(
                        if (current == DownloadPhase.WORKING || current == DownloadPhase.QUEUED) 11.dp else 22.dp
                    )
                )
            }
        }
        Spacer(Modifier.width(18.dp))
        AnimatedContent(
            targetState = phase,
            transitionSpec = {
                fadeIn(animationSpec = tween(durationMillis = 220)) togetherWith
                    fadeOut(animationSpec = tween(durationMillis = 160))
            },
            label = "download-text",
            modifier = Modifier.weight(1f)
        ) { current ->
            Column {
                Text(
                    text = when (current) {
                        DownloadPhase.WORKING -> "Остановить загрузку"
                        DownloadPhase.QUEUED -> "Отменить, пока не началось"
                        DownloadPhase.READY -> "Удалить загрузку"
                        DownloadPhase.BROKEN -> "Скачать ещё раз"
                        DownloadPhase.IDLE -> "Скачать"
                    },
                    color = tint,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Text(
                    text = when (current) {
                        // Проценты не дублируются в подписи: цифра справа и так одна на строку.
                        DownloadPhase.WORKING -> "Сохраняется в " + OfflineStoreLabel
                        DownloadPhase.QUEUED -> "В очереди: качаем по два трека за раз"
                        DownloadPhase.READY -> "Играет без сети. Файл лежит в " + OfflineStoreLabel
                        DownloadPhase.BROKEN -> (status as? DownloadStatus.Failed)?.message ?: "не удалось"
                        DownloadPhase.IDLE -> "Файлом в " + OfflineStoreLabel + " · играет без сети"
                    },
                    color = p.subtext,
                    fontSize = 12.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        // Цифра читается из status напрямую: внутри фазы это обычная перерисовка одного Text,
        // без анимации и без мигания. Анимировать каждый процент — это мигать двадцать раз в
        // секунду; двигаться должно кольцо, а не текст.
        if (phase == DownloadPhase.WORKING && percent >= 0) {
            Text("$percent%", color = p.subtext, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private enum class DownloadPhase { IDLE, QUEUED, WORKING, READY, BROKEN }

/** Одна строка на всё приложение: путь к загрузкам показывается человеку в четырёх местах. */
private const val OfflineStoreLabel = "Музыка/Zizi"

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Реверб", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$reverb%", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = reverb.toFloat(),
                onValueChange = { reverb = it.roundToInt() },
                onValueChangeFinished = { apply() },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(6.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", current?.let { "Осталось $it мин" } ?: "Выключен")
        listOf(10, 15, 20, 30, 45, 60, 90).forEach { minutes ->
            MenuItem(Icons.Filled.Bedtime, "$minutes минут") { onPick(minutes); onDismiss() }
        }
        if (current != null) {
            MenuItem(Icons.Filled.Close, "Выключить таймер") { onPick(null); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
    /** 6.17.0: тот же лист обслуживает «добавить», «перенести» и «сохранить сборник». */
    title: String = "Добавить в плейлист",
    subtitle: String = "",
    /** Заготовка имени для нового плейлиста: имя сборника или папки, откуда пришли. */
    defaultName: String = ""
) {
    val p = LocalPalette.current
    var newName by remember(defaultName) { mutableStateOf(defaultName) }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle(title)
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                color = p.subtext,
                fontSize = 12.5.sp,
                modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 6.dp)
            )
        }
        if (playlists.isEmpty()) {
            Text(
                "Плейлистов пока нет — назови новый ниже",
                color = p.subtext,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }
        playlists.forEach { playlist ->
            MenuItem(Icons.Filled.QueueMusic, playlist.name) { onPick(playlist.id); onDismiss() }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.accent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = ""; onDismiss() } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* --------------------------------------------------------- множественный выбор (6.17.0) */

/**
 * «Ещё» для выделенных треков: всё, что переносит и убирает.
 *
 * Разделение сделано по цене ошибки. Наверху — перенос, он обратим одним движением. Ниже, за
 * отступом и красным цветом, то, что что-то убирает; каждое такое действие уходит в снек с
 * «Вернуть», потому что пачка из сорока треков — это не тот случай, когда человек согласен
 * восстанавливать руками.
 */
@Composable
fun SelectionMenuSheet(
    count: Int,
    inPlaylist: PlaylistEntity?,
    onMove: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onUnsave: () -> Unit,
    onHide: () -> Unit,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Выбрано: $count")
        MenuItem(
            Icons.Filled.PlaylistAdd,
            if (inPlaylist != null) "Перенести в другой плейлист" else "Перенести в плейлист",
            subtitle = if (inPlaylist != null) "Уйдут из «${inPlaylist.name}»"
            else "Из медиатеки в плейлист, без дублей в «Треках»"
        ) { onMove(); onDismiss() }
        if (inPlaylist != null) {
            MenuItem(Icons.Filled.PlaylistRemove, "Убрать из «${inPlaylist.name}»", danger = true) {
                onRemoveFromPlaylist(); onDismiss()
            }
        }
        MenuItem(
            Icons.Filled.CloudOff,
            "Убрать из медиатеки",
            subtitle = "Только для сетевых треков: строка останется в поиске",
            danger = true
        ) { onUnsave(); onDismiss() }
        MenuItem(
            Icons.Filled.VisibilityOff,
            "Убрать из Zizi",
            subtitle = "Файлы на устройстве не трогаем",
            danger = true
        ) { onHide(); onDismiss() }
    }
}

/**
 * Меню папки (6.17.0).
 *
 * Появилось из-за папки «YouTube Music». Она не настоящая: это группировка сетевых треков по
 * источнику, и до 6.17.0 из неё нельзя было ничего достать — только слушать вперемешку. Отсюда
 * содержимое папки уходит в нормальный плейлист.
 */
@Composable
fun FolderMenuSheet(
    folder: String,
    count: Int,
    remote: Boolean,
    onOpenSelection: () -> Unit,
    onMoveAll: () -> Unit,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle(folder)
        MenuItem(Icons.Filled.DoneAll, "Выбрать треки", subtitle = "Отметить нужные и перенести") {
            onOpenSelection(); onDismiss()
        }
        MenuItem(
            Icons.Filled.PlaylistAdd,
            "Перенести всё в плейлист",
            subtitle = if (remote) "Все $count — из папки в плейлист"
            else "Локальные файлы останутся на диске, в плейлист уйдут ссылки на них"
        ) { onMoveAll(); onDismiss() }
    }
}

/* ------------------------------------------------------------------ track menu */

@Composable
fun TrackMenuSheet(
    favorite: Boolean,
    plays: Int,
    sleepMinutesLeft: Int?,
    track: TrackEntity,
    inPlaylist: PlaylistEntity?,
    queueSize: Int,
    download: DownloadStatus,
    onDismiss: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onQueue: () -> Unit,
    onGoToArtist: () -> Unit,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    onRemoveDownload: () -> Unit,
    onInfo: () -> Unit
) {
    val p = LocalPalette.current
    // 6.23.0: этот лист стал ЕДИНСТВЕННОЙ точкой входа во всё, что можно сделать с треком —
    // кнопка «поделиться» из шапки плеера убрана, троеточие переехало на её место. Поэтому
    // порядок пунктов теперь не косметика, а навигация: сверху то, что делают каждый день,
    // ниже то, что делают раз в неделю, в самом низу то, что нельзя отменить.
    ZiziSheetScaffold(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 20,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickAction(
                icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                label = "Избранное",
                active = favorite,
                onClick = onToggleFavorite
            )
            QuickAction(Icons.Filled.PlaylistAdd, "В плейлист", onClick = onAddToPlaylist)
            QuickAction(Icons.Filled.Speed, "Скорость", onClick = onFx)
            // 6.24.0: подпись говорит, что РЕАЛЬНО уйдёт. У скачанного трека уходит файл, у
            // остальных — название: внутренний адрес zizi:// чужому приложению бесполезен.
            // Обещать вложение там, где его нет, хуже, чем честная надпись.
            QuickAction(
                Icons.Filled.Share,
                if (download == DownloadStatus.Done) "Файлом" else "Поделиться",
                onClick = onShare
            )
        }
        Spacer(Modifier.height(14.dp))

        // --- офлайн ---
        DownloadMenuItem(
            status = download,
            onDownload = onDownload,
            onCancel = onCancelDownload,
            onRemove = onRemoveDownload
        )

        // --- очередь ---
        MenuItem(Icons.Filled.QueuePlayNext, "Играть следующим", onClick = onPlayNext)
        MenuItem(Icons.Filled.PlaylistPlay, "Добавить в очередь", onClick = onAddToQueue)
        MenuItem(Icons.Filled.QueueMusic, "Очередь", trailing = if (queueSize > 0) "$queueSize" else null, onClick = onQueue)

        // --- навигация и остальное ---
        if (track.artist.isNotBlank() && track.artist != "—") {
            MenuItem(Icons.Filled.Person, "Перейти к исполнителю", trailing = null, onClick = onGoToArtist)
        }
        MenuItem(Icons.Filled.Bedtime, "Таймер сна", trailing = sleepMinutesLeft?.let { "$it мин" }, onClick = onSleep)
        if (inPlaylist != null) {
            MenuItem(Icons.Filled.PlaylistRemove, "Убрать из «${inPlaylist.name}»", onClick = onRemoveFromPlaylist)
        }
        MenuItem(
            icon = Icons.Filled.Info,
            label = "Сведения о треке",
            trailing = if (plays > 0) "$plays" else null,
            onClick = onInfo
        )

        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(Icons.Filled.DeleteOutline, "Убрать из Zizi", tint = Color(0xFFFF8A8A), onClick = onHide)
        // Удалить можно только то, что действительно лежит файлом на устройстве.
        if (!track.isRemote) {
            MenuItem(Icons.Filled.DeleteForever, "Удалить файл с устройства", tint = Color(0xFFFF5555), onClick = onDeleteFile)
        }
    }
}

/**
 * «Сведения о треке».
 *
 * Ровно те факты, которые нельзя увидеть на экране плеера, и ни одного придуманного: источник,
 * длительность, размер, папка, счётчик прослушиваний. Пустые поля не показываются — строка
 * «Альбом: —» это шум, а не информация.
 */
@Composable
fun TrackInfoSheet(
    track: TrackEntity,
    plays: Int,
    downloaded: Boolean,
    streamLabel: String?,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Сведения о треке", track.title)
        InfoRow("Исполнитель", track.artist)
        if (track.album.isNotBlank()) InfoRow("Альбом", track.album)
        InfoRow("Источник", if (track.isRemote) (track.provider ?: "сеть") else "файл на устройстве")
        if (track.isRemote && streamLabel != null) InfoRow("Поток", streamLabel)
        if (track.isRemote) InfoRow("Офлайн", if (downloaded) "скачан" else "только из сети")
        InfoRow("Длительность", formatTime(track.durationMs))
        if (track.sizeBytes > 0) InfoRow("Размер", "%.1f МБ".format(track.sizeBytes / 1024f / 1024f))
        if (!track.isRemote) InfoRow("Папка", track.sourceFolder)
        InfoRow("Прослушан", "$plays раз")
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = p.subtext, fontSize = 14.sp, modifier = Modifier.width(120.dp))
        Text(value, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Круглая кнопка быстрого действия. Подпись — часть кнопки, а не пояснение:
 * пояснительные строки («Файл останется на устройстве…», «прослушан N раз») убраны целиком.
 */
@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(if (active) p.accent.copy(alpha = 0.22f) else p.chip.copy(alpha = 0.75f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (active) p.accent else p.text, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = if (active) p.accent else p.subtext, fontSize = 11.sp, maxLines = 1)
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    tracks: List<TrackEntity>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPick: (String) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        // The queue opens straight at the track that is playing instead of at the top.
        val queueState = rememberLazyListState()
        // Same rule as the library list: while the finger moves, background indexing stands still.
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.isScrollInProgress }.collectLatest { scrolling ->
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
        }
        LaunchedEffect(currentTrackId) {
            val index = tracks.indexOfFirst { it.id == currentTrackId }
            if (index > 1) queueState.scrollToItem((index - 1).coerceAtLeast(0))
        }
        LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = maxHeight),
            state = queueState
        ) {
            itemsIndexed(
                tracks,
                key = { _, item -> item.id },
                // A declared contentType lets the lazy layout reuse a row's whole subtree instead of
                // building a new one, and the fixed height below means no row is ever re-measured.
                contentType = { _, _ -> "queue" }
            ) { _, track ->
                val playing = track.id == currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clickable { onPick(track.id) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                        )
                        // 6.14.0: третья копия того же маркера убрана — здесь `playing` значит
                        // «эта строка и есть текущий трек», а `isPlaying` — играет ли он сейчас.
                        NowPlayingBadge(
                            current = playing,
                            playing = isPlaying,
                            size = 48.dp,
                            corner = 8.dp,
                            barSize = 17.dp
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

/**
 * A titled card. The old settings screen was one flat stream of 14 rows, dividers and radio
 * buttons - everything at the same visual weight, which is exactly why it read as "thrown
 * together". Now every row lives in a group with a heading, and the group is a card.
 */
@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        text = title.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 26.dp, top = 16.dp, bottom = 8.dp)
    )
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.chip.copy(alpha = 0.38f))
            .padding(vertical = 4.dp),
        content = content
    )
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    label: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
    /** 6.17.0: нужен строке «О приложении» — там долгое нажатие это единственный вход. */
    onLongClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .then(
                when {
                    onLongClick != null -> Modifier.combinedClickable(
                        onClick = { onClick?.invoke() },
                        onLongClick = onLongClick
                    )
                    onClick != null -> Modifier.clickable(onClick = onClick)
                    else -> Modifier
                }
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) {
                Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, label: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    SettingRow(
        icon = icon,
        label = label,
        subtitle = subtitle,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }
    )
}

@Composable
fun SettingsSheet(vm: MainViewModel, state: LibraryUiState, onDismiss: () -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    var sortOpen by remember { mutableStateOf(false) }
    // 6.19.0: подтверждение отключения папки. rememberSaveable — лист настроек живёт через
    // системный диалог выбора папки и через поворот экрана.
    var confirmRemoveFolder by rememberSaveable { mutableStateOf<String?>(null) }
    // 6.24.0: снос всех загрузок — операция без отмены, поэтому только через подтверждение.
    var confirmWipeDownloads by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val themeNames = remember {
        mapOf(
            AppTheme.GRAPHITE to "Графит",
            AppTheme.MIDNIGHT to "Полночь",
            AppTheme.AMOLED to "AMOLED",
            AppTheme.SUNSET to "Закат"
        )
    }
    val sortNames = remember {
        mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Настройки", "${state.tracks.size} треков в библиотеке")

        SettingsGroup("Оформление") {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppTheme.entries.forEach { theme ->
                    val active = state.settings.theme == theme
                    val preview = remember(theme) { basePalette(theme) }
                    Column(
                        Modifier
                            .width(76.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) p.accent.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable { vm.setTheme(theme) }
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(preview.background)
                                .then(
                                    if (active) Modifier.border(1.5.dp, p.accent, RoundedCornerShape(10.dp))
                                    else Modifier
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            themeNames[theme] ?: theme.name,
                            color = if (active) p.accent else p.subtext,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }
            }
            SettingSwitch(
                icon = Icons.Filled.Palette,
                label = "Цвет из обложки",
                subtitle = "Фон повторяет оттенки текущей обложки",
                checked = state.settings.accentFromArtwork,
                onChange = vm::setDynamicAccent
            )
        }

        SettingsGroup("Библиотека") {
            SettingRow(
                icon = Icons.Filled.SortByAlpha,
                label = "Сортировка",
                subtitle = sortNames[state.settings.sortMode],
                trailing = {
                    Icon(
                        if (sortOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = null,
                        tint = p.subtext,
                        modifier = Modifier.size(22.dp)
                    )
                },
                onClick = { sortOpen = !sortOpen }
            )
            if (sortOpen) {
                SortMode.entries.forEach { mode ->
                    val active = state.settings.sortMode == mode
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.setSortMode(mode) }
                            .padding(start = 60.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            sortNames[mode] ?: mode.name,
                            color = if (active) p.accent else p.text,
                            fontSize = 14.5.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (active) Icon(Icons.Filled.Check, null, tint = p.accent, modifier = Modifier.size(19.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
            SettingRow(
                icon = Icons.Filled.CreateNewFolder,
                label = "Добавить папку с музыкой",
                subtitle = if (state.settings.folderUris.isEmpty()) "Ничего не подключено"
                else "Подключено: ${state.settings.folderUris.size}",
                onClick = onPickFolder
            )
            state.settings.folderUris.forEach { uri ->
                Row(
                    Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uri.substringAfterLast("/").ifBlank { uri },
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(10.dp))
                            // 6.19.0: подтверждение и здесь. Крестик 30 dp в плотном списке —
                            // это промах в одно касание, а последствие то же, что в медиатеке.
                            .clickable { confirmRemoveFolder = uri },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Close, null, tint = p.subtext, modifier = Modifier.size(16.dp)) }
                }
            }
            SettingRow(
                icon = Icons.Filled.Refresh,
                label = "Пересканировать",
                subtitle = if (state.scanning) "Идёт сканирование…" else "Найдено ${state.tracks.size} треков",
                onClick = vm::rescan
            )
            if (state.hiddenCount > 0) {
                SettingRow(
                    icon = Icons.Filled.Visibility,
                    label = "Вернуть скрытые треки",
                    subtitle = "Скрыто: ${state.hiddenCount}",
                    onClick = vm::restoreAllHidden
                )
            }
        }

        NetworkCatalogGroup(vm, state)

        confirmRemoveFolder?.let { folderUri ->
            ConfirmDialog(
                title = "Отключить папку?",
                message = "Треки из «" + android.net.Uri.decode(folderUri).substringAfterLast('/') +
                    "» исчезнут из медиатеки. Сами файлы останутся на месте.",
                confirm = "Отключить",
                onConfirm = { vm.removeFolder(folderUri); confirmRemoveFolder = null },
                onDismiss = { confirmRemoveFolder = null }
            )
        }

        SettingsGroup("Загрузки") {
            SettingRow(
                icon = Icons.Filled.DownloadDone,
                label = "Скачанные треки",
                subtitle = vm.downloadsLabel()
            )
            if (vm.downloadsCount() > 0) {
                SettingRow(
                    icon = Icons.Filled.DeleteSweep,
                    label = "Удалить все загрузки",
                    subtitle = "Файлы из «Музыка/Zizi» будут удалены с устройства",
                    tint = DANGER,
                    onClick = { confirmWipeDownloads = true }
                )
            }
        }
        if (confirmWipeDownloads) {
            ConfirmDialog(
                title = "Удалить все загрузки?",
                message = "Скачанные файлы из «Музыка/Zizi» будут удалены. Сами треки останутся " +
                    "в библиотеке и снова будут играть из сети.",
                confirm = "Удалить",
                onConfirm = { vm.removeAllDownloads(); confirmWipeDownloads = false },
                onDismiss = { confirmWipeDownloads = false }
            )
        }

        SettingsGroup("Звук") {
            SettingSwitch(
                icon = Icons.Filled.GraphicEq,
                label = "Пропускать тишину",
                subtitle = "Убирает паузы в начале и в конце трека",
                checked = state.settings.skipSilence,
                onChange = vm::setSkipSilence
            )
        }

        // СЛУЖЕБНЫЙ ДОСТУП (6.17.0, вместо семи тапов из 6.11.0).
        //
        // Семь тапов по строке версии человек делает сам, из любопытства, и именно так тестер
        // и попал в технические настройки. Секрет переехал из жеста в код (см. data/DevAccess):
        // долгое нажатие лишь ПРЕДЛАГАЕТ ввести код, а без вшитого при сборке хеша не открывает
        // вообще ничего. Подсказок в интерфейсе нет ни одной — ни счётчика, ни «ещё N…».
        val devUnlocked by vm.devUnlocked.collectAsStateWithLifecycle()
        var askCode by remember { mutableStateOf(false) }
        SettingsGroup("О приложении") {
            SettingRow(
                icon = Icons.Filled.Info,
                label = "ZiziPlayer",
                subtitle = if (devUnlocked)
                    "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · служебный доступ открыт"
                else "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · Media3 · Compose",
                // Обычный тап не делает НИЧЕГО — строка справочная, и такой она и должна выглядеть.
                onLongClick = {
                    if (devUnlocked) vm.lockDev() else if (DevAccess.unlockable) askCode = true
                }
            )
            if (devUnlocked) {
                SettingRow(
                    icon = Icons.Filled.LockOpen,
                    label = "Закрыть служебный доступ",
                    subtitle = "Сам закроется через 15 минут и при перезапуске приложения",
                    onClick = vm::lockDev
                )
            }
            /**
             * 6.24.0: отчёт о последнем сбое.
             *
             * Строка появляется ТОЛЬКО если приложение действительно падало. До этой версии
             * единственным источником данных о вылете был рассказ человека «нажал и вылетело»,
             * по которому причину приходится угадывать — а угаданная причина лечится заплаткой,
             * а не ремонтом. Здесь лежит стек: одно нажатие, и он уходит текстом куда угодно.
             */
            val crash = vm.crashReport()
            if (crash != null) {
                SettingRow(
                    icon = Icons.Filled.BugReport,
                    label = "Отчёт о последнем сбое",
                    subtitle = "Отправить и очистить",
                    tint = DANGER,
                    onClick = {
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_SUBJECT, "ZiziPlayer: сбой")
                            putExtra(android.content.Intent.EXTRA_TEXT, crash)
                        }
                        runCatching { context.startActivity(android.content.Intent.createChooser(send, "Отчёт о сбое")) }
                        vm.clearCrashReport()
                    }
                )
            }
        }
        if (askCode) {
            DevCodeDialog(
                onConfirm = { code ->
                    askCode = false
                    // Результат наружу не сообщается: неверный код выглядит ровно так же, как
                    // закрытый диалог. Подбирать что-либо, не видя реакции, бессмысленно.
                    vm.unlockDev(code)
                },
                onDismiss = { askCode = false }
            )
        }
        Spacer(Modifier.height(6.dp))
    }
}

/**
 * Ввод служебного кода (6.17.0).
 *
 * Ни счётчика попыток, ни «неверный код», ни разной задержки — снаружи все исходы выглядят
 * одинаково. Тот, кто код знает, войдёт с первого раза; тому, кто не знает, интерфейс не поможет.
 */
@Composable
private fun DevCodeDialog(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var code by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text("Служебный доступ", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Только для разработки. Доступ закроется через 15 минут.", fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                        focusedBorderColor = p.accent,
                        unfocusedBorderColor = p.chip,
                        cursorColor = p.accent
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(code) }) { Text("Открыть", color = p.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/* ------------------------------------------------------------------ confirm */

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = DANGER, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    title: String = "Переименовать",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.accent,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Готово", color = p.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/**
 * The report, in full, on a screen you can read and in a form you can paste.
 *
 * Three properties, and every one of them is a lesson from 6.8.0: it does not truncate (each client
 * gets its own line, wrapped, not ellipsised), it scrolls (eight clients plus a header do not fit on
 * a phone), and it copies (a screenshot of a wrapped Russian sentence is not a bug report - the
 * verbatim status string is).
 */
@Composable
private fun StreamReportDialog(lines: List<String>, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    val text = lines.joinToString("\n")
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Диагностика потока", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                lines.forEach { line ->
                    Text(
                        text = line,
                        color = if (line.contains("HTTP 2")) p.text else p.subtext,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) {
                Text("Скопировать", color = p.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = p.text) } }
    )
}

/**
 * Network catalogue settings, plus the connection probe.
 *
 * The probe is not a debug leftover: this section talks to a private API that is guaranteed to break
 * eventually, and when it does, the difference between "поиск не работает" and a message naming the
 * provider and the exact refusal is the difference between a patch and a guessing game. It stays.
 */
/**
 * The four rows a listener actually has decisions to make about. Shared by both variants of the
 * group so that hiding the technical part cannot silently drop them.
 */
@Composable
private fun ColumnScope.StreamUserRows(vm: MainViewModel, settings: app.ziziplayer.data.UserSettings) {
    SettingSwitch(
        icon = Icons.Filled.Wifi,
        label = "Только Wi-Fi",
        subtitle = "Не тратить мобильный трафик на потоки",
        checked = settings.wifiOnly,
        onChange = vm::setWifiOnly
    )
    SettingRow(
        icon = Icons.Filled.GraphicEq,
        label = "Качество потока",
        subtitle = when (settings.streamQuality) {
            RemoteQuality.LOW -> "Экономно, около 64 кбит/с"
            RemoteQuality.NORMAL -> "Обычное, около 128 кбит/с"
            RemoteQuality.HIGH -> "Высокое, около 256 кбит/с"
        },
        onClick = vm::cycleStreamQuality
    )
    SettingSwitch(
        icon = Icons.Filled.Storage,
        label = "Кэшировать потоки",
        subtitle = "До ${settings.streamCacheMb} МБ: мгновенная перемотка и повтор без трафика",
        checked = settings.streamCacheEnabled,
        onChange = vm::setStreamCacheEnabled
    )
    SettingRow(
        icon = Icons.Filled.DeleteSweep,
        label = "Очистить кэш потоков",
        subtitle = vm.streamCacheLabel(),
        onClick = vm::clearStreamCache
    )
}

@Composable
private fun NetworkCatalogGroup(vm: MainViewModel, state: LibraryUiState) {
    val probe by vm.catalogProbe.collectAsState()
    val report by vm.streamReport.collectAsState()
    val reportRunning by vm.reportRunning.collectAsState()
    val resolverStatus by vm.resolverStatus.collectAsState()
    val settings = state.settings
    // Hoisted next to the report dialog for the same reason: the group recomposes while a probe runs.
    var resolverUrlDialog by remember { mutableStateOf(false) }
    var resolverTokenDialog by remember { mutableStateOf(false) }

    if (resolverUrlDialog) {
        RenameDialog(
            initial = settings.resolverUrl,
            title = "Адрес резолвера",
            onConfirm = { value -> vm.setResolverUrl(value); resolverUrlDialog = false },
            onDismiss = { resolverUrlDialog = false }
        )
    }
    if (resolverTokenDialog) {
        RenameDialog(
            initial = settings.resolverToken,
            title = "Токен резолвера",
            onConfirm = { value -> vm.setResolverToken(value); resolverTokenDialog = false },
            onDismiss = { resolverTokenDialog = false }
        )
    }

    // The dialog is hoisted here so it survives the group recomposing while the report runs.
    report?.let { lines ->
        StreamReportDialog(lines = lines, onDismiss = vm::dismissStreamReport)
    }

    // 6.11.0 — две разные группы вместо одной.
    //
    // Пользователю нужны четыре решения: качество, мобильный трафик, кэш, очистка. Всё остальное в
    // этой группе появилось из отладки бот-чека и гео-блока и для него бессмысленно: адрес сервера
    // и токен теперь вшиты в сборку (BuildConfig.RESOLVER_URL / RESOLVER_TOKEN), а диагностика
    // открывается семью тапами по версии.
    // 6.17.0: гейт — сессия служебного доступа, а не сохранённая настройка.
    val devUnlocked by vm.devUnlocked.collectAsStateWithLifecycle()
    if (!devUnlocked) {
        SettingsGroup("Поток из сети") {
            StreamUserRows(vm, settings)
        }
        return
    }

    SettingsGroup("Сетевой каталог") {
        /*
         * OWN RESOLVER (6.10.0) — first rows of the group, because this is now the main path.
         *
         * 6.9.4 diagnostics: eight internal YouTube clients, both host families, valid poToken,
         * LOGIN_REQUIRED eight times out of eight. The same track answered on the first try when
         * yt-dlp asked from a VPS. Attestation cannot be passed by an APK Google did not sign, so
         * the resolve moved to a machine that has Python, a JS engine and daily yt-dlp updates.
         * Search stays on Innertube: it never broke, it is not attested.
         */
        SettingRow(
            icon = Icons.Filled.Dns,
            label = "Свой резолвер",
            subtitle = if (settings.resolverUrl.isBlank())
                "Не задан — поток берётся у YouTube напрямую (не работает: бот-чек)"
            else settings.resolverUrl,
            onClick = { resolverUrlDialog = true }
        )
        if (settings.resolverUrl.isNotBlank()) {
            SettingRow(
                icon = Icons.Filled.Key,
                label = "Токен резолвера",
                // 6.17.0: длина токена больше не показывается — это подсказка тому, кто её видеть
                // не должен, а владельцу она не нужна: он и так знает, что вписал.
                subtitle = if (settings.resolverToken.isBlank()) "Не задан — сервер ответит 401"
                    else "Задан (нажми, чтобы заменить)",
                onClick = { resolverTokenDialog = true }
            )
            SettingSwitch(
                icon = Icons.Filled.CloudDownload,
                label = "Гнать звук через сервер",
                subtitle = "Вкл: /stream, ссылка не привязана к IP телефона. Выкл: прямая ссылка, трафик мимо сервера",
                checked = settings.resolverProxy,
                onChange = vm::setResolverProxy
            )
            SettingRow(
                icon = Icons.Filled.NetworkCheck,
                label = "Проверить сервер",
                subtitle = resolverStatus ?: "Спросит /health: живой ли сервис и сколько в кэше",
                onClick = vm::probeResolver
            )
        }
        SettingRow(
            icon = Icons.Filled.Language,
            label = "Источник",
            subtitle = if (settings.catalogProvider == "yt") "YouTube Music" else "Audius",
            onClick = { vm.setCatalogProvider(if (settings.catalogProvider == "yt") "audius" else "yt") }
        )
        StreamUserRows(vm, settings)
        // What is playing, in provider terms.
        //
        // Not a debug leftover either: the stream is produced by picking one of five internal
        // YouTube clients at runtime, and which one survives is decided by attestation, not by us.
        // When playback breaks, the first question is always "which client answered" - this row is
        // the answer, without a build, a log or a cable.
        vm.streamStatusLabel()?.let { status ->
            SettingRow(
                icon = Icons.Filled.GraphicEq,
                label = "Активный поток",
                subtitle = status,
                onClick = {}
            )
        }
        SettingRow(
            icon = Icons.Filled.Search,
            label = "Проверить подключение",
            subtitle = probe ?: "Спросит у источника «phonk» и покажет, что он ответил",
            onClick = { vm.probeCatalog() }
        )
        if (probe != null) {
            // The row that finds the 403.
            //
            // "Проверить подключение" proves the catalogue parses; it says nothing about whether
            // the URL it produced can be fetched, and that is precisely where YouTube failed in
            // 6.6.0 - search fine, resolve fine, GET refused. This asks the CDN for two bytes and
            // prints the client that answered plus the HTTP code, which turns "треки сами
            // свайпаются" into one line naming one layer.
            SettingRow(
                icon = Icons.Filled.NetworkCheck,
                label = "Проверить поток",
                subtitle = "Резолвит первый трек и запрашивает 2 байта с CDN",
                onClick = vm::probeStream
            )
            // FULL DIAGNOSTICS (6.8.1).
            //
            // "Проверить поток" answers with the LAST client's complaint, in a two line subtitle,
            // which is how `LOGIN_REQUIRED «Войдите, чтобы подтвердить, что вы не робот»` reached
            // the user as `ANDROID_VR: Войдите в` and cost a release. This walks every internal
            // client and opens the result in a dialog that can be copied out whole.
            SettingRow(
                icon = Icons.Filled.BugReport,
                label = if (reportRunning) "Опрашиваю клиентов…" else "Полная диагностика потока",
                subtitle = "Все клиенты YouTube по очереди, с копированием отчёта",
                onClick = { vm.runStreamReport() }
            )
            SettingRow(
                icon = Icons.Filled.PlayArrow,
                label = "Включить найденное",
                subtitle = "Полный тракт: резолв ссылки, кэш, декодер",
                onClick = vm::playProbeResults
            )
        }
    }
}
