package app.ziziplayer.playback

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * Скачивание трека целиком — 6.24.0, переписано.
 *
 * Что было до: [androidx.media3.datasource.cache.CacheWriter] наполнял SimpleCache в `filesDir`.
 * Байты на диске есть, файла нет; «Поделиться» отдавать нечего, в файловом менеджере ничего не
 * видно, при переустановке всё пропадает. Подробный разбор — в шапке [OfflineStore].
 *
 * Что стало: те же байты по той же цепочке (резолвер `zizi://` → OkHttp каталога, то есть весь
 * поворот клиентов, прокси и повтор на 403 достаются бесплатно), но пишутся в один настоящий
 * файл в «Музыка/Zizi» через [OfflineStore]. Плюс к этому:
 *
 *  - не больше двух загрузок одновременно, остальные честно показываются как «в очереди»;
 *  - пока что-то качается, живёт [DownloadService] — foreground-уведомление с процентом и
 *    отменой. Свернуть приложение и убрать его из недавних больше не значит «потерять загрузку»;
 *  - прогресс публикуется не чаще, чем раз в 120 мс. Раньше [CacheWriter] дёргал StateFlow на
 *    каждый блок, то есть десятки перерисовок меню в секунду ради цифры, которая меняется на
 *    единицу — именно это и выглядело как «дёргается»;
 *  - расширение и MIME определяются по первым байтам ([AudioFormatSniffer]), а не по надежде.
 *
 * Отмена по-прежнему закрывает источник руками: `read()` блокирующий, отмена корутины сама его
 * не прерывает, и без этого поток докачивал бы трек в никуда.
 */
@UnstableApi
object OfflineDownloads {

    private const val MAX_PARALLEL = 2
    private const val BUFFER_BYTES = 64 * 1024
    private const val PROGRESS_MIN_GAP_MS = 120L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Semaphore(MAX_PARALLEL)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val readers = ConcurrentHashMap<String, DataSource>()
    /** Кто остановлен пользователем: отличает «нажал отмену» от «оборвалась связь». */
    private val cancelled: MutableSet<String> = Collections.synchronizedSet(HashSet())

    private val _states = MutableStateFlow<Map<String, DownloadStatus>>(emptyMap())
    /** Только «живые» состояния: в очереди / качается / только что упало. Остальное — с диска. */
    val states: StateFlow<Map<String, DownloadStatus>> = _states

    /** Сколько загрузок ещё не закончилось. Читает [DownloadService] для своего уведомления. */
    fun activeCount(): Int = _states.value.values.count {
        it is DownloadStatus.Running || it is DownloadStatus.Queued
    }

    /** Дёшево и синхронно: индекс в памяти плюс одна проверка существования файла. */
    fun statusOf(context: Context, track: TrackEntity): DownloadStatus {
        if (!RemoteUri.isRemote(track.uri)) return DownloadStatus.Local
        _states.value[track.id]?.let { return it }
        return if (OfflineStore.isDownloaded(context, track)) DownloadStatus.Done else DownloadStatus.None
    }

    fun isComplete(context: Context, track: TrackEntity): Boolean =
        RemoteUri.isRemote(track.uri) && OfflineStore.isDownloaded(context, track)

    fun start(context: Context, track: TrackEntity) {
        if (!RemoteUri.isRemote(track.uri)) return
        if (jobs.containsKey(track.id)) return
        val app = context.applicationContext
        if (OfflineStore.isDownloaded(app, track)) { publish(track.id, DownloadStatus.Done); return }
        if (OfflineStore.needsLegacyPermission(app)) {
            publish(track.id, DownloadStatus.Failed("нужен доступ к памяти в настройках Android"))
            return
        }
        cancelled.remove(track.id)
        // Сразу «в очереди», ещё до захвата разрешения: тап обязан немедленно что-то изменить
        // на экране, иначе человек жмёт второй раз.
        publish(track.id, DownloadStatus.Queued)
        DownloadService.start(app)
        val job = scope.launch {
            try {
                gate.withPermit { download(app, track) }
            } finally {
                jobs.remove(track.id)
            }
        }
        jobs[track.id] = job
    }

    private suspend fun download(context: Context, track: TrackEntity) {
        if (cancelled.contains(track.id)) { clear(track.id); return }
        publish(track.id, DownloadStatus.Running(-1))
        var pending: OfflineStore.Pending? = null
        var source: DataSource? = null
        try {
            source = ZiziDataSources.resolvingFactory(context).createDataSource()
            readers[track.id] = source
            val length = source.open(DataSpec.Builder().setUri(Uri.parse(track.uri)).build())
            val buffer = ByteArray(BUFFER_BYTES)
            var total = 0L
            var lastPublishAt = 0L
            while (currentCoroutineContext().isActive) {
                val read = source.read(buffer, 0, buffer.size)
                if (read == C.RESULT_END_OF_INPUT) break
                if (read <= 0) continue
                if (pending == null) {
                    // Цель создаётся ПОСЛЕ первого блока: до него неизвестно, чем окажется файл,
                    // а строка в «Музыке» с неправильным расширением — это чужой плеер, который
                    // не смог его открыть.
                    val format = AudioFormatSniffer.of(buffer, read)
                    pending = OfflineStore.create(context, track, format.mime, format.extension)
                }
                pending.stream.write(buffer, 0, read)
                total += read
                val now = SystemClock.elapsedRealtime()
                if (now - lastPublishAt >= PROGRESS_MIN_GAP_MS) {
                    lastPublishAt = now
                    val percent = if (length > 0L) ((total * 100L) / length).toInt().coerceIn(0, 99) else -1
                    publish(track.id, DownloadStatus.Running(percent, total))
                }
            }
            if (!currentCoroutineContext().isActive || cancelled.contains(track.id)) {
                OfflineStore.abandon(context, pending)
                clear(track.id)
                return
            }
            if (pending == null || total <= 0L) throw IOException("источник отдал пустой поток")
            OfflineStore.publish(context, track, pending, total)
            publish(track.id, DownloadStatus.Running(100, total))
            publish(track.id, DownloadStatus.Done)
        } catch (cancel: CancellationException) {
            OfflineStore.abandon(context, pending)
            clear(track.id)
            throw cancel
        } catch (error: Throwable) {
            OfflineStore.abandon(context, pending)
            // Закрытый руками источник роняет read() обычным IOException — это отмена, не сбой.
            if (cancelled.remove(track.id)) clear(track.id)
            else publish(track.id, DownloadStatus.Failed(shortReason(error)))
        } finally {
            readers.remove(track.id)
            runCatching { source?.close() }
        }
    }

    fun cancel(trackId: String) {
        cancelled.add(trackId)
        // Порядок важен: сначала источник (он выбьет блокирующее чтение), потом корутина.
        // Наоборот — поток остался бы качать в никуда.
        runCatching { readers.remove(trackId)?.close() }
        jobs.remove(trackId)?.cancel()
        clear(trackId)
    }

    fun cancelAll() {
        (jobs.keys.toList() + _states.value.keys.toList()).distinct().forEach { cancel(it) }
    }

    /** «Удалить загрузку»: файл уходит, трек остаётся в библиотеке и играет из сети. */
    fun remove(context: Context, track: TrackEntity) {
        cancel(track.id)
        OfflineStore.delete(context.applicationContext, track.id)
        clear(track.id)
    }

    fun removeAll(context: Context) {
        cancelAll()
        OfflineStore.deleteAll(context.applicationContext)
        _states.value = emptyMap()
    }

    private fun shortReason(error: Throwable): String = when {
        error.message?.contains("403") == true -> "источник отказал, попробуй ещё раз"
        error.message?.contains("Музык") == true -> error.message!!
        error is IOException -> "нет связи"
        else -> "не удалось скачать"
    }

    private fun publish(id: String, status: DownloadStatus) = _states.update { it + (id to status) }

    private fun clear(id: String) = _states.update { it - id }
}
