package app.ziziplayer.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Insets
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.DisplayCutout
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asComposePath
import androidx.test.filters.SdkSuppress
import app.ziziplayer.ui.components.cameraCutoutSnapshot
import app.ziziplayer.ui.components.cameraMorphSafetyPath
import org.junit.Assert.*
import org.junit.Test

/** Android adapter + real Android path rasterization. GPU is tested separately. */
@SdkSuppress(minSdkVersion = 28)
class CameraNotch6702Test {
    @Suppress("DEPRECATION")
    private fun rect(vararg bounds: Rect) = DisplayCutout(Rect(0, 96, 0, 0), bounds.toList())

    @Test fun rectOnlyUNotchGetsCompactBottomEmitter() {
        val result = cameraCutoutSnapshot(rect(Rect(468, 0, 612, 72)), 1080, 2400, 96, 3f)
        assertTrue(result.topAttached)
        assertFalse(result.exact)
        val t = requireNotNull(result.target)
        assertEquals(72f, t.width(), 0f)
        assertEquals(72f, t.bottom, 0f)
        assertEquals(540f, t.cx(), 0f)
        assertNotNull(result.outline)
        assertTrue(result.report().contains("Приближённое"))
        assertEquals(144f, requireNotNull(result.physicalBounds).width(), 0f)
    }

    @Test fun tallRectReservationRetainsExistingHoleEstimate() {
        val result = cameraCutoutSnapshot(rect(Rect(510, 0, 570, 96)), 1080, 2400, 96, 3f)
        assertFalse(result.topAttached)
        assertFalse(result.exact)
        assertEquals(60f, requireNotNull(result.target).width(), 0f)
        assertEquals(96f, requireNotNull(result.target).bottom, 0f)
    }

    @Test fun absentBroadShiftedAndMultipleRectsStaySafe() {
        assertNull(cameraCutoutSnapshot(null, 1080, 2400, 96, 3f).target)
        assertNull(cameraCutoutSnapshot(rect(Rect(0, 0, 1080, 96)), 1080, 2400, 96, 3f).target)
        val c = rect(Rect(468, 0, 612, 72))
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 96, 3f, screenY = 1).target)
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 96, 3f, multiWindow = true).target)
        assertNull(cameraCutoutSnapshot(c, 2400, 1080, 96, 3f).target)
        assertNull(cameraCutoutSnapshot(c, 1080, 2400, 0, 3f).target)
        assertNull(cameraCutoutSnapshot(rect(Rect(468, 0, 612, 72), Rect(48, 0, 96, 72)),
            1080, 2400, 96, 3f).target)
    }

    @Test
    @SdkSuppress(minSdkVersion = 33)
    fun exactVNotchUsesActualBottomInsteadOfBoundingBoxCentre() {
        val path = Path().apply {
            moveTo(468f, 0f); lineTo(612f, 0f); lineTo(555f, 72f); close()
        }
        val cutout = DisplayCutout.Builder().setSafeInsets(Insets.of(0, 96, 0, 0))
            .setBoundingRectTop(Rect(468, 0, 612, 72)).setCutoutPath(path).build()
        val original = requireNotNull(cutout.cutoutPath).approximate(.1f)
        repeat(3) {
            val result = cameraCutoutSnapshot(cutout, 1080, 2400, 96, 3f)
            assertTrue(result.exact)
            assertTrue(result.topAttached)
            assertEquals(555f, requireNotNull(result.target).cx(), 1f)
            assertEquals(72f, requireNotNull(result.target).bottom, .01f)
            val box = RectF().also { requireNotNull(result.outline).asAndroidPath().computeBounds(it, true) }
            assertEquals(144f, box.width(), .01f)
        }
        assertArrayEquals(original, requireNotNull(cutout.cutoutPath).approximate(.1f), 0f)
    }

    @Test
    @SdkSuppress(minSdkVersion = 33)
    fun exactUNotchIsNotReplacedWithDetachedOval() {
        val path = Path().apply {
            moveTo(420f, 0f); lineTo(660f, 0f)
            cubicTo(660f, 72f, 600f, 84f, 540f, 84f)
            cubicTo(480f, 84f, 420f, 72f, 420f, 0f); close()
        }
        val cutout = DisplayCutout.Builder().setSafeInsets(Insets.of(0, 96, 0, 0))
            .setBoundingRectTop(Rect(420, 0, 660, 84)).setCutoutPath(path).build()
        val result = cameraCutoutSnapshot(cutout, 1080, 2400, 96, 3f)
        assertTrue(result.exact)
        assertTrue(result.topAttached)
        assertEquals(84f, requireNotNull(result.target).width(), .01f)
        assertEquals(540f, requireNotNull(result.target).cx(), 1f)
        assertEquals(240f, requireNotNull(result.physicalBounds).width(), .01f)
    }

    @Test fun physicalSafetyMaskDoesNotPaintNotchShouldersInEitherRenderer() {
        val t = CameraMorphGeometry.Target(42f, 0f, 78f, 36f)
        for (legacy in listOf(false, true)) for (reverse in listOf(false, true)) {
            val outline = Path().apply {
                moveTo(24f, 0f)
                if (reverse) { lineTo(60f, 36f); lineTo(96f, 0f) }
                else { lineTo(96f, 0f); lineTo(60f, 36f) }
                close()
            }.asComposePath()
            val safe = cameraMorphSafetyPath(120f, 200f, 48f, t, outline, true, legacy, 1f)
            val bitmap = Bitmap.createBitmap(120, 200, Bitmap.Config.ARGB_8888)
            try {
                Canvas(bitmap).drawPath(safe.asAndroidPath(), Paint().apply { color = android.graphics.Color.BLACK })
                assertEquals("Outside physical V must stay transparent", 0, bitmap.getPixel(40, 30))
                assertEquals("Other shoulder must stay transparent", 0, bitmap.getPixel(80, 30))
                assertEquals(android.graphics.Color.BLACK, bitmap.getPixel(60, 25))
                assertEquals("Free bridge below the notch", android.graphics.Color.BLACK, bitmap.getPixel(60, 40))
                assertEquals("Artwork remains unclipped below the tip", android.graphics.Color.BLACK, bitmap.getPixel(5, 50))
            } finally { bitmap.recycle() }
        }
    }

    @Test
    @SdkSuppress(minSdkVersion = 33)
    fun exactTallReservationRetainsHoleMode6703() {
        // Some OEMs expose the top-to-camera reservation as a system Path as well.
        // 6.70.2 incorrectly opted those existing holes into the new notch pipeline.
        for (left in listOf(30, 510, 990)) {
            val raw = Rect(left, 0, left + 60, 110)
            val path = Path().apply { addRect(RectF(raw), Path.Direction.CW) }
            val cutout = DisplayCutout.Builder().setSafeInsets(Insets.of(0, 110, 0, 0))
                .setBoundingRectTop(raw).setCutoutPath(path).build()
            val result = cameraCutoutSnapshot(cutout, 1080, 2400, 110, 3f)
            assertLegacyHole6703(result, left.toFloat())
        }
    }

    @Test
    @SdkSuppress(minSdkVersion = 33)
    fun unsupportedExactDetachedPathRetainsHoleFallback6703() {
        // A narrow exact contour can fail supported() even though its raw reservation
        // was handled correctly in 6.70.1. It must not become a null target in 6.70.3.
        val path = Path().apply { addOval(525f, 12f, 555f, 90f, Path.Direction.CW) }
        val cutout = DisplayCutout.Builder().setSafeInsets(Insets.of(0, 110, 0, 0))
            .setBoundingRectTop(Rect(510, 0, 570, 110)).setCutoutPath(path).build()
        val result = cameraCutoutSnapshot(cutout, 1080, 2400, 110, 3f)
        assertLegacyHole6703(result, 510f)
    }

    private fun assertLegacyHole6703(result: app.ziziplayer.ui.components.CameraCutoutSnapshot,
        left: Float) {
        assertFalse("Do not opt existing holes into notch blur/clip", result.topAttached)
        assertFalse("Reservation remains explicitly approximate", result.exact)
        assertNull(result.physicalBounds)
        val target = requireNotNull(result.target)
        assertEquals(left, target.left, 0f)
        assertEquals(left + 60f, target.right, 0f)
        assertEquals(50f, target.top, 0f)
        assertEquals(110f, target.bottom, 0f)
        val expected = Path().apply { addOval(left, 50f, left + 60f, 110f, Path.Direction.CW) }
        val actual = requireNotNull(result.outline).asAndroidPath()
        val mismatch = Path(actual)
        assertTrue(mismatch.op(expected, Path.Op.XOR))
        assertTrue("Restore the old oval, not the OEM reservation strip", mismatch.isEmpty)
        val reference = CameraMorphGeometry.Target(left, 50f, left + 60f, 110f)
        for (step in 0..100) {
            val scroll = step * 3.69f
            val frame = CameraGooeyGeometry.frame(716f, 315f, 1f, scroll,
                540f, 164f, 18f, 369f, 110f, target)
            val oldFrame = CameraGooeyGeometry.frame(716f, 315f, 1f, scroll,
                540f, 164f, 18f, 369f, 110f, reference)
            assertEquals(oldFrame.cy, frame.cy, 0f)
            assertEquals(oldFrame.width, frame.width, 0f)
            val actualSeeds = CameraGooeyGeometry.seeds(target, frame, 3f)
            val oldSeeds = CameraGooeyGeometry.seeds(reference, oldFrame, 3f)
            assertArrayEquals(oldSeeds.camera, actualSeeds.camera, 0f)
            assertArrayEquals(oldSeeds.artwork, actualSeeds.artwork, 0f)
        }
    }
}
