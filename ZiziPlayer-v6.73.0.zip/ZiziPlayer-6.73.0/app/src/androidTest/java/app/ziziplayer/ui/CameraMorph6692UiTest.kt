package app.ziziplayer.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.PixelMap
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import app.ziziplayer.ui.components.CameraCutoutSnapshot
import app.ziziplayer.ui.components.CameraMorphDebug
import app.ziziplayer.ui.components.cameraMorphSilhouette
import app.ziziplayer.ui.components.LocalCameraCutoutOverride
import app.ziziplayer.ui.screens.CollectionHeroContent
import app.ziziplayer.ui.screens.CollectionActionsRow
import app.ziziplayer.ui.screens.PinnedCollectionScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import kotlin.math.roundToInt
import kotlin.math.floor
import kotlin.math.ceil

/** Requires device/emulator. Not reported as passed by the offline JVM/Python checker. */
class CameraMorph6692UiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private var cameraPoint = Offset.Zero
    private var status = 0f
    private var backs = 0
    private var plays = 0
    private val collectionVisible = mutableStateOf(true)

    @Suppress("DEPRECATION")
    private fun mount(hasCamera: Boolean, corner: Boolean = false) {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            // Match MainActivity: an opaque DecorView status-bar color view would hide
            // the injected contour in PixelCopy and test the harness rather than the overlay.
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                compose.activity.window.isStatusBarContrastEnforced = false
            }
        }
        compose.setContent {
            val destinationState = rememberSaveableStateHolder()
            if (collectionVisible.value) destinationState.SaveableStateProvider("test:collection") {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusValue = WindowInsets.statusBars.getTop(density).toFloat()
                status = statusValue
                val pointX = w * if (corner) .12f else .5f
                val pointY = statusValue * .5f
                cameraPoint = Offset(pointX, pointY)
                // Stable identity, mirroring rememberCameraCutout()'s previousKey guard in
                // production: a fresh CameraCutoutSnapshot/Path every recomposition, handed to
                // a staticCompositionLocalOf, forces a full-subtree recompose on every pass and
                // starved the idling resource under load (root cause of the corner-hole timeout).
                val snapshot = remember(hasCamera, corner, w, h, statusValue) {
                    val diameter = statusValue * .55f
                    val t = CameraMorphGeometry.Target(pointX - diameter/2, pointY - diameter/2,
                        pointX + diameter/2, pointY + diameter/2)
                    val outline = Path().apply { addOval(Rect(t.left,t.top,t.right,t.bottom)) }
                    CameraCutoutSnapshot(
                        target = if (hasCamera) t else null, outline = if (hasCamera) outline else null,
                        windowWidth = w.roundToInt(), windowHeight = h.roundToInt(),
                        statusTop = statusValue.roundToInt(), exact = true, reason = "Injected test fixture"
                    )
                }
                CompositionLocalProvider(LocalPalette provides basePalette(), LocalCameraCutoutOverride provides snapshot) {
                    PinnedCollectionScaffold(destination = "test:6692", title = "Camera collection",
                        tint = Color.DarkGray, trackCount = 40, playingHere = false, playEnabled = true,
                        onBack = { backs++ }, onPlay = { plays++ },
                        artwork = { Box(Modifier.fillMaxSize().background(Color.Magenta)) },
                        hero = {
                            CollectionHeroContent(title = "Camera collection", metadata = "40 tracks") {
                                CollectionActionsRow(onShuffle = {}, shuffleEnabled = true)
                            }
                        }) {
                        items(40) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                    }
                }
            }
            } else Text("Other destination", Modifier.testTag("test:other-destination"))
        }
        compose.waitUntil { status > 0f }
        compose.waitForIdle()
    }

    /** Real disposal/remount with saved LazyListState, not just recomposition.
     * The hero remains offscreen and unmeasured after returning to item 12. */
    private fun restoredDeepCollection(hasCamera: Boolean, corner: Boolean = false) {
        mount(hasCamera, corner)
        collapse()
        compose.onNodeWithText("Track 11").assertIsDisplayed()
        fun magentaPixels(): Int {
            val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
            var count = 0
            for (y in status.toInt().coerceAtLeast(0) until pixels.height step 2) {
                for (x in 0 until pixels.width step 2) {
                    val c = pixels[x,y]
                    if (c.red > .7f && c.blue > .7f && c.green < .15f) count++
                }
            }
            return count
        }
        assertEquals("No artwork before leaving", 0, magentaPixels())
        repeat(2) {
            compose.runOnIdle { collectionVisible.value = false }
            compose.onNodeWithTag("test:other-destination").assertIsDisplayed()
            compose.onNodeWithTag("collection:viewport").assertDoesNotExist()
            compose.runOnIdle { collectionVisible.value = true }
            compose.waitForIdle()
            compose.onNodeWithText("Track 11").assertIsDisplayed()
            compose.onNodeWithTag("collection:banner").assertIsDisplayed()
            compose.onNodeWithTag("collection:play").assertIsDisplayed().assertIsEnabled()
            assertEquals("Hidden cover must not reappear after navigation", 0, magentaPixels())
        }
        compose.onNodeWithTag("collection:play").performClick()
        compose.runOnIdle { assertEquals(1, plays) }
        compose.onNodeWithTag("collection:list").performScrollToIndex(0)
        compose.onNodeWithTag("collection:cover").assertIsDisplayed()
        assertTrue("Artwork returns only when scrolling back to the hero", magentaPixels() > 20)
    }

    @Test fun centralCameraCoverStaysHiddenAfterNavigation66911() = restoredDeepCollection(true)
    @Test fun cornerCameraCoverStaysHiddenAfterNavigation66911() = restoredDeepCollection(true, true)
    @Test fun noCameraCoverStaysHiddenAfterNavigation66911() = restoredDeepCollection(false)

    private fun cameraPixel(): Color {
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        return pixels[cameraPoint.x.roundToInt().coerceIn(0,pixels.width-1),
            cameraPoint.y.roundToInt().coerceIn(0,pixels.height-1)]
    }
    private fun collapse() {
        compose.onNodeWithTag("collection:list").performScrollToIndex(12)
        compose.waitForIdle()
    }
    private fun assertCameraBackground(c: Color) {
        assertEquals("No residual camera overlay: $c", Color.DarkGray.red, c.red, .01f)
        assertEquals("No residual camera overlay: $c", Color.DarkGray.green, c.green, .01f)
        assertEquals("No residual camera overlay: $c", Color.DarkGray.blue, c.blue, .01f)
    }

    @Test fun centralHoleLeavesNoOverlayAfterCompletionAndControlsStillWork() {
        mount(true)
        assertTrue(cameraPixel().red > .1f) // No fabricated black dot in the expanded header.
        collapse()
        assertCameraBackground(cameraPixel())
        compose.onNodeWithContentDescription("Слушать подборку").performClick()
        compose.onNodeWithContentDescription("Назад").performClick()
        compose.runOnIdle { assertEquals(1, plays); assertEquals(1, backs) }
    }
    @Test fun cornerHoleLeavesNoOverlayAtCameraOrScreenCenter() {
        mount(true, corner = true)
        collapse()
        assertCameraBackground(cameraPixel())
        // The real hole is off-center; nothing invents a black dot at screen center instead.
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        val centerX = pixels.width / 2
        val centerPixel = pixels[centerX.coerceIn(0, pixels.width - 1), cameraPoint.y.roundToInt().coerceIn(0, pixels.height - 1)]
        assertTrue("No fabricated camera at screen center for a corner cutout, got $centerPixel",
            centerPixel.red > .03f || centerPixel.green > .03f || centerPixel.blue > .03f)
    }
    @Test fun noHoleLeavesStatusBackgroundUntouched() {
        mount(false)
        val before = cameraPixel()
        collapse()
        val after = cameraPixel()
        assertEquals(before.red, after.red, .01f)
        assertEquals(before.green, after.green, .01f)
        assertEquals(before.blue, after.blue, .01f)
    }
    private fun drag(upwards: Boolean, fraction: Float = .42f) {
        compose.onNodeWithTag("collection:list").performTouchInput {
            val point = Offset(center.x, height * .5f)
            down(point)
            moveTo(point + Offset(0f, height * fraction * if (upwards) -1f else 1f))
            // Stationary before release: test nested scroll, not an uncontrolled fling.
            advanceEventTime(1000)
            up()
        }
        compose.waitForIdle()
    }

    /** The measured placeholder is NOT proof of artwork rendering. Inspect real pixels too. */
    private fun magentaWidth(): Int {
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        var left = pixels.width
        var right = -1
        for (y in status.roundToInt() until pixels.height) for (x in 0 until pixels.width) {
            val c = pixels[x, y]
            if (c.red > .95f && c.blue > .95f && c.green < .05f) {
                left = minOf(left, x)
                right = maxOf(right, x)
            }
        }
        return if (right < left) 0 else right - left + 1
    }

    @Test fun shortRealDragShrinksRenderedArtworkAndReverseRestoresIt() {
        mount(true)
        val before = magentaWidth()
        assertTrue(before > 0)
        drag(upwards = true, fraction = .06f)
        val smaller = magentaWidth()
        assertTrue("The picture, not just its slot, must shrink", smaller in 1 until before)
        drag(upwards = false, fraction = .14f)
        assertEquals(before.toFloat(), magentaWidth().toFloat(), 2f)
        assertTrue(cameraPixel().red > .1f)
    }

    @Test fun realScrollRoundTripRemovesAnchorAndRestoresExpandedGeometry() {
        mount(true)
        val before = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().boundsInRoot
        val imageBefore = magentaWidth()
        repeat(3) { drag(upwards = true) }
        assertCameraBackground(cameraPixel())
        assertEquals(0, magentaWidth())
        repeat(5) { drag(upwards = false) }
        val after = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().boundsInRoot
        assertEquals(before.width, after.width, 1f)
        assertEquals(before.top, after.top, 1f)
        assertEquals(imageBefore.toFloat(), magentaWidth().toFloat(), 2f)
        assertTrue(cameraPixel().red > .1f)
    }
    @Test fun scrolledGradientHasNoStatusBarSeam() {
        mount(true)
        drag(upwards = true, fraction = .32f)
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        val edge = status.roundToInt()
        val above = pixels[2, edge-1]
        val below = pixels[2, edge+1]
        assertEquals(above.red, below.red, .025f)
        assertEquals(above.green, below.green, .025f)
        assertEquals(above.blue, below.blue, .025f)
    }

    /** Real Android adapter + compatibility Compose overlay at a controlled intermediate scroll,
     * not merely a black endpoint in an injected fixture. Does not claim OEM calibration. */
    @Test
    @androidx.test.filters.SdkSuppress(minSdkVersion = 28)
    @Suppress("DEPRECATION")
    fun topAttachedReservationRendersConnectedNeckBeforeArtworkDisappears() {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29)
                compose.activity.window.isStatusBarContrastEnforced = false
        }
        var neckPoint = Offset.Zero
        var bodyPoint = Offset.Zero
        var neckInk = 0f
        var bodyInk = 0f
        var connected = false
        compose.setContent {
            BoxWithConstraints(Modifier.fillMaxSize().background(Color.DarkGray).testTag("morph:midframe")) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusPx = WindowInsets.statusBars.getTop(density)
                val snapshot = remember(w, h, statusPx, density.density) {
                    val d = (statusPx * .55f).roundToInt()
                    val raw = android.graphics.Rect((w/2-d/2).roundToInt(), 0,
                        (w/2-d/2).roundToInt()+d, statusPx)
                    val cutout = android.view.DisplayCutout(android.graphics.Rect(0,statusPx,0,0), listOf(raw))
                    app.ziziplayer.ui.components.cameraCutoutSnapshot(cutout, w.roundToInt(),
                        h.roundToInt(), statusPx, density.density)
                }
                val unit = CollectionHeaderGeometry.unit(maxWidth.value)
                val maximum = (CollectionHeaderGeometry.COVER_SIZE * unit).dp
                val minimum = (maximum * .44f).coerceAtLeast(64.dp).coerceAtMost(maximum)
                val top = (CollectionHeaderGeometry.COVER_TOP * unit).dp
                val travel = with(density) { (minimum + top).toPx() }
                val offset = travel * .5f
                val target = snapshot.target
                if (target != null) {
                    val f = CameraMorphGeometry.frame(with(density) { maximum.toPx() },
                        with(density) { minimum.toPx() }, 1f, offset, w/2,
                        statusPx + with(density) { top.toPx() }, 0f, travel, statusPx.toFloat(), target)
                    neckPoint = Offset(target.cx(), (target.bottom + f.top())/2)
                    bodyPoint = Offset(f.cx, f.cy + f.height*.2f)
                    val goo = CameraMorphGeometry.goo(target, f)
                    connected = goo?.joined == true
                    bodyInk = CameraMorphGeometry.bodyBlack(f, goo)
                    neckInk = goo?.inkAt(neckPoint.x.roundToInt().toFloat(), neckPoint.y.roundToInt().toFloat()) ?: 0f
                }
                app.ziziplayer.ui.components.LegacyCollectionCoverMorphOverlay(
                    camera = snapshot, maximum = maximum, minimum = minimum, coverTop = top,
                    corner = 0.dp, status = with(density) { statusPx.toDp() },
                    fraction = { 1f }, scroll = { offset },
                    artwork = { Box(Modifier.fillMaxSize().background(Color.Magenta)) }
                )
            }
        }
        compose.waitForIdle()
        assertTrue("System reservation must produce a usable approximation", neckPoint.y > 0)
        val pixels = compose.onNodeWithTag("morph:midframe").captureToImage().toPixelMap()
        assertTrue("Connected phase must be reached", connected)
        val neck = pixels[neckPoint.x.roundToInt(), neckPoint.y.roundToInt()]
        // The neck carries artwork with local ink, not an opaque black full-gap slab.
        assertEquals((1f - bodyInk) * (1f - neckInk), neck.red, .06f)
        assertEquals((1f - bodyInk) * (1f - neckInk), neck.blue, .06f)
        assertTrue("No background showing through the connected neck", neck.green < .03f)
        val body = pixels[bodyPoint.x.roundToInt(), bodyPoint.y.roundToInt()]
        assertTrue("Artwork is still present below the connected neck", body.red > .05f &&
            body.blue > .05f && body.green < .03f)
        val outside = pixels[8, neckPoint.y.roundToInt()]
        assertTrue("No full-width status darkening", outside.red > .1f)
    }

    // 6.69.15: explicit COMPATIBILITY renderer harness. Old contour/material expectations
    // remain valid for API 26–30; new default GPU pixels have separate CameraGooey66915UiTest.
    // The mount() real-scroll harness above still exercises the DEFAULT production route.
    private val materialProgress = mutableFloatStateOf(0f)
    private val materialRedraw = mutableStateOf(0)
    private var materialTravel = 1f
    private var materialFrame: CameraMorphGeometry.Frame? = null
    private var materialTarget: CameraMorphGeometry.Target? = null

    @Suppress("DEPRECATION")
    private fun mountMaterial6696(pattern: Boolean, corner: Boolean = false) {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29)
                compose.activity.window.isStatusBarContrastEnforced = false
        }
        compose.setContent {
            BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF304050)).testTag("material:6696")) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusPx = WindowInsets.statusBars.getTop(density)
                status = statusPx.toFloat()
                val snapshot = remember(w, h, statusPx, corner) {
                    val diameter = statusPx * .55f
                    val x = w * if (corner) .12f else .5f
                    val t = CameraMorphGeometry.Target(x-diameter/2, statusPx*.5f-diameter/2,
                        x+diameter/2, statusPx*.5f+diameter/2)
                    CameraCutoutSnapshot(target = t,
                        outline = Path().apply { addOval(Rect(t.left,t.top,t.right,t.bottom)) },
                        windowWidth = w.roundToInt(), windowHeight = h.roundToInt(),
                        statusTop = statusPx, exact = true, reason = "Material pixel fixture")
                }
                val unit = CollectionHeaderGeometry.unit(maxWidth.value)
                val maximum = (CollectionHeaderGeometry.COVER_SIZE * unit).dp
                val minimum = (maximum*.44f).coerceAtLeast(64.dp).coerceAtMost(maximum)
                val top = (CollectionHeaderGeometry.COVER_TOP * unit).dp
                val travel = with(density) { (minimum+top).toPx() }
                materialTravel = travel
                materialTarget = snapshot.target
                materialFrame = CameraMorphGeometry.frame(with(density) { maximum.toPx() },
                    with(density) { minimum.toPx() }, 1f, materialProgress.floatValue*travel,
                    w/2, statusPx+with(density) { top.toPx() }, 0f, travel, statusPx.toFloat(), snapshot.target)
                app.ziziplayer.ui.components.LegacyCollectionCoverMorphOverlay(
                    camera = snapshot, maximum = maximum, minimum = minimum, coverTop = top,
                    corner = 0.dp, status = with(density) { statusPx.toDp() },
                    fraction = { 1f }, scroll = { materialProgress.floatValue*travel },
                    artwork = {
                        Canvas(Modifier.fillMaxSize()) {
                            // Force an identical display-list rerecording in stationary tests.
                            check(materialRedraw.value >= 0)
                            drawRect(Color.White)
                            if (pattern) {
                                val stripe = size.width/64f
                                for (i in 0 until 64 step 2) drawRect(Color.Black,
                                    topLeft = Offset(i*stripe,0f), size = Size(stripe,size.height))
                            }
                        }
                    }
                )
            }
        }
        compose.waitForIdle()
    }

    /** Sample BOTH halves: a centre-only test cannot detect a clipped right side.
     * Change state in both directions and inspect actual Compose/RenderNode output.
     * Runs with blur on API 35 and without RenderEffect on API 28. */
    private fun bodySidesStayPainted66912(corner: Boolean) {
        mountMaterial6696(pattern = false, corner = corner)
        val steps = listOf(.30f, .34f, .37f, .38f, .39f, .40f, .41f, .43f,
            .46f, .50f, .60f, .70f, .80f, .86f)
        for (progress in steps + steps.reversed()) {
            val pixels = materialAt6696(progress)
            val f = requireNotNull(materialFrame)
            val g = CameraMorphGeometry.goo(materialTarget, f)
            val bodyInk = CameraMorphGeometry.bodyBlack(f, g)
            for (side in listOf(-.28f, 0f, .28f)) {
                val x = (f.cx + f.width * side).roundToInt()
                val y = (f.cy + f.height * .15f).roundToInt()
                assertTrue("Interior probe below status clip", y >= status)
                val expected = (1f - bodyInk) * (1f - (g?.inkAt(x.toFloat(), y.toFloat()) ?: 0f))
                val c = pixels[x, y]
                assertEquals("Body red side=$side p=$progress corner=$corner", expected, c.red, .04f)
                assertEquals("Body green side=$side p=$progress corner=$corner", expected, c.green, .04f)
                assertEquals("Body blue side=$side p=$progress corner=$corner", expected, c.blue, .04f)
            }
        }
    }

    @Test fun centralBodyBothSidesSurviveContactAndReversal66912() = bodySidesStayPainted66912(false)
    @Test fun cornerBodyBothSidesSurviveContactAndReversal66912() = bodySidesStayPainted66912(true)

    /** Keep the whole contact region stable through forced redraws, not just its centre.
     * Also return from quarter-pixel forward/backward motion at the actual device's
     * contact progress. This is an Android test, not executed by the offline checks. */
    private fun contactHoldAndMicroReversal66913(corner: Boolean) {
        mountMaterial6696(pattern = true, corner = corner)
        var low = .12f
        var high = .85f
        repeat(16) {
            val mid = (low + high) / 2f
            compose.runOnIdle { materialProgress.floatValue = mid }
            compose.waitForIdle()
            if (CameraMorphGeometry.goo(materialTarget, materialFrame)?.joined == true) high = mid
            else low = mid
        }
        val contact = high
        val pixel = 1f / materialTravel
        for (offset in listOf(-1f, 0f, 1f, 4f, 10f)) {
            val progress = contact + offset * pixel
            val expected = materialAt6696(progress)
            val f = requireNotNull(materialFrame)
            val t = requireNotNull(materialTarget)
            val left = floor(minOf(t.left, f.left()) - 4f - CameraMorphGeometry.maxSwellPx(t)).toInt().coerceAtLeast(0)
            val right = ceil(maxOf(t.right, f.left()+f.width) + 4f + CameraMorphGeometry.maxSwellPx(t)).toInt().coerceAtMost(expected.width-1)
            val top = floor(t.top-3f).toInt().coerceAtLeast(0)
            val bottom = ceil(f.top()+f.height+3f).toInt().coerceAtMost(expected.height-1)
            fun sameRegion(actual: PixelMap) {
                var maxError = 0f
                for (y in top..bottom) for (x in left..right) {
                    val a = actual[x,y]
                    val b = expected[x,y]
                    maxError = maxOf(maxError, kotlin.math.abs(a.red-b.red),
                        kotlin.math.abs(a.green-b.green), kotlin.math.abs(a.blue-b.blue))
                }
                assertTrue("Stationary/reversed contour p=$progress corner=$corner error=$maxError", maxError <= .02f)
            }
            repeat(4) {
                compose.runOnIdle { materialRedraw.value++ }
                compose.waitForIdle()
                sameRegion(compose.onNodeWithTag("material:6696").captureToImage().toPixelMap())
            }
            for (delta in listOf(-.25f, .25f, -1f, 1f)) {
                materialAt6696(progress + delta * pixel)
                sameRegion(materialAt6696(progress))
            }
        }
    }

    @Test fun centralContactHoldAndMicroReversal66913() = contactHoldAndMicroReversal66913(false)
    @Test fun cornerContactHoldAndMicroReversal66913() = contactHoldAndMicroReversal66913(true)

    private fun materialAt6696(progress: Float): PixelMap {
        android.util.Log.i("CameraMaterialCI", "begin progress=$progress api=${android.os.Build.VERSION.SDK_INT}")
        compose.runOnIdle { materialProgress.floatValue = progress }
        compose.waitForIdle()
        android.util.Log.i("CameraMaterialCI", "idle progress=$progress frame=$materialFrame")
        val pixels = compose.onNodeWithTag("material:6696").captureToImage().toPixelMap()
        android.util.Log.i("CameraMaterialCI", "captured progress=$progress size=${pixels.width}x${pixels.height}")
        return pixels
    }

    /** Decode the actual contour, not its bounding rectangle. This is test-only geometry;
     * Path.op runs on Android, without sampling rendered colors to pick a passing pixel. */
    private fun probePath(commands: FloatArray): android.graphics.Path {
        val path = android.graphics.Path()
        var i = 0
        while (i < commands.size) {
            when (commands[i++].toInt()) {
                0 -> { path.moveTo(commands[i], commands[i + 1]); i += 2 }
                1 -> {
                    path.cubicTo(commands[i], commands[i + 1], commands[i + 2],
                        commands[i + 3], commands[i + 4], commands[i + 5])
                    i += 6
                }
                2 -> path.close()
                else -> error("Invalid camera path opcode")
            }
        }
        return path
    }

    /** A pixel is the area [x,x+1] x [y,y+1], NOT the point (x,y).
     * Require another half-pixel of clearance to exclude rasterizer edge coverage. */
    private fun probeFits(path: android.graphics.Path, x: Int, y: Int, inside: Boolean): Boolean {
        val remainder = android.graphics.Path().apply {
            addRect(x - .5f, y - .5f, x + 1.5f, y + 1.5f, android.graphics.Path.Direction.CW)
        }
        val operation = if (inside) android.graphics.Path.Op.DIFFERENCE else android.graphics.Path.Op.INTERSECT
        check(remainder.op(path, operation)) { "Pixel probe path operation failed" }
        return remainder.isEmpty
    }

    @Test fun cameraDropPrecedesConnection6699() {
        mountMaterial6696(pattern = false)
        var selected: CameraMorphGeometry.Goo? = null
        var dropX = -1
        var dropY = -1
        var gapX = -1
        var gapY = -1
        // Select only by geometry, never by screenshot colors. Keep the same separate
        // phase and strict black/background thresholds; don't assume its first frame
        // has an opaque pixel at the rounded midpoint of a ~2px drop.
        for (step in 15..65) {
            compose.runOnIdle { materialProgress.floatValue = step / 100f }
            compose.waitForIdle()
            val t = checkNotNull(materialTarget)
            val g = CameraMorphGeometry.goo(t, materialFrame) ?: continue
            val ink = g.ink ?: continue
            val flesh = g.flesh ?: continue
            if (g.joined || g.u !in 3.10f..3.65f) continue
            val inkPath = probePath(ink)
            val fleshPath = probePath(flesh)
            val x = floor(t.cx()).toInt()
            // Entire sampled pixel must be BELOW the original camera, so the static
            // black camera alone cannot satisfy this test if the growing drop is lost.
            val y = (ceil(t.bottom).toInt() until floor(ink[9]).toInt())
                .firstOrNull { probeFits(inkPath, x, it, inside = true) } ?: continue
            val gx = floor((ink[8] + flesh[1]) * .5f).toInt()
            val gy = floor((ink[9] + flesh[2]) * .5f).toInt()
            if (!probeFits(inkPath, gx, gy, inside = false) ||
                !probeFits(fleshPath, gx, gy, inside = false)) continue
            selected = g
            dropX = x; dropY = y; gapX = gx; gapY = gy
            break
        }
        val g = checkNotNull(selected) { "A separate phase with interior drop/gap pixels must exist" }
        val saved = materialProgress.floatValue
        val pixels = compose.onNodeWithTag("material:6696").captureToImage().toPixelMap()
        val diagnostic = "p=$saved u=${g.u} size=${pixels.width}x${pixels.height} " +
            "drop=($dropX,$dropY) gap=($gapX,$gapY)"
        val between = pixels[gapX, gapY]
        assertEquals("No instant full-gap bridge: $diagnostic", 48f/255f, between.red, .025f)
        assertEquals(diagnostic, 64f/255f, between.green, .025f)
        assertEquals(diagnostic, 80f/255f, between.blue, .025f)
        val drop = pixels[dropX, dropY]
        assertTrue("The drop is rooted in the camera: $diagnostic color=$drop",
            drop.red < .03f && drop.green < .03f && drop.blue < .03f)
        // Cross the topology change, then verify BOTH the gap and drop on reverse.
        materialAt6696(.8f)
        val reverse = materialAt6696(saved)
        val reverseGap = reverse[gapX, gapY]
        val reverseDrop = reverse[dropX, dropY]
        assertEquals(diagnostic, between.red, reverseGap.red, .01f)
        assertEquals(diagnostic, between.green, reverseGap.green, .01f)
        assertEquals(diagnostic, between.blue, reverseGap.blue, .01f)
        assertEquals(diagnostic, drop.red, reverseDrop.red, .01f)
        assertEquals(diagnostic, drop.green, reverseDrop.green, .01f)
        assertEquals(diagnostic, drop.blue, reverseDrop.blue, .01f)
    }

    @Test fun bodyDarkeningTracksContactAndReverses66910() {
        mountMaterial6696(pattern = false)
        var darkest = 0f
        for (progress in listOf(.15f,.35f,.5f,.7f,.5f,.35f,.15f)) {
            val pixels = materialAt6696(progress)
            val f = checkNotNull(materialFrame)
            val g = CameraMorphGeometry.goo(materialTarget, f)
            val x = f.cx.roundToInt()
            val y = (f.top()+f.height*.85f).roundToInt()
            val ink = g?.inkAt(x.toFloat(), y.toFloat()) ?: 0f
            val black = CameraMorphGeometry.bodyBlack(f, g)
            val expected = (1f-black)*(1f-ink)
            darkest = maxOf(darkest, black)
            val body = pixels[x,y]
            assertEquals("White fixture follows contact ink at $progress", expected, body.red, .025f)
            assertEquals(expected, body.green, .025f)
            assertEquals(expected, body.blue, .025f)
            if (g == null || g.u >= 4.1f) assertEquals("No dimmer outside proximity", 0f, black, .001f)
            val outside = pixels[(f.left()-4f).roundToInt(),f.cy.roundToInt()]
            assertEquals("No blur halo outside shape",48f/255f,outside.red,.015f)
            assertEquals(64f/255f,outside.green,.015f)
            assertEquals(80f/255f,outside.blue,.015f)
        }
        assertTrue("The body must retain ink while still connected", darkest > .05f)
        // Probe across the FORMER circle/extension clip seam, well inside the union.
        // White source makes double antialias coverage visible as an unwanted dark line.
        val pixels = materialAt6696(.5f)
        val f = checkNotNull(materialFrame)
        val g = checkNotNull(CameraMorphGeometry.goo(materialTarget, f))
        val union = probePath(checkNotNull(g.flesh))
        val bodyInk = CameraMorphGeometry.bodyBlack(f, g)
        var seamProbes = 0
        for (y in ceil(maxOf(status+2f,f.top()-3f)).toInt()..floor(f.cy).toInt()) {
            for (x in floor(f.left()-2f).toInt()..ceil(f.left()+f.width+2f).toInt()) {
                val radial = kotlin.math.hypot(x+.5f-f.cx,y+.5f-f.cy)
                if (kotlin.math.abs(radial-f.width*.5f)>1.5f ||
                    !probeFits(union,x,y,inside = true)) continue
                val expected = (1f-bodyInk)*(1f-g.inkAt(x+.5f,y+.5f))
                val actual = pixels[x,y]
                assertEquals("No internal clip seam at ($x,$y)",expected,actual.red,.025f)
                assertEquals(expected,actual.green,.025f)
                assertEquals(expected,actual.blue,.025f)
                seamProbes++
            }
        }
        assertTrue("Must exercise the former internal seam",seamProbes>0)
    }

    private fun bodyStats6696(pixels: PixelMap): Pair<Float,Float> {
        val f = checkNotNull(materialFrame)
        var sum = 0f
        var squares = 0f
        var count = 0
        val left = (f.left()+f.width*.35f).roundToInt()
        val right = (f.left()+f.width*.65f).roundToInt()
        val top = (f.top()+f.height*.79f).roundToInt()
        val bottom = (f.top()+f.height*.84f).roundToInt()
        for (y in top..bottom) for (x in left..right) {
            val value = pixels[x,y].red
            sum += value
            squares += value*value
            count++
        }
        val mean = sum/count
        return mean to (squares/count-mean*mean).coerceAtLeast(0f)
    }

    @Test
    @androidx.test.filters.SdkSuppress(minSdkVersion = 31)
    fun blurReducesDetailWithoutDimming6696() {
        mountMaterial6696(pattern = true)
        val sharp = bodyStats6696(materialAt6696(0f))
        val blurred = bodyStats6696(materialAt6696(.20f))
        val frame = checkNotNull(materialFrame)
        val bodyInk = CameraMorphGeometry.bodyBlack(frame, CameraMorphGeometry.goo(materialTarget, frame))
        assertTrue("Blur fixture is only lightly shaded", bodyInk < .1f)
        assertTrue("Fixture has visible detail",sharp.second > .10f)
        assertTrue("RenderEffect must remove high-frequency detail: $sharp -> $blurred",
            blurred.second < sharp.second*.45f)
        assertEquals("Blur preserves mean after predicted contact ink",sharp.first*(1f-bodyInk),blurred.first,.08f)
        assertTrue("Not a black overlay",blurred.first > .4f)
    }

    @Test fun materialRoundTripRestoresTheSamePixels6696() {
        mountMaterial6696(pattern = true)
        val before = materialAt6696(.45f)
        val f = checkNotNull(materialFrame)
        val sharpBefore = materialAt6696(0f)
        // The entire injected camera region must become background, not just its centre.
        // Check exact completion AND overscroll; include room for the swollen contour.
        for (completion in listOf(1f, 1.2f)) {
            val completed = materialAt6696(completion)
            val target = checkNotNull(materialTarget)
            val padding = CameraMorphGeometry.maxSwellPx(target) + 2f
            for (y in floor(target.top-padding).toInt().coerceAtLeast(0)..
                ceil(target.bottom+padding).toInt().coerceAtMost(completed.height-1)) {
                for (x in floor(target.left-padding).toInt().coerceAtLeast(0)..
                    ceil(target.right+padding).toInt().coerceAtMost(completed.width-1)) {
                    val color = completed[x,y]
                    val message = "No residual dot/drop at p=$completion pixel=($x,$y): $color"
                    assertEquals(message, 48f/255f, color.red, .01f)
                    assertEquals(message, 64f/255f, color.green, .01f)
                    assertEquals(message, 80f/255f, color.blue, .01f)
                }
            }
        }
        materialAt6696(.15f)
        val after = materialAt6696(.45f)
        var maxError = 0f
        for (y in (f.top().roundToInt()-3).coerceAtLeast(status.roundToInt()+1)..(f.top()+f.height+3).roundToInt()) {
            for (x in (f.left()-3).roundToInt()..(f.left()+f.width+3).roundToInt()) {
                maxError = maxOf(maxError,kotlin.math.abs(before[x,y].red-after[x,y].red))
            }
        }
        assertTrue("Same scroll must restore the same blur/mask pixels: $maxError",maxError <= .02f)
        // A group fade must not let bright artwork reappear underneath a fading black
        // overlay (the ModulateAlpha double-alpha regression).
        val faded = materialAt6696(.95f)
        val fadeFrame = checkNotNull(materialFrame)
        val t = checkNotNull(materialTarget)
        val x = fadeFrame.cx.roundToInt()
        val fy = fadeFrame.cy.roundToInt()
        val inCamera = kotlin.math.hypot((x-t.cx())/(t.width()*.5f),
            (fy-t.cy())/(t.height()*.5f)) < 1f
        val background = (48f/255f) * if (inCamera) (1f-fadeFrame.anchorAlpha) else 1f
        val ink = CameraMorphGeometry.goo(t, fadeFrame)?.inkAt(x.toFloat(), fy.toFloat()) ?: 0f
        // Patterned source is bounded by white, so this is an upper luminance bound.
        val upper = background*(1f-fadeFrame.imageAlpha) +
            (1f-CameraMorphGeometry.bodyBlack(fadeFrame, CameraMorphGeometry.goo(t, fadeFrame)))*(1f-ink)*fadeFrame.imageAlpha
        assertTrue("No artwork flash during group fade", faded[x,fy].red <= upper + .04f)
        val sharpAfter = materialAt6696(0f)
        val expanded = checkNotNull(materialFrame)
        val y = (expanded.top()+expanded.height*.8f).roundToInt()
        for (x in (expanded.left()+expanded.width*.3f).roundToInt()..(expanded.left()+expanded.width*.7f).roundToInt())
            assertEquals("Fully restored sharpness",sharpBefore[x,y].red,sharpAfter[x,y].red,.02f)
    }



    /** The real LazyColumn and production nested-scroll connection receive a held touch.
     * Unlike the controlled material harness, this catches integer input, dropped fractions,
     * incorrect consumed-delta sign, a stale draw snapshot and snapping on finger-up.
     * Event partitions are not a claim about the physical panel's refresh rate.
     */
    private fun realSubpixelContact66914(corner: Boolean) {
        mount(hasCamera = true, corner = corner)
        val list = compose.onNodeWithTag("collection:list")
        val viewport = compose.onNodeWithTag("collection:viewport")
        val width = viewport.fetchSemanticsNode().boundsInRoot.width
        val density = compose.density
        val unit = CollectionHeaderGeometry.unit(width / density.density)
        val maximum = with(density) { (CollectionHeaderGeometry.COVER_SIZE * unit).dp.toPx() }
        val minimum = (maximum * .44f).coerceAtLeast(with(density) { 64.dp.toPx() }).coerceAtMost(maximum)
        val top = with(density) { (CollectionHeaderGeometry.COVER_TOP * unit).dp.toPx() }
        val travel = minimum + top
        val radius = status * .55f / 2f
        val target = CameraMorphGeometry.Target(cameraPoint.x - radius, cameraPoint.y - radius,
            cameraPoint.x + radius, cameraPoint.y + radius)
        fun frameAt(px: Float) = CameraMorphGeometry.frame(maximum, minimum, 1f, px,
            width / 2, status + top, 0f, travel, status, target)
        var low = .12f * travel
        var high = .85f * travel
        assertTrue("The fixture reaches contact", CameraMorphGeometry.goo(target, frameAt(high))?.joined == true)
        repeat(20) {
            val mid = (low + high) / 2f
            if (CameraMorphGeometry.goo(target, frameAt(mid))?.joined == true) high = mid else low = mid
        }
        val desired = floor(high) + 2.375f
        fun sample() = compose.runOnIdle { requireNotNull(CameraMorphDebug.lastScroll) }
        fun drawMatchesInput() {
            val input = sample()
            val draw = compose.runOnIdle { requireNotNull(CameraMorphDebug.lastFrame) }
            assertEquals("First hero remains visible in the list", 0, input.index)
            assertEquals("Renderer must use the consumed subpixel coordinate", input.precise, draw.scroll, .001f)
            assertEquals("No independent geometry clock", frameAt(input.precise).progress, draw.progress, .00001f)
        }
        fun sameContent(a: PixelMap, b: PixelMap) {
            assertEquals(a.width, b.width)
            assertEquals(a.height, b.height)
            var error = 0f
            // Exclude live system status icons; include both body sides, list and background.
            for (y in (ceil(status).toInt() + 2) until minOf(a.height, (status + width).toInt()) step 2) {
                for (x in 0 until a.width step 2) {
                    val c = a[x,y]; val d = b[x,y]
                    error = maxOf(error, kotlin.math.abs(c.red - d.red),
                        kotlin.math.abs(c.green - d.green), kotlin.math.abs(c.blue - d.blue))
                }
            }
            assertTrue("Held/reversed actual pixels corner=$corner error=$error", error <= .025f)
        }
        var fingerDown = false
        var pointer = Offset.Zero
        fun move(dy: Float) {
            list.performTouchInput {
                pointer += Offset(0f, dy)
                moveTo(pointer)
            }
            compose.waitForIdle()
        }
        compose.runOnIdle { CameraMorphDebug.startTrace() }
        try {
            list.performTouchInput {
                pointer = Offset(center.x, height * .9f)
                down(pointer)
                // Cross touch slop and phase one first; adjust from actual consumption below.
                pointer -= Offset(0f, maximum - minimum + desired + with(density) { 48.dp.toPx() })
                moveTo(pointer)
            }
            fingerDown = true
            compose.waitForIdle()
            move(sample().precise - desired)
            assertEquals("Subpixel set point is not rounded", desired, sample().precise, .005f)
            drawMatchesInput()
            var crossed = false
            for (step in 0 until 16) {
                val before = sample()
                move(-.125f)
                val after = sample()
                assertEquals("Every eighth-pixel event is retained", before.precise + .125f, after.precise, .001f)
                assertEquals("Only child consumption feeds the visual coordinate", -.125f, after.consumedY, .001f)
                drawMatchesInput()
                if (after.raw != before.raw) {
                    assertEquals("Crossing one layout rounding boundary", before.raw + 1, after.raw)
                    crossed = true
                    break
                }
            }
            assertTrue("Must exercise a real integer-boundary crossing", crossed)
            val held = sample()
            val pixels = viewport.captureToImage().toPixelMap()
            list.performTouchInput { advanceEventTime(3000) }
            compose.mainClock.advanceTimeBy(3000)
            compose.waitForIdle()
            assertEquals("A held finger has no settling animation", held.precise, sample().precise, 0f)
            drawMatchesInput()
            sameContent(pixels, viewport.captureToImage().toPixelMap())
            repeat(8) {
                move(.125f)
                assertEquals("Reverse across the same boundary", held.raw - 1, sample().raw)
                assertEquals(held.precise - .125f, sample().precise, .001f)
                drawMatchesInput()
                move(-.125f)
                assertEquals(held.raw, sample().raw)
                assertEquals("Return retains the fraction", held.precise, sample().precise, .001f)
                drawMatchesInput()
            }
            sameContent(pixels, viewport.captureToImage().toPixelMap())
            list.performTouchInput { advanceEventTime(1000); up() }
            fingerDown = false
            compose.waitForIdle()
            assertEquals("Finger-up must not snap to the integer list offset", held.precise, sample().precise, .001f)
            drawMatchesInput()
            sameContent(pixels, viewport.captureToImage().toPixelMap())
        } finally {
            if (fingerDown) list.performTouchInput { advanceEventTime(1000); up() }
            compose.runOnIdle { CameraMorphDebug.stopTrace() }
        }
    }

    @Test fun centralRealSubpixelContact66914() = realSubpixelContact66914(false)
    @Test fun cornerRealSubpixelContact66914() = realSubpixelContact66914(true)

    /** Execute the production Compose mask helper on Android. The reference is the set
     * union of separately scan-converted body and extension, NOT another floating-point
     * Path.op of tangent curves. Opposite winding and EvenOdd are explicit failing controls.
     * This proves pixel-set coverage on the fixture grid, not GPU frame timing or AA quality.
     */
    @Test fun compoundMaskEqualsUnion66914() {
        var checked = 0
        var separated = 0
        var joined = 0
        var detectsEvenOdd = false
        var detectsOpposite = false
        for (scale in listOf(.5f, 1f, 2f)) for (cx in listOf(108f, 540f, 972f)) {
            val target = CameraMorphGeometry.Target((cx - 18.5f) * scale, 49.5f * scale,
                (cx + 18.5f) * scale, 86.5f * scale)
            for (step in 125 until 995 step 5) {
                val f = CameraMorphGeometry.frame(716f * scale, 315.04f * scale, 1f,
                    step * .001f * 369.04f * scale, 540f * scale, 148f * scale,
                    18f * scale, 369.04f * scale, 94f * scale, target)
                val g = CameraMorphGeometry.goo(target, f)
                val sx = 716f / f.width
                val sy = 716f / f.height
                val r = CornerRadius(f.radius * sx, f.radius * sy)
                val body = RoundRect(0f, 0f, 716f, 716f, r, r, r, r)
                val extension = g?.flesh?.let { commands ->
                    probePath(commands).apply {
                        transform(android.graphics.Matrix().apply {
                            setValues(floatArrayOf(sx, 0f, -f.left() * sx,
                                0f, sy, -f.top() * sy, 0f, 0f, 1f))
                        })
                    }.asComposePath()
                }
                val bodyPath = Path().apply { addRoundRect(body, Path.Direction.Clockwise) }
                val bounds = extension?.getBounds() ?: Rect(0f, 0f, 716f, 716f)
                val clip = android.graphics.Region(floor(minOf(0f, bounds.left) - 2).toInt(),
                    floor(minOf(0f, bounds.top) - 2).toInt(),
                    ceil(maxOf(716f, bounds.right) + 2).toInt(),
                    ceil(maxOf(716f, bounds.bottom) + 2).toInt())
                fun region(path: Path) = android.graphics.Region().apply { setPath(path.asAndroidPath(), clip) }
                val expected = region(bodyPath).apply {
                    if (extension != null) op(region(extension), android.graphics.Region.Op.UNION)
                }
                fun differs(path: Path) = region(path).apply {
                    op(expected, android.graphics.Region.Op.XOR)
                }.isEmpty.not()
                val actual = cameraMorphSilhouette(body, extension)
                assertTrue("Mask coverage scale=$scale cx=$cx p=${f.progress}", !differs(actual))
                checked++
                if (extension != null) {
                    if (g?.joined == true) joined++ else separated++
                    val evenOdd = Path().apply {
                        fillType = PathFillType.EvenOdd
                        addRoundRect(body, Path.Direction.Clockwise)
                        addPath(extension)
                    }
                    val opposite = Path().apply {
                        fillType = PathFillType.NonZero
                        addRoundRect(body, Path.Direction.CounterClockwise)
                        addPath(extension)
                    }
                    detectsEvenOdd = detectsEvenOdd || differs(evenOdd)
                    detectsOpposite = detectsOpposite || differs(opposite)
                }
            }
        }
        assertTrue("Both phases and multiple densities must be exercised", checked > 1000 && separated > 0 && joined > 0)
        assertTrue("EvenOdd cancellation must be observable", detectsEvenOdd)
        assertTrue("Opposite winding cancellation must be observable", detectsOpposite)
    }
}
