package app.ziziplayer.data

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Fresh Room schema and real DAO transactions; device/emulator only. */
class TrackOrder66919RoomTest {
    @Test fun orderAndCoverChangeTogetherAndStalePlaylistIsRejected() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, ZiziDatabase::class.java).build()
        try {
            val sql = db.openHelper.writableDatabase
            sql.execSQL("INSERT INTO playlists(id,name,createdAt,coverUri) VALUES(99,'test',123,'old-cover')")
            for ((index, id) in listOf("a", "b", "c").withIndex())
                sql.execSQL("INSERT INTO playlist_tracks(playlistId,trackId,position) VALUES(99,?,?)", arrayOf(id, index))
            val dao = db.musicDao()
            assertTrue(dao.reorderPlaylist(99, 123, listOf("c", "a", "b"), true))
            assertEquals(listOf("c", "a", "b"), dao.orderedPlaylistIds(99))
            assertEquals(null, dao.playlistById(99)?.coverUri)
            assertTrue(dao.playlistById(99)?.followFirstTrack == true)
            dao.setPlaylistCoverIfEmpty(99, "next-import")
            assertEquals(null, dao.playlistById(99)?.coverUri)
            assertFalse(dao.reorderPlaylist(99, 122, listOf("a", "b", "c"), true))
            assertEquals(listOf("c", "a", "b"), dao.orderedPlaylistIds(99))
            dao.saveCollectionOrder("TRACKS", listOf("c", "a", "b"))
            dao.saveCollectionOrder("FAVORITES", listOf("a", "b"))
            assertEquals(listOf("c", "a", "b"), dao.observeCollectionOrder("TRACKS").first())
            assertEquals(listOf("a", "b"), dao.observeCollectionOrder("FAVORITES").first())
        } finally { db.close() }
    }
}
