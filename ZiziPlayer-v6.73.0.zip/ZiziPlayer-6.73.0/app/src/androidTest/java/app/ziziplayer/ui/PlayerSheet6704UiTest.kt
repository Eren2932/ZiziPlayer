package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.PlayerSheetShape
import app.ziziplayer.ui.components.playerSheetSurface
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import kotlin.math.roundToInt

/** Production layer + synthetic colours/radii. Not a MainActivity end-to-end/device-fit claim. */
class PlayerSheet6704UiTest {
    @get:Rule val compose = createComposeRule()
    private var offset by mutableFloatStateOf(0f)
    private val corners = mutableStateOf(PlayerSheetGeometry.NONE)
    private var pxPerDp = 1f

    private fun mount() {
        compose.setContent {
            pxPerDp = LocalDensity.current.density
            Box(Modifier.size(220.dp, 320.dp).background(Color.Magenta).testTag("sheet-window")) {
                Box(Modifier.fillMaxSize().playerSheetSurface(corners) { offset }.background(Color.Red)) {
                    // This child would cover a rounded background if the host wasn't clipped.
                    Box(Modifier.fillMaxSize().background(Color.Green))
                }
            }
        }
        compose.runOnIdle {
            val r = 24f * pxPerDp
            corners.value = PlayerSheetGeometry.Corners(r, r, r, r)
        }
    }

    private fun pixel(x: Int, y: Int, expected: Color) {
        val map = compose.onNodeWithTag("sheet-window").captureToImage().toPixelMap()
        val actual = map[x, y]
        assertEquals("red at $x,$y", expected.red, actual.red, .025f)
        assertEquals("green at $x,$y", expected.green, actual.green, .025f)
        assertEquals("blue at $x,$y", expected.blue, actual.blue, .025f)
        assertEquals("opaque at $x,$y", 1f, actual.alpha, .025f)
    }

    @Test fun movingLayerClipsBackdropAndChildrenAndRestoresFullscreen() {
        mount()
        pixel(2, 2, Color.Green)
        // Forward, partial reversal and forward again; no second animation clock to wait for.
        for (distance in listOf(40f, 17f, 40f)) {
            compose.runOnIdle { offset = distance * pxPerDp }
            val top = (distance * pxPerDp).roundToInt()
            pixel(2, 2, Color.Magenta)
            pixel(2, top + 2, Color.Magenta)
            pixel((110f * pxPerDp).roundToInt(), top + 2, Color.Green)
        }
        compose.runOnIdle { offset = 0f }
        pixel(2, 2, Color.Green)
    }

    @Test fun cornerStateUpdateChangesSameLayer() {
        mount()
        compose.runOnIdle { offset = 40f * pxPerDp }
        val y = (40f * pxPerDp).roundToInt() + 2
        pixel(2, y, Color.Magenta)
        // Mirrors fresh insets after a window/rotation change, without remounting the sheet.
        compose.runOnIdle { corners.value = PlayerSheetGeometry.NONE }
        pixel(2, y, Color.Green)
        compose.runOnIdle {
            val r = 24f * pxPerDp
            corners.value = PlayerSheetGeometry.Corners(r, 0f, 0f, 0f)
        }
        pixel(2, y, Color.Magenta)
        pixel((220f * pxPerDp).roundToInt() - 3, y, Color.Green)
    }

    @Test fun outlineKeepsPhysicalCornersInRtlAndDoesNotScalePixelsTwice() {
        val shape = PlayerSheetShape(PlayerSheetGeometry.Corners(80f, 60f, 40f, 20f), 100f)
        for (direction in listOf(LayoutDirection.Ltr, LayoutDirection.Rtl)) {
            for (density in listOf(.75f, 1f, 3.5f)) {
                val rr = (shape.createOutline(Size(500f, 800f), direction, Density(density)) as Outline.Rounded).roundRect
                assertEquals(80f, rr.topLeftCornerRadius.x, 0f)
                assertEquals(60f, rr.topRightCornerRadius.x, 0f)
                assertEquals(40f, rr.bottomRightCornerRadius.x, 0f)
                assertEquals(20f, rr.bottomLeftCornerRadius.x, 0f)
            }
        }
    }
}
