package app.ziziplayer.ui

import android.view.RoundedCorner
import android.view.WindowInsets
import androidx.test.filters.SdkSuppress
import app.ziziplayer.ui.components.readPlayerSheetCorners
import org.junit.Assert.assertEquals
import org.junit.Test

/** Real framework builder -> production adapter. Does not manufacture a hardware-fit result. */
@SdkSuppress(minSdkVersion = 31)
class PlayerSheetInsets6704Test {
    // AOSP Builder can retain the shared NO_ROUNDED_CORNERS instance. inset() creates an
    // independent rounded-corner container before setters, avoiding order-dependent tests
    // or mutation of another window. This uses public APIs only (no reflection/mock SDK).
    private fun freshBuilder(): WindowInsets.Builder =
        WindowInsets.Builder(WindowInsets.Builder().build().inset(1, 1, 1, 1))

    private fun window(tl: Int, tr: Int, br: Int, bl: Int): WindowInsets = freshBuilder()
        .setRoundedCorner(RoundedCorner.POSITION_TOP_LEFT,
            RoundedCorner(RoundedCorner.POSITION_TOP_LEFT, tl, tl, tl))
        .setRoundedCorner(RoundedCorner.POSITION_TOP_RIGHT,
            RoundedCorner(RoundedCorner.POSITION_TOP_RIGHT, tr, 1080 - tr, tr))
        .setRoundedCorner(RoundedCorner.POSITION_BOTTOM_RIGHT,
            RoundedCorner(RoundedCorner.POSITION_BOTTOM_RIGHT, br, 1080 - br, 2400 - br))
        .setRoundedCorner(RoundedCorner.POSITION_BOTTOM_LEFT,
            RoundedCorner(RoundedCorner.POSITION_BOTTOM_LEFT, bl, bl, 2400 - bl))
        .build()

    @Test fun readsFourIndependentFrameworkPixelRadii() {
        val c = readPlayerSheetCorners(window(96, 72, 48, 24))
        assertEquals(96f, c.topLeft, 0f)
        assertEquals(72f, c.topRight, 0f)
        assertEquals(48f, c.bottomRight, 0f)
        assertEquals(24f, c.bottomLeft, 0f)
    }

    @Test fun absentAndZeroCornersNeverReceiveTheLegacyGuess() {
        assertEquals(PlayerSheetGeometry.NONE, readPlayerSheetCorners(null))
        assertEquals(PlayerSheetGeometry.NONE, readPlayerSheetCorners(freshBuilder().build()))
        assertEquals(PlayerSheetGeometry.NONE, readPlayerSheetCorners(window(0, 0, 0, 0)))
        val partial = freshBuilder().setRoundedCorner(RoundedCorner.POSITION_TOP_RIGHT,
            RoundedCorner(RoundedCorner.POSITION_TOP_RIGHT, 72, 1008, 72)).build()
        assertEquals(PlayerSheetGeometry.Corners(0f, 72f, 0f, 0f), readPlayerSheetCorners(partial))
    }

    @Test fun freshWindowDoesNotReusePreviousPhysicalCorners() {
        val first = readPlayerSheetCorners(window(96, 72, 48, 24))
        val rotated = readPlayerSheetCorners(window(24, 96, 72, 48))
        assertEquals(PlayerSheetGeometry.Corners(24f, 96f, 72f, 48f), rotated)
        assertEquals(PlayerSheetGeometry.Corners(96f, 72f, 48f, 24f), first)
    }
}
