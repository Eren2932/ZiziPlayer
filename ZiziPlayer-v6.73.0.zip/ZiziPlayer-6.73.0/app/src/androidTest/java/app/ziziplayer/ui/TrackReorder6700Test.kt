package app.ziziplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.TrackReorderState
import app.ziziplayer.ui.components.rememberTrackReorder
import kotlinx.coroutines.CompletableDeferred
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Real Compose-state regressions; require Android instrumentation, not executed by Python. */
class TrackReorder6700Test {
    @get:Rule val compose = createComposeRule()
    private data class Row(val id: String, val title: String = id)
    private var source by mutableStateOf(listOf(Row("a"), Row("b"), Row("c")))
    private lateinit var reorder: TrackReorderState<Row>
    private var commits = 0
    private var write: suspend (List<Row>) -> Boolean = { after -> source = after; true }

    private fun mount() {
        compose.setContent {
            val list = rememberLazyListState()
            val state = rememberTrackReorder(list, source, { it.id }) { _, after ->
                commits++; write(after)
            }
            SideEffect { reorder = state }
            LazyColumn(Modifier.requiredSize(360.dp, 480.dp).testTag("list"), state = list) {
                items(state.items, key = { it.id }) { row ->
                    Text(row.title, Modifier.fillMaxWidth().height(64.dp).testTag(row.id))
                }
            }
        }
        compose.waitForIdle()
    }

    @Test fun successiveArrivalsAppearAtTopWithoutRemountOrResort() {
        mount()
        val originalState = reorder
        compose.runOnIdle { source = listOf(Row("new1")) + source }
        compose.onNodeWithTag("new1").assertIsDisplayed()
        compose.runOnIdle { source = listOf(Row("new2")) + source }
        compose.onNodeWithTag("new2").assertIsDisplayed()
        compose.runOnIdle {
            assertSame(originalState, reorder)
            assertEquals(source, reorder.items)
            assertEquals(0, commits)
            assertEquals(0, reorder.list.firstVisibleItemIndex)
        }
    }

    @Test fun acknowledgedWriteDoesNotSwallowFurtherAddsDeletesOrMetadata() {
        val releaseWrite = CompletableDeferred<Boolean>()
        write = { releaseWrite.await() }
        mount()
        compose.runOnIdle { assertTrue(reorder.accessibilityMove("a", 1)) }
        compose.waitUntil(3000) { commits == 1 }
        // Room's acknowledgement may precede the return of its suspending writer.
        compose.runOnIdle { source = listOf(Row("b"), Row("a"), Row("c")) }
        compose.waitForIdle()
        compose.runOnIdle { assertTrue(reorder.saving); source = listOf(Row("new1")) + source }
        compose.waitForIdle()
        compose.runOnIdle {
            assertTrue(reorder.saving)
            assertEquals(source, reorder.items)
            source = listOf(Row("new2"), Row("new1"), Row("b", "updated"), Row("a"))
        }
        compose.waitForIdle()
        compose.runOnIdle {
            assertEquals(source, reorder.items)
            assertFalse(reorder.items.any { it.id == "c" })
            assertEquals("updated", reorder.items.first { it.id == "b" }.title)
            releaseWrite.complete(true)
        }
        compose.waitUntil(3000) { !reorder.busy }
        compose.runOnIdle { assertEquals(source, reorder.items) }
    }

    @Test fun failedWriteRollsBackToNewestSourceNotGestureSnapshot() {
        val releaseWrite = CompletableDeferred<Boolean>()
        write = { releaseWrite.await() }
        mount()
        compose.runOnIdle { assertTrue(reorder.accessibilityMove("a", 1)) }
        compose.waitUntil(3000) { commits == 1 }
        compose.runOnIdle { source = listOf(Row("new"), Row("b"), Row("c")) }
        compose.waitForIdle()
        compose.runOnIdle { assertEquals(source, reorder.items); releaseWrite.complete(false) }
        compose.waitUntil(3000) { !reorder.busy }
        compose.runOnIdle { assertEquals(source, reorder.items); assertFalse(reorder.items.any { it.id == "a" }) }
    }

    @Test fun arrivalDuringDragCancelsOnlyPreviewAndRemainsVisible() {
        mount()
        compose.runOnIdle {
            assertTrue(reorder.start("b"))
            source = listOf(Row("new")) + source
        }
        compose.waitForIdle()
        compose.runOnIdle {
            assertNull(reorder.draggingKey)
            assertEquals(source, reorder.items)
            reorder.finish()
            assertEquals(0, commits)
        }
    }

    @Test fun newArrivalKeepsDeepScrollAnchorInsteadOfJumpingToTop() {
        source = (0..40).map { Row("row:$it") }
        mount()
        compose.onNodeWithTag("list").performScrollToIndex(20)
        compose.waitForIdle()
        val offset = reorder.list.firstVisibleItemScrollOffset
        compose.runOnIdle { source = listOf(Row("new")) + source }
        compose.waitForIdle()
        compose.runOnIdle {
            assertEquals(21, reorder.list.firstVisibleItemIndex)
            assertEquals(offset, reorder.list.firstVisibleItemScrollOffset)
            assertEquals("new", reorder.items.first().id)
        }
    }
}
