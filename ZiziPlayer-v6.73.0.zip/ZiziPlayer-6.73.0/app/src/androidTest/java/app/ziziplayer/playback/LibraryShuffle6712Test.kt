package app.ziziplayer.playback

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.media3.common.Player
import androidx.test.platform.app.InstrumentationRegistry
import app.ziziplayer.data.TrackEntity
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

/** Real service/controller + local WAV. Requires an Android device, not source-string assertions. */
class LibraryShuffle6712Test {
    @get:Rule val compose = createComposeRule()
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var audio: File
    private var controller: PlayerController? = null

    @Before fun fixture() {
        compose.setContent { }
        // Quiet tone, not silence: skip-silence preferences cannot consume the entire fixture.
        val samples = 8000 * 60
        val buffer = ByteBuffer.allocate(44 + samples * 2).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("RIFF".toByteArray()).putInt(36 + samples * 2).put("WAVEfmt ".toByteArray())
        buffer.putInt(16).putShort(1.toShort()).putShort(1.toShort()).putInt(8000)
        buffer.putInt(16000).putShort(2.toShort()).putShort(16.toShort())
        buffer.put("data".toByteArray()).putInt(samples * 2)
        repeat(samples) { buffer.putShort((1200 * kotlin.math.sin(it * 2.0 * Math.PI * 440 / 8000)).toInt().toShort()) }
        audio = File.createTempFile("shuffle-6712-", ".wav", context.cacheDir).apply { writeBytes(buffer.array()) }
    }

    private fun tracks(size: Int): List<TrackEntity> = (0 until size).map { index ->
        TrackEntity(id = "shuffle-test:$index", uri = Uri.fromFile(audio).toString(),
            title = "Shuffle $index", artist = "Test", durationMs = 60_000L,
            sourceFolder = "shuffle-test-6712")
    }

    private fun create(beforeConnection: (PlayerController) -> Unit): PlayerController {
        compose.runOnIdle {
            controller = PlayerController(context).also(beforeConnection)
        }
        return checkNotNull(controller)
    }

    private fun awaitState(predicate: (PlaybackState) -> Boolean): PlaybackState = runBlocking {
        withTimeout(20_000) { checkNotNull(controller).state.first(predicate) }
    }

    private fun ready(source: String, count: Int): PlaybackState = awaitState {
        it.queueSourceId == source && it.queueIds.size == count && it.shuffle &&
            it.isPlaying && !it.isBuffering && !it.isLoadingAudio && it.error == null
    }

    @After fun cleanUp() {
        compose.runOnIdle {
            controller?.let { player ->
                if (player.state.value.isPlaying) player.playPause()
                player.release()
            }
            controller = null
            context.stopService(Intent(context, PlaybackService::class.java))
        }
        compose.waitForIdle()
        if (::audio.isInitialized) audio.delete()
    }

    @Test fun pendingShuffleStartsAudioAndVisitsEveryTrackBeforeRepeating() {
        val source = tracks(5)
        val player = create {
            it.shuffleAndPlay(source, "cycle")
            assertTrue(it.hasQueue()) // Restoration must not replace this pending command.
        }
        var state = ready("cycle", 5)
        assertEquals(Player.REPEAT_MODE_ALL, state.repeatMode)
        val first = state.currentTrackId
        val seen = mutableSetOf(first)
        repeat(4) {
            val previous = state.currentTrackId
            compose.runOnIdle { player.next() }
            state = awaitState { it.currentTrackId != previous && it.isPlaying && !it.isLoadingAudio }
            assertTrue("Repeated before completing the cycle", seen.add(state.currentTrackId))
        }
        assertEquals(source.map { it.id }.toSet(), seen)
        compose.runOnIdle { player.next() }
        awaitState { it.currentTrackId == first }
    }

    @Test fun oneTrackStartsAndEmptyRequestDoesNotDestroyIt() {
        val source = tracks(1)
        val player = create { it.shuffleAndPlay(source, "single") }
        val before = ready("single", 1)
        compose.runOnIdle { player.shuffleAndPlay(emptyList(), "empty") }
        compose.runOnIdle {
            assertEquals(before.currentQueueEntryKey, player.state.value.currentQueueEntryKey)
            assertEquals("single", player.state.value.queueSourceId)
            assertTrue(player.state.value.isPlaying)
        }
        compose.runOnIdle { player.playPause() }
        awaitState { !it.isPlaying }
        compose.runOnIdle { player.shuffleAndPlay(source, "resumed") }
        ready("resumed", 1)
    }

    @Test fun largeLibraryDeduplicatesAndReshuffleDoesNotRestartCurrentTrack() {
        val source = tracks(600)
        val player = create { it.shuffleAndPlay(source + source.take(20), "large") }
        val before = ready("large", 600)
        assertEquals(source.map { it.id }, before.queueIds) // Canonical order is preserved.
        compose.runOnIdle { player.shuffleAndPlay(source, "reshuffled") }
        val after = ready("reshuffled", 600)
        assertNotEquals(before.currentTrackId, after.currentTrackId)
        compose.runOnIdle { player.toggleShuffle() }
        val sequential = awaitState { !it.shuffle }
        assertEquals(after.currentTrackId, sequential.currentTrackId)
        assertEquals(after.queueEntryKeys, sequential.queueEntryKeys)
    }

    @Test fun rapidPendingAndConnectedRequestsKeepLatestSource() {
        val source = tracks(3)
        val player = create { p ->
            repeat(8) { p.shuffleAndPlay(source, "pending:$it") }
        }
        ready("pending:7", 3)
        compose.runOnIdle { repeat(8) { player.shuffleAndPlay(source, "connected:$it") } }
        ready("connected:7", 3)
    }
}
