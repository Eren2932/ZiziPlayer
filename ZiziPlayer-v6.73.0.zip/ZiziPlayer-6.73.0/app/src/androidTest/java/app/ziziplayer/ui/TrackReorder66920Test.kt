package app.ziziplayer.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.*
import kotlinx.coroutines.CompletableDeferred
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Requires Android/Compose. NOT executed by offline source/Java checks. */
class TrackReorder66920Test {
    @get:Rule val compose = createComposeRule()
    private lateinit var state: TrackReorderState<String>
    private val heroHeight = mutableStateOf(220.dp)
    private var writes = 0

    private fun mount(withImport: Boolean = false) {
        compose.setContent {
            var rows by remember { mutableStateOf((0..11).map { "row:$it" }) }
            val list = rememberLazyListState()
            val reorder = rememberTrackReorder(list, rows, { it },
                firstRowIndex = if (withImport) 2 else 1, topInset = 56.dp) { _, after ->
                writes++; rows = after; true
            }
            SideEffect { state = reorder }
            LazyColumn(Modifier.requiredSize(360.dp, 640.dp), state = list) {
                item(key = "hero") { Box(Modifier.fillMaxWidth().height(heroHeight.value).testTag("hero")) }
                if (withImport) item(key = "import") { Box(Modifier.fillMaxWidth().height(48.dp).testTag("import")) }
                items(reorder.items, key = { it }) { id ->
                    Text(id, Modifier.fillMaxWidth().height(56.dp)
                        .animateItem(fadeInSpec = null, fadeOutSpec = null,
                            placementSpec = if (reorder.animatePlacement(id)) spring(dampingRatio = 1f, stiffness = 600f) else null)
                        .reorderRow(reorder, id).testTag(id))
                }
            }
        }
    }

    private fun assertAboveTracksIsProtected() {
        val info = state.list.layoutInfo
        val slot = info.visibleItemsInfo.first { it.key == "row:3" }
        val boundary = info.visibleItemsInfo.filter { it.key.toString().startsWith("row:") }.minOf { it.offset }
        assertTrue("lifted row entered hero/import", slot.offset + state.translation("row:3") >= boundary - .01f)
    }

    @Test fun expandedHeroIsNotADragTargetEvenBeforeRemeasure() {
        mount(); compose.mainClock.autoAdvance = false
        compose.runOnIdle {
            assertTrue(state.start("row:3")); state.dragBy(-10000f)
            assertAboveTracksIsProtected() // old layout + new preview keys
        }
        compose.mainClock.advanceTimeByFrame()
        compose.runOnIdle {
            assertAboveTracksIsProtected(); assertTrue(state.previewChangesFirst)
            state.cancel(); assertFalse(state.previewChangesFirst); assertEquals("row:0",state.items.first())
        }
    }

    @Test fun artistImportSlotDoesNotFreezeTheSecondMove() {
        mount(withImport = true); compose.mainClock.autoAdvance = false
        compose.runOnIdle { assertTrue(state.start("row:3")); state.dragBy(-10000f) }
        compose.mainClock.advanceTimeByFrame()
        compose.runOnIdle {
            assertEquals("row:3",state.items.first()); assertAboveTracksIsProtected()
            state.dragBy(10000f) // return the raw pointer to its starting row, after remeasure
        }
        compose.mainClock.advanceTimeByFrame()
        compose.runOnIdle { assertTrue(state.items.indexOf("row:3") > 0); state.cancel() }
    }

    @Test fun releaseInSwapFrameKeepsTheLiftedRowBelowHero() {
        mount(); compose.mainClock.autoAdvance = false
        compose.runOnIdle {
            assertTrue(state.start("row:3")); state.dragBy(-10000f); state.finish()
            assertAboveTracksIsProtected()
        }
        repeat(20) {
            compose.mainClock.advanceTimeByFrame()
            compose.runOnIdle { assertAboveTracksIsProtected() }
        }
        compose.mainClock.autoAdvance = true
        compose.waitForIdle()
        compose.runOnIdle { assertEquals(1,writes); assertEquals("row:3",state.items.first()) }
    }

    @Test fun headerResizeDoesNotStartTrackPlacementSprings() {
        mount(); compose.mainClock.autoAdvance = false
        for (height in listOf(180, 140, 100, 140, 180, 220)) {
            compose.runOnIdle { heroHeight.value = height.dp }
            compose.mainClock.advanceTimeByFrame()
            val hero = compose.onNodeWithTag("hero").fetchSemanticsNode().boundsInRoot
            val row = compose.onNodeWithTag("row:0").fetchSemanticsNode().boundsInRoot
            assertEquals("track must touch hero on the same frame", hero.bottom,row.top,1f)
            compose.runOnIdle { assertFalse(state.animatePlacement("row:0")); assertEquals(0,writes) }
        }
    }

    private fun art(color: Color): Art {
        val image = Bitmap.createBitmap(4,4,Bitmap.Config.ARGB_8888).apply { eraseColor(color.toArgb()) }.asImageBitmap()
        return Art(image,1,ArtSwatches(color,color,color))
    }

    @Test fun newCoverKeepsPreviousPairUntilDecodeFinishes() {
        val red = art(Color.Red); val blue = art(Color.Blue)
        val request = mutableStateOf("a")
        val ready = CompletableDeferred<Art?>()
        var visible: CollectionCover? = null
        compose.setContent {
            val target = request.value
            val loaded = rememberRetainedCollectionArt(target, if (target == "a") red else null) {
                if (target == "a") red else ready.await()
            }
            val cover = collectionCoverForArt(loaded, true)
            SideEffect { visible = cover }
            CollectionCoverImage(cover, Modifier.size(100.dp))
        }
        compose.runOnIdle { request.value = "b" }
        compose.waitForIdle()
        compose.runOnIdle {
            assertSame(red,visible!!.art)
            assertTintNear(Color(app.ziziplayer.ui.theme.ArtworkColorMath.coverTop(android.graphics.Color.RED)),visible!!.tint)
            ready.complete(blue)
        }
        compose.waitForIdle()
        compose.runOnIdle {
            assertSame(blue,visible!!.art)
            assertTintNear(Color(app.ziziplayer.ui.theme.ArtworkColorMath.coverTop(android.graphics.Color.BLUE)),visible!!.tint)
        }
    }

    @Test fun lateDecodeCannotOverwriteNewerCover() {
        val red = art(Color.Red); val blue = art(Color.Blue)
        val request = mutableStateOf("a")
        val late = CompletableDeferred<Art?>()
        var visible: Art? = null
        compose.setContent {
            val target = request.value
            val loaded = rememberRetainedCollectionArt(target, if (target == "a") red else null) {
                when (target) { "a" -> red; "b" -> late.await(); else -> blue }
            }
            SideEffect { visible = loaded }
        }
        compose.runOnIdle { request.value = "b" }; compose.waitForIdle()
        compose.runOnIdle { request.value = "c" }; compose.waitForIdle()
        compose.runOnIdle { assertSame(blue,visible); late.complete(red) }
        compose.waitForIdle()
        compose.runOnIdle { assertSame(blue,visible) }
    }

    @Test fun missingCoverDoesNotKeepPreviousTrackForever() {
        val red = art(Color.Red); val request = mutableStateOf("a")
        var visible: Art? = null
        compose.setContent {
            val target = request.value
            val loaded = rememberRetainedCollectionArt(target, if (target == "a") red else null) {
                if (target == "a") red else null
            }
            SideEffect { visible = loaded }
        }
        compose.runOnIdle { assertSame(red,visible); request.value = "missing" }
        compose.waitForIdle()
        compose.runOnIdle { assertNull(visible) }
    }
    private fun assertTintNear(expected: Color, actual: Color) {
        assertEquals(expected.red,actual.red,.005f)
        assertEquals(expected.green,actual.green,.005f)
        assertEquals(expected.blue,actual.blue,.005f)
    }

    @Test fun imageAndTintHaveIntermediateFramesThenReachNewCover() {
        val red = art(Color.Red); val blue = art(Color.Blue)
        val target = mutableStateOf(red)
        var visible: CollectionCover? = null
        compose.setContent {
            val cover = collectionCoverForArt(target.value, true)
            SideEffect { visible = cover }
            CollectionCoverImage(cover,Modifier.size(100.dp).testTag("cover:fade"))
        }
        compose.mainClock.autoAdvance = false
        var before = Color.Transparent
        compose.runOnIdle { before = visible!!.tint; target.value = blue }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(80)
        val middle = compose.onNodeWithTag("cover:fade").captureToImage().toPixelMap()
        val pixel = middle[middle.width/2,middle.height/2]
        assertTrue("image must blend, not cut to new pixels",pixel.red > .01f && pixel.blue > .01f)
        compose.runOnIdle { assertTrue("tint must move with image",visible!!.tint != before) }
        compose.mainClock.advanceTimeBy(220)
        val after = compose.onNodeWithTag("cover:fade").captureToImage().toPixelMap()
        val final = after[after.width/2,after.height/2]
        assertTrue(final.blue > .95f && final.red < .05f)
        compose.runOnIdle {
            assertTintNear(Color(app.ziziplayer.ui.theme.ArtworkColorMath.coverTop(android.graphics.Color.BLUE)),visible!!.tint)
        }
    }

}
