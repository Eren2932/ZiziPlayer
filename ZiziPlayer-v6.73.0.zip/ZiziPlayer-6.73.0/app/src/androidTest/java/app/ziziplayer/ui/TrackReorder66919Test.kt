package app.ziziplayer.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.rememberTrackReorder
import app.ziziplayer.ui.components.reorderHandle
import app.ziziplayer.ui.components.reorderRow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Real pointer input tests. Require connectedDebugAndroidTest; not run by Python source guards. */
@OptIn(ExperimentalFoundationApi::class)
class TrackReorder66919Test {
    @get:Rule val compose = createComposeRule()
    private var savedOrder = (0..9).map { "row:$it" }
    private var writes = 0
    private var menus = 0
    private var plays = 0
    private var selections = 0

    private fun mount(acceptWrite: Boolean = true) {
        compose.setContent {
            var rows by remember { mutableStateOf(savedOrder) }
            val list = rememberLazyListState()
            val reorder = rememberTrackReorder(list, rows, { it }) { _, after ->
                writes++
                if (acceptWrite) { savedOrder = after; rows = after }
                acceptWrite
            }
            LazyColumn(Modifier.requiredSize(360.dp, 640.dp).testTag("list"), state = list) {
                items(reorder.items, key = { it }) { id ->
                    Row(Modifier.fillMaxWidth().height(64.dp).reorderRow(reorder, id)
                        .testTag(id).combinedClickable(onClick = { plays++ }, onLongClick = { selections++ })) {
                        Text(id, Modifier.weight(1f))
                        Box(Modifier.size(48.dp).testTag("handle:$id")
                            .reorderHandle(reorder, id) { menus++ }) { Text("…") }
                    }
                }
            }
        }
    }

    @Test fun shortTapOpensMenuButDoesNotPlayOrSelect() {
        mount()
        compose.onNodeWithTag("handle:row:2", useUnmergedTree = true).performTouchInput { click() }
        compose.runOnIdle {
            assertEquals(1, menus); assertEquals(0, plays); assertEquals(0, selections); assertEquals(0, writes)
        }
    }

    @Test fun longPressMovesAcrossSeveralRowsAndCommitsOnce() {
        mount()
        val from = compose.onNodeWithTag("handle:row:4", useUnmergedTree = true).fetchSemanticsNode().boundsInRoot.center
        val to = compose.onNodeWithTag("handle:row:0", useUnmergedTree = true).fetchSemanticsNode().boundsInRoot.center
        compose.onRoot().performTouchInput {
            down(from); advanceEventTime(700); moveTo(to); advanceEventTime(32); up()
        }
        compose.waitUntil(3000) { writes == 1 }
        compose.runOnIdle {
            assertEquals("row:4", savedOrder.first())
            assertEquals(0, menus); assertEquals(0, plays); assertEquals(0, selections)
        }
    }

    @Test fun cancellationDoesNotPersistPreview() {
        mount()
        val start = compose.onNodeWithTag("handle:row:4", useUnmergedTree = true).fetchSemanticsNode().boundsInRoot.center
        compose.onRoot().performTouchInput {
            down(start); advanceEventTime(700); moveBy(Offset(0f, -150f)); cancel()
        }
        compose.runOnIdle { assertEquals(0, writes); assertEquals((0..9).map { "row:$it" }, savedOrder) }
    }

    @Test fun failedWriteRollsBackWithoutOpeningMenu() {
        mount(acceptWrite = false)
        val start = compose.onNodeWithTag("handle:row:4", useUnmergedTree = true).fetchSemanticsNode().boundsInRoot.center
        compose.onRoot().performTouchInput {
            down(start); advanceEventTime(700); moveBy(Offset(0f, -150f)); up()
        }
        compose.waitUntil(3000) { writes == 1 }
        compose.runOnIdle { assertEquals("row:0", savedOrder.first()); assertEquals(0, menus) }
        val a = compose.onNodeWithTag("row:0").fetchSemanticsNode().boundsInRoot
        val b = compose.onNodeWithTag("row:1").fetchSemanticsNode().boundsInRoot
        assertTrue(a.top < b.top)
    }
}
