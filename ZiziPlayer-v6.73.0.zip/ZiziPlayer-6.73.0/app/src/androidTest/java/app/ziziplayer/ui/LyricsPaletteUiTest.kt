package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.ui.components.ArtSwatches
import app.ziziplayer.ui.screens.lyricText
import app.ziziplayer.ui.theme.ArtworkColorMath
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.LyricsSurfaceTheme
import app.ziziplayer.ui.theme.ZiziPalette
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.lyricsPalette
import app.ziziplayer.ui.theme.tintedWith
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Device/emulator tests. Added for CI; not claimed as executed by the offline Java runner. */
class LyricsPaletteUiTest {
    @get:Rule val compose = createComposeRule()
    private fun player(color: Color) = basePalette().tintedWith(ArtSwatches(color, color, color))

    @Test fun lyricsScopeUpdatesAndRestoresPlayerWithoutChangingNeutralLibrary() {
        val source = mutableStateOf(player(Color(0xFF887043)))
        var inside: ZiziPalette? = null
        var outside: ZiziPalette? = null
        var materialBackground: Color? = null
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides source.value) {
                ZiziTheme(source.value) {
                    Column {
                        LyricsSurfaceTheme {
                            val palette = LocalPalette.current
                            val background = MaterialTheme.colorScheme.background
                            SideEffect { inside = palette; materialBackground = background }
                        }
                        val palette = LocalPalette.current
                        SideEffect { outside = palette }
                    }
                }
            }
        }
        fun verify() = compose.runOnIdle {
            assertEquals(lyricsPalette(source.value.artworkPrimary), inside)
            assertEquals(inside!!.bottom, materialBackground)
            assertEquals(source.value, outside)
            assertEquals(Color(0xFF9A9A9A), basePalette().subtext)
        }
        verify()
        for (next in listOf(player(Color.Red), player(Color.Blue), basePalette())) {
            compose.runOnIdle { source.value = next }
            verify()
        }
        compose.runOnIdle { assertNull(inside!!.artworkPrimary) }
    }

    @Test fun gradientPixelsRiseTowardBottomInsteadOfBlack() {
        val player = player(Color(0xFF887043))
        val target = lyricsPalette(player.artworkPrimary)
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides player) {
                LyricsSurfaceTheme {
                    val palette = LocalPalette.current
                    Box(Modifier.size(120.dp, 240.dp).testTag("lyrics-colour-ramp").background(palette.background))
                }
            }
        }
        val image = compose.onNodeWithTag("lyrics-colour-ramp").captureToImage()
        val pixels = image.toPixelMap()
        val top = pixels[image.width / 2, 0].toArgb()
        val bottom = pixels[image.width / 2, image.height - 1].toArgb()
        for ((actual, expected) in listOf(top to target.top.toArgb(), bottom to target.bottom.toArgb())) {
            for (shift in listOf(16, 8, 0)) {
                assertTrue(kotlin.math.abs(((actual ushr shift) and 255) - ((expected ushr shift) and 255)) <= 2)
            }
        }
        assertTrue(ArtworkColorMath.luminance(bottom) > ArtworkColorMath.luminance(top))
    }

    @Test fun enhancedLrcUsesOpaquePendingInkWithoutInventingWordTiming() {
        val palette = lyricsPalette(Color(0xFF887043))
        val line = LrcTimeline.Line(1000, "One two", listOf(
            LrcTimeline.Word(1000, 0, 3), LrcTimeline.Word(1500, 4, 7)))
        val text = lyricText(line, 0, palette.text, pendingInk = palette.subtext)
        assertEquals(palette.subtext, text.spanStyles.first().item.color)
        assertEquals(palette.text, text.spanStyles.last().item.color)
        assertEquals(1f, text.spanStyles.first().item.color.alpha, 0f)
        assertEquals(3, text.spanStyles.last().end)
        val plain = lyricText(LrcTimeline.Line(1000, "One two"), -1, palette.text, pendingInk = palette.subtext)
        assertTrue(plain.spanStyles.isEmpty())
        // Inline player lyrics keep the existing default, not the full-screen palette.
        assertEquals(.5f, lyricText(line, -1, palette.text).spanStyles.first().item.color.alpha, .005f)
    }
}
