package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.screens.LibraryAddPanel
import app.ziziplayer.ui.screens.LibrarySearchBlock
import app.ziziplayer.ui.screens.LibraryToolbar
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Updated for 6.71.2. These tests require an Android device/emulator. */
class Library6710UiTest {
    @get:Rule val compose = createComposeRule()
    private val view = mutableStateOf(LibraryView.GRID)
    private val importing = mutableStateOf(false)
    private val shuffle = mutableStateOf(false)
    private val hasTracks = mutableStateOf(true)
    private var shuffleStarts = 0

    private fun toolbar(width: Dp = 360.dp) {
        compose.setContent {
            Box(Modifier.width(width)) {
                LibraryToolbar(sortLabel = "Недавние", view = view.value, addExpanded = importing.value,
                    searchOpen = false, shuffle = shuffle.value, shuffleEnabled = hasTracks.value,
                    onView = { view.value = it }, onSort = {}, onSearch = {},
                    onShuffle = { shuffle.value = true; shuffleStarts++ }, onAdd = { importing.value = !importing.value })
            }
        }
    }
    @Test fun noLongClickAction() {
        toolbar()
        compose.onNodeWithTag("library-view-toggle")
            .assert(SemanticsMatcher.keyNotDefined(SemanticsActions.OnLongClick))
        compose.onNodeWithTag("library-view-LIST").assertDoesNotExist()
    }
    @Test fun tapCycles() {
        toolbar()
        listOf(LibraryView.LARGE_GRID, LibraryView.COMPACT, LibraryView.LIST, LibraryView.GRID).forEach { next ->
            compose.onNodeWithTag("library-view-toggle").performClick()
            compose.runOnIdle { assertEquals(next, view.value) }
        }
    }
    @Test fun shuffleFollowsExternalPlayerState() {
        toolbar()
        compose.onNodeWithTag("library-shuffle-toggle").assertIsNotSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertDoesNotExist()
        // Simulate the full player changing shuffle, without clicking the library button.
        compose.runOnIdle { shuffle.value = true }
        compose.onNodeWithTag("library-shuffle-toggle").assertIsSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertIsDisplayed()
        repeat(2) { compose.onNodeWithTag("library-shuffle-toggle").performClick().assertIsSelected() }
        compose.runOnIdle { assertEquals(2, shuffleStarts); shuffle.value = false }
        compose.onNodeWithTag("library-shuffle-toggle").assertIsNotSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertDoesNotExist()
    }
    @Test fun emptyLibraryCannotStartShuffle() {
        hasTracks.value = false
        toolbar()
        compose.onNodeWithTag("library-shuffle-toggle").assertIsNotEnabled().performTouchInput { click() }
        compose.runOnIdle { assertFalse(shuffle.value); assertEquals(0, shuffleStarts) }
    }
    @Test fun plusIsAToggleNotImmediateAction() {
        toolbar()
        compose.onNodeWithContentDescription("Добавить в медиатеку").performClick()
        compose.runOnIdle { assertTrue(importing.value) }
        compose.onNodeWithContentDescription("Скрыть добавление").performClick()
        compose.runOnIdle { assertFalse(importing.value) }
    }
    @Test fun rapidPlusTapsSettleOnLatestState() {
        toolbar()
        compose.mainClock.autoAdvance = false
        repeat(5) { compose.onNodeWithTag("library-add-toggle").performClick(); compose.mainClock.advanceTimeByFrame() }
        compose.mainClock.advanceTimeBy(350)
        compose.mainClock.autoAdvance = true
        compose.onNodeWithContentDescription("Скрыть добавление").assertIsSelected()
        compose.runOnIdle { assertTrue(importing.value) }
    }
    @Test fun narrowToolbarDoesNotOverlap() {
        toolbar(240.dp)
        val shuffleBounds = compose.onNodeWithTag("library-shuffle-toggle").fetchSemanticsNode().boundsInRoot
        val importBounds = compose.onNodeWithTag("library-add-toggle").fetchSemanticsNode().boundsInRoot
        val viewBounds = compose.onNodeWithTag("library-view-toggle").fetchSemanticsNode().boundsInRoot
        assertTrue(shuffleBounds.right <= importBounds.left + 1f)
        assertTrue(importBounds.right <= viewBounds.left + 1f)
        compose.onNodeWithTag("library-view-toggle").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(LibraryView.LARGE_GRID, view.value) }
    }
    @Test fun searchClearsAndCloses() {
        val open = mutableStateOf(true)
        val query = mutableStateOf("")
        compose.setContent {
            Column {
                LibraryToolbar(sortLabel = "Недавние", view = view.value, addExpanded = importing.value,
                    searchOpen = open.value, shuffle = shuffle.value, onView = { view.value = it }, onSort = {},
                    onSearch = { open.value = !open.value; if (!open.value) query.value = "" },
                    onShuffle = {}, onAdd = {})
                LibrarySearchBlock(open.value, query.value, "Поиск по медиатеке",
                    onQuery = { if (open.value) query.value = it })
            }
        }
        compose.onNodeWithTag("library-search-field").performTextInput("night")
        compose.waitUntil(3000) { query.value == "night" }
        compose.onNodeWithContentDescription("Очистить поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertTextEquals("")
        compose.runOnIdle { assertEquals("", query.value) }
        // Search closes from its magnifier in the toolbar; the field has no back arrow.
        compose.onNodeWithContentDescription("Закрыть поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertDoesNotExist()
        compose.runOnIdle { assertFalse(open.value); assertEquals("", query.value) }
    }
    @Test fun addPanelSupportsLargeTextAndSeparateActions() {
        val clicks = IntArray(3)
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale = 1.8f)) {
                Box(Modifier.width(280.dp)) {
                    LibraryAddPanel(enabled = true, onCreatePlaylist = { clicks[0]++ },
                        onAddFolder = { clicks[1]++ }, onImport = { clicks[2]++ })
                }
            }
        }
        compose.onNodeWithText("Новый плейлист").assertIsDisplayed()
        compose.onNodeWithText("Добавить папку").assertIsDisplayed()
        compose.onNodeWithText("Из файла или ссылки").assertIsDisplayed()
        listOf("library-create-playlist", "library-add-folder", "library-import-playlist").forEach {
            compose.onNodeWithTag(it).performClick()
        }
        compose.runOnIdle { assertArrayEquals(intArrayOf(1, 1, 1), clicks) }
    }
    @Test fun closingPanelDisablesEveryAction() {
        var clicks = 0
        compose.setContent {
            LibraryAddPanel(enabled = false, onCreatePlaylist = { clicks++ },
                onAddFolder = { clicks++ }, onImport = { clicks++ })
        }
        listOf("library-create-playlist", "library-add-folder", "library-import-playlist").forEach {
            compose.onNodeWithTag(it).assertIsNotEnabled().performTouchInput { click() }
        }
        compose.runOnIdle { assertEquals(0, clicks) }
    }
}
