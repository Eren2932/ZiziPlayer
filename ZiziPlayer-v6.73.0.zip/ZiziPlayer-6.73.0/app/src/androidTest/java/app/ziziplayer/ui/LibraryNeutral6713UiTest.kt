package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.screens.LibrarySearchBlock
import app.ziziplayer.ui.screens.ZiziSheetScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import app.ziziplayer.ui.theme.ZiziPalette
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Device/emulator regressions. Not executed by local Python source contracts. */
class LibraryNeutral6713UiTest {
    @get:Rule val compose = createComposeRule()
    private val cover = mutableStateOf(basePalette().copy(
        surface = Color(0xFF552020), chip = Color(0xFF883020), accent = Color.Cyan))

    @Test fun neutralScopeIgnoresCoverAndRestoresPlayerTheme() {
        var inside: ZiziPalette? = null
        var outside: ZiziPalette? = null
        var materialSurface: Color? = null
        var materialPrimary: Color? = null
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides cover.value) {
                ZiziTheme(cover.value) {
                    Column {
                        NeutralSurfaceTheme {
                            val palette = LocalPalette.current
                            val colors = MaterialTheme.colorScheme
                            SideEffect { inside = palette; materialSurface = colors.surface; materialPrimary = colors.primary }
                        }
                        val inherited = LocalPalette.current
                        SideEffect { outside = inherited }
                    }
                }
            }
        }
        fun verify() = compose.runOnIdle {
            assertEquals(basePalette(), inside)
            assertEquals(basePalette().surface, materialSurface)
            assertEquals(basePalette().accent, materialPrimary)
            assertEquals(cover.value, outside)
        }
        verify()
        compose.runOnIdle { cover.value = cover.value.copy(surface = Color.Blue, chip = Color.Green, accent = Color.Yellow) }
        verify()
    }

    @Test fun sheetHasNeutralContentAndMaterialColors() {
        var observed: ZiziPalette? = null
        var materialSurface: Color? = null
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides cover.value) {
                ZiziTheme(cover.value) {
                    ZiziSheetScaffold(onDismiss = {}) {
                        val palette = LocalPalette.current
                        val surface = MaterialTheme.colorScheme.surface
                        SideEffect { observed = palette; materialSurface = surface }
                        Box(Modifier.width(240.dp).height(80.dp))
                    }
                }
            }
        }
        compose.runOnIdle {
            assertEquals(basePalette(), observed)
            assertEquals(basePalette().surface, materialSurface)
        }
        compose.runOnIdle { cover.value = cover.value.copy(surface = Color.Green, chip = Color.Blue) }
        compose.runOnIdle { assertEquals(basePalette(), observed); assertEquals(basePalette().surface, materialSurface) }
    }

    @Test fun searchInsetsMatchCardGeometryWithLargeText() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale = 1.8f)) {
                NeutralSurfaceTheme {
                    Box(Modifier.width(300.dp)) {
                        LibrarySearchBlock(true, "", "Поиск по медиатеке", onQuery = {})
                    }
                }
            }
        }
        val outer = compose.onNodeWithTag("library-search-container").fetchSemanticsNode().boundsInRoot
        val surface = compose.onNodeWithTag("library-search-surface").fetchSemanticsNode().boundsInRoot
        val inset = LibraryGeometry.edge(outer.width)
        assertEquals(inset, surface.left - outer.left, 1.1f)
        assertEquals(inset, outer.right - surface.right, 1.1f)
        assertTrue(surface.width < outer.width)
        compose.onNodeWithTag("library-search-field").performTextInput("night")
        compose.onNodeWithContentDescription("Очистить поиск").assertIsDisplayed().performClick()
        compose.onNodeWithTag("library-search-field").assertTextEquals("")
    }
}
