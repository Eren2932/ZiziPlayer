package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.ArtSwatches
import app.ziziplayer.ui.theme.ArtworkSurfaceMath
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziBrand
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.lyricsPalette
import app.ziziplayer.ui.theme.tintedWith
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Rule
import org.junit.Test

/** Role/render integration. Not a screenshot of MiniPlayer; that widget has separate wiring guards. */
class ArtworkSurfaceUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun dedicatedCapsulePixelsUpdateAndDisableWithoutChangingPanels() {
        val swatches = mutableStateOf<ArtSwatches?>(ArtSwatches(Color(0xFF37A4C6), Color(0xFF3C3361), Color(0xFF18535A)))
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides basePalette().tintedWith(swatches.value)) {
                val p = LocalPalette.current
                Column {
                    Box(Modifier.size(80.dp).testTag("capsule-role").background(p.miniPlayer))
                    Box(Modifier.size(80.dp).testTag("panel-role").background(p.surface))
                }
            }
        }
        for (next in listOf(swatches.value, ArtSwatches(Color(0xFFAB312F), Color.Red, Color(0xFF46100D)), null)) {
            compose.runOnIdle { swatches.value = next }
            val expected = basePalette().tintedWith(next)
            for ((tag, target) in listOf("capsule-role" to expected.miniPlayer, "panel-role" to expected.surface)) {
                val image = compose.onNodeWithTag(tag).captureToImage()
                assertEquals(target.toArgb(), image.toPixelMap()[image.width / 2, image.height / 2].toArgb())
            }
            if (next != null) assertNotEquals(expected.surface, expected.miniPlayer)
        }
    }

    @Test fun rolesAreIndependentAndLyricsKeepsTheOriginalPrimary() {
        val primary = Color(0xFFAB312F)
        val p = basePalette().tintedWith(ArtSwatches(primary, Color.Blue, Color(0xFF46100D)))
        assertEquals(ZiziBrand, p.brand)
        assertEquals(primary, p.artworkPrimary)
        assertEquals(primary, lyricsPalette(p.artworkPrimary).artworkPrimary)
        assertNotEquals(p.top, Color(ArtworkSurfaceMath.collectionTop(primary.toArgb())))
        assertNotEquals(p.miniPlayer, p.surface)
        assertEquals(Color(0xFFE0E0E0), p.miniPlayerSubtext)
        assertEquals(Color(0xFFE0E0E0), p.playerHeaderSubtext)
        assertEquals(basePalette().subtext.copy(alpha = 0.85f), basePalette().playerHeaderSubtext)
        assertEquals(basePalette().surface, basePalette().miniPlayer)
    }
}
