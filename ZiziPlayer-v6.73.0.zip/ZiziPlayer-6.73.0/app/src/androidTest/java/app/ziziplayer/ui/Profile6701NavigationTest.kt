package app.ziziplayer.ui

import androidx.activity.OnBackPressedDispatcher
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.ProfileDestinationHost
import app.ziziplayer.ui.components.RootBackHandler
import app.ziziplayer.ui.components.surfaceInputBoundary
import app.ziziplayer.ui.screens.ProfileTab
import app.ziziplayer.ui.screens.ProfileTabs
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Compose integration fixture for the production back dispatcher/host/tabs with synthetic rows.
 * No network, account login, Media3 or MainActivity end-to-end claim. Requires Android execution. */
class Profile6701NavigationTest {
    @get:Rule val compose = createComposeRule()
    private var profile by mutableStateOf(true)
    private var manager by mutableStateOf(false)
    private var settings by mutableStateOf(false)
    private var equalizer by mutableStateOf(false)
    private var player by mutableStateOf(false)
    private var mounted by mutableStateOf(false)
    private var profileMounts = 0
    private var profileDisposals = 0
    private var contentBacks = 0
    private var settingsBacks = 0
    private var managerBacks = 0
    private lateinit var dispatcher: OnBackPressedDispatcher
    private lateinit var list: LazyListState
    private var observedTab = ProfileTab.PLAYLISTS

    private fun mount() {
        compose.setContent {
            dispatcher = checkNotNull(LocalOnBackPressedDispatcherOwner.current).onBackPressedDispatcher
            val target = RootBackPolicy.target(false, false, equalizer, player, mounted, settings, profile, manager)
            ZiziTheme(basePalette()) {
                Box(Modifier.fillMaxSize()) {
                    if (profile) Box(Modifier.fillMaxSize()
                        .drawWithContent { if (!mounted && !settings && !equalizer) drawContent() }
                        .then(if (mounted || settings || equalizer) Modifier.clearAndSetSemantics { } else Modifier)) {
                        ProfileDestinationHost(managerOpen = manager, profile = {
                            var selected by rememberSaveable { mutableStateOf(ProfileTab.PLAYLISTS) }
                            val rows = rememberLazyListState()
                            SideEffect { list = rows; observedTab = selected }
                            DisposableEffect(Unit) {
                                profileMounts++
                                onDispose { profileDisposals++ }
                            }
                            Column(Modifier.fillMaxSize()) {
                                ProfileTabs(selected, 1f) { selected = it }
                                LazyColumn(Modifier.weight(1f).testTag("fixture-tracks"), state = rows) {
                                    items((0 until 80).toList(), key = { it }) {
                                        Text("fixture-track-$it", Modifier.fillMaxWidth().height(48.dp))
                                    }
                                }
                                Button(onClick = { player = true; mounted = true }, modifier = Modifier.testTag("fixture-mini")) {
                                    Text("Открыть плеер")
                                }
                            }
                        }, manager = {
                            BackHandler(enabled = target == RootBackPolicy.Target.CHILD && !settings) {
                                managerBacks++; manager = false
                            }
                            Box(Modifier.fillMaxSize().background(Color.Black)) { Text("manager") }
                        })
                    }
                    if (settings) {
                        BackHandler(enabled = target == RootBackPolicy.Target.CHILD) { settingsBacks++; settings = false }
                        Box(Modifier.fillMaxSize().background(Color.Black).surfaceInputBoundary()) { Text("settings") }
                    }
                    if (mounted) Box(Modifier.fillMaxSize().background(Color.Black).surfaceInputBoundary()) {
                        Button(onClick = { player = false }, modifier = Modifier.testTag("fixture-close")) { Text("Закрыть плеер") }
                    }
                    if (equalizer) Box(Modifier.fillMaxSize().background(Color.Black).surfaceInputBoundary()) { Text("equalizer") }
                }
                RootBackHandler(target = target, onDrawer = {}, onEqualizer = { equalizer = false },
                    onPlayer = { player = false }, onProfile = { profile = false }, onContent = { contentBacks++ })
            }
        }
    }

    private fun back() { compose.runOnUiThread { dispatcher.onBackPressed() }; compose.waitForIdle() }
    private fun finishPlayerExit() { compose.runOnIdle { mounted = false }; compose.waitForIdle() }

    @Test fun allInlineTrackTabsKeepSelectionAndDeepScrollAfterPlayerBack() {
        mount()
        for (tab in listOf(ProfileTab.FAVORITES, ProfileTab.RECENT, ProfileTab.DOWNLOADS)) {
            compose.onNodeWithText(tab.label).performScrollTo().performClick()
            compose.onNodeWithTag("fixture-tracks").performScrollToIndex(27)
            var index = 0; var offset = 0
            compose.runOnIdle { index = list.firstVisibleItemIndex; offset = list.firstVisibleItemScrollOffset }
            compose.onNodeWithTag("fixture-mini").performClick()
            back()
            compose.runOnIdle { assertFalse(player); assertTrue(profile) }
            finishPlayerExit()
            compose.runOnIdle {
                assertEquals(tab, observedTab)
                assertEquals(index, list.firstVisibleItemIndex)
                assertEquals(offset, list.firstVisibleItemScrollOffset)
                assertEquals(1, profileMounts); assertEquals(0, profileDisposals)
            }
        }
    }

    @Test fun closeButtonPreservesTheSameProfileInstance() {
        mount()
        compose.onNodeWithText("Избранные").performClick()
        compose.onNodeWithTag("fixture-mini").performClick()
        compose.onNodeWithTag("fixture-close").performClick()
        finishPlayerExit()
        compose.runOnIdle {
            assertTrue(profile); assertEquals(ProfileTab.FAVORITES, observedTab)
            assertEquals(1, profileMounts); assertEquals(0, profileDisposals)
        }
    }

    @Test fun repeatedBackDuringExitDoesNotCloseProfile() {
        mount()
        compose.onNodeWithTag("fixture-mini").performClick()
        back(); back(); back()
        compose.runOnIdle { assertFalse(player); assertTrue(mounted); assertTrue(profile); assertEquals(0, contentBacks) }
        finishPlayerExit()
        back()
        compose.runOnIdle { assertFalse(profile); assertEquals(0, contentBacks) }
    }

    @Test fun settingsRegisteredAfterRootCannotInterceptPlayerOrEqualizerBack() {
        mount()
        compose.runOnIdle { settings = true }
        compose.waitForIdle()
        compose.runOnIdle { player = true; mounted = true; equalizer = true }
        back()
        compose.runOnIdle { assertFalse(equalizer); assertTrue(player); assertTrue(settings); assertEquals(0, settingsBacks) }
        back()
        compose.runOnIdle { assertFalse(player); assertTrue(settings); assertEquals(0, settingsBacks) }
        finishPlayerExit()
        back()
        compose.runOnIdle { assertFalse(settings); assertTrue(profile); assertEquals(1, settingsBacks) }
    }

    @Test fun managerBackReturnsToMountedProfileInsteadOfDismissingAccount() {
        mount()
        compose.onNodeWithText("Избранные").performClick()
        compose.onNodeWithTag("fixture-tracks").performScrollToIndex(31)
        var index = 0
        compose.runOnIdle { index = list.firstVisibleItemIndex; manager = true }
        back()
        compose.runOnIdle {
            assertFalse(manager); assertTrue(profile); assertEquals(1, managerBacks)
            assertEquals(ProfileTab.FAVORITES, observedTab); assertEquals(index, list.firstVisibleItemIndex)
            assertEquals(1, profileMounts); assertEquals(0, profileDisposals)
        }
    }

    @Test fun managerRegisteredAfterRootCannotStealPlayerBack() {
        mount()
        compose.runOnIdle { manager = true }
        compose.waitForIdle()
        compose.runOnIdle { player = true; mounted = true }
        back()
        compose.runOnIdle { assertFalse(player); assertTrue(manager); assertTrue(profile); assertEquals(0, managerBacks) }
        finishPlayerExit()
        back()
        compose.runOnIdle { assertFalse(manager); assertTrue(profile); assertEquals(1, managerBacks) }
    }
}
