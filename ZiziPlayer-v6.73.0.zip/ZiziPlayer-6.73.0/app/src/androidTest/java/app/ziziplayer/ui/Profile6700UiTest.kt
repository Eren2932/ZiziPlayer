package app.ziziplayer.ui

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import app.ziziplayer.ui.components.ProfileBackdrop
import app.ziziplayer.ui.components.rememberProfileBackdrop
import app.ziziplayer.ui.screens.ProfilePinnedHeader
import app.ziziplayer.ui.screens.ProfileTab
import app.ziziplayer.ui.screens.ProfileTabs
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import java.io.ByteArrayOutputStream
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Device/emulator tests. Deliberately NOT presented as executed by the offline Java checks. */
class Profile6700UiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun tabsSwitchLocallyAndExposeSelection() {
        var selected by mutableStateOf(ProfileTab.PLAYLISTS)
        compose.setContent {
            ZiziTheme(basePalette()) { ProfileTabs(selected, 1f) { selected = it } }
        }
        compose.onNodeWithText("Плейлисты").assertIsSelected()
        compose.onNodeWithText("Избранные").performClick().assertIsSelected()
        compose.runOnIdle { assertEquals(ProfileTab.FAVORITES, selected) }
        compose.onNodeWithText("Недавние").performScrollTo().performClick().assertIsSelected()
        compose.onNodeWithText("Загрузки").performScrollTo().performClick().assertIsSelected()
    }

    @Test fun collapsedNameHasNoInvisibleAccessibilityTwinAndControlsStillWork() {
        var progress by mutableFloatStateOf(0f)
        var back = 0; var settings = 0; var menu = 0
        compose.setContent {
            ZiziTheme(basePalette()) {
                ProfilePinnedHeader("Devzis", { progress }, { back++ }, { settings++ }, { menu++ })
            }
        }
        compose.onNodeWithText("Devzis").assertDoesNotExist()
        compose.onNodeWithContentDescription("Назад").performClick()
        compose.onNodeWithContentDescription("Настройки").performClick()
        compose.onNodeWithContentDescription("Меню аккаунта").performClick()
        compose.runOnIdle { assertEquals(1, back); assertEquals(1, settings); assertEquals(1, menu); progress = 1f }
        compose.onNodeWithText("Devzis").assertIsDisplayed()
    }

    @Test fun deepScrollCurtainFullyCoversAccountColourIncludingStatusRegion() {
        compose.setContent {
            ProfileBackdrop("", Color(0xFFFF6430), Color(0xFF121212), 1f, { 10000f }, Modifier.fillMaxSize())
        }
        val pixels = compose.onRoot().captureToImage().toPixelMap()
        for (x in listOf(1, pixels.width / 2, pixels.width - 2)) {
            for (y in listOf(1, pixels.height / 2, pixels.height - 2)) {
                val c = pixels[x,y]
                assertEquals(18f/255, c.red, .01f)
                assertEquals(c.red, c.green, .001f)
                assertEquals(c.green, c.blue, .001f)
            }
        }
    }

    @Test fun removeAndReplaceAvatarNeverRetainsPreviousBackdrop() {
        val red = avatar(android.graphics.Color.RED)
        val blue = avatar(android.graphics.Color.BLUE)
        var payload by mutableStateOf(red)
        var observed: ImageBitmap? = null
        compose.setContent {
            val image = rememberProfileBackdrop(payload)
            SideEffect { observed = image }
        }
        compose.waitUntil(5000) { observed != null }
        compose.runOnIdle { assertEquals(android.graphics.Color.RED, observed!!.asAndroidBitmap().getPixel(64,64)); payload = "" }
        compose.waitForIdle()
        compose.runOnIdle { assertNull(observed); payload = blue }
        compose.waitUntil(5000) { observed?.asAndroidBitmap()?.getPixel(64,64) == android.graphics.Color.BLUE }
        compose.runOnIdle { payload = "not a valid image" }
        compose.waitForIdle()
        compose.runOnIdle { assertNull(observed) }
    }

    private fun avatar(color: Int): String {
        val bitmap = Bitmap.createBitmap(8,8,Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(color)
        return ByteArrayOutputStream().use { bytes ->
            bitmap.compress(Bitmap.CompressFormat.PNG,100,bytes)
            bitmap.recycle()
            Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
        }
    }
}
