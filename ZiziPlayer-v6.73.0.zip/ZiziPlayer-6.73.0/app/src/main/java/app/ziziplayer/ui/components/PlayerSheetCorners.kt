package app.ziziplayer.ui.components

import android.os.Build
import android.view.RoundedCorner
import android.view.ViewTreeObserver
import android.view.WindowInsets
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import app.ziziplayer.ui.PlayerSheetGeometry

/**
 * Read the window, not the camera cutout, status-bar height, device name or hidden resources.
 * Each physical corner is independent (including a real zero); rotation and resized windows
 * get fresh WindowInsets. A null corner on API 31+ means no reported rounding: never invent
 * a radius for a square screen. An OEM that omits this data cannot be distinguished from it.
 */
@Composable
internal fun rememberPlayerSheetCorners(): State<PlayerSheetGeometry.Corners> {
    val view = LocalView.current
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current.density
    val snapshot = remember(view, configuration, density) {
        mutableStateOf(if (Build.VERSION.SDK_INT >= 31) readPlayerSheetCorners(view.rootView.rootWindowInsets)
            else PlayerSheetGeometry.legacy(density))
    }
    DisposableEffect(view, configuration, density) {
        // No listener needed for a density-only legacy fallback.
        if (Build.VERSION.SDK_INT < 31) return@DisposableEffect onDispose { }
        val root = view.rootView
        var previousInsets: WindowInsets? = null
        var previousWidth = -1
        var previousHeight = -1
        var previousRotation = -1
        fun refresh() {
            val insets = root.rootWindowInsets
            val rotation = root.display?.rotation ?: -1
            if (insets != previousInsets || root.width != previousWidth ||
                root.height != previousHeight || rotation != previousRotation) {
                previousInsets = insets
                previousWidth = root.width
                previousHeight = root.height
                previousRotation = rotation
                // Explicit API guard also keeps calls safe on pre-31 runtimes.
                if (Build.VERSION.SDK_INT >= 31) snapshot.value = readPlayerSheetCorners(insets)
            }
        }
        // Observe without stealing Compose's OnApplyWindowInsetsListener or consuming insets.
        // Unchanged animation frames perform no geometry allocation and no state write.
        val observer = root.viewTreeObserver
        val listener = ViewTreeObserver.OnPreDrawListener { refresh(); true }
        observer.addOnPreDrawListener(listener)
        refresh()
        onDispose {
            if (observer.isAlive) observer.removeOnPreDrawListener(listener)
            else if (root.viewTreeObserver.isAlive) root.viewTreeObserver.removeOnPreDrawListener(listener)
        }
    }
    return snapshot
}

/** Public Android values are already PX, not DP. Kept separate for real framework tests. */
@RequiresApi(31)
internal fun readPlayerSheetCorners(insets: WindowInsets?): PlayerSheetGeometry.Corners =
    PlayerSheetGeometry.Corners(
        insets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)?.radius?.toFloat() ?: 0f,
        insets?.getRoundedCorner(RoundedCorner.POSITION_TOP_RIGHT)?.radius?.toFloat() ?: 0f,
        insets?.getRoundedCorner(RoundedCorner.POSITION_BOTTOM_RIGHT)?.radius?.toFloat() ?: 0f,
        insets?.getRoundedCorner(RoundedCorner.POSITION_BOTTOM_LEFT)?.radius?.toFloat() ?: 0f
    )
