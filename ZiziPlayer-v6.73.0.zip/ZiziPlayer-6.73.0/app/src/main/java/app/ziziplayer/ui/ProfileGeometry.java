package app.ziziplayer.ui;

/** Reference: 1080 x 2400. Dimensions are dp at 360dp width, not physical screen pixels. */
public final class ProfileGeometry {
    private ProfileGeometry() {}
    public static final float INSET = 20f;
    public static final float AVATAR_TOP = 200f;
    public static final float AVATAR_SIZE = 120f;
    public static final float COVER_SIZE = 52f;
    public static final float SHEET_START = 174f;
    public static final float SHEET_END = 306f;
    public static final float BACKDROP_HEIGHT = 340f;
    public static final float PARALLAX = .28f;
    public static float scale(float width) { return Math.max(.5f, Math.min(width / 360f, 1.6f)); }
    public static float collapse(float scroll, float nameBottom, float toolbar) {
        if (nameBottom <= 0 || toolbar <= 0) return 0;
        float end = Math.max(toolbar, nameBottom - toolbar);
        float range = Math.min(toolbar, 24f * toolbar / 56f);
        return CollectionGeometry.smoothstep((scroll - (end - range)) / range);
    }
    public static float sheetOpacity(float windowY, float scroll, float scale) {
        return CollectionGeometry.smoothstep((windowY + Math.max(0, scroll) - SHEET_START * scale) /
            ((SHEET_END - SHEET_START) * scale));
    }
    public static float backgroundOffset(float scroll) { return -Math.max(0, scroll) * PARALLAX; }
}
