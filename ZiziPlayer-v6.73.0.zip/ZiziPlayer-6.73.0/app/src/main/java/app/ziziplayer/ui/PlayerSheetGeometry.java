package app.ziziplayer.ui;

/** Physical window pixels throughout. No Android dependency, clock or gesture ownership. */
public final class PlayerSheetGeometry {
    private PlayerSheetGeometry() {}

    public static final class Corners {
        public final float topLeft, topRight, bottomRight, bottomLeft;
        public Corners(float topLeft, float topRight, float bottomRight, float bottomLeft) {
            this.topLeft = positive(topLeft);
            this.topRight = positive(topRight);
            this.bottomRight = positive(bottomRight);
            this.bottomLeft = positive(bottomLeft);
        }
        public float maximum() {
            return Math.max(Math.max(topLeft, topRight), Math.max(bottomRight, bottomLeft));
        }
        @Override public boolean equals(Object other) {
            if (!(other instanceof Corners)) return false;
            Corners c = (Corners) other;
            return topLeft == c.topLeft && topRight == c.topRight
                && bottomRight == c.bottomRight && bottomLeft == c.bottomLeft;
        }
        @Override public int hashCode() {
            int h = Float.hashCode(topLeft);
            h = 31 * h + Float.hashCode(topRight);
            h = 31 * h + Float.hashCode(bottomRight);
            return 31 * h + Float.hashCode(bottomLeft);
        }
    }

    public static final Corners NONE = new Corners(0f, 0f, 0f, 0f);

    private static float positive(float value) {
        return Float.isFinite(value) && value > 0f ? value : 0f;
    }

    /** API 26-30 has no public physical-corner API. This is a UI fallback, not device data. */
    public static Corners legacy(float density) {
        float radius = positive(28f * positive(density));
        return new Corners(radius, radius, radius, radius);
    }

    /** Scale all four radii together only if an edge's two arcs would overlap. */
    public static Corners fit(Corners c, float width, float height) {
        if (c == null || positive(width) == 0f || positive(height) == 0f) return NONE;
        double scale = 1.0;
        scale = edgeScale(scale, width, (double) c.topLeft + c.topRight);
        scale = edgeScale(scale, width, (double) c.bottomLeft + c.bottomRight);
        scale = edgeScale(scale, height, (double) c.topLeft + c.bottomLeft);
        scale = edgeScale(scale, height, (double) c.topRight + c.bottomRight);
        if (scale == 1.0) return c;
        return scaled(c, scale);
    }

    private static double edgeScale(double scale, double edge, double sum) {
        return sum > 0.0 ? Math.min(scale, edge / sum) : scale;
    }

    private static Corners scaled(Corners c, double scale) {
        if (scale <= 0.0) return NONE;
        if (scale >= 1.0) return c;
        return new Corners((float) (c.topLeft * scale), (float) (c.topRight * scale),
            (float) (c.bottomRight * scale), (float) (c.bottomLeft * scale));
    }

    /**
     * r_i(y) = R_i * (3t² - 2t³), t = clamp(y / max(1px, max(R_i)), 0, 1).
     * R is already fitted to the actual layer. Fullscreen stays unchanged; after one
     * maximum-radius of travel each corner equals its system radius. C1-continuous at
     * both ends, identical on drag, cancel, button/Back and opening; no second animator.
     */
    public static Corners atOffset(Corners target, float width, float height, float offsetY) {
        Corners c = fit(target, width, height);
        double t = Math.min(1.0, positive(offsetY) / (double) Math.max(1f, c.maximum()));
        return scaled(c, t * t * (3.0 - 2.0 * t));
    }
}
