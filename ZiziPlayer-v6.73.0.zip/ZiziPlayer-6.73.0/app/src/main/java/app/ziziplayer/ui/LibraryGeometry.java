package app.ziziplayer.ui;

/** Measurements from the supplied 692 px reference; isolated from detail/track page geometry. */
public final class LibraryGeometry {
    private LibraryGeometry() {}
    public static final float REFERENCE_WIDTH = 692f;
    public static final float OUTER_PX = 29f;
    public static final float GUTTER_PX = 16f;
    public static final float SHORTCUT_HEIGHT = 90f;
    public static float edge(float width) { return Math.max(0f, width) * OUTER_PX / REFERENCE_WIDTH; }
    public static float gap(float width) { return Math.max(0f, width) * GUTTER_PX / REFERENCE_WIDTH; }
    public static float tile(float width, int columns) {
        if (columns < 1 || columns > 3) throw new IllegalArgumentException("columns must be 1..3");
        return Math.max(0f, (width - 2 * edge(width) - (columns - 1) * gap(width)) / columns);
    }
    public static float shortcutHeight(float width) {
        return Math.max(48f, Math.min(72f, width * SHORTCUT_HEIGHT / REFERENCE_WIDTH));
    }
}
