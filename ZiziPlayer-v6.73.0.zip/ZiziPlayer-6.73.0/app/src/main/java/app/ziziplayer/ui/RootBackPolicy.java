package app.ziziplayer.ui;

/** Front-to-back ownership, shared by the real Compose host and offline regression checks.
 * CHILD delegates to an editor/settings/playlist manager; never dismiss its parent as well.
 * A mounted, closing player consumes Back until its exit animation has finished. */
public final class RootBackPolicy {
    private RootBackPolicy() {}
    public enum Target { DRAWER, CHILD, EQUALIZER, PLAYER, PROFILE, CONTENT }

    public static Target target(boolean drawer, boolean editing, boolean equalizer,
            boolean playerOpen, boolean playerMounted, boolean settings,
            boolean profile, boolean playlistManager) {
        if (drawer) return Target.DRAWER;
        if (editing) return Target.CHILD;
        if (equalizer) return Target.EQUALIZER;
        if (playerOpen || playerMounted) return Target.PLAYER;
        if (settings || (profile && playlistManager)) return Target.CHILD;
        if (profile) return Target.PROFILE;
        return Target.CONTENT;
    }
}
