package app.ziziplayer.ui;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/** No Android dependencies; confirmed timestamps are seconds, not milliseconds. */
public final class ProfilePresentation {
    private ProfilePresentation() {}
    public static String plural(long n, String one, String few, String many) {
        long value = Math.max(0, n), mod100 = value % 100, mod10 = value % 10;
        return mod100 >= 11 && mod100 <= 14 ? many : mod10 == 1 ? one : mod10 >= 2 && mod10 <= 4 ? few : many;
    }
    public static String tracks(int n) { return Math.max(0, n) + " " + plural(n, "трек", "трека", "треков"); }
    public static String musicTime(long ms) {
        long minutes = Math.max(0, ms) / 60000;
        return minutes >= 60 ? (minutes / 60) + " ч" : minutes + " мин";
    }
    public static final class CloudLabel {
        public final String text;
        public final boolean confirmed;
        public CloudLabel(String text, boolean confirmed) { this.text = text; this.confirmed = confirmed; }
    }
    public static CloudLabel cloud(boolean guest, boolean ownerMatches, boolean busy, boolean choice,
            boolean error, boolean enabled, boolean available, long savedSeconds, long nowMs, ZoneId zone) {
        if (guest) return new CloudLabel("данные на телефоне", false);
        if (!ownerMatches) return new CloudLabel("проверяем сохранение", false);
        if (choice) return new CloudLabel("нужно выбрать копию", false);
        if (error) return new CloudLabel("проверьте сохранение", false);
        if (busy) return new CloudLabel("проверяем сохранение…", false);
        if (!enabled || !available || savedSeconds <= 0) return new CloudLabel("облако не подключено", false);
        try {
            LocalDate saved = Instant.ofEpochSecond(savedSeconds).atZone(zone).toLocalDate();
            LocalDate today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate();
            if (saved.isAfter(today)) return new CloudLabel("проверьте дату устройства", false);
            String date = saved.equals(today) ? "сегодня" : saved.equals(today.minusDays(1)) ? "вчера" :
                saved.format(DateTimeFormatter.ofPattern(saved.getYear() == today.getYear() ? "dd.MM" : "dd.MM.yyyy"));
            return new CloudLabel("сохранено " + date, true);
        } catch (java.time.DateTimeException ex) {
            return new CloudLabel("проверьте сохранение", false);
        }
    }
}
