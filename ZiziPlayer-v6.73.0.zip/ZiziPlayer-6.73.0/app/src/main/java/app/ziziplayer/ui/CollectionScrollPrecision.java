package app.ziziplayer.ui;

/**
 * Subpixel visual position, anchored to the REAL LazyList position. This does not scroll,
 * consume gestures, filter touch input or persist pixels. Compose 1.7.6 reports the full
 * floating-point consumed delta but exposes an integer firstVisibleItemScrollOffset.
 * Driving the contact contour from that integer turns tiny reversals across a rounding
 * boundary into one-pixel jumps. Keep the consumed fraction instead.
 *
 * Samples are immutable so the Kotlin owner can publish one observable snapshot per event.
 * Read methods never write state during composition/drawing. Direct scrollToItem, restoration,
 * item changes and layout changes that did not pass through nested scroll use the actual list
 * coordinate immediately; the next event starts a new anchor there.
 */
public final class CollectionScrollPrecision {
    private CollectionScrollPrecision() {}

    // The initial private LazyList remainder is not public. An anchor may be off by <= .5 px;
    // the current list rounding contributes another <= .5 px. This is a consistency bound,
    // NOT a dead zone: every finite consumed subpixel is applied, without smoothing/delay.
    private static final double MAX_ANCHOR_ERROR_PX = 1.0001;

    public static final class Sample {
        public final int index, offset;
        public final double pixels;

        private Sample(int index, int offset, double pixels) {
            this.index = Math.max(0, index);
            this.offset = Math.max(0, offset);
            this.pixels = pixels;
        }

        public boolean matches(int currentIndex, int currentOffset) {
            return index == Math.max(0, currentIndex) && offset == Math.max(0, currentOffset);
        }

        /** Call before the child consumes a nested-scroll event. */
        public Sample rebase(int currentIndex, int currentOffset) {
            return matches(currentIndex, currentOffset) ? this : at(currentIndex, currentOffset);
        }

        /**
         * childConsumedY is NestedScrollConnection.onPostScroll's consumed.y, NOT available.y
         * and NOT the parent's collapse consumption. Negative y scrolls the list forwards.
         * Crossing an item boundary is outside the visible morph; re-anchor rather than
         * integrating unmeasured item heights. A deep list remains saturated in visualScroll.
         */
        public Sample after(float childConsumedY, int currentIndex, int currentOffset) {
            Sample actual = at(currentIndex, currentOffset);
            if (index != 0 || actual.index != 0 || !Float.isFinite(childConsumedY)) return actual;
            double next = Math.max(0.0, pixels - (double) childConsumedY);
            if (!Double.isFinite(next) || Math.abs(next - actual.offset) > MAX_ANCHOR_ERROR_PX)
                return actual; // external remeasure/clamping: the real list always wins
            return new Sample(actual.index, actual.offset, next);
        }

        /** No synthetic absolute offsets when the hero is absent, including after restore. */
        public float visualScroll(int currentIndex, int currentOffset, float heroHeight,
                float morphTravel) {
            if (currentIndex == 0 && matches(currentIndex, currentOffset)) return (float) pixels;
            return CollectionCollapseMath.visualScroll(currentIndex, currentOffset, heroHeight, morphTravel);
        }
    }

    public static Sample at(int index, int offset) {
        return new Sample(index, offset, Math.max(0, offset));
    }
}
