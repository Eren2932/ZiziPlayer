package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.semantics.clearAndSetSemantics

/** Keep the profile mounted while its playlist manager is open: restoring a LazyList into an
 * asynchronously loading, temporarily shorter list would clamp a deep scroll to the header. */
@Composable
internal fun ProfileDestinationHost(
    managerOpen: Boolean,
    profile: @Composable () -> Unit,
    manager: @Composable () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()
            .drawWithContent { if (!managerOpen) drawContent() }
            .then(if (managerOpen) Modifier.clearAndSetSemantics { } else Modifier)) {
            profile()
        }
        if (managerOpen) Box(Modifier.fillMaxSize().surfaceInputBoundary()) { manager() }
    }
}
