package app.ziziplayer.playback;

import java.util.Random;

/** Uniform first draw with no rejection loop and no immediate repeat when an alternative exists. */
public final class ShuffleStartPolicy {
    private ShuffleStartPolicy() {}

    public static int chooseStartIndex(int size, int currentIndex, Random random) {
        if (size < 0) throw new IllegalArgumentException("negative queue size");
        if (size == 0) return -1;
        if (size == 1) return 0;
        boolean exclude = currentIndex >= 0 && currentIndex < size;
        int draw = random.nextInt(exclude ? size - 1 : size);
        // A bijection from [0, size-2] onto all indices except currentIndex.
        return exclude && draw >= currentIndex ? draw + 1 : draw;
    }
}
