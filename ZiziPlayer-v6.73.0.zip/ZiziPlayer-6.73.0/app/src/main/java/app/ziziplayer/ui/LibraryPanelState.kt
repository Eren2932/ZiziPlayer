package app.ziziplayer.ui

/** One expandable Add panel. Search and this panel are mutually exclusive in MainViewModel. */
data class LibraryPanelState(val addExpanded: Boolean = false) {
    val isOpen: Boolean get() = addExpanded
    fun dismissTop(): LibraryPanelState = copy(addExpanded = false)
}
