package app.ziziplayer.ui;

/**
 * 6.69.18. Independent implementation of the blur + alpha-threshold mechanism studied in
 * Telegram ProfileGooeyView (dc780e81). No Telegram source is embedded; see THIRD_PARTY_NOTICES.
 * Pure, stateless parameters shared by the Compose renderer and executable JVM tests.
 * The legacy WAIST/REACH/SWELL tables do NOT drive this renderer.
 */
public final class CameraGooeyGeometry {
    private CameraGooeyGeometry() {}
    // Telegram's high-performance GPU profile. Radius is in reduced-layer pixels, NOT dp.
    public static final float GOO_SCALE = 3f;
    public static final float BLUR_RADIUS = 15f;
    public static final float ALPHA_GAIN = 51f;
    public static final float ALPHA_OFFSET = -6375f;
    private static final float COS_45 = (float) Math.sqrt(.5);

    public static float progress(float value) { return CameraMorphGeometry.unit(value); }
    public static float protrusion(float p, float density) {
        float d = Float.isFinite(density) && density > 0f ? density : 1f;
        // AndroidUtilities.dp uses ceil for positive values. One constant rounding at setup,
        // NOT a rounding of scroll/coordinates. The pulse is 0 -> peak at .5 -> 0.
        float peak = (float) Math.ceil(7f * d) * GOO_SCALE;
        return peak * (1f - Math.abs(2f * progress(p) - 1f));
    }
    /** 6.69.18: advance ONLY the axial reach, not the seed widths or cover motion.
     * Before the pulse peak, t=2p and easeOutCubic(t)=1-(1-t)^3. This is monotone,
     * stays within the existing peak, and rejoins the original pulse at p=.5.
     * From .5 onwards every seed vertex is identical to 6.69.17. Stateless on reversal.
     * Keep protrusion() as the width envelope: using reach() for the base makes a marker.
     */
    public static float reach(float p, float density) {
        float phase = progress(p);
        if (phase >= .5f) return protrusion(phase, density);
        float t = 2f * phase;
        float eased = t * (3f + t * (t - 3f));
        return protrusion(.5f, density) * eased;
    }
    public static float blurIntensity(float p) {
        return Math.min(.75f, Math.max(0f, (progress(p) - .2f) / .5f));
    }
    public static float imageAlphaUnclamped(float p) { return 2f * (1f - progress(p)); }
    public static float imageAlpha(float p) { return Math.min(1f, imageAlphaUnclamped(p)); }
    public static float blurImageAlpha(float p) { return Math.min(1f, .75f * imageAlphaUnclamped(p)); }
    public static float detailScale(float p) { return 1.25f + .5f * blurIntensity(p); }
    public static float threshold(float alpha) {
        return progress(ALPHA_GAIN * progress(alpha) + ALPHA_OFFSET / 255f);
    }
    /** 6.69.17: ONE kernel for both lobes, exactly as the reference (both RenderNodes use
     * the same `intensity`). The 6.69.16 size-aware camera kernel kept the camera lobe
     * almost sharp: its outline and seed crossed the shared threshold as a hard black
     * disc/spike ("thick marker"), and any mismatch between the OEM path and the physical
     * hole became a visible black blob. A 15px kernel shrinks the camera lobe INSIDE the
     * physical hole; only the growing seed mass reaches out of it, as a smooth drip.
     */
    public static float cameraBlurRadius(CameraMorphGeometry.Target target) { return BLUR_RADIUS; }

    private static float mix(float a, float b, float p) { return a + (b - a) * p; }

    /** Phase one (fraction) is unchanged. Phase two is the reference's ProfileActivity motion:
     *   avatarScale = lerp(intoSize, 96, diff), intoSize = 0.5 * notchWidth  -> size linear to W/2
     *   avatarY     = lerp(notchCenterY, startY, diff), pivot (0,0)          -> TOP edge linear to cy
     * so the artwork ends INSIDE the lower half of the hole (top at the hole centre, bottom at the
     * hole bottom), not centred on it. There is no group opacity fade: the reference toggles the
     * view GONE only at p >= 1. Our old 0.9..1 fade faded the black goo in/out by opacity, which
     * is exactly the stepped dark->light "pop" seen on the return path.
     * Lateral travel for off-centre cutouts is a Zizi extension (reference disables them).
     */
    public static CameraMorphGeometry.Frame frame(float maximum, float minimum, float fraction,
            float scroll, float centerX, float coverTop, float initialRadius, float travel,
            float fallbackY, CameraMorphGeometry.Target target) {
        CameraMorphGeometry.Frame base = CameraMorphGeometry.frame(maximum, minimum, fraction,
                scroll, centerX, coverTop, initialRadius, travel, fallbackY, target);
        if (target == null || base.progress <= 0f) return base;
        float p = base.progress;
        float size = Math.max(0f, Math.min(maximum, minimum));
        float into = endSize(target);
        float s = mix(size, into, p);
        float top = mix(coverTop, target.cy(), p);
        float cx = mix(centerX, target.cx(), CameraMorphGeometry.smooth(p / .65f));
        float cy = top + s * .5f;
        float alpha = p < 1f ? 1f : 0f;
        return new CameraMorphGeometry.Frame(cx, cy, s, s, s * .5f, p,
                alpha, 1f - imageAlpha(p), 1f - blurImageAlpha(p), base.anchorAlpha);
    }
    /** Reference intoSize: half the (likely-circle) cutout width. */
    public static float endSize(CameraMorphGeometry.Target target) {
        return Math.max(0f, Math.min(target.width(), target.height())) * .5f;
    }

    public static final class Seeds {
        /** Triangle vertices in window pixels, [x0,y0,x1,y1,x2,y2]. */
        public final float[] camera, artwork;
        public final float protrusion, reach, nx, ny;
        private Seeds(float[] camera, float[] artwork, float protrusion, float reach, float nx, float ny) {
            this.camera = camera; this.artwork = artwork; this.protrusion = protrusion; this.reach = reach;
            this.nx = nx; this.ny = ny;
        }
    }
    public static Seeds seeds(CameraMorphGeometry.Target target, CameraMorphGeometry.Frame f, float density) {
        float dx = f.cx - target.cx(), dy = f.cy - target.cy();
        float length = (float) Math.hypot(dx, dy);
        float nx = length > .0001f ? dx / length : 0f;
        float ny = length > .0001f ? dy / length : 1f;
        float h = protrusion(f.progress, density);
        float reach = reach(f.progress, density);
        float r = Math.min(f.width, f.height) * .5f;
        float cameraR = (float) Math.hypot(nx * target.width() * .5f, ny * target.height() * .5f);
        return new Seeds(triangle(target.cx(), target.cy(), nx, ny, 0f, h*.5f, cameraR+reach),
                triangle(f.cx, f.cy, nx, ny, -COS_45*r, r, -r-reach*.25f), h, reach, nx, ny);
    }
    private static float[] triangle(float x, float y, float nx, float ny,
            float base, float halfWidth, float tip) {
        return new float[] {x+nx*base-ny*halfWidth, y+ny*base+nx*halfWidth,
                x+nx*tip, y+ny*tip,
                x+nx*base+ny*halfWidth, y+ny*base-nx*halfWidth};
    }
}
