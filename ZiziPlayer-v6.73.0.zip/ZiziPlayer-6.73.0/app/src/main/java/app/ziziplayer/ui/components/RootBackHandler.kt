package app.ziziplayer.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import app.ziziplayer.ui.RootBackPolicy

/** Register unconditionally. Covered children explicitly disable their own BackHandlers. */
@Composable
internal fun RootBackHandler(
    target: RootBackPolicy.Target,
    beforeBack: () -> Unit = {},
    onDrawer: () -> Unit,
    onEqualizer: () -> Unit,
    onPlayer: () -> Unit,
    onProfile: () -> Unit,
    onContent: () -> Unit
) {
    BackHandler(enabled = target != RootBackPolicy.Target.CHILD) {
        beforeBack()
        when (target) {
            RootBackPolicy.Target.DRAWER -> onDrawer()
            RootBackPolicy.Target.EQUALIZER -> onEqualizer()
            RootBackPolicy.Target.PLAYER -> onPlayer()
            RootBackPolicy.Target.PROFILE -> onProfile()
            RootBackPolicy.Target.CONTENT -> onContent()
            RootBackPolicy.Target.CHILD -> Unit
        }
    }
}
