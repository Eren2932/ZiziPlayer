package app.ziziplayer.ui.components

import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import app.ziziplayer.ui.PlayerSheetGeometry

/** Translation and contour sample the SAME offset in the SAME graphics-layer update. */
internal fun Modifier.playerSheetSurface(
    corners: State<PlayerSheetGeometry.Corners>,
    offsetY: () -> Float
): Modifier = graphicsLayer {
    val offset = offsetY()
    translationY = offset
    shape = PlayerSheetShape(corners.value, offset)
    // On the OUTER player Box: clips backdrop and all child content, not just an empty layer.
    clip = true
}

/** Absolute screen corners: RTL must not exchange the hardware left/right radii. */
internal data class PlayerSheetShape(
    val corners: PlayerSheetGeometry.Corners,
    val offsetY: Float
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = PlayerSheetGeometry.atOffset(corners, size.width, size.height, offsetY)
        return Outline.Rounded(RoundRect(
            left = 0f, top = 0f, right = size.width, bottom = size.height,
            topLeftCornerRadius = CornerRadius(c.topLeft),
            topRightCornerRadius = CornerRadius(c.topRight),
            bottomRightCornerRadius = CornerRadius(c.bottomRight),
            bottomLeftCornerRadius = CornerRadius(c.bottomLeft)
        ))
    }
}
