package app.ziziplayer.ui.theme;

/**
 * Lyrics-only tones, independent of the player's black-ended backdrop. Input is the original
 * cached artwork swatch, NOT the already darkened player top. No decoding, Android or UI clock.
 *
 * OKLCH keeps perceptual hue while changing lightness. The full-screen reference rises by about
 * 0.10 in OKLab L from top to bottom; its surrounding text is opaque, lightly cover-tinted ink.
 * Those relationships are shared by all covers, not special-cased for a song or a hue family.
 */
public final class LyricsColorMath {
    public static final int STOP_COUNT = 7;
    public static final int ACTIVE = 7;
    public static final int INACTIVE = 8;
    private static final double[] POSITIONS = {0, .10, .28, .46, .64, .82, 1};
    private static final int ACTIVE_INK = 0xfffafafa;

    private LyricsColorMath() {}

    /** Seven opaque gradient stops, active ink, surrounding/pending-word ink. Null = neutral. */
    public static int[] create(Integer primary) {
        double[] lch = toLch(primary == null ? 0xff666666 : primary);
        // Do not amplify near-neutral JPEG noise. The gate is continuous, not a hue switch.
        double neutralGate = clamp((lch[1] - .012) / .023, 0, 1);
        neutralGate = neutralGate * neutralGate * (3 - 2 * neutralGate);
        double sourceChroma = lch[1] * neutralGate;
        double topL = .335 + .030 * lch[0];
        double chroma = Math.min(sourceChroma, .14);
        // Use the same chroma across the ramp when possible, rather than mixing with black.
        chroma = fittingChroma(topL, chroma, lch[2]);
        int[] result = new int[STOP_COUNT + 2];
        for (int i = 0; i < STOP_COUNT; i++) {
            result[i] = tone(topL + .100 * POSITIONS[i], chroma, lch[2]);
        }
        result[ACTIVE] = ACTIVE_INK;
        double inkChroma = Math.min(sourceChroma * 1.35, .10);
        // Channel-wise envelope bounds every sRGB-interpolated point, not just the stops.
        int envelope = envelope(result);
        int ink = tone(.845, inkChroma, lch[2]);
        for (int step = 1; contrast(ink, envelope) < 4.5 && step <= 31; step++) {
            ink = tone(.845 + .005 * step, inkChroma, lch[2]);
        }
        result[INACTIVE] = ink;
        return result;
    }

    private static int envelope(int[] colors) {
        int r = 0, g = 0, b = 0;
        for (int i = 0; i < STOP_COUNT; i++) {
            r = Math.max(r, channel(colors[i], 16));
            g = Math.max(g, channel(colors[i], 8));
            b = Math.max(b, channel(colors[i], 0));
        }
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }

    private static double contrast(int a, int b) {
        double x = ArtworkColorMath.luminance(a), y = ArtworkColorMath.luminance(b);
        return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
    }

    private static double[] toLch(int color) {
        double r = linear(channel(color, 16) / 255.0);
        double g = linear(channel(color, 8) / 255.0);
        double b = linear(channel(color, 0) / 255.0);
        double l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
        double m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
        double s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
        double light = .2104542553 * l + .7936177850 * m - .0040720468 * s;
        double a = 1.9779984951 * l - 2.4285922050 * m + .4505937099 * s;
        double bb = .0259040371 * l + .7827717662 * m - .8086757660 * s;
        return new double[]{light, Math.hypot(a, bb), Math.atan2(bb, a)};
    }

    /** Gamut mapping reduces chroma, never hue or lightness. No clipping a saturated channel. */
    private static double fittingChroma(double light, double chroma, double hue) {
        if (inGamut(linearRgb(light, chroma, hue))) return chroma;
        double low = 0, high = chroma;
        for (int i = 0; i < 18; i++) {
            double mid = (low + high) * .5;
            if (inGamut(linearRgb(light, mid, hue))) low = mid; else high = mid;
        }
        return low;
    }

    private static int tone(double light, double chroma, double hue) {
        light = clamp(light, 0, 1);
        double[] rgb = linearRgb(light, fittingChroma(light, chroma, hue), hue);
        return 0xff000000 | (encoded(rgb[0]) << 16) | (encoded(rgb[1]) << 8) | encoded(rgb[2]);
    }

    private static double[] linearRgb(double light, double chroma, double hue) {
        double a = Math.cos(hue) * chroma, b = Math.sin(hue) * chroma;
        double l = light + .3963377774 * a + .2158037573 * b;
        double m = light - .1055613458 * a - .0638541728 * b;
        double s = light - .0894841775 * a - 1.2914855480 * b;
        l = l * l * l; m = m * m * m; s = s * s * s;
        return new double[]{4.0767416621 * l - 3.3077115913 * m + .2309699292 * s,
                -1.2684380046 * l + 2.6097574011 * m - .3413193965 * s,
                -.0041960863 * l - .7034186147 * m + 1.7076147010 * s};
    }

    private static boolean inGamut(double[] rgb) {
        for (double v : rgb) if (v < -1e-7 || v > 1.0000001) return false;
        return true;
    }
    private static int encoded(double linear) {
        // Clamp only floating point residue after gamut mapping.
        double c = clamp(linear, 0, 1);
        return (int) Math.round(255 * (c <= .0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - .055));
    }
    private static double linear(double c) { return c <= .04045 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4); }
    private static int channel(int rgb, int shift) { return (rgb >>> shift) & 255; }
    private static double clamp(double v, double low, double high) { return Math.max(low, Math.min(high, v)); }
}
