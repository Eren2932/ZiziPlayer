package app.ziziplayer.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** A destination-local palette. Closing lyrics restores the player without touching its blend. */
@Composable
internal fun LyricsSurfaceTheme(content: @Composable () -> Unit) {
    val primary = LocalPalette.current.artworkPrimary
    val palette = remember(primary) { lyricsPalette(primary) }
    CompositionLocalProvider(LocalPalette provides palette) {
        ZiziTheme(palette, content)
    }
}

/** Uses the existing cached swatch; neither opens artwork nor derives a hue from tinted text. */
internal fun lyricsPalette(primary: Color?): ZiziPalette {
    val tones = LyricsColorMath.create(primary?.toArgb())
    return basePalette().copy(
        top = Color(tones[0]),
        crest = Color(tones[1]),
        upper = Color(tones[2]),
        middle = Color(tones[3]),
        lower = Color(tones[4]),
        deep = Color(tones[5]),
        bottom = Color(tones[6]),
        text = Color(tones[LyricsColorMath.ACTIVE]),
        subtext = Color(tones[LyricsColorMath.INACTIVE]),
        surface = Color(tones[3]),
        chip = Color(tones[LyricsColorMath.INACTIVE]).copy(alpha = .32f),
        accent = Color(tones[LyricsColorMath.ACTIVE]),
        onAccent = Color.Black,
        glowStrength = 0f,
        artworkPrimary = primary
    )
}
