package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.drag as dragReorderPointer
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import app.ziziplayer.ui.ReorderMath
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** One local preview per gesture. Persistence/audio changes happen once, on release. */
@Stable
internal class TrackReorderState<T>(
    val list: LazyListState,
    initial: List<T>,
    private val keyOf: (T) -> String,
    private val scope: CoroutineScope,
    private val firstRowIndex: Int
) {
    var items by mutableStateOf(initial); private set
    var draggingKey by mutableStateOf<String?>(null); private set
    var settlingKey by mutableStateOf<String?>(null); private set
    var saving by mutableStateOf(false); private set
    private var external = initial
    private var before = initial
    private var beforeKeys = initial.map(keyOf)
    private var expected by mutableStateOf<List<String>?>(null)
    private var indices = initial.mapIndexed { i, value -> keyOf(value) to i }.toMap()
    private var top by mutableFloatStateOf(0f)
    private var pointerCenter = 0f
    private var height = 0f
    private var awaitingLayout = false
    private val settle = Animatable(0f)
    private var landingTop by mutableStateOf<Float?>(null)
    var topInsetPx = 0f
    var edgePx = 1f
    var maxSpeedPx = 1f
    var elevationPx = 0f
    var commit: suspend (List<T>, List<T>) -> Boolean = { _, _ -> false }
    val busy: Boolean get() = draggingKey != null || saving || settlingKey != null
    val previewChangesFirst: Boolean
        get() = busy && items.firstOrNull()?.let(keyOf) != beforeKeys.firstOrNull()

    fun animatePlacement(key: String): Boolean = ReorderMath.animatePlacement(
        busy, draggingKey == key || settlingKey == key)

    fun key(item: T): String = keyOf(item)
    private fun keys(values: List<T>) = values.map(keyOf)
    private fun replace(values: List<T>) {
        items = values
        indices = values.mapIndexed { i, value -> keyOf(value) to i }.toMap()
    }

    fun sync(values: List<T>) {
        // Hero colour animation recomposes the owner, not the collection. Do not rebuild
        // thousands of keys/indices on each of its frames. Sources publish immutable lists.
        if (values === external) return
        external = values
        val incoming = keys(values)
        if (draggingKey != null) {
            // A deletion, privacy change, sort or another queue edit invalidates this gesture.
            if (incoming != beforeKeys) cancel()
        } else if (expected != null) {
            if (incoming == expected || incoming != beforeKeys) {
                expected = null
                replace(values)
            }
        } else {
            // The write may have been acknowledged while its coroutine/landing animation
            // is still running. `saving` is an interaction lock, NOT a data subscription
            // gate. Dropping this emission used to leave items stale indefinitely because
            // `external` was already advanced and the identity guard skipped the retry.
            val oldFirst = items.firstOrNull()?.let(keyOf)
            val newFirst = values.firstOrNull()?.let(keyOf)
            if (oldFirst != null && newFirst != null && newFirst !in indices && oldFirst in incoming &&
                list.firstVisibleItemIndex <= firstRowIndex && !list.isScrollInProgress && !busy) {
                // At the leading rows reveal new arrivals, rather than anchoring the old
                // first key above them. Preserve a reader's anchor deeper in the list.
                list.requestScrollToItem(list.firstVisibleItemIndex, list.firstVisibleItemScrollOffset)
            }
            replace(values)
        }
    }

    fun start(key: String): Boolean {
        if (busy || items.size < 2 || indices.size != items.size) return false
        val row = list.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key } ?: return false
        before = items
        beforeKeys = keys(items)
        height = row.size.toFloat()
        top = row.offset.toFloat()
        pointerCenter = top + height / 2f
        draggingKey = key
        awaitingLayout = false
        return true
    }

    private fun updateTop() {
        val info = list.layoutInfo
        val low = ReorderMath.viewportStart(info.viewportStartOffset, info.beforeContentPadding, topInsetPx)
        val bottom = ReorderMath.viewportEnd(info.viewportEndOffset, info.afterContentPadding, low)
        top = boundedTop(pointerCenter - height / 2f, low, bottom)
    }

    private fun boundedTop(candidate: Float, low: Float, bottom: Float): Float {
        val visible = list.layoutInfo.visibleItemsInfo
        val first = visible.firstOrNull { it.index == firstRowIndex }
        val last = visible.firstOrNull { it.index == firstRowIndex + items.lastIndex }
        return ReorderMath.trackTop(candidate + height / 2f, height, low, bottom,
            first?.offset?.toFloat() ?: Float.NEGATIVE_INFINITY,
            last?.let { (it.offset + it.size).toFloat() } ?: Float.POSITIVE_INFINITY)
    }

    fun dragBy(delta: Float) {
        if (draggingKey == null) return
        pointerCenter += delta
        updateTop()
        crossRows()
    }

    private fun crossRows() {
        val key = draggingKey ?: return
        val from = indices[key] ?: return
        val visible = list.layoutInfo.visibleItemsInfo
        val row = visible.firstOrNull { it.key == key } ?: return
        if (awaitingLayout && row.index != from + firstRowIndex) return
        awaitingLayout = false
        var target = from
        for (other in visible) {
            val index = (other.key as? String)?.let(indices::get) ?: continue
            if (index > from && ReorderMath.crossesNeighbour(top, height, other.offset.toFloat(), other.size.toFloat(), true))
                target = maxOf(target, index)
            if (index < from && ReorderMath.crossesNeighbour(top, height, other.offset.toFloat(), other.size.toFloat(), false))
                target = minOf(target, index)
        }
        if (target == from) return
        // Disable LazyColumn's key anchoring for this edit, not for ordinary scrolling.
        list.requestScrollToItem(list.firstVisibleItemIndex, list.firstVisibleItemScrollOffset)
        replace(ReorderMath.move(items, from, target))
        awaitingLayout = true
    }

    suspend fun frame(dt: Float) {
        if (draggingKey == null) return
        val layout = list.layoutInfo
        val usableTop = ReorderMath.viewportStart(layout.viewportStartOffset, layout.beforeContentPadding, topInsetPx)
        val usableBottom = ReorderMath.viewportEnd(layout.viewportEndOffset, layout.afterContentPadding, usableTop)
        val speed = ReorderMath.edgeSpeed(pointerCenter, usableTop, usableBottom, edgePx, maxSpeedPx)
        if (speed != 0f && dt > 0f) {
            var distance = speed * dt
            // Do not scroll into a tall hero or a decorative tail: that could dispose the
            // pointer-owning row before release. The first/last TRACK is the drag boundary.
            val first = layout.visibleItemsInfo.firstOrNull { it.index == firstRowIndex }
            val last = layout.visibleItemsInfo.firstOrNull { it.index == firstRowIndex + items.lastIndex }
            if (distance < 0f && first != null)
                distance = maxOf(distance, minOf(0f, first.offset - usableTop))
            if (distance > 0f && last != null)
                distance = minOf(distance, maxOf(0f, last.offset + last.size - usableBottom))
            if (distance != 0f) list.scrollBy(distance)
        }
        updateTop()
        crossRows()
    }

    fun translation(key: String): Float {
        if (key != draggingKey && key != settlingKey) return 0f
        val info = list.layoutInfo
        val row = info.visibleItemsInfo.firstOrNull { it.key == key } ?: return 0f
        val low = ReorderMath.viewportStart(info.viewportStartOffset, info.beforeContentPadding, topInsetPx)
        val bottom = ReorderMath.viewportEnd(info.viewportEndOffset, info.afterContentPadding, low)
        val candidate = if (key == draggingKey) top else landingTop ?: (row.offset + settle.value)
        // Clamp in draw as well: a remeasure can happen between pointer/frame callbacks.
        return boundedTop(candidate, low, bottom) - row.offset
    }

    fun cancel() {
        draggingKey = null
        awaitingLayout = false
        replace(external)
    }

    fun finish() {
        val key = draggingKey ?: return
        val row = list.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
        landingTop = (row?.offset ?: 0) + translation(key)
        val result = items
        val original = before
        draggingKey = null
        settlingKey = key
        saving = true
        expected = keys(result)
        scope.launch {
            try {
                val landing = launch {
                    // Release may follow the final swap in the SAME input frame. Hold screen
                    // coordinates until that slot is measured; never spring from the old slot.
                    withTimeoutOrNull(250) {
                        snapshotFlow {
                            list.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
                        }.first { it != null && it.index == (indices[key] ?: -1) + firstRowIndex }
                    }
                    val slot = list.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
                    settle.snapTo(if (slot == null) 0f else (landingTop ?: slot.offset.toFloat()) - slot.offset)
                    landingTop = null
                    settle.animateTo(0f, spring(dampingRatio = 1f, stiffness = 700f))
                    settlingKey = null
                }
                val success = keys(original) == keys(result) || commit(original, result)
                if (!success) { expected = null; replace(external) }
                // Room/Media3 may have acknowledged before the suspending write returned.
                if (keys(external) == expected) { expected = null; replace(external) }
                if (expected != null) {
                    // Wake on acknowledgement, not a fixed delay between consecutive drags.
                    withTimeoutOrNull(1500) { snapshotFlow { expected }.first { it == null } }
                    expected = null
                    replace(external)
                }
                landing.join()
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Exception) {
                expected = null
                replace(external)
            } finally {
                expected = null
                saving = false
                settlingKey = null
                landingTop = null
                // Also converge on cancellation/error/timeout with the newest source,
                // not the gesture snapshot. Never resurrect a concurrently deleted row.
                replace(external)
            }
        }
    }

    fun accessibilityMove(key: String, delta: Int): Boolean {
        if (busy) return false
        val from = indices[key] ?: return false
        val to = from + delta
        if (to !in items.indices) return false
        before = items; beforeKeys = keys(items)
        replace(ReorderMath.move(items, from, to))
        // No lifted row in accessibility mode, but the same persistence/rollback path.
        draggingKey = key
        val row = list.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
        top = row?.offset?.toFloat() ?: 0f
        height = row?.size?.toFloat() ?: 0f
        finish()
        return true
    }
}

@Composable
internal fun <T> rememberTrackReorder(
    list: LazyListState, items: List<T>, keyOf: (T) -> String,
    firstRowIndex: Int = 0, topInset: Dp = 0.dp,
    onCommit: suspend (List<T>, List<T>) -> Boolean
): TrackReorderState<T> {
    val scope = rememberCoroutineScope()
    val state = remember(list, firstRowIndex) { TrackReorderState(list, items, keyOf, scope, firstRowIndex) }
    val latestCommit by rememberUpdatedState(onCommit)
    val density = LocalDensity.current
    SideEffect {
        state.topInsetPx = with(density) { topInset.toPx() }
        state.edgePx = with(density) { 72.dp.toPx() }
        state.maxSpeedPx = with(density) { 1100.dp.toPx() }
        state.elevationPx = with(density) { 10.dp.toPx() }
        state.commit = { a, b -> latestCommit(a, b) }
        state.sync(items)
    }
    LaunchedEffect(state, state.draggingKey) {
        if (state.draggingKey != null) {
            var last = 0L
            while (state.draggingKey != null) {
                val now = withFrameNanos { it }
                state.frame(ReorderMath.frameSeconds(last, now))
                last = now
            }
        }
    }
    DisposableEffect(state) { onDispose { state.cancel() } }
    return state
}

internal fun <T> Modifier.reorderRow(state: TrackReorderState<T>, key: String): Modifier =
    zIndex(if (state.draggingKey == key || state.settlingKey == key) 1f else 0f)
        .graphicsLayer {
            translationY = state.translation(key)
            shadowElevation = if (state.draggingKey == key) state.elevationPx else 0f
        }

/** Own DOWN before the row's combinedClickable: hold must not also select/play/open its menu.
 * A swipe before the platform long-press timeout is left to LazyColumn's normal scrolling.
 */
@Composable
internal fun <T> Modifier.reorderHandle(
    state: TrackReorderState<T>, key: String, enabled: Boolean = true, onTap: () -> Unit
): Modifier {
    val handleTap by rememberUpdatedState(onTap)
    val haptic = LocalHapticFeedback.current
    if (!enabled) return this
    return semantics {
        onClick(label = "Открыть меню") { handleTap(); true }
        customActions = listOf(
            CustomAccessibilityAction("Переместить выше") { state.accessibilityMove(key, -1) },
            CustomAccessibilityAction("Переместить ниже") { state.accessibilityMove(key, 1) })
    }.pointerInput(state, key) {
        awaitEachGesture {
            val down = awaitFirstDown(pass = PointerEventPass.Initial)
            down.consume()
            // Finish this DOWN's Main pass before waiting for the next event; otherwise
            // awaitLongPressOrCancellation sees our own consumed DOWN and cancels immediately.
            awaitPointerEvent(PointerEventPass.Main)
            val held = awaitLongPressOrCancellation(down.id)
            if (held == null) {
                val up = currentEvent.changes.firstOrNull { it.id == down.id }
                if (up != null && !up.pressed && !up.isConsumed) { up.consume(); handleTap() }
            } else {
                held.consume()
                if (state.start(key)) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    try {
                        val released = dragReorderPointer(held.id) { change ->
                            state.dragBy(change.positionChange().y)
                            change.consume()
                        }
                        if (released) {
                            currentEvent.changes.forEach { it.consume() }
                            state.finish()
                        } else state.cancel()
                    } finally {
                        if (state.draggingKey == key) state.cancel()
                    }
                }
            }
        }
    }
}
