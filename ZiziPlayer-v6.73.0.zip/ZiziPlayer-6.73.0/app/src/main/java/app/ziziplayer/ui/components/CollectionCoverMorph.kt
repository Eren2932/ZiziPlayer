package app.ziziplayer.ui.components

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.CameraMorphGeometry as M
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.abs

/** Compatibility renderer for API 26–30 / unavailable cutout.
 * 6.69.15 uses CameraGooeyOverlay on supported Android 12+ hardware.
 * One artwork instance outside LazyColumn clipping, inside the destination's normal z-order.
 * No pointer input, timer, bitmap capture, global overlay window or second image request.
 * Blur is on the inner rectangular image layer; shape/safety clips and contact ink stay sharp.
 */
@Composable
internal fun LegacyCollectionCoverMorphOverlay(
    camera: CameraCutoutSnapshot,
    maximum: Dp,
    minimum: Dp,
    coverTop: Dp,
    corner: Dp,
    status: Dp,
    fraction: () -> Float,
    scroll: () -> Float,
    artwork: @Composable () -> Unit
) {
    val sourceLayer = rememberGraphicsLayer()
    val density = LocalDensity.current
    var origin by remember { mutableStateOf<Offset?>(null) }
    val maxPx = with(density) { maximum.toPx() }
    val minPx = with(density) { minimum.toPx() }
    val statusPx = with(density) { status.toPx() }
    val topPx = with(density) { coverTop.toPx() }
    val radiusPx = with(density) { corner.toPx() }
    val edgePx = with(density) { 1.dp.toPx() }
    BoxWithConstraints(Modifier.fillMaxSize().clearAndSetSemantics { }
        .onGloballyPositioned { origin = it.positionInWindow() }) {
        val widthPx = with(density) { maxWidth.toPx() }
        // Do not aim at a display-space hole from an inset, translated or preview-sized page.
        val aligned = origin?.let { abs(it.x) <= 1f && abs(it.y) <= 1f } == true &&
            abs(widthPx - camera.windowWidth) <= 1f && abs(statusPx - camera.statusTop) <= 1f
        val target = if (aligned) camera.target else null
        val outline = if (aligned) camera.outline else null
        val frame = remember(maxPx, minPx, statusPx, topPx, radiusPx, widthPx, target, fraction, scroll) {
            derivedStateOf {
                M.frame(maxPx, minPx, fraction(), scroll(), widthPx * .5f, statusPx + topPx,
                    radiusPx, minPx + topPx, statusPx, target)
            }
        }
        // One geometry snapshot per scroll position, shared by camera and artwork layers.
        val goo = remember(frame, target) { derivedStateOf { M.goo(target, frame.value) } }
        val neck = remember { Path() }
        Box(Modifier.fillMaxSize().drawWithCache {
            val safe = cameraMorphSafetyPath(size.width, size.height, statusPx, target,
                outline, camera.topAttached, legacy = true, edgePx = edgePx)
            onDrawWithContent { clipPath(safe) { this@onDrawWithContent.drawContent() } }
        }) {
            Canvas(Modifier.fillMaxSize()) {
                val f = frame.value
                if (target != null && outline != null) {
                    val g = goo.value
                    // Before contact the camera really grows a separate drop. Never draw
                    // a full-distance bridge underneath it. Joined artwork supplies the neck.
                    if (g != null && !g.joined && g.ink != null) {
                        neck.setGoo(g.ink)
                        drawPath(neck, Color.Black, alpha = f.anchorAlpha * f.imageAlpha)
                    }
                    // Do not leave an app-painted dot after absorption. Keep the layer
                    // mounted for reversible scroll, but emit no anchor at completion.
                    if (f.anchorAlpha > 0f) drawPath(outline, Color.Black, alpha = f.anchorAlpha)
                }
            }
            Box(Modifier.size(maximum).testTag("collection:morph-artwork")
                .drawWithCache {
                    val f = frame.value
                    // Transform, paths, blur and material use THIS snapshot. No independently
                    // invalidated graphicsLayer transform can replay yesterday's clip.
                    val g = M.goo(target, f)
                    val sx = if (f.width > 0f) size.width / f.width else 1f
                    val sy = if (f.height > 0f) size.height / f.height else 1f
                    val radius = CornerRadius(f.radius * sx, f.radius * sy)
                    val body = RoundRect(0f, 0f, size.width, size.height,
                        radius, radius, radius, radius)
                    val flesh = g?.flesh?.let { commands ->
                        Path().apply { setGoo(commands, f.left(), f.top(), sx, sy) }
                    }
                    // One mask and shading pass. Same-winding NonZero contours give
                    // the set union directly; no Boolean solver at near-tangent cubics.
                    val silhouette = cameraMorphSilhouette(body, flesh)
                    val bodyBlack = M.bodyBlack(f, g)
                    val bodyBounds = Rect(0f, 0f, size.width, size.height)
                    val bounds = flesh?.getBounds()?.let {
                        Rect(minOf(0f, it.left), minOf(0f, it.top),
                            maxOf(size.width, it.right), maxOf(size.height, it.bottom))
                    } ?: bodyBounds
                    val ink = g?.let {
                        Brush.linearGradient(
                            0f to Color.Black.copy(alpha = it.inkAlpha),
                            1f to Color.Transparent,
                            start = Offset((it.originX + it.axisX * it.inkStart - f.left()) * sx,
                                (it.originY + it.axisY * it.inkStart - f.top()) * sy),
                            end = Offset((it.originX + it.axisX * it.inkEnd - f.left()) * sx,
                                (it.originY + it.axisY * it.inkEnd - f.top()) * sy))
                    }
                    // Reflect the SAME image display list across its camera-facing tangent.
                    // Sixfold stretch samples a shallow strip of the blurred source, not a
                    // second Coil request or a screenshot. The tangent is continuous in color.
                    val nx0 = (g?.axisX ?: 0f) * sx
                    val ny0 = (g?.axisY ?: 1f) * sy
                    val length = hypot(nx0, ny0).coerceAtLeast(.0001f)
                    val nx = nx0 / length
                    val ny = ny0 / length
                    val pivot = Offset(size.width * .5f - nx * size.minDimension * .5f,
                        size.height * .5f - ny * size.minDimension * .5f)
                    val angle = (atan2(ny, nx) * 180f / Math.PI.toFloat()) - 90f
                    val extent = (size.maxDimension + bounds.width + bounds.height) * 4f
                    val outside = Path().apply {
                        moveTo(pivot.x - ny * extent, pivot.y + nx * extent)
                        lineTo(pivot.x + ny * extent, pivot.y - nx * extent)
                        lineTo(pivot.x + ny * extent - nx * extent, pivot.y - nx * extent - ny * extent)
                        lineTo(pivot.x - ny * extent - nx * extent, pivot.y + nx * extent - ny * extent)
                        close()
                    }
                    val blur = size.minDimension * M.blurFraction(f.progress)
                    sourceLayer.renderEffect = if (Build.VERSION.SDK_INT >= 31 && blur > 0f)
                        BlurEffect(blur, blur, TileMode.Clamp) else null
                    val fadePaint = if (f.imageAlpha < 1f) Paint().apply { alpha = f.imageAlpha } else null
                    onDrawWithContent {
                        CameraMorphDebug.recordFrame(scroll(), f, g)
                        if (f.imageAlpha <= 0f) return@onDrawWithContent
                        // Record the child exactly once. Repeated drawContent() can place the
                        // same Compose child layer multiple times in one recording. Replay an
                        // explicit owned display list instead, including reflected padding.
                        sourceLayer.record { this@onDrawWithContent.drawContent() }
                        withTransform({
                            translate(f.left(), f.top())
                            scale(f.width / size.width, f.height / size.height, Offset.Zero)
                        }) {
                            // True group alpha (not ModulateAlpha): a black overlay must not
                            // expose bright artwork again during the final fade. Include the
                            // extension's negative coordinates in the offscreen layer bounds.
                            if (fadePaint != null) drawContext.canvas.saveLayer(bounds, fadePaint)
                            try {
                                clipPath(silhouette) {
                                    if (flesh == null) {
                                        drawLayer(sourceLayer)
                                    } else {
                                        // Always draw the body directly at its original transform.
                                        // The nine-tile helper is ONLY for padding the reflected
                                        // extension, never the sole renderer of the artwork body.
                                        // Keep the single union clip and single shading pass.
                                        drawLayer(sourceLayer)
                                        clipPath(outside) {
                                            withTransform({
                                                rotate(angle, pivot)
                                                scale(1f, -6f, pivot)
                                                rotate(-angle, pivot)
                                            }) { this@onDrawWithContent.drawMirroredLayer(sourceLayer) }
                                        }
                                    }
                                    // Shade the UNION once, never body and neck independently.
                                    if (bodyBlack > 0f)
                                        drawRect(Color.Black, bounds.topLeft, bounds.size, alpha = bodyBlack)
                                    if (ink != null) drawRect(ink, bounds.topLeft, bounds.size)
                                }
                            } finally {
                                if (fadePaint != null) drawContext.canvas.restore()
                            }
                        }
                    }
                }) {
                // One mounted artwork, one recording; no image reload on reversal.
                // API 26-30 keeps the same spatial blend without unsupported RenderEffect.
                Box(Modifier.fillMaxSize()) { artwork() }
            }
            if (CameraMorphDebug.outlineEnabled && target != null && outline != null) {
                Canvas(Modifier.fillMaxSize()) {
                    drawPath(outline, Color.Cyan, style = Stroke(edgePx))
                    drawRect(Color.Magenta, topLeft = Offset(target.left, target.top),
                        size = Size(target.width(), target.height()), style = Stroke(edgePx * .5f))
                }
            }
        }
    }
}

/** Decode pure-Java path commands into window or unscaled artwork coordinates. */
private fun Path.setGoo(commands: FloatArray, left: Float = 0f, top: Float = 0f,
    sx: Float = 1f, sy: Float = 1f) {
    reset()
    var i = 0
    while (i < commands.size) {
        when (commands[i++].toInt()) {
            0 -> {
                moveTo((commands[i] - left) * sx, (commands[i + 1] - top) * sy)
                i += 2
            }
            1 -> {
                cubicTo((commands[i] - left) * sx, (commands[i + 1] - top) * sy,
                    (commands[i + 2] - left) * sx, (commands[i + 3] - top) * sy,
                    (commands[i + 4] - left) * sx, (commands[i + 5] - top) * sy)
                i += 6
            }
            2 -> close()
            else -> error("Invalid camera path opcode")
        }
    }
}

/** Mirror-pad the existing image display list by one tile at every edge. A rotated
 * neck or swollen camera can sample just outside the original square; without this
 * padding a transparent wedge appears on corner-camera devices. No bitmap copies,
 * captures or additional image requests. The surrounding path clips all nine tiles.
 * The explicitly recorded source layer is reused; it is not re-recorded per tile.
 */
private fun ContentDrawScope.drawMirroredLayer(layer: GraphicsLayer) {
    for (y in -1..1) for (x in -1..1) {
        withTransform({
            translate(x * size.width, y * size.height)
            scale(if (x == 0) 1f else -1f, if (y == 0) 1f else -1f)
        }) { drawLayer(layer) }
    }
}

/**
 * NonZero(A + B) is A union B when both contours wind clockwise. Goo.flesh uses
 * clockwise window coordinates; its positive scale into artwork space preserves that.
 * Compose's DEFAULT addRoundRect direction is counter-clockwise, so it must be explicit:
 * opposite winding would cancel the overlap and produce a hole. Never use EvenOdd here.
 * The exact platform round rect, one AA clip, one texture and one ink pass are preserved.
 */
internal fun cameraMorphSilhouette(body: RoundRect, extension: Path?): Path = Path().apply {
    fillType = PathFillType.NonZero
    addRoundRect(body, Path.Direction.Clockwise)
    if (extension != null) addPath(extension)
}

/** Notch pixels above its bottom may only occupy its physical outline. This prevents a
 * circular emitter or threshold blur from painting new black shoulders beside a U/V cutout.
 * Path union (not contour addition) also handles either winding of an OEM system Path.
 */
internal fun cameraMorphSafetyPath(width: Float, height: Float, status: Float,
    target: M.Target?, outline: Path?, topAttached: Boolean, legacy: Boolean, edgePx: Float
): Path {
    if (topAttached && target != null && outline != null) {
        val lower = Path().apply { addRect(Rect(0f, target.bottom, width, height)) }
        return Path.combine(androidx.compose.ui.graphics.PathOperation.Union, lower, outline)
    }
    return Path().apply {
        addRect(Rect(0f, if (legacy) status else target?.top ?: status, width, height))
        if (legacy && target != null) {
            val swell = M.maxSwellPx(target)
            addRect(Rect(target.left - edgePx - swell, target.top - edgePx,
                target.right + edgePx + swell, status + edgePx))
        }
    }
}
