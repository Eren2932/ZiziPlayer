package app.ziziplayer.ui;

/** 6.70.2. A top-connected cutout is a reservoir, NOT a wide punch-hole target.
 * Keep the physical outline separate from a compact, bottom-aligned emitter. All values
 * are window pixels. No model names, status-height diameter, timers or mutable history.
 */
public final class CameraNotchGeometry {
    private CameraNotchGeometry() {}

    public static CameraMorphGeometry.Target anchor(CameraMorphGeometry.Target bounds,
            float width, float height, float status, float density, boolean exactPath,
            float tipX) {
        if (bounds == null || !finite(bounds.left, bounds.top, bounds.right, bounds.bottom,
                width, height, status, density, tipX) || density <= 0 || status <= 0
                || width <= 0 || height <= width) return null;
        float w = bounds.width(), h = bounds.height();
        // Broad strips, waterfall edges, bottom/side cutouts and unknown tall reservations
        // must not become cameras. Tall RECT reservations retain compactTopEstimate().
        if (bounds.left < 0 || bounds.right > width || bounds.top < 0 || bounds.top > 1f
                || w < 8f*density || h < 4f*density || h > 64f*density
                || bounds.bottom > status + 8f*density
                || w > Math.min(width * (exactPath ? .45f : .24f), (exactPath ? 160f : 80f)*density)
                || (!exactPath && (h > w + .5f || w > 4f*h))) return null;
        // The local emitter uses depth, not the entire notch width. Its tip is on the
        // measured bottom. An asymmetric system Path supplies its own bottom centre.
        float diameter = Math.min(Math.min(w, h),
                2f * Math.min(tipX - bounds.left, bounds.right - tipX));
        if (diameter < 4f*density) return null;
        return new CameraMorphGeometry.Target(tipX-diameter*.5f, bounds.bottom-diameter,
                tipX+diameter*.5f, bounds.bottom);
    }

    /** Android computeBounds bounds the CONTROL points, not necessarily the curve.
     * Approximation samples give the actual contour extrema to the adapter's explicitly
     * chosen subpixel tolerance. Keep the original Path for rendering, never polygonize it.
     */
    public static CameraMorphGeometry.Target sampledBounds(float[] samples) {
        if (samples == null || samples.length < 6 || samples.length % 3 != 0) return null;
        float left=Float.POSITIVE_INFINITY, top=Float.POSITIVE_INFINITY;
        float right=Float.NEGATIVE_INFINITY, bottom=Float.NEGATIVE_INFINITY;
        for (int i=0; i<samples.length; i+=3) {
            float x=samples[i+1], y=samples[i+2];
            if (!finite(samples[i],x,y)) return null;
            left=Math.min(left,x); right=Math.max(right,x);
            top=Math.min(top,y); bottom=Math.max(bottom,y);
        }
        return right>left && bottom>top ? new CameraMorphGeometry.Target(left,top,right,bottom) : null;
    }

    /** Path.approximate triples: fraction,x,y. A narrow band avoids unstable selection
     * of a single sampled vertex at the bottom of a flat/rounded U. Not a physical lens
     * position: this is the bottom attachment point of the DISPLAY cutout.
     */
    public static float bottomCenter(float[] samples, CameraMorphGeometry.Target bounds,
            float density) {
        if (samples == null || samples.length < 6 || samples.length % 3 != 0
                || bounds == null || !finite(bounds.left, bounds.top, bounds.right,
                bounds.bottom, density) || density <= 0) return Float.NaN;
        float tolerance = Math.max(.5f, .25f*density);
        float left = Float.POSITIVE_INFINITY, right = Float.NEGATIVE_INFINITY;
        for (int i=0; i<samples.length; i+=3) {
            float x = samples[i+1], y = samples[i+2];
            if (!finite(samples[i], x, y) || x < bounds.left-tolerance
                    || x > bounds.right+tolerance || y < bounds.top-tolerance
                    || y > bounds.bottom+tolerance) return Float.NaN;
            if (y >= bounds.bottom-tolerance) {
                left = Math.min(left,x); right = Math.max(right,x);
            }
        }
        return Float.isFinite(left) && Float.isFinite(right) ? (left+right)*.5f : Float.NaN;
    }

    /** The established 15 reduced-pixel kernel at density 3, expressed in dp for
     * attached notches. A fixed 45 screen-pixel blur erases a 24dp notch at mdpi.
     * BOTH lobes and the detail pass use this radius; never sharpen only the camera.
     * Detached-hole rendering deliberately remains byte-for-byte unchanged.
     */
    public static float blurRadius(float density) {
        float d = Float.isFinite(density) && density > 0 ? density : 1f;
        return 5f * d;
    }

    private static boolean finite(float... values) {
        for (float value : values) if (!Float.isFinite(value)) return false;
        return true;
    }
}
