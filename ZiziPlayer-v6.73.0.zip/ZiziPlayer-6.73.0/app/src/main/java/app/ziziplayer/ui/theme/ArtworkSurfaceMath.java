package app.ziziplayer.ui.theme;

/**
 * 6.73: role-specific opaque tones from EXISTING cached swatches. No image I/O, track names,
 * RGB lookup tables or hue-family branches. Lyrics deliberately keep the original primary.
 *
 * A dark swatch may describe a cyan shadow better than the primary's blue highlight. It is
 * admitted only when chromatic and close to the primary hue; rival hues never repaint it.
 * Hue confidence fades smoothly (8..20 degrees), avoiding a threshold jump. Once selected,
 * the hue stays fixed while saturation/value are controlled separately for each surface.
 *
 * Near-neutral/dark RGB noise is suppressed by saturation AND absolute channel spread.
 * q is the linear-sRGB luminance of the fully saturated hue at V=1, not artwork brightness.
 * It continuously allocates more RGB headroom to cyan/green than red/blue. This is a calibrated
 * rendering policy, NOT a reconstruction of any third-party application's private algorithm.
 */
public final class ArtworkSurfaceMath {
    private static final float[] RAMP = {1f, .98f, .88f, .65f, .38f, .16f, 0f};
    private static final int BOTTOM = 0xff111111;
    public static final int SECONDARY_INK = 0xffe0e0e0;
    private ArtworkSurfaceMath() {}

    public static int[] playerBackdrop(int primary, int deep) {
        int top = playerTop(primary, deep);
        int[] out = new int[RAMP.length];
        for (int i = 0; i < out.length; i++) out[i] = linearMix(BOTTOM, top, (float) Math.pow(RAMP[i], 1.5));
        return out;
    }

    public static int playerTop(int primary, int deep) {
        float[] s = reading(primary, deep);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float q = hueLuminance(s[0]);
        float neutral = hsv(ArtworkColorMath.coverTop(grey(primary)))[2];
        float value = lerp(neutral, .175f + .56f * q, gate);
        float saturation = gate * (s[1] + .20f * (1f - s[1]));
        return visiblePlayerTop(s[0], saturation, value);
    }

    /** Not a modal sheet colour and NOT a fraction of an already darkened player backdrop. */
    public static int miniPlayer(int primary, int deep) {
        float[] s = reading(primary, deep);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float q = hueLuminance(s[0]);
        float neutral = .14f + .067f * hsv(primary)[2];
        float value = lerp(neutral, .10f + .56f * q, gate);
        float boost = .22f + .66f * (1f - q) * (1f - q);
        float saturation = gate * (s[1] + boost * (1f - s[1]));
        return bounded(s[0], saturation, value, .125);
    }

    /** Brighter cover header, not the dim listening canvas. Greys retain the previous tone. */
    public static int collectionTop(int primary) {
        float[] s = hsv(primary);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float oldValue = hsv(ArtworkColorMath.coverTop(primary))[2];
        float value = oldValue * (1f + .15f * gate);
        float saturation = gate * (s[1] + .60f * (1f - s[1]));
        return bounded(s[0], saturation, Math.min(value, .80f), .125);
    }

    /** Chips remain subdued UI surfaces, independent of the mini-player and modal panels. */
    public static int chip(int primary, int deep) {
        return ArtworkColorMath.mix(0xff1b1b1b, miniPlayer(primary, deep), .32f);
    }

    private static float[] reading(int primary, int deep) {
        float[] p = hsv(primary), d = hsv(deep);
        float delta = (d[0] - p[0] + 540f) % 360f - 180f;
        float confidence = .80f * (1f - smooth(8f, 20f, Math.abs(delta)))
                * chromaticGate(d[1]) * smooth(.06f, .18f, d[2]) * chromaticGate(p[1]);
        return new float[]{(p[0] + delta * confidence + 360f) % 360f,
                lerp(p[1], d[1], confidence), p[2]};
    }
    private static float hueLuminance(float hue) {
        return (float) ArtworkColorMath.luminance(rgb(hue, 1f, 1f));
    }
    private static float chromaticGate(float saturation) { return smooth(.08f, .22f, saturation); }
    private static float smooth(float a, float b, float x) {
        float t = clamp((x - a) / (b - a), 0f, 1f);
        return t * t * (3f - 2f * t);
    }
    private static int grey(int primary) {
        int v = Math.round(hsv(primary)[2] * 255f);
        return 0xff000000 | (v << 16) | (v << 8) | v;
    }
    private static int visiblePlayerTop(float h, float s, float v) {
        int top = bounded(h, s, v, .125);
        if (ArtworkColorMath.luminance(top) >= .012) return top;
        float lo = v, hi = 1f;
        for (int i = 0; i < 16; i++) {
            float mid = (lo + hi) * .5f;
            if (ArtworkColorMath.luminance(rgb(h, s, mid)) < .012) lo = mid; else hi = mid;
        }
        return rgb(h, s, hi);
    }
    /** Linear-light stops avoid a dark dip when a saturated blue approaches neutral black. */
    private static int linearMix(int a, int b, float t) {
        int out = 0xff000000;
        for (int shift : new int[]{16, 8, 0}) {
            double x = linear(((a >>> shift) & 255) / 255.0), y = linear(((b >>> shift) & 255) / 255.0);
            double v = x + (y - x) * t;
            int c = (int) Math.round(255 * (v <= .0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - .055));
            out |= c << shift;
        }
        return out;
    }
    private static double linear(double v) { return v <= .04045 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }
    private static int bounded(float h, float s, float v, double ceiling) {
        int result = rgb(h, s, v);
        if (ArtworkColorMath.luminance(result) <= ceiling) return result;
        float lo = 0, hi = v;
        for (int i = 0; i < 16; i++) {
            float mid = (lo + hi) * .5f;
            if (ArtworkColorMath.luminance(rgb(h, s, mid)) <= ceiling) lo = mid; else hi = mid;
        }
        return rgb(h, s, lo);
    }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }
    private static float[] hsv(int rgb) {
        float r = ((rgb >>> 16) & 255) / 255f, g = ((rgb >>> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), delta = max - min;
        float h = 0f;
        if (delta > 0f) {
            h = max == r ? (g - b) / delta : max == g ? (b - r) / delta + 2f : (r - g) / delta + 4f;
            h = (h * 60f + 360f) % 360f;
        }
        return new float[]{h, max == 0 ? 0 : delta / max, max};
    }
    private static int rgb(float hue, float sat, float value) {
        float h = ((hue % 360f) + 360f) % 360f / 60f;
        float v = clamp(value, 0f, 1f), c = v * clamp(sat, 0f, 1f), x = c * (1f - Math.abs(h % 2f - 1f)), m = v - c;
        float r = 0, g = 0, b = 0;
        if (h < 1) { r = c; g = x; } else if (h < 2) { r = x; g = c; }
        else if (h < 3) { g = c; b = x; } else if (h < 4) { g = x; b = c; }
        else if (h < 5) { r = x; b = c; } else { r = c; b = x; }
        return 0xff000000 | (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }
}
