package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.library.LibrarySyncState
import app.ziziplayer.ui.ProfilePresentation
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.blockSurfaceInput
import app.ziziplayer.ui.components.pinnedPageChrome
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.time.ZoneId

internal val ProfileSavedColor = Color(0xFF35CC96)

@Composable
internal fun profileCloudLabel(account: AccountLocalState, sync: LibrarySyncState): ProfilePresentation.CloudLabel {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (isActive) { now = System.currentTimeMillis(); delay(60_000) }
        }
    }
    return ProfilePresentation.cloud(account.isGuest, sync.ownerId == account.userId,
        sync.busy, sync.needsChoice, sync.error.isNotBlank(), sync.enabled, sync.cloudAvailable,
        sync.savedAt, now, ZoneId.systemDefault())
}

@Composable
internal fun ProfileRoundAction(icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String, progress: () -> Float, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp).drawBehind {
        drawCircle(Color.Black.copy(alpha = .42f * (1f - progress().coerceIn(0f, 1f))), radius = 20.dp.toPx())
    }) { Icon(icon, description, tint = LocalPalette.current.text, modifier = Modifier.size(24.dp)) }
}

/** A single owner for status+toolbar chrome. Symmetric slots keep the collapsed name centred. */
@Composable
internal fun ProfilePinnedHeader(title: String, progress: () -> Float,
    onBack: () -> Unit, onSettings: () -> Unit, onMenu: () -> Unit) {
    val p = LocalPalette.current
    val titleAccessible by remember(progress) { derivedStateOf { progress() >= .99f } }
    Row(Modifier.fillMaxWidth().testTag("profile-toolbar").pinnedPageChrome(progress)
        .blockSurfaceInput().statusBarsPadding().heightIn(min = 56.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.width(96.dp)) {
            ProfileRoundAction(ZiziIcons.ArrowBack, "Назад", progress, onBack)
            Spacer(Modifier.size(48.dp))
        }
        Text(title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).graphicsLayer { alpha = progress() }
                .then(if (titleAccessible) Modifier else Modifier.clearAndSetSemantics { }))
        Row {
            ProfileRoundAction(ZiziIcons.AccountGear, "Настройки", progress, onSettings)
            ProfileRoundAction(ZiziIcons.More, "Меню аккаунта", progress, onMenu)
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
internal fun ProfileStats(playlists: Int, favorites: Int, durationMs: Long, loading: Boolean, scale: Float) {
    val p = LocalPalette.current
    FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        fun number(value: String, suffix: String) = buildAnnotatedString {
            withStyle(SpanStyle(color = p.text, fontWeight = FontWeight.Bold)) { append(value) }
            withStyle(SpanStyle(color = p.subtext)) { append(" $suffix") }
        }
        Text(number(playlists.toString(), ProfilePresentation.plural(playlists.toLong(), "плейлист", "плейлиста", "плейлистов")),
            fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp)
        Text(number(if (loading) "—" else favorites.toString(), "избранных"),
            fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp)
        Text(number(if (loading) "—" else ProfilePresentation.musicTime(durationMs), "музыки"),
            fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp)
    }
}

@Composable
internal fun ProfileTabs(selectedTab: ProfileTab, scale: Float, onPick: (ProfileTab) -> Unit) {
    val p = LocalPalette.current
    LazyRow(Modifier.fillMaxWidth().background(p.surface).testTag("profile-tabs"),
        contentPadding = PaddingValues(horizontal = (20 * scale).dp),
        horizontalArrangement = Arrangement.spacedBy((8 * scale).dp)) {
        items(ProfileTab.entries, key = { it.name }) { tab ->
            // 34dp visual pill, >=48dp touch target. Large fonts increase, never clip, its height.
            Box(Modifier.heightIn(min = 48.dp).semantics { selected = selectedTab == tab }
                .clickable(role = Role.Tab, onClick = { onPick(tab) }), contentAlignment = Alignment.Center) {
                Surface(shape = CircleShape, color = if (selectedTab == tab) p.text else Color(0xFF1C1C1C)) {
                    Text(tab.label, color = if (selectedTab == tab) p.surface else p.text,
                        fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1,
                        modifier = Modifier.padding(horizontal = (14 * scale).dp, vertical = (7 * scale).dp))
                }
            }
        }
    }
}
