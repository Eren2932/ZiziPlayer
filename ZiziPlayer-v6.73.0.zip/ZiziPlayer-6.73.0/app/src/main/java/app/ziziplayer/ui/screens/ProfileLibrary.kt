@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.ziziplayer.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.playback.OfflineDownloads
import app.ziziplayer.privacy.VaultState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*

internal enum class ProfileTab(val label: String) {
    PLAYLISTS("Плейлисты"), FAVORITES("Избранные"), RECENT("Недавние"), DOWNLOADS("Загрузки")
}

internal data class ProfileRecent(val session: ListeningSessionEntity, val track: TrackEntity?)
internal data class ProfileLibraryState(
    val loading: Boolean = true,
    val hidden: Set<String> = emptySet(),
    val gate: VaultState = VaultState(emptySet()),
    val favorites: List<TrackEntity> = emptyList(),
    val recent: List<ProfileRecent> = emptyList(),
    val downloads: List<TrackEntity> = emptyList(),
    val durationMs: Long = 0L,
    val error: String = ""
)
private data class ProfileSources(val all: List<TrackEntity>, val favorites: List<TrackEntity>,
    val hidden: Set<String>, val gate: VaultState)

/** Subscriptions exist only while the profile is STARTED. History is observed only on its tab;
 * download file checks happen on IO, never in a row or during a scroll. No player clock here. */
@Composable
internal fun rememberProfileLibrary(tab: ProfileTab, owner: String?, refresh: Int): ProfileLibraryState {
    val app = LocalContext.current.applicationContext as ZiziApplication
    val repo = app.repository
    val gate by repo.vault.state.collectAsStateWithLifecycle()
    val hiddenFlow: Flow<Set<String>?> = remember(repo) { repo.hiddenIds }
    val hidden by hiddenFlow.collectAsStateWithLifecycle(initialValue = null)
    val source = remember(app, tab, owner, refresh) {
        val sources = combine(repo.allTracks, repo.favoriteTracks, repo.hiddenIds, repo.vault.state) { all, favorites, ids, vault ->
            ProfileSources(all, favorites, ids, vault)
        }
        val history = if (tab == ProfileTab.RECENT) app.database.listeningDao().observeSessions()
            else flowOf(emptyList<ListeningSessionEntity>())
        val downloadChanges = OfflineDownloads.states.map { states -> states.mapValues { it.value::class } }.distinctUntilChanged()
        val downloaded = if (tab == ProfileTab.DOWNLOADS) combine(repo.allTracks, downloadChanges) { tracks, _ ->
            tracks.asSequence().filter { it.isRemote && OfflineDownloads.isComplete(app, it) }.map { it.id }.toSet()
        }.flowOn(Dispatchers.IO) else flowOf(emptySet<String>())
        combine(sources, history, downloaded) { input, sessions, offlineIds ->
            fun allowed(track: TrackEntity): Boolean = track.id !in input.hidden &&
                !input.gate.blocks(track) && (!track.isRemote || CatalogPolicy.supports(track.provider, track.remoteId))
            val allowed = input.all.filter(::allowed)
            val byId = allowed.associateBy { it.id }
            val favorites = input.favorites.filter(::allowed).distinctBy { it.id }
            val recent = sessions.asSequence().filter { row -> row.trackId !in input.hidden &&
                (row.source != "local" || input.gate.unlocked || row.sourceFolder !in input.gate.folders)
            }.distinctBy { it.trackId }.take(200).map { ProfileRecent(it, byId[it.trackId]) }.toList()
            ProfileLibraryState(loading = false, hidden = input.hidden, gate = input.gate,
                favorites = favorites, recent = recent,
                downloads = allowed.filter { it.id in offlineIds }.sortedByDescending { it.savedAt ?: it.dateAdded },
                durationMs = allowed.asSequence().filter { !it.isRemote || it.savedAt != null }
                    .sumOf { it.durationMs.coerceAtLeast(0) })
        }.flowOn(Dispatchers.Default).catch {
            emit(ProfileLibraryState(loading = false, error = "Не удалось прочитать библиотеку. Повторить"))
        }
    }
    // key resets the collector's old value when the tab/owner changes: no one-frame old list.
    val raw by key(source) { source.collectAsStateWithLifecycle(initialValue = ProfileLibraryState()) }
    if (raw.error.isNotBlank()) return ProfileLibraryState(loading = false, error = raw.error)
    // A lock/hide emission can outrun the off-main projection. Fail closed at the render boundary.
    return if (hidden != null && raw.hidden == hidden && raw.gate == gate) raw else ProfileLibraryState()
}
