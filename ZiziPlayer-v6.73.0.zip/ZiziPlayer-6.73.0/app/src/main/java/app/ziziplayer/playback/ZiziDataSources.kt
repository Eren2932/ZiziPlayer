package app.ziziplayer.playback

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import java.io.IOException
import android.net.Uri
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.InnertubeCatalog
import app.ziziplayer.data.remote.PoTokenMinter
import app.ziziplayer.data.remote.ZiziHttp

/**
 * How bytes reach the decoder. The order of the wrappers is the design.
 *
 *   DefaultDataSource            file:// and content:// are handled locally, exactly as before -
 *        │                       a local track never touches any of the network machinery
 *        ▼  (unknown scheme, i.e. zizi://)
 *   CacheDataSource              keys by zizi://, so an entry survives the address changing
 *        │
 *        ▼
 *   ResolvingDataSource          zizi:// -> https://..., resolved now, not earlier
 *        │
 *        ▼
 *   OkHttpDataSource             on the SAME OkHttp client the catalogue uses: one connection pool,
 *                                so the stream reuses the TLS session the search just opened
 *
 * If cache and resolver were swapped, the cache would key entries by the expiring googlevideo URL
 * and every replay would download the track again. That single line of ordering is the difference
 * between a cache and a decoration.
 */
@UnstableApi
object ZiziDataSources {

    fun mediaSourceFactory(context: Context): MediaSource.Factory =
        DefaultMediaSourceFactory(dataSourceFactory(context))
            .setLoadErrorHandlingPolicy(RemoteLoadErrorPolicy())

    /**
     * Сеть + резолвер, БЕЗ единого кэша.
     *
     * Вынесено наружу ради «Скачать»: загрузчик пишет в свой кэш сам и не должен по дороге
     * заполнять стримовый — иначе одни и те же байты лежали бы на диске дважды.
     */
    fun resolvingFactory(context: Context): DataSource.Factory {
        val http: HttpDataSource.Factory = OkHttpDataSource.Factory(ZiziHttp.client)
        return ResolvingDataSource.Factory(http, StreamResolver(context))
    }

    fun dataSourceFactory(context: Context): DataSource.Factory {
        // Cross-protocol redirects (https -> http on a CDN hand-off) are NOT configured here on
        // purpose: unlike DefaultHttpDataSource.Factory, the OkHttp-backed factory has no such
        // setter, because it does not do redirects itself - OkHttp does, and ZiziHttp.client
        // already has followRedirects/followSslRedirects on. Calling the Media3 setter here was a
        // compile error, and reaching for it again would be a redundant one.
        // No .setUserAgent here, ON PURPOSE. The factory-level agent is applied after the
        // DataSpec's own headers are merged in, so setting it would quietly override the
        // per-stream agent that StreamResolver attaches - and a YouTube URL fetched with the
        // wrong agent is a 403. Every zizi:// request passes through the resolver, and the
        // resolver always sets a UA, so nothing is left agent-less.
        val http: HttpDataSource.Factory = OkHttpDataSource.Factory(ZiziHttp.client)

        val resolving = ResolvingDataSource.Factory(http, StreamResolver(context))

        val upstream: DataSource.Factory = if (RemoteRuntime.cacheEnabled) {
            CacheDataSource.Factory()
                .setCache(StreamCache.get(context))
                .setUpstreamDataSourceFactory(resolving)
                // Read from cache, write to cache, but never let a cache write failure kill
                // playback: a full disk must degrade to streaming, not to silence.
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        } else {
            resolving
        }

        // Скачанное читается ПЕРВЫМ и вообще не участвует в сетевой цепочке.
        //
        // 6.24.0: раньше здесь стоял ещё один CacheDataSource над кэшем загрузок. Сейчас
        // загрузка — это настоящий файл в «Музыка/Zizi», поэтому слой сведён к одной проверке в
        // момент открытия источника: есть файл — играем файл, нет — идём в сеть. Ноль секунд до
        // звука, полная независимость от связи и, что важнее, ноль шансов, что обычное
        // прослушивание молча наполнит папку загрузок.
        val offlineFirst: DataSource.Factory = OfflineFirstDataSource.Factory(context, upstream)

        return DefaultDataSource.Factory(context, offlineFirst)
    }

    /**
     * Buffering tuned for a mobile connection.
     *
     * The defaults (50 s of buffer, 2.5 s before playback starts) are written for video on wifi.
     * For audio on LTE a deeper buffer is nearly free - a 128 kbps track is 16 KB/s, so 90 s costs
     * about 1.4 MB - and it is what carries playback through a lift, a tunnel or a dead cell.
     * The start thresholds stay low so tapping a track still feels immediate.
     */
    fun loadControl(): LoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            /* minBufferMs = */ 20_000,
            /* maxBufferMs = */ 90_000,
            /* bufferForPlaybackMs = */ 1_500,
            /* bufferForPlaybackAfterRebufferMs = */ 3_000
        )
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()
}

/**
 * Gives an expired stream URL exactly one second chance.
 *
 * The default policy treats HTTP 403 as fatal, which is right for a normal server and wrong for
 * this one: 403 is precisely what a stale, IP-bound YouTube link returns, and the fix is to ask
 * again - the retry re-enters [StreamResolver] and gets a fresh address. Without this override the
 * six-hour link expiry shows up as "трек просто перестал играть" halfway through a long queue.
 *
 * One retry, not three: if a freshly resolved URL also 403s, the track really is gone and grinding
 * on it only delays skipping to the next one.
 */
@UnstableApi
class RemoteLoadErrorPolicy : DefaultLoadErrorHandlingPolicy() {

    override fun getRetryDelayMsFor(info: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
        val exception = info.exception
        // StreamResolver wraps catalog errors as IOExceptions. A terminal match
        // miss will not improve by repeating the same cached /match request.
        val catalogError = generateSequence<Throwable>(exception) { it.cause }
            .take(12).filterIsInstance<CatalogException>().firstOrNull()
        if (catalogError?.reason == CatalogException.Reason.UNAVAILABLE)
            return androidx.media3.common.C.TIME_UNSET
        val code = (exception as? HttpDataSource.InvalidResponseCodeException)?.responseCode
            ?: (exception.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
        if (code == 403 || code == 401 || code == 410) {
            // Two things have to be thrown away before the retry, and 6.7.0 threw away neither:
            //
            //  1. the resolved address, or the retry would be handed the exact URL that was just
            //     refused and would fail identically, twice as slowly;
            //  2. the trust in the internal client that produced it - dropping it makes the next
            //     resolve verify against the CDN again and move on to another client if needed.
            //
            // Without these, a 403 halfway through a queue was terminal in practice: the retry was
            // real but it could not possibly succeed.
            // 6.19.0: выбрасываем адреса только того источника, который отказал.
            //
            // `LoadEventInfo.uri` — это наш собственный zizi://-адрес: StreamResolver сознательно
            // возвращает его из resolveReportedUri, чтобы Media3 видела стабильный ресурс. Значит,
            // источник из него читается напрямую. Если по какой-то причине не прочитался, ведём
            // себя как раньше — сносим всё: перестраховка здесь дешевле, чем застрявший адрес.
            val provider = RemoteUri.parse(info.loadEventInfo.uri)?.first
            if (provider != null) ResolvedStreams.clearProvider(provider) else ResolvedStreams.clear()

            // Недоверие к внутреннему клиенту и сброс аттестации касаются YouTube и только его.
            // Другим каталогам не нужен poToken — сбрасывать там нечего, а один
            // прогон WebView за минту токена это реальные полторы секунды и разряд батареи. Раньше
            // 403 от любого источника (включая свой собственный резолвер, который отвечает 403 на
            // бот-чек) запускал эту машину вхолостую.
            if (provider == null || provider == InnertubeCatalog.ID) {
                InnertubeCatalog.distrust()
                // 6.9.0: and the attestation, on 401/403. A token that was accepted by the player
                // endpoint and then refused by the CDN is a token that has gone stale mid-session
                // (revoked key, changed IP, expired integrity); keeping it means every retry
                // carries the same dead proof. Dropping it costs one WebView run on the next track
                // and nothing if the token was not the problem.
                PoTokenMinter.invalidate()
            }
            // Two chances now, not one: the first retry re-resolves with the same (still trusted)
            // client, the second gets a genuinely different one.
            if (info.errorCount <= 2) return 400L
        }
        return super.getRetryDelayMsFor(info)
    }
}

/**
 * «Сначала скачанное, потом сеть» — один источник, два возможных нижних слоя.
 *
 * Почему не CacheDataSource, как было до 6.24.0: кэш умеет отдавать ЧАСТИЧНО закэшированный
 * ресурс, дочитывая остаток из сети. Для загрузки это неверная семантика — скачанный трек либо
 * есть целиком, либо его нет, и «наполовину офлайн» это состояние, которого не должно
 * существовать. Здесь решение принимается один раз, в [open], и дальше поток идёт из одного
 * места до самого конца.
 *
 * Пропавший файл (пользователь удалил его проводником — он на это имеет полное право, файл лежит
 * в его папке) не превращается в ошибку воспроизведения: запись вычищается из индекса, и тот же
 * запрос уходит в сеть. Молча — потому что для слушателя ничего и не произошло, музыка играет.
 */
@UnstableApi
class OfflineFirstDataSource(
    private val context: Context,
    private val network: DataSource
) : DataSource {

    class Factory(
        private val context: Context,
        private val network: DataSource.Factory
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource =
            OfflineFirstDataSource(context, network.createDataSource())
    }

    private val listeners = ArrayList<TransferListener>()
    private var localSource: DataSource? = null
    private var active: DataSource? = null

    override fun addTransferListener(transferListener: TransferListener) {
        listeners.add(transferListener)
        network.addTransferListener(transferListener)
        localSource?.addTransferListener(transferListener)
    }

    private fun openNetwork(dataSpec: DataSpec): Long {
        val span = StartupTrace.begin(StartupTrace.Stage.NETWORK_OPEN)
        try {
            return network.open(dataSpec).also { StartupTrace.finish(span, StartupTrace.Outcome.OK) }
        } catch (e: Exception) {
            StartupTrace.finish(span, StartupTrace.Outcome.ERROR)
            throw e
        }
    }

    override fun open(dataSpec: DataSpec): Long {
        val local = OfflineStore.playbackUri(context, dataSpec.uri)
        if (local == null) {
            active = network
            return openNetwork(dataSpec)
        }
        val source = localSource ?: DefaultDataSource.Factory(context).createDataSource().also { created ->
            listeners.forEach { created.addTransferListener(it) }
            localSource = created
        }
        active = source
        return try {
            source.open(dataSpec.buildUpon().setUri(local).build())
        } catch (error: IOException) {
            OfflineStore.forgetUri(context, dataSpec.uri)
            active = network
            openNetwork(dataSpec)
        }
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
        (active ?: throw IOException("источник не открыт")).read(buffer, offset, length)

    override fun getUri(): Uri? = active?.uri

    override fun getResponseHeaders(): Map<String, List<String>> =
        active?.responseHeaders ?: emptyMap()

    override fun close() {
        val source = active
        active = null
        source?.close()
    }
}
