package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Read the Activity's LocalView before entering the dialog's separate window. */
@Composable
internal fun CameraMorphDiagnosticsDialog(onDismiss: () -> Unit) {
    val camera = rememberCameraCutout()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Слияние обложки с камерой") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SelectionContainer { Text(camera.report()) }
                Spacer(Modifier.height(12.dp))
                Text("Контур виден только на экранах подборок. Бирюзовый — форма системы, " +
                    "розовый — её границы. Для приближённого режима это оценка, не физический замер. Сравнивай с отверстием прямо на телефоне. " +
                    "Проверка временная: выключается здесь или после перезапуска приложения.")
                if (CameraMorphDebug.outlineEnabled) Text("Проверочный контур сейчас включён.")
                Spacer(Modifier.height(12.dp))
                Text("Для проверки дрожания включи запись, удержи обложку у камеры и вернись сюда. " +
                    "Сохраняются только числа последних 240 событий в памяти; треки, изображения " +
                    "и касания вне прокрутки не записываются. Ничего не отправляется.")
                TextButton(onClick = {
                    if (CameraMorphDebug.traceEnabled) CameraMorphDebug.stopTrace()
                    else CameraMorphDebug.startTrace()
                    onDismiss()
                }) { Text(if (CameraMorphDebug.traceEnabled) "Остановить запись" else "Начать запись движений") }
                SelectionContainer { Text(CameraMorphDebug.traceReport()) }
            }
        },
        confirmButton = {
            TextButton(enabled = camera.target != null, onClick = {
                CameraMorphDebug.outlineEnabled = !CameraMorphDebug.outlineEnabled
                onDismiss()
            }) { Text(if (CameraMorphDebug.outlineEnabled) "Выключить контур" else "Включить контур") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
