package app.ziziplayer.ui;

import org.junit.Test;

public final class CameraMorph66912Test {
    @Test public void smoothPixelMotion() { CameraMorph66912Checks.main(new String[0]); }
}
