package app.ziziplayer.ui

import org.junit.Test

class ArtworkSurfaceMathTest {
    @Test fun artworkRolesStayReadableAndStable() { ArtworkSurfaceMathChecks.runAll() }
}
