package app.ziziplayer.ui;

/** Production Java math; does not execute Android/Compose/Skia. */
public final class CameraMorph66912Checks {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static CameraMorphGeometry.Frame frame(float scroll, float scale, CameraMorphGeometry.Target t) {
        return CameraMorphGeometry.frame(716*scale,315.04f*scale,1,scroll,
            540*scale,164*scale,8*scale,369.04f*scale,110*scale,t);
    }
    private static float width(float scroll, float scale, CameraMorphGeometry.Target t) {
        var g=CameraMorphGeometry.goo(t,frame(scroll,scale,t));
        return g==null ? 0 : CameraMorphGeometry.waist(g.u)*18.5f*scale;
    }
    public static void main(String[] args) {
        float maxSpeed=0;
        // Subpixel steps + real integer list offsets, central and both corner cameras.
        for(float scale:new float[]{.4f,.5f,.75f,1f,1.5f,2f,3f}) {
            for(float center:new float[]{108f,540f,972f}) {
                var target=new CameraMorphGeometry.Target((center-18.5f)*scale,50*scale,
                    (center+18.5f)*scale,87*scale);
                for(float step:new float[]{.25f,1f}) {
                    float previous=width(0,scale,target);
                    for(int i=1;i*step<369.04f*scale*.89f;i++) {
                        float scroll=i*step;
                        float current=width(scroll,scale,target);
                        float speed=(current-previous)/step;
                        check(speed>=-.005f,"monotone opening");
                        // Corner trajectories also consume horizontal distance; the central
                        // fixture isolates the contact curve from that extra velocity.
                        check(speed<(center==540f ? 3.2f : 8f),"neck amplifies scroll too much: "+speed);
                        maxSpeed=Math.max(maxSpeed,speed);
                        // No history, same value after a one-pixel reverse motion.
                        width(scroll+step,scale,target);
                        check(Float.floatToIntBits(current)==Float.floatToIntBits(width(scroll,scale,target)),
                            "reversal must not introduce hysteresis");
                        var f=frame(scroll,scale,target);
                        var g=CameraMorphGeometry.goo(target,f);
                        if(g!=null && g.flesh!=null) {
                            for(float v:g.flesh)check(Float.isFinite(v),"finite path coordinates");
                        }
                        previous=current;
                    }
                }
            }
        }
        // C1 onset: width and its first derivative approach zero from the joined side.
        check(CameraMorphGeometry.waist(3.07f)==0,"zero-width contact");
        check(CameraMorphGeometry.waist(3.07f-.001f)<.0001f,"no width step at contact");
        float slope=(CameraMorphGeometry.waist(3.07f-.002f)-CameraMorphGeometry.waist(3.07f-.001f))/.001f;
        check(slope<.15f,"flat onset derivative");
        check(CameraMorphGeometry.waist(2.45f)==2.62f,"retain reference full neck");
        check(Math.abs(CollectionGeometry.scrimAlpha(1)-.80f)<.000001f,"80% bottom scrim");
        check(CollectionGeometry.scrimAlpha(0)==0,"transparent lead-in retained");
        System.out.println("PASS: "+checks+" 6.69.12 assertions; max waist px/scroll px="+maxSpeed+" (not Android)");
    }
}
