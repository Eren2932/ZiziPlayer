package app.ziziplayer.ui;

import java.util.ArrayList;

/** Numerical winding check of production cubic extensions. It does not execute Compose,
 * Path.op, Skia, antialiasing or the GPU. The Android test calls the real mask helper.
 * A clockwise simple body contributes +1. A nonnegative extension winding cannot cancel
 * it under NonZero; EvenOdd and the default counterclockwise body CAN cancel overlaps.
 */
public final class CameraMask66914Checks {
    private static int assertions;
    private static void require(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static double[][] flatten(float[] commands) {
        ArrayList<double[]> points = new ArrayList<>();
        double x = 0, y = 0;
        for (int i = 0; i < commands.length;) {
            int op = (int) commands[i++];
            if (op == 0) {
                x = commands[i++]; y = commands[i++]; points.add(new double[]{x, y});
            } else if (op == 1) {
                double x1 = commands[i++], y1 = commands[i++], x2 = commands[i++], y2 = commands[i++];
                double x3 = commands[i++], y3 = commands[i++];
                for (int j = 1; j <= 32; j++) {
                    double t = j / 32.0, a = 1 - t;
                    points.add(new double[]{a*a*a*x + 3*a*a*t*x1 + 3*a*t*t*x2 + t*t*t*x3,
                        a*a*a*y + 3*a*a*t*y1 + 3*a*t*t*y2 + t*t*t*y3});
                }
                x = x3; y = y3;
            } else require(op == 2, "valid cubic extension opcode");
        }
        return points.toArray(new double[0][]);
    }
    private static int winding(double[][] p, double x, double y) {
        int w = 0;
        for (int i = 0; i < p.length; i++) {
            double[] a = p[i], b = p[(i+1) % p.length];
            double side = (b[0]-a[0]) * (y-a[1]) - (x-a[0]) * (b[1]-a[1]);
            if (a[1] <= y && b[1] > y && side > 0) w++;
            else if (a[1] > y && b[1] <= y && side < 0) w--;
        }
        return w;
    }
    private static boolean inBody(CameraMorphGeometry.Frame f, double x, double y) {
        double halfW = f.width / 2.0, halfH = f.height / 2.0;
        double dx = Math.abs(x-f.cx), dy = Math.abs(y-f.cy);
        if (dx > halfW || dy > halfH) return false;
        double r = Math.max(0, Math.min(f.radius, Math.min(halfW, halfH)));
        dx = Math.max(0, dx - (halfW-r)); dy = Math.max(0, dy - (halfH-r));
        return dx*dx + dy*dy <= r*r + 1e-12;
    }
    public static void main(String[] args) {
        boolean evenOdd = args.length > 0 && args[0].equals("evenodd");
        boolean opposite = args.length > 0 && args[0].equals("opposite");
        int fixtures = 0, separated = 0, joined = 0, overlaps = 0;
        for (float scale : new float[]{.5f, 1f, 2f}) {
            for (float cx : new float[]{108f, 540f, 972f}) {
                for (float aspect : new float[]{.75f, 1f, 1.3f}) {
                    var target = new CameraMorphGeometry.Target((cx-18.5f*aspect)*scale,49.5f*scale,
                        (cx+18.5f*aspect)*scale,86.5f*scale);
                    for (int step=125; step<995; step+=7) {
                        var f = CameraMorphGeometry.frame(716*scale,315.04f*scale,1,
                            step*.001f*369.04f*scale,540*scale,148*scale,18*scale,369.04f*scale,94*scale,target);
                        var g = CameraMorphGeometry.goo(target,f);
                        if (g == null || g.flesh == null) continue;
                        fixtures++; if (g.joined) joined++; else separated++;
                        var poly = flatten(g.flesh);
                        double area2=0, left=f.left(), right=f.left()+f.width, top=f.top(), bottom=f.top()+f.height;
                        for (int i=0; i<poly.length; i++) {
                            double[] a=poly[i], b=poly[(i+1)%poly.length];
                            area2 += a[0]*b[1] - b[0]*a[1];
                            left=Math.min(left,a[0]); right=Math.max(right,a[0]);
                            top=Math.min(top,a[1]); bottom=Math.max(bottom,a[1]);
                        }
                        require(area2 > 0, "extension must wind clockwise in window coordinates");
                        for (int iy=0; iy<17; iy++) for (int ix=0; ix<17; ix++) {
                            double x=left+(right-left)*(ix+.37)/17, y=top+(bottom-top)*(iy+.61)/17;
                            int extension=winding(poly,x,y);
                            require(extension >= 0, "extension cannot contain a negative winding region");
                            int body=inBody(f,x,y) ? 1 : 0;
                            boolean union=body!=0 || extension!=0;
                            int total=(opposite ? -body : body)+extension;
                            boolean mask=evenOdd ? (total&1)!=0 : total!=0;
                            require(mask==union,"compound mask must equal set union, without overlap holes");
                            if (body!=0 && extension!=0) overlaps++;
                        }
                    }
                }
            }
        }
        require(fixtures>1000 && separated>0 && joined>0 && overlaps>1000,"nontrivial winding fixtures");
        System.out.println("Mask fixture grid: "+fixtures+" contours, "+separated+" separated, "+joined+
            " joined, "+overlaps+" overlap witnesses; cubic flattening 32 samples/segment");
        System.out.println("PASS: "+assertions+" winding/union assertions (pure JVM; not Android rasterization)");
    }
}
