package app.ziziplayer.playback

import org.junit.Test

class ShuffleStartPolicyTest {
    @Test fun exhaustiveUniformFirstDraw() { ShuffleStart6712Checks.main(emptyArray()) }
}
