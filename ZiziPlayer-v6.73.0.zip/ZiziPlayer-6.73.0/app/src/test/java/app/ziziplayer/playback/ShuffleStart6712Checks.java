package app.ziziplayer.playback;

import java.util.Random;

/** Exhaustive discrete proof of the production mapping, not a statistical smoke test. */
public final class ShuffleStart6712Checks {
    private static int checks;
    private static void verify(boolean condition) {
        checks++;
        if (!condition) throw new AssertionError("shuffle check " + checks);
    }
    private static final class Draw extends Random {
        final int value, expectedBound;
        int calls;
        Draw(int value, int expectedBound) { this.value = value; this.expectedBound = expectedBound; }
        @Override public int nextInt(int bound) {
            calls++;
            verify(bound == expectedBound);
            return value;
        }
    }
    public static void main(String[] args) {
        checks = 0;
        Draw noDraw = new Draw(0, -1);
        verify(ShuffleStartPolicy.chooseStartIndex(0, -1, noDraw) == -1);
        verify(ShuffleStartPolicy.chooseStartIndex(1, 0, noDraw) == 0);
        verify(ShuffleStartPolicy.chooseStartIndex(1, -1, noDraw) == 0);
        verify(noDraw.calls == 0);
        boolean rejected = false;
        try { ShuffleStartPolicy.chooseStartIndex(-1, -1, noDraw); }
        catch (IllegalArgumentException expected) { rejected = true; }
        verify(rejected);
        // Every possible random draw, every possible excluded index, all sizes up to 128.
        for (int size = 2; size <= 128; size++) {
            for (int current = -1; current <= size; current++) {
                boolean excluded = current >= 0 && current < size;
                int bound = size - (excluded ? 1 : 0);
                int[] counts = new int[size];
                for (int draw = 0; draw < bound; draw++) {
                    Draw rng = new Draw(draw, bound);
                    int index = ShuffleStartPolicy.chooseStartIndex(size, current, rng);
                    verify(index >= 0 && index < size);
                    verify(!excluded || index != current);
                    verify(rng.calls == 1);
                    counts[index]++;
                }
                // Exactly one preimage for each eligible index: probability = 1 / bound.
                for (int index = 0; index < size; index++)
                    verify(counts[index] == (excluded && index == current ? 0 : 1));
            }
        }
        Random random = new Random(6712L);
        for (int size : new int[] {600, 633, 10000, Integer.MAX_VALUE}) {
            for (int trial = 0; trial < 10000; trial++) {
                int current = trial % 2 == 0 ? size - 1 : random.nextInt(size);
                int index = ShuffleStartPolicy.chooseStartIndex(size, current, random);
                verify(index >= 0 && index < size && index != current);
            }
        }
        System.out.println("ShuffleStartPolicy: " + checks + " checks passed (exhaustive uniformity + large queues)");
    }
}
