package app.ziziplayer.ui;
import org.junit.Test;
public final class CameraMask66914Test {
    @Test public void nonZeroWindingPreservesUnion() { CameraMask66914Checks.main(new String[0]); }
}
