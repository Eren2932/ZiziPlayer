package app.ziziplayer.ui;
import org.junit.Test;
public final class CameraMorph66910Test {
    @Test public void referenceContactAndReverseMaterial() { CameraMorph66910Checks.main(new String[0]); }
}
