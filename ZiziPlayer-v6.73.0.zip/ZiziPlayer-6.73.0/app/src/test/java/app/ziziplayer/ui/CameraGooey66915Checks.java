package app.ziziplayer.ui;

import java.util.Arrays;
import java.util.Locale;

public final class CameraGooey66915Checks {
    private static int assertions;
    private static void check(boolean value, String what) {
        assertions++;
        if (!value) throw new AssertionError(what);
    }
    private static void eq(float a, float b, float tolerance, String what) {
        check(Float.isFinite(a) && Float.isFinite(b) && Math.abs(a-b)<=tolerance,
                what+": "+a+" != "+b);
    }
    public static CameraMorphGeometry.Frame fixture(float p, float x, float scale) {
        CameraMorphGeometry.Target t = new CameraMorphGeometry.Target((x-18.5f)*scale,
                49.5f*scale, (x+18.5f)*scale, 86.5f*scale);
        return CameraGooeyGeometry.frame(716f*scale,315.04f*scale,1f,369.04f*scale*p,
                540f*scale,148f*scale,18f*scale,369.04f*scale,94f*scale,t);
    }
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("samples")) {
            for (int i=0;i<=1000;i++) {
                float p=i/1000f;
                CameraMorphGeometry.Target t = new CameraMorphGeometry.Target(521.5f,49.5f,558.5f,86.5f);
                CameraMorphGeometry.Frame f=fixture(p,540,1);
                CameraGooeyGeometry.Seeds s=CameraGooeyGeometry.seeds(t,f,3f);
                System.out.printf(Locale.ROOT,"%.5f %.6f %.6f %.6f %.6f %.6f",p,f.cx,f.cy,f.width,f.radius,s.protrusion);
                for (float v:s.camera) System.out.printf(Locale.ROOT," %.6f",v);
                for (float v:s.artwork) System.out.printf(Locale.ROOT," %.6f",v);
                System.out.println();
            }
            return;
        }
        eq(CameraGooeyGeometry.BLUR_RADIUS,15,0,"Reduced-pixel blur radius");
        eq(CameraGooeyGeometry.GOO_SCALE,3,0,"High-performance profile scale");
        eq(CameraGooeyGeometry.protrusion(0,3),0,0,"No initial protrusion");
        eq(CameraGooeyGeometry.protrusion(.5f,3),63,0,"Pulse peak");
        eq(CameraGooeyGeometry.protrusion(1,3),0,0,"No final protrusion");
        eq(CameraGooeyGeometry.protrusion(.25f,3),31.5f,.0001f,"Pulse rising");
        eq(CameraGooeyGeometry.protrusion(.75f,3),31.5f,.0001f,"Pulse falling");
        eq(CameraGooeyGeometry.blurIntensity(.2f),0,0,"Blur onset");
        eq(CameraGooeyGeometry.blurIntensity(.45f),.5f,.0001f,"Blur ramp");
        eq(CameraGooeyGeometry.blurIntensity(1),.75f,0,"Blur limit");
        eq(CameraGooeyGeometry.imageAlpha(.5f),1,0,"Color until half progress");
        eq(CameraGooeyGeometry.imageAlpha(.75f),.5f,0,"Color fade");
        eq(CameraGooeyGeometry.blurImageAlpha(.5f),.75f,0,"Detail alpha");
        eq(CameraGooeyGeometry.threshold(125f/255),0,.00001f,"Threshold floor");
        eq(CameraGooeyGeometry.threshold(.5f),.5f,.00001f,"Threshold midpoint");
        eq(CameraGooeyGeometry.threshold(130f/255),1,.00001f,"Threshold ceiling");
        float combined=.3f+.3f*(1-.3f);
        eq(CameraGooeyGeometry.threshold(combined),1,.00001f,"Common threshold connects overlapping blur tails");
        eq(CameraGooeyGeometry.threshold(.3f),0,0,"Separate threshold would NOT connect");
        check(CameraGooeyGeometry.protrusion(Float.NaN,Float.NaN)==0,"Invalid input is finite");
        float maxInputStep=0;
        for (float scale:new float[]{.5f,1f,1.5f,2f}) for (float x:new float[]{108f,540f,972f}) {
            CameraMorphGeometry.Target t=new CameraMorphGeometry.Target((x-18.5f)*scale,
                    49.5f*scale,(x+18.5f)*scale,86.5f*scale);
            CameraMorphGeometry.Frame last=fixture(0,x,scale);
            for (int i=0;i<=10000;i++) {
                float p=i/10000f;
                CameraMorphGeometry.Frame f=fixture(p,x,scale);
                CameraGooeyGeometry.Seeds s=CameraGooeyGeometry.seeds(t,f,3*scale);
                check(f.width>0 && f.height>0 && f.imageAlpha>=0 && f.imageAlpha<=1,"Finite positive frame");
                check(f.width<=last.width+.0001f,"Monotonic shrink");
                eq(f.width,(315.04f+(18.5f-315.04f)*p)*scale,.001f*scale,"Reference linear size");
                eq(f.top(),(148f+(68f-148f)*p)*scale,.001f*scale,"Reference linear top (avatarY, pivot 0,0)");
                eq(f.cy,f.top()+f.width*.5f,.001f*scale,"Centre follows top + size/2");
                check(p>=1f || f.imageAlpha==1f,"No opacity fade of the black goo before completion");
                eq((float)Math.hypot(s.nx,s.ny),1,.00001f,"Unit axis");
                float tipDx=s.camera[2]-t.cx(),tipDy=s.camera[3]-t.cy();
                eq(tipDx*s.ny-tipDy*s.nx,0,.0003f*scale,"Camera apex lies on approach axis");
                eq((float)Math.hypot(s.camera[0]-s.camera[4],s.camera[1]-s.camera[5]),
                        s.protrusion,.0003f*scale,"Camera seed base equals h");
                float end=(float)Math.hypot(f.cx-t.cx(),f.cy-t.cy());
                if (end>.001) {
                    eq((s.artwork[2]-f.cx)*s.nx+(s.artwork[3]-f.cy)*s.ny,
                            -f.width*.5f-s.reach*.25f,.0003f*scale,"Artwork apex extension");
                }
                CameraGooeyGeometry.seeds(t,fixture(1-p,x,scale),3*scale);
                CameraGooeyGeometry.Seeds again=CameraGooeyGeometry.seeds(t,fixture(p,x,scale),3*scale);
                check(Arrays.equals(s.camera,again.camera)&&Arrays.equals(s.artwork,again.artwork),"Hold/reversal bit-identical");
                for (float v:s.camera) check(Float.isFinite(v),"Finite camera seed");
                for (float v:s.artwork) check(Float.isFinite(v),"Finite artwork seed");
                if(i>0) maxInputStep=Math.max(maxInputStep,Math.abs(f.cy-last.cy));
                last=f;
            }
            eq(last.width,t.width()*.5f,.0001f*scale,"End diameter half hole");
            eq(last.top(),t.cy(),.001f*scale,"Artwork top ends at hole centre");
            eq(last.top()+last.height,t.bottom,.001f*scale,"Artwork bottom ends at hole bottom");
            eq(last.imageAlpha,0,0,"No residual overlay at completion");
            CameraMorphGeometry.Frame overscroll=fixture(2,x,scale);
            eq(overscroll.width,last.width,0,"Overscroll clamped");
            CameraMorphGeometry.Frame a=fixture(.40000f,x,scale), b=fixture(.40001f,x,scale);
            check(Math.abs(a.cy-b.cy)>0 && Math.abs(a.cy-b.cy)<.01f*scale,"Subpixel movement retained");
        }
        eq(CameraGooeyGeometry.imageAlpha(1),0,0,"Fully black before final hide");
        CameraMorphGeometry.Frame a=CameraGooeyGeometry.frame(716,315,1,50,540,148,18,369,94,null);
        CameraMorphGeometry.Frame b=CameraMorphGeometry.frame(716,315,1,50,540,148,18,369,94,null);
        eq(a.cx,b.cx,0,"No-hole fallback unchanged"); eq(a.width,b.width,0,"No-hole size unchanged");
        System.out.println("PASS: "+assertions+" production gooey parameter/seed assertions; max fixture step="+maxInputStep+" px. Not Android rasterization.");
    }
}
