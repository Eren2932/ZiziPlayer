package app.ziziplayer.ui;

/** Offline tests of production math. Android raster/Compose tests are separate. */
public final class CameraMorph66910Checks {
    private static int checks;
    private static void ok(boolean b, String message) {
        checks++;
        if (!b) throw new AssertionError(message);
    }
    private static void near(float a, float b, float tolerance, String message) {
        ok(Float.isFinite(a) && Float.isFinite(b) && Math.abs(a-b)<=tolerance,
                message+": "+a+" vs "+b);
    }
    private static CameraMorphGeometry.Frame frame(float p, CameraMorphGeometry.Target t, float scale) {
        return CameraMorphGeometry.frame(716*scale,315.04f*scale,1,369.04f*scale*p,
                540*scale,164*scale,8*scale,369.04f*scale,110*scale,t);
    }
    public static void main(String[] args) {
        // System reservation policy; no screenshot-specific scaling or vertical correction.
        for (float scale : new float[]{.5f,.75f,1,1.5f,2,3}) {
            var t=CameraMorphGeometry.compactTopEstimate(new CameraMorphGeometry.Target(
                    508*scale,0,572*scale,91*scale),1080*scale,2400*scale,110*scale,3*scale);
            ok(t!=null,"narrow reservation supported");
            near(t.width(),64f*scale,.001f,"reservation width preserved (no screenshot calibration)");
            near(t.cx(),540*scale,.001f,"reported horizontal position preserved");
            near(t.cy(),59f*scale,.001f,"centre is bottom minus half reported width");
            var exact = new CameraMorphGeometry.Target(521.5f*scale,50*scale,558.5f*scale,87*scale);
            float first=-1, prevInk=0;
            float[] forward=new float[10001];
            for (int i=0;i<=10000;i++) {
                float p=i/10000f;
                var f=frame(p,exact,scale);
                var g=CameraMorphGeometry.goo(exact,f);
                float ink=CameraMorphGeometry.bodyBlack(f,g);
                ok(ink>=0 && ink<=1,"bounded material");
                if (g==null || g.u>=4.1f) near(ink,f.bottomBlack,.000001f,"no dimming outside proximity");
                if(g!=null && g.joined && first<0)first=p;
                ok(ink>=prevInk-.00001f,"no bright rebound during absorption");
                ok(Math.abs(ink-prevInk)<.003f,"no step in body ink");
                forward[i]=ink;prevInk=ink;
                if(g!=null && !g.joined)ok(g.ink!=null,"camera drop before connection");
            }
            // 6.69.9 admission gate delayed physical contact to about p=.393.
            // The new normal-camera contact is close to the geometric u=3.07 crossing.
            ok(first>.37f && first<.40f,"contact is early but not at scroll handoff: "+first);
            for(int i=10000;i>=0;i--) {
                var f=frame(i/10000f,exact,scale);
                near(CameraMorphGeometry.bodyBlack(f,CameraMorphGeometry.goo(exact,f)),forward[i],0,
                        "bit-identical reverse color");
            }
            var f=frame(.7f,exact,scale);
            ok(CameraMorphGeometry.bodyBlack(f,CameraMorphGeometry.goo(exact,f))>.12f,
                    "emerging body retains ink before final absorption");
            near(CameraMorphGeometry.bodyBlack(frame(0,null,scale),null),0,0,"no-camera expanded fallback");
        }
        near(CameraMorphGeometry.waist(CameraMorphGeometry.GOO_CONTACT),0,0,"zero-width birth");
        ok(CameraMorphGeometry.waist(3.01f) > 0f && CameraMorphGeometry.waist(3.01f) < .20f,
                "regularized neck birth, not the old subpixel snap");
        near(CameraMorphGeometry.waist(CameraMorphGeometry.GOO_FULL),2.62f,.000001f,"measured fully opened neck");
        near(CameraMorphGeometry.waist(-.5f),2.62f,.000001f,"smooth deep relaxation");
        var t=new CameraMorphGeometry.Target(-18.5f,-18.5f,18.5f,18.5f);
        var separate=new CameraMorphGeometry.Frame(0,18.5f+90+3.58f*18.5f,180,180,90,.65f,1,1,0,1);
        var g=CameraMorphGeometry.goo(t,separate);
        ok(g!=null && !g.joined,"reference pre-contact fixture");
        near(CameraMorphGeometry.bodyBlack(separate,g),.05f,.00001f,"ink survives reverse detachment");
        // Independent reverse-video samples, frames 860..1000 (sequential VFR decode).
        // Estimated opacity from normalized gamma-encoded luma of a lower-body ROI.
        // Four percentage points allow codec/fit/texture/blur error: these are NOT
        // calibrated photometric measurements or Android pixel assertions.
        float[][] reverseVideo = {
            {0.7691967f, 0.5445300f},
            {0.9369371f, 0.5337000f},
            {1.0244952f, 0.5025700f},
            {1.0917197f, 0.4946800f},
            {1.1348148f, 0.4800300f},
            {1.2568659f, 0.4688100f},
            {1.3379397f, 0.4541200f},
            {1.3626809f, 0.4426600f},
            {1.4486297f, 0.4186700f},
            {1.4857078f, 0.4029700f},
            {1.6034146f, 0.3909000f},
            {1.6595712f, 0.3873900f},
            {1.7356637f, 0.3634500f},
            {1.9098922f, 0.3469000f},
            {1.9152859f, 0.3253700f},
            {1.9817093f, 0.3229800f},
            {2.1681361f, 0.2999200f},
            {2.1933233f, 0.2868100f},
            {2.3224344f, 0.2712600f},
            {2.3829672f, 0.2447600f},
            {2.5147393f, 0.2285400f},
            {2.6147133f, 0.2132100f},
            {2.7649051f, 0.1871500f},
            {3.0068316f, 0.1528700f},
            {3.2350299f, 0.1245200f},
            {3.3873904f, 0.0792800f},
            {3.6149897f, 0.0559200f},
            {3.7689711f, 0.0250300f},
            {4.0083302f, 0.0015300f}
        };
        for (float[] sample : reverseVideo) {
            var f = new CameraMorphGeometry.Frame(0,18.5f+90+sample[0]*18.5f,
                180,180,90,.65f,1,1,0,1);
            near(CameraMorphGeometry.bodyBlack(f,CameraMorphGeometry.goo(t,f)),
                sample[1],.04f,"reverse-video residual dimming");
        }
        float last=0;
        for(int i=0;i<=10000;i++) {
            float u=CameraMorphGeometry.GOO_CONTACT-(CameraMorphGeometry.GOO_CONTACT+.5f)*i/10000f;
            float w=CameraMorphGeometry.waist(u);
            ok(w>=last-.00001f && w<=2.62001f,"bounded monotone opening");
            ok(w-last<.02f,"bounded measured waist derivative");last=w;
        }
        System.out.println("PASS: "+checks+" new 6.69.10 math assertions (not Android)");
    }
}
