package app.ziziplayer.ui;

import app.ziziplayer.ui.theme.ArtworkColorMath;
import app.ziziplayer.ui.theme.ArtworkSurfaceMath;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Executes production Java, including the shared sampler; fixtures are screenshot crops only. */
public final class ArtworkSurfaceMathChecks {
    private static void check(boolean b, String message) { if (!b) throw new AssertionError(message); }
    private static int channel(int c, int shift) { return (c >>> shift) & 255; }
    private static double contrast(int a, int b) {
        double x = ArtworkColorMath.luminance(a), y = ArtworkColorMath.luminance(b);
        return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
    }
    private static void near(int actual, int expected, int tolerance, String name) {
        for (int shift : new int[]{16, 8, 0}) check(Math.abs(channel(actual, shift) - channel(expected, shift)) <= tolerance,
            name + " actual=" + Integer.toHexString(actual) + " expected=" + Integer.toHexString(expected));
    }
    public static void runAll() {
        for (int r = 0; r < 256; r += 17) for (int g = 0; g < 256; g += 17) for (int b = 0; b < 256; b += 17) {
            int seed = 0xff000000 | (r << 16) | (g << 8) | b;
            int deep = ArtworkColorMath.mix(0xff000000, seed, .4f);
            int[] ramp = ArtworkSurfaceMath.playerBackdrop(seed, deep);
            check(Arrays.equals(ramp, ArtworkSurfaceMath.playerBackdrop(seed, deep)), "Determinism");
            check(ramp[6] == 0xff111111, "Player endpoint changed");
            check(ArtworkColorMath.luminance(ramp[0]) >= .0119, "Invisible blue top");
            double prev = ArtworkColorMath.luminance(ramp[0]);
            for (int segment = 0; segment < 6; segment++) for (int step = 0; step <= 32; step++) {
                int c = ArtworkColorMath.mix(ramp[segment], ramp[segment + 1], step / 32f);
                double lum = ArtworkColorMath.luminance(c);
                check(lum <= prev + .0008, "Nonmonotone ramp beyond 8-bit rounding: " + Integer.toHexString(seed));
                check(contrast(0xffe0e0e0, c) >= 4.5, "Player secondary contrast");
                check(contrast(0xfff6f7f8, c) >= 4.5, "Player primary contrast");
                prev = lum;
            }
            for (int c : new int[]{ArtworkSurfaceMath.miniPlayer(seed, deep), ArtworkSurfaceMath.collectionTop(seed), ArtworkSurfaceMath.chip(seed, deep)}) {
                check((c >>> 24) == 255, "Surface not opaque");
                check(contrast(0xffe0e0e0, c) >= 4.5, "Surface secondary contrast " + Integer.toHexString(seed));
                check(contrast(0xfff6f7f8, c) >= 4.5, "Surface primary contrast");
            }
        }
        for (int v = 0; v < 256; v++) {
            int grey = 0xff000000 | (v << 16) | (v << 8) | v;
            for (int c : new int[]{ArtworkSurfaceMath.playerTop(grey, 0xff550000), ArtworkSurfaceMath.miniPlayer(grey, 0xff000055), ArtworkSurfaceMath.collectionTop(grey)})
                check(channel(c, 16) == channel(c, 8) && channel(c, 8) == channel(c, 0), "Neutral invented a hue");
            check(ArtworkSurfaceMath.collectionTop(grey) == ArtworkColorMath.coverTop(grey), "Neutral collection regression");
        }
        int primary = 0xffcc2222;
        check(ArtworkSurfaceMath.miniPlayer(primary, 0xff000080) == ArtworkSurfaceMath.miniPlayer(primary, primary), "Rival hue voted");
        check(ArtworkSurfaceMath.playerTop(primary, 0xff000000) == ArtworkSurfaceMath.playerTop(primary, primary), "Black noise voted");
        check(ArtworkSurfaceMath.miniPlayer(0xff777674, 0xff414344) == 0xff2c2c2c, "JPEG neutral noise");
        // Adjacent channels near gates and red's circular seam must not cause a visible jump.
        for (int v = 32; v < 240; v += 13) for (int n = 0; n < 255; n++) {
            int a = 0xff000000 | (v << 16) | (n << 8) | 50, b = a + 256;
            near(ArtworkSurfaceMath.miniPlayer(a, a), ArtworkSurfaceMath.miniPlayer(b, b), 7, "Continuity");
        }
        near(ArtworkSurfaceMath.miniPlayer(0xffdd1112, 0xff661011), ArtworkSurfaceMath.miniPlayer(0xffdd1211, 0xff661110), 3, "Red seam");
    }
    private static void fixtures(String folder) throws Exception {
        String[] names = {"RAYA", "RAYA_REF", "PASSO", "PASSO_REF", "ABNORMAL", "ABNORMAL_REF"};
        int[] targets = {0xff380504, 0xff380504, 0xff14646f, 0xff14646f, 0xff292929, 0xff292929};
        for (int i = 0; i < names.length; i++) {
            byte[] raw = Files.readAllBytes(Path.of(folder, names[i] + ".argb"));
            int[] pixels = new int[4096]; ByteBuffer.wrap(raw).asIntBuffer().get(pixels);
            int[] sw = ArtworkColorMath.extract(pixels);
            int mini = ArtworkSurfaceMath.miniPlayer(sw[0], sw[2]);
            int player = ArtworkSurfaceMath.playerTop(sw[0], sw[2]);
            int collection = ArtworkSurfaceMath.collectionTop(sw[0]);
            near(mini, targets[i], 7, names[i] + " mini");
            if (i < 2) {
                near(player, 0xff4b0c0c, 6, "Raya player");
                near(collection, 0xffb91413, 9, "Raya collection top");
                check(ArtworkColorMath.luminance(player) < ArtworkColorMath.luminance(ArtworkColorMath.coverTop(sw[0])) * .35, "Raya still washed out");
            }
            if (i == 2 || i == 3) check(ArtworkColorMath.luminance(mini) > ArtworkColorMath.luminance(ArtworkColorMath.surface(sw[0])) * 5, "Cyan still crushed");
            System.out.printf("FIXTURE,%s,%08X,%08X,%08X,%08X,%08X%n",names[i],sw[0],sw[2],player,mini,collection);
        }
    }
    public static void main(String[] args) throws Exception {
        runAll(); if (args.length > 0) fixtures(args[0]);
        System.out.println("PASS: 4096 RGB seeds; 811008 ramp samples; role contrast >= 4.5:1; 256 neutrals; rival/noise rejection; continuity; reference tolerances.");
        System.out.println("Numerical source tests, not an Android build or device rendering test.");
    }
}
