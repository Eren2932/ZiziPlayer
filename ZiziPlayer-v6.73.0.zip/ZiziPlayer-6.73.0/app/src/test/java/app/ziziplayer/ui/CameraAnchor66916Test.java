package app.ziziplayer.ui;

import org.junit.Test;

public class CameraAnchor66916Test {
    @Test public void cameraCoreAndSystemReservation() { CameraAnchor66916Checks.main(new String[0]); }
}
