package app.ziziplayer.ui;

import java.util.ArrayList;
import java.util.Arrays;

/** Production geometry regression, not Android/Skia rendering or a frame-time benchmark. */
public final class CameraMorph66913Checks {
    private static int checks;
    private static void require(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    private static double[][] flatten(float[] path) {
        ArrayList<double[]> out = new ArrayList<>();
        double x=0, y=0;
        for (int i=0; i<path.length;) {
            int op=(int)path[i++];
            if (op==0) { x=path[i++]; y=path[i++]; out.add(new double[]{x,y}); }
            else if (op==1) {
                double x1=path[i++], y1=path[i++], x2=path[i++], y2=path[i++];
                double x3=path[i++], y3=path[i++];
                for (int j=1; j<=32; j++) {
                    double t=j/32., a=1-t;
                    out.add(new double[]{a*a*a*x+3*a*a*t*x1+3*a*t*t*x2+t*t*t*x3,
                        a*a*a*y+3*a*a*t*y1+3*a*t*t*y2+t*t*t*y3});
                }
                x=x3; y=y3;
            }
        }
        return out.toArray(new double[0][]);
    }
    private static double directedDistance(double[][] a, double[][] b) {
        double max=0;
        for (double[] p:a) {
            double min=Double.POSITIVE_INFINITY;
            for (int i=1; i<b.length; i++) {
                double x=b[i-1][0], y=b[i-1][1], dx=b[i][0]-x, dy=b[i][1]-y;
                double t=Math.max(0,Math.min(1,((p[0]-x)*dx+(p[1]-y)*dy)/(dx*dx+dy*dy+1e-30)));
                double xx=p[0]-x-t*dx, yy=p[1]-y-t*dy;
                min=Math.min(min,xx*xx+yy*yy);
            }
            max=Math.max(max,min);
        }
        return Math.sqrt(max);
    }
    private static double widthAt(double[][] outline, double y) {
        double result=0;
        for (int i=1; i<outline.length; i++) {
            double[] a=outline[i-1], b=outline[i];
            if (y<Math.min(a[1],b[1]) || y>Math.max(a[1],b[1]) || Math.abs(b[1]-a[1])<1e-10) continue;
            result=Math.max(result,Math.abs(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1])));
        }
        return result;
    }
    private static CameraMorphGeometry.Frame frame(float scroll,float scale,CameraMorphGeometry.Target t) {
        return CameraMorphGeometry.frame(716*scale,315.04f*scale,1,scroll,
            540*scale,164*scale,8*scale,369.04f*scale,110*scale,t);
    }
    private static void shoulders() {
        for (float unit:new float[]{5,18.5f,48}) for (float ratio:new float[]{1.2f,2,4,8}) {
            var target=new CameraMorphGeometry.Target(-unit,-unit,unit,unit);
            double[] previous=new double[3];
            for (int step=0; step<=310; step++) {
                float u=CameraMorphGeometry.GOO_CONTACT-.00001f-step*.002f;
                float r=ratio*unit, d=unit+u*unit+r;
                var f=new CameraMorphGeometry.Frame(0,d,2*r,2*r,r,.5f,1,1,0,1);
                var g=CameraMorphGeometry.goo(target,f);
                require(g!=null && g.joined && g.ink!=null,"joined fixture");
                var contour=flatten(g.ink);
                double sw=unit+CameraMorphGeometry.CAMERA_SHARE*u*unit;
                for (int lane=0;lane<3;lane++) {
                    double width=widthAt(contour,sw*(.25+.20*lane));
                    if (step>0) require(width>=previous[lane]-.0001*unit,
                        "shoulder retracts during opening: u="+u+" delta/U="+(width-previous[lane])/unit);
                    previous[lane]=width;
                }
            }
        }
    }
    private static void interiorExtensionAndHold() {
        for (float scale:new float[]{.5f,1,2}) for (float cx:new float[]{108,540,972}) {
            var t=new CameraMorphGeometry.Target((cx-18.5f)*scale,50*scale,(cx+18.5f)*scale,87*scale);
            for (int step=130;step<990;step+=3) {
                float scroll=step*.001f*369.04f*scale;
                var f=frame(scroll,scale,t); var g=CameraMorphGeometry.goo(t,f);
                if (g==null) continue;
                for (int repeat=0;repeat<3;repeat++) {
                    CameraMorphGeometry.goo(t,frame(scroll+(repeat-1)*.25f,scale,t));
                    var same=CameraMorphGeometry.goo(t,frame(scroll,scale,t));
                    require(Arrays.equals(g.ink,same.ink) && Arrays.equals(g.flesh,same.flesh),
                        "hold/reversal must be history independent");
                }
                if (!g.joined || g.flesh==null) continue;
                double d=Math.hypot(f.cx-t.cx(),f.cy-t.cy());
                for (double[] point:flatten(g.flesh)) {
                    double s=(point[0]-t.cx())*g.axisX+(point[1]-t.cy())*g.axisY;
                    require(s<=d+.002*scale,"extension duplicates the rear artwork boundary");
                }
            }
        }
    }
    private static void contactLimits() {
        for (float unit:new float[]{5,18.5f,48}) for (float ratio:new float[]{1.2f,2,4,8}) {
            var t=new CameraMorphGeometry.Target(-unit,-unit,unit,unit);
            float r=unit*ratio;
            float beforeU=CameraMorphGeometry.GOO_CONTACT+.00001f;
            float afterU=CameraMorphGeometry.GOO_CONTACT-.00001f;
            var before=CameraMorphGeometry.goo(t,new CameraMorphGeometry.Frame(0,unit+beforeU*unit+r,2*r,2*r,r,.5f,1,1,0,1));
            var after=CameraMorphGeometry.goo(t,new CameraMorphGeometry.Frame(0,unit+afterU*unit+r,2*r,2*r,r,.5f,1,1,0,1));
            require(!before.joined && after.joined,"must straddle actual topology switch");
            var camera=flatten(before.ink); var tent=flatten(before.flesh); var joined=flatten(after.ink);
            for(int row=0;row<180;row++) {
                double y=-unit+(2+CameraMorphGeometry.GOO_CONTACT)*unit*row/180.;
                double a=Math.max(widthAt(camera,y),widthAt(tent,y));
                double b=widthAt(joined,y);
                // Probe above the unextended body, where the detached union is
                // exactly camera + tent. The body itself is unchanged by topology.
                if(y<unit+afterU*unit-.01*unit)
                    require(Math.abs(a-b)<.012*unit,"contact silhouette has a finite jump");
            }
        }
    }
    private static void boundarySpeed() {
        double maximum=0;
        for (float scale:new float[]{.5f,1,2}) {
            var t=new CameraMorphGeometry.Target(521.5f*scale,50*scale,558.5f*scale,87*scale);
            double[][] previous=null;
            for (int step=375;step<=465;step++) {
                float p=step*.001f;
                var g=CameraMorphGeometry.goo(t,frame(p*369.04f*scale,scale,t));
                if(g==null || !g.joined || g.u<CameraMorphGeometry.GOO_FULL) {previous=null;continue;}
                var outline=flatten(g.ink);
                if(previous!=null) {
                    double speed=Math.max(directedDistance(previous,outline),directedDistance(outline,previous))/(.36904*scale);
                    require(speed<2.2,"full contour amplifies scroll: "+speed);
                    maximum=Math.max(maximum,speed);
                }
                previous=outline;
            }
        }
        System.out.printf("Full-outline sampled Hausdorff speed: %.6f px / scroll px (central fixture)%n",maximum);
    }
    public static void main(String[] args) {
        shoulders(); boundarySpeed(); interiorExtensionAndHold(); contactLimits();
        System.out.println("PASS: "+checks+" contact-contour assertions (pure JVM, not Android)");
    }
}
