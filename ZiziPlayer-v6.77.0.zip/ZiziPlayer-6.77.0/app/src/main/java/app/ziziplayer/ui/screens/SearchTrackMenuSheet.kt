package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.material3.rememberStandardBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.SearchResultGeometry
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.RemoteArtwork
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

internal data class SearchTrackAction(val id: String, val label: String, val icon: ImageVector, val run: () -> Unit)

/** A modal host around Material's anchored/nested-scroll sheet, not a hand-written drag detector.
 * Unlike ModalBottomSheet's fixed 50% anchor, this scaffold supports the measured 60% peek.
 * Header remains pinned; scrolling actions expands first and scrolls at the upper anchor.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SearchTrackMenuSheet(
    track: RemoteTrack,
    actions: List<SearchTrackAction>,
    onDismiss: () -> Unit,
    status: String? = null,
    onRetry: (() -> Unit)? = null
) {
    val state = rememberStandardBottomSheetState(initialValue = SheetValue.Hidden, skipHiddenState = false)
    val scaffold = rememberBottomSheetScaffoldState(bottomSheetState = state)
    val scope = rememberCoroutineScope()
    var appeared by remember { mutableStateOf(false) }
    var exiting by remember { mutableStateOf(false) }
    var dispatched by remember { mutableStateOf(false) }
    val finish: (() -> Unit) -> Unit = { action ->
        if (!dispatched) { dispatched = true; onDismiss(); action() }
    }
    val exit: (() -> Unit) -> Unit = { action ->
        if (!exiting && !dispatched) {
            exiting = true
            scope.launch {
                try { state.hide(); finish(action) }
                finally { exiting = false }
            }
        }
    }
    LaunchedEffect(state) {
        snapshotFlow { state.hasPartiallyExpandedState }.first { it }
        state.partialExpand()
        appeared = true
    }
    LaunchedEffect(state.currentValue, appeared) {
        if (appeared && state.currentValue == SheetValue.Hidden && !exiting) finish { }
    }
    Dialog(onDismissRequest = { exit { } }, properties = DialogProperties(
        usePlatformDefaultWidth = false, decorFitsSystemWindows = false
    )) {
        BoxWithConstraints(Modifier.fillMaxSize().testTag("search-track-menu-host")) {
            val top = maxOf(WindowInsets.statusBars.asPaddingValues().calculateTopPadding(),
                maxHeight * SearchResultGeometry.MENU_TOP_FRACTION)
            val expandedHeight = maxHeight - top
            val peek = (maxHeight * SearchResultGeometry.MENU_PEEK_FRACTION).coerceAtMost(expandedHeight)
            val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            BottomSheetScaffold(
                scaffoldState = scaffold,
                sheetPeekHeight = peek,
                sheetMaxWidth = Dp.Unspecified,
                containerColor = Color.Transparent,
                sheetContainerColor = Color(0xFF1F1F1F),
                sheetContentColor = Color.White,
                sheetShape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                sheetShadowElevation = 0.dp,
                sheetTonalElevation = 0.dp,
                // Explicit handle in sheetContent makes the total height include the handle.
                sheetDragHandle = null,
                sheetContent = {
                    Column(Modifier.fillMaxWidth().height(expandedHeight).testTag("search-track-menu")) {
                        Box(Modifier.fillMaxWidth().height(28.dp).testTag("search-track-menu-handle"),
                            contentAlignment = Alignment.Center) {
                            Box(Modifier.size(36.dp, 4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF777777)))
                        }
                        Row(Modifier.fillMaxWidth().heightIn(min = 72.dp)
                            .padding(horizontal = 16.5.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RemoteArtwork(track.artworkUrl, track.trackId, maxPx = ARTWORK_ROW_PX,
                                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(3.dp)), glyphSize = 20)
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(track.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(track.artist, color = Color(0xFFB3B3B3), fontSize = 14.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        HorizontalDivider(color = Color(0xFF3E3E3E), thickness = 1.dp)
                        LazyColumn(Modifier.fillMaxWidth().weight(1f).testTag("search-track-menu-actions"),
                            contentPadding = PaddingValues(bottom = bottom + 12.dp)) {
                            if (status != null) item("status") {
                                Column(Modifier.padding(16.dp)) {
                                    Text(status, color = Color(0xFFB3B3B3))
                                    onRetry?.let { retry -> TextButton(onClick = retry) { Text("Повторить") } }
                                }
                            }
                            items(actions, key = { it.id }) { action ->
                                Row(Modifier.fillMaxWidth().heightIn(min = SearchResultGeometry.MENU_ROW_DP.dp)
                                    .clickable(enabled = !exiting, role = Role.Button) { exit(action.run) }
                                    .padding(horizontal = 16.5.dp, vertical = 12.dp)
                                    .testTag("search-track-action-${action.id}"), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(action.icon, contentDescription = null, tint = Color(0xFFB3B3B3), modifier = Modifier.size(24.dp))
                                    Spacer(Modifier.width(13.dp))
                                    Text(action.label, color = Color.White, fontSize = 17.sp,
                                        fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            ) {
                // Dialog supplies dimming; this surface only owns outside taps, no second scrim.
                Box(Modifier.fillMaxSize().clickable(enabled = !exiting, onClickLabel = "Закрыть меню трека") {
                    exit { }
                })
            }
        }
    }
}
