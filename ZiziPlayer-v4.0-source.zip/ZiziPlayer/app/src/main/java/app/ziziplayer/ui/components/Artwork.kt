package app.ziziplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections

/**
 * Artwork pipeline, rebuilt for scrolling performance.
 *
 * The v3 version called MediaMetadataRetriever for every visible row: opening and parsing an
 * audio file costs 20-120 ms, so a 450 track list could not scroll at 60 fps no matter what
 * else was optimised. Now the order is:
 *
 *  1. in-memory LruCache            (instant)
 *  2. MediaStore album art uri      (already decoded by the system, cheap)
 *  3. ContentResolver.loadThumbnail (API 29+, disk cached by MediaProvider)
 *  4. MediaMetadataRetriever        (slow path, allowed only while the list is idle)
 *
 * "This track has no art" is remembered in memory and persisted, so the slow path is never
 * repeated for the same file.
 */
object ArtworkCache {
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceIn(6 * 1024, 64 * 1024)
    private val cache = object : LruCache<String, Bitmap>(maxKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val seeds = LruCache<String, Int>(512)
    private val empty = Collections.synchronizedSet(HashSet<String>())
    private val gate = Semaphore(2)
    private val slowGate = Semaphore(1)

    @Volatile private var busyUntilMs = 0L
    @Volatile private var memory: ArtworkMemory? = null

    private fun key(id: String, maxPx: Int) = "$id@$maxPx"

    fun attachMemory(context: Context) {
        if (memory != null) return
        val store = ArtworkMemory(context)
        memory = store
        empty.addAll(store.load())
    }

    /** Called by scrollable lists: while the finger is moving no slow decode is started. */
    fun markBusy() { busyUntilMs = System.currentTimeMillis() + 220 }
    private fun busy() = System.currentTimeMillis() < busyUntilMs

    fun peek(track: TrackEntity?, maxPx: Int): Bitmap? {
        val id = track?.id ?: return null
        return cache.get(key(id, maxPx))
    }

    fun peekSeed(track: TrackEntity?): Color? {
        val id = track?.id ?: return null
        return seeds.get(id)?.let { Color(it) }
    }

    fun putSeed(track: TrackEntity, color: Color) { seeds.put(track.id, color.toArgb()) }

    fun hasNoArt(track: TrackEntity?): Boolean = track != null && empty.contains(track.id)

    suspend fun load(context: Context, track: TrackEntity, maxPx: Int, allowSlow: Boolean): Bitmap? {
        val cacheKey = key(track.id, maxPx)
        cache.get(cacheKey)?.let { return it }
        if (empty.contains(track.id)) return null
        // A smaller variant already decoded? Reuse it instead of touching storage again.
        if (maxPx > ARTWORK_ROW_PX) cache.get(key(track.id, ARTWORK_ROW_PX))?.let { small ->
            if (small.width >= maxPx / 2) return small
        }
        // Fast path first, under a small concurrency gate.
        val fast = gate.withPermit {
            cache.get(cacheKey) ?: withContext(Dispatchers.IO) {
                fromArtworkUri(context, track, maxPx) ?: fromThumbnail(context, track, maxPx)
            }
        }
        if (fast != null) { cache.put(cacheKey, fast); return fast }
        if (!allowSlow) return null

        // Slow path lives outside the gate so it can never block cheap decodes.
        val slow = fromEmbedded(context, track, maxPx)
        if (slow != null) cache.put(cacheKey, slow) else { empty.add(track.id); memory?.remember(track.id) }
        return slow
    }

    private fun fromArtworkUri(context: Context, track: TrackEntity, maxPx: Int): Bitmap? {
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { stream ->
                decode(stream.readBytes(), maxPx)
            }
        }.getOrNull()
    }

    private fun fromThumbnail(context: Context, track: TrackEntity, maxPx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            context.contentResolver.loadThumbnail(Uri.parse(track.uri), Size(maxPx, maxPx), null)
        }.getOrNull()
    }

    /** The expensive one: never runs while a list is being scrolled, and only one at a time. */
    private suspend fun fromEmbedded(context: Context, track: TrackEntity, maxPx: Int): Bitmap? =
        slowGate.withPermit {
            var guard = 0
            while (busy() && guard < 40) { delay(60); guard++ }
            val bytes = runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, Uri.parse(track.uri))
                    retriever.embeddedPicture
                } finally {
                    runCatching { retriever.release() }
                }
            }.getOrNull() ?: return@withPermit null
            decode(bytes, maxPx)
        }

    private fun decode(bytes: ByteArray, maxPx: Int): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        while (largest / (sample * 2) >= maxPx) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

/** Persists the "no cover art" verdict so the slow probe happens once per file, ever. */
private class ArtworkMemory(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("zizi_artwork", Context.MODE_PRIVATE)
    private val pending = Collections.synchronizedSet(HashSet<String>())

    fun load(): Set<String> = prefs.getStringSet(KEY, emptySet()) ?: emptySet()

    fun remember(id: String) {
        pending.add(id)
        if (pending.size < 12) return
        flush()
    }

    private fun flush() {
        val snapshot = synchronized(pending) { HashSet(pending).also { pending.clear() } }
        if (snapshot.isEmpty()) return
        val merged = HashSet(load()); merged.addAll(snapshot)
        prefs.edit().putStringSet(KEY, merged).apply()
    }

    companion object { private const val KEY = "no_art_ids" }
}

const val ARTWORK_ROW_PX = 160
const val ARTWORK_FULL_PX = 640

@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int, allowSlow: Boolean = true): Bitmap? {
    val context = LocalContext.current
    val state = produceState<Bitmap?>(ArtworkCache.peek(track, maxPx), track?.id, maxPx, allowSlow) {
        val target = track
        if (target == null) { value = null; return@produceState }
        if (value == null) value = ArtworkCache.load(context, target, maxPx, allowSlow)
    }
    return state.value
}

/** Stable pleasant colour pair for tracks that simply have no cover art. */
private val fallbackHues = listOf(
    Color(0xFF6C7BFF) to Color(0xFF2B2FA8),
    Color(0xFFFF7A9A) to Color(0xFF9C1F4B),
    Color(0xFF4ED8C0) to Color(0xFF126E7A),
    Color(0xFFFFB169) to Color(0xFFA84E14),
    Color(0xFFB98BFF) to Color(0xFF5B2C9E),
    Color(0xFF7ED0FF) to Color(0xFF1B5C9B),
    Color(0xFFFFD36B) to Color(0xFF9A6C10),
    Color(0xFF8CE07A) to Color(0xFF2C7A32)
)

fun fallbackColors(track: TrackEntity?): Pair<Color, Color> {
    val seedText = ((track?.title ?: "zizi") + (track?.artist ?: "")).lowercase()
    var hash = 7
    for (char in seedText) hash = hash * 31 + char.code
    val index = ((hash % fallbackHues.size) + fallbackHues.size) % fallbackHues.size
    return fallbackHues[index]
}

/** Colour that drives the whole UI tint for the given track. Computed once per track, then cached. */
@Composable
fun rememberArtworkSeed(track: TrackEntity?, enabled: Boolean): Color? {
    val bitmap = rememberArtwork(track, ARTWORK_ROW_PX)
    val fallback = remember(track?.id) { fallbackColors(track).first }
    val cached = ArtworkCache.peekSeed(track)
    val extracted by produceState<Color?>(cached, bitmap, track?.id, enabled) {
        val source = bitmap
        val target = track
        if (!enabled || source == null || target == null) return@produceState
        ArtworkCache.peekSeed(target)?.let { value = it; return@produceState }
        val color = withContext(Dispatchers.Default) {
            runCatching {
                val palette = Palette.from(source).maximumColorCount(16).resizeBitmapArea(64 * 64).generate()
                val rgb = palette.vibrantSwatch?.rgb
                    ?: palette.lightVibrantSwatch?.rgb
                    ?: palette.darkVibrantSwatch?.rgb
                    ?: palette.mutedSwatch?.rgb
                    ?: palette.dominantSwatch?.rgb
                rgb?.let { Color(it) }
            }.getOrNull()
        }
        if (color != null) { ArtworkCache.putSeed(target, color); value = color }
    }
    if (!enabled) return null
    return extracted ?: if (track != null && (bitmap == null || ArtworkCache.hasNoArt(track))) fallback else null
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44,
    allowSlow: Boolean = true
) {
    val bitmap = rememberArtwork(track, maxPx, allowSlow)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val colors = remember(track?.id) { fallbackColors(track) }
            Canvas(Modifier.fillMaxSize()) {
                drawRect(
                    Brush.linearGradient(
                        listOf(colors.first, colors.second),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height)
                    )
                )
            }
            Text(
                text = "\u266A",
                color = Color.White.copy(alpha = 0.82f),
                fontSize = glyphSize.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
