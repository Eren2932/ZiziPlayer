package app.ziziplayer.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TrackEntity::class,
        FavoriteEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class,
        TrackFxEntity::class,
        HiddenEntity::class,
        PlayStatEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ZiziDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        /** Adds the new tables without touching favourites, playlists or saved FX. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `hidden` (`trackId` TEXT NOT NULL, `hiddenAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `play_stats` (`trackId` TEXT NOT NULL, `playCount` INTEGER NOT NULL, `lastPlayedAt` INTEGER NOT NULL, PRIMARY KEY(`trackId`))")
            }
        }
    }
}
