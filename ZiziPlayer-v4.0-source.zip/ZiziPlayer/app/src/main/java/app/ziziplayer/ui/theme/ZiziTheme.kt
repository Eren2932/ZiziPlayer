package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import app.ziziplayer.data.AppTheme
import kotlinx.coroutines.launch

data class ZiziPalette(
    val top: Color,
    val middle: Color,
    val bottom: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    val tintStrength: Float
) {
    val background: Brush
        get() = Brush.verticalGradient(
            0f to top,
            0.42f to middle,
            0.82f to bottom,
            1f to bottom
        )
}

private val Graphite = ZiziPalette(
    top = Color(0xFF2B2D31),
    middle = Color(0xFF16181B),
    bottom = Color(0xFF07080A),
    surface = Color(0xFF1D1F23),
    chip = Color(0xFF303338),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF8FD3FF),
    onAccent = Color(0xFF06121A),
    tintStrength = 1f
)

private val Midnight = Graphite.copy(
    top = Color(0xFF1C2540),
    middle = Color(0xFF101728),
    bottom = Color(0xFF05070C),
    surface = Color(0xFF161E33),
    chip = Color(0xFF243154),
    accent = Color(0xFF9EB8FF),
    tintStrength = 0.9f
)

private val Amoled = Graphite.copy(
    top = Color(0xFF141414),
    middle = Color(0xFF090909),
    bottom = Color(0xFF000000),
    surface = Color(0xFF121212),
    chip = Color(0xFF1F1F1F),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000),
    tintStrength = 0.4f
)

private val Sunset = Graphite.copy(
    top = Color(0xFF3A2028),
    middle = Color(0xFF20131A),
    bottom = Color(0xFF0A0507),
    surface = Color(0xFF291921),
    chip = Color(0xFF43262F),
    accent = Color(0xFFFFA36B),
    onAccent = Color(0xFF25100A),
    tintStrength = 1f
)

fun basePalette(theme: AppTheme): ZiziPalette = when (theme) {
    AppTheme.GRAPHITE -> Graphite
    AppTheme.MIDNIGHT -> Midnight
    AppTheme.AMOLED -> Amoled
    AppTheme.SUNSET -> Sunset
}

val LocalPalette = compositionLocalOf { Graphite }

/** Re-maps a colour onto a target brightness while keeping its hue. */
private fun Color.shade(saturationScale: Float, value: Float, saturationCap: Float = 0.92f): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(this.toArgb(), hsv)
    hsv[1] = (hsv[1] * saturationScale).coerceIn(0f, saturationCap)
    hsv[2] = value.coerceIn(0f, 1f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/**
 * Blends the artwork colour into the palette the way VK does it: strong at the top,
 * fading into near-black at the bottom of the screen.
 */
fun ZiziPalette.tintedWith(seed: Color?): ZiziPalette {
    val strength = tintStrength
    if (seed == null || strength <= 0.01f) return this
    return copy(
        top = lerp(top, seed.shade(1.05f, 0.42f), 0.92f * strength),
        middle = lerp(middle, seed.shade(1f, 0.19f), 0.86f * strength),
        bottom = lerp(bottom, seed.shade(0.85f, 0.07f), 0.62f * strength),
        surface = lerp(surface, seed.shade(0.95f, 0.30f), 0.80f * strength),
        chip = lerp(chip, seed.shade(0.80f, 0.34f), 0.78f * strength),
        subtext = lerp(subtext, seed.shade(0.30f, 0.80f), 0.55f * strength),
        text = lerp(text, seed.shade(0.10f, 0.99f), 0.35f * strength)
    )
}

fun ZiziPalette.withAccent(seed: Color?): ZiziPalette {
    if (seed == null) return this
    val bright = seed.shade(0.92f, 0.94f)
    val dark = bright.luminance() > 0.55f
    return copy(accent = bright, onAccent = if (dark) Color(0xFF0B0B0C) else Color.White)
}

private fun Color.luminance(): Float = 0.299f * red + 0.587f * green + 0.114f * blue

/**
 * Track changes used to animate nine colours inside a CompositionLocal, which rebuilt the
 * palette object on every animation frame and therefore recomposed the ENTIRE tree ~60 times
 * per second for half a second. Now the gradient is animated in the draw phase only: the
 * Animatable values are read inside drawBehind, so a colour change costs a repaint, never a
 * recomposition.
 */
@Composable
fun ZiziBackdrop(palette: ZiziPalette, modifier: Modifier = Modifier, durationMs: Int = 420) {
    val top = remember { Animatable(palette.top) }
    val middle = remember { Animatable(palette.middle) }
    val bottom = remember { Animatable(palette.bottom) }
    LaunchedEffect(palette.top, palette.middle, palette.bottom) {
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(palette.top, spec) }
        launch { middle.animateTo(palette.middle, spec) }
        launch { bottom.animateTo(palette.bottom, spec) }
    }
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to top.value,
                        0.42f to middle.value,
                        0.82f to bottom.value,
                        1f to bottom.value
                    )
                )
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = Typography(),
        content = content
    )
}
