package app.ziziplayer.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.session.SessionCommand
import app.ziziplayer.data.TrackEntity
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Structural playback state. Deliberately WITHOUT position:
 * position changes 2-4 times per second and would invalidate every consumer of this state.
 * Position lives in [PlayerController.progress] so that only the seek bar reacts to it.
 */
data class PlaybackState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentIndex: Int = 0,
    val currentTrackId: String? = null,
    val queueIds: List<String> = emptyList(),
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val sleepMinutesLeft: Int? = null
)

/** Position stream, updated only while playing and only while the UI is on screen. */
data class Progress(val positionMs: Long = 0L, val durationMs: Long = 0L)

@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingQueue: PendingQueue? = null
    private var sleepJob: Job? = null
    private var tickerJob: Job? = null
    private var sleepEndAtMs: Long? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress

    /** Cached queue ids: rebuilt only when the timeline actually changes, never on every tick. */
    private var cachedQueueIds: List<String> = emptyList()
    private var uiActive = false
    private var queueEpoch = 0

    private data class PendingQueue(val tracks: List<TrackEntity>, val index: Int, val play: Boolean, val positionMs: Long)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_TIMELINE_CHANGED)) invalidateQueue()
            publish()
            if (events.contains(Player.EVENT_POSITION_DISCONTINUITY) ||
                events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                events.contains(Player.EVENT_IS_PLAYING_CHANGED) ||
                events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED)
            ) publishProgress()
            syncTicker()
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync().also { f ->
            f.addListener({
                runCatching { f.get() }.onSuccess { c ->
                    controller = c
                    c.addListener(listener)
                    pendingQueue?.also { q -> pendingQueue = null; setQueue(q.tracks, q.index, q.play, q.positionMs) }
                    invalidateQueue(); publish(); publishProgress(); syncTicker()
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }

    /** Called from the Activity lifecycle: no polling at all while the UI is not visible. */
    fun setUiActive(active: Boolean) {
        if (uiActive == active) return
        uiActive = active
        if (active) { publish(); publishProgress() }
        syncTicker()
    }

    private fun syncTicker() {
        val shouldTick = uiActive && _state.value.isPlaying
        if (shouldTick) {
            if (tickerJob?.isActive == true) return
            tickerJob = scope.launch {
                while (isActive) { delay(500); publishProgress(); publishSleep() }
            }
        } else {
            tickerJob?.cancel(); tickerJob = null
        }
    }

    private fun invalidateQueue() {
        val p = controller ?: return
        cachedQueueIds = ArrayList<String>(p.mediaItemCount).apply {
            for (i in 0 until p.mediaItemCount) add(p.getMediaItemAt(i).mediaId)
        }
    }

    private fun publish() {
        val p = controller ?: return
        // playWhenReady instead of isPlaying: the icon must not flicker while the player buffers after a seek
        val playing = p.playWhenReady && p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        val next = PlaybackState(
            connected = true,
            isPlaying = playing,
            currentIndex = p.currentMediaItemIndex.coerceAtLeast(0),
            currentTrackId = p.currentMediaItem?.mediaId,
            queueIds = cachedQueueIds,
            shuffle = p.shuffleModeEnabled,
            repeatMode = p.repeatMode,
            sleepMinutesLeft = minutesLeft()
        )
        if (next != _state.value) _state.value = next
    }

    private fun publishProgress() {
        val p = controller ?: return
        val next = Progress(p.currentPosition.coerceAtLeast(0), p.duration.coerceAtLeast(0))
        if (next != _progress.value) _progress.value = next
    }

    private fun publishSleep() {
        val left = minutesLeft()
        if (left != _state.value.sleepMinutesLeft) _state.value = _state.value.copy(sleepMinutesLeft = left)
    }

    private fun minutesLeft(): Int? = sleepEndAtMs?.let { end ->
        val left = end - System.currentTimeMillis()
        if (left <= 0) null else ((left + 59_999) / 60_000).toInt()
    }

    /**
     * Building 450 MediaItems takes tens of milliseconds, which used to be spent on the main
     * thread right after a tap - that is exactly the "button feels slow" symptom. The list is
     * now built on a background dispatcher and only handed to the controller on the main thread.
     */
    fun setQueue(tracks: List<TrackEntity>, startIndex: Int, play: Boolean = true, startPositionMs: Long = 0L) {
        if (tracks.isEmpty()) return
        val p = controller ?: run { pendingQueue = PendingQueue(tracks, startIndex, play, startPositionMs); return }
        val epoch = ++queueEpoch
        scope.launch {
            val items = withContext(Dispatchers.Default) {
                tracks.map { t ->
                    MediaItem.Builder().setMediaId(t.id).setUri(t.uri).setMediaMetadata(
                        MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                            .setArtworkUri(t.artworkUri?.let(Uri::parse)).build()
                    ).build()
                }
            }
            if (epoch != queueEpoch) return@launch
            p.setMediaItems(items, startIndex.coerceIn(items.indices), startPositionMs.coerceAtLeast(0))
            p.prepare(); if (play) p.play()
            invalidateQueue(); publish(); publishProgress(); syncTicker()
        }
    }

    /** Used when a track is removed from the library: it must leave the running queue too. */
    fun removeFromQueue(trackId: String) {
        val p = controller ?: return
        val index = cachedQueueIds.indexOf(trackId)
        if (index < 0) return
        if (p.mediaItemCount <= 1) { p.pause(); p.clearMediaItems() } else p.removeMediaItem(index)
        invalidateQueue(); publish(); publishProgress()
    }

    fun playPause() { controller?.let { if (it.playWhenReady) it.pause() else it.play() }; publish(); syncTicker() }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs.coerceAtLeast(0)); publishProgress() }
    fun seekToIndex(index: Int) { controller?.seekToDefaultPosition(index); publish(); publishProgress() }
    fun next() { controller?.seekToNextMediaItem(); publish(); publishProgress() }
    fun previous() {
        val p = controller ?: return
        // Standard behaviour: restart the track if we are past 3 seconds, otherwise go back
        if (p.currentPosition > 3000) p.seekTo(0) else p.seekToPreviousMediaItem()
        publish(); publishProgress()
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; publish() }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
        publish()
    }
    fun setPlayback(speed: Float, pitch: Float, reverb: Int = 0) {
        controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_REVERB, Bundle.EMPTY), Bundle().apply { putInt("percent", reverb) })
    }
    fun setSkipSilence(enabled: Boolean) {
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_SKIP_SILENCE, Bundle.EMPTY), Bundle().apply { putBoolean("enabled", enabled) })
    }
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel(); sleepJob = null
        if (minutes == null || minutes <= 0) { sleepEndAtMs = null; publishSleep(); return }
        sleepEndAtMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause(); sleepEndAtMs = null; publish(); publishSleep()
        }
        publishSleep()
    }
    fun release() {
        sleepJob?.cancel(); tickerJob?.cancel()
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        scope.cancel()
    }
}
