package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.FolderInfo
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalPalette

private val rowShape = RoundedCornerShape(13.dp)

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onOpenPlayer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    var menuTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var renamePlaylistId by remember { mutableStateOf<Long?>(null) }

    val listState = rememberLazyListState()
    // While the finger is moving, no expensive artwork probe is allowed to start.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemScrollOffset to listState.firstVisibleItemIndex }
            .collect { ArtworkCache.markBusy() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        LibraryHeader(
            state = state,
            onSearch = { vm.setSearchOpen(!state.searchOpen) },
            onQuery = vm::setQuery,
            onShuffle = vm::shuffleAll,
            onSettings = { showSettings = true },
            onBack = { vm.handleBack() }
        )

        if (!state.isDrilledIn) {
            FilterRow(state.filter) { vm.setFilter(it) }
            Spacer(Modifier.height(4.dp))
        }

        Box(Modifier.weight(1f)) {
            when {
                state.loading -> CenterNote("Загружаем библиотеку…")
                state.filter == LibraryFilter.PLAYLISTS && state.openPlaylist == null ->
                    PlaylistList(
                        state = state,
                        onOpen = vm::openPlaylist,
                        onRename = { renamePlaylistId = it },
                        onDelete = vm::deletePlaylist,
                        onCreate = { vm.createPlaylist(it) }
                    )
                state.filter == LibraryFilter.FOLDERS && state.openFolder == null ->
                    FolderList(
                        folders = state.folders,
                        settingsFolders = remember(state.settings.folderUris) { state.settings.folderUris.toList() },
                        onOpen = vm::openFolder,
                        onAdd = onPickFolder,
                        onRemove = vm::removeFolder
                    )
                state.visible.isEmpty() -> CenterNote(
                    when {
                        state.query.isNotBlank() -> "Ничего не найдено"
                        state.filter == LibraryFilter.FAVORITES -> "Пока нет избранных треков"
                        else -> "Треков нет. Добавь папку через «Папки»"
                    }
                )
                else -> TrackList(
                    listState = listState,
                    tracks = state.visible,
                    favoriteIds = state.favoriteIds,
                    currentTrackId = playback.currentTrackId,
                    isPlaying = playback.isPlaying,
                    hasMiniPlayer = currentTrack != null,
                    onPlay = { track -> vm.play(track, state.visible) },
                    onFavorite = vm::toggleFavorite,
                    onMenu = { menuTrack = it }
                )
            }

            if (state.scanning) ScanningBadge(Modifier.align(Alignment.TopCenter))
        }

        if (currentTrack != null) {
            MiniPlayer(
                vm = vm,
                track = currentTrack,
                isPlaying = playback.isPlaying,
                onOpen = onOpenPlayer
            )
        }
        Spacer(Modifier.navigationBarsPadding())
    }

    menuTrack?.let { track ->
        TrackMenuSheet(
            favorite = state.favoriteIds.contains(track.id),
            plays = 0,
            sleepMinutesLeft = playback.sleepMinutesLeft,
            track = track,
            inPlaylist = state.openPlaylist,
            onDismiss = { menuTrack = null },
            onFx = { menuTrack = null; vm.play(track, state.visible); onOpenPlayer() },
            onSleep = { menuTrack = null },
            onAddToPlaylist = { menuTrack = null; playlistTarget = track },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                menuTrack = null
            },
            onToggleFavorite = { vm.toggleFavorite(track); menuTrack = null },
            onHide = { vm.removeFromApp(track); menuTrack = null },
            onDeleteFile = { menuTrack = null; confirmDelete = track },
            onShare = { onShare(track); menuTrack = null }
        )
    }
    playlistTarget?.let { track ->
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id); playlistTarget = null },
            onCreate = { vm.createPlaylist(it, listOf(track)); playlistTarget = null },
            onDismiss = { playlistTarget = null }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Отменить это будет нельзя.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
    if (showSettings) SettingsSheet(vm, state, { showSettings = false }, onPickFolder)
    renamePlaylistId?.let { id ->
        val playlist = state.playlists.firstOrNull { it.id == id }
        if (playlist == null) renamePlaylistId = null
        else RenameDialog(
            initial = playlist.name,
            onConfirm = { vm.renamePlaylist(id, it); renamePlaylistId = null },
            onDismiss = { renamePlaylistId = null }
        )
    }
}

@Composable
private fun LibraryHeader(
    state: LibraryUiState,
    onSearch: () -> Unit,
    onQuery: (String) -> Unit,
    onShuffle: () -> Unit,
    onSettings: () -> Unit,
    onBack: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 10.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state.isDrilledIn) {
            RoundIconButton(
                icon = Icons.Filled.ArrowBack,
                tint = p.text,
                background = Color.Transparent,
                size = 40,
                iconSize = 24,
                onClick = onBack
            )
            Spacer(Modifier.width(4.dp))
        }
        if (state.searchOpen) {
            Row(
                Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.chip.copy(alpha = 0.75f))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = state.query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(p.accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (state.query.isEmpty()) {
                                Text("Поиск по трекам", color = p.subtext, fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            }
            RoundIconButton(Icons.Filled.Close, p.text, Color.Transparent, 44, 24, onSearch)
        } else {
            Text(
                text = state.openPlaylist?.name ?: state.openFolder ?: "Zizi",
                color = p.text,
                fontSize = if (state.isDrilledIn) 20.sp else 27.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            RoundIconButton(Icons.Filled.Search, p.text, Color.Transparent, 44, 24, onSearch)
            RoundIconButton(Icons.Filled.Shuffle, p.text, Color.Transparent, 44, 24, onShuffle)
            RoundIconButton(Icons.Filled.Tune, p.text, Color.Transparent, 44, 24, onSettings)
        }
    }
}

@Composable
private fun FilterRow(current: LibraryFilter, onPick: (LibraryFilter) -> Unit) {
    val p = LocalPalette.current
    val chipColors = remember(p.chip, p.text, p.accent, p.onAccent) {
        ChipColors(p.chip, p.text, p.accent, p.onAccent)
    }
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PillChip("Треки", null, current == LibraryFilter.TRACKS, chipColors, { onPick(LibraryFilter.TRACKS) }) }
        item { PillChip("Избранное", null, current == LibraryFilter.FAVORITES, chipColors, { onPick(LibraryFilter.FAVORITES) }) }
        item { PillChip("Плейлисты", null, current == LibraryFilter.PLAYLISTS, chipColors, { onPick(LibraryFilter.PLAYLISTS) }) }
        item { PillChip("Папки", null, current == LibraryFilter.FOLDERS, chipColors, { onPick(LibraryFilter.FOLDERS) }) }
    }
}

@Composable
private fun TrackList(
    listState: androidx.compose.foundation.lazy.LazyListState,
    tracks: List<TrackEntity>,
    favoriteIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    hasMiniPlayer: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 6.dp, top = 4.dp, bottom = if (hasMiniPlayer) 12.dp else 24.dp)
    ) {
        items(
            items = tracks,
            key = { it.id },
            contentType = { "track" }
        ) { track ->
            // Only primitives are passed down, so a row recomposes exclusively when ITS state changes.
            TrackRow(
                track = track,
                favorite = favoriteIds.contains(track.id),
                current = track.id == currentTrackId,
                playing = isPlaying,
                onPlay = onPlay,
                onFavorite = onFavorite,
                onMenu = onMenu
            )
        }
    }
}

@Composable
private fun TrackRow(
    track: TrackEntity,
    favorite: Boolean,
    current: Boolean,
    playing: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(66.dp)
            .clip(rowShape)
            .clickable { onPlay(track) }
            .padding(start = 4.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp)) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(rowShape),
                glyphSize = 20
            )
            if (current) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .clip(rowShape)
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    EqualizerBars(p.accent, playing, Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (current) p.accent else p.text,
                fontSize = 15.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.artist,
                color = p.subtext,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        RoundIconButton(
            icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            tint = if (favorite) p.accent else p.subtext,
            background = Color.Transparent,
            size = 42,
            iconSize = 21,
            onClick = { onFavorite(track) }
        )
        RoundIconButton(
            icon = Icons.Filled.MoreVert,
            tint = p.subtext,
            background = Color.Transparent,
            size = 38,
            iconSize = 20,
            onClick = { onMenu(track) }
        )
    }
}

@Composable
private fun PlaylistList(
    state: LibraryUiState,
    onOpen: (Long) -> Unit,
    onRename: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onCreate: (String) -> Unit
) {
    val p = LocalPalette.current
    var creating by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable { creating = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("Новый плейлист", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(state.playlists, key = { it.id }) { playlist ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(rowShape)
                    .clickable { onOpen(playlist.id) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(rowShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.QueueMusic, null, tint = p.text, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${state.playlistCounts[playlist.id] ?: 0} треков", color = p.subtext, fontSize = 12.5.sp)
                }
                RoundIconButton(Icons.Filled.Edit, p.subtext, Color.Transparent, 40, 19, { onRename(playlist.id) })
                RoundIconButton(Icons.Filled.DeleteOutline, p.subtext, Color.Transparent, 40, 20, { onDelete(playlist.id) })
            }
        }
    }
    if (creating) RenameDialog(
        initial = "",
        title = "Новый плейлист",
        onConfirm = { onCreate(it); creating = false },
        onDismiss = { creating = false }
    )
}

@Composable
private fun FolderList(
    folders: List<FolderInfo>,
    settingsFolders: List<String>,
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit
) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable(onClick = onAdd),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.CreateNewFolder, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Добавить папку", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
                    Text("Через файловый менеджер", color = p.subtext, fontSize = 12.sp)
                }
            }
        }
        items(folders, key = { it.name }) { folder ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .clip(rowShape)
                    .clickable { onOpen(folder.name) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(rowShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.FolderOpen, null, tint = p.text, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(folder.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${folder.count} треков", color = p.subtext, fontSize = 12.5.sp)
                }
            }
        }
        if (settingsFolders.isNotEmpty()) {
            item {
                Text(
                    "Подключённые папки",
                    color = p.subtext,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 6.dp, start = 4.dp)
                )
            }
            itemsIndexed(settingsFolders, key = { _, uri -> uri }) { _, uri ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Link, null, tint = p.subtext, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = Uri.decode(uri).substringAfterLast('/'),
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    RoundIconButton(Icons.Filled.Close, p.subtext, Color.Transparent, 34, 16, { onRemove(uri) })
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(vm: MainViewModel, track: TrackEntity, isPlaying: Boolean, onOpen: () -> Unit) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(p.surface.copy(alpha = 0.94f))
            .clickable(onClick = onOpen)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(11.dp)),
                glyphSize = 18
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = p.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RoundIconButton(
                icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                tint = p.text,
                background = Color.Transparent,
                size = 46,
                iconSize = 28,
                onClick = vm::playPause
            )
            RoundIconButton(Icons.Filled.SkipNext, p.text, Color.Transparent, 44, 26, vm::next)
        }
        MiniProgressLine(vm)
    }
}

/** Separate composable on purpose: the position ticks twice a second and stops here. */
@Composable
private fun MiniProgressLine(vm: MainViewModel) {
    val p = LocalPalette.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fraction = if (progress.durationMs <= 0) 0f
    else (progress.positionMs.toFloat() / progress.durationMs.toFloat()).coerceIn(0f, 1f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(2.5.dp)
            .drawBehind {
                drawRect(p.chip.copy(alpha = 0.6f))
                drawRect(p.accent, size = size.copy(width = size.width * fraction))
            }
    )
}

@Composable
private fun ScanningBadge(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Text(
        "Сканируем…",
        color = p.onAccent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .padding(top = 8.dp)
            .clip(CircleShape)
            .background(p.accent)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

@Composable
private fun CenterNote(text: String) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = p.subtext, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
    }
}
