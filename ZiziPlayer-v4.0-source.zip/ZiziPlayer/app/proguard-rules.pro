-keep class androidx.media3.** { *; }
-keep class app.ziziplayer.data.** { *; }

# ---- ZiziPlayer keep rules (release/R8) ----
# Room: generated implementations are referenced by name.
-keep class app.ziziplayer.data.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.room.paging.**

# Media3 session service is resolved through the manifest / IPC.
-keep class app.ziziplayer.playback.PlaybackService { *; }
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Palette + coroutines internals
-keep class androidx.palette.graphics.** { *; }
-dontwarn kotlinx.coroutines.**
