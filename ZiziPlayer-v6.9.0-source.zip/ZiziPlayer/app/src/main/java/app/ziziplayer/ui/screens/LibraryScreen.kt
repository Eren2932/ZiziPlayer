package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import app.ziziplayer.data.EnrichProgress
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.ScanProgress
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.FolderInfo
import app.ziziplayer.ui.SearchScope
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext

/**
 * Row metrics measured off the reference player: 48 dp cover, 8 dp corner, 62 dp row pitch.
 * v5 used a 52 dp cover inside a 66 dp row with a 13 dp radius, which is why the list looked
 * heavier and less dense than the reference.
 */
// Geometry lifted off the reference screenshot rather than eyeballed. The shot is 576 px wide on a
// 360 dp screen, i.e. 1.6 px/dp: row pitch measured 90 px = 56 dp (we were at 62), artwork 76 px =
// 48 dp (already right), corner radius ~10 px = 6 dp (we were at 8), right icon inset 32 px = 20 dp.
private val rowShape = RoundedCornerShape(8.dp)
private val artShape = RoundedCornerShape(6.dp)
private val ROW_HEIGHT = 56.dp
private val ART_SIZE = 48.dp
private val MINI_HEIGHT = 46.dp

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onOpenPlayer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    var menuTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var renamePlaylistId by remember { mutableStateOf<Long?>(null) }
    // 6.6: the library menu owns these two sheets now. Until now "Скорость и тональность" from the
    // list just started the track and threw the user into the player, and "Таймер сна" closed the
    // sheet and did literally nothing - the callback was `{ menuTrack = null }`.
    var fxTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var lyricsTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var searchTrack by remember { mutableStateOf<TrackEntity?>(null) }
    // Only read for the one open menu sheet, but hoisted here: collecting it inside the row would
    // subscribe 444 rows to a map that changes on every fetched cover.
    val fetchedMeta by vm.meta.collectAsStateWithLifecycle()
    var sleepOpen by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val context = LocalContext.current

    // While the finger is moving, nothing expensive may start.
    //
    // v5 collected the scroll offset itself, which allocated a Pair on every single frame of every
    // scroll. One boolean and a 120 ms heartbeat do the same job for free.
    // One effect, two jobs, and `collect` instead of `collectLatest` for the focus one.
    //
    // 6.5 ran two separate collectors and re-aimed the prefetcher from inside the 120 ms heartbeat
    // as well, so the aim was written up to nine times a second with the same value. collectLatest
    // also cancels and restarts its block on every emission - for a value that changes once per
    // row that is a wasted cancellation per row. The heartbeat is the only thing that repeats now.
    LaunchedEffect(listState) {
        launch {
            snapshotFlow { listState.firstVisibleItemIndex }.collect { first ->
                // Where the user is actually looking. Without this, scrolling to track 2000 left
                // the indexer grinding through tracks 0..1999 first - covers you will never see.
                ArtworkPrefetcher.focusOn(first)
            }
        }
        snapshotFlow { listState.isScrollInProgress }.collectLatest { scrolling ->
            if (!scrolling) return@collectLatest
            while (true) {
                ArtworkCache.markBusy()
                delay(120)
            }
        }
    }

    // Covers are indexed in the background, once per file, and persisted to disk. This is what
    // makes the second launch instant and keeps MediaMetadataRetriever away from the scroll.
    // Keyed on a cheap signature instead of the list identity: toggling a favourite rebuilds the
    // list object, and restarting the whole indexing pass for that would be pure waste.
    val prefetchKey = state.visible.size to state.visible.firstOrNull()?.id
    LaunchedEffect(prefetchKey) {
        delay(450)
        ArtworkPrefetcher.submit(context, state.visible)
    }

    // 6.9: hoisted ABOVE the Column. In 6.8 these two lived next to the row that draws them,
    // which reads better but does not compile: LibraryHeader is called first and needs the scope
    // to decide its placeholder, and a Kotlin local is not visible before its declaration.
    val searchScope by vm.searchScope.collectAsStateWithLifecycle()
    val onlineState by vm.online.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        LibraryHeader(
            state = state,
            netScope = searchScope == SearchScope.NET,
            onSearch = { vm.setSearchOpen(!state.searchOpen) },
            onQuery = vm::setQuery,
            onShuffle = vm::shuffleAll,
            onSettings = { showSettings = true },
            onBack = { vm.handleBack() }
        )

        // 6.8: while the search field is open the row under it switches the SCOPE of the query
        // instead of the section of the library. The filters are meaningless for a network search
        // (there is no "favourites" in a catalogue) and the scope is meaningless without a query,
        // so the two never need to be on screen at the same time.
        if (state.searchOpen) {
            SearchScopeRow(searchScope) { vm.setSearchScope(it) }
            Spacer(Modifier.height(4.dp))
        } else if (!state.isDrilledIn) {
            FilterRow(state.filter) { vm.setFilter(it) }
            Spacer(Modifier.height(4.dp))
        }

        Box(Modifier.weight(1f)) {
            when {
                state.searchOpen && searchScope == SearchScope.NET -> OnlineSearchList(
                    query = state.query,
                    state = onlineState,
                    hasMiniPlayer = currentTrack != null,
                    onSearch = vm::searchOnline,
                    onPlay = { track -> vm.playOnline(track, onlineState.results) },
                    onDownload = vm::downloadOnline
                )
                state.loading -> CenterNote("Загружаем библиотеку…")
                state.filter == LibraryFilter.PLAYLISTS && state.openPlaylist == null ->
                    PlaylistList(
                        state = state,
                        onOpen = vm::openPlaylist,
                        onRename = { renamePlaylistId = it },
                        onDelete = vm::deletePlaylist,
                        onCreate = { vm.createPlaylist(it) }
                    )
                state.filter == LibraryFilter.FOLDERS && state.openFolder == null ->
                    FolderList(
                        folders = state.folders,
                        settingsFolders = remember(state.settings.folderUris) { state.settings.folderUris.toList() },
                        onOpen = vm::openFolder,
                        onAdd = onPickFolder,
                        onRemove = vm::removeFolder
                    )
                state.visible.isEmpty() -> CenterNote(
                    when {
                        state.query.isNotBlank() -> "Ничего не найдено"
                        state.filter == LibraryFilter.FAVORITES -> "Пока нет избранных треков"
                        else -> "Треков нет. Добавь папку через «Папки»"
                    }
                )
                else -> {
                    // Both lambdas are now created ONCE for the life of the screen.
                    //
                    // 6.5 keyed onPlay on the visible list, and the visible list is a brand new
                    // object every time anything in the library changes - tapping one heart
                    // rebuilds it. That handed every row a different lambda instance, so a single
                    // favourite toggle recomposed every visible row instead of one. The list is
                    // read through a snapshot holder at click time instead, which is also more
                    // correct: the queue is built from what is on screen at the tap, not from
                    // whatever was on screen when the lambda happened to be created.
                    val visibleRef = rememberUpdatedState(state.visible)
                    val onPlay = remember { { track: TrackEntity -> vm.play(track, visibleRef.value) } }
                    val onMenu = remember { { track: TrackEntity -> menuTrack = track } }
                    TrackList(
                        listState = listState,
                        tracks = visibleRef.value,
                        favoriteIds = state.favoriteIds,
                        currentTrackId = playback.currentTrackId,
                        isPlaying = playback.isPlaying,
                        hasMiniPlayer = currentTrack != null,
                        onPlay = onPlay,
                        onFavorite = vm::toggleFavorite,
                        onMenu = onMenu
                    )
                }
            }

            if (state.scanning) {
                // Collected here, not lifted into LibraryUiState: see MainViewModel.scanProgress.
                val progress by vm.scanProgress.collectAsStateWithLifecycle()
                ScanningBadge(progress, Modifier.align(Alignment.TopCenter))
            } else {
                // 6.7: covers and artists appearing one by one, minutes after the app opened, with
                // nothing on screen to explain it, reads like a glitch. Scanning wins the slot
                // because it blocks the library and this does not - enrichment is a background
                // errand and the badge is worded like one.
                val enrich by vm.enrichProgress.collectAsStateWithLifecycle()
                EnrichBadge(enrich, Modifier.align(Alignment.TopCenter))
            }
        }

        if (currentTrack != null) {
            MiniPlayer(
                vm = vm,
                track = currentTrack,
                isPlaying = playback.isPlaying,
                onOpen = onOpenPlayer
            )
        }
        Spacer(Modifier.navigationBarsPadding())
    }

    menuTrack?.let { track ->
        val stat = state.stats[track.id]
        val metaSource = fetchedMeta[track.id]?.source?.takeIf { it.isNotBlank() }
        TrackMenuSheet(
            track = track,
            favorite = state.favoriteIds.contains(track.id),
            plays = stat?.playCount ?: 0,
            lastPlayedAt = stat?.lastPlayedAt ?: 0L,
            sleepMinutesLeft = playback.sleepMinutesLeft,
            inPlaylist = state.openPlaylist,
            metaSource = metaSource,
            onDismiss = { menuTrack = null },
            onPlayNow = { menuTrack = null; vm.play(track, state.visible); onOpenPlayer() },
            onPlayNext = { menuTrack = null; vm.playNext(track) },
            onAddToQueue = { menuTrack = null; vm.addToQueue(track) },
            onFx = { menuTrack = null; fxTrack = track },
            onSleep = { menuTrack = null; sleepOpen = true },
            onAddToPlaylist = { menuTrack = null; playlistTarget = track },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                menuTrack = null
            },
            // Deliberately does NOT close the sheet: the tile is a toggle and it shows its own
            // state, so the sheet closing under your finger was just a loss of feedback.
            onToggleFavorite = { vm.toggleFavorite(track) },
            onHide = { vm.removeFromApp(track); menuTrack = null },
            onDeleteFile = { menuTrack = null; confirmDelete = track },
            onShare = { onShare(track); menuTrack = null },
            onLyrics = { menuTrack = null; lyricsTrack = track },
            onRefreshMeta = { menuTrack = null; vm.refreshMeta(track) },
            onCatalogSearch = { menuTrack = null; searchTrack = track }
        )
    }
    fxTrack?.let { target -> FxSheet(vm, target) { fxTrack = null } }
    lyricsTrack?.let { target -> LyricsSheet(vm, target) { lyricsTrack = null } }
    searchTrack?.let { target -> CatalogSearchSheet(vm, target) { searchTrack = null } }
    if (sleepOpen) SleepSheet(
        current = playback.sleepMinutesLeft,
        onPick = { vm.setSleepTimer(it); sleepOpen = false },
        onDismiss = { sleepOpen = false }
    )
    playlistTarget?.let { track ->
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id); playlistTarget = null },
            onCreate = { vm.createPlaylist(it, listOf(track)); playlistTarget = null },
            onDismiss = { playlistTarget = null }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Отменить это будет нельзя.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
    if (showSettings) SettingsSheet(vm, state, { showSettings = false }, onPickFolder)
    renamePlaylistId?.let { id ->
        val playlist = state.playlists.firstOrNull { it.id == id }
        if (playlist == null) renamePlaylistId = null
        else RenameDialog(
            initial = playlist.name,
            onConfirm = { vm.renamePlaylist(id, it); renamePlaylistId = null },
            onDismiss = { renamePlaylistId = null }
        )
    }
}

@Composable
private fun LibraryHeader(
    state: LibraryUiState,
    netScope: Boolean,
    onSearch: () -> Unit,
    onQuery: (String) -> Unit,
    onShuffle: () -> Unit,
    onSettings: () -> Unit,
    onBack: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 10.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state.isDrilledIn) {
            RoundIconButton(
                icon = Icons.AutoMirrored.Filled.ArrowBack,
                tint = p.text,
                background = Color.Transparent,
                size = 40,
                iconSize = 24,
                onClick = onBack
            )
            Spacer(Modifier.width(4.dp))
        }
        if (state.searchOpen) {
            // The field owns its text.
            //
            // v4 fed the field from the library flow: every character travelled to the ViewModel,
            // through the whole combine pipeline and back, so characters arrived late or vanished
            // and the entire library was refiltered on each keystroke. Now typing is instant and
            // the query is only published once the finger has rested for 130 ms.
            var text by remember { mutableStateOf(state.query) }
            LaunchedEffect(text) {
                delay(130)
                if (text != state.query) onQuery(text)
            }
            Row(
                Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.chip.copy(alpha = 0.75f))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = TextStyle(color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(p.accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (text.isEmpty()) {
                                Text(
                                    if (netScope) "Найти трек в сети" else "Поиск по трекам",
                                    color = p.subtext,
                                    fontSize = 16.sp
                                )
                            }
                            inner()
                        }
                    }
                )
            }
            RoundIconButton(Icons.Filled.Close, p.text, Color.Transparent, 44, 24, onSearch)
        } else {
            Text(
                text = state.openPlaylist?.name ?: state.openFolder ?: "Zizi",
                color = p.text,
                fontSize = if (state.isDrilledIn) 20.sp else 27.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            RoundIconButton(Icons.Filled.Search, p.text, Color.Transparent, 44, 24, onSearch)
            RoundIconButton(Icons.Filled.Shuffle, p.text, Color.Transparent, 44, 24, onShuffle)
            RoundIconButton(Icons.Filled.Tune, p.text, Color.Transparent, 44, 24, onSettings)
        }
    }
}

@Composable
private fun FilterRow(current: LibraryFilter, onPick: (LibraryFilter) -> Unit) {
    val p = LocalPalette.current
    val chipColors = remember(p.chip, p.text, p.accent, p.onAccent) {
        ChipColors(p.chip, p.text, p.accent, p.onAccent)
    }
    // Four fixed filters, so this is a segmented row, not a carousel.
    //
    // As a LazyRow the fourth chip was always half off the right edge - it looked like a bug, and
    // the only way to find out that "Папки" existed was to try dragging a row of chips that gave no
    // hint it could be dragged. Equal weights fit all four inside 360 dp with room to spare.
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        FilterChip("Треки", current == LibraryFilter.TRACKS, chipColors, Modifier.weight(1f)) { onPick(LibraryFilter.TRACKS) }
        FilterChip("Избранное", current == LibraryFilter.FAVORITES, chipColors, Modifier.weight(1f)) { onPick(LibraryFilter.FAVORITES) }
        FilterChip("Плейлисты", current == LibraryFilter.PLAYLISTS, chipColors, Modifier.weight(1f)) { onPick(LibraryFilter.PLAYLISTS) }
        FilterChip("Папки", current == LibraryFilter.FOLDERS, chipColors, Modifier.weight(1f)) { onPick(LibraryFilter.FOLDERS) }
    }
}

/** Segment of the filter row: fills its share of the width, centres its label, never truncates. */
@Composable
private fun FilterChip(
    label: String,
    active: Boolean,
    colors: ChipColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(if (active) colors.activeBackground else colors.background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (active) colors.activeContent else colors.content,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TrackList(
    listState: androidx.compose.foundation.lazy.LazyListState,
    tracks: List<TrackEntity>,
    favoriteIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    hasMiniPlayer: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 10.dp, end = 8.dp, top = 2.dp, bottom = if (hasMiniPlayer) 8.dp else 20.dp)
    ) {
        items(
            items = tracks,
            key = { it.id },
            contentType = { "track" }
        ) { track ->
            // Only primitives are passed down, so a row recomposes exclusively when ITS state changes.
            TrackRow(
                track = track,
                favorite = favoriteIds.contains(track.id),
                current = track.id == currentTrackId,
                playing = isPlaying && track.id == currentTrackId,
                onPlay = onPlay,
                onFavorite = onFavorite,
                onMenu = onMenu
            )
        }
    }
}

private val rowArtistStyle = TextStyle(fontSize = 13.5.sp, fontWeight = FontWeight.Normal)

@Composable
private fun TrackRow(
    track: TrackEntity,
    favorite: Boolean,
    current: Boolean,
    playing: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(ROW_HEIGHT)
            // No .clip(rowShape) here since 6.6. A rounded clip is a graphics layer, and this one
            // existed only to round the corners of a press ripple that is invisible for 99 % of the
            // list's life. The cover keeps its own clip; the row itself is now a plain node.
            .clickable { onPlay(track) }
            .padding(start = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // One clip for the whole tile instead of one per child (6.5). A rounded clip is a
        // graphics layer, and the playing row was paying for three of them - artwork, scrim and
        // the tile itself - on every frame of a scroll it appeared in.
        Box(Modifier.size(ART_SIZE).clip(artShape)) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier.fillMaxSize(),
                glyphSize = 18
            )
            if (current) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.48f)),
                    contentAlignment = Alignment.Center
                ) {
                    EqualizerBars(p.accent, playing, Modifier.size(17.dp))
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            TrackTitle(
                title = track.title,
                color = if (current) p.accent else p.text,
                dim = if (current) p.accent.copy(alpha = 0.55f) else p.text.copy(alpha = 0.42f),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(1.dp))
            // Style hoisted to a file-level constant: passing fontSize/fontWeight makes Text
            // merge a fresh TextStyle on every composition, and this line exists 3000 times.
            Text(
                text = track.artist,
                color = p.subtext,
                style = rowArtistStyle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        RoundIconButton(
            icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            tint = if (favorite) p.accent else p.subtext,
            background = Color.Transparent,
            size = 38,
            iconSize = 19,
            onClick = { onFavorite(track) }
        )
        RoundIconButton(
            icon = Icons.Filled.MoreVert,
            tint = p.subtext,
            background = Color.Transparent,
            size = 34,
            iconSize = 18,
            onClick = { onMenu(track) }
        )
    }
}

@Composable
private fun PlaylistList(
    state: LibraryUiState,
    onOpen: (Long) -> Unit,
    onRename: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onCreate: (String) -> Unit
) {
    val p = LocalPalette.current
    var creating by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable { creating = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("Новый плейлист", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(state.playlists, key = { it.id }) { playlist ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_HEIGHT)
                    .clip(rowShape)
                    .clickable { onOpen(playlist.id) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(artShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.QueueMusic, null, tint = p.accent, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${state.playlistCounts[playlist.id] ?: 0} треков", color = p.subtext, fontSize = 12.5.sp)
                }
                RoundIconButton(Icons.Filled.Edit, p.subtext, Color.Transparent, 40, 19, { onRename(playlist.id) })
                RoundIconButton(Icons.Filled.DeleteOutline, p.subtext, Color.Transparent, 40, 20, { onDelete(playlist.id) })
            }
        }
    }
    if (creating) RenameDialog(
        initial = "",
        title = "Новый плейлист",
        onConfirm = { onCreate(it); creating = false },
        onDismiss = { creating = false }
    )
}

@Composable
private fun FolderList(
    folders: List<FolderInfo>,
    settingsFolders: List<String>,
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit
) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
    ) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(rowShape)
                    .clickable(onClick = onAdd),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(CircleShape)
                        .background(p.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.CreateNewFolder, null, tint = p.accent, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Добавить папку", color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
                    Text("Через файловый менеджер", color = p.subtext, fontSize = 12.sp)
                }
            }
        }
        items(folders, key = { it.name }) { folder ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_HEIGHT)
                    .clip(rowShape)
                    .clickable { onOpen(folder.name) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(ART_SIZE)
                        .clip(artShape)
                        .background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.FolderOpen, null, tint = p.accent, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(folder.name, color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${folder.count} треков", color = p.subtext, fontSize = 12.5.sp)
                }
            }
        }
        if (settingsFolders.isNotEmpty()) {
            item {
                Text(
                    "Подключённые папки",
                    color = p.subtext,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 6.dp, start = 4.dp)
                )
            }
            itemsIndexed(settingsFolders, key = { _, uri -> uri }) { _, uri ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Link, null, tint = p.subtext, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = Uri.decode(uri).substringAfterLast('/'),
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    RoundIconButton(Icons.Filled.Close, p.subtext, Color.Transparent, 34, 16, { onRemove(uri) })
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(vm: MainViewModel, track: TrackEntity, isPlaying: Boolean, onOpen: () -> Unit) {
    val p = LocalPalette.current
    // v6.1 drew a floating rounded card with 10/6 dp margins, 8 dp inner padding, a 44 dp cover and
    // 46 dp buttons - about 68 dp of screen for a strip the reference does in 40. It is now a
    // full-bleed bar sitting flush on the navigation bar, with the progress line doubling as the
    // divider (measured: 63 px = 39 dp tall; 46 dp keeps the two buttons at a legal touch target).
    Column(
        Modifier
            .fillMaxWidth()
            .background(p.surface.copy(alpha = 0.97f))
            .clickable(onClick = onOpen)
    ) {
        MiniProgressLine(vm)
        Row(
            Modifier
                .fillMaxWidth()
                .height(MINI_HEIGHT)
                .padding(start = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(5.dp)),
                glyphSize = 15
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                TrackTitle(
                    title = track.title,
                    color = p.text,
                    dim = p.text.copy(alpha = 0.45f),
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(track.artist, color = p.subtext, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RoundIconButton(
                icon = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                tint = p.text,
                background = Color.Transparent,
                size = 38,
                iconSize = 24,
                onClick = vm::playPause
            )
            RoundIconButton(Icons.Rounded.SkipNext, p.text, Color.Transparent, 36, 22, vm::next)
        }
    }
}

/** Separate composable on purpose: the position ticks twice a second and stops here. */
@Composable
private fun MiniProgressLine(vm: MainViewModel) {
    val p = LocalPalette.current
    // The state object is held, NOT unwrapped with `by`: reading .value inside drawBehind keeps the
    // twice-a-second position tick in the draw phase. Unwrapping it here made this composable - and
    // therefore the whole mini player row - recompose two times a second, forever, while playing.
    val progress = vm.progress.collectAsStateWithLifecycle()
    val inactive = remember(p.chip) { p.chip.copy(alpha = 0.65f) }
    val accent = p.accent
    Box(
        Modifier
            .fillMaxWidth()
            .height(2.dp)
            .drawBehind {
                val state = progress.value
                val fraction = if (state.durationMs <= 0) 0f
                else (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f)
                drawRect(inactive)
                drawRect(accent, size = size.copy(width = size.width * fraction))
            }
    )
}

/**
 * The quiet twin of [ScanningBadge]: says what the enrichment pass is doing, then gets out.
 *
 * Fades rather than appearing, because a badge that pops in during a scroll steals the eye from the
 * list. It also lingers for a moment on "готово" - a progress indicator that vanishes the instant
 * it finishes never gets read, so the one piece of good news the pass produces would be invisible.
 */
@Composable
private fun EnrichBadge(progress: EnrichProgress, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    // Held state, not the raw flow: the "готово" tail has to outlive `running = false`.
    var shown by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(progress.running, progress.done, progress.total, progress.matched, progress.offline) {
        when {
            progress.running && progress.total > 0 ->
                shown = "Дополняем библиотеку · ${progress.done} / ${progress.total}"
            progress.running -> shown = "Дополняем библиотеку…"
            shown != null -> {
                shown = if (progress.matched > 0) "Готово · дополнено ${progress.matched}" else null
                delay(2_500)
                shown = null
            }
        }
    }
    val label = shown
    AnimatedVisibility(
        visible = label != null,
        enter = fadeIn(animationSpec = tween(220)),
        exit = fadeOut(animationSpec = tween(400)),
        modifier = modifier
    ) {
        Row(
            Modifier
                .padding(top = 8.dp)
                .clip(CircleShape)
                // Deliberately NOT the accent fill the scan badge uses: this must not compete with
                // the list for attention, and an accent pill at the top of the screen does.
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 13.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.CloudDownload, null, tint = p.accent, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(7.dp))
            Text(label ?: "", color = Color.White.copy(alpha = 0.92f), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ScanningBadge(progress: ScanProgress?, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    // "Сканируем…" with no end in sight is indistinguishable from a hang, and on a large folder the
    // wait used to be tens of seconds. The badge now says what is happening and how far it has got.
    val label = when {
        progress == null -> "Сканируем…"
        progress.total > 0 -> "${progress.label} · ${progress.done} / ${progress.total}"
        else -> progress.label
    }
    Row(
        modifier
            .padding(top = 8.dp)
            .clip(CircleShape)
            .background(p.accent)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = p.onAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CenterNote(text: String) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = p.subtext, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
    }
}
