package app.ziziplayer.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import app.ziziplayer.ui.components.CameraCutoutSnapshot
import app.ziziplayer.ui.components.LocalCameraCutoutOverride
import app.ziziplayer.ui.screens.CollectionHeroContent
import app.ziziplayer.ui.screens.CollectionActionsRow
import app.ziziplayer.ui.screens.PinnedCollectionScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import kotlin.math.roundToInt

/** Requires device/emulator. Not reported as passed by the offline JVM/Python checker. */
class CameraMorph6692UiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private var cameraPoint = Offset.Zero
    private var status = 0f
    private var backs = 0
    private var plays = 0

    @Suppress("DEPRECATION")
    private fun mount(hasCamera: Boolean, corner: Boolean = false) {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            // Match MainActivity: an opaque DecorView status-bar color view would hide
            // the injected contour in PixelCopy and test the harness rather than the overlay.
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                compose.activity.window.isStatusBarContrastEnforced = false
            }
        }
        compose.setContent {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusValue = WindowInsets.statusBars.getTop(density).toFloat()
                status = statusValue
                val pointX = w * if (corner) .12f else .5f
                val pointY = statusValue * .5f
                cameraPoint = Offset(pointX, pointY)
                // Stable identity, mirroring rememberCameraCutout()'s previousKey guard in
                // production: a fresh CameraCutoutSnapshot/Path every recomposition, handed to
                // a staticCompositionLocalOf, forces a full-subtree recompose on every pass and
                // starved the idling resource under load (root cause of the corner-hole timeout).
                val snapshot = remember(hasCamera, corner, w, h, statusValue) {
                    val diameter = statusValue * .55f
                    val t = CameraMorphGeometry.Target(pointX - diameter/2, pointY - diameter/2,
                        pointX + diameter/2, pointY + diameter/2)
                    val outline = Path().apply { addOval(Rect(t.left,t.top,t.right,t.bottom)) }
                    CameraCutoutSnapshot(
                        target = if (hasCamera) t else null, outline = if (hasCamera) outline else null,
                        windowWidth = w.roundToInt(), windowHeight = h.roundToInt(),
                        statusTop = statusValue.roundToInt(), exact = true, reason = "Injected test fixture"
                    )
                }
                CompositionLocalProvider(LocalPalette provides basePalette(), LocalCameraCutoutOverride provides snapshot) {
                    PinnedCollectionScaffold(destination = "test:6692", title = "Camera collection",
                        tint = Color.DarkGray, trackCount = 40, playingHere = false, playEnabled = true,
                        onBack = { backs++ }, onPlay = { plays++ },
                        artwork = { Box(Modifier.fillMaxSize().background(Color.Magenta)) },
                        hero = {
                            CollectionHeroContent(title = "Camera collection", metadata = "40 tracks") {
                                CollectionActionsRow(onShuffle = {}, shuffleEnabled = true)
                            }
                        }) {
                        items(40) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                    }
                }
            }
        }
        compose.waitUntil { status > 0f }
        compose.waitForIdle()
    }

    private fun cameraPixel(): Color {
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        return pixels[cameraPoint.x.roundToInt().coerceIn(0,pixels.width-1),
            cameraPoint.y.roundToInt().coerceIn(0,pixels.height-1)]
    }
    private fun collapse() {
        compose.onNodeWithTag("collection:list").performScrollToIndex(12)
        compose.waitForIdle()
    }
    private fun assertBlack(c: Color) {
        assertTrue("Expected the injected cutout contour, got $c", c.red < .03f && c.green < .03f && c.blue < .03f)
    }

    @Test fun centralHoleCompletesAtInjectedContourAndControlsStillWork() {
        mount(true)
        assertTrue(cameraPixel().red > .1f) // No fabricated black dot in the expanded header.
        collapse()
        assertBlack(cameraPixel())
        compose.onNodeWithContentDescription("Слушать подборку").performClick()
        compose.onNodeWithContentDescription("Назад").performClick()
        compose.runOnIdle { assertEquals(1, plays); assertEquals(1, backs) }
    }
    @Test fun cornerHoleUsesItsRealXNotScreenCenter() {
        mount(true, corner = true)
        collapse()
        assertBlack(cameraPixel())
        // The real hole is off-center; nothing invents a black dot at screen center instead.
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        val centerX = pixels.width / 2
        val centerPixel = pixels[centerX.coerceIn(0, pixels.width - 1), cameraPoint.y.roundToInt().coerceIn(0, pixels.height - 1)]
        assertTrue("No fabricated camera at screen center for a corner cutout, got $centerPixel",
            centerPixel.red > .03f || centerPixel.green > .03f || centerPixel.blue > .03f)
    }
    @Test fun noHoleLeavesStatusBackgroundUntouched() {
        mount(false)
        val before = cameraPixel()
        collapse()
        val after = cameraPixel()
        assertEquals(before.red, after.red, .01f)
        assertEquals(before.green, after.green, .01f)
        assertEquals(before.blue, after.blue, .01f)
    }
    private fun drag(upwards: Boolean, fraction: Float = .42f) {
        compose.onNodeWithTag("collection:list").performTouchInput {
            val point = Offset(center.x, height * .5f)
            down(point)
            moveTo(point + Offset(0f, height * fraction * if (upwards) -1f else 1f))
            // Stationary before release: test nested scroll, not an uncontrolled fling.
            advanceEventTime(1000)
            up()
        }
        compose.waitForIdle()
    }

    /** The measured placeholder is NOT proof of artwork rendering. Inspect real pixels too. */
    private fun magentaWidth(): Int {
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        var left = pixels.width
        var right = -1
        for (y in status.roundToInt() until pixels.height) for (x in 0 until pixels.width) {
            val c = pixels[x, y]
            if (c.red > .95f && c.blue > .95f && c.green < .05f) {
                left = minOf(left, x)
                right = maxOf(right, x)
            }
        }
        return if (right < left) 0 else right - left + 1
    }

    @Test fun shortRealDragShrinksRenderedArtworkAndReverseRestoresIt() {
        mount(true)
        val before = magentaWidth()
        assertTrue(before > 0)
        drag(upwards = true, fraction = .06f)
        val smaller = magentaWidth()
        assertTrue("The picture, not just its slot, must shrink", smaller in 1 until before)
        drag(upwards = false, fraction = .14f)
        assertEquals(before.toFloat(), magentaWidth().toFloat(), 2f)
        assertTrue(cameraPixel().red > .1f)
    }

    @Test fun realScrollRoundTripRemovesAnchorAndRestoresExpandedGeometry() {
        mount(true)
        val before = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().boundsInRoot
        val imageBefore = magentaWidth()
        repeat(3) { drag(upwards = true) }
        assertBlack(cameraPixel())
        assertEquals(0, magentaWidth())
        repeat(5) { drag(upwards = false) }
        val after = compose.onNodeWithTag("collection:cover").fetchSemanticsNode().boundsInRoot
        assertEquals(before.width, after.width, 1f)
        assertEquals(before.top, after.top, 1f)
        assertEquals(imageBefore.toFloat(), magentaWidth().toFloat(), 2f)
        assertTrue(cameraPixel().red > .1f)
    }
    @Test fun scrolledGradientHasNoStatusBarSeam() {
        mount(true)
        drag(upwards = true, fraction = .32f)
        val pixels = compose.onNodeWithTag("collection:viewport").captureToImage().toPixelMap()
        val edge = status.roundToInt()
        val above = pixels[2, edge-1]
        val below = pixels[2, edge+1]
        assertEquals(above.red, below.red, .025f)
        assertEquals(above.green, below.green, .025f)
        assertEquals(above.blue, below.blue, .025f)
    }

    /** Real Android adapter + real Compose overlay at a controlled intermediate scroll,
     * not merely a black endpoint in an injected fixture. Does not claim OEM calibration. */
    @Test
    @androidx.test.filters.SdkSuppress(minSdkVersion = 28)
    @Suppress("DEPRECATION")
    fun topAttachedReservationRendersConnectedNeckBeforeArtworkDisappears() {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29)
                compose.activity.window.isStatusBarContrastEnforced = false
        }
        var neckPoint = Offset.Zero
        var bodyPoint = Offset.Zero
        compose.setContent {
            BoxWithConstraints(Modifier.fillMaxSize().background(Color.DarkGray).testTag("morph:midframe")) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusPx = WindowInsets.statusBars.getTop(density)
                val snapshot = remember(w, h, statusPx, density.density) {
                    val d = (statusPx * .55f).roundToInt()
                    val raw = android.graphics.Rect((w/2-d/2).roundToInt(), 0,
                        (w/2-d/2).roundToInt()+d, statusPx)
                    val cutout = android.view.DisplayCutout(android.graphics.Rect(0,statusPx,0,0), listOf(raw))
                    app.ziziplayer.ui.components.cameraCutoutSnapshot(cutout, w.roundToInt(),
                        h.roundToInt(), statusPx, density.density)
                }
                val unit = CollectionHeaderGeometry.unit(maxWidth.value)
                val maximum = (CollectionHeaderGeometry.COVER_SIZE * unit).dp
                val minimum = (maximum * .44f).coerceAtLeast(64.dp).coerceAtMost(maximum)
                val top = (CollectionHeaderGeometry.COVER_TOP * unit).dp
                val travel = with(density) { (minimum + top).toPx() }
                val offset = travel * .5f
                val target = snapshot.target
                if (target != null) {
                    val f = CameraMorphGeometry.frame(with(density) { maximum.toPx() },
                        with(density) { minimum.toPx() }, 1f, offset, w/2,
                        statusPx + with(density) { top.toPx() }, 0f, travel, statusPx.toFloat(), target)
                    neckPoint = Offset(target.cx(), (target.bottom + f.top())/2)
                    bodyPoint = Offset(f.cx, f.cy + f.height*.2f)
                }
                app.ziziplayer.ui.components.CollectionCoverMorphOverlay(
                    camera = snapshot, maximum = maximum, minimum = minimum, coverTop = top,
                    corner = 0.dp, status = with(density) { statusPx.toDp() },
                    fraction = { 1f }, scroll = { offset },
                    artwork = { Box(Modifier.fillMaxSize().background(Color.Magenta)) }
                )
            }
        }
        compose.waitForIdle()
        assertTrue("System reservation must produce a usable approximation", neckPoint.y > 0)
        val pixels = compose.onNodeWithTag("morph:midframe").captureToImage().toPixelMap()
        assertBlack(pixels[neckPoint.x.roundToInt(), neckPoint.y.roundToInt()])
        val body = pixels[bodyPoint.x.roundToInt(), bodyPoint.y.roundToInt()]
        assertTrue("Artwork is still present below the connected neck", body.red > .05f &&
            body.blue > .05f && body.green < .03f)
        val outside = pixels[8, neckPoint.y.roundToInt()]
        assertTrue("No full-width status darkening", outside.red > .1f)
    }

}
