package app.ziziplayer.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable

/**
 * Custom seek bar. The stock Material slider fires a seek on every pixel of movement,
 * which is what made the play icon flicker; this one only reports the final value.
 */
@Composable
fun ZiziSlider(
    fraction: Float,
    accent: Color,
    inactive: Color,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var local by remember { mutableFloatStateOf(fraction) }
    var scrubbing by remember { mutableStateOf(false) }
    val shown = (if (scrubbing) local else fraction).coerceIn(0f, 1f)
    val density = LocalDensity.current

    Box(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            // ONE gesture detector.
            //
            // v4 attached a tap detector AND a horizontal drag detector to the same box. A short
            // finger movement satisfied both, so two different seeks were dispatched for a single
            // gesture - that is exactly the twitching when nudging the thumb a little. On top of
            // that the tap path used an absolute position while the drag path accumulated relative
            // deltas, so the two disagreed about where the finger actually was.
            //
            // Now a press, a drag and a tap are the same code path, always absolute, one seek.
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scrubbing = true
                    local = (down.position.x / widthPx).coerceIn(0f, 1f)
                    onScrubStart()
                    onScrub(local)
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val next = (change.position.x / widthPx).coerceIn(0f, 1f)
                        if (next != local) { local = next; onScrub(next) }
                        change.consume()
                    }
                    scrubbing = false
                    onScrubEnd(local)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            val trackHeight = with(density) { 5.dp.toPx() }
            val radius = trackHeight / 2f
            val centerY = size.height / 2f
            drawRoundRect(
                color = inactive,
                topLeft = Offset(0f, centerY - radius),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(radius, radius)
            )
            val filled = size.width * shown
            if (filled > 0.5f) {
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(filled, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val thumb = with(density) { (if (scrubbing) 9.dp else 7.dp).toPx() }
            // coerceIn throws when min > max, which happens the moment the bar is laid out
            // narrower than the thumb (a very small window, a 0 px first frame). A crash inside
            // the draw phase takes the whole screen down, so the bounds are ordered explicitly.
            val minX = thumb.coerceAtMost(size.width / 2f)
            val maxX = (size.width - thumb).coerceAtLeast(minX)
            drawCircle(color = accent, radius = thumb, center = Offset(filled.coerceIn(minX, maxX), centerY))
        }
    }
}

@Composable
fun PillChip(
    label: String,
    icon: ImageVector?,
    active: Boolean,
    palette: ChipColors,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val background = if (active) palette.activeBackground else palette.background
    val content = if (active) palette.activeContent else palette.content
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(19.dp))
            Box(Modifier.width(9.dp))
        }
        Text(label, color = content, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

data class ChipColors(
    val background: Color,
    val content: Color,
    val activeBackground: Color,
    val activeContent: Color
)

/** Little animated equaliser shown on the row that is currently playing. */
@Composable
fun EqualizerBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    // v3 read the animated values during composition, so this tiny widget recomposed 60 times a
    // second - and it never stopped, even on pause. Now the values are read inside the draw
    // lambda (draw-phase only) and the animation exists exclusively while something is playing.
    if (!playing) {
        Canvas(modifier) { drawEqualizerBars(color, 0.35f, 0.6f, 0.4f) }
        return
    }
    val transition = rememberInfiniteTransition(label = "eq")
    val a = transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "a")
    val b = transition.animateFloat(1f, 0.45f, infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "b")
    val c = transition.animateFloat(0.55f, 0.95f, infiniteRepeatable(tween(430), RepeatMode.Reverse), label = "c")
    Canvas(modifier) { drawEqualizerBars(color, a.value, b.value, c.value) }
}

private fun DrawScope.drawEqualizerBars(color: Color, first: Float, second: Float, third: Float) {
    // Unrolled on purpose: this runs on every frame while music plays, and the listOf() it used to
    // build allocated a list plus three boxed floats sixty times a second, on the row the user is
    // looking at. Small, but it is pure garbage in the hot path.
    val barWidth = size.width / 5f
    val radius = CornerRadius(barWidth / 2f, barWidth / 2f)
    drawBar(color, 0f, barWidth, first, radius)
    drawBar(color, barWidth * 2f, barWidth, second, radius)
    drawBar(color, barWidth * 4f, barWidth, third, radius)
}

private fun DrawScope.drawBar(color: Color, x: Float, width: Float, value: Float, radius: CornerRadius) {
    val barHeight = size.height * value
    drawRoundRect(
        color = color,
        topLeft = Offset(x, size.height - barHeight),
        size = Size(width, barHeight),
        cornerRadius = radius
    )
}

@Composable
fun RoundIconButton(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: Int = 52,
    iconSize: Int = 24,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .size(size.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize.dp))
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
