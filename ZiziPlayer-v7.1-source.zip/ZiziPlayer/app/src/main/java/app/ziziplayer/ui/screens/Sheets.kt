@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.SortMode
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.EqualizerBars
import app.ziziplayer.ui.components.PillChip
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
private fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun MenuItem(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    trailing: String? = null,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
        if (trailing != null) Text(trailing, color = p.subtext, fontSize = 14.sp)
    }
}

/**
 * Our own bottom sheet, in place of ModalBottomSheet.
 *
 * The stock component animates on a fixed tween and rebuilds a whole window's worth of state on the
 * way in - the lazy, floaty feel of v6.1. This one snaps open on a stiff spring (~180 ms, damping
 * 0.85, no overshoot), closes on 150 ms, and drags to dismiss. Nothing here reads an animated value
 * during composition: the slide is a graphicsLayer translation and the scrim is a layer alpha, so
 * the transition costs zero recompositions.
 *
 * ## The v7.0 freeze, and why it killed every button in the app
 *
 * v7.0 called `onDismiss()` on the line after `offset.animateTo(...)` inside a coroutine:
 *
 *     closing = true
 *     scope.launch { offset.animateTo(height, tween(150)); onDismiss() }
 *
 * An `Animatable` cancels its running animation as soon as anything else touches it. Start a second
 * gesture during those 150 ms - a flick, a stray finger on the sheet, a double tap on the scrim -
 * and `draggable`'s `snapTo` cancels the exit animation, the `CancellationException` kills the
 * coroutine, and `onDismiss()` is never reached. `closing` stays true forever, so every later tap
 * hits `if (closing) return` and does nothing.
 *
 * What is left on screen is the worst possible object: a focusable, full screen `Popup` whose scrim
 * alpha is computed as `1 - offset / height` - which is 0 once the sheet has slid down. Invisible,
 * in its own window, above everything, consuming every touch event. The app looks completely normal
 * and nothing responds: not the player buttons, not the tabs, not search. It survives leaving and
 * re-entering the app, because the composition is still alive.
 *
 * The fix is structural, not a patch on the symptom:
 *
 * 1. Dismissal is owned by state, not by an animation. `closing = true` is the request; a separate
 *    effect performs the exit and then dismisses in a `finally`-style path, so cancellation of the
 *    animation cannot cancel the dismissal.
 * 2. That effect is wrapped in `withTimeout`, so even a wedged animation cannot hold the sheet for
 *    more than the exit duration plus a small margin.
 * 3. While closing, the scrim's gesture detector and the drag handle are switched off - nothing can
 *    interrupt an exit that is already under way.
 * 4. The scrim's pointer input exists only while the scrim is actually visible, so an invisible
 *    layer can never be the thing swallowing touches.
 */
@Composable
private fun ZiziSheetScaffold(
    onDismiss: () -> Unit,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(OFFSCREEN) }
    var heightPx by remember { mutableFloatStateOf(0f) }
    var opened by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.92f).dp
    val dismiss = rememberUpdatedState(onDismiss)

    LaunchedEffect(heightPx) {
        if (heightPx > 0f && !opened) {
            opened = true
            offset.snapTo(heightPx)
            offset.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 1600f))
        }
    }

    // The one-way door. Once `closing` is true this sheet WILL be dismissed: the animation is best
    // effort, the dismissal is not optional.
    LaunchedEffect(closing) {
        if (!closing) return@LaunchedEffect
        try {
            withTimeout(SHEET_EXIT_MS + 120L) {
                offset.animateTo(
                    heightPx.coerceAtLeast(1f),
                    tween(SHEET_EXIT_MS.toInt(), easing = FastOutLinearInEasing)
                )
            }
        } catch (_: Throwable) {
            // Interrupted by another gesture, or the animation never settled. Irrelevant: the sheet
            // goes away either way.
        }
        dismiss.value.invoke()
    }

    Popup(
        alignment = Alignment.TopStart,
        onDismissRequest = { closing = true },
        properties = PopupProperties(
            focusable = !closing,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        val h = heightPx
                        alpha = if (h <= 0f) 0f else (1f - offset.value / h).coerceIn(0f, 1f)
                    }
                    .background(Color.Black.copy(alpha = 0.55f))
                    .then(
                        if (closing) Modifier
                        else Modifier.pointerInput(Unit) { detectTapGestures { closing = true } }
                    )
            )
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .heightIn(max = maxHeight)
                    .graphicsLayer { translationY = offset.value }
                    .onSizeChanged { size ->
                        val measured = size.height.toFloat()
                        // Only the first measurement drives the entry animation; later growth (a
                        // switch flipping, the cache size arriving) must not restart it.
                        if (measured > 0f && !opened) heightPx = measured
                        else if (measured > heightPx) heightPx = measured
                    }
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(p.surface)
                    .draggable(
                        orientation = Orientation.Vertical,
                        enabled = !closing,
                        state = rememberDraggableState { delta ->
                            scope.launch { offset.snapTo((offset.value + delta).coerceAtLeast(0f)) }
                        },
                        onDragStopped = { velocity ->
                            if (offset.value > heightPx * 0.26f || velocity > 900f) closing = true
                            else offset.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 1600f))
                        }
                    )
            ) {
                Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(width = 38.dp, height = 4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(p.subtext.copy(alpha = 0.45f))
                    )
                }
                // Sheets whose body is a lazy list (the queue) opt out of the scrolling container:
                // a LazyColumn inside a verticalScroll fights the parent for every drag and loses
                // its own item recycling in the process.
                if (scrollable) {
                    Column(
                        Modifier
                            .verticalScroll(rememberScrollState())
                            .navigationBarsPadding()
                            .padding(bottom = 26.dp),
                        content = content
                    )
                } else {
                    Column(
                        Modifier
                            .navigationBarsPadding()
                            .padding(bottom = 14.dp),
                        content = content
                    )
                }
            }
        }
    }
}

/** Exit duration of a sheet, in ms. Short enough to feel like a dismissal, not an animation. */
private const val SHEET_EXIT_MS = 150L

/** Far enough down to be off any phone screen on the very first frame, before the sheet is measured. */
private const val OFFSCREEN = 6000f

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Реверб", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$reverb%", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = reverb.toFloat(),
                onValueChange = { reverb = it.roundToInt() },
                onValueChangeFinished = { apply() },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(6.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", current?.let { "Осталось $it мин" } ?: "Выключен")
        listOf(10, 15, 20, 30, 45, 60, 90).forEach { minutes ->
            MenuItem(Icons.Filled.Bedtime, "$minutes минут") { onPick(minutes); onDismiss() }
        }
        if (current != null) {
            MenuItem(Icons.Filled.Close, "Выключить таймер") { onPick(null); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var newName by remember { mutableStateOf("") }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Добавить в плейлист")
        playlists.forEach { playlist ->
            MenuItem(Icons.Filled.QueueMusic, playlist.name) { onPick(playlist.id); onDismiss() }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.accent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* ------------------------------------------------------------------ track menu */

@Composable
fun TrackMenuSheet(
    favorite: Boolean,
    plays: Int,
    sleepMinutesLeft: Int?,
    track: TrackEntity,
    inPlaylist: PlaylistEntity?,
    onDismiss: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit
) {
    val p = LocalPalette.current
    ZiziSheetScaffold(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 20,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(10.dp))
        MenuItem(Icons.Filled.Speed, "Скорость и тональность", onClick = onFx)
        MenuItem(
            if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            if (favorite) "Убрать из избранного" else "В избранное",
            onClick = onToggleFavorite
        )
        MenuItem(Icons.Filled.PlaylistAdd, "Добавить в плейлист", onClick = onAddToPlaylist)
        if (inPlaylist != null) {
            MenuItem(Icons.Filled.PlaylistRemove, "Убрать из «${inPlaylist.name}»", onClick = onRemoveFromPlaylist)
        }
        MenuItem(Icons.Filled.Bedtime, "Таймер сна", trailing = sleepMinutesLeft?.let { "$it мин" }, onClick = onSleep)
        MenuItem(Icons.Filled.Share, "Поделиться файлом", onClick = onShare)
        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(
            Icons.Filled.DeleteOutline,
            "Удалить из приложения",
            tint = Color(0xFFFF8A8A),
            onClick = onHide
        )
        Text(
            "Файл останется на устройстве, трек просто исчезнет из Zizi",
            color = p.subtext,
            fontSize = 11.5.sp,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
        )
        MenuItem(Icons.Filled.DeleteForever, "Удалить файл с устройства", tint = Color(0xFFFF5555), onClick = onDeleteFile)
        Text(
            "${track.sourceFolder} · ${formatTime(track.durationMs)}" + if (plays > 0) " · прослушан $plays раз" else "",
            color = p.subtext,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
        )
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    tracks: List<TrackEntity>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPick: (Int) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        // The queue opens straight at the track that is playing instead of at the top.
        val queueState = rememberLazyListState()
        // Same rule as the library list: while the finger moves, background indexing stands still.
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.isScrollInProgress }.collectLatest { scrolling ->
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
        }
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.firstVisibleItemIndex }.collectLatest { index ->
                app.ziziplayer.ui.components.ArtworkPrefetcher.focusOn(index)
            }
        }
        LaunchedEffect(currentTrackId) {
            val index = tracks.indexOfFirst { it.id == currentTrackId }
            if (index > 1) queueState.scrollToItem((index - 1).coerceAtLeast(0))
        }
        // The reference queue is a full screen list, not a 460 dp window peeking out of the bottom.
        val queueMaxHeight = (LocalConfiguration.current.screenHeightDp * 0.64f).dp
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = queueMaxHeight), state = queueState) {
            itemsIndexed(tracks, key = { _, item -> item.id }) { index, track ->
                val playing = track.id == currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        // 56 dp of fixed height, 48 dp cover: the same metrics as the library list and
                        // as the reference. A fixed height also means the list never re-measures a row
                        // while scrolling.
                        .height(56.dp)
                        .clickable { onPick(index) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                        )
                        if (playing) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.48f)))
                            EqualizerBars(p.accent, isPlaying, Modifier.size(17.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

/**
 * A titled card. The old settings screen was one flat stream of 14 rows, dividers and radio
 * buttons - everything at the same visual weight, which is exactly why it read as "thrown
 * together". Now every row lives in a group with a heading, and the group is a card.
 */
@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        text = title.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 26.dp, top = 16.dp, bottom = 8.dp)
    )
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.chip.copy(alpha = 0.38f))
            .padding(vertical = 4.dp),
        content = content
    )
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    label: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: Color? = null,
    onClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) {
                Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, label: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    SettingRow(
        icon = icon,
        label = label,
        subtitle = subtitle,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }
    )
}

@Composable
fun SettingsSheet(vm: MainViewModel, state: LibraryUiState, onDismiss: () -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val themeNames = remember {
        mapOf(
            AppTheme.GRAPHITE to "Графит",
            AppTheme.MIDNIGHT to "Полночь",
            AppTheme.AMOLED to "AMOLED",
            AppTheme.SUNSET to "Закат"
        )
    }
    val sortNames = remember {
        mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
    }

    // Cover cache size, read once when the sheet opens - never from composition.
    var cacheLabel by remember { mutableStateOf<String?>(null) }
    var cacheVersion by remember { mutableIntStateOf(0) }
    LaunchedEffect(cacheVersion) {
        val bytes = withContext(Dispatchers.IO) { ArtworkCache.cacheBytes() }
        cacheLabel = if (bytes < 1024L * 1024L) "${(bytes / 1024L)} КБ" else "${bytes / (1024L * 1024L)} МБ"
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Настройки", "${state.tracks.size} треков в библиотеке")

        SettingsGroup("Воспроизведение") {
            SettingSwitch(
                icon = Icons.Filled.GraphicEq,
                label = "Пропускать тишину",
                subtitle = "Убирает паузы в начале и в конце трека",
                checked = state.settings.skipSilence,
                onChange = vm::setSkipSilence
            )
        }

        SettingsGroup("Оформление") {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppTheme.entries.forEach { theme ->
                    val active = state.settings.theme == theme
                    val preview = remember(theme) { basePalette(theme) }
                    Column(
                        Modifier
                            .width(76.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) p.accent.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable { vm.setTheme(theme) }
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(preview.background)
                                .then(
                                    if (active) Modifier.border(1.5.dp, p.accent, RoundedCornerShape(10.dp))
                                    else Modifier
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            themeNames[theme] ?: theme.name,
                            color = if (active) p.accent else p.subtext,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }
            }
            SettingSwitch(
                icon = Icons.Filled.Palette,
                label = "Цвет из обложки",
                subtitle = "Фон повторяет оттенки текущей обложки",
                checked = state.settings.accentFromArtwork,
                onChange = vm::setDynamicAccent
            )
        }

        SettingsGroup("Библиотека") {
            // Sorting was a row that opened a list of five more rows: two taps and a jumping layout
            // for something you change in one gesture. Now it is a chip strip - one tap, no reflow.
            SettingRow(
                icon = Icons.Filled.SortByAlpha,
                label = "Сортировка",
                subtitle = sortNames[state.settings.sortMode]
            )
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SortMode.entries.forEach { mode ->
                    PillChip(
                        label = sortNames[mode] ?: mode.name,
                        icon = null,
                        active = state.settings.sortMode == mode,
                        palette = ChipColors(p.chip, p.subtext, p.accent, p.onAccent),
                        onClick = { vm.setSortMode(mode) }
                    )
                }
            }
            SettingRow(
                icon = Icons.Filled.CreateNewFolder,
                label = "Добавить папку с музыкой",
                subtitle = if (state.settings.folderUris.isEmpty()) "Ничего не подключено"
                else "Подключено: ${state.settings.folderUris.size}",
                onClick = onPickFolder
            )
            state.settings.folderUris.forEach { uri ->
                Row(
                    Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uri.substringAfterLast("/").ifBlank { uri },
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { vm.removeFolder(uri) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Close, null, tint = p.subtext, modifier = Modifier.size(16.dp)) }
                }
            }
            SettingRow(
                icon = Icons.Filled.Refresh,
                label = "Пересканировать",
                subtitle = if (state.scanning) "Идёт сканирование…" else "Найдено ${state.tracks.size} треков",
                onClick = vm::rescan
            )
            if (state.hiddenCount > 0) {
                SettingRow(
                    icon = Icons.Filled.Visibility,
                    label = "Вернуть скрытые треки",
                    subtitle = "Скрыто: ${state.hiddenCount}",
                    onClick = vm::restoreAllHidden
                )
            }
        }

        SettingsGroup("Данные") {
            SettingRow(
                icon = Icons.Filled.Storage,
                label = "Кэш обложек",
                subtitle = cacheLabel?.let { "Занято $it · нажми, чтобы очистить" } ?: "Считаем…",
                onClick = {
                    scope.launch {
                        ArtworkCache.clearCache()
                        cacheVersion++
                    }
                }
            )
        }

        SettingsGroup("О приложении") {
            SettingRow(
                icon = Icons.Filled.Info,
                label = "ZiziPlayer",
                subtitle = "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · Media3 · Compose"
            )
        }
        Spacer(Modifier.height(6.dp))
    }
}

/* ------------------------------------------------------------------ confirm */

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    title: String = "Переименовать",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.accent,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Готово", color = p.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}
