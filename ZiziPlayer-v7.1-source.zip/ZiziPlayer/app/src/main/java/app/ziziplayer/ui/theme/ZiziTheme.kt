package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import app.ziziplayer.data.AppTheme
import app.ziziplayer.ui.components.ArtSwatches
import kotlinx.coroutines.launch

/**
 * Seven vertical stops built from five cover shades, plus a separate glow colour.
 *
 * A cover is not one colour. The reference players build the backdrop out of several shades of the
 * same artwork - deep at the very top, opening up behind the cover, brightest behind the title and
 * the controls, closing down again at the bottom bar. Measuring the reference screenshot gives
 * value 0.10 -> 0.26 and saturation around 0.3: dark and quiet. v5 lit the top stop up to value
 * 0.42 with almost no cap on saturation, which is why a warm cover turned the whole screen muddy
 * brown instead of looking like the artwork.
 */
@Immutable
data class ZiziPalette(
    val top: Color,
    val upper: Color,
    val upperMid: Color,
    val middle: Color,
    val lower: Color,
    val lowerMid: Color,
    val bottom: Color,
    val glow: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    val tintStrength: Float
) {
    /**
     * Stop positions are lifted straight off the reference: brightness climbs from 0.05 at the
     * status bar to a peak of 0.24 at 0.67 of the height - behind the controls, not behind the
     * cover - and closes back down to 0.13 at the bottom bar. v6.1 put the peak at 0.80 and lit the
     * very top stop to 0.135, which is why the screen read as "tinted dark grey" instead of as the
     * cover itself.
     */
    val background: Brush
        get() = Brush.verticalGradient(
            0f to top,
            0.16f to upper,
            0.34f to upperMid,
            0.50f to middle,
            0.67f to lower,
            0.83f to lowerMid,
            1f to bottom
        )
}

private val Graphite = ZiziPalette(
    top = Color(0xFF14161A),
    upper = Color(0xFF1A1C20),
    upperMid = Color(0xFF1F2226),
    middle = Color(0xFF23262B),
    lower = Color(0xFF282C31),
    lowerMid = Color(0xFF1C1F23),
    bottom = Color(0xFF0B0C0E),
    glow = Color(0xFF3C4550),
    surface = Color(0xFF1D1F23),
    chip = Color(0xFF2C2F34),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF8FD3FF),
    onAccent = Color(0xFF06121A),
    tintStrength = 1f
)

private val Midnight = Graphite.copy(
    top = Color(0xFF090C16),
    upper = Color(0xFF101728),
    upperMid = Color(0xFF161F36),
    middle = Color(0xFF1A2440),
    lower = Color(0xFF1F2B4C),
    lowerMid = Color(0xFF141B2E),
    bottom = Color(0xFF06080F),
    glow = Color(0xFF31406E),
    surface = Color(0xFF161E33),
    chip = Color(0xFF223054),
    accent = Color(0xFF9EB8FF),
    tintStrength = 0.92f
)

private val Amoled = Graphite.copy(
    top = Color(0xFF000000),
    upper = Color(0xFF070707),
    upperMid = Color(0xFF0C0C0C),
    middle = Color(0xFF101010),
    lower = Color(0xFF141414),
    lowerMid = Color(0xFF090909),
    bottom = Color(0xFF000000),
    glow = Color(0xFF1C1C1C),
    surface = Color(0xFF121212),
    chip = Color(0xFF1E1E1E),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000),
    tintStrength = 0.45f
)

private val Sunset = Graphite.copy(
    top = Color(0xFF130A0E),
    upper = Color(0xFF1F1218),
    upperMid = Color(0xFF2A181F),
    middle = Color(0xFF321C25),
    lower = Color(0xFF3B212B),
    lowerMid = Color(0xFF23141A),
    bottom = Color(0xFF0C0608),
    glow = Color(0xFF5C3340),
    surface = Color(0xFF291921),
    chip = Color(0xFF3E242D),
    accent = Color(0xFFFFA36B),
    onAccent = Color(0xFF25100A),
    tintStrength = 1f
)

fun basePalette(theme: AppTheme): ZiziPalette = when (theme) {
    AppTheme.GRAPHITE -> Graphite
    AppTheme.MIDNIGHT -> Midnight
    AppTheme.AMOLED -> Amoled
    AppTheme.SUNSET -> Sunset
}

val LocalPalette = compositionLocalOf { Graphite }

/** Perceptual luminance, used only to decide whether text on the accent must be dark or light. */
private fun Color.luminance(): Float = 0.299f * red + 0.587f * green + 0.114f * blue

/**
 * The measured backdrop.
 *
 * Sampled off the reference player, left edge, one column of pixels from the status bar down to the
 * bottom bar, converted to Oklch:
 *
 *   y      0.03   0.07   0.12   0.30   0.40   0.52   0.62   0.70   0.80   0.90
 *   L      0.124  0.161  0.199  0.254  0.278  0.305  0.334  0.342  0.294  0.234
 *   C     0.0105 0.0115 0.0174 0.0251 0.0273 0.0295 0.0346 0.0344 0.0290 0.0182
 *   hue     134    151    145    149    145    141    140    140    139    142
 *
 * Three facts fall out of that table, and v7.0 got all three wrong:
 *
 * 1. The hue is CONSTANT - it moves by five degrees over the entire screen, and it is the hue of the
 *    cover (149 deg). v7.0 built seven stops out of five different swatches, so on the sunflower
 *    cover the backdrop hue crawled 65 -> 83 -> 108 -> 136 -> 161 from top to bottom: brown at the
 *    title, green at the controls. That is the "in some zone it looks awful" part.
 * 2. Chroma is not a constant either - it tracks lightness, C = 0.104 x L. Dark bands are almost
 *    grey, the bright band under the controls carries the colour. A flat saturation cap cannot do
 *    that.
 * 3. The lightness ramp peaks at 67 % of the height, at L = 0.334 - a good deal brighter than the
 *    0.24 HSV value v7.0 aimed for.
 */
private val RAMP_L = floatArrayOf(0.125f, 0.185f, 0.245f, 0.290f, 0.334f, 0.292f, 0.228f)

fun ZiziPalette.tintedWith(swatches: ArtSwatches?): ZiziPalette {
    val strength = tintStrength
    if (swatches == null || strength <= 0.01f) return this
    val cover = coverHue(
        listOf(swatches.vivid, swatches.primary, swatches.secondary, swatches.light, swatches.deep)
    ) ?: return this
    val hue = cover.first
    val peakChroma = cover.second

    // How colourful the screen is allowed to get. The reference cover peaks at C = 0.048 and its
    // backdrop lands on 0.104 x L, which is exactly what this line returns for it. A neon cover is
    // clamped at 0.140: past that a dark band stops reading as "the cover" and starts reading as a
    // colour filter over the app.
    val k = (0.085f + peakChroma * 0.42f).coerceIn(0.085f, 0.140f)

    // Every theme keeps its own darkness. AMOLED sits at L 0.17, Graphite at 0.30, so the ramp is
    // scaled by the theme's own middle stop instead of being hard-coded to the reference.
    val scale = (middle.toOklch().l / 0.290f).coerceIn(0.45f, 1.20f)

    fun stop(index: Int, base: Color, mix: Float): Color {
        val l = RAMP_L[index] * scale
        return lerp(base, oklch(l, k * l * strength, hue), mix * strength)
    }

    return copy(
        top = stop(0, top, 0.96f),
        upper = stop(1, upper, 0.96f),
        upperMid = stop(2, upperMid, 0.95f),
        middle = stop(3, middle, 0.95f),
        lower = stop(4, lower, 0.95f),
        lowerMid = stop(5, lowerMid, 0.94f),
        bottom = stop(6, bottom, 0.92f),
        // The halo behind the cover: same hue, three times the chroma, bright enough to be seen
        // through a 12 % alpha wash.
        glow = lerp(glow, oklch(0.66f * scale.coerceAtLeast(0.7f), (k * 2.9f).coerceAtMost(0.15f), hue), 0.95f * strength),
        // Surfaces sit one step above the brightest band so a sheet never disappears into the
        // backdrop, and chips one step above that.
        surface = lerp(surface, oklch(0.255f * scale, k * 0.255f * 1.15f * strength, hue), 0.88f * strength),
        chip = lerp(chip, oklch(0.335f * scale, k * 0.335f * 1.25f * strength, hue), 0.85f * strength),
        // Text stays text: a whisper of the cover hue, nothing that costs contrast.
        text = lerp(text, oklch(0.965f, 0.010f, hue), 0.55f * strength),
        subtext = lerp(subtext, oklch(0.700f, 0.018f, hue), 0.60f * strength)
    )
}

/**
 * The accent is the one place where the cover is allowed to be loud: it comes from the single most
 * colourful swatch, pinned to L 0.80 so a dark cover still produces a visible accent and a neon one
 * does not glare.
 */
fun ZiziPalette.withAccent(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null) return this
    val source = listOf(swatches.vivid, swatches.primary, swatches.light, swatches.secondary)
        .map { it.toOklch() }
        .maxByOrNull { if (it.l < 0.05f || it.l > 0.98f) -1f else it.c } ?: return this
    if (source.c < 0.012f) return this
    val bright = oklch(0.800f, (source.c * 1.10f).coerceIn(0.055f, 0.165f), source.h)
    return copy(accent = bright, onAccent = if (bright.luminance() > 0.55f) Color(0xFF0B0B0C) else Color.White)
}

/**
 * The gradient is animated in the DRAW phase only: the Animatable values are read inside
 * drawBehind, so a track change costs a repaint, never a recomposition of the tree.
 *
 * [glowAlpha] adds the radial highlight sitting behind the cover - that is what makes the artwork
 * colour look like it spilled over the whole screen. The library gets a faint one, the player a
 * strong one.
 */
@Composable
fun ZiziBackdrop(
    palette: ZiziPalette,
    modifier: Modifier = Modifier,
    durationMs: Int = 480,
    glowAlpha: Float = 0f,
    glowCenter: Float = 0.30f
) {
    val top = remember { Animatable(palette.top) }
    val upper = remember { Animatable(palette.upper) }
    val upperMid = remember { Animatable(palette.upperMid) }
    val middle = remember { Animatable(palette.middle) }
    val lower = remember { Animatable(palette.lower) }
    val lowerMid = remember { Animatable(palette.lowerMid) }
    val bottom = remember { Animatable(palette.bottom) }
    val glow = remember { Animatable(palette.glow) }
    LaunchedEffect(palette) {
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(palette.top, spec) }
        launch { upper.animateTo(palette.upper, spec) }
        launch { upperMid.animateTo(palette.upperMid, spec) }
        launch { middle.animateTo(palette.middle, spec) }
        launch { lower.animateTo(palette.lower, spec) }
        launch { lowerMid.animateTo(palette.lowerMid, spec) }
        launch { bottom.animateTo(palette.bottom, spec) }
        launch { glow.animateTo(palette.glow, spec) }
    }
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to top.value,
                        0.16f to upper.value,
                        0.34f to upperMid.value,
                        0.50f to middle.value,
                        0.67f to lower.value,
                        0.83f to lowerMid.value,
                        1f to bottom.value
                    )
                )
                if (glowAlpha > 0.01f) {
                    // ONE wash, behind the cover. v7.0 added a second one under the controls to
                    // fake the reference's bright band - but that band is part of the lightness
                    // ramp now, and two overlapping radials on top of it were what pushed warm
                    // covers into glare.
                    val tint = glow.value
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(
                                tint.copy(alpha = glowAlpha),
                                tint.copy(alpha = glowAlpha * 0.38f),
                                tint.copy(alpha = 0f)
                            ),
                            center = Offset(size.width * 0.5f, size.height * glowCenter),
                            radius = size.width * 1.05f
                        )
                    )
                }
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = Typography(),
        content = content
    )
}
