package app.ziziplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring

/**
 * The transport icons, drawn instead of imported.
 *
 * Material's `Icons.Filled.Shuffle` / `Repeat` / `SkipNext` are 24 x 24 glyphs with square caps and a
 * ~2.4 dp stem. Measured against the reference player they are the wrong shape and the wrong size,
 * which is the whole reason the row read as "close, but not it":
 *
 *   glyph            reference (dp)      Material at v7.0 sizes
 *   shuffle          18.8 x 14.4         24 x 24, square caps
 *   skip prev/next   16.9 x 18.8         34 x 34
 *   pause bars       2 x 12.5, h 33.8    52 x 52 box, ~14 dp bars
 *   repeat           18.8 x 18.8         24 x 24, square caps
 *
 * (Scale: the reference screenshots are 576 px captures of a 1080 px screen at density 3, so one
 * screenshot pixel is 0.625 dp. Every number above is a bounding box measured off the pixels, not an
 * eyeballed guess.)
 *
 * Each glyph is a `Path` built once per size inside `drawWithCache` - no `ImageVector` parsing, no
 * vector tree, no per-frame allocation, and round caps and joins that actually match the reference.
 */
fun interface Glyph {
    /** Builds the glyph inside a box of [size]. Stroked glyphs are returned as paths. */
    fun build(size: Size): Path
}

private fun path(block: Path.() -> Unit): Path = Path().apply(block)

object PlayerGlyphs {

    /** Two crossing arrows. Wider than tall, exactly as in the reference. */
    val Shuffle = Glyph { s ->
        val w = s.width
        val h = s.height
        path {
            // upper strand: enters top left, dives to the bottom right
            moveTo(0.03f * w, 0.17f * h)
            lineTo(0.20f * w, 0.17f * h)
            cubicTo(0.36f * w, 0.17f * h, 0.42f * w, 0.40f * h, 0.52f * w, 0.58f * h)
            cubicTo(0.62f * w, 0.76f * h, 0.70f * w, 0.83f * h, 0.86f * w, 0.83f * h)
            // lower strand: enters bottom left, climbs to the top right, broken in the middle so the
            // two arrows read as crossing instead of touching
            moveTo(0.03f * w, 0.83f * h)
            lineTo(0.20f * w, 0.83f * h)
            cubicTo(0.32f * w, 0.83f * h, 0.38f * w, 0.68f * h, 0.44f * w, 0.56f * h)
            moveTo(0.58f * w, 0.42f * h)
            cubicTo(0.66f * w, 0.28f * h, 0.72f * w, 0.17f * h, 0.86f * w, 0.17f * h)
            // arrow heads, open chevrons
            moveTo(0.76f * w, 0.02f * h)
            lineTo(0.97f * w, 0.17f * h)
            lineTo(0.76f * w, 0.32f * h)
            moveTo(0.76f * w, 0.68f * h)
            lineTo(0.97f * w, 0.83f * h)
            lineTo(0.76f * w, 0.98f * h)
        }
    }

    /** Rounded loop with two chevrons. Square bounding box. */
    val Repeat = Glyph { s -> repeatPath(s, one = false) }

    /** The same loop with a numeral one in the middle - "repeat this track". */
    val RepeatOne = Glyph { s -> repeatPath(s, one = true) }

    private fun repeatPath(s: Size, one: Boolean): Path {
        val w = s.width
        val h = s.height
        return path {
            // top run, left corner rounded, ending in a right pointing chevron
            moveTo(0.06f * w, 0.50f * h)
            lineTo(0.06f * w, 0.34f * h)
            cubicTo(0.06f * w, 0.24f * h, 0.13f * w, 0.19f * h, 0.22f * w, 0.19f * h)
            lineTo(0.70f * w, 0.19f * h)
            moveTo(0.73f * w, 0.04f * h)
            lineTo(0.95f * w, 0.19f * h)
            lineTo(0.73f * w, 0.34f * h)
            // bottom run, mirrored
            moveTo(0.94f * w, 0.50f * h)
            lineTo(0.94f * w, 0.66f * h)
            cubicTo(0.94f * w, 0.76f * h, 0.87f * w, 0.81f * h, 0.78f * w, 0.81f * h)
            lineTo(0.30f * w, 0.81f * h)
            moveTo(0.27f * w, 0.66f * h)
            lineTo(0.05f * w, 0.81f * h)
            lineTo(0.27f * w, 0.96f * h)
            if (one) {
                moveTo(0.40f * w, 0.46f * h)
                lineTo(0.50f * w, 0.38f * h)
                lineTo(0.50f * w, 0.64f * h)
            }
        }
    }

    /** Solid triangle plus a bar, 0.9 aspect. */
    val SkipNext = Glyph { s ->
        val w = s.width
        val h = s.height
        path {
            moveTo(0f, 0f)
            lineTo(0.70f * w, 0.5f * h)
            lineTo(0f, h)
            close()
            moveTo(0.80f * w, 0f)
            lineTo(w, 0f)
            lineTo(w, h)
            lineTo(0.80f * w, h)
            close()
        }
    }

    val SkipPrevious = Glyph { s ->
        val w = s.width
        val h = s.height
        path {
            moveTo(w, 0f)
            lineTo(0.30f * w, 0.5f * h)
            lineTo(w, h)
            close()
            moveTo(0f, 0f)
            lineTo(0.20f * w, 0f)
            lineTo(0.20f * w, h)
            lineTo(0f, h)
            close()
        }
    }

    /** Triangle with the reference's slightly softened tips. */
    val Play = Glyph { s ->
        val w = s.width
        val h = s.height
        path {
            moveTo(0.06f * w, 0.02f * h)
            lineTo(0.98f * w, 0.5f * h)
            lineTo(0.06f * w, 0.98f * h)
            close()
        }
    }
}

/**
 * A tappable glyph.
 *
 * [box] is the touch target, [glyphWidth] x [glyphHeight] the drawn size - the two are deliberately
 * separate: the reference draws an 18.8 dp shuffle inside a 44 dp target, and a control you can
 * actually hit is worth more than a control that looks tidy in the layout inspector.
 *
 * The press spring lives in `graphicsLayer`, so pressing a button repaints one layer instead of
 * recomposing the transport row.
 */
@Composable
fun GlyphButton(
    glyph: Glyph,
    tint: Color,
    box: Dp,
    glyphWidth: Dp,
    glyphHeight: Dp,
    filled: Boolean,
    onClick: () -> Unit,
    strokeWidth: Dp = 1.9.dp,
    modifier: Modifier = Modifier
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 2600f),
        label = "glyph-press"
    )
    Box(
        modifier
            .size(box)
            .clip(RoundedCornerShape(percent = 50))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(glyphWidth, glyphHeight)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .drawWithCache {
                    val stroke = strokeWidth.toPx()
                    // Stroked glyphs are inset by half the stroke so the drawn shape matches the
                    // measured bounding box instead of overflowing it by a pixel on each side.
                    val inner = if (filled) size else Size(
                        (size.width - stroke).coerceAtLeast(1f),
                        (size.height - stroke).coerceAtLeast(1f)
                    )
                    val built = glyph.build(inner)
                    val shift = if (filled) 0f else stroke / 2f
                    val style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    onDrawBehind {
                        if (filled) {
                            drawPath(built, tint)
                        } else {
                            translate(shift, shift) { drawPath(built, tint, style = style) }
                        }
                    }
                }
        )
    }
}

/**
 * Play / pause as one component so the two states share a touch target and swap without a layout
 * pass. The pause bars are round rects - 12.5 dp wide, 33.8 dp tall, 6.25 dp apart, straight off the
 * reference - and drawing them directly avoids a 52 dp Material glyph pretending to be them.
 */
@Composable
fun PlayPauseGlyph(
    isPlaying: Boolean,
    tint: Color,
    box: Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 2600f),
        label = "playpause-press"
    )
    Box(
        modifier
            .size(box)
            .clip(RoundedCornerShape(percent = 50))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(width = 30.dp, height = 34.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .drawWithCache {
                    val barWidth = size.width * 0.417f
                    val radius = CornerRadius(barWidth * 0.34f, barWidth * 0.34f)
                    val playPath = PlayerGlyphs.Play.build(Size(size.width * 0.92f, size.height))
                    onDrawBehind {
                        if (isPlaying) {
                            drawRoundRect(
                                color = tint,
                                topLeft = Offset.Zero,
                                size = Size(barWidth, size.height),
                                cornerRadius = radius
                            )
                            drawRoundRect(
                                color = tint,
                                topLeft = Offset(size.width - barWidth, 0f),
                                size = Size(barWidth, size.height),
                                cornerRadius = radius
                            )
                        } else {
                            drawPath(playPath, tint)
                        }
                    }
                }
        )
    }
}
