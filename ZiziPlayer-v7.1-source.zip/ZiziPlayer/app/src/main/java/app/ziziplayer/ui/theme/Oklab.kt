package app.ziziplayer.ui.theme

import androidx.compose.ui.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * Oklch: the colour space the backdrop is built in.
 *
 * HSV was the wrong tool and it is why v7.0 looked wrong on warm covers. In HSV, "value 0.24,
 * saturation 0.30" means something completely different for a yellow hue than for a blue one: dark
 * yellow at fixed HSV value is olive mud, dark blue at the same numbers is a clean navy. Every
 * screenshot where the tint "sat down in some zone and looked awful" was that: a yellow cover
 * mapped onto an HSV ramp.
 *
 * Oklch is perceptually uniform - L really is lightness, C really is colourfulness - so one ramp
 * produces an equally clean screen for every hue on the wheel. Measurements off the reference
 * player (Cinematic Asia, green cover) come out as: L climbing 0.124 -> 0.334 with the peak at 67 %
 * of the height, chroma tracking lightness at C = 0.104 x L, and a hue that never moves more than
 * 5 degrees over the whole screen.
 */
internal data class Oklch(val l: Float, val c: Float, val h: Float)

private fun srgbToLinear(v: Float): Float =
    if (v <= 0.04045f) v / 12.92f else ((v + 0.055f) / 1.055f).pow(2.4f)

private fun linearToSrgb(v: Float): Float =
    if (v <= 0.0031308f) v * 12.92f else 1.055f * v.pow(1f / 2.4f) - 0.055f

private fun cbrtf(v: Float): Float =
    if (v < 0f) -((-v).toDouble().pow(1.0 / 3.0)).toFloat() else v.toDouble().pow(1.0 / 3.0).toFloat()

internal fun Color.toOklch(): Oklch {
    val r = srgbToLinear(red)
    val g = srgbToLinear(green)
    val b = srgbToLinear(blue)
    val l = cbrtf(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b)
    val m = cbrtf(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b)
    val s = cbrtf(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b)
    val lightness = 0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s
    val a = 1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s
    val bb = 0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s
    var hue = Math.toDegrees(atan2(bb, a).toDouble()).toFloat()
    if (hue < 0f) hue += 360f
    return Oklch(lightness, hypot(a, bb), hue)
}

/** Raw Oklab -> linear sRGB. Returns the three channels, possibly out of gamut. */
private fun oklabChannels(l: Float, a: Float, b: Float, out: FloatArray) {
    val l_ = l + 0.3963377774f * a + 0.2158037573f * b
    val m_ = l - 0.1055613458f * a - 0.0638541728f * b
    val s_ = l - 0.0894841775f * a - 1.2914855480f * b
    val l3 = l_ * l_ * l_
    val m3 = m_ * m_ * m_
    val s3 = s_ * s_ * s_
    out[0] = 4.0767416621f * l3 - 3.3077115913f * m3 + 0.2309699292f * s3
    out[1] = -1.2684380046f * l3 + 2.6097574011f * m3 - 0.3413193965f * s3
    out[2] = -0.0041960863f * l3 - 0.7034186147f * m3 + 1.7076147010f * s3
}

/**
 * Oklch -> sRGB with gamut mapping.
 *
 * Chroma is walked down until the colour fits inside sRGB instead of being clipped per channel:
 * clipping shifts the hue, which is exactly what you see as "the colour changes as the screen gets
 * darker". Lightness and hue are preserved, colourfulness gives way - the same trade CSS Color 4
 * makes.
 */
internal fun oklch(l: Float, c: Float, h: Float): Color {
    val lightness = l.coerceIn(0f, 1f)
    val rad = Math.toRadians(h.toDouble()).toFloat()
    val ca = cos(rad)
    val cb = sin(rad)
    val channels = FloatArray(3)
    var chroma = c.coerceAtLeast(0f)
    var steps = 0
    while (steps < 14) {
        oklabChannels(lightness, chroma * ca, chroma * cb, channels)
        if (channels[0] >= -0.001f && channels[0] <= 1.001f &&
            channels[1] >= -0.001f && channels[1] <= 1.001f &&
            channels[2] >= -0.001f && channels[2] <= 1.001f
        ) break
        chroma *= 0.80f
        steps++
    }
    return Color(
        linearToSrgb(channels[0].coerceIn(0f, 1f)),
        linearToSrgb(channels[1].coerceIn(0f, 1f)),
        linearToSrgb(channels[2].coerceIn(0f, 1f))
    )
}

/**
 * One hue for the whole screen, taken from the cover.
 *
 * Averaged as a vector on the hue circle so that 350 deg and 10 deg average to 0 and not to 180, and
 * weighted by chroma squared so a nearly grey shade cannot drag the hue of a colourful cover.
 * Near-black and near-white swatches are dropped: their hue is numerical noise.
 *
 * Returns the hue plus the strongest chroma found, which is what sets how colourful the backdrop is
 * allowed to be.
 */
internal fun coverHue(colors: List<Color>): Pair<Float, Float>? {
    var x = 0f
    var y = 0f
    var weight = 0f
    var peak = 0f
    for (color in colors) {
        val (l, c, h) = color.toOklch()
        if (l < 0.045f || l > 0.985f) continue
        val w = c * c
        val rad = Math.toRadians(h.toDouble()).toFloat()
        x += cos(rad) * w
        y += sin(rad) * w
        weight += w
        if (c > peak) peak = c
    }
    if (weight <= 1e-6f || peak < 0.012f) return null
    var hue = Math.toDegrees(atan2(y, x).toDouble()).toFloat()
    if (hue < 0f) hue += 360f
    return hue to peak
}
