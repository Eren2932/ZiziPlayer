// `java` внутри build.gradle.kts — это аксессор расширения Gradle, а не корневой пакет JDK,
// поэтому java.security.MessageDigest не компилировался. Импорт снимает двусмысленность.
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "app.ziziplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.ziziplayer"
        minSdk = 26
        targetSdk = 35
        versionCode = 58
        versionName = "6.29.3"

        /**
         * Innertube's public web key.
         *
         * It is not a secret and it is not tied to any account - the YouTube Music web app ships it
         * to every visitor - but it is still kept out of the source and injected here, so that it
         * can be overridden per build (`-PinnertubeKey=...` or the INNERTUBE_KEY environment
         * variable) the day YouTube rotates it, without touching code or waiting for a release.
         */
        val innertubeKey = (project.findProperty("innertubeKey") as String?)
            ?: System.getenv("INNERTUBE_KEY")
            ?: "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
        buildConfigField("String", "INNERTUBE_KEY", "\"" + innertubeKey + "\"")

        // Off-screen WebView -> JS bridge -> OkHttp session integration. Keep the URL empty to
        // disable it. Production builds should inject these values from CI/gradle.properties.
        fun quoted(value: String): String = "\"" + value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"") + "\""
        val sessionBootstrapUrl = (project.findProperty("sessionBootstrapUrl") as String?)
            ?: System.getenv("SESSION_BOOTSTRAP_URL") ?: ""
        val sessionUserAgent = (project.findProperty("sessionUserAgent") as String?)
            ?: System.getenv("SESSION_USER_AGENT")
            ?: "Mozilla/5.0 (Linux; Android 14; CustomDevice) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        val sessionHeader = (project.findProperty("sessionTokenHeader") as String?)
            ?: System.getenv("SESSION_TOKEN_HEADER") ?: "X-Session-Payload"
        val sessionHosts = (project.findProperty("sessionProtectedHosts") as String?)
            ?: System.getenv("SESSION_PROTECTED_HOSTS") ?: ""
        val sessionWaitMs = ((project.findProperty("sessionTokenWaitMs") as String?)
            ?: System.getenv("SESSION_TOKEN_WAIT_MS"))?.toLongOrNull() ?: 12_000L
        buildConfigField("String", "SESSION_BOOTSTRAP_URL", quoted(sessionBootstrapUrl))
        buildConfigField("String", "SESSION_USER_AGENT", quoted(sessionUserAgent))
        buildConfigField("String", "SESSION_TOKEN_HEADER", quoted(sessionHeader))
        buildConfigField("String", "SESSION_PROTECTED_HOSTS", quoted(sessionHosts))
        buildConfigField("long", "SESSION_TOKEN_WAIT_MS", sessionWaitMs.toString() + "L")

        /**
         * 6.11.0 — resolver baked into the build.
         *
         * Up to 6.10.2 every user had to type the server address and the token by hand, which is
         * absurd for a player: those two values are infrastructure, not preferences. They are now
         * injected at build time and the whole technical part of the settings screen is hidden
         * (see Sheets.kt, DEV UNLOCK).
         *
         * The token is deliberately NOT in the repository: the repo is public, and a token in it
         * is a public token. CI passes it through the RESOLVER_TOKEN secret. A build without that
         * secret still works - it just leaves the resolver rows visible so the address can be
         * typed manually, exactly as before.
         *
         *   ./gradlew assembleRelease -PresolverUrl=1.2.3.4:8080 -PresolverToken=xxxx
         */
        val resolverUrl = (project.findProperty("resolverUrl") as String?)
            ?: System.getenv("RESOLVER_URL") ?: "147.45.166.244:8080"
        val resolverToken = (project.findProperty("resolverToken") as String?)
            ?: System.getenv("RESOLVER_TOKEN") ?: ""
        val resolverProxy = ((project.findProperty("resolverProxy") as String?)
            ?: System.getenv("RESOLVER_PROXY"))?.toBoolean() ?: true
        /**
         * 6.17.0 — служебный доступ (бывший «режим отладки»).
         *
         * До 6.17.0 технические строки открывались семью тапами по строке «О приложении». Тестер
         * открыл их случайно, и это не его вина: семь тапов подряд по одной строке человек делает
         * сам, из любопытства, а дальше ему видны адрес резолвера, длина токена и диагностика.
         *
         * Теперь тайна не в жесте, а в коде. В сборку кладётся ТОЛЬКО SHA-256 от кодовой фразы,
         * посчитанный здесь же; сама фраза не попадает ни в репозиторий, ни в APK:
         *
         *   ./gradlew assembleRelease -PdevUnlockCode=...   (или DEV_UNLOCK_CODE в окружении)
         *
         * Сборка без фразы и с вшитым токеном резолвера не имеет служебного доступа вообще —
         * это правильное состояние для релиза. Локальная сборка без токена работает как раньше.
         */
        val devUnlockCode = (project.findProperty("devUnlockCode") as String?)
            ?: System.getenv("DEV_UNLOCK_CODE") ?: ""
        val devUnlockHash = if (devUnlockCode.isBlank()) "" else
            MessageDigest.getInstance("SHA-256")
                .digest(("zizi-dev-v1:" + devUnlockCode.trim()).toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        buildConfigField("String", "DEV_UNLOCK_HASH", quoted(devUnlockHash))

        buildConfigField("String", "RESOLVER_URL", quoted(resolverUrl))
        buildConfigField("String", "RESOLVER_TOKEN", quoted(resolverToken))
        buildConfigField("boolean", "RESOLVER_PROXY", resolverProxy.toString())
    }

    signingConfigs {
        // isNullOrBlank, not != null: GitHub Actions hands over an unset secret as an EMPTY string,
        // and file("") makes Gradle die with a message that has nothing to do with signing.
        val storePath = System.getenv("SIGNING_STORE_FILE")
        if (!storePath.isNullOrBlank() && file(storePath).exists()) create("release") {
            storeFile = file(storePath)
            storePassword = System.getenv("SIGNING_STORE_PASSWORD")
            keyAlias = System.getenv("SIGNING_KEY_ALIAS")
            keyPassword = System.getenv("SIGNING_KEY_PASSWORD")
        }
    }
    buildTypes {
        release {
            // Signed with the release key when CI provides one, otherwise with the debug key so
            // the optimised build can still be installed straight from the artifact.
            //
            // 6.18.0: молчаливый откат на debug-ключ убран — теперь он кричит в лог. Ревью
            // предлагало ронять сборку, но это сломало бы ровно то, ради чего откат и сделан:
            // APK из ветки, который ставится на телефон без секретов. Тихая подмена ключа опаснее
            // самой подмены: такой APK не встанет поверх релизного, и понять это можно только по
            // ошибке установки. Одна заметная строка в логе решает проблему, ничего не ломая.
            val releaseSigning = signingConfigs.findByName("release")
            if (releaseSigning == null) {
                logger.warn(
                    "ZiziPlayer: релизный ключ не найден (SIGNING_STORE_FILE пуст) — APK будет " +
                        "подписан DEBUG-ключом. Поверх релизной установки он не встанет. " +
                        "Для настоящего релиза заведи секреты подписи."
                )
            }
            signingConfig = releaseSigning ?: signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

// Schema history is required to write real migrations instead of wiping user data.
ksp { arg("room.schemaLocation", "$projectDir/schemas") }


dependencies {
    // 6.19.0: тесты. До этой версии в проекте не было ни одного, и «не сломалось ли» проверялось
    // только руками на телефоне. Здесь только JVM-тесты (никакого Robolectric и никакого
    // androidTest): они гоняются за секунды командой `./gradlew testDebugUnitTest` и покрывают то,
    // что не требует Android — вычисление идентичности трека и правило рассылки токена сессии.
    testImplementation("junit:junit:4.13.2")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    // Explicit, not transitive: MainViewModel and SearchViewModel take a SavedStateHandle now, and
    // relying on activity-compose to keep pulling this in is how the build breaks on an unrelated
    // dependency bump.
    implementation("androidx.lifecycle:lifecycle-viewmodel-savedstate:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")
    // Network playback: the OkHttp data source shares the catalogue's client (one connection pool),
    // media3-datasource brings ResolvingDataSource and CacheDataSource, and the cache index needs
    // media3-database. JSON is parsed with android's own org.json - see data/remote/Json.kt for why
    // a schema-based parser is the wrong tool for a private API that changes shape without notice.
    implementation("androidx.media3:media3-datasource:1.5.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.5.1")
    implementation("androidx.media3:media3-database:1.5.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    implementation("androidx.room:room-runtime:2.7.1")
    implementation("androidx.room:room-ktx:2.7.1")
    ksp("androidx.room:room-compiler:2.7.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    // androidx.documentfile and androidx.palette were both dropped in 6.3: the scanner now queries
    // DocumentsContract directly (DocumentFile was the bottleneck, not a helper - every property
    // read was a separate IPC round trip), and palette was already superseded by the in-app
    // quantiser in 6.2. Neither was referenced any more, both were still being packaged, and both
    // still had keep rules pointed at them.
}
