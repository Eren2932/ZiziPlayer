package app.ziziplayer.playback.dsp;

import java.util.Arrays;

/** Read-only octave-band meter. It never modifies PCM, requests permissions or calls Android. */
public final class PcmSpectrumAnalyzer {
    public interface Listener { void onSpectrum(float[] bands, float peak); }
    private static final double[] FREQUENCIES = {31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000};
    private final int channels;
    private final int window;
    private final Listener listener;
    private final double[] b0 = new double[10], b2 = new double[10], a1 = new double[10], a2 = new double[10];
    private final double[][] z1, z2;
    private final double[] sums = new double[10];
    private final float[] display = new float[10];
    private int counted;
    private float peak;

    public PcmSpectrumAnalyzer(int sampleRate, int channels, Listener listener) {
        if (sampleRate <= 0 || channels <= 0) throw new IllegalArgumentException("Invalid PCM format");
        this.channels = channels;
        this.listener = listener;
        window = Math.max(1, sampleRate / 25);
        z1 = new double[10][channels];
        z2 = new double[10][channels];
        for (int b = 0; b < 10; b++) {
            // Above-Nyquist bands stay zero rather than being folded into false bass.
            if (FREQUENCIES[b] >= sampleRate * 0.48) continue;
            double omega = 2 * Math.PI * FREQUENCIES[b] / sampleRate;
            double alpha = Math.sin(omega) / 4.0; // Q=2, constant 0 dB peak band-pass
            double a0 = 1 + alpha;
            b0[b] = alpha / a0;
            b2[b] = -alpha / a0;
            a1[b] = -2 * Math.cos(omega) / a0;
            a2[b] = (1 - alpha) / a0;
        }
    }

    public void reset() {
        for (double[] row : z1) Arrays.fill(row, 0);
        for (double[] row : z2) Arrays.fill(row, 0);
        Arrays.fill(sums, 0);
        Arrays.fill(display, 0);
        counted = 0;
        peak = 0;
    }

    public void feed(float[] pcm, int frames) {
        if (frames < 0 || frames > pcm.length / channels) throw new IllegalArgumentException("PCM length");
        for (int f = 0; f < frames; f++) {
            for (int ch = 0; ch < channels; ch++) {
                float input = pcm[f * channels + ch];
                double x = Float.isFinite(input) ? Math.max(-1f, Math.min(1f, input)) : 0;
                peak = Math.max(peak, (float) Math.abs(x));
                for (int b = 0; b < 10; b++) {
                    double y = b0[b] * x + z1[b][ch];
                    z1[b][ch] = -a1[b] * y + z2[b][ch];
                    z2[b][ch] = b2[b] * x - a2[b] * y;
                    // Add channel ENERGY, not mono samples: opposite-phase stereo stays visible.
                    sums[b] += y * y;
                }
            }
            if (++counted == window) publish();
        }
    }

    private void publish() {
        float[] out = new float[10]; // one immutable UI snapshot at 25 Hz, never per PCM buffer
        for (int b = 0; b < 10; b++) {
            double rms = Math.sqrt(sums[b] / (counted * (double) channels));
            double db = 20 * Math.log10(Math.max(rms, 1e-6));
            float norm = (float) Math.max(0, Math.min(1, (db + 60) / 60));
            display[b] = norm >= display[b] ? norm : display[b] * 0.72f + norm * 0.28f;
            if (display[b] < 0.005f) display[b] = 0f;
            out[b] = display[b];
            sums[b] = 0;
        }
        listener.onSpectrum(out, peak);
        peak = 0;
        counted = 0;
    }
}
