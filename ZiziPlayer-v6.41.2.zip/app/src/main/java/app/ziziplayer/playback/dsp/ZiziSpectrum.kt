package app.ziziplayer.playback.dsp

import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Published arrays are never mutated. One snapshot and one UI collector for all indicators. */
data class SpectrumFrame(val bands: FloatArray, val peak: Float, val capturedAtNanos: Long, val revision: Long = 0L) {
    companion object {
        val SILENT = SpectrumFrame(FloatArray(DspConfig.BAND_COUNT), 0f, 0L)
    }
}

object ZiziSpectrum {
    private val _frame = MutableStateFlow(SpectrumFrame.SILENT)
    val frame: StateFlow<SpectrumFrame> = _frame
    private val epoch = AtomicLong(0L)
    val revision: Long get() = epoch.get()
    @Volatile private var uiVisible = false
    @Volatile private var playbackActive = false
    val listening: Boolean get() = uiVisible && playbackActive

    /** Only the window lifecycle owns this flag; individual widgets never switch it off. */
    fun setUiVisible(visible: Boolean) {
        if (uiVisible == visible) return
        uiVisible = visible
        reset()
    }

    /** Media3 isPlaying also excludes buffering, ended state and audio-focus suppression. */
    fun setPlaybackActive(active: Boolean) {
        if (playbackActive == active) return
        playbackActive = active
        reset()
    }

    internal fun publish(values: FloatArray, peak: Float, revision: Long) {
        if (!listening || epoch.get() != revision) return
        val previous = _frame.value
        val next = SpectrumFrame(values, peak, System.nanoTime(), revision)
        // Do not overwrite a simultaneous pause/seek reset with an old audio block.
        if (listening && epoch.get() == revision) _frame.compareAndSet(previous, next)
    }

    fun reset() {
        val revision = epoch.incrementAndGet()
        _frame.value = SpectrumFrame(SpectrumFrame.SILENT.bands, 0f, 0L, revision)
    }

    /** A stalled/unsupported audio route must show silence, not a frozen last loud frame. */
    fun expire() {
        val previous = _frame.value
        if (previous.capturedAtNanos != 0L && System.nanoTime() - previous.capturedAtNanos > 240_000_000L) {
            _frame.compareAndSet(previous, SpectrumFrame(SpectrumFrame.SILENT.bands, 0f, 0L, previous.revision))
        }
    }
}
