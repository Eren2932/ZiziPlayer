package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Fixed, translucent tint ABOVE app content and BELOW Android's system icons.
 * Mount once as the last visual layer in the window host, not inside the moving player.
 * Future lyrics/scrolling content can pass underneath without any change to this component.
 * This is tint glass, not blur: no bitmap capture, RenderEffect or offscreen compositing layer.
 * The Spacer has no input/semantics handlers, so system gestures and app hits are untouched.
 */
@Composable
fun StatusBarTint(modifier: Modifier = Modifier) {
    Spacer(
        modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).drawWithCache {
            val tint = Color.Black.copy(alpha = 0.24f)
            onDrawBehind { drawRect(tint) }
        }
    )
}

/** A single translucent surface under title, filters AND sort controls, with a quiet edge. */
fun Modifier.libraryChrome(): Modifier = drawWithCache {
    val tint = Brush.verticalGradient(
        0f to Color.Black.copy(alpha = 0.19f),
        1f to Color.Black.copy(alpha = 0.11f)
    )
    val edge = 0.5.dp.toPx()
    onDrawBehind {
        drawRect(tint)
        drawRect(
            Color.White.copy(alpha = 0.055f),
            topLeft = Offset(0f, (size.height - edge).coerceAtLeast(0f)),
            size = Size(size.width, edge)
        )
    }
}

/**
 * ФОН ШАПКИ ПОИСКА (6.41.0).
 *
 * Это не «другой цвет сзади», как кажется по скриншоту, а отдельный слой с собственной
 * геометрией, и собрать его одним диагональным градиентом нельзя: у эталона максимум стоит в
 * ДВУХ верхних углах сразу, а не на одной диагонали.
 *
 * Замер эталона (1080 px, срезы по строкам): левый верх R79 G41 B20 — это в точности бренд
 * #F97316 с альфой 0.26 на базе #121212 (0.26*249 + 0.74*18 = 78). Правый верх R43 G30 B40 —
 * верхний цвет рампы обложки с альфой около 0.23. К низу блока всё уходит в базу: на 540-й
 * строке слева остаётся R34, то есть альфа 0.069 — падение ровно в 3.8 раза.
 *
 * Отсюда два слоя вместо одного: горизонтальный градиент бренд → обложка с верхними альфами,
 * поверх — вертикальная вуаль базы от прозрачной до 0.74. Произведение и даёт измеренные 0.069
 * внизу слева (0.26 * 0.26). Два `drawRect` на кадр, ни одного offscreen-слоя.
 */
fun Modifier.searchChrome(brand: Color, cover: Color): Modifier = drawWithCache {
    val wash = Brush.horizontalGradient(
        0f to brand.copy(alpha = 0.26f),
        1f to cover.copy(alpha = 0.23f)
    )
    val fade = Brush.verticalGradient(
        0f to Color.Transparent,
        1f to SEARCH_CHROME_BASE.copy(alpha = 0.74f)
    )
    onDrawBehind {
        drawRect(wash)
        drawRect(fade)
    }
}

/** База приложения. Вуаль шапки уходит именно в неё, а не в чёрный: чёрный дал бы провал. */
private val SEARCH_CHROME_BASE = Color(0xFF121212)

/** Dims real outgoing text/art at the list edge, not only the background underneath it. */
fun Modifier.topContentTint(): Modifier = drawWithCache {
    val height = 14.dp.toPx().coerceAtMost(size.height)
    val tint = Brush.verticalGradient(
        colors = listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent),
        startY = 0f,
        endY = height.coerceAtLeast(1f)
    )
    onDrawWithContent {
        drawContent()
        if (height > 0f) drawRect(tint, size = Size(size.width, height))
    }
}


/** Measured overlay height, consumed as lazy-list content padding, never viewport padding. */
val LocalBottomChromeInset = staticCompositionLocalOf { 0.dp }

/** 90% transparent tint UNDER the capsule and navigation; no alpha on the children. */
fun Modifier.bottomChrome(): Modifier = drawWithCache {
    val tint = Color.Black.copy(alpha = 0.10f)
    onDrawBehind { drawRect(tint) }
}
