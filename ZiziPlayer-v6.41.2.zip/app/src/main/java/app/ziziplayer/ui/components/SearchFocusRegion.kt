package app.ziziplayer.ui.components

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Rect

/** Root-coordinate region; plain fields avoid recomposing the host on every layout/focus. */
class SearchFocusRegion {
    var bounds: Rect? = null
    var focused: Boolean = false
}

val LocalSearchFocusRegion = staticCompositionLocalOf { SearchFocusRegion() }
