package app.ziziplayer.ui.screens

import app.ziziplayer.ui.theme.ZiziFontFamily
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.EqProfileEntity
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPreset
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.LocalAudioSpectrum
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Экран эквалайзера (6.24.4).
 *
 * ГЛАВНОЕ РЕШЕНИЕ, определившее весь файл: у экрана НЕТ собственного состояния тракта.
 *
 * Ползунки читают `vm.dsp` и пишут через `vm.setDsp`, а не держат локальную копию, которую надо
 * синхронизировать. Локальная копия здесь выглядела бы естественнее (так написан FxSheet), но она
 * означает второй источник правды: пресет, применённый из листа, смена трека со своими
 * настройками, включение глобального режима — каждое из этих событий меняет звук, и экран с
 * локальной копией показывал бы после них старые цифры. Один поток вниз, один вызов вверх —
 * рассинхрон невозможен по построению, а не «исправлен».
 *
 * Цена — рекомпозиция на каждое движение пальца. Она измеримо дешёвая: перерисовывается один
 * Canvas и одна строка текста, всё остальное в Column читает то же значение и пропускается.
 */
@Composable
fun EqualizerScreen(vm: MainViewModel, onClose: () -> Unit) {
    val p = LocalPalette.current
    val cfg by vm.dsp.collectAsStateWithLifecycle()
    val profiles by vm.eqProfiles.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var saveDialog by remember { mutableStateOf(false) }


    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
    ) {

        // ---------------- шапка ----------------
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 18.dp, top = 6.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onClose)
                    .padding(12.dp)
            ) {
                Icon(ZiziIcons.Close, contentDescription = "Закрыть", tint = p.text, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("Эквалайзер", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (settings.dspGlobal) "Одна настройка на всю музыку" else "Своя настройка для этого трека",
                    color = p.subtext, fontSize = 12.sp, maxLines = 1
                )
            }
            Switch(
                checked = cfg.enabled,
                onCheckedChange = { vm.setDsp(cfg.copy(enabled = it)) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }

        // ---------------- полосы ----------------
        BandGraph(
            config = cfg,
            onBand = { index, db ->
                val next = cfg.bandsDb.toMutableList()
                while (next.size < DspConfig.BAND_COUNT) next.add(0f)
                next[index] = db
                // Движение ползунка ВКЛЮЧАЕТ тракт. Иначе первое знакомство с экраном выглядит
                // как «двигаю — ничего не меняется», и человек уходит, не найдя тумблер в шапке.
                vm.setDsp(cfg.copy(enabled = true, bandsDb = next))
            }
        )

        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
            DspConfig.BAND_LABELS.forEach { label ->
                Text(
                    label,
                    color = p.subtext,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Кривая", color = p.subtext, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.chip)
                    .clickable { vm.setDsp(cfg.copy(bandsDb = List(DspConfig.BAND_COUNT) { 0f }, preampDb = 0f)) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text("Выровнять", color = p.text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.chip)
                    .clickable { vm.resetDsp() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(ZiziIcons.Refresh, contentDescription = null, tint = p.text, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Сбросить всё", color = p.text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        EqSlider(
            label = "Пре-амп",
            value = cfg.preampDb,
            range = -12f..6f,
            display = dbText(cfg.preampDb),
            hint = "Поднял полосы — опусти общий уровень, иначе лимитер начнёт душить бочку.",
            onChange = { vm.setDsp(cfg.copy(preampDb = round(it, 0.5f))) }
        )
        EqSlider(
            label = "Ширина полос",
            value = cfg.bandQ,
            range = 0.5f..4f,
            display = "Q %.1f".format(cfg.bandQ),
            hint = "0,5 — мягкие широкие колокола. 4,0 — хирургический вырез одной частоты.",
            onChange = { vm.setDsp(cfg.copy(bandQ = round(it, 0.1f))) }
        )

        // ---------------- пресеты ----------------
        PresetGroup("Жанр и тембр", DspPresets.curve, cfg, vm)
        PresetGroup("Объём и характер", DspPresets.space, cfg, vm)
        PresetGroup("Под устройство", DspPresets.device, cfg, vm)

        // ---------------- модули ----------------
        SectionTitle("Объём и пространство")

        EqSlider(
            label = "Под водой",
            value = cfg.underwater,
            percent = true,
            hint = "Тот самый «звук из-под воды»: срез верха плавает, и трек будто уходит вглубь.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, underwater = round(it, 0.01f))) }
        )
        EqSlider(
            label = "8D вокруг головы",
            value = cfg.rotation,
            percent = true,
            hint = "Источник ходит по кругу. Слышно только в наушниках — на динамике это моно.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, rotation = round(it, 0.01f))) }
        )
        if (cfg.rotation > 0f) {
            EqSlider(
                label = "Скорость вращения",
                value = cfg.rotationHz,
                range = 0.02f..1.5f,
                display = "%.1f с на круг".format(1f / cfg.rotationHz.coerceAtLeast(0.02f)),
                hint = null,
                onChange = { vm.setDsp(cfg.copy(rotationHz = round(it, 0.01f))) }
            )
        }
        EqSlider(
            label = "Ширина стерео",
            value = cfg.width,
            range = -1f..1f,
            display = when {
                cfg.width < -0.95f -> "Моно"
                abs(cfg.width) < 0.02f -> "Как записано"
                cfg.width > 0f -> "+${(cfg.width * 100).roundToInt()}%"
                else -> "${(cfg.width * 100).roundToInt()}%"
            },
            hint = "Влево — к моно (спасает кривые записи), вправо — шире базы колонок.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, width = round(it, 0.01f))) }
        )

        SectionTitle("Ревер")

        EqSlider(
            label = "Количество",
            value = cfg.reverbMix,
            percent = true,
            hint = "Сколько отражённого звука подмешано к прямому.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, reverbMix = round(it, 0.01f))) }
        )
        EqSlider(
            label = "Размер помещения",
            value = cfg.reverbSize,
            percent = true,
            display = if (cfg.reverbSize < 0.3f) "Комната" else if (cfg.reverbSize < 0.7f) "Зал" else "Собор",
            hint = null,
            onChange = { vm.setDsp(cfg.copy(reverbSize = round(it, 0.01f))) }
        )
        EqSlider(
            label = "Поглощение верха",
            value = cfg.reverbDamp,
            percent = true,
            display = if (cfg.reverbDamp < 0.3f) "Кафель" else if (cfg.reverbDamp < 0.7f) "Дерево" else "Вата",
            hint = null,
            onChange = { vm.setDsp(cfg.copy(reverbDamp = round(it, 0.01f))) }
        )

        SectionTitle("Насыщение")

        EqSlider(
            label = "Сатуратор низа",
            value = cfg.bassDrive,
            percent = true,
            hint = "Добавляет ГАРМОНИКИ баса, а не сам бас: низ слышно даже там, где динамик его не умеет.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, bassDrive = round(it, 0.01f))) }
        )
        EqSlider(
            label = "Воздух",
            value = cfg.air,
            percent = true,
            hint = "Полка на 11 кГц. Открывает верх, не трогая шипящие в вокале.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, air = round(it, 0.01f))) }
        )
        EqSlider(
            label = "Ламповое насыщение",
            value = cfg.drive,
            percent = true,
            hint = "Мягкое ограничение всего сигнала. В малых дозах — плотность, в больших — грязь.",
            onChange = { vm.setDsp(cfg.copy(enabled = true, drive = round(it, 0.01f))) }
        )

        ToggleRow(
            label = "Лимитер",
            subtitle = "Держит выход ниже перегруза. Пока нет клиппинга — не делает ничего, поэтому выключать его незачем.",
            checked = cfg.limiter,
            onChange = { vm.setDsp(cfg.copy(limiter = it)) }
        )

        ToggleRow(
            label = "Применять ко всем трекам",
            subtitle = "Включено — этот тракт звучит везде. Выключено — у каждого трека свой, и он не пропал: он вернётся сюда же.",
            checked = settings.dspGlobal,
            onChange = { vm.setDspGlobal(it) }
        )

        // ---------------- свои пресеты ----------------
        SectionTitle("Мои пресеты")

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.accent)
                    .clickable { saveDialog = true }
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(ZiziIcons.Spectrum, contentDescription = null, tint = p.onAccent, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("Сохранить", color = p.onAccent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            profiles.forEach { profile -> ProfileChip(profile, vm) }
        }

        if (profiles.isEmpty()) {
            Text(
                "Настроил под свои наушники — сохрани, и настройка встанет в один тап на любом треке.",
                color = p.subtext, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
            )
        }

        Spacer(Modifier.height(28.dp))
    }

    if (saveDialog) {
        SaveProfileDialog(
            onDismiss = { saveDialog = false },
            onSave = { name -> vm.saveEqProfile(name); saveDialog = false }
        )
    }
}

/* ------------------------------------------------------------------ полосы */

/**
 * Десять полос одним холстом, а не десятью `Slider`.
 *
 * Причина не в красоте. Десять вертикальных Material-ползунков — это десять независимых
 * перехватчиков жеста: провести пальцем по кривой невозможно, каждую полосу надо брать отдельно,
 * а промах по узкой дорожке скроллит экран. Здесь жест обрабатывает один родитель: палец ведёт
 * ЛИНИЮ, полоса под пальцем меняется на лету — так эквалайзер настраивают одним движением, и
 * именно это отличает инструмент от формы ввода.
 *
 * Позади ползунков в реальном времени рисуется спектр того, что играет, — из нашего же
 * процессора, без `Visualizer` и без разрешения на микрофон (см. [ZiziSpectrum]).
 */
@Composable
private fun BandGraph(config: DspConfig, onBand: (Int, Float) -> Unit) {
    val p = LocalPalette.current
    val spectrumState = LocalAudioSpectrum.current
    val dim by animateFloatAsState(if (config.enabled) 1f else 0.35f, label = "eqDim")

    val count = DspConfig.BAND_COUNT
    val bands = remember(config.bandsDb) {
        FloatArray(count) { config.bandsDb.getOrElse(it) { 0f } }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(230.dp)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .pointerInput(Unit) {
                fun report(pos: Offset) {
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    if (w <= 0f || h <= 0f) return
                    val index = ((pos.x / w) * count).toInt().coerceIn(0, count - 1)
                    // Полшага в децибелах — предел, на котором ещё имеет смысл целиться пальцем.
                    val db = (((1f - pos.y / h) * 24f) - 12f).coerceIn(-12f, 12f)
                    onBand(index, (db * 2f).roundToInt() / 2f)
                }
                detectDragGestures(
                    onDragStart = { report(it) },
                    onDrag = { change, _ -> change.consume(); report(change.position) }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    if (w <= 0f || h <= 0f) return@detectTapGestures
                    val index = ((pos.x / w) * count).toInt().coerceIn(0, count - 1)
                    val db = (((1f - pos.y / h) * 24f) - 12f).coerceIn(-12f, 12f)
                    onBand(index, (db * 2f).roundToInt() / 2f)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val spectrum = spectrumState.value.bands
            val peak = spectrumState.value.peak
            val w = size.width
            val h = size.height
            val slot = w / count
            val zeroY = h / 2f

            // --- сетка: 0 дБ жирнее остальных, потому что это единственная линия, к которой
            // возвращаются, а остальные нужны только для оценки «на сколько поднял».
            for (step in -2..2) {
                val y = zeroY - step * (h / 2f) / 2f
                drawLine(
                    color = p.subtext.copy(alpha = if (step == 0) 0.35f else 0.12f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = if (step == 0) 1.6f else 1f
                )
            }

            // --- спектр позади: то, что реально звучит прямо сейчас
            for (i in 0 until count) {
                val level = spectrum.getOrElse(i) { 0f }
                if (level <= 0.01f) continue
                val barH = level * (h * 0.92f)
                val cx = slot * i + slot / 2f
                val barW = slot * 0.52f
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        0f to p.accent.copy(alpha = 0.34f * dim),
                        1f to p.accent.copy(alpha = 0.05f * dim)
                    ),
                    topLeft = Offset(cx - barW / 2f, h - barH),
                    size = androidx.compose.ui.geometry.Size(barW, barH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(barW / 2f, barW / 2f)
                )
            }

            // --- кривая: сглаженная, потому что фильтры суммируются плавно, и ломаная из
            // отрезков врала бы про то, что делает звук между центрами полос.
            val pts = ArrayList<Offset>(count)
            for (i in 0 until count) {
                val cx = slot * i + slot / 2f
                val cy = zeroY - (bands[i] / 12f) * (h / 2f - 14f)
                pts.add(Offset(cx, cy))
            }
            val curve = Path().apply {
                moveTo(0f, pts[0].y)
                lineTo(pts[0].x, pts[0].y)
                for (i in 0 until pts.size - 1) {
                    val a = pts[i]
                    val b = pts[i + 1]
                    val mx = (a.x + b.x) / 2f
                    cubicTo(mx, a.y, mx, b.y, b.x, b.y)
                }
                lineTo(w, pts.last().y)
            }
            val fill = Path().apply {
                addPath(curve)
                lineTo(w, zeroY)
                lineTo(0f, zeroY)
                close()
            }
            drawPath(
                path = fill,
                brush = Brush.verticalGradient(
                    0f to p.accent.copy(alpha = 0.20f * dim),
                    1f to p.accent.copy(alpha = 0.02f * dim)
                )
            )
            drawPath(
                path = curve,
                brush = SolidColor(p.accent.copy(alpha = dim)),
                style = Stroke(width = 3.2f)
            )

            // --- ручки
            for (i in 0 until count) {
                val c = pts[i]
                drawCircle(color = p.top.copy(alpha = 0.9f * dim), radius = 10f, center = c)
                drawCircle(color = p.accent.copy(alpha = dim), radius = 6.5f, center = c)
            }

            // --- индикатор перегруза. Не «красиво мигает»: если сюда упёрлось, значит лимитер
            // уже работает, и человеку надо убрать пре-амп, а не гадать, почему «дышит».
            if (peak > 0.98f) {
                drawRoundRect(
                    color = Color(0xFFFF6B6B).copy(alpha = 0.85f),
                    topLeft = Offset(w - 46f, 4f),
                    size = androidx.compose.ui.geometry.Size(42f, 6f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ мелкие блоки */

@Composable
private fun SectionTitle(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        color = p.text,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 6.dp)
    )
}

/**
 * Ползунок с подписью, значением и — там, где это не очевидно — одной строкой о том, что он
 * делает со звуком. Подсказка не украшение: «Q», «пре-амп» и «сатуратор» ничего не говорят
 * человеку, который просто хочет, чтобы бас бил, и без объяснения он их не тронет.
 */
@Composable
private fun EqSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    percent: Boolean = false,
    display: String? = null,
    hint: String? = null,
    onChange: (Float) -> Unit
) {
    val p = LocalPalette.current
    Column(Modifier.padding(horizontal = 20.dp, vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(
                display ?: if (percent) "${(value * 100).roundToInt()}%" else "%.2f".format(value),
                color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = p.accent,
                activeTrackColor = p.accent,
                inactiveTrackColor = p.chip
            )
        )
        if (hint != null) {
            Text(hint, color = p.subtext.copy(alpha = 0.75f), fontSize = 11.5.sp)
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun ToggleRow(label: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = p.subtext, fontSize = 11.5.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = p.onAccent,
                checkedTrackColor = p.accent,
                uncheckedTrackColor = p.chip,
                uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
            )
        )
    }
}

/**
 * Ряд пресетов одной группы.
 *
 * Подсветка активного намеренно НЕ вычисляется сравнением конфигов. Пресет — это функция, и
 * «активен» для него означало бы «результат его применения совпадает с текущим состоянием»,
 * то есть выполнение всех 26 трансформаций на каждый кадр перетаскивания ползунка. Хуже того,
 * после ручной правки одной полосы подсветка всё равно погасла бы — и человек решил бы, что
 * пресет слетел. Пресет здесь — это ДЕЙСТВИЕ, а не состояние, поэтому он не «горит».
 */
@Composable
private fun PresetGroup(title: String, presets: List<DspPreset>, cfg: DspConfig, vm: MainViewModel) {
    val p = LocalPalette.current
    SectionTitle(title)
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        presets.forEach { preset ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.chip)
                    .clickable { vm.applyDspPreset(preset) }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(preset.name, color = p.text, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Тап — применить, долгий тап — удалить. Удаление не прячется в меню, но и не под пальцем. */
@Composable
private fun ProfileChip(profile: EqProfileEntity, vm: MainViewModel) {
    val p = LocalPalette.current
    var confirm by remember { mutableStateOf(false) }
    Box(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(p.chip)
            .pointerInput(profile.name) {
                detectTapGestures(
                    onTap = { vm.applyEqProfile(profile) },
                    onLongPress = { confirm = true }
                )
            }
            .padding(horizontal = 16.dp, vertical = 11.dp)
    ) {
        Text(profile.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = p.surface,
            title = { Text("Удалить «${profile.name}»?", color = p.text) },
            text = { Text("Пресет исчезнет из списка. На звук прямо сейчас это не повлияет.", color = p.subtext) },
            confirmButton = {
                TextButton(onClick = { vm.deleteEqProfile(profile.name); confirm = false }) {
                    Text("Удалить", color = DANGER)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Отмена", color = p.subtext) }
            }
        )
    }
}

@Composable
private fun SaveProfileDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Сохранить настройку", color = p.text) },
        text = {
            Column {
                Text("Имя, по которому ты её узнаешь через месяц.", color = p.subtext, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.chip)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = name,
                        onValueChange = { if (it.length <= 40) name = it },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = ZiziFontFamily, color = p.text, fontSize = 15.sp),
                        cursorBrush = SolidColor(p.accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (name.isEmpty()) Text("Например: Мои наушники", color = p.subtext, fontSize = 15.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onSave(name) }) {
                Text("Сохранить", color = p.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.subtext) } }
    )
}

/* ------------------------------------------------------------------ мелочи */

private fun dbText(db: Float): String =
    (if (db > 0f) "+" else "") + "%.1f дБ".format(db)

/** Квантование значения ползунка: без него в базу уезжает 0.4372159 и строка кодека пухнет. */
private fun round(value: Float, step: Float): Float =
    (value / step).roundToInt() * step
