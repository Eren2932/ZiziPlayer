package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import app.ziziplayer.ui.components.ArtSwatches
import app.ziziplayer.ui.motion.PlayerTransitionPolicy
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * 6.39.8: artwork mode has a visible top-to-bottom colour ramp, separate from the bare
 * AMOLED base. Earlier comments/calibration described a different reference and a peak
 * under the controls; the new references instead retain the cover hue at the top.
 * Stop positions are shared by the normal background and the cached swipe renderer.
 */
private val RAMP_POS = floatArrayOf(0.00f, 0.10f, 0.28f, 0.46f, 0.64f, 0.82f, 1.00f)
private val RAMP_REL = floatArrayOf(0.34f, 0.44f, 0.63f, 0.81f, 0.98f, 0.84f, 0.58f)

/** Retained for legacy palette glow transitions; the new artwork ramp has no halo. */
private const val GLOW_CENTRE_Y = 0.20f
private const val GLOW_RADIUS_W = 1.15f

/**
 * Фирменный оранжевый Zizi Player. Один на всё приложение: тема, кнопки, иконка (см.
 * res/drawable/ic_launcher_background.xml — там тот же #F97316 и никакого второго источника
 * правды).
 */
val ZiziBrand = Color(0xFFF97316)

@Immutable
data class ZiziPalette(
    val top: Color,
    val crest: Color,
    val upper: Color,
    val middle: Color,
    val lower: Color,
    val deep: Color,
    val bottom: Color,
    val glow: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    /** How much of the cover's colour this theme accepts at all. */
    val tintStrength: Float,
    /** Peak Oklab lightness this theme allows before the cover has any say. */
    val peakLightness: Float,
    /** Legacy base calibration; artwork mode now uses an explicit text-contrast cap. */
    val peakCeiling: Float,
    /**
     * How much of [glow] actually reaches the screen. 0 on a dark cover (the reference shows no
     * glow there at all), 1 on a white one. Carried as a separate float rather than baked into
     * [glow]'s alpha so that the swipe blend can interpolate colour and strength independently.
     */
    val glowStrength: Float = 0f,
    /**
     * БРЕНДОВЫЙ ОРАНЖЕВЫЙ. #F97316. Не путать с [accent].
     *
     * [accent] — производная от обложки играющего трека: withAccent пересчитывает его на каждой
     * смене песни, и это правильно для всего, что относится к текущему воспроизведению. Но ровно
     * поэтому accent непригоден для того, по чему приложение узнают: активный фильтр, галочка
     * «сохранено», иконка в шапке и сама иконка на рабочем столе обязаны быть одного цвета
     * всегда, иначе «фирменный цвет» — это просто цвет последней обложки.
     *
     * [brand] не трогают ни withAccent, ни тонирование темы. Это единственная константа палитры.
     */
    val brand: Color = ZiziBrand,
    /** Что писать и рисовать поверх [brand]. Почти чёрный, а не белый: на #F97316 контраст белого
     *  4.0:1 — ниже порога AA для мелкого текста, у тёмного 8.9:1. */
    val onBrand: Color = Color(0xFF1B0C00)
) {
    /** [glow] with its strength folded into alpha - the single value the backdrop paints. */
    val glowLayer: Color get() = glow.copy(alpha = glowStrength.coerceIn(0f, 1f))

    val background: Brush
        get() = Brush.verticalGradient(
            RAMP_POS[0] to top,
            RAMP_POS[1] to crest,
            RAMP_POS[2] to upper,
            RAMP_POS[3] to middle,
            RAMP_POS[4] to lower,
            RAMP_POS[5] to deep,
            RAMP_POS[6] to bottom
        )
}

/* ---------------------------------------------------------------- colour space ---- */

private fun cbrtf(value: Float): Float = Math.cbrt(value.toDouble()).toFloat()

private fun toLinear(channel: Float): Float =
    if (channel <= 0.04045f) channel / 12.92f else ((channel + 0.055f) / 1.055f).pow(2.4f)

private fun fromLinear(channel: Float): Float =
    if (channel <= 0.0031308f) channel * 12.92f else 1.055f * channel.pow(1f / 2.4f) - 0.055f

/** sRGB -> Oklch. Returns [L, C, h(deg)]. */
private fun Color.toOklch(): FloatArray {
    val r = toLinear(red)
    val g = toLinear(green)
    val b = toLinear(blue)
    val l = cbrtf(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b)
    val m = cbrtf(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b)
    val s = cbrtf(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b)
    val okL = 0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s
    val okA = 1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s
    val okB = 0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s
    var hue = atan2(okB, okA) * 57.29578f
    if (hue < 0f) hue += 360f
    return floatArrayOf(okL, hypot(okA, okB), hue)
}

/**
 * Oklch -> sRGB with a gamut walk: if the requested chroma cannot be shown at this lightness,
 * chroma is given up in 6 % steps. The hue and the lightness are never touched, which is the
 * whole point - a band getting darker must not drift towards another colour.
 */
private fun oklch(lightness: Float, chroma: Float, hueDeg: Float): Color {
    val okL = lightness.coerceIn(0f, 1f)
    val rad = hueDeg * 0.017453292f
    val dirA = cos(rad)
    val dirB = sin(rad)
    var c = chroma.coerceAtLeast(0f)
    var attempt = 0
    while (true) {
        val okA = dirA * c
        val okB = dirB * c
        val lp = okL + 0.3963377774f * okA + 0.2158037573f * okB
        val mp = okL - 0.1055613458f * okA - 0.0638541728f * okB
        val sp = okL - 0.0894841775f * okA - 1.2914855480f * okB
        val l = lp * lp * lp
        val m = mp * mp * mp
        val s = sp * sp * sp
        val r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s
        val g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s
        val b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s
        val inGamut = r >= -0.001f && r <= 1.001f && g >= -0.001f && g <= 1.001f &&
            b >= -0.001f && b <= 1.001f
        if (inGamut || attempt >= 24 || c <= 0.0005f) {
            return Color(
                red = fromLinear(r.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                green = fromLinear(g.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                blue = fromLinear(b.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            )
        }
        c *= 0.94f
        attempt++
    }
}

/* ------------------------------------------------------------------- base theme ---- */

/**
 * The one base palette is built from the measured ramp. Before, each theme carried five
 * hand-picked hex values, so "no cover colour" and "cover colour" were two differently SHAPED
 * gradients and the first track change visibly re-laid the screen out.
 */
private fun themePalette(
    hue: Float,
    chromaK: Float,
    peakLightness: Float,
    peakCeiling: Float,
    tintStrength: Float,
    surface: Color,
    chip: Color,
    text: Color,
    subtext: Color,
    accent: Color,
    onAccent: Color
): ZiziPalette {
    fun stop(index: Int): Color {
        val l = peakLightness * RAMP_REL[index]
        return oklch(l, chromaK * l, hue)
    }
    return ZiziPalette(
        top = stop(0),
        crest = stop(1),
        upper = stop(2),
        middle = stop(3),
        lower = stop(4),
        deep = stop(5),
        bottom = stop(6),
        glow = oklch((peakLightness * 1.9f).coerceIn(0.16f, 0.52f), chromaK * 0.30f, hue),
        surface = surface,
        chip = chip,
        text = text,
        subtext = subtext,
        accent = accent,
        onAccent = onAccent,
        tintStrength = tintStrength,
        peakLightness = peakLightness,
        peakCeiling = peakCeiling,
        // No cover, no glow: the bare theme is the ramp and nothing else.
        glowStrength = 0f
    )
}

private val Amoled = themePalette(
    hue = 0f,
    chromaK = 0f,
    peakLightness = 0.085f,
    // Bare AMOLED calibration, not the brightness ceiling of artwork mode.
    peakCeiling = 0.150f,
    // Kept as the enable/strength gate for existing callers.
    tintStrength = 0.88f,
    surface = Color(0xFF101010),
    chip = Color(0xFF1B1B1B),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9A9A9A),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000)
)

/** One neutral AMOLED base; enabling cover colour adds a separate, visible colour ramp. */
fun basePalette(): ZiziPalette = Amoled

val LocalPalette = compositionLocalOf { Amoled }

/* --------------------------------------------------------------------- tinting ---- */

/** The quantiser already chose the dominant colour: never average it with rival hues. */
private class CoverReading(val hue: Float, val chroma: Float)

private fun readCover(swatches: ArtSwatches): CoverReading? {
    val primary = swatches.primary.toOklch()
    if (primary[1] < 0.012f) return null
    return CoverReading(primary[2], primary[1])
}

/**
 * Real dominant hue at the top, near-black at the bottom. Monochrome covers yield a
 * visible neutral graphite ramp, NOT a fabricated colour and NOT the almost-black base.
 * Text contrast is bounded in the pure JVM core, independently of hue. No radial glow,
 * blur, artwork re-decode or palette computation is added to the rendering path.
 */
fun ZiziPalette.tintedWith(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null || tintStrength <= 0.01f) return this
    val primary = swatches.primary.toArgb()
    val stops = ArtworkColorMath.backdrop(primary)
    return copy(
        top = Color(stops[0]),
        crest = Color(stops[1]),
        upper = Color(stops[2]),
        middle = Color(stops[3]),
        lower = Color(stops[4]),
        deep = Color(stops[5]),
        bottom = Color(stops[6]),
        glowStrength = 0f,
        surface = Color(ArtworkColorMath.surface(primary)),
        chip = Color(ArtworkColorMath.chip(primary)),
        text = Color(0xFFF6F7F8),
        subtext = Color(0xFFE0E0E0)
    )
}

/**
 * The accent drives the progress bar, the active icons and the equaliser bars, so it has to stay
 * legible over the brightest band whatever the cover looks like: the hue is the cover's, the
 * lightness is pinned high. A grey cover yields a near-white accent instead of a muddy one.
 */
fun ZiziPalette.withAccent(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null) return this
    val cover = readCover(swatches)
    val accentColour = if (cover == null) {
        oklch(0.90f, 0f, 0f)
    } else {
        oklch(0.80f, (0.055f + cover.chroma * 0.52f).coerceIn(0.055f, 0.170f), cover.hue)
    }
    return copy(
        accent = accentColour,
        onAccent = if (accentColour.toOklch()[0] > 0.66f) Color(0xFF0B0B0C) else Color.White
    )
}

/**
 * Нужны ли системным иконкам тёмные значки (6.17.0).
 *
 * Раньше цвет иконок часов и батареи был прибит в styles.xml (`windowLightStatusBar=false`), то
 * есть белым всегда. Пока все темы были тёмные, это работало; стоило обложке поднять пик к
 * потолку 0.34 и подсветить верх экрана — белое по светлому. Решение принимает сам gradient:
 * порог 0.62 по Oklab-светлоте гребня, ровно там, где белый текст перестаёт держать 4.5:1.
 */
fun ZiziPalette.prefersDarkSystemIcons(): Boolean = crest.toOklch()[0] > 0.62f

/* ---------------------------------------------------------- carousel cross-fade ---- */

/**
 * One animated ramp for the whole app. Backdrops are renderers, not competing owners.
 * A gesture paints absolute page palettes; changing the playing index cannot re-anchor it
 * on the previous neighbour. Work per frame stays in the draw phase.
 */
@Stable
class BackdropBlend(initial: ZiziPalette = basePalette()) {
    internal val top = Animatable(initial.top)
    internal val crest = Animatable(initial.crest)
    internal val upper = Animatable(initial.upper)
    internal val middle = Animatable(initial.middle)
    internal val lower = Animatable(initial.lower)
    internal val deep = Animatable(initial.deep)
    internal val bottom = Animatable(initial.bottom)
    internal val glow = Animatable(initial.glowLayer)

    var from by mutableStateOf<ZiziPalette?>(null)
        private set
    var target by mutableStateOf<ZiziPalette?>(null)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var gestureActive by mutableStateOf(false)
        private set
    var heldTrackId by mutableStateOf<String?>(null)
        private set
    var originTrackId by mutableStateOf<String?>(null)
        private set
    var revision by androidx.compose.runtime.mutableIntStateOf(0)
        private set

    fun beginGesture() {
        gestureActive = true
        heldTrackId = null
        originTrackId = null
        revision++
    }

    fun drag(left: ZiziPalette, right: ZiziPalette, fraction: Float) {
        if (!gestureActive) return
        from = left
        target = right
        progress = fraction.coerceIn(0f, 1f)
    }

    fun hold(origin: String?, trackId: String, palette: ZiziPalette) {
        from = palette
        target = palette
        progress = 1f
        originTrackId = origin
        heldTrackId = trackId
        gestureActive = false
        revision++
    }

    /** Preserve the visible ramp until the single animator adopts it (no one-frame flash). */
    fun cancelGesture() {
        gestureActive = false
        heldTrackId = null
        originTrackId = null
        revision++
    }

    internal fun clearOverride() {
        from = null
        target = null
        progress = 0f
        heldTrackId = null
        originTrackId = null
    }

    internal fun visiblePalette(template: ZiziPalette): ZiziPalette {
        val a = from
        val b = target
        val f = progress
        fun stop(base: Color, left: Color?, right: Color?): Color =
            if (left == null || right == null) base else blendOklch(left, right, f)
        return template.copy(
            top = stop(top.value, a?.top, b?.top),
            crest = stop(crest.value, a?.crest, b?.crest),
            upper = stop(upper.value, a?.upper, b?.upper),
            middle = stop(middle.value, a?.middle, b?.middle),
            lower = stop(lower.value, a?.lower, b?.lower),
            deep = stop(deep.value, a?.deep, b?.deep),
            bottom = stop(bottom.value, a?.bottom, b?.bottom),
            glow = glow.value,
            glowStrength = glow.value.alpha
        )
    }

    internal suspend fun snapTo(p: ZiziPalette) {
        top.snapTo(p.top)
        crest.snapTo(p.crest)
        upper.snapTo(p.upper)
        middle.snapTo(p.middle)
        lower.snapTo(p.lower)
        deep.snapTo(p.deep)
        bottom.snapTo(p.bottom)
        glow.snapTo(p.glowLayer)
    }

    internal suspend fun animateTo(p: ZiziPalette, durationMs: Int) = coroutineScope {
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(p.top, spec) }
        launch { crest.animateTo(p.crest, spec) }
        launch { upper.animateTo(p.upper, spec) }
        launch { middle.animateTo(p.middle, spec) }
        launch { lower.animateTo(p.lower, spec) }
        launch { deep.animateTo(p.deep, spec) }
        launch { bottom.animateTo(p.bottom, spec) }
        launch { glow.animateTo(p.glowLayer, spec) }
    }
}

val LocalBackdropBlend = staticCompositionLocalOf { BackdropBlend() }

/** Called exactly once by the app host, never by the individual background renderers. */
@Composable
fun SyncBackdropPalette(
    blend: BackdropBlend,
    palette: ZiziPalette,
    paletteTrackId: String?,
    playingTrackId: String?,
    durationMs: Int = 380
) {
    LaunchedEffect(blend, palette, paletteTrackId, playingTrackId, blend.revision) {
        if (blend.gestureActive) return@LaunchedEffect
        when (PlayerTransitionPolicy.handoff(
            blend.originTrackId, blend.heldTrackId, playingTrackId, paletteTrackId
        )) {
            PlayerTransitionPolicy.WAIT -> return@LaunchedEffect
            PlayerTransitionPolicy.SNAP -> {
                // Preview already reached this page: adopt it before removing the overlay.
                blend.snapTo(palette)
                blend.clearOverride()
            }
            else -> {
                if (blend.target != null) {
                    blend.snapTo(blend.visiblePalette(palette))
                    blend.clearOverride()
                }
                // A new target cancels the entire previous animation, including all children.
                blend.animateTo(palette, durationMs)
            }
        }
    }
}

/**
 * Mixes two ramp stops the way the eye expects: through the shorter hue arc at constant
 * perceptual lightness, never through grey.
 *
 * sRGB interpolation between the yellow sleeve's band and the purple one's passes through a dead
 * olive-brown, because the straight line between two hues in RGB goes through the middle of the
 * cube. That muddy midpoint is exactly what showed up between two covers.
 */
private fun blendOklch(from: Color, to: Color, fraction: Float): Color {
    if (fraction <= 0.001f) return from
    if (fraction >= 0.999f) return to
    val a = from.toOklch()
    val b = to.toOklch()
    var delta = b[2] - a[2]
    if (delta > 180f) delta -= 360f
    if (delta < -180f) delta += 360f
    // A colourless stop has no meaningful hue: borrow the other one's instead of rotating half
    // way round the circle to reach it.
    val hue = when {
        a[1] < 0.004f -> b[2]
        b[1] < 0.004f -> a[2]
        else -> a[2] + delta * fraction
    }
    return oklch(
        a[0] + (b[0] - a[0]) * fraction,
        a[1] + (b[1] - a[1]) * fraction,
        hue
    )
}

/* -------------------------------------------------------------------- backdrop ---- */

/** Pure renderer: both visible surfaces read the same animation and handoff state. */
@Composable
fun ZiziBackdrop(
    palette: ZiziPalette,
    modifier: Modifier = Modifier
) {
    val blend = LocalBackdropBlend.current
    Spacer(
        modifier
            .fillMaxSize()
            .drawWithCache {
                val from = blend.from
                val other = blend.target
                val mix = blend.progress
                fun stop(base: Color, left: Color?, right: Color?): Color =
                    if (left == null || right == null) base else blendOklch(left, right, mix)
                val brush = Brush.verticalGradient(
                    RAMP_POS[0] to stop(blend.top.value, from?.top, other?.top),
                    RAMP_POS[1] to stop(blend.crest.value, from?.crest, other?.crest),
                    RAMP_POS[2] to stop(blend.upper.value, from?.upper, other?.upper),
                    RAMP_POS[3] to stop(blend.middle.value, from?.middle, other?.middle),
                    RAMP_POS[4] to stop(blend.lower.value, from?.lower, other?.lower),
                    RAMP_POS[5] to stop(blend.deep.value, from?.deep, other?.deep),
                    RAMP_POS[6] to stop(blend.bottom.value, from?.bottom, other?.bottom)
                )
                val halo = blend.glow.value
                val haloBrush = if (halo.alpha > 0.004f) Brush.radialGradient(
                    0.0f to halo,
                    0.55f to halo.copy(alpha = halo.alpha * 0.42f),
                    1.0f to halo.copy(alpha = 0f),
                    center = Offset(size.width * 0.5f, size.height * GLOW_CENTRE_Y),
                    radius = size.width * GLOW_RADIUS_W
                ) else null
                onDrawBehind {
                    drawRect(brush)
                    if (haloBrush != null) drawRect(haloBrush)
                }
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = ZiziTypography,
        content = content
    )
}
