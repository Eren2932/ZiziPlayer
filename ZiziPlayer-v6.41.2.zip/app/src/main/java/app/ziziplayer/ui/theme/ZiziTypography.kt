package app.ziziplayer.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import app.ziziplayer.R

/** Packaged faces, not a device's named sans-serif. System font scaling remains accessible. */
val ZiziFontFamily = FontFamily(
    Font(R.font.zizi_roboto_regular, FontWeight.Normal),
    Font(R.font.zizi_roboto_medium, FontWeight.Medium),
    Font(R.font.zizi_roboto_semibold, FontWeight.SemiBold),
    Font(R.font.zizi_roboto_bold, FontWeight.Bold),
    Font(R.font.zizi_roboto_extrabold, FontWeight.ExtraBold)
)

private val defaults = Typography()
val ZiziTypography = Typography(
    displayLarge = defaults.displayLarge.copy(fontFamily = ZiziFontFamily),
    displayMedium = defaults.displayMedium.copy(fontFamily = ZiziFontFamily),
    displaySmall = defaults.displaySmall.copy(fontFamily = ZiziFontFamily),
    headlineLarge = defaults.headlineLarge.copy(fontFamily = ZiziFontFamily),
    headlineMedium = defaults.headlineMedium.copy(fontFamily = ZiziFontFamily),
    headlineSmall = defaults.headlineSmall.copy(fontFamily = ZiziFontFamily),
    titleLarge = defaults.titleLarge.copy(fontFamily = ZiziFontFamily),
    titleMedium = defaults.titleMedium.copy(fontFamily = ZiziFontFamily),
    titleSmall = defaults.titleSmall.copy(fontFamily = ZiziFontFamily),
    bodyLarge = defaults.bodyLarge.copy(fontFamily = ZiziFontFamily),
    bodyMedium = defaults.bodyMedium.copy(fontFamily = ZiziFontFamily),
    bodySmall = defaults.bodySmall.copy(fontFamily = ZiziFontFamily),
    labelLarge = defaults.labelLarge.copy(fontFamily = ZiziFontFamily),
    labelMedium = defaults.labelMedium.copy(fontFamily = ZiziFontFamily),
    labelSmall = defaults.labelSmall.copy(fontFamily = ZiziFontFamily)
)
