package app.ziziplayer.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import app.ziziplayer.playback.dsp.SpectrumFrame
import app.ziziplayer.playback.dsp.ZiziSpectrum
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

val LocalAudioSpectrum = staticCompositionLocalOf<State<SpectrumFrame>> {
    mutableStateOf(SpectrumFrame.SILENT)
}

/** Exactly one lifecycle owner/collector regardless of the number of visible playing rows. */
@Composable
fun ProvideAudioSpectrum(playing: Boolean, content: @Composable () -> Unit) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val frame = ZiziSpectrum.frame.collectAsStateWithLifecycle()
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, _ ->
            ZiziSpectrum.setUiVisible(lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
        }
        lifecycle.addObserver(observer)
        ZiziSpectrum.setUiVisible(lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
        onDispose {
            lifecycle.removeObserver(observer)
            ZiziSpectrum.setUiVisible(false)
        }
    }
    LaunchedEffect(lifecycle, playing) {
        if (!playing) return@LaunchedEffect
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (isActive) {
                delay(120)
                ZiziSpectrum.expire()
            }
        }
    }
    CompositionLocalProvider(LocalAudioSpectrum provides frame, content = content)
}

/** Frequency groups preserve the same bass-to-treble meaning in 3- and 4-bar badges. */
internal fun SpectrumFrame.level(from: Int, until: Int): Float {
    var value = 0f
    for (i in from until until) value = maxOf(value, bands[i])
    return value.coerceIn(0.08f, 1f)
}
