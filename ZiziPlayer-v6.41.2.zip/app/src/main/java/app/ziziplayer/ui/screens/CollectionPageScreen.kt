package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import app.ziziplayer.ui.components.LocalBottomChromeInset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.OpenCollection
import app.ziziplayer.ui.SearchPresentation
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.rememberUrlArtwork
import app.ziziplayer.ui.theme.LocalPalette

/** A real scrolling destination, not a draggable sheet. The existing mini-player lives outside it. */
@Composable
internal fun CollectionPageScreen(
    open: OpenCollection,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    imported: Boolean,
    onClose: () -> Unit,
    onPlay: (Int) -> Unit,
    onShuffle: () -> Unit,
    onAddCollection: () -> Unit,
    onRemoveCollection: () -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit
) {
    val p = LocalPalette.current
    val collection = open.collection
    val artist = collection.kind == RemoteKind.ARTIST
    val listState = rememberLazyListState()
    val collapsed by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }
    val art = rememberUrlArtwork(collection.artworkUrl, 1024)
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val background = Color(0xFF121212)
    // Actual cover colour, not the currently playing song and not a generated artist portrait.
    val tint = art?.swatches?.primary?.copy(alpha = 0.55f) ?: Color(0xFF29221E)

    Box(Modifier.fillMaxSize().background(background)) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = LocalBottomChromeInset.current + 24.dp)) {
            item(key = "collection-header") {
                Column(Modifier.fillMaxWidth().background(
                    Brush.verticalGradient(listOf(tint, background))
                )) {
                    if (artist) {
                        BoxWithConstraints(Modifier.fillMaxWidth()) {
                            Box(Modifier.fillMaxWidth().height(maxWidth * 0.66f + topInset)) {
                                RemoteArtwork(collection.artworkUrl, collection.remoteId, 1024,
                                    modifier = Modifier.fillMaxSize(), glyphSize = 64)
                                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.12f), Color.Transparent,
                                        Color.Black.copy(alpha = 0.7f))
                                )))
                                Text(collection.title, color = Color.White,
                                    fontSize = if (collection.title.length > 16) 34.sp else 42.sp,
                                    lineHeight = 44.sp, fontWeight = FontWeight.Black,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.align(Alignment.BottomStart)
                                        .padding(horizontal = EDGE, vertical = 16.dp))
                            }
                        }
                    } else {
                        Box(Modifier.fillMaxWidth().padding(top = 42.dp + topInset, bottom = 20.dp),
                            contentAlignment = Alignment.Center) {
                            RemoteArtwork(collection.artworkUrl, collection.remoteId, 1024,
                                modifier = Modifier.fillMaxWidth(0.66f).aspectRatio(1f)
                                    .clip(RoundedCornerShape(4.dp)), glyphSize = 64)
                        }
                        Text(collection.title, color = p.text, fontSize = 27.sp,
                            lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = EDGE),
                            maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                    Column(Modifier.padding(horizontal = EDGE, vertical = 12.dp)) {
                        if (collection.subtitle.isNotBlank()) {
                            Text(collection.subtitle, color = p.text, fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold, maxLines = 2,
                                overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(8.dp))
                        }
                        val kind = when (collection.kind) {
                            RemoteKind.ARTIST -> "Исполнитель"
                            RemoteKind.ALBUM -> "Альбом"
                            else -> "Плейлист"
                        }
                        val count = when {
                            open.loading -> ""
                            open.total != null && open.total > open.tracks.size ->
                                " · Загружено ${open.tracks.size} из ${open.total}"
                            open.nextToken != null -> " · Загружено ${open.tracks.size} треков"
                            open.tracks.isNotEmpty() -> " · ${open.tracks.size} треков"
                            else -> ""
                        }
                        val minutes = SearchPresentation.durationMinutes(
                            open.tracks.map { it.durationMs },
                            complete = !artist && !open.loading && open.nextToken == null && open.error == null
                        )
                        val duration = minutes?.let { " · $it мин." }.orEmpty()
                        Text(kind + count + duration, color = p.subtext, fontSize = 14.sp)
                        if (open.tracks.isNotEmpty()) {
                            Spacer(Modifier.height(14.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // This saves the loaded selection; it is NOT a fake artist subscription.
                                Box(Modifier.weight(1f)) {
                                    Text(if (imported) "Сохранено" else "Сохранить треки",
                                        color = if (imported) p.brand else p.text,
                                        fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clip(RoundedCornerShape(24.dp))
                                            .border(1.dp, p.subtext.copy(alpha = 0.65f), RoundedCornerShape(24.dp))
                                            .clickable(role = Role.Button, onClick =
                                                if (imported) onRemoveCollection else onAddCollection)
                                            .padding(horizontal = 14.dp, vertical = 13.dp))
                                }
                                RoundIconButton(ZiziIcons.Shuffle, p.subtext, Color.Transparent,
                                    48, 26, onShuffle, modifier = Modifier.semantics { contentDescription = "Перемешать загруженные треки" })
                                RoundIconButton(ZiziIcons.PlayFilled, p.onBrand, p.brand,
                                    56, 28, { onPlay(0) }, modifier = Modifier.semantics { contentDescription = "Слушать с начала" })
                            }
                        }
                    }
                }
            }
            if (artist) item(key = "popular-title") {
                Text("Популярное", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = EDGE, top = 18.dp, bottom = 10.dp))
            }
            if (open.loading) item(key = "loading") { LoadingRow("Открываем…") }
            itemsIndexed(open.tracks, key = { index, track -> "$index:${track.trackId}" }) { index, track ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (artist) Text((index + 1).toString(), color = p.subtext, fontSize = 14.sp,
                        modifier = Modifier.padding(start = EDGE).width(20.dp))
                    Box(Modifier.weight(1f)) {
                        ResultTrackRow(track, savedIds.contains(track.trackId),
                            currentTrackId == track.trackId && isPlaying, currentTrackId == track.trackId,
                            onPlay = { onPlay(index) }, onSave = { onSave(track) },
                            onUnsave = { onUnsave(track.trackId) })
                    }
                }
            }
            when {
                open.error != null -> item(key = "error") { ErrorBlock(open.error, onRetry) }
                open.appending -> item(key = "more-loading") { LoadingRow("Загружаем ещё…") }
                open.nextToken != null -> item(key = "more") {
                    Text("Показать ещё", color = p.brand, fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onLoadMore)
                            .padding(horizontal = EDGE, vertical = 20.dp))
                }
                !open.loading && open.tracks.isEmpty() -> item(key = "empty") {
                    Text("Здесь пока нет доступных треков", color = p.subtext,
                        modifier = Modifier.padding(EDGE))
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(if (collapsed) background else Color.Transparent)
            .statusBarsPadding().padding(start = 6.dp, end = EDGE, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(ZiziIcons.ArrowBack, Color.White, Color.Black.copy(alpha = 0.28f),
                48, 25, onClose, modifier = Modifier.semantics { contentDescription = "Назад к поиску" })
            if (collapsed) {
                Spacer(Modifier.width(8.dp))
                Text(collection.title, color = p.text, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
