package app.ziziplayer.playback.dsp

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Real Media3 adapter tests. Run in Gradle CI; not included in the offline Java test result. */
@UnstableApi
class ZiziAudioProcessorTest {
    private val processor = ZiziAudioProcessor()

    @After
    fun cleanup() {
        processor.reset()
        ZiziSpectrum.setUiVisible(false)
        ZiziSpectrum.setPlaybackActive(false)
        ZiziSpectrum.reset()
    }

    private fun prepare(encoding: Int) {
        ZiziSpectrum.setUiVisible(true)
        ZiziSpectrum.setPlaybackActive(true)
        processor.configure(AudioProcessor.AudioFormat(48000, 2, encoding))
        processor.flush()
    }

    private fun process(bytes: ByteArray): ByteArray {
        val input = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        input.put(bytes)
        input.flip()
        processor.queueInput(input)
        assertEquals(input.limit(), input.position())
        val output = processor.output
        return ByteArray(output.remaining()).also { output.get(it) }
    }

    private fun pcm16(): ByteArray {
        val data = ByteBuffer.allocate(3840 * 2 * 2).order(ByteOrder.nativeOrder())
        repeat(3840) { frame ->
            val sample = (sin(2.0 * Math.PI * 1000 * frame / 48000) * 24000).toInt().toShort()
            data.putShort(sample)
            data.putShort((-sample.toInt()).toShort()) // opposite phase, not silence
        }
        return data.array()
    }

    @Test
    fun neutral16BitMeterNeverChangesAudio() {
        prepare(C.ENCODING_PCM_16BIT)
        val original = pcm16()
        assertArrayEquals(original, process(original))
        assertTrue(ZiziSpectrum.frame.value.bands[5] > 0.5f)
    }

    @Test
    fun neutralFloatMeterPreservesEveryBit() {
        prepare(C.ENCODING_PCM_FLOAT)
        val values = floatArrayOf(0f, -0f, 0.5f, -0.5f, Float.NaN, Float.POSITIVE_INFINITY)
        val data = ByteBuffer.allocate(3840 * 2 * 4).order(ByteOrder.nativeOrder())
        repeat(3840 * 2) { data.putFloat(values[it % values.size]) }
        assertArrayEquals(data.array(), process(data.array()))
        assertTrue(ZiziSpectrum.frame.value.bands.all { it.isFinite() && it in 0f..1f })
    }

    @Test
    fun noAnalysisWhileBackgroundedOrPaused() {
        prepare(C.ENCODING_PCM_16BIT)
        val data = pcm16()
        ZiziSpectrum.setUiVisible(false)
        assertArrayEquals(data, process(data))
        assertTrue(ZiziSpectrum.frame.value.bands.all { it == 0f })
        ZiziSpectrum.setUiVisible(true)
        ZiziSpectrum.setPlaybackActive(false)
        assertArrayEquals(data, process(data))
        assertTrue(ZiziSpectrum.frame.value.bands.all { it == 0f })
    }

    @Test
    fun flushClearsTheLastTrack() {
        prepare(C.ENCODING_PCM_16BIT)
        process(pcm16())
        assertTrue(ZiziSpectrum.frame.value.bands.any { it > 0f })
        processor.flush()
        assertTrue(ZiziSpectrum.frame.value.bands.all { it == 0f })
    }

    @Test
    fun oldAudioGenerationCannotPublishAfterReset() {
        prepare(C.ENCODING_PCM_16BIT)
        val oldRevision = ZiziSpectrum.revision
        ZiziSpectrum.reset()
        ZiziSpectrum.publish(FloatArray(10) { 1f }, 1f, oldRevision)
        assertTrue(ZiziSpectrum.frame.value.bands.all { it == 0f })
    }
}
