package app.ziziplayer.playback.dsp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Executes the production analyzer, not a translated model. No Android runtime required. */
public final class PcmSpectrumChecks {
    private static int assertions;
    private static void check(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }
    private static float[] tone(int rate, int channels, double hz, double amplitude, boolean opposite) {
        float[] data = new float[rate * channels];
        for (int f = 0; f < rate; f++) {
            float v = (float)(amplitude * Math.sin(2 * Math.PI * hz * f / rate));
            for (int c = 0; c < channels; c++) data[f * channels + c] = opposite && c % 2 != 0 ? -v : v;
        }
        return data;
    }
    private static List<float[]> analyze(int rate, int channels, float[] data, int chunk) {
        List<float[]> frames = new ArrayList<>();
        PcmSpectrumAnalyzer meter = new PcmSpectrumAnalyzer(rate, channels, (bands, peak) -> {
            check(peak >= 0 && peak <= 1 && Float.isFinite(peak), "finite peak");
            for (float b : bands) check(b >= 0 && b <= 1 && Float.isFinite(b), "finite bands");
            frames.add(bands);
        });
        for (int f = 0; f < data.length / channels; f += chunk) {
            int end = Math.min(data.length / channels, f + chunk);
            float[] block = Arrays.copyOfRange(data, f * channels, end * channels);
            float[] original = block.clone();
            meter.feed(block, end - f);
            check(Arrays.equals(block, original), "meter must never modify PCM");
        }
        return frames;
    }
    public static void main(String[] args) {
        for (int rate : new int[]{8000, 22050, 44100, 48000, 96000}) {
            List<float[]> frames = analyze(rate, 2, tone(rate, 2, 1000, .7, false), 733);
            check(frames.size() == 25, "25 Hz at " + rate);
            float[] last = frames.get(frames.size() - 1);
            int maximum = 0;
            for (int i = 1; i < last.length; i++) if (last[i] > last[maximum]) maximum = i;
            check(maximum == 5, "1 kHz must peak in 1 kHz band at " + rate);
            if (rate == 8000) check(last[8] == 0 && last[9] == 0, "no Nyquist alias");
        }
        float[] stereo = tone(48000, 2, 125, .5, false);
        float[] opposite = tone(48000, 2, 125, .5, true);
        List<float[]> a = analyze(48000, 2, stereo, 1920);
        List<float[]> b = analyze(48000, 2, opposite, 1920);
        check(Arrays.equals(a.get(24), b.get(24)), "opposite-phase stereo must not cancel");
        List<float[]> split = analyze(48000, 2, stereo, 127);
        check(split.size() == a.size(), "chunk-independent snapshot count");
        for (int i = 0; i < a.size(); i++) check(Arrays.equals(a.get(i), split.get(i)), "chunk independence");
        List<float[]> silence = analyze(48000, 1, new float[48000], 1024);
        for (float value : silence.get(24)) check(value == 0, "digital silence is zero");
        List<float[]> decay = new ArrayList<>();
        PcmSpectrumAnalyzer meter = new PcmSpectrumAnalyzer(48000, 2, (bands, peak) -> decay.add(bands));
        meter.feed(stereo, 48000);
        float[] saved = decay.get(24).clone();
        meter.feed(new float[48000 * 2 * 3], 48000 * 3);
        check(Arrays.equals(decay.get(24), saved), "published snapshots immutable");
        for (float value : decay.get(decay.size() - 1)) check(value == 0, "silence tail settles");
        meter.reset();
        meter.feed(new float[3840], 1920);
        for (float value : decay.get(decay.size() - 1)) check(value == 0, "reset clears filters");
        float[] invalid = {Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, 2, -2, 0};
        analyze(25, 2, invalid, 1);
        check(analyze(48000, 6, tone(48000, 6, 2000, .4, true), 1024).size() == 25, "multichannel");
        System.out.println("PASS: PCM analyzer, " + assertions + " assertions");
        // Informational only: this is the Computer, not an Android battery/latency benchmark.
        PcmSpectrumAnalyzer perf = new PcmSpectrumAnalyzer(48000, 2, (bands, peak) -> {});
        for (int i = 0; i < 5; i++) perf.feed(stereo, 48000);
        long start = System.nanoTime();
        for (int i = 0; i < 20; i++) perf.feed(stereo, 48000);
        System.out.printf("Informational: 20 s of stereo 48 kHz PCM in %.1f ms%n", (System.nanoTime()-start)/1e6);
    }
}
