#!/usr/bin/env python3
"""
Ловит ровно ту ошибку, на которой упала 6.30.0:

    ZiziApplication.kt:77:22 Unresolved reference 'DeezerCatalog'.

Класс объявлен в проекте, используется в другом файле, но импорт не дописан.
Kotlin такое находит только на этапе compileKotlin, то есть через 1.5 минуты
CI и только после того, как ZIP уже уехал в репозиторий.

Как работает: собирает все top-level объявления (class/object/interface/
enum/typealias/fun/val) с их пакетами, затем для каждого файла проверяет, что
каждое использованное имя разрешимо — свой пакет, точечный импорт, звёздочка
на нужный пакет, полное имя или локальное объявление.

Осознанно консервативен: имена внутри строк и комментариев вырезаются, имена,
объявленные более чем в одном пакете, пропускаются (нельзя сказать, какое
имелось в виду, не разбирая типы). Ложная тревога здесь дороже пропуска.
"""
import os
import re
import sys

SRC = "app/src/main/java"
DECL = re.compile(
    r"^\s*(?:@\w+\s+)*(?:public\s+|internal\s+|private\s+|abstract\s+|open\s+|sealed\s+|final\s+|data\s+|value\s+|annotation\s+|enum\s+|inline\s+|expect\s+|actual\s+)*"
    r"(class|interface|object|typealias|fun|val|var)\s+([A-Za-z_][A-Za-z0-9_]*)(?!\s*[.<]*\s*\.)"
)
NAME = re.compile(r"(?<![.\w])([A-Z][A-Za-z0-9_]*)\b")


def strip_noise(text):
    text = re.sub(r'"""(?:.|\n)*?"""', '""', text)
    text = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', text)
    text = re.sub(r"//[^\n]*", "", text)
    text = re.sub(r"/\*(?:.|\n)*?\*/", "", text)
    return text


def kt_files():
    for dirpath, _, names in os.walk(SRC):
        for n in sorted(names):
            if n.endswith(".kt"):
                yield os.path.join(dirpath, n)


# ---------------------------------------------------------------------------
# 6.41.2: второй проход, БИБЛИОТЕЧНЫЕ имена.
#
# Проход выше знает только объявления самого проекта, поэтому 6.41.1 он пропустил:
#
#     LibraryScreen.kt:1212:45 Unresolved reference 'LocalDensity'.
#
# `LocalDensity` объявлен не у нас, а в androidx.compose.ui.platform, и звёздочка
# `androidx.compose.runtime.*` его НЕ накрывает. Ошибка живёт ровно в этом зазоре:
# composition local выглядит как часть runtime, а лежит в другом пакете, и увидеть это
# можно только компилятором — то есть в CI, через полторы минуты и уже после заливки ZIP.
#
# Таблица намеренно короткая: только composition locals, у которых имя ничего не говорит
# о пакете. Для каждого имени перечислены ВСЕ допустимые дома (material и material3 —
# разные пакеты с одинаковыми именами), и срабатывание возможно лишь тогда, когда ни один
# из домов не импортирован ни точкой, ни звёздочкой. Своё объявление с таким же именем
# отменяет проверку: приоритет у проекта.
UI = "androidx.compose.ui.platform"
LIB_LOCALS = {
    "LocalDensity": (UI,),
    "LocalContext": (UI,),
    "LocalConfiguration": (UI,),
    "LocalView": (UI,),
    "LocalFocusManager": (UI,),
    "LocalSoftwareKeyboardController": (UI,),
    "LocalClipboardManager": (UI,),
    "LocalHapticFeedback": (UI,),
    "LocalLayoutDirection": (UI, "androidx.compose.ui.unit"),
    "LocalUriHandler": (UI,),
    "LocalInspectionMode": (UI,),
    "LocalAccessibilityManager": (UI,),
    "LocalWindowInfo": (UI,),
    "LocalIndication": ("androidx.compose.foundation",),
    "LocalOverscrollConfiguration": ("androidx.compose.foundation",),
    "LocalTextSelectionColors": ("androidx.compose.foundation.text.selection",),
    "LocalTextStyle": ("androidx.compose.material3", "androidx.compose.material"),
    "LocalContentColor": ("androidx.compose.material3", "androidx.compose.material"),
    "LocalContentAlpha": ("androidx.compose.material",),
    "LocalAbsoluteTonalElevation": ("androidx.compose.material3",),
    "LocalRippleConfiguration": ("androidx.compose.material3",),
    "LocalMinimumInteractiveComponentSize": ("androidx.compose.material3",),
    "LocalMinimumInteractiveComponentEnforcement": ("androidx.compose.material3",),
    "LocalLifecycleOwner": ("androidx.lifecycle.compose", UI),
    "LocalSavedStateRegistryOwner": ("androidx.savedstate.compose", UI),
    "LocalViewModelStoreOwner": ("androidx.lifecycle.viewmodel.compose",),
    "LocalImageLoader": ("coil.compose",),
}


def library_problems(path, body, exact, star, local, declared):
    """Библиотечные composition locals, использованные без импорта."""
    found = []
    code = re.sub(r"^import[^\n]*\n", "", body, flags=re.M)
    for name in sorted(set(NAME.findall(code))):
        homes = LIB_LOCALS.get(name)
        if not homes:
            continue
        if name in exact or name in local or name in declared:
            continue
        if any(h in star for h in homes):
            continue
        if any((h + "." + name) in body for h in homes):
            continue
        found.append((path, name, homes[0]))
    return found

def main():
    if not os.path.isdir(SRC):
        print("нет " + SRC + " — запускать из корня проекта", file=sys.stderr)
        return 2

    files = list(kt_files())
    decls = {}          # имя -> множество пакетов
    file_pkg = {}
    bodies = {}
    for path in files:
        raw = open(path, encoding="utf-8").read()
        m = re.search(r"^package\s+([\w.]+)", raw, re.M)
        pkg = m.group(1) if m else ""
        file_pkg[path] = pkg
        body = strip_noise(raw)
        bodies[path] = body
        # top-level = без отступа
        for line in body.splitlines():
            if line[:1] in (" ", "\t"):
                continue
            d = DECL.match(line)
            if d:
                decls.setdefault(d.group(2), set()).add(pkg)

    problems = []
    for path in files:
        pkg = file_pkg[path]
        body = bodies[path]
        imported = set(re.findall(r"^import\s+([\w.]+\*?)(?:\s+as\s+(\w+))?", body, re.M))
        exact = set()
        star = set()
        for full, alias in imported:
            if full.endswith(".*"):
                star.add(full[:-2])
            else:
                exact.add(alias or full.rsplit(".", 1)[-1])
        local = set()
        for line in body.splitlines():
            d = DECL.match(line)
            if d:
                local.add(d.group(2))
        # локальные вложенные объявления и параметры типа
        local |= set(re.findall(r"\b(?:class|interface|object|enum class)\s+([A-Z]\w*)", body))

        code = re.sub(r"^import[^\n]*\n", "", body, flags=re.M)
        code = re.sub(r"^package[^\n]*\n", "", code, flags=re.M)
        for name in sorted(set(NAME.findall(code))):
            if name in local or name in exact:
                continue
            pkgs = decls.get(name)
            if not pkgs or len(pkgs) != 1:
                continue
            owner = next(iter(pkgs))
            if owner == pkg or owner in star:
                continue
            if (owner + "." + name) in body:   # полное имя в коде
                continue
            problems.append((path, name, owner))
        problems.extend(library_problems(path, body, exact, star, local, set(decls)))

    for path, name, owner in problems:
        print("НЕ ИМПОРТИРОВАНО: " + path + " → " + name +
              " (объявлен в " + owner + "), нужна строка: import " + owner + "." + name)
    print("проблем: " + str(len(problems)))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
