#!/usr/bin/env python3
"""Compile and execute the actual read-only PCM meter, offline and without Android."""
from pathlib import Path
import os
import subprocess
import tempfile
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
if __name__ == '__main__':
    paths = ['app/src/main/java/app/ziziplayer/playback/dsp/PcmSpectrumAnalyzer.java',
             'app/src/test/java/app/ziziplayer/playback/dsp/PcmSpectrumChecks.java']
    with tempfile.TemporaryDirectory(prefix='zizi-pcm-') as output:
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                        *[str(ROOT / p) for p in paths]], check=True)
        subprocess.run(['java', '-cp', output, 'app.ziziplayer.playback.dsp.PcmSpectrumChecks'], check=True)
