#!/usr/bin/env python3
"""Source integration contracts only: not Kotlin compilation or Android rendering."""
from pathlib import Path
import os
import unittest
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
JAVA = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (JAVA / path).read_text()
class Mobile642Contracts(unittest.TestCase):
    def test_version_and_preflight(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 88', gradle)
        self.assertIn('versionName = "6.41.3"', gradle)
        preflight = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn("'test_mobile_642.py'", preflight)
        self.assertIn("'test_mobile_642_contracts.py'", preflight)
    def test_bottom_alignment_and_safe_insets(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('Alignment.BottomCenter', ui)
        self.assertIn('Modifier.fillMaxSize().safeDrawingPadding()', ui)
        self.assertIn('val availableHeight = maxHeight', ui)
        self.assertIn('heightIn(max = availableHeight)', ui)
        self.assertIn('.verticalScroll(rememberScrollState())', ui)
        self.assertIn('widthIn(max = 360.dp)', ui)
        self.assertIn('decorFitsSystemWindows = false', ui)
    def test_circle_gradient_and_light_numerals(self):
        ui = read('ui/components/VaultAuthDialog.kt').split('private fun PinPad', 1)[1]
        self.assertIn('Brush.linearGradient', ui)
        self.assertIn('lerp(p.brand, Color.White, 0.18f)', ui)
        self.assertIn('p.brand.copy(alpha = 0.42f)', ui)
        self.assertIn('BorderStroke(1.25.dp, ring)', ui)
        self.assertIn('Modifier.size(keySize), shape = CircleShape', ui)
        self.assertIn('FontWeight.Light', ui)
        self.assertNotIn('Color(0x', ui)  # use the actual brand, not a new orange constant
    def test_hollow_pin_dots_and_no_plaintext_semantics(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('.border(1.2.dp, p.brand.copy(alpha = 0.8f), CircleShape)', ui)
        self.assertIn('else Color.Transparent, CircleShape)', ui)
        self.assertIn('password(); contentDescription = "PIN, введено ${value.length} цифр"', ui)
        self.assertNotIn('rememberSaveable', ui)
        self.assertNotIn('OutlinedTextField', ui)
        self.assertNotIn('Touch ID', ui)
        self.assertNotIn('SOS', ui)
    def test_touch_targets_and_short_window_fallback(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('availableHeight < 650.dp || fontScale > 1.2f', ui)
        self.assertIn('if (compact) 56.dp else 64.dp', ui)
        self.assertIn('.coerceAtLeast(48.dp)', ui)
        self.assertIn('Arrangement.spacedBy(if (compact) 8.dp else 10.dp)', ui)
        self.assertIn('heightIn(min = 48.dp)', ui)
    def test_countdown_does_not_move_keypad(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        reserve = ui.index('heightIn(min = 32.dp)')
        countdown = ui.index('if (retrySeconds > 0) Text(')
        self.assertLess(reserve, countdown)
        self.assertIn('delay(1_000)', ui)
        self.assertIn('retrySeconds = vault.remainingSeconds()', ui)
    def test_explicit_submit_preserves_existing_variable_length_pins(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('input.length in 6..12', ui)
        self.assertIn('else if (vault.verify(secret))', ui)
        self.assertIn('Button(onClick = ::submit', ui)
        self.assertIn('if (key == "erase") onChange(value.dropLast(1))', ui)
        self.assertIn('onChange(value + key)', ui)
        self.assertIn('PatternPad(input, enabled', ui)
    def test_real_deadline_persisted_not_just_visual_cap(self):
        vault = read('privacy/FolderVault.kt')
        self.assertIn('val deadline = PrivacyRules.cappedRetryAt(saved, now)', vault)
        self.assertIn('if (deadline != saved) prefs.edit().putLong("retryAt", deadline).apply()', vault)
        self.assertIn('return PrivacyRules.remainingSeconds(deadline, now)', vault)
        self.assertIn('if (!configured || remainingSeconds() > 0)', vault)
        self.assertIn('PrivacyRules.retryDelay(failures)', vault)
        self.assertIn('coerceIn(0, 19) + 1', vault)
        self.assertNotIn('300_000', vault)
    def test_key_hash_and_storage_compatibility(self):
        vault = read('privacy/FolderVault.kt')
        for token in ('folder_vault_v1', 'PBKDF2WithHmacSHA256', '210_000, 256', 'ByteArray(24)',
                      'MessageDigest.isEqual', 'remove("failures").remove("retryAt")', 'mutex.withLock'):
            self.assertIn(token, vault)
    def test_curtain_uses_staged_production_policy(self):
        ui = read('ui/components/VaultPullSurface.kt')
        self.assertIn('VaultPullPolicy.OPEN_DISTANCE_DP.dp.toPx()', ui)
        self.assertIn('hintStage = gesture.hintStage; progress = gesture.progress', ui)
        self.assertIn('Crossfade(targetState = hintStage, animationSpec = tween(140)', ui)
        self.assertIn('1 -> "Потяни ещё немного"', ui)
        self.assertIn('2 -> "Отпусти для открытия"', ui)
        self.assertIn('else -> "Потяни для скрытых папок"', ui)
        self.assertIn('if (dragging) { hintStage', ui)
    def test_release_and_accessibility_are_preserved(self):
        ui = read('ui/components/VaultPullSurface.kt')
        self.assertIn('val shouldOpen = gesture.release()', ui)
        self.assertIn('if (shouldOpen) openVaultAction.invoke()', ui)
        self.assertIn('if (!normalEnd) { gesture.cancel(); sync() }', ui)
        self.assertIn('CustomAccessibilityAction("Открыть скрытые папки")', ui)
        self.assertIn('source != NestedScrollSource.UserInput', ui)
    def test_cover_pairs_wired_for_quick_and_genre_tiles(self):
        ui = read('ui/screens/SearchScreen.kt')
        self.assertEqual(ui.count('frontArt = artPool.getOrNull(DiscoveryArtworkPolicy.frontIndex('), 2)
        self.assertEqual(ui.count('backArt = artPool.getOrNull(DiscoveryArtworkPolicy.backIndex('), 2)
        self.assertEqual(ui.count('TiltedArtPair(frontArt, backArt,'), 2)
        self.assertIn('.filter { it.isNotBlank() }', ui)
        self.assertIn('.distinct()', ui)
    def test_cover_stack_order_angle_cache_and_clip(self):
        ui = read('ui/screens/SearchScreen.kt').split('private fun TiltedArtPair', 1)[1].split('/** Портретная', 1)[0]
        self.assertIn('listOf(false, true).forEach', ui)
        self.assertIn('url = if (front) frontArt else backArt', ui)
        self.assertIn('rotationZ = DiscoveryArtworkPolicy.rotation(front)', ui)
        self.assertIn('maxPx = ARTWORK_ROW_PX', ui)
        self.assertIn('shadowElevation = 8.dp.toPx()', ui)
        self.assertIn('clip = true', ui)
        self.assertNotIn('.clickable', ui)
        self.assertNotIn('loadHub', ui)
    def test_artwork_size_and_title_layer(self):
        ui = read('ui/screens/SearchScreen.kt')
        quick = ui.split('private fun QuickTile(', 1)[1].split('/** Genre tile', 1)[0]
        genre = ui.split('private fun CategoryTile(', 1)[1].split('/** Desktop 0.3.5', 1)[0]
        self.assertIn('(maxWidth * 0.34f).coerceIn(58.dp, 72.dp)', quick)
        self.assertIn('(width * 0.43f).coerceIn(72.dp, 94.dp)', genre)
        for tile in (quick, genre):
            self.assertLess(tile.index('TiltedArtPair('), tile.index('Text('))
            self.assertIn('Brush.verticalGradient', tile)
            self.assertIn('.clipToBounds()', tile)
    def test_secure_and_biometric_boundaries(self):
        ui = read('ui/components/VaultAuthDialog.kt')
        self.assertIn('SecureFlagPolicy.SecureOn', ui)
        self.assertIn('active() && epoch == authEpoch && biometricActive', ui)
        self.assertIn('cancelAuthentication(); dismiss()', ui)
        self.assertIn('Lifecycle.Event.ON_STOP', ui)
        self.assertNotIn('Authenticators.DEVICE_CREDENTIAL', ui)
        self.assertNotIn('window.addFlags', read('MainActivity.kt'))
if __name__ == '__main__': unittest.main(verbosity=2)
