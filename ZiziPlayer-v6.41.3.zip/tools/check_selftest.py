#!/usr/bin/env python3
"""Самотест проверок. Появился в 6.37.1, и не от хорошей жизни.

Три «известных подозрительных вызова» висели в выводе `check_call_args.py` с 6.35.0 и были
записаны в ложные срабатывания. Они действительно были ложными — но причина оказалась не
безобидной: `split_top()` принимал оператор сравнения (`cfg.width < 0.3f`) за открытие
угловой скобки generic, скобка никогда не закрывалась, и ВСЕ аргументы правее переставали
считаться переданными. По замеру на 6.37.0 так разбирались 13 вызовов из 2339 в семи файлах:
два подали сигнал, одиннадцать прошли молча с урезанной проверкой.

Смысл этого файла ровно один. Gradle в песочнице запустить нечем, поэтому `tools/check_*.py` —
единственная граница корректности в проекте. У этой границы не было способа сообщить, что она
сломалась: вывод «подозрительных вызовов: 0» и «проверка местами не работает» — это один и тот
же вывод. Фикстуры делают разницу видимой.

Запускать ДО прогона проверок по коду. Не сошлось — сломан прибор, а не код, и результатам
основного прогона в этом случае верить нельзя.

Формат фикстуры: первая строка `// expect: clean` либо `// expect: <подстрока вердикта>`.
Каждая фикстура проверяется отдельным прогоном, в своём каталоге: у скрипта проверки одно
пространство имён на весь корень, и сигнатуры фикстур не должны видеть друг друга.
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES = os.path.join(HERE, 'fixtures')
CHECKER = os.path.join(HERE, 'check_call_args.py')


def expectation(path):
    with open(path, encoding='utf-8') as fh:
        first = fh.readline().strip()
    m = re.match(r'//\s*expect:\s*(.+)$', first)
    if not m:
        return None
    want = m.group(1).strip()
    return None if want == 'clean' else want


def run_checker(kt_path, work):
    """Гоняет проверку на одной фикстуре в изолированном каталоге."""
    root = os.path.join(work, os.path.splitext(os.path.basename(kt_path))[0])
    os.makedirs(root, exist_ok=True)
    shutil.copy(kt_path, root)
    out = subprocess.run(
        [sys.executable, CHECKER, root],
        capture_output=True, text=True, check=False
    )
    return [l for l in out.stdout.splitlines() if '->' in l]


def main():
    if not os.path.isdir(FIXTURES):
        print('НЕТ КАТАЛОГА ФИКСТУР:', FIXTURES)
        return 1

    names = sorted(f for f in os.listdir(FIXTURES) if f.endswith('.kt'))
    if not names:
        print('НЕТ ФИКСТУР в', FIXTURES)
        return 1

    failed = 0
    work = tempfile.mkdtemp(prefix='zizi-selftest-')
    try:
        for name in names:
            path = os.path.join(FIXTURES, name)
            with open(path, encoding='utf-8') as fh:
                if not re.match(r'//\s*expect:', fh.readline()):
                    print(f'ПРОВАЛ  {name}: нет строки `// expect:` в первой строке')
                    failed += 1
                    continue

            want = expectation(path)
            verdicts = run_checker(path, work)

            if want is None:
                if verdicts:
                    failed += 1
                    print(f'ПРОВАЛ  {name}: ждали чисто, получили {len(verdicts)}:')
                    for v in verdicts:
                        print('           ' + v.strip())
                else:
                    print(f'ок      {name}: чисто, как и ждали')
            else:
                if any(want in v for v in verdicts):
                    print(f'ок      {name}: найдено «{want}»')
                else:
                    failed += 1
                    print(f'ПРОВАЛ  {name}: ждали «{want}», получили '
                          f'{len(verdicts) or "ничего"}:')
                    for v in verdicts:
                        print('           ' + v.strip())
    finally:
        shutil.rmtree(work, ignore_errors=True)

    print(f'\nфикстур: {len(names)} · провалов: {failed}')
    if failed:
        print('Сломан ИНСТРУМЕНТ, а не код. Результатам основного прогона верить нельзя.')
    # 6.39.7: the existing root workflow calls this preflight from the source ZIP.
    # Run UI source contracts here too, so uploading only the ZIP does not leave new
    # regressions disconnected from CI. These are NOT Compose / Kotlin execution tests.
    if not failed:
        for name in ('test_live_ui_contracts.py', 'test_menu_ui_contracts.py',
                     'test_artwork_ui_contracts.py', 'test_artwork_color_math.py',
                     'test_transition_ui_contracts.py', 'test_player_transition_policy.py',
                     'test_mobile_640_contracts.py', 'test_mobile_640.py',
                     'test_mobile_641_contracts.py', 'test_mobile_641.py',
                     'test_mobile_642_contracts.py', 'test_mobile_642.py',
                     'test_mobile_6410_contracts.py', 'test_mobile_6411_contracts.py',
                     'test_mobile_6412_contracts.py', 'test_mobile_6413_contracts.py', 'test_pcm_spectrum.py'):
            print('\n' + ('Production Java core execution: ' if name in ('test_artwork_color_math.py', 'test_player_transition_policy.py', 'test_mobile_640.py', 'test_mobile_641.py', 'test_mobile_642.py', 'test_pcm_spectrum.py')
                           else 'UI source contracts (not Kotlin execution): ') + name, flush=True)
            result = subprocess.run([sys.executable, os.path.join(HERE, name)], check=False)
            if result.returncode != 0:
                failed += 1
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
