#!/usr/bin/env python3
"""Explicit source contracts. No claim of executing Kotlin, Room or Compose."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
J = ROOT / 'app/src/main/java/app/ziziplayer'
def read(p): return (J / p).read_text()

class Home648Contracts(unittest.TestCase):
    def test_home_has_requested_blocks_without_marketing_or_duplicate_player(self):
        s = read('ui/screens/HomeScreen.kt')
        for token in ['HomeTile(', 'HomeCollectionKind.WAVE.title', '"Закрепления"', '"Недавно добавлено"']:
            self.assertIn(token, s)
        for token in ['"continue"', '"privacy"', '"discover"', '"offline-description"', 'Продолжить воспроизведение']:
            self.assertNotIn(token, s)
        self.assertNotIn('MiniPlayer(', s)
        self.assertIn('state.playlists.filter { it.pinned }', s)
        self.assertNotIn('ifEmpty { state.playlists.take', s)

    def test_wave_keeps_offline_projection_with_ranked_fallback_and_bounds(self):
        vm = read('ui/HomeViewModel.kt')
        self.assertIn('HomeCollectionKind.WAVE -> recommendations.state.value.wave.ifEmpty { state.value.offline }', vm)
        self.assertIn('OfflineDownloads.isComplete', vm)
        self.assertIn('.take(50)', vm); self.assertIn('.take(100)', vm)
        self.assertIn('.thenBy { it.id }', vm)
        self.assertNotIn('ZiziResolve', vm); self.assertNotIn('Retrofit', vm)

    def test_history_subscription_is_lazy_and_off_the_main_thread(self):
        vm = read('ui/HomeViewModel.kt')
        self.assertIn('_historyOpen.flatMapLatest',vm)
        self.assertIn('if (open) dao.observeSessions() else flowOf(emptyList<ListeningSessionEntity>())',vm)
        self.assertIn('combine(local, historySessions,',vm)
        self.assertIn('flowOn(Dispatchers.IO)',vm)

    def test_snapshot_keeps_order_and_filters_newly_hidden_or_deleted_tracks(self):
        vm = read('ui/HomeViewModel.kt'); ui = read('ui/screens/HomeScreen.kt')
        self.assertIn('HomeCollection(kind, tracks.map { it.id })',vm)
        self.assertIn('openCollection?.trackIds?.mapNotNull(byId::get)',ui)
        self.assertIn('raw.vaultFolders == gate.folders',ui)
        self.assertIn('t.id !in source.hidden',vm)
        self.assertIn('t.sourceFolder !in gate.folders',vm)
        self.assertIn('if (rows.any { !allowed(it.track) })',vm)
        self.assertIn('allTracks.firstOrNull { it.id == menuTrackId }',ui)

    def test_real_rows_and_actions_are_reused(self):
        ui=read('ui/screens/HomeScreen.kt'); collection=read('ui/screens/HomeCollectionScreen.kt')
        for s in [ui,collection]: self.assertIn('CollectionTrackRow(',s)
        for token in ['ZiziSheetScaffold(', 'TrackMenuAction(', 'vm.toggleFavorite(track)',
                      'vm.playNext(track)', 'vm.addToQueue(track)', 'vm.addToPlaylist(', 'vm.createPlaylist(']:
            self.assertIn(token,ui)

    def test_one_scroller_one_play_and_measured_header(self):
        s=read('ui/screens/PinnedCollectionScaffold.kt')
        self.assertEqual(s.count('LazyColumn('),1)
        self.assertEqual(s.count('ZiziIcons.CollectionPlayFilled'),1)
        self.assertIn('onSizeChanged { heroPx = it.height }',s)
        self.assertIn('density.fontScale',s)
        self.assertIn('G.pinnedPlayTop(scrollPx(), expandedPx, pinnedPx)',s)
        self.assertIn('G.minimumPinnedTail(',s)
        self.assertIn('LocalBottomChromeInset.current',s)
        self.assertIn('LazyListScope.() -> Unit',s)
        self.assertNotIn('Crossfade',s)

    def test_source_identity_crosses_pending_queue_and_session(self):
        pc=read('playback/PlayerController.kt'); svc=read('playback/PlaybackService.kt')
        self.assertIn('val queueSourceId: String? = null',pc)
        self.assertIn('setQueue(q.tracks, q.index, q.play, q.positionMs, q.sourceId)',pc)
        self.assertIn('mediaItemOf(t, sourceId)',pc)
        self.assertIn('putString("zizi.queueSource", it)',pc)
        self.assertIn('queueSourceId = p.currentMediaItem?.mediaMetadata?.extras?.getString("zizi.queueSource")',pc)
        self.assertIn('Bundle(item.mediaMetadata.extras ?: Bundle.EMPTY)',svc)
        self.assertIn('val ownsQueue = playback.queueSourceId == sourceId',read('ui/screens/HomeCollectionScreen.kt'))
        self.assertIn('sourceId = sourceId', read('ui/MainViewModel.kt'))

    def test_back_and_project_version(self):
        self.assertIn('_collection.value = null; _catalogTracks.value = emptyList(); return true',read('ui/HomeViewModel.kt'))
        self.assertIn('collectionEpoch++; collectionJob?.cancel()',read('ui/HomeViewModel.kt'))
        self.assertIn('tab == ZiziTab.HOME && homeVm.back()',read('MainActivity.kt'))
        s=(ROOT/'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 117',s); self.assertIn('versionName = "6.62.0-lyrics-hybrid"',s)

if __name__ == '__main__': unittest.main(verbosity=2)
