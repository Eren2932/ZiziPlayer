#!/usr/bin/env python3
"""Production Java plus source wiring guards, not Kotlin/Compose execution."""
from pathlib import Path
import ast
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
SCREENS = SRC / 'ui/screens'

class Collection6601(unittest.TestCase):
    def test_production_geometry(self):
        files = [SRC / 'ui/CollectionGeometry.java', SRC / 'ui/CollectionCollapseMath.java',
                 ROOT / 'app/src/test/java/app/ziziplayer/ui/Collection6601Checks.java']
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                            '-d', out, *map(str, files)], check=True)
            subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.Collection6601Checks'], check=True)

    def test_menu_is_hero_only_not_a_banner_action(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        scaffold, row = s.split('internal fun CollectionActionsRow(', 1)
        self.assertNotIn('onMenu', scaffold)
        self.assertNotIn('"Меню плейлиста"', scaffold)
        self.assertIn('if (onMenu != null) IconButton(onClick = onMenu', row)
        self.assertIn('"collection:menu"', row)

    def test_panel_and_title_share_fade_without_capturing_expanded_cover(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        self.assertEqual(s.count('alpha = bannerAlpha'), 2)
        self.assertIn('if (bannerAlpha > 0f) Box(', s)
        self.assertIn('remember(list, heroPx, expandedPx, pinnedPx)', s)
        self.assertIn('if (heroPx > 0) collapse() else 0f', s)

    def test_search_removed_from_all_shared_collection_routes(self):
        for name in ['UnifiedLocalCollectionScreen.kt', 'HomeCollectionScreen.kt', 'RemoteCollectionScreen.kt']:
            s = (SCREENS / name).read_text()
            for bad in ['Поиск в подборке', 'OutlinedTextField(', 'BasicTextField(', 'vm.setQuery(']:
                self.assertNotIn(bad, s)
            self.assertIn('CollectionActionsRow(', s)
            self.assertNotIn('ZiziIcons.Shuffle', s)  # sole shared layout, no stray left shuffle

    def test_actions_use_shared_width_based_geometry(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        self.assertIn('val playSize = metrics.touchSize', s)
        self.assertIn('padding(end = metrics.touchEnd)', s)
        row = s.split('internal fun CollectionActionsRow(', 1)[1]
        for part in ['m.touchEnd + m.touchSize + m.actionGap', 'verticalAlignment = Alignment.Bottom',
                     'Modifier.weight(1f)', 'FlowRow(', 'Modifier.size(m.touchSize)',
                     'H.SHUFFLE_CANVAS * m.unit']:
            self.assertIn(part, row)
        for name in ['UnifiedLocalCollectionScreen.kt', 'HomeCollectionScreen.kt', 'RemoteCollectionScreen.kt']:
            self.assertIn('CollectionHeroContent(', (SCREENS / name).read_text())
        self.assertIn('Spacer(Modifier.height(m.bottomGap))', (SCREENS / 'CollectionHeroContent.kt').read_text())

    def test_existing_local_actions_and_source_identity_preserved(self):
        s = (SCREENS / 'UnifiedLocalCollectionScreen.kt').read_text()
        for part in ['onClick = onSort', 'onClick = onAdd', 'showDownloads = true',
                     'CollectionDownloadDialog(vm, state.collectionTracks', 'PlaylistActionsHost(',
                     'vm.play(it, shuffled, destination)', 'playback.queueSourceId == destination']:
            self.assertIn(part, s)

    def test_no_hidden_filter_on_navigation(self):
        s = (SRC / 'ui/MainViewModel.kt').read_text()
        for method in ['setFilter', 'openPlaylist', 'openFolder']:
            block = s.split('fun ' + method + '(', 1)[1].split('\n    }', 1)[0]
            self.assertIn('query = ""', block)
            self.assertIn('searchOpen = false', block)

    def test_empty_lists_disable_shuffle_on_all_routes(self):
        for name, data in [('UnifiedLocalCollectionScreen.kt', 'state.visible'),
                           ('HomeCollectionScreen.kt', 'tracks'), ('RemoteCollectionScreen.kt', 'open.tracks')]:
            self.assertIn('shuffleEnabled = ' + data + '.isNotEmpty()', (SCREENS / name).read_text())

    def test_release_identity(self):
        s = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 117', s)
        self.assertIn('versionName = "6.62.0-lyrics-hybrid"', s)

    def test_connected_to_existing_ci_preflight(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        main = next(n for n in ast.parse(s).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        self.assertIn('test_collection_6601.py', ast.get_source_segment(s, main))

if __name__ == '__main__':
    unittest.main(verbosity=2)
