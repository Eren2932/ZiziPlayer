"""Real Java geometry + source/resource contracts. Not Kotlin compilation or Android rendering."""
from pathlib import Path
import hashlib
import subprocess
import tempfile
import unittest
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'

class Auth6610(unittest.TestCase):
    def test_production_geometry(self):
        with tempfile.TemporaryDirectory() as d:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', d,
                str(S/'ui/BookPageGeometry.java'),
                str(R/'app/src/test/java/app/ziziplayer/ui/BookPageGeometryChecks.java')], check=True)
            subprocess.run(['java', '-cp', d, 'app.ziziplayer.ui.BookPageGeometryChecks'], check=True)

    def test_one_clock_and_correct_direction(self):
        host = (S/'ui/components/BookOverlayHost.kt').read_text()
        self.assertEqual(host.count('Animatable('), 1)
        for fragment in ('BookPageGeometry.baseOffset(width, progress.value, completing)',
                         'BookPageGeometry.pageOffset(width, progress.value, completing)',
                         'tween(280, easing = FastOutSlowInEasing)', 'open || progress.value > 0f',
                         'open && progress.value == 1f && !progress.isRunning', 'clipToBounds()',
                         'clearAndSetSemantics', 'blockSurfaceInput()', 'surfaceInputBoundary()'):
            self.assertIn(fragment, host)
        self.assertNotIn('fadeIn', host)
        self.assertNotIn('delay(', host)
        auth = (S/'ui/screens/AccountAuthScreen.kt').read_text()
        self.assertIn('if (targetState.backwards) -1 else 1', auth)
        self.assertIn('{ it * direction }', auth)
        self.assertIn('{ -it * direction }', auth)
        self.assertEqual(auth.count('tween(280, easing = FastOutSlowInEasing)'), 2)
        self.assertIn('if (!enabled) Box(Modifier.fillMaxSize().blockSurfaceInput())', auth)
        self.assertIn('Modifier.clearAndSetSemantics', auth)

    def test_all_entry_points_share_host_and_no_library_unmount(self):
        main = (S/'MainActivity.kt').read_text()
        self.assertIn('BookOverlayHost(open = authOpen', main)
        self.assertNotIn('visible = authOpen', main)
        self.assertNotIn('libraryOpen && !authOpen', main)
        self.assertIn('closeForward = authCompleted', main)
        self.assertIn('authCompleted = true', main)
        self.assertIn('accounts.markSignedIn(email, id)', main)
        self.assertIn('interactive = authInteractive', main)
        self.assertIn('if (!authOpen) accounts.chooseGuest()', main)
        welcome = (S/'ui/screens/WelcomeScreen.kt').read_text()
        self.assertIn('BookOverlayHost(open = about', welcome)
        self.assertIn('BackHandler { if (interactive) about = false }', welcome)
        self.assertNotIn('AlertDialog', welcome)

    def test_discard_stays_a_confirmation_and_credentials_stay_ephemeral(self):
        auth = (S/'ui/screens/AccountAuthScreen.kt').read_text()
        self.assertIn('if (discard) AlertDialog', auth)
        self.assertIn('FLAG_SECURE', auth)
        self.assertNotIn('rememberSaveable', auth)
        self.assertIn('history.settle(transition.currentState.revision)', auth)
        self.assertIn('AuthFlow.entries.associateWith { AuthDraft() }', auth)

    def test_success_resets_history_but_is_not_a_back_press(self):
        history = (S/'ui/screens/AuthHistory.java').read_text()
        reset = history.split('public boolean resetTo', 1)[1].split('private void begin', 1)[0]
        self.assertIn('begin(false)', reset)
        self.assertNotIn('begin(true)', reset)

    def test_logo_exact_reviewed_resource(self):
        logo = R/'app/src/main/res/drawable/zizi_auth_logo.png'
        self.assertEqual(hashlib.sha256(logo.read_bytes()).hexdigest(),
            'd5029e89c0de93ba178a4c898f9703d48ed66a8caef83b8852b89c2f34179a6e')
        self.assertIn('Modifier.size(80.dp)', (S/'ui/screens/WelcomeScreen.kt').read_text())

    def test_release_identity(self):
        gradle = (R/'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 117', gradle)
        self.assertIn('versionName = "6.62.0-lyrics-hybrid"', gradle)
        self.assertIn('test_auth_6610.py', (R/'tools/check_selftest.py').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
