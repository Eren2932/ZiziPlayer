package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.Request
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Production coordinator + production OVH adapter, fake transport. No live API or Android UI. */
class LyricsHybridTest {
    private val track = TrackEntity(id = "fixture", uri = "", title = "Raya (Ultra Slowed)",
        artist = "Zericxxn", durationMs = 130_000L)
    private fun payload() = JSONObject().put("source", "fixture").put("plainLyrics", "synthetic text")
    private fun request() = Request.Builder().url("https://lrclib.net/api/get").build()
    private fun provider(name: String, budget: Long = 1_000L,
        run: suspend (suspend (Request) -> String) -> JSONObject?) = object : LyricsProvider {
        override val id = name
        override val budgetMs = budget
        override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
            trace: LyricsLookupTrace?) = run(http)
    }
    private suspend fun failure(run: suspend () -> Unit): Exception {
        try { run() } catch (e: Exception) { return e }
        throw AssertionError("Expected failure")
    }

    @Test fun primaryHitDoesNotContactFallback() = runBlocking {
        val expected = payload()
        var called = false
        val lookup = LyricsHybridLookup(listOf(provider("primary") { expected },
            provider("fallback") { called = true; payload() }), { 0L })
        assertSame(expected, lookup.lookup(track, { _, _ -> error("No HTTP expected") }, null))
        assertFalse(called)
    }

    @Test fun primaryMissUsesRealOvhAdapter() = runBlocking {
        val lookup = LyricsHybridLookup(listOf(provider("primary") { null }, OvhLyricsProvider()), { 0L })
        val result = lookup.lookup(track, { p, _ ->
            assertEquals("lyrics.ovh", p.id)
            """{"lyrics":"synthetic line one\nsynthetic line two"}"""
        }, null)
        assertEquals("lyrics.ovh", result.getString("source"))
        assertEquals("", result.getString("syncedLyrics"))
        assertFalse(result.getBoolean("matchVerified"))
        assertEquals(0, result.getInt("duration"))
    }

    @Test fun outageCanUseFallbackButOutagePlusMissIsNotNegative() = runBlocking {
        val broken = provider("primary") { throw IOException("offline") }
        val expected = payload()
        assertSame(expected, LyricsHybridLookup(listOf(broken, provider("backup") { expected }), { 0L })
            .lookup(track, { _, _ -> "" }, null))
        val error = failure {
            LyricsHybridLookup(listOf(broken, provider("backup") { null }), { 0L })
                .lookup(track, { _, _ -> "" }, null)
        }
        assertTrue(error is IOException)
        assertFalse(error is LyricsRepository.NoLyrics)
    }

    @Test fun allMissesProduceNegativeResult() = runBlocking {
        val error = failure {
            LyricsHybridLookup(listOf(provider("one") { null }, provider("two") { null }), { 0L })
                .lookup(track, { _, _ -> "" }, null)
        }
        assertTrue(error is LyricsRepository.NoLyrics)
    }

    @Test fun primary429DoesNotBlockBackupOrNextSongAndExpires() = runBlocking {
        var now = 0L
        var primaryCalls = 0
        var backupCalls = 0
        val lookup = LyricsHybridLookup(listOf(provider("primary") { http ->
            primaryCalls++; http(request()); payload()
        }, provider("backup") { backupCalls++; payload() }), { now })
        val transport: suspend (LyricsProvider, Request) -> String = { _, _ ->
            throw LyricsRepository.HttpFailure(429, "rate limited")
        }
        lookup.lookup(track, transport, null)
        now = 59_999L
        lookup.lookup(track.copy(id = "next"), transport, null)
        assertEquals(1, primaryCalls)
        assertEquals(2, backupCalls)
        now = 60_000L
        lookup.lookup(track, transport, null)
        assertEquals(2, primaryCalls)
    }

    @Test fun fallback429DoesNotBlockRecoveredPrimary() = runBlocking {
        var primaryHit = false
        val lookup = LyricsHybridLookup(listOf(provider("primary") { if (primaryHit) payload() else null },
            provider("backup") { http -> http(request()); payload() }), { 0L })
        val failedLookup = failure { lookup.lookup(track, { _, _ -> throw LyricsRepository.HttpFailure(429, "429") }, null) }
        assertTrue(failedLookup is LyricsRepository.HttpFailure)
        primaryHit = true
        assertEquals("fixture", lookup.lookup(track, { _, _ -> error("No network expected") }, null).getString("source"))
    }

    @Test fun cancellationAndAudioBusyNeverAdvanceToAnotherProvider() = runBlocking {
        for (reason in listOf(CancellationException("track changed"), LyricsRepository.AudioBusy())) {
            var backupCalls = 0
            val lookup = LyricsHybridLookup(listOf(provider("primary") { throw reason },
                provider("backup") { backupCalls++; payload() }), { 0L })
            assertSame(reason, failure { lookup.lookup(track, { _, _ -> "" }, null) })
            assertEquals(0, backupCalls)
        }
    }

    @Test fun parentDeadlineIsNotMistakenForProviderTimeout() = runBlocking {
        var backupCalls = 0
        val lookup = LyricsHybridLookup(listOf(provider("primary") { awaitCancellation() },
            provider("backup") { backupCalls++; payload() }), { 0L })
        val error = failure { withTimeout(20L) { lookup.lookup(track, { _, _ -> "" }, null) } }
        assertTrue(error is CancellationException)
        assertEquals(0, backupCalls)
    }

    @Test fun providerDeadlineCanAdvanceToBackup() = runBlocking {
        var cleanup = false
        val lookup = LyricsHybridLookup(listOf(provider("primary", 20L) {
            try { awaitCancellation() } finally { cleanup = true }
        }, provider("backup") { payload() }), { 0L })
        assertEquals("fixture", lookup.lookup(track, { _, _ -> "" }, null).getString("source"))
        assertTrue(cleanup)
    }

    @Test fun requestLimitIsEnforcedByCoordinator() = runBlocking {
        var calls = 0
        val lookup = LyricsHybridLookup(listOf(provider("tooMany") { http ->
            http(request()); http(request()); payload()
        }), { 0L })
        val error = failure { lookup.lookup(track, { _, _ -> calls++; "{}" }, null) }
        assertTrue(error is IOException)
        assertEquals(1, calls)
    }

    @Test fun ovhUsesExactEncodedPathWithoutTitleStrippingOrCredentials() = runBlocking {
        val wanted = track.copy(artist = "AC/DC & café", title = "Raya (Ultra Slowed) / 100%? #")
        OvhLyricsProvider().lookup(wanted, { request ->
            assertEquals(listOf("v1", wanted.artist, wanted.title), request.url.pathSegments)
            assertEquals("api.lyrics.ovh", request.url.host)
            assertEquals("https", request.url.scheme)
            assertNull(request.url.query)
            assertNull(request.header("Authorization"))
            assertNull(request.header("Cookie"))
            """{"lyrics":"synthetic","syncedLyrics":"[00:01.00]DO NOT USE"}"""
        }, null)?.let { assertTrue(LrcTimeline.parse(it.getString("syncedLyrics")).isEmpty()) }
            ?: throw AssertionError("Missing result")
    }

    @Test fun ovh404IsAMissButMalformedOrEmptyResponsesAreNot() = runBlocking {
        val provider = OvhLyricsProvider()
        assertNull(provider.lookup(track, { throw LyricsRepository.HttpFailure(404, "not found") }, null))
        for (body in listOf("not json", "{}", "{\"lyrics\":null}", "{\"lyrics\":123}",
            "{\"lyrics\":\" \"}", "{\"lyrics\":\"<html>failure</html>\"}",
            "{\"lyrics\":\"synthetic\",\"error\":\"failed\"}")) {
            val lookup = LyricsHybridLookup(listOf(provider), { 0L })
            val error = failure { lookup.lookup(track, { _, _ -> body }, null) }
            assertTrue(error is IOException)
            assertFalse(error is LyricsRepository.NoLyrics)
        }
    }

    @Test fun diagnosticContainsSourcesButNotBodyOrCompleteUrl() = runBlocking {
        val trace = LyricsLookupTrace()
        LyricsHybridLookup(listOf(provider("primary") { null }, OvhLyricsProvider()), { 0L })
            .lookup(track, { _, _ -> """{"lyrics":"SECRET_SYNTHETIC_BODY"}""" }, trace)
        assertTrue(trace.render().contains("lyrics.ovh"))
        assertFalse(trace.render().contains("SECRET_SYNTHETIC_BODY"))
        assertFalse(trace.render().contains("https://"))
    }
}
