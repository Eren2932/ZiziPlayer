package app.ziziplayer.lyrics

import android.content.Context
import app.ziziplayer.playback.StartupTrace
import android.net.Uri
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import org.json.JSONArray
import kotlinx.coroutines.CancellationException
import android.os.SystemClock
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToLong

internal data class LyricsDocument(
    val lines: List<LrcTimeline.Line>,
    val plain: String,
    val source: String,
    val durationMs: Long,
    val instrumental: Boolean = false,
    val matchVerified: Boolean = true
) {
    val hasText: Boolean get() = !instrumental && (lines.any { it.text.isNotBlank() } || plain.isNotBlank())
}

/** Automatic current-track metadata only; no audio uploads or resolver credentials. */
class LyricsRepository(context: Context) {
    private val app = context.applicationContext
    private val lock = Mutex()
    private val misses = object : LinkedHashMap<String, Long>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean = size > 128
    }
    private val hybrid by lazy {
        LyricsHybridLookup(listOf(object : LyricsProvider {
            override val id: String = "LRCLIB"
            override val budgetMs: Long = 26_000L
            override val requestLimit: Int = 3
            override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
                trace: LyricsLookupTrace?): JSONObject? = lookupLrclib(track, http, trace)
        }, OvhLyricsProvider()), { SystemClock.elapsedRealtime() })
    }
    private val offsets by lazy { app.getSharedPreferences("lyrics-offsets-v1", Context.MODE_PRIVATE) }
    internal suspend fun advance(track: TrackEntity): Long = withContext(Dispatchers.IO) {
        offsets.getLong(key(track), 0L).coerceIn(-60000L, 60000L)
    }
    internal suspend fun saveAdvance(track: TrackEntity, value: Long) = withContext(Dispatchers.IO) {
        val id = key(track)
        val edit = offsets.edit()
        if (offsets.all.size >= 256 && !offsets.contains(id)) offsets.all.keys.take(32).forEach { edit.remove(it) }
        edit.putLong(id, value.coerceIn(-60000L, 60000L)).apply()
    }
    // A dedicated public-metadata client MUST NOT inherit the resolver's auth interceptor.
    private val client by lazy {
        OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS)
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false).followRedirects(false).build()
    }
    private data class CachedDocument(val document: LyricsDocument, val expiresAt: Long)
    private val memory = object : LinkedHashMap<String, CachedDocument>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedDocument>?): Boolean = size > 24
    }
    private fun key(track: TrackEntity): String {
        val identity = listOf(track.id, track.title, track.artist, track.album, track.durationMs.toString())
        val encoded = identity.joinToString("") { "${it.length}:$it" }
        return MessageDigest.getInstance("SHA-256").digest(encoded.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
    private fun dir(imported: Boolean) = File(if (imported) app.filesDir else app.cacheDir,
        if (imported) "lyrics-imports-v1" else "lyrics-cache-v1").apply { mkdirs() }
    private fun decode(json: JSONObject): LyricsDocument {
        val synced = if (json.isNull("syncedLyrics")) "" else json.optString("syncedLyrics", "")
        val plain = if (json.isNull("plainLyrics")) "" else json.optString("plainLyrics", "")
        return LyricsDocument(LrcTimeline.parse(synced), plain,
            json.optString("source", "LRCLIB"), (json.optDouble("duration", 0.0) * 1000).roundToLong(),
            json.optBoolean("instrumental", false), json.optBoolean("matchVerified", true))
    }
    internal suspend fun cached(track: TrackEntity): LyricsDocument? = withContext(Dispatchers.IO) {
        lock.withLock {
            val id = key(track)
            val now = SystemClock.elapsedRealtime()
            memory[id]?.takeIf { now < it.expiresAt }?.let { return@withLock it.document }
            memory.remove(id)
            sequenceOf(File(dir(true), "$id.json"), File(dir(false), "$id.json"))
                .mapNotNull { file ->
                    val imported = file.parentFile == dir(true)
                    val age = (System.currentTimeMillis() - file.lastModified()).coerceAtLeast(0L)
                    if (!file.isFile || file.length() > MAX_BYTES || (!imported && age > CACHE_AGE_MS)) null
                    else try {
                        val doc = decode(JSONObject(file.readText()))
                        CachedDocument(doc, if (imported) Long.MAX_VALUE else now + CACHE_AGE_MS - age)
                    } catch (_: Exception) { null }
                }.firstOrNull()?.also { memory[id] = it }?.document
        }
    }
    private suspend fun store(track: TrackEntity, json: JSONObject, imported: Boolean): LyricsDocument =
        withContext(Dispatchers.IO) {
            lock.withLock {
                val doc = decode(json)
                val id = key(track)
                val folder = dir(imported)
                val target = File(folder, "$id.json")
                val entries = folder.listFiles { f -> f.extension == "json" }.orEmpty()
                if (imported && !target.exists() && entries.size >= 128)
                    throw IOException("Достигнут лимит 128 импортированных текстов")
                val encoded = json.toString().toByteArray(Charsets.UTF_8)
                if (encoded.size > MAX_BYTES) throw IOException("Слишком большой текст")
                val tmp = File.createTempFile("lyrics-", ".tmp", folder)
                try {
                    tmp.writeBytes(encoded)
                    if (!tmp.renameTo(target)) throw IOException("Не удалось сохранить текст")
                } finally { tmp.delete() }
                if (!imported) folder.listFiles { f -> f.extension == "json" }.orEmpty()
                    .sortedByDescending { it.lastModified() }.drop(48).forEach { it.delete() }
                memory[id] = CachedDocument(doc, if (imported) Long.MAX_VALUE else SystemClock.elapsedRealtime() + CACHE_AGE_MS)
                doc
            }
        }
    internal suspend fun importLrc(track: TrackEntity, uri: Uri): LyricsDocument = withContext(Dispatchers.IO) {
        val text = app.contentResolver.openInputStream(uri)?.use { readLimited(it).toString(Charsets.UTF_8) }
            ?: throw IOException("Не удалось открыть LRC")
        if (LrcTimeline.parse(text).isEmpty()) throw IOException("В файле нет таймкодов LRC. Нужен UTF-8 LRC")
        store(track, JSONObject().put("syncedLyrics", text).put("plainLyrics", "")
            .put("source", "Импорт LRC").put("duration", 0), true)
    }
    internal suspend fun fetch(track: TrackEntity, force: Boolean = false,
        awaitNetworkSlot: suspend () -> Unit, trace: LyricsLookupTrace? = null): LyricsDocument = withContext(Dispatchers.IO) {
        if (track.title.isBlank() || track.artist.isBlank() ||
            track.artist.equals("Неизвестный артист", true) || track.artist.equals("<unknown>", true))
            throw NoLyrics("Недостаточно метаданных для текста")
        val id = key(track)
        val now = SystemClock.elapsedRealtime()
        lock.withLock {
            if (!force && now < (misses[id] ?: 0L))
                throw NoLyrics("Текст пока не найден. Можно повторить поиск вручную")
        }
        try {
            val payload = hybrid.lookup(track, { provider, request ->
                get(request, awaitNetworkSlot, trace, provider.id)
            }, trace)
            // The unverified fallback is short-lived RAM only: no persistent disk copy and no
            // month-long suppression of a newly published synchronized LRCLIB entry.
            val stored = if (!payload.optBoolean("matchVerified", true)) {
                decode(payload).also { found -> lock.withLock {
                    memory[id] = CachedDocument(found, SystemClock.elapsedRealtime() + FALLBACK_AGE_MS)
                } }
            } else try { store(track, payload, false) }
                catch (e: CancellationException) { throw e }
                catch (_: IOException) {
                    decode(payload).also { found -> lock.withLock {
                        memory[id] = CachedDocument(found, SystemClock.elapsedRealtime() + CACHE_AGE_MS)
                    } }
                }
            lock.withLock { misses.remove(id) }
            stored
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lock.withLock {
                val time = SystemClock.elapsedRealtime()
                // Only ALL-provider misses are negative-cached; errors/backoff are not misses.
                if (e is NoLyrics) misses[id] = time + 120_000L
            }
            throw e
        }
    }
    private suspend fun lookupLrclib(track: TrackEntity, http: suspend (Request) -> String,
        trace: LyricsLookupTrace?): JSONObject? {
        val candidates = mutableListOf<Candidate>()
        var exactFailure: IOException? = null
        // Exact first. Missing/unknown album and duration must not poison the search fallback.
        if (track.durationMs > 0L) {
            val builder = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
                .addQueryParameter("track_name", track.title)
                .addQueryParameter("artist_name", track.artist)
                .addQueryParameter("duration", (track.durationMs / 1000.0).toString())
            if (track.album.isNotBlank()) builder.addQueryParameter("album_name", track.album)
            val exact = try { JSONObject(http(request(builder.build()))) }
                catch (e: CancellationException) { throw e }
                catch (e: IOException) {
                    when {
                        e is HttpFailure && e.status == 404 -> null
                        e is AudioBusy || e is DeferredLyrics -> throw e
                        e is HttpFailure && e.status < 500 -> throw e
                        else -> {
                            // An exact endpoint outage does not prove the search endpoint is down.
                            // Keep the error: empty fallback results must not become a cached miss.
                            exactFailure = e
                            trace?.add("Exact unavailable; trying bounded search fallback")
                            null
                        }
                    }
                }
            exact?.let { candidate(track, it, trace) }?.let { candidates.add(it) }
        }
        if (candidates.none { it.synchronized && it.document.hasText }) {
            val title = LyricsMatchPolicy.searchTitle(track.title)
            // At most 3 LRCLIB HTTP calls: exact, title+artist, title-only. The last query
            // tolerates provider spelling (Jung Kook / Jungkook); selection STILL checks artist.
            for (includeArtist in listOf(true, false)) {
                val builder = "https://lrclib.net/api/search".toHttpUrl().newBuilder()
                    .addQueryParameter("track_name", title)
                if (includeArtist) builder.addQueryParameter("artist_name", track.artist)
                val result = try { JSONArray(http(request(builder.build()))) }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) {
                        if (e is HttpFailure && e.status == 404) JSONArray()
                        else {
                            // A later fallback outage must not discard text already found.
                            if (candidates.any { it.document.hasText }) break
                            throw e
                        }
                    }
                trace?.add("Search artist=$includeArtist: ${result.length()} rows")
                for (index in 0 until minOf(result.length(), 100)) {
                    result.optJSONObject(index)?.let { candidate(track, it, trace) }?.let { candidates.add(it) }
                }
                if (candidates.any { it.synchronized && it.document.hasText }) break
            }
        }
        val selected = candidates.sortedWith(
            compareByDescending<Candidate> { it.document.hasText }
                .thenByDescending { it.synchronized }
                .thenBy { kotlin.math.abs(it.document.durationMs - track.durationMs) }
                .thenByDescending { track.album.isNotBlank() && it.json.optString("albumName").equals(track.album, true) }
                .thenBy { it.json.optLong("id", Long.MAX_VALUE) }
        ).firstOrNull() ?: return if (exactFailure != null) throw exactFailure else null
        // Alternate LRC timestamps are not different songs. Pick deterministically instead
        // of rejecting the entire result set. A mismatched duration never gets fake timings.
        val doc = selected.document
        trace?.add("Selected LRCLIB id=${selected.json.optLong("id")} durationMs=${doc.durationMs} synchronized=${selected.synchronized} instrumental=${doc.instrumental}")
        val plain = doc.plain.ifBlank { doc.lines.joinToString("\n") { it.text } }
        return JSONObject()
            .put("syncedLyrics", if (selected.synchronized) selected.json.opt("syncedLyrics") else "")
            .put("plainLyrics", plain).put("duration", doc.durationMs / 1000.0)
            .put("instrumental", doc.instrumental).put("source", "LRCLIB")
    }
    internal fun retryDelay(error: Exception): Long? = when {
        error is AudioBusy -> 5_000L
        error is DeferredLyrics -> error.delayMs
        error is NoLyrics -> null
        error is HttpFailure && error.status == 429 -> 60_000L
        error is HttpFailure && error.status < 500 -> null
        error is IOException -> 30_000L
        else -> null
    }
    private data class Candidate(val json: JSONObject, val document: LyricsDocument, val synchronized: Boolean)
    private fun candidate(track: TrackEntity, json: JSONObject, trace: LyricsLookupTrace? = null): Candidate? {
        fun reject(reason: String): Candidate? { trace?.count(reason); return null }
        if (!LyricsMatchPolicy.identityMatches(track.title, track.artist, json.optString("trackName"), json.optString("artistName"))) return reject("Rejected: identity")
        val seconds = json.optDouble("duration", 0.0)
        if (!seconds.isFinite() || seconds <= 0 || seconds > 86400) return reject("Rejected: invalid duration")
        val doc = try { decode(json) } catch (_: Exception) { return reject("Rejected: invalid LRC") }
        if (LyricsMatchPolicy.requiresExactDuration(track.title, json.optString("trackName")) &&
            !LrcTimeline.durationMatches(track.durationMs, doc.durationMs)) return reject("Rejected: guest-credit duration")
        if (!(doc.instrumental || doc.hasText)) return reject("Rejected: empty text")
        if (!LyricsMatchPolicy.textDurationMatches(track.durationMs, doc.durationMs)) return reject("Rejected: text duration")
        val validTimings = (doc.lines.lastOrNull()?.timeMs ?: 0L) <= doc.durationMs + 2000 &&
            doc.lines.all { line -> line.words.all { it.timeMs <= doc.durationMs + 2000 } }
        trace?.count("Accepted candidates")
        trace?.add("Candidate id=${json.optLong("id")} durationMs=${doc.durationMs} cues=${doc.lines.size} timingValid=$validTimings deltaMs=${doc.durationMs - track.durationMs}")
        return Candidate(json, doc, doc.lines.isNotEmpty() && validTimings &&
            LrcTimeline.durationMatches(track.durationMs, doc.durationMs))
    }
    private fun request(url: okhttp3.HttpUrl) = Request.Builder().url(url)
        .header("User-Agent", "ZiziPlayer/6.62.0-lyrics-hybrid (https://github.com/Eren2932/ZiziPlayer)")
        .header("Accept", "application/json").build()
    internal class AudioBusy : IOException("Текст отложен: ожидаем запуск аудио. Можно повторить поиск")
    internal class DeferredLyrics(val delayMs: Long) : IOException("Поиск отложен сервисом")
    internal class NoLyrics(message: String) : IOException(message)
    internal class HttpFailure(val status: Int, message: String) : IOException(message)
    private suspend fun get(request: Request, awaitNetworkSlot: suspend () -> Unit, trace: LyricsLookupTrace? = null, provider: String = "LRCLIB"): String {
        // Gate every fallback/retry, not just the initial search. Cache/import do not wait.
        // An already-running request remains cancellable on track/settings changes.
        trace?.add("$provider: waiting for audio")
        awaitNetworkSlot()
        trace?.add("$provider: GET ${request.url.host}")
        val span = StartupTrace.begin(StartupTrace.Stage.LYRICS_HTTP)
        try {
            return execute(request, span).also {
                trace?.add("$provider: HTTP success")
                StartupTrace.finish(span, StartupTrace.Outcome.OK)
            }
        } catch (e: CancellationException) {
            StartupTrace.finish(span, StartupTrace.Outcome.CANCELLED)
            throw e
        } catch (e: Exception) {
            trace?.add(if (e is HttpFailure) "$provider: HTTP ${e.status}" else "$provider: network/body error ${e.javaClass.simpleName}")
            StartupTrace.finish(span, StartupTrace.Outcome.ERROR)
            throw e
        }
    }
    private suspend fun execute(request: Request, span: StartupTrace.Span): String = suspendCancellableCoroutine { continuation ->
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWithException(IOException("Сервис текста недоступен. Проверьте сеть", e))
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    try {
                        if (!continuation.isActive) return
                        StartupTrace.http(span, r.code)
                        if (!r.isSuccessful) throw HttpFailure(r.code, when (r.code) {
                            404 -> "Для этой версии текст не найден. Можно импортировать LRC"
                            429 -> "Сервис ограничил запросы. Попробуйте позднее"
                            else -> "Сервис текста временно недоступен (HTTP ${r.code})"
                        })
                        val body = r.body ?: throw IOException("Пустой ответ сервиса")
                        val raw = body.byteStream().use { readLimited(it).toString(Charsets.UTF_8) }
                        if (continuation.isActive) continuation.resume(raw)
                    } catch (e: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(e)
                    }
                }
            }
        })
    }
    private fun readLimited(input: InputStream): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (output.size() + count > MAX_BYTES) throw IOException("Текст превышает лимит 512 КБ")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }
    private companion object {
        const val FALLBACK_AGE_MS = 10L * 60 * 1000
        const val MAX_BYTES = 512 * 1024
        const val CACHE_AGE_MS = 30L * 24 * 60 * 60 * 1000
    }
}
