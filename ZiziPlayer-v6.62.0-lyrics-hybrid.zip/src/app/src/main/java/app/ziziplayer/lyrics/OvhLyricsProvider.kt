package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/** Public documented API: exact artist/title path, no search, no version stripping.
 * It returns no recording metadata or timestamps. Never claim verified identity or sync.
 */
internal class OvhLyricsProvider : LyricsProvider {
    override val id: String = "lyrics.ovh"
    override val budgetMs: Long = 8_000L

    override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
        trace: LyricsLookupTrace?): JSONObject? {
        val url = "https://api.lyrics.ovh/v1".toHttpUrl().newBuilder()
            .addPathSegment(track.artist.trim()).addPathSegment(track.title.trim()).build()
        val request = Request.Builder().url(url)
            .header("User-Agent", "ZiziPlayer/6.62.0-lyrics-hybrid (https://github.com/Eren2932/ZiziPlayer)")
            .header("Accept", "application/json").build()
        val raw = try { http(request) }
            catch (e: LyricsRepository.HttpFailure) { if (e.status == 404) return null else throw e }
        val json = JSONObject(raw)
        if (json.has("error") && !json.isNull("error")) throw IOException("lyrics.ovh: ответ с ошибкой")
        val text = LyricsFallbackText.clean(json.opt("lyrics") as? String)
            ?: throw IOException("lyrics.ovh: нет корректного обычного текста")
        trace?.add("lyrics.ovh: plain only; recording metadata unavailable")
        // Ignore any unknown timing fields. Zero duration means UNKNOWN, not the audio duration.
        return JSONObject().put("source", id).put("plainLyrics", text)
            .put("syncedLyrics", "").put("duration", 0).put("instrumental", false)
            .put("matchVerified", false)
    }
}
