package app.ziziplayer.ui.components

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.CameraMorphGeometry as M
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.abs

/** One artwork instance outside LazyColumn clipping, inside the destination's normal z-order.
 * No pointer input, timer, bitmap capture, global overlay window or second image request.
 * Blur is on the inner rectangular image layer; shape/safety clips and contact ink stay sharp.
 */
@Composable
internal fun CollectionCoverMorphOverlay(
    camera: CameraCutoutSnapshot,
    maximum: Dp,
    minimum: Dp,
    coverTop: Dp,
    corner: Dp,
    status: Dp,
    fraction: () -> Float,
    scroll: () -> Float,
    artwork: @Composable () -> Unit
) {
    val density = LocalDensity.current
    var origin by remember { mutableStateOf<Offset?>(null) }
    val maxPx = with(density) { maximum.toPx() }
    val minPx = with(density) { minimum.toPx() }
    val statusPx = with(density) { status.toPx() }
    val topPx = with(density) { coverTop.toPx() }
    val radiusPx = with(density) { corner.toPx() }
    val edgePx = with(density) { 1.dp.toPx() }
    BoxWithConstraints(Modifier.fillMaxSize().clearAndSetSemantics { }
        .onGloballyPositioned { origin = it.positionInWindow() }) {
        val widthPx = with(density) { maxWidth.toPx() }
        // Do not aim at a display-space hole from an inset, translated or preview-sized page.
        val aligned = origin?.let { abs(it.x) <= 1f && abs(it.y) <= 1f } == true &&
            abs(widthPx - camera.windowWidth) <= 1f && abs(statusPx - camera.statusTop) <= 1f
        val target = if (aligned) camera.target else null
        val outline = if (aligned) camera.outline else null
        val frame = remember(maxPx, minPx, statusPx, topPx, radiusPx, widthPx, target, fraction, scroll) {
            derivedStateOf {
                M.frame(maxPx, minPx, fraction(), scroll(), widthPx * .5f, statusPx + topPx,
                    radiusPx, minPx + topPx, statusPx, target)
            }
        }
        // One geometry snapshot per scroll position, shared by camera and artwork layers.
        val goo = remember(frame, target) { derivedStateOf { M.goo(target, frame.value) } }
        val neck = remember { Path() }
        Box(Modifier.fillMaxSize().drawWithCache {
            val safe = Path().apply {
                addRect(Rect(0f, statusPx, size.width, size.height))
                // Only the actual cutout corridor may paint above the content inset.
                // A corner-camera trajectory must never obscure the clock/network icons.
                if (target != null) {
                    val swell = M.maxSwellPx(target)
                    addRect(Rect(target.left - edgePx - swell, target.top - edgePx,
                        target.right + edgePx + swell, statusPx + edgePx))
                }
            }
            onDrawWithContent { clipPath(safe) { this@onDrawWithContent.drawContent() } }
        }) {
            Canvas(Modifier.fillMaxSize()) {
                val f = frame.value
                if (target != null && outline != null) {
                    val g = goo.value
                    // Before contact the camera really grows a separate drop. Never draw
                    // a full-distance bridge underneath it. Joined artwork supplies the neck.
                    if (g != null && !g.joined && g.ink != null) {
                        neck.setGoo(g.ink)
                        drawPath(neck, Color.Black, alpha = f.anchorAlpha * f.imageAlpha)
                    }
                    // Do not leave an app-painted dot after absorption. Keep the layer
                    // mounted for reversible scroll, but emit no anchor at completion.
                    if (f.anchorAlpha > 0f) drawPath(outline, Color.Black, alpha = f.anchorAlpha)
                }
            }
            Box(Modifier.size(maximum).testTag("collection:morph-artwork")
                .graphicsLayer {
                    val f = frame.value
                    transformOrigin = TransformOrigin(0f, 0f)
                    translationX = f.left()
                    translationY = f.top()
                    scaleX = if (size.width > 0) f.width / size.width else 0f
                    scaleY = if (size.height > 0) f.height / size.height else 0f
                    // Group fade is recorded with explicit extended bounds below: the
                    // default image-sized alpha layer would crop the camera-facing tent.
                    clip = false
                }
                .drawWithCache {
                    val f = frame.value
                    val g = goo.value
                    val sx = if (f.width > 0f) size.width / f.width else 1f
                    val sy = if (f.height > 0f) size.height / f.height else 1f
                    val radius = CornerRadius(f.radius * sx, f.radius * sy)
                    val body = Path().apply {
                        addRoundRect(RoundRect(0f, 0f, size.width, size.height,
                            radius, radius, radius, radius))
                    }
                    val flesh = g?.flesh?.let { commands ->
                        Path().apply { setGoo(commands, f.left(), f.top(), sx, sy) }
                    }
                    // One antialiased outer boundary. Two complementary body/flesh clips
                    // leave a subpixel seam: their separate coverages do not add to one.
                    val silhouette = if (flesh == null) body else
                        Path.combine(PathOperation.Union, body, flesh)
                    val bodyBlack = M.bodyBlack(f, g)
                    val bodyBounds = Rect(0f, 0f, size.width, size.height)
                    val bounds = flesh?.getBounds()?.let {
                        Rect(minOf(0f, it.left), minOf(0f, it.top),
                            maxOf(size.width, it.right), maxOf(size.height, it.bottom))
                    } ?: bodyBounds
                    val ink = g?.let {
                        Brush.linearGradient(
                            0f to Color.Black.copy(alpha = it.inkAlpha),
                            1f to Color.Transparent,
                            start = Offset((it.originX + it.axisX * it.inkStart - f.left()) * sx,
                                (it.originY + it.axisY * it.inkStart - f.top()) * sy),
                            end = Offset((it.originX + it.axisX * it.inkEnd - f.left()) * sx,
                                (it.originY + it.axisY * it.inkEnd - f.top()) * sy))
                    }
                    // Reflect the SAME image display list across its camera-facing tangent.
                    // Sixfold stretch samples a shallow strip of the blurred source, not a
                    // second Coil request or a screenshot. The tangent is continuous in color.
                    val nx0 = (g?.axisX ?: 0f) * sx
                    val ny0 = (g?.axisY ?: 1f) * sy
                    val length = hypot(nx0, ny0).coerceAtLeast(.0001f)
                    val nx = nx0 / length
                    val ny = ny0 / length
                    val pivot = Offset(size.width * .5f - nx * size.minDimension * .5f,
                        size.height * .5f - ny * size.minDimension * .5f)
                    val angle = (atan2(ny, nx) * 180f / Math.PI.toFloat()) - 90f
                    val extent = (size.maxDimension + bounds.width + bounds.height) * 4f
                    val outside = Path().apply {
                        moveTo(pivot.x - ny * extent, pivot.y + nx * extent)
                        lineTo(pivot.x + ny * extent, pivot.y - nx * extent)
                        lineTo(pivot.x + ny * extent - nx * extent, pivot.y - nx * extent - ny * extent)
                        lineTo(pivot.x - ny * extent - nx * extent, pivot.y + nx * extent - ny * extent)
                        close()
                    }
                    val fadePaint = if (f.imageAlpha < 1f) Paint().apply { alpha = f.imageAlpha } else null
                    onDrawWithContent {
                        if (f.imageAlpha <= 0f) return@onDrawWithContent
                        // True group alpha (not ModulateAlpha): a black overlay must not
                        // expose bright artwork again during the final fade. Include the
                        // extension's negative coordinates in the offscreen layer bounds.
                        if (fadePaint != null) drawContext.canvas.saveLayer(bounds, fadePaint)
                        try {
                            clipPath(silhouette) {
                                if (flesh == null) {
                                    this@onDrawWithContent.drawContent()
                                } else {
                                    // An opaque base under the reflected extension prevents
                                    // a second complementary-clip seam at the tangent. The
                                    // two textures agree exactly on that tangent.
                                    this@onDrawWithContent.drawMirroredContent()
                                    clipPath(outside) {
                                        withTransform({
                                            rotate(angle, pivot)
                                            scale(1f, -6f, pivot)
                                            rotate(-angle, pivot)
                                        }) { this@onDrawWithContent.drawMirroredContent() }
                                    }
                                }
                                // Shade the UNION once, never body and neck independently.
                                if (bodyBlack > 0f)
                                    drawRect(Color.Black, bounds.topLeft, bounds.size, alpha = bodyBlack)
                                if (ink != null) drawRect(ink, bounds.topLeft, bounds.size)
                            }
                        } finally {
                            if (fadePaint != null) drawContext.canvas.restore()
                        }
                    }
                }) {
                // Keep this child mounted even at radius zero: no image reload or layer swap
                // when reversing direction. CLAMP does not mix transparent black into edges.
                // API 26-30: clean, reversible spatial blend; Android has no RenderEffect there.
                Box(Modifier.fillMaxSize().graphicsLayer {
                    val radius = size.minDimension * M.blurFraction(frame.value.progress)
                    renderEffect = if (Build.VERSION.SDK_INT >= 31 && radius > 0f)
                        BlurEffect(radius, radius, TileMode.Clamp) else null
                }) { artwork() }
            }
            if (CameraMorphDebug.outlineEnabled && target != null && outline != null) {
                Canvas(Modifier.fillMaxSize()) {
                    drawPath(outline, Color.Cyan, style = Stroke(edgePx))
                    drawRect(Color.Magenta, topLeft = Offset(target.left, target.top),
                        size = Size(target.width(), target.height()), style = Stroke(edgePx * .5f))
                }
            }
        }
    }
}

/** Decode pure-Java path commands into window or unscaled artwork coordinates. */
private fun Path.setGoo(commands: FloatArray, left: Float = 0f, top: Float = 0f,
    sx: Float = 1f, sy: Float = 1f) {
    reset()
    var i = 0
    while (i < commands.size) {
        when (commands[i++].toInt()) {
            0 -> {
                moveTo((commands[i] - left) * sx, (commands[i + 1] - top) * sy)
                i += 2
            }
            1 -> {
                cubicTo((commands[i] - left) * sx, (commands[i + 1] - top) * sy,
                    (commands[i + 2] - left) * sx, (commands[i + 3] - top) * sy,
                    (commands[i + 4] - left) * sx, (commands[i + 5] - top) * sy)
                i += 6
            }
            2 -> close()
            else -> error("Invalid camera path opcode")
        }
    }
}

/** Mirror-pad the existing image display list by one tile at every edge. A rotated
 * neck or swollen camera can sample just outside the original square; without this
 * padding a transparent wedge appears on corner-camera devices. No bitmap copies,
 * captures or additional image requests. The surrounding path clips all nine tiles.
 * The inner blur layer is reused; it is not recreated per tile.
 */
private fun ContentDrawScope.drawMirroredContent() {
    for (y in -1..1) for (x in -1..1) {
        withTransform({
            translate(x * size.width, y * size.height)
            scale(if (x == 0) 1f else -1f, if (y == 0) 1f else -1f)
        }) { this@drawMirroredContent.drawContent() }
    }
}
