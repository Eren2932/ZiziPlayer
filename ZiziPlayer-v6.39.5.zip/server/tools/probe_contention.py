#!/usr/bin/env python3
"""One bounded, opt-in probe of the running Stage 2 service. Python stdlib only.
No subprocesses, cache flush, configuration edits, or service restarts.
May fill normal server caches. Loopback only; this does NOT test phone networking.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import http.client
import json
from pathlib import Path
import re
import shlex
import threading
import time
from urllib.parse import urlencode, urlsplit

COUNTERS = ('started', 'rejected', 'preemptions', 'wait_ms')
SAFE_SCHEDULER = COUNTERS + ('slots', 'scope', 'resolver_attached', 'active', 'queued', 'active_ms')


def origin(value):
    p = urlsplit(value)
    if (p.scheme != 'http' or p.hostname not in ('127.0.0.1', 'localhost', '::1')
            or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment):
        raise ValueError('base must be a loopback HTTP origin')
    return p.hostname, p.port or 8080


def read_token(path):
    # Read only the named key; never source/execute an env file or print its contents.
    value = None
    for line in Path(path).read_text().splitlines():
        match = re.match(r'^\s*(?:export\s+)?ZIZI_TOKEN\s*=(.*)$', line)
        if match:
            parts = shlex.split(match[1], comments=True)
            value = parts[0] if len(parts) == 1 else None
    if not value:
        raise ValueError('ZIZI_TOKEN missing or unsupported syntax')
    return value


def clean_text(value):
    return ''.join(c for c in str(value or '') if c.isprintable())[:200]


def safe_result(result):
    # Never publish raw JSON/errors/headers: they may contain a signed URL or token.
    return {k: result[k] for k in ('status', 'ms', 'error', 'retry_after_s', 'cached',
            'bytes_observed', 'expected_bytes', 'range_valid', 'complete',
            'first_byte_ms', 'max_read_gap_ms') if k in result}


class Client:
    def __init__(self, base, token, timeout=45):
        self.host, self.port = origin(base)
        self.token, self.timeout = token, timeout
        self.install = 'stage2-contention-probe'

    def call(self, path, params=None, stream_bytes=None, timeout=None):
        start = time.monotonic()
        result = {'status': None}
        conn = http.client.HTTPConnection(self.host, self.port, timeout=timeout or self.timeout)
        headers = {'Authorization': 'Bearer ' + self.token,
                   'X-Zizi-Install': self.install, 'Connection': 'close'}
        if stream_bytes:
            headers['Range'] = 'bytes=0-' + str(stream_bytes - 1)
        target = path + ('?' + urlencode(params) if params else '')
        try:
            conn.request('GET', target, headers=headers)
            response = conn.getresponse()
            result['status'] = response.status
            retry = response.getheader('Retry-After', '')
            if retry.isdecimal():
                result['retry_after_s'] = int(retry)
            # http.client deliberately does not follow redirects.
            if response.status not in (200, 206):
                return result
            if stream_bytes:
                content_range = response.getheader('Content-Range', '')
                m = re.fullmatch(r'bytes 0-(\d+)/(\d+)', content_range)
                valid = bool(m and response.status == 206
                             and 0 <= int(m[1]) < int(m[2])
                             and int(m[1]) + 1 == min(stream_bytes, int(m[2])))
                result.update(range_valid=valid, bytes_observed=0, complete=False)
                if not valid:
                    result['error'] = 'invalid_range_response'
                    return result
                expected = int(m[1]) + 1
                result['expected_bytes'] = expected
                deadline = start + (timeout or self.timeout)
                previous = None
                max_gap = 0
                while result['bytes_observed'] < expected:
                    if time.monotonic() >= deadline:
                        result['error'] = 'read_budget_exceeded'
                        break
                    # read1 avoids waiting to fill a whole 16 KiB chunk. First read is 1 byte.
                    amount = 1 if previous is None else min(16384, expected - result['bytes_observed'])
                    chunk = response.read1(amount)
                    now = time.monotonic()
                    if not chunk:
                        break
                    if previous is None:
                        result['first_byte_ms'] = round((now - start) * 1000)
                    else:
                        max_gap = max(max_gap, now - previous)
                    previous = now
                    result['bytes_observed'] += len(chunk)
                result['max_read_gap_ms'] = round(max_gap * 1000)
                result['complete'] = result['bytes_observed'] == expected
            else:
                raw = bytearray()
                deadline = start + (timeout or self.timeout)
                while len(raw) <= 2 * 1024 * 1024:
                    if time.monotonic() >= deadline:
                        raise TimeoutError()
                    chunk = response.read1(min(65536, 2 * 1024 * 1024 + 1 - len(raw)))
                    if not chunk:
                        break
                    raw.extend(chunk)
                if len(raw) > 2 * 1024 * 1024:
                    result['error'] = 'response_too_large'
                else:
                    body = json.loads(raw)
                    if not isinstance(body, dict):
                        raise ValueError()
                    result['body'] = body
                    if type(body.get('cached')) is bool:
                        result['cached'] = body['cached']
        except (OSError, ValueError, http.client.HTTPException):
            result['error'] = 'network_or_protocol'
        finally:
            conn.close()
            result['ms'] = round((time.monotonic() - start) * 1000)
        return result

    def snapshot(self):
        result = self.call('/health', timeout=1)
        body = result.get('body', {})
        scheduler = body.get('scheduler')
        if (result['status'] != 200 or not isinstance(scheduler, dict)
                or body.get('version') != '1.7-stage2'):
            return None
        return {k: scheduler.get(k) for k in SAFE_SCHEDULER}


class Monitor:
    def __init__(self, client):
        self.client = client
        self.stop = threading.Event()
        self.extra_active = threading.Event()
        self.rows = []
        self.failures = 0
        self.lock = threading.Lock()
        self.start = time.monotonic()
        self.thread = threading.Thread(target=self.run)

    def run(self):
        # One tiny /health request at most every 200 ms, max 180 seconds.
        while not self.stop.is_set() and time.monotonic() - self.start < 180:
            state = self.client.snapshot()
            with self.lock:
                if state is None:
                    self.failures += 1
                else:
                    self.rows.append(dict(t_ms=round((time.monotonic() - self.start) * 1000), **state))
                    if state['active'] == 'extra':
                        self.extra_active.set()
            self.stop.wait(.2)

    def finish(self):
        self.stop.set()
        self.thread.join(3)


def chain(client, deezer_id, stream_bytes):
    start = time.monotonic()
    out = {}
    match = client.call('/match/deezer', {'id': deezer_id})
    out['match'] = safe_result(match)
    vid = match.get('body', {}).get('vid')
    if match['status'] != 200 or not isinstance(vid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
        out['total_ms'] = round((time.monotonic() - start) * 1000)
        return out
    out['video_id'] = vid
    resolved = client.call('/resolve', {'id': vid})
    out['resolve'] = safe_result(resolved)
    if resolved['status'] == 200:
        out['stream'] = safe_result(client.call('/stream', {'id': vid}, stream_bytes=stream_bytes))
    out['total_ms'] = round((time.monotonic() - start) * 1000)
    return out


def assess(report):
    chain_result = report.get('chain', {})
    success = chain_result.get('stream', {}).get('complete') is True
    cold = (chain_result.get('match', {}).get('cached') is False
            and chain_result.get('resolve', {}).get('cached') is False)
    before, after = report.get('before'), report.get('after')
    delta = {}
    if before and after:
        for key in COUNTERS:
            if type(before.get(key)) is int and type(after.get(key)) is int:
                delta[key] = after[key] - before[key]
    reset = any(v < 0 for v in delta.values())
    report['scheduler_delta'] = delta
    report['counter_reset_detected'] = reset
    report['pipeline_success'] = success
    report['cold_match_and_resolve'] = cold
    rows = report.get('timeline', [])
    report['queue_observed'] = any(type(r.get('queued')) is int and r['queued'] > 0 for r in rows)
    report['max_queue_observed'] = max((r.get('queued') or 0 for r in rows), default=0)
    report['post_probe_idle'] = bool(after and after.get('active') is None and after.get('queued') == 0)
    active_before = report.get('at_match_start') or {}
    evidence = (success and cold and not reset and report['post_probe_idle'] and report.get('extra_seen_active')
                and active_before.get('active') == 'extra'
                and delta.get('preemptions', 0) >= 1
                and report.get('extra', {}).get('status') == 429)
    if report.get('abort'):
        report['assessment'] = 'not_run'
    elif not success:
        report['assessment'] = 'pipeline_failed' if chain_result else 'inconclusive'
    elif report['mode'] == 'contention':
        report['assessment'] = 'cold_preemption_observed' if evidence else 'inconclusive'
    else:
        report['assessment'] = 'cold_pipeline_observed' if cold else 'warm_or_partial_pipeline'
    # Never call a service-level counter proof of request ownership, bounded OS resources or sound.
    report['request_attribution'] = 'service_counters_only_other_clients_can_contribute'
    report['queue_limit_tested'] = False
    report['mobile_network_tested'] = False
    report['audible_stability'] = 'not_measured'
    report['audio_cache_cold'] = 'unknown'
    report['server_work_after_disconnect'] = 'may_continue_until_worker_finishes'
    report['cache_flushed'] = False
    report['service_restarted'] = False
    return report


def run_probe(client, deezer_id, extra_query=None, stream_bytes=262144):
    report = {'schema': 1, 'mode': 'contention' if extra_query else 'pipeline', 'deezer_id': deezer_id}
    before = client.snapshot()
    report['before'] = before
    if not before or before.get('slots') != 1 or not before.get('resolver_attached'):
        report['abort'] = 'expected_stage2_single_slot_service'
        return assess(report)
    if before.get('active') or before.get('queued'):
        report['abort'] = 'extractor_already_busy_try_later'
        return assess(report)
    if extra_query:
        health = client.call('/catalog/health', timeout=3).get('body', {})
        if health.get('extra', {}).get('enabled') is not True:
            report['abort'] = 'extra_disabled_enable_only_in_a_listening_pause'
            return assess(report)
    monitor = Monitor(client)
    monitor.thread.start()
    try:
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(client.call, '/catalog/extra/search', {'q': extra_query, 'limit': 5},
                                 timeout=12) if extra_query else None
            if future:
                deadline = time.monotonic() + 10
                while not monitor.extra_active.wait(.05) and not future.done() and time.monotonic() < deadline:
                    pass
                report['extra_seen_active'] = monitor.extra_active.is_set()
                if report['extra_seen_active']:
                    report['at_match_start'] = client.snapshot()
                    report['chain'] = chain(client, deezer_id, stream_bytes)
                # No extra observed => do not warm the selected track with a meaningless run.
                report['extra'] = safe_result(future.result())
            else:
                report['chain'] = chain(client, deezer_id, stream_bytes)
            # Poll for a short drain window; still-active work is reported, never killed.
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                state = client.snapshot()
                if state and not state.get('active') and not state.get('queued'):
                    break
                time.sleep(.2)
            report['after'] = client.snapshot()
    finally:
        monitor.finish()
        with monitor.lock:
            report['timeline'] = list(monitor.rows)
            report['health_poll_failures'] = monitor.failures
    return assess(report)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', default='http://127.0.0.1:8080')
    parser.add_argument('--env-file', default='/opt/zizi/zizi.env')
    targets = parser.add_mutually_exclusive_group(required=True)
    targets.add_argument('--deezer-id')
    targets.add_argument('--find', help='List Deezer IDs only; does not match, resolve or stream')
    parser.add_argument('--extra-query', help='One real, unused search query; no random cache-busting suffix')
    parser.add_argument('--stream-kib', type=int, default=256, choices=(64, 256, 1024))
    parser.add_argument('--run-live', action='store_true')
    args = parser.parse_args(argv)
    if not args.run_live:
        parser.error('--run-live is required')
    try:
        origin(args.base)  # Reject non-loopback BEFORE reading any secret.
        if args.deezer_id and not re.fullmatch(r'[0-9]{1,20}', args.deezer_id):
            raise ValueError('invalid Deezer ID')
        if args.extra_query and (not args.deezer_id or not 2 <= len(args.extra_query.strip()) <= 160):
            raise ValueError('extra-query requires a Deezer ID and 2..160 characters')
        if args.find and not 2 <= len(args.find.strip()) <= 160:
            raise ValueError('find needs 2..160 characters')
        token = read_token(args.env_file)
    except (ValueError, OSError):
        print(json.dumps({'assessment': 'not_run', 'error': 'invalid_arguments_or_token_file'}))
        return 1
    client = Client(args.base, token)
    auth = client.call('/auth/device', timeout=10)
    device = auth.get('body', {}).get('token')
    if auth['status'] != 200 or not isinstance(device, str) or not device:
        print(json.dumps({'assessment': 'not_run', 'phase': 'device_auth', **safe_result(auth)}))
        return 1
    client.token = device
    if args.find:
        response = client.call('/catalog/search', {'q': args.find, 'src': 'deezer', 'limit': 10}, timeout=15)
        body = response.get('body', {})
        items = [{'deezer_id': str(r.get('id', '')), 'title': clean_text(r.get('title')),
                  'artist': clean_text(r.get('artist')), 'duration_s': r.get('dur')}
                 for r in body.get('items', []) if isinstance(r, dict) and str(r.get('id', '')).isdecimal()]
        print(json.dumps({'phase': 'find', **safe_result(response), 'items': items}, ensure_ascii=False, indent=2))
        return 0 if response['status'] == 200 else 1
    report = run_probe(client, args.deezer_id, args.extra_query, args.stream_kib * 1024)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report['assessment'] in ('cold_preemption_observed', 'cold_pipeline_observed'):
        return 0
    return 1 if report['assessment'] in ('pipeline_failed', 'not_run') else 2


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print(json.dumps({'assessment': 'interrupted', 'server_work_may_continue': True}))
        raise SystemExit(130)
