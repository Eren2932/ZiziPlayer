#!/usr/bin/env python3
"""
test_catalog_wiring.py — проверка ВРЕЗКИ границы в zizi_catalog.py.

Зачем отдельно от test_zizi_guard.py. Тот проверяет, что замок работает. Этот — что замок
висит на двери. Ровно между этими двумя утверждениями и жил весь баг: _check_token в резолвере
был написан прекрасно, просто к каталогу не был применён.

fastapi на машине разработки нет, поэтому модуль импортируется поверх заглушки (tools/_stub).
Заглушка не изображает фреймворк: она даёт имена и запоминает, что модуль зарегистрировал.
Это позволяет проверить три вещи, которые иначе выяснились бы только на VPS:

  1. зависимость висит на самом APIRouter, то есть на всех роутах разом;
  2. yt_search не запускает процесс, когда семафор занят;
  3. занятость НЕ превращается в запись в кэш промахов.

Запуск:  python3 server/tools/test_catalog_wiring.py
"""

import os
import sys
import tempfile

# До импорта модуля: он открывает SQLite на пути из ZIZI_CATALOG_DB прямо на импорте, и по
# умолчанию это /opt/zizi/catalog.db. Без подмены тест падает на OperationalError раньше, чем
# доходит до проверяемого — и выглядит это как «сломана защита», хотя сломан путь к файлу.
_TMP = tempfile.mkdtemp(prefix="zizi-wiring-")
os.environ.setdefault("ZIZI_CATALOG_DB", os.path.join(_TMP, "catalog.db"))
os.environ.setdefault("ZIZI_IMG_DIR", os.path.join(_TMP, "img"))
os.makedirs(os.environ["ZIZI_IMG_DIR"], exist_ok=True)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "_stub"))
sys.path.insert(0, os.path.join(HERE, ".."))

FAILED = []


def check(name, cond, detail=""):
    print(("  ok    " if cond else "  ПРОВАЛ ") + name + ("" if cond else f" {detail}"))
    if not cond:
        FAILED.append(name)


import fastapi  # noqa: E402  (заглушка)
import zizi_catalog as zc  # noqa: E402
from zizi_guard import ExtractBusy  # noqa: E402


def test_router_guarded():
    print("защита висит на роутере, а не на отдельных роутах")
    deps = zc.router.dependencies
    check("у роутера есть зависимость", len(deps) == 1, f"их {len(deps)}")
    check("это именно guard_dep", deps[0].dependency is zc.guard_dep)
    n = len(zc.router.routes)
    check("роуты зарегистрированы", n >= 10, f"найдено {n}")
    # Ни один роут не должен иметь СВОЮ зависимость вместо общей: это первый шаг к тому,
    # чтобы двенадцатый роут забыли.
    own = [p for p, _, d in zc.router.routes if d]
    check("ни у одного роута нет отдельной защиты", not own, f"{own}")


def test_dep_allows_and_blocks():
    print("зависимость пропускает и отбивает")
    zc._guard.mode = "off"
    r = fastapi.Request("/catalog/chart")
    try:
        zc.guard_dep(r, None, None)
        check("нормальный запрос проходит", True)
    except fastapi.HTTPException as e:
        check("нормальный запрос проходит", False, f"got {e.status_code}")

    # исчерпываем квоту анонима на /match
    blocked = None
    for _ in range(200):
        try:
            zc.guard_dep(fastapi.Request("/match", client_host="9.9.9.9"), None, None)
        except fastapi.HTTPException as e:
            blocked = e
            break
    check("квота срабатывает", blocked is not None)
    if blocked:
        check("отдаётся 429", blocked.status_code == 429, f"={blocked.status_code}")
        check("есть Retry-After", "Retry-After" in blocked.headers, f"{blocked.headers}")
        check("Retry-After число", str(blocked.headers.get("Retry-After", "")).isdigit())


def test_health_not_blocked():
    print("health не отбивается даже когда всё отбивается")
    zc._guard.mode = "require"
    zc._guard.token = "x"
    try:
        zc.guard_dep(fastapi.Request("/catalog/health"), None, None)
        check("health проходит без токена", True)
    except fastapi.HTTPException as e:
        check("health проходит без токена", False, f"got {e.status_code}")
    try:
        zc.guard_dep(fastapi.Request("/catalog/chart"), None, None)
        check("а chart — нет", False, "прошёл без токена")
    except fastapi.HTTPException as e:
        check("а chart — нет", e.status_code == 401, f"={e.status_code}")
    zc._guard.mode = "off"


def test_yt_search_respects_semaphore():
    print("yt_search не плодит процессы сверх потолка")
    gate = zc._guard.gate
    got = []
    for _ in range(gate.slots):
        got.append(gate.acquire(timeout=0.05))
    check("слоты разобраны", all(got))
    gate.wait = 0.05
    try:
        zc.yt_search("что угодно", 1)
        check("занятый семафор останавливает запуск", False, "процесс всё-таки стартовал")
    except ExtractBusy:
        check("занятый семафор останавливает запуск", True)
    except Exception as e:
        check("занятый семафор останавливает запуск", False, f"другое исключение: {e!r}")
    for _ in range(gate.slots):
        gate.release()
    check("слоты возвращены", gate.stats()["in_flight"] == 0)


def test_busy_does_not_poison_negative_cache():
    """Самая дорогая ошибка, которую здесь можно совершить.

    _hunt глушит исключения каждого захода, а match_track на пустой результат пишет miss_put
    на шесть часов. Если перегрузка выглядит как «не нашли», то собственный семафор в час пик
    начинает штамповать вечные 404 по живым трекам.
    """
    print("перегрузка не пишется в кэш промахов")
    gate = zc._guard.gate
    gate.wait = 0.05
    for _ in range(gate.slots):
        gate.acquire(timeout=0.05)

    key_seen = []
    orig_miss_put = zc.miss_put
    zc.miss_put = lambda k, v: key_seen.append(k)
    try:
        zc.match_track("Some Title", "Some Artist", 200000, isrc="TESTISRC0001")
        check("должен был подняться 429", False, "запрос завершился успешно")
    except fastapi.HTTPException as e:
        check("наружу уходит 429, а не 404", e.status_code == 429, f"={e.status_code}")
        check("с Retry-After", "Retry-After" in (e.headers or {}))
    except Exception as e:
        check("наружу уходит 429, а не 404", False, f"утекло {e!r}")
    finally:
        zc.miss_put = orig_miss_put
        for _ in range(gate.slots):
            gate.release()

    check("в кэш промахов НИЧЕГО не записано", not key_seen, f"записано: {key_seen}")


def main():
    for fn in (test_router_guarded, test_dep_allows_and_blocks, test_health_not_blocked,
               test_yt_search_respects_semaphore, test_busy_does_not_poison_negative_cache):
        fn()
    print()
    if FAILED:
        print(f"ПРОВАЛОВ: {len(FAILED)} -> {', '.join(FAILED)}")
        return 1
    print("врезка проверена")
    return 0


if __name__ == "__main__":
    sys.exit(main())
