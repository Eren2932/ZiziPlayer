#!/usr/bin/env python3
"""Ключ на устройство: ступени 2 и 3 защиты токена (zizi_guard 1.8).

Проверяется не «код исполняется», а конкретные утверждения о правах:
  - ключ подписан секретом, которого в APK нет, и внутри него installId;
  - бутстрап-токен из APK в режиме require годится ТОЛЬКО на /auth/device;
  - квота считается на устройство по ПОДПИСИ, а не по подделываемому заголовку;
  - отзыв одного installId работает сразу и не задевает остальных;
  - /img по-прежнему открыт без токена, иначе у всех установленных копий серая сетка.

Запуск: python3 tools/test_zizi_device.py   (fastapi не нужен, модуль чистый)
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import zizi_guard as G

OK = 0
FAILED = []


def head(name):
    print()
    print(name)


def check(name, cond, detail=""):
    global OK
    if cond:
        OK += 1
        print(f"  ok    {name}")
    else:
        FAILED.append(name)
        print(f"  ПРОВАЛ {name} {detail}")


def env(**kw):
    for k, v in kw.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = str(v)


BOOT = "9f1c4ab27d0e5b6318aa4c2f7e0d91b5"  # как в zizi.env: hex


def reset(mode="warn", device_mode="warn", deny=None, ttl=None, key=None):
    env(ZIZI_TOKEN=BOOT, ZIZI_CATALOG_TOKEN=None, ZIZI_CATALOG_TOKEN_MODE=mode,
        ZIZI_DEVICE_MODE=device_mode, ZIZI_DEVICE_DENY=deny, ZIZI_DEVICE_TTL=ttl,
        ZIZI_DEVICE_KEY=key)
    return G.Guard()


def bearer(t):
    return "Bearer " + t


# ── подпись ─────────────────────────────────────────────────────────────────────────────────

def test_roundtrip():
    head("подпись ключа")
    reset()
    tok, ttl = G.issue_device_token("aaaaaaaa-1111")
    check("ключ выдан", tok.startswith("zd1."), tok[:12])
    check("срок положительный", ttl > 0, ttl)
    check("installId читается из подписи", G.verify_device_token(tok) == "aaaaaaaa-1111")
    check("в ключе нет самого бутстрап-токена", BOOT not in tok)


def test_non_ascii_header_is_401_not_500():
    head("мусор в заголовке")
    g = reset()
    for junk in ("Bearer привет", "Bearer \udcff", "не-bearer-вовсе", "Bearer " + "x" * 4096):
        try:
            d = g.admit(path="/catalog/chart", client_ip="1.1.1.1", authorization=junk)
            ok = not d.allowed or g.mode == "warn"
        except Exception as e:
            ok = False
            d = type(e).__name__
        check(f"{junk[:18]!r} не роняет сервер", ok, d)
    g = reset(mode="require")
    d = g.admit(path="/catalog/chart", client_ip="1.1.1.1", authorization="Bearer привет")
    check("не-ASCII токен в require -> 401, а не исключение",
          not d.allowed and d.status == 401, d)


def test_tampering():
    head("подделка ключа")
    reset()
    tok, _ = G.issue_device_token("aaaaaaaa-1111")
    body, sig = tok[4:].split(".", 1)
    other, _ = G.issue_device_token("bbbbbbbb-2222")
    other_body = other[4:].split(".", 1)[0]
    check("чужое тело с той же подписью отвергнуто",
          G.verify_device_token("zd1." + other_body + "." + sig) is None)
    check("испорченная подпись отвергнута",
          G.verify_device_token("zd1." + body + "." + sig[:-2] + "AA") is None)
    check("мусор вместо base64 отвергнут без исключения",
          G.verify_device_token("zd1.!!!.???") is None)
    check("ключ без префикса отвергнут", G.verify_device_token(body + "." + sig) is None)
    check("пустая строка отвергнута", G.verify_device_token("") is None)


def test_expiry_and_key_rotation():
    head("срок и ротация секрета")
    reset(ttl=60)
    tok, ttl = G.issue_device_token("aaaaaaaa-1111", ttl=1)
    check("живой ключ принимается", G.verify_device_token(tok) == "aaaaaaaa-1111")
    check("истёкший ключ отвергнут",
          G.verify_device_token(tok, now=time.time() + 2) is None)
    tok2, _ = G.issue_device_token("aaaaaaaa-1111")
    env(ZIZI_TOKEN="другой-токен-после-ротации")
    check("ротация ZIZI_TOKEN гасит выданные ключи", G.verify_device_token(tok2) is None)
    env(ZIZI_TOKEN=BOOT, ZIZI_DEVICE_KEY="свой-секрет-подписи")
    tok3, _ = G.issue_device_token("aaaaaaaa-1111")
    env(ZIZI_TOKEN="ещё-раз-сменили")
    check("с ZIZI_DEVICE_KEY ключи ротацию ZIZI_TOKEN переживают",
          G.verify_device_token(tok3) == "aaaaaaaa-1111")
    env(ZIZI_DEVICE_KEY=None)


def test_no_secret_no_tokens():
    head("нечем подписывать")
    env(ZIZI_TOKEN=None, ZIZI_CATALOG_TOKEN=None, ZIZI_DEVICE_KEY=None)
    tok, ttl = G.issue_device_token("aaaaaaaa-1111")
    check("без секрета ключ не выдаётся", tok == "" and ttl == 0)
    check("и не проверяется", G.verify_device_token("zd1.x.y") is None)
    env(ZIZI_TOKEN=BOOT)


# ── права ───────────────────────────────────────────────────────────────────────────────────

def test_auth_route_always_closed():
    head("/auth/device закрыт в любом режиме")
    for mode in ("off", "warn", "require"):
        g = reset(mode=mode)
        d = g.admit(path="/auth/device", client_ip="1.1.1.1", install_id="aaaaaaaa-1111")
        check(f"без токена нельзя, режим {mode}", not d.allowed and d.status == 401, d)
        d = g.admit(path="/auth/device", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                    client_ip="1.1.1.1")
        check(f"с бутстрап-токеном можно, режим {mode}", d.allowed, d)


def test_require_kills_bootstrap_everywhere_else():
    head("ступень 3: в require бутстрап-токен больше не пропуск")
    g = reset(device_mode="require")
    d = g.admit(path="/catalog/chart", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                client_ip="1.1.1.1")
    check("каталог с токеном из APK -> 401", not d.allowed and d.status == 401, d)
    check("и причина названа", d.reason == "device token required", d.reason)
    tok, _ = G.issue_device_token("aaaaaaaa-1111")
    d = g.admit(path="/catalog/chart", authorization=bearer(tok), client_ip="1.1.1.1")
    check("с ключом — можно", d.allowed, d)
    d = g.admit(path="/auth/device", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                client_ip="1.1.1.1")
    check("обмен токена на ключ остаётся открытым", d.allowed, d)
    d = g.admit(path="/img", client_ip="1.1.1.1")
    check("/img не сломался ни для одной установленной копии", d.allowed, d)


def test_warn_keeps_old_apk_alive():
    head("warn: старый APK продолжает работать")
    g = reset(device_mode="warn")
    d = g.admit(path="/catalog/chart", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                client_ip="1.1.1.1")
    check("токен из APK принимается", d.allowed, d)
    check("и считается опознанным по заголовку", d.kind == "id", d.kind)


def test_identity_comes_from_signature():
    head("квота считается по подписи, а не по заголовку")
    g = reset()
    tok, _ = G.issue_device_token("aaaaaaaa-1111")
    # Пытаемся выдать себя за другое устройство: заголовок чужой, ключ свой.
    burst = int(G.DEFAULT_QUOTAS["match"]["id"][0])
    for _ in range(burst):
        g.admit(path="/match", authorization=bearer(tok), install_id="ЧУЖОЙ-ЗАГОЛОВОК",
                client_ip="1.1.1.1")
    d = g.admit(path="/match", authorization=bearer(tok), install_id="ЕЩЁ-ОДИН-ЗАГОЛОВОК",
                client_ip="1.1.1.1")
    check("смена заголовка НЕ обнуляет квоту владельца ключа",
          not d.allowed and d.status == 429, d)
    other, _ = G.issue_device_token("bbbbbbbb-2222")
    d = g.admit(path="/match", authorization=bearer(other), client_ip="1.1.1.1")
    check("другое устройство при этом не наказано", d.allowed, d)


def test_auth_quota_is_tight_and_isolated():
    head("класс auth: узкий и независимый")
    check("класс распознаётся", G.class_of("/auth/device") == "auth")
    check("порядок классов не сломан", G.class_of("/catalog/chart") == "catalog"
          and G.class_of("/match/warm") == "match")
    g = reset()
    burst = int(G.DEFAULT_QUOTAS["auth"]["id"][0])
    allowed = 0
    for _ in range(burst + 5):
        if g.admit(path="/auth/device", authorization=bearer(BOOT),
                   install_id="aaaaaaaa-1111", client_ip="1.1.1.1").allowed:
            allowed += 1
    check("залп за ключами упирается в потолок", allowed <= burst, allowed)
    d = g.admit(path="/catalog/chart", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                client_ip="1.1.1.1")
    check("исчерпанный auth не задевает каталог", d.allowed, d)


def test_revocation():
    head("отзыв устройства")
    g = reset(deny="bbbbbbbb-2222")
    good, _ = G.issue_device_token("aaaaaaaa-1111")
    bad, _ = G.issue_device_token("bbbbbbbb-2222")
    d = g.admit(path="/catalog/chart", authorization=bearer(bad), client_ip="1.1.1.1")
    check("отозванный получает 403", not d.allowed and d.status == 403, d)
    d = g.admit(path="/catalog/chart", authorization=bearer(good), client_ip="1.1.1.1")
    check("остальные не задеты", d.allowed, d)
    d = g.admit(path="/img", install_id="bbbbbbbb-2222", client_ip="1.1.1.1")
    check("отзыв действует и на открытый /img", not d.allowed and d.status == 403, d)
    d = g.admit(path="/auth/device", authorization=bearer(BOOT), install_id="bbbbbbbb-2222",
                client_ip="1.1.1.1")
    check("отозванный не может выпустить себе новый ключ", not d.allowed, d)


def test_stats_guide_the_switch():
    head("цифра, по которой включают require")
    g = reset()
    tok, _ = G.issue_device_token("aaaaaaaa-1111")
    for _ in range(3):
        g.admit(path="/catalog/chart", authorization=bearer(tok), client_ip="1.1.1.1")
    st = g.stats()
    check("device_pct == 100, когда все с ключами", st["device_pct"] == 100.0, st["device_pct"])
    check("режим ключей виден снаружи", st["device_mode"] == "warn", st)
    g2 = reset()
    for _ in range(3):
        g2.admit(path="/catalog/chart", authorization=bearer(BOOT), install_id="aaaaaaaa-1111",
                 client_ip="1.1.1.1")
    check("со старым APK device_pct == 0", g2.stats()["device_pct"] == 0.0, g2.stats())


def main():
    for fn in (test_roundtrip, test_non_ascii_header_is_401_not_500, test_tampering, test_expiry_and_key_rotation,
               test_no_secret_no_tokens, test_auth_route_always_closed,
               test_require_kills_bootstrap_everywhere_else, test_warn_keeps_old_apk_alive,
               test_identity_comes_from_signature, test_auth_quota_is_tight_and_isolated,
               test_revocation, test_stats_guide_the_switch):
        fn()
    print()
    print(f"утверждений: {OK}")
    if FAILED:
        print(f"ПРОВАЛОВ: {len(FAILED)} -> {', '.join(FAILED)}")
        return 1
    print("все проверки пройдены")
    return 0


if __name__ == "__main__":
    sys.exit(main())
