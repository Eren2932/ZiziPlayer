#!/usr/bin/env python3
"""
test_zizi_guard.py — юнит-тесты границы каталога.

Запуск:  python3 server/tools/test_zizi_guard.py

Без pytest и вообще без зависимостей: на VPS стоит голый python3, и тест, который нельзя
запустить прямо там, куда деплоят, — это не тест, а обещание.

Время подставляется искусственно (класс Clock). Тест на квоту, который ждёт настоящие
секунды, идёт минуту и первым же попадает в «ну оно флакает, перезапусти» — то есть перестаёт
быть проверкой.
"""

import os
import sys
import threading
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from zizi_guard import (  # noqa: E402
    DEFAULT_QUOTAS, Decision, ExtractBusy, ExtractGate, Guard, KeyedRateLimiter,
    class_of,
)


def wide(**over):
    """Квоты, заведомо не мешающие тесту. Нужны там, где проверяется НЕ квота.

    Первая версия этих тестов этого не делала, и тест на разбор заголовка Authorization
    падал с 429 — то есть проверял ограничитель, думая, что проверяет разбор строки.
    Тест, который падает не по той причине, по которой написан, хуже отсутствующего.
    """
    q = {cls: {tier: (10_000.0, 600_000.0) for tier in tiers}
         for cls, tiers in DEFAULT_QUOTAS.items()}
    for cls, tiers in over.items():
        q[cls].update(tiers)
    return q

FAILED = []


def check(name, cond, detail=""):
    if cond:
        print(f"  ok    {name}")
    else:
        print(f"  ПРОВАЛ {name} {detail}")
        FAILED.append(name)


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t

    def advance(self, dt):
        self.t += dt


# ---------------------------------------------------------------- бакет

def test_bucket():
    print("бакет")
    c = Clock()
    rl = KeyedRateLimiter(capacity=5, refill_per_sec=1.0, now=c)
    ok = [rl.take("k")[0] for _ in range(5)]
    check("всплеск проходит целиком", all(ok))
    allowed, retry = rl.take("k")
    check("шестой отбит", not allowed)
    check("retry_after осмысленный", 0.9 <= retry <= 1.1, f"retry={retry}")

    c.advance(3.0)
    got = sum(1 for _ in range(4) if rl.take("k")[0])
    check("за 3 с накапало ровно 3", got == 3, f"прошло {got}")

    check("чужой ключ не задет", rl.take("other")[0])

    c.advance(10_000)
    tokens_now = sum(1 for _ in range(20) if rl.take("k")[0])
    check("бакет не переполняется сверх capacity", tokens_now == 5, f"прошло {tokens_now}")


def test_bucket_eviction():
    print("вытеснение ключей")
    c = Clock()
    rl = KeyedRateLimiter(3, 1.0, max_keys=100, now=c)
    for i in range(100):
        c.advance(0.01)
        rl.take(f"k{i}")
    before = rl.size()
    c.advance(0.01)
    rl.take("newcomer")
    check("словарь ограничен сверху", rl.size() <= 100, f"было {before}, стало {rl.size()}")
    check("вытеснение зафиксировано", rl.evictions > 0)
    # Самый свежий ключ обязан пережить вытеснение, иначе активный клиент теряет счётчик
    # каждый раз, когда мимо проходит шум с чужими id.
    check("свежий ключ уцелел", "k99" in rl._buckets or "newcomer" in rl._buckets)


def test_bucket_threads():
    print("бакет под потоками")
    rl = KeyedRateLimiter(50, 0.0)          # refill=0: разрешено ровно 50 на всю жизнь
    passed = []
    lock = threading.Lock()

    def worker():
        got = sum(1 for _ in range(20) if rl.take("shared")[0])
        with lock:
            passed.append(got)

    ts = [threading.Thread(target=worker) for _ in range(10)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    total = sum(passed)
    check("гонки не выдают лишних токенов", total == 50, f"выдано {total} из 50")


# ---------------------------------------------------------------- токен

def test_token_modes():
    print("режимы токена")
    g = Guard(token="s3cret", mode="require", quotas=wide())
    check("require: без токена 401", g.admit("/match").status == 401)
    check("require: неверный токен 401", g.admit("/match", authorization="Bearer nope").status == 401)
    check("require: верный проходит", g.admit("/match", authorization="Bearer s3cret").allowed)
    check("require: верный в query проходит", g.admit("/match", q_token="s3cret").allowed)

    g = Guard(token="s3cret", mode="warn", quotas=wide())
    d = g.admit("/match", client_ip="1.2.3.4")
    check("warn: без токена пропускаем", d.allowed)
    check("warn: но считаем анонимом", d.kind == "anon")
    d = g.admit("/match", authorization="Bearer s3cret", install_id="dev1")
    check("warn: с токеном и installId опознан", d.kind == "id")

    g = Guard(token="", mode="require", quotas=wide())
    check("пустой токен в конфиге не даёт 401 всем", g.mode == "off")
    check("режим off пропускает", g.admit("/match").allowed)


def test_token_case_and_prefix():
    print("разбор заголовка")
    g = Guard(token="abc", mode="require", quotas=wide())
    check("Bearer в любом регистре", g.admit("/match", authorization="bearer abc").allowed)
    check("голый токен без Bearer", g.admit("/match", authorization="abc").allowed)
    check("пробелы обрезаются", g.admit("/match", authorization="  Bearer   abc  ").allowed)
    check("префикс верного токена не проходит", not g.admit("/match", authorization="Bearer ab").allowed)


# ---------------------------------------------------------------- квоты

def test_quota_split():
    print("квоты: аноним против опознанного")
    c = Clock()
    g = Guard(token="t", mode="warn",
              quotas=wide(catalog={"id": (40, 60), "anon": (8, 12)}), now=c)

    anon = sum(1 for _ in range(50)
               if g.admit("/catalog/chart", client_ip="9.9.9.9").allowed)
    ident = sum(1 for _ in range(50)
                if g.admit("/catalog/chart", authorization="Bearer t",
                           install_id="dev1").allowed)
    check("анониму досталась жёсткая квота", anon == 8, f"прошло {anon}")
    check("опознанному — мягкая", ident == 40, f"прошло {ident}")
    check("аноним не съел квоту опознанного", ident > anon)


def test_quota_isolation():
    print("квоты: изоляция")
    c = Clock()
    g = Guard(token="t", mode="warn",
              quotas=wide(catalog={"id": (4, 6), "anon": (4, 6)}), now=c)
    for _ in range(4):
        g.admit("/catalog/chart", client_ip="1.1.1.1")
    check("сосед по IP отбит", not g.admit("/catalog/chart", client_ip="1.1.1.1").allowed)
    check("другой IP не наказан", g.admit("/catalog/chart", client_ip="2.2.2.2").allowed)


def test_class_of():
    print("классы нагрузки")
    check("/match -> match", class_of("/match") == "match")
    check("/match/warm -> match", class_of("/match/warm") == "match")
    check("/match/deezer -> match", class_of("/match/deezer") == "match")
    check("/img -> img", class_of("/img") == "img")
    check("/catalog/chart -> catalog", class_of("/catalog/chart") == "catalog")
    check("неизвестный путь не попадает в img/match", class_of("/wat") == "catalog")


def test_classes_are_independent():
    """Главный тест этого модуля.

    Ровно эта ошибка была в первой версии: обложки и сопоставление считались одним бакетом.
    Открытый плейлист на 100 треков = 100 запросов /img, и после него /match отвечал 429,
    хотя человек ещё ничего не нажал.
    """
    print("залп обложек не выедает квоту сопоставления")
    c = Clock()
    g = Guard(token="t", mode="warn", now=c)
    ok_img = sum(1 for _ in range(100)
                 if g.admit("/img", client_ip="4.4.4.4").allowed)
    check("сотня обложек проходит целиком", ok_img == 100, f"прошло {ok_img}")
    d = g.admit("/match", client_ip="4.4.4.4")
    check("после них /match всё ещё пускает", d.allowed, f"status={d.status}")

    # И симметрично: исчерпанный /match не должен гасить картинки.
    for _ in range(50):
        g.admit("/match", client_ip="4.4.4.4")
    check("/match исчерпан", not g.admit("/match", client_ip="4.4.4.4").allowed)
    check("но обложки живы", g.admit("/img", client_ip="4.4.4.4").allowed)


def test_real_session_is_not_throttled():
    """Калибровка: обычная сессия человека обязана пройти без единого 429.

    Сценарий снят с клиента: открытие приложения (чарт на 40 треков + 40 обложек),
    переход в плейлист на 100 треков (100 обложек), прогрев и три тапа по трекам.
    """
    print("живая сессия анонима (старый клиент)")
    c = Clock()
    g = Guard(token="t", mode="warn", now=c)
    ip = "77.88.99.1"
    denied = []

    def go(path):
        d = g.admit(path, client_ip=ip)
        if not d.allowed:
            denied.append((path, d.reason))

    go("/catalog/chart")
    for _ in range(40):
        go("/img")
    c.advance(3)
    go("/catalog/playlist")
    for _ in range(100):
        go("/img")
    c.advance(2)
    go("/match/warm")
    for _ in range(3):
        c.advance(4)
        go("/match/deezer")
    check("ни одного отказа за сессию", not denied, f"отказов {len(denied)}: {denied[:3]}")


def test_retry_after():
    print("Retry-After")
    c = Clock()
    g = Guard(token="t", mode="warn",
              quotas=wide(catalog={"id": (2, 60), "anon": (2, 60)}), now=c)
    g.admit("/catalog/chart", client_ip="7.7.7.7")
    g.admit("/catalog/chart", client_ip="7.7.7.7")
    d = g.admit("/catalog/chart", client_ip="7.7.7.7")
    check("отбит с 429", d.status == 429)
    check("Retry-After целое и >=1", isinstance(d.retry_after, int) and d.retry_after >= 1,
          f"={d.retry_after}")
    c.advance(d.retry_after)
    check("после ожидания действительно пускает",
          g.admit("/catalog/chart", client_ip="7.7.7.7").allowed)


def test_img_token_optional():
    """Обложки обязаны работать без токена даже в режиме require.

    Проверено по клиенту: ZiziHttp.fetchBytes шлёт только User-Agent. Если этот тест начнёт
    падать после «ужесточения», значит ужесточение вернуло серую сетку вместо картинок.
    """
    print("/img без токена, но под квотой")
    c = Clock()
    g = Guard(token="t", mode="require", quotas=wide(), now=c)
    check("require: /img без токена проходит", g.admit("/img", client_ip="3.3.3.3").allowed)
    check("require: /catalog без токена по-прежнему 401",
          g.admit("/catalog/chart", client_ip="3.3.3.3").status == 401)
    check("require: /match без токена по-прежнему 401",
          g.admit("/match", client_ip="3.3.3.3").status == 401)

    # но квоту /img платит
    g2 = Guard(token="t", mode="require",
               quotas=wide(img={"id": (3, 6), "anon": (3, 6)}), now=c)
    n = sum(1 for _ in range(10) if g2.admit("/img", client_ip="3.3.3.3").allowed)
    check("/img всё равно ограничен квотой", n == 3, f"прошло {n}")


def test_current_apk_survives_require():
    """Сценарий «включили require, релиз не выпускали».

    Нынешний APK шлёт Authorization на /catalog/* и /match/*, но не шлёт на /img и не шлёт
    installId. Проверяю, что такой клиент живёт целиком.
    """
    print("нынешний APK в режиме require")
    c = Clock()
    g = Guard(token="t", mode="require", now=c)
    h = "Bearer t"
    bad = []
    for path, hdr in (("/catalog/chart", h), ("/catalog/search", h),
                      ("/match/warm", h), ("/match/deezer", h)):
        if not g.admit(path, authorization=hdr, client_ip="5.5.5.5").allowed:
            bad.append(path)
    for _ in range(40):
        if not g.admit("/img", client_ip="5.5.5.5").allowed:
            bad.append("/img")
            break
    check("старый клиент не сломан режимом require", not bad, f"сломано: {bad}")


def test_health_open():
    print("health открыт всегда")
    c = Clock()
    g = Guard(token="t", mode="require",
              quotas=wide(catalog={"id": (1, 1), "anon": (1, 1)}), now=c)
    for _ in range(50):
        g.admit("/catalog/chart", client_ip="8.8.8.8")
    d = g.admit("/catalog/health")
    check("health не требует токена", d.allowed)
    check("health не ест квоту", d.kind == "open")


# ---------------------------------------------------------------- семафор

def test_gate_capacity():
    print("потолок yt-dlp")
    gate = ExtractGate(slots=2, wait=0.05)
    check("первый слот", gate.acquire())
    check("второй слот", gate.acquire())
    t0 = time.monotonic()
    check("третий отбит", not gate.acquire())
    waited = time.monotonic() - t0
    check("ожидание ограничено", waited < 1.0, f"ждал {waited:.2f}s")
    check("отказ посчитан", gate.stats()["rejected"] == 1)
    gate.release()
    check("после release слот снова есть", gate.acquire())
    gate.release()
    gate.release()
    check("in_flight вернулся в ноль", gate.stats()["in_flight"] == 0)


def test_gate_contextmanager():
    print("семафор как контекст")
    gate = ExtractGate(slots=1, wait=0.05)
    with gate:
        check("внутри блока слот занят", gate.stats()["in_flight"] == 1)
    check("после блока освобождён", gate.stats()["in_flight"] == 0)

    with gate:
        try:
            with gate:
                check("вложенный захват не должен пройти", False)
        except ExtractBusy as e:
            check("занятый семафор кидает ExtractBusy", True)
            check("у исключения есть retry_after", e.retry_after >= 1)
    check("исключение не потеряло слот", gate.stats()["in_flight"] == 0)


def test_gate_releases_on_exception():
    print("семафор при падении внутри")
    gate = ExtractGate(slots=1, wait=0.05)
    try:
        with gate:
            raise RuntimeError("yt-dlp упал")
    except RuntimeError:
        pass
    check("слот освобождён после исключения", gate.stats()["in_flight"] == 0)
    check("слот действительно переиспользуем", gate.acquire())
    gate.release()


def test_gate_never_exceeds():
    print("потолок под нагрузкой")
    gate = ExtractGate(slots=3, wait=0.5)
    seen_peak = []
    lock = threading.Lock()

    def worker():
        if gate.acquire():
            with lock:
                seen_peak.append(gate.stats()["in_flight"])
            time.sleep(0.02)
            gate.release()

    ts = [threading.Thread(target=worker) for _ in range(30)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    check("одновременно не больше 3", max(seen_peak) <= 3, f"пик {max(seen_peak)}")
    check("работа не потеряна", len(seen_peak) == 30, f"выполнено {len(seen_peak)}")
    check("in_flight обнулён", gate.stats()["in_flight"] == 0)


# ---------------------------------------------------------------- наблюдаемость

def test_stats():
    print("счётчики для health")
    c = Clock()
    g = Guard(token="t", mode="warn", quotas=wide(), now=c)
    for _ in range(7):
        g.admit("/catalog/chart", client_ip="1.1.1.1")
    for _ in range(3):
        g.admit("/catalog/chart", authorization="Bearer t", install_id="dev1")
    g.admit("/catalog/chart", authorization="Bearer wrong", client_ip="1.1.1.1")
    s = g.stats()
    check("запросы посчитаны", s["requests"] == 11, f"={s['requests']}")
    check("анонимы посчитаны", s["anon"] == 8, f"={s['anon']}")
    check("доля анонимов считается", abs(s["anon_pct"] - 72.7) < 0.2, f"={s['anon_pct']}")
    check("неверный токен виден отдельно", s["bad_token"] == 1)
    check("режим виден", s["token_mode"] == "warn")
    check("health не попал в счётчики", g.admit("/catalog/health") and g.stats()["requests"] == 11)


def test_stats_guide_the_switch():
    print("anon_pct как критерий включения require")
    # Смысл счётчика: он должен дойти до нуля, когда все клиенты обновились. Проверяю, что
    # он это действительно показывает, а не залипает.
    g = Guard(token="t", mode="warn", quotas=wide())
    for _ in range(20):
        g.admit("/catalog/chart", authorization="Bearer t", install_id="dev1")
    check("все с токеном -> anon_pct == 0", g.stats()["anon_pct"] == 0.0,
          f"={g.stats()['anon_pct']}")


def main():
    for fn in (test_bucket, test_bucket_eviction, test_bucket_threads,
               test_token_modes, test_token_case_and_prefix,
               test_quota_split, test_quota_isolation, test_class_of,
               test_classes_are_independent, test_real_session_is_not_throttled,
               test_retry_after, test_img_token_optional,
               test_current_apk_survives_require, test_health_open,
               test_gate_capacity, test_gate_contextmanager,
               test_gate_releases_on_exception, test_gate_never_exceeds,
               test_stats, test_stats_guide_the_switch):
        fn()
    print()
    if FAILED:
        print(f"ПРОВАЛОВ: {len(FAILED)} -> {', '.join(FAILED)}")
        return 1
    print("все проверки пройдены")
    return 0


if __name__ == "__main__":
    sys.exit(main())
