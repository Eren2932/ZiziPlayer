import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent))
import deploy_browse as deploy


class DeployTests(unittest.TestCase):
    def test_restore_deletes_new_module_and_restores_catalog(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); dest = root/'dest'; backup = root/'backup'
            dest.mkdir(); backup.mkdir()
            for name in deploy.MODULES: (dest/name).write_text('new')
            (backup/'zizi_catalog.py').write_text('old')
            (backup/'manifest.json').write_text(json.dumps({'zizi_catalog.py': deploy.digest(backup/'zizi_catalog.py'),
                                                         'zizi_browse.py': None}))
            deploy.restore(dest, backup)
            self.assertEqual((dest/'zizi_catalog.py').read_text(), 'old')
            self.assertFalse((dest/'zizi_browse.py').exists())

    def test_corrupt_backup_does_not_write_anything(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root/'zizi_catalog.py').write_text('untouched')
            (root/'zizi_browse.py').write_text('untouched')
            (root/'manifest.json').write_text(json.dumps({name: 'bad' for name in deploy.MODULES}))
            with self.assertRaises(RuntimeError): deploy.restore(root, root)
            self.assertEqual((root/'zizi_catalog.py').read_text(), 'untouched')

    def test_unknown_manifest_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root/'manifest.json').write_text('{"../outside": null}')
            with self.assertRaises(RuntimeError): deploy.validate_backup(root)

    def test_unknown_installed_hotfix_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root/'zizi_catalog.py').write_text('unknown hotfix')
            with self.assertRaisesRegex(RuntimeError, 'unknown server edit'): deploy.validate_install(root)

    def test_current_release_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            known = json.loads((deploy.ROOT/'tools/browse_base_hashes.json').read_text())
            for name in list(deploy.MODULES) + list(known['unchanged']):
                (root/name).write_bytes((deploy.ROOT/name).read_bytes())
            deploy.validate_install(root)


if __name__ == '__main__': unittest.main(verbosity=2)
