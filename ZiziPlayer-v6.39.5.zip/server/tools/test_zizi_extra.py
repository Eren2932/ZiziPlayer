#!/usr/bin/env python3
"""Execute implementation with real SQLite, threads and local child processes.
External YouTube responses are fixtures. FastAPI registration uses project stub.
"""
import json
from contextlib import closing
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from zizi_extra import ExtraCatalog, ExtraError, bounded_run, clean_query, parse_tracks
from zizi_guard import ExtractGate

VID = 'abcdefghijk'

def entry(vid=VID, title='MONTAGEM DELÍRIO - Super Slowed', **kw):
    return dict(id=vid, title=title, channel='Uploader', duration=123, **kw)


def lines(*entries):
    return '\n'.join(json.dumps(e, ensure_ascii=False) for e in entries)


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.clock = [1000.0]
        self.commands = []
        self.raw = lines(entry())
        self.gate = ExtractGate(1, 0)
        self.service = ExtraCatalog(self.tmp.name + '/cache.db', self.gate,
                                    self.run_fixture, lambda: self.clock[0], enabled=lambda: True)

    def tearDown(self):
        self.tmp.cleanup()

    def run_fixture(self, command, timeout):
        self.commands.append((command, timeout))
        return self.raw

    def assert_error(self, status, fn, *args):
        with self.assertRaises(ExtraError) as result:
            fn(*args)
        self.assertEqual(result.exception.status, status)
        return result.exception

    def rows(self):
        with closing(sqlite3.connect(self.service.db_path)) as con:
            return con.execute('SELECT COUNT(*) FROM extra_pages').fetchone()[0]

    def test_disabled_never_runs_or_opens_database(self):
        self.service.enabled = lambda: False
        self.assert_error(503, self.service.search, 'montagem')
        self.assertFalse(self.commands)
        self.assertFalse(Path(self.service.db_path).exists())

    def test_default_flag_is_off(self):
        with patch.dict(os.environ, {'ZIZI_EXTRA_ENABLED': '0'}):
            self.assertFalse(ExtraCatalog('unused', self.gate).stats()['enabled'])

    def test_query_unicode_normalization(self):
        self.assertEqual(clean_query('  MONTAGEM   DELÍRIO  '), 'MONTAGEM DELÍRIO')

    def test_query_validation(self):
        for value in ['', 'a', 'x' * 201, 'foo\nbar', None]:
            with self.subTest(value=value):
                self.assert_error(422, self.service.search, value)
        self.assertFalse(self.commands)

    def test_limits_validated_without_framework(self):
        for n in [0, -1, 21, True, '10']:
            self.assert_error(422, self.service.search, 'montagem', n)

    def test_success_identity_is_youtube_not_deezer(self):
        page = self.service.search('montagem')
        track = page['items'][0]
        self.assertEqual((track['provider'], track['id']), ('yt', VID))
        self.assertIsNone(track['artist'])
        self.assertEqual(track['uploader'], 'Uploader')
        self.assertEqual(track['availability'], 'unverified')
        self.assertNotIn('url', track)
        self.assertFalse(page['cached'])

    def test_distinct_versions_and_reuploads_remain(self):
        self.raw = lines(entry(), entry('12345678901', 'MONTAGEM DELÍRIO - Slowed'),
                         entry('12345678902', 'MONTAGEM DELÍRIO'), entry('12345678903'))
        self.assertEqual(len(self.service.search('montagem')['items']), 4)

    def test_duplicate_video_ids_collapse(self):
        self.raw = lines(entry(), entry(title='same video new title'))
        self.assertEqual(len(self.service.search('montagem')['items']), 1)

    def test_live_private_bad_ids_filtered(self):
        self.raw = lines(entry(live_status='is_live'), entry('12345678901', availability='private'),
                         entry('https://evil.test'), entry('12345678902', availability='public'))
        self.assertEqual([x['id'] for x in self.service.search('montagem')['items']], ['12345678902'])

    def test_unknown_duration_not_fabricated(self):
        e = entry(); e['duration'] = None
        track = parse_tracks(lines(e), 10)[0]
        self.assertIsNone(track['dur'])
        self.assertFalse(track['duration_known'])

    def test_json_error_not_negative_cache(self):
        self.raw = '{bad json'
        self.assert_error(502, self.service.search, 'montagem')
        self.assertEqual(self.rows(), 0)
        self.assertEqual(self.gate.stats()['in_flight'], 0)

    def test_non_object_json_rejected(self):
        for text in ['null', '[]', '42']:
            self.assert_error(502, parse_tracks, text, 10)

    def test_cache_hit_no_new_process(self):
        self.service.search('montagem')
        self.assertTrue(self.service.search('montagem')['cached'])
        self.assertEqual(len(self.commands), 1)

    def test_cache_persists_across_service_instances(self):
        self.service.search('montagem')
        other = ExtraCatalog(self.service.db_path, self.gate, self.run_fixture,
                             lambda: self.clock[0], enabled=lambda: True)
        self.assertTrue(other.search('montagem')['cached'])
        self.assertEqual(len(self.commands), 1)

    def test_positive_cache_expires_at_six_hours(self):
        self.service.search('montagem')
        self.clock[0] += 21600
        self.assertFalse(self.service.search('montagem')['cached'])
        self.assertEqual(len(self.commands), 2)

    def test_successful_empty_page_short_ttl(self):
        self.raw = ''
        self.service.search('montagem')
        self.clock[0] += 299
        self.assertTrue(self.service.search('montagem')['cached'])
        self.clock[0] += 1
        self.assertFalse(self.service.search('montagem')['cached'])

    def test_cache_is_bounded(self):
        for i in range(270):
            self.service.search(f'montagem {i}')
        self.assertEqual(self.rows(), 256)

    def test_busy_gate_fast_fail_no_process_no_cache(self):
        self.assertTrue(self.gate.acquire(0))
        try:
            error = self.assert_error(429, self.service.search, 'montagem')
            self.assertEqual(error.retry, 2)
            self.assertEqual(self.rows(), 0)
            self.assertFalse(self.commands)
        finally:
            self.gate.release()
        self.assertTrue(self.service.search('montagem')['items'])

    def test_failure_cooldown_and_slot_release(self):
        def fail(*a, **kw):
            raise ExtraError(504, 'extractor timeout', 15)
        self.service.runner = fail
        self.assert_error(504, self.service.search, 'montagem')
        self.assertEqual(self.gate.stats()['in_flight'], 0)
        self.assertEqual(self.rows(), 0)
        self.service.runner = self.run_fixture
        self.assert_error(503, self.service.search, 'different query')
        self.clock[0] += 15
        self.assertTrue(self.service.search('montagem')['items'])

    def test_singleflight_no_duplicate_process_and_no_waiter_queue(self):
        entered, finish = threading.Event(), threading.Event()
        outcomes = []
        def slow(*a, **kw):
            entered.set()
            if not finish.wait(3):
                raise RuntimeError('test did not release worker')
            return self.raw
        def worker():
            try:
                outcomes.append(self.service.search('montagem'))
            except Exception as error:
                outcomes.append(error)
        self.service.runner = slow
        thread = threading.Thread(target=worker)
        thread.start()
        try:
            self.assertTrue(entered.wait(2))
            self.assert_error(429, self.service.search, 'montagem')
            self.assert_error(429, self.service.search, 'other query')
            self.assertEqual(self.service.stats()['runs'], 1)
        finally:
            finish.set(); thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertIsInstance(outcomes[0], dict)
        self.assertTrue(self.service.search('montagem')['cached'])

    def test_command_no_shell_no_config_no_audio(self):
        self.service.search('--exec $(touch /tmp/NOPE)')
        cmd, timeout = self.commands[0]
        self.assertEqual(cmd[-1], 'ytsearch10:--exec $(touch /tmp/NOPE)')
        self.assertEqual(cmd[-2], '--')
        self.assertIn('--ignore-config', cmd)
        self.assertIn('--skip-download', cmd)
        self.assertIn('--flat-playlist', cmd)
        self.assertEqual(timeout, 8)

    def test_playlist_uses_bounded_page_not_user_url(self):
        pid = 'PLabcdefghijklmnopqrstuv'
        page = self.service.playlist(pid, 10, 20)
        cmd = self.commands[0][0]
        self.assertEqual(cmd[cmd.index('--playlist-start') + 1], '21')
        self.assertEqual(cmd[cmd.index('--playlist-end') + 1], '30')
        self.assertEqual(cmd[-1], 'https://www.youtube.com/playlist?list=' + pid)
        self.assertIsNone(page['total'])
        self.assertIsNone(page['next_offset'])

    def test_arbitrary_playlist_urls_rejected(self):
        for value in ['https://127.0.0.1/', 'file:///etc/passwd', '../secret', 'RDabcdefghijk']:
            self.assert_error(422, self.service.playlist, value)
        self.assertFalse(self.commands)

    def test_cache_database_failure_does_not_start_extractor(self):
        self.service.db_path = self.tmp.name + '/missing/cache.db'
        self.assert_error(503, self.service.search, 'montagem')
        self.assertFalse(self.commands)

    def test_healthy_cache_still_works_during_cooldown(self):
        self.service.search('healthy query')
        def fail(*a, **kw):
            raise ExtraError(502, 'upstream failed', 15)
        self.service.runner = fail
        self.assert_error(502, self.service.search, 'failing query')
        self.assertTrue(self.service.search('healthy query')['cached'])

    def test_corrupted_json_cache_is_refetched(self):
        self.service.search('montagem')
        with closing(sqlite3.connect(self.service.db_path)) as con, con:
            con.execute("UPDATE extra_pages SET body='broken json'")
        self.assertFalse(self.service.search('montagem')['cached'])
        self.assertEqual(len(self.commands), 2)

    def test_stats_explicit_about_playback_isolation(self):
        self.assertFalse(self.service.stats()['playback_isolation'])


class ProcessTests(unittest.TestCase):
    def test_real_child_success(self):
        self.assertEqual(bounded_run([sys.executable, '-c', "print('metadata')"]), 'metadata\n')

    def test_real_child_failure(self):
        with self.assertRaises(ExtraError) as error:
            bounded_run([sys.executable, '-c', 'raise SystemExit(2)'])
        self.assertEqual(error.exception.status, 502)

    def test_real_child_timeout(self):
        with self.assertRaises(ExtraError) as error:
            bounded_run([sys.executable, '-c', 'import time; time.sleep(10)'], timeout=.1)
        self.assertEqual(error.exception.status, 504)

    def test_real_child_output_limit(self):
        with self.assertRaises(ExtraError) as error:
            bounded_run([sys.executable, '-c', "print('x' * 5000)"], max_bytes=128)
        self.assertEqual(error.exception.status, 502)

    def test_missing_executable(self):
        with self.assertRaises(ExtraError) as error:
            bounded_run(['/not/a/real/executable'])
        self.assertEqual(error.exception.status, 503)


class WiringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(HERE / '_stub'))
        import zizi_catalog
        cls.zc = zizi_catalog

    def test_extra_routes_inherit_guard(self):
        self.assertIs(self.zc.router.dependencies[0].dependency, self.zc.guard_dep)
        paths = {p for p, _, _ in self.zc.router.routes}
        self.assertTrue({'/catalog/extra/search', '/catalog/extra/playlist'} <= paths)

    def test_error_status_and_retry_after_preserved(self):
        def fail():
            raise ExtraError(429, 'busy', 2)
        with self.assertRaises(self.zc.HTTPException) as error:
            self.zc._extra_call(fail)
        self.assertEqual(error.exception.status_code, 429)
        self.assertEqual(error.exception.headers['Retry-After'], '2')

    def test_route_calls_actual_service(self):
        with tempfile.TemporaryDirectory() as tmp:
            service = ExtraCatalog(tmp + '/extra.db', ExtractGate(1, 0),
                                   lambda *a, **kw: lines(entry()), enabled=lambda: True)
            with patch.object(self.zc, '_extra', service):
                self.assertEqual(self.zc.catalog_extra_search('montagem', 10)['items'][0]['id'], VID)

    def test_old_search_stays_deezer_only(self):
        expected = [{'src': 'deezer', 'id': '123'}]
        with patch.object(self.zc, 'SP_ID', ''), patch.object(self.zc, 'dz_search', return_value=expected):
            self.assertEqual(self.zc.catalog_search('montagem', 10, 0, 'auto')['items'], expected)


if __name__ == '__main__':
    unittest.main(verbosity=2)
