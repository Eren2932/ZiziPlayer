#!/usr/bin/env python3
"""Time match -> resolve -> first stream byte against the local VPS service.
Explicit --run-live. May populate existing caches; never flushes or restarts.
Reads only ZIZI_TOKEN from the env file; prints no token, signed URL, or raw body.
The stream request can trigger the service's normal full-track cache fill.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import re
import shlex
import time
import urllib.error
import urllib.parse
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',default='http://127.0.0.1:8080')
    target=p.add_mutually_exclusive_group(required=True)
    target.add_argument('--video-id'); target.add_argument('--deezer-id')
    p.add_argument('--env-file',default='/opt/zizi/zizi.env')
    p.add_argument('--extra-query',help='Optional parallel search, ONLY after extra trial is enabled')
    p.add_argument('--run-live',action='store_true')
    args=p.parse_args()
    if not args.run_live: p.error('--run-live is required')
    base=args.base.rstrip('/'); parsed=urllib.parse.urlsplit(base)
    if (parsed.scheme!='http' or parsed.hostname not in ('127.0.0.1','localhost','::1')
            or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment):
        p.error('base must be a loopback HTTP origin')
    if args.video_id and not re.fullmatch(r'[A-Za-z0-9_-]{11}',args.video_id): p.error('invalid video id')
    if args.deezer_id and not re.fullmatch(r'[0-9]{1,20}',args.deezer_id): p.error('invalid Deezer id')
    token=''
    for line in Path(args.env_file).read_text().splitlines():
        if line.startswith('ZIZI_TOKEN='):
            parts=shlex.split(line.split('=',1)[1],comments=True)
            token=parts[0] if len(parts)==1 else ''
    if not token: p.error('ZIZI_TOKEN missing; no unauthenticated probe will be sent')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    headers={'Authorization':'Bearer '+token, 'X-Zizi-Install':'stage2-playback-probe'}
    def call(path, params=None, stream=False):
        url=base+path+('?' + urllib.parse.urlencode(params) if params else '')
        req=urllib.request.Request(url,headers=dict(headers,**({'Range':'bytes=0-65535'} if stream else {})))
        start=time.monotonic()
        try:
            with opener.open(req,timeout=100) as response:
                if stream:
                    first=response.read(1)
                    return {'status':response.status,'first_byte_ms':round((time.monotonic()-start)*1000),
                            'bytes_observed':len(first)}
                body=json.loads(response.read(2*1024*1024))
                return {'status':response.status,'ms':round((time.monotonic()-start)*1000),'body':body}
        except urllib.error.HTTPError as e:
            return {'status':e.code,'ms':round((time.monotonic()-start)*1000)}
        except (OSError,ValueError):
            return {'status':None,'ms':round((time.monotonic()-start)*1000),'error':'network_or_decode'}
    auth=call('/auth/device')
    if auth.get('status')!=200 or not auth.get('body',{}).get('token'):
        print(json.dumps({'ok':False,'phase':'device_auth','status':auth.get('status')})); return 1
    headers['Authorization']='Bearer '+auth['body']['token']
    rows=[]; extra=None
    # At most one optional extra request; no stress loop on the production VPS.
    with ThreadPoolExecutor(max_workers=1) as pool:
        future=pool.submit(call,'/catalog/extra/search',{'q':args.extra_query,'limit':5}) if args.extra_query else None
        for phase in ('first','repeat'):
            start=time.monotonic(); row={'phase':phase}; vid=args.video_id
            if args.deezer_id:
                result=call('/match/deezer',{'id':args.deezer_id})
                row['match']={k:v for k,v in result.items() if k!='body'}
                row['match']['cached']=result.get('body',{}).get('cached')
                vid=result.get('body',{}).get('vid')
            if vid:
                result=call('/resolve',{'id':vid})
                row['resolve']={k:v for k,v in result.items() if k!='body'}
                row['resolve']['cached']=result.get('body',{}).get('cached')
                if result.get('status')==200:
                    row['stream']=call('/stream',{'id':vid},True)
            row['total_ms']=round((time.monotonic()-start)*1000); rows.append(row)
        if future:
            result=future.result(); extra={k:v for k,v in result.items() if k!='body'}
            extra['count']=len(result.get('body',{}).get('items',[]))
            extra['cached']=result.get('body',{}).get('cached')
    health=call('/health').get('body',{})
    ok=all(r.get('stream',{}).get('bytes_observed')==1 for r in rows)
    print(json.dumps({'ok':ok,'rows':rows,'extra':extra,
                      'resolver_version':health.get('version'),'scheduler':health.get('scheduler'),
                      'cache_flushed':False,'service_restarted':False},ensure_ascii=False,indent=2))
    return 0 if ok else 1


if __name__=='__main__': raise SystemExit(main())
