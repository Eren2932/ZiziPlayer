#!/usr/bin/env python3
"""Probe tests with real loopback HTTP and fixture service behavior (not real YouTube)."""
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import probe_contention as probe


@contextmanager
def server(mode='cold'):
    lock = threading.RLock()
    state = dict(started=0, rejected=0, preemptions=0, wait_ms=0, slots=1,
                 scope='service-process', resolver_attached=True, active=None, queued=0, active_ms=0)
    cancel = threading.Event()
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            requests.append(self.path)
            body = {}
            status = 200
            if self.path == '/health':
                with lock:
                    body = {'version': '1.7-stage2', 'scheduler': dict(state)}
            elif self.path == '/catalog/health':
                body = {'extra': {'enabled': mode != 'disabled'}}
            elif self.path == '/auth/device':
                body = {'token': 'fixture-device-NOT-REAL'}
            elif self.path.startswith('/catalog/search'):
                body = {'items': [{'id': '123', 'title': 'Name', 'artist': 'Artist', 'dur': 90,
                                   'art': 'https://invalid.example/SECRET-SIGNED-URL'}]}
            elif self.path.startswith('/catalog/extra/search'):
                if mode == 'extra_cached':
                    body = {'cached': True, 'items': []}
                else:
                    with lock:
                        state['active'] = 'extra'
                        state['started'] += 1
                    cancelled = cancel.wait(1.5)
                    with lock:
                        if state['active'] == 'extra':
                            state['active'] = None
                    status = 429 if cancelled else 200
                    body = {'cached': False, 'items': []}
            elif self.path.startswith('/match/deezer'):
                if mode != 'warm':
                    with lock:
                        if state['active'] == 'extra':
                            state['preemptions'] += 1
                            state['queued'] = 1
                            cancel.set()
                    time.sleep(.25)
                    with lock:
                        state['active'] = 'match'
                        state['queued'] = 0
                        state['started'] += 1
                    time.sleep(.1)
                    with lock:
                        state['active'] = None
                body = {'vid': 'abcdefghijk', 'cached': mode == 'warm'}
            elif self.path.startswith('/resolve'):
                with lock:
                    state['started'] += int(mode != 'warm')
                body = {'cached': mode == 'warm', 'url': 'https://invalid.example/SECRET-SIGNED-URL'}
            elif self.path.startswith('/stream'):
                content = b'x' * 100
                self.send_response(206)
                self.send_header('Content-Range', 'bytes 0-99/100' if mode != 'bad_range' else 'nonsense')
                self.send_header('Content-Length', '100')
                self.end_headers()
                self.wfile.write(content[:3] if mode == 'short_stream' else content)
                return
            raw = json.dumps(body).encode()
            self.send_response(status)
            if status == 429:
                self.send_header('Retry-After', '2')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

    srv = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=srv.serve_forever)
    thread.start()
    client = probe.Client('http://127.0.0.1:' + str(srv.server_port), 'fixture-token-NOT-REAL', timeout=3)
    try:
        yield client, requests
    finally:
        cancel.set()
        srv.shutdown()
        thread.join(3)
        srv.server_close()


class ProbeTests(unittest.TestCase):
    def test_cold_preemption_and_queue(self):
        with server() as (client, requests):
            r = probe.run_probe(client, '123', 'unused music')
        self.assertEqual(r['assessment'], 'cold_preemption_observed')
        self.assertEqual(r['scheduler_delta']['preemptions'], 1)
        self.assertTrue(r['queue_observed'])
        self.assertEqual(r['chain']['stream']['bytes_observed'], 100)
        self.assertEqual(r['audible_stability'], 'not_measured')
        self.assertFalse(r['mobile_network_tested'])
        self.assertFalse(any('/flush' in p for p in requests))
        self.assertEqual(sum(p.startswith('/match/deezer') for p in requests), 1)

    def test_cached_extra_never_warms_selected_track(self):
        with server('extra_cached') as (client, requests):
            r = probe.run_probe(client, '123', 'cached music')
        self.assertEqual(r['assessment'], 'inconclusive')
        self.assertNotIn('chain', r)
        self.assertFalse(any(p.startswith('/match') for p in requests))

    def test_warm_pipeline_is_not_cold(self):
        with server('warm') as (client, _):
            r = probe.run_probe(client, '123')
        self.assertEqual(r['assessment'], 'warm_or_partial_pipeline')
        self.assertTrue(r['pipeline_success'])

    def test_cold_pipeline(self):
        with server() as (client, _):
            r = probe.run_probe(client, '123')
        self.assertEqual(r['assessment'], 'cold_pipeline_observed')
        self.assertFalse(r['queue_limit_tested'])

    def test_disabled_aborts_before_extraction(self):
        with server('disabled') as (client, requests):
            r = probe.run_probe(client, '123', 'unused music')
        self.assertEqual(r['assessment'], 'not_run')
        self.assertFalse(any(p.startswith('/match') for p in requests))
        self.assertFalse(any(p.startswith('/catalog/extra') for p in requests))

    def test_invalid_range_is_failure(self):
        with server('bad_range') as (client, _):
            r = probe.run_probe(client, '123')
        self.assertEqual(r['assessment'], 'pipeline_failed')

    def test_short_body_is_failure(self):
        with server('short_stream') as (client, _):
            r = probe.run_probe(client, '123')
        self.assertEqual(r['assessment'], 'pipeline_failed')
        self.assertEqual(r['chain']['stream']['bytes_observed'], 3)

    def test_origin_validation(self):
        for url in ['https://example.com', 'http://127.0.0.1.example.com',
                    'http://x@127.0.0.1', 'http://127.0.0.1/path', 'http://127.0.0.1?token=x']:
            with self.assertRaises(ValueError):
                probe.origin(url)
        self.assertEqual(probe.origin('http://[::1]:8080'), ('::1', 8080))

    def test_nonlocal_rejected_before_secret_read(self):
        r = subprocess.run([sys.executable, str(Path(probe.__file__)), '--base', 'http://example.com',
                            '--env-file', '/nonexistent', '--deezer-id', '123', '--run-live'],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertEqual(json.loads(r.stdout)['assessment'], 'not_run')

    def test_cli_finder_no_match_or_secrets(self):
        with server() as (client, requests), tempfile.TemporaryDirectory() as tmp:
            env = Path(tmp) / 'env'
            env.write_text('OTHER_SECRET=do-not-echo\nZIZI_TOKEN="bootstrap-fixture"\n')
            r = subprocess.run([sys.executable, str(Path(probe.__file__)), '--base',
                               'http://127.0.0.1:' + str(client.port), '--env-file', str(env),
                               '--find', 'Artist Name', '--run-live'], capture_output=True, text=True, timeout=5)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(json.loads(r.stdout)['items'][0]['deezer_id'], '123')
        for secret in ['do-not-echo', 'bootstrap-fixture', 'SECRET-SIGNED-URL', 'fixture-device-NOT-REAL']:
            self.assertNotIn(secret, r.stdout + r.stderr)
        self.assertFalse(any(p.startswith('/match') for p in requests))

    def test_counter_reset_cannot_pass(self):
        r = probe.assess({'mode': 'contention', 'before': {'preemptions': 3}, 'after': {'preemptions': 1},
                         'chain': {'match': {'cached': False}, 'resolve': {'cached': False},
                                   'stream': {'complete': True}}, 'extra_seen_active': True,
                         'at_match_start': {'active': 'extra'}, 'extra': {'status': 429}})
        self.assertTrue(r['counter_reset_detected'])
        self.assertEqual(r['assessment'], 'inconclusive')

    def test_unrelated_preemptions_cannot_pass_without_observed_extra(self):
        r = probe.assess({'mode': 'contention', 'before': {'preemptions': 0}, 'after': {'preemptions': 2},
                         'chain': {'match': {'cached': False}, 'resolve': {'cached': False},
                                   'stream': {'complete': True}}, 'extra': {'status': 429}})
        self.assertEqual(r['assessment'], 'inconclusive')


if __name__ == '__main__':
    unittest.main(verbosity=2)
