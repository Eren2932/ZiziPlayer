"""Минимальная заглушка FastAPI — только чтобы импортировать zizi_catalog и проверить врезку.

Не имитирует фреймворк. Даёт ровно те имена, которые модуль использует на уровне импорта и
объявления роутов, и запоминает зависимости роутера, чтобы тест мог убедиться: защита
действительно висит на КАЖДОМ роуте, а не на тех, что я не забыл.
"""


class HTTPException(Exception):
    def __init__(self, status_code, detail=None, headers=None):
        super().__init__(f"{status_code}: {detail}")
        self.status_code = status_code
        self.detail = detail
        self.headers = headers or {}


class _Dep:
    def __init__(self, dependency):
        self.dependency = dependency


def Depends(dependency=None):
    return _Dep(dependency)


def Query(default=None, **kw):
    return default


def Header(default=None, **kw):
    return default


class Response:
    def __init__(self, *a, **kw):
        pass


class BackgroundTasks:
    def add_task(self, *a, **kw):
        pass


class Request:
    def __init__(self, path="/", query=None, client_host="1.2.3.4"):
        self.url = type("U", (), {"path": path})()
        self.query_params = query or {}
        self.client = type("C", (), {"host": client_host})()


class APIRouter:
    def __init__(self, dependencies=None, **kw):
        self.dependencies = dependencies or []
        self.routes = []

    def _reg(self, path, **kw):
        def deco(fn):
            self.routes.append((path, fn, kw.get("dependencies")))
            return fn
        return deco

    def get(self, path, **kw):
        return self._reg(path, **kw)

    def post(self, path, **kw):
        return self._reg(path, **kw)
