"""Заглушка requests для теста врезки.

Стоит в sys.path ПЕРЕД настоящей библиотекой намеренно, по двум причинам.

Первая: на раннере GitHub Actions настоящего requests может не быть, и тогда шаг CI упал бы
на ImportError — то есть тест защиты заблокировал бы сборку APK по причине, к защите
отношения не имеющей.

Вторая важнее: тест врезки не должен ходить в сеть. Любой вызов здесь падает громко, а не
уходит в интернет и не залипает на таймауте. Если этот текст когда-нибудь появится в логе —
значит тест начал делать то, чего делать не должен.
"""


class RequestException(Exception):
    pass


class Timeout(RequestException):
    pass


class HTTPError(RequestException):
    pass


class _Boom(RequestException):
    pass


def _no_network(*a, **kw):
    raise _Boom(
        "тест врезки попытался выйти в сеть — так быть не должно; "
        "проверь, какой вызов это сделал"
    )


get = post = head = put = delete = request = _no_network


class Session:
    def __init__(self, *a, **kw):
        pass

    get = post = head = request = staticmethod(_no_network)


class exceptions:  # noqa: N801 — имя как в оригинале
    RequestException = RequestException
    Timeout = Timeout
    HTTPError = HTTPError
