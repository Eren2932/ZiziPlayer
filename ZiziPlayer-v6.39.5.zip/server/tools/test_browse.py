#!/usr/bin/env python3
"""Execute Browse handlers with fixture upstream data; no live API or ASGI claims."""
import copy
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / '_stub'))
sys.path.insert(0, str(HERE.parent))
from fastapi import APIRouter, HTTPException
from zizi_browse import install_routes

TRACK = {'id': 42, 'title': 'Super Slowed', 'artist': {'name': 'Artist'},
         'album': {'title': 'Album', 'cover_big': 'https://img.example/album.jpg'},
         'duration': 123, 'explicit_lyrics': True}


def convert(row):
    return {'id': str(row['id']), 'title': row.get('title'),
            'artist': (row.get('artist') or {}).get('name'),
            'album': (row.get('album') or {}).get('title'),
            'art': (row.get('album') or {}).get('cover_big'), 'dur': row.get('duration', 0)}


class BrowseTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.reply = {'data': [TRACK], 'total': 1}
        self.metadata = {'id': 17, 'title': 'Album', 'name': 'Artist',
                         'cover_xl': 'https://img.example/xl.jpg',
                         'picture_xl': 'https://img.example/artist.jpg'}
        router = APIRouter(dependencies=['existing guard'])
        def get(path, **params):
            self.calls.append((path, params))
            return copy.deepcopy(self.metadata if path in ('artist/17', 'album/17', 'playlist/17') else self.reply)
        install_routes(router, get, convert)
        self.router = router
        self.handlers = {path: fn for path, fn, deps in router.routes}
        self.search = self.handlers['/catalog/browse']
        self.collection = self.handlers['/catalog/browse/collection']

    def test_artist_tab_uses_artist_endpoint(self):
        self.reply = {'data': [self.metadata]}
        result = self.search('MONTAGEM', 'artist', 25, 0)
        self.assertEqual(self.calls[0][0], 'search/artist')
        self.assertEqual(result['items'][0]['kind'], 'artist')
        self.assertEqual(result['items'][0]['art'], self.metadata['picture_xl'])
        self.assertEqual(result['items'][0]['title'], 'Artist')

    def test_album_tab_has_album_identity(self):
        self.reply = {'data': [dict(self.metadata, artist={'name': 'Owner'})]}
        result = self.search('album', 'album', 25, 0)
        self.assertEqual(self.calls[0][0], 'search/album')
        self.assertEqual(result['items'][0]['subtitle'], 'Owner')
        self.assertEqual(result['items'][0]['kind'], 'album')

    def test_playlist_owner_is_not_artist(self):
        self.reply = {'data': [dict(self.metadata, user={'name': 'Curator'})]}
        row = self.search('mix', 'playlist', 25, 0)['items'][0]
        self.assertEqual(row['subtitle'], 'Curator')
        self.assertNotIn('artist', row)

    def test_tracks_keep_explicit(self):
        result = self.search('song', 'track', 25, 0)
        self.assertTrue(result['items'][0]['explicit'])
        self.assertEqual(result['src'], 'deezer')
        self.assertEqual(result['items'][0]['id'], '42')

    def test_offset_and_limit_forwarded(self):
        self.search(' song ', 'track', 25, 25)
        self.assertEqual(self.calls, [('search', {'q': 'song', 'limit': 25, 'index': 25})])

    def test_no_next_when_full_but_finished(self):
        self.reply['data'] = [TRACK] * 25
        self.assertIsNone(self.search('song', 'track', 25, 0)['next_offset'])

    def test_next_is_number_never_upstream_url(self):
        self.reply['next'] = 'https://untrusted.example/path?token=secret'
        result = self.search('song', 'track', 25, 25)
        self.assertEqual(result['next_offset'], 50)
        self.assertNotIn('untrusted', str(result))

    def test_empty_page_stops(self):
        self.reply = {'data': [], 'next': 'present'}
        self.assertIsNone(self.search('song', 'track', 25, 0)['next_offset'])

    def test_invalid_kind_no_upstream(self):
        with self.assertRaises(HTTPException):
            self.search('song', '../../private', 25, 0)
        self.assertFalse(self.calls)

    def test_invalid_query_no_upstream(self):
        for query in ['   ', 'x' * 301]:
            with self.assertRaises(HTTPException):
                self.search(query, 'track', 25, 0)
        self.assertFalse(self.calls)

    def test_invalid_id_no_upstream(self):
        for key in ['../17', '١٧', '17?x=y', '']:
            with self.assertRaises(HTTPException):
                self.collection(key, 'album', 50, 0)
        self.assertFalse(self.calls)

    def test_artist_hero_uses_artist_image(self):
        result = self.collection('17', 'artist', 50, 0)
        self.assertEqual(result['collection']['art'], self.metadata['picture_xl'])
        self.assertEqual(self.calls[1][0], 'artist/17/top')
        self.assertNotIn('listeners', result['collection'])
        self.assertNotIn('verified', result['collection'])

    def test_album_missing_track_art_falls_back_to_album_cover(self):
        self.reply['data'] = [dict(TRACK, album=None)]
        result = self.collection('17', 'album', 50, 0)
        self.assertEqual(result['items'][0]['art'], self.metadata['cover_xl'])
        self.assertEqual(result['items'][0]['album'], 'Album')

    def test_playlist_keeps_order_and_repetitions(self):
        self.reply['data'] = [dict(TRACK, id=3), dict(TRACK, id=2), dict(TRACK, id=3)]
        result = self.collection('17', 'playlist', 50, 50)
        self.assertEqual([row['id'] for row in result['items']], ['3', '2', '3'])
        self.assertEqual(self.calls[1][1]['index'], 50)

    def test_empty_collection_keeps_cover(self):
        self.reply = {'data': [], 'total': 0}
        result = self.collection('17', 'album', 50, 0)
        self.assertEqual(result['items'], [])
        self.assertTrue(result['collection']['art'])

    def test_routes_use_supplied_guarded_router(self):
        self.assertEqual(self.router.dependencies, ['existing guard'])
        self.assertEqual(len(self.router.routes), 2)

    def test_unknown_total_not_fabricated(self):
        self.reply.pop('total')
        self.assertIsNone(self.search('song', 'track', 25, 0)['total'])

    def test_malformed_rows_skipped(self):
        self.reply['data'] = [None, {}, TRACK]
        self.assertEqual(len(self.search('song', 'track', 25, 0)['items']), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
