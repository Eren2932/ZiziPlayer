from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import threading
import unittest
from urllib.parse import parse_qs, urlsplit

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from probe_browse import probe
from probe_contention import Client


class ProbeTests(unittest.TestCase):
    def test_local_http_contract_auth_and_no_audio(self):
        calls = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(self):
                calls.append((self.path, self.headers.get('Authorization')))
                if self.path == '/auth/device':
                    body = {'token': 'fixture-device-secret'}
                else:
                    kind = parse_qs(urlsplit(self.path).query)['kind'][0]
                    body = {'contract': 1, 'src': 'deezer', 'items': [{'kind': kind, 'id': '17',
                            'title': 'fixture', 'private_field': 'not-in-report'}]}
                self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps(body).encode())
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever); thread.start()
        try:
            result = probe(Client('http://127.0.0.1:' + str(server.server_port), 'fixture-bootstrap'), 'song')
            self.assertTrue(result['ok'])
            self.assertEqual(len(calls), 5)
            self.assertTrue(all(path.startswith('/catalog/browse?') for path, auth in calls[1:]))
            self.assertTrue(all(auth == 'Bearer fixture-device-secret' for path, auth in calls[1:]))
            self.assertNotIn('secret', json.dumps(result))
            self.assertNotIn('not-in-report', json.dumps(result))
        finally:
            server.shutdown(); thread.join(2); server.server_close()

    def test_wrong_kind_fails(self):
        class Fake:
            token = ''
            def call(self, path, *args, **kwargs):
                return {'status': 200, 'body': {'token': 'fixture', 'contract': 1, 'src': 'deezer',
                                               'items': [{'kind': 'track'}]}}
        self.assertFalse(probe(Fake(), 'song')['ok'])

    def test_old_server_fails(self):
        class Fake:
            token = ''
            def call(self, path, *args, **kwargs):
                if path == '/auth/device': return {'status': 200, 'body': {'token': 'fixture'}}
                return {'status': 404}
        self.assertFalse(probe(Fake(), 'song')['ok'])

    def test_external_origin_rejected_before_env_read(self):
        result = subprocess.run([sys.executable, str(HERE/'probe_browse.py'), '--run-live',
                                 '--base', 'http://example.com', '--env-file', '/no-file'],
                                capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('loopback', result.stderr)
        self.assertNotIn('FileNotFoundError', result.stderr)


if __name__ == '__main__': unittest.main(verbosity=2)
