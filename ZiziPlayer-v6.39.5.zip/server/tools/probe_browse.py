#!/usr/bin/env python3
"""Check typed metadata on local VPS. No extraction, stream reads or restarts."""
import argparse
import json
from probe_contention import Client, origin, read_token, safe_result


def probe(client, query):
    auth = client.call('/auth/device', timeout=5)
    token = auth.get('body', {}).get('token')
    if auth.get('status') != 200 or not token:
        return {'ok': False, 'phase': 'device_auth', 'status': auth.get('status')}
    client.token = token
    rows = []
    for kind in ('track', 'artist', 'album', 'playlist'):
        response = client.call('/catalog/browse', {'q': query, 'kind': kind, 'limit': 3}, timeout=20)
        body = response.get('body', {})
        items = body.get('items', [])
        correct = (response.get('status') == 200 and body.get('contract') == 1 and
                   body.get('src') == 'deezer' and isinstance(items, list) and
                   all(isinstance(row, dict) and row.get('kind') == kind for row in items))
        rows.append(dict(safe_result(response), kind=kind, count=len(items) if isinstance(items, list) else None,
                         correct_contract=correct))
    return {'ok': all(row['correct_contract'] for row in rows), 'rows': rows,
            'audio_requested': False, 'extractors_requested': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', default='http://127.0.0.1:8080')
    p.add_argument('--env-file', default='/opt/zizi/zizi.env')
    p.add_argument('--query', default='MORGENSHTERN')
    p.add_argument('--run-live', action='store_true')
    args = p.parse_args()
    if not args.run_live: p.error('--run-live is required')
    origin(args.base)  # Validate before reading a secret.
    if not args.query.strip() or len(args.query) > 300: p.error('query must contain 1..300 characters')
    result = probe(Client(args.base, read_token(args.env_file)), args.query)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__': raise SystemExit(main())
