#!/usr/bin/env python3
"""Execute resolver functions with fake YoutubeDL/httpx/FastAPI dependencies.
No ASGI lifecycle or external networking is claimed. Scheduler/threads are real.
"""
import asyncio
from pathlib import Path
import sys
import threading
import time
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent),str(HERE/'_stub')]
import fastapi
class App(fastapi.APIRouter):
    def on_event(self, name): return lambda f:f
    def include_router(self, router): self.routes.extend(router.routes)
fastapi.FastAPI=App
responses=types.ModuleType('fastapi.responses')
responses.JSONResponse=fastapi.Response
responses.StreamingResponse=fastapi.Response
sys.modules['fastapi.responses']=responses
httpx=types.ModuleType('httpx'); httpx.AsyncClient=object
sys.modules['httpx']=httpx
fake_ydl=types.ModuleType('yt_dlp'); fake_ydl.YoutubeDL=object
sys.modules['yt_dlp']=fake_ydl
import zizi_resolver as resolver
import zizi_catalog as catalog
from zizi_scheduler import SCHEDULER


def data(vid):
    return dict(id=vid,via='direct',mime='m4a',abr=128,
                cached_until=time.time()+3600,url='https://invalid.test/audio')


class ResolverTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        resolver._cache.clear(); resolver._neg.clear(); resolver._locks.clear()
        resolver._fg_want.clear(); resolver._throttle.update(direct=0,proxy=0)

    async def test_same_singleton_is_wired_to_both_modules(self):
        self.assertIs(resolver.SCHEDULER,catalog.SCHEDULER)
        self.assertTrue(SCHEDULER.stats()['resolver_attached'])

    async def test_cache_hit_bypasses_occupied_extractor(self):
        resolver._cache['abcdefghijk']=data('abcdefghijk')
        with SCHEDULER.acquire('match',1), patch.object(resolver,'_extract') as extract:
            hit=await resolver._resolve_cached('abcdefghijk')
            self.assertEqual(hit['id'],'abcdefghijk'); extract.assert_not_called()

    async def test_full_cold_resolve_uses_shared_slot_and_caches(self):
        def extract(vid,*args):
            self.assertEqual(SCHEDULER.stats()['active'],'playback')
            return data(vid)
        with patch.object(resolver,'_extract',side_effect=extract), patch.object(resolver,'CLIENTS',['ios']):
            hit=await resolver._resolve_cached('abcdefghijk')
        self.assertEqual(hit['id'],'abcdefghijk')
        self.assertIn('abcdefghijk',resolver._cache)
        self.assertIsNone(SCHEDULER.stats()['active'])

    async def test_same_video_singleflight(self):
        calls=[]
        def extract(vid,*args):
            calls.append(vid); time.sleep(.03); return data(vid)
        with patch.object(resolver,'_extract',side_effect=extract):
            results=await asyncio.gather(resolver._resolve_cached('abcdefghijk'),resolver._resolve_cached('abcdefghijk'))
        self.assertEqual(len(results),2); self.assertEqual(len(calls),1)

    async def test_soft_budget_does_not_negative_cache_or_try_next_client(self):
        calls=[]
        def extract(*args):
            calls.append(1); time.sleep(.04); raise RuntimeError('fixture transient failure')
        with patch.object(resolver,'_extract',side_effect=extract), \
             patch.object(resolver,'RESOLVE_BUDGET',.02), patch.object(resolver,'CLIENTS',['ios','tv']):
            with self.assertRaises(resolver.HTTPException) as error:
                await resolver._resolve_cached('abcdefghijk')
        self.assertEqual(error.exception.status_code,504)
        self.assertEqual(len(calls),1); self.assertFalse(resolver._neg)

    async def test_cancel_resolve_retains_actual_extraction_slot(self):
        started=threading.Event(); finish=threading.Event()
        def extract(vid,*args):
            started.set(); finish.wait(2); return data(vid)
        with patch.object(resolver,'_extract',side_effect=extract):
            task=asyncio.create_task(resolver._resolve_cached('abcdefghijk'))
            try:
                for _ in range(200):
                    if started.is_set(): break
                    await asyncio.sleep(.005)
                self.assertTrue(started.is_set())
                task.cancel()
                with self.assertRaises(asyncio.CancelledError): await task
                self.assertEqual(SCHEDULER.stats()['active'],'playback')
            finally: finish.set()
            for _ in range(200):
                if SCHEDULER.stats()['active'] is None: break
                await asyncio.sleep(.005)
        self.assertIsNone(SCHEDULER.stats()['active'])

    async def test_busy_does_not_become_negative_result(self):
        from zizi_scheduler import SchedulerBusy
        async def busy(*a,**kw): raise SchedulerBusy()
        with patch.object(resolver,'_extract_attempt',side_effect=busy):
            with self.assertRaises(resolver.HTTPException) as error:
                await resolver._resolve_cached('abcdefghijk')
        self.assertEqual(error.exception.status_code,429); self.assertFalse(resolver._neg)

    async def test_foreground_promotes_queued_prefetch(self):
        order=[]
        def extract(vid,*args): order.append(vid); return data(vid)
        held=SCHEDULER.acquire('match',1)
        with patch.object(resolver,'_extract',side_effect=extract):
            warm=asyncio.create_task(resolver._resolve_cached('abcdefghijk',False))
            for _ in range(100):
                if SCHEDULER.stats()['queued']: break
                await asyncio.sleep(.005)
            live=asyncio.create_task(resolver._resolve_cached('abcdefghijk',True))
            await asyncio.sleep(.01); held.close()
            await asyncio.wait_for(asyncio.gather(warm,live),2)
        self.assertEqual(order,['abcdefghijk'])
        self.assertFalse(resolver._fg_want)


if __name__=='__main__': unittest.main(verbosity=2)
