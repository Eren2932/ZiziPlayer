#!/usr/bin/env python3
"""Add Browse 1 to an exact Stage 2 server. Default is read-only --check.
Only zizi_catalog.py and zizi_browse.py are replaced; env, DBs, audio and
scheduler/resolver modules are never written. --apply interrupts music.
"""
import argparse
import ast
from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
from deploy_stage2 import digest, replace, service

ROOT = Path(__file__).resolve().parent.parent
MODULES = ('zizi_catalog.py', 'zizi_browse.py')


def validate_backup(backup):
    manifest = json.loads((backup / 'manifest.json').read_text())
    if set(manifest) != set(MODULES):
        raise RuntimeError('invalid browse backup manifest')
    for name, value in manifest.items():
        if value is not None and digest(backup / name) != value:
            raise RuntimeError('corrupt backup: ' + name)
    return manifest


def restore(dest, backup):
    manifest = validate_backup(backup)
    for name, value in manifest.items():
        if value is None:
            (dest / name).unlink(missing_ok=True)
        else:
            replace(backup / name, dest / name)


def validate_install(dest):
    known = json.loads((ROOT / 'tools/browse_base_hashes.json').read_text())
    for name in MODULES:
        ast.parse((ROOT / name).read_text(), filename=name)
        path = dest / name
        if path.is_symlink():
            raise RuntimeError('refusing symlink: ' + name)
        if not path.exists():
            if name == 'zizi_catalog.py':
                raise RuntimeError('Stage 2 is not installed')
        elif digest(path) not in known[name] + [digest(ROOT / name)]:
            raise RuntimeError('unknown server edit: ' + name)
    for name, checksum in known['unchanged'].items():
        if not (dest / name).is_file() or digest(dest / name) != checksum:
            raise RuntimeError('requires the tested Stage 2 module: ' + name)


def healthy(expect_browse):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(24):
        try:
            with opener.open('http://127.0.0.1:8080/health', timeout=1) as r:
                resolver = json.load(r)
            with opener.open('http://127.0.0.1:8080/catalog/health', timeout=1) as r:
                catalog = json.load(r)
            if (resolver.get('version') == '1.7-stage2' and
                    resolver.get('scheduler', {}).get('resolver_attached') and
                    catalog.get('ok') and (not expect_browse or catalog.get('browse_contract') == 1)):
                return True
        except (OSError, ValueError):
            pass
        time.sleep(.25)
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--apply', action='store_true')
    mode.add_argument('--rollback', type=Path)
    parser.add_argument('--dest', type=Path, default=Path('/opt/zizi'))
    args = parser.parse_args()
    dest = args.dest.resolve()
    if args.rollback:
        if os.geteuid() != 0:
            raise RuntimeError('rollback requires root')
        backup = args.rollback.resolve()
        if backup.parent != dest / 'browse-backups':
            raise RuntimeError('backup must be in dest/browse-backups')
        validate_backup(backup)  # before interrupting the service
        service('stop')
        try:
            restore(dest, backup)
        finally:
            service('start')
        if not healthy(False):
            raise RuntimeError('files restored, service health failed; inspect service locally')
        print('Rollback complete; env/databases unchanged')
        return 0
    validate_install(dest)
    wd = subprocess.check_output(['systemctl', 'show', 'zizi-resolver', '-p', 'WorkingDirectory', '--value'],
                                 text=True, timeout=5).strip()
    if Path(wd).resolve() != dest:
        raise RuntimeError('service WorkingDirectory differs from --dest')
    for test in ['test_browse.py', 'test_browse_deploy.py', 'test_probe_browse.py', 'test_catalog_wiring.py',
                 'test_stage2.py', 'test_resolver_stage2.py', 'smoke_stage2.py']:
        result = subprocess.run([sys.executable, str(ROOT / 'tools' / test)], cwd=ROOT,
                                capture_output=True, timeout=90)
        if result.returncode:
            raise RuntimeError(test + ' failed; run separately in the service venv')
        print('PASS ' + test, flush=True)
    if not args.apply:
        print('CHECK ONLY: no installed files, env or services changed. --apply interrupts music.')
        return 0
    if os.geteuid() != 0:
        raise RuntimeError('--apply requires root')
    backup = dest / 'browse-backups' / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + str(os.getpid()))
    backup.mkdir(parents=True, mode=0o700)
    manifest = {}
    for name in MODULES:
        path = dest / name
        manifest[name] = digest(path) if path.exists() else None
        if path.exists():
            replace(path, backup / name)
    (backup / 'manifest.json').write_text(json.dumps(manifest))
    print('Backup: ' + str(backup), flush=True)
    service('stop')
    try:
        for name in MODULES:
            replace(ROOT / name, dest / name)
        service('start')
        if not healthy(True):
            raise RuntimeError('Browse health failed')
    except Exception:
        service('stop')
        try:
            restore(dest, backup)
        finally:
            service('start')
        print('Automatic rollback health: ' + str(healthy(False)), flush=True)
        raise
    print('Browse 1 installed. Resolver/scheduler/env/databases unchanged. Extra setting unchanged.')
    print('Rollback: ' + sys.executable + ' ' + str(Path(__file__).resolve()) + ' --rollback ' + str(backup))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
