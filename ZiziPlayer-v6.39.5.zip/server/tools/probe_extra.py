#!/usr/bin/env python3
"""Explicit live metadata probe for a QUIET VPS, no service install/restart.

Requires an already installed yt-dlp. Does not install packages, read zizi.env,
use cookies, download audio, or write production databases. Its in-process
semaphore does NOT coordinate with a running resolver: run only when idle.
"""
import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from zizi_extra import ExtraCatalog, ExtraError, bounded_run
from zizi_guard import ExtractGate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument('--query')
    target.add_argument('--playlist-id')
    parser.add_argument('--run-live', action='store_true', help='Allow one live request on an idle VPS')
    args = parser.parse_args()
    if not args.run_live:
        parser.error('Live probe requires --run-live; use only while the VPS is idle')
    report = {'probe': 'extra-stage2', 'network': 'live', 'production_modified': False}
    try:
        report['yt_dlp_version'] = bounded_run(['yt-dlp', '--ignore-config', '--version'], timeout=4).strip()[:80]
        with tempfile.TemporaryDirectory(prefix='zizi-extra-probe-') as tmp:
            service = ExtraCatalog(tmp + '/extra.db', ExtractGate(1, 0), enabled=lambda: True)
            call = (lambda: service.search(args.query, 5)) if args.query else (
                lambda: service.playlist(args.playlist_id, 5, 0))
            rows = []
            for label in ['cold', 'warm']:
                start = time.monotonic()
                page = call()
                rows.append({'phase': label, 'ms': round((time.monotonic()-start)*1000),
                             'cached': page['cached'], 'count': len(page['items']),
                             'items': page['items']})
            report.update(ok=True, results=rows, stats=service.stats())
    except ExtraError as e:
        report.update(ok=False, status=e.status, reason=e.reason, retry_after=e.retry)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
