#!/usr/bin/env python3
"""Синтаксис всех .py сервера. Аналог check_kotlin_syntax.py, только настоящий: у Python
есть ast, поэтому здесь нет ни одной эвристики и ни одного шанса на ложное срабатывание."""
import ast
import glob
import os
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "server"
files = sorted(glob.glob(os.path.join(root, "**", "*.py"), recursive=True))
bad = 0
for f in files:
    try:
        ast.parse(open(f, encoding="utf-8").read(), filename=f)
    except SyntaxError as e:
        print(f"::error file={f},line={e.lineno}::{e.msg}")
        bad += 1
print(f"проверено файлов: {len(files)}, ошибок: {bad}")
sys.exit(1 if bad else 0)
