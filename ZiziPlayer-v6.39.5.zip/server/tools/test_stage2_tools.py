#!/usr/bin/env python3
"""Real local HTTP for the latency probe, and real files for backup restoration.
Does not invoke systemctl or test actual production deployment.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import deploy_stage2 as deploy


class ToolTests(unittest.TestCase):
    def test_restore_original_and_remove_new_modules(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); dest=root/'dest'; backup=root/'backup'; dest.mkdir(); backup.mkdir()
            manifest={name:None for name in deploy.MODULES}
            for name in deploy.MODULES: (dest/name).write_text('new')
            for name in deploy.MODULES[:3]:
                (backup/name).write_text('old '+name); manifest[name]=deploy.digest(backup/name)
            (backup/'manifest.json').write_text(json.dumps(manifest))
            deploy.restore(dest,backup)
            for name in deploy.MODULES[:3]: self.assertEqual((dest/name).read_text(),'old '+name)
            for name in deploy.MODULES[3:]: self.assertFalse((dest/name).exists())

    def test_corrupt_backup_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); dest=root/'dest'; backup=root/'backup'; dest.mkdir(); backup.mkdir()
            manifest={name:None for name in deploy.MODULES}
            manifest[deploy.MODULES[0]]='bad'; (backup/deploy.MODULES[0]).write_text('corrupt')
            (backup/'manifest.json').write_text(json.dumps(manifest))
            with self.assertRaises(RuntimeError): deploy.restore(dest,backup)

    def test_atomic_replace(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=Path(tmp)/'a'; b=Path(tmp)/'b'; a.write_text('new'); b.write_text('old')
            deploy.replace(a,b)
            self.assertEqual(b.read_text(),'new'); self.assertEqual(a.read_text(),'new')

    def test_probe_refuses_nonloopback_before_reading_token(self):
        result=subprocess.run([sys.executable,str(HERE/'probe_playback.py'),'--video-id','abcdefghijk',
                               '--base','http://example.com','--run-live'],capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0); self.assertIn('loopback',result.stderr)

    def test_probe_real_local_http_and_redaction(self):
        requests=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self):
                requests.append((self.path,self.headers.get('Authorization'),self.headers.get('Range')))
                if self.path.startswith('/auth/device'):
                    body={'token':'fixture-device-token'}
                elif self.path.startswith('/match/deezer'):
                    body={'vid':'abcdefghijk','cached':False}
                elif self.path.startswith('/resolve'):
                    body={'url':'https://signed.invalid/SECRET-URL','cached':True}
                elif self.path.startswith('/stream'):
                    self.send_response(206); self.end_headers(); self.wfile.write(b'audio'); return
                elif self.path.startswith('/health'):
                    body={'version':'fixture','scheduler':{'slots':1}}
                else: body={'items':[],'cached':False}
                self.send_response(200); self.end_headers(); self.wfile.write(json.dumps(body).encode())
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever); thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                env=Path(tmp)/'test.env'; env.write_text('ZIZI_TOKEN=fixture-bootstrap-token\n')
                result=subprocess.run([sys.executable,str(HERE/'probe_playback.py'),
                    '--deezer-id','123','--base','http://127.0.0.1:'+str(server.server_port),
                    '--env-file',str(env),'--run-live'],capture_output=True,text=True,timeout=10)
                self.assertEqual(result.returncode,0,result.stderr)
                report=json.loads(result.stdout); self.assertTrue(report['ok'])
                self.assertEqual(len(report['rows']),2)
                for value in ['fixture-bootstrap-token','fixture-device-token','SECRET-URL']:
                    self.assertNotIn(value,result.stdout+result.stderr)
                self.assertTrue(any(r[2]=='bytes=0-65535' for r in requests))
                self.assertFalse(any('token=' in r[0] for r in requests))
                self.assertEqual(requests[0][1],'Bearer fixture-bootstrap-token')
        finally:
            server.shutdown(); thread.join(2); server.server_close()


if __name__=='__main__': unittest.main(verbosity=2)
