"""Conservative title-version ranking; channel identity is never artist identity."""
import re
import unicodedata


def normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text or '').casefold().split())


def version_tags(text):
    text = normalized(text)
    tags = set()
    if re.search(r'\bultra[\s_-]*slow(?:ed)?\b', text):
        tags.add('ultra_slowed')
    elif re.search(r'\bsuper[\s_-]*slow(?:ed)?\b', text):
        tags.add('super_slowed')
    elif re.search(r'\bslow(?:ed)?\b', text):
        tags.add('slowed')
    if re.search(r'\b(?:sped[\s_-]*up|speed[\s_-]*up|nightcore)\b', text):
        tags.add('sped_up')
    for tag, pattern in [('reverb', r'\breverb\b'), ('remix', r'\b(?:remix|bootleg)\b'),
                         ('live', r'\b(?:live|concert)\b'), ('cover', r'\b(?:cover|karaoke)\b')]:
        if re.search(pattern, text):
            tags.add(tag)
    return tags


def rank_tracks(items, query):
    want = version_tags(query)
    def key(item):
        got = version_tags(item['title'])
        speed = {'super_slowed', 'ultra_slowed', 'slowed', 'sped_up'}
        speed_match = (want & speed) == (got & speed)
        return (not speed_match, len(want ^ got))
    # Stable sort: no fabricated duration reference or uploader popularity.
    result = []
    for item in sorted(items, key=key):
        got = version_tags(item['title'])
        result.append(dict(item, version_tags=sorted(got),
                           version_match='exact' if got == want else 'different'))
    return result
