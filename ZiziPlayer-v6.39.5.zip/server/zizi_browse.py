"""Typed metadata browsing. No extractors, playback calls, credentials or new database.
Routes are installed on the EXISTING guarded router. Provider is always Deezer;
a Spotify ID must never enter /match/deezer through this contract.
"""
from fastapi import HTTPException, Query

CONTRACT = 1
KINDS = ('track', 'artist', 'album', 'playlist')


def _text(value):
    return value if isinstance(value, str) else ''


def _image(row, artist=False):
    prefix = 'picture' if artist else 'cover'
    # Playlists use picture_*, albums use cover_*.
    return next((_text(row.get(key)) for key in
                 (prefix + '_xl', prefix + '_big', 'picture_xl', 'picture_big', prefix)
                 if _text(row.get(key))), None)


def group(row, kind):
    owner = row.get('artist') if kind == 'album' else row.get('user')
    return {'id': str(row['id']), 'kind': kind,
            'title': _text(row.get('name') if kind == 'artist' else row.get('title')),
            'subtitle': _text((owner or {}).get('name')),
            'art': _image(row, kind == 'artist')}


def page_result(rows, upstream, offset, limit):
    # Trust next as a presence flag only; never follow an upstream URL.
    return {'contract': CONTRACT, 'src': 'deezer', 'items': rows,
            'next_offset': offset + limit if upstream.get('next') and rows else None,
            'total': upstream.get('total') if type(upstream.get('total')) is int else None}


def install_routes(router, dz_get, dz_track):
    def track(row):
        result = dz_track(row)
        result['kind'] = 'track'
        result['explicit'] = bool(row.get('explicit_lyrics', False))
        return result

    @router.get('/catalog/browse')
    def browse(q: str, kind: str = 'track', limit: int = Query(25, ge=1, le=50),
               offset: int = Query(0, ge=0, le=10000)):
        if kind not in KINDS:
            raise HTTPException(422, 'unsupported browse kind')
        if not q.strip() or len(q) > 300:
            raise HTTPException(422, 'query must contain 1..300 characters')
        endpoint = 'search' if kind == 'track' else 'search/' + kind
        upstream = dz_get(endpoint, q=q.strip(), limit=limit, index=offset)
        rows = [track(row) if kind == 'track' else group(row, kind)
                for row in upstream.get('data', []) if isinstance(row, dict) and row.get('id')]
        return page_result(rows, upstream, offset, limit)

    @router.get('/catalog/browse/collection')
    def collection(id: str, kind: str, limit: int = Query(50, ge=1, le=100),
                   offset: int = Query(0, ge=0, le=10000)):
        if kind not in ('artist', 'album', 'playlist') or not id.isascii() or not id.isdigit():
            raise HTTPException(422, 'invalid collection identity')
        # Metadata is independent of audio. An empty collection still has its own cover.
        metadata = dz_get(kind + '/' + id)
        endpoint = kind + '/' + id + ('/top' if kind == 'artist' else '/tracks')
        upstream = dz_get(endpoint, limit=limit, index=offset)
        rows = []
        for row in upstream.get('data', []):
            if not isinstance(row, dict) or not row.get('id'):
                continue
            item = track(row)
            if kind == 'album':
                item['art'] = item.get('art') or _image(metadata)
                item['album'] = item.get('album') or _text(metadata.get('title'))
            rows.append(item)
        result = page_result(rows, upstream, offset, limit)
        result['collection'] = group(metadata, kind)
        return result
