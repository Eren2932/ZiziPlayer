#!/usr/bin/env bash
# zizi-watch.sh — глаза на гео-плечо и на долю отказов. Закрывает п. 4.3 / чек-лист 9 ревью 6.37.0.
#
# ЗАЧЕМ ИМЕННО ТАК
#   Единственный узел VLESS с GL=DE — единственная точка отказа на всех пользователей сразу.
#   Отключат узел, и симптом у человека будет не «нет гео», а «музыка перестала играть».
#   По твоему же замеру новый узел находится за 8 минут — вся цена вопроса в том, чтобы
#   узнать об этом от сервера, а не из сообщения «опять не работает».
#
# ПОЧЕМУ ЕСТЬ ФАЙЛ СОСТОЯНИЯ
#   Крон раз в 10 минут при мёртвом узле — это 144 одинаковых сообщения в сутки, то есть
#   выключенные уведомления через день. Пишем ТОЛЬКО на смене состояния (ok -> bad, bad -> ok)
#   и напоминаем раз в ZIZI_WATCH_REMIND_H часов, пока не вылечено.
#
# УСТАНОВКА
#   install -m 755 zizi-watch.sh /opt/zizi/zizi-watch.sh
#   # в /opt/zizi/zizi.env (те же переменные читает и сервис):
#   #   ZIZI_TG_TOKEN=123456:AA...
#   #   ZIZI_TG_CHAT=123456789
#   # ZIZI_ADMIN_TOKEN нужен для /geo и /stats, если он у тебя задан; иначе берётся ZIZI_TOKEN.
#   ( crontab -l 2>/dev/null; echo '*/10 * * * * /opt/zizi/zizi-watch.sh >>/var/log/zizi-watch.log 2>&1' ) | crontab -
#   /opt/zizi/zizi-watch.sh --test    # разовая проверка: печатает вердикт и шлёт тестовое сообщение
set -uo pipefail

ENV_FILE=${ZIZI_ENV:-/opt/zizi/zizi.env}
BASE=${ZIZI_BASE:-http://127.0.0.1:8080}
STATE=${ZIZI_WATCH_STATE:-/opt/zizi/watch.state}
REMIND_H=${ZIZI_WATCH_REMIND_H:-6}
FAIL_PCT_MAX=${ZIZI_WATCH_FAIL_PCT:-25}
TEST=0
[ "${1:-}" = "--test" ] && TEST=1

# zizi.env — это systemd EnvironmentFile: строки KEY=VALUE без export. Читаем его сами,
# построчно, без source: одна кавычка в токене положила бы весь скрипт.
if [ -r "$ENV_FILE" ]; then
  while IFS='=' read -r k v; do
    case "$k" in ''|\#*) continue;; esac
    v=${v%\"}; v=${v#\"}
    export "$k=$v" 2>/dev/null || true
  done < "$ENV_FILE"
fi

TOKEN=${ZIZI_ADMIN_TOKEN:-${ZIZI_TOKEN:-}}
TG_TOKEN=${ZIZI_TG_TOKEN:-}
TG_CHAT=${ZIZI_TG_CHAT:-}

ask() { # $1 = путь; отдаёт тело или пусто
  curl -fsS --max-time 25 -H "Authorization: Bearer $TOKEN" "$BASE$1" 2>/dev/null
}
jget() { python3 -c 'import json,sys
try: d=json.load(sys.stdin)
except Exception: sys.exit(1)
for k in sys.argv[1].split("."):
    if not isinstance(d,dict) or k not in d: sys.exit(1)
    d=d[k]
print(d)' "$1" 2>/dev/null; }

notify() { # $1 = текст
  echo "$(date '+%F %T') $1"
  [ -n "$TG_TOKEN" ] && [ -n "$TG_CHAT" ] || { echo "(telegram не настроен: ZIZI_TG_TOKEN/ZIZI_TG_CHAT)"; return; }
  curl -fsS --max-time 15 -X POST \
    "https://api.telegram.org/bot$TG_TOKEN/sendMessage" \
    --data-urlencode "chat_id=$TG_CHAT" \
    --data-urlencode "text=$1" >/dev/null || echo "(отправка в telegram не удалась)"
}

problems=""
add() { problems="${problems}${problems:+$'\n'}• $1"; }

# 1. Сервис вообще жив? Если нет — остальные проверки бессмысленны, и это самая важная строка.
health=$(ask /health)
if [ -z "$health" ]; then
  add "резолвер не отвечает на $BASE/health (сервис лежит или порт закрыт)"
else
  # 2. Каталог смонтирован? Ровно та поломка, из-за которой 6.37.2 стоял с 404 на /catalog/*.
  chealth=$(curl -fsS --max-time 15 "$BASE/catalog/health" 2>/dev/null)
  if [ -z "$chealth" ]; then
    add "/catalog/health не отвечает — роутер каталога не подключён в zizi_resolver.py (include_router)"
  else
    cver=$(printf '%s' "$chealth" | jget version)
    anon=$(printf '%s' "$chealth" | jget guard.anon_pct)
    [ -n "$cver" ] && echo "каталог: версия $cver, анонимных ${anon:-?}%"
  fi

  # 3. Гео-плечо: паспорт от самого youtube.com, а не от ipinfo.
  geo=$(ask /geo)
  if [ -z "$geo" ]; then
    add "/geo не ответил (токен неверный или узел висит дольше таймаута)"
  else
    ok=$(printf '%s' "$geo" | jget geo_ok)
    gl=$(printf '%s' "$geo" | jget proxy.gl)
    if [ "$ok" != "True" ] && [ "$ok" != "true" ]; then
      add "гео-плечо мёртвое: GL=${gl:-нет} — гео-блоки не лечатся, ищи узел (server/tools/zizi-geoscan.py)"
    else
      echo "гео: GL=$gl, ok"
    fi
  fi

  # 4. Доля отказов резолва. Порог, а не факт отказа: одиночные промахи были всегда.
  stats=$(ask /stats)
  if [ -n "$stats" ]; then
    fail=$(printf '%s' "$stats" | jget share_failed_pct)
    cnt=$(printf '%s' "$stats" | jget resolve_count)
    if [ -n "$fail" ] && [ "${cnt:-0}" -ge 20 ] 2>/dev/null; then
      if python3 -c "import sys;sys.exit(0 if float('$fail')>float('$FAIL_PCT_MAX') else 1)"; then
        add "доля отказов резолва ${fail}% при пороге ${FAIL_PCT_MAX}% (замеров: $cnt)"
      else
        echo "отказы: ${fail}% из $cnt — в норме"
      fi
    fi
  fi
fi

now=$(date +%s)
prev_state=bad; prev_at=0
if [ -r "$STATE" ]; then read -r prev_state prev_at < "$STATE" 2>/dev/null || true; fi
[ -z "${prev_at:-}" ] && prev_at=0

if [ -n "$problems" ]; then
  state=bad
  since=$(( (now - prev_at) / 3600 ))
  if [ "$prev_state" != "bad" ] || [ "$since" -ge "$REMIND_H" ]; then
    notify "ZiziPlayer — сервер требует внимания:
$problems

host: $(hostname), $BASE, $(date '+%F %T %Z')"
    prev_at=$now
  else
    echo "$(date '+%F %T') проблема та же, напоминание через $(( REMIND_H - since )) ч"
  fi
else
  state=ok
  if [ "$prev_state" = bad ]; then
    notify "ZiziPlayer — всё вернулось в норму: резолвер отвечает, каталог смонтирован, гео чистое.
host: $(hostname), $(date '+%F %T %Z')"
  fi
  prev_at=$now
fi

echo "$state $prev_at" > "$STATE" 2>/dev/null || true
[ "$TEST" = 1 ] && notify "ZiziPlayer — тестовое сообщение zizi-watch.sh, канал работает."
[ "$state" = ok ] || exit 2
exit 0
