"""
zizi_catalog.py — слой каталога для ZiziPlayer.
Метаданные: Spotify (плейлисты/поиск) + Deezer (безключевой запасной).
Звук: НЕ ТРОГАЕМ. Модуль отдаёт youtube_id, дальше работает старый /resolve + /stream.

Ставится рядом с zizi_resolver.py:
    from zizi_catalog import router as catalog_router
    app.include_router(catalog_router)

Переменные окружения (в /opt/zizi/zizi.env):
    ZIZI_SP_ID=...            # Spotify Client ID     (необязательно, без него работает Deezer)
    ZIZI_SP_SECRET=...        # Spotify Client Secret
    ZIZI_CATALOG_DB=/opt/zizi/catalog.db
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
import sqlite3
import subprocess
import time
import json
import threading
from typing import Optional

import requests
from concurrent.futures import ThreadPoolExecutor
from zizi_scheduler import SCHEDULER, SchedulerBusy
from zizi_process import run_text, ProcessError
from zizi_versions import version_tags, normalized
from fastapi import (APIRouter, BackgroundTasks, Depends, Header, HTTPException, Query,
                     Request, Response)

# 1.7. Граница «клиент -> каталог». Импорт жёсткий и это намеренно: если zizi_guard.py не
# доехал на VPS, сервис обязан не подняться. Мягкий импорт с молчаливым отключением защиты —
# это ровно патология «написано, но не подключено», из-за которой каталог и стоял открытым.
from zizi_guard import (ExtractBusy, Guard, device_mode, device_ttl, issue_device_token)

_guard = Guard()


def guard_dep(request: Request,
              authorization: Optional[str] = Header(None),
              x_zizi_install: Optional[str] = Header(None)) -> None:
    """Проверка на входе КАЖДОГО роута этого модуля.

    Повешена на сам APIRouter, а не расставлена по эндпоинтам руками. Причина ровно та же,
    по которой мы здесь оказались: список из одиннадцати роутов, который надо не забыть
    дополнить при добавлении двенадцатого, — это не защита, а обещание не ошибиться.
    Новый роут закрыт по умолчанию; исключения перечислены в zizi_guard.OPEN_PATHS.
    """
    d = _guard.admit(
        path=request.url.path,
        authorization=authorization,
        q_token=request.query_params.get("token"),
        # Обложки грузит картиночный загрузчик, который своих заголовков не ставит: там
        # installId приезжает параметром `i`. Заголовок всё равно главнее параметра.
        install_id=x_zizi_install or request.query_params.get("i"),
        client_ip=request.client.host if request.client else None,
    )
    if not d.allowed:
        headers = {"Retry-After": str(d.retry_after)} if d.retry_after else None
        raise HTTPException(d.status, d.reason, headers=headers)


router = APIRouter(dependencies=[Depends(guard_dep)])

# Видно в /catalog/health. Без него нельзя отличить «файл залит» от «сервис не перезапущен» —
# ровно та неопределённость, которая стоила нам целого релиза 6.36.0.
VERSION = "1.9-stage2"

SP_ID = os.getenv("ZIZI_SP_ID", "")
SP_SECRET = os.getenv("ZIZI_SP_SECRET", "")
DB_PATH = os.getenv("ZIZI_CATALOG_DB", "/opt/zizi/catalog.db")
IMG_DIR = os.getenv("ZIZI_IMG_DIR", "/opt/zizi/img")
IMG_QUOTA = int(os.getenv("ZIZI_IMG_QUOTA_MB", "512")) * 1024 * 1024
IMG_MAX = 3 * 1024 * 1024
UA = "Mozilla/5.0 (Linux; Android 13) ZiziPlayer/7.0"

# Optional isolated contract: never feed YouTube IDs into the old Deezer route.
from zizi_extra import ExtraCatalog, ExtraError
_extra = ExtraCatalog(os.getenv("ZIZI_EXTRA_DB", DB_PATH + ".extra"), _guard.gate)

_db_lock = threading.Lock()


# ---------------------------------------------------------------- база сопоставлений

def _db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    con.execute(
        """CREATE TABLE IF NOT EXISTS match (
               key   TEXT PRIMARY KEY,   -- isrc, либо 'q:artist - title'
               vid   TEXT NOT NULL,
               score REAL,
               ts    INTEGER
           )"""
    )
    # 1.6 — отрицательный кэш.
    #
    # До 1.6 «не нашли» не запоминалось нигде. Один и тот же трек, по которому охота провалилась,
    # запускал три процесса yt-dlp КАЖДЫЙ раз, когда по нему тапнули. Для клиента это выглядит как
    # «трек думает минуту и скипается», и цена платится заново при каждом нажатии, хотя ответ уже
    # известен. Промах живёт [MISS_TTL] и стоит один SELECT.
    con.execute(
        """CREATE TABLE IF NOT EXISTS miss (
               key  TEXT PRIMARY KEY,
               ts   INTEGER,
               why  TEXT
           )"""
    )
    return con


def cache_get(key: str) -> Optional[str]:
    with _db_lock, _db() as con:
        row = con.execute("SELECT vid FROM match WHERE key=?", (key,)).fetchone()
    return row[0] if row else None


def cache_put(key: str, vid: str, score: float) -> None:
    with _db_lock, _db() as con:
        con.execute(
            "INSERT OR REPLACE INTO match(key,vid,score,ts) VALUES(?,?,?,?)",
            (key, vid, score, int(time.time())),
        )


MISS_TTL = int(os.getenv("ZIZI_MISS_TTL", "21600"))  # 6 часов


def miss_get(key: str) -> Optional[str]:
    with _db_lock, _db() as con:
        row = con.execute("SELECT ts, why FROM miss WHERE key=?", (key,)).fetchone()
    if not row:
        return None
    if time.time() - (row[0] or 0) > MISS_TTL:
        with _db_lock, _db() as con:
            con.execute("DELETE FROM miss WHERE key=?", (key,))
        return None
    return row[1] or "no confident match"


def miss_put(key: str, why: str) -> None:
    with _db_lock, _db() as con:
        con.execute("INSERT OR REPLACE INTO miss(key,ts,why) VALUES(?,?,?)",
                    (key, int(time.time()), why[:200]))


# ---------------------------------------------------------------- Spotify (только метаданные)

_sp_tok = {"v": "", "exp": 0.0}


def sp_token() -> str:
    if not (SP_ID and SP_SECRET):
        raise HTTPException(501, "spotify credentials not configured")
    if _sp_tok["v"] and _sp_tok["exp"] > time.time() + 30:
        return _sp_tok["v"]
    basic = base64.b64encode(f"{SP_ID}:{SP_SECRET}".encode()).decode()
    r = requests.post(
        "https://accounts.spotify.com/api/token",
        data={"grant_type": "client_credentials"},
        headers={"Authorization": f"Basic {basic}"},
        timeout=12,
    )
    r.raise_for_status()
    j = r.json()
    _sp_tok["v"] = j["access_token"]
    _sp_tok["exp"] = time.time() + float(j.get("expires_in", 3600))
    return _sp_tok["v"]


def sp_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.spotify.com/v1/{path}",
        headers={"Authorization": f"Bearer {sp_token()}"},
        params=params,
        timeout=15,
    )
    if r.status_code == 429:
        raise HTTPException(429, f"spotify rate limit, retry after {r.headers.get('Retry-After','?')}s")
    r.raise_for_status()
    return r.json()


def sp_track(t: dict) -> dict:
    return {
        "src": "spotify",
        "id": t.get("id"),
        "isrc": (t.get("external_ids") or {}).get("isrc"),
        "title": t.get("name"),
        "artist": ", ".join(a["name"] for a in t.get("artists", [])),
        "album": (t.get("album") or {}).get("name"),
        "dur": int((t.get("duration_ms") or 0) / 1000),
        "art": next((i["url"] for i in ((t.get("album") or {}).get("images") or [])), None),
    }


# ---------------------------------------------------------------- Deezer (без ключа, запасной)

def dz_track(t: dict) -> dict:
    return {
        "src": "deezer",
        "id": str(t.get("id")),
        "isrc": t.get("isrc"),
        "title": t.get("title"),
        "artist": (t.get("artist") or {}).get("name"),
        "album": (t.get("album") or {}).get("title"),
        "dur": int(t.get("duration") or 0),
        "art": (t.get("album") or {}).get("cover_big"),
    }


def dz_get(path: str, **params) -> dict:
    r = requests.get(
        f"https://api.deezer.com/{path}",
        params=params,
        headers={"User-Agent": UA},
        timeout=15,
    )
    r.raise_for_status()
    j = r.json()
    if isinstance(j, dict) and "error" in j:
        e = j["error"]
        raise HTTPException(502, f"deezer: {e.get('type')} {e.get('message')}")
    return j


def dz_search(q: str, limit: int, offset: int = 0) -> list[dict]:
    j = dz_get("search", q=q, limit=limit, index=offset)
    return [dz_track(t) for t in j.get("data", [])]


# ---------------------------------------------------------------- сопоставление -> youtube_id

_PAREN = re.compile(r"\((?:official|lyric|audio|video|hd|mv)[^)]*\)", re.I)
_JUNK = re.compile(r"\b(official|video|audio|lyrics?|hd|4k|mv|remaster(ed)?)\b", re.I)


def _norm(s: str) -> str:
    s = _PAREN.sub(" ", s or "")
    s = _JUNK.sub(" ", s)
    return re.sub(r"[^\w\s]", " ", s.lower()).strip()


class MatchUnavailable(Exception):
    """Upstream/deadline failure is NOT a negative catalog result."""


def yt_search(query: str, n: int = 6, budget: float = 5.0, foreground: bool = True) -> list[dict]:
    deadline = time.monotonic() + budget
    cmd = ["yt-dlp", "--ignore-config", "--quiet", "--no-warnings", "--flat-playlist",
           "--skip-download", "--socket-timeout", "3", "--retries", "0",
           "--extractor-retries", "0", "--dump-json", "--", f"ytsearch{n}:{query}"]
    if not _guard.gate.acquire(timeout=min(_guard.gate.wait, max(0, budget))):
        raise ExtractBusy(_guard.gate.wait)
    try:
        try:
            lease = SCHEDULER.acquire('match' if foreground else 'match-prefetch',
                                      1 if foreground else 2,
                                      timeout=min(2, max(0, deadline-time.monotonic())) if foreground else 0)
        except SchedulerBusy:
            raise ExtractBusy(2) from None
        with lease:
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise MatchUnavailable('matching time budget exhausted')
            try:
                raw = run_text(cmd, timeout=remaining, cancel=lease.cancel)
            except ProcessError as e:
                if e.status == 429:
                    raise ExtractBusy(2) from None
                raise MatchUnavailable(e.reason) from None
    finally:
        _guard.gate.release()
    res = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            j = json.loads(line)
            if not isinstance(j, dict):
                raise ValueError()
            vid = j.get('id')
            if not isinstance(vid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
                continue
            duration = j.get('duration')
            res.append({'vid': vid, 'title': j.get('title') or '',
                        'uploader': j.get('uploader') or j.get('channel') or '',
                        'dur': int(duration) if type(duration) in (int, float)
                               and 0 <= duration <= 604800 else 0})
        except (ValueError, TypeError, OverflowError):
            raise MatchUnavailable('invalid matching metadata') from None
    return res


# 1.6. Пометки версии записи: «slowed», «sped up», «remix» и прочее.
#
# В 1.5 они штрафовались всегда, безусловно, -25 очков. Это верно ровно до тех пор, пока в каталоге
# ищут студийный оригинал. Половина живой выдачи Deezer — это записи, у которых пометка стоит В
# САМОМ НАЗВАНИИ: «BACHI BACHI (Slowed + Reverb)», «Verão Flow (Super Slowed)». Для них правильный
# кандидат на YouTube тоже замедленный, то есть 1.5 штрафовала именно тот ролик, который искала, и
# добивала его штрафом за длительность (замедленная версия на минуту длиннее оригинала). Отсюда
# «no confident match» на целом жанре — фонк в выдаче состоит из таких названий почти целиком.
#
# Правило простое и симметричное: сравниваются НАБОРЫ пометок у запроса и у кандидата. Совпали —
# плюс, разошлись — минус. Ни одной пометки ни там, ни там — как раньше.
_MARKERS = {
    "slowed": r"\b(slowed|slow(ed)? ?\+ ?reverb|super slowed)\b",
    "sped": r"\b(sped ?up|speed ?up|nightcore)\b",
    "remix": r"\b(remix|bootleg|flip|vip mix)\b",
    "live": r"\b(live|concert|acoustic session)\b",
    "cover": r"\b(cover|karaoke|instrumental)\b",
    "8d": r"\b(8d|bass boosted)\b",
}


def markers(text: str) -> set[str]:
    low = (text or "").lower()
    return {name for name, rx in _MARKERS.items() if re.search(rx, low)}


def score(cand: dict, title: str, artist: str, dur: int) -> float:
    """Длительность — главный критерий. Каналы '- Topic' это официальное аудио от лейбла."""
    want = version_tags(title)
    got = version_tags(cand["title"])
    # Замедленная/ускоренная версия ЗАКОННО отличается по длительности от того, что написано в
    # каталоге: Deezer знает свою запись, YouTube — свою, и это разные мастер-файлы. Требовать от
    # них совпадения в две секунды бессмысленно, поэтому для помеченных треков окно шире.
    stretched = bool(want & {"slowed", "super_slowed", "ultra_slowed", "sped_up"})
    s = 0.0
    speed = {"slowed", "super_slowed", "ultra_slowed", "sped_up"}
    if (want & speed) != (got & speed):
        return -1000.0  # not the requested recording, even if duration happens to match
    if dur and cand["dur"]:
        d = abs(cand["dur"] - dur)
        if stretched:
            if d <= 10:
                s += 45
            elif d <= 25:
                s += 30
            elif d <= 60:
                s += 5
            else:
                s -= 30
        else:
            if d <= 2:
                s += 50
            elif d <= 5:
                s += 35
            elif d <= 12:
                s += 10
            else:
                s -= 40          # не тот трек: лайв, ремикс, час музыки
    ct, nt, na = _norm(cand["title"]), _norm(title), _norm(artist)
    if nt and nt in ct:
        s += 25
    elif nt and ct:
        # Частичное совпадение по словам: название в каталоге и на YouTube редко совпадает
        # посимвольно («PHONK INSTINCT» против «DOGEDA - Phonk Instinct (Official)»).
        words = [w for w in nt.split() if len(w) > 2]
        if words:
            hit = sum(1 for w in words if w in ct) / len(words)
            s += 20 * hit
    if na and (na in ct or na in _norm(cand["uploader"])):
        s += 20
    if cand["uploader"].endswith("- Topic"):
        s += 30
    same = want & got
    only_cand = got - want
    only_want = want - got
    s += 12 * len(same)          # искали замедленную — нашли замедленную, это попадание
    s -= 25 * len(only_cand)     # искали оригинал — подсунули ремикс, это промах
    s -= 15 * len(only_want)     # искали замедленную — нашли оригинал, звучит не так
    if re.search(r"\b(lyric|lyrics|visualizer)\b", (cand["title"] or "").lower()):
        s -= 10          # перезалив: своя громкость, часто интро. Уступает Topic, но лучше чем ничего
    return s


class HuntResults(list):
    complete = True


def _hunt(title: str, artist: str, isrc: str, dur: int = 0, foreground: bool = True) -> list[dict]:
    """Sequential, bounded hunt. Do not spawn 3 contenders on one CPU.

    Stop early ONLY on strong title/artist/version/duration agreement; leave
    CONFIDENT/WEAK untouched. A partial failed hunt must not poison miss cache.
    """
    queries = [(f"{artist} {title}", 6), (f"{artist} - Topic {title}", 5)]
    if isrc:
        queries.append((f'"{isrc}"', 3))
    deadline = time.monotonic() + 10.0
    cands = HuntResults()
    busy = 0
    for query, n in queries:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            cands.complete = False
            break
        try:
            found = yt_search(query, n, budget=min(5.0, remaining), foreground=foreground)
            cands.extend(found)
            for c in found:
                title_words = set(_norm(title).split())
                cand_words = set(_norm(c['title']).split())
                if (dur and c['dur'] and abs(dur-c['dur']) <= 5
                        and title_words and title_words <= cand_words
                        and _norm(artist) and _norm(artist) in _norm(c['title'] + ' ' + c['uploader'])
                        and version_tags(title) == version_tags(c['title'])
                        and score(c, title, artist, dur) >= 70):
                    return cands
        except ExtractBusy:
            busy += 1
            cands.complete = False
        except MatchUnavailable:
            cands.complete = False
    if not cands and busy == len(queries):
        raise ExtractBusy(2)
    return cands


# Порог уверенности. 20 — как в 1.5: с таким счётом кандидат совпал по длительности и хотя бы
# по артисту. WEAK — то, что раньше выбрасывалось в 404: не идеально, но это лучший кандидат из
# найденных, и человеку нужнее «играет похожее», чем «трек молча скипнулся».
CONFIDENT = 20.0
WEAK = -5.0


def match_track(title: str, artist: str, dur: int, isrc: str = "", allow_weak: bool = True, foreground: bool = True) -> dict:
    # Old _norm removed parenthesized versions; separate versions must not share IDs.
    key = isrc or "q2:" + hashlib.sha256(json.dumps(
        [normalized(artist), normalized(title), dur], ensure_ascii=False).encode()).hexdigest()
    hit = cache_get(key)
    if hit:
        return {"vid": hit, "cached": True, "key": key}
    stale = miss_get(key)
    if stale:
        # Ответ известен и он отрицательный. Отдаём мгновенно, вместо трёх процессов yt-dlp.
        raise HTTPException(404, stale)

    try:
        cands = _hunt(title, artist, isrc, dur, foreground)
    except ExtractBusy as e:
        # 503 было бы враньём: сервис жив, он занят. 429 + Retry-After клиент уже умеет
        # обрабатывать, и, главное, в кэш промахов не попадает ничего.
        raise HTTPException(429, "extractor busy",
                            headers={"Retry-After": str(e.retry_after)})

    seen: set[str] = set()
    best, best_s = None, -1e9
    for c in cands:
        if not c["vid"] or c["vid"] in seen:
            continue
        seen.add(c["vid"])
        sc = score(c, title, artist, dur)
        if sc > best_s:
            best, best_s = c, sc

    threshold = WEAK if allow_weak else CONFIDENT
    if not best or best_s < threshold:
        if not getattr(cands, 'complete', True):
            raise HTTPException(503, "matching incomplete; retry later", headers={"Retry-After": "2"})
        miss_put(key, "no confident match")
        raise HTTPException(404, "no confident match")
    cache_put(key, best["vid"], best_s)
    return {"vid": best["vid"], "cached": False, "key": key, "score": best_s,
            "confident": best_s >= CONFIDENT,
            "picked": best["title"], "by": best["uploader"]}


# ---------------------------------------------------------------- эндпоинты

def _extra_call(fn, *args):
    try:
        return fn(*args)
    except ExtraError as e:
        raise HTTPException(e.status, e.reason,
                            headers={"Retry-After": str(e.retry)} if e.retry else None)


@router.get("/catalog/extra/search")
def catalog_extra_search(q: str, limit: int = Query(10, ge=1, le=20)):
    return _extra_call(_extra.search, q, limit)


@router.get("/catalog/extra/playlist")
def catalog_extra_playlist(id: str, limit: int = Query(20, ge=1, le=20),
                           offset: int = Query(0, ge=0, le=480)):
    return _extra_call(_extra.playlist, id, limit, offset)


@router.get("/catalog/search")
def catalog_search(q: str, limit: int = Query(20, le=50), offset: int = 0, src: str = "auto"):
    if src in ("spotify", "auto") and SP_ID:
        try:
            j = sp_get("search", q=q, type="track", limit=limit)
            return {"src": "spotify", "items": [sp_track(t) for t in j["tracks"]["items"]]}
        except HTTPException:
            if src == "spotify":
                raise
    return {"src": "deezer", "offset": offset, "items": dz_search(q, limit, offset)}


@router.get("/catalog/playlist")
def catalog_playlist(id: str, limit: int = Query(100, le=300), offset: int = 0,
                     src: str = "auto"):
    """Плейлист по id. Deezer — без ключей; Spotify — только если заданы ZIZI_SP_ID/SECRET."""
    if src == "spotify" or (src == "auto" and SP_ID and not id.isdigit()):
        j = sp_get(f"playlists/{id}/tracks", limit=min(limit, 100), offset=offset)
        items = [sp_track(it["track"]) for it in j.get("items", []) if it.get("track")]
        return {"src": "spotify", "total": j.get("total"), "offset": offset, "items": items}
    j = dz_get(f"playlist/{id}/tracks", limit=limit, index=offset)
    return {"src": "deezer", "total": j.get("total"), "offset": offset,
            "items": [dz_track(t) for t in j.get("data", [])]}


@router.get("/catalog/album")
def catalog_album(id: str):
    """Альбом Deezer целиком. У треков в этой выдаче нет isrc — сопоставление пойдёт по artist+title+dur."""
    j = dz_get(f"album/{id}")
    art = j.get("cover_big")
    items = []
    for t in (j.get("tracks") or {}).get("data", []):
        d = dz_track(t)
        d["album"] = j.get("title")
        d["art"] = d["art"] or art
        items.append(d)
    return {"src": "deezer", "album": j.get("title"),
            "artist": (j.get("artist") or {}).get("name"), "art": art, "items": items}


@router.get("/catalog/artist")
def catalog_artist(id: str, limit: int = Query(50, le=100)):
    """Топ-треки артиста — то, чем в Спотифае открывается страница исполнителя."""
    j = dz_get(f"artist/{id}/top", limit=limit)
    return {"src": "deezer", "items": [dz_track(t) for t in j.get("data", [])]}


@router.get("/catalog/chart")
def catalog_chart(limit: int = Query(50, le=100)):
    """Главный экран: чарт треков + подборка плейлистов. Ничего не требует."""
    j = dz_get("chart", limit=limit)
    return {
        "src": "deezer",
        "tracks": [dz_track(t) for t in (j.get("tracks") or {}).get("data", [])],
        "playlists": [
            {"id": str(p["id"]), "title": p.get("title"), "art": p.get("picture_big"),
             "n": p.get("nb_tracks")}
            for p in (j.get("playlists") or {}).get("data", [])
        ],
        "artists": [
            {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
            for a in (j.get("artists") or {}).get("data", [])
        ],
    }


@router.get("/catalog/similar")
def catalog_similar(id: str, limit: int = Query(30, le=100)):
    """«Похожие артисты» — основа радио и автоплея."""
    j = dz_get(f"artist/{id}/related", limit=limit)
    return {"src": "deezer", "items": [
        {"id": str(a["id"]), "name": a.get("name"), "art": a.get("picture_big")}
        for a in j.get("data", [])
    ]}


@router.get("/match")
def match(title: str, artist: str, dur: int = 0, isrc: str = ""):
    """Сердце гибрида: метаданные -> youtube_id. Дальше клиент идёт в /resolve?id=<vid>."""
    return match_track(title, artist, dur, isrc)


@router.get("/match/deezer")
def match_deezer(id: str):
    """Сопоставление по одному лишь id каталога.

    Клиент на этом этапе знает только remoteId, поэтому метаданные (и, главное, ISRC)
    добираем здесь: `track/{id}` отдаёт их всегда, в отличие от выдачи альбома и плейлиста.
    """
    d = dz_track(dz_get(f"track/{id}"))
    r = match_track(d["title"], d["artist"], d["dur"], d["isrc"] or "")
    r["meta"] = d
    return r


# Сколько сопоставлений греется одновременно. Ядро на VPS одно, и прогрев обязан уступать дорогу
# живому запросу: один работник и не более восьми принятых фоновых задач.
_warm_pool = ThreadPoolExecutor(max_workers=1)
_warm_pending = threading.BoundedSemaphore(8)
_warm_seen: dict[str, float] = {}
_warm_lock = threading.Lock()


def _warm_one(track_id: str) -> None:
    try:
        d = dz_track(dz_get(f"track/{track_id}"))
        match_track(d["title"], d["artist"], d["dur"], d["isrc"] or "", foreground=False)
    except Exception:
        # Прогрев молчит по определению: не удался — трек отрезолвится вживую, как раньше.
        pass


@router.get("/match/warm")
def match_warm(ids: str):
    """Сопоставить треки ЗАРАНЕЕ и ответить немедленно (1.6).

    Смысл в одной фразе: сопоставление должно происходить, пока человек читает список результатов,
    а не после того, как он нажал на трек. Приложение зовёт этот адрес сразу после отрисовки
    поиска; ответ приходит через миллисекунды, работа идёт в фоне, и к моменту тапа videoId уже
    лежит в SQLite.

    Дедупликация по пятиминутному окну: открытый и закрытый пять раз экран поиска не должен
    ставить в очередь один и тот же трек пять раз.
    """
    wanted = [x.strip() for x in (ids or "").split(",") if x.strip()][:5]
    now = time.time()
    fresh = []
    with _warm_lock:
        if len(_warm_seen) > 512:
            _warm_seen.clear()
        for t in wanted:
            if now - _warm_seen.get(t, 0.0) > 300:
                _warm_seen[t] = now
                fresh.append(t)
    queued = 0
    for t in fresh:
        if not _warm_pending.acquire(blocking=False):
            with _warm_lock:
                _warm_seen.pop(t, None)
            continue
        try:
            future = _warm_pool.submit(_warm_one, t)
        except BaseException:
            _warm_pending.release()
            raise
        future.add_done_callback(lambda _: _warm_pending.release())
        queued += 1
    return {"ok": True, "queued": queued}


# ---------------------------------------------------------------- обложки

# Только хосты каталогов, и по суффиксу домена, а не по вхождению подстроки: без этой проверки
# /img — открытый прокси наружу, и первый же чужой бот утащит канал VPS на что угодно.
IMG_HOSTS = (
    ".dzcdn.net", ".deezer.com",
    ".scdn.co", ".spotifycdn.com",
    ".ytimg.com", ".ggpht.com", ".googleusercontent.com",
)


def _img_allowed(url: str) -> bool:
    m = re.match(r"^https?://([^/:?#]+)", url or "")
    if not m:
        return False
    host = m.group(1).lower()
    return any(host == h.lstrip(".") or host.endswith(h) for h in IMG_HOSTS)


def _img_purge() -> None:
    """LRU по времени доступа. Считается только при переполнении, а не на каждой картинке."""
    try:
        files = []
        total = 0
        for name in os.listdir(IMG_DIR):
            path = os.path.join(IMG_DIR, name)
            try:
                st = os.stat(path)
            except FileNotFoundError:
                continue
            files.append((st.st_atime, st.st_size, path))
            total += st.st_size
        if total <= IMG_QUOTA:
            return
        files.sort()
        for _, size, path in files:
            try:
                os.remove(path)
            except OSError:
                pass
            total -= size
            if total <= IMG_QUOTA * 0.8:
                break
    except OSError:
        pass


@router.get("/img")
def img(u: str):
    """Обложка чужого CDN, забранная сервером и отданная с диска.

    Существует не ради экономии, а ради одной фразы: телефон не обращается к Google и к чужим
    CDN вообще. Пока картинки шли напрямую, «работает без VPN» означало «текст есть, обложек нет».

    Кэш на диске бессрочный: адрес обложки у Deezer и YouTube содержит идентификатор записи и
    меняется вместе с картинкой, поэтому протухнуть тут нечему.
    """
    if not _img_allowed(u):
        raise HTTPException(400, "host not allowed")
    os.makedirs(IMG_DIR, exist_ok=True)
    key = hashlib.sha1(u.encode("utf-8")).hexdigest()
    path = os.path.join(IMG_DIR, key)
    headers = {"Cache-Control": "public, max-age=2592000, immutable"}
    if os.path.exists(path):
        os.utime(path, None)          # отметка доступа для LRU
        with open(path, "rb") as f:
            return Response(f.read(), media_type="image/jpeg", headers=headers)

    try:
        r = requests.get(u, headers={"User-Agent": UA}, timeout=15, stream=True)
    except requests.RequestException as e:
        raise HTTPException(502, f"image fetch failed: {e}")
    if r.status_code != 200:
        raise HTTPException(r.status_code if r.status_code < 500 else 502, "image not available")

    body = b""
    for chunk in r.iter_content(64 * 1024):
        body += chunk
        if len(body) > IMG_MAX:
            raise HTTPException(413, "image too large")
    if not body:
        raise HTTPException(502, "empty image")

    # Через временный файл: два телефона, открывшие один чарт, пишут один и тот же путь, и без
    # этого один прочитал бы половину картинки другого.
    tmp = path + ".part"
    try:
        with open(tmp, "wb") as f:
            f.write(body)
        os.replace(tmp, path)
    except OSError:
        pass
    _img_purge()
    ctype = r.headers.get("Content-Type", "image/jpeg").split(";")[0].strip()
    if not ctype.startswith("image/"):
        ctype = "image/jpeg"
    return Response(body, media_type=ctype, headers=headers)


@router.get("/auth/device")
def auth_device(request: Request, x_zizi_install: Optional[str] = Header(None)):
    """Обмен бутстрап-токена из APK на короткоживущий ключ этого устройства (1.8).

    Роут закрыт бутстрап-токеном в ЛЮБОМ режиме (zizi_guard.TOKEN_REQUIRED) и стоит в самом
    узком классе квоты. Ключ подписан секретом, которого в APK нет; внутри него installId,
    поэтому дальше квота считается на устройство, а не на подделываемый заголовок.

    Сам installId сервер не хранит: ни в базе, ни в логах. Он нужен как единица учёта и как
    единица отзыва, а не как личность — по нему нельзя узнать ни устройство, ни человека.
    """
    install = (x_zizi_install or request.query_params.get("i") or "").strip()
    # Границы и алфавит: installId уезжает в подпись и в ключи квоты. Пускать туда произвольную
    # строку с телефона — это разрешить чужому клиенту раздувать память ключами по 4 КБ.
    if not (8 <= len(install) <= 64) or not re.fullmatch(r"[A-Za-z0-9._:-]+", install):
        raise HTTPException(400, "bad install id")
    token, ttl = issue_device_token(install)
    if not token:
        # Подписывать нечем: ZIZI_TOKEN и ZIZI_DEVICE_KEY оба пусты. Это конфигурация, а не
        # запрос, поэтому 503 и честный текст, а не 401 — иначе клиент будет ломиться в цикле.
        raise HTTPException(503, "device tokens disabled: ни ZIZI_TOKEN, ни ZIZI_DEVICE_KEY не заданы")
    return {"token": token, "expires_in": ttl, "install_id": install,
            "mode": device_mode(), "ttl_hours": round(device_ttl() / 3600.0, 1)}


@router.get("/catalog/health")
def catalog_health():
    with _db_lock, _db() as con:
        n = con.execute("SELECT COUNT(*) FROM match").fetchone()[0]
    try:
        cached_images = len(os.listdir(IMG_DIR))
    except OSError:
        cached_images = 0
    with _db_lock, _db() as con:
        misses = con.execute("SELECT COUNT(*) FROM miss").fetchone()[0]
    return {"ok": True, "version": VERSION, "browse_contract": 1, "spotify": bool(SP_ID), "deezer": True,
            "matches_cached": n, "misses_cached": misses, "images_cached": cached_images,
            # 1.7. Здесь смотрят, когда решают, пора ли переключать токен в require:
            # guard.anon_pct == 0 означает, что все живые клиенты уже присылают токен.
            # Без этой цифры переключение делается на глаз, то есть выключает сервис кому-то.
            "guard": _guard.stats(), "extra": _extra.stats(), "scheduler": SCHEDULER.stats()}

# 6.39: additive metadata-only routes; inherit this router's auth and rate limits.
from zizi_browse import install_routes as _install_browse_routes
_install_browse_routes(router, dz_get, dz_track)
