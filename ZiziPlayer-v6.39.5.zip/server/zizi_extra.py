"""Optional YouTube metadata; no audio URLs, cookies or Deezer matching.

One shared extraction slot per service process. Keep disabled until VPS acceptance.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import subprocess
import tempfile
import threading
import time
import unicodedata
from contextlib import closing
from urllib.parse import urlencode


class ExtraError(Exception):
    def __init__(self, status, reason, retry=0):
        super().__init__(reason)
        self.status, self.reason, self.retry = status, reason, retry


from zizi_scheduler import SCHEDULER, SchedulerBusy
from zizi_process import run_text, ProcessError
from zizi_versions import rank_tracks


def bounded_run(command, timeout=8.0, max_bytes=2 * 1024 * 1024, cancel=None):
    try:
        return run_text(command, timeout, max_bytes, cancel)
    except ProcessError as e:
        raise ExtraError(e.status, e.reason, 2 if e.status == 429 else 15) from None


def clean_query(q):
    if not isinstance(q, str) or len(q) > 200:
        raise ExtraError(422, 'query must contain 2..200 characters')
    if any(unicodedata.category(c).startswith('C') for c in q):
        raise ExtraError(422, 'query contains control characters')
    q = ' '.join(unicodedata.normalize('NFC', q).split())
    if len(q) < 2:
        raise ExtraError(422, 'query must contain 2..200 characters')
    return q


def validate_page(limit, offset):
    if type(limit) is not int or not 1 <= limit <= 20:
        raise ExtraError(422, 'limit must be 1..20')
    if type(offset) is not int or not 0 <= offset <= 480:
        raise ExtraError(422, 'offset must be 0..480')


def parse_tracks(raw, limit):
    """Conservative identity: deduplicate by video ID ONLY, not title.

    A channel is an uploader, not a verified performing artist. A long video
    stays a video, not a fabricated album. Skip live/unavailable entries.
    """
    result, seen = [], set()
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except (ValueError, TypeError):
            raise ExtraError(502, 'invalid extractor JSON', 15) from None
        if not isinstance(item, dict):
            raise ExtraError(502, 'invalid extractor entry', 15)
        vid = item.get('id')
        if not isinstance(vid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
            continue
        if vid in seen:
            continue
        if item.get('availability') not in (None, 'public', 'unlisted'):
            continue
        if item.get('live_status') in ('is_live', 'is_upcoming', 'post_live'):
            continue
        title = item.get('title')
        if not isinstance(title, str) or not title.strip():
            continue
        duration = item.get('duration')
        # bool is a number in Python, but not a duration.
        dur = int(duration) if type(duration) in (int, float) and 0 <= duration <= 604800 else None
        result.append({
            'src': 'youtube', 'provider': 'yt', 'id': vid,
            'title': title[:500], 'artist': None,
            'uploader': str(item.get('channel') or item.get('uploader') or '')[:200],
            'channel_id': str(item.get('channel_id') or '')[:100],
            'dur': dur, 'duration_known': dur is not None,
            'art': 'https://i.ytimg.com/vi/' + vid + '/hqdefault.jpg',
            'kind': 'video', 'availability': 'unverified',
        })
        seen.add(vid)
        if len(result) >= limit:
            break
    return result


class ExtraCatalog:
    """Singleflight via a single nonblocking work lock; no waiter pileup.

    Repeated in-flight requests get 429, not another subprocess. Positive
    cached pages live 6h, successful empty pages 5min. Failures are never
    written as empty results. A global 15s cooldown prevents failure storms.
    """
    def __init__(self, db_path, gate, runner=bounded_run, now=time.time,
                 executable='yt-dlp', enabled=None):
        self.db_path, self.gate, self.runner, self.now = db_path, gate, runner, now
        self.executable = executable
        self.enabled = enabled or (lambda: os.getenv('ZIZI_EXTRA_ENABLED', '0') == '1')
        self._work = threading.Lock()
        self._db_lock = threading.Lock()
        self._state_lock = threading.Lock()
        self._cooldown_until = 0
        self._counts = dict(hits=0, runs=0, busy=0, failures=0)

    def stats(self):
        with self._state_lock:
            return dict(self._counts, enabled=bool(self.enabled()),
                        contract=1, max_results=20, timeout_seconds=8,
                        playback_isolation=SCHEDULER.stats()['resolver_attached'],
                        scheduler=SCHEDULER.stats(), ranking_revision=2)

    def _count(self, name):
        with self._state_lock:
            self._counts[name] += 1

    def _connect(self):
        con = sqlite3.connect(self.db_path, timeout=1)
        con.execute('CREATE TABLE IF NOT EXISTS extra_pages '
                    '(key TEXT PRIMARY KEY, ts REAL NOT NULL, ttl INTEGER NOT NULL, body TEXT NOT NULL)')
        return con

    def _read(self, key):
        with self._db_lock, closing(self._connect()) as con:
            row = con.execute('SELECT ts, ttl, body FROM extra_pages WHERE key=?', (key,)).fetchone()
        if row and 0 <= self.now() - row[0] < row[1]:
            try:
                return json.loads(row[2])
            except ValueError:
                return None
        return None

    def _write(self, key, value):
        body = json.dumps(value, ensure_ascii=False)
        if len(body.encode('utf-8')) > 65536:
            raise ExtraError(502, 'metadata page too large', 15)
        now = self.now()
        with self._db_lock, closing(self._connect()) as con, con:
            con.execute('DELETE FROM extra_pages WHERE ts+ttl<=?', (now,))
            con.execute('INSERT OR REPLACE INTO extra_pages VALUES(?,?,?,?)',
                        (key, now, 21600 if value['items'] else 300, body))
            con.execute('DELETE FROM extra_pages WHERE key IN '
                        '(SELECT key FROM extra_pages ORDER BY ts DESC, key DESC LIMIT -1 OFFSET 256)')

    def search(self, q, limit=10):
        q = clean_query(q)
        validate_page(limit, 0)
        return self._page('search', q, limit, 0)

    def playlist(self, playlist_id, limit=20, offset=0):
        # Accept known public playlist IDs, never arbitrary URLs (SSRF).
        if not isinstance(playlist_id, str) or not re.fullmatch(r'(?:PL|OLAK5uy_)[A-Za-z0-9_-]{10,80}', playlist_id):
            raise ExtraError(422, 'expected a public YouTube playlist ID')
        validate_page(limit, offset)
        return self._page('playlist', playlist_id, limit, offset)

    def _page(self, kind, value, limit, offset):
        if not self.enabled():
            raise ExtraError(503, 'extra catalog disabled')
        key = hashlib.sha256(json.dumps([2, kind, value, limit, offset], ensure_ascii=False).encode()).hexdigest()
        try:
            cached = self._read(key)
        except sqlite3.Error:
            raise ExtraError(503, 'metadata cache unavailable', 15) from None
        if cached is not None:
            self._count('hits')
            return dict(cached, cached=True)
        if not self._work.acquire(blocking=False):
            self._count('busy')
            raise ExtraError(429, 'extra catalog busy', 2)
        try:
            # A preceding worker may have committed since our first read.
            cached = self._read(key)
            if cached is not None:
                self._count('hits')
                return dict(cached, cached=True)
            if self.now() < self._cooldown_until:
                raise ExtraError(503, 'extra catalog cooling down', 15)
            if not self.gate.acquire(timeout=0):
                self._count('busy')
                raise ExtraError(429, 'catalog extractor busy', 2)
            try:
                command = [self.executable, '--ignore-config', '--quiet', '--no-warnings',
                           '--flat-playlist', '--skip-download', '--socket-timeout', '4',
                           '--retries', '0', '--extractor-retries', '0',
                           '--playlist-start', str(offset + 1), '--playlist-end', str(offset + limit),
                           '--print', '%(.{id,title,channel,channel_id,uploader,duration,availability,live_status})j']
                target = f'ytsearch{limit}:{value}' if kind == 'search' else (
                    'https://www.youtube.com/playlist?' + urlencode({'list': value}))
                try:
                    lease = SCHEDULER.acquire('extra', 3, timeout=0)
                except SchedulerBusy:
                    self._count('busy')
                    raise ExtraError(429, 'playback/extractor busy', 2) from None
                with lease:
                    self._count('runs')
                    if self.runner is bounded_run:
                        raw = self.runner(command + ['--', target], timeout=8.0,
                                          cancel=lease.cancel)
                    else:
                        raw = self.runner(command + ['--', target], timeout=8.0)
                items = parse_tracks(raw, limit)
                if kind == 'search':
                    items = rank_tracks(items, value)
                page = {'contract': 1, 'src': 'youtube', 'kind': kind,
                        'items': items, 'offset': offset, 'requested_limit': limit,
                        'total': None, 'next_offset': None,
                        'pagination': 'manual' if kind == 'playlist' else 'none',
                        'cached': False}
                self._write(key, page)
                return page
            except ExtraError as e:
                if e.status == 429:
                    raise  # preemption/busy is not an upstream failure or cooldown
                self._count('failures')
                self._cooldown_until = self.now() + 15
                raise
            finally:
                self.gate.release()
        except sqlite3.Error:
            raise ExtraError(503, 'metadata cache unavailable', 15) from None
        finally:
            self._work.release()
