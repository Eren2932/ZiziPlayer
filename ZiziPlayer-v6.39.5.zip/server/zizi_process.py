"""Bounded, no-shell POSIX child runner. Kill process GROUP before releasing slot."""
import os
import signal
import subprocess
import tempfile
import time


class ProcessError(Exception):
    def __init__(self, status, reason):
        super().__init__(reason)
        self.status, self.reason = status, reason


def run_text(command, timeout=8.0, max_bytes=2*1024*1024, cancel=None):
    deadline = time.monotonic() + timeout
    with tempfile.TemporaryFile() as output:
        try:
            child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=output,
                                     stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError:
            raise ProcessError(503, 'extractor unavailable') from None
        try:
            while True:
                if cancel is not None and cancel.is_set():
                    raise ProcessError(429, 'search yielded to playback')
                if os.fstat(output.fileno()).st_size > max_bytes:
                    raise ProcessError(502, 'extractor output too large')
                if child.poll() is not None:
                    break
                if time.monotonic() >= deadline:
                    raise ProcessError(504, 'extractor timeout')
                time.sleep(.02)
            if child.returncode != 0:
                raise ProcessError(502, 'extractor failed')
            output.seek(0)
            try:
                return output.read(max_bytes).decode('utf-8', errors='strict')
            except UnicodeError:
                raise ProcessError(502, 'invalid extractor encoding') from None
        finally:
            # Also kill descendants after their leader exits: no orphaned Deno/child.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait()
