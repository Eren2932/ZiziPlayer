"""One extraction slot per service PROCESS; uvicorn --workers 1 is required.

Priority: playback (0), matching for playback (1), prefetch (2), extra catalog (3).
Only extra and matching-prefetch subprocesses are preemptible. Running YoutubeDL threads
are NOT killable: their lease is released by the worker, never by HTTP cancellation.
Does not isolate network/disk streaming or unrelated OS processes.
"""
import asyncio
import threading
import time
from contextlib import contextmanager


class SchedulerBusy(Exception):
    pass


class Lease:
    def __init__(self, scheduler, kind, cancel, priority):
        self.scheduler, self.kind, self.cancel = scheduler, kind, cancel
        self.priority = priority
        self.started = time.monotonic()
        self.closed = False

    def close(self):
        with self.scheduler._cv:
            if not self.closed:
                self.closed = True
                self.scheduler._active = None
                self.scheduler._cv.notify_all()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class ExtractionScheduler:
    def __init__(self, max_waiters=16):
        self._cv = threading.Condition()
        self._active = None
        self._queue = {}
        self._seq = 0
        self.max_waiters = max_waiters
        self._counts = dict(started=0, rejected=0, preemptions=0, wait_ms=0)
        self._resolver_attached = False
        self._tasks = set()

    def attach_resolver(self):
        with self._cv:
            self._resolver_attached = True

    def stats(self):
        with self._cv:
            a = self._active
            return dict(self._counts, slots=1, scope='service-process',
                        resolver_attached=self._resolver_attached,
                        active=a.kind if a else None, queued=len(self._queue),
                        active_ms=round((time.monotonic()-a.started)*1000) if a else 0)

    def foreground_pending(self):
        with self._cv:
            a = self._active
            return bool((a and (a.priority() if callable(a.priority) else a.priority) <= 1) or
                        any(self._priority(row) <= 1 for row in self._queue.values()))

    def _register(self, kind, priority):
        with self._cv:
            if len(self._queue) >= self.max_waiters:
                self._counts['rejected'] += 1
                raise SchedulerBusy('extraction queue full')
            self._seq += 1
            ticket = self._seq
            self._queue[ticket] = (kind, priority, time.monotonic())
            self._preempt()
            return ticket

    @staticmethod
    def _priority(row):
        value = row[1]
        return value() if callable(value) else value

    def _preempt(self):
        a = self._active
        if a and a.kind in ('extra', 'match-prefetch') and not a.cancel.is_set():
            if any(self._priority(row) <= 1 for row in self._queue.values()):
                a.cancel.set()
                self._counts['preemptions'] += 1

    def _take(self, ticket):
        with self._cv:
            self._preempt()
            best = min(self._queue, key=lambda t: (self._priority(self._queue[t]), t))
            if self._active is not None or best != ticket:
                return None
            kind, priority, start = self._queue.pop(ticket)
            lease = Lease(self, kind, threading.Event(), priority)
            self._active = lease
            self._counts['started'] += 1
            self._counts['wait_ms'] += round((time.monotonic()-start)*1000)
            return lease

    def _remove(self, ticket):
        with self._cv:
            self._queue.pop(ticket, None)
            self._cv.notify_all()

    def acquire(self, kind, priority, timeout=2.0):
        deadline = time.monotonic() + max(0, timeout)
        ticket = self._register(kind, priority)
        try:
            with self._cv:
                while True:
                    lease = self._take(ticket)
                    if lease:
                        return lease
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        self._counts['rejected'] += 1
                        raise SchedulerBusy('extractor busy')
                    self._cv.wait(min(.02, remaining))
        finally:
            self._remove(ticket)

    async def acquire_async(self, kind, priority, timeout=5.0):
        deadline = time.monotonic() + max(0, timeout)
        ticket = self._register(kind, priority)
        try:
            while True:
                lease = self._take(ticket)
                if lease:
                    return lease
                if time.monotonic() >= deadline:
                    with self._cv:
                        self._counts['rejected'] += 1
                    raise SchedulerBusy('extractor busy')
                await asyncio.sleep(.02)
        finally:
            self._remove(ticket)

    async def run_async(self, fn, *args, kind='playback', priority=0, timeout=5.0):
        lease = await self.acquire_async(kind, priority, timeout)
        def work():
            with lease:
                return fn(*args)
        # Shield the owner, not just a coroutine waiting on a thread. The worker
        # owns release even if the HTTP coroutine is cancelled multiple times.
        try:
            task = asyncio.create_task(asyncio.to_thread(work))
        except BaseException:
            lease.close()
            raise
        self._tasks.add(task)
        def done(t):
            self._tasks.discard(t)
            if not t.cancelled():
                t.exception()  # consume detached failures, never log signed URLs
        task.add_done_callback(done)
        return await asyncio.shield(task)


SCHEDULER = ExtractionScheduler()
