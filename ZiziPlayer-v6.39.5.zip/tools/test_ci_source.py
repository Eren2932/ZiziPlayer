import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

HERE = Path(__file__).parent
SELECTOR = (HERE/'select_ci_source.py').read_text()
WORKFLOW = (HERE.parent/'.github/workflows/build.yml').read_text()


def archive(root, name, code=71, unsafe=False, patch=False):
    with zipfile.ZipFile(root/name, 'w') as z:
        if patch:
            z.writestr('only-a-patch.txt', 'test')
            return
        z.writestr('settings.gradle.kts', 'rootProject.name = "test"')
        z.writestr('app/build.gradle.kts', f'    versionCode = {code}\n    versionName = "6.38.0-stage2"\n')
        if unsafe:
            z.writestr('../outside.txt', 'bad')


def select(root):
    return subprocess.run([sys.executable, '-c', SELECTOR], cwd=root,
                          env=dict(os.environ, GITHUB_ENV=str(root/'github-env')),
                          capture_output=True, text=True)


class WorkflowTests(unittest.TestCase):
    def test_uses_code_not_filename(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive(root, 'zzz-old.zip', 70)
            archive(root, 'stage2.zip', 71)
            r = select(root)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn('stage2.zip', r.stdout)

    def test_ambiguous_same_code_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive(root, 'stage2.zip')
            archive(root, 'stage2-new.zip')
            self.assertNotEqual(select(root).returncode, 0)
            self.assertFalse((root/'_src').exists())

    def test_skips_patch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive(root, 'patch.zip', patch=True)
            archive(root, 'project.zip')
            self.assertEqual(select(root).returncode, 0)

    def test_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive(root, 'bad.zip', unsafe=True)
            self.assertNotEqual(select(root).returncode, 0)
            self.assertFalse((root/'_src').exists())

    def test_embedded_selector_identical(self):
        block = WORKFLOW.split("          python3 - <<'PY_SOURCE'\n", 1)[1].split('          PY_SOURCE', 1)[0]
        extracted = ''.join(l[10:]+'\n' for l in block.splitlines())
        self.assertEqual(extracted, SELECTOR)

    def test_all_run_blocks_bash_syntax(self):
        lines = WORKFLOW.splitlines()
        scripts = []
        for i, line in enumerate(lines):
            if line == '        run: |':
                body = []
                for l in lines[i+1:]:
                    if l and not l.startswith('          '):
                        break
                    body.append(l[10:] if l else '')
                scripts.append('\n'.join(body))
        self.assertGreaterEqual(len(scripts), 8)
        for script in scripts:
            # Syntax check only; replace GitHub's expressions with an inert value.
            script = re.sub(r'\$\{\{.*?\}\}', 'fixture', script)
            r = subprocess.run(['bash', '-n'], input=script, text=True, capture_output=True)
            self.assertEqual(r.returncode, 0, r.stderr)
        for name in ('test_zizi_extra.py', 'test_stage2.py', 'test_resolver_stage2.py',
                     'test_stage2_tools.py', 'test_probe_contention.py'):
            self.assertIn('python3 server/tools/' + name, WORKFLOW)


if __name__ == '__main__':
    unittest.main(verbosity=2)
