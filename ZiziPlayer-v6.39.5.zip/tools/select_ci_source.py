import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import zipfile

candidates = []
for path in sorted(Path('.').glob('*.zip')):
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            settings = [n for n in names if PurePosixPath(n).name == 'settings.gradle.kts']
            if len(settings) != 1:
                print('Skip non-project or ambiguous ZIP:', path.name)
                continue
            parent = str(PurePosixPath(settings[0]).parent)
            prefix = '' if parent == '.' else parent + '/'
            gradle = prefix + 'app/build.gradle.kts'
            if gradle not in names:
                continue
            info = z.getinfo(gradle)
            if info.file_size > 100000:
                raise ValueError('oversized Gradle metadata')
            text = z.read(gradle).decode('utf-8')
            codes = re.findall(r'^\s*versionCode\s*=\s*([0-9]+)\s*$', text, re.M)
            versions = re.findall(r'^\s*versionName\s*=\s*"([A-Za-z0-9._+-]+)"\s*$', text, re.M)
            if len(codes) != 1 or len(versions) != 1:
                raise ValueError('ambiguous version metadata')
            candidates.append((int(codes[0]), path, prefix, versions[0]))
    except (OSError, ValueError, zipfile.BadZipFile):
        raise SystemExit('Invalid source ZIP: ' + path.name)
if not candidates:
    raise SystemExit('No full Gradle project ZIP found')
maximum = max(c[0] for c in candidates)
winners = [c for c in candidates if c[0] == maximum]
if len(winners) != 1:
    raise SystemExit('Multiple ZIPs with highest versionCode; keep one: ' + ', '.join(c[1].name for c in winners))
code, path, prefix, version = winners[0]
if any(c in str(path) + prefix for c in '\r\n'):
    raise SystemExit('Unsafe path')
with zipfile.ZipFile(path) as z:
    entries = z.infolist()
    if len(entries) > 10000 or sum(x.file_size for x in entries) > 100 * 1024 * 1024:
        raise SystemExit('Source archive exceeds extraction limits')
    if len(set(z.namelist())) != len(entries):
        raise SystemExit('Duplicate archive entries')
    for info in entries:
        n = PurePosixPath(info.filename)
        mode = info.external_attr >> 16
        if (n.is_absolute() or '..' in n.parts or '\\' in info.filename
                or any(c in info.filename for c in '\r\n') or stat.S_ISLNK(mode)):
            raise SystemExit('Unsafe archive entry')
    shutil.rmtree('_src', ignore_errors=True)
    Path('_src').mkdir()
    z.extractall('_src')
root = '_src/' + prefix.rstrip('/') if prefix else '_src'
with open(os.environ['GITHUB_ENV'], 'a') as out:
    out.write('PROJECT_ROOT=' + root + '\nAPP_VERSION=' + version + '\n')
print('Selected:', path.name, 'version:', version, 'versionCode:', code)
print('SHA256:', hashlib.sha256(path.read_bytes()).hexdigest())
