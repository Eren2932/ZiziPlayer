#!/usr/bin/env python3
"""Offline source-wiring checks, not Kotlin execution or an Android build."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app/src/main/java/app/ziziplayer'

class RemovalWiringTests(unittest.TestCase):
    def read(self, path):
        return (APP / path).read_text()

    def test_removed_provider_has_no_production_references(self):
        self.assertFalse((APP / 'data/remote/AudiusCatalog.kt').exists())
        for path in (ROOT / 'app/src/main').rglob('*'):
            if path.is_file():
                self.assertNotIn('audius', path.read_text(errors='ignore').lower(), str(path))

    def test_registry_only_registers_supported_parts(self):
        text = self.read('ZiziApplication.kt')
        self.assertIn('MixCatalog(listOf(deezer, innertube))', text)
        self.assertIn('val deezer = DeezerCatalog()', text)
        self.assertIn('val innertube = InnertubeCatalog(', text)

    def test_preferences_normalized_before_old_migration_exit(self):
        text = self.read('data/SettingsStore.kt')
        self.assertIn('catalogProvider = CatalogPolicy.preference(p[catalogKey])', text)
        migrate = text.split('suspend fun migrateCatalogDefault()', 1)[1]
        self.assertLess(migrate.index('CatalogPolicy.preference(stored)'),
                        migrate.index('if (p[catalogMigratedKey] == true)'))

    def test_old_hub_and_restored_collection_filtered(self):
        self.assertIn('private const val VERSION = 2', self.read('data/remote/HubCache.kt'))
        self.assertIn('CatalogPolicy.supports(provider, remoteId)', self.read('data/remote/HubCache.kt'))
        text = self.read('ui/SearchViewModel.kt')
        self.assertIn('CatalogPolicy.supports(parts[0], parts[1])', text)
        self.assertIn('entry.kind == RecentKind.QUERY || CatalogPolicy.supports(entry.provider, entry.remoteId)', text)

    def test_old_streams_fail_before_network_resolution(self):
        text = self.read('playback/StreamResolver.kt')
        self.assertLess(text.index('CatalogPolicy.supports(providerId, remoteId)'),
                        text.index('catalog.resolveStream(remoteId, quality)'))
        # Offline-first stays outside the network path; user downloads are not deleted.
        text = self.read('playback/ZiziDataSources.kt')
        self.assertIn('OfflineStore.playbackUri(context, dataSpec.uri)', text)

    def test_old_track_art_not_refetched(self):
        self.assertIn('if (!CatalogPolicy.supports(track.provider, track.remoteId)) return null',
                      self.read('ui/components/Artwork.kt'))
        self.assertIn('!CatalogPolicy.supports(t.provider, t.remoteId)) null',
                      self.read('playback/PlayerController.kt'))

    def test_server_no_removed_image_hosts(self):
        self.assertNotIn('audius', (ROOT / 'server/zizi_catalog.py').read_text().lower())

if __name__ == '__main__':
    unittest.main(verbosity=2)
