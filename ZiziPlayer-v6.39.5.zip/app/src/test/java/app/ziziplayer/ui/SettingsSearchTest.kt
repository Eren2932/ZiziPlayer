package app.ziziplayer.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsSearchTest {
    @Test fun emptyQueryMatches() { assertTrue(SettingsSearch.matches("  ", "Звук")) }
    @Test fun caseAndYoAreNormalized() { assertTrue(SettingsSearch.matches("ОТЧЕТ", "Отчёт о загрузках")) }
    @Test fun wordsCanAppearInDifferentOrder() { assertTrue(SettingsSearch.matches("память кэш", "Кэш потоков память")) }
    @Test fun allWordsMustMatch() { assertFalse(SettingsSearch.matches("звук папки", "звук эквалайзер")) }
    @Test fun whitespaceIsIgnored() { assertTrue(SettingsSearch.matches("  цвет   обложки ", "Цвет из обложки")) }
}
