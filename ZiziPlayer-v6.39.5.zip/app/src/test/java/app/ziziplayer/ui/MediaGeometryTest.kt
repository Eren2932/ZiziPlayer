package app.ziziplayer.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaGeometryTest {
    @Test fun referencePixelsMatch() {
        assertEquals(3, MediaGeometry.COLUMNS)
        assertEquals(45f, MediaGeometry.edge(1080f), 0.01f)
        assertEquals(300f, MediaGeometry.tile(1080f), 0.01f)
    }
    @Test fun threeTilesAndFourGapsFitTheParent() {
        listOf(280f, 320f, 360f, 411.43f, 480f, 600f, 840f).forEach { width ->
            assertTrue(MediaGeometry.tile(width) > 0f)
            assertEquals(width, MediaGeometry.tile(width) * 3 + MediaGeometry.edge(width) * 4, 0.01f)
        }
    }
    @Test fun zeroWidthIsSafe() {
        assertEquals(0f, MediaGeometry.tile(0f), 0f)
        assertEquals(0f, MediaGeometry.tile(-10f), 0f)
    }
}
