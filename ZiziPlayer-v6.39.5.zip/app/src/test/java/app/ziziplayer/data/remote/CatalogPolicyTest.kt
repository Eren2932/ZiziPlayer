package app.ziziplayer.data.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogPolicyTest {
    @Test fun oldPreferenceReturnsToMix() {
        assertEquals("mix", CatalogPolicy.preference("audius"))
        assertEquals("mix", CatalogPolicy.preference(null))
        assertEquals("mix", CatalogPolicy.preference("unknown"))
    }
    @Test fun supportedPreferencesArePreserved() {
        for (provider in listOf("mix", "dz", "yt")) {
            assertEquals(provider, CatalogPolicy.preference(provider))
        }
    }
    @Test fun directTracksAndCollectionsRemainSupported() {
        assertTrue(CatalogPolicy.supports("dz", "42"))
        assertTrue(CatalogPolicy.supports("dz", "artist:17"))
        assertTrue(CatalogPolicy.supports("yt", "UCexample"))
    }
    @Test fun mixedTracksAndCollectionsRemainSupported() {
        assertTrue(CatalogPolicy.supports("mix", "dz:42"))
        assertTrue(CatalogPolicy.supports("mix", "dz:artist:17"))
        assertTrue(CatalogPolicy.supports("mix", "yt:UCexample"))
    }
    @Test fun removedDirectAndMixedIdentitiesAreRejected() {
        assertFalse(CatalogPolicy.supports("audius", "old-id"))
        assertFalse(CatalogPolicy.supports("mix", "audius:old-id"))
    }
    @Test fun missingAndMalformedIdentitiesAreRejected() {
        assertFalse(CatalogPolicy.supports(null, "42"))
        assertFalse(CatalogPolicy.supports("dz", null))
        assertFalse(CatalogPolicy.supports("yt", " "))
        for (id in listOf("dz", "dz:", ":42", "mix:dz:42", "other:42")) {
            assertFalse(CatalogPolicy.supports("mix", id))
        }
    }
}
