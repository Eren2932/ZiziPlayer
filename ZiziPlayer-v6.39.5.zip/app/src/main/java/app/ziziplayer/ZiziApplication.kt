package app.ziziplayer

import android.app.Application
import androidx.room.Room
import app.ziziplayer.data.*
import app.ziziplayer.data.remote.CatalogRegistry
import app.ziziplayer.data.remote.DeezerCatalog
import app.ziziplayer.data.remote.InnertubeCatalog
import app.ziziplayer.data.remote.MixCatalog
import app.ziziplayer.data.remote.PoTokenMinter
import app.ziziplayer.data.remote.SessionWebToken
import app.ziziplayer.data.remote.ZiziInstall
import app.ziziplayer.data.remote.ZiziResolve
import app.ziziplayer.playback.DownloadTemp
import app.ziziplayer.playback.LegacyOfflineCache
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.RemoteRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class ZiziApplication : Application() {
    lateinit var database: ZiziDatabase; private set
    lateinit var repository: MusicRepository; private set
    lateinit var playerController: PlayerController; private set

    override fun onCreate() {
        super.onCreate()
        // Первым делом и до всего остального: обработчик падений не имеет права зависеть от
        // того, успела ли подняться база, резолвер или плеер.
        CrashLog.install(this)
        // No destructive fallback: a schema change must never wipe playlists, favourites and FX.
        database = Room.databaseBuilder(this, ZiziDatabase::class.java, "zizi.db")
            .addMigrations(
                ZiziDatabase.MIGRATION_1_2,
                ZiziDatabase.MIGRATION_2_3,
                ZiziDatabase.MIGRATION_3_4,
                ZiziDatabase.MIGRATION_4_5,
                ZiziDatabase.MIGRATION_5_6,
                ZiziDatabase.MIGRATION_6_7,
                ZiziDatabase.MIGRATION_7_8,
                ZiziDatabase.MIGRATION_8_9
            )
            .build()
        val settings = SettingsStore(this)
        repository = MusicRepository(
            this,
            database.musicDao(),
            settings,
            MusicScanner(this),
            PlaybackMemory(this)
        )
        // The attestation minter needs an Application context to build its off-screen WebView and
        // to read its asset. It builds nothing here: the WebView appears on first use, and only if
        // remote playback actually happens.
        PoTokenMinter.install(this)
        SessionWebToken.install(
            this,
            SessionWebToken.Config(bootstrapUrl = BuildConfig.SESSION_BOOTSTRAP_URL)
        )
        // 6.36.0. `SessionWebToken.start()` отсюда УБРАН.
        //
        // Обе установки выше ничего не делают по сети — они запоминают контекст. А `start()`
        // поднимал WebView и шёл в Google на КАЖДОМ запуске приложения, включая запуск человека,
        // которому нужна витрина Deezer и который сидит без VPN. Там этот запрос не отваливается,
        // он висит, и висит первым — при том что аттестация нужна ровно одному потребителю,
        // прямому поиску в Innertube. Теперь он и запускается: в прогреве ниже, под флагом.
        // Ленивый путь при этом сохранён — `SessionWebToken.await()` сам зовёт `start()`, если
        // защищённый запрос всё-таки случится.
        // 6.30.0. Наверху теперь один каталог, "mix": он опрашивает витрину и сырой поиск
        // параллельно и склеивает их в один список, поэтому пользователь нигде не выбирает
        // источник. Оба поддерживаемых каталога остаются в реестре по своим id, и это не
        // декорация: id трека вида `r:yt:...`, сохранённый прошлыми версиями в избранном и
        // плейлистах, обязан продолжать резолвиться после обновления.
        val innertube = InnertubeCatalog(apiKey = BuildConfig.INNERTUBE_KEY)
        val deezer = DeezerCatalog()
        RemoteRuntime.registry = CatalogRegistry(
            listOf(
                MixCatalog(listOf(deezer, innertube)),
                innertube,
                deezer
            )
        )

        // Attestation takes a second or three. Spent here, at launch, off any user-visible path, it
        // costs nothing; spent on the first track it is a track that takes three seconds to start.
        // Failure is deliberately ignored - prewarm is an optimisation, not a step.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            // 6.36.0. Первым делом — уборка дефолта `yt`, доставшегося от прошлых версий, и только
            // потом чтение настроек: иначе прогрев успел бы прочитать значение, которое мы прямо
            // сейчас отменяем.
            settings.migrateCatalogDefault()
            val current = settings.settings.first()
            RemoteRuntime.youtubeDirect = current.youtubeDirect
            // 6.36.0. Греется ОДИН каталог — тот, который будет отвечать. Раньше грелись все, то
            // есть Innertube грелся всегда, даже когда его никто не спросит: аттестация на старте
            // стоила секунд и уходила в Google с телефона.
            if (current.youtubeDirect) SessionWebToken.start()
            val preferred = RemoteRuntime.registry.byId(current.catalogProvider)
                ?: RemoteRuntime.registry.all.firstOrNull()
            try {
                preferred?.prewarm()
            } catch (e: Throwable) {
                // A provider that cannot warm up still works on demand.
            }
        }

        // The Media3 loading thread cannot ask a ViewModel for settings, so the handful of values it
        // needs are mirrored into RemoteRuntime as they change. Application scope, because the
        // playback service outlives every screen.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            settings.settings
                .map {
                    // 6.37.1. Именованные аргументы, и это не косметика. У NetworkPrefs три пары
                    // СОСЕДНИХ однотипных полей: quality/meteredQuality (RemoteQuality),
                    // resolverUrl/resolverToken (String), resolverProxy/youtubeDirect (Boolean).
                    // Позиционный вызов позволял перепутать любую пару молча: компилируется,
                    // проходит все четыре tools/check_*.py, а поток загрузки Media3 получает
                    // качество для мобильной сети на Wi-Fi, токен вместо адреса или прокси
                    // вместо youtubeDirect. Симптом такого бага - «иногда не играет», то есть
                    // худший из возможных.
                    NetworkPrefs(
                        wifiOnly = it.wifiOnly,
                        quality = it.streamQuality,
                        meteredQuality = it.meteredQuality,
                        cacheEnabled = it.streamCacheEnabled,
                        cacheMb = it.streamCacheMb,
                        resolverUrl = it.resolverUrl,
                        resolverToken = it.resolverToken,
                        resolverProxy = it.resolverProxy,
                        youtubeDirect = it.youtubeDirect
                    )
                }
                .distinctUntilChanged()
                .collect { prefs ->
                    RemoteRuntime.wifiOnly = prefs.wifiOnly
                    RemoteRuntime.quality = prefs.quality
                    RemoteRuntime.meteredQuality = prefs.meteredQuality
                    RemoteRuntime.cacheEnabled = prefs.cacheEnabled
                    RemoteRuntime.cacheBytes = prefs.cacheMb.toLong() * 1024 * 1024
                    // 6.10.0: the resolver is read on the Media3 loading thread too, so it is
                    // mirrored here next to the other playback-path values, not fetched per track.
                    // installId обязан существовать РАНЬШЕ первого запроса: иначе первые
                    // экраны уедут без X-Zizi-Install и посчитаются анонимными.
                    ZiziInstall.ensure(this@ZiziApplication)
                    ZiziResolve.baseUrl = prefs.resolverUrl
                    ZiziResolve.token = prefs.resolverToken
                    ZiziResolve.proxyStream = prefs.resolverProxy
                    // 6.36.0: микс читает этот флаг на каждом поиске, а поиск идёт не только из UI.
                    RemoteRuntime.youtubeDirect = prefs.youtubeDirect
                }
        }

        playerController = PlayerController(this)

        // 6.24.0: разовая уборка кэша загрузок 6.20-6.23 и брошенных PENDING-строк в «Музыке».
        // На IO и после всего остального: это гигиена, а не часть запуска.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            LegacyOfflineCache.purgeOnce(this@ZiziApplication)
            // 6.24.1: недокачанные *.part от убитого процесса. Кэш система чистит только когда
            // память кончится, то есть сам он не уйдёт никогда.
            DownloadTemp.purge(this@ZiziApplication)
            // 6.24.1: cleanupPending теперь сначала пробует ДОПУБЛИКОВАТЬ наши строки и только
            // потом удаляет чужие. В 6.24.0 она удаляла всё pending подряд — и добивала ровно те
            // загрузки, у которых не снялся флаг видимости.
            OfflineStore.cleanupPending(this@ZiziApplication)
        }
    }

    /** Only so distinctUntilChanged has something small to compare. */
    private data class NetworkPrefs(
        val wifiOnly: Boolean,
        val quality: app.ziziplayer.data.remote.RemoteQuality,
        val meteredQuality: app.ziziplayer.data.remote.RemoteQuality,
        val cacheEnabled: Boolean,
        val cacheMb: Int,
        val resolverUrl: String,
        val resolverToken: String,
        val resolverProxy: Boolean,
        val youtubeDirect: Boolean
    )
}
