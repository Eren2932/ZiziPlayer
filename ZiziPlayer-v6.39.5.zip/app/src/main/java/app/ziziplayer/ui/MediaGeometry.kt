package app.ziziplayer.ui

/** Relative geometry measured from the 1080 px library reference. */
internal object MediaGeometry {
    const val COLUMNS = 3
    fun edge(width: Float): Float = width.coerceAtLeast(0f) * (45f / 1080f)
    fun tile(width: Float): Float = (width.coerceAtLeast(0f) - edge(width) * 4) / COLUMNS
}
