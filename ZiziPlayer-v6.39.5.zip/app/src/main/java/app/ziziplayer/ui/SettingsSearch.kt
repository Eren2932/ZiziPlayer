package app.ziziplayer.ui

import java.util.Locale

/** Word-wise, case-insensitive settings lookup, independent of Android. */
internal object SettingsSearch {
    private fun normalize(text: String) = text.lowercase(Locale.ROOT).replace('ё', 'е')
    fun matches(query: String, searchable: String): Boolean {
        val haystack = normalize(searchable)
        return normalize(query).trim().split(Regex("\\s+"))
            .filter { it.isNotEmpty() }.all { haystack.contains(it) }
    }
}
