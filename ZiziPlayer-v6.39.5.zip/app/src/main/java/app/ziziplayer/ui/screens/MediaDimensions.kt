package app.ziziplayer.ui.screens

import androidx.compose.ui.unit.dp

/** Shared row metrics; reference density assumed ~2.625 px/dp, not embedded in PNG. */
internal object MediaDimensions {
    val trackArt = 53.dp
    val trackRow = 71.dp
    val collectionArt = 70.dp
    val collectionRow = 88.dp
}
