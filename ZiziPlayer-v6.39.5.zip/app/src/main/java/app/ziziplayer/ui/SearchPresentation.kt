package app.ziziplayer.ui

/** Platform-free rules shared by the ViewModel and collection screen. */
internal object SearchPresentation {
    /** Provider completions first, then history and real matched metadata. Never invent titles. */
    fun completions(query: String, remote: List<String>, history: List<String>, metadata: List<String>): List<String> {
        val needle = query.trim().lowercase(java.util.Locale.ROOT)
        if (needle.length < 2) return emptyList()
        return (remote + (history + metadata).filter { it.lowercase(java.util.Locale.ROOT).contains(needle) })
            .map { it.trim() }.filter { it.isNotEmpty() }
            .distinctBy { it.lowercase(java.util.Locale.ROOT) }.take(5)
    }

    fun nextPage(next: String?, previous: String?, received: Int): String? =
        next?.takeIf { it.isNotBlank() && it != previous && received > 0 }

    fun durationMinutes(durations: List<Long>, complete: Boolean): Long? =
        if (!complete || durations.isEmpty() || durations.any { it <= 0L }) null
        else durations.sum() / 60000L
}
