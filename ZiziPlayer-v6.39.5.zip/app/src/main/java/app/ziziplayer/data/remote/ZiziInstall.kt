package app.ziziplayer.data.remote

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * 6.37.3 — установка как единица учёта, и ключ этой установки вместо вечного токена из APK.
 *
 * ПОЧЕМУ ЭТОТ ФАЙЛ ВООБЩЕ ПОЯВИЛСЯ
 *
 * `RESOLVER_TOKEN` запекается в релиз (build.gradle.kts) и достаётся из APK за минуту. Ротация
 * его не лечит: новый токен уедет в новый APK и утечёт оттуда точно так же. Сервер 1.7 научился
 * считать квоту «на устройство», но опирался на заголовок `X-Zizi-Install`, которого клиент не
 * присылал вообще — то есть ветка квоты на устройство не исполнялась ни разу. Это ровно та
 * болезнь, которой посвящён раздел 2 внешнего ревью: код написан, но не подключён.
 *
 * КАК ЭТО РАБОТАЕТ ТЕПЕРЬ
 *
 *  1. При первом запуске генерируется `installId` — случайный UUID. Он живёт в своих
 *     SharedPreferences, переживает обновление приложения и исчезает при переустановке.
 *  2. Он уезжает заголовком `X-Zizi-Install` на каждый запрос к нашему серверу, и сервер
 *     считает квоту по нему, а не по IP. Смысл в CGNAT: за одним адресом оператора сидят
 *     тысячи живых людей, и квота по IP наказывает их всех разом.
 *  3. Раз в сутки `installId` обменивается на `/auth/device` на короткоживущий КЛЮЧ, подписанный
 *     секретом, которого в APK нет. Дальше все запросы идут с ключом, а токен из сборки нужен
 *     только для обмена. С этого момента утёкший из релиза токен позволяет одно — попросить
 *     себе такой же ключ, упираясь в самую узкую квоту сервера, и быть отозванным по одному
 *     идентификатору без выпуска нового APK.
 *
 * ЧЕГО ЗДЕСЬ СОЗНАТЕЛЬНО НЕТ
 *
 * Ни ANDROID_ID, ни IMEI, ни рекламного идентификатора — ничего, что связано с устройством или
 * человеком. Случайный UUID нельзя сопоставить ни с другим приложением, ни с той же установкой
 * после переустановки, а `allowBackup="false"` в манифесте не даст ему уехать в чужую копию
 * через облачный бэкап. Это единица учёта и единица отзыва, а не личность. Позиция та же, что
 * у `CrashLog` без сети: считаем нагрузку, а не пользователей.
 *
 * ПОЧЕМУ SharedPreferences, А НЕ DataStore
 *
 * [ZiziResolve.authHeaders] — обычная функция, её зовут из построения любого запроса, в том
 * числе с потоков плеера. DataStore отдаёт значения только через suspend/Flow, и ради одной
 * строки пришлось бы либо блокировать поток, либо тащить корутину в путь каждого запроса.
 * SharedPreferences читается синхронно, и это единственная причина выбора.
 */
object ZiziInstall {

    private const val PREFS = "zizi_install"
    private const val KEY_ID = "install_id"
    private const val KEY_TOKEN = "device_token"
    private const val KEY_EXP = "device_token_exp"

    /** За сколько до конца срока идём за новым ключом. */
    private const val RENEW_MARGIN_MS = 10L * 60 * 1000

    /** Пауза после неудачи, чтобы не долбить сервер, когда он отвечает 429 или лежит. */
    private const val RETRY_AFTER_FAIL_MS = 5L * 60 * 1000

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var prefs: android.content.SharedPreferences? = null

    @Volatile
    var id: String = ""
        private set

    @Volatile
    private var deviceToken: String = ""

    @Volatile
    private var deviceExpiresAt: Long = 0L

    @Volatile
    private var nextAttemptAt: Long = 0L

    @Volatile
    private var lastError: String = ""

    /**
     * Зовётся из [app.ziziplayer.ZiziApplication] один раз, до первого сетевого запроса.
     * Идемпотентна: повторный вызов ничего не перегенерирует.
     */
    fun ensure(context: Context): String {
        prefs?.let { if (id.isNotBlank()) return id }
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        var value = p.getString(KEY_ID, "").orEmpty()
        if (value.isBlank()) {
            // Дефис из UUID оставляем: сервер принимает [A-Za-z0-9._:-] длиной 8..64, а
            // читаемый идентификатор проще отозвать руками, не перепутав символы.
            value = UUID.randomUUID().toString()
            p.edit().putString(KEY_ID, value).apply()
        }
        id = value
        deviceToken = p.getString(KEY_TOKEN, "").orEmpty()
        deviceExpiresAt = p.getLong(KEY_EXP, 0L)
        return value
    }

    /** Есть ли на руках ключ, который ещё не пора менять. */
    private fun fresh(now: Long = System.currentTimeMillis()): Boolean =
        deviceToken.isNotBlank() && now < deviceExpiresAt - RENEW_MARGIN_MS

    /**
     * Что положить в `Authorization`. Ключ устройства, если он есть; иначе токен из сборки.
     *
     * Функция не ждёт сети НИКОГДА. Пока ключа нет, запрос уходит с бутстрап-токеном — это то же
     * поведение, что во всех предыдущих релизах, — а обмен идёт в фоне. Иначе первый экран
     * зависел бы от лишнего кругового обхода, и любая проблема с /auth/device выглядела бы как
     * «приложение не запускается».
     */
    fun bearer(bootstrap: String): String {
        if (fresh()) return deviceToken
        if (bootstrap.isNotBlank()) refreshSoon(bootstrap)
        return bootstrap
    }

    private fun refreshSoon(bootstrap: String) {
        val now = System.currentTimeMillis()
        if (now < nextAttemptAt) return
        nextAttemptAt = now + RETRY_AFTER_FAIL_MS
        scope.launch { refresh(bootstrap) }
    }

    /**
     * Обмен бутстрап-токена на ключ. Тихая: любой отказ означает «работаем как раньше», а не
     * «приложение сломалось». Причина отказа видна в диагностике ([report]).
     */
    suspend fun refresh(bootstrap: String) {
        val base = ZiziResolve.authBase() ?: return
        if (id.isBlank() || bootstrap.isBlank()) return
        try {
            val json = ZiziHttp.getJson(
                base + "/auth/device",
                mapOf("Authorization" to "Bearer " + bootstrap.trim(), "X-Zizi-Install" to id),
            )
            val token = json.optString("token", "")
            val ttl = json.optLong("expires_in", 0L)
            if (token.isBlank() || ttl <= 0L) {
                lastError = "сервер не отдал ключ"
                return
            }
            deviceToken = token
            // Срок считаем от МОМЕНТА ОТВЕТА и по относительному expires_in, а не по абсолютной
            // метке с сервера: часы на телефоне могут отставать на часы, и абсолютное время
            // сделало бы ключ «истёкшим» сразу после выдачи.
            deviceExpiresAt = System.currentTimeMillis() + ttl * 1000L
            lastError = ""
            prefs?.edit()?.putString(KEY_TOKEN, token)?.putLong(KEY_EXP, deviceExpiresAt)?.apply()
            // Успех снимает паузу: следующий обмен нужен только к концу срока.
            nextAttemptAt = 0L
        } catch (e: Throwable) {
            // 401 здесь значит «токен сборки не подходит серверу», 503 — «сервер ключи не
            // выдаёт, ZIZI_TOKEN пуст». Оба случая штатны для старого сервера, и оба не должны
            // ничего ломать: bearer() продолжит отдавать бутстрап-токен.
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
    }

    /** Одна строка для экрана диагностики. Сам ключ наружу не показываем никогда. */
    fun report(): String {
        val left = deviceExpiresAt - System.currentTimeMillis()
        return when {
            deviceToken.isBlank() -> "ключ устройства: нет" +
                (if (lastError.isNotBlank()) " · $lastError" else " · токен сборки")
            left <= 0 -> "ключ устройства: истёк, обновляется"
            else -> "ключ устройства: есть, ещё " + (left / 3_600_000L) + " ч"
        }
    }

    /** Только для тестов и для кнопки «сбросить» в диагностике. */
    fun forgetDeviceToken() {
        deviceToken = ""
        deviceExpiresAt = 0L
        nextAttemptAt = 0L
        prefs?.edit()?.remove(KEY_TOKEN)?.remove(KEY_EXP)?.apply()
    }
}
