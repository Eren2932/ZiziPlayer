package app.ziziplayer.data

import app.ziziplayer.data.remote.CatalogPolicy
import android.content.Context
import android.net.Uri
import app.ziziplayer.BuildConfig
import app.ziziplayer.data.remote.RemoteQuality
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("zizi_settings")

enum class SortMode { TITLE, ARTIST, DURATION, RECENT, PLAYS }

/**
 * Как показана коллекция медиатеки: сеткой обложек или списком строк (6.29.0).
 *
 * Это НАСТРОЙКА, а не состояние экрана, и живёт она здесь по одной причине: человек выбирает
 * вид один раз и ждёт его всегда. Держать переключатель в `remember` экрана значило бы сбрасывать
 * выбор на каждый уход в плеер и на каждый поворот телефона — то есть просить выбирать заново
 * ровно то, что уже выбрано.
 *
 * По умолчанию GRID: у коллекции опознавательный знак — обложка, а сетка показывает четыре
 * обложки там, где список показывает четыре строки текста.
 */
enum class LibraryView { GRID, LIST }

/**
 * Порядок карточек коллекции (6.29.0). У треков свой порядок — [SortMode]; смешивать их в одно
 * перечисление нельзя: «по длительности» для папки бессмысленно, «по размеру» для трека — тоже.
 *
 * [RECENT] — по последнему открытию (см. `libraryRecents`). Именно этот порядок стоит первым в
 * референсе, и он же единственный, который отвечает на вопрос «где то, с чем я только что работал».
 * [ADDED] — по дате появления в медиатеке. [TITLE] — по алфавиту. [SIZE] — по числу треков.
 */
enum class CollectionSort { RECENT, ADDED, TITLE, SIZE }

/** Сколько последних открытий помнить. Больше экрана — уже не «недавние». */
private const val RECENTS_MAX = 40

data class UserSettings(
    val accentFromArtwork: Boolean = true,
    val folderUris: Set<String> = emptySet(),
    /**
     * Имя папки -> как её называть на экране (6.27.1).
     *
     * Переименование ЭКРАННОЕ, и это осознанный выбор, а не полумера. Настоящее
     * `DocumentsContract.renameDocument` меняет documentId дерева, а долговременный доступ выдан
     * именно на старый id: переименовал папку — потерял к ней доступ до повторного выбора через
     * системный диалог. Имя на экране решает ту задачу, которая у человека есть («папка
     * называется new_folder_3, я не понимаю, что в ней»), и не трогает то, чего он не просил.
     */
    val folderLabels: Map<String, String> = emptyMap(),
    val skipSilence: Boolean = false,

    /**
     * 6.24.4. true — один тракт на всю музыку, настройка трека игнорируется; false — у каждого
     * трека свой. Флаг существует потому, что оба поведения правильные для разных людей: тому,
     * кто слушает в одних наушниках, нужна одна коррекция навсегда, а тому, кто крутит «подводный»
     * под конкретный трек, — своя на трек. Угадывать за человека нечего, поэтому это переключатель.
     */
    val dspGlobal: Boolean = false,
    /** Глобальный тракт строкой DspCodec. Пустая строка — нейтраль. */
    val dspConfig: String = "",
    val sortMode: SortMode = SortMode.TITLE,
    /** 6.29.0: вид коллекции (сетка/список) и порядок карточек. */
    val libraryView: LibraryView = LibraryView.GRID,
    val collectionSort: CollectionSort = CollectionSort.RECENT,
    /**
     * Ключи открытых карточек, свежие в начале: `fav`, `tracks`, `pl:12`, `dir:Music`,
     * `art:madk1d`. Ключ, а не сущность: плейлист удалят, папку отключат, исполнитель исчезнет
     * вместе с последним треком — и список «недавних» не должен держать на них ссылку.
     */
    val libraryRecents: List<String> = emptyList(),

    // ---- network catalogue ----
    /**
     * Preferred catalogue id.
     *
     * 6.36.0: `mix`, а не `yt`. С 6.30.0 в реестре первым стоит [MixCatalog] — витрина Deezer,
     * склеенная с остальными источниками, — но выбирался он только если предпочтённый каталог
     * УПАЛ. С VPN Innertube не падал, поэтому пользователь шесть релизов подряд видел сырую
     * выдачу YouTube и ни разу — то, ради чего 6.30.0 писалась. Значение читается в трёх местах
     * (`MainViewModel.search`, `discover`, `SearchViewModel`), и во всех трёх оно молча решало,
     * будет ли телефон вообще ходить в Google.
     */
    val catalogProvider: String = "mix",
    /**
     * 6.36.0. Разрешено ли телефону ходить в YouTube СВОИМИ ногами.
     *
     * Выключено по умолчанию, и это не про приватность, а про то, что без VPN такой запрос не
     * получает отказ — он висит до таймаута OkHttp. Выключенный флаг убирает из микса Innertube,
     * не даёт стартовать аттестации (`SessionWebToken`, `PoTokenMinter`) и уводит обложки на свой
     * сервер. Воспроизведение он не трогает вообще: звук и так берётся у резолвера, включая старые
     * треки `r:yt:...` из избранного — [InnertubeCatalog.resolveStream] первым делом спрашивает
     * [ZiziResolve] и до клиентской лестницы доходит только когда сервер недоступен.
     */
    val youtubeDirect: Boolean = false,
    /** Refuse to open a stream on a metered connection. Off by default; nothing is hidden. */
    val wifiOnly: Boolean = false,
    val streamQuality: RemoteQuality = RemoteQuality.NORMAL,
    /** Used instead of [streamQuality] on mobile data, when it is the cheaper of the two. */
    val meteredQuality: RemoteQuality = RemoteQuality.LOW,
    val streamCacheEnabled: Boolean = true,
    /** Cache ceiling in MB. 512 is roughly 8 hours of 128 kbps audio. */
    val streamCacheMb: Int = 512,

    // ---- own resolver (6.10.0) ----
    /**
     * Address of the user's own resolver, e.g. `147.45.166.244:8080`. Empty means the old
     * on-device path, which 6.9.4 proved is refused by attestation on every client.
     */
    val resolverUrl: String = BuildConfig.RESOLVER_URL,
    /** Token printed by the installer. Without it the server answers 401, by design. */
    val resolverToken: String = BuildConfig.RESOLVER_TOKEN,
    /**
     * true: audio is proxied through the server (`/stream`), which sidesteps the fact that a
     * googlevideo URL is minted for the IP that asked for it. false: the phone fetches Google
     * directly and no traffic goes through the VPS - faster and free, but only works when that
     * 403 does not happen.
     */
    val resolverProxy: Boolean = BuildConfig.RESOLVER_PROXY,

    /**
     * 6.11.0 — technical rows of the settings screen.
     *
     * Address, token, `/health`, the client walker and the stream report exist because this app
     * talks to a private API that breaks without notice; they are indispensable when it does and
     * pure noise when it does not. So they are hidden, not deleted: seven taps on the version row.
     *
     * Default: hidden when the build already knows the token (a real release), visible when it
     * does not (a local or fork build, where the address has to be typed by hand anyway).
     */
    val devMode: Boolean = !DevAccess.protected
)

class SettingsStore(private val context: Context) {
    private val dynamicAccent = booleanPreferencesKey("dynamic_accent")
    private val folders = stringSetPreferencesKey("folders")
    private val folderLabelKey = stringSetPreferencesKey("folder_labels")
    private val skipSilenceKey = booleanPreferencesKey("skip_silence")
    private val dspGlobalKey = booleanPreferencesKey("dsp_global")
    private val dspConfigKey = stringPreferencesKey("dsp_config")
    private val sortModeKey = stringPreferencesKey("sort_mode")
    private val libraryViewKey = stringPreferencesKey("library_view")
    private val collectionSortKey = stringPreferencesKey("collection_sort")
    /**
     * Одна строка, а не stringSet: у множества нет порядка, а здесь порядок — это и есть всё
     * содержание. Разделитель \u0001 выбран потому, что в имени папки и в имени исполнителя может
     * встретиться любой печатный символ, включая запятую, точку с запятой и перевод строки.
     */
    private val recentsKey = stringPreferencesKey("library_recents")
    /**
     * Marks the one-shot rewrite of track ids as finished. Read and written outside [settings] on
     * purpose: it is not user-facing state, and pushing it through that flow would rebuild the whole
     * library pipeline for a housekeeping flag.
     */
    private val idsMigratedKey = booleanPreferencesKey("ids_migrated_v3")
    private val catalogKey = stringPreferencesKey("catalog_provider")
    /** Разовая уборка дефолта `yt`, доставшегося от версий до 6.36.0. См. [migrateCatalogDefault]. */
    private val catalogMigratedKey = booleanPreferencesKey("catalog_default_mix_v1")
    private val youtubeDirectKey = booleanPreferencesKey("youtube_direct")
    private val wifiOnlyKey = booleanPreferencesKey("stream_wifi_only")
    private val qualityKey = stringPreferencesKey("stream_quality")
    private val meteredQualityKey = stringPreferencesKey("stream_quality_metered")
    private val cacheEnabledKey = booleanPreferencesKey("stream_cache_enabled")
    private val cacheMbKey = intPreferencesKey("stream_cache_mb")
    private val resolverUrlKey = stringPreferencesKey("resolver_url")
    private val resolverTokenKey = stringPreferencesKey("resolver_token")
    private val resolverProxyKey = booleanPreferencesKey("resolver_proxy")
    private val devModeKey = booleanPreferencesKey("dev_mode")

    private fun quality(raw: String?, fallback: RemoteQuality): RemoteQuality =
        runCatching { RemoteQuality.valueOf(raw ?: fallback.name) }.getOrDefault(fallback)

    val settings: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            accentFromArtwork = p[dynamicAccent] ?: true,
            folderUris = p[folders] ?: emptySet(),
            folderLabels = decodeLabels(p[folderLabelKey]),
            skipSilence = p[skipSilenceKey] ?: false,
            dspGlobal = p[dspGlobalKey] ?: false,
            dspConfig = p[dspConfigKey] ?: "",
            sortMode = runCatching { SortMode.valueOf(p[sortModeKey] ?: SortMode.TITLE.name) }.getOrDefault(SortMode.TITLE),
            libraryView = runCatching { LibraryView.valueOf(p[libraryViewKey] ?: LibraryView.GRID.name) }.getOrDefault(LibraryView.GRID),
            collectionSort = runCatching { CollectionSort.valueOf(p[collectionSortKey] ?: CollectionSort.RECENT.name) }.getOrDefault(CollectionSort.RECENT),
            libraryRecents = decodeRecents(p[recentsKey]),
            catalogProvider = CatalogPolicy.preference(p[catalogKey]),
            youtubeDirect = p[youtubeDirectKey] ?: false,
            wifiOnly = p[wifiOnlyKey] ?: false,
            streamQuality = quality(p[qualityKey], RemoteQuality.NORMAL),
            meteredQuality = quality(p[meteredQualityKey], RemoteQuality.LOW),
            streamCacheEnabled = p[cacheEnabledKey] ?: true,
            streamCacheMb = (p[cacheMbKey] ?: 512).coerceIn(64, 8192),
            // Baked value is the default, a value typed by hand still wins: an old install that
            // already has the address keeps it, and a user with his own server is not locked out.
            resolverUrl = (p[resolverUrlKey] ?: "").ifBlank { BuildConfig.RESOLVER_URL },
            resolverToken = (p[resolverTokenKey] ?: "").ifBlank { BuildConfig.RESOLVER_TOKEN },
            resolverProxy = p[resolverProxyKey] ?: BuildConfig.RESOLVER_PROXY,
            // 6.17.0: в защищённой сборке сохранённый флаг больше не читается вообще. Иначе
            // тестер, случайно открывший отладку в 6.15.0, остался бы с ней навсегда — обновление
            // приложения не трогает DataStore.
            devMode = if (DevAccess.protected) false else (p[devModeKey] ?: true)
        )
    }
    suspend fun setDynamicAccent(value: Boolean) = context.dataStore.edit { it[dynamicAccent] = value }
    suspend fun addFolder(uri: Uri) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) + uri.toString() }

    /**
     * Пустое или совпадающее с исходным имя — это снятие переименования, а не запись пустой
     * строки: иначе «стереть всё и подтвердить» дало бы папку без названия, которую нечем
     * вернуть обратно.
     */
    suspend fun setFolderLabel(name: String, label: String) = context.dataStore.edit { prefs ->
        val current = decodeLabels(prefs[folderLabelKey]).toMutableMap()
        val trimmed = label.trim().take(60)
        if (trimmed.isBlank() || trimmed == name) current.remove(name) else current[name] = trimmed
        prefs[folderLabelKey] = current.map { it.key + LABEL_SEP + it.value }.toSet()
    }
    suspend fun removeFolder(uri: String) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) - uri }
    suspend fun setSkipSilence(value: Boolean) = context.dataStore.edit { it[skipSilenceKey] = value }
    suspend fun setDspGlobal(value: Boolean) = context.dataStore.edit { it[dspGlobalKey] = value }
    suspend fun setGlobalDsp(value: String) = context.dataStore.edit { it[dspConfigKey] = value }
    suspend fun setSortMode(value: SortMode) = context.dataStore.edit { it[sortModeKey] = value.name }
    suspend fun setLibraryView(value: LibraryView) = context.dataStore.edit { it[libraryViewKey] = value.name }
    suspend fun setCollectionSort(value: CollectionSort) = context.dataStore.edit { it[collectionSortKey] = value.name }

    /**
     * Отметить карточку открытой. Ключ переезжает в начало, дубликат снимается, хвост обрезается.
     *
     * Пишется одним `edit` на одно открытие — это несколько десятков байт и не тот масштаб, из-за
     * которого стоит городить кэш в памяти. Зато «недавние» одинаковы после перезапуска, а не
     * только внутри одного сеанса.
     */
    suspend fun noteRecent(key: String) = context.dataStore.edit { p ->
        val list = decodeRecents(p[recentsKey]).toMutableList()
        list.remove(key)
        list.add(0, key)
        p[recentsKey] = list.take(RECENTS_MAX).joinToString("\u0001")
    }

    private fun decodeRecents(raw: String?): List<String> =
        if (raw.isNullOrEmpty()) emptyList() else raw.split('\u0001').filter { it.isNotBlank() }

    suspend fun setCatalogProvider(value: String) = context.dataStore.edit { it[catalogKey] = CatalogPolicy.preference(value) }
    suspend fun setYoutubeDirect(value: Boolean) = context.dataStore.edit { it[youtubeDirectKey] = value }

    /** Keep the original one-time default migration, but normalize removed providers on
     * every upgrade, including installations where that earlier migration already ran.
     */
    suspend fun migrateCatalogDefault() {
        context.dataStore.edit { p ->
            val stored = p[catalogKey]
            if (stored != null) p[catalogKey] = CatalogPolicy.preference(stored)
            if (p[catalogMigratedKey] == true) return@edit
            if (p[catalogKey] == "yt") p.remove(catalogKey)
            p[catalogMigratedKey] = true
        }
    }
    suspend fun setWifiOnly(value: Boolean) = context.dataStore.edit { it[wifiOnlyKey] = value }
    suspend fun setStreamQuality(value: RemoteQuality) = context.dataStore.edit { it[qualityKey] = value.name }
    suspend fun setMeteredQuality(value: RemoteQuality) = context.dataStore.edit { it[meteredQualityKey] = value.name }
    suspend fun setStreamCacheEnabled(value: Boolean) = context.dataStore.edit { it[cacheEnabledKey] = value }
    suspend fun setStreamCacheMb(value: Int) = context.dataStore.edit { it[cacheMbKey] = value.coerceIn(64, 8192) }

    suspend fun setResolverUrl(value: String) = context.dataStore.edit { it[resolverUrlKey] = value.trim() }
    suspend fun setResolverToken(value: String) = context.dataStore.edit { it[resolverTokenKey] = value.trim() }
    suspend fun setResolverProxy(value: Boolean) = context.dataStore.edit { it[resolverProxyKey] = value }
    /** Пишется только в незащищённой сборке; в релизе доступ живёт сессией, а не настройкой. */
    suspend fun setDevMode(value: Boolean) {
        if (DevAccess.protected) return
        context.dataStore.edit { it[devModeKey] = value }
    }

    suspend fun idsMigrated(): Boolean = context.dataStore.data.map { it[idsMigratedKey] ?: false }.first()
    suspend fun setIdsMigrated() = context.dataStore.edit { it[idsMigratedKey] = true }
}

/** Разделитель внутри одной строки набора: имя папки и её экранное имя. */
private const val LABEL_SEP = "\u001F"

/**
 * Карта имён в Preferences DataStore хранится набором строк, потому что своего типа для карты у
 * него нет. Разделитель — управляющий символ 0x1F (Unit Separator): в имени папки он не встречается
 * ни в одной файловой системе, в отличие от двоеточия, дефиса и вертикальной черты.
 */
private fun decodeLabels(raw: Set<String>?): Map<String, String> {
    if (raw.isNullOrEmpty()) return emptyMap()
    val out = HashMap<String, String>(raw.size)
    raw.forEach { entry ->
        val at = entry.indexOf(LABEL_SEP)
        if (at <= 0 || at == entry.length - 1) return@forEach
        out[entry.substring(0, at)] = entry.substring(at + 1)
    }
    return out
}
