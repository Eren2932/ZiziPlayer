package app.ziziplayer.data.remote

/** Supported identities, also applied before reading pre-upgrade preferences and caches.
 * No old IDs are reassigned to another provider: that could play the wrong recording.
 */
object CatalogPolicy {
    fun preference(provider: String?): String = when (provider) {
        "mix", "dz", "yt" -> provider
        else -> "mix"
    }

    fun supports(provider: String?, remoteId: String?): Boolean {
        if (remoteId.isNullOrBlank()) return false
        return when (provider) {
            "dz", "yt" -> true
            "mix" -> {
                val separator = remoteId.indexOf(':')
                separator > 0 && separator < remoteId.lastIndex &&
                    remoteId.substring(0, separator) in setOf("dz", "yt")
            }
            else -> false
        }
    }
}
