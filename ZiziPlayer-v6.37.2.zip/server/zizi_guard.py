"""
zizi_guard.py — граница «клиент -> каталог» для ZiziPlayer.

Зачем отдельный файл, а не десять строк внутри zizi_catalog.py.
Резолвер закрыт _check_token с первого дня, каталог — не закрыт вообще: одиннадцать роутов,
ни одной проверки. Дыра стоит рядом с фанаутом: один запрос /match порождает три процесса
yt-dlp, а негативный кэш от мусорных запросов не спасает — ключ кэша собирается из title и
artist, то есть из свободных параметров. Случайная строка = гарантированный промах = три
процесса. На одном ядре и 890 МБ это curl в цикле.

Модуль намеренно не импортирует fastapi и вообще ничего внешнего. Причина простая: всё, что я
делал в клиенте, проверялось эвристиками, а этот код я хочу ЗАПУСТИТЬ. Без веб-фреймворка он
целиком покрывается юнит-тестами (server/tools/test_zizi_guard.py), а в zizi_catalog.py уходит
подключение в несколько строк.

Три слоя, каждый закрывает то, что не закрывают другие:

  1. Токен      — отсекает того, кто не наш клиент вообще.
  2. Квота      — отсекает нашего клиента, который сошёл с ума или которым притворяются.
  3. Семафор    — ставит потолок на yt-dlp по ВСЕЙ машине, а не по одному запросу.

Третий слой обязателен даже если первые два идеальны: max_workers=3 в _hunt ограничивает один
запрос, а не сервер. N одновременных запросов = 3N процессов. Семафор — единственное место,
где написано, сколько процессов машина готова держать.

Переменные окружения (все необязательны, значения по умолчанию безопасны):

    ZIZI_CATALOG_TOKEN=...        # по умолчанию берётся ZIZI_TOKEN; если пусто — режим "off"
    ZIZI_CATALOG_TOKEN_MODE=warn  # off | warn | require   (по умолчанию warn)
    ZIZI_CATALOG_SLOTS=3          # потолок одновременных yt-dlp каталога на всю машину
    ZIZI_CATALOG_SLOT_WAIT=8.0    # сколько секунд ждать слот, прежде чем ответить 429

Имя НЕ ZIZI_EXTRACT_SLOTS, и это не вкусовщина. Такая переменная уже занята резолвером
(install-zizi-resolver.sh пишет в zizi.env ZIZI_EXTRACT_SLOTS=1), и совпадение имён означало бы
семафор на ОДИН слот: три захода _hunt встали бы в очередь, каждое сопоставление подорожало бы
втрое и упёрлось в таймаут. Причём тихо — сервис бы работал, просто медленно.

    # Квоты задаются на КЛАСС нагрузки и на уровень доверия:
    #   ZIZI_RL_<CLASS>_<TIER>_BURST   и   ZIZI_RL_<CLASS>_<TIER>_RPM
    # где CLASS = MATCH | CATALOG | IMG,   TIER = ID | ANON.
    # Например ZIZI_RL_MATCH_ANON_RPM=20.

Почему три бакета, а не один с ценами. Первая версия этого модуля считала все роуты одним
бакетом, назначив /match цену повыше. Так делать нельзя, и причина видна только в клиенте:
ZiziResolve.kt:102 строит /img?u=... НА КАЖДУЮ ОБЛОЖКУ, а DeezerCatalog.kt:188 просит плейлист
на 100 треков. То есть законное открытие одного экрана — это под сотню запросов за пару секунд.
Общий бакет, настроенный так, чтобы пережить этот залп, перестаёт защищать /match; настроенный
так, чтобы защищать /match, — рвёт клиенту загрузку обложек на середине списка. Это не выбор
числа, это выбор между двумя поломками.

Классы разведены, и залп обложек физически не может выесть квоту сопоставления:

    IMG      дёшево: диск + allowlist, сети почти нет      -> квота широкая
    CATALOG  один HTTP к Deezer/Spotify + кэш              -> квота средняя
    MATCH    до трёх процессов yt-dlp по 25 секунд         -> квота узкая + семафор

Почему по умолчанию mode=warn, а не require. Правило №10: мягкая деградация. Токена в текущем
APK нет — включённый require убьёт каталог у всех установленных копий в ту секунду, когда файл
ляжет на VPS. В режиме warn запрос без токена проходит, но считается анонимным (жёсткая квота)
и попадает в счётчики. Когда в /catalog/health доля anon_pct упадёт до нуля — значит новый
клиент разошёлся, и require можно включать осознанно, по цифре, а не на глаз.
"""

from __future__ import annotations

import hmac
import os
import threading
import time
from typing import Callable, Dict, NamedTuple, Optional, Tuple


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


# ---------------------------------------------------------------- квота

class KeyedRateLimiter:
    """Токен-бакет на ключ.

    Бакет, а не «N запросов в минуту» окном: окно либо режет законный всплеск (человек открыл
    экран, полетело шесть запросов разом), либо пропускает залп на стыке двух окон. Бакет
    разводит эти два параметра — burst отвечает за всплеск, rate за длительную нагрузку.

    Словарь ключей ограничен сверху: иначе сам ограничитель становится вектором атаки —
    достаточно слать запросы с разными installId, чтобы съесть память.
    """

    __slots__ = ("capacity", "refill", "_buckets", "_lock", "_now", "max_keys", "evictions")

    def __init__(self, capacity: float, refill_per_sec: float,
                 max_keys: int = 4096,
                 now: Callable[[], float] = time.monotonic) -> None:
        self.capacity = float(capacity)
        self.refill = float(refill_per_sec)
        self.max_keys = int(max_keys)
        self.evictions = 0
        # ключ -> [токенов, момент последнего обращения]
        self._buckets: Dict[str, list] = {}
        self._lock = threading.Lock()
        self._now = now

    def take(self, key: str, cost: float = 1.0) -> Tuple[bool, float]:
        """Списать cost. Возвращает (пропускаем, через сколько секунд пробовать снова)."""
        now = self._now()
        with self._lock:
            b = self._buckets.get(key)
            if b is None:
                if len(self._buckets) >= self.max_keys:
                    self._evict_locked(now)
                b = [self.capacity, now]
                self._buckets[key] = b
            tokens, last = b
            tokens = min(self.capacity, tokens + (now - last) * self.refill)
            b[1] = now
            if tokens >= cost:
                b[0] = tokens - cost
                return True, 0.0
            b[0] = tokens
            if self.refill <= 0:
                return False, 60.0
            need = cost - tokens
            return False, max(0.001, need / self.refill)

    def _evict_locked(self, now: float) -> None:
        """Выкидываем четверть самых давних ключей.

        Именно давних, а не случайных: у активного клиента бакет должен переживать чужой шум,
        иначе вытеснение само по себе выдаёт всем полный лимит заново.
        """
        victims = sorted(self._buckets.items(), key=lambda kv: kv[1][1])
        for k, _ in victims[: max(1, len(victims) // 4)]:
            self._buckets.pop(k, None)
            self.evictions += 1

    def size(self) -> int:
        with self._lock:
            return len(self._buckets)


# ---------------------------------------------------------------- потолок на yt-dlp

class ExtractGate:
    """Глобальный потолок одновременных извлечений (yt-dlp).

    Не заменяет пул в _hunt и не спорит с ним: пул отвечает за то, чтобы три захода одного
    запроса шли параллельно, а этот семафор — за то, чтобы сумма по всем запросам не выносила
    машину. Ждём слот ограниченное время: бесконечное ожидание превращает 429 в зависший
    сокет, а телефон всё равно уходит по таймауту через 20 секунд.
    """

    __slots__ = ("_sem", "slots", "wait", "_lock", "in_flight", "peak", "waited", "rejected")

    def __init__(self, slots: int = 3, wait: float = 8.0) -> None:
        self.slots = max(1, int(slots))
        self.wait = float(wait)
        self._sem = threading.BoundedSemaphore(self.slots)
        self._lock = threading.Lock()
        self.in_flight = 0
        self.peak = 0
        self.waited = 0
        self.rejected = 0

    def acquire(self, timeout: Optional[float] = None) -> bool:
        t = self.wait if timeout is None else timeout
        ok = self._sem.acquire(timeout=t)
        with self._lock:
            if ok:
                self.in_flight += 1
                self.peak = max(self.peak, self.in_flight)
            else:
                self.rejected += 1
        return ok

    def release(self) -> None:
        with self._lock:
            if self.in_flight > 0:
                self.in_flight -= 1
        try:
            self._sem.release()
        except ValueError:
            # Освободили больше, чем брали. Молча проглотить нельзя — это баг вызывающего.
            raise

    def __enter__(self) -> "ExtractGate":
        if not self.acquire():
            raise ExtractBusy(self.wait)
        return self

    def __exit__(self, *exc) -> None:
        self.release()

    def stats(self) -> dict:
        with self._lock:
            return {"slots": self.slots, "in_flight": self.in_flight,
                    "peak": self.peak, "rejected": self.rejected}


class ExtractBusy(Exception):
    """Слот под yt-dlp не освободился за отведённое время."""

    def __init__(self, waited: float) -> None:
        super().__init__(f"extractor busy after {waited:.1f}s")
        self.retry_after = max(1, int(waited))


# ---------------------------------------------------------------- решение по запросу

class Decision(NamedTuple):
    allowed: bool
    status: int            # 0 когда пропускаем
    retry_after: int       # секунды, 0 когда неприменимо
    reason: str
    kind: str              # "id" | "anon" — по какой квоте посчитали


# Класс нагрузки по префиксу пути. Порядок важен: /match/warm обязан проверяться до /match.
CLASSES: Tuple[Tuple[str, str], ...] = (
    ("/match/warm", "match"),
    ("/match/deezer", "match"),
    ("/match", "match"),
    ("/img", "img"),
    ("/catalog/", "catalog"),
)

# (burst, rpm) для опознанного и для анонимного.
#
# Числа взяты не с потолка, а из того, что делает клиент:
#   img     — плейлист на 100 треков = 100 обложек залпом (DeezerCatalog.kt:188), поэтому
#             burst 200; дальше их забирает дисковый кэш и поток спадает.
#   catalog — экран это 1-3 запроса; 60 залпом хватает на любое листание руками.
#   match   — здесь платит процессор. 20 подряд для устройства — это уже не человек.
# Аноним урезан втрое, но НЕ до нуля: под CGNAT оператора за одним IP сидит много живых людей,
# и жёсткая квота по IP наказала бы их всех разом. Настоящий потолок для /match ставит семафор,
# а не эта квота: он ограничивает машину, и его обойти нельзя ни с какого числа адресов.
DEFAULT_QUOTAS: Dict[str, Dict[str, Tuple[float, float]]] = {
    "match":   {"id": (20, 60),   "anon": (8, 24)},
    "catalog": {"id": (60, 240),  "anon": (30, 120)},
    "img":     {"id": (200, 900), "anon": (120, 600)},
}


def class_of(path: str) -> str:
    for prefix, cls in CLASSES:
        if path.startswith(prefix):
            return cls
    return "catalog"


# Роуты, которые НЕ требуют токена даже в режиме require, но квоту платят наравне со всеми.
#
# Здесь ровно один адрес, и он попал сюда не по мягкости, а по факту, снятому с клиента:
# ZiziHttp.kt:216 fetchBytes() шлёт только User-Agent, без Authorization — обложки за токеном
# не ходят и никогда не ходили. Потребовать токен на /img — значит получить серую сетку вместо
# картинок у всех установленных копий.
#
# Цена вопроса мала и посчитана: /img закрыт allowlist'ом хостов (_img_allowed), ограничен по
# размеру (IMG_MAX) и вытесняется по квоте, то есть SSRF там нет, а стоимость запроса — диск.
# Именно поэтому остальные роуты можно закрывать по-настоящему уже сегодня: /catalog/* и
# /match/* нынешний APK шлёт с Authorization (DeezerCatalog.kt:96 и :210), то есть режим
# require не ломает ни одной установленной копии. Нового релиза для этого не нужно.
TOKEN_OPTIONAL = ("/img",)

# Открыто всегда. Мониторинг обязан отвечать, даже когда всё остальное отдаёт 429, иначе
# алерт из пункта 3 не отличит «сервис лёг» от «сервис защищается».
OPEN_PATHS = ("/catalog/health",)


class Guard:
    """Три слоя в одном решении. Ничего не знает про HTTP — только про строки и числа."""

    def __init__(self,
                 token: Optional[str] = None,
                 mode: Optional[str] = None,
                 quotas: Optional[Dict[str, Dict[str, Tuple[float, float]]]] = None,
                 now: Callable[[], float] = time.monotonic) -> None:
        # Откат на ZIZI_TOKEN — не лень, а единственный способ заработать без правки zizi.env.
        # Клиент шлёт в каталог ТОТ ЖЕ токен, что и в резолвер (ZiziResolve.authHeaders одна на
        # всё приложение). Отдельная переменная нужна только тем, кто захочет развести их позже.
        if token is None:
            self.token = os.getenv("ZIZI_CATALOG_TOKEN") or os.getenv("ZIZI_TOKEN", "")
        else:
            self.token = token
        m = (os.getenv("ZIZI_CATALOG_TOKEN_MODE", "warn") if mode is None else mode).lower()
        if m not in ("off", "warn", "require"):
            m = "warn"
        # Требовать токен, которого нет в конфиге, — это 401 всем и навсегда. Такая опечатка
        # в zizi.env не должна валить сервис молча.
        if not self.token:
            m = "off"
        self.mode = m

        self.quotas = quotas if quotas is not None else self._quotas_from_env()
        # limiters[класс][уровень] -> бакет
        self.limiters: Dict[str, Dict[str, KeyedRateLimiter]] = {
            cls: {tier: KeyedRateLimiter(b, rpm / 60.0, now=now)
                  for tier, (b, rpm) in tiers.items()}
            for cls, tiers in self.quotas.items()
        }

        self.gate = ExtractGate(_env_int("ZIZI_CATALOG_SLOTS", 3),
                                _env_float("ZIZI_CATALOG_SLOT_WAIT", 8.0))

        self._lock = threading.Lock()
        self.n_total = 0
        self.n_anon = 0
        self.n_no_token = 0
        self.n_bad_token = 0
        self.n_429 = 0
        self.n_401 = 0

    @staticmethod
    def _quotas_from_env() -> Dict[str, Dict[str, Tuple[float, float]]]:
        q: Dict[str, Dict[str, Tuple[float, float]]] = {}
        for cls, tiers in DEFAULT_QUOTAS.items():
            q[cls] = {}
            for tier, (b, rpm) in tiers.items():
                pre = f"ZIZI_RL_{cls.upper()}_{tier.upper()}"
                q[cls][tier] = (_env_float(f"{pre}_BURST", b),
                                _env_float(f"{pre}_RPM", rpm))
        return q

    # ---- токен

    def _token_ok(self, authorization: Optional[str], q_token: Optional[str]) -> Optional[bool]:
        """None — токена не прислали вовсе; True/False — прислали верный/неверный."""
        given = None
        if authorization:
            a = authorization.strip()
            given = a[7:].strip() if a[:7].lower() == "bearer " else a
        elif q_token:
            given = q_token
        if not given:
            return None
        # compare_digest, а не ==. По той же причине, что и в резолвере: обычное сравнение
        # выходит на первом несовпавшем байте и тем самым сообщает, сколько байт угадано.
        return hmac.compare_digest(given, self.token)

    # ---- решение

    def admit(self,
              path: str,
              authorization: Optional[str] = None,
              q_token: Optional[str] = None,
              install_id: Optional[str] = None,
              client_ip: Optional[str] = None) -> Decision:
        if any(path.startswith(p) for p in OPEN_PATHS):
            return Decision(True, 0, 0, "open", "open")

        with self._lock:
            self.n_total += 1

        tok = None if self.mode == "off" else self._token_ok(authorization, q_token)
        if tok is None and self.mode != "off":
            with self._lock:
                self.n_no_token += 1
        elif tok is False:
            with self._lock:
                self.n_bad_token += 1

        token_needed = not any(path.startswith(p) for p in TOKEN_OPTIONAL)
        if self.mode == "require" and token_needed and tok is not True:
            with self._lock:
                self.n_401 += 1
            return Decision(False, 401, 0,
                            "bad token" if tok is False else "token required", "anon")

        # Опознан — это токен ВЕРНЫЙ плюс installId. Одного installId мало: заголовок
        # подделывается тривиально, он опознаёт устройство, а не право.
        identified = bool(install_id) and (tok is True or self.mode == "off")
        if identified:
            key, kind = f"i:{install_id}", "id"
        else:
            key, kind = f"a:{client_ip or 'unknown'}", "anon"
            with self._lock:
                self.n_anon += 1

        cls = class_of(path)
        ok, retry = self.limiters[cls][kind].take(key)
        if not ok:
            with self._lock:
                self.n_429 += 1
            return Decision(False, 429, max(1, int(retry + 0.999)),
                            f"rate limited: {cls}", kind)
        return Decision(True, 0, 0, "ok", kind)

    # ---- наблюдаемость

    def stats(self) -> dict:
        with self._lock:
            total = self.n_total
            d = {
                "token_mode": self.mode,
                "requests": total,
                "anon": self.n_anon,
                "anon_pct": round(100.0 * self.n_anon / total, 1) if total else 0.0,
                "no_token": self.n_no_token,
                "bad_token": self.n_bad_token,
                "rejected_429": self.n_429,
                "rejected_401": self.n_401,
            }
        d["keys"] = {cls: {tier: rl.size() for tier, rl in tiers.items()}
                     for cls, tiers in self.limiters.items()}
        d["extract"] = self.gate.stats()
        return d
