#!/usr/bin/env bash
# Выкатка zizi_catalog 1.7 (граница «клиент -> каталог»).
# Запускать НА СЕРВЕРЕ, из папки, куда положены zizi_catalog.py, zizi_guard.py и tools/.
set -euo pipefail
DEST=${DEST:-/opt/zizi}
SRC=${1:-./zizi_catalog.py}
GUARD=${GUARD:-./zizi_guard.py}
TESTS=${TESTS:-./tools/test_zizi_guard.py}

[ -f "$SRC" ]   || { echo "нет файла $SRC"; exit 1; }
# 1.7. zizi_catalog импортирует zizi_guard жёстко. Приехать без него — значит уронить ВЕСЬ
# сервис, включая резолвер: модуль подключён в то же приложение. Проверяем до рестарта.
[ -f "$GUARD" ] || { echo "нет файла $GUARD — zizi_catalog 1.7 без него не поднимется"; exit 1; }

python3 -c "import ast,sys;[ast.parse(open(f,encoding='utf-8').read()) for f in sys.argv[1:]]" "$SRC" "$GUARD"

# Тесты границы гоняются ЗДЕСЬ, на той же машине и том же python3, куда деплоим. Тест, который
# прошёл где-то ещё, про этот сервер ничего не утверждает.
if [ -f "$TESTS" ]; then
  echo "== тесты границы =="
  python3 "$TESTS" || { echo "ТЕСТЫ УПАЛИ — выкатка отменена, сервис не тронут"; exit 1; }
else
  echo "ВНИМАНИЕ: $TESTS не найден, выкатываю без прогона тестов"
fi

ts=$(date +%Y%m%d-%H%M%S)
for f in zizi_catalog.py zizi_guard.py; do
  [ -f "$DEST/$f" ] && cp "$DEST/$f" "$DEST/$f.bak-$ts" && echo "бэкап: $f.bak-$ts"
done
install -m 644 "$SRC"   "$DEST/zizi_catalog.py"
install -m 644 "$GUARD" "$DEST/zizi_guard.py"
mkdir -p "$DEST/img" "$DEST/tools"
[ -f "$TESTS" ] && install -m 644 "$TESTS" "$DEST/tools/test_zizi_guard.py"

if ! grep -q "catalog_router" "$DEST/zizi_resolver.py" 2>/dev/null; then
  echo "ВНИМАНИЕ: в zizi_resolver.py не найдено include_router(catalog_router)."
  echo "Добавьте:  from zizi_catalog import router as catalog_router"
  echo "           app.include_router(catalog_router)"
fi

# Токен каталога: по умолчанию берётся ZIZI_TOKEN, отдельная переменная не обязательна.
if ! grep -q "ZIZI_ADMIN_TOKEN" "$DEST/zizi.env" 2>/dev/null; then
  echo
  echo "ПОДСКАЗКА: ZIZI_ADMIN_TOKEN не задан — /flush по-прежнему открывается токеном из APK."
  echo "  echo \"ZIZI_ADMIN_TOKEN=\$(openssl rand -hex 24)\" >> $DEST/zizi.env"
fi

systemctl restart zizi-resolver
sleep 2
echo -n "health: "; curl -s http://127.0.0.1:8080/catalog/health; echo
echo
echo "Проверка, что граница жива (ожидается 401 при mode=require, 200 при warn/off):"
echo -n "  /catalog/chart без токена: "; curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:8080/catalog/chart?limit=1"
