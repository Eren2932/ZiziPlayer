package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlinx.coroutines.delay

internal fun libraryViewLabel(view: LibraryView): String = when (view) {
    LibraryView.COMPACT -> "Компактный список"
    LibraryView.LIST -> "Список с обложками"
    LibraryView.GRID -> "Три колонки"
    LibraryView.LARGE_GRID -> "Две колонки"
}

internal const val LIBRARY_ADD_MS = 260

/** Fixed toolbar geometry: ordinary taps cycle four views; no long-press picker. */
@Composable
internal fun LibraryToolbar(
    sortLabel: String,
    view: LibraryView,
    addExpanded: Boolean,
    searchOpen: Boolean,
    shuffle: Boolean,
    onView: (LibraryView) -> Unit,
    onSort: () -> Unit,
    onSearch: () -> Unit,
    onShuffle: () -> Unit,
    onAdd: () -> Unit,
    shuffleEnabled: Boolean = true
) {
    val p = LocalPalette.current
    // A single Plus vector rotates into a cross and back, including interrupted animations.
    val addRotation by animateFloatAsState(if (addExpanded) 135f else 0f,
        tween(LIBRARY_ADD_MS, easing = FastOutSlowInEasing), label = "library-add-rotation")
    val addTint by animateColorAsState(if (addExpanded) p.brand else p.text,
        tween(180), label = "library-add-tint")
    val shuffleTint by animateColorAsState(
        if (shuffle) p.brand else if (shuffleEnabled) p.text else p.subtext.copy(alpha = 0.5f),
        tween(180), label = "library-shuffle-tint")
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val sortWidth = (maxWidth - 192.dp).coerceAtLeast(40.dp)
        // Very narrow split-screen windows scroll rather than overlapping touch targets.
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).height(48.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.width(sortWidth).height(48.dp).clip(RoundedCornerShape(8.dp))
                .clickable(role = Role.Button, onClickLabel = "Сортировка: $sortLabel", onClick = onSort)
                .padding(end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(ZiziIcons.SortSwap, "Сортировка", tint = p.text, modifier = Modifier.size(16.dp))
                if (sortWidth > 64.dp) {
                    Spacer(Modifier.width(7.dp))
                    Text(sortLabel, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            LibraryToolButton(ZiziIcons.Search,
                if (searchOpen) "Закрыть поиск" else "Поиск по медиатеке", onSearch)
            Box(Modifier.size(48.dp).clip(CircleShape)
                .testTag("library-shuffle-toggle")
                .semantics {
                    selected = shuffle
                    contentDescription = "Перемешать медиатеку и включить"
                    stateDescription = if (shuffle) "Случайный порядок включён" else "Случайный порядок выключен"
                }
                .clickable(enabled = shuffleEnabled, role = Role.Button, onClick = onShuffle),
                contentAlignment = Alignment.Center) {
                Icon(ZiziIcons.Shuffle, null, tint = shuffleTint, modifier = Modifier.size(22.dp))
                androidx.compose.animation.AnimatedVisibility(shuffle, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp),
                    enter = fadeIn(tween(160)) + scaleIn(tween(160), initialScale = 0.5f),
                    exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.5f)) {
                    Box(Modifier.size(3.dp).clip(CircleShape).background(p.brand).testTag("library-shuffle-dot"))
                }
            }
            Box(Modifier.size(48.dp).clip(CircleShape)
                .testTag("library-add-toggle")
                .semantics {
                    selected = addExpanded
                    contentDescription = if (addExpanded) "Скрыть добавление" else "Добавить в медиатеку"
                    stateDescription = if (addExpanded) "Развёрнуто" else "Свёрнуто"
                }
                .clickable(role = Role.Button, onClick = onAdd), contentAlignment = Alignment.Center) {
                Icon(ZiziIcons.Plus, null, tint = addTint,
                    modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = addRotation })
            }
            Box(Modifier.size(48.dp).clip(CircleShape)
                .testTag("library-view-toggle")
                .semantics { contentDescription = "Вид: ${libraryViewLabel(view)}" }
                .clickable(role = Role.Button, onClickLabel = "Следующий вид",
                    onClick = { onView(view.next()) }), contentAlignment = Alignment.Center) {
                Crossfade(targetState = view, modifier = Modifier.size(21.dp),
                    animationSpec = tween(140), label = "library-view-glyph") { mode ->
                    LibraryViewGlyph(mode, p.text)
                }
            }
        }
    }
}

@Composable
private fun LibraryToolButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Icon(icon, label, tint = LocalPalette.current.text, modifier = Modifier.size(22.dp))
    }
}

/** Fixed identities, independent of the currently playing track's artwork/accent. */
internal object LibraryShortcutColors {
    val favoritesTop = Color(0xFF7653C1)
    val favoritesBottom = Color(0xFF33205D)
    val favoritesSurface = Color(0xFF201A32)
    val tracksTop = Color(0xFF13777B)
    val tracksBottom = Color(0xFF103B48)
    val tracksSurface = Color(0xFF122D2B)
    val glyph = Color(0xFFF7F5FF)
}

/** One expandable Add surface; all three actions work in all four library views. */
@Composable
internal fun LibraryAddPanel(
    enabled: Boolean,
    onCreatePlaylist: () -> Unit,
    onAddFolder: () -> Unit,
    onImport: () -> Unit
) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)
        .clip(RoundedCornerShape(16.dp)).background(p.chip).testTag("library-add-panel")) {
        LibraryAddAction(ZiziIcons.Plus, "Новый плейлист", "Собери любимые треки",
            "library-create-playlist", enabled, onCreatePlaylist)
        Box(Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp).height(1.dp)
            .background(p.subtext.copy(alpha = 0.12f)))
        LibraryAddAction(ZiziIcons.FolderMusic, "Добавить папку", "Музыка с устройства",
            "library-add-folder", enabled, onAddFolder)
        Box(Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp).height(1.dp)
            .background(p.subtext.copy(alpha = 0.12f)))
        LibraryAddAction(ZiziIcons.Download, "Импорт плейлиста", "Из файла или ссылки",
            "library-import-playlist", enabled, onImport)
    }
}

/** Minimum, not fixed height: large font sizes grow the row without overlapping targets. */
@Composable
private fun LibraryAddAction(
    icon: ImageVector, title: String, subtitle: String, tag: String,
    enabled: Boolean, onClick: () -> Unit
) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).testTag(tag)
        .clickable(enabled = enabled, role = Role.Button, onClickLabel = title, onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(p.brand.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = p.brand, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 14.sp, lineHeight = 19.sp,
                fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = p.subtext, fontSize = 12.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.width(8.dp))
        Icon(ZiziIcons.ChevronRight, null, tint = p.subtext, modifier = Modifier.size(16.dp))
    }
}

/** The four silhouettes match the supplied segmented-control reference. */
@Composable
private fun LibraryViewGlyph(view: LibraryView, tint: Color) {
    Canvas(Modifier.size(21.dp)) {
        val u = size.width / 24f
        val stroke = Stroke(1.7f * u)
        if (view == LibraryView.COMPACT || view == LibraryView.LIST) {
            repeat(4) { row ->
                val y = (3f + row * 5.5f) * u
                if (view == LibraryView.COMPACT) drawCircle(tint, 1.15f * u, Offset(2.5f * u, y + u))
                else drawRoundRect(tint, Offset(u, y - u), Size(3.8f * u, 3.8f * u), CornerRadius(0.4f * u), style = stroke)
                drawLine(tint, Offset(8f * u, y + u), Offset(22f * u, y + u), 1.9f * u, StrokeCap.Round)
            }
        } else {
            val columns = view.columns
            val box = if (columns == 3) 4.5f else 8f
            val gap = if (columns == 3) 3f else 4f
            repeat(columns) { col ->
                val x = (1.5f + col * (box + gap)) * u
                repeat(if (columns == 3) 2 else 1) { row ->
                    drawRoundRect(tint, Offset(x, (2f + row * 8f) * u), Size(box * u, box * u), CornerRadius(0.5f * u), style = stroke)
                }
                val lineY = if (columns == 3) 20f else 15f
                drawLine(tint, Offset(x, lineY * u), Offset(x + box * u, lineY * u), 1.7f * u, StrokeCap.Round)
                if (columns == 2) drawLine(tint, Offset(x, 20f * u), Offset(x + 5f * u, 20f * u), 1.7f * u, StrokeCap.Round)
            }
        }
    }
}

internal const val LIBRARY_SEARCH_MS = 180

/** Separate full-width search block. Closing never leaves an invisible focus/IME owner. */
@Composable
internal fun LibrarySearchBlock(
    open: Boolean,
    query: String,
    hint: String,
    onQuery: (String) -> Unit
) {
    val p = LocalPalette.current
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val requester = remember { FocusRequester() }
    DisposableEffect(Unit) { onDispose { focus.clearFocus(); keyboard?.hide() } }
    var text by remember(open) { mutableStateOf(query) }
    val latestQuery by rememberUpdatedState(onQuery)
    LaunchedEffect(text, open) {
        if (!open) return@LaunchedEffect
        delay(130)
        if (text != query) latestQuery(text)
    }
    LaunchedEffect(open) {
        if (open) {
            delay(LIBRARY_SEARCH_MS.toLong())
            withFrameNanos { }
            requester.requestFocus()
            keyboard?.show()
        } else {
            focus.clearFocus()
            keyboard?.hide()
        }
    }
    AnimatedVisibility(open, enter = expandVertically(tween(LIBRARY_SEARCH_MS)) + fadeIn(),
        exit = shrinkVertically(tween(LIBRARY_SEARCH_MS)) + fadeOut()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp)).background(p.chip).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(ZiziIcons.Search, null, tint = p.subtext, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            BasicTextField(value = text, onValueChange = { text = it }, enabled = open, singleLine = true,
                textStyle = TextStyle(fontFamily = ZiziFontFamily, color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.brand),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { latestQuery(text); focus.clearFocus(); keyboard?.hide() }),
                modifier = Modifier.weight(1f).focusRequester(requester).testTag("library-search-field")
                    .semantics { contentDescription = hint },
                decorationBox = { inner ->
                    Box { if (text.isEmpty()) Text(hint, color = p.subtext, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); inner() }
                })
            if (text.isNotEmpty()) LibraryToolButton(ZiziIcons.Close, "Очистить поиск") { text = ""; latestQuery("") }
        }
    }
}
