package app.ziziplayer.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.ui.LyricsPreviewGeometry as G
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.LyricsSurfaceTheme
import app.ziziplayer.ui.theme.ZiziFontFamily

private val PreviewScrollEasing = CubicBezierEasing(.22f, .0f, .12f, 1f)

/** Pure UI: both lyric destinations receive the SAME document, cursor and saved advanceMs. */
@Composable
internal fun LyricsPreviewCard(
    document: LyricsDocument,
    cursor: LyricsCursor,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!document.hasText) return
    LyricsSurfaceTheme {
        val p = LocalPalette.current
        // Exactly the full-screen seven-stop ramp, normalized over this card's own bounds.
        val background = remember(p) { p.background }
        BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            val u = G.unit(maxWidth.value)
            val density = LocalDensity.current
            val bodyStyle = TextStyle(
                fontFamily = ZiziFontFamily, fontWeight = FontWeight.ExtraBold,
                fontSize = (G.BODY_FONT * u).sp, lineHeight = (G.BODY_LINE * u).sp,
                letterSpacing = (-1f * u).sp,
                platformStyle = PlatformTextStyle(includeFontPadding = false)
            )
            // Use the actual sp->dp conversion (including Android nonlinear font scaling).
            // Large accessibility fonts grow the viewport rather than collide with the CTA.
            val lineDp = with(density) { bodyStyle.lineHeight.toDp() }
            val viewportHeight = maxOf((G.VIEWPORT * u).dp, lineDp * (G.VIEWPORT / G.BODY_LINE))
            val buttonLine = (G.BUTTON_LINE * u).sp
            val buttonHeight = maxOf((G.BUTTON_HEIGHT * u).dp,
                with(density) { buttonLine.toDp() } + (46f * u).dp)
            val touchHeight = maxOf(48.dp, buttonHeight)
            val touchExtra = (touchHeight - buttonHeight) / 2f
            val active = G.activeIndex(cursor.sameTrack, cursor.matchesDuration,
                document.matchVerified, cursor.active, document.lines.size)
            Column(Modifier.width((G.CARD_WIDTH * u).dp)
                .testTag("lyrics-preview-card")
                .clip(RoundedCornerShape((G.CORNER * u).dp))
                .background(background)
                .padding(horizontal = (G.INSET * u).dp)) {
                Spacer(Modifier.height((G.INSET * u).dp))
                Text(if (document.matchVerified) "Предпросмотр текста" else "Текст · версия не проверена",
                    color = p.text,
                    style = TextStyle(fontFamily = ZiziFontFamily, fontWeight = FontWeight.Bold,
                        fontSize = (G.HEADER_FONT * u).sp, lineHeight = (G.HEADER_LINE * u).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)),
                    // Text may trim leading on its first/last line. Reserve the measured
                    // header row explicitly; still allow wrapped/accessibility text to grow.
                    modifier = Modifier.heightIn(min = (G.HEADER_LINE * u).dp)
                        .semantics { heading() })
                Spacer(Modifier.height((G.HEADER_GAP * u).dp))
                key(document) {
                    LyricsPreviewViewport(document, cursor, active, bodyStyle, u,
                        Modifier.fillMaxWidth().height(viewportHeight))
                }
                // This is the card's ONLY opening action. The surrounding card/cues are
                // read-only; do not add a parent clickable or swallow vertical scrolling.
                // Maintain the measured visible button position AND a >=48dp touch target.
                Spacer(Modifier.height(((G.BUTTON_GAP * u).dp - touchExtra).coerceAtLeast(0.dp)))
                Box(Modifier.height(touchHeight).widthIn(min = 48.dp)
                    .testTag("lyrics-preview-open")
                    .clickable(role = Role.Button, onClickLabel = "Показать текст", onClick = onOpen),
                    contentAlignment = Alignment.Center) {
                    Box(Modifier.height(buttonHeight).testTag("lyrics-preview-button-face")
                        .clip(CircleShape).background(p.text)
                        .padding(horizontal = (47f * u).dp), contentAlignment = Alignment.Center) {
                        Text("Показать текст", color = Color.Black,
                            style = TextStyle(fontFamily = ZiziFontFamily, fontWeight = FontWeight.Bold,
                                fontSize = (G.BUTTON_FONT * u).sp, lineHeight = buttonLine,
                                platformStyle = PlatformTextStyle(includeFontPadding = false)))
                    }
                }
                Spacer(Modifier.height(((G.BOTTOM * u).dp - touchExtra).coerceAtLeast(0.dp)))
            }
        }
    }
}

/** Only visible cues are composed/measured. Changing a word never restarts line motion. */
@Composable
private fun LyricsPreviewViewport(
    document: LyricsDocument,
    cursor: LyricsCursor,
    active: Int,
    style: TextStyle,
    unit: Float,
    modifier: Modifier
) {
    val p = LocalPalette.current
    val list = rememberLazyListState(initialFirstVisibleItemIndex = active.coerceAtLeast(0))
    var previousActive by remember { mutableIntStateOf(-1) }
    val plain = remember(document) { document.plain.lineSequence().filter { it.isNotBlank() }.take(12).toList() }
    BoxWithConstraints(modifier.testTag("lyrics-preview-viewport").previewEdgeFade()) {
        val timed = document.lines.isNotEmpty()
        val anchor = maxHeight * if (timed) G.ANCHOR else G.FADE_TOP
        val viewportPx = with(LocalDensity.current) { maxHeight.roundToPx() }
        val widthPx = with(LocalDensity.current) { maxWidth.roundToPx() }
        LaunchedEffect(active, viewportPx, widthPx) {
            val previous = previousActive
            previousActive = active
            val target = active.coerceAtLeast(0)
            val visible = list.layoutInfo.visibleItemsInfo.firstOrNull { it.index == target }
            if (!G.shouldAnimate(previous, active) || visible == null) {
                list.scrollToItem(target)
            } else {
                // With top contentPadding=anchor, item offset 0 is exactly the anchor.
                // Start from the *current* measured offset, including an interrupted animation.
                list.animateScrollBy(visible.offset.toFloat(), tween(G.SCROLL_MS, easing = PreviewScrollEasing))
            }
        }
        LazyColumn(state = list, userScrollEnabled = false,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = anchor, bottom = maxHeight - anchor),
            verticalArrangement = Arrangement.spacedBy((G.CUE_GAP * unit).dp)) {
            if (timed) itemsIndexed(document.lines, key = { index, _ -> index }) { index, line ->
                val isActive = index == active
                val scale by animateFloatAsState(if (isActive) 1f else G.INACTIVE_SCALE,
                    spring(dampingRatio = .9f, stiffness = 260f), label = "previewCueScale")
                val ink by animateColorAsState(if (isActive) p.text else p.subtext,
                    tween(G.INK_MS), label = "previewCueInk")
                Text(if (isActive) lyricText(line, cursor.word, ink, pendingInk = p.subtext)
                    else AnnotatedString(line.text.ifBlank { "♪" }),
                    color = ink, style = style, maxLines = G.MAX_CUE_LINES, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().testTag("lyrics-preview-cue-$index")
                        .graphicsLayer {
                            scaleX = scale; scaleY = scale
                            transformOrigin = TransformOrigin(0f, .5f)
                        }.semantics { selected = isActive })
            } else itemsIndexed(plain) { index, line ->
                Text(line, color = p.subtext, style = style,
                    maxLines = G.MAX_CUE_LINES, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().testTag("lyrics-preview-plain-$index"))
            }
        }
    }
}

/** DstIn is isolated to the text viewport. It must not erase the card's gradient or its CTA. */
private fun Modifier.previewEdgeFade(): Modifier = clipToBounds()
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithCache {
        val mask = Brush.verticalGradient(
            0f to Color.Transparent, G.FADE_TOP to Color.Black,
            G.FADE_BOTTOM to Color.Black, 1f to Color.Transparent,
            startY = 0f, endY = size.height
        )
        onDrawWithContent {
            drawContent()
            drawRect(mask, blendMode = BlendMode.DstIn)
        }
    }
