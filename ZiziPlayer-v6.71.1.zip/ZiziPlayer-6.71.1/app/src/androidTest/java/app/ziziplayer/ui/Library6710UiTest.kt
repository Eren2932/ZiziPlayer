package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.screens.LibraryImportBanner
import app.ziziplayer.ui.screens.LibrarySearchBlock
import app.ziziplayer.ui.screens.LibraryToolbar
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Updated for 6.71.1. These tests require an Android device/emulator. */
class Library6710UiTest {
    @get:Rule val compose = createComposeRule()
    private val view = mutableStateOf(LibraryView.GRID)
    private val importing = mutableStateOf(false)
    private val shuffle = mutableStateOf(false)
    private val connected = mutableStateOf(true)

    private fun toolbar(width: Dp = 360.dp) {
        compose.setContent {
            Box(Modifier.width(width)) {
                LibraryToolbar(sortLabel = "Недавние", view = view.value, importExpanded = importing.value,
                    searchOpen = false, shuffle = shuffle.value, shuffleEnabled = connected.value,
                    onView = { view.value = it }, onSort = {}, onSearch = {},
                    onShuffle = { shuffle.value = !shuffle.value }, onImport = { importing.value = !importing.value })
            }
        }
    }
    @Test fun noLongClickAction() {
        toolbar()
        compose.onNodeWithTag("library-view-toggle")
            .assert(SemanticsMatcher.keyNotDefined(SemanticsActions.OnLongClick))
        compose.onNodeWithTag("library-view-LIST").assertDoesNotExist()
    }
    @Test fun tapCycles() {
        toolbar()
        listOf(LibraryView.LARGE_GRID, LibraryView.COMPACT, LibraryView.LIST, LibraryView.GRID).forEach { next ->
            compose.onNodeWithTag("library-view-toggle").performClick()
            compose.runOnIdle { assertEquals(next, view.value) }
        }
    }
    @Test fun shuffleFollowsExternalPlayerState() {
        toolbar()
        compose.onNodeWithTag("library-shuffle-toggle").assertIsNotSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertDoesNotExist()
        // Simulate the full player changing shuffle, without clicking the library button.
        compose.runOnIdle { shuffle.value = true }
        compose.onNodeWithTag("library-shuffle-toggle").assertIsSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertIsDisplayed()
        compose.onNodeWithTag("library-shuffle-toggle").performClick().assertIsNotSelected()
        compose.onNodeWithTag("library-shuffle-dot", useUnmergedTree = true).assertDoesNotExist()
    }
    @Test fun disconnectedShuffleCannotFakeEnabledState() {
        connected.value = false
        toolbar()
        compose.onNodeWithTag("library-shuffle-toggle").assertIsNotEnabled().performTouchInput { click() }
        compose.runOnIdle { assertFalse(shuffle.value) }
    }
    @Test fun plusIsAToggleNotImmediateImport() {
        toolbar()
        compose.onNodeWithContentDescription("Показать импорт").performClick()
        compose.runOnIdle { assertTrue(importing.value) }
        compose.onNodeWithContentDescription("Скрыть импорт").performClick()
        compose.runOnIdle { assertFalse(importing.value) }
    }
    @Test fun rapidPlusTapsSettleOnLatestState() {
        toolbar()
        compose.mainClock.autoAdvance = false
        repeat(5) { compose.onNodeWithTag("library-import-toggle").performClick(); compose.mainClock.advanceTimeByFrame() }
        compose.mainClock.advanceTimeBy(350)
        compose.mainClock.autoAdvance = true
        compose.onNodeWithContentDescription("Скрыть импорт").assertIsSelected()
        compose.runOnIdle { assertTrue(importing.value) }
    }
    @Test fun narrowToolbarDoesNotOverlap() {
        toolbar(220.dp)
        val shuffleBounds = compose.onNodeWithTag("library-shuffle-toggle").fetchSemanticsNode().boundsInRoot
        val importBounds = compose.onNodeWithTag("library-import-toggle").fetchSemanticsNode().boundsInRoot
        val viewBounds = compose.onNodeWithTag("library-view-toggle").fetchSemanticsNode().boundsInRoot
        assertTrue(shuffleBounds.right <= importBounds.left + 1f)
        assertTrue(importBounds.right <= viewBounds.left + 1f)
        compose.onNodeWithTag("library-view-toggle").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(LibraryView.LARGE_GRID, view.value) }
    }
    @Test fun searchClearsAndCloses() {
        val open = mutableStateOf(true)
        val query = mutableStateOf("")
        compose.setContent {
            Column {
                LibraryToolbar(sortLabel = "Недавние", view = view.value, importExpanded = importing.value,
                    searchOpen = open.value, shuffle = shuffle.value, onView = { view.value = it }, onSort = {},
                    onSearch = { open.value = !open.value; if (!open.value) query.value = "" },
                    onShuffle = {}, onImport = {})
                LibrarySearchBlock(open.value, query.value, "Поиск по медиатеке",
                    onQuery = { if (open.value) query.value = it })
            }
        }
        compose.onNodeWithTag("library-search-field").performTextInput("night")
        compose.waitUntil(3000) { query.value == "night" }
        compose.onNodeWithContentDescription("Очистить поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertTextEquals("")
        compose.runOnIdle { assertEquals("", query.value) }
        // Search closes from its magnifier in the toolbar; the field has no back arrow.
        compose.onNodeWithContentDescription("Закрыть поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertDoesNotExist()
        compose.runOnIdle { assertFalse(open.value); assertEquals("", query.value) }
    }
    @Test fun importBannerSupportsLargeTextAndOpensOnce() {
        var clicks = 0
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale = 1.8f)) {
                Box(Modifier.width(280.dp)) { LibraryImportBanner { clicks++ } }
            }
        }
        compose.onNodeWithText("Импорт плейлиста").assertIsDisplayed()
        compose.onNodeWithText("Из файла или ссылки").assertIsDisplayed()
        compose.onNodeWithTag("library-import-banner").performClick()
        compose.runOnIdle { assertEquals(1, clicks) }
    }
}
