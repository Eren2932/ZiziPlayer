package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlinx.coroutines.delay

internal fun libraryViewLabel(view: LibraryView): String = when (view) {
    LibraryView.COMPACT -> "Компактный список"
    LibraryView.LIST -> "Список с обложками"
    LibraryView.GRID -> "Три колонки"
    LibraryView.LARGE_GRID -> "Две колонки"
}

internal const val LIBRARY_IMPORT_MS = 260

/** Fixed toolbar geometry: ordinary taps cycle four views; no long-press picker. */
@Composable
internal fun LibraryToolbar(
    sortLabel: String,
    view: LibraryView,
    importExpanded: Boolean,
    searchOpen: Boolean,
    shuffle: Boolean,
    onView: (LibraryView) -> Unit,
    onSort: () -> Unit,
    onSearch: () -> Unit,
    onShuffle: () -> Unit,
    onImport: () -> Unit,
    shuffleEnabled: Boolean = true
) {
    val p = LocalPalette.current
    // A single Plus vector rotates into a cross and back, including interrupted animations.
    val importRotation by animateFloatAsState(if (importExpanded) 135f else 0f,
        tween(LIBRARY_IMPORT_MS, easing = FastOutSlowInEasing), label = "library-import-rotation")
    val importTint by animateColorAsState(if (importExpanded) p.brand else p.text,
        tween(180), label = "library-import-tint")
    val shuffleTint by animateColorAsState(
        if (shuffle) p.brand else if (shuffleEnabled) p.text else p.subtext.copy(alpha = 0.5f),
        tween(180), label = "library-shuffle-tint")
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val sortWidth = (maxWidth - 144.dp).coerceAtLeast(40.dp)
        // Very narrow split-screen windows scroll rather than overlapping touch targets.
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).height(48.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.width(sortWidth).height(48.dp).clip(RoundedCornerShape(8.dp))
                .clickable(role = Role.Button, onClickLabel = "Сортировка: $sortLabel", onClick = onSort)
                .padding(end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(ZiziIcons.SortSwap, "Сортировка", tint = p.text, modifier = Modifier.size(16.dp))
                if (sortWidth > 64.dp) {
                    Spacer(Modifier.width(7.dp))
                    Text(sortLabel, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            LibraryToolButton(ZiziIcons.Search,
                if (searchOpen) "Закрыть поиск" else "Поиск по медиатеке", onSearch)
            Box(Modifier.size(36.dp, 48.dp).clip(CircleShape)
                .testTag("library-shuffle-toggle")
                .semantics {
                    selected = shuffle
                    contentDescription = if (shuffle) "Выключить перемешивание" else "Включить перемешивание"
                    stateDescription = if (shuffle) "Включено" else "Выключено"
                }
                .clickable(enabled = shuffleEnabled, role = Role.Button, onClick = onShuffle),
                contentAlignment = Alignment.Center) {
                Icon(ZiziIcons.Shuffle, null, tint = shuffleTint, modifier = Modifier.size(22.dp))
                androidx.compose.animation.AnimatedVisibility(shuffle, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp),
                    enter = fadeIn(tween(160)) + scaleIn(tween(160), initialScale = 0.5f),
                    exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.5f)) {
                    Box(Modifier.size(3.dp).clip(CircleShape).background(p.brand).testTag("library-shuffle-dot"))
                }
            }
            Box(Modifier.size(36.dp, 48.dp).clip(CircleShape)
                .testTag("library-import-toggle")
                .semantics {
                    selected = importExpanded
                    contentDescription = if (importExpanded) "Скрыть импорт" else "Показать импорт"
                    stateDescription = if (importExpanded) "Развёрнуто" else "Свёрнуто"
                }
                .clickable(role = Role.Button, onClick = onImport), contentAlignment = Alignment.Center) {
                Icon(ZiziIcons.Plus, null, tint = importTint,
                    modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = importRotation })
            }
            Box(Modifier.size(36.dp, 48.dp).clip(CircleShape)
                .testTag("library-view-toggle")
                .semantics { contentDescription = "Вид: ${libraryViewLabel(view)}" }
                .clickable(role = Role.Button, onClickLabel = "Следующий вид",
                    onClick = { onView(view.next()) }), contentAlignment = Alignment.Center) {
                Crossfade(targetState = view, modifier = Modifier.size(21.dp),
                    animationSpec = tween(140), label = "library-view-glyph") { mode ->
                    LibraryViewGlyph(mode, p.text)
                }
            }
        }
    }
}

@Composable
private fun LibraryToolButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(Modifier.size(36.dp, 48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Icon(icon, label, tint = LocalPalette.current.text, modifier = Modifier.size(22.dp))
    }
}

/** Compact two-line action; height grows with font scale instead of clipping its content. */
@Composable
internal fun LibraryImportBanner(onOpen: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).heightIn(min = 64.dp)
        .clip(RoundedCornerShape(12.dp)).background(p.chip)
        .testTag("library-import-banner")
        .clickable(role = Role.Button, onClickLabel = "Импортировать плейлист", onClick = onOpen)
        .padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(p.brand.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center) {
            Icon(ZiziIcons.Download, null, tint = p.brand, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Импорт плейлиста", color = p.text, fontSize = 14.sp, lineHeight = 18.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Из файла или ссылки", color = p.subtext, fontSize = 12.sp, lineHeight = 16.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Icon(ZiziIcons.ChevronRight, null, tint = p.subtext, modifier = Modifier.size(16.dp))
    }
}

/** The four silhouettes match the supplied segmented-control reference. */
@Composable
private fun LibraryViewGlyph(view: LibraryView, tint: Color) {
    Canvas(Modifier.size(21.dp)) {
        val u = size.width / 24f
        val stroke = Stroke(1.7f * u)
        if (view == LibraryView.COMPACT || view == LibraryView.LIST) {
            repeat(4) { row ->
                val y = (3f + row * 5.5f) * u
                if (view == LibraryView.COMPACT) drawCircle(tint, 1.15f * u, Offset(2.5f * u, y + u))
                else drawRoundRect(tint, Offset(u, y - u), Size(3.8f * u, 3.8f * u), CornerRadius(0.4f * u), style = stroke)
                drawLine(tint, Offset(8f * u, y + u), Offset(22f * u, y + u), 1.9f * u, StrokeCap.Round)
            }
        } else {
            val columns = view.columns
            val box = if (columns == 3) 4.5f else 8f
            val gap = if (columns == 3) 3f else 4f
            repeat(columns) { col ->
                val x = (1.5f + col * (box + gap)) * u
                repeat(if (columns == 3) 2 else 1) { row ->
                    drawRoundRect(tint, Offset(x, (2f + row * 8f) * u), Size(box * u, box * u), CornerRadius(0.5f * u), style = stroke)
                }
                val lineY = if (columns == 3) 20f else 15f
                drawLine(tint, Offset(x, lineY * u), Offset(x + box * u, lineY * u), 1.7f * u, StrokeCap.Round)
                if (columns == 2) drawLine(tint, Offset(x, 20f * u), Offset(x + 5f * u, 20f * u), 1.7f * u, StrokeCap.Round)
            }
        }
    }
}

internal const val LIBRARY_SEARCH_MS = 180

/** Separate full-width search block. Closing never leaves an invisible focus/IME owner. */
@Composable
internal fun LibrarySearchBlock(
    open: Boolean,
    query: String,
    hint: String,
    onQuery: (String) -> Unit
) {
    val p = LocalPalette.current
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val requester = remember { FocusRequester() }
    DisposableEffect(Unit) { onDispose { focus.clearFocus(); keyboard?.hide() } }
    var text by remember(open) { mutableStateOf(query) }
    val latestQuery by rememberUpdatedState(onQuery)
    LaunchedEffect(text, open) {
        if (!open) return@LaunchedEffect
        delay(130)
        if (text != query) latestQuery(text)
    }
    LaunchedEffect(open) {
        if (open) {
            delay(LIBRARY_SEARCH_MS.toLong())
            withFrameNanos { }
            requester.requestFocus()
            keyboard?.show()
        } else {
            focus.clearFocus()
            keyboard?.hide()
        }
    }
    AnimatedVisibility(open, enter = expandVertically(tween(LIBRARY_SEARCH_MS)) + fadeIn(),
        exit = shrinkVertically(tween(LIBRARY_SEARCH_MS)) + fadeOut()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp)).background(p.chip).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(ZiziIcons.Search, null, tint = p.subtext, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            BasicTextField(value = text, onValueChange = { text = it }, enabled = open, singleLine = true,
                textStyle = TextStyle(fontFamily = ZiziFontFamily, color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.brand),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { latestQuery(text); focus.clearFocus(); keyboard?.hide() }),
                modifier = Modifier.weight(1f).focusRequester(requester).testTag("library-search-field")
                    .semantics { contentDescription = hint },
                decorationBox = { inner ->
                    Box { if (text.isEmpty()) Text(hint, color = p.subtext, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); inner() }
                })
            if (text.isNotEmpty()) LibraryToolButton(ZiziIcons.Close, "Очистить поиск") { text = ""; latestQuery("") }
        }
    }
}
