package app.ziziplayer.ui

/** Import is the only expandable library panel; view selection is tap-only since 6.71.1. */
data class LibraryPanelState(val importExpanded: Boolean = false) {
    val isOpen: Boolean get() = importExpanded
    fun dismissTop(): LibraryPanelState = copy(importExpanded = false)
}
