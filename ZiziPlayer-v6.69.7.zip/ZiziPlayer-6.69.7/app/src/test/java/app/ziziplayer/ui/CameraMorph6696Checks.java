package app.ziziplayer.ui;

/** Executes production material math, not a model reimplemented in Python. */
public final class CameraMorph6696Checks {
    private static int assertions;
    private static void ok(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
    private static void near(float a, float b, float epsilon, String message) {
        ok(Float.isFinite(a) && Float.isFinite(b) && Math.abs(a-b)<=epsilon,
            message+": "+a+" vs "+b);
    }
    private static CameraMorphGeometry.Frame frame(float p, CameraMorphGeometry.Target target) {
        return CameraMorphGeometry.frame(716,315.04f,1,369.04f*p,540,164,8,369.04f,110,target);
    }
    public static void main(String[] args) {
        assertions=0;
        near(CameraMorphGeometry.blurFraction(0),0,0,"expanded artwork is sharp");
        near(CameraMorphGeometry.blurFraction(Float.NaN),0,0,"NaN safe");
        near(CameraMorphGeometry.blurFraction(-4),0,0,"negative safe");
        near(CameraMorphGeometry.blurFraction(1),.075f,.000001f,"blur bounded");
        near(CameraMorphGeometry.blurFraction(4),.075f,.000001f,"overscroll safe");
        near(CameraMorphGeometry.blurFraction(.0001f)/.0001f,0,.0001f,"blur starts with zero slope");
        near((CameraMorphGeometry.blurFraction(.65f)-CameraMorphGeometry.blurFraction(.6499f))/.0001f,
            0,.003f,"blur plateaus with zero slope");
        float previousBlur=0;
        for(int i=0;i<=10000;i++) {
            float blur=CameraMorphGeometry.blurFraction(i/10000f);
            ok(blur>=previousBlur-.0000002f && blur>=0 && blur<=.075001f,"monotone bounded blur");
            ok(Math.abs(blur-previousBlur)<.00005f,"no blur discontinuity on return");
            previousBlur=blur;
        }
        CameraMorphGeometry.Target[] targets={
            new CameraMorphGeometry.Target(513,48,567,102),
            new CameraMorphGeometry.Target(30,48,84,102),
            new CameraMorphGeometry.Target(996,48,1050,102),
            new CameraMorphGeometry.Target(478,48,602,102),
            new CameraMorphGeometry.Target(510,50,570,110),null
        };
        float maxStep=0;
        for(CameraMorphGeometry.Target target:targets) {
            float[][] forward=new float[2001][27];
            for(int i=0;i<=2000;i++) {
                float p=i/2000f;
                CameraMorphGeometry.Frame f=frame(p,target);
                CameraMorphGeometry.Material m=CameraMorphGeometry.material(target,f);
                ok(m.contactEnd>=0 && m.contactEnd<=.5f && m.blendEnd<=.78001f,"localized contact stops");
                ok(m.contactBlack>=m.bodyBlack && m.contactBlack<=1 && m.bodyBlack>=0,"bounded material");
                if(p<=.78f) {
                    near(m.bodyBlack,0,0,"no full-image dimmer before final absorption");
                    near(m.blackAt(.5f-m.axisX*.35f,.5f-m.axisY*.35f),0,.000001f,
                        "body opposite the camera retains luminance");
                }
                forward[i][0]=CameraMorphGeometry.blurFraction(f.progress);
                forward[i][1]=f.imageAlpha;
                for(int y=0;y<5;y++) for(int x=0;x<5;x++) {
                    int k=2+y*5+x;
                    float alpha=m.blackAt(.1f+x*.2f,.1f+y*.2f);
                    ok(alpha>=0 && alpha<=1,"black opacity finite and bounded");
                    forward[i][k]=alpha;
                    if(i>0) maxStep=Math.max(maxStep,Math.abs(alpha-forward[i-1][k]));
                }
                if(target==null) {
                    near(m.contactBlack,0,0,"no imaginary camera shading");
                    near(m.bodyBlack,0,0,"fallback remains undimmed");
                }
            }
            // Exact same progress values on the return journey, including multiple reversals.
            for(int i=2000;i>=0;i--) {
                CameraMorphGeometry.Frame f=frame(i/2000f,target);
                CameraMorphGeometry.Material m=CameraMorphGeometry.material(target,f);
                near(CameraMorphGeometry.blurFraction(f.progress),forward[i][0],0,"reverse blur bit exact");
                near(f.imageAlpha,forward[i][1],0,"reverse visibility bit exact");
                for(int y=0;y<5;y++) for(int x=0;x<5;x++)
                    near(m.blackAt(.1f+x*.2f,.1f+y*.2f),forward[i][2+y*5+x],0,"reverse mask bit exact");
            }
            if(target!=null) near(frame(1,target).bottomBlack,1,0,"fully absorbed endpoint");
        }
        ok(maxStep<.025f,"no contact on/off flash, max step="+maxStep);
        // White/uniform source: a normalized Gaussian cannot lower luminance. These tests
        // check the overlay's zero-body-alpha policy; real RenderEffect is tested on Android.
        for(float p:new float[]{.18f,.35f,.50f,.70f}) {
            CameraMorphGeometry.Material m=CameraMorphGeometry.material(targets[0],frame(p,targets[0]));
            near(m.blackAt(.5f,.85f),0,.000001f,"white artwork body must not turn grey");
        }
        System.out.println("PASS: "+assertions+" material assertions; max mask step="+maxStep+
            " over progress step 0.0005 (not Android rendering)");
    }
}
