package app.ziziplayer.ui.components

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import app.ziziplayer.ui.CameraMorphGeometry as M
import kotlin.math.abs

/** One artwork instance outside LazyColumn clipping, inside the destination's normal z-order.
 * No pointer input, timer, bitmap capture, global overlay window or second image request.
 * Blur is on the inner rectangular image layer; shape/safety clips and contact ink stay sharp.
 */
@Composable
internal fun CollectionCoverMorphOverlay(
    camera: CameraCutoutSnapshot,
    maximum: Dp,
    minimum: Dp,
    coverTop: Dp,
    corner: Dp,
    status: Dp,
    fraction: () -> Float,
    scroll: () -> Float,
    artwork: @Composable () -> Unit
) {
    val density = LocalDensity.current
    var origin by remember { mutableStateOf<Offset?>(null) }
    val maxPx = with(density) { maximum.toPx() }
    val minPx = with(density) { minimum.toPx() }
    val statusPx = with(density) { status.toPx() }
    val topPx = with(density) { coverTop.toPx() }
    val radiusPx = with(density) { corner.toPx() }
    val edgePx = with(density) { 1.dp.toPx() }
    BoxWithConstraints(Modifier.fillMaxSize().clearAndSetSemantics { }
        .onGloballyPositioned { origin = it.positionInWindow() }) {
        val widthPx = with(density) { maxWidth.toPx() }
        // Do not aim at a display-space hole from an inset, translated or preview-sized page.
        val aligned = origin?.let { abs(it.x) <= 1f && abs(it.y) <= 1f } == true &&
            abs(widthPx - camera.windowWidth) <= 1f && abs(statusPx - camera.statusTop) <= 1f
        val target = if (aligned) camera.target else null
        val outline = if (aligned) camera.outline else null
        val frame = remember(maxPx, minPx, statusPx, topPx, radiusPx, widthPx, target, fraction, scroll) {
            derivedStateOf {
                M.frame(maxPx, minPx, fraction(), scroll(), widthPx * .5f, statusPx + topPx,
                    radiusPx, minPx + topPx, statusPx, target)
            }
        }
        val neck = remember { Path() }
        Box(Modifier.fillMaxSize().drawWithCache {
            val safe = Path().apply {
                addRect(Rect(0f, statusPx, size.width, size.height))
                // Only the actual cutout corridor may paint above the content inset.
                // A corner-camera trajectory must never obscure the clock/network icons.
                if (target != null) addRect(Rect(target.left - edgePx, target.top - edgePx,
                    target.right + edgePx, statusPx + edgePx))
            }
            onDrawWithContent { clipPath(safe) { this@onDrawWithContent.drawContent() } }
        }) {
            Canvas(Modifier.fillMaxSize()) {
                val f = frame.value
                if (target != null && outline != null) {
                    val points = M.bridge(target, f)
                    if (points != null) {
                        neck.reset()
                        neck.moveTo(points[0], points[1])
                        neck.cubicTo(points[2], points[3], points[4], points[5], points[6], points[7])
                        neck.lineTo(points[8], points[9])
                        neck.cubicTo(points[10], points[11], points[12], points[13], points[14], points[15])
                        neck.close()
                        drawPath(neck, Color.Black, alpha = f.anchorAlpha * f.imageAlpha)
                    }
                    // At completion only the real system contour remains, not its bounding oval.
                    drawPath(outline, Color.Black, alpha = f.anchorAlpha)
                }
            }
            Box(Modifier.size(maximum).testTag("collection:morph-artwork")
                .graphicsLayer {
                    val f = frame.value
                    transformOrigin = TransformOrigin(0f, 0f)
                    translationX = f.left()
                    translationY = f.top()
                    scaleX = if (size.width > 0) f.width / size.width else 0f
                    scaleY = if (size.height > 0) f.height / size.height else 0f
                    alpha = f.imageAlpha
                    clip = true
                    shape = CameraCoverShape(f.radius, f.width, f.height)
                }
                .drawWithCache {
                    val material = M.material(target, frame.value)
                    // Normalized camera-facing axis -> local image coordinates. The opaque
                    // stop matches the bridge's contact points, not a fixed 28%-black cap.
                    val start = Offset((.5f + material.axisX*.5f)*size.width,
                        (.5f + material.axisY*.5f)*size.height)
                    val end = Offset((.5f - material.axisX*.5f)*size.width,
                        (.5f - material.axisY*.5f)*size.height)
                    val stops = Array(19) { index ->
                        val depth = when (index) {
                            0 -> 0f
                            18 -> 1f
                            else -> material.contactEnd +
                                (material.blendEnd-material.contactEnd)*(index-1)/16f
                        }
                        val alpha = material.contactBlack + (material.bodyBlack-material.contactBlack) *
                            M.smoother((depth-material.contactEnd)/(material.blendEnd-material.contactEnd))
                        depth to Color.Black.copy(alpha = alpha.coerceIn(0f,1f))
                    }
                    val contact = Brush.linearGradient(*stops, start = start, end = end)
                    onDrawWithContent {
                        drawContent()
                        if (material.contactBlack > 0f || material.bodyBlack > 0f) drawRect(contact)
                    }
                }) {
                // Keep this child mounted even at radius zero: no image reload or layer swap
                // when reversing direction. CLAMP does not mix transparent black into edges.
                // API 26-30: clean, reversible spatial blend; Android has no RenderEffect there.
                Box(Modifier.fillMaxSize().graphicsLayer {
                    val radius = size.minDimension * M.blurFraction(frame.value.progress)
                    renderEffect = if (Build.VERSION.SDK_INT >= 31 && radius > 0f)
                        BlurEffect(radius, radius, TileMode.Clamp) else null
                }) { artwork() }
            }
            if (CameraMorphDebug.outlineEnabled && target != null && outline != null) {
                Canvas(Modifier.fillMaxSize()) {
                    drawPath(outline, Color.Cyan, style = Stroke(edgePx))
                    drawRect(Color.Magenta, topLeft = Offset(target.left, target.top),
                        size = Size(target.width(), target.height()), style = Stroke(edgePx * .5f))
                }
            }
        }
    }
}

/** Compensate corner radii for non-uniform scale: a compact pill stays a pill, not an ellipse. */
private data class CameraCoverShape(val radius: Float, val width: Float, val height: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = CornerRadius(if (width > 0) radius * size.width / width else 0f,
            if (height > 0) radius * size.height / height else 0f)
        return Outline.Rounded(RoundRect(0f, 0f, size.width, size.height, r, r, r, r))
    }
}
