@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.DevAccess
import app.ziziplayer.data.remote.RemoteQuality
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.ScanProgress
import app.ziziplayer.data.SortMode
import android.content.Context
import android.content.Intent
import android.widget.Toast
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.ui.DownloadsInfo
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.WipeKind
import app.ziziplayer.ui.WipeProgress
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.CHIP_ROW_INSET
import app.ziziplayer.ui.components.CHIP_SPACING
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.PillChip
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.NowPlayingBadge
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.pow
import kotlin.math.roundToInt
import app.ziziplayer.ui.components.ZiziIcons

@Composable
internal fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
internal fun MenuItem(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    trailing: String? = null,
    /** 6.17.0: вторая строка — там, где одного глагола мало, чтобы понять последствия. */
    subtitle: String? = null,
    /** 6.17.0: пункт что-то убирает. Красный не для красоты: он тормозит палец. */
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val color = tint ?: if (danger) DANGER else p.text
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = if (subtitle == null) 15.dp else 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
        }
        if (trailing != null) Text(trailing, color = p.subtext, fontSize = 14.sp)
    }
}

/** Один красный на всё приложение: он уже был тремя копиями в диалогах. */
internal val DANGER = Color(0xFFFF6B6B)

/**
 * [scrollable] exists for the queue. A LazyColumn nested inside a verticalScroll parent is the
 * classic Compose performance trap: the two scrollables fight over the same gesture and the lazy
 * list loses most of its item reuse, so a 100 track queue scrolled worse than the 3000 track
 * library. The queue passes false and drives its own LazyColumn.
 */
/**
 * 6.24.0: у листа ОДНО состояние, и закрывается он одним движением.
 *
 * Меню трека открывалось с `partial = true`, то есть с двумя якорями: раскрытый и половинный.
 * Системный жест «назад» в такой шторке сначала сжимает её до половины и только вторым жестом
 * закрывает. Со стороны это выглядит как заедание — человек сделал жест закрытия, окно осталось
 * на экране, и он делает жест ещё раз. Двух логик закрытия у одного окна быть не должно, поэтому
 * половинный якорь убран вместе с параметром: любое раскрытие теперь уезжает вниз с первого
 * жеста, и уезжает анимацией Material (её проигрывает сам ModalBottomSheet перед
 * onDismissRequest), а не мгновенным исчезновением.
 */
@Composable
internal fun ZiziSheetScaffold(
    onDismiss: () -> Unit,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        contentColor = p.text,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        dragHandle = {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(p.subtext.copy(alpha = 0.45f)))
            }
        }
    ) {
        // Content scrolls: the settings sheet is taller than a phone screen in landscape and the
        // v5 version simply clipped the last rows away.
        Column(
            Modifier
                .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(bottom = 26.dp),
            content = content
        )
    }
}

/**
 * Строка «Скачать» — 6.24.0, переписана целиком.
 *
 * Было так: пять разных [MenuItem] в `when`. Смена состояния меняла ОДНОВРЕМЕННО иконку, текст,
 * наличие второй строки и, из-за второй строки, высоту ряда — мгновенно, без перехода. Список под
 * ним подпрыгивал, проценты дёргались рывками (загрузчик публиковал их десятки раз в секунду).
 * Именно это «режет глаза»: глаз ловит не анимацию, а скачок.
 *
 * Стало так:
 *  - ряд ОДИН и высота у него фиксированная, вторая строка есть всегда. Прыгать больше нечему;
 *  - смена фазы (нет копии → в очереди → качается → скачано) — это crossfade иконки и текста,
 *    ~200 мс. Внутри фазы текст меняется обычной перерисовкой: анимировать каждый процент значит
 *    мигать двадцать раз в секунду;
 *  - прогресс нарисован кольцом вокруг иконки и едет через animateFloatAsState, поэтому шаг
 *    процента виден как движение, а не как подмена цифры. Когда длина неизвестна, кольцо
 *    крутится — это честное «идёт, длину не сказали», а не мёртвое «…».
 */
@Composable
private fun DownloadMenuItem(
    status: DownloadStatus,
    /**
     * Реальный путь скачанного файла — «Музыка/Zizi/Артист - Трек.m4a».
     *
     * 6.24.1. До этого подпись говорила «файл лежит в Музыка/Zizi» — константой, одинаковой для
     * всех и не связанной с тем, что произошло на самом деле. На прошивке, где загрузка ушла в
     * запасную папку, подпись врала; там, где не ушла никуда, — врала тоже. Теперь строка
     * приходит из [OfflineStore] и показывает то, что действительно есть на диске.
     */
    where: String?,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onRemove: () -> Unit
) {
    // Локальный файл: качать нечего, и пункт-заглушка тут был бы враньём.
    if (status is DownloadStatus.Local) return

    val p = LocalPalette.current
    val phase = when (status) {
        is DownloadStatus.Running -> DownloadPhase.WORKING
        DownloadStatus.Queued -> DownloadPhase.QUEUED
        DownloadStatus.Done -> DownloadPhase.READY
        is DownloadStatus.Failed -> DownloadPhase.BROKEN
        else -> DownloadPhase.IDLE
    }
    val percent = (status as? DownloadStatus.Running)?.percent ?: -1

    val progress by animateFloatAsState(
        targetValue = when (phase) {
            DownloadPhase.READY -> 1f
            DownloadPhase.WORKING -> if (percent >= 0) percent / 100f else 0f
            else -> 0f
        },
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "download-progress"
    )
    val ring by animateFloatAsState(
        targetValue = if (phase == DownloadPhase.WORKING || phase == DownloadPhase.QUEUED) 1f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "download-ring"
    )
    val tint by animateColorAsState(
        targetValue = when (phase) {
            DownloadPhase.READY -> p.accent
            DownloadPhase.BROKEN -> DANGER
            else -> p.text
        },
        animationSpec = tween(durationMillis = 260),
        label = "download-tint"
    )
    val spin = rememberInfiniteTransition(label = "download-spin")
    val sweepStart by spin.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1100, easing = LinearEasing)),
        label = "download-sweep"
    )

    val onClick: () -> Unit = when (phase) {
        DownloadPhase.WORKING, DownloadPhase.QUEUED -> onCancel
        DownloadPhase.READY -> onRemove
        else -> onDownload
    }

    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            if (ring > 0.01f) Canvas(Modifier.size(24.dp).alpha(ring)) {
                val stroke = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
                drawArc(
                    color = p.subtext.copy(alpha = 0.28f),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = stroke
                )
                if (percent >= 0) drawArc(
                    color = p.accent,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = stroke
                ) else drawArc(
                    color = p.accent,
                    startAngle = sweepStart,
                    sweepAngle = 96f,
                    useCenter = false,
                    style = stroke
                )
            }
            Crossfade(targetState = phase, animationSpec = tween(durationMillis = 200), label = "download-icon") { current ->
                Icon(
                    imageVector = when (current) {
                        DownloadPhase.WORKING, DownloadPhase.QUEUED -> ZiziIcons.Stop
                        DownloadPhase.READY -> ZiziIcons.DownloadDone
                        else -> ZiziIcons.Download
                    },
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(
                        if (current == DownloadPhase.WORKING || current == DownloadPhase.QUEUED) 11.dp else 22.dp
                    )
                )
            }
        }
        Spacer(Modifier.width(18.dp))
        AnimatedContent(
            targetState = phase,
            transitionSpec = {
                fadeIn(animationSpec = tween(durationMillis = 220)) togetherWith
                    fadeOut(animationSpec = tween(durationMillis = 160))
            },
            label = "download-text",
            modifier = Modifier.weight(1f)
        ) { current ->
            Column {
                Text(
                    text = when (current) {
                        DownloadPhase.WORKING -> "Остановить загрузку"
                        DownloadPhase.QUEUED -> "Отменить, пока не началось"
                        DownloadPhase.READY -> "Удалить загрузку"
                        DownloadPhase.BROKEN -> "Скачать ещё раз"
                        DownloadPhase.IDLE -> "Скачать"
                    },
                    color = tint,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Text(
                    text = when (current) {
                        // Проценты не дублируются в подписи: цифра справа и так одна на строку.
                        DownloadPhase.WORKING -> "Сохраняется в " + OfflineStoreLabel
                        DownloadPhase.QUEUED -> "В очереди: качаем по два трека за раз"
                        DownloadPhase.READY -> "Файл: " + (where ?: OfflineStoreLabel)
                        DownloadPhase.BROKEN -> (status as? DownloadStatus.Failed)?.message ?: "не удалось"
                        DownloadPhase.IDLE -> "Файлом в " + OfflineStoreLabel + " · играет без сети"
                    },
                    color = p.subtext,
                    fontSize = 12.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        // Цифра читается из status напрямую: внутри фазы это обычная перерисовка одного Text,
        // без анимации и без мигания. Анимировать каждый процент — это мигать двадцать раз в
        // секунду; двигаться должно кольцо, а не текст.
        if (phase == DownloadPhase.WORKING && percent >= 0) {
            Text("$percent%", color = p.subtext, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private enum class DownloadPhase { IDLE, QUEUED, WORKING, READY, BROKEN }

/** Одна строка на всё приложение: путь к загрузкам показывается человеку в четырёх местах. */
private const val OfflineStoreLabel = "Музыка/Zizi"

/**
 * Открыть скачанный файл системным приложением.
 *
 * `createChooser` вместо прямого старта: единственного «правильного» приложения для аудио в
 * Android нет, а список выбора попутно показывает человеку, что файл существует и его видят
 * другие программы. Разрешение на чтение выдаётся флагом в самом интенте — без него сторонний
 * плеер получит SecurityException у себя, и это выглядело бы как «Zizi опять сломался».
 */
private fun showDownloadedFile(context: Context, track: TrackEntity) {
    val intent = OfflineStore.viewIntent(context, track)
    if (intent == null) {
        Toast.makeText(context, "Файла нет на месте — скачай ещё раз", Toast.LENGTH_LONG).show()
        return
    }
    runCatching { context.startActivity(Intent.createChooser(intent, "Показать файл")) }
        .onFailure { Toast.makeText(context, "Нет приложения, которое откроет файл", Toast.LENGTH_LONG).show() }
}

/**
 * Открыть папку «Музыка/Zizi» в проводнике.
 *
 * Единого интента «открой папку» в Android нет: у Pixel это `DocumentsContract`, у части
 * прошивок — свой файловый менеджер, у некоторых нет ничего. Поэтому кандидаты перебираются по
 * очереди, а если не подошёл ни один — человек получает путь текстом. Тоже ответ, и он лучше
 * молчания по нажатию.
 */
private fun openDownloadsFolder(context: Context) {
    for (intent in OfflineStore.folderIntents()) {
        if (runCatching { context.startActivity(intent) }.isSuccess) return
    }
    Toast.makeText(context, "Файлы лежат в «Внутренняя память/Музыка/Zizi»", Toast.LENGTH_LONG).show()
}

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onOpenEqualizer: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(14.dp))
            // 6.24.4: ползунок «Реверб %» отсюда ушёл — теперь это один из параметров тракта, а
            // не отдельная ручка с пятью прошивочными пресетами. Лист остался тем, чем был:
            // быстрым доступом к скорости и тональности, из которого одна кнопка ведёт вглубь.
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.chip)
                    .clickable(onClick = onOpenEqualizer)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Эквалайзер", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "10 полос, ревер, объём, «под водой», 8D",
                            color = p.subtext, fontSize = 12.sp
                        )
                    }
                    Text("Открыть", color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", current?.let { "Осталось $it мин" } ?: "Выключен")
        listOf(10, 15, 20, 30, 45, 60, 90).forEach { minutes ->
            MenuItem(ZiziIcons.Moon, "$minutes минут") { onPick(minutes); onDismiss() }
        }
        if (current != null) {
            MenuItem(ZiziIcons.Close, "Выключить таймер") { onPick(null); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
    /** 6.17.0: тот же лист обслуживает «добавить», «перенести» и «сохранить сборник». */
    title: String = "Добавить в плейлист",
    subtitle: String = "",
    /** Заготовка имени для нового плейлиста: имя сборника или папки, откуда пришли. */
    defaultName: String = ""
) {
    val p = LocalPalette.current
    var newName by remember(defaultName) { mutableStateOf(defaultName) }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle(title)
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                color = p.subtext,
                fontSize = 12.5.sp,
                modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 6.dp)
            )
        }
        if (playlists.isEmpty()) {
            Text(
                "Плейлистов пока нет — назови новый ниже",
                color = p.subtext,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }
        playlists.forEach { playlist ->
            MenuItem(ZiziIcons.Queue, playlist.name) { onPick(playlist.id); onDismiss() }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.brand,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.brand
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = ""; onDismiss() } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* --------------------------------------------------------- множественный выбор (6.17.0) */

/**
 * «Ещё» для выделенных треков: всё, что переносит и убирает.
 *
 * Разделение сделано по цене ошибки. Наверху — перенос, он обратим одним движением. Ниже, за
 * отступом и красным цветом, то, что что-то убирает; каждое такое действие уходит в снек с
 * «Вернуть», потому что пачка из сорока треков — это не тот случай, когда человек согласен
 * восстанавливать руками.
 */
@Composable
fun SelectionMenuSheet(
    count: Int,
    inPlaylist: PlaylistEntity?,
    onMove: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onUnsave: () -> Unit,
    onHide: () -> Unit,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Выбрано: $count")
        MenuItem(
            ZiziIcons.QueueAdd,
            if (inPlaylist != null) "Перенести в другой плейлист" else "Перенести в плейлист",
            subtitle = if (inPlaylist != null) "Уйдут из «${inPlaylist.name}»"
            else "Из медиатеки в плейлист, без дублей в «Треках»"
        ) { onMove(); onDismiss() }
        if (inPlaylist != null) {
            MenuItem(ZiziIcons.QueueRemove, "Убрать из «${inPlaylist.name}»", danger = true) {
                onRemoveFromPlaylist(); onDismiss()
            }
        }
        MenuItem(
            ZiziIcons.CloudOff,
            "Убрать из медиатеки",
            subtitle = "Только для сетевых треков: строка останется в поиске",
            danger = true
        ) { onUnsave(); onDismiss() }
        MenuItem(
            ZiziIcons.EyeOff,
            "Убрать из Zizi",
            subtitle = "Файлы на устройстве не трогаем",
            danger = true
        ) { onHide(); onDismiss() }
    }
}

/**
 * Меню папки (6.17.0).
 *
 * Появилось из-за папки «YouTube Music». Она не настоящая: это группировка сетевых треков по
 * источнику, и до 6.17.0 из неё нельзя было ничего достать — только слушать вперемешку. Отсюда
 * содержимое папки уходит в нормальный плейлист.
 */
@Composable
fun FolderMenuSheet(
    folder: String,
    label: String,
    count: Int,
    remote: Boolean,
    onOpenSelection: () -> Unit,
    onMoveAll: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle(label)
        MenuItem(ZiziIcons.CheckDouble, "Выбрать треки", subtitle = "Отметить нужные и перенести") {
            onOpenSelection(); onDismiss()
        }
        MenuItem(
            ZiziIcons.QueueAdd,
            "Перенести всё в плейлист",
            subtitle = if (remote) "Все $count — из папки в плейлист"
            else "Локальные файлы останутся на диске, в плейлист уйдут ссылки на них"
        ) { onMoveAll(); onDismiss() }
        // 6.27.1: папку теперь можно переименовать и удалить.
        //
        // Переименование ЭКРАННОЕ, и в подписи это сказано прямо, а не спрятано. Настоящее
        // `DocumentsContract.renameDocument` меняет documentId дерева, а долговременный доступ
        // выдан именно на старый id: приложение переименовало бы папку и потеряло к ней доступ
        // до повторного выбора через системный диалог. Обещать «переименую папку» и молча
        // отвалиться от неё — хуже, чем честно переименовать её у себя на экране.
        MenuItem(
            ZiziIcons.Edit,
            "Переименовать",
            subtitle = "Имя только в плеере · на диске папка останется «$folder»"
        ) { onRename(); onDismiss() }
        if (!remote) {
            MenuItem(
                ZiziIcons.Trash,
                "Удалить папку с устройства",
                subtitle = "Файлов: $count · насовсем, отменить нельзя",
                tint = DANGER
            ) { onDelete(); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ track menu */

@Composable
fun TrackMenuSheet(
    favorite: Boolean,
    plays: Int,
    sleepMinutesLeft: Int?,
    track: TrackEntity,
    inPlaylist: PlaylistEntity?,
    queueSize: Int,
    download: DownloadStatus,
    onDismiss: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onQueue: () -> Unit,
    onGoToArtist: () -> Unit,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    onRemoveDownload: () -> Unit,
    onInfo: () -> Unit,
    /**
     * 6.33.0. «Папки» — из плеера, где ряда таблеток больше нет.
     *
     * Необязательный: этот же лист открывают библиотека и поиск, а там пункт «уйти в папки»
     * ведёт туда, где человек уже стоит. Null — пункта нет, а не пункт-заглушка.
     */
    onFolders: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    // Один поход к индексу на открытие меню, а не на каждую рекомпозицию: OfflineStore проверяет
    // существование файла через ContentResolver, то есть через другой процесс.
    val downloadWhere = remember(track.id, download) {
        if (download == DownloadStatus.Done) OfflineStore.whereIs(ctx, track) else null
    }
    // 6.23.0: этот лист стал ЕДИНСТВЕННОЙ точкой входа во всё, что можно сделать с треком —
    // кнопка «поделиться» из шапки плеера убрана, троеточие переехало на её место. Поэтому
    // порядок пунктов теперь не косметика, а навигация: сверху то, что делают каждый день,
    // ниже то, что делают раз в неделю, в самом низу то, что нельзя отменить.
    ZiziSheetScaffold(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 20,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickAction(
                icon = ZiziIcons.HeartFilled,
                label = "Избранное",
                active = favorite,
                onClick = onToggleFavorite
            )
            QuickAction(ZiziIcons.QueueAdd, "В плейлист", onClick = onAddToPlaylist)
            QuickAction(ZiziIcons.Speed, "Скорость", onClick = onFx)
            // 6.24.0: подпись говорит, что РЕАЛЬНО уйдёт. У скачанного трека уходит файл, у
            // остальных — название: внутренний адрес zizi:// чужому приложению бесполезен.
            // Обещать вложение там, где его нет, хуже, чем честная надпись.
            QuickAction(
                ZiziIcons.Share,
                if (download == DownloadStatus.Done) "Файлом" else "Поделиться",
                onClick = onShare
            )
        }
        Spacer(Modifier.height(14.dp))

        // --- офлайн ---
        DownloadMenuItem(
            status = download,
            where = downloadWhere,
            onDownload = onDownload,
            onCancel = onCancelDownload,
            onRemove = onRemoveDownload
        )
        // 6.24.1. Пункт, которого не хватало больше всего: «покажи мне файл».
        // Ответом на «у меня нигде нет скачанного трека» должно быть действие в приложении, а
        // не переписка. Открывает файл системным приложением — то есть доказывает, что он есть,
        // и заодно показывает, где именно.
        if (download == DownloadStatus.Done) {
            MenuItem(
                icon = ZiziIcons.FolderOpen,
                label = "Показать файл",
                subtitle = downloadWhere ?: OfflineStoreLabel,
                onClick = { showDownloadedFile(ctx, track) }
            )
        }

        // --- очередь ---
        MenuItem(ZiziIcons.PlayNext, "Играть следующим", onClick = onPlayNext)
        MenuItem(ZiziIcons.QueueAdd, "Добавить в очередь", onClick = onAddToQueue)
        MenuItem(ZiziIcons.Queue, "Очередь", trailing = if (queueSize > 0) "$queueSize" else null, onClick = onQueue)

        // --- навигация и остальное ---
        if (track.artist.isNotBlank() && track.artist != "—") {
            MenuItem(ZiziIcons.Person, "Перейти к исполнителю", trailing = null, onClick = onGoToArtist)
        }
        MenuItem(ZiziIcons.Moon, "Таймер сна", trailing = sleepMinutesLeft?.let { "$it мин" }, onClick = onSleep)
        onFolders?.let { MenuItem(ZiziIcons.FolderMusic, "Папки", onClick = it) }
        if (inPlaylist != null) {
            MenuItem(ZiziIcons.QueueRemove, "Убрать из «${inPlaylist.name}»", onClick = onRemoveFromPlaylist)
        }
        MenuItem(
            icon = ZiziIcons.Info,
            label = "Сведения о треке",
            trailing = if (plays > 0) "$plays" else null,
            onClick = onInfo
        )

        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(ZiziIcons.Trash, "Убрать из Zizi", tint = Color(0xFFFF8A8A), onClick = onHide)
        // Удалить можно только то, что действительно лежит файлом на устройстве.
        if (!track.isRemote) {
            MenuItem(ZiziIcons.TrashForever, "Удалить файл с устройства", tint = Color(0xFFFF5555), onClick = onDeleteFile)
        }
    }
}

/**
 * «Сведения о треке».
 *
 * Ровно те факты, которые нельзя увидеть на экране плеера, и ни одного придуманного: источник,
 * длительность, размер, папка, счётчик прослушиваний. Пустые поля не показываются — строка
 * «Альбом: —» это шум, а не информация.
 */
@Composable
fun TrackInfoSheet(
    track: TrackEntity,
    plays: Int,
    downloaded: Boolean,
    streamLabel: String?,
    onDismiss: () -> Unit
) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Сведения о треке", track.title)
        InfoRow("Исполнитель", track.artist)
        if (track.album.isNotBlank()) InfoRow("Альбом", track.album)
        InfoRow("Источник", if (track.isRemote) (track.provider ?: "сеть") else "файл на устройстве")
        if (track.isRemote && streamLabel != null) InfoRow("Поток", streamLabel)
        if (track.isRemote) InfoRow("Офлайн", if (downloaded) "скачан" else "только из сети")
        InfoRow("Длительность", formatTime(track.durationMs))
        if (track.sizeBytes > 0) InfoRow("Размер", "%.1f МБ".format(track.sizeBytes / 1024f / 1024f))
        if (!track.isRemote) InfoRow("Папка", track.sourceFolder)
        InfoRow("Прослушан", "$plays раз")
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = p.subtext, fontSize = 14.sp, modifier = Modifier.width(120.dp))
        Text(value, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Круглая кнопка быстрого действия. Подпись — часть кнопки, а не пояснение:
 * пояснительные строки («Файл останется на устройстве…», «прослушан N раз») убраны целиком.
 */
@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(percent = 50))
                // 6.27.1: включённое действие — на фирменном оранжевом, а не на акценте.
                //
                // `p.accent` пересчитывается из обложки играющего трека. У тёмной обложки он
                // уходит в тот же тёмный, у оранжевой сливается с фоном плашки, и «Избранное»
                // в нажатом состоянии переставало отличаться от ненажатого — на что и была
                // жалоба. `p.brand` не зависит ни от обложки, ни от темы: одно состояние —
                // один цвет, всегда одинаковый.
                .background(if (active) p.brand.copy(alpha = 0.22f) else p.chip.copy(alpha = 0.75f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (active) p.brand else p.text, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = if (active) p.brand else p.subtext, fontSize = 11.sp, maxLines = 1)
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    tracks: List<TrackEntity>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPick: (String) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(ZiziIcons.QueueAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        // The queue opens straight at the track that is playing instead of at the top.
        val queueState = rememberLazyListState()
        // Same rule as the library list: while the finger moves, background indexing stands still.
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.isScrollInProgress }.collectLatest { scrolling ->
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
        }
        LaunchedEffect(currentTrackId) {
            val index = tracks.indexOfFirst { it.id == currentTrackId }
            if (index > 1) queueState.scrollToItem((index - 1).coerceAtLeast(0))
        }
        LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = maxHeight),
            state = queueState
        ) {
            itemsIndexed(
                tracks,
                key = { _, item -> item.id },
                // A declared contentType lets the lazy layout reuse a row's whole subtree instead of
                // building a new one, and the fixed height below means no row is ever re-measured.
                contentType = { _, _ -> "queue" }
            ) { _, track ->
                val playing = track.id == currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clickable { onPick(track.id) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                        )
                        // 6.14.0: третья копия того же маркера убрана — здесь `playing` значит
                        // «эта строка и есть текущий трек», а `isPlaying` — играет ли он сейчас.
                        NowPlayingBadge(
                            current = playing,
                            playing = isPlaying,
                            size = 48.dp,
                            corner = 8.dp,
                            barSize = 17.dp
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

/**
 * A titled card. The old settings screen was one flat stream of 14 rows, dividers and radio
 * buttons - everything at the same visual weight, which is exactly why it read as "thrown
 * together". Now every row lives in a group with a heading, and the group is a card.
 */
@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        text = title.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 26.dp, top = 16.dp, bottom = 8.dp)
    )
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.chip.copy(alpha = 0.38f))
            .padding(vertical = 4.dp),
        content = content
    )
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    label: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
    /** 6.17.0: нужен строке «О приложении» — там долгое нажатие это единственный вход. */
    onLongClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .then(
                when {
                    onLongClick != null -> Modifier.combinedClickable(
                        onClick = { onClick?.invoke() },
                        onLongClick = onLongClick
                    )
                    onClick != null -> Modifier.clickable(onClick = onClick)
                    else -> Modifier
                }
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) {
                Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, label: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    SettingRow(
        icon = icon,
        label = label,
        subtitle = subtitle,
        onClick = { onChange(!checked) },
        trailing = {
            // 6.27.1: включённый переключатель — фирменный, а не акцентный.
            //
            // p.accent пересчитывается из обложки играющего трека, то есть «включено»
            // меняло цвет вместе с песней: на одной обложке зелёное, на другой сиреневое,
            // на третьей почти сливалось с дорожкой. Состояние «включено» обязано
            // выглядеть одинаково всегда — иначе это не индикатор, а украшение.
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onBrand,
                    checkedTrackColor = p.brand,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }
    )
}


/* ------------------------------------------------------------- настройки: оболочка 6.27.1 */

/**
 * Разделы настроек.
 *
 * До 6.27.1 настройки были одной лентой из шести групп подряд — тридцать с лишним строк, и
 * чтобы дойти до «Скачанных треков», надо было проскроллить весь сетевой каталог. Экран поиска
 * мы уже перестроили по одному принципу: сверху поле, под ним чипы разрезов, дальше содержимое.
 * Здесь тот же принцип и по той же причине — не ради единообразия ради единообразия, а потому
 * что оба экрана решают одну задачу: «в куче пунктов найти один».
 *
 * [keywords] — то, что человек НАБЕРЁТ, а не то, что написано в заголовке. «Память», «офлайн»,
 * «место» ведут в «Загрузки», хотя ни одного из этих слов в разделе нет. Поиск, который находит
 * только по точному названию раздела, не нужен: название и так видно в чипах.
 */
private enum class SettingsSection(
    val chip: String,
    /** Заголовок плитки в хабе: там места больше, чем в чипе, и сокращать незачем. */
    val tile: String,
    val icon: ImageVector,
    val keywords: String
) {
    LOOK("Оформление", "Оформление", ZiziIcons.Palette, "тема темы цвет цвета обложка палитра оформление вид графит полночь amoled закат акцент"),
    LIBRARY("Библиотека", "Библиотека", ZiziIcons.Library, "библиотека папка папки сортировка порядок сканирование пересканировать скрытые треки диск"),
    SOUND("Звук", "Звук", ZiziIcons.Equalizer, "звук тишина паузы эквалайзер громкость полосы басы"),
    DOWNLOADS("Загрузки", "Загрузки", ZiziIcons.DownloadDone, "загрузки скачанные скачать офлайн кэш память место файлы удалить отчёт"),
    NETWORK("Сеть", "Поток из сети", ZiziIcons.Cloud, "сеть сетевой каталог поток качество трафик резолвер сервер прокси адрес токен wi-fi"),
    ABOUT("О приложении", "О приложении", ZiziIcons.Info, "о приложении версия сбой отчёт служебный доступ разработка")
}

/**
 * Что показывать: пересечение выбранного чипа и набранного запроса.
 *
 * Фильтр работает по РАЗДЕЛАМ, а не по отдельным строкам, и это осознанно. Строка настройки
 * без соседей часто бессмысленна: «Пропускать тишину» рядом с «Качеством потока» и «Мобильным
 * трафиком» читается иначе, чем в одиночестве, а переключатель, вырванный из группы, человек
 * тыкает вслепую. Раздел — минимальная единица, которая сохраняет смысл.
 */
private fun matchingSections(query: String, active: SettingsSection?): List<SettingsSection> {
    val base = if (active == null) SettingsSection.entries.toList() else listOf(active)
    val q = query.trim().lowercase()
    if (q.isEmpty()) return base
    return base.filter { it.chip.lowercase().contains(q) || it.keywords.contains(q) }
}

/**
 * Поле фильтра. Геометрия — поля поиска: высота 52 dp, радиус 8 dp, курсор фирменным.
 *
 * Единственное отличие от поиска — фон. Там поле белое, потому что лежит на тёмном экране и
 * обязано быть первым, что видит глаз. Здесь оно лежит на поверхности листа, и белая плита
 * посреди тёмного листа была бы той самой кляксой: поле не важнее того, что под ним, оно
 * всего лишь способ туда добраться.
 */
@Composable
private fun SettingsFilterField(text: String, onText: (String) -> Unit, onClear: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(52.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(p.chip.copy(alpha = 0.55f))
            .padding(start = 14.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(ZiziIcons.Search, null, tint = p.subtext, modifier = Modifier.size(21.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = text,
            onValueChange = onText,
            singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 15.5.sp, fontWeight = FontWeight.Medium),
            cursorBrush = SolidColor(p.brand),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) {
                        Text("Найти настройку", color = p.subtext, fontSize = 15.5.sp)
                    }
                    inner()
                }
            }
        )
        if (text.isNotEmpty()) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onClear),
                contentAlignment = Alignment.Center
            ) { Icon(ZiziIcons.Close, null, tint = p.subtext, modifier = Modifier.size(19.dp)) }
        }
    }
    Spacer(Modifier.height(10.dp))
}

/** Чипы разрезов — та же геометрия и те же цвета, что у вкладок поиска: активный фирменный. */
@Composable
private fun SettingsSectionChips(active: SettingsSection?, onPick: (SettingsSection?) -> Unit) {
    val p = LocalPalette.current
    val colors = ChipColors(p.chip, p.text, p.brand, p.onBrand)
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = CHIP_ROW_INSET),
        horizontalArrangement = Arrangement.spacedBy(CHIP_SPACING)
    ) {
        PillChip("Все", null, active == null, colors) { onPick(null) }
        SettingsSection.entries.forEach { s ->
            PillChip(s.chip, null, active == s, colors) { onPick(s) }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/* ------------------------------------------------ настройки: хаб разделов 6.28.0 */

/**
 * ЧТО БЫЛО НЕ ТАК В 6.27.1 И ПОЧЕМУ ЭТО НЕ ЛЕЧИЛОСЬ КОСМЕТИКОЙ.
 *
 * Сверху стоял блок 2x2 из «Пересканировать», «Добавить папку», «Очистить кэш», «Загрузки».
 * Ниже те же четыре действия лежали строками в своих группах: «Пересканировать» и «Добавить
 * папку с музыкой» — в «Библиотеке», «Очистить кэш потоков» — в «Потоке из сети», «Скачанные
 * треки» плюс «Открыть папку с загрузками» — в «Загрузках». Восемь входов в четыре действия на
 * одном экране, причём подписи разные («Добавить папку» против «Добавить папку с музыкой»), и
 * человек честно пытается понять, чем они отличаются. Ничем.
 *
 * Дубль тут не опечатка, а следствие структуры: блок 2x2 был скопирован из хаба поиска, где он
 * уместен, — но в поиске плитки ведут туда, где ничего кроме них нет, а в настройках они вели к
 * действиям, у которых уже есть постоянный адрес в группе. Быстрый доступ, продублировавший
 * содержимое, перестаёт быть быстрым: он добавляет к выбору «что нажать» выбор «какой из двух
 * одинаковых пунктов правильный».
 *
 * РЕШЕНИЕ — РАЗДЕЛИТЬ ПОВЕРХНОСТИ ТАК ЖЕ, КАК ЭТО СДЕЛАНО В ПОИСКЕ.
 *
 * В поиске две поверхности: хаб (плитки разделов, вкладок нет) и результаты (вкладки-чипы,
 * плиток нет). Ни одна кнопка не встречается на обеих. Настройки теперь устроены ровно так:
 *
 *   ХАБ (поле пустое, раздел не выбран) — шесть цветных плиток разделов и ничего больше.
 *       Плитка отвечает на «куда идти» и показывает состояние раздела цифрами.
 *   СОДЕРЖИМОЕ (набран запрос или выбран раздел) — чипы разрезов и группы строк.
 *       Строка отвечает на «что сделать», и каждое действие живёт ровно в одном месте.
 *
 * Отсюда: чипы больше не висят над плитками (два ряда одной и той же навигации подряд — это и
 * была «клякса»), а блока 2x2 нет вообще. Действия не потерялись, они перестали удваиваться.
 */

/** Русская форма числа. «1 папка», «2 папки», «5 папок» — без этого экран звучит как робот. */
private fun plural(n: Int, one: String, few: String, many: String): String {
    val mod100 = n % 100
    val mod10 = n % 10
    return when {
        mod100 in 11..14 -> many
        mod10 == 1 -> one
        mod10 in 2..3 -> few
        else -> many
    }
}

private fun mb(bytes: Long): String = "%.1f МБ".format(bytes / 1024.0 / 1024.0)

/**
 * Подпись плитки — состояние раздела, а не его описание.
 *
 * «Библиотека: настройки библиотеки» не говорит ничего; «231 трек · 2 папки» отвечает на
 * вопрос, с которым в раздел и заходят. Пока идёт сканирование, подпись показывает его ход:
 * в хабе строк с прогрессом не видно, и единственный способ узнать, что работа идёт, — плитка.
 */
private fun sectionCaption(
    section: SettingsSection,
    state: LibraryUiState,
    downloads: DownloadsInfo,
    scan: ScanProgress?,
    themeName: String
): String = when (section) {
    SettingsSection.LOOK ->
        themeName + if (state.settings.accentFromArtwork) " · цвет из обложки" else " · без подкраски"
    SettingsSection.LIBRARY -> when {
        state.scanning && scan != null && scan.total > 0 -> "Сканирую · ${scan.done} из ${scan.total}"
        state.scanning -> "Сканирую…"
        else -> {
            val tracks = state.tracks.size
            val folders = state.settings.folderUris.size
            val head = "$tracks " + plural(tracks, "трек", "трека", "треков")
            if (folders == 0) "$head · папки не подключены"
            else "$head · $folders " + plural(folders, "папка", "папки", "папок")
        }
    }
    SettingsSection.SOUND ->
        "Эквалайзер · " + if (state.settings.skipSilence) "тишина пропускается" else "тишина как есть"
    SettingsSection.DOWNLOADS ->
        if (downloads.count == 0) "Пока ничего не скачано"
        else "${downloads.count} " + plural(downloads.count, "трек", "трека", "треков") + " · " + mb(downloads.bytes)
    SettingsSection.NETWORK -> {
        val provider = if (state.settings.catalogProvider == "yt") "YouTube Music" else "Audius"
        provider + if (state.settings.wifiOnly) " · только Wi-Fi" else ""
    }
    SettingsSection.ABOUT -> "Версия " + app.ziziplayer.BuildConfig.VERSION_NAME
}

/**
 * Плитка раздела: геометрия жанровой плитки поиска, до последней константы.
 *
 * Пропорция [TILE_RATIO], радиус [TILE_RADIUS], поля [EDGE], зазор [GAP], ширина колонки из
 * [columnWidth] и цвет из [TILE_COLORS] — это не скопированные числа, а те же самые значения
 * из SearchScreen.kt. Скопированное число живёт до первой правки; общая константа держит два
 * экрана в одном стиле сама.
 *
 * Знак раздела повторяет наклонённую обложку плитки поиска: тот же угол 25 градусов, тот же
 * вылет за правый край, та же тень. Именно этот скос отличает плитку от кнопки — квадрат,
 * целиком уместившийся внутри, читается как иконка в списке.
 *
 * У «Оформления» на месте знака не глиф, а градиент выбранной темы: раздел про внешний вид
 * обязан показывать внешний вид. Смена темы видна в хабе, не открывая раздел.
 */
@Composable
private fun SettingsHubTile(
    section: SettingsSection,
    caption: String,
    color: Color,
    width: Dp,
    busy: Boolean,
    preview: Brush?,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .width(width)
            .aspectRatio(TILE_RATIO)
            .clip(RoundedCornerShape(TILE_RADIUS))
            .background(color)
            .clickable(onClick = onClick)
            .clipToBounds()
    ) {
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 14.dp, y = 10.dp)
                .size(66.dp)
                .graphicsLayer {
                    rotationZ = 25f
                    shadowElevation = 6f
                }
                .clip(RoundedCornerShape(2.dp))
                .background(preview ?: SolidColor(Color.Black.copy(alpha = 0.20f))),
            contentAlignment = Alignment.Center
        ) {
            if (preview == null) {
                Icon(
                    section.icon,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.92f),
                    modifier = Modifier.size(29.dp)
                )
            }
        }
        Text(
            section.tile,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 13.dp, top = 11.dp, end = 58.dp)
        )
        Row(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 13.dp, bottom = 10.dp, end = 60.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(11.dp),
                    color = Color.White,
                    strokeWidth = 1.6.dp
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(
                caption,
                // Белый с прозрачностью, а не серый: под ним шесть разных фонов, и любой
                // конкретный серый на половине из них выглядит грязью.
                color = Color.White.copy(alpha = 0.82f),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Хаб: шесть плиток в две колонки.
 *
 * Порядок не алфавитный и не случайный — по частоте: «Оформление» и «Библиотека» сверху,
 * «О приложении» последним. «Оформление» стоит первым ещё и потому, что оно единственное
 * показывает результат сразу, не открывая раздел.
 */
@Composable
private fun SettingsHub(
    state: LibraryUiState,
    downloads: DownloadsInfo,
    scan: ScanProgress?,
    themeName: String,
    onPick: (SettingsSection) -> Unit
) {
    val width = columnWidth()
    Column(
        Modifier.fillMaxWidth().padding(horizontal = EDGE),
        verticalArrangement = Arrangement.spacedBy(GAP)
    ) {
        SettingsSection.entries.chunked(2).forEachIndexed { row, pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(GAP)) {
                pair.forEachIndexed { col, section ->
                    val index = row * 2 + col
                    SettingsHubTile(
                        section = section,
                        caption = sectionCaption(section, state, downloads, scan, themeName),
                        color = TILE_COLORS[index % TILE_COLORS.size],
                        width = width,
                        busy = section == SettingsSection.LIBRARY && state.scanning,
                        preview = if (section == SettingsSection.LOOK)
                            basePalette(state.settings.theme).background else null,
                        onClick = { onPick(section) }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.width(width))
            }
        }
    }
}

/**
 * Полоса состояния — единственное, что появляется в хабе поверх плиток, и только пока есть
 * о чём отчитаться.
 *
 * Причина та же, из-за которой в 6.27.1 появился [WipeRow]: долгое дело без отклика человек
 * читает как «не сработало». Но строка с крутилкой живёт внутри раздела, а уборку и сканирование
 * можно запустить и уйти в хаб — там от неё не остаётся ничего. Полоса это закрывает и исчезает
 * сама, как только дело кончилось и итог отгорел свои секунды.
 *
 * Постоянного места на экране она не занимает: в покое её нет, а не «нет данных».
 */
@Composable
private fun SettingsPulse(text: String, fraction: Float?, done: Boolean) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = EDGE)
            .padding(bottom = GAP - 4.dp)
            .clip(RoundedCornerShape(TILE_RADIUS))
            .background(p.chip.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (done) {
                Icon(ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(15.dp))
            } else {
                CircularProgressIndicator(
                    modifier = Modifier.size(13.dp),
                    color = p.brand,
                    strokeWidth = 1.8.dp
                )
            }
            Spacer(Modifier.width(9.dp))
            Text(text, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
        if (!done) {
            Spacer(Modifier.height(8.dp))
            // Локальная копия, а не умное приведение параметра прямо в лямбде: `progress`
            // принимает функцию, и такой захват компилятор разбирает по-разному в зависимости
            // от версии. Одна строка — и вопрос закрыт для любой.
            val value = fraction
            if (value != null) {
                LinearProgressIndicator(
                    progress = { value },
                    modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                    color = p.brand,
                    trackColor = p.chip
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                    color = p.brand,
                    trackColor = p.chip
                )
            }
        }
    }
}

/** Пусто по фильтру: заглушка со сбросом, а не одинокая строка серым по тёмному. */
@Composable
private fun SettingsEmpty(query: String, onReset: () -> Unit) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = EDGE, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(ZiziIcons.SearchOff, null, tint = p.subtext, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(10.dp))
        Text(
            if (query.isBlank()) "В этом разрезе пусто"
            else "Ничего не нашлось по запросу «" + query.trim() + "»",
            color = p.text,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Поиск идёт по разделам и по словам вроде «память», «трафик», «тема»",
            color = p.subtext,
            fontSize = 12.5.sp
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Сбросить фильтр",
            color = p.brand,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onReset)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun SettingsSheet(
    vm: MainViewModel,
    state: LibraryUiState,
    onDismiss: () -> Unit,
    onPickFolder: () -> Unit,
    /**
     * 6.28.0: вход в эквалайзер из раздела «Звук».
     *
     * Экран эквалайзера живёт в MainActivity поверх плеера, и до этой версии попасть в него можно
     * было ровно одним путём: открыть плеер, открыть «Эффекты», нажать «Эквалайзер». Раздел
     * «Звук» в настройках при этом состоял из одного переключателя и выглядел недоделанным — не
     * потому, что дизайн скудный, а потому, что главная настройка звука была не здесь.
     *
     * Лист настроек закрывается перед открытием: эквалайзер перекрывает всё, включая плеер, и
     * оставленный под ним лист ловил бы жест закрытия сквозь экран настройки звука.
     */
    onOpenEqualizer: () -> Unit
) {
    val p = LocalPalette.current
    var sortOpen by remember { mutableStateOf(false) }
    // 6.19.0: подтверждение отключения папки. rememberSaveable — лист настроек живёт через
    // системный диалог выбора папки и через поворот экрана.
    var confirmRemoveFolder by rememberSaveable { mutableStateOf<String?>(null) }
    // 6.24.0: снос всех загрузок — операция без отмены, поэтому только через подтверждение.
    var confirmWipeDownloads by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val themeNames = remember {
        mapOf(
            AppTheme.GRAPHITE to "Графит",
            AppTheme.MIDNIGHT to "Полночь",
            AppTheme.AMOLED to "AMOLED",
            AppTheme.SUNSET to "Закат"
        )
    }
    val sortNames = remember {
        mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
    }

    // 6.27.1: состояние фильтра. rememberSaveable — лист настроек переживает и поворот
    // экрана, и уход в системный диалог выбора папки; терять при возврате набранное — это
    // ровно тот сорт мелочи, из которого складывается ощущение «приложение меня не слушает».
    var query by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf<SettingsSection?>(null) }
    // 6.24.1: состояние отчёта живёт здесь, а не во ViewModel — это разовый текст для
    // одного диалога, переживать поворот экрана ему незачем.
    var downloadsReport by remember { mutableStateOf<String?>(null) }
    // 6.27.1: цифры «Скачанных треков» — из потока.
    //
    // Тут стояло `subtitle = vm.downloadsLabel()`, то есть обычный вызов функции. Композиция
    // на такое не подписывается: строка показывала то, что было прочитано при открытии
    // настроек, и не менялась ни после скачивания, ни после удаления — ровно то, на что ты
    // жаловался («не обновляются данные в „скачанные треки“»). Ошибка невидимая: код
    // выглядит правильным, компилятор молчит, а UI живёт прошлым.
    val downloads by vm.downloadsInfo.collectAsState()
    val wipe by vm.wipe.collectAsState()
    // 6.28.0: в хабе разделов групп нет вообще, поэтому и список совпадений пуст. Так «пусто»
    // на поверхности содержимого означает ровно «фильтр ничего не нашёл», а не «мы в хабе».
    val filtering = query.isNotBlank() || section != null
    val shown = remember(query, section) {
        if (filtering) matchingSections(query, section) else emptyList()
    }
    // Ход сканирования держится отдельным потоком, а не полем состояния: он тикает часто, и в
    // LibraryUiState его нет намеренно (см. MainViewModel.scanProgress).
    val scan by vm.scanProgress.collectAsStateWithLifecycle()
    ZiziSheetScaffold(onDismiss) {
        // 6.28.0: подзаголовка «N треков в библиотеке · скачано M» здесь больше нет.
        //
        // Он повторял ровно то, что теперь стоит в подписях плиток «Библиотека» и «Загрузки»
        // двумя строками ниже — и повторял хуже: в одну строку, обрезанный многоточием на
        // узком экране. Цифра должна лежать там, куда по ней и идут, а не над всем экраном
        // сразу. Дубль текстом — такой же дубль, как дубль кнопкой.
        SheetTitle("Настройки")

        SettingsFilterField(
            text = query,
            onText = { query = it },
            onClear = { query = "" }
        )
        // Поле фильтра стояло вплотную к следующему ряду: у поля своих отступов снизу нет, у
        // чипов — сверху, и два элемента срастались в одно серое пятно. Один зазор на обе
        // поверхности, тот же [GAP], которым разложены плитки.
        Spacer(Modifier.height(GAP - 4.dp))

        if (filtering) {
            SettingsSectionChips(active = section) { picked ->
                // Повторное нажатие по активному чипу снимает фильтр — тем же жестом, которым он
                // был поставлен. Чип «Все» делает то же самое явно, для тех, кто про повторное
                // нажатие не догадается: два пути к одному состоянию лучше, чем один неочевидный.
                // Он же и есть путь назад в хаб: снять раздел и очистить запрос.
                section = if (picked == null || picked == section) null else picked
                query = ""
            }
        } else {
            // Хаб. Полоса состояния появляется только пока есть о чём отчитаться: действия
            // живут в разделах, а запустить их и уйти сюда — обычное дело, и без этой полосы
            // хаб врал бы, что ничего не происходит.
            when {
                state.scanning -> SettingsPulse(
                    text = scan?.let { progress ->
                        if (progress.total > 0) "${progress.label} · ${progress.done} из ${progress.total}"
                        else progress.label
                    } ?: "Сканирую медиатеку…",
                    fraction = scan?.takeIf { it.total > 0 }?.let { it.done.toFloat() / it.total.toFloat() },
                    done = false
                )
                wipe.running -> SettingsPulse(
                    text = when (wipe.kind) {
                        WipeKind.DOWNLOADS -> "Удаляю загрузки"
                        WipeKind.STREAM_CACHE -> "Чищу кэш потоков"
                        WipeKind.NONE -> "Убираюсь"
                    } + if (wipe.total > 0) " · ${wipe.done} из ${wipe.total}" else "…",
                    fraction = wipe.takeIf { it.total > 0 }?.fraction,
                    done = false
                )
                wipe.finished -> {
                    SettingsPulse(
                        text = if (wipe.freedBytes > 0) "Готово · освободилось " + mb(wipe.freedBytes)
                        else "Готово · освобождать было нечего",
                        fraction = null,
                        done = true
                    )
                    // Итог гасит тот, кто его показывает. В разделах это делает WipeRow, но если
                    // уборку запустили и ушли в хаб, гасить его там некому — и «Готово» осталось
                    // бы висеть до перезапуска приложения.
                    LaunchedEffect(wipe.finishedAt) {
                        delay(3500)
                        vm.dismissWipeResult()
                    }
                }
            }
            SettingsHub(
                state = state,
                downloads = downloads,
                scan = scan,
                themeName = themeNames[state.settings.theme] ?: state.settings.theme.name,
                onPick = { picked -> section = picked }
            )
        }

        if (SettingsSection.LOOK in shown) {
            SettingsGroup("Оформление") {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AppTheme.entries.forEach { theme ->
                        val active = state.settings.theme == theme
                        val preview = remember(theme) { basePalette(theme) }
                        Column(
                            Modifier
                                .width(76.dp)
                                .clip(RoundedCornerShape(14.dp))
                                // Выбранная тема помечается фирменным, а не акцентным: акцент здесь и есть
                                // предмет выбора, помечать им же выбор — значит помечать предмет им самим.
                                .background(if (active) p.brand.copy(alpha = 0.18f) else Color.Transparent)
                                .clickable { vm.setTheme(theme) }
                                .padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(preview.background)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                themeNames[theme] ?: theme.name,
                                color = if (active) p.brand else p.subtext,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }
                    }
                }
                SettingSwitch(
                    icon = ZiziIcons.Palette,
                    label = "Цвет из обложки",
                    subtitle = "Фон повторяет оттенки текущей обложки",
                    checked = state.settings.accentFromArtwork,
                    onChange = vm::setDynamicAccent
                )
            }
        }

        if (SettingsSection.LIBRARY in shown) {
            SettingsGroup("Библиотека") {
                SettingRow(
                    icon = ZiziIcons.Sort,
                    label = "Сортировка",
                    subtitle = sortNames[state.settings.sortMode],
                    trailing = {
                        Icon(
                            if (sortOpen) ZiziIcons.ChevronUp else ZiziIcons.ChevronDown,
                            contentDescription = null,
                            tint = p.subtext,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    onClick = { sortOpen = !sortOpen }
                )
                if (sortOpen) {
                    SortMode.entries.forEach { mode ->
                        val active = state.settings.sortMode == mode
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.setSortMode(mode) }
                                .padding(start = 60.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                sortNames[mode] ?: mode.name,
                                color = if (active) p.brand else p.text,
                                fontSize = 14.5.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            if (active) Icon(ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(19.dp))
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
                SettingRow(
                    icon = ZiziIcons.FolderPlus,
                    label = "Добавить папку с музыкой",
                    subtitle = if (state.settings.folderUris.isEmpty()) "Ничего не подключено"
                    else "Подключено: ${state.settings.folderUris.size}",
                    onClick = onPickFolder
                )
                state.settings.folderUris.forEach { uri ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = uri.substringAfterLast("/").ifBlank { uri },
                            color = p.subtext,
                            fontSize = 12.5.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(10.dp))
                                // 6.19.0: подтверждение и здесь. Крестик 30 dp в плотном списке —
                                // это промах в одно касание, а последствие то же, что в медиатеке.
                                .clickable { confirmRemoveFolder = uri },
                            contentAlignment = Alignment.Center
                        ) { Icon(ZiziIcons.Close, null, tint = p.subtext, modifier = Modifier.size(16.dp)) }
                    }
                }
                SettingRow(
                    icon = ZiziIcons.Refresh,
                    label = "Пересканировать",
                    subtitle = if (state.scanning) "Идёт сканирование…" else "Найдено ${state.tracks.size} треков",
                    onClick = vm::rescan
                )
                if (state.hiddenCount > 0) {
                    SettingRow(
                        icon = ZiziIcons.Eye,
                        label = "Вернуть скрытые треки",
                        subtitle = "Скрыто: ${state.hiddenCount}",
                        onClick = vm::restoreAllHidden
                    )
                }
            }
            confirmRemoveFolder?.let { folderUri ->
                ConfirmDialog(
                    title = "Отключить папку?",
                    message = "Треки из «" + android.net.Uri.decode(folderUri).substringAfterLast('/') +
                        "» исчезнут из медиатеки. Сами файлы останутся на месте.",
                    confirm = "Отключить",
                    onConfirm = { vm.removeFolder(folderUri); confirmRemoveFolder = null },
                    onDismiss = { confirmRemoveFolder = null }
                )
            }
        }

        if (SettingsSection.SOUND in shown) {
            SettingsGroup("Звук") {
                SettingRow(
                    icon = ZiziIcons.Equalizer,
                    label = "Эквалайзер",
                    subtitle = "Полосы, предустановки, басы и объём",
                    trailing = {
                        Icon(
                            ZiziIcons.ChevronRight,
                            contentDescription = null,
                            tint = p.subtext,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { onDismiss(); onOpenEqualizer() }
                )
                SettingSwitch(
                    icon = ZiziIcons.Speed,
                    label = "Пропускать тишину",
                    subtitle = "Убирает паузы в начале и в конце трека",
                    checked = state.settings.skipSilence,
                    onChange = vm::setSkipSilence
                )
            }
        }

        if (SettingsSection.DOWNLOADS in shown) {
            SettingsGroup("Загрузки") {
                // 6.28.0: было две строки об одном и том же — «Скачанные треки» с цифрами, но
                // без нажатия, и «Открыть папку с загрузками» с тем же адресом в подписи. Тот,
                // кто хочет посмотреть скачанное, жмёт на строку с цифрами и не понимает, почему
                // ничего не произошло. Теперь строка одна: цифры, папка и нажатие в одном месте.
                SettingRow(
                    icon = ZiziIcons.DownloadDone,
                    label = "Скачанные треки",
                    subtitle = if (downloads.count == 0)
                        "Пока ничего не скачано · папка " + OfflineStore.FOLDER_LABEL
                    else "${downloads.count} " + plural(downloads.count, "трек", "трека", "треков") +
                        " · " + mb(downloads.bytes) + " · " + OfflineStore.FOLDER_LABEL,
                    trailing = {
                        Icon(
                            ZiziIcons.FolderOpen,
                            contentDescription = null,
                            tint = p.subtext,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { openDownloadsFolder(context) }
                )
                SettingRow(
                    icon = ZiziIcons.Bug,
                    label = "Проверить загрузки",
                    subtitle = "Отчёт: куда легли файлы, все ли на месте, видит ли их система",
                    onClick = { downloadsReport = OfflineStore.report(context) }
                )
                if (downloads.count > 0 || wipe.kind == WipeKind.DOWNLOADS) {
                    WipeRow(
                        icon = ZiziIcons.TrashSweep,
                        label = "Удалить все загрузки",
                        idleSubtitle = "Файлы из «Музыка/Zizi» будут удалены с устройства",
                        runningLabel = "Удаляю файлы",
                        wipe = wipe,
                        kind = WipeKind.DOWNLOADS,
                        tint = DANGER,
                        onClick = { confirmWipeDownloads = true },
                        onDone = vm::dismissWipeResult
                    )
                }
            }
            downloadsReport?.let { text ->
                ConfirmDialog(
                    title = "Загрузки",
                    message = text,
                    confirm = "Понятно",
                    onConfirm = { downloadsReport = null },
                    onDismiss = { downloadsReport = null }
                )
            }
            if (confirmWipeDownloads) {
                ConfirmDialog(
                    title = "Удалить все загрузки?",
                    message = "Скачанные файлы из «Музыка/Zizi» будут удалены. Сами треки останутся " +
                        "в библиотеке и снова будут играть из сети.",
                    confirm = "Удалить",
                    onConfirm = { vm.removeAllDownloads(); confirmWipeDownloads = false },
                    onDismiss = { confirmWipeDownloads = false }
                )
            }
        }

        if (SettingsSection.NETWORK in shown) {
            NetworkCatalogGroup(vm, state)
        }

        if (SettingsSection.ABOUT in shown) {
            // СЛУЖЕБНЫЙ ДОСТУП (6.17.0, вместо семи тапов из 6.11.0).
            //
            // Семь тапов по строке версии человек делает сам, из любопытства, и именно так тестер
            // и попал в технические настройки. Секрет переехал из жеста в код (см. data/DevAccess):
            // долгое нажатие лишь ПРЕДЛАГАЕТ ввести код, а без вшитого при сборке хеша не открывает
            // вообще ничего. Подсказок в интерфейсе нет ни одной — ни счётчика, ни «ещё N…».
            val devUnlocked by vm.devUnlocked.collectAsStateWithLifecycle()
            var askCode by remember { mutableStateOf(false) }
            SettingsGroup("О приложении") {
                SettingRow(
                    icon = ZiziIcons.Info,
                    label = "ZiziPlayer",
                    subtitle = if (devUnlocked)
                        "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · служебный доступ открыт"
                    else "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · Media3 · Compose",
                    // Обычный тап не делает НИЧЕГО — строка справочная, и такой она и должна выглядеть.
                    onLongClick = {
                        if (devUnlocked) vm.lockDev() else if (DevAccess.unlockable) askCode = true
                    }
                )
                if (devUnlocked) {
                    SettingRow(
                        icon = ZiziIcons.LockOpen,
                        label = "Закрыть служебный доступ",
                        subtitle = "Сам закроется через 15 минут и при перезапуске приложения",
                        onClick = vm::lockDev
                    )
                }
                /**
                 * 6.24.0: отчёт о последнем сбое.
                 *
                 * Строка появляется ТОЛЬКО если приложение действительно падало. До этой версии
                 * единственным источником данных о вылете был рассказ человека «нажал и вылетело»,
                 * по которому причину приходится угадывать — а угаданная причина лечится заплаткой,
                 * а не ремонтом. Здесь лежит стек: одно нажатие, и он уходит текстом куда угодно.
                 */
                val crash = vm.crashReport()
                if (crash != null) {
                    SettingRow(
                        icon = ZiziIcons.Bug,
                        label = "Отчёт о последнем сбое",
                        subtitle = "Отправить и очистить",
                        tint = DANGER,
                        onClick = {
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_SUBJECT, "ZiziPlayer: сбой")
                                putExtra(android.content.Intent.EXTRA_TEXT, crash)
                            }
                            runCatching { context.startActivity(android.content.Intent.createChooser(send, "Отчёт о сбое")) }
                            vm.clearCrashReport()
                        }
                    )
                }
            }
            if (askCode) {
                DevCodeDialog(
                    onConfirm = { code ->
                        askCode = false
                        // Результат наружу не сообщается: неверный код выглядит ровно так же, как
                        // закрытый диалог. Подбирать что-либо, не видя реакции, бессмысленно.
                        vm.unlockDev(code)
                    },
                    onDismiss = { askCode = false }
                )
            }
        }

        if (filtering && shown.isEmpty()) {
            SettingsEmpty(query = query, onReset = { query = ""; section = null })
        }
        Spacer(Modifier.height(6.dp))
    }
}

/**
 * Ввод служебного кода (6.17.0).
 *
 * Ни счётчика попыток, ни «неверный код», ни разной задержки — снаружи все исходы выглядят
 * одинаково. Тот, кто код знает, войдёт с первого раза; тому, кто не знает, интерфейс не поможет.
 */
@Composable
private fun DevCodeDialog(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var code by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text("Служебный доступ", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Только для разработки. Доступ закроется через 15 минут.", fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                        focusedBorderColor = p.brand,
                        unfocusedBorderColor = p.chip,
                        cursorColor = p.brand
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(code) }) { Text("Открыть", color = p.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/* ------------------------------------------------------------------ confirm */

/**
 * Подтверждение.
 *
 * [danger] — 6.27.1, и это не «покрасить кнопку поярче». Диалогов у нас два разных класса, а
 * выглядели они одинаково: «Отключить папку?» (обратимо: подключил снова — всё вернулось) и
 * «Удалить папку с устройства?» (необратимо: файлов больше нет). Обе кнопки были красным
 * текстом одного веса. Красный текст на прозрачном фоне — это САМАЯ ЛЁГКАЯ кнопка из всех, что
 * есть в Material: у неё нет ни фона, ни границы. Необратимое действие не имеет права быть
 * самым лёгким элементом на экране.
 *
 * При danger подтверждение становится залитой кнопкой, а «Отмена» остаётся текстовой — то есть
 * привычный порядок «лёгкое слева, тяжёлое справа» сохраняется, но вес перераспределён по
 * последствиям, а не по положению.
 */
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    danger: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            if (danger) {
                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DANGER,
                        contentColor = Color.White
                    )
                ) { Text(confirm, fontWeight = FontWeight.Bold) }
            } else {
                TextButton(onClick = onConfirm) { Text(confirm, color = DANGER, fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    title: String = "Переименовать",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.brand,
                    focusedBorderColor = p.brand,
                    unfocusedBorderColor = p.chip
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Готово", color = p.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/**
 * The report, in full, on a screen you can read and in a form you can paste.
 *
 * Three properties, and every one of them is a lesson from 6.8.0: it does not truncate (each client
 * gets its own line, wrapped, not ellipsised), it scrolls (eight clients plus a header do not fit on
 * a phone), and it copies (a screenshot of a wrapped Russian sentence is not a bug report - the
 * verbatim status string is).
 */
@Composable
private fun StreamReportDialog(lines: List<String>, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    val text = lines.joinToString("\n")
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Диагностика потока", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                lines.forEach { line ->
                    Text(
                        text = line,
                        color = if (line.contains("HTTP 2")) p.text else p.subtext,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) {
                Text("Скопировать", color = p.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = p.text) } }
    )
}

/**
 * Network catalogue settings, plus the connection probe.
 *
 * The probe is not a debug leftover: this section talks to a private API that is guaranteed to break
 * eventually, and when it does, the difference between "поиск не работает" and a message naming the
 * provider and the exact refusal is the difference between a patch and a guessing game. It stays.
 */
/**
 * The four rows a listener actually has decisions to make about. Shared by both variants of the
 * group so that hiding the technical part cannot silently drop them.
 */
@Composable
private fun ColumnScope.StreamUserRows(vm: MainViewModel, settings: app.ziziplayer.data.UserSettings) {
    SettingSwitch(
        icon = ZiziIcons.Wifi,
        label = "Только Wi-Fi",
        subtitle = "Не тратить мобильный трафик на потоки",
        checked = settings.wifiOnly,
        onChange = vm::setWifiOnly
    )
    SettingRow(
        icon = ZiziIcons.Equalizer,
        label = "Качество потока",
        subtitle = when (settings.streamQuality) {
            RemoteQuality.LOW -> "Экономно, около 64 кбит/с"
            RemoteQuality.NORMAL -> "Обычное, около 128 кбит/с"
            RemoteQuality.HIGH -> "Высокое, около 256 кбит/с"
        },
        onClick = vm::cycleStreamQuality
    )
    SettingSwitch(
        icon = ZiziIcons.Storage,
        label = "Кэшировать потоки",
        subtitle = "До ${settings.streamCacheMb} МБ: мгновенная перемотка и повтор без трафика",
        checked = settings.streamCacheEnabled,
        onChange = vm::setStreamCacheEnabled
    )
    // 6.27.1: у очистки появился отклик. Причина — в WipeRow.
    val wipe by vm.wipe.collectAsState()
    WipeRow(
        icon = ZiziIcons.TrashSweep,
        label = "Очистить кэш потоков",
        idleSubtitle = vm.streamCacheLabel(),
        runningLabel = "Очищаю кэш",
        wipe = wipe,
        kind = WipeKind.STREAM_CACHE,
        onClick = vm::clearStreamCache,
        onDone = vm::dismissWipeResult
    )
}

/**
 * Строка настроек, которая умеет отчитаться о долгом деле (6.27.1).
 *
 * Появилась по твоей жалобе на очистку кэша: нажатие не давало ничего. Ни строки, ни движения,
 * ни цифры — а поведение в этот момент правильное, файлы действительно удаляются. Отсутствие
 * отклика человек читает однозначно: «не сработало». Дальше он жмёт второй раз и третий, а
 * поскольку каждое нажатие теперь ничего не делает (кэш уже пуст), вывод закрепляется — кнопка
 * мёртвая.
 *
 * Три состояния вместо двух, и третье здесь главное:
 *
 * - **покой** — сколько занято сейчас;
 * - **идёт** — крутилка на фирменном оранжевом плюс «N из M», когда общее число известно;
 * - **готово** — сколько освободилось, галочкой и цифрой, ещё 3.5 секунды после конца.
 *
 * Итог держится на экране намеренно. Обе уборки на пустом хранилище заканчиваются за десятки
 * миллисекунд (нижняя граница видимости в 420 мс задана во ViewModel, см. `runWipe`), и без
 * оставленного итога человек всё равно не понял бы, что произошло: мигнувшая крутилка сообщает
 * «что-то было», а «Готово · освободилось 214 МБ» сообщает, что дело сделано и в каком объёме.
 * Гасится по времени, а не по следующему нажатию: остаться навсегда итог не должен — он
 * относится к прошлому, а строка снова показывает настоящее.
 *
 * Нажатия во время работы не проходят, и это не защита от дурака: второй запуск на том же
 * состоянии наложился бы на первый и сбил бы счётчик, то есть наказал бы за нетерпение
 * недоверием к цифрам.
 */
@Composable
private fun WipeRow(
    icon: ImageVector,
    label: String,
    idleSubtitle: String,
    runningLabel: String,
    wipe: WipeProgress,
    kind: WipeKind,
    tint: Color? = null,
    onClick: () -> Unit,
    onDone: () -> Unit
) {
    val p = LocalPalette.current
    val mine = wipe.kind == kind
    val running = mine && wipe.running
    val finished = mine && wipe.finished
    LaunchedEffect(finished, wipe.finishedAt) {
        if (finished) {
            delay(3500)
            onDone()
        }
    }
    val freed = wipe.freedBytes / 1024.0 / 1024.0
    SettingRow(
        icon = icon,
        label = label,
        subtitle = when {
            running && wipe.total > 0 -> "$runningLabel · ${wipe.done} из ${wipe.total}"
            running -> "$runningLabel…"
            finished && wipe.freedBytes > 0 -> "Готово · освободилось %.1f МБ".format(freed)
            finished -> "Готово · освобождать было нечего"
            else -> idleSubtitle
        },
        // Оранжевым выделяется только состояние, но не опасное действие: у «Удалить все загрузки»
        // цвет остаётся красным, потому что он предупреждает, а не отчитывается.
        tint = if (finished && tint == null) p.brand else tint,
        trailing = {
            when {
                running && wipe.total > 0 -> CircularProgressIndicator(
                    progress = { wipe.fraction },
                    modifier = Modifier.size(18.dp),
                    color = p.brand,
                    strokeWidth = 2.dp
                )
                running -> CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = p.brand,
                    strokeWidth = 2.dp
                )
                finished -> Icon(
                    ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(19.dp)
                )
                else -> Unit
            }
        },
        onClick = { if (!running) onClick() }
    )
}

@Composable
private fun NetworkCatalogGroup(vm: MainViewModel, state: LibraryUiState) {
    val probe by vm.catalogProbe.collectAsState()
    val report by vm.streamReport.collectAsState()
    val reportRunning by vm.reportRunning.collectAsState()
    val resolverStatus by vm.resolverStatus.collectAsState()
    val settings = state.settings
    // Hoisted next to the report dialog for the same reason: the group recomposes while a probe runs.
    var resolverUrlDialog by remember { mutableStateOf(false) }
    var resolverTokenDialog by remember { mutableStateOf(false) }

    if (resolverUrlDialog) {
        RenameDialog(
            initial = settings.resolverUrl,
            title = "Адрес резолвера",
            onConfirm = { value -> vm.setResolverUrl(value); resolverUrlDialog = false },
            onDismiss = { resolverUrlDialog = false }
        )
    }
    if (resolverTokenDialog) {
        RenameDialog(
            initial = settings.resolverToken,
            title = "Токен резолвера",
            onConfirm = { value -> vm.setResolverToken(value); resolverTokenDialog = false },
            onDismiss = { resolverTokenDialog = false }
        )
    }

    // The dialog is hoisted here so it survives the group recomposing while the report runs.
    report?.let { lines ->
        StreamReportDialog(lines = lines, onDismiss = vm::dismissStreamReport)
    }

    // 6.11.0 — две разные группы вместо одной.
    //
    // Пользователю нужны четыре решения: качество, мобильный трафик, кэш, очистка. Всё остальное в
    // этой группе появилось из отладки бот-чека и гео-блока и для него бессмысленно: адрес сервера
    // и токен теперь вшиты в сборку (BuildConfig.RESOLVER_URL / RESOLVER_TOKEN), а диагностика
    // открывается семью тапами по версии.
    // 6.17.0: гейт — сессия служебного доступа, а не сохранённая настройка.
    val devUnlocked by vm.devUnlocked.collectAsStateWithLifecycle()
    if (!devUnlocked) {
        SettingsGroup("Поток из сети") {
            StreamUserRows(vm, settings)
        }
        return
    }

    SettingsGroup("Сетевой каталог") {
        /*
         * OWN RESOLVER (6.10.0) — first rows of the group, because this is now the main path.
         *
         * 6.9.4 diagnostics: eight internal YouTube clients, both host families, valid poToken,
         * LOGIN_REQUIRED eight times out of eight. The same track answered on the first try when
         * yt-dlp asked from a VPS. Attestation cannot be passed by an APK Google did not sign, so
         * the resolve moved to a machine that has Python, a JS engine and daily yt-dlp updates.
         * Search stays on Innertube: it never broke, it is not attested.
         */
        SettingRow(
            icon = ZiziIcons.Server,
            label = "Свой резолвер",
            subtitle = if (settings.resolverUrl.isBlank())
                "Не задан — поток берётся у YouTube напрямую (не работает: бот-чек)"
            else settings.resolverUrl,
            onClick = { resolverUrlDialog = true }
        )
        if (settings.resolverUrl.isNotBlank()) {
            SettingRow(
                icon = ZiziIcons.Key,
                label = "Токен резолвера",
                // 6.17.0: длина токена больше не показывается — это подсказка тому, кто её видеть
                // не должен, а владельцу она не нужна: он и так знает, что вписал.
                subtitle = if (settings.resolverToken.isBlank()) "Не задан — сервер ответит 401"
                    else "Задан (нажми, чтобы заменить)",
                onClick = { resolverTokenDialog = true }
            )
            SettingSwitch(
                icon = ZiziIcons.CloudDownload,
                label = "Гнать звук через сервер",
                subtitle = "Вкл: /stream, ссылка не привязана к IP телефона. Выкл: прямая ссылка, трафик мимо сервера",
                checked = settings.resolverProxy,
                onChange = vm::setResolverProxy
            )
            SettingRow(
                icon = ZiziIcons.Network,
                label = "Проверить сервер",
                subtitle = resolverStatus ?: "Спросит /health: живой ли сервис и сколько в кэше",
                onClick = vm::probeResolver
            )
        }
        SettingRow(
            icon = ZiziIcons.Globe,
            label = "Источник",
            subtitle = if (settings.catalogProvider == "yt") "YouTube Music" else "Audius",
            onClick = { vm.setCatalogProvider(if (settings.catalogProvider == "yt") "audius" else "yt") }
        )
        StreamUserRows(vm, settings)
        // What is playing, in provider terms.
        //
        // Not a debug leftover either: the stream is produced by picking one of five internal
        // YouTube clients at runtime, and which one survives is decided by attestation, not by us.
        // When playback breaks, the first question is always "which client answered" - this row is
        // the answer, without a build, a log or a cable.
        vm.streamStatusLabel()?.let { status ->
            SettingRow(
                icon = ZiziIcons.Equalizer,
                label = "Активный поток",
                subtitle = status,
                onClick = {}
            )
        }
        SettingRow(
            icon = ZiziIcons.Search,
            label = "Проверить подключение",
            subtitle = probe ?: "Спросит у источника «phonk» и покажет, что он ответил",
            onClick = { vm.probeCatalog() }
        )
        if (probe != null) {
            // The row that finds the 403.
            //
            // "Проверить подключение" proves the catalogue parses; it says nothing about whether
            // the URL it produced can be fetched, and that is precisely where YouTube failed in
            // 6.6.0 - search fine, resolve fine, GET refused. This asks the CDN for two bytes and
            // prints the client that answered plus the HTTP code, which turns "треки сами
            // свайпаются" into one line naming one layer.
            SettingRow(
                icon = ZiziIcons.Network,
                label = "Проверить поток",
                subtitle = "Резолвит первый трек и запрашивает 2 байта с CDN",
                onClick = vm::probeStream
            )
            // FULL DIAGNOSTICS (6.8.1).
            //
            // "Проверить поток" answers with the LAST client's complaint, in a two line subtitle,
            // which is how `LOGIN_REQUIRED «Войдите, чтобы подтвердить, что вы не робот»` reached
            // the user as `ANDROID_VR: Войдите в` and cost a release. This walks every internal
            // client and opens the result in a dialog that can be copied out whole.
            SettingRow(
                icon = ZiziIcons.Bug,
                label = if (reportRunning) "Опрашиваю клиентов…" else "Полная диагностика потока",
                subtitle = "Все клиенты YouTube по очереди, с копированием отчёта",
                onClick = { vm.runStreamReport() }
            )
            SettingRow(
                icon = ZiziIcons.Play,
                label = "Включить найденное",
                subtitle = "Полный тракт: резолв ссылки, кэш, декодер",
                onClick = vm::playProbeResults
            )
        }
    }
}
