package app.ziziplayer.ui;
import org.junit.Test;
public final class CollectionRestore66911Test {
    @Test public void restoredDeepListCannotResurrectArtwork() { CollectionRestore66911Checks.main(new String[0]); }
}
