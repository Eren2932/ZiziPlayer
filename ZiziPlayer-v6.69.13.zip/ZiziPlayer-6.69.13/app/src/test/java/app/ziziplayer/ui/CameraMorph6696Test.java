package app.ziziplayer.ui;

import org.junit.Test;

public final class CameraMorph6696Test {
    @Test public void reversibleMaterialContracts() { CameraMorph6696Checks.main(new String[0]); }
}
