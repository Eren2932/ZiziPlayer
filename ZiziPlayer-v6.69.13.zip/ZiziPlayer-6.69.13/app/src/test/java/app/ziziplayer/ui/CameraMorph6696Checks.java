package app.ziziplayer.ui;

/** Executes the production material and symbiote geometry, including phase boundaries. */
public final class CameraMorph6696Checks {
    private static int assertions;
    private static void ok(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }
    private static void near(float a,float b,float eps,String message) {
        ok(Float.isFinite(a)&&Float.isFinite(b)&&Math.abs(a-b)<=eps,message+": "+a+" vs "+b);
    }
    private static CameraMorphGeometry.Frame frame(float p,CameraMorphGeometry.Target t) {
        return CameraMorphGeometry.frame(716,315.04f,1,369.04f*p,540,164,8,369.04f,110,t);
    }
    // Direct geometry at full admission; independently vary the real inter-body gap.
    private static CameraMorphGeometry.Goo gap(float u,float radius,float scale) {
        float r=18.5f*scale, R=radius*scale;
        CameraMorphGeometry.Target t=new CameraMorphGeometry.Target(-r,-r,r,r);
        CameraMorphGeometry.Frame f=new CameraMorphGeometry.Frame(0,r+R+u*r,2*R,2*R,R,.65f,1,1,0,1);
        return CameraMorphGeometry.goo(t,f);
    }
    private static void same(float[] a,float[] b,String message) {
        ok((a==null)==(b==null),message+" null");
        if(a==null)return;
        ok(a.length==b.length,message+" length");
        for(int i=0;i<a.length;i++)near(a[i],b[i],0,message);
    }
    private static void tangents(float[] commands) {
        if(commands==null)return;
        float x=0,y=0,tx=0,ty=0;
        int i=0;
        boolean previous=false;
        while(i<commands.length) {
            int op=(int)commands[i++];
            if(op==0) {x=commands[i++];y=commands[i++];previous=false;}
            else if(op==1) {
                // A collapsed connector must not erase the incoming tangent and hide
                // a cusp between its two nondegenerate neighbours.
                if(commands[i]==x && commands[i+1]==y && commands[i+2]==x &&
                    commands[i+3]==y && commands[i+4]==x && commands[i+5]==y) { i+=6;continue; }
                float dx=commands[i]-x,dy=commands[i+1]-y;
                double lengths=Math.hypot(dx,dy)*Math.hypot(tx,ty);
                if(previous && Math.hypot(dx,dy)>.1 && Math.hypot(tx,ty)>.1) {
                    ok(Math.abs(dx*ty-dy*tx)/lengths<.01,"G1 tangent continuity");
                    ok(dx*tx+dy*ty>0,"no reversed tangent");
                }
                x=commands[i+4];y=commands[i+5];tx=x-commands[i+2];ty=y-commands[i+3];
                i+=6;previous=true;
            } else previous=false;
        }
    }

    public static void main(String[] args) {
        assertions=0;
        near(CameraMorphGeometry.blurFraction(0),0,0,"expanded sharp");
        near(CameraMorphGeometry.blurFraction(Float.NaN),0,0,"NaN blur safe");
        near(CameraMorphGeometry.blurFraction(-1),0,0,"negative blur safe");
        near(CameraMorphGeometry.blurFraction(1),.075f,.000001f,"bounded blur");
        float previous=0;
        for(int i=0;i<=10000;i++) {
            float b=CameraMorphGeometry.blurFraction(i/10000f);
            ok(b>=previous-.0000002f && b<=.075001f,"monotone blur");
            ok(Math.abs(b-previous)<.00005f,"no blur flash"); previous=b;
        }
        for(float[] pair:new float[][]{{CameraMorphGeometry.GOO_ONSET,0},{CameraMorphGeometry.GOO_CONTACT,1}})
            near(CameraMorphGeometry.reach(pair[0]),pair[1],.000001f,"reach endpoint");
        near(CameraMorphGeometry.waist(CameraMorphGeometry.GOO_CONTACT),0,0,"zero-width first contact");
        near(CameraMorphGeometry.swell(CameraMorphGeometry.GOO_ONSET),0,0,"no swelling pop");
        near(CameraMorphGeometry.reach(CameraMorphGeometry.GOO_ONSET-.0001f)/.0001f,0,.01f,"flat onset");
        near(CameraMorphGeometry.waist(CameraMorphGeometry.GOO_CONTACT-.00001f)/.00001f,0,.1f,"flat contact");
        ok(gap(4.5f,90,1)==null,"no distance-spanning bridge at old onset");
        CameraMorphGeometry.Goo initial=gap(4.25f,90,1);
        ok(initial!=null && initial.ink!=null && initial.flesh==null,"camera leads before artwork responds");
        CameraMorphGeometry.Goo drop=gap(3.5f,90,1);
        ok(drop!=null && !drop.joined && drop.ink!=null,"camera drop precedes connection");
        // Tip of the camera's two forward cubic segments, in window coordinates.
        float tip=drop.ink[9];
        ok(tip>18.5f && tip<18.5f*(1+3.5f),"drop grows from the camera, not the entire gap");
        CameraMorphGeometry.Goo joined=gap(2.9f,90,1);
        ok(joined.joined && joined.ink!=null && joined.flesh!=null,"later connected contour");
        for(float u:new float[]{4.3f,4,3.5f,3.071f,3.069f,3,2.7f,2,1,0,-.5f}) {
            CameraMorphGeometry.Goo g=gap(u,90,1), scaled=gap(u,90,3);
            near(g.u,scaled.u,.00002f,"density invariant proximity");
            near(g.inkStart*3,scaled.inkStart,.001f,"density invariant ink");
            for(float[] path:new float[][]{g.ink,g.flesh}) if(path!=null)
                for(float v:path)ok(Float.isFinite(v),"finite commands");
            for(int y=-20;y<350;y++) {
                float a=g.inkAt(0,y);
                ok(a>=0&&a<=1,"bounded alpha");
            }
            // The LOCAL neck gradient must not reach the body centre; body shading is separate.
            near(g.inkAt(0,18.5f+u*18.5f+90),0,.000001f,"local ink only");
        }
        CameraMorphGeometry.Target[] ts={
            new CameraMorphGeometry.Target(513,48,567,102),new CameraMorphGeometry.Target(30,48,84,102),
            new CameraMorphGeometry.Target(996,48,1050,102),new CameraMorphGeometry.Target(478,48,602,102),
            new CameraMorphGeometry.Target(510,50,570,110),null};
        float maxStep=0;
        for(CameraMorphGeometry.Target t:ts) {
            CameraMorphGeometry.Goo[] gs=new CameraMorphGeometry.Goo[2001];
            float[] last=new float[25];
            int separated=0, connected=0;
            for(int i=0;i<=2000;i++) {
                float p=i/2000f;
                CameraMorphGeometry.Frame f=frame(p,t);
                CameraMorphGeometry.Goo g=CameraMorphGeometry.goo(t,f); gs[i]=g;
                if(p<=.12f)ok(g==null,"no deformation at handoff");
                if(p<=.78f)near(CameraMorphGeometry.bodyBlack(f),0,0,"no early global dimmer");
                if(t==null)ok(g==null,"no invented camera");
                if(g!=null) { if(g.joined) {
                        connected++;
                        ok(g.inkEnd-g.inkStart >= .8f*Math.min(t.width(),t.height())*.5f-.001f,
                            "nonzero gradient span throughout overlap");
                        // A zero-width contact is a topology change; once measurable,
                        // every neighbouring cubic must share its tangent direction.
                        if(CameraMorphGeometry.waist(g.u)*Math.min(t.width(),t.height())*.5f > .5f)
                            tangents(g.ink);
                    } else separated++;
                    for(float[] path:new float[][]{g.ink,g.flesh})if(path!=null)
                        for(float v:path)ok(Float.isFinite(v),"finite actual path");
                }
                for(int y=0;y<5;y++)for(int x=0;x<5;x++) {
                    int k=y*5+x;
                    float ink=g==null?0:g.inkAt(f.left()+f.width*(.1f+.2f*x),f.top()+f.height*(.1f+.2f*y));
                    float alpha=1-(1-ink)*(1-CameraMorphGeometry.bodyBlack(f,g));
                    ok(alpha>=0&&alpha<=1,"finite bounded actual material");
                    if(i>0)maxStep=Math.max(maxStep,Math.abs(alpha-last[k]));last[k]=alpha;
                }
            }
            if(t!=null)ok(separated>10&&connected>10,"both phases must be visible");
            for(int i=2000;i>=0;i--) {
                CameraMorphGeometry.Goo g=CameraMorphGeometry.goo(t,frame(i/2000f,t)), a=gs[i];
                ok((g==null)==(a==null),"exact reverse topology");
                if(g!=null) {
                    same(g.ink,a.ink,"reverse camera");same(g.flesh,a.flesh,"reverse artwork");
                    near(g.inkStart,a.inkStart,0,"reverse ink start");
                    near(g.inkEnd,a.inkEnd,0,"reverse ink end");
                    near(g.inkAlpha,a.inkAlpha,0,"reverse ink alpha");
                }
            }
        }
        ok(maxStep<.03f,"no material switch flash: "+maxStep);
        System.out.println("PASS: "+assertions+" production symbiote/material assertions, max step="+maxStep+" (not Android rendering)");
    }
}
