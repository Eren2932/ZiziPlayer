package app.ziziplayer.ui;

/** Executes production math, not Compose lifecycle/Android rendering. */
public final class CollectionRestore66911Checks {
    static int checks;
    static void ok(boolean b, String message) {
        checks++; if (!b) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var t = new CameraMorphGeometry.Target(521.5f,50,558.5f,87);
        for (float scale : new float[]{.5f,.75f,1,1.5f,2,3}) {
            float travel = 369.04f*scale;
            for (int index : new int[]{1,2,12,600,10000})
                for (float hero : new float[]{0,1,100,500,1000,Float.NaN}) {
                    float scroll = CollectionCollapseMath.visualScroll(index,0,hero*scale,travel);
                    ok(Float.isFinite(scroll) && scroll>=travel,"offscreen hero completes morph even unmeasured");
                    for (var target : new CameraMorphGeometry.Target[]{t,null}) {
                        var f=CameraMorphGeometry.frame(716*scale,315.04f*scale,1,scroll,
                            540*scale,164*scale,8*scale,travel,110*scale,target);
                        ok(f.progress==1 && f.imageAlpha==0 && f.anchorAlpha==0,"no restored ghost artwork");
                    }
                    // Repeat entering/leaving: no accumulated or saved pixel dependency.
                    ok(scroll==CollectionCollapseMath.visualScroll(index,0,hero*scale,travel),"deterministic restore");
                }
            for(int offset=0;offset<10000;offset+=7) {
                float scroll=CollectionCollapseMath.visualScroll(0,offset,0,travel);
                ok(scroll==offset,"partially visible hero uses exact list offset");
            }
            ok(CollectionCollapseMath.visualScroll(0,0,0,travel)==0,"expanded state stays expanded");
            ok(CollectionCollapseMath.visualScroll(0,-1,0,travel)==0,"nonnegative scroll");
        }
        System.out.println("PASS: "+checks+" restoration geometry assertions (not Android)");
    }
}
