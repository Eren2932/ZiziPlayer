# Обновление workflow

Скопировать `.github/workflows/build.yml` из этой папки в `.github/workflows/build.yml`
самого репозитория. Одного обновления ZIP исходников недостаточно.

Обычная сборка — без эмуляторов. API 28/35 доступны отдельно через
Run workflow → run_camera_tests. JVM-тесты и проверка подписи сохранены.
Подробнее: RELEASE_v6.69.11.md в корне проекта.
