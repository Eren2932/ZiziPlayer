package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.components.SearchFilterRail
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Added to the Android suite; needs an emulator/device, not the offline Python runner. */
class SearchFilterRailTest {
    @get:Rule val compose = createComposeRule()
    private val selected = mutableStateOf(SearchTab.ALL)
    private var density = 1f
    private fun mount(width: Int = 360) {
        compose.setContent {
            density = LocalDensity.current.density
            Box(Modifier.width(width.dp)) {
                SearchFilterRail(selected.value) { selected.value = it }
            }
        }
        compose.waitForIdle()
    }
    private fun x(tab: SearchTab) = compose.onNodeWithTag("search-filter-${tab.name}")
        .fetchSemanticsNode().boundsInRoot.left

    @Test fun selectedChipMovesContinuouslyAndResetReturnsToOrigin() {
        mount()
        compose.onNodeWithTag("search-filter-PLAYLISTS").performScrollTo()
        val origin = x(SearchTab.PLAYLISTS)
        val rail = compose.onNodeWithTag("search-filter-rail").fetchSemanticsNode().boundsInRoot.left
        compose.mainClock.autoAdvance = false
        compose.onNodeWithTag("search-filter-PLAYLISTS").performClick()
        compose.mainClock.advanceTimeBy(96)
        val middle = x(SearchTab.PLAYLISTS)
        compose.mainClock.advanceTimeBy(400)
        val end = x(SearchTab.PLAYLISTS)
        assertTrue(middle < origin)
        assertTrue(middle > end)
        assertEquals(rail + 57f * density, end, 2f)
        compose.onNodeWithTag("search-filter-reset").performClick()
        compose.mainClock.advanceTimeBy(400)
        assertEquals(origin, x(SearchTab.PLAYLISTS), 2f)
        compose.mainClock.autoAdvance = true
    }

    @Test fun lastChipCanBeSelectedAfterHorizontalScrollOnNarrowScreen() {
        mount(280)
        compose.onNodeWithTag("search-filter-ARTISTS").performScrollTo().performClick()
        compose.onNodeWithTag("search-filter-ARTISTS").assertIsDisplayed()
        val rail = compose.onNodeWithTag("search-filter-rail").fetchSemanticsNode().boundsInRoot.left
        assertEquals(rail + 57f * density, x(SearchTab.ARTISTS), 2f)
        compose.onNodeWithTag("search-filter-reset").performClick()
        compose.onNodeWithTag("search-filter-ARTISTS").assertIsDisplayed()
    }

    @Test fun resetDuringMotionReversesWithoutReplacingChip() {
        mount()
        compose.onNodeWithTag("search-filter-PLAYLISTS").performScrollTo()
        val origin = x(SearchTab.PLAYLISTS)
        compose.mainClock.autoAdvance = false
        compose.onNodeWithTag("search-filter-PLAYLISTS").performClick()
        compose.mainClock.advanceTimeBy(80)
        val middle = x(SearchTab.PLAYLISTS)
        compose.onNodeWithTag("search-filter-reset").performClick()
        compose.mainClock.advanceTimeBy(16)
        val reversing = x(SearchTab.PLAYLISTS)
        assertTrue(reversing >= middle - 2f)
        assertTrue(reversing < origin)
        compose.mainClock.advanceTimeBy(400)
        assertEquals(origin, x(SearchTab.PLAYLISTS), 2f)
        compose.mainClock.autoAdvance = true
    }
}
