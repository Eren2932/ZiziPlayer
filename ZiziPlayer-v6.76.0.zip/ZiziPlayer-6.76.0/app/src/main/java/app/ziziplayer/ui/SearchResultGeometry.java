package app.ziziplayer.ui;

/** Search-only metrics. Do not change the library, collection rows or search editor. */
public final class SearchResultGeometry {
    private SearchResultGeometry() {}
    public static final float EDGE_DP = 16f;
    public static final float ART_DP = 48f;
    public static final float ROW_DP = 64f;
    public static final float TEXT_GAP_DP = 12f;
    public static final float CHIP_DP = 30f;
    public static final float TOUCH_DP = 48f;
    public static final int FILTER_DURATION_MS = 280;

    private static float unit(float value) { return Math.max(0f, Math.min(1f, value)); }
    /** Coordinates are in the scrolling content; subtract scroll only when drawing on screen. */
    public static float filterX(float naturalX, float selectedNaturalX, float scroll,
                                float selectedViewportX, float progress) {
        return naturalX + (scroll + selectedViewportX - selectedNaturalX) * unit(progress);
    }
    public static float siblingAlpha(float progress) { return 1f - unit(progress / 0.55f); }
    public static boolean nearEnd(int lastVisible, int layoutItems) {
        return lastVisible >= 0 && layoutItems > 0 && lastVisible >= Math.max(0, layoutItems - 4);
    }
}
