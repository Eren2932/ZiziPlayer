package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.SearchResultGeometry
import app.ziziplayer.ui.SearchTab
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.roundToInt

private val FILTERS = listOf(SearchTab.ALBUMS, SearchTab.TRACKS, SearchTab.PLAYLISTS, SearchTab.ARTISTS)

/**
 * One persistent, measured rail; NOT inside the tab's SaveableStateProvider.
 * Selecting translates the actual chip from its scrolled position to the reset button.
 * All children keep their identity/width throughout both directions. No cloned label,
 * delayed coroutine scroll, disappearing anchor or second clickable overlay.
 */
@Composable
internal fun SearchFilterRail(selectedTab: SearchTab, onTab: (SearchTab) -> Unit) {
    val palette = LocalPalette.current
    val scroll = rememberScrollState()
    var movingTab by remember { mutableStateOf(selectedTab.takeUnless { it == SearchTab.ALL }) }
    val progress = remember { Animatable(if (selectedTab == SearchTab.ALL) 0f else 1f) }
    LaunchedEffect(selectedTab) {
        if (selectedTab != SearchTab.ALL) movingTab = selectedTab
        // Animatable obeys the system MotionDurationScale, including zero/reduced motion.
        // Reset mid-flight cancels this animation and reverses from its current value.
        progress.animateTo(if (selectedTab == SearchTab.ALL) 0f else 1f,
            tween(SearchResultGeometry.FILTER_DURATION_MS, easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)))
    }
    BoxWithConstraints(Modifier.fillMaxWidth().clipToBounds().testTag("search-filter-rail")) {
        val viewport = maxWidth
        val expanded = selectedTab == SearchTab.ALL && progress.value == 0f
        Layout(
            modifier = Modifier.horizontalScroll(scroll, enabled = expanded),
            content = {
                val canReset = selectedTab != SearchTab.ALL
                Box(
                    Modifier.size(SearchResultGeometry.TOUCH_DP.dp)
                        .then(if (canReset) Modifier else Modifier.clearAndSetSemantics { })
                        .clip(CircleShape).clickable(enabled = canReset, role = Role.Button,
                            onClickLabel = "Сбросить фильтр") { onTab(SearchTab.ALL) }
                        .testTag("search-filter-reset"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(SearchResultGeometry.CHIP_DP.dp).clip(CircleShape)
                        .background(palette.chip), contentAlignment = Alignment.Center) {
                        Icon(ZiziIcons.Close, "Сбросить фильтр", tint = palette.text, modifier = Modifier.size(19.dp))
                    }
                }
                FILTERS.forEach { tab ->
                    val enabled = expanded || selectedTab == tab
                    val active = movingTab == tab
                    Box(
                        Modifier.heightIn(min = SearchResultGeometry.TOUCH_DP.dp)
                            .then(if (enabled) Modifier else Modifier.clearAndSetSemantics { })
                            .clickable(enabled = enabled, role = Role.Tab) { onTab(tab) }
                            .semantics { selected = selectedTab == tab }
                            .testTag("search-filter-${tab.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.heightIn(min = SearchResultGeometry.CHIP_DP.dp).clip(CircleShape)
                            .background(lerp(palette.chip, palette.brand, if (active) progress.value else 0f))
                            .padding(horizontal = 12.dp, vertical = 5.dp), contentAlignment = Alignment.Center) {
                            Text(tab.label, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                                color = lerp(palette.text, palette.onBrand, if (active) progress.value else 0f))
                        }
                    }
                }
            }
        ) { measurables, constraints ->
            val childConstraints = Constraints(maxWidth = viewport.roundToPx(), maxHeight = constraints.maxHeight)
            val places = measurables.map { it.measure(childConstraints) }
            val edge = SearchResultGeometry.EDGE_DP.dp.toPx()
            val gap = 8.dp.roundToPx()
            val resetStart = edge - 9.dp.toPx()
            val target = resetStart + places[0].width + 2.dp.toPx()
            var cursor = edge
            val natural = places.drop(1).map { child -> cursor.also { cursor += child.width + gap } }
            val activeIndex = FILTERS.indexOf(movingTab).coerceAtLeast(0)
            val origin = natural[activeIndex]
            val contentWidth = maxOf(viewport.roundToPx(), (cursor - gap + edge).roundToInt())
            val height = places.maxOf { it.height }
            // Width stays constant even when collapsed, so ScrollState cannot clamp halfway.
            layout(contentWidth, height) {
                val amount = progress.value
                if (amount > 0f) places[0].placeRelativeWithLayer(
                    (scroll.value + resetStart - 8.dp.toPx() * (1f - amount)).roundToInt(),
                    (height - places[0].height) / 2
                ) { alpha = amount }
                places.drop(1).forEachIndexed { index, child ->
                    val alpha = if (index == activeIndex) 1f else SearchResultGeometry.siblingAlpha(amount)
                    if (alpha > 0f) child.placeRelativeWithLayer(
                        SearchResultGeometry.filterX(natural[index], origin, scroll.value.toFloat(), target, amount).roundToInt(),
                        (height - child.height) / 2
                    ) { this.alpha = alpha }
                }
            }
        }
    }
}
