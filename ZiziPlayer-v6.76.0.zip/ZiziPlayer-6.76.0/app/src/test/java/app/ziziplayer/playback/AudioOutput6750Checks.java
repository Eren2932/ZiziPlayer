package app.ziziplayer.playback;

import app.ziziplayer.ui.components.MiniPlayerGeometry;

/** Executes production Java, without Android mocks or a reimplementation of the production policy. */
public final class AudioOutput6750Checks {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for (int actual = -1; actual < 5; actual++)
            for (int planned = -1; planned < 5; planned++)
                for (int remembered = -1; remembered < 5; remembered++)
                    for (int mask = 0; mask < 32; mask++) {
                        int[] ids = new int[Integer.bitCount(mask)];
                        int j = 0;
                        for (int id = 0; id < 5; id++) if ((mask & (1 << id)) != 0) ids[j++] = id;
                        int value = AudioRoutePolicy.select(actual, planned, remembered, ids);
                        if (actual >= 0) check(value == actual, "actual beats planned/remembered");
                        else if (planned >= 0) check(value == planned, "planned beats remembered");
                        else if (remembered >= 0 && (mask & (1 << remembered)) != 0)
                            check(value == remembered, "remember only connected");
                        else check(value == -1, "never invent active route from connection order");
                    }
        check(AudioRoutePolicy.select(102, 101, 101, new int[]{101,102}) == 102, "two A2DP identities");
        check(AudioRoutePolicy.select(-1, -1, 101, new int[]{102}) == -1, "unplug clears old identity");
        check(AudioRoutePolicy.select(-1, -1, -1, null) == -1, "inventory denied");
        check(MiniPlayerGeometry.progress("new", "old", 90,100) == 0f, "no previous track tail");
        check(MiniPlayerGeometry.progress("new", null, 90,100) == 0f, "no anonymous progress");
        check(MiniPlayerGeometry.progress("a", "a", 10,0) == 0f, "unknown duration");
        check(MiniPlayerGeometry.progress("a", "a", -50,100) == 0f, "negative position");
        check(MiniPlayerGeometry.progress("a", "a", Long.MAX_VALUE,100) == 1f, "overflow clamp");
        check(MiniPlayerGeometry.progress("a", "a", 50,100) == .5f, "normal progress");
        check(MiniPlayerGeometry.progress(null, null, 5,10) == 0f, "no track");
        for (int width = 280; width <= 840; width++) {
            float text = width - 2*MiniPlayerGeometry.EDGE - 16 - MiniPlayerGeometry.ART - 12 - 4 - 3*MiniPlayerGeometry.CONTROL;
            check(text >= 72, "text slot stays positive on narrow phones");
        }
        for (int scale = 80; scale <= 250; scale++) {
            float fontScale = scale / 100f;
            float height = MiniPlayerGeometry.height(fontScale);
            check(height >= 56 && height >= 32*fontScale, "accessible two-line text fits");
        }
        final float density = 2.875f;
        check(Math.round(MiniPlayerGeometry.EDGE*density) == 23, "reference x=23");
        check(Math.round(MiniPlayerGeometry.HEIGHT*density) == 161, "reference height ~=161/162 px");
        check(Math.round(MiniPlayerGeometry.ART*density) == 115, "reference art ~=115/116 px");
        check(Math.round(2400-(46+MiniPlayerGeometry.DOCK_GAP+MiniPlayerGeometry.HEIGHT)*density) == 2075,
            "reference vertical position with existing tabs, no bottom system inset");
        System.out.println("PASS AudioOutput6750Checks: " + checks + " assertions (Java policy/math, NOT Android rendering)");
    }
}
