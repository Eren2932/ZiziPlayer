package app.ziziplayer.playback;

import org.junit.Test;

/** Run the same production-policy checks in Gradle's JVM gate, not just the offline runner. */
public final class AudioOutput6750Test {
    @Test public void routingAndGeometryRespectTheirContracts() {
        AudioOutput6750Checks.main(new String[0]);
    }
}
