"""Static Android wiring checks, not Kotlin/SDK execution."""
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[1]
S=R/'app/src/main/java/app/ziziplayer'
def source(name):return (S/name).read_text()
class Account6510Contracts(unittest.TestCase):
    def test_isolated_http_and_fail_closed_rotation(self):
        s=source('account/AccountRepository.kt')
        for text in ('Mutex()', 'lane.withLock', 'Dispatchers.IO + NonCancellable',
                     '.followRedirects(false)', '.followSslRedirects(false)', '.retryOnConnectionFailure(false)',
                     'cookie.secure && cookie.httpOnly && cookie.hostOnly', 'SameSite=Strict',
                     'vault.write(nextRefresh.toString())', 'source.request(limit + 1)'):
            self.assertIn(text,s)
        for text in ('SessionWebToken','ZiziResolve','addInterceptor','println(', 'Log.'):
            self.assertNotIn(text,s)
    def test_refresh_encrypted_and_excluded_from_backup(self):
        s=source('account/AccountSessionVault.kt')
        for text in ('AndroidKeyStore', 'AES/GCM/NoPadding', 'context.noBackupFilesDir',
                     'cipher.updateAAD(origin.toByteArray', 'AtomicFile', 'file.failWrite(stream)'):
            self.assertIn(text,s)
        self.assertIn('android:allowBackup="false"',(R/'app/src/main/AndroidManifest.xml').read_text())
    def test_native_google_with_server_nonce(self):
        s=source('account/GoogleAccountSignIn.kt')
        for text in ('CredentialManager.create', 'repository.googleChallenge()',
                     '.setNonce(challenge.getString("nonce"))', 'repository.googleLogin'):
            self.assertIn(text,s)
        for text in ('WebView(', 'client_secret', 'markSignedIn'):self.assertNotIn(text,s)
    def test_password_not_saveable_or_logged(self):
        s=source('ui/screens/AccountAuthScreen.kt')
        for text in ('rememberSaveable','Log.','println(', 'SharedPreferences'):
            self.assertNotIn(text,s)
        self.assertIn('PasswordVisualTransformation()',s)
        self.assertIn('if (!wasSecure) activity.window.clearFlags',s)
    def test_no_media_mutations(self):
        for p in (S/'account').glob('*'):
            if p.suffix not in ('.kt','.java'):continue
            for text in ('clearAllTables(', 'deleteDatabase(', 'TrackDao', 'AppDatabase', 'Room.databaseBuilder'):
                self.assertNotIn(text,p.read_text())
    def test_preferences_not_identity_proof(self):
        self.assertIn('if (storedMode == AccountGate.Mode.SIGNED_IN) AccountGate.Mode.GUEST', source('account/AccountStore.kt'))
        self.assertIn('accountRepository.restore()?.let { accounts.markSignedIn',source('MainActivity.kt'))
    def test_no_sync_claim(self):
        self.assertIn('Перед удалением приложения проверьте подтверждение сохранения.', source('ui/screens/WelcomeScreen.kt'))
        self.assertIn('Сам вход ещё не означает, что данные отправлены.',source('ui/screens/AccountScreen.kt'))
    def test_build_configuration_defaults_off(self):
        s=(R/'app/build.gradle.kts').read_text()
        self.assertIn('System.getenv("ACCOUNT_URL") ?: ""',s)
        self.assertIn('System.getenv("GOOGLE_WEB_CLIENT_ID") ?: ""',s)
        self.assertIn('versionCode = 116',s)
        self.assertIn('versionName = "6.61.1-lyrics-exp"',s)
if __name__=='__main__':unittest.main(verbosity=2)
