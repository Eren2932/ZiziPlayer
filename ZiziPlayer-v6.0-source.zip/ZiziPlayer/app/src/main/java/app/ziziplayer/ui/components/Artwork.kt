package app.ziziplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections

const val ARTWORK_ROW_PX = 160
const val ARTWORK_FULL_PX = 640

/**
 * Three colours pulled out of one cover: the accent, a second shade for depth, and a deep one for
 * the far ends of the gradient. v5 used a single seed, so the whole screen was one flat wash of
 * colour. Reference players build the backdrop out of several shades of the same cover, which is
 * why it reads as "the cover flew across the screen" instead of "someone tinted the app brown".
 */
@Immutable
data class ArtSwatches(val primary: Color, val secondary: Color, val deep: Color) {
    fun pack(): String = "${primary.toArgb()},${secondary.toArgb()},${deep.toArgb()}"

    companion object {
        fun unpack(raw: String?): ArtSwatches? {
            val parts = raw?.split(',') ?: return null
            if (parts.size != 3) return null
            val ints = parts.map { it.toIntOrNull() ?: return null }
            return ArtSwatches(Color(ints[0]), Color(ints[1]), Color(ints[2]))
        }
    }
}

/** One decoded cover. The ImageBitmap wrapper is built once, not on every recomposition. */
@Immutable
class Art(val image: ImageBitmap, val kb: Int, val swatches: ArtSwatches?)

/**
 * Artwork pipeline, third rewrite - this time for a 3000 track library.
 *
 * The order of attempts:
 *   1. in-memory LruCache                       (instant, no allocation)
 *   2. on-disk thumbnail cache                  (~1 ms, survives app restarts)
 *   3. MediaStore album art / loadThumbnail     (cheap, system side cache)
 *   4. MediaMetadataRetriever                   (20-120 ms - NEVER from a visible row)
 *
 * The single most important rule: a scrolling row is only ever allowed to use steps 1-3.
 * v5 let every row start step 4, so scrolling a 400 track list queued 400 file parses behind a
 * one-permit semaphore - the list could not be smooth, whatever else was optimised. Step 4 now
 * belongs to [ArtworkPrefetcher], which walks the library in the background, pauses while the
 * finger is down, and writes the result to disk so it is paid exactly once per file, ever.
 */
object ArtworkCache {
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceIn(6 * 1024, 48 * 1024)
    private val memory = object : LruCache<String, Art>(maxKb) {
        override fun sizeOf(key: String, value: Art): Int = value.kb
    }
    private val swatchMemory = LruCache<String, ArtSwatches>(2048)
    private val noArt = Collections.synchronizedSet(HashSet<String>())
    private val fastGate = Semaphore(2)
    private val slowGate = Semaphore(1)

    @Volatile private var busyUntilMs = 0L
    @Volatile private var index: ArtworkIndex? = null
    @Volatile private var dir: File? = null

    private fun key(id: String, px: Int) = "$id@$px"

    fun attach(context: Context) {
        if (index != null) return
        val app = context.applicationContext
        val store = ArtworkIndex(app)
        index = store
        noArt.addAll(store.noArtIds())
        store.swatches().forEach { (id, swatches) -> swatchMemory.put(id, swatches) }
        val cacheDir = File(app.cacheDir, "artwork").apply { mkdirs() }
        dir = cacheDir
        // Keep the thumbnail cache bounded: oldest files go first.
        CoroutineScope(Dispatchers.IO).launch { prune(cacheDir) }
    }

    /** Called by every scrollable list: while the finger moves, nothing expensive may start. */
    fun markBusy() { busyUntilMs = System.currentTimeMillis() + 260 }
    fun isBusy(): Boolean = System.currentTimeMillis() < busyUntilMs

    /** Exactly the requested size, or nothing. */
    fun peekExact(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px))
    }

    /**
     * Anything usable right now, including a smaller thumbnail of the same cover. Used purely as a
     * stand-in for the first frame so nothing ever flashes a grey placeholder while the full size
     * decodes - it never replaces the real load.
     */
    fun peek(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px)) ?: if (px > ARTWORK_ROW_PX) memory.get(key(id, ARTWORK_ROW_PX)) else null
    }

    fun peekSwatches(track: TrackEntity?): ArtSwatches? = track?.let { swatchMemory.get(it.id) }

    /** Flushes the batched "no art" / colour verdicts to disk. */
    fun flushIndex() { index?.flush() }

    fun hasNoArt(track: TrackEntity?): Boolean = track != null && noArt.contains(track.id)

    /** True when this track needs no further work at all - used to skip cheaply while prefetching. */
    fun isSettled(id: String): Boolean =
        memory.get(key(id, ARTWORK_ROW_PX)) != null || noArt.contains(id) || fileFor(id, ARTWORK_ROW_PX)?.exists() == true

    suspend fun load(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        val cacheKey = key(track.id, px)
        memory.get(cacheKey)?.let { return it }
        if (noArt.contains(track.id)) return null

        // 2. disk
        withContext(Dispatchers.IO) { readDisk(track.id, px) }?.let { bitmap ->
            return finish(track, px, bitmap, writeDisk = false)
        }

        // 3. fast system paths
        val fast = fastGate.withPermit {
            memory.get(cacheKey) ?: withContext(Dispatchers.IO) {
                fromArtworkUri(context, track, px) ?: fromThumbnail(context, track, px)
            }
        }
        if (fast != null) return finish(track, px, fast, writeDisk = true)
        if (!allowSlow) return null

        // 4. the expensive one, one at a time, never while scrolling
        val slow = fromEmbedded(context, track, px)
        if (slow != null) return finish(track, px, slow, writeDisk = true)
        noArt.add(track.id)
        index?.rememberNoArt(track.id)
        return null
    }

    private fun finish(track: TrackEntity, px: Int, bitmap: Bitmap, writeDisk: Boolean): Art {
        var swatches = swatchMemory.get(track.id)
        if (swatches == null) {
            swatches = extract(bitmap)
            if (swatches != null) {
                swatchMemory.put(track.id, swatches)
                index?.rememberSwatches(track.id, swatches)
            }
        }
        val art = Art(bitmap.asImageBitmap(), (bitmap.byteCount / 1024).coerceAtLeast(1), swatches)
        memory.put(key(track.id, px), art)
        if (writeDisk) CoroutineScope(Dispatchers.IO).launch { writeDisk(track.id, px, bitmap) }
        return art
    }

    /**
     * Palette on a 160 px thumbnail costs 2-4 ms and happens on a background thread exactly once
     * per track in the app's lifetime, then it is persisted. v5 ran it from composition through a
     * produceState every time the current track changed.
     */
    private fun extract(bitmap: Bitmap): ArtSwatches? = runCatching {
        val palette = Palette.from(bitmap).maximumColorCount(20).resizeBitmapArea(72 * 72).generate()
        val vibrant = palette.vibrantSwatch?.rgb ?: palette.lightVibrantSwatch?.rgb
        val muted = palette.mutedSwatch?.rgb ?: palette.darkMutedSwatch?.rgb
        val dominant = palette.dominantSwatch?.rgb
        val dark = palette.darkVibrantSwatch?.rgb ?: palette.darkMutedSwatch?.rgb
        val primary = vibrant ?: dominant ?: muted ?: return@runCatching null
        ArtSwatches(
            primary = Color(primary),
            secondary = Color(muted ?: dominant ?: primary),
            deep = Color(dark ?: dominant ?: primary)
        )
    }.getOrNull()

    // ---------------- sources ----------------

    private fun fromArtworkUri(context: Context, track: TrackEntity, px: Int): Bitmap? {
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { decode(it.readBytes(), px) }
        }.getOrNull()
    }

    private fun fromThumbnail(context: Context, track: TrackEntity, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            context.contentResolver.loadThumbnail(Uri.parse(track.uri), Size(px, px), null)
        }.getOrNull()
    }

    private suspend fun fromEmbedded(context: Context, track: TrackEntity, px: Int): Bitmap? =
        slowGate.withPermit {
            var guard = 0
            while (isBusy() && guard < 60) { delay(80); guard++ }
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(track.uri))
                        retriever.embeddedPicture
                    } finally {
                        runCatching { retriever.release() }
                    }
                }.getOrNull()
            } ?: return@withPermit null
            decode(bytes, px)
        }

    // ---------------- disk ----------------

    private fun fileFor(id: String, px: Int): File? {
        val base = dir ?: return null
        val digest = MessageDigest.getInstance("SHA-1").digest(id.toByteArray())
        val name = StringBuilder(digest.size * 2)
        for (byte in digest) name.append("%02x".format(byte))
        return File(base, "$name-$px.webp")
    }

    private fun readDisk(id: String, px: Int): Bitmap? {
        val file = fileFor(id, px)?.takeIf { it.exists() } ?: return null
        val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
        val bitmap = runCatching { BitmapFactory.decodeFile(file.absolutePath, options) }.getOrNull()
        if (bitmap == null) runCatching { file.delete() }
        return bitmap
    }

    private fun writeDisk(id: String, px: Int, bitmap: Bitmap) {
        val file = fileFor(id, px) ?: return
        runCatching {
            val tmp = File(file.absolutePath + ".tmp")
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            }
            tmp.outputStream().use { bitmap.compress(format, 82, it) }
            if (!tmp.renameTo(file)) tmp.delete()
        }
    }

    private fun prune(base: File) {
        runCatching {
            val files = base.listFiles() ?: return
            var total = files.sumOf { it.length() }
            val cap = 40L * 1024 * 1024
            if (total <= cap) return
            files.sortedBy { it.lastModified() }.forEach { file ->
                if (total <= cap / 2) return
                total -= file.length()
                file.delete()
            }
        }
    }

    private fun decode(bytes: ByteArray, px: Int): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        var sample = 1
        while (largest / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

/**
 * Walks the library in the background and pays the expensive cover probe once per file, writing
 * both the thumbnail and the extracted colours to disk. Pauses whenever a list is being scrolled,
 * so it can never compete with the finger.
 */
object ArtworkPrefetcher {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastTracks: List<TrackEntity> = emptyList()
    private var appContext: Context? = null

    fun submit(context: Context, tracks: List<TrackEntity>) {
        job?.cancel()
        if (tracks.isEmpty()) return
        val app = context.applicationContext
        appContext = app
        lastTracks = tracks
        job = scope.launch {
            var done = 0
            for (track in tracks) {
                if (!isActive) return@launch
                if (ArtworkCache.isSettled(track.id)) continue
                while (ArtworkCache.isBusy()) {
                    if (!isActive) return@launch
                    delay(160)
                }
                ArtworkCache.load(app, track, ARTWORK_ROW_PX, allowSlow = true)
                done++
                if (done % 24 == 0) ArtworkCache.flushIndex()
                delay(8)
            }
            ArtworkCache.flushIndex()
        }
    }

    fun stop() { job?.cancel(); job = null }

    /**
     * Restarts indexing after the app comes back to the foreground. Without this the composition
     * survives backgrounding, the LaunchedEffect never re-runs, and indexing would stay dead for
     * the rest of the process.
     */
    fun resume() {
        val app = appContext ?: return
        if (job?.isActive == true) return
        submit(app, lastTracks)
    }
}

/**
 * Placeholder colours for a track with no cover at all.
 *
 * v5 picked one of eight hardcoded pairs, so in a folder of 400 untagged files every eighth tile
 * was literally the same green. The hue is now derived from the file identity across the full
 * circle: two different tracks share a shade only by accident, and the player backdrop built from
 * this pair is unique too.
 */
fun fallbackSwatches(track: TrackEntity?): ArtSwatches {
    val id = track?.id ?: "zizi"
    var hash = 0x811C9DC5.toInt()
    for (index in id.indices) hash = (hash xor id[index].code) * 0x01000193
    val hue = ((hash ushr 8) % 360 + 360) % 360
    val drift = 18 + ((hash ushr 3) and 0x1F)
    fun hsv(h: Int, s: Float, v: Float) =
        Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360) + 360f) % 360f, s, v)))
    return ArtSwatches(
        primary = hsv(hue, 0.62f, 0.74f),
        secondary = hsv(hue + drift, 0.70f, 0.52f),
        deep = hsv(hue - drift / 2, 0.78f, 0.34f)
    )
}

fun fallbackColors(track: TrackEntity?): Pair<Color, Color> {
    val swatches = fallbackSwatches(track)
    return swatches.primary to swatches.deep
}

/**
 * Deliberately NOT produceState.
 *
 * produceState keeps the previous value when its keys change - it only restarts the producer. In a
 * recycled list row, and in the player when the track changes, that means the widget would keep
 * showing the cover of the *previous* track until the new one finished decoding, and if the new
 * track had no cover at all it would show the wrong artwork forever.
 *
 * remember(key) re-seeds synchronously from the in-memory cache instead: a cached cover appears on
 * the very first frame (no grey flash while scrolling) and a cache miss starts exactly one load.
 */
@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int, allowSlow: Boolean = false): Art? {
    val context = LocalContext.current
    val id = track?.id
    val holder = remember(id, maxPx) { mutableStateOf(ArtworkCache.peekExact(track, maxPx)) }
    LaunchedEffect(id, maxPx, allowSlow) {
        val target = track ?: return@LaunchedEffect
        if (holder.value == null) holder.value = ArtworkCache.load(context, target, maxPx, allowSlow)
    }
    // While a bigger size decodes, the smaller thumbnail of the same cover stands in for it.
    return holder.value ?: ArtworkCache.peek(track, maxPx)
}

/** Colours that drive the whole backdrop. Never blocks: falls back to the per-track hue. */
@Composable
fun rememberArtSwatches(track: TrackEntity?, enabled: Boolean): ArtSwatches? {
    if (!enabled) return null
    val art = rememberArtwork(track, ARTWORK_ROW_PX, allowSlow = true)
    val fallback = remember(track?.id) { fallbackSwatches(track) }
    val cached = ArtworkCache.peekSwatches(track)
    return when {
        art?.swatches != null -> art.swatches
        cached != null -> cached
        track == null -> null
        else -> fallback
    }
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44,
    allowSlow: Boolean = false
) {
    val art = rememberArtwork(track, maxPx, allowSlow)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val colors = remember(track?.id) { fallbackSwatches(track) }
            Canvas(Modifier.fillMaxSize()) {
                drawRect(
                    Brush.linearGradient(
                        listOf(colors.primary, colors.deep),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height)
                    )
                )
            }
            Text(
                text = "\u266A",
                color = Color.White.copy(alpha = 0.80f),
                fontSize = glyphSize.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
