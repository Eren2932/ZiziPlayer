package app.ziziplayer.ui.screens

import android.app.Activity
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.exceptions.GetCredentialCancellationException
import app.ziziplayer.account.AccountApiException
import app.ziziplayer.account.AccountRepository
import app.ziziplayer.account.GoogleAccountSignIn
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Passwords/codes only in non-saveable memory. No Room writes or implicit media upload. */
@Composable
fun AccountAuthScreen(
    activity: Activity,
    repository: AccountRepository,
    onSignedIn: (String) -> Unit,
    onClose: () -> Unit
) {
    val p = LocalPalette.current
    var mode by remember { mutableStateOf("login") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var googleAvailable by remember { mutableStateOf(false) }
    LaunchedEffect(repository) {
        if (GoogleAccountSignIn.configured) {
            try { googleAvailable = repository.capabilities().optBoolean("google_enabled", false) }
            catch (error: CancellationException) { throw error }
            catch (_: Exception) { googleAvailable = false }
        }
    }
    val scope = rememberCoroutineScope()
    BackHandler { if (!busy) onClose() }
    DisposableEffect(activity) {
        val wasSecure = activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (!wasSecure) activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun switch(next: String) {
        mode = next; password = ""; confirmation = ""; code = ""; message = ""
    }

    fun launchAction(action: String) {
        if (busy) return
        if (action in setOf("register", "reset") && password != confirmation) {
            message = "Пароли не совпадают"; return
        }
        if (action in setOf("register", "login", "reset") && password.length !in 12..128) {
            message = "Пароль должен содержать от 12 до 128 символов"; return
        }
        busy = true; message = ""
        scope.launch {
            try {
                val result = if (action == "google") GoogleAccountSignIn.signIn(activity, repository)
                    else repository.submit(action, email, password, code)
                password = ""; confirmation = ""; code = ""
                when (action) {
                    "login", "google" -> onSignedIn(result.getString("email"))
                    "register", "resend" -> {
                        mode = "verify"
                        message = result.optString("message", "Проверьте почту, включая папку «Спам».")
                    }
                    "forgot" -> { mode = "reset"; message = result.optString("message") }
                    "verify" -> { mode = "login"; message = "Почта подтверждена. Теперь войдите." }
                    "reset" -> { mode = "login"; message = "Пароль изменён. Прежние сессии отозваны. Войдите заново." }
                }
            } catch (error: CancellationException) {
                throw error
            } catch (_: GetCredentialCancellationException) {
                message = "Вход через Google отменён"
            } catch (error: Exception) {
                message = accountErrorMessage(error)
            } finally { busy = false }
        }
    }

    Column(
        Modifier.fillMaxSize().background(p.background).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onClose, enabled = !busy) { Text("Назад", color = p.text) }
        Text(when (mode) {
            "register" -> "Создать аккаунт"
            "verify" -> "Подтвердить почту"
            "forgot" -> "Восстановить доступ"
            "reset" -> "Новый пароль"
            else -> "Войти в ZiziPlayer"
        }, color = p.text, fontSize = 25.sp)
        Text("Аккаунт не включает синхронизацию: избранное, плейлисты и история пока только на этом телефоне.",
            color = p.subtext, fontSize = 13.sp)
        if (mode in setOf("login", "register", "forgot", "verify")) {
            OutlinedTextField(value = email, onValueChange = { email = it.take(254) },
                label = { Text("Почта") }, singleLine = true, enabled = !busy,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        }
        if (mode in setOf("verify", "reset")) {
            Text("Вставьте полный одноразовый код из письма. Он действует 30 минут; повторный запрос заменяет предыдущий код.", color = p.subtext)
            OutlinedTextField(value = code, onValueChange = { code = it.take(100) },
                label = { Text("Код из письма") }, singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth())
        }
        if (mode in setOf("login", "register", "reset")) {
            OutlinedTextField(value = password, onValueChange = { password = it.take(128) },
                label = { Text(if (mode == "reset") "Новый пароль" else "Пароль") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), enabled = !busy,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        }
        if (mode in setOf("register", "reset")) {
            Text("12–128 символов. Используйте уникальный пароль и менеджер паролей.", color = p.subtext)
            OutlinedTextField(value = confirmation, onValueChange = { confirmation = it.take(128) },
                label = { Text("Повторите пароль") }, singleLine = true, enabled = !busy,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        }
        if (message.isNotEmpty()) Text(message, color = p.text)
        if (busy) CircularProgressIndicator(color = p.accent)
        Button(onClick = { launchAction(mode) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(when (mode) {
                "register" -> "Зарегистрироваться"
                "verify" -> "Подтвердить"
                "forgot" -> "Отправить код"
                "reset" -> "Сохранить новый пароль"
                else -> "Войти"
            })
        }
        if (mode == "login") {
            TextButton(onClick = { switch("register") }, enabled = !busy) { Text("Нет аккаунта? Создать") }
            TextButton(onClick = { switch("forgot") }, enabled = !busy) { Text("Забыли пароль?") }
            TextButton(onClick = { switch("verify") }, enabled = !busy) { Text("Подтвердить почту / повторить письмо") }
            Spacer(Modifier.height(8.dp))
            if (googleAvailable) {
                OutlinedButton(onClick = { launchAction("google") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Войти через Google")
                }
                Text("Откроется выбор Google-аккаунта. Другую почту используйте через обычную регистрацию.", color = p.subtext, fontSize = 12.sp)
            } else Text("Вход через Google не настроен или сервис сейчас недоступен.", color = p.subtext, fontSize = 12.sp)
        } else {
            if (mode == "verify") TextButton(onClick = { launchAction("resend") }, enabled = !busy) { Text("Отправить код повторно") }
            TextButton(onClick = { switch("login") }, enabled = !busy) { Text("Вернуться ко входу") }
        }
    }
}

private fun accountErrorMessage(error: Exception): String = when ((error as? AccountApiException)?.reason) {
    "invalid_credentials" -> "Почта или пароль неверны."
    "email_not_verified" -> "Сначала подтвердите почту: вернитесь ко входу и выберите подтверждение почты."
    "invalid_email" -> "Проверьте адрес почты. В этой версии поддерживаются адреса латиницей."
    "password_length" -> "Пароль должен содержать от 12 до 128 символов."
    "invalid_code" -> "Код неверен, уже использован или истёк. Запросите новое письмо."
    "use_existing_sign_in" -> "Для этой почты уже есть аккаунт. Войдите прежним способом. Автоматически связывать аккаунты небезопасно."
    "google_email_use_password" -> "Для этого адреса Google используйте регистрацию по почте и паролю."
    "google_not_configured", "not_configured" -> "Этот способ входа ещё не настроен на сервере или в сборке."
    "rate_limited", "busy" -> "Слишком много попыток. Подождите несколько минут и повторите."
    "google_verification_failed" -> "Не удалось подтвердить вход через Google. Повторите выбор аккаунта."
    "session_reused" -> "Сессия отозвана для безопасности. Войдите заново."
    else -> "Не удалось завершить запрос. Проверьте интернет и повторите позже. Если письмо не пришло, запросите его повторно."
}
