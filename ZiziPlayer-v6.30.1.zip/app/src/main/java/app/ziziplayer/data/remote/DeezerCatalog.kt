package app.ziziplayer.data.remote

import android.net.Uri
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject

/**
 * Deezer как ВИТРИНА, а не как источник звука (6.30.0).
 *
 * Никакого аудио отсюда не приходит и прийти не может: Deezer наружу поток не отдаёт. Он отдаёт то,
 * чего у нас никогда не было и что нельзя вытащить из поиска YouTube — чистое название, артиста,
 * альбом, обложку в высоком разрешении и **ISRC**, глобальный код записи. Звук по-прежнему тянет
 * [ZiziResolve], то есть весь тракт 1.8.2 со складом, хвостом и лестницей клиентов.
 *
 * Стык между витриной и звуком — один серверный вызов `/match/deezer`, который по id каталога
 * находит тот же трек на YouTube и возвращает videoId. Сопоставление считается ОДИН раз на трек:
 * сервер кладёт `isrc → videoId` в SQLite, и со второго раза это бесплатно.
 *
 * Почему сопоставление живёт на сервере, а не здесь: оно требует нескольких поисковых запросов и
 * сравнения длительностей, то есть секунд процессорного времени и трафика. На телефоне это батарея
 * и задержка старта у каждого пользователя; на сервере — один раз для всех.
 */
class DeezerCatalog : RemoteCatalog {

    override val id: String = "dz"

    /** Наружу источник не называется: для пользователя это просто музыка. */
    override val label: String = "Музыка"

    private companion object {
        const val PAGE = 25
    }

    private fun base(): String {
        val raw = ZiziResolve.baseUrl.trim().trimEnd('/')
        if (raw.isEmpty()) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Адрес резолвера не задан")
        }
        return if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "http://$raw"
    }

    private fun url(path: String, params: Map<String, String>): String {
        val b = Uri.parse(base() + path).buildUpon()
        params.forEach { (k, v) -> b.appendQueryParameter(k, v) }
        return b.build().toString()
    }

    private suspend fun get(path: String, params: Map<String, String>): JSONObject =
        ZiziHttp.getJson(url(path, params), ZiziResolve.authHeaders())

    override suspend fun isUsable(): Boolean = ZiziResolve.configured

    // ── разбор ───────────────────────────────────────────────────────────────────────────────────

    private fun JSONObject.toTrack(): RemoteTrack = RemoteTrack(
        provider = id,
        remoteId = optString("id"),
        title = optString("title"),
        artist = optString("artist"),
        album = optString("album").takeIf { it.isNotEmpty() && it != "null" } ?: "",
        durationMs = optInt("dur").toLong() * 1000L,
        artworkUrl = optString("art").takeIf { it.isNotEmpty() && it != "null" }
    )

    private fun tracksOf(response: JSONObject, field: String): List<RemoteTrack> {
        val arr = response.optJSONArray(field) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.toTrack()?.takeIf { it.remoteId.isNotEmpty() }
        }
    }

    // ── интерфейс каталога ───────────────────────────────────────────────────────────────────────

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        val offset = pageToken?.toIntOrNull() ?: 0
        val response = get(
            "/catalog/search",
            mapOf("q" to query, "limit" to "$PAGE", "offset" to "$offset")
        )
        val items = tracksOf(response, "items").map { RemoteItem.Song(it) }
        val next = if (items.size < PAGE) null else (offset + PAGE).toString()
        return SearchPage(items, next)
    }

    /** Подсказок у витрины нет, и это не ошибка: пустой список — валидный ответ по контракту. */
    override suspend fun suggest(prefix: String): List<String> = emptyList()

    override suspend fun discover(): List<DiscoverShelf> {
        val j = get("/catalog/chart", mapOf("limit" to "40"))
        val shelves = mutableListOf<DiscoverShelf>()

        tracksOf(j, "tracks").map { RemoteItem.Song(it) }
            .takeIf { it.isNotEmpty() }
            ?.let { shelves += DiscoverShelf("Сейчас слушают", it) }

        j.optJSONArray("playlists")?.let { arr ->
            val items = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = "playlist:" + o.optString("id"),
                        kind = RemoteKind.PLAYLIST,
                        title = o.optString("title"),
                        subtitle = o.optInt("n").takeIf { it > 0 }?.let { "$it треков" } ?: "",
                        artworkUrl = o.optString("art")
                    )
                )
            }
            if (items.isNotEmpty()) shelves += DiscoverShelf("Подборки", items)
        }

        j.optJSONArray("artists")?.let { arr ->
            val items = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = "artist:" + o.optString("id"),
                        kind = RemoteKind.ARTIST,
                        title = o.optString("name"),
                        artworkUrl = o.optString("art")
                    )
                )
            }
            if (items.isNotEmpty()) shelves += DiscoverShelf("Артисты", items)
        }
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val raw = collection.remoteId
        val kind = raw.substringBefore(':', "")
        val key = raw.substringAfter(':', raw)
        val response = when {
            kind == "album" || collection.kind == RemoteKind.ALBUM ->
                get("/catalog/album", mapOf("id" to key))
            kind == "artist" || collection.kind == RemoteKind.ARTIST ->
                get("/catalog/artist", mapOf("id" to key, "limit" to "50"))
            else ->
                get("/catalog/playlist", mapOf("id" to key, "limit" to "100"))
        }
        return tracksOf(response, "items")
    }

    /**
     * Витрина → звук. Единственное место, где эти два мира встречаются.
     *
     * Сначала спрашиваем сервер, какому videoId соответствует запись, и только потом отдаём задачу
     * [ZiziResolve] — тому же коду, что играет треки сегодня. Ошибка сопоставления и ошибка
     * резолва различимы: первая приходит как UNAVAILABLE (этой записи на YouTube нет — пропускаем
     * трек), вторая как всё остальное (сломан тракт — есть смысл в запасном провайдере).
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val response = try {
            get("/match/deezer", mapOf("id" to remoteId))
        } catch (e: CatalogException) {
            if (e.reason == CatalogException.Reason.UNAVAILABLE) throw e
            throw CatalogException(e.reason, "Сопоставление не удалось: " + e.message, e)
        }
        val videoId = response.optString("vid")
        if (videoId.isEmpty()) {
            throw CatalogException(
                CatalogException.Reason.UNAVAILABLE,
                "Записи нет на источнике звука"
            )
        }
        return ZiziResolve.resolve(videoId, quality)
    }
}

/**
 * Один каталог вместо трёх (6.30.0).
 *
 * Пользователь не должен знать слова «Deezer», «Innertube» и «Audius» и не должен выбирать между
 * ними в настройках — он ищет музыку. [MixCatalog] опрашивает вложенные каталоги параллельно и
 * отдаёт наверх ОДИН плоский список: сверху записи с обложкой и альбомом, ниже всё остальное.
 *
 * Ключ склейки — `<провайдер>:<remoteId>`, поэтому `r:mix:dz:3135556` остаётся стабильным и
 * пригодным для избранного и плейлистов ровно так же, как обычный id. Дубликаты схлопываются по
 * нормализованным артисту, названию и длительности с точностью до пяти секунд: один и тот же трек,
 * найденный и в витрине, и в сыром поиске, показывается один раз, и побеждает версия с обложкой.
 *
 * Падение одного источника не роняет выдачу: [runCatching] на каждом, а не общий try.
 */
class MixCatalog(private val parts: List<RemoteCatalog>) : RemoteCatalog {

    override val id: String = "mix"
    override val label: String = "Музыка"

    override suspend fun isUsable(): Boolean = parts.any { runCatching { it.isUsable() }.getOrDefault(false) }

    override suspend fun prewarm() {
        parts.forEach { runCatching { it.prewarm() } }
    }

    private fun wrap(part: RemoteCatalog, track: RemoteTrack) =
        track.copy(provider = id, remoteId = part.id + ":" + track.remoteId)

    private fun wrap(part: RemoteCatalog, collection: RemoteCollection) =
        collection.copy(provider = id, remoteId = part.id + ":" + collection.remoteId)

    private fun unwrap(remoteId: String): Pair<RemoteCatalog, String> {
        val part = parts.firstOrNull { remoteId.startsWith(it.id + ":") }
            ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Неизвестный источник: $remoteId")
        return part to remoteId.removePrefix(part.id + ":")
    }

    private fun key(track: RemoteTrack): String {
        val norm = { s: String ->
            s.lowercase()
                .replace(Regex("\\((?:official|lyric|audio|video|hd|mv)[^)]*\\)"), " ")
                .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }
        return norm(track.artist) + "|" + norm(track.title) + "|" + (track.durationMs / 5000L)
    }

    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage =
        coroutineScope {
            val pages = parts.map { part ->
                part to async {
                    runCatching { part.search(query, kind, pageToken) }.getOrDefault(SearchPage.EMPTY)
                }
            }
            val merged = LinkedHashMap<String, RemoteItem>()
            var next: String? = null
            for ((part, deferred) in pages) {
                val page = deferred.await()
                if (next == null) next = page.nextToken
                for (item in page.items) when (item) {
                    is RemoteItem.Song -> {
                        val wrapped = RemoteItem.Song(wrap(part, item.track))
                        val k = key(item.track)
                        val current = merged[k] as? RemoteItem.Song
                        if (current == null || (current.track.artworkUrl == null && item.track.artworkUrl != null)) {
                            merged[k] = wrapped
                        }
                    }
                    is RemoteItem.Group -> {
                        merged["g:" + part.id + ":" + item.collection.remoteId] =
                            RemoteItem.Group(wrap(part, item.collection))
                    }
                }
            }
            SearchPage(merged.values.toList(), next)
        }

    override suspend fun suggest(prefix: String): List<String> = coroutineScope {
        parts.map { part -> async { runCatching { part.suggest(prefix) }.getOrDefault(emptyList()) } }
            .flatMap { it.await() }
            .distinct()
            .take(10)
    }

    override suspend fun discover(): List<DiscoverShelf> = coroutineScope {
        parts.map { part ->
            part to async { runCatching { part.discover() }.getOrDefault(emptyList()) }
        }.flatMap { (part, deferred) ->
            deferred.await().map { shelf ->
                DiscoverShelf(
                    shelf.title,
                    shelf.items.map { item ->
                        when (item) {
                            is RemoteItem.Song -> RemoteItem.Song(wrap(part, item.track))
                            is RemoteItem.Group -> RemoteItem.Group(wrap(part, item.collection))
                        }
                    }
                )
            }
        }
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val (part, inner) = unwrap(collection.remoteId)
        return part.collection(collection.copy(provider = part.id, remoteId = inner))
            .map { wrap(part, it) }
    }

    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        val (part, inner) = unwrap(remoteId)
        return part.resolveStream(inner, quality)
    }

    override suspend fun streamReport(remoteId: String, quality: RemoteQuality): List<String> {
        val (part, inner) = unwrap(remoteId)
        return part.streamReport(inner, quality)
    }
}
