package app.ziziplayer.data.remote

import android.net.Uri
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * YouTube Music through its own internal API (Innertube).
 *
 * This is the only source that actually contains the music this library is about - 2025/2026
 * distributor and upload repertoire that Jamendo, Audius and the Spotify API either do not have or
 * will not stream. It is also a private API, and the honest consequences are:
 *
 *  - it is used against YouTube's terms of service;
 *  - the response shape changes without notice, so **every** parse below returns null on anything
 *    unexpected instead of throwing (see Json.kt for why that is not laziness but the design);
 *  - stream URLs are short lived and IP bound, which is why nothing here is ever cached or stored:
 *    [resolveStream] is called from the Media3 loading thread at the moment the stream is opened.
 *
 * No cookies, no login, no account. Not only because personalisation is not worth it, but because
 * an account attached to this kind of traffic is an account that gets banned - the app would keep
 * working, the user's YouTube would not.
 */
class InnertubeCatalog(
    private val apiKey: String,
    private val hl: String = Locale.getDefault().language.ifEmpty { "ru" },
    private val gl: String = Locale.getDefault().country.ifEmpty { "RU" }
) : RemoteCatalog {

    override val id: String = "yt"
    override val label: String = "YouTube Music"

    companion object {
        /**
         * THREE hosts, because the host has to match the client - 6.7.0 sent every client to
         * music.youtube.com and that is one of the two reasons YouTube "did not start".
         *
         * music.youtube.com is the web app's own host and it is the only one that wants the web
         * `key`. The app clients (VR, the two music apps) talk to youtubei.googleapis.com, and the
         * embedded TV player talks to www.youtube.com - asking them on the wrong host returns a
         * perfectly well formed response with no `streamingData` in it at all, which is exactly the
         * silence we were getting.
         */
        const val MUSIC = "https://music.youtube.com/youtubei/v1"
        const val API = "https://youtubei.googleapis.com/youtubei/v1"
        const val WWW = "https://www.youtube.com/youtubei/v1"

        /**
         * Search filter blobs. These are protobuf-encoded filter selections, i.e. exactly the
         * bytes the web app itself sends when a chip is tapped. They are stable in practice but
         * they are not ours, so a failed filtered search degrades to an unfiltered one rather than
         * to an error - the user sees results, mixed, instead of a red screen.
         */
        const val FILTER_SONGS = "EgWKAQIIAWoKEAkQBRAKEAMQBA=="
        const val FILTER_ALBUMS = "EgWKAQIYAWoKEAkQChAFEAMQBA=="
        const val FILTER_PLAYLISTS = "EgeKAQQoAEABagwQDhAKEAMQBRAJEBU="
        const val FILTER_ARTISTS = "EgWKAQIgAWoKEAkQChAFEAMQBA=="

        /**
         * Clients tried in order for a stream, and WHY the order is what it is.
         *
         * 6.6.0 asked ANDROID_MUSIC first, then IOS_MUSIC, then WEB_REMIX, and every track failed:
         * the player answered `status: OK`, handed back a URL, and the GET of that URL came back
         * 403. That is not a parsing bug and it is not a network bug - it is attestation. Since
         * mid-2024 the mobile app clients are expected to present a `poToken` minted by Google's
         * own attestation service; a request without one still gets a *shaped* answer, which is the
         * cruel part, but the URLs inside it are dead on arrival. The queue then did exactly what
         * it was told to do with a dead remote track: skipped to the next one, and the next, and
         * the next. "Само свайпает без проигрывания" was the auto-skip working correctly on top of
         * a source that was 100% broken.
         *
         * ANDROID_VR is first because it is the one client that is still served unciphered,
         * un-attested URLs: it ships on standalone headsets that cannot run the attestation
         * library, so Google kept it exempt. TVHTML5_SIMPLY_EMBEDDED_PLAYER is the second exemption
         * (embedded playback on TVs) and it is a genuinely different code path, so it survives when
         * the first one does not. The two mobile music clients stay as third and fourth: they cost
         * one request each, they still work for some tracks, and the day attestation is relaxed
         * they are the ones with the best audio formats. WEB_REMIX stays last and is expected to
         * fail with `signatureCipher` - it is kept only so the error message can say so.
         *
         * [ua] is not decoration either. A googlevideo URL is bound to the client identity that
         * minted it, and fetching an ANDROID_VR URL with a Chrome user agent is one more way to
         * earn a 403. The chosen UA travels with the URL all the way into the data source - see
         * [StreamInfo.userAgent] and `StreamResolver`.
         */
        val STREAM_CLIENTS = listOf(
            StreamClient(
                name = "ANDROID_VR",
                version = "1.65.10",
                ua = "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
            ),
            StreamClient(
                name = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                version = "2.0",
                ua = "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"
            ),
            StreamClient(
                name = "IOS_MUSIC",
                version = "7.27.0",
                ua = "com.google.ios.youtubemusic/7.27.0 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)"
            ),
            StreamClient(
                name = "ANDROID_MUSIC",
                version = "7.27.52",
                ua = "com.google.android.apps.youtube.music/7.27.52 (Linux; U; Android 14; ru_RU) gzip"
            ),
            StreamClient(
                name = "WEB_REMIX",
                version = "1.20241028.01.00",
                ua = ZiziHttp.USER_AGENT
            )
        )

        val DURATION = Regex("""^\d{1,2}:\d{2}(:\d{2})?$""")

        /**
         * Which internal client last produced a URL the CDN actually served, and which ones are
         * being rested.
         *
         * Process wide and deliberately so: the resolver runs on Media3's loader thread, once per
         * track, and the answer to "who works right now" is a property of the network and of
         * YouTube's current mood - not of a screen. It is what makes the verification below cost
         * one round trip per session instead of one per track.
         */
        @Volatile private var trusted: String? = null
        private val restedUntil = ConcurrentHashMap<String, Long>()

        /** A client is rested for ten minutes after the CDN refused its URL. */
        private const val REST_MS = 10 * 60 * 1000L

        /**
         * Called when playback itself failed with 403 on a URL we had already trusted.
         *
         * The trust is dropped, not the client: it goes back into the verified-on-first-use pool,
         * so the very next track pays one probe and either confirms it or moves on.
         */
        fun distrust() { trusted = null }
    }

    // ---------------------------------------------------------------- request plumbing

    private fun hostFor(client: StreamClient): String = when (client.name) {
        "ANDROID_VR", "ANDROID_MUSIC", "IOS_MUSIC" -> API
        "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> WWW
        else -> MUSIC
    }

    private fun endpoint(
        client: StreamClient,
        path: String,
        extra: Map<String, String> = emptyMap()
    ): String {
        val builder = Uri.parse(hostFor(client) + "/" + path).buildUpon()
        // The `key` belongs to the web app and to nothing else. Sending it with an app client is
        // how a request gets answered politely and uselessly; Innertube has not required it for
        // app clients for a long time.
        if (client.name == "WEB_REMIX" && apiKey.isNotBlank()) {
            builder.appendQueryParameter("key", apiKey)
        }
        builder.appendQueryParameter("prettyPrint", "false")
        extra.forEach { (k, v) -> builder.appendQueryParameter(k, v) }
        return builder.build().toString()
    }

    /**
     * The `context.client` block, per client.
     *
     * Every field here is one the real client sends. Innertube does not validate most of them, but
     * the ones it does validate it validates silently: an ANDROID_VR context without
     * `androidSdkVersion`, or a TVHTML5 context without `clientScreen`, comes back as a perfectly
     * well formed response with no `streamingData` in it at all.
     */
    private fun context(client: StreamClient): JSONObject {
        val clientJson = JSONObject()
            .put("hl", hl)
            .put("gl", gl)
            .put("clientName", client.name)
            .put("clientVersion", client.version)
        when (client.name) {
            "ANDROID_VR" -> clientJson
                .put("deviceMake", "Oculus")
                .put("deviceModel", "Quest 3")
                .put("androidSdkVersion", 32)
                .put("osName", "Android")
                .put("osVersion", "12L")
            "ANDROID_MUSIC" -> clientJson
                .put("androidSdkVersion", 34)
                .put("osName", "Android")
                .put("osVersion", "14")
            "IOS_MUSIC" -> clientJson
                .put("deviceMake", "Apple")
                .put("deviceModel", "iPhone16,2")
                .put("osName", "iOS")
                .put("osVersion", "17.5.1.21F90")
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> clientJson
                .put("clientScreen", "EMBED")
        }
        val context = JSONObject().put("client", clientJson)
        if (client.name == "TVHTML5_SIMPLY_EMBEDDED_PLAYER" || client.name == "WEB_REMIX") {
            // The embedded player refuses to resolve anything without knowing which page it is
            // supposedly embedded in.
            context.put(
                "thirdParty",
                JSONObject().put("embedUrl", "https://www.youtube.com/")
            )
        }
        return context
    }

    private fun headers(client: StreamClient): Map<String, String> = buildMap {
        put("X-Goog-Api-Format-Version", "1")
        put("Accept-Language", "$hl-$gl")
        // The UA has to match the client on the API call too, not just on the media fetch.
        put("User-Agent", client.ua)
        if (client.name == "WEB_REMIX") {
            put("Origin", "https://music.youtube.com")
            put("Referer", "https://music.youtube.com/")
            put("X-Youtube-Client-Name", "67")
            put("X-Youtube-Client-Version", client.version)
        }
    }

    /** The client used for browsing and searching. Never used for streams - see [STREAM_CLIENTS]. */
    private val web = StreamClient("WEB_REMIX", "1.20241028.01.00", ZiziHttp.USER_AGENT)

    // ---------------------------------------------------------------- search

    // The key is optional now (see [endpoint]), so the catalogue is usable without one.
    override suspend fun isUsable(): Boolean = true

    /**
     * One page of results - and, since 6.8.0, a page token that can mean two different things.
     *
     * Innertube pages a search in two incompatible ways and 6.7.0 only knew about one of them:
     *
     *  - a `continuationCommand` token, which walks further down the SAME shelf;
     *  - a shelf's own `bottomEndpoint` params ("Показать все"), which is the only way into the
     *    DEEP shelves - the ones behind "Треки", "Видео", "Альбомы" on an unfiltered search. An
     *    unfiltered response carries the first five rows of each shelf and a button, and nothing
     *    else; there is no continuation to follow, which is exactly why "треков мало".
     *
     * So the token is tagged: `c:` is a continuation, `p:` is a filter blob for a deeper request.
     * The screen still treats it as opaque - see [SearchPage.nextToken].
     */
    override suspend fun search(query: String, kind: RemoteKind?, pageToken: String?): SearchPage {
        if (query.isBlank()) return SearchPage.EMPTY

        val deeperParams = if (pageToken != null && pageToken.startsWith("p:")) pageToken.substring(2) else null
        val continuation = when {
            pageToken == null -> null
            pageToken.startsWith("p:") -> null
            pageToken.startsWith("c:") -> pageToken.substring(2)
            // Tokens minted by 6.7.0 and stored in a live UI state carry no prefix.
            else -> pageToken
        }

        val activeParams = deeperParams ?: filterFor(kind)
        val body = JSONObject()
            .put("context", context(web))
            .put("query", query)
        activeParams?.let { body.put("params", it) }
        continuation?.let { body.put("continuation", it) }

        val extra = if (continuation == null) emptyMap() else mapOf("continuation" to continuation, "type" to "next")
        val response = ZiziHttp.postJson(endpoint(web, "search", extra), body, headers(web))

        // A 200 with neither of these keys means the response shape moved, not that nothing matched.
        if (!response.has("contents") && !response.has("continuationContents") && !response.has("onResponseReceivedActions")) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "YouTube Music ответил в неизвестном формате")
        }

        // The top result lives in its own renderer and was silently dropped before: the single most
        // relevant row of the whole response was the one row the parser could not see.
        val items = (parseCardShelf(response) + parseListItems(response)).distinctBy { item ->
            when (item) {
                is RemoteItem.Song -> item.track.trackId
                is RemoteItem.Group -> item.collection.kind.name + ":" + item.collection.remoteId
            }
        }
        val next = continuationToken(response)?.let { "c:" + it }
            ?: deeperShelfParams(response, activeParams)?.let { "p:" + it }
        return SearchPage(items, next)
    }

    /** Both spellings of a continuation token. The second one still appears on browse responses. */
    private fun continuationToken(response: JSONObject): String? =
        response.deepFind("continuationCommand", limit = 8).firstNotNullOfOrNull { it.str("token") }
            ?: response.deepFind("nextContinuationData", limit = 8).firstNotNullOfOrNull { it.str("continuation") }

    /**
     * The "Показать все" filter blob of the first shelf that offers one.
     *
     * [current] is excluded so a filtered search cannot hand back its own filter and page in place
     * forever - which would look exactly like a list that refuses to grow.
     */
    private fun deeperShelfParams(response: JSONObject, current: String?): String? {
        val shelves = response.deepFind("musicShelfRenderer", limit = 12) +
            response.deepFind("musicCarouselShelfRenderer", limit = 12)
        for (shelf in shelves) {
            val params = shelf.str("bottomEndpoint", "searchEndpoint", "params")
                ?: shelf.node("moreContentButton")?.deepFind("searchEndpoint", limit = 4)
                    ?.firstNotNullOfOrNull { it.str("params") }
                ?: shelf.node("header")?.deepFind("searchEndpoint", limit = 4)
                    ?.firstNotNullOfOrNull { it.str("params") }
            if (params != null && params != current) return params
        }
        return null
    }

    /** The big "top result" card at the head of an unfiltered search. */
    private fun parseCardShelf(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicCardShelfRenderer", limit = 4).mapNotNull { card ->
            val title = card.runs("title") ?: return@mapNotNull null
            val subtitle = card.runs("subtitle").orEmpty()
            val artwork = card.node("thumbnail")?.bestThumbnail() ?: card.bestThumbnail()
            val videoId = card.deepString("videoId")
            if (videoId != null) {
                RemoteItem.Song(
                    RemoteTrack(
                        provider = id,
                        remoteId = videoId,
                        title = title,
                        artist = cleanArtist(subtitle),
                        artworkUrl = artwork
                    )
                )
            } else {
                val browseId = card.deepString("browseId") ?: return@mapNotNull null
                val playlistId = card.deepString("playlistId")
                val kind = when {
                    browseId.startsWith("UC") || browseId.startsWith("MPLA") -> RemoteKind.ARTIST
                    browseId.startsWith("MPRE") -> RemoteKind.ALBUM
                    playlistId != null || browseId.startsWith("VL") -> RemoteKind.PLAYLIST
                    else -> return@mapNotNull null
                }
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                        kind = kind,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artwork
                    )
                )
            }
        }

    private fun filterFor(kind: RemoteKind?): String? = when (kind) {
        RemoteKind.TRACK -> FILTER_SONGS
        RemoteKind.ALBUM -> FILTER_ALBUMS
        RemoteKind.PLAYLIST -> FILTER_PLAYLISTS
        RemoteKind.ARTIST -> FILTER_ARTISTS
        null -> null
    }

    override suspend fun suggest(prefix: String): List<String> {
        if (prefix.isBlank()) return emptyList()
        val body = JSONObject().put("context", context(web)).put("input", prefix)
        val response = runCatching {
            ZiziHttp.postJson(endpoint(web, "music/get_search_suggestions"), body, headers(web))
        }.getOrNull() ?: return emptyList()
        return response.deepFind("searchSuggestionRenderer", limit = 12)
            .mapNotNull { it.runs("suggestion") }
            .distinct()
    }

    override suspend fun discover(): List<DiscoverShelf> {
        val body = JSONObject()
            .put("context", context(web))
            .put("browseId", "FEmusic_explore")
        val response = ZiziHttp.postJson(endpoint(web, "browse"), body, headers(web))
        val shelves = response.deepFind("musicCarouselShelfRenderer", limit = 12).mapNotNull { shelf ->
            val title = shelf.node("header")?.runs("musicCarouselShelfBasicHeaderRenderer", "title")
                ?: shelf.runs("header", "musicCarouselShelfBasicHeaderRenderer", "title")
                ?: return@mapNotNull null
            val items = parseTwoRowItems(shelf) + parseListItems(shelf)
            if (items.isEmpty()) null else DiscoverShelf(title, items)
        }
        if (shelves.isEmpty()) {
            throw CatalogException(CatalogException.Reason.PROTOCOL, "Не удалось разобрать подборки YouTube Music")
        }
        return shelves
    }

    override suspend fun collection(collection: RemoteCollection): List<RemoteTrack> {
        val browseId = when (collection.kind) {
            // A playlist id becomes a browse id by prefixing VL; album and artist ids already are one.
            RemoteKind.PLAYLIST ->
                if (collection.remoteId.startsWith("VL")) collection.remoteId else "VL${collection.remoteId}"
            else -> collection.remoteId
        }
        val body = JSONObject().put("context", context(web)).put("browseId", browseId)
        var response = ZiziHttp.postJson(endpoint(web, "browse"), body, headers(web))

        // A browse response holds the first ~100 rows and a continuation. 6.7.0 read page one and
        // stopped, so a 300 track playlist opened as a 100 track playlist with no hint that the
        // rest existed. Five pages is a deliberate ceiling: it covers every real album and playlist
        // while keeping a pathological "все треки мира" list from paging forever on mobile data.
        val out = ArrayList<RemoteTrack>()
        var page = 0
        while (true) {
            out.addAll(parseListItems(response).filterIsInstance<RemoteItem.Song>().map { it.track })
            page++
            val token = continuationToken(response)?.takeIf { page < 5 } ?: break
            val nextBody = JSONObject().put("context", context(web)).put("continuation", token)
            response = try {
                ZiziHttp.postJson(
                    endpoint(web, "browse", mapOf("continuation" to token, "type" to "next")),
                    nextBody,
                    headers(web)
                )
            } catch (e: CatalogException) {
                // Whatever we already have is worth more than an exception.
                break
            }
        }
        return out.distinctBy { it.remoteId }
    }

    // ---------------------------------------------------------------- parsing

    /**
     * Rows, from anywhere in the payload.
     *
     * `musicResponsiveListItemRenderer` is asked for by name across the whole tree rather than
     * quoted through a nine-level path, because the path is what changes when YouTube reshuffles
     * its layout - the renderer name is what stays. Breadth first, so screen order is preserved.
     */
    private fun parseListItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicResponsiveListItemRenderer").mapNotNull { parseRow(it) }

    private fun parseRow(row: JSONObject): RemoteItem? {
        val texts = row.optJSONArray("flexColumns").items().mapNotNull {
            it.runs("musicResponsiveListItemFlexColumnRenderer", "text")
        }
        val title = texts.firstOrNull()?.takeIf { it.isNotBlank() } ?: return null
        val artwork = row.node("thumbnail")?.bestThumbnail()
        val explicit = row.deepString("iconType")?.contains("EXPLICIT") == true ||
            row.toString().contains("MUSIC_EXPLICIT_BADGE")

        val videoId = row.node("overlay")?.deepString("videoId")
            ?: row.node("playlistItemData")?.str("videoId")
            ?: row.deepString("videoId")

        if (videoId != null) {
            val duration = (texts + row.optJSONArray("fixedColumns").items().mapNotNull {
                it.runs("musicResponsiveListItemFixedColumnRenderer", "text")
            }).lastOrNull { DURATION.matches(it.trim()) }
            // Column layout differs per result type; the first non-title column that is not the
            // type label and not the duration is the artist.
            val artist = texts.drop(1).firstOrNull { !DURATION.matches(it.trim()) && it.isNotBlank() }
            return RemoteItem.Song(
                RemoteTrack(
                    provider = id,
                    remoteId = videoId,
                    title = title,
                    artist = cleanArtist(artist),
                    album = "",
                    durationMs = parseDuration(duration),
                    artworkUrl = artwork,
                    explicit = explicit
                )
            )
        }

        val browseId = row.deepString("browseId") ?: return null
        val playlistId = row.deepString("playlistId")
        val kind = when {
            browseId.startsWith("UC") || browseId.startsWith("MPLA") -> RemoteKind.ARTIST
            browseId.startsWith("MPRE") -> RemoteKind.ALBUM
            playlistId != null || browseId.startsWith("VL") -> RemoteKind.PLAYLIST
            else -> return null
        }
        return RemoteItem.Group(
            RemoteCollection(
                provider = id,
                remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                kind = kind,
                title = title,
                subtitle = texts.drop(1).joinToString(" • ").take(80),
                artworkUrl = artwork
            )
        )
    }

    /** Cards on the explore shelves use a different renderer than list rows. */
    private fun parseTwoRowItems(root: JSONObject): List<RemoteItem> =
        root.deepFind("musicTwoRowItemRenderer", limit = 40).mapNotNull { card ->
            val title = card.runs("title") ?: return@mapNotNull null
            val subtitle = card.runs("subtitle").orEmpty()
            val artwork = card.node("thumbnailRenderer")?.bestThumbnail() ?: card.bestThumbnail()
            val videoId = card.deepString("videoId")
            if (videoId != null) {
                RemoteItem.Song(
                    RemoteTrack(
                        provider = id,
                        remoteId = videoId,
                        title = title,
                        artist = cleanArtist(subtitle),
                        artworkUrl = artwork
                    )
                )
            } else {
                val browseId = card.deepString("browseId") ?: return@mapNotNull null
                val playlistId = card.deepString("playlistId")
                val kind = when {
                    browseId.startsWith("UC") -> RemoteKind.ARTIST
                    browseId.startsWith("MPRE") -> RemoteKind.ALBUM
                    else -> RemoteKind.PLAYLIST
                }
                RemoteItem.Group(
                    RemoteCollection(
                        provider = id,
                        remoteId = if (kind == RemoteKind.PLAYLIST) (playlistId ?: browseId) else browseId,
                        kind = kind,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artwork
                    )
                )
            }
        }

    private fun cleanArtist(raw: String?): String {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty()) return "Неизвестный исполнитель"
        // Subtitles arrive as "Трек • Артист • Альбом" or "Song • Artist"; the label is noise.
        val parts = value.split("•").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size <= 1) return value
        val label = setOf("song", "трек", "video", "видео", "single", "сингл", "album", "альбом", "playlist", "плейлист", "artist", "исполнитель")
        return parts.firstOrNull { it.lowercase() !in label && !it.endsWith("просмотров") } ?: parts.last()
    }

    private fun parseDuration(text: String?): Long {
        val value = text?.trim() ?: return 0L
        if (!DURATION.matches(value)) return 0L
        val parts = value.split(":").mapNotNull { it.toIntOrNull() }
        return when (parts.size) {
            2 -> (parts[0] * 60L + parts[1]) * 1000L
            3 -> (parts[0] * 3600L + parts[1] * 60L + parts[2]) * 1000L
            else -> 0L
        }
    }

    // ---------------------------------------------------------------- stream

    /**
     * Walks [STREAM_CLIENTS] until one returns a playable, unciphered audio format.
     *
     * The client matters and it is the whole trick: the web client returns URLs behind
     * `signatureCipher`, which has to be deobfuscated by running YouTube's own JavaScript. The
     * mobile music clients return the URL as-is. So we ask them first, and the web client is kept
     * last only to produce a meaningful error rather than a silent nothing.
     *
     * Failures are collected instead of swallowed: when this eventually breaks, the message says
     * which client refused and why, which is the difference between a five minute fix and an
     * evening.
     */
    override suspend fun resolveStream(remoteId: String, quality: RemoteQuality): StreamInfo {
        var contentBlocked: String? = null
        val problems = ArrayList<String>(STREAM_CLIENTS.size)
        val now = System.currentTimeMillis()

        /*
         * Order: the client that worked last, then everyone who is not being rested, then the
         * rested ones as a last resort.
         *
         * sortedBy is stable, so inside each of those three groups the hand-picked order of
         * STREAM_CLIENTS is preserved - VR first, embedded TV second, and so on.
         */
        val ordered = STREAM_CLIENTS.sortedBy { candidate ->
            when {
                candidate.name == trusted -> -1
                (restedUntil[candidate.name] ?: 0L) > now -> 1
                else -> 0
            }
        }

        for (client in ordered) {
            val body = JSONObject()
                .put("context", context(client))
                .put("videoId", remoteId)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
            val response = try {
                ZiziHttp.postJson(endpoint(client, "player"), body, headers(client))
            } catch (e: CatalogException) {
                if (e.reason == CatalogException.Reason.OFFLINE) throw e
                problems.add("${client.name}: ${e.message}")
                continue
            }

            val status = response.str("playabilityStatus", "status")
            if (status != null && status != "OK") {
                val why = response.str("playabilityStatus", "reason")
                    ?: response.runs("playabilityStatus", "messages")
                    ?: status
                /**
                 * 6.6.0 gave up on the whole track here, for every client, on any of these three
                 * statuses. That was wrong for two of them and it is the reason a single grumpy
                 * client killed tracks that the next client in the list would have played:
                 *
                 *  - LOGIN_REQUIRED from an app client means "you did not attest", not "this track
                 *    is private". The embedded and VR clients are exactly the ones that answer the
                 *    same id without it, so this must fall through to them.
                 *  - ERROR is Innertube's catch-all, including for a context it did not like.
                 *  - UNPLAYABLE is the only one that really is about the video (age gate, region,
                 *    takedown), and even then it is only final once every client agrees.
                 *
                 * So nothing is fatal until the loop is exhausted, and the reason of the LAST
                 * client to complain about the content itself is what the user gets told.
                 */
                problems.add("${client.name}: $why")
                if (status == "UNPLAYABLE") contentBlocked = why
                continue
            }

            val picked = pickFormat(response.array("streamingData", "adaptiveFormats"), quality)
                ?: pickFormat(response.array("streamingData", "formats"), quality)
            if (picked == null) {
                // The single most useful diagnostic in this file: it distinguishes "no audio at
                // all" from "audio, but every URL was behind signatureCipher", which is the
                // signature of a client that needs the JS player deobfuscated.
                val ciphered = response.array("streamingData", "adaptiveFormats").items()
                    .count { it.str("signatureCipher") != null || it.str("cipher") != null }
                problems.add(
                    if (ciphered > 0) "${client.name}: $ciphered потоков зашифрованы"
                    else "${client.name}: нет аудиопотоков"
                )
                continue
            }
            /*
             * THE FIX FOR "ТРЕКИ САМИ СВАЙПАЮТСЯ".
             *
             * Up to 6.7.0 this line returned the first URL that parsed. Whether the CDN would
             * actually serve it was somebody else's problem - and when it would not (403, because
             * that client's attestation had caught up with it), the player saw a broken stream,
             * gave up, and auto-skipped. Four clients were sitting right there in the list, any of
             * which might have worked, and none of them were ever asked.
             *
             * So the URL is now proven before it leaves this function: two bytes, ranged, with the
             * agent it was minted for. A refusal rests that client for ten minutes and the loop
             * simply continues to the next one.
             *
             * The cost is one round trip, and only on the first track of a session: the client
             * that answers becomes [trusted] and is taken on faith afterwards. If playback later
             * dies on a trusted client, `distrust()` is called from the load error policy and the
             * next track pays for one probe again.
             */
            if (client.name == trusted) {
                return picked.copy(client = client.name, userAgent = client.ua)
            }
            val cdn = ZiziHttp.statusOf(picked.url, client.ua)
            if (cdn == null || cdn < 200 || cdn >= 300) {
                restedUntil[client.name] = System.currentTimeMillis() + REST_MS
                problems.add("${client.name}: CDN ${cdn ?: "нет ответа"}")
                continue
            }
            restedUntil.remove(client.name)
            trusted = client.name
            return picked.copy(client = client.name, userAgent = client.ua)
        }
        contentBlocked?.let { throw CatalogException(CatalogException.Reason.UNAVAILABLE, it) }
        throw CatalogException(
            CatalogException.Reason.PROTOCOL,
            "YouTube Music не отдал поток. " + problems.joinToString("; ")
        )
    }

    /**
     * Audio only, no cipher, closest to the requested bitrate.
     *
     * Chosen by measured bitrate rather than by a hardcoded itag list: itags get retired, and a
     * table of magic numbers is one more thing that silently rots. Ties go to m4a/AAC - it is
     * hardware decoded on everything this app runs on, Opus is not always.
     */
    private fun pickFormat(formats: JSONArray?, quality: RemoteQuality): StreamInfo? {
        val candidates = formats.items().filter { format ->
            val mime = format.str("mimeType").orEmpty()
            val url = format.str("url")
            mime.startsWith("audio/") &&
                url != null &&
                format.str("signatureCipher") == null &&
                format.str("cipher") == null
        }
        if (candidates.isEmpty()) return null
        val target = quality.targetKbps * 1000
        val best = candidates.minByOrNull { format ->
            val bitrate = (format.long("bitrate") ?: format.long("averageBitrate") ?: 0L).toInt()
            val distance = abs(bitrate - target)
            val penalty = if (format.str("mimeType").orEmpty().contains("mp4a")) 0 else 8_000
            distance + penalty
        } ?: return null

        val url = best.str("url") ?: return null
        val bitrate = ((best.long("bitrate") ?: 0L) / 1000).toInt()
        return StreamInfo(
            url = url,
            mimeType = best.str("mimeType")?.substringBefore(';') ?: "audio/mp4",
            bitrateKbps = if (bitrate > 0) bitrate else quality.targetKbps,
            ttlMs = ttlOf(url)
        )
    }

    /**
     * The URL carries its own deadline in `expire=<epoch seconds>`.
     *
     * A minute is shaved off it, because "valid until" and "still valid when the request arrives"
     * are not the same thing on a mobile connection. If the parameter is missing we assume a
     * conservative hour rather than trusting the link forever.
     */
    private fun ttlOf(url: String): Long {
        val expire = Regex("""[?&]expire=(\d+)""").find(url)?.groupValues?.getOrNull(1)?.toLongOrNull()
            ?: return 60 * 60 * 1000L
        val left = expire * 1000L - System.currentTimeMillis() - 60_000L
        return left.coerceIn(60_000L, 6 * 60 * 60 * 1000L)
    }
}
