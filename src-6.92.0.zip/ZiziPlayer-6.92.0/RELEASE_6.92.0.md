# ZiziPlayer 6.92.0 (230) + сервер 1.28-import-rc1

Порядок выкладки: **сначала сервер, потом клиент.** Контракт импорта остаётся `import_contract == 1`, клиент 6.91.0 работает с сервером 1.28.

## Сервер
1. `python3 server/tools/deploy_server.py` (откатится сам, если после рестарта `/catalog/health` не покажет `import_rev == 2`).
2. `python3 server/tools/probe_import_spotify.py` на VPS: покажет, какая ступень Spotify (pathfinder v2 / v1 / Web API / embed) ответила и сколько треков вернула.
3. В `/catalog/health` смотреть `import.sources` и `import.sources_last`.

## Не проверено вживую (в Computer нет сети)
- Принимает ли pathfinder анонимный токен из embed, нужен ли `client-token`, жив ли хеш `queryPlaylist`. Каскад страхует, худший случай равен 1.27.2 (100 треков).
- Разметка VK-плейлиста в WebView: сборщик написан по `data-audio` / `ai_*`, проверен на фальшивом DOM. На живом VK не гонялся.
- Что `primaryClipDescription` не вызывает плашку Android: по документации так, на устройстве не смотрели.
- Kotlin здесь не компилируется: только статические чекеры и Python/JVM-тесты; компиляцию подтвердит CI.

## Тесты (в Computer)
клиент 157/157, сервер 30/30, чекеры 8/8.
