# ---- ZiziPlayer keep rules (release / R8) ----

# Room: generated implementations and entities are looked up by name.
-keep class app.ziziplayer.data.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.room.paging.**

# ViewModels are instantiated reflectively by ViewModelProvider (`by viewModels()`).
# The lifecycle artifact ships a rule for this, but the app must not depend on that detail:
# losing the constructor is a release-only crash on the very first frame.
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class app.ziziplayer.ui.MainViewModel { *; }

# Application and Media3 session service are resolved through the manifest / IPC.
-keep class app.ziziplayer.ZiziApplication { *; }
-keep class app.ziziplayer.playback.PlaybackService { *; }
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# The promoted-notification flag is read by reflection (Android 16+, absent below it).
-keepclassmembers class android.app.Notification { public static final int FLAG_PROMOTED_ONGOING; }

# Coroutines internals.
-dontwarn kotlinx.coroutines.**

# Room's generated DAO implementation is reached by name from the generated database class, and the
# @Transaction default method on MusicDao is compiled into a synthetic class that R8 sees as unused.
-keep class app.ziziplayer.data.*_Impl { *; }
-keepclassmembers class * implements app.ziziplayer.data.MusicDao { *; }

# ---------------------------------------------------------------- network (6.6.0)
# OkHttp ships optional hooks for platforms we do not target (Conscrypt, BouncyCastle, OpenJSSE)
# and references them reflectively. Without these, R8 turns a working release build into a wall of
# warnings and, on some setups, a stripped TLS path.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn okio.**

# Media3's cache index and the OkHttp data source are reached through factories, not directly.
-keep class androidx.media3.datasource.okhttp.** { *; }
-keep class androidx.media3.database.** { *; }

# ---------------------------------------------------------------- poToken (6.9.0)
# The minter's bridge is called from JavaScript, by name. Nothing in Kotlin calls `ready` or `fail`,
# so R8 removes both and every release build ends its WebView run in a timeout - a bug that cannot
# reproduce in debug. Keep the annotated members, and keep the object graph they live in.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class app.ziziplayer.data.remote.PoTokenMinter { *; }
-keep class app.ziziplayer.data.remote.PoTokenMinter$* { *; }
-dontwarn android.webkit.**
