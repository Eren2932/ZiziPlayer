package app.ziziplayer.data.remote

import java.io.IOException
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.Buffer
import org.json.JSONObject

/**
 * Process-wide pair used by the Innertube interceptor.
 *
 * A poToken without the visitorData it was minted for is invalid. Keeping them in one immutable
 * snapshot prevents a request from observing a new visitor together with an old token.
 */
object InnertubeSessionProof {
    data class Snapshot(val visitorData: String, val poToken: String?)

    private val state = AtomicReference<Snapshot?>()

    fun updateVisitor(visitorData: String) {
        if (visitorData.isBlank()) return
        while (true) {
            val old = state.get()
            if (old?.visitorData == visitorData) return
            // A visitor rotation invalidates the old proof immediately.
            if (state.compareAndSet(old, Snapshot(visitorData, null))) return
        }
    }

    fun updatePoToken(visitorData: String, poToken: String?) {
        if (visitorData.isBlank()) return
        while (true) {
            val old = state.get()
            if (old != null && old.visitorData != visitorData) return
            val next = Snapshot(visitorData, poToken?.takeIf { it.isNotBlank() })
            if (state.compareAndSet(old, next)) return
        }
    }

    fun snapshot(): Snapshot? = state.get()

    fun invalidateToken() {
        while (true) {
            val old = state.get() ?: return
            if (old.poToken == null) return
            if (state.compareAndSet(old, old.copy(poToken = null))) return
        }
    }
}

/** Adds visitorData and, when available, its matching poToken to Innertube POST JSON bodies. */
private object InnertubeJsonProofInjector {
    private const val MAX_BODY_BYTES = 2L * 1024L * 1024L
    private val hosts = setOf("youtubei.googleapis.com", "www.youtube.com", "music.youtube.com")

    fun handles(request: Request): Boolean {
        val host = request.url.host.lowercase(Locale.US)
        return request.method.equals("POST", ignoreCase = true) &&
            host in hosts && request.url.encodedPath.startsWith("/youtubei/v1/")
    }

    @Throws(IOException::class)
    fun inject(request: Request, proof: InnertubeSessionProof.Snapshot): Request {
        val body = request.body ?: return request
        val type = body.contentType() ?: return request
        val jsonType = type.subtype.equals("json", ignoreCase = true) ||
            type.subtype.endsWith("+json", ignoreCase = true)
        if (!jsonType) return request
        if (body.isDuplex() || body.isOneShot()) {
            throw IOException("Cannot inject Innertube proof into a one-shot or duplex JSON body")
        }
        val declared = body.contentLength()
        if (declared > MAX_BODY_BYTES) throw IOException("Innertube JSON body is too large")

        val buffer = Buffer()
        body.writeTo(buffer)
        if (buffer.size > MAX_BODY_BYTES) throw IOException("Innertube JSON body is too large")
        val root = try {
            JSONObject(buffer.readUtf8())
        } catch (e: Throwable) {
            throw IOException("Innertube POST body is not a JSON object", e)
        }

        val context = objectAt(root, "context")
        val client = objectAt(context, "client")
        // The pair comes from one atomic snapshot, therefore these values cannot be mismatched.
        client.put("visitorData", proof.visitorData)
        proof.poToken?.let { client.put("poToken", it) }

        return request.newBuilder()
            .method(request.method, root.toString().toRequestBody(type))
            .build()
    }

    @Throws(IOException::class)
    private fun objectAt(parent: JSONObject, key: String): JSONObject {
        if (!parent.has(key) || parent.isNull(key)) {
            return JSONObject().also { parent.put(key, it) }
        }
        return parent.optJSONObject(key)
            ?: throw IOException("Innertube JSON field '$key' must be an object")
    }
}

/**
 * Despite the historical class name, this interceptor no longer changes headers.
 *
 * In particular it never replaces User-Agent: ANDROID_VR, IOS, IOS_MUSIC and every other client
 * keep the UA selected by InnertubeCatalog.headers(client). The only mutation is a targeted update
 * of context.client inside Innertube JSON requests.
 */
class SessionHeadersInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val proof = InnertubeSessionProof.snapshot()
        val request = if (proof != null && InnertubeJsonProofInjector.handles(original)) {
            InnertubeJsonProofInjector.inject(original, proof)
        } else {
            original
        }

        val response = chain.proceed(request)
        if (InnertubeJsonProofInjector.handles(request) &&
            (response.code == 401 || response.code == 403)
        ) {
            PoTokenMinter.invalidate()
        }
        return response
    }
}
