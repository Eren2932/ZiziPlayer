# ZiziPlayer 6.9.3

Сессионный мост настроен на `https://music.youtube.com`. Единый User-Agent WebView и OkHttp задан
как Chrome Mobile под Android 13. Защищены `youtubei.googleapis.com`, `googlevideo.com` со всеми
поддоменами и `music.youtube.com`; payload передаётся заголовком `X-Youtube-Identity-Token`.

После `onPageFinished` WebView инъецирует ограниченный JS-probe. Он ожидает появление payload в
явных конфигурационных точках страницы (`INNERTUBE_CONTEXT.client.poToken`, `PO_TOKEN`,
`PLAYER_PO_TOKEN`, `ID_TOKEN`, служебный meta-тег или `window.__ZIZI_PAYLOAD__`) и вызывает
`window.AndroidTokenBridge.postToken(payload)`. Cookies, localStorage и сетевые ответы скрипт не
читает.

Для каждого защищённого POST с JSON-телом `SessionHeadersInterceptor` разбирает корневой объект и
принудительно записывает тот же payload по пути `context.client.poToken`. Потоковые, one-shot,
duplex, невалидные и слишком большие JSON-тела завершаются локальной ошибкой вместо отправки
запроса без требуемого поля.

Важно: `X-Youtube-Identity-Token` и `poToken` являются разными классами токенов в протоколах
YouTube. Реализация выполняет запрошенную передачу одного payload в оба места, но сервер может
отвергнуть запрос, если извлечённое значение является только identity token, а не proof-of-origin
токеном, привязанным к текущей сессии/идентификатору.
