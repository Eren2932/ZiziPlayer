# Innertube session proof architecture (6.9.5)

## Единственный источник poToken

Версия 6.9.5 использует только `PoTokenMinter`. Он получает актуальный `visitorData` из
`InnertubeCatalog`, запускает BotGuard в невидимом WebView и возвращает poToken, связанный именно с
этим visitor. Экспериментальная загрузка главной страницы `music.youtube.com`, поиск `ID_TOKEN` и
заголовок `X-Youtube-Identity-Token` полностью удалены.

## Атомарная пара

`InnertubeSessionProof` хранит одну неизменяемую пару:

````text
visitorData + poToken(visitorData)
````

Если Innertube возвращает новый visitorData, старый poToken сбрасывается. Перехватчик не может
увидеть новый visitor вместе со старым proof.

## Модификация запросов

`SessionHeadersInterceptor` исторически сохранил имя, но заголовки больше не меняет. Он обрабатывает
только POST JSON к следующим Innertube endpoint:

````text
https://youtubei.googleapis.com/youtubei/v1/...
https://www.youtube.com/youtubei/v1/...
https://music.youtube.com/youtubei/v1/...
````

В `context.client` записывается visitorData и, если готов соответствующий proof, poToken:

````json
{
  "context": {
    "client": {
      "clientName": "ANDROID_VR",
      "clientVersion": "1.65.10",
      "visitorData": "<current visitor>",
      "poToken": "<proof bound to current visitor>"
    }
  }
}
````

`serviceIntegrityDimensions.poToken` в player body остаётся на месте и получает тот же
visitor-bound session token через `playerBody()`.

## User-Agent

Перехватчик не добавляет и не заменяет User-Agent. Например:

- ANDROID_VR сохраняет `com.google.android.apps.youtube.vr.oculus/...`;
- IOS_MUSIC сохраняет `com.google.ios.youtubemusic/...`;
- ANDROID_MUSIC сохраняет `com.google.android.apps.youtube.music/...`;
- URL потока запрашивается с UA того клиента, который этот URL получил.
