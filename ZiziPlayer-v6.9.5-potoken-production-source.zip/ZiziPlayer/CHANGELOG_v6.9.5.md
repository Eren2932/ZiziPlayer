# ZiziPlayer 6.9.5 — visitor-bound poToken без подмены User-Agent

Удалена экспериментальная схема `X-Youtube-Identity-Token`. poToken больше не отправляется ни в
одном HTTP-заголовке, а общий OkHttp interceptor не изменяет `User-Agent` вообще. ANDROID_VR, IOS,
IOS_MUSIC, ANDROID_MUSIC и web-клиенты сохраняют собственные UA из `InnertubeCatalog.headers()`;
тот же UA продолжает сопровождать выбранную ссылку до Googlevideo CDN.

Удалён второй WebView, который пытался вытащить токен из глобальных переменных
`music.youtube.com`. Такой токен не был гарантированно связан с visitorData приложения. Единственным
источником proof-of-origin снова является существующий `PoTokenMinter`: он запускает BotGuard в
невидимом WebView и минтит poToken непосредственно для текущего `visitorData`.

Добавлен атомарный `InnertubeSessionProof`, хранящий visitorData и соответствующий ему poToken одной
неразрывной парой. При смене visitorData старый токен немедленно сбрасывается. Перед каждым POST JSON
к `/youtubei/v1/` перехватчик гарантированно записывает `context.client.visitorData` и, если он уже
получен для этого visitor, `context.client.poToken`. Другие заголовки и поля запроса не меняются.

Существующее поле `serviceIntegrityDimensions.poToken` в player-запросе сохранено: это отдельная
точка протокола, которую уже заполняет `playerBody`. На 401/403 proof инвалидируется и будет заново
сминчен при следующем resolve.
