package app.ziziplayer.ui.components;

/** Decorative hub artwork selection; never issues a separate catalog request. */
public final class DiscoveryArtworkPolicy {
    private DiscoveryArtworkPolicy() {}
    // Desktop 0.3.5 DiscoveryTile: front +14 degrees, rear -9 degrees.
    public static float rotation(boolean front) { return front ? 14f : -9f; }
    public static int frontIndex(int count, int tileIndex) {
        return count <= 0 ? -1 : Math.floorMod(tileIndex, count);
    }
    public static int backIndex(int count, int tileIndex) {
        return count < 2 ? -1 : (frontIndex(count, tileIndex) + 1) % count;
    }
}
