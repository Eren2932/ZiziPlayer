package app.ziziplayer.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.key
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.RecentEntity
import app.ziziplayer.data.RecentKind
import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.providerLabel
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.OpenCollection
import app.ziziplayer.ui.SearchStage
import app.ziziplayer.ui.SearchTab
import app.ziziplayer.ui.SearchUiState
import app.ziziplayer.ui.SearchViewModel
import app.ziziplayer.ui.TabResults
import app.ziziplayer.ui.components.DiscoveryArtworkPolicy
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.NowPlayingBadge
import app.ziziplayer.ui.components.PillChip
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.TrackTitle
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.fallbackSwatchesFor
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette

/* ===================================================================================
 *  ПОИСК, 6.27.0 — ПЕРЕСОБРАН ПО ЗАМЕРУ РЕФЕРЕНСА
 * ===================================================================================
 *
 *  Все размеры ниже не подобраны на глаз, а сняты с трёх скриншотов референса
 *  (1080 x 2400, 411 dp ширины, 2.628 px/dp). Что мерялось и что получилось:
 *
 *      поле поиска, высота ........ 136 px -> 51.8 dp
 *      поля экрана ................  43 px -> 16.4 dp
 *      плитка жанра ............... 477 x 287 px -> 181.5 x 109.2 dp
 *      зазор колонок / рядов ......  42 / 45 px -> 16 / 17 dp
 *      радиус плитки ..............  ~17 px -> 6.5 dp
 *      карточка раздела (2x2) ..... 472 x 199 px -> 179.6 x 75.7 dp
 *      портретная карточка ........ 364 x 538 px -> 138.5 x 205 dp
 *      «Недавние»: обложка / шаг .. 136 / 182 px -> 51.8 / 69.3 dp
 *
 *  Из этого следует единственная честная реализация ширины плитки: НЕ константа в dp,
 *  а доля ширины экрана. 181.5 dp на 411 dp — это (411 - 2*16.4 - 16) / 2, то есть
 *  «две колонки в поле с зазором», и на любом другом экране правильный ответ даёт та же
 *  формула, а не то же число. Пропорция плитки при этом фиксируется: 1.663 к 1 (477/287).
 *
 *  ЧТО УШЛО ИЗ 6.26.1 И ПОЧЕМУ:
 *
 *   - «Ты искал» лентой чипов в хабе. У референса истории в хабе нет вообще: она живёт
 *     на отдельной поверхности «Недавние», которая открывается по тапу в поле. Лента
 *     чипов была попыткой уместить историю туда, где ей не место, — отсюда и ощущение
 *     «ужаса» по горизонтали. Теперь это вертикальный список с обложками (см. RecentBody).
 *   - MoodTile 64 dp высотой. Плитка референса — 109 dp с наклонённой обложкой, и это не
 *     украшение: обложка в углу — единственное, что отличает жанровую плитку от кнопки.
 *   - SeedTile «Из твоей медиатеки» отдельным блоком. Артисты из медиатеки не исчезли,
 *     они стали источником карточек «Открой новое для себя» — там, где у референса стоит
 *     персональная полка.
 *
 *  ЧТО НЕ БОРРОУИТСЯ И НЕ БУДЕТ: плюс на каждой строке. Прослушивание по-прежнему ничего
 *  не кладёт в медиатеку, кладёт только «+» (см. TrackEntity.savedAt).
 * =================================================================================== */

/** Материализовано один раз: values() аллоцирует массив на каждый вызов, а это ключ LazyRow. */
private val SEARCH_TABS: List<SearchTab> = SearchTab.values().toList()

/**
 * Поля экрана. 43 px по замеру.
 *
 * 6.28.0: `internal`, а не `private`. Настройки переехали на ту же сетку, и общая сетка —
 * это одна константа на два экрана, а не две одинаковые в разных файлах. Второй экземпляр
 * живёт до первой правки: поправят здесь, забудут там, и «тот же стиль» разъедется на 2 dp.
 */
internal val EDGE = 17.dp

/** Зазор между колонками сетки. 42 px по замеру. Общий с настройками — см. [EDGE]. */
internal val GAP = 17.dp

/** Высота строки результата и обложка в ней. */
private val ROW_ART = MediaDimensions.trackArt

/** «Недавние»: обложка 136 px по замеру. */
private val RECENT_ART = MediaDimensions.trackArt

/** Пропорция жанровой плитки: 477 / 287 у референса. Общая с плитками настроек. */
internal const val TILE_RATIO = 1.663f

/** Пропорция карточки раздела в блоке 2x2: 472 / 199. */
private const val QUICK_RATIO = 2.372f

/** Портретная карточка полки «Открой новое для себя»: 364 x 538. */
private val DISCOVER_CARD_W = 138.dp
private const val DISCOVER_RATIO = 0.677f

/** Радиус плитки. 6.5 dp по замеру — округлено вниз, полупиксель на 2.6x не виден. */
internal val TILE_RADIUS = 6.dp

/**
 * Ширина колонки сетки: считается, а не задаётся.
 *
 * На 411 dp даёт ровно 181.3 dp — замеренные 181.5 с точностью до округления пикселя.
 */
@Composable
internal fun columnWidth(): Dp {
    val w = LocalConfiguration.current.screenWidthDp.dp
    return (w - EDGE * 2 - GAP) / 2
}

/**
 * «Поиск» — раздел, который делает из приложения не файловый браузер.
 *
 * Четыре поверхности, а не три (было в 6.26.1): хаб, НЕДАВНИЕ, подсказки, результаты.
 * «Недавние» вынесены в свою поверхность ровно по той причине, по которой у референса они
 * там же: это единственный экран, который человек видит между «нажал на поле» и «набрал
 * первую букву», и он обязан отвечать на вопрос «куда я вчера ходил», а не «какие есть
 * жанры». Хаб отвечает на второй вопрос и живёт под полем, а не поверх него.
 */
@Composable
fun SearchScreen(
    vm: MainViewModel,
    search: SearchViewModel,
    state: SearchUiState,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    /** Артисты из медиатеки, самые слушаемые первыми. Из них строится персональная полка. */
    seeds: List<String>
) {
    val p = LocalPalette.current
    // 6.27.0: активный чип — БРЕНДОВЫЙ, а не акцентный.
    //
    // p.accent пересчитывается из обложки играющего трека (см. ZiziPalette.withAccent), то есть
    // «активный фильтр» менял цвет при смене песни. Бренд — единственное, что на экране обязано
    // стоять на месте: по нему человек узнаёт приложение.
    val chips = remember(p.chip, p.text, p.brand, p.onBrand) {
        ChipColors(p.chip, p.text, p.brand, p.onBrand)
    }

    val links by vm.collectionLinks.collectAsStateWithLifecycle()
    val playlists by vm.playlistsForPicker.collectAsStateWithLifecycle()
    var savePicker by remember { mutableStateOf<OpenCollection?>(null) }
    var confirmRemove by remember { mutableStateOf<OpenCollection?>(null) }

    // Поверхность поиска «сфокусирована», когда клавиатура на экране: недавние и подсказки.
    val focused = state.stage == SearchStage.RECENT || state.stage == SearchStage.SUGGEST

    val keyboard = LocalSoftwareKeyboardController.current
    val searchFocus = LocalFocusManager.current
    val submitQuery: (String) -> Unit = { query ->
        searchFocus.clearFocus()
        keyboard?.hide()
        search.submit(query)
    }

    // Открыть трек из недавних — это и воспроизведение, и подтверждение интереса: строка
    // поднимается наверх списка тем же способом, каким туда попала.
    val playTrack: (RemoteTrack) -> Unit = { track ->
        searchFocus.clearFocus()
        keyboard?.hide()
        search.rememberRecent(track)
        vm.playRemote(listOf(track), 0)
    }
    val openCollection: (RemoteCollection) -> Unit = { collection ->
        searchFocus.clearFocus()
        keyboard?.hide()
        search.rememberRecent(collection)
        search.openCollection(collection)
    }

    val scrollHolder = key(state.query) { rememberSaveableStateHolder() }
    Box(Modifier.fillMaxSize().background(Color(0xFF121212))) {
        Column(Modifier.fillMaxSize()) {
            if (state.stage == SearchStage.HUB) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = EDGE + 2.dp, end = EDGE - 4.dp, top = 8.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Поиск",
                        color = p.text,
                        fontSize = 27.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.weight(1f)
                    )
                    // У референса здесь камера (сканер кода). Сканера у нас нет и не будет, а
                    // место в шапке есть — и единственное действие, которое на этом экране
                    // реально хочется под большим пальцем, это «обнови подборки».
                    HubRefreshButton(
                        refreshing = state.hubRefreshing,
                        onClick = { search.loadHub(force = true) }
                    )
                }
            }

            SearchField(
                text = state.field,
                focusedSurface = state.stage != SearchStage.HUB,
                onText = search::onField,
                onSubmit = submitQuery,
                onClear = search::clearField,
                onFocused = search::onFieldFocused,
                onBack = { search.back() }
            )

            when (state.stage) {
                SearchStage.HUB -> HubBody(
                    state = state,
                    seeds = seeds,
                    onSearch = submitQuery,
                    onOpen = openCollection,
                    onPlay = playTrack,
                    onRetryHub = { search.loadHub(force = true) }
                )

                SearchStage.RECENT -> RecentBody(
                    recents = state.recents,
                    savedIds = savedIds,
                    currentTrackId = currentTrackId,
                    isPlaying = isPlaying,
                    onSearch = submitQuery,
                    onPlay = playTrack,
                    onOpen = openCollection,
                    onSave = vm::saveRemote,
                    onUnsave = { vm.setRemoteSaved(it, false) },
                    onForget = search::forgetRecent,
                    onClear = search::clearRecents
                )

                SearchStage.SUGGEST -> SuggestBody(
                    field = state.field,
                    suggestions = state.suggestions,
                    recents = state.recents,
                    preview = state.previewTracks,
                    loading = state.previewLoading,
                    error = state.previewError,
                    savedIds = savedIds,
                    currentTrackId = currentTrackId,
                    isPlaying = isPlaying,
                    onFill = search::onField,
                    onSave = vm::saveRemote,
                    onUnsave = { vm.setRemoteSaved(it, false) },
                    onPick = submitQuery,
                    onPlay = playTrack
                )

                SearchStage.RESULTS -> scrollHolder.SaveableStateProvider(state.tab.name) {
                    ResultsBody(
                    state = state,
                    chips = chips,
                    savedIds = savedIds,
                    currentTrackId = currentTrackId,
                    isPlaying = isPlaying,
                    onTab = search::setTab,
                    onLoadMore = search::loadMore,
                    onRetry = search::retry,
                    onPlay = { list, index ->
                        list.getOrNull(index)?.let { search.rememberRecent(it) }
                        vm.playRemote(list, index)
                    },
                    onSave = vm::saveRemote,
                    onUnsave = { vm.setRemoteSaved(it, false) },
                    onOpen = openCollection,
                    importedKeys = links.keys
                    )
                }
            }
        }

        state.collection?.let { open ->
            val collectionKey = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            key(open.collection.provider, open.collection.remoteId) {
            CollectionPageScreen(
                open = open,
                savedIds = savedIds,
                currentTrackId = currentTrackId,
                isPlaying = isPlaying,
                onClose = search::closeCollection,
                onPlay = { index -> vm.playRemote(open.tracks, index) },
                onShuffle = { vm.playRemote(open.tracks.shuffled(), 0) },
                imported = links.containsKey(collectionKey),
                onAddCollection = { savePicker = open },
                onRemoveCollection = { confirmRemove = open },
                onSave = vm::saveRemote,
                onUnsave = { vm.setRemoteSaved(it, false) },
                onRetry = search::retryCollection,
                onLoadMore = search::loadMoreCollection
            )
            }
        }

        savePicker?.let { open ->
            val key = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            PlaylistPickerSheet(
                playlists = playlists,
                title = "Сохранить к себе",
                subtitle = "«${open.collection.title}» · ${open.tracks.size}",
                defaultName = open.collection.title,
                onPick = { id ->
                    vm.saveCollectionAsPlaylist(key, open.collection.title, open.tracks, intoPlaylistId = id)
                    savePicker = null
                },
                onCreate = { name ->
                    vm.saveCollectionAsPlaylist(key, open.collection.title, open.tracks, newName = name)
                    savePicker = null
                },
                onDismiss = { savePicker = null }
            )
        }

        confirmRemove?.let { open ->
            val key = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            val link = links[key]
            if (link == null) confirmRemove = null
            else ConfirmDialog(
                title = if (link.owned) "Удалить плейлист?" else "Убрать треки?",
                message = if (link.owned)
                    "«${link.title}» пропадёт из медиатеки целиком. Сам сборник останется в поиске — добавить заново можно в любой момент."
                else "Треки этого сборника уйдут из плейлиста «${link.title}». Остальное в плейлисте не тронем.",
                confirm = if (link.owned) "Удалить" else "Убрать",
                onConfirm = {
                    vm.removeCollection(key, open.tracks.map { it.trackId })
                    confirmRemove = null
                },
                onDismiss = { confirmRemove = null }
            )
        }
    }
}

// ------------------------------------------------------------------ поле

/**
 * Поле поиска в двух состояниях, как у референса.
 *
 * СПОКОЙНОЕ (хаб): белая плашка 51.8 dp с тёмной подписью. Да, белая — это не описка и не
 * «светлая тема протекла». На тёмном хабе поле обязано быть единственным светлым объектом:
 * оно и есть входная точка раздела, а всё остальное на экране — материал. Референс поступает
 * так же и по той же причине.
 *
 * СФОКУСИРОВАННОЕ (недавние / подсказки): плашка гаснет до фона, слева появляется стрелка
 * назад. Клавиатура уже на экране, белый прямоугольник под ней ничего не сообщает, зато
 * стрелка отвечает на единственный вопрос этого состояния — «как отсюда выйти».
 */
@Composable
private fun SearchField(
    text: String,
    focusedSurface: Boolean,
    onText: (String) -> Unit,
    onSubmit: (String) -> Unit,
    onClear: () -> Unit,
    onFocused: () -> Unit,
    onBack: () -> Unit
) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    val fieldBg = if (focusedSurface) Color(0xFF292929) else Color.White
    val fieldText = if (focusedSurface) p.text else Color(0xFF121212)
    val hintText = if (focusedSurface) p.subtext else Color(0xFF6E6E6E)

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = if (focusedSurface) 0.dp else EDGE)
            // 6.29.3, размеры сняты с референса на экране 1080: высота 136 px, радиус угла
            // 9.5 px. Радиус был 8.dp — вдвое круглее оригинала, плашка читалась как «пилюля».
            .height(if (focusedSurface) 52.dp else 49.5.dp)
            .clip(RoundedCornerShape(3.5.dp))
            .background(fieldBg)
            .padding(start = if (focusedSurface) 0.dp else 9.5.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (focusedSurface) {
            RoundIconButton(
                icon = ZiziIcons.ArrowBack,
                tint = p.text,
                background = Color.Transparent,
                size = 44,
                iconSize = 23,
                onClick = {
                    keyboard?.hide()
                    onBack()
                }
            )
            Spacer(Modifier.width(2.dp))
        } else {
            // Лупа в референсе 61x59 px — это 29 dp кегля, а не 22: пропорции знака у нас и у
            // оригинала совпадают (обводка к ширине 0.112 против 0.118), расходился только размер.
            Icon(ZiziIcons.Search, null, tint = Color(0xFF121212), modifier = Modifier.size(29.dp))
            Spacer(Modifier.width(11.dp))
        }
        BasicTextField(
            value = text,
            // Как и раньше: дебаунса здесь нет намеренно. Тот, что имеет значение, стоит на
            // сетевом запросе внутри SearchViewModel, где его можно отменить.
            onValueChange = onText,
            singleLine = true,
            textStyle = TextStyle(
                color = fieldText,
                fontSize = 17.sp,
                fontWeight = if (focusedSurface) FontWeight.Medium else FontWeight.Bold
            ),
            cursorBrush = SolidColor(p.brand),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSubmit(text)
                keyboard?.hide()
            }),
            modifier = Modifier
                .weight(1f)
                .focusRequester(focus)
                .onFocusChanged { if (it.isFocused) onFocused() },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) {
                        Text(
                            "Что хочешь послушать?",
                            color = hintText,
                            fontSize = 16.sp,
                            fontWeight = if (focusedSurface) FontWeight.Normal else FontWeight.SemiBold
                        )
                    }
                    inner()
                }
            }
        )
        if (text.isNotEmpty()) {
            RoundIconButton(
                icon = ZiziIcons.Close,
                tint = if (focusedSurface) p.subtext else Color(0xFF121212),
                background = Color.Transparent,
                size = 38,
                iconSize = 20,
                onClick = {
                    onClear()
                    focus.requestFocus()
                }
            )
        }
    }
    Spacer(Modifier.height(if (focusedSurface) 6.dp else 12.dp))
}

// ------------------------------------------------------------------ хаб

/**
 * Разделы верхнего блока 2x2.
 *
 * У референса это «Музыка / Подкасты / Аудиокниги / Мероприятия» — типы контента, которых у
 * него четыре. У нас тип контента ровно один, поэтому четыре плитки отданы не типам, а
 * входам: три из них — готовые запросы, которые человек и так набирает руками, четвёртый —
 * личный, он собирается из самого слушаемого артиста медиатеки.
 *
 * [query] намеренно не равен [label]: подпись короткая и русская, а в поиск уходит
 * формулировка, на которой у провайдера есть выдача. «Новинки» находит мусор, «new music
 * 2026» находит новинки.
 */
private data class QuickEntry(val label: String, val query: String, val color: Color)

@Composable
private fun quickEntries(seeds: List<String>): List<QuickEntry> {
    val p = LocalPalette.current
    val top = seeds.firstOrNull()
    return remember(top, p.brand) {
        listOf(
            QuickEntry(
                label = if (top != null) "Твоя волна" else "Популярное",
                query = if (top != null) "$top radio" else "хиты 2026",
                color = p.brand
            ),
            QuickEntry("Новинки", "new music 2026", Color(0xFF1E6F5C)),
            QuickEntry("Чарты", "top hits chart", Color(0xFF2E4EA8)),
            QuickEntry("Настроения", "chill mood mix", Color(0xFF7B2FBF))
        )
    }
}

/**
 * Жанровая сетка — то, ради чего этот экран переписан.
 *
 * Двадцать четыре плитки, две колонки, порядок неслучайный: первые шесть — то, что в этом
 * приложении ищут чаще всего (фонк, слоуед, русский рэп), дальше по убыванию. Первый экран
 * должен закрывать девяносто процентов запросов без клавиатуры, иначе сетка — просто обои.
 *
 * Цвета взяты списком, а не выведены из подписи. Хэш от строки даёт равномерный шум по кругу
 * оттенков, и рядом неизбежно оказываются два почти одинаковых цвета — на сетке из 24 плиток
 * это видно сразу. Список из 12 тонов, взятых через хроматический шаг и включающих бренд,
 * повторяется дважды и гарантирует, что соседи по строке и по столбцу различаются.
 */
private data class Category(val label: String, val query: String)

private val CATEGORIES = listOf(
    Category("Фонк", "phonk"),
    Category("Русский рэп", "русский рэп 2026"),
    Category("Замедленные", "slowed reverb"),
    Category("Ускоренные", "sped up"),
    Category("Басс", "bass boosted"),
    Category("Бразильский фанк", "funk brazilian"),
    Category("Хип-хоп", "hip hop 2026"),
    Category("Поп", "pop hits"),
    Category("Рок", "rock classics"),
    Category("Метал", "metal essentials"),
    Category("Электроника", "electronic music"),
    Category("Хаус", "house mix"),
    Category("Техно", "techno set"),
    Category("Драм-н-бэйс", "drum and bass"),
    Category("Дабстеп", "dubstep"),
    Category("Лоу-фай", "lofi beats"),
    Category("Джаз", "jazz essentials"),
    Category("Блюз", "blues classics"),
    Category("Классика", "classical music"),
    Category("Саундтреки", "soundtrack ost"),
    Category("Аниме", "anime openings"),
    Category("K-pop", "kpop hits"),
    Category("Инди", "indie music"),
    Category("Для сна", "sleep ambient")
)

/**
 * Палитра плиток.
 *
 * 6.28.0: общая с настройками. Цвета здесь не декоративные, а опознавательные: человек
 * запоминает не подпись, а «синяя плитка слева внизу», и если в настройках будет свой набор
 * оттенков, два экрана перестанут читаться как одно приложение. Один список — один язык.
 */
internal val TILE_COLORS = listOf(
    Color(0xFFF97316), // бренд
    Color(0xFF1E3264),
    Color(0xFFE13300),
    Color(0xFF148A08),
    Color(0xFF8D67AB),
    Color(0xFFB02897),
    Color(0xFF0D73EC),
    Color(0xFF7D4B32),
    Color(0xFFBC5900),
    Color(0xFF503750),
    Color(0xFF477D95),
    Color(0xFFA56752)
)

@Composable
private fun HubBody(
    state: SearchUiState,
    seeds: List<String>,
    onSearch: (String) -> Unit,
    onOpen: (RemoteCollection) -> Unit,
    onPlay: (RemoteTrack) -> Unit,
    onRetryHub: () -> Unit
) {
    val p = LocalPalette.current
    val quick = quickEntries(seeds)
    val column = columnWidth()

    // Обложки для плиток берутся из того, что провайдер уже прислал в подборки: реальные
    // картинки вместо заглушек, и ни одного лишнего сетевого запроса — эти URL уже в кэше,
    // потому что те же обложки рисуются полками ниже.
    val artPool = remember(state.shelves) {
        state.shelves.asSequence()
            .flatMap { it.items.asSequence() }
            .mapNotNull { item ->
                when (item) {
                    is RemoteItem.Song -> item.track.artworkUrl
                    is RemoteItem.Group -> item.collection.artworkUrl
                }
            }
            .filter { it.isNotBlank() }
            .distinct()
            .take(40)
            .toList()
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item(key = "quick") {
            Column(Modifier.padding(horizontal = EDGE)) {
                quick.chunked(2).forEach { pair ->
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = GAP - 1.dp),
                        horizontalArrangement = Arrangement.spacedBy(GAP)
                    ) {
                        pair.forEach { entry ->
                            QuickTile(
                                entry = entry,
                                frontArt = artPool.getOrNull(DiscoveryArtworkPolicy.frontIndex(artPool.size, quick.indexOf(entry))),
                                backArt = artPool.getOrNull(DiscoveryArtworkPolicy.backIndex(artPool.size, quick.indexOf(entry))),
                                modifier = Modifier.weight(1f),
                                onClick = { onSearch(entry.query) }
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        // Персональная полка. Она СТРОИТСЯ ИЗ МЕДИАТЕКИ, а не из чартов: карточка — это артист,
        // которого человек уже слушает, и запрос уходит на его радио. Настоящий движок
        // рекомендаций встанет ровно сюда и заменит эту эвристику, не тронув вёрстку.
        if (seeds.isNotEmpty()) {
            item(key = "discover-head") { SectionHead("Открой новое для себя") }
            item(key = "discover") {
                LazyRow(
                    Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = EDGE),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(seeds.take(10), key = { _, name -> "d:$name" }) { index, name ->
                        DiscoverCard(
                            title = name,
                            caption = "Радио по артисту",
                            art = artPool.getOrNull(index + 4),
                            onClick = { onSearch("$name radio") }
                        )
                    }
                }
            }
        }

        item(key = "cat-head") { SectionHead("Всё, что можно послушать") }
        itemsIndexed(CATEGORIES.chunked(2), key = { _, pair -> "c:${pair.first().label}" }) { row, pair ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = EDGE, vertical = (GAP / 2) - 0.5.dp),
                horizontalArrangement = Arrangement.spacedBy(GAP)
            ) {
                pair.forEachIndexed { col, category ->
                    val index = row * 2 + col
                    CategoryTile(
                        category = category,
                        color = TILE_COLORS[index % TILE_COLORS.size],
                        frontArt = artPool.getOrNull(DiscoveryArtworkPolicy.frontIndex(artPool.size, index)),
                        backArt = artPool.getOrNull(DiscoveryArtworkPolicy.backIndex(artPool.size, index)),
                        width = column,
                        onClick = { onSearch(category.query) }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.width(column))
            }
        }

        if (state.hubError != null) {
            item(key = "hub-error") {
                NoticeStrip(
                    text = "Подборки не загрузились: ${state.hubError}",
                    action = "Повторить",
                    onAction = onRetryHub
                )
            }
        }
        if (state.hubLoading && state.shelves.isEmpty()) {
            item(key = "hub-loading") { LoadingRow("Загружаем подборки…") }
        }
        items(state.shelves, key = { "s:${it.title}" }) { shelf ->
            Shelf(shelf, onOpen = onOpen, onPlay = onPlay)
        }
    }
}

/** Compact quick entry: same navigation, now with a slightly larger two-cover stack. */
@Composable
private fun QuickTile(
    entry: QuickEntry,
    frontArt: String?,
    backArt: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    BoxWithConstraints(
        modifier
            .aspectRatio(QUICK_RATIO)
            .clip(RoundedCornerShape(TILE_RADIUS))
            .background(entry.color)
            .clickable(onClick = onClick)
            .clipToBounds()
    ) {
        val artSize = (maxWidth * 0.34f).coerceIn(58.dp, 72.dp)
        TiltedArtPair(frontArt, backArt, entry.label, artSize, Modifier.align(Alignment.BottomEnd))
        // Text is deliberately drawn AFTER the artwork, with a local readability scrim.
        Box(Modifier.fillMaxWidth().height(54.dp).background(Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = 0.32f), Color.Transparent))))
        Text(
            entry.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 10.dp, end = 12.dp)
                .fillMaxWidth(0.85f)
        )
    }
}

/** Genre tile: keep its grid footprint, enlarge the covers rather than the whole card. */
@Composable
private fun CategoryTile(
    category: Category,
    color: Color,
    frontArt: String?,
    backArt: String?,
    width: Dp,
    onClick: () -> Unit
) {
    Box(
        Modifier.width(width).aspectRatio(TILE_RATIO)
            .clip(RoundedCornerShape(TILE_RADIUS)).background(color)
            .clickable(onClick = onClick).clipToBounds()
    ) {
        val artSize = (width * 0.43f).coerceIn(72.dp, 94.dp)
        TiltedArtPair(frontArt, backArt, category.label, artSize, Modifier.align(Alignment.BottomEnd))
        Box(Modifier.fillMaxWidth().height(64.dp).background(Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = 0.36f), Color.Transparent))))
        Text(
            category.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 13.dp, top = 11.dp, end = 12.dp)
                .fillMaxWidth(0.85f)
        )
    }
}

/** Desktop 0.3.5 stack geometry, scaled for touch cards. Rear is drawn first.
 * Art comes from existing hub shelves (decorative, not a promise of genre-specific albums).
 * A missing second URL uses the normal Zizi placeholder, never the same image twice.
 * The tile clips the rotated shadows; the covers do not introduce tiny click targets.
 */
@Composable
private fun TiltedArtPair(frontArt: String?, backArt: String?, seed: String, size: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(width = size * 1.6f, height = size * 1.25f)) {
        listOf(false, true).forEach { front ->
            RemoteArtwork(
                url = if (front) frontArt else backArt,
                seed = if (front) seed else "$seed:back",
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier.align(Alignment.BottomEnd)
                    .offset(x = size * (if (front) 6f / 130f else -42f / 130f),
                        y = size * (if (front) 22f / 130f else 12f / 130f))
                    .size(size)
                    .graphicsLayer {
                        rotationZ = DiscoveryArtworkPolicy.rotation(front)
                        shadowElevation = 8.dp.toPx()
                        shape = RoundedCornerShape(4.dp)
                        clip = true
                    },
                glyphSize = 20
            )
        }
    }
}

/** Портретная карточка полки «Открой новое для себя»: 138.5 x 205 dp по замеру. */
@Composable
private fun DiscoverCard(title: String, caption: String, art: String?, onClick: () -> Unit) {
    val colors = remember(title) { fallbackSwatchesFor(title) }
    Box(
        Modifier
            .width(DISCOVER_CARD_W)
            .aspectRatio(DISCOVER_RATIO)
            .clip(RoundedCornerShape(8.dp))
            .drawWithCache {
                val brush = Brush.linearGradient(
                    listOf(colors.primary, colors.deep),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height)
                )
                onDrawBehind { drawRect(brush) }
            }
            .clickable(onClick = onClick)
            .clipToBounds()
    ) {
        RemoteArtwork(
            url = art,
            seed = title,
            maxPx = ARTWORK_ROW_PX,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 14.dp)
                .size(DISCOVER_CARD_W - 28.dp)
                .clip(CircleShape),
            glyphSize = 30
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
        ) {
            Text(
                title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                caption,
                color = Color.White.copy(alpha = 0.75f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Полка провайдера. Карточка — доля экрана, как и колонка сетки. */
@Composable
private fun shelfCardWidth(): Dp {
    val w = LocalConfiguration.current.screenWidthDp.dp
    return (w * 0.34f).coerceIn(128.dp, 188.dp)
}

@Composable
private fun Shelf(
    shelf: DiscoverShelf,
    onOpen: (RemoteCollection) -> Unit,
    onPlay: (RemoteTrack) -> Unit
) {
    SectionHead(shelf.title)
    val card = shelfCardWidth()
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = EDGE),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(shelf.items, key = { keyOf(it) }) { item ->
            when (item) {
                is RemoteItem.Song -> ShelfCard(
                    art = item.track.artworkUrl,
                    seed = item.track.trackId,
                    title = item.track.title,
                    subtitle = item.track.artist,
                    round = false,
                    width = card,
                    onClick = { onPlay(item.track) }
                )
                is RemoteItem.Group -> ShelfCard(
                    art = item.collection.artworkUrl,
                    seed = item.collection.remoteId,
                    title = item.collection.title,
                    subtitle = item.collection.subtitle.ifBlank { kindLabel(item.collection.kind) },
                    round = item.collection.kind == RemoteKind.ARTIST,
                    width = card,
                    onClick = { onOpen(item.collection) }
                )
            }
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun ShelfCard(
    art: String?,
    seed: String,
    title: String,
    subtitle: String,
    round: Boolean,
    width: Dp,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .width(width)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        RemoteArtwork(
            url = art,
            seed = seed,
            // Запрашивается в размер строки, а не карточки: CDN отдаёт 240 px, этого уже больше,
            // чем нужно карточке 128 dp на 3x, и те же байты обслуживают строку и мини-плеер.
            maxPx = ARTWORK_ROW_PX,
            modifier = Modifier
                .size(width)
                .clip(if (round) CircleShape else RoundedCornerShape(12.dp)),
            glyphSize = 34
        )
        Spacer(Modifier.height(8.dp))
        Text(
            title,
            color = p.text,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (subtitle.isNotBlank()) {
            Text(subtitle, color = p.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------------ недавние

/**
 * «НЕДАВНИЕ» — то, чего у нас не было вообще.
 *
 * До 6.27.0 память поиска состояла из строк: таблица `search_history`, двадцать запросов,
 * нарисованных лентой чипов в хабе. Проблема ленты не в том, что она горизонтальная, а в том,
 * ЧТО в ней лежит. Человек ищет не «слова, которые я вводил», а «то, что я вчера слушал», и
 * между этими двумя списками нет ничего общего: запрос «semp» не напоминает ни о чём, а
 * строка «SEMPERO · Мини-альбом · QMIIR» с обложкой напоминает обо всём сразу.
 *
 * Поэтому теперь запоминается СУЩНОСТЬ (таблица `recents`, миграция 7 -> 8): трек, альбом,
 * плейлист, артист — с обложкой, типом и автором; и отдельно, наравне с ними, сам запрос,
 * если по нему ничего не открыли. Строка 69.3 dp, обложка 51.8 dp, «+» и «x» справа — всё по
 * замеру референса.
 *
 * Почему «x» здесь есть, а в чипах 6.26.1 не было: в строке высотой 69 dp две цели по 44 dp
 * расходятся на 53 dp по центрам, и промахнуться мимо «плюса» в «крестик» нельзя. В чипе
 * высотой 38 dp это были бы две команды ближе пальца друг к другу — там забывание жило на
 * долгом нажатии, и это было правильно для чипа.
 */
@Composable
private fun RecentBody(
    recents: List<RecentEntity>,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onSearch: (String) -> Unit,
    onPlay: (RemoteTrack) -> Unit,
    onOpen: (RemoteCollection) -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit,
    onForget: (String) -> Unit,
    onClear: () -> Unit
) {
    val p = LocalPalette.current
    if (recents.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 28.dp)) {
            Text(
                "Здесь появится то, что ты слушал",
                color = p.text,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Треки, альбомы и запросы из поиска — по одному нажатию, без клавиатуры.",
                color = p.subtext,
                fontSize = 13.5.sp
            )
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item(key = "recent-head") { SectionHead("Недавние", "Очистить", onClear) }
        items(recents, key = { it.key }) { entry ->
            RecentRow(
                entry = entry,
                saved = entry.trackId != null && savedIds.contains(entry.trackId),
                current = entry.trackId != null && entry.trackId == currentTrackId,
                playing = entry.trackId != null && entry.trackId == currentTrackId && isPlaying,
                onClick = {
                    when (entry.kind) {
                        RecentKind.QUERY -> onSearch(entry.title)
                        RecentKind.TRACK -> entry.asTrack()?.let(onPlay)
                        else -> entry.asCollection()?.let(onOpen)
                    }
                },
                onPlus = {
                    val track = entry.asTrack()
                    if (track != null) {
                        if (savedIds.contains(track.trackId)) onUnsave(track.trackId) else onSave(track)
                    } else {
                        entry.asCollection()?.let(onOpen)
                    }
                },
                onForget = { onForget(entry.key) }
            )
        }
    }
}

@Composable
private fun RecentRow(
    entry: RecentEntity,
    saved: Boolean,
    current: Boolean,
    playing: Boolean,
    onClick: () -> Unit,
    onPlus: () -> Unit,
    onForget: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = EDGE, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (entry.kind == RecentKind.QUERY) {
            // У запроса нет обложки, и рисовать ему сгенерированный градиент нельзя: он бы
            // выглядел как альбом, которого не существует. Квадрат-подложка с часами занимает
            // ровно то же место, поэтому список не «прыгает» смешанным содержимым.
            Box(
                Modifier
                    .size(RECENT_ART)
                    .clip(RoundedCornerShape(4.dp))
                    .background(p.chip),
                contentAlignment = Alignment.Center
            ) {
                Icon(ZiziIcons.History, null, tint = p.subtext, modifier = Modifier.size(23.dp))
            }
        } else {
            Box(contentAlignment = Alignment.Center) {
                RemoteArtwork(
                    url = entry.artworkUrl,
                    seed = entry.remoteId ?: entry.key,
                    maxPx = ARTWORK_ROW_PX,
                    modifier = Modifier
                        .size(RECENT_ART)
                        .clip(if (entry.kind == RecentKind.ARTIST) CircleShape else RoundedCornerShape(4.dp)),
                    glyphSize = 20
                )
                NowPlayingBadge(current = current, playing = playing, size = RECENT_ART, corner = 4.dp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.title,
                // Играющий трек подсвечивается брендом и в недавних тоже: это тот же объект,
                // что и в мини-плеере, и он обязан выглядеть так же.
                color = if (current) p.brand else p.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val subtitle = buildString {
                append(recentKindLabel(entry.kind))
                if (entry.subtitle.isNotBlank()) append(" · ").append(entry.subtitle)
            }
            Text(subtitle, color = p.subtext, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (entry.kind != RecentKind.QUERY && entry.kind != RecentKind.ARTIST) {
            RoundIconButton(
                icon = if (saved) ZiziIcons.Check else ZiziIcons.Plus,
                tint = if (saved) p.brand else p.text,
                background = Color.Transparent,
                size = 44,
                iconSize = 23,
                onClick = onPlus
            )
        } else {
            Spacer(Modifier.width(44.dp))
        }
        RoundIconButton(
            icon = ZiziIcons.Close,
            tint = p.subtext,
            background = Color.Transparent,
            size = 44,
            iconSize = 22,
            onClick = onForget
        )
    }
}

// ------------------------------------------------------------------ подсказки

/**
 * Подсказки во время набора.
 *
 * Порядок жёсткий и он же единственно верный: сначала СВОИ недавние, подходящие под набранное,
 * потом догадки провайдера. Своё всегда точнее чужого — человек уже был там, куда он сейчас
 * снова целится, и заставлять его дочитывать до своей же вчерашней сессии незачем.
 */
@Composable
private fun SuggestBody(
    field: String,
    suggestions: List<String>,
    recents: List<RecentEntity>,
    preview: List<RemoteTrack>,
    loading: Boolean,
    error: String?,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onFill: (String) -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit,
    onPick: (String) -> Unit,
    onPlay: (RemoteTrack) -> Unit
) {
    val p = LocalPalette.current
    val needle = field.trim().lowercase(java.util.Locale.ROOT)
    val tracks = remember(needle, preview, recents) {
        val recentTracks = if (needle.length < 2) emptyList() else recents.filter {
            it.title.lowercase(java.util.Locale.ROOT).contains(needle) ||
                it.subtitle.lowercase(java.util.Locale.ROOT).contains(needle)
        }.mapNotNull { it.asTrack() }
        (preview + recentTracks).distinctBy { it.trackId }.take(4)
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(suggestions.distinct(), key = { "suggest:$it" }, contentType = { "suggestion" }) { query ->
            SuggestRow(query, onFill = { onFill(query) }, onClick = { onPick(query) })
        }
        items(tracks, key = { "preview:${it.trackId}" }, contentType = { "track" }) { track ->
            ResultTrackRow(
                track = track,
                saved = track.trackId in savedIds,
                current = track.trackId == currentTrackId,
                playing = isPlaying && track.trackId == currentTrackId,
                onPlay = { onPlay(track) },
                onSave = { onSave(track) },
                onUnsave = { onUnsave(track.trackId) }
            )
        }
        if (loading) item(key = "preview:loading") { LoadingRow("Ищу совпадения…") }
        if (error != null) item(key = "preview:error") {
            Text(error, color = p.subtext, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
        }
        if (needle.isNotEmpty()) item(key = "preview:submit") {
            Text(
                "Показать все результаты для «${field.trim()}»",
                color = p.text, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().clickable { onPick(field) }.padding(16.dp)
            )
        }
    }
}

@Composable
private fun SuggestRow(text: String, onFill: () -> Unit, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(onClick = onClick)
            .padding(start = EDGE, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(ZiziIcons.Search, contentDescription = null, tint = p.subtext, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(text, color = p.text, fontSize = 18.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        IconButton(onClick = onFill) {
            Icon(ZiziIcons.ArrowBack, contentDescription = "Подставить запрос: $text", tint = p.subtext,
                modifier = Modifier.graphicsLayer { rotationZ = 45f })
        }
    }
}

// ------------------------------------------------------------------ results

@Composable
private fun ResultsBody(
    state: SearchUiState,
    chips: ChipColors,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onTab: (SearchTab) -> Unit,
    onLoadMore: () -> Unit,
    onRetry: () -> Unit,
    onPlay: (List<RemoteTrack>, Int) -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit,
    onOpen: (RemoteCollection) -> Unit,
    /** Ключи сборников, уже добавленных к себе: на них в списке стоит галочка (6.17.0). */
    importedKeys: Set<String> = emptySet()
) {
    val p = LocalPalette.current
    val results: TabResults = state.current
    val listState = rememberLazyListState()

    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (state.tab != SearchTab.ALL) {
            item(key = "reset-filter") {
                RoundIconButton(ZiziIcons.Close, p.text, p.chip, 36, 20, { onTab(SearchTab.ALL) })
            }
        }
        items(if (state.tab == SearchTab.ALL) SEARCH_TABS else listOf(state.tab), key = { it.name }) { tab ->
            PillChip(tab.label, null, state.tab == tab, chips, onClick = { onTab(tab) })
        }
    }
    Spacer(Modifier.height(6.dp))

    // The tracks of this list, in list order. Tapping a row plays FROM that row and keeps the rest
    // of the results as the queue - a search result you tap is a queue, not a single track, which
    // is the difference between a player and a preview button.
    val songs = remember(results.items) {
        results.items.filterIsInstance<RemoteItem.Song>().map { it.track }
    }

    // Endless scroll, armed four rows from the bottom so the next page is already arriving by the
    // time the user reaches it. derivedStateOf keeps this out of the recomposition path: reading
    // layoutInfo directly in composition would recompose the whole list on every scrolled pixel.
    val nearEnd by remember(results.items.size) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: return@derivedStateOf false
            last >= results.items.size - 4
        }
    }
    LaunchedEffect(nearEnd, state.tab, state.query, results.nextToken) {
        if (nearEnd) onLoadMore()
    }

    Box(Modifier.fillMaxSize()) {
        when {
            results.loading -> LoadingRow("Ищем…")

            results.error != null && results.items.isEmpty() -> ErrorBlock(results.error, onRetry)

            results.isEmpty -> Text(
                "По запросу «${state.query}» ничего не нашлось",
                color = p.subtext,
                fontSize = 14.5.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 22.dp)
            )

            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                itemsIndexed(results.items, key = { _, item -> keyOf(item) }) { _, item ->
                    when (item) {
                        is RemoteItem.Song -> {
                            val track = item.track
                            ResultTrackRow(
                                track = track,
                                saved = savedIds.contains(track.trackId),
                                playing = currentTrackId == track.trackId && isPlaying,
                                current = currentTrackId == track.trackId,
                                onPlay = {
                                    val index = songs.indexOfFirst { it.trackId == track.trackId }
                                    onPlay(songs, index.coerceAtLeast(0))
                                },
                                onSave = { onSave(track) },
                                onUnsave = { onUnsave(track.trackId) }
                            )
                        }
                        is RemoteItem.Group -> ResultGroupRow(
                            collection = item.collection,
                            imported = importedKeys.contains("${item.collection.provider}:${item.collection.remoteId}"),
                            onClick = { onOpen(item.collection) }
                        )
                    }
                }

                if (results.appending) {
                    item(key = "appending") { LoadingRow("Ещё…") }
                }
                if (results.error != null && results.items.isNotEmpty()) {
                    // A page that failed after the first one must not blank the results already on
                    // screen. It gets a strip at the bottom and nothing else moves.
                    item(key = "tail-error") {
                        NoticeStrip(results.error, "Ещё раз", onRetry)
                    }
                }
                if (results.provider != null) {
                    item(key = "provider") {
                        Text(
                            "Источник: ${providerLabel(results.provider)}",
                            color = p.subtext.copy(alpha = 0.7f),
                            fontSize = 11.5.sp,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun ResultTrackRow(
    track: RemoteTrack,
    saved: Boolean,
    playing: Boolean,
    current: Boolean,
    onPlay: () -> Unit,
    onSave: () -> Unit,
    onUnsave: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = EDGE, end = 6.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.Center) {
            RemoteArtwork(
                url = track.artworkUrl,
                seed = track.trackId,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .size(ROW_ART)
                    .clip(RoundedCornerShape(4.dp)),
                glyphSize = 18
            )
            // 6.13.0: было `Icon(PlayArrow)` — ▶ у играющего трека против ⏸ в мини-плеере.
            NowPlayingBadge(current = current, playing = playing, size = ROW_ART, corner = 4.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            TrackTitle(
                title = track.title,
                color = if (current) p.brand else p.text,
                dim = p.text.copy(alpha = 0.45f),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (track.explicit) {
                    ExplicitBadge()
                    Spacer(Modifier.width(5.dp))
                }
                Text(
                    buildString {
                        append(track.artist)
                        if (track.durationMs > 0) append(" · ").append(formatTime(track.durationMs))
                    },
                    color = p.subtext,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        // The one control on the row, and it says what it does: plus means "не у меня", check means
        // "у меня". Nothing here deletes anything - unsaving only removes the row from the library,
        // the track keeps playing if it is playing.
        RoundIconButton(
            icon = if (saved) ZiziIcons.Check else ZiziIcons.Plus,
            tint = if (saved) p.brand else p.text,
            background = Color.Transparent,
            size = 42,
            iconSize = 22,
            onClick = { if (saved) onUnsave() else onSave() }
        )
    }
}

@Composable
private fun ResultGroupRow(collection: RemoteCollection, imported: Boolean = false, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = EDGE, end = 10.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteArtwork(
            url = collection.artworkUrl,
            seed = collection.remoteId,
            maxPx = ARTWORK_ROW_PX,
            modifier = Modifier
                .size(ROW_ART)
                .clip(if (collection.kind == RemoteKind.ARTIST) CircleShape else RoundedCornerShape(4.dp)),
            glyphSize = 18
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                collection.title,
                color = p.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                buildString {
                    append(kindLabel(collection.kind))
                    if (collection.subtitle.isNotBlank()) append(" · ").append(collection.subtitle)
                },
                color = p.subtext,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        // Галочка вместо стрелки: сборник уже лежит у тебя, открывать его заново незачем — но
        // если откроешь, там будет «Сохранён» и повторное нажатие уберёт.
        if (imported) {
            Icon(ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(2.dp))
        }
        Icon(ZiziIcons.ChevronRight, null, tint = p.subtext, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun ActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    filled: Boolean,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (filled) p.brand else p.chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            null,
            tint = if (filled) p.onBrand else p.text,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            label,
            color = if (filled) p.onBrand else p.text,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

// ------------------------------------------------------------------ small parts

@Composable
private fun SectionHead(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 14.dp, top = 14.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            color = p.text,
            // 6.26.1: 17 -> 20 sp. Заголовок раздела и название трека в строке результатов были
            // 17 и 15 sp: разница 2 sp, при Bold против SemiBold она почти не читается, и полки
            // выглядели как один длинный список без границ. 20 против 15 — это уже уровень.
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (action != null && onAction != null) {
            Text(
                action,
                // Действие раздела акцентное, а не приглушённое: «Очистить» — это то, что можно
                // нажать, и оно не должно выглядеть подписью.
                color = p.brand,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}


@Composable
private fun ExplicitBadge() {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(13.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(p.subtext.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center
    ) {
        Text("E", color = p.bottom, fontSize = 9.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
internal fun LoadingRow(text: String) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = p.brand,
            strokeWidth = 2.dp
        )
        Spacer(Modifier.width(12.dp))
        Text(text, color = p.subtext, fontSize = 14.sp)
    }
}

@Composable
private fun NoticeStrip(text: String, action: String?, onAction: (() -> Unit)?) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(p.chip.copy(alpha = 0.7f))
            .padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = p.subtext, fontSize = 13.sp, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action,
                color = p.brand,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
internal fun ErrorBlock(text: String, onRetry: (() -> Unit)?) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text,
            color = p.text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
        if (onRetry != null) {
            Spacer(Modifier.height(14.dp))
            ActionButton("Повторить", ZiziIcons.Refresh, filled = false, onClick = onRetry)
        }
    }
}

private fun keyOf(item: RemoteItem): String = when (item) {
    is RemoteItem.Song -> item.track.trackId
    is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
}

private fun kindLabel(kind: RemoteKind): String = when (kind) {
    RemoteKind.TRACK -> "Трек"
    RemoteKind.ALBUM -> "Альбом"
    RemoteKind.PLAYLIST -> "Плейлист"
    RemoteKind.ARTIST -> "Артист"
}

// ------------------------------------------------------------------ недавние: перевод типов

/**
 * Строка «Недавнего» -> объект каталога.
 *
 * Обратное преобразование существует потому, что таблица `recents` намеренно ПЛОСКАЯ и не
 * ссылается на `tracks` внешним ключом. Причина ровно та же, по которой во всей базе нет
 * каскадов (см. MIGRATION_5_6): `upsertTracks` работает через REPLACE, то есть DELETE + INSERT,
 * и любая ссылка на трек умирала бы при каждом пересканировании и каждой чистке удалённого
 * кэша. Недавнее обязано пережить и то, и другое — человек ожидает увидеть вчерашний альбом,
 * даже если временная запись о его треках уже подметена sweepRemote.
 *
 * Плата за это — четыре поля, которых хватает, чтобы собрать объект обратно. Не «почти
 * трек», а именно тот же: trackId выводится из provider и remoteId по той же формуле
 * (`r:<provider>:<id>`), поэтому «плюс», галочка «сохранено» и подсветка играющего работают
 * без единого обращения к базе.
 */
private fun RecentEntity.asTrack(): RemoteTrack? {
    if (kind != RecentKind.TRACK) return null
    val provider = provider ?: return null
    val remote = remoteId ?: return null
    return RemoteTrack(
        provider = provider,
        remoteId = remote,
        title = title,
        artist = subtitle,
        durationMs = durationMs,
        artworkUrl = artworkUrl
    )
}

private fun RecentEntity.asCollection(): RemoteCollection? {
    val provider = provider ?: return null
    val remote = remoteId ?: return null
    val collectionKind = when (kind) {
        RecentKind.ALBUM -> RemoteKind.ALBUM
        RecentKind.PLAYLIST -> RemoteKind.PLAYLIST
        RecentKind.ARTIST -> RemoteKind.ARTIST
        else -> return null
    }
    return RemoteCollection(
        provider = provider,
        remoteId = remote,
        kind = collectionKind,
        title = title,
        subtitle = subtitle,
        artworkUrl = artworkUrl
    )
}

private fun recentKindLabel(kind: String): String = when (kind) {
    RecentKind.TRACK -> "Трек"
    RecentKind.ALBUM -> "Альбом"
    RecentKind.PLAYLIST -> "Плейлист"
    RecentKind.ARTIST -> "Артист"
    else -> "Запрос"
}

/**
 * Кнопка «обновить подборки» в шапке поиска (6.27.1).
 *
 * До этой версии она была честной кнопкой с нечестным поведением: `loadHub(force = true)` уходил в
 * сеть, а на экране не менялось НИЧЕГО — `hubLoading` по замыслу остаётся false, когда полки уже
 * нарисованы (крутилка вместо готового содержимого — это хуже, чем тихое обновление). Человек
 * нажимал, ничего не происходило, и вывод был очевидный: заглушка.
 *
 * Вращение сделано на [Animatable], а не на `rememberInfiniteTransition`, ровно из-за конца
 * анимации. Бесконечный переход умеет только «идёт» и «выключен»: обновление, которое завершилось
 * за 120 мс (провайдер ответил из своего кэша), обрубило бы знак на случайном угле — и это
 * читается как рывок, то есть как сбой, а не как готовность. Здесь оборот всегда доводится до
 * конца: пока идёт запрос — линейные обороты по 900 мс без единой остановки в крайних точках, по
 * завершении — доводка до ближайшего полного круга за 340 мс с замедлением. Минимальная
 * длительность отклика получается сама, без искусственной задержки: даже мгновенный ответ даёт
 * один аккуратный доведённый оборот.
 *
 * Пока идёт обновление, нажатие не проходит: второй `force` отменил бы первый запрос и начал бы
 * его заново — то есть наказал бы человека за нетерпение ожиданием подольше.
 */
@Composable
private fun HubRefreshButton(refreshing: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val angle = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) {
                angle.animateTo(angle.value + 360f, animationSpec = tween(900, easing = LinearEasing))
                // Угол сбрасывается в пределах круга, иначе за долгое обновление он вырастет до
                // величин, на которых float теряет точность и вращение начинает дёргаться.
                angle.snapTo(angle.value % 360f)
            }
        } else if (angle.value != 0f) {
            angle.animateTo(360f, animationSpec = tween(340, easing = FastOutSlowInEasing))
            angle.snapTo(0f)
        }
    }
    RoundIconButton(
        icon = ZiziIcons.Refresh,
        // Во время работы знак ярче: цвет тоже несёт состояние, а не только движение — это
        // единственный отклик, который останется человеку с включённым «убрать анимацию».
        tint = if (refreshing) p.brand else p.brand.copy(alpha = 0.9f),
        background = if (refreshing) p.brand.copy(alpha = 0.14f) else Color.Transparent,
        size = 42,
        iconSize = 23,
        onClick = { if (!refreshing) onClick() },
        modifier = Modifier.graphicsLayer { rotationZ = angle.value }
    )
}
