package app.ziziplayer.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import app.ziziplayer.privacy.VaultPullPolicy
import app.ziziplayer.ui.theme.LocalPalette

/** Pull only the scroll remainder at the top, including an empty LazyColumn.
 * Release, not a fling callback, commits the gesture. There is no header lock button.
 */
@Composable
fun VaultPullSurface(enabled: Boolean, unlocked: Boolean, onOpen: () -> Unit, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val threshold = with(density) { VaultPullPolicy.OPEN_DISTANCE_DP.dp.toPx() }
    val haptic = LocalHapticFeedback.current
    val openVaultAction by rememberUpdatedState(onOpen)
    val gesture = remember(enabled, threshold) { VaultPullPolicy(threshold) }
    var pull by remember(gesture) { mutableFloatStateOf(0f) }
    var dragging by remember(gesture) { mutableStateOf(false) }
    var hintStage by remember(gesture) { mutableIntStateOf(0) }
    var progress by remember(gesture) { mutableFloatStateOf(0f) }
    fun sync() {
        pull = gesture.distance; dragging = gesture.isDragging
        // Keep the released hint during collapse rather than flashing the initial prompt.
        if (dragging) { hintStage = gesture.hintStage; progress = gesture.progress }
    }
    val connection = remember(enabled, gesture) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.retract(available.y)
                sync()
                return Offset(0f, used)
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                val used = gesture.pull(available.y)
                sync()
                if (gesture.takeHaptic()) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                return Offset(0f, used)
            }
            override suspend fun onPreFling(available: Velocity): Velocity =
                if (gesture.consumeFling()) available else Velocity.Zero
        }
    }
    val height by animateFloatAsState(pull, tween(if (dragging) 0 else 200), label = "vault-pull")
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize().nestedScroll(connection).semantics {
        // TalkBack has the same action without adding a visible alternative entry point.
        if (enabled) customActions = listOf(CustomAccessibilityAction("Открыть скрытые папки") {
            openVaultAction.invoke(); true
        })
    }.pointerInput(enabled, gesture) {
        if (enabled) awaitEachGesture {
            var normalEnd = false
            try {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                gesture.begin(); sync()
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val pressed = event.changes.any { it.pressed }
                    if (!pressed) {
                        normalEnd = true
                        val shouldOpen = gesture.release()
                        sync()
                        if (shouldOpen) openVaultAction.invoke()
                    }
                } while (pressed)
            } finally {
                if (!normalEnd) { gesture.cancel(); sync() }
            }
        }
    }) {
        Box(Modifier.fillMaxWidth().height(with(density) { height.toDp() })
            .background(if (unlocked) p.brand else p.surface), contentAlignment = Alignment.Center) {
            if (height > threshold * 0.25f) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Crossfade(targetState = hintStage, animationSpec = tween(140), label = "vault-pull-hint") { stage ->
                    Text(when (stage) {
                        2 -> "Отпусти для открытия"
                        1 -> "Потяни ещё немного"
                        else -> "Потяни для скрытых папок"
                    }, color = if (unlocked) p.onBrand else p.text, fontSize = 13.sp, maxLines = 1)
                }
                if (height > threshold * 0.45f) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.width(64.dp).height(3.dp).clip(CircleShape)
                        .background((if (unlocked) p.onBrand else p.brand).copy(alpha = 0.15f))) {
                        Box(Modifier.fillMaxWidth(progress).fillMaxHeight().clip(CircleShape)
                            .background(if (unlocked) p.onBrand else p.brand))
                    }
                }
            }
        }
        Box(Modifier.weight(1f)) { content.invoke() }
    }
}
