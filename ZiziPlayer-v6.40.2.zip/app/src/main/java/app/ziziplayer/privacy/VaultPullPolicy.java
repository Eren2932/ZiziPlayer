package app.ziziplayer.privacy;

/** Platform-free gesture state; only the top-of-list nested-scroll remainder enters pull(). */
public final class VaultPullPolicy {
    public static final float OPEN_DISTANCE_DP = 96f;
    public static final float RESISTANCE = 0.55f;
    private final float threshold;
    private float distance;
    private boolean dragging, armed, buzzed, haptic, swallowFling;
    public VaultPullPolicy(float threshold) {
        if (!(threshold > 0f) || !Float.isFinite(threshold)) throw new IllegalArgumentException();
        this.threshold = threshold;
    }
    public float getDistance() { return distance; }
    public boolean isDragging() { return dragging; }
    public boolean isArmed() { return armed; }
    public int getHintStage() { return armed ? 2 : distance >= threshold * 0.625f ? 1 : 0; }
    public float getProgress() { return Math.min(1f, distance / threshold); }
    private void updateArmed() {
        if (!armed && distance >= threshold) {
            armed = true;
            if (!buzzed) { buzzed = true; haptic = true; }
        } else if (armed && distance < threshold * 0.875f) {
            // 12dp at the normal threshold: finger jitter must not flicker the hint.
            armed = false;
        }
    }
    public void begin() { cancel(); dragging = true; }
    public float pull(float remainder) {
        if (!dragging || remainder <= 0f || !Float.isFinite(remainder)) return 0f;
        distance = Math.min(threshold * 1.55f, distance + remainder * RESISTANCE);
        updateArmed();
        return remainder;
    }
    public float retract(float delta) {
        if (!dragging || distance <= 0f || delta >= 0f || !Float.isFinite(delta)) return 0f;
        float used = Math.max(delta, -distance / RESISTANCE);
        distance = Math.max(0f, distance + used * RESISTANCE);
        updateArmed();
        return used;
    }
    public boolean takeHaptic() { boolean value = haptic; haptic = false; return value; }
    public boolean release() {
        if (!dragging) return false;
        boolean open = armed;
        swallowFling = distance > 0f;
        distance = 0f; dragging = false; armed = false; buzzed = false; haptic = false;
        return open;
    }
    public boolean consumeFling() {
        // A child may enter onPreFling before/after the observer sees the final up event.
        boolean value = swallowFling || distance > 0f;
        swallowFling = false;
        return value;
    }
    public void cancel() { distance = 0f; dragging = false; armed = false; buzzed = false; haptic = false; swallowFling = false; }
}
