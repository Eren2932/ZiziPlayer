# Сервер 1.32-deephunt (поверх 1.31, клиент 7.5.6 / 7.5.7)

Что и зачем: `CHANGELOG_v7.5.7.md`. Меняются `zizi_catalog.py` и `zizi_match.py`; `zizi_versions.py` и остальные файлы не трогаются
(скип «уже актуален» для них нормален).

## Установка
```
cd <комплект>/server
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --check   # ожидается replace: zizi_catalog.py, zizi_match.py; остальное skip
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply
```
Успех: деплой пишет `Установлено: 1.32-deephunt`. Если пишет `1.30-fastplay`, код не обновился.
Проверка вручную (токен не нужен, путь открытый):
```
curl -s http://127.0.0.1:8080/catalog/health | jq '{version, anchor, deep_hunt, deep_budget, match_rules}'
```
Ожидается `1.32-deephunt`, `anchor 1`, `deep_hunt 1`, `deep_budget 12`.

## Что делать с «route_not_found» и портами
Каталог (`/match/deezer`, `/catalog/*`) живёт в `zizi-resolver`: `uvicorn zizi_resolver:app` на порту **8080**. Порты 8000, 8090, 8091 и 8092 — другие
процессы (чат, gunicorn, lyrics), на них `/match/deezer` не существует и отвечать там нечему. Домен `https://infrawat.ch/match/deezer` отдаёт 404
от Cloudflare с пустым телом: такого пути снаружи нет, настоящий префикс задаёт nginx. Проверять нужно только локально на 8080.

## Разбор трека (вместо ручного curl)
```
cd /opt/zizi
/opt/zizi/venv/bin/python tools/probe_match.py 1134333132
```
Скрипт сам берёт токен из `zizi.env` (не печатает), проверяет, что на порту именно zizi-resolver, печатает сводку (запросы охоты с движком, кандидаты с
причиной отказа, якорные, итог) и сохраняет весь ответ в `./match_explain.json`. `explain=1` не читает и не пишет кэши и ничего не меняет на сервере.
Коды выхода: 0 — разбор получен, 2 — нет соединения, 3 — на порту не zizi-resolver, 4 — отказ сервера (например 401).

## Откат
`ZIZI_DEEP_BUDGET=0` в `zizi.env` и перезапуск `zizi-resolver`: глубокая охота выключена, промахам верят любым (поведение 1.31).
Откат файлов: `deploy_server.py --rollback /opt/zizi/server-backups/<папка>`.
