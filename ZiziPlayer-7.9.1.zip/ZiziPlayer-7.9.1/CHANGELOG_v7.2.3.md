## 7.2.3 — 2026-10-25

Сборка 7.2.2 не собиралась: правка одного вызова, функциональность без изменений.

**Что сломалось.** `compileDebugKotlin` и `compileReleaseKotlin` упали в `ChatScreen.kt:494`: `AnimatedVisibility` счётчика жалоб
стоял в `Box`, а `Box` лежит в `Row` (шапка чата). Без квалификатора компилятор берёт перегрузку `RowScope.AnimatedVisibility`, а
DslMarker запрещает неявно звать получателя внешнего уровня при наличии внутреннего (`BoxScope`):
«cannot be called in this context with an implicit receiver», а следом три «@Composable invocations can only happen...» (500, 501, 502)
на содержимое лямбды. Это одна причина, а не четыре.

**Правка.** Вызов стал `androidx.compose.animation.AnimatedVisibility(...)` (top-level перегрузка), как уже сделано в `SharedUi.kt`
и `LibraryControls.kt`. Поведение, анимации и параметры те же.

**Защита.** `tools/check_scope_overload.py` (подключена в `check_static_refs.py`, шаг «Квалифицированные ссылки») находит
неквалифицированный `AnimatedVisibility` внутри `Box`/`BoxWithConstraints`, вложенного в `Row`/`Column` (и в функции с получателем
`RowScope`/`ColumnScope`). На 7.2.2 она даёт ровно одно срабатывание (`ChatScreen.kt:494`), на 7.2.3 ноль. Тесты:
`tools/test_scope_overload_7230.py`.

**Версия.** `versionCode 265`, `versionName 7.2.3` (CI берёт ZIP с наибольшим `versionCode`).

**Проверено:** `check_kotlin_syntax`, `check_imports`, `check_static_refs`, `check_package_shadow`, `check_call_args` (те же 88 прежних
эвристических замечаний, новых нет), `test_scope_overload_7230`, `test_chat_motion_7220`, `test_chat_staff_7200`, `test_chat_globe_7140`,
`test_ci_source`, `ChatLogicChecks` на JVM (15221 проверка). **Не проверено:** сам Kotlin-компилятор и Gradle (в среде нет Android SDK и
сети), поэтому подтверждение даст только CI. Android-проверка (эмулятор) не выполнялась.

