# Выкатка чата под 7.7.0 (делать ДО раздачи APK)

На VPS, из распакованного архива:
````bash
unzip -q ZiziPlayer-7.7.0.zip -d /tmp/zz && cd /tmp/zz/ZiziPlayer-7.7.0
sudo bash chat_server/deploy/update-zizi-chat.sh
````
Скрипт сам: прогонит 60 тестов сервера на копии (упали → сервер не тронут), положит релиз в `/opt/zizi-chat/<дата>`,
переключит `current`, перезапустит `zizi-chat`, дождётся `/health`. Не поднялся → **автоматический откат** на прежний релиз.
`chat.env`, база и systemd-юнит не меняются.

Проверка после:
````bash
curl -s http://127.0.0.1:8092/health                         # ok:true (порт = ZIZI_CHAT_PORT из chat.env)
grep -c "'fx': 1" /opt/zizi-chat/current/chatlib.py          # 1
````
Откат вручную (скрипт печатает точную команду): `sudo ln -sfn /opt/zizi-chat/<прежний> /opt/zizi-chat/current && sudo systemctl restart zizi-chat`

Совместимость: старые APK с новым сервером работают как раньше (поле `fx` им просто не приходит в их треках, а чужие
игнорируются). Новый APK со старым сервером рецепт не шлёт (нет `cfg.fx`), отправляет оригинал.
