# Zizi 7.5.2 (сборка 271): правка одного выражения в ChatMotion.kt

**Исходники, не APK.** Gradle в среде, где это писалось, не запускался. Kotlin прошёл в CI 7.5.1 до этой единственной ошибки, но
после неё сборка остановилась: дальше `testDebugUnitTest`, `assembleRelease` и подпись ещё не выполнялись.

## Что сломалось

Лог run (7.5.1), шаг `Kotlin compile and JVM tests`, `:app:compileDebugKotlin` и `:app:compileReleaseKotlin`:

    e: .../ui/screens/ChatMotion.kt:134:29 Unresolved reference 'using'.

Других `e:` в логе нет. Шаг ffmpeg из 7.5.1 отработал (apt поставил ffmpeg 6.1.1 за ~20 с), прежние 22 шага зелёные.

**Причина.** В `AccessorySwap` (7.5.0) было `(enter) togetherWith exit using SizeTransform(...)`. `togetherWith` — обычная функция верхнего уровня
с импортом, а `using` — инфикс-член `AnimatedContentTransitionScope`. Внутри `transitionSpec = { ... }` получатель-область есть, у нас значение
лежало top-level, поэтому `using` не находился. Это ровно тот вариант, который 7.5.0 перечислял как вероятное место ошибки («цепочка
`togetherWith ... using` в `ChatMotion.kt`»).

## Правка

    internal val AccessorySwap: ContentTransform = ContentTransform(
        targetContentEnter = fadeIn(...) + scaleIn(...),
        initialContentExit = fadeOut(tween(110)),
        sizeTransform = SizeTransform(clip = false) { _, _ -> tween(AccessoryMs, easing = FastOutSlowInEasing) }
    )

Конструктор `ContentTransform` публичный и от области не зависит. Анимация та же: вход, выход и кривая размера не менялись. Импорт `togetherWith`
убран как ненужный. `ChatScreen.kt` не менялся (`transitionSpec = { AccessorySwap }`).

## Защита

`tools/check_scope_member_infix.py` + `tools/test_scope_member_infix_7510.py`: инфикс `using` вне тела `transitionSpec` = ошибка. Подключено в
`check_static_refs.py`, то есть работает от ZIP без правки workflow. Проверено: на дереве 7.5.1 ровно одно срабатывание (`ChatMotion.kt:134`),
на этом ноль. `test_fast_scroll_7500.py` теперь требует `ContentTransform(` вместо `togetherWith`.

## Что НЕ менялось

Workflow, приложение, версии зависимостей. `versionCode` 270 -> 271, `versionName` 7.5.1 -> 7.5.2 (при равном versionCode workflow
падает с «Multiple ZIPs»). Корневой `build.yml` от 7.5.1 остаётся как есть, повторно заливать его не нужно.

## Где ещё может упасть

Kotlin в CI показал одну ошибку, но фронтенд-проверка и дальнейшие стадии разные: `FastScroller.kt` (400+ строк) прошёл разбор имён и типов,
а вот JVM-тесты (`testDebugUnitTest`) и кодогенерация впервые доберутся до 7.5.x только теперь.
