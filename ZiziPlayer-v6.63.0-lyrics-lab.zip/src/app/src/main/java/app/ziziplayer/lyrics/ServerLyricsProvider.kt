package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/** Only the operator-configured HTTPS endpoint; no audio, resolver tokens or cookies. */
internal class ServerLyricsProvider(base: String) : LyricsProvider {
    override val id = "ZiziLyrics"
    override val budgetMs = 6_000L
    private val endpoint: HttpUrl = base.toHttpUrl().also {
        require(it.isHttps && it.username.isEmpty() && it.password.isEmpty() && it.query == null && it.fragment == null) {
            "Lyrics server must be an HTTPS base URL without credentials/query/fragment"
        }
    }.newBuilder().addPathSegments("v1/lyrics").build()

    override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
        trace: LyricsLookupTrace?): JSONObject? {
        val url = endpoint.newBuilder().addQueryParameter("title", track.title)
            .addQueryParameter("artist", track.artist)
            .addQueryParameter("durationMs", track.durationMs.toString()).build()
        val root = JSONObject(http(Request.Builder().url(url).header("Accept", "application/json")
            .header("User-Agent", "ZiziPlayer/6.63.0-lyrics-lab").build()))
        if (root.optInt("schemaVersion", 0) != 1) throw IOException("Сервер текста: неизвестная схема")
        if (root.optString("status") == "miss" && root.isNull("document")) return null
        if (root.optString("status") != "found") throw IOException("Сервер текста: поиск не завершён")
        val doc = root.optJSONObject("document") ?: throw IOException("Сервер текста: нет документа")
        if (!LyricsMatchPolicy.identityMatches(track.title, track.artist, doc.optString("trackName"), doc.optString("artistName")))
            throw IOException("Сервер текста: другая запись")
        val seconds = doc.optDouble("duration", 0.0)
        if (!seconds.isFinite() || seconds <= 0 || seconds > 86400) throw IOException("Сервер текста: неверная длительность")
        val duration = (seconds * 1000).toLong()
        if (!LyricsMatchPolicy.textDurationMatches(track.durationMs, duration)) return null
        val plain = LyricsFallbackText.clean(doc.opt("plainLyrics") as? String)
            ?: throw IOException("Сервер текста: пустой текст")
        val rawSync = doc.opt("syncedLyrics") as? String ?: ""
        val lines = LrcTimeline.parse(rawSync)
        val syncAllowed = doc.optString("timingProvenance") == "provider_lrc" &&
            lines.size >= 2 && LrcTimeline.durationMatches(track.durationMs, duration) &&
            lines.all { it.timeMs <= duration + 2000 && it.words.all { w -> w.timeMs <= duration + 2000 } }
        val source = when (doc.optString("source")) {
            "NetEase" -> "NetEase · ZiziLyrics"
            "Official description" -> "Описание артиста · ZiziLyrics"
            else -> throw IOException("Сервер текста: неизвестный источник")
        }
        trace?.add("ZiziLyrics: validated; synchronized=$syncAllowed")
        // Strict reserialization: do not trust arbitrary flags, HTML, instrumental or future fields.
        return JSONObject().put("trackName", doc.getString("trackName")).put("artistName", doc.getString("artistName"))
            .put("source", source).put("plainLyrics", plain).put("syncedLyrics", if (syncAllowed) rawSync else "")
            .put("duration", seconds).put("instrumental", false).put("matchVerified", true)
    }
}
