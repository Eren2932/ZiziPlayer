package app.ziziplayer.ui

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.MusicRepository
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteCatalog
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.SearchPage
import app.ziziplayer.data.remote.providerLabel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Which of the three faces of the section is showing.
 *
 * Three, not two, and not one screen with flags. The reference player has exactly this shape and
 * the reason is not aesthetic: the hub is a browsing surface with vertical shelves, the suggestion
 * list is a keyboard-driven surface that must never move under the finger, and the result list is a
 * paged surface. Collapsing them into "search screen with a query or without one" is how you end up
 * with a hub that reflows while the user types.
 */
enum class SearchStage { HUB, SUGGEST, RESULTS }

/**
 * The result tabs, and the provider filter each one maps to.
 *
 * [ALL] deliberately sends no filter at all rather than merging four filtered calls: one unfiltered
 * request is one round trip and it returns the provider's own idea of relevance, which is better
 * than anything we could re-rank client side.
 */
enum class SearchTab(val label: String, val kind: RemoteKind?) {
    ALL("Все", null),
    TRACKS("Треки", RemoteKind.TRACK),
    ALBUMS("Альбомы", RemoteKind.ALBUM),
    PLAYLISTS("Плейлисты", RemoteKind.PLAYLIST),
    ARTISTS("Артисты", RemoteKind.ARTIST)
}

/**
 * One tab's worth of results.
 *
 * [appending] is separate from [loading] because they draw differently and confusing them is a
 * visible bug: a first load replaces the list with a spinner, a page append must leave the list
 * exactly where it is and put the spinner at the bottom. One boolean cannot express both.
 */
@Immutable
data class TabResults(
    val items: List<RemoteItem> = emptyList(),
    val nextToken: String? = null,
    val loading: Boolean = false,
    val appending: Boolean = false,
    val error: String? = null,
    /** Which catalogue actually answered - not which one was asked. */
    val provider: String? = null
) {
    val isEmpty: Boolean get() = items.isEmpty() && !loading && error == null
    val canLoadMore: Boolean get() = nextToken != null && !loading && !appending && error == null
}

/** An album / playlist / artist opened out into its tracks. */
@Immutable
data class OpenCollection(
    val collection: RemoteCollection,
    val tracks: List<RemoteTrack> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null
)

@Immutable
data class SearchUiState(
    val stage: SearchStage = SearchStage.HUB,
    /** What is in the text field right now. Not the same thing as [query]. */
    val field: String = "",
    /** The last query that was actually submitted. Results belong to this, not to the field. */
    val query: String = "",
    val tab: SearchTab = SearchTab.ALL,
    val suggestions: List<String> = emptyList(),
    val history: List<String> = emptyList(),
    val shelves: List<DiscoverShelf> = emptyList(),
    val hubLoading: Boolean = false,
    val hubError: String? = null,
    /**
     * Results per tab, kept for the lifetime of one query.
     *
     * Tabs are a filter over the same query, so the fetched pages stay valid while the query does.
     * Re-requesting on every tab tap would cost a round trip and - worse - lose the scroll position
     * and every page the user had already loaded. Switching back to a tab you were on must show it
     * as you left it.
     */
    val results: Map<SearchTab, TabResults> = emptyMap(),
    val collection: OpenCollection? = null
) {
    val current: TabResults get() = results[tab] ?: TabResults()
}

/**
 * Everything the "Поиск" section does, kept out of [MainViewModel] on purpose.
 *
 * The library view model owns a 3000 row pipeline that recombines on every keystroke of the LOCAL
 * search. Hanging network paging, suggestion debouncing and per-tab caches off the same object
 * would put two unrelated failure domains in one place: a broken catalogue would recompose the
 * library, and a rescan would recompose the results. They share the repository and nothing else.
 */
class SearchViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: MusicRepository = (application as ZiziApplication).repository

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    /** Ids of remote tracks the user chose to keep. Drives the "+" / "✓" on every result row. */
    val savedIds: StateFlow<Set<String>> = repo.tracks
        .map { tracks -> tracks.asSequence().filter { it.isRemote }.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private var suggestJob: Job? = null
    private var pageJob: Job? = null
    private var hubJob: Job? = null
    private var collectionJob: Job? = null

    init {
        viewModelScope.launch {
            repo.searchHistory.collect { entries ->
                _state.value = _state.value.copy(history = entries.map { it.query })
            }
        }
        loadHub()
    }

    // ---------------------------------------------------------------- the hub

    fun loadHub(force: Boolean = false) {
        val current = _state.value
        if (!force && current.shelves.isNotEmpty()) return
        hubJob?.cancel()
        _state.value = current.copy(hubLoading = true, hubError = null)
        hubJob = viewModelScope.launch {
            try {
                val preferred = repo.settings.first().catalogProvider
                val shelves = repo.catalogs.withFallback(preferred) { it.discover() }
                _state.value = _state.value.copy(
                    shelves = shelves.filter { it.items.isNotEmpty() },
                    hubLoading = false,
                    hubError = null
                )
            } catch (e: CatalogException) {
                // The hub failing is not the section failing. Search still works with no shelves at
                // all, so this is reported as a dismissible strip and never as an empty screen.
                _state.value = _state.value.copy(hubLoading = false, hubError = explain(e))
            }
        }
    }

    // ---------------------------------------------------------------- typing

    fun onField(text: String) {
        val trimmed = text.trimStart()
        val stage = when {
            trimmed.isBlank() -> SearchStage.HUB
            else -> SearchStage.SUGGEST
        }
        _state.value = _state.value.copy(
            field = text,
            stage = stage,
            suggestions = if (trimmed.isBlank()) emptyList() else _state.value.suggestions
        )
        suggestJob?.cancel()
        if (trimmed.length < 2) return
        suggestJob = viewModelScope.launch {
            // 220 ms. Below ~150 ms a normal typing speed fires a request per character and the
            // provider starts rate limiting; above ~300 ms the list visibly lags the keyboard.
            delay(220)
            val preferred = repo.settings.first().catalogProvider
            val fetched = runCatching {
                repo.catalogs.withFallback(preferred) { it.suggest(trimmed) }
            }.getOrDefault(emptyList())
            // Suggestions are a convenience: a failure here is silence, never an error banner.
            if (_state.value.field.trimStart() == trimmed) {
                _state.value = _state.value.copy(suggestions = fetched)
            }
        }
    }

    fun clearField() {
        suggestJob?.cancel()
        _state.value = _state.value.copy(field = "", stage = SearchStage.HUB, suggestions = emptyList())
    }

    /** Re-opens the suggestion surface when the field is tapped with text already in it. */
    fun onFieldFocused() {
        val current = _state.value
        if (current.stage == SearchStage.RESULTS && current.field.isNotBlank()) {
            _state.value = current.copy(stage = SearchStage.SUGGEST)
        }
    }

    // ---------------------------------------------------------------- searching

    fun submit(raw: String) {
        val query = raw.trim()
        if (query.isEmpty()) return
        suggestJob?.cancel()
        _state.value = _state.value.copy(
            field = query,
            query = query,
            stage = SearchStage.RESULTS,
            tab = SearchTab.ALL,
            suggestions = emptyList(),
            // Every tab's cache belongs to the previous query and every entry in it is now wrong.
            results = emptyMap(),
            collection = null
        )
        viewModelScope.launch { repo.rememberQuery(query) }
        fetch(SearchTab.ALL, append = false)
    }

    fun setTab(tab: SearchTab) {
        val current = _state.value
        if (current.tab == tab) return
        _state.value = current.copy(tab = tab)
        if (current.results[tab] == null) fetch(tab, append = false)
    }

    fun loadMore() {
        val current = _state.value
        if (!current.current.canLoadMore) return
        fetch(current.tab, append = true)
    }

    fun retry() = fetch(_state.value.tab, append = false)

    private fun fetch(tab: SearchTab, append: Boolean) {
        val query = _state.value.query
        if (query.isBlank()) return
        val existing = _state.value.results[tab] ?: TabResults()
        val token = if (append) existing.nextToken else null
        if (append && token == null) return

        // One page request at a time across the whole section. A tab switch mid-load must abandon
        // the old request: letting it finish would write a page of the wrong tab into the state.
        pageJob?.cancel()
        update(tab) {
            it.copy(
                loading = !append,
                appending = append,
                error = null,
                items = if (append) it.items else emptyList()
            )
        }
        pageJob = viewModelScope.launch {
            try {
                val preferred = repo.settings.first().catalogProvider
                var answered: RemoteCatalog? = null
                val page: SearchPage = repo.catalogs.withFallback(preferred) { catalog ->
                    answered = catalog
                    catalog.search(query, tab.kind, token)
                }
                // The catalogue may legitimately return the same row twice across two pages
                // (continuations overlap on shelf boundaries). De-duplicating on append rather
                // than trusting the provider keeps the LazyColumn keys unique, which is otherwise
                // a crash and not a cosmetic problem.
                val merged = if (append) dedupe(existing.items + page.items) else dedupe(page.items)
                update(tab) {
                    it.copy(
                        items = merged,
                        // A token that returns nothing is a token that will keep returning
                        // nothing; treat it as the end of the list instead of an infinite footer.
                        nextToken = page.nextToken?.takeIf { page.items.isNotEmpty() },
                        loading = false,
                        appending = false,
                        error = null,
                        provider = answered?.id
                    )
                }
                // Remote rows are written to the database as soon as they are seen, not when they
                // are played: the mini player, the queue and the play counters all resolve by id,
                // and a row that does not exist yet cannot be favourited or queued. Unsaved rows
                // are swept later - see MusicRepository.sweepRemote.
                val songs = page.items.filterIsInstance<RemoteItem.Song>().map { it.track }
                if (songs.isNotEmpty()) repo.rememberRemote(songs)
            } catch (e: CatalogException) {
                update(tab) { it.copy(loading = false, appending = false, error = explain(e)) }
            }
        }
    }

    private fun dedupe(items: List<RemoteItem>): List<RemoteItem> {
        val seen = HashSet<String>(items.size * 2)
        return items.filter { item ->
            val key = when (item) {
                is RemoteItem.Song -> item.track.trackId
                is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
            }
            seen.add(key)
        }
    }

    private inline fun update(tab: SearchTab, block: (TabResults) -> TabResults) {
        val current = _state.value
        val updated = block(current.results[tab] ?: TabResults())
        _state.value = current.copy(results = current.results + (tab to updated))
    }

    // ---------------------------------------------------------------- collections

    fun openCollection(collection: RemoteCollection) {
        collectionJob?.cancel()
        _state.value = _state.value.copy(collection = OpenCollection(collection))
        collectionJob = viewModelScope.launch {
            try {
                val catalog = repo.catalogs.byId(collection.provider)
                    ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник недоступен")
                val tracks = catalog.collection(collection)
                if (tracks.isNotEmpty()) repo.rememberRemote(tracks)
                // Guarded, and the guard is not paranoia: the user can close this sheet and open
                // another one while the request is in flight. Writing the answer unconditionally
                // would either resurrect a closed sheet or overwrite the new one's contents with
                // the old one's tracks.
                applyToOpen(collection) { it.copy(tracks = tracks, loading = false) }
            } catch (e: CatalogException) {
                applyToOpen(collection) { it.copy(loading = false, error = explain(e)) }
            }
        }
    }

    private inline fun applyToOpen(target: RemoteCollection, block: (OpenCollection) -> OpenCollection) {
        val current = _state.value
        val open = current.collection ?: return
        if (open.collection != target) return
        _state.value = current.copy(collection = block(open))
    }

    fun closeCollection() {
        collectionJob?.cancel()
        _state.value = _state.value.copy(collection = null)
    }

    // ---------------------------------------------------------------- history

    fun forgetQuery(query: String) { viewModelScope.launch { repo.forgetQuery(query) } }
    fun clearHistory() { viewModelScope.launch { repo.clearSearchHistory() } }

    /**
     * One back step inside the section, or false to let the app handle it.
     *
     * Collection -> results -> hub. The query survives going back to the hub, in the field, because
     * "back" after a search almost always means "let me change one word", not "forget what I typed".
     */
    fun back(): Boolean {
        val current = _state.value
        return when {
            current.collection != null -> { closeCollection(); true }
            current.stage == SearchStage.SUGGEST -> {
                _state.value = current.copy(
                    stage = if (current.query.isBlank()) SearchStage.HUB else SearchStage.RESULTS
                )
                true
            }
            current.stage == SearchStage.RESULTS -> {
                _state.value = current.copy(stage = SearchStage.HUB)
                true
            }
            else -> false
        }
    }

    private fun explain(e: CatalogException): String = when (e.reason) {
        CatalogException.Reason.OFFLINE -> "Нет соединения"
        CatalogException.Reason.RATE_LIMITED -> "Источник просит подождать. Попробуй через минуту"
        CatalogException.Reason.METERED_BLOCKED -> "Включено «только Wi-Fi»"
        CatalogException.Reason.UNAVAILABLE -> e.message ?: "Недоступно"
        // Deliberately verbatim. A protocol error means the provider changed its answers and this
        // app is the broken side; hiding that behind "что-то пошло не так" is how a two line fix
        // turns into an evening of guessing.
        CatalogException.Reason.PROTOCOL -> e.message ?: "Источник ответил неожиданно"
    }

    fun providerName(id: String?): String = id?.let { providerLabel(it) } ?: ""
}
