package app.ziziplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.SearchViewModel
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ArtworkPrefetcher
import app.ziziplayer.ui.components.rememberArtSwatches
import app.ziziplayer.ui.components.ZiziTab
import app.ziziplayer.ui.components.ZiziTabBar
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.MiniPlayer
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.screens.SearchScreen
import app.ziziplayer.ui.theme.BackdropBlend
import app.ziziplayer.ui.theme.LocalBackdropBlend
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziBackdrop
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private val searchVm: SearchViewModel by viewModels()

    private var deleteTarget: TrackEntity? = null
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ArtworkCache.attach(this)

        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { vm.addFolder(it) }
        }
        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = deleteTarget
            deleteTarget = null
            if (result.resultCode == RESULT_OK && target != null) vm.onFileDeleted(target)
        }
        val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) vm.rescan()
        }
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        }

        setContent {
            ZiziApp(
                vm = vm,
                searchVm = searchVm,
                onPickFolder = { folderLauncher.launch(null) },
                onShare = ::shareTrack,
                onDeleteFile = ::deleteTrackFile,
                onExit = { finish() }
            )
        }
    }

    /** No position polling and no artwork work at all while the UI is off screen. */
    override fun onStart() {
        super.onStart()
        vm.setUiActive(true)
        // The composition survives backgrounding, so cover indexing has to be woken up by hand.
        ArtworkPrefetcher.resume()
    }

    override fun onStop() {
        vm.setUiActive(false)
        vm.savePosition()
        // Nothing may keep parsing audio files once the UI is gone.
        ArtworkPrefetcher.stop()
        ArtworkCache.flushIndex()
        super.onStop()
    }

    private fun shareTrack(track: TrackEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(track.uri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, track.title)) }
    }

    private fun deleteTrackFile(track: TrackEntity) {
        vm.requestDeleteFile(track) { sender ->
            if (sender == null) return@requestDeleteFile
            deleteTarget = track
            runCatching { deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
        }
    }
}

@Composable
private fun ZiziApp(
    vm: MainViewModel,
    searchVm: SearchViewModel,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit,
    onExit: () -> Unit
) {
    val library by vm.library.collectAsStateWithLifecycle()
    val playback by vm.playback.collectAsStateWithLifecycle()
    val current by vm.currentTrack.collectAsStateWithLifecycle()
    val search by searchVm.state.collectAsStateWithLifecycle()
    val savedRemoteIds by searchVm.savedIds.collectAsStateWithLifecycle()

    /**
     * The artists the hub offers as starting points.
     *
     * Local rows only, most-frequent first, and recomputed only when the library's SIZE changes -
     * not on every emission. The list flow re-emits on a favourite toggle and on every play count
     * bump, and grouping 3000 rows on the main thread each time would be a stutter you could feel
     * in the tab bar. Sixteen names is two screens of tiles; nobody scrolls further for a seed.
     */
    val seeds = remember(library.tracks.size) {
        library.tracks.asSequence()
            .filter { !it.isRemote }
            .map { it.artist.trim() }
            .filter { it.isNotEmpty() && !it.equals("<unknown>", ignoreCase = true) }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(16)
            .map { it.key }
    }

    // Three cover shades drive the whole app: one hue, one chroma level, one brightness. They
    // only change when the track changes.
    val swatches = rememberArtSwatches(current, library.settings.accentFromArtwork)
    val palette = remember(library.settings.theme, swatches) {
        basePalette(library.settings.theme).tintedWith(swatches).withAccent(swatches)
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(vm) {
        vm.messages.collect { message ->
            val result = snackbar.showSnackbar(
                message = message.text,
                actionLabel = message.actionLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) message.action?.invoke()
        }
    }

    // One blend per process, shared by both backdrops: the library's and the player's ramps stay
    // on the same colour, so sliding the player down never crosses a seam.
    val blend = remember { BackdropBlend() }

    CompositionLocalProvider(LocalPalette provides palette, LocalBackdropBlend provides blend) {
        ZiziTheme(palette) {
            var playerOpen by remember { mutableStateOf(false) }
            // Saveable: a rotation or a process death that lands the user back on the library
            // after they had opened search is a small betrayal, and it costs one Parcelable int.
            var tab by rememberSaveable { mutableStateOf(ZiziTab.LIBRARY) }
            var screenHeight by remember { mutableFloatStateOf(0f) }
            val slide = remember { Animatable(0f) }
            var mounted by remember { mutableStateOf(false) }
            // Read inside the draw phase only, so toggling it costs no recomposition.
            val libraryDrawn = remember { mutableStateOf(true) }

            LaunchedEffect(playerOpen, screenHeight) {
                if (screenHeight <= 0f) return@LaunchedEffect
                if (playerOpen) {
                    if (!mounted) { slide.snapTo(screenHeight); mounted = true }
                    libraryDrawn.value = true
                    slide.animateTo(0f, spring(dampingRatio = 0.88f, stiffness = Spring.StiffnessMediumLow))
                    // Fully covered: stop drawing the library underneath.
                    if (slide.value == 0f) libraryDrawn.value = false
                } else if (mounted) {
                    libraryDrawn.value = true
                    slide.animateTo(screenHeight, tween(210, easing = FastOutLinearInEasing))
                    mounted = false
                }
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { screenHeight = it.height.toFloat() }
            ) {
                // No wash, no halo: the crest at y = 0.20 carries the cover's colour on its own.
                ZiziBackdrop(palette)

                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent { if (libraryDrawn.value) drawContent() }
                ) {
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f)) {
                            // Both destinations stay in the composition; only one is shown.
                            //
                            // A `when` that swaps them would throw away the library's scroll
                            // position, its drill-down and its cover cache every time the user
                            // glances at search - and would restart the hub request every time
                            // they come back. Keeping both alive costs two LazyLists worth of
                            // state and buys instant, lossless tab switching.
                            if (tab == ZiziTab.LIBRARY) {
                                LibraryScreen(
                                    vm = vm,
                                    state = library,
                                    playback = playback,
                                    currentTrack = current,
                                    onOpenPlayer = { playerOpen = true },
                                    onPickFolder = onPickFolder,
                                    onShare = onShare,
                                    onDeleteFile = onDeleteFile
                                )
                            } else {
                                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                                    SearchScreen(
                                        vm = vm,
                                        search = searchVm,
                                        state = search,
                                        savedIds = savedRemoteIds,
                                        currentTrackId = playback.currentTrackId,
                                        isPlaying = playback.isPlaying,
                                        seeds = seeds
                                    )
                                }
                            }
                        }

                        current?.let { track ->
                            MiniPlayer(
                                vm = vm,
                                track = track,
                                isPlaying = playback.isPlaying,
                                onOpen = { playerOpen = true }
                            )
                        }
                        ZiziTabBar(current = tab, onPick = { tab = it })
                        Spacer(Modifier.navigationBarsPadding())
                    }
                }

                if (mounted) {
                    val dragState = rememberDraggableState { delta ->
                        scope.launch { slide.snapTo((slide.value + delta).coerceIn(0f, screenHeight)) }
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer { translationY = slide.value }
                            .draggable(
                                state = dragState,
                                orientation = Orientation.Vertical,
                                onDragStarted = { libraryDrawn.value = true },
                                onDragStopped = { velocity ->
                                    val shouldClose = slide.value > screenHeight * 0.16f || velocity > 1400f
                                    if (shouldClose) playerOpen = false
                                    else {
                                        slide.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium))
                                        if (slide.value == 0f) libraryDrawn.value = false
                                    }
                                }
                            )
                    ) {
                        ZiziBackdrop(palette)
                        PlayerScreen(
                            vm = vm,
                            state = library,
                            playback = playback,
                            currentTrack = current,
                            onClose = { playerOpen = false },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    }
                }

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 84.dp)
                )
            }

            // Single back path: player -> drill-down -> app exit. The system side swipe follows it too.
            BackHandler(enabled = true) {
                when {
                    playerOpen -> playerOpen = false
                    // Inside search, back unwinds the section's own stack first (collection ->
                    // results -> hub) and only then leaves the tab. Dropping straight to the
                    // library from a result list is the behaviour every user reads as a bug.
                    tab == ZiziTab.SEARCH && searchVm.back() -> Unit
                    tab == ZiziTab.SEARCH -> tab = ZiziTab.LIBRARY
                    vm.handleBack() -> Unit
                    else -> onExit()
                }
            }
        }
    }
}
