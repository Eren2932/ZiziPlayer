package app.ziziplayer.data.remote

import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * The one HTTP client in the process.
 *
 * It is shared with Media3 (`OkHttpDataSource.Factory(ZiziHttp.client)`) on purpose: one connection
 * pool, one DNS cache, one TLS session cache. A second client would mean a second full TCP+TLS
 * handshake for the audio stream right after the search request just finished talking to the same
 * host - which is exactly the "first second of playback stutters" case.
 *
 * `followRedirects` stays on: Audius answers a stream request with a 302 to a storage node, and
 * Media3 must follow it without us pre-resolving anything.
 */
object ZiziHttp {

    /** A plain mobile browser UA. No fingerprinting games, no impersonating an app we are not. */
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val json = "application/json; charset=utf-8".toMediaType()

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            // Last word on identity and session payload. Media3 shares this client, therefore the
            // same policy is enforced for catalogue JSON, artwork and stream requests.
            .addInterceptor(SessionHeadersInterceptor())
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            // Audio is a long lived read; a pool that closes idle connections too eagerly makes
            // every track change pay for a new handshake.
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    suspend fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody(json))
                .header("User-Agent", USER_AGENT)
                .header("Content-Type", "application/json")
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    suspend fun getJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .get()
                .header("User-Agent", USER_AGENT)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    /**
     * Two bytes of the real stream, and what the server said about them.
     *
     * This exists because of a class of failure that is invisible from the API layer: the catalogue
     * answers, the parse succeeds, a URL comes out - and the GET of that URL is refused. From
     * inside the app that looks exactly like a track that "just skips". A one-byte ranged request
     * with the right agent settles it in 200 ms and reports the code, which is the difference
     * between guessing and knowing.
     *
     * Never used on the playback path. It is a diagnostic, called only from settings.
     */
    suspend fun probeStream(url: String, userAgent: String?): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", userAgent ?: USER_AGENT)
            .header("Range", "bytes=0-1")
            .build()
        try {
            client.newCall(request).execute().use { r ->
                val type = r.header("Content-Type") ?: "?"
                val length = r.header("Content-Range") ?: r.header("Content-Length") ?: "?"
                if (r.isSuccessful) "HTTP ${r.code} · $type · $length"
                else "HTTP ${r.code} · отказ · $type"
            }
        } catch (e: IOException) {
            "нет ответа: ${e.javaClass.simpleName}"
        }
    }

    /**
     * The same two bytes as [probeStream], but as a bare HTTP code, and ON the playback path.
     *
     * This is what turns "resolve succeeded" into "the CDN will actually serve this": the catalogue
     * calls it before handing a URL back, and a refusal makes it try the next internal client
     * instead of handing the player a dead address to auto-skip over. Its own timeouts, short ones -
     * a probe that hangs for twenty seconds would be worse than no probe at all, because the user is
     * staring at a track that is supposedly starting.
     *
     * Returns null when there was no answer at all, which the caller treats exactly like a refusal.
     */
    private val probeClient: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()
    }

    suspend fun statusOf(url: String, userAgent: String?): Int? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", userAgent ?: USER_AGENT)
            .header("Range", "bytes=0-1")
            .build()
        try {
            probeClient.newCall(request).execute().use { r -> r.code }
        } catch (e: IOException) {
            null
        }
    }

    /**
     * Cover bytes. Blocking on purpose: the only caller is the artwork pipeline, which is already
     * on a gated IO dispatcher and already owns a permit, and handing it a suspending call would
     * mean a second dispatch per tile.
     */
    fun fetchBytes(url: String, limitBytes: Int = 1_500_000): ByteArray? {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", USER_AGENT)
            .build()
        return try {
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return null
                val body = r.body ?: return null
                if ((r.header("Content-Length")?.toLongOrNull() ?: 0L) > limitBytes) return null
                // Read by hand rather than with InputStream.readNBytes: that method is API 33,
                // this app supports API 26, and the lint for it is not enforced on a call inside
                // a runCatching-style block - it would have shipped and crashed on half the
                // install base.
                val out = java.io.ByteArrayOutputStream(64 * 1024)
                val buffer = ByteArray(16 * 1024)
                body.byteStream().use { input ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        if (out.size() > limitBytes) return null
                    }
                }
                out.toByteArray()
            }
        } catch (e: IOException) {
            null
        }
    }

    /**
     * Turns transport reality into [CatalogException].
     *
     * Every branch here exists because the UI has to do something different: 429 must back off,
     * 403/404 on a single track must skip it, a DNS failure must not be reported as "провайдер
     * сломался", and a 200 that is not JSON means the shape changed and that is our bug.
     */
    private fun execute(call: Call, url: String): JSONObject {
        val response = try {
            call.execute()
        } catch (e: UnknownHostException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Нет соединения", e)
        } catch (e: SocketTimeoutException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Сервер не отвечает", e)
        } catch (e: IOException) {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Сеть недоступна", e)
        }
        response.use { r ->
            val code = r.code
            if (code == 429) throw CatalogException(CatalogException.Reason.RATE_LIMITED, "Слишком много запросов")
            if (code == 403 || code == 404 || code == 410) {
                throw CatalogException(CatalogException.Reason.UNAVAILABLE, "Недоступно ($code)")
            }
            if (!r.isSuccessful) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "HTTP $code от ${host(url)}")
            }
            val text = try {
                r.body?.string()
            } catch (e: IOException) {
                throw CatalogException(CatalogException.Reason.OFFLINE, "Обрыв ответа", e)
            }
            if (text.isNullOrBlank()) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "Пустой ответ от ${host(url)}")
            }
            return try {
                JSONObject(text)
            } catch (e: Throwable) {
                throw CatalogException(
                    CatalogException.Reason.PROTOCOL,
                    "Ответ ${host(url)} не JSON (${text.length} байт)",
                    e
                )
            }
        }
    }

    private fun host(url: String): String = runCatching { java.net.URL(url).host }.getOrDefault(url)
}
