package app.ziziplayer.playback

/**
 * Состояние офлайн-копии одного трека.
 *
 * Живёт в отдельном файле и БЕЗ @UnstableApi намеренно: на него смотрит UI, а таскать
 * media3-optin через весь Compose-слой ради одного sealed-типа — плохая сделка.
 */
sealed interface DownloadStatus {
    /** Локальный файл: он и так на устройстве, качать нечего. */
    data object Local : DownloadStatus
    /** Сетевой трек, копии нет. */
    data object None : DownloadStatus
    /** Качается прямо сейчас. [percent] = -1, когда сервер не отдал длину. */
    data class Running(val percent: Int) : DownloadStatus
    /** Скачан целиком, играет без сети. */
    data object Done : DownloadStatus
    /** Сорвалось. Текст короткий — он идёт второй строкой в меню. */
    data class Failed(val message: String) : DownloadStatus
}
