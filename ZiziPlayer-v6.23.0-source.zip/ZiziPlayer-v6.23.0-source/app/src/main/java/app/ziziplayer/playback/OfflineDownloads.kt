package app.ziziplayer.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.ContentMetadata
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Скачивание трека целиком.
 *
 * Ни одного нового сетевого пути здесь нет, и это главное решение: [CacheWriter] тянет байты
 * через ТУ ЖЕ цепочку, что и плеер — резолвер `zizi://` → OkHttp каталога. Значит загрузка
 * автоматически получает поворот клиентов, прокси, повтор на 403 и свежий адрес взамен протухшего,
 * без единой строчки дубликата. Отдельный «загрузчик по URL» пришлось бы чинить дважды.
 *
 * Состояния БЕЗ таблицы в Room, тоже намеренно: правда о том, скачан ли трек, лежит в самом кэше
 * (длина контента в метаданных против числа закэшированных байт). База дала бы второй источник
 * истины, который рано или поздно разойдётся с диском — и пользователь увидит «скачано» там, где
 * файла нет.
 *
 * Ограничение первой версии, честно: загрузка живёт в процессе приложения. Свернуть можно, убить
 * приложение — нельзя, докачается при следующем запуске (CacheWriter возобновляется с места).
 * Foreground-сервис для пачки треков — следующий шаг.
 */
@UnstableApi
object OfflineDownloads {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()

    /**
     * Живые [CacheWriter]-ы.
     *
     * Отдельно от [jobs], и это не дублирование: `CacheWriter.cache()` — блокирующее копирование,
     * отмена корутины его НЕ прерывает, поток продолжал бы качать трек в фоне до конца. Остановить
     * его может только собственный `cancel()` писателя.
     */
    private val writers = ConcurrentHashMap<String, CacheWriter>()

    private val _states = MutableStateFlow<Map<String, DownloadStatus>>(emptyMap())
    /** Только «живые» состояния: качается / только что упало. Всё остальное читается с диска. */
    val states: StateFlow<Map<String, DownloadStatus>> = _states

    private fun keyOf(track: TrackEntity): String = track.uri

    /** Дёшево и синхронно: пара обращений к индексу кэша, без диска. */
    fun statusOf(context: Context, track: TrackEntity): DownloadStatus {
        if (!RemoteUri.isRemote(track.uri)) return DownloadStatus.Local
        _states.value[track.id]?.let { return it }
        return if (isComplete(context, track)) DownloadStatus.Done else DownloadStatus.None
    }

    fun isComplete(context: Context, track: TrackEntity): Boolean {
        if (!RemoteUri.isRemote(track.uri)) return false
        return runCatching {
            val cache = OfflineCache.get(context)
            val key = keyOf(track)
            val length = ContentMetadata.getContentLength(cache.getContentMetadata(key))
            length > 0L && cache.getCachedBytes(key, 0L, length) >= length
        }.getOrDefault(false)
    }

    fun start(context: Context, track: TrackEntity) {
        if (!RemoteUri.isRemote(track.uri)) return
        if (jobs.containsKey(track.id)) return
        if (isComplete(context, track)) { publish(track.id, DownloadStatus.Done); return }

        publish(track.id, DownloadStatus.Running(0))
        val app = context.applicationContext
        val job = scope.launch {
            val result = runCatching {
                val source = CacheDataSource.Factory()
                    .setCache(OfflineCache.get(app))
                    // Апстрим — резолвер, а не голый HTTP: адрес добывается в момент чтения.
                    .setUpstreamDataSourceFactory(ZiziDataSources.resolvingFactory(app))
                    .createDataSource()
                val spec = DataSpec.Builder()
                    .setUri(Uri.parse(track.uri))
                    .setFlags(DataSpec.FLAG_ALLOW_CACHE_FRAGMENTATION)
                    .build()
                val writer = CacheWriter(source, spec, null) { requestLength, bytesCached, _ ->
                    val percent = if (requestLength > 0L) {
                        ((bytesCached * 100L) / requestLength).toInt().coerceIn(0, 100)
                    } else -1
                    publish(track.id, DownloadStatus.Running(percent))
                }
                writers[track.id] = writer
                try { writer.cache() } finally { writers.remove(track.id) }
            }
            jobs.remove(track.id)
            result.fold(
                onSuccess = { publish(track.id, DownloadStatus.Done) },
                onFailure = { error ->
                    // Отмена — не ошибка: пользователь сам нажал.
                    if (error is kotlinx.coroutines.CancellationException) clear(track.id)
                    else publish(track.id, DownloadStatus.Failed(shortReason(error)))
                }
            )
        }
        jobs[track.id] = job
    }

    fun cancel(trackId: String) {
        // Порядок важен: сначала писатель (он выйдет из блокирующего чтения с InterruptedIOException),
        // потом корутина. Наоборот — поток остался бы качать в никуда.
        writers.remove(trackId)?.cancel()
        jobs.remove(trackId)?.cancel()
        clear(trackId)
    }

    /** Удаляет скачанные байты. Трек остаётся в библиотеке и продолжает играть из сети. */
    fun remove(context: Context, track: TrackEntity) {
        cancel(track.id)
        runCatching {
            val cache = OfflineCache.get(context)
            val key = keyOf(track)
            cache.getCachedSpans(key).forEach { span -> runCatching { cache.removeSpan(span) } }
        }
        clear(track.id)
    }

    private fun shortReason(error: Throwable): String = when {
        error.message?.contains("403") == true -> "источник отказал, попробуй ещё раз"
        error is java.io.IOException -> "нет связи"
        else -> "не удалось скачать"
    }

    private fun publish(id: String, status: DownloadStatus) =
        _states.update { it + (id to status) }

    private fun clear(id: String) = _states.update { it - id }
}
