package app.ziziplayer.playback

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/**
 * Хранилище СКАЧАННОГО. Второй кэш рядом со [StreamCache], и это принципиально разные вещи.
 *
 *   StreamCache  — cacheDir, LRU, система вправе стереть его под нехватку места.
 *                  Потеря стоит трафика.
 *   OfflineCache — filesDir, NoOpCacheEvictor: не вытесняет НИЧЕГО и не подлежит уборке
 *                  системой. Потеря стоила бы контента, поэтому её просто не может быть.
 *
 * Именно это разделение и написано в комментарии StreamCache как условие появления «Скачать».
 * Смешать их — самый короткий путь к приложению, которое «теряет загрузки».
 *
 * Ключ записи — наш `zizi://provider/id` (см. [RemoteUri]), тот же, что у стримового кэша:
 * CacheDataSource стоит НАД резолвером, поэтому ключ стабилен и переживает смену адреса CDN.
 */
@UnstableApi
object OfflineCache {

    private const val DIR = "zizi-offline"

    @Volatile private var instance: SimpleCache? = null

    fun get(context: Context): SimpleCache {
        instance?.let { return it }
        synchronized(this) {
            instance?.let { return it }
            val created = SimpleCache(
                File(context.filesDir, DIR),
                NoOpCacheEvictor(),
                StandaloneDatabaseProvider(context)
            )
            instance = created
            return created
        }
    }

    /** Сколько занимают загрузки. Показывается в настройках. */
    fun sizeBytes(): Long = instance?.cacheSpace ?: 0L

    fun release() {
        synchronized(this) {
            runCatching { instance?.release() }
            instance = null
        }
    }
}
