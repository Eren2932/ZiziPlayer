package app.ziziplayer.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.palette.graphics.Palette
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Pulls the accent colour out of the artwork. Falls back to the theme accent. */
@Composable fun rememberAccent(track: TrackEntity?, enabled: Boolean, fallback: Color): Color {
    val bitmap by rememberArtwork(track)
    val target by produceState(fallback, bitmap, enabled, fallback) {
        val source = bitmap
        value = if (!enabled || source == null) fallback else withContext(Dispatchers.Default) {
            runCatching {
                val argb = source.copy(Bitmap.Config.ARGB_8888, false) ?: source
                val small = Bitmap.createScaledBitmap(argb, 72, 72, true)
                val generated = Palette.from(small).maximumColorCount(14).generate()
                val rgb = generated.vibrantSwatch?.rgb
                    ?: generated.lightVibrantSwatch?.rgb
                    ?: generated.lightMutedSwatch?.rgb
                    ?: generated.dominantSwatch?.rgb
                if (rgb != null) readable(Color(rgb)) else fallback
            }.getOrDefault(fallback)
        }
    }
    val animated by animateColorAsState(target, tween(durationMillis = 420), label = "accent")
    return animated
}

private fun readable(color: Color): Color {
    val level = color.luminance()
    return when {
        level < 0.18f -> lerp(color, Color.White, 0.42f)
        level > 0.85f -> lerp(color, Color.Black, 0.12f)
        else -> color
    }
}
