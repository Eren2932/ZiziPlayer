package app.ziziplayer.playback

import android.media.audiofx.PresetReverb
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import android.os.Bundle
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    companion object { const val CMD_REVERB="app.ziziplayer.SET_REVERB"; const val CMD_SKIP_SILENCE="app.ziziplayer.SKIP_SILENCE" }
    private var session: MediaSession? = null
    private var reverb: PresetReverb? = null
    private var reverbPercent = 0

    override fun onCreate() {
        super.onCreate()
        val player=ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(),
                true
            ).setHandleAudioBecomingNoisy(true).build()
        player.addListener(object: Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { attachReverb(audioSessionId) }
        })
        val callback=object: MediaSession.Callback {
            override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
                val base=super.onConnect(session,controller)
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(base.availableSessionCommands.buildUpon().add(SessionCommand(CMD_REVERB,Bundle.EMPTY)).add(SessionCommand(CMD_SKIP_SILENCE,Bundle.EMPTY)).build())
                    .setAvailablePlayerCommands(base.availablePlayerCommands)
                    .build()
            }
            override fun onCustomCommand(session: MediaSession, controller: MediaSession.ControllerInfo, command: SessionCommand, args: Bundle): ListenableFuture<SessionResult> {
                if(command.customAction==CMD_REVERB) {
                    setReverb(args.getInt("percent",0))
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                if(command.customAction==CMD_SKIP_SILENCE) {
                    (session.player as? ExoPlayer)?.skipSilenceEnabled=args.getBoolean("enabled",false)
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                return super.onCustomCommand(session,controller,command,args)
            }
        }
        session=MediaSession.Builder(this,player).setCallback(callback).build()
    }

    fun setReverb(percent: Int) { reverbPercent=percent.coerceIn(0,100); updateReverb() }

    @Suppress("DEPRECATION")
    private fun attachReverb(audioSessionId: Int) {
        reverb?.release()
        reverb=runCatching { PresetReverb(0,audioSessionId) }.getOrNull()
        updateReverb()
    }
    @Suppress("DEPRECATION")
    private fun updateReverb() {
        reverb?.apply {
            preset=when {
                reverbPercent==0 -> PresetReverb.PRESET_NONE
                reverbPercent<25 -> PresetReverb.PRESET_SMALLROOM
                reverbPercent<50 -> PresetReverb.PRESET_MEDIUMROOM
                reverbPercent<75 -> PresetReverb.PRESET_LARGEROOM
                else -> PresetReverb.PRESET_LARGEHALL
            }
            enabled=reverbPercent>0
        }
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onDestroy() { reverb?.release(); session?.run { player.release(); release() }; session=null; super.onDestroy() }
}
