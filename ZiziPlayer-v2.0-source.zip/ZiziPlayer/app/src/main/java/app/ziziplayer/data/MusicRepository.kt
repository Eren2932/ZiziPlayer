package app.ziziplayer.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.*

class MusicRepository(
    private val context: Context,
    private val dao: MusicDao,
    private val settingsStore: SettingsStore,
    private val scanner: MusicScanner
) {
    val tracks = dao.observeTracks()
    val favoriteIds = dao.observeFavoriteIds().map { it.toSet() }
    val playlists = dao.observePlaylists()
    val settings = settingsStore.settings

    suspend fun rescan() {
        val folders=settings.first().folderUris
        val all=(scanner.scanMediaStore()+folders.flatMap { scanner.scanTree(Uri.parse(it)) }).distinctBy { "${it.title.lowercase()}|${it.artist.lowercase()}|${it.durationMs/1000}" }
        if(all.isNotEmpty()) { dao.upsertTracks(all); dao.deleteMissing(all.map { it.id }) }
    }
    suspend fun addFolder(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        settingsStore.addFolder(uri); rescan()
    }
    suspend fun toggleFavorite(id: String, favorite: Boolean) { if(favorite) dao.unfavorite(id) else dao.favorite(FavoriteEntity(id)) }
    suspend fun saveFx(fx: TrackFxEntity) = dao.saveFx(fx)
    suspend fun fx(id: String) = dao.fx(id) ?: TrackFxEntity(id)
    suspend fun createPlaylist(name: String) = dao.createPlaylist(PlaylistEntity(name=name))
    suspend fun addToPlaylist(playlistId: Long, trackId: String) = dao.addToPlaylist(PlaylistTrackEntity(playlistId,trackId,dao.nextPosition(playlistId)))
    suspend fun playlistTracks(playlistId: Long) = dao.playlistTracks(playlistId)
    suspend fun setTheme(theme: AppTheme) = settingsStore.setTheme(theme)
    suspend fun setDynamicAccent(value: Boolean) = settingsStore.setDynamicAccent(value)
    suspend fun setSkipSilence(value: Boolean) = settingsStore.setSkipSilence(value)
    suspend fun setSortMode(value: SortMode) = settingsStore.setSortMode(value)
    suspend fun saveLastPosition(trackId: String, positionMs: Long) = settingsStore.saveLastPosition(trackId, positionMs)
}
