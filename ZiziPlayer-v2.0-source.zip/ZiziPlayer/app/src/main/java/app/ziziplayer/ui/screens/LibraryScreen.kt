package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.*
import app.ziziplayer.ui.*
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.palette

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun LibraryScreen(
    state: MainUiState,
    onFilter:(LibraryFilter)->Unit,onQuery:(String)->Unit,onTrack:(TrackEntity)->Unit,
    onFavorite:(TrackEntity)->Unit,onOpenPlayer:()->Unit,onPlayPause:()->Unit,onPickFolder:()->Unit,onRescan:()->Unit,
    onTheme:(AppTheme)->Unit,onDynamicAccent:(Boolean)->Unit,onCreatePlaylist:(String)->Unit,
    onAddToPlaylist:(Long,String)->Unit,onPlayPlaylist:(Long)->Unit,onSortMode:(SortMode)->Unit
) {
    val p=palette(state.settings.theme)
    var themeSheet by remember { mutableStateOf(false) }
    var createDialog by remember { mutableStateOf(false) }
    var addTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.top,p.middle,p.bottom)))) {
        LazyColumn(contentPadding=PaddingValues(start=20.dp,end=20.dp,top=48.dp,bottom=state.currentTrack?.let{180.dp}?:36.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Моя музыка",color=p.text,fontSize=34.sp,fontWeight=FontWeight.Bold)
                        Text("${state.tracks.size} треков · ${state.tracks.map{it.sourceFolder}.distinct().size} папок",color=p.subtext,fontSize=14.sp)
                    }
                    Box {
                        IconButton(onClick={sortMenu=true}) { Icon(Icons.Rounded.SwapVert,null,tint=p.text) }
                        DropdownMenu(expanded=sortMenu,onDismissRequest={sortMenu=false}) {
                            val options=listOf(SortMode.TITLE to "По названию",SortMode.ARTIST to "По исполнителю",SortMode.RECENT to "Сначала новые",SortMode.DURATION to "По длительности")
                            options.forEach { (mode,label) ->
                                DropdownMenuItem(
                                    text={ Text(label,fontWeight=if(state.settings.sortMode==mode) FontWeight.Bold else FontWeight.Normal) },
                                    onClick={ onSortMode(mode);sortMenu=false }
                                )
                            }
                        }
                    }
                    IconButton(onClick=onRescan) { Icon(Icons.Rounded.Refresh,null,tint=p.text) }
                    IconButton(onClick={themeSheet=true}) { Icon(Icons.Rounded.Palette,null,tint=p.text) }
                }
            }
            item {
                LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=8.dp)) {
                    items(LibraryFilter.entries) { filter ->
                        val label=when(filter){ LibraryFilter.TRACKS->"Треки";LibraryFilter.FAVORITES->"Избранное";LibraryFilter.PLAYLISTS->"Плейлисты";LibraryFilter.FOLDERS->"Папки" }
                        FilterChip(selected=state.filter==filter,onClick={onFilter(filter)},label={Text(label)},
                            colors=FilterChipDefaults.filterChipColors(containerColor=p.chip,labelColor=p.text,selectedContainerColor=p.accent,selectedLabelColor=androidx.compose.ui.graphics.Color(0xFF111114)),border=null)
                    }
                }
            }
            if(state.filter==LibraryFilter.TRACKS || state.filter==LibraryFilter.FAVORITES) {
                item {
                    OutlinedTextField(value=state.query,onValueChange=onQuery,modifier=Modifier.fillMaxWidth(),singleLine=true,
                        placeholder={Text("Поиск по трекам и артистам")},leadingIcon={Icon(Icons.Rounded.Search,null)},shape=RoundedCornerShape(22.dp),
                        colors=OutlinedTextFieldDefaults.colors(focusedContainerColor=p.chip,unfocusedContainerColor=p.chip,focusedBorderColor=p.accent,unfocusedBorderColor=androidx.compose.ui.graphics.Color.Transparent,focusedTextColor=p.text,unfocusedTextColor=p.text,focusedLeadingIconColor=p.subtext,unfocusedLeadingIconColor=p.subtext))
                }
                if(state.visibleTracks.isEmpty()) item { EmptyLibrary(onPickFolder,p.text,p.subtext,state.scanning) }
                items(state.visibleTracks,key={it.id}) { track ->
                    TrackRow(track,track.id==state.playback.currentTrackId,track.id in state.favoriteIds,p,
                        onClick={onTrack(track)},onFavorite={onFavorite(track)},onMore={addTrack=track})
                }
            } else if(state.filter==LibraryFilter.PLAYLISTS) {
                item { Button(onClick={createDialog=true},colors=ButtonDefaults.buttonColors(containerColor=p.accent,contentColor=androidx.compose.ui.graphics.Color(0xFF111114))) { Icon(Icons.Rounded.Add,null);Spacer(Modifier.width(8.dp));Text("Новый плейлист") } }
                items(state.playlists,key={it.id}) { pl ->
                    Row(Modifier.fillMaxWidth().background(p.chip,RoundedCornerShape(24.dp)).clickable{onPlayPlaylist(pl.id)}.padding(20.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.QueueMusic,null,tint=p.accent,modifier=Modifier.size(42.dp));Spacer(Modifier.width(16.dp));Text(pl.name,color=p.text,fontSize=18.sp,fontWeight=FontWeight.Bold)
                    }
                }
            } else {
                item {
                    Column(Modifier.fillMaxWidth().background(p.chip,RoundedCornerShape(26.dp)).padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
                        Text("Папки устройства",color=p.text,fontSize=20.sp,fontWeight=FontWeight.Bold)
                        Text("Выберите одну или несколько папок. Доступ сохранится после перезапуска — повторно открывать файловый менеджер не придётся.",color=p.subtext)
                        Button(onClick=onPickFolder,colors=ButtonDefaults.buttonColors(containerColor=p.accent,contentColor=androidx.compose.ui.graphics.Color(0xFF111114))) { Icon(Icons.Rounded.FolderOpen,null);Spacer(Modifier.width(8.dp));Text("Открыть файловый менеджер") }
                        state.settings.folderUris.forEach { Text("• ${it.substringAfterLast('%').takeLast(32)}",color=p.text,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis) }
                    }
                }
            }
        }
        state.currentTrack?.let { track ->
            MiniPlayer(track,state.playback.isPlaying,state.playback.positionMs,state.playback.durationMs,p,onOpenPlayer,playPause=onPlayPause)
        }
        if(state.scanning) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter),color=p.accent,trackColor=p.chip)
    }
    if(themeSheet) ThemeSheet(state.settings,onDismiss={themeSheet=false},onTheme=onTheme,onDynamicAccent=onDynamicAccent)
    if(createDialog) NameDialog("Новый плейлист",onDismiss={createDialog=false}) { onCreatePlaylist(it);createDialog=false }
    addTrack?.let { track ->
        ModalBottomSheet(onDismissRequest={addTrack=null},containerColor=p.middle) {
            Text(track.title,color=p.text,fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=24.dp))
            Spacer(Modifier.height(14.dp))
            if(state.playlists.isEmpty()) Text("Сначала создайте плейлист",color=p.subtext,modifier=Modifier.padding(24.dp))
            state.playlists.forEach { pl -> TextButton(onClick={onAddToPlaylist(pl.id,track.id);addTrack=null},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Rounded.PlaylistAdd,null,tint=p.accent);Spacer(Modifier.width(10.dp));Text(pl.name,color=p.text) } }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable private fun TrackRow(track:TrackEntity,playing:Boolean,favorite:Boolean,p:app.ziziplayer.ui.theme.ZiziPalette,onClick:()->Unit,onFavorite:()->Unit,onMore:()->Unit) {
    Row(Modifier.fillMaxWidth().then(if(playing) Modifier.background(p.chip,RoundedCornerShape(22.dp)) else Modifier).clickable(onClick=onClick).padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
        Artwork(track,Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title,color=p.text,fontSize=16.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(track.artist,color=p.subtext,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                if(playing) { Spacer(Modifier.width(8.dp));Icon(Icons.Rounded.GraphicEq,null,tint=p.accent,modifier=Modifier.size(18.dp)) }
            }
        }
        IconButton(onClick=onFavorite) { Icon(if(favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,null,tint=if(favorite)p.accent else p.subtext) }
        IconButton(onClick=onMore) { Icon(Icons.Rounded.MoreVert,null,tint=p.subtext) }
    }
}

@Composable private fun EmptyLibrary(onPick:()->Unit,text:androidx.compose.ui.graphics.Color,sub:androidx.compose.ui.graphics.Color,loading:Boolean) {
    Column(Modifier.fillMaxWidth().padding(top=70.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.LibraryMusic,null,tint=sub,modifier=Modifier.size(64.dp));Spacer(Modifier.height(16.dp))
        Text(if(loading)"Сканируем музыку…" else "Музыка пока не найдена",color=text,fontSize=20.sp,fontWeight=FontWeight.Bold)
        Text("Разрешите доступ или выберите папку вручную",color=sub);Spacer(Modifier.height(16.dp));Button(onClick=onPick) { Text("Выбрать папку") }
    }
}

@Composable private fun BoxScope.MiniPlayer(track:TrackEntity,isPlaying:Boolean,pos:Long,dur:Long,p:app.ziziplayer.ui.theme.ZiziPalette,onOpen:()->Unit,playPause:()->Unit) {
    Column(Modifier.fillMaxWidth().padding(14.dp).background(p.chip,RoundedCornerShape(25.dp)).clickable(onClick=onOpen).padding(10.dp).align(Alignment.BottomCenter)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Artwork(track,Modifier.size(58.dp).clip(RoundedCornerShape(15.dp)));Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(track.title,color=p.text,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(track.artist,color=p.subtext,fontSize=13.sp,maxLines=1) }
            IconButton(onClick=playPause) { Icon(if(isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,null,tint=p.text,modifier=Modifier.size(34.dp)) }
        }
        LinearProgressIndicator(progress={if(dur>0) pos.toFloat()/dur else 0f},modifier=Modifier.fillMaxWidth().height(3.dp),color=p.accent,trackColor=p.middle)
    }
}

@Composable private fun NameDialog(title:String,onDismiss:()->Unit,onOk:(String)->Unit) { var name by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={OutlinedTextField(name,{name=it},singleLine=true)},confirmButton={TextButton(onClick={if(name.isNotBlank())onOk(name.trim())}){Text("Создать")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}}) }
