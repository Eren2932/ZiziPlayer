#!/usr/bin/env python3
"""Source contracts, not compilation, Android UI tests or network simulation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(name): return (SRC/name).read_text()
class LyricsContracts(unittest.TestCase):
    def test_secondary_ink_never_changes_with_artwork(self):
        s = read('ui/theme/ZiziTheme.kt')
        body = s.split('fun ZiziPalette.tintedWith(')[1].split('fun ZiziPalette.withAccent')[0]
        self.assertIn('subtext = subtext', body)
        self.assertNotIn('0xFFE0E0E0', body)
        self.assertIn('subtext = Color(0xFF9A9A9A)', s)
    def test_single_fetch_owner_and_cancellation(self):
        owner = read('ui/screens/LyricsUiState.kt')
        self.assertEqual(owner.count('vm.lyrics.fetch('), 1)
        self.assertIn('LaunchedEffect(track, enabled, networkAllowed, state.attempt)', owner)
        self.assertIn('throw e', owner)
        for name in ('LyricsScreen.kt', 'LyricsPreview.kt'):
            s = read('ui/screens/'+name)
            self.assertNotIn('vm.lyrics.fetch', s)
        http = read('lyrics/LyricsRepository.kt')
        self.assertIn('continuation.invokeOnCancellation { call.cancel() }', http)
        self.assertIn('response.use', http)
    def test_no_audio_credentials_in_public_request(self):
        s = read('lyrics/LyricsRepository.kt')
        for bad in ('ZiziResolve', 'ZiziHttp', 'authHeaders', 'SessionHeadersInterceptor', 'Authorization'):
            self.assertNotIn(bad, s)
        self.assertIn('.followRedirects(false)', s)
        self.assertIn('https://lrclib.net/api/get', s)
        self.assertIn('identityMatches', s)
        self.assertIn('durationMatches', s)
    def test_cache_and_input_bounds(self):
        s = read('lyrics/LyricsRepository.kt')
        for text in ('size > 24', '.drop(48)', 'entries.size >= 128', '512 * 1024', 'readLimited', 'Mutex()', 'withContext(Dispatchers.IO)'):
            self.assertIn(text, s)
    def test_cursor_only_uses_existing_media_time(self):
        s = read('ui/screens/LyricsCursor.kt')
        for text in ('vm.progress.map', 'distinctUntilChanged()', 'collectAsStateWithLifecycle', 'progress.trackId == track.id'):
            self.assertIn(text, s)
        for name in ('LyricsCursor.kt', 'LyricsScreen.kt', 'LyricsPreview.kt', 'LyricsUiState.kt'):
            s = read('ui/screens/'+name)
            for bad in ('addListener(', 'while (true)', 'delay(', 'System.currentTimeMillis('):
                self.assertNotIn(bad, s)
    def test_fullscreen_preview_seek_and_manual_scroll(self):
        s = read('ui/screens/PlayerScreen.kt')
        for text in ('LyricsPreview(', 'LyricsScreen(', '.verticalScroll(rememberScrollState())', '.height(viewportHeight)'):
            self.assertIn(text, s)
        s = read('ui/screens/LyricsScreen.kt')
        for text in ('vm.seekTo(LrcTimeline.seekPosition(line, advanceMs), track.id)',
                     'DragInteraction.Start', 'follow = false', 'list.scrollToItem', 'PlayerProgress(vm)', 'OpenDocument()'):
            self.assertIn(text, s)
    def test_nested_scroll_replaces_competing_drag_handler(self):
        s = read('MainActivity.kt')
        self.assertIn('.nestedScroll(sheetScroll)', s)
        self.assertIn('available.y > 0f', s)
        self.assertIn('NestedScrollSource.UserInput', s)
        self.assertNotIn('rememberDraggableState', s)
    def test_tests_wired_and_no_unused_navigation_dependency(self):
        preflight = (ROOT/'tools/check_selftest.py').read_text()
        self.assertIn("'test_lyrics_6440.py'", preflight)
        self.assertIn("'test_lyrics_6440_contracts.py'", preflight)
        self.assertNotIn('implementation("androidx.navigation:', (ROOT/'app/build.gradle.kts').read_text())
    def test_dead_functions_removed(self):
        self.assertNotIn('fun Modifier.topContentTint()', read('ui/components/TopChrome.kt'))
        self.assertNotIn('int cardTop(', read('ui/theme/ArtworkColorMath.java'))
if __name__ == '__main__': unittest.main(verbosity=2)
