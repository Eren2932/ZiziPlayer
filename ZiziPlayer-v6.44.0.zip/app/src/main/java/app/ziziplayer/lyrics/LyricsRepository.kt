package app.ziziplayer.lyrics

import android.content.Context
import android.net.Uri
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToLong

internal data class LyricsDocument(
    val lines: List<LrcTimeline.Line>,
    val plain: String,
    val source: String,
    val durationMs: Long,
    val instrumental: Boolean = false
)

/** On-demand metadata only; no resolver/session credentials and no playback listeners. */
class LyricsRepository(context: Context) {
    private val app = context.applicationContext
    private val lock = Mutex()
    // A dedicated public-metadata client MUST NOT inherit the resolver's auth interceptor.
    private val client by lazy {
        OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS)
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false).followRedirects(false).build()
    }
    private val memory = object : LinkedHashMap<String, LyricsDocument>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LyricsDocument>?): Boolean = size > 24
    }
    private fun key(track: TrackEntity): String {
        val identity = listOf(track.id, track.title, track.artist, track.album, track.durationMs.toString())
        val encoded = identity.joinToString("") { "${it.length}:$it" }
        return MessageDigest.getInstance("SHA-256").digest(encoded.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
    private fun dir(imported: Boolean) = File(if (imported) app.filesDir else app.cacheDir,
        if (imported) "lyrics-imports-v1" else "lyrics-cache-v1").apply { mkdirs() }
    private fun decode(json: JSONObject): LyricsDocument {
        val synced = if (json.isNull("syncedLyrics")) "" else json.optString("syncedLyrics", "")
        val plain = if (json.isNull("plainLyrics")) "" else json.optString("plainLyrics", "")
        return LyricsDocument(LrcTimeline.parse(synced), plain,
            json.optString("source", "LRCLIB"), (json.optDouble("duration", 0.0) * 1000).roundToLong(),
            json.optBoolean("instrumental", false))
    }
    internal suspend fun cached(track: TrackEntity): LyricsDocument? = withContext(Dispatchers.IO) {
        lock.withLock {
            val id = key(track)
            memory[id] ?: sequenceOf(File(dir(true), "$id.json"), File(dir(false), "$id.json"))
                .mapNotNull { file ->
                    if (!file.isFile || file.length() > MAX_BYTES ||
                        (file.parentFile == dir(false) && System.currentTimeMillis() - file.lastModified() > CACHE_AGE_MS)) null
                    else try { decode(JSONObject(file.readText())) } catch (_: Exception) { null }
                }.firstOrNull()?.also { memory[id] = it }
        }
    }
    private suspend fun store(track: TrackEntity, json: JSONObject, imported: Boolean): LyricsDocument =
        withContext(Dispatchers.IO) {
            lock.withLock {
                val doc = decode(json)
                val id = key(track)
                val folder = dir(imported)
                val target = File(folder, "$id.json")
                val entries = folder.listFiles { f -> f.extension == "json" }.orEmpty()
                if (imported && !target.exists() && entries.size >= 128)
                    throw IOException("Достигнут лимит 128 импортированных текстов")
                val encoded = json.toString().toByteArray(Charsets.UTF_8)
                if (encoded.size > MAX_BYTES) throw IOException("Слишком большой текст")
                val tmp = File.createTempFile("lyrics-", ".tmp", folder)
                try {
                    tmp.writeBytes(encoded)
                    if (!tmp.renameTo(target)) throw IOException("Не удалось сохранить текст")
                } finally { tmp.delete() }
                if (!imported) folder.listFiles { f -> f.extension == "json" }.orEmpty()
                    .sortedByDescending { it.lastModified() }.drop(48).forEach { it.delete() }
                memory[id] = doc
                doc
            }
        }
    internal suspend fun importLrc(track: TrackEntity, uri: Uri): LyricsDocument = withContext(Dispatchers.IO) {
        val text = app.contentResolver.openInputStream(uri)?.use { readLimited(it).toString(Charsets.UTF_8) }
            ?: throw IOException("Не удалось открыть LRC")
        if (LrcTimeline.parse(text).isEmpty()) throw IOException("В файле нет таймкодов LRC. Нужен UTF-8 LRC")
        store(track, JSONObject().put("syncedLyrics", text).put("plainLyrics", "")
            .put("source", "Импорт LRC").put("duration", 0), true)
    }
    internal suspend fun fetch(track: TrackEntity): LyricsDocument = withContext(Dispatchers.IO) {
        if (track.title.isBlank() || track.artist.isBlank() ||
            track.artist.equals("Неизвестный артист", true) || track.durationMs <= 0)
            throw IOException("Для поиска нужны название, исполнитель и длительность. Можно импортировать LRC")
        val url = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", track.title)
            .addQueryParameter("artist_name", track.artist)
            .addQueryParameter("album_name", track.album)
            .addQueryParameter("duration", (track.durationMs / 1000.0).toString()).build()
        val raw = get(Request.Builder().url(url)
            .header("User-Agent", "ZiziPlayer/6.44.0 (https://github.com/Eren2932/ZiziPlayer)")
            .header("Accept", "application/json").build())
        val json = JSONObject(raw)
        if (!LrcTimeline.identityMatches(track.title, track.artist, json.optString("trackName"), json.optString("artistName")))
            throw IOException("Название или исполнитель найденного текста не совпадают с треком")
        val doc = decode(json)
        if (!LrcTimeline.durationMatches(track.durationMs, doc.durationMs))
            throw IOException("Длительность найденной версии не совпадает. Можно импортировать точный LRC")
        if (doc.lines.lastOrNull()?.timeMs?.let { it > doc.durationMs + 2000 } == true)
            throw IOException("Таймкоды выходят за длительность трека")
        if (!doc.instrumental && doc.lines.isEmpty() && doc.plain.isBlank())
            throw IOException("Текст для этой версии не найден")
        // Never persist the provider's unrelated/unknown fields.
        store(track, JSONObject().put("syncedLyrics", json.opt("syncedLyrics"))
            .put("plainLyrics", json.opt("plainLyrics")).put("duration", doc.durationMs / 1000.0)
            .put("instrumental", doc.instrumental).put("source", "LRCLIB"), false)
    }
    private suspend fun get(request: Request): String = suspendCancellableCoroutine { continuation ->
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWithException(IOException("Сервис текста недоступен. Проверьте сеть", e))
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    try {
                        if (!continuation.isActive) return
                        if (!r.isSuccessful) throw IOException(when (r.code) {
                            404 -> "Для этой версии текст не найден. Можно импортировать LRC"
                            429 -> "Сервис ограничил запросы. Попробуйте позднее"
                            else -> "Сервис текста временно недоступен (HTTP ${r.code})"
                        })
                        val body = r.body ?: throw IOException("Пустой ответ сервиса")
                        val raw = body.byteStream().use { readLimited(it).toString(Charsets.UTF_8) }
                        if (continuation.isActive) continuation.resume(raw)
                    } catch (e: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(e)
                    }
                }
            }
        })
    }
    private fun readLimited(input: InputStream): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (output.size() + count > MAX_BYTES) throw IOException("Текст превышает лимит 512 КБ")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }
    private companion object {
        const val MAX_BYTES = 512 * 1024
        const val CACHE_AGE_MS = 30L * 24 * 60 * 60 * 1000
    }
}
