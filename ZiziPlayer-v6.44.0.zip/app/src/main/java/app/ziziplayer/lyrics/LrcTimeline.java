package app.ziziplayer.lyrics;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Line-level media timestamps, never wall-clock time. No Android dependencies. */
public final class LrcTimeline {
    private LrcTimeline() {}
    public static final int MAX_CHARS = 512 * 1024;
    public static final int MAX_LINES = 10000;
    private static final Pattern TIME = Pattern.compile("\\[(\\d{1,3}):([0-5]\\d)(?:[.:](\\d{1,3}))?\\]");
    private static final Pattern OFFSET = Pattern.compile("(?im)^\\s*\\[offset:([+-]?\\d{1,8})\\]\\s*$");
    private static final Pattern WORD_TIME = Pattern.compile("<\\d{1,3}:[0-5]\\d(?:[.:]\\d{1,3})?>");
    public static final class Line {
        public final long timeMs;
        public final String text;
        public Line(long timeMs, String text) { this.timeMs = timeMs; this.text = text; }
    }
    public static List<Line> parse(String source) {
        if (source == null || source.isEmpty()) return Collections.emptyList();
        if (source.length() > MAX_CHARS) throw new IllegalArgumentException("LRC too large");
        source = source.replace("\ufeff", "");
        long offset = 0;
        Matcher om = OFFSET.matcher(source);
        while (om.find()) offset = Long.parseLong(om.group(1));
        TreeMap<Long, String> sorted = new TreeMap<>();
        int count = 0;
        for (String raw : source.split("\\r?\\n")) {
            Matcher m = TIME.matcher(raw);
            List<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                // A timestamp in the middle of prose is not a new timed line.
                if (!raw.substring(end, m.start()).trim().isEmpty()) break;
                String fraction = m.group(3);
                long millis = fraction == null ? 0 : Long.parseLong((fraction + "000").substring(0, 3));
                long t = Long.parseLong(m.group(1)) * 60000 + Long.parseLong(m.group(2)) * 1000 + millis;
                // LRC positive offset means display earlier: cue time = stamp - offset.
                stamps.add(Math.max(0, t - offset));
                end = m.end();
                if (++count > MAX_LINES) throw new IllegalArgumentException("Too many LRC cues");
            }
            if (stamps.isEmpty()) continue;
            String text = WORD_TIME.matcher(raw.substring(end).trim()).replaceAll("");
            for (long t : stamps) {
                String previous = sorted.get(t);
                if (previous == null || previous.isEmpty()) sorted.put(t, text);
                else if (!text.isEmpty() && !previous.equals(text)) sorted.put(t, previous + "\n" + text);
            }
        }
        List<Line> result = new ArrayList<>(sorted.size());
        sorted.forEach((t, text) -> result.add(new Line(t, text)));
        return Collections.unmodifiableList(result);
    }
    /** Last cue <= media position + user advance; -1 before the first cue. O(log n). */
    public static int activeIndex(List<Line> lines, long mediaMs, long advanceMs) {
        long position = Math.max(0, mediaMs) + Math.max(-60000, Math.min(60000, advanceMs));
        int lo = 0, hi = lines.size();
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs <= position) lo = mid + 1; else hi = mid;
        }
        return lo - 1;
    }
    public static long seekPosition(Line line, long advanceMs) {
        return Math.max(0, line.timeMs - Math.max(-60000, Math.min(60000, advanceMs)));
    }
    public static boolean durationMatches(long expectedMs, long actualMs) {
        return expectedMs > 0 && actualMs > 0 && Math.abs(expectedMs - actualMs) <= 2000;
    }
    private static String normalized(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFKC)
            .trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }
    /** Deliberately do not remove slowed/remix/live qualifiers or infer a different artist. */
    public static boolean identityMatches(String title, String artist, String candidateTitle, String candidateArtist) {
        return !normalized(title).isEmpty() && !normalized(artist).isEmpty()
            && normalized(title).equals(normalized(candidateTitle))
            && normalized(artist).equals(normalized(candidateArtist));
    }
}
