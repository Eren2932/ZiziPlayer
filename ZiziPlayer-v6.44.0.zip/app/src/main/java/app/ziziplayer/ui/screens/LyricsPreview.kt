package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.theme.LocalPalette

/** Below the existing viewport: it never compresses the cover or transport geometry. */
@Composable
internal fun LyricsPreview(vm: MainViewModel, track: TrackEntity, state: LyricsUiState, onOpen: () -> Unit, onLoad: () -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        .clip(RoundedCornerShape(20.dp)).background(p.chip).padding(18.dp)) {
        Text("Предпросмотр текста", color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(22.dp))
        val doc = state.document
        when {
            state.busy -> Text("Загружаем текст…", color = p.subtext)
            doc != null -> PreviewLines(vm, track, state)
            else -> {
                Text(state.message ?: "Найти текст с таймкодами для этой версии трека", color = p.subtext)
                Spacer(Modifier.height(8.dp))
                Text("Поиск отправит название, исполнителя, альбом и длительность в LRCLIB, но не аудио. Разрешение — до закрытия плеера.", color = p.subtext, fontSize = 12.sp)
                TextButton(onClick = onLoad) { Text("Найти текст", color = p.text) }
            }
        }
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = onOpen, modifier = Modifier.background(p.text, RoundedCornerShape(24.dp))) {
            Text(if (doc == null) "Показать текст / импорт LRC" else "Показать текст", color = Color.Black,
                modifier = Modifier.padding(horizontal = 10.dp), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PreviewLines(vm: MainViewModel, track: TrackEntity, state: LyricsUiState) {
    val p = LocalPalette.current
    val doc = state.document ?: return
    val cursor by rememberLyricsCursor(vm, track, doc, state.advanceMs)
    val sync = cursor.sameTrack && cursor.matchesDuration
    val active = cursor.active
    if (doc.lines.isNotEmpty()) {
        val start = (active - 1).coerceAtLeast(0)
        for (index in start until (start + 3).coerceAtMost(doc.lines.size)) {
            Text(doc.lines[index].text.ifBlank { "♪" }, color = if (index == active) p.text else p.text.copy(alpha = 0.52f),
                fontSize = 23.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
        }
        Text(if (sync) "${doc.source} · по строкам" else "Длительность или позиция ещё не совпадают", color = p.subtext, fontSize = 12.sp)
    } else {
        Text(if (doc.instrumental) "Инструментальная композиция" else doc.plain, color = p.text,
            fontSize = 23.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
        Text("${doc.source} · без синхронизации", color = p.subtext, fontSize = 12.sp)
    }
}
