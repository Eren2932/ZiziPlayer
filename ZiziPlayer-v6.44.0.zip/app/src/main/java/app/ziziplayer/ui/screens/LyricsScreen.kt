package app.ziziplayer.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import java.util.Locale

/** One dialog, current Media3 identity, no second clock and no queue-wide fetches. */
@Composable
internal fun LyricsScreen(
    vm: MainViewModel,
    track: TrackEntity,
    playback: PlaybackState,
    state: LyricsUiState,
    networkAllowed: Boolean,
    onAllowNetwork: () -> Unit,
    onClose: () -> Unit
) {
    val p = LocalPalette.current
    var pickedFor by rememberSaveable { mutableStateOf<String?>(null) }
    val advanceMs = state.advanceMs
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pickedFor == track.id) state.importFile(uri)
        pickedFor = null
    }
    val busy = state.busy
    val message = state.message
    val document = state.document
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val background = remember(p.top, p.bottom) { Brush.verticalGradient(listOf(p.top, p.bottom)) }
        Column(Modifier.fillMaxSize().background(background).safeDrawingPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(ZiziIcons.ChevronDown, "Закрыть текст", tint = p.text) }
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = p.text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = p.subtext, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (busy) Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator(Modifier.size(24.dp), color = p.text)
            }
            val doc = document
            if (doc == null) {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(24.dp)) {
                    item {
                        Text(message ?: "Синхронизированный текст для текущей версии трека", color = p.text, fontSize = 20.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("Поиск отправляет название, исполнителя, альбом и длительность в LRCLIB. Аудио и файлы не отправляются. Разрешение действует до закрытия плеера. Можно открыть свой UTF-8 LRC без сети.", color = p.subtext)
                    }
                }
            } else {
                if (message != null) Text(message.orEmpty(), color = p.text, modifier = Modifier.padding(horizontal = 24.dp), maxLines = 3)
                LyricsBody(vm, track, doc, advanceMs, Modifier.weight(1f))
                if (doc.lines.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        TextButton(onClick = { state.advanceMs = (advanceMs - 500).coerceAtLeast(-60000) }) { Text("−0,5 с", color = p.text) }
                        TextButton(onClick = { state.advanceMs = 0 }) {
                            Text(String.format(Locale.ROOT, "%+.1f с", advanceMs / 1000.0), color = p.text)
                        }
                        TextButton(onClick = { state.advanceMs = (advanceMs + 500).coerceAtMost(60000) }) { Text("+0,5 с", color = p.text) }
                    }
                    Text("+ показывает строки раньше · число сбрасывает сдвиг", color = p.subtext,
                        fontSize = 11.sp, modifier = Modifier.padding(horizontal = 24.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(enabled = !busy, onClick = {
                    if (!networkAllowed) onAllowNetwork() else state.retry()
                }) { Text(if (doc == null) "Найти текст" else "Обновить · LRCLIB", color = p.text) }
                TextButton(enabled = !busy, onClick = {
                    pickedFor = track.id
                    importer.launch(arrayOf("*/*"))
                }) { Text("Импорт LRC", color = p.text) }
            }
            PlayerProgress(vm)
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center) {
                IconButton(onClick = vm::playPause, modifier = Modifier.size(64.dp)
                    .background(p.text, androidx.compose.foundation.shape.CircleShape)) {
                    Icon(if (playback.isPlaying) ZiziIcons.Pause else ZiziIcons.PlayFilled,
                        if (playback.isPlaying) "Пауза" else "Воспроизвести", tint = Color.Black, modifier = Modifier.size(30.dp))
                }
            }
        }
    }
}

/** Position is collected here, never in the library or the parent player composition. */
@Composable
private fun LyricsBody(vm: MainViewModel, track: TrackEntity, doc: LyricsDocument, advanceMs: Long, modifier: Modifier) {
    val p = LocalPalette.current
    val cursor by rememberLyricsCursor(vm, track, doc, advanceMs)
    val list = rememberLazyListState()
    var follow by remember(doc) { mutableStateOf(true) }
    val sameTrack = cursor.sameTrack
    val matchesDuration = cursor.matchesDuration
    val synchronized = sameTrack && matchesDuration && doc.lines.isNotEmpty()
    val active = cursor.active
    LaunchedEffect(list) {
        list.interactionSource.interactions.collect { if (it is DragInteraction.Start) follow = false }
    }
    // Large seeks jump directly; no multi-page animation chasing a previous position.
    LaunchedEffect(active, follow) {
        if (follow && active >= 0) list.scrollToItem((active - 1).coerceAtLeast(0))
    }
    Column(modifier.fillMaxWidth()) {
        Text(when {
            doc.instrumental -> "LRCLIB: инструментальная композиция"
            doc.lines.isEmpty() -> "${doc.source} · без таймкодов"
            !sameTrack -> "Ожидание позиции текущего трека"
            !matchesDuration -> "Длительность аудио отличается: синхронизация отключена"
            else -> "${doc.source} · по строкам · совпадение версии требует проверки"
        }, color = p.subtext, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 24.dp))
        if (!follow && synchronized) TextButton(onClick = { follow = true }) { Text("К текущей строке", color = p.text) }
        val plainLines = remember(doc) { doc.plain.lines() }
        LazyColumn(state = list, modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)) {
            if (doc.lines.isNotEmpty()) {
                itemsIndexed(doc.lines, key = { _, line -> line.timeMs }) { index, line ->
                    Text(line.text.ifBlank { "♪" },
                        color = if (index == active) p.text else p.text.copy(alpha = 0.52f),
                        fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth().semantics { selected = index == active }
                            .clickable(enabled = synchronized) {
                                follow = true
                                vm.seekTo(LrcTimeline.seekPosition(line, advanceMs), track.id)
                            }.padding(vertical = 6.dp))
                }
            } else {
                itemsIndexed(plainLines) { _, line -> Text(line, color = p.text, fontSize = 23.sp) }
            }
        }
    }
}
