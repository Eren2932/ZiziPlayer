package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.runtime.*
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.ui.MainViewModel
import kotlinx.coroutines.CancellationException

/** Shared by the two views: exactly one request owner, regardless of which view is visible. */
@Stable
internal class LyricsUiState {
    var document by mutableStateOf<LyricsDocument?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var attempt by mutableIntStateOf(0)
    var pickedUri by mutableStateOf<Uri?>(null)
    var advanceMs by mutableLongStateOf(0L)
    var generation = 0
    fun retry() { pickedUri = null; attempt++ }
    fun importFile(uri: Uri) { pickedUri = uri; attempt++ }
}

@Composable
internal fun rememberLyricsUiState(vm: MainViewModel, track: TrackEntity?, enabled: Boolean, networkAllowed: Boolean): LyricsUiState {
    val state = remember(track) { LyricsUiState() }
    LaunchedEffect(track, enabled, networkAllowed, state.attempt) {
        if (!enabled || track == null) return@LaunchedEffect
        val requestGeneration = ++state.generation
        state.busy = true
        state.message = null
        val uri = state.pickedUri
        try {
            state.document = if (uri != null) vm.lyrics.importLrc(track, uri) else {
                val cached = if (state.attempt == 0) vm.lyrics.cached(track) else null
                cached ?: if (networkAllowed) vm.lyrics.fetch(track) else null
            }
            if (uri != null) state.advanceMs = 0
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            state.message = e.message ?: "Не удалось загрузить текст"
        } finally {
            if (state.generation == requestGeneration) {
                if (state.pickedUri == uri) state.pickedUri = null
                state.busy = false
            }
        }
    }
    return state
}
