# ZiziPlayer — Android 6.43.0

Нативный Android-плеер на Kotlin, Jetpack Compose и Media3: локальные файлы/SAF, сетевой каталог и офлайн-загрузки, очередь, избранное, плейлисты, индивидуальные аудионастройки. Данные сохраняются через Room и DataStore. В этом архиве также оставлены серверная часть и история изменений.

**Эта поставка — кандидат исходников, versionCode 91, не готовый проверенный APK.** Основа: 6.42.0. Изменения: нейтральные пустые обложки, единый бар выбора, нижняя вуаль 65%, новый диалог массовой загрузки и нейтральное меню трека. Подробный отчёт: `CHANGELOG_v6.43.0.md`; приёмка: `DEVICE_CHECKLIST_v6.43.0.md`; журналы проверок: `verification/v6.43.0/`.

## Обновление существующего репозитория

В Eren2932/ZiziPlayer загрузить `ZiziPlayer-v6.43.0.zip` целиком в корень. Не распаковывать поверх корня, не заменять desktop `current.json` и не изменять ключи подписи. Android workflow в корне репозитория выбирает ZIP с максимальным versionCode; при push подходящего ZIP запускается сборка. APK необходимо получить из успешного запуска Actions и проверить на устройстве.

## Локальная проверка и сборка

Текущий проект требует JDK 17, Android SDK 36 и версий Gradle/плагинов, записанных в `gradle/wrapper/gradle-wrapper.properties` и `build.gradle.kts`. В исходном архиве нет готового wrapper JAR и запускающего `gradlew`; CI подготавливает Gradle своим существующим способом. Не подставлять версии из исторических changelog.

````bash
python tools/check_selftest.py
python tools/check_kotlin_syntax.py app/src
python tools/check_imports.py
python tools/check_call_args.py
python tools/check_static_refs.py
# После подготовки Android SDK и Gradle:
gradle :app:testDebugUnitTest :app:assembleDebug
````

Статические проверки и standalone Java-тесты пройдены в the Computer. Kotlin/Compose и APK в этой сессии не компилировались; производительность и визуальная приёмка на телефоне не измерялись. Исторические `CHANGELOG_*`, `RELEASE_*`, `STATUS.md` описывают прошлые версии, а не дополнительные одновременно работающие реализации.
