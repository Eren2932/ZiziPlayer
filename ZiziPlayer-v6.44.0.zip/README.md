# ZiziPlayer — Android 6.44.0

Нативный Android-плеер на Kotlin, Jetpack Compose и Media3: локальные файлы/SAF, сетевой каталог и офлайн-загрузки, очередь, избранное, плейлисты, индивидуальные аудионастройки. Данные сохраняются через Room и DataStore. Версия 6.44.0 добавляет тексты песен LRCLIB и импорт LRC; серверная часть и история изменений сохранены в архиве.

**Эта поставка — исходники 6.44.0, versionCode 92, с адресным исправлением компиляции Java-тестов, не готовый проверенный APK.** Диагноз, точные изменения, ограничения проверок и инструкция: `BUILD_FIX_v6.44.0.md`. Актуальный манифест исправления: `BUILD_FIX_MANIFEST_v6.44.0.json`. Исходный функциональный отчёт: `RELEASE_v6.44.0.md`; приёмка на телефоне: `DEVICE_CHECKLIST_v6.44.0.md`.

## Обновление существующего репозитория

Загрузить `ZiziPlayer-v6.44.0.zip` целиком в корень Eren2932/ZiziPlayer **с заменой старого одноимённого файла**. Не распаковывать поверх корня, не заменять desktop `current.json` и не изменять секреты подписи. Не оставлять два исходных ZIP с одинаковым versionCode 92: Android workflow выбирает единственный ZIP с максимальным кодом.

Нужен новый запуск Actions для нового коммита. Повтор старого запуска использует старый ZIP. Готовый APK получать только из успешной новой сборки, затем проверять на устройстве.

## Локальные проверки

Проект требует JDK 17, Android SDK 36 и Gradle 8.11.1. Версии плагинов записаны в `build.gradle.kts`. В исходном архиве нет готового wrapper JAR и `gradlew`; существующий CI подготавливает Gradle отдельно.

````bash
python tools/check_selftest.py
python tools/check_kotlin_syntax.py app/src
python tools/check_imports.py app/src/main
python tools/check_static_refs.py app/src/main
python tools/check_call_args.py app/src/main
# Дополнительная адресная проверка с установленным SDK:
python tools/test_lyrics_file_api.py --android-jar "$ANDROID_HOME/platforms/android-36/android.jar"
# После подготовки всего Android/Gradle-окружения:
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug --stacktrace
````

44 исходные проверочные команды и адресная компиляция выражения чтения против Android API 26 прошли в the Computer. Полная Gradle-сборка исправленного Android-проекта здесь не выполнялась. Журналы текущей проверки: `verification/v6.44.0-buildfix/`; старые журналы описывают первоначальный кандидат, а не эту проверку.
