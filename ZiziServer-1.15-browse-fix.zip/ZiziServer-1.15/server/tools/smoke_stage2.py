#!/usr/bin/env python3
"""Real ASGI startup on loopback with temporary state; no YouTube requests.
Requires existing FastAPI, uvicorn, httpx, yt-dlp in this Python environment.
Does not read zizi.env or touch the production service/databases.
"""
import json
import os
import re
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request


def main():
    root=Path(__file__).resolve().parent.parent
    with tempfile.TemporaryDirectory(prefix='zizi-stage2-smoke-') as tmp:
        # Keep the listening socket reserved; uvicorn inherits it via --fd.
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); sock.listen(32)
            port=sock.getsockname()[1]
            env={'PATH':os.environ.get('PATH','/usr/bin:/bin'), 'HOME':tmp,
                 'PYTHONUNBUFFERED':'1', 'ZIZI_TOKEN':'smoke-test-not-a-secret',
                 'ZIZI_ADMIN_TOKEN':'smoke-admin-not-a-secret',
                 'ZIZI_DEVICE_KEY':'smoke-device-not-a-secret', 'ZIZI_DEVICE_MODE':'require',
                 'ZIZI_CATALOG_TOKEN_MODE':'require', 'ZIZI_EXTRA_ENABLED':'0',
                 'ZIZI_CATALOG_DB':tmp+'/catalog.db', 'ZIZI_IMG_DIR':tmp+'/img',
                 'ZIZI_AUDIO_DIR':tmp+'/audio', 'ZIZI_CACHE_FILE':tmp+'/cache.json',
                 'ZIZI_PROXY_MODE':'off'}
            with tempfile.TemporaryFile() as log:
                child=subprocess.Popen([sys.executable,'-m','uvicorn','zizi_resolver:app',
                                        '--fd',str(sock.fileno()),'--workers','1','--no-access-log'],
                                       cwd=root,env=env,pass_fds=(sock.fileno(),),stdout=log,stderr=log)
                checks=[]
                try:
                    deadline=time.monotonic()+12
                    while True:
                        if child.poll() is not None: raise RuntimeError('ASGI startup failed; check installed dependencies')
                        try:
                            with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=.5) as r:
                                health=json.load(r)
                            break
                        except (OSError,ValueError):
                            if time.monotonic()>=deadline: raise RuntimeError('ASGI startup timeout')
                            time.sleep(.05)
                    assert health['version']=='1.7-stage2'
                    assert health['scheduler']['resolver_attached'] and health['scheduler']['slots']==1
                    checks.append('resolver health + shared scheduler')
                    with urllib.request.urlopen(f'http://127.0.0.1:{port}/catalog/health',timeout=2) as r:
                        health=json.load(r)
                    # Версия каталога растёт с каждым релизом (1.13, 1.14, 1.15...): проверяем форму, а не
                    # буквальную строку. Буквальное '1.9-stage2' роняло этот тест на каждой версии после 1.10.
                    assert re.fullmatch(r'\d+\.\d+-[a-z0-9-]+', health['version']), health['version']
                    assert not health['extra']['enabled']
                    assert health['browse_contract'] == 1
                    # Три факта, из которых состоит «установлено правильно»: умный подбор, Reco и лента.
                    assert health['match_engine'] == 'smart', health.get('match_engine')
                    assert health['reco_contract'] == 1, health.get('reco_contract')
                    assert health['reco_feed'] == 1, health.get('reco_feed')
                    checks.append('catalog mounted + Browse 1 + smart match + Reco 1 + feed + extra disabled')
                    for path in ['/catalog/browse?q=test&kind=artist',
                                 '/catalog/browse/collection?id=1&kind=album',
                                 '/resolve?id=abcdefghijk','/catalog/extra/search?q=test',
                                 '/match?title=test&artist=fixture']:
                        try:
                            urllib.request.urlopen(f'http://127.0.0.1:{port}'+path,timeout=2)
                            raise AssertionError('unauthenticated request unexpectedly accepted')
                        except urllib.error.HTTPError as e:
                            assert e.code==401, e.code
                    for path in ['/catalog/reco/home','/catalog/reco/feed']:
                        try:
                            urllib.request.urlopen(urllib.request.Request(
                                f'http://127.0.0.1:{port}'+path,data=b'{"s":"1~1"}',method='POST',
                                headers={'Content-Type':'application/json'}),timeout=2)
                            raise AssertionError('unauthenticated reco request unexpectedly accepted')
                        except urllib.error.HTTPError as e:
                            assert e.code==401, (path, e.code)
                    checks.append('resolve/match/extra/reco reject unauthenticated requests')
                    req=urllib.request.Request(f'http://127.0.0.1:{port}/auth/device',headers={
                        'Authorization':'Bearer smoke-test-not-a-secret','X-Zizi-Install':'stage2-smoke-install'})
                    with urllib.request.urlopen(req,timeout=2) as r: token=json.load(r)['token']
                    req=urllib.request.Request(f'http://127.0.0.1:{port}/catalog/extra/search?q=test',headers={
                        'Authorization':'Bearer '+token,'X-Zizi-Install':'stage2-smoke-install'})
                    try:
                        urllib.request.urlopen(req,timeout=2)
                        raise AssertionError('disabled extra unexpectedly accepted request')
                    except urllib.error.HTTPError as e: assert e.code==503,e.code
                    checks.append('device auth + disabled feature returns 503')
                    # С токеном роуты ленты существуют и сами проверяют тело: пустой профиль = 422, а не 404/500.
                    for path in ['/catalog/reco/home','/catalog/reco/feed']:
                        req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=b'{}',method='POST',headers={
                            'Authorization':'Bearer '+token,'X-Zizi-Install':'stage2-smoke-install',
                            'Content-Type':'application/json'})
                        try:
                            urllib.request.urlopen(req,timeout=2)
                            raise AssertionError('empty profile unexpectedly accepted')
                        except urllib.error.HTTPError as e: assert e.code==422,(path,e.code)
                    checks.append('reco routes mounted behind device auth, empty profile = 422')
                    print(json.dumps({'ok':True,'network':'loopback-only','checks':checks}))
                finally:
                    child.terminate()
                    try: child.wait(5)
                    except subprocess.TimeoutExpired: child.kill(); child.wait()
    return 0


if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as e:
        print(json.dumps({'ok':False,'error':type(e).__name__, 'reason':str(e)}))
        raise SystemExit(1)
