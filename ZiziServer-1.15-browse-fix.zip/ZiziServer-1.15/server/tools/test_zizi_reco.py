#!/usr/bin/env python3
"""Reco 1: математика, сборка полок и устойчивость. Ответы Deezer — снятые с живого API фикстуры.

Сеть не нужна. FastAPI подменён проектной заглушкой (server/tools/_stub), SQLite и потоки настоящие.
Часы инъектированы: «сегодня» = 2026-10-02 12:00 UTC, чтобы окно свежести не зависело от даты прогона.
"""
import json
import math
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "_stub"))
sys.path.insert(0, str(HERE.parent))

import zizi_reco as reco                       # noqa: E402
from fastapi import APIRouter, HTTPException  # noqa: E402

FX = HERE / "fixtures" / "reco"
NOW = datetime(2026, 10, 2, 12, 0, tzinfo=timezone.utc).timestamp()
ZAYLO, SAMIR = "8815756", "6833609"


def load(name):
    return json.loads((FX / name).read_text(encoding="utf-8"))


def dz_track(t):                                # то же, что zizi_catalog.dz_track
    return {"src": "deezer", "id": str(t.get("id")), "isrc": t.get("isrc"),
            "artist_id": str((t.get("artist") or {}).get("id") or "") or None,
            "album_id": str((t.get("album") or {}).get("id") or "") or None,
            "title": t.get("title"), "artist": (t.get("artist") or {}).get("name"),
            "album": (t.get("album") or {}).get("title"), "dur": int(t.get("duration") or 0),
            "art": (t.get("album") or {}).get("cover_big")}


class FakeDeezer:
    """Отдаёт снятые фикстуры; для чужих артистов синтезирует два релиза (20 и 300 дней назад)."""

    def __init__(self, delay=0.0, fail=None):
        self.calls, self.delay, self.fail = [], delay, fail
        self.lock = threading.Lock()
        self.search = {"zaylo": load("search_zaylo.json"), "rubikdice": load("search_rubikdice.json"),
                       "yasuharu takanashi": load("search_takanashi.json")}
        self.files = {}
        for aid in (ZAYLO, SAMIR):
            for kind in ("related", "radio", "albums"):
                self.files[f"artist/{aid}/{kind}"] = load(f"{kind}_{aid}.json")
        self.names = {ZAYLO: ("Zaylo", 1341), SAMIR: ("DJ Samir", 12570)}

    def __call__(self, path, **params):
        with self.lock:
            self.calls.append((path, tuple(sorted(params.items()))))
        if self.delay:
            time.sleep(self.delay)
        if self.fail:
            raise self.fail(path)
        if path == "search/artist":
            return self.search.get(str(params.get("q")).lower(), {"data": []})
        if path in self.files:
            return self.files[path]
        parts = path.split("/")
        if len(parts) == 2 and parts[0] == "artist":
            name, fans = self.names.get(parts[1], (f"Artist {parts[1]}", 500))
            return {"id": int(parts[1]), "name": name, "nb_fan": fans,
                    "picture_big": f"https://img/artist/{parts[1]}.jpg"}
        if len(parts) == 3 and parts[0] == "artist" and parts[2] == "albums":
            aid = int(parts[1])
            day = 86400
            def date(offset):
                return datetime.fromtimestamp(NOW - offset * day, timezone.utc).strftime("%Y-%m-%d")
            return {"data": [
                {"id": aid * 10 + 1, "title": f"New {aid}", "cover_big": f"https://img/al/{aid}1.jpg",
                 "release_date": date(20), "record_type": "ep"},
                {"id": aid * 10 + 2, "title": f"Old {aid}", "cover_big": f"https://img/al/{aid}2.jpg",
                 "release_date": date(300), "record_type": "album"},
                {"id": aid * 10 + 3, "title": f"Mix {aid}", "cover_big": f"https://img/al/{aid}3.jpg",
                 "release_date": date(5), "record_type": "compile"}]}
        if len(parts) == 3 and parts[0] == "artist":
            return {"data": []}
        raise HTTPException(404, "unknown " + path)

    def count(self, kind):
        return sum(1 for p, _ in self.calls if p.endswith("/" + kind))


class Clock:
    def __init__(self, t=NOW):
        self.t = t

    def __call__(self):
        return self.t


def make_engine(fake=None, db=None, clock=None):
    fake = fake or FakeDeezer()
    clock = clock or Clock()
    bucket = reco.Bucket(1000.0, 1000.0)
    up = reco.Upstream(fake, db, clock, bucket)
    return reco.Engine(up, dz_track, clock), fake, clock


def profile(**kw):
    s = kw.pop("s", f"{ZAYLO}~1|{SAMIR}~0.7")
    return reco.parse_profile(s, kw.pop("k", ""), kw.pop("x", ""), kw.pop("r", ""), kw.pop("v", ""))


def shelf(result, sid):
    return next((s for s in result["shelves"] if s["id"] == sid or s["id"].startswith(sid)), None)


class MathTests(unittest.TestCase):
    def test_rank_decay_values(self):
        self.assertEqual(reco.phi(0), 1.0)
        self.assertAlmostEqual(reco.phi(3), 0.5)
        self.assertAlmostEqual(reco.phi(24), 0.2)
        self.assertEqual(reco.phi(-5), 1.0)

    def test_fans_penalty_only_for_empty_profiles(self):
        self.assertAlmostEqual(reco.psi(0), 0.6)
        self.assertAlmostEqual(reco.psi(150), 0.8)
        self.assertEqual(reco.psi(300), 1.0)
        self.assertEqual(reco.psi(10 ** 7), 1.0)

    def test_popularity_is_bounded(self):
        self.assertEqual(reco.pop_of(0), 0.0)
        self.assertEqual(reco.pop_of(10 ** 9), 1.0)
        self.assertAlmostEqual(reco.pop_of(999999), 1.0, places=5)

    def test_daily_tie_is_stable_small_and_rotates(self):
        a = reco.daily_tie("42", 100)
        self.assertEqual(a, reco.daily_tie("42", 100))
        self.assertTrue(0 <= a < 0.01)
        self.assertNotEqual(a, reco.daily_tie("42", 101))

    def test_fold_matches_client_normalization(self):
        self.assertEqual(reco.fold("  DJ_Samir  "), "dj samir")
        self.assertEqual(reco.fold("Beyoncé"), "beyonce")
        self.assertEqual(reco.fold("NIGHTFXRCE!"), "nightfxrce")

    def test_age_days(self):
        self.assertAlmostEqual(reco.age_days("2026-10-01", NOW), 1.5)
        self.assertIsNone(reco.age_days("garbage", NOW))
        self.assertIsNone(reco.age_days(None, NOW))


class ProfileTests(unittest.TestCase):
    def test_ids_names_weights(self):
        p = reco.parse_profile("8815756~1|Zaylo~0.5|8815756~0.2|bad~x|~1", "DJ Samir|123", "Foo", "6833609|Zaylo", "slowed")
        self.assertEqual(p.seeds[0], (("id", "8815756"), 1.0))
        self.assertEqual(len([s for s in p.seeds if s[0] == ("id", "8815756")]), 1)   # дубль отброшен
        self.assertIn("dj samir", p.known_names)
        self.assertIn("123", p.known_ids)
        self.assertEqual(p.neg_names, {"foo"})
        self.assertEqual(p.recent, [("id", "6833609"), ("name", "zaylo")])
        self.assertEqual(p.version, "slowed")

    def test_digit_only_name_needs_prefix(self):
        p = reco.parse_profile("n:070~1|8815756~0.5", "n:50|123")
        self.assertEqual(p.seeds[0][0], ("name", "070"))
        self.assertEqual(p.seeds[1][0], ("id", "8815756"))
        self.assertEqual(p.known_names, {"50"})
        self.assertEqual(p.known_ids, {"123"})

    def test_weights_clamped_and_seed_cap(self):
        p = reco.parse_profile("|".join(f"{i}~{w}" for i, w in enumerate([5, -1, 0.5, float("nan")], 100)))
        self.assertTrue(all(0.05 <= w <= 1.0 for _, w in p.seeds))
        many = "|".join(f"{1000 + i}~{1 - i / 100}" for i in range(30))
        self.assertEqual(len(reco.parse_profile(many).seeds), reco.MAX_SEEDS)

    def test_order_is_by_weight_then_ref(self):
        p = reco.parse_profile("3~0.5|1~0.9|2~0.5")
        self.assertEqual([r[1] for r, _ in p.seeds], ["1", "2", "3"])

    def test_oversize_profile_is_rejected(self):
        with self.assertRaises(HTTPException) as ctx:
            reco.parse_profile("1~1", "x" * (reco.MAX_QUERY + 1))
        self.assertEqual(ctx.exception.status_code, 422)

    def test_unknown_version_is_ignored(self):
        self.assertEqual(reco.parse_profile("1~1", v="'; drop").version, "")

    def test_key_changes_with_day_and_content(self):
        a, b = profile(), profile(v="slowed")
        self.assertEqual(a.key(5), profile().key(5))
        self.assertNotEqual(a.key(5), a.key(6))
        self.assertNotEqual(a.key(5), b.key(5))


class BucketTests(unittest.TestCase):
    def test_burst_then_rate(self):
        t, slept = [0.0], []
        def sleep(d):
            slept.append(d)
            t[0] += d
        b = reco.Bucket(8.0, 8.0, clock=lambda: t[0], sleep=sleep)
        self.assertTrue(all(b.take(1.0) for _ in range(8)))
        self.assertEqual(slept, [])
        self.assertTrue(b.take(1.0))
        self.assertAlmostEqual(sum(slept), 0.125, places=6)

    def test_refuses_when_budget_is_shorter_than_wait(self):
        t = [0.0]
        b = reco.Bucket(1.0, 1.0, clock=lambda: t[0], sleep=lambda d: None)
        self.assertTrue(b.take(0.1))
        self.assertFalse(b.take(0.5))


class UpstreamTests(unittest.TestCase):
    def test_cache_hit_and_ttl(self):
        engine, fake, clock = make_engine()
        up = engine.up
        up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
        up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
        self.assertEqual(fake.count("related"), 1)
        clock.t += reco.TTL["related"] + 1
        up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
        self.assertEqual(fake.count("related"), 2)

    def test_stale_served_when_upstream_fails(self):
        engine, fake, clock = make_engine()
        first = engine.up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
        clock.t += reco.TTL["related"] + 10
        fake.fail = lambda path: HTTPException(502, "deezer: boom")
        self.assertEqual(engine.up.get("related", f"artist/{ZAYLO}/related", {"limit": 25}), first)
        self.assertEqual(engine.up.stale, 1)

    def test_failure_without_cache_is_none_not_exception(self):
        engine, fake, _ = make_engine(FakeDeezer(fail=lambda path: RuntimeError("net")))
        self.assertIsNone(engine.up.get("related", "artist/1/related", {}))

    def test_quota_error_starts_cooldown(self):
        fake = FakeDeezer(fail=lambda path: HTTPException(502, "deezer: Exception Quota limit exceeded"))
        engine, _, clock = make_engine(fake)
        engine.up.get("related", "artist/1/related", {})
        engine.up.get("related", "artist/2/related", {})
        self.assertEqual(len(fake.calls), 1)          # второй запрос в паузе не ушёл
        clock.t += 6
        fake.fail = None
        engine.up.get("related", "artist/2/related", {})
        self.assertEqual(len(fake.calls), 2)

    def test_concurrent_identical_requests_are_coalesced(self):
        engine, fake, _ = make_engine(FakeDeezer(delay=0.15))
        out = []
        threads = [threading.Thread(target=lambda: out.append(
            engine.up.get("related", f"artist/{ZAYLO}/related", {"limit": 25}, budget=3))) for _ in range(6)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(fake.count("related"), 1)
        self.assertEqual(len(out), 6)
        self.assertTrue(all(o is not None for o in out))

    def test_sqlite_survives_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = tmp + "/reco.db"
            engine, fake, clock = make_engine(db=db)
            engine.up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
            second = reco.Upstream(FakeDeezer(fail=lambda p: RuntimeError("down")), db, clock, reco.Bucket(100, 100))
            data = second.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
            self.assertIsNotNone(data)
            self.assertEqual(len(second.dz_get.calls), 0)

    def test_unwritable_db_does_not_break_install_or_requests(self):
        # Кэш не критичен: недоступный путь не должен ронять импорт zizi_catalog (а с ним резолвер).
        with tempfile.TemporaryDirectory() as tmp:
            bad = tmp + "/no/such/dir/reco.db"
            up = reco.Upstream(FakeDeezer(), bad, Clock(), reco.Bucket(100, 100))
            self.assertEqual(up.stats()["db"], "off")
            self.assertGreaterEqual(up.stats()["db_errors"], 1)
            self.assertIsNotNone(up.get("related", f"artist/{ZAYLO}/related", {"limit": 25}))
            router = APIRouter(dependencies=["guard"])
            reco.install_routes(router, FakeDeezer(), dz_track, bad)       # не бросает
            handler = next(fn for p, fn, _ in router.routes if p == "/reco/home")
            self.assertEqual(handler(payload={"s": f"{ZAYLO}~1"})["contract"], 1)

    def test_db_failing_midflight_degrades_to_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeDeezer()
            up = reco.Upstream(fake, tmp + "/reco.db", Clock(), reco.Bucket(100, 100))
            self.assertEqual(up.stats()["db"], "on")
            def broken():
                raise sqlite3.OperationalError("database or disk is full")
            up._db = broken
            first = up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
            again = up.get("related", f"artist/{ZAYLO}/related", {"limit": 25})
            self.assertIsNotNone(first)
            self.assertEqual(first, again)
            self.assertEqual(fake.count("related"), 1)       # память держит, диск не нужен
            self.assertGreaterEqual(up.stats()["db_errors"], 2)


class HomeTests(unittest.TestCase):
    def setUp(self):
        self.engine, self.fake, self.clock = make_engine()
        self.result = self.engine.home(profile())

    def test_basic_shape(self):
        r = self.result
        self.assertEqual(r["contract"], 1)
        self.assertTrue(r["complete"])
        self.assertFalse(r["cold"])
        self.assertEqual([s["name"] for s in r["seeds"]], ["Zaylo", "DJ Samir"])
        ids = [s["id"] for s in r["shelves"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue({"station", "fresh", "artists", "start"} <= set(ids), ids)
        json.dumps(r)

    def test_similar_shelves_anchor_on_seeds(self):
        similar = [s for s in self.result["shelves"] if s["id"].startswith("similar:")]
        self.assertEqual([s["anchor"]["name"] for s in similar], ["Zaylo", "DJ Samir"])
        for s in similar:
            self.assertGreaterEqual(len(s["items"]), 3)
            for card in s["items"]:
                self.assertEqual(card["kind"], "album")
                self.assertIn(card["label"], reco.TYPE_LABEL.values())
                self.assertTrue(card["art"].startswith("https://"))
                self.assertNotEqual(card["artist_id"], s["anchor"]["id"])   # не собственные альбомы сида

    def test_compilations_never_appear(self):
        for s in self.result["shelves"]:
            if s["kind"] == "albums":
                self.assertFalse([c for c in s["items"] if c["title"].startswith("Mix ")])

    def test_albums_are_not_repeated_across_similar_shelves(self):
        ids = [c["id"] for s in self.result["shelves"] if s["id"].startswith("similar:") for c in s["items"]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_artist_shelf_matches_independent_formula(self):
        rz = {a["id"]: i for i, a in enumerate(load("related_8815756.json")["data"])}
        rs = {a["id"]: i for i, a in enumerate(load("related_6833609.json")["data"])}
        fans = {}
        for name in ("related_8815756.json", "related_6833609.json"):
            for a in load(name)["data"]:
                fans[a["id"]] = a["nb_fan"]
        expected = {}
        for cid in set(rz) | set(rs):
            if str(cid) in (ZAYLO, SAMIR):
                continue
            total = 0.0
            if cid in rz:
                total += 1.0 * (1 + rz[cid]) ** -0.5
            if cid in rs:
                total += 0.7 * (1 + rs[cid]) ** -0.5
            expected[cid] = total * min(1.0, 0.6 + 0.4 * fans[cid] / 300.0)
        want = [str(c) for c, _ in sorted(expected.items(), key=lambda it: (-it[1], str(it[0])))][:12]
        got = [a["id"] for a in shelf(self.result, "artists")["items"]]
        self.assertEqual(got, want)

    def test_overlap_beats_single_seed_neighbour(self):
        got = [a["title"] for a in shelf(self.result, "artists")["items"]]
        # M4GN, NIGHTFXRCE, ICEDMANE, SCHWVFTY стоят в графе обоих сидов.
        self.assertIn("NIGHTFXRCE", got[:6])
        self.assertIn("M4GN", got[:6])

    def test_seeds_never_recommended_to_themselves(self):
        seeds = {ZAYLO, SAMIR}
        for sid in ("artists", "start"):
            for item in shelf(self.result, sid)["items"]:
                self.assertNotIn(item["id"] if item["kind"] == "artist" else item["artist_id"], seeds)
        for s in self.result["shelves"]:
            if s["id"].startswith("similar:"):
                self.assertFalse({c["artist_id"] for c in s["items"]} & seeds)

    def test_station_dedupes_versions_and_limits_artist(self):
        station = shelf(self.result, "station")["items"]
        self.assertGreaterEqual(len(station), 10)
        keys = [(t["artist_id"], reco.fold(reco.strip_version_phrases(reco.normalized(t["title"].split(" (")[0]))))
                for t in station]
        self.assertEqual(len(keys), len(set(keys)), keys)
        per = {}
        for t in station:
            per[t["artist_id"]] = per.get(t["artist_id"], 0) + 1
        self.assertLessEqual(max(per.values()), 2)
        self.assertGreaterEqual(len(per), 6)                      # станция разнообразна
        for a, b in zip(station, station[1:]):
            self.assertNotEqual(a["artist_id"], b["artist_id"])    # соседи-повторы штрафуются

    def test_station_has_no_internal_fields(self):
        for s in self.result["shelves"]:
            for item in s["items"]:
                self.assertNotIn("_short", item)
                self.assertNotIn("rank", item)
                self.assertNotIn("_value", item)

    def test_start_shelf_is_unknown_artists_one_track_each(self):
        start = shelf(self.result, "start")["items"]
        station_ids = {t["id"] for t in shelf(self.result, "station")["items"]}
        arts = [t["artist_id"] for t in start]
        self.assertEqual(len(arts), len(set(arts)))
        self.assertNotIn(ZAYLO, arts)
        self.assertNotIn(SAMIR, arts)
        self.assertFalse(station_ids & {t["id"] for t in start})

    def test_fresh_contains_new_ep_of_favourite_and_excludes_old(self):
        fresh = shelf(self.result, "fresh")["items"]
        titles = [c["title"] for c in fresh]
        self.assertIn("Only You Girl", titles)              # 2026-09-02, 30 дней
        self.assertNotIn("Sagittarius", titles)             # 2025
        self.assertNotIn("Ineligible", [c["title"] for c in fresh if c["released"] < "2026-08-01"])
        for c in fresh:
            self.assertLessEqual(reco.age_days(c["released"], NOW), reco.FRESH_DAYS)
        per = {}
        for c in fresh:
            per[c["artist_id"]] = per.get(c["artist_id"], 0) + 1
        self.assertLessEqual(max(per.values()), 2)

    def test_fresh_is_ordered_by_formula(self):
        fresh = shelf(self.result, "fresh")["items"]
        weight = {ZAYLO: 1.0, SAMIR: 0.7}
        related = {}
        for aid, name in ((ZAYLO, "related_8815756.json"), (SAMIR, "related_6833609.json")):
            for i, a in enumerate(load(name)["data"]):
                related.setdefault(str(a["id"]), []).append((weight[aid], i, a["nb_fan"]))
        def base(aid):
            if aid in weight:
                return 1.5 * weight[aid]
            return sum(w * (1 + i) ** -0.5 * min(1.0, 0.6 + 0.4 * f / 300.0) for w, i, f in related.get(aid, []))
        values = [base(c["artist_id"]) * math.exp(-reco.age_days(c["released"], NOW) / reco.FRESH_TAU) for c in fresh]
        self.assertEqual(values, sorted(values, reverse=True))

    def test_second_call_is_free(self):
        before = len(self.fake.calls)
        again = self.engine.home(profile())
        self.assertEqual(len(self.fake.calls), before)
        self.assertEqual(again, self.result)

    def test_changed_profile_reuses_graph_cache(self):
        before = (self.fake.count("related"), self.fake.count("radio"))
        self.engine.home(profile(v="slowed"))
        self.assertEqual((self.fake.count("related"), self.fake.count("radio")), before)

    def test_json_is_deterministic_within_a_day(self):
        engine2, _, _ = make_engine()
        self.assertEqual(json.dumps(engine2.home(profile()), sort_keys=True),
                         json.dumps(self.result, sort_keys=True))

    def test_rotation_next_day_keeps_membership_mostly(self):
        self.clock.t += 86400
        nxt = self.engine.home(profile())
        a = {t["id"] for t in shelf(self.result, "station")["items"]}
        b = {t["id"] for t in shelf(nxt, "station")["items"]}
        self.assertGreaterEqual(len(a & b), len(a) // 2)           # вкус не прыгает


class FilterTests(unittest.TestCase):
    def test_negative_artist_is_absent_everywhere(self):
        engine, _, _ = make_engine()
        r = engine.home(profile(x="NIGHTFXRCE|M4GN"))
        for s in r["shelves"]:
            for item in s["items"]:
                names = {reco.fold(item.get("subtitle") or ""), reco.fold(item.get("artist") or ""),
                         reco.fold(item.get("title") if item["kind"] == "artist" else "")}
                self.assertFalse(names & {"nightfxrce", "m4gn"}, (s["id"], item))

    def test_known_artists_are_not_suggested_as_new(self):
        engine, _, _ = make_engine()
        r = engine.home(profile(k="NIGHTFXRCE|M4GN|ICEDMANE"))
        titles = {a["title"] for a in shelf(r, "artists")["items"]}
        self.assertFalse(titles & {"NIGHTFXRCE", "M4GN", "ICEDMANE"})
        start = {t["artist"] for t in shelf(r, "start")["items"]}
        self.assertFalse(start & {"NIGHTFXRCE", "M4GN", "ICEDMANE"})

    def test_known_artist_is_demoted_not_removed_in_similar(self):
        engine, _, _ = make_engine()
        plain = engine.home(profile())
        marked = make_engine()[0].home(profile(k="DJ FKU"))
        def names(r):
            return [c["subtitle"] for c in shelf(r, "similar:" + SAMIR)["items"]]
        self.assertIn("DJ FKU", names(plain))
        if "DJ FKU" in names(marked):
            self.assertGreater(names(marked).index("DJ FKU"), names(plain).index("DJ FKU"))

    def test_negative_seed_is_dropped_from_seeds(self):
        engine, _, _ = make_engine()
        r = engine.home(profile(x=ZAYLO))
        self.assertEqual([s["name"] for s in r["seeds"]], ["DJ Samir"])

    def test_version_preference_changes_station(self):
        engine, _, _ = make_engine()
        slowed = engine.home(profile(v="slowed"))
        sped = make_engine()[0].home(profile(v="sped"))
        def share(r, fam):
            items = shelf(r, "station")["items"]
            return sum(1 for t in items if fam in reco.speed_family(reco.version_tags(t["title"]))) / len(items)
        self.assertGreater(share(slowed, reco.SLOWED), share(sped, reco.SLOWED))
        self.assertGreaterEqual(share(slowed, reco.SLOWED), 0.6)


class ResolveTests(unittest.TestCase):
    def test_name_must_match_exactly(self):
        engine, _, _ = make_engine()
        self.assertEqual(engine.resolve(("name", "zaylo"), 2)["id"], ZAYLO)      # не Waylon, не Saylo
        self.assertIsNone(engine.resolve(("name", "zayl"), 2))                    # поиск пуст
        search = {"data": [{"id": 1, "name": "Zaylo", "nb_fan": 3, "picture_big": "x"},
                           {"id": 2, "name": "ZAYLO", "nb_fan": 900, "picture_big": "y"}]}
        fresh, _, _ = make_engine()
        fresh.up.dz_get = lambda path, **p: search
        self.assertEqual(fresh.resolve(("name", "zaylo"), 2)["id"], "2")         # тёзка с большей аудиторией

    def test_homonym_choice_uses_fans_for_real_fixture(self):
        engine, _, _ = make_engine()
        self.assertEqual(engine.resolve(("name", "yasuharu takanashi"), 2)["id"], "1648806")

    def test_name_seed_flow(self):
        engine, _, _ = make_engine()
        r = engine.home(reco.parse_profile("Zaylo~1|DJ Samir~0.7"))
        # «DJ Samir» не найден фейковым поиском — остаётся один сид, и это нормальный частичный результат
        self.assertEqual([s["name"] for s in r["seeds"]], ["Zaylo"])
        self.assertTrue(shelf(r, "similar:" + ZAYLO))


class ResilienceTests(unittest.TestCase):
    def test_cold_profile_returns_empty_not_error(self):
        engine, _, _ = make_engine()
        r = engine.home(reco.parse_profile("Nobody Knows~1"))
        self.assertTrue(r["cold"])
        self.assertEqual(r["shelves"], [])

    def test_upstream_down_gives_empty_incomplete(self):
        engine, _, _ = make_engine(FakeDeezer(fail=lambda path: RuntimeError("down")))
        r = engine.home(profile())
        self.assertEqual(r["shelves"], [])
        self.assertFalse(r.get("complete", False) and r["shelves"])

    def test_partial_when_graph_fails_but_seed_resolves(self):
        engine, fake, _ = make_engine()
        def selective(path, **p):
            if path.endswith("/related"):
                raise RuntimeError("blip")
            return fake(path, **p)
        engine.up.dz_get = selective
        r = engine.home(profile())
        self.assertFalse(r["complete"])
        self.assertIsNotNone(shelf(r, "station"))               # радио живо без графа

    def test_deadline_returns_partial_and_next_call_completes(self):
        slow = FakeDeezer(delay=0.12)
        engine, _, _ = make_engine(slow)
        old = reco.DEADLINE_S
        reco.DEADLINE_S = 0.2
        try:
            engine.clock = time.time                     # реальные часы нужны дедлайну
            engine.up.clock = time.time
            t0 = time.time()
            r1 = engine.home(profile())
            self.assertLess(time.time() - t0, 1.5)
            self.assertFalse(r1["complete"])
        finally:
            reco.DEADLINE_S = old
        time.sleep(3.0)                                  # фоновые потоки достраивают кэш
        reco.DEADLINE_S = 20
        try:
            r2 = engine.home(profile())
        finally:
            reco.DEADLINE_S = old
        self.assertTrue(r2["complete"])
        self.assertTrue(shelf(r2, "similar:" + ZAYLO))

    def test_bad_rows_do_not_crash(self):
        engine, fake, _ = make_engine()
        fake.files[f"artist/{ZAYLO}/related"] = {"data": [None, {}, {"id": 5}, {"id": 6, "name": ""},
                                                           {"id": 7, "name": "Ok", "nb_fan": "many"}]}
        fake.files[f"artist/{ZAYLO}/radio"] = {"data": [None, {"id": 1}, {"id": 2, "artist": "x"}]}
        fake.files[f"artist/{ZAYLO}/albums"] = {"data": [{"id": 1}, None, {"id": 2, "record_type": "ep"}]}
        r = engine.home(profile(s=f"{ZAYLO}~1"))
        json.dumps(r)


class RouteTests(unittest.TestCase):
    def test_routes_are_installed_on_guarded_router(self):
        router = APIRouter(dependencies=["guard"])
        engine = reco.install_routes(router, FakeDeezer(), dz_track, None)
        paths = {p for p, _, _ in router.routes}
        self.assertEqual(paths, {"/reco/home", "/reco/feed", "/reco/health"})
        handler = next(fn for p, fn, _ in router.routes if p == "/reco/home")
        out = handler(payload={"s": f"{ZAYLO}~1", "k": "", "x": "", "r": "", "v": ""})
        self.assertEqual(out["contract"], 1)
        with self.assertRaises(HTTPException) as ctx:
            handler(payload={"s": ""})
        self.assertEqual(ctx.exception.status_code, 422)
        health = next(fn for p, fn, _ in router.routes if p == "/reco/health")()
        self.assertTrue(health["ok"])
        self.assertIs(reco.ENGINE, engine)

    def test_profile_travels_in_post_body_never_in_the_url(self):
        # access-лог uvicorn пишет путь с query; профиль вкуса там быть не должен.
        router = APIRouter(dependencies=["guard"])
        reco.install_routes(router, FakeDeezer(), dz_track, None)
        self.assertIn(("POST", "/reco/home"), router.methods)
        self.assertNotIn(("GET", "/reco/home"), router.methods)
        self.assertEqual([m for m, p in router.methods if p == "/reco/home"], ["POST"])
        self.assertEqual([m for m, p in router.methods if p == "/reco/feed"], ["POST"])

    def test_body_validation(self):
        def code(payload):
            with self.assertRaises(HTTPException) as ctx:
                reco.profile_from_body(payload)
            return ctx.exception.status_code
        for bad in (None, [], "s=1", 42):
            self.assertEqual(code(bad), 422, bad)                       # тело должно быть объектом
        self.assertEqual(code({"s": 123}), 422)                         # поля — только строки
        self.assertEqual(code({"s": ["a"]}), 422)
        self.assertEqual(code({"v": "x" * 9}), 422)                     # пофилдовые пределы
        self.assertEqual(code({"s": "a" * 1201}), 422)
        self.assertEqual(code({"s": "a" * 1200, "k": "b" * 1400, "x": "c" * 500, "r": "d" * 300}), 422)  # сумма > 3200
        ok = reco.profile_from_body({"s": f"{ZAYLO}~1|{SAMIR}~0.7", "unknown": "ignored", "v": "slowed"})
        self.assertEqual([ref for ref, _ in ok.seeds], [("id", str(ZAYLO)), ("id", str(SAMIR))])
        self.assertEqual(ok.version, "slowed")
        self.assertEqual(reco.profile_from_body({}).seeds, [])          # пустое тело = пустой профиль (роут даст 422)

    def test_guard_covers_reco_paths(self):
        import zizi_guard as g
        self.assertEqual(g.class_of("/reco/home"), "catalog")
        self.assertEqual(g.class_of("/reco/feed"), "catalog")
        guard = g.Guard(token="secret", mode="require")
        denied = guard.admit(path="/reco/home", authorization=None, q_token=None, install_id=None, client_ip="9.9.9.9")
        self.assertFalse(denied.allowed)

    def test_wired_into_catalog(self):
        text = (HERE.parent / "zizi_catalog.py").read_text(encoding="utf-8")
        self.assertIn('"reco_contract": RECO_CONTRACT', text)   # деплой проверяет живые роуты по /catalog/health
        self.assertIn('"reco_feed": RECO_FEED', text)
        self.assertIn("from zizi_reco import install_routes as _install_reco_routes", text)
        self.assertIn("_install_reco_routes(router, dz_get, dz_track", text)


class CatalogHookTests(unittest.TestCase):
    """Реальный zizi_catalog в отдельном процессе: Reco — надстройка и не вправе ронять резолвер."""
    PROBE = r'''
import json, os, sys, tempfile
tmp = tempfile.mkdtemp()
os.environ["ZIZI_CATALOG_DB"] = os.path.join(tmp, "catalog.db")
os.environ["ZIZI_IMG_DIR"] = os.path.join(tmp, "img"); os.makedirs(os.environ["ZIZI_IMG_DIR"])
mode, stub, server, broken_dir = sys.argv[1:5]
sys.path.insert(0, stub); sys.path.insert(0, server)
if mode == "absent":
    sys.modules["zizi_reco"] = None                 # import zizi_reco -> ImportError
elif mode == "broken":
    sys.path.insert(0, broken_dir)                  # свой zizi_reco.py, падающий на импорте
elif mode == "unwritable":
    os.environ["ZIZI_RECO_DB"] = "/no/such/dir/reco.db"
import zizi_catalog as zc
routes = {p: fn for p, fn, _ in zc.router.routes}
print(json.dumps({"contract": zc.RECO_CONTRACT, "reco_routes": sorted(p for p in routes if p.startswith("/reco")),
                  "health": routes["/catalog/health"]().get("reco_contract"),
                  "browse_still_there": "/catalog/browse" in routes}))
'''

    def probe(self, mode):
        import subprocess
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "zizi_reco.py").write_text('raise RuntimeError("boom at import")\n')
            out = subprocess.run([sys.executable, "-c", self.PROBE, mode, str(HERE / "_stub"), str(HERE.parent), tmp],
                                 capture_output=True, text=True, timeout=60)
        self.assertEqual(out.returncode, 0, out.stderr[-600:])      # импорт каталога обязан состояться
        return json.loads(out.stdout.strip().splitlines()[-1]), out.stderr

    def test_ok(self):
        res, _ = self.probe("ok")
        self.assertEqual(res["contract"], 1)
        self.assertEqual(res["health"], 1)
        self.assertEqual(res["reco_routes"], ["/reco/feed", "/reco/health", "/reco/home"])

    def test_module_absent_resolver_still_starts(self):
        res, err = self.probe("absent")
        self.assertEqual((res["contract"], res["health"], res["reco_routes"]), (0, 0, []))
        self.assertTrue(res["browse_still_there"])
        self.assertIn("reco disabled", err)                         # причина видна в журнале

    def test_module_broken_resolver_still_starts(self):
        res, err = self.probe("broken")
        self.assertEqual((res["contract"], res["health"], res["reco_routes"]), (0, 0, []))
        self.assertTrue(res["browse_still_there"])
        self.assertIn("boom at import", err)

    def test_unwritable_cache_path_keeps_reco_on(self):
        res, _ = self.probe("unwritable")
        self.assertEqual((res["contract"], res["health"]), (1, 1))  # кэш в памяти, фича жива


if __name__ == "__main__":
    unittest.main(verbosity=1)
