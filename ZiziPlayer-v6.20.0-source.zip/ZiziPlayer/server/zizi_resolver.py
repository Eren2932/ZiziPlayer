#!/usr/bin/env python3
"""
ZiziResolve 1.3 — резолвер аудио-потоков для ZiziPlayer.

ЗАЧЕМ 1.2 (всё по живым замерам с сервера 147.45.166.244):

  Мы выяснили, что у нас два выхода в интернет и у каждого своя болезнь:

    прямой  (IP сервера, RU-паспорт) → бот-чек ПРОХОДИТ, часть треков даёт 451 гео
    прокси  (VLESS-узел NL/EE/US/FR) → гео ЧИСТОЕ, но часть узлов ловит бот-чек

  Поэтому 1.2 не выбирает один маршрут, а использует оба по назначению:

    1) резолвим НАПРЯМУЮ (быстро, VPN-трафик не тратится);
    2) получили 451 / 404 / 402 → тот же трек переспрашиваем ЧЕРЕЗ ПРОКСИ;
    3) прошло через прокси → помечаем трек via=proxy и байты для него тоже
       льём через прокси (googlevideo привязывает ссылку к IP того, кто
       её попросил — иначе прилетит 403);
    4) не прошло нигде → отдаём приложению приговор с ПРЯМОГО пути
       (он честнее: "заблокирован в регионе", а не "бот-чек" от чужого узла).

  Прочее против 1.1:
    • geo_bypass выключен — Google закрыл трюк с X-Forwarded-For, он только жрал время
    • /stats — сколько треков ушло прямым путём, сколько через прокси, сколько отказов
    • via в ответе /resolve — видно маршрут, удобно для диагностики в приложении

Переменные окружения (/opt/zizi/zizi.env):
    ZIZI_TOKEN=...                       обязательный токен доступа
    ZIZI_PROXY=socks5h://127.0.0.1:1080  выход через xray; пусто = прокси выключен
    ZIZI_PROXY_MODE=fallback             fallback (по умолчанию) | always | off
    ZIZI_CACHE_TTL=10800                 3 часа на удачные резолвы
    ZIZI_NEG_TTL=600                     10 минут на приговоры
    ZIZI_COOKIES=/opt/zizi/cookies.txt   куки левого аккаунта, если понадобятся
    ZIZI_POT_URL=http://127.0.0.1:4416   bgutil POT-провайдер, если понадобится

Запуск: uvicorn zizi_resolver:app --host 0.0.0.0 --port 8080
"""

import os
import re
import time
import hmac
import asyncio
import logging
from typing import Optional, Dict, Any, List, Tuple

import httpx
from fastapi import FastAPI, HTTPException, Query, Header, Request
from fastapi.responses import JSONResponse, StreamingResponse
from yt_dlp import YoutubeDL

# ── Конфиг ───────────────────────────────────────────────────────────────────
API_TOKEN = os.environ.get("ZIZI_TOKEN", "")
_token_warned = False
CACHE_TTL = int(os.environ.get("ZIZI_CACHE_TTL", "10800"))
NEG_TTL = int(os.environ.get("ZIZI_NEG_TTL", "600"))
# Мягкий приговор: причина неизвестна или зависит от узла прокси. Живёт минуту,
# чтобы смена узла/патч сразу вступали в силу, а не через 10 минут.
NEG_TTL_SOFT = int(os.environ.get("ZIZI_NEG_TTL_SOFT", "60"))
# Проверять существование трека через oembed перед приговором "удалён".
OEMBED_CHECK = os.environ.get("ZIZI_OEMBED_CHECK", "1").lower() not in ("0", "false", "no")
PROXY_CHUNK = 256 * 1024
COOKIES_FILE = os.environ.get("ZIZI_COOKIES", "")
PO_PROVIDER = os.environ.get("ZIZI_POT_URL", "")
OUT_PROXY = os.environ.get("ZIZI_PROXY", "").strip()
PROXY_MODE = os.environ.get("ZIZI_PROXY_MODE", "fallback").strip().lower()
CLIENTS = os.environ.get(
    "ZIZI_CLIENTS", "ios_music,ios,visionos,tv,android_vr,web_music"
).split(",")

# Коды, при которых имеет смысл переспросить через прокси.
# 6.19.3: список стал НАСТРАИВАЕМЫМ и по умолчанию УЗКИМ.
#
# Замер 30.08 (сутки логов): 114 отказов 404, 15 × 451, 12 × 502, 3 × 403. Старый список
# (451,404,402,502) означал, что каждый из этих 141 отказов задавался YouTube ДВА раза — прямо и
# через прокси. Это 282 запроса на 141 трек с одного IP, который уже отвечает нам 429 Too Many
# Requests. Второй вопрос имеет смысл ровно тогда, когда прокси даёт ДРУГОЙ гео-паспорт; при
# geo_ok=false он не лечит ничего и только приближает бан. 404 и 502 убраны из значения по
# умолчанию: включи их обратно (ZIZI_RETRY_CODES=451,404,402,502), когда /geo скажет geo_ok=true.
RETRY_VIA_PROXY = tuple(
    int(c) for c in re.split(r"[,\s]+", os.environ.get("ZIZI_RETRY_CODES", "451,402").strip())
    if c.isdigit()
)
# Визитор-данные браузерной сессии. С ними web_safari/mweb перестают быть «пустыми» клиентами.
VISITOR_DATA = os.environ.get("ZIZI_VISITOR_DATA", "").strip()
# player_skip=configs экономил один запрос, но заодно лишал yt-dlp конфигурации плеера, из которой
# берутся визитор-данные. С PO-провайдером экономия не нужна: ZIZI_PLAYER_SKIP=configs вернёт как было.
PLAYER_SKIP = [x for x in re.split(r"[,\s]+", os.environ.get("ZIZI_PLAYER_SKIP", "").strip()) if x]
# Пауза после 429: сколько секунд не трогать YouTube прямым путём.
THROTTLE_COOLDOWN = int(os.environ.get("ZIZI_THROTTLE_COOLDOWN", "300"))

if not OUT_PROXY:
    PROXY_MODE = "off"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("zizi")

app = FastAPI(title="ZiziResolve", version="1.4")

_cache: Dict[str, Dict[str, Any]] = {}
_neg: Dict[str, Dict[str, Any]] = {}
_locks: Dict[str, asyncio.Lock] = {}
_clients: Dict[bool, Optional[httpx.AsyncClient]] = {False: None, True: None}
# 6.18.0: фоновые задачи прогрева. asyncio хранит на задачу только СЛАБУЮ ссылку — задача без
# внешней ссылки может быть собрана сборщиком мусора прямо посреди работы, и /prefetch тогда
# «иногда не греет» без единой строчки в логе. Держим их здесь и убираем по завершении.
_warm_tasks: set = set()
# Порог уборки словарей. Ключи протухают по времени, но САМИ СЛОВАРИ никто не чистил: id, который
# больше не спросят, оставался в _cache/_neg/_locks до перезапуска. Один asyncio.Lock — это ~500
# байт; на живом сервере с тысячами треков в сутки это медленно растущая утечка.
GC_INTERVAL = int(os.environ.get("ZIZI_GC_INTERVAL", "300"))
_stat = {"direct": 0, "proxy": 0, "failed": 0, "cache_hits": 0,
         "soft_neg": 0, "hard_neg": 0, "throttled": 0}
# 6.19.3: 429 — это состояние ВЫХОДА, а не свойство трека. Пока он держится, прямой путь
# бессмысленен: каждый новый запрос продлевает наказание. Помним до какого времени.
_throttle: Dict[str, float] = {"direct": 0.0, "proxy": 0.0}


def _throttled(via_proxy: bool) -> bool:
    return time.time() < _throttle["proxy" if via_proxy else "direct"]


# ── HTTP-клиенты: один прямой, один через прокси. Оба жёстко IPv4 ────────────
def get_client(via_proxy: bool) -> httpx.AsyncClient:
    """Отдельный keep-alive клиент на каждый маршрут: TLS-хендшейк к
    googlevideo делается один раз, а не на каждое нажатие."""
    cl = _clients.get(via_proxy)
    if cl is None or cl.is_closed:
        transport = httpx.AsyncHTTPTransport(
            local_address="0.0.0.0",   # без этого httpx уходит в IPv6, где YouTube душит
            retries=1,
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32,
                                keepalive_expiry=60.0),
        )
        cl = httpx.AsyncClient(
            transport=transport,
            # 6.19.0: read=None здесь означало «ждать байт от googlevideo бесконечно».
            #
            # Соединение, которое замолчало и не закрылось (а именно так ведёт себя половина
            # разрывов на мобильной сети со стороны CDN), держало корутину, слот из 64 соединений и
            # открытый сокет до перезапуска процесса. Десяток таких — и сервер отвечает 503 всем,
            # оставаясь при этом «живым» по /health. 90 секунд — заведомо больше любой честной
            # паузы между чанками аудио и заведомо меньше вечности.
            timeout=httpx.Timeout(20.0, connect=10.0, read=90.0),
            follow_redirects=True,
            proxy=(OUT_PROXY if via_proxy else None),
            headers={"User-Agent": "Mozilla/5.0", "Accept": "*/*"},
        )
        _clients[via_proxy] = cl
    return cl


@app.on_event("startup")
async def _startup():
    """Периодическая уборка. Одна корутина раз в 5 минут дешевле, чем проверка возраста на
    каждом запросе, и не трогает горячий путь резолва вообще."""
    async def gc_loop():
        while True:
            await asyncio.sleep(GC_INTERVAL)
            try:
                now = time.time()
                for vid, item in list(_cache.items()):
                    if now > item.get("cached_until", 0):
                        _cache.pop(vid, None)
                for vid, item in list(_neg.items()):
                    if now > item.get("until", 0):
                        _neg.pop(vid, None)
                # Замок удаляем только свободный: занятый означает, что прямо сейчас кто-то
                # резолвит этот id, и подмена замка пустила бы второй yt-dlp по тому же треку.
                for vid, lock in list(_locks.items()):
                    if not lock.locked() and vid not in _cache and vid not in _neg:
                        _locks.pop(vid, None)
            except Exception as e:  # уборка никогда не должна ронять сервис
                log.warning("gc: %s", e)

    task = asyncio.create_task(gc_loop())
    _warm_tasks.add(task)
    task.add_done_callback(_warm_tasks.discard)


@app.on_event("shutdown")
async def _shutdown():
    for task in list(_warm_tasks):
        task.cancel()
    _warm_tasks.clear()
    for cl in _clients.values():
        if cl and not cl.is_closed:
            await cl.aclose()


# ── Классификация ошибок yt-dlp ──────────────────────────────────────────────
# Формулировки гео-блока. Прежний шаблон "not available in your country" НЕ ловил
# реальный текст YouTube: "The uploader has NOT MADE THIS VIDEO available in your
# country" — там между "not" и "available" стоят три слова. Замер 29.08.
_GEO_MARKERS = (
    "in your country",
    "in this country",
    "uploader has not made this video available",
    "you might want to use a vpn",
    "this video is available in ",     # yt-dlp печатает список разрешённых стран
    "error code: 152",
)

# Невнятное "недоступно" без указания причины. Такое отдают в том числе art-track'и
# (каналы "- Topic"), закрытые для страны сервера: они НЕ говорят про country.
_AMBIGUOUS_MARKERS = (
    "video unavailable",
    "video is not available",
    "video is unavailable",
    "error code: 152",
    "no audio url in extractor output",
)

# Однозначная смерть трека: тут oembed спрашивать не надо.
_DEAD_MARKERS = (
    "private video",
    "removed by the uploader",
    "account associated",
    "terminated",
    "has been removed",
)


def classify(msg: str) -> int:
    m = msg.lower()
    # 6.19.3: 429 проверяем самым первым. Раньше "Too Many Requests" не попадал ни в один шаблон
    # и уходил в 502 — то есть в код, который старый RETRY_VIA_PROXY переспрашивал через прокси.
    # Нас лимитируют, а мы в ответ удваиваем запросы: ровно то, что видно в логах 30.08.
    if "429" in m and "too many requests" in m:
        return 429
    # Бот-чек проверяем первым: его текст не содержит слов про страну.
    if "sign in to confirm" in m or "not a bot" in m or "login_required" in m:
        return 403
    if any(s in m for s in _GEO_MARKERS):
        return 451
    if "members-only" in m or "premium" in m:
        return 402
    if any(s in m for s in _DEAD_MARKERS) or any(s in m for s in _AMBIGUOUS_MARKERS):
        return 404
    return 502


def _looks_ambiguous(msg: str) -> bool:
    """Отказ вида "Video unavailable" без причины: виноват может быть и трек,
    и наш маршрут. Такому приговору нельзя верить без проверки."""
    m = msg.lower()
    if any(s in m for s in _DEAD_MARKERS):
        return False
    return any(s in m for s in _AMBIGUOUS_MARKERS)


_OEMBED_URL = ("https://www.youtube.com/oembed"
               "?url=https://www.youtube.com/watch?v={}&format=json")


async def _video_exists(video_id: str) -> Optional[bool]:
    """True  — трек существует (oembed 200): значит "удалён" был бы враньём.
    False — трек удалён/приватный (oembed 401/404): приговор честный.
    None  — спросить не удалось.
    oembed отвечает без JS, без аттестации и без учёта гео — идеальный арбитр."""
    if not OEMBED_CHECK:
        return None
    try:
        r = await get_client(False).get(
            _OEMBED_URL.format(video_id),
            # 6.19.0: свой User-Agent. Общий клиент представляется «Mozilla/5.0» — обрубком,
            # который выдаёт себя за браузер и не является им. Именно такие UA попадают под
            # эвристики первыми, а oembed здесь работает арбитром: если его начнут отшивать,
            # приложение станет врать «трек удалён» о живых треках.
            headers={"User-Agent": "ZiziResolver/6.19 (+oembed-verify)"},
            timeout=httpx.Timeout(6.0, connect=4.0, read=6.0))
        if r.status_code == 200:
            return True
        if r.status_code in (400, 401, 403, 404):
            return False
    except Exception as e:
        log.info("oembed %s не ответил (%s)", video_id, type(e).__name__)
    return None


def human(code: int) -> str:
    return {
        429: "источник временно лимитирует сервер, попробуй через минуту",
        451: "трек недоступен из региона сервера",
        403: "YouTube требует вход (бот-чек)",
        404: "трек удалён или закрыт",
        402: "трек только для подписчиков/участников",
    }.get(code, "источник не отдал поток")


# ── Кэш ──────────────────────────────────────────────────────────────────────
def _cache_get(video_id: str) -> Optional[Dict[str, Any]]:
    item = _cache.get(video_id)
    if not item:
        return None
    if time.time() > item["cached_until"]:
        _cache.pop(video_id, None)
        return None
    return item


def _neg_get(video_id: str) -> Optional[Dict[str, Any]]:
    item = _neg.get(video_id)
    if not item:
        return None
    if time.time() > item["until"]:
        _neg.pop(video_id, None)
        return None
    return item


# ── yt-dlp ───────────────────────────────────────────────────────────────────
def _ydl_opts(via_proxy: bool) -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        # m4a (itag 140) первым: Media3 декодирует быстрее, есть почти всегда
        "format": "bestaudio[ext=m4a]/bestaudio[acodec^=opus]/bestaudio/best",
        "socket_timeout": 20,
        "retries": 2,
        "extractor_retries": 1,
        # ВАЖНО: кэш плееров отдельный на каждый маршрут, иначе визитор-данные
        # с RU-паспортом утекают в прокси-запрос и гео-обход не срабатывает
        "cachedir": "/opt/zizi/ytdlp-cache/" + ("proxy" if via_proxy else "direct"),
        "extractor_args": {
            "youtube": {
                "player_client": [c.strip() for c in CLIENTS if c.strip()],
            }
        },
    }
    if via_proxy:
        opts["proxy"] = OUT_PROXY
    else:
        opts["source_address"] = "0.0.0.0"   # прямой путь — только IPv4
    if COOKIES_FILE and os.path.exists(COOKIES_FILE):
        opts["cookiefile"] = COOKIES_FILE
    yt = opts["extractor_args"]["youtube"]
    if PLAYER_SKIP:
        yt["player_skip"] = PLAYER_SKIP
    if VISITOR_DATA:
        yt["visitor_data"] = [VISITOR_DATA]
    if PO_PROVIDER:
        opts["extractor_args"]["youtubepot-bgutilhttp"] = {"base_url": [PO_PROVIDER]}
    return opts


def _extract(video_id: str, via_proxy: bool) -> Dict[str, Any]:
    url = f"https://www.youtube.com/watch?v={video_id}"
    with YoutubeDL(_ydl_opts(via_proxy)) as ydl:
        info = ydl.extract_info(url, download=False)

    audio = [f for f in info.get("formats", [])
             if f.get("acodec") not in (None, "none")
             and f.get("vcodec") in ("none", None)
             and f.get("url")]
    audio.sort(key=lambda f: (f.get("ext") == "m4a", f.get("abr") or 0), reverse=True)
    fmt = audio[0] if audio else {"url": info.get("url"), "abr": info.get("abr"),
                                  "ext": info.get("ext")}
    if not fmt.get("url"):
        raise RuntimeError("no audio url in extractor output")

    ext = (fmt.get("ext") or "webm").lower()
    ctype = "audio/mp4" if ext in ("m4a", "mp4") else "audio/webm"
    return {
        "id": video_id,
        "title": info.get("title"),
        "artist": info.get("artist") or info.get("uploader"),
        "duration": info.get("duration"),
        "url": fmt["url"],
        "mime": ext,
        "content_type": ctype,
        "abr": fmt.get("abr"),
        "filesize": fmt.get("filesize") or fmt.get("filesize_approx"),
        "via": "proxy" if via_proxy else "direct",
        "resolved_at": int(time.time()),
        "cached_until": time.time() + CACHE_TTL,
    }


def _routes_possible() -> List[bool]:
    return [False, True] if OUT_PROXY else [False]


def _routes() -> List[bool]:
    """Порядок маршрутов: False = прямой, True = через прокси."""
    if PROXY_MODE == "always":
        return [True]
    if PROXY_MODE == "off":
        return [False]
    return [False, True]          # fallback


async def _try_route(video_id: str, via_proxy: bool) -> Tuple[Optional[Dict[str, Any]], Optional[int], str]:
    t0 = time.time()
    try:
        data = await asyncio.to_thread(_extract, video_id, via_proxy)
        log.info("resolved %s via %s in %.1fs (%s, %skbps)", video_id,
                 data["via"], time.time() - t0, data["mime"], data.get("abr"))
        return data, None, ""
    except Exception as e:
        code = classify(str(e))
        log.warning("resolve %s via %s failed [%s] %.1fs: %s", video_id,
                    "proxy" if via_proxy else "direct", code, time.time() - t0,
                    str(e)[:200])
        return None, code, str(e)


async def _resolve_cached(video_id: str) -> Dict[str, Any]:
    hit = _cache_get(video_id)
    if hit:
        _stat["cache_hits"] += 1
        return hit
    neg = _neg_get(video_id)
    if neg:
        raise HTTPException(status_code=neg["code"], detail=neg["detail"])

    lock = _locks.setdefault(video_id, asyncio.Lock())
    async with lock:
        hit = _cache_get(video_id)
        if hit:
            _stat["cache_hits"] += 1
            return hit
        neg = _neg_get(video_id)
        if neg:
            raise HTTPException(status_code=neg["code"], detail=neg["detail"])

        first_code: Optional[int] = None
        first_raw: str = ""

        routes = _routes()
        # Прямой путь под лимитом — начинаем с прокси, если он есть. Это не «обход блокировки»,
        # это уважение к 429: выход, которому сказали «слишком часто», надо оставить в покое.
        if routes and routes[0] is False and _throttled(False) and True in _routes_possible():
            routes = [True] + [r for r in routes if r is not True]
            log.info("resolve %s: прямой путь под 429-паузой, идём сразу через прокси", video_id)

        for via_proxy in routes:
            if _throttled(via_proxy):
                if first_code is None:
                    first_code, first_raw = 429, "throttled route skipped"
                continue
            # На прокси идём только если прямой путь дал именно тот отказ,
            # который прокси лечит. Бот-чек (403) прокси не лечит — там наш
            # прямой IP как раз сильнее.
            if via_proxy and first_code is not None and first_code not in RETRY_VIA_PROXY:
                break

            data, code, raw = await _try_route(video_id, via_proxy)
            if code == 429:
                _throttle["proxy" if via_proxy else "direct"] = time.time() + THROTTLE_COOLDOWN
                _stat["throttled"] += 1
                log.warning("429 на маршруте %s: пауза %s с",
                            "proxy" if via_proxy else "direct", THROTTLE_COOLDOWN)
            if data:
                _stat["proxy" if via_proxy else "direct"] += 1
                _cache[video_id] = data
                return data
            if first_code is None:
                first_code, first_raw = code, raw

        # Приговор берём с ПЕРВОГО (прямого) пути: он честнее для пользователя
        code = first_code or 502
        # 429 — это про нас, а не про трек: запоминать приговор надолго нельзя вообще.
        soft = code in (451, 429)   # гео зависит от узла прокси — не запоминаем надолго

        # Арбитраж: не имеем права говорить "удалён", не спросив oembed.
        if code in (404, 502) and _looks_ambiguous(first_raw):
            exists = await _video_exists(video_id)
            if exists is True:
                code, soft = 451, True
                log.info("verdict %s: oembed=200 → трек жив, значит это регион/клиент, "
                         "а не удаление", video_id)
            elif exists is False:
                log.info("verdict %s: oembed=404 → трек действительно удалён", video_id)
            else:
                soft = True         # арбитр молчит — верить приговору нельзя
                log.info("verdict %s: oembed не ответил → приговор мягкий", video_id)

        ttl = NEG_TTL_SOFT if soft else NEG_TTL
        detail = human(code)
        _neg[video_id] = {"code": code, "detail": detail,
                          "until": time.time() + ttl, "soft": soft}
        _stat["failed"] += 1
        _stat["soft_neg" if soft else "hard_neg"] += 1
        raise HTTPException(status_code=code, detail=detail)


def _check_token(header: Optional[str], q_token: Optional[str]) -> None:
    if not API_TOKEN:
        # 6.19.0: пустой ZIZI_TOKEN — это открытый наружу резолвер, и молчать об этом нельзя.
        # Раньше отсутствие токена выглядело в логах ровно как его наличие, то есть никак:
        # человек, забывший переменную окружения при переносе на новый сервер, узнавал об этом
        # по трафику. Предупреждение один раз за жизнь процесса, не на каждый запрос.
        global _token_warned
        if not _token_warned:
            _token_warned = True
            log.warning("ZIZI_TOKEN не задан: /resolve, /prefetch и /stream открыты всем, "
                        "кто знает адрес. Для домашнего сервера в локальной сети это нормально, "
                        "для публичного адреса — нет.")
        return
    supplied = None
    if header and header.lower().startswith("bearer "):
        supplied = header[7:].strip()
    supplied = supplied or q_token
    # hmac.compare_digest, а не «!=»: обычное сравнение строк выходит на первом несовпавшем байте,
    # и время ответа подсказывает, сколько символов угадано. Через сеть шум велик, но защита
    # ничего не стоит — не отдавать этот сигнал вообще правильнее, чем спорить, хватит ли его.
    if not hmac.compare_digest(str(supplied or ""), API_TOKEN):
        raise HTTPException(status_code=401, detail="bad token")


def _public(d: Dict[str, Any], cached: bool) -> Dict[str, Any]:
    out = {k: v for k, v in d.items() if k != "cached_until"}
    out["cached"] = cached
    return out


# ── Эндпоинты ────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"ok": True, "version": "1.4", "cache": len(_cache), "neg": len(_neg),
            "proxy": bool(OUT_PROXY), "proxy_mode": PROXY_MODE,
            "cookies": bool(COOKIES_FILE and os.path.exists(COOKIES_FILE)),
            "pot": bool(PO_PROVIDER), "clients": CLIENTS,
            "oembed_check": OEMBED_CHECK, "neg_ttl": NEG_TTL,
            "neg_ttl_soft": NEG_TTL_SOFT,
            "retry_codes": list(RETRY_VIA_PROXY),
            "visitor_data": bool(VISITOR_DATA),
            "player_skip": PLAYER_SKIP,
            "throttled": {k: max(0, int(v - time.time())) for k, v in _throttle.items()},
            "ts": int(time.time())}


@app.get("/stats")
async def stats(token: Optional[str] = Query(None),
                authorization: Optional[str] = Header(None)):
    _check_token(authorization, token)
    total = _stat["direct"] + _stat["proxy"] + _stat["failed"]
    pct = (lambda n: round(100.0 * n / total, 1) if total else 0.0)
    return {
        "resolved_direct": _stat["direct"],
        "resolved_proxy": _stat["proxy"],
        "failed": _stat["failed"],
        "cache_hits": _stat["cache_hits"],
        "share_direct_pct": pct(_stat["direct"]),
        "share_proxy_pct": pct(_stat["proxy"]),
        "share_failed_pct": pct(_stat["failed"]),
        "cache_size": len(_cache),
        "neg_size": len(_neg),
        "soft_neg": _stat["soft_neg"],
        "hard_neg": _stat["hard_neg"],
        "throttle_events": _stat["throttled"],
        "throttled_now": {k: max(0, int(v - time.time())) for k, v in _throttle.items()},
        "verdicts": {k: v["code"] for k, v in list(_neg.items())[:40]},
    }


@app.get("/resolve")
async def resolve(id: str = Query(..., min_length=5, max_length=32),
                  token: Optional[str] = Query(None),
                  authorization: Optional[str] = Header(None)):
    _check_token(authorization, token)
    had = _cache_get(id) is not None
    data = await _resolve_cached(id)
    # 6.19.0: Cache-Control: no-store.
    #
    # В ответе лежит подписанная ссылка на googlevideo, привязанная к IP этого сервера и живущая
    # несколько часов. Без явного запрета её имеет право положить себе любой прокси по пути и любой
    # CDN перед сервером — а отданная не тому, кому её выдали, она либо не работает, либо работает,
    # и второе хуже. no-store, а не no-cache: no-cache разрешает хранить, но требует
    # перепроверять; хранить тут нельзя вообще.
    return JSONResponse(_public(data, had), headers={"Cache-Control": "no-store"})


@app.get("/prefetch")
async def prefetch(ids: str = Query(..., max_length=512),
                   token: Optional[str] = Query(None),
                   authorization: Optional[str] = Header(None)):
    """Прогрев очереди: приложение шлёт id следующих 2-3 треков.
    Отвечает сразу, резолвит в фоне — ожидание yt-dlp уезжает из тракта."""
    _check_token(authorization, token)
    wanted: List[str] = [x for x in re.split(r"[,\s]+", ids) if 5 <= len(x) <= 32][:5]

    async def warm(vid: str):
        try:
            await _resolve_cached(vid)
        except Exception:
            pass

    for vid in wanted:
        if not _cache_get(vid) and not _neg_get(vid):
            task = asyncio.create_task(warm(vid))
            # Ссылку держим до конца работы: иначе задача существует только в слабой ссылке
            # цикла событий и может исчезнуть до первого await.
            _warm_tasks.add(task)
            task.add_done_callback(_warm_tasks.discard)
    return {"queued": wanted, "cache": len(_cache), "warming": len(_warm_tasks)}


@app.get("/geo")
async def geo(token: Optional[str] = Query(None),
              authorization: Optional[str] = Header(None)):
    """Что YouTube думает о стране каждого нашего выхода.

    ipinfo врёт: узел, который он считает американским, Google может считать
    российским. Единственный честный источник — поле "GL" в HTML главной
    youtube.com. Замер 29.08: direct GL=RU, proxy GL=RU при ipinfo=US."""
    _check_token(authorization, token)
    out: Dict[str, Any] = {}
    for via_proxy in ([False, True] if OUT_PROXY else [False]):
        key = "proxy" if via_proxy else "direct"
        try:
            r = await get_client(via_proxy).get(
                "https://www.youtube.com/",
                timeout=httpx.Timeout(15.0, connect=8.0, read=15.0))
            m = re.search(r'"GL"\s*:\s*"([A-Z]{2})"', r.text or "")
            out[key] = {"gl": m.group(1) if m else None, "http": r.status_code}
        except Exception as e:
            out[key] = {"gl": None, "error": type(e).__name__}
    proxy_gl = (out.get("proxy") or {}).get("gl")
    out["geo_ok"] = bool(proxy_gl and proxy_gl != "RU")
    out["hint"] = ("гео чистое, 451 должны лечиться" if out["geo_ok"]
                   else "выход не даёт не-RU паспорт — гео-блоки не вылечить")
    return out


@app.get("/flush")
async def flush(token: Optional[str] = Query(None),
                authorization: Optional[str] = Header(None),
                neg_only: int = Query(1)):
    """Сброс приговоров (и, если neg_only=0, всего кэша).
    Нужен после смены узла прокси: старые 451 больше не актуальны."""
    _check_token(authorization, token)
    n = len(_neg)
    _neg.clear()
    c = 0
    if not neg_only:
        c = len(_cache)
        _cache.clear()
    # 6.18.0: /flush зовут ровно тогда, когда сменили узел прокси. Сбросить приговоры и оставить
    # keep-alive соединения, приклеенные к СТАРОМУ узлу, — значит «почистить» и продолжить ходить
    # там же. Клиенты закрываются здесь же, следующий запрос поднимет их заново, уже с текущим
    # ZIZI_PROXY. Замки не трогаем: занятый резолв должен доработать на своём соединении.
    closed = 0
    for key, cl in list(_clients.items()):
        if cl is not None and not cl.is_closed:
            try:
                await cl.aclose()
                closed += 1
            except Exception as e:
                log.warning("flush: клиент не закрылся: %s", e)
        _clients[key] = None
    return {"cleared_verdicts": n, "cleared_cache": c, "closed_clients": closed}


@app.get("/stream")
async def stream(request: Request,
                 id: str = Query(..., min_length=5, max_length=32),
                 token: Optional[str] = Query(None),
                 authorization: Optional[str] = Header(None)):
    _check_token(authorization, token)
    item = await _resolve_cached(id)

    headers = {}
    rng = request.headers.get("range")
    if rng:
        headers["Range"] = rng

    # Тем же маршрутом, каким резолвили: ссылка привязана к IP просившего
    via_proxy = item.get("via") == "proxy"
    client = get_client(via_proxy)

    async def open_upstream(url: str):
        req = client.build_request("GET", url, headers=headers)
        return await client.send(req, stream=True)

    try:
        upstream = await open_upstream(item["url"])
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"upstream error: {e}")

    # Ссылка просрочилась или отвязалась — резолвим заново и пробуем один раз
    if upstream.status_code in (403, 410):
        await upstream.aclose()
        _cache.pop(id, None)
        item = await _resolve_cached(id)
        via_proxy = item.get("via") == "proxy"
        client = get_client(via_proxy)
        try:
            upstream = await open_upstream(item["url"])
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"refresh failed: {e}")

    async def body():
        try:
            async for chunk in upstream.aiter_bytes(PROXY_CHUNK):
                yield chunk
        finally:
            await upstream.aclose()

    passthrough = {}
    for h in ("content-length", "content-range", "content-type", "accept-ranges"):
        if h in upstream.headers:
            passthrough[h] = upstream.headers[h]
    passthrough.setdefault("accept-ranges", "bytes")
    passthrough["content-type"] = upstream.headers.get(
        "content-type", item.get("content_type", "audio/mp4"))
    passthrough["x-zizi-via"] = item.get("via", "direct")

    return StreamingResponse(body(), status_code=upstream.status_code,
                             headers=passthrough)
