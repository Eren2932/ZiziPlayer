# Kentra

Гибридный VPN-клиент: конфигуратор чужих ключей + магазин своих подписок.
Android (Kotlin + Compose), Clean Architecture + MVI + модуляризация, ядро — sing-box (libbox).

**Читать первым делом: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).**
Дополнительно: [`docs/APK_SIZE.md`](docs/APK_SIZE.md), [`docs/BACKEND.md`](docs/BACKEND.md).

## Статус: итерация 1

Работает:

- импорт ключей: `vless://`, `vmess://`, `trojan://`, `ss://`, `hysteria2://`,
  список ссылок, base64-подписка, подписка по http(s)
- хранение в Room, активный профиль в DataStore
- генерация типизированного конфига sing-box
- `VpnService` с foreground-уведомлением и корректным жизненным циклом
- MVI-экраны: Главная, Ключи, Подписка
- unit-тесты: парсеры, конфиг, мапперы, MVI-ядро, ViewModel

Ещё не работает (сознательно, см. роадмап):

- **реальный туннель**: подключён `SimulatedVpnEngine`. Go-ядро подключается на этапе 2
  заменой одной строки в `vpnModule` (инструкция — в `vpn/service/.../LibboxVpnEngine.kt.template`)
- платежи и активация кодов: этап 4, `StubBillingRepository`

## Сборка

### GitHub Actions (основной путь)

Пуш в любую ветку запускает `.github/workflows/android.yml`:
юнит-тесты → `:app:assembleDebug` → APK в артефактах (`kentra-debug-apk`).

Gradle-wrapper в репозитории не нужен: Gradle ставится через `gradle/actions/setup-gradle`.

### Локально

```bash
gradle wrapper --gradle-version 8.11.1   # один раз, если нужен wrapper
./gradlew test
./gradlew :app:assembleDebug
```

Требуется JDK 17 и Android SDK 35.

## Переименование проекта

```bash
grep -rl "dev.kentra" . | xargs sed -i 's/dev\.kentra/com\.yourname\.vpn/g'
grep -rl "Kentra" . | xargs sed -i 's/Kentra/YourName/g'
# переименовать каталоги dev/kentra -> com/yourname/vpn
```

## Структура

```
app/                хост приложения, DI, навигация
domain/             модели, use cases, интерфейсы репозиториев (pure Kotlin)
core/common         ошибки, логгер, диспетчеры
core/mvi            MviMachine
core/ui             MviViewModel, сбор эффектов
core/designsystem   тема и компоненты
core/database       Room
core/datastore      настройки
core/network        Ktor
data/               реализации репозиториев
vpn/link            парсеры ключей
vpn/config          модель и генератор конфига sing-box
vpn/service         VpnService, VpnEngine, TunnelController
feature/home        коннект и статистика
feature/profiles    ключи и подписки
feature/store       тарифы и активация
docs/               архитектура, вес APK, бэкенд
```

## Правила, которые нельзя нарушать

1. `:domain` не знает про Android. Ни одного `import android.*`.
2. `:feature:*` не зависят друг от друга и не видят `:data`.
3. JSON конфига собирается только в `ConfigFactory`, никогда строками.
4. Состояние туннеля живёт в VPN-слое, UI на него только подписывается.
5. Ключи и токены не попадают в логи: всё через `redactSecrets()`.
6. Go-ядро видит только `:vpn:service`.
