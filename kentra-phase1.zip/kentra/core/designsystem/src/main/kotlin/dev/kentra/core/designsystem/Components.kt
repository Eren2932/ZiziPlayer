package dev.kentra.core.designsystem

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun KentraCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(KentraTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(KentraTokens.SpaceMd)) { content() }
    }
}

/**
 * The one control users actually touch. It owns no logic: state comes in, clicks go out.
 * Deliberately built from Box + clickable instead of a clickable Surface so it never
 * depends on an experimental Material3 API.
 */
@Composable
fun ConnectOrb(
    label: String,
    sublabel: String,
    active: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val color by animateColorAsState(
        targetValue = when {
            busy -> KentraTokens.Warning
            active -> KentraTokens.Accent
            else -> MaterialTheme.colorScheme.surfaceVariant
        },
        label = "orbColor",
    )
    val scale by animateFloatAsState(if (active) 1f else 0.96f, label = "orbScale")
    val onColor = if (active || busy) Color(0xFF04231B) else MaterialTheme.colorScheme.onSurface

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(200.dp)
            .scale(scale)
            .background(color = color, shape = CircleShape)
            .clickable(onClick = onClick),
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(KentraTokens.SpaceMd),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleLarge,
                color = onColor,
                textAlign = TextAlign.Center,
            )
            Text(
                text = sublabel,
                style = MaterialTheme.typography.labelSmall,
                color = onColor.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun StatPill(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(KentraTokens.RadiusControl))
            .padding(horizontal = KentraTokens.SpaceMd, vertical = KentraTokens.SpaceSm),
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}
