package dev.kentra.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * One theme, no dynamic color: a VPN app must look identical on every device
 * so screenshots from support tickets are readable.
 */
object KentraTokens {
    val Accent = Color(0xFF2BD9A6)
    val AccentPressed = Color(0xFF19B589)
    val Danger = Color(0xFFFF5C5C)
    val Warning = Color(0xFFFFB020)
    val SurfaceDark = Color(0xFF0E1116)
    val SurfaceDarkElevated = Color(0xFF161B22)
    val OnDark = Color(0xFFE6EDF3)
    val OnDarkMuted = Color(0xFF8B949E)

    val RadiusCard = 20.dp
    val RadiusControl = 14.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 16.dp
    val SpaceLg = 24.dp
    val SpaceXl = 32.dp
}

private val DarkScheme = darkColorScheme(
    primary = KentraTokens.Accent,
    onPrimary = Color(0xFF04231B),
    secondary = KentraTokens.Accent,
    background = KentraTokens.SurfaceDark,
    onBackground = KentraTokens.OnDark,
    surface = KentraTokens.SurfaceDark,
    onSurface = KentraTokens.OnDark,
    surfaceVariant = KentraTokens.SurfaceDarkElevated,
    onSurfaceVariant = KentraTokens.OnDarkMuted,
    error = KentraTokens.Danger,
)

private val LightScheme = lightColorScheme(
    primary = KentraTokens.AccentPressed,
    onPrimary = Color.White,
    background = Color(0xFFF6F8FA),
    surface = Color.White,
    error = KentraTokens.Danger,
)

private val KentraTypography = Typography(
    displaySmall = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal),
    labelSmall = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun KentraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = KentraTypography,
        content = content,
    )
}
