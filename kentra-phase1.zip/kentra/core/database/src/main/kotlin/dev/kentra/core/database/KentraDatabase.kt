package dev.kentra.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ProfileEntity::class, SubscriptionEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class KentraDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun subscriptionDao(): SubscriptionDao

    companion object {
        private const val NAME = "kentra.db"

        fun build(context: Context): KentraDatabase =
            Room.databaseBuilder(context, KentraDatabase::class.java, NAME)
                // No destructive migration in release: users would silently lose their keys.
                .build()
    }
}
