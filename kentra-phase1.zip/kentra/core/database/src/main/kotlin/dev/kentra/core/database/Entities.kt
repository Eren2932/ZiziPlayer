package dev.kentra.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Storage shape is intentionally flat and dumb: complex objects are stored as JSON strings
 * so schema migrations stay trivial. Domain mapping happens in :data.
 */
@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val protocol: String,
    val server: String,
    val port: Int,
    val uuid: String?,
    val password: String?,
    val method: String?,
    val flow: String?,
    val alterId: Int?,
    val tlsJson: String,
    val transportJson: String,
    val originType: String,
    val originSourceId: String?,
    val createdAt: Long,
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val lastSyncEpochMs: Long?,
    val profileCount: Int,
    val lastError: String?,
)
