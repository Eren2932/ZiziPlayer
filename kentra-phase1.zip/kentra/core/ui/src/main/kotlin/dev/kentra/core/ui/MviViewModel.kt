package dev.kentra.core.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviMachine
import dev.kentra.core.mvi.MviState
import dev.kentra.core.mvi.Store
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Android host for [MviMachine]. Features extend this and implement [handle] only.
 * No Compose type may ever appear in a subclass of this class.
 */
abstract class MviViewModel<I : MviIntent, S : MviState, E : MviEffect>(
    initialState: S,
) : ViewModel(), Store<I, S, E> {

    private val machine = MviMachine<I, S, E>(initialState, viewModelScope) { intent -> handle(intent) }

    override val state: StateFlow<S> = machine.state
    override val effects: Flow<E> = machine.effects

    protected val currentState: S get() = machine.current

    override fun dispatch(intent: I) = machine.dispatch(intent)

    protected fun reduce(reducer: S.() -> S) = machine.reduce(reducer)

    protected fun effect(effect: E) = machine.effect(effect)

    protected abstract suspend fun handle(intent: I)
}
