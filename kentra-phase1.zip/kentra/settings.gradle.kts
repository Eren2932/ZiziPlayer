@file:Suppress("UnstableApiUsage")

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Kentra"

include(":app")

include(":domain")

include(":core:common")
include(":core:mvi")
include(":core:ui")
include(":core:designsystem")
include(":core:database")
include(":core:datastore")
include(":core:network")

include(":data")

include(":vpn:link")
include(":vpn:config")
include(":vpn:service")

include(":feature:home")
include(":feature:profiles")
include(":feature:store")
