package dev.kentra.vpn.link

import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultLinkParserTest {

    private val parser = DefaultLinkParser(idFactory = { "fixed-id" }, clock = { 0L })

    @Test
    fun `parses vless reality link`() {
        val link = "vless://11111111-2222-3333-4444-555555555555@example.com:443" +
            "?encryption=none&security=reality&sni=www.microsoft.com&fp=chrome" +
            "&pbk=PUBKEY&sid=ab12&type=tcp&flow=xtls-rprx-vision#NL-01"

        val profile = parser.parse(link)
        assertNotNull(profile)
        requireNotNull(profile)

        assertEquals(VpnProtocol.VLESS, profile.protocol)
        assertEquals("example.com", profile.server)
        assertEquals(443, profile.port)
        assertEquals("11111111-2222-3333-4444-555555555555", profile.uuid)
        assertEquals("xtls-rprx-vision", profile.flow)
        assertEquals("NL-01", profile.name)
        assertTrue(profile.tls.enabled)
        assertEquals("www.microsoft.com", profile.tls.serverName)
        assertEquals("PUBKEY", profile.tls.reality?.publicKey)
        assertEquals("ab12", profile.tls.reality?.shortId)
    }

    @Test
    fun `parses trojan ws link`() {
        val link = "trojan://secret@host.tld:8443?security=tls&sni=host.tld&type=ws&path=%2Fws#TR"
        val profile = parser.parse(link)!!

        assertEquals(VpnProtocol.TROJAN, profile.protocol)
        assertEquals("secret", profile.password)
        assertEquals("ws", profile.transport.type)
        assertEquals("/ws", profile.transport.path)
    }

    @Test
    fun `parses shadowsocks sip002 link`() {
        // base64("aes-256-gcm:pass")
        val link = "ss://YWVzLTI1Ni1nY206cGFzcw==@1.2.3.4:8388#SS-Node"
        val profile = parser.parse(link)!!

        assertEquals(VpnProtocol.SHADOWSOCKS, profile.protocol)
        assertEquals("aes-256-gcm", profile.method)
        assertEquals("pass", profile.password)
        assertEquals("1.2.3.4", profile.server)
        assertEquals(8388, profile.port)
        assertEquals("SS-Node", profile.name)
    }

    @Test
    fun `parses base64 subscription blob`() {
        val plain = """
            vless://aaaa@a.com:443?security=tls#A
            trojan://bbbb@b.com:443?security=tls#B
        """.trimIndent()
        val blob = java.util.Base64.getEncoder().encodeToString(plain.toByteArray())

        val profiles = parser.parseMany(blob)

        assertEquals(2, profiles.size)
        assertEquals("A", profiles[0].name)
        assertEquals("B", profiles[1].name)
    }

    @Test
    fun `rejects garbage`() {
        assertNull(parser.parse("https://example.com"))
        assertEquals(0, parser.parseMany("hello world").size)
    }
}
