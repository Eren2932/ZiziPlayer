package dev.kentra.vpn.link

import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.repository.LinkParser
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI
import java.net.URLDecoder
import java.util.UUID

/**
 * Pure-Kotlin parser for the key formats users actually paste.
 * Every supported format has a unit test; add a test BEFORE adding a format.
 */
class DefaultLinkParser(
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
    private val clock: () -> Long = { System.currentTimeMillis() },
) : LinkParser {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    override fun parse(uri: String): VpnProfile? {
        val raw = uri.trim()
        return runCatching {
            when {
                raw.startsWith("vless://", true) -> parseVless(raw)
                raw.startsWith("trojan://", true) -> parseTrojan(raw)
                raw.startsWith("vmess://", true) -> parseVmess(raw)
                raw.startsWith("ss://", true) -> parseShadowsocks(raw)
                raw.startsWith("hysteria2://", true) || raw.startsWith("hy2://", true) -> parseHysteria2(raw)
                else -> null
            }
        }.getOrNull()
    }

    override fun parseMany(payload: String): List<VpnProfile> {
        val direct = payload.lines().mapNotNull { parse(it) }
        if (direct.isNotEmpty()) return direct
        val decoded = payload.decodeBase64OrNull() ?: return emptyList()
        return decoded.lines().mapNotNull { parse(it) }
    }

    // ---------------------------------------------------------------- vless

    private fun parseVless(raw: String): VpnProfile {
        val uri = URI(raw)
        val q = uri.rawQuery.toQueryMap()
        val security = q["security"]?.lowercase() ?: "none"
        return VpnProfile(
            id = idFactory(),
            name = raw.fragmentName() ?: uri.host.orEmpty(),
            protocol = VpnProtocol.VLESS,
            server = uri.host.orEmpty(),
            port = uri.port.takeIf { it > 0 } ?: 443,
            uuid = uri.userInfo?.decode(),
            flow = q["flow"],
            tls = TlsSettings(
                enabled = security == "tls" || security == "reality" || security == "xtls",
                serverName = q["sni"] ?: q["peer"] ?: q["host"],
                allowInsecure = q["allowInsecure"] == "1",
                alpn = q["alpn"]?.split(",")?.filter { it.isNotBlank() } ?: emptyList(),
                fingerprint = q["fp"],
                reality = q["pbk"]?.let { RealitySettings(publicKey = it, shortId = q["sid"], spiderX = q["spx"]) },
            ),
            transport = q.toTransport(),
            origin = ProfileOrigin.Manual,
            createdAt = clock(),
        )
    }

    // -------------------------------------------------------------- trojan

    private fun parseTrojan(raw: String): VpnProfile {
        val uri = URI(raw)
        val q = uri.rawQuery.toQueryMap()
        return VpnProfile(
            id = idFactory(),
            name = raw.fragmentName() ?: uri.host.orEmpty(),
            protocol = VpnProtocol.TROJAN,
            server = uri.host.orEmpty(),
            port = uri.port.takeIf { it > 0 } ?: 443,
            password = uri.userInfo?.decode(),
            tls = TlsSettings(
                enabled = true,
                serverName = q["sni"] ?: q["peer"],
                allowInsecure = q["allowInsecure"] == "1",
                alpn = q["alpn"]?.split(",")?.filter { it.isNotBlank() } ?: emptyList(),
                fingerprint = q["fp"],
                reality = q["pbk"]?.let { RealitySettings(publicKey = it, shortId = q["sid"]) },
            ),
            transport = q.toTransport(),
            createdAt = clock(),
        )
    }

    // --------------------------------------------------------------- vmess

    private fun parseVmess(raw: String): VpnProfile? {
        val body = raw.removePrefix("vmess://").removePrefix("VMESS://")
        val decoded = body.decodeBase64OrNull() ?: return null
        val obj = json.parseToJsonElement(decoded) as? JsonObject ?: return null
        fun str(key: String) = obj[key]?.jsonPrimitive?.contentOrNullSafe()
        val net = str("net") ?: "tcp"
        val tlsMode = str("tls")?.lowercase()
        return VpnProfile(
            id = idFactory(),
            name = str("ps") ?: str("add").orEmpty(),
            protocol = VpnProtocol.VMESS,
            server = str("add").orEmpty(),
            port = str("port")?.toIntOrNull() ?: 443,
            uuid = str("id"),
            alterId = str("aid")?.toIntOrNull() ?: 0,
            tls = TlsSettings(
                enabled = tlsMode == "tls" || tlsMode == "reality",
                serverName = str("sni").takeUnless { it.isNullOrBlank() } ?: str("host"),
                fingerprint = str("fp"),
            ),
            transport = TransportSettings(
                type = net,
                path = str("path"),
                host = str("host"),
                serviceName = str("path").takeIf { net == "grpc" },
            ),
            createdAt = clock(),
        )
    }

    // -------------------------------------------------------- shadowsocks

    private fun parseShadowsocks(raw: String): VpnProfile? {
        val name = raw.fragmentName()
        val body = raw.substringBefore('#').removePrefix("ss://").removePrefix("SS://")
        // Form A: ss://base64(method:password)@host:port
        // Form B: ss://base64(method:password@host:port)
        val (credsPart, hostPart) = if (body.contains('@')) {
            body.substringBeforeLast('@') to body.substringAfterLast('@')
        } else {
            val decoded = body.decodeBase64OrNull() ?: return null
            decoded.substringBeforeLast('@') to decoded.substringAfterLast('@')
        }
        val creds = credsPart.decodeBase64OrNull() ?: credsPart.decode()
        val method = creds.substringBefore(':')
        val password = creds.substringAfter(':')
        val host = hostPart.substringBefore(':').substringBefore('?')
        val port = hostPart.substringAfter(':').substringBefore('?').toIntOrNull() ?: return null
        if (host.isBlank() || method.isBlank()) return null
        return VpnProfile(
            id = idFactory(),
            name = name ?: host,
            protocol = VpnProtocol.SHADOWSOCKS,
            server = host,
            port = port,
            method = method,
            password = password,
            createdAt = clock(),
        )
    }

    // ----------------------------------------------------------- hysteria2

    private fun parseHysteria2(raw: String): VpnProfile {
        val normalized = raw.replaceFirst("hy2://", "hysteria2://")
        val uri = URI(normalized)
        val q = uri.rawQuery.toQueryMap()
        return VpnProfile(
            id = idFactory(),
            name = raw.fragmentName() ?: uri.host.orEmpty(),
            protocol = VpnProtocol.HYSTERIA2,
            server = uri.host.orEmpty(),
            port = uri.port.takeIf { it > 0 } ?: 443,
            password = uri.userInfo?.decode(),
            tls = TlsSettings(
                enabled = true,
                serverName = q["sni"],
                allowInsecure = q["insecure"] == "1",
            ),
            createdAt = clock(),
        )
    }

    // ----------------------------------------------------------- helpers

    private fun String?.toQueryMap(): Map<String, String> =
        this?.split('&')
            ?.filter { it.contains('=') }
            ?.associate { it.substringBefore('=') to it.substringAfter('=').decode() }
            ?: emptyMap()

    private fun Map<String, String>.toTransport(): TransportSettings {
        val type = this["type"]?.lowercase() ?: "tcp"
        return TransportSettings(
            type = type,
            path = this["path"],
            host = this["host"],
            serviceName = this["serviceName"] ?: this["path"].takeIf { type == "grpc" },
        )
    }

    private fun String.decode(): String = runCatching { URLDecoder.decode(this, "UTF-8") }.getOrDefault(this)

    private fun String.fragmentName(): String? =
        substringAfter('#', "").takeIf { it.isNotBlank() }?.decode()

    private fun kotlinx.serialization.json.JsonPrimitive.contentOrNullSafe(): String? =
        content.takeIf { it.isNotBlank() && it != "null" }
}
