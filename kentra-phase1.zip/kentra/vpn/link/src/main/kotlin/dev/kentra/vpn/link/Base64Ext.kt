package dev.kentra.vpn.link

import java.util.Base64

internal fun String.decodeBase64OrNull(): String? {
    val cleaned = trim().replace("\n", "").replace("\r", "").replace(" ", "")
    if (cleaned.isEmpty()) return null
    val padded = cleaned.padEnd((cleaned.length + 3) / 4 * 4, '=')
    return runCatching { String(Base64.getUrlDecoder().decode(padded)) }
        .recoverCatching { String(Base64.getMimeDecoder().decode(padded)) }
        .getOrNull()
}
