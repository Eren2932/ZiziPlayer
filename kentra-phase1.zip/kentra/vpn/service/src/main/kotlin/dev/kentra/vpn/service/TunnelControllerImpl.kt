package dev.kentra.vpn.service

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import dev.kentra.core.common.AppError
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first

/**
 * The only bridge between the app and the VPN process.
 *
 * Note the permission contract: this class does NOT show UI. If the VPN consent dialog is
 * required it fails with [AppError.Permission] and the feature layer turns that into an
 * MVI effect. Keeping Android dialogs out of the data layer is what makes this testable.
 */
class TunnelControllerImpl(
    private val context: Context,
    private val bus: TunnelBus,
    private val settings: SettingsStore,
    private val configFactory: ConfigFactory,
) : TunnelController {

    override val state: StateFlow<TunnelState> = bus.state
    override val traffic: Flow<TrafficSample> = bus.traffic

    override suspend fun connect(profile: VpnProfile) {
        if (VpnService.prepare(context) != null) throw AppError.Permission("vpn-consent")

        val options = settings.tunnelOptions.first()
        val configJson = runCatching { configFactory.build(profile, options) }
            .getOrElse { throw AppError.Tunnel("config build failed: ${it.message}") }

        val intent = Intent(context, KentraVpnService::class.java).apply {
            action = KentraVpnService.ACTION_START
            putExtra(KentraVpnService.EXTRA_PROFILE_ID, profile.id)
            putExtra(KentraVpnService.EXTRA_PROFILE_NAME, profile.name)
            putExtra(KentraVpnService.EXTRA_CONFIG, configJson)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    override suspend fun disconnect() {
        context.startService(
            Intent(context, KentraVpnService::class.java).setAction(KentraVpnService.ACTION_STOP),
        )
    }
}
