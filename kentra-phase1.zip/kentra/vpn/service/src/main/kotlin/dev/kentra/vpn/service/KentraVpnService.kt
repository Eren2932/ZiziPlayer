package dev.kentra.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

/**
 * Owns the tunnel lifecycle. It is the only component allowed to change [TunnelBus] state.
 *
 * Contract with the UI: the UI sends intents and observes state. It never assumes success.
 */
class KentraVpnService : VpnService() {

    private val bus: TunnelBus by inject()
    private val engine: VpnEngine by inject()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineName("vpn"))
    private var tunnelJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val session = TunnelSession(
                    profileId = intent.getStringExtra(EXTRA_PROFILE_ID).orEmpty(),
                    profileName = intent.getStringExtra(EXTRA_PROFILE_NAME).orEmpty(),
                    configJson = intent.getStringExtra(EXTRA_CONFIG).orEmpty(),
                )
                startTunnel(session)
                return START_STICKY
            }
            else -> return START_NOT_STICKY
        }
    }

    private fun startTunnel(session: TunnelSession) {
        if (tunnelJob?.isActive == true) return
        bus.publish(TunnelState.Preparing)
        startForeground(NOTIFICATION_ID, notification(session.profileName, connected = false))

        tunnelJob = scope.launch {
            runCatching {
                launch {
                    engine.traffic.collect { bus.publish(it) }
                }
                bus.publish(TunnelState.Connected(session.profileId, System.currentTimeMillis()))
                notifyConnected(session.profileName)
                engine.start(this@KentraVpnService, session)
            }.onFailure { error ->
                if (error is kotlinx.coroutines.CancellationException) throw error
                bus.publish(TunnelState.Failed(error.message ?: "engine failure"))
                stopSelfSafely()
            }
        }
    }

    private fun stopTunnel() {
        bus.publish(TunnelState.Stopping)
        scope.launch {
            runCatching {
                tunnelJob?.cancelAndJoin()
                engine.stop()
            }
            bus.reset()
            stopSelfSafely()
        }
    }

    private fun stopSelfSafely() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
        }
        stopSelf()
    }

    /** The user killed the VPN from system settings. Treat it as an explicit disconnect. */
    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        scope.launch { engine.stop() }
        bus.reset()
        super.onDestroy()
    }

    private fun notifyConnected(name: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification(name, connected = true))
    }

    private fun notification(profileName: String, connected: Boolean): Notification {
        ensureChannel()
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, KentraVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(if (connected) "Подключено" else "Подключение…")
            .setContentText(profileName.ifBlank { "VPN" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Отключить", stopIntent)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Статус VPN", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            },
        )
    }

    companion object {
        const val ACTION_START = "dev.kentra.vpn.START"
        const val ACTION_STOP = "dev.kentra.vpn.STOP"
        const val EXTRA_PROFILE_ID = "profile_id"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_CONFIG = "config"

        private const val CHANNEL_ID = "vpn_status"
        private const val NOTIFICATION_ID = 0x4B45
    }
}
