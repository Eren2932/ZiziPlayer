package dev.kentra.vpn.service

import android.net.VpnService
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.flow.Flow

/** Everything the engine needs to bring a tunnel up. Generated in :vpn:config, never hand-written. */
data class TunnelSession(
    val profileId: String,
    val profileName: String,
    val configJson: String,
)

/**
 * The seam that keeps the Go core out of the rest of the app.
 *
 * Only this interface is allowed to know about libbox/sing-box. Swapping the core
 * (sing-box -> xray, or adding a WireGuard engine) is a one-file change and the
 * whole UI/domain test suite keeps running against [SimulatedVpnEngine].
 */
interface VpnEngine {
    val id: String

    /** Must establish the TUN interface through [service] and block until stopped. */
    suspend fun start(service: VpnService, session: TunnelSession)

    suspend fun stop()

    val traffic: Flow<TrafficSample>
}
