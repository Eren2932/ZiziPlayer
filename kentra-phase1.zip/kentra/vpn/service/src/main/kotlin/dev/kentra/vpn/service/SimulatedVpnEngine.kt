package dev.kentra.vpn.service

import android.net.VpnService
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlin.random.Random

/**
 * PHASE 1 ENGINE.
 *
 * Brings up nothing: it validates the generated config, reports Connected and emits
 * plausible traffic so the whole UI, state machine, notification and MVI layer can be
 * built, tested and shipped as a working APK before the 40 MB Go core lands.
 *
 * It deliberately does NOT call VpnService.Builder.establish(): a tunnel that captures
 * traffic and drops it would look like "internet is broken" to a tester.
 *
 * Replace with LibboxVpnEngine in `vpnModule` when the core is wired (phase 2).
 */
class SimulatedVpnEngine : VpnEngine {

    override val id: String = "simulated"

    private val _traffic = MutableStateFlow(TrafficSample())
    override val traffic: Flow<TrafficSample> = _traffic

    override suspend fun start(service: VpnService, session: TunnelSession) {
        require(session.configJson.contains("\"outbounds\"")) { "generated config has no outbounds" }
        delay(600) // handshake theatre, also exercises the Preparing state in the UI
        var up = 0L
        var down = 0L
        while (currentCoroutineContext().isActive) {
            val upDelta = Random.nextLong(4_000, 40_000)
            val downDelta = Random.nextLong(20_000, 400_000)
            up += upDelta
            down += downDelta
            _traffic.value = TrafficSample(
                uplinkBytes = up,
                downlinkBytes = down,
                uplinkSpeedBps = upDelta,
                downlinkSpeedBps = downDelta,
            )
            delay(1_000)
        }
    }

    override suspend fun stop() {
        _traffic.value = TrafficSample()
    }
}
