package dev.kentra.vpn.service

import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val vpnModule = module {
    single { TunnelBus() }
    single { ConfigFactory() }

    // PHASE 2: replace with LibboxVpnEngine() — the only line that has to change.
    single<VpnEngine> { SimulatedVpnEngine() }

    single<TunnelController> {
        TunnelControllerImpl(
            context = androidContext(),
            bus = get(),
            settings = get(),
            configFactory = get(),
        )
    }
}
