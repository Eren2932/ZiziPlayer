package dev.kentra.data

import dev.kentra.core.database.ProfileDao
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.ProfileRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class ProfileRepositoryImpl(
    private val dao: ProfileDao,
    private val settings: SettingsStore,
) : ProfileRepository {

    override fun observeProfiles(): Flow<List<VpnProfile>> =
        dao.observeAll().map { list -> list.map(ProfileMapper::toDomain) }

    override fun observeActiveProfileId(): Flow<String?> = settings.activeProfileId

    override suspend fun getProfile(id: String): VpnProfile? = dao.byId(id)?.let(ProfileMapper::toDomain)

    override suspend fun upsert(profile: VpnProfile) = dao.upsert(ProfileMapper.toEntity(profile))

    override suspend fun upsertAll(profiles: List<VpnProfile>) =
        dao.upsertAll(profiles.map(ProfileMapper::toEntity))

    override suspend fun delete(id: String) {
        dao.deleteById(id)
        // Deleting the active profile must never leave a dangling selection.
        if (settings.activeProfileId.first() == id) settings.setActiveProfileId(null)
    }

    override suspend fun setActiveProfileId(id: String?) = settings.setActiveProfileId(id)
}
