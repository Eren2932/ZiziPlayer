package dev.kentra.data

import dev.kentra.core.common.AppError
import dev.kentra.core.common.appRunCatching
import dev.kentra.core.database.ProfileDao
import dev.kentra.core.database.SubscriptionDao
import dev.kentra.core.database.SubscriptionEntity
import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.SubscriptionSource
import dev.kentra.domain.repository.LinkParser
import dev.kentra.domain.repository.SubscriptionRepository
import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Subscriptions are the reason this app survives blocks: the server can rotate keys and nodes
 * without shipping an app update. Never persist a bare key when a subscription URL is available.
 */
class SubscriptionRepositoryImpl(
    private val dao: SubscriptionDao,
    private val profileDao: ProfileDao,
    private val client: HttpClient,
    private val parser: LinkParser,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : SubscriptionRepository {

    override fun observeSources(): Flow<List<SubscriptionSource>> = dao.observeAll().map { list ->
        list.map {
            SubscriptionSource(
                id = it.id,
                name = it.name,
                url = it.url,
                lastSyncEpochMs = it.lastSyncEpochMs,
                profileCount = it.profileCount,
                lastError = it.lastError,
            )
        }
    }

    override suspend fun add(name: String, url: String): Result<SubscriptionSource> = appRunCatching {
        require(url.startsWith("http", ignoreCase = true)) { "subscription url must be http(s)" }
        val entity = SubscriptionEntity(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { url.take(32) },
            url = url,
            lastSyncEpochMs = null,
            profileCount = 0,
            lastError = null,
        )
        dao.insert(entity)
        refresh(entity.id).getOrThrow()
        SubscriptionSource(id = entity.id, name = entity.name, url = entity.url)
    }

    override suspend fun refresh(sourceId: String): Result<Int> = appRunCatching {
        val source = dao.byId(sourceId) ?: throw AppError.NotFound("subscription $sourceId")
        val payload = try {
            client.get(source.url).bodyAsText()
        } catch (t: Throwable) {
            dao.upsert(source.copy(lastError = t.message?.take(200)))
            throw AppError.Network(t.message)
        }
        val parsed = parser.parseMany(payload)
        if (parsed.isEmpty()) {
            dao.upsert(source.copy(lastError = "no keys in response"))
            throw AppError.Parse("subscription returned no usable keys")
        }
        // Replace instead of merge: the server is the source of truth for rotated keys.
        profileDao.deleteBySource(sourceId)
        profileDao.upsertAll(
            parsed.map { profile ->
                ProfileMapper.toEntity(profile.copy(origin = ProfileOrigin.Subscription(sourceId)))
            },
        )
        dao.upsert(
            source.copy(
                lastSyncEpochMs = clock(),
                profileCount = parsed.size,
                lastError = null,
            ),
        )
        parsed.size
    }

    override suspend fun refreshAll(): Result<Int> = appRunCatching {
        val sources = dao.observeAll().first()
        sources.sumOf { refresh(it.id).getOrElse { 0 } }
    }

    override suspend fun remove(sourceId: String) {
        profileDao.deleteBySource(sourceId)
        dao.deleteById(sourceId)
    }
}
