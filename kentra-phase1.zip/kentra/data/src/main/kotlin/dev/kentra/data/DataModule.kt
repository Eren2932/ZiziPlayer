package dev.kentra.data

import dev.kentra.core.database.KentraDatabase
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.network.ApiConfig
import dev.kentra.core.network.HttpClientFactory
import dev.kentra.domain.repository.BillingRepository
import dev.kentra.domain.repository.LinkParser
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.SubscriptionRepository
import dev.kentra.vpn.link.DefaultLinkParser
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val dataModule = module {
    single { KentraDatabase.build(androidContext()) }
    single { get<KentraDatabase>().profileDao() }
    single { get<KentraDatabase>().subscriptionDao() }
    single { SettingsStore(androidContext()) }
    single { ApiConfig() }
    single { HttpClientFactory.create(get()) }

    single<LinkParser> { DefaultLinkParser() }
    single<ProfileRepository> { ProfileRepositoryImpl(dao = get(), settings = get()) }
    single<SubscriptionRepository> {
        SubscriptionRepositoryImpl(dao = get(), profileDao = get(), client = get(), parser = get())
    }
    single<BillingRepository> { StubBillingRepository() }
}
