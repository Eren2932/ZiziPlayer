package dev.kentra.data

import dev.kentra.core.common.AppError
import dev.kentra.domain.model.Entitlement
import dev.kentra.domain.model.Plan
import dev.kentra.domain.repository.BillingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * PHASE 1 PLACEHOLDER.
 *
 * The real implementation talks to our control plane (see docs/ARCHITECTURE.md, phase 4):
 *   GET  /v1/plans
 *   POST /v1/orders        -> external checkout url (YooKassa / Cryptomus / Telegram)
 *   POST /v1/activate      -> binds a code to this device, returns entitlement + sub url
 *   GET  /v1/me            -> entitlement sync
 *
 * In-app purchases are deliberately NOT used: Play Billing takes a cut and rejects
 * network-tool subscriptions far more often than an external checkout gets flagged.
 */
class StubBillingRepository : BillingRepository {

    private val entitlement = MutableStateFlow<Entitlement?>(null)

    private val catalogue = listOf(
        Plan(id = "m1", name = "1 месяц", days = 30, priceMinor = 19900, deviceLimit = 3),
        Plan(id = "m3", name = "3 месяца", days = 90, priceMinor = 49900, deviceLimit = 3, highlighted = true),
        Plan(id = "m12", name = "12 месяцев", days = 365, priceMinor = 149900, deviceLimit = 5),
    )

    override suspend fun plans(): Result<List<Plan>> = Result.success(catalogue)

    override fun observeEntitlement(): Flow<Entitlement?> = entitlement.asStateFlow()

    override suspend fun createCheckout(planId: String): Result<String> =
        Result.failure(AppError.Unknown(IllegalStateException("checkout not wired yet (phase 4)")))

    override suspend fun activateCode(code: String): Result<Entitlement> =
        Result.failure(AppError.Unknown(IllegalStateException("activation not wired yet (phase 4)")))

    override suspend fun syncEntitlement(): Result<Entitlement?> = Result.success(entitlement.value)
}
