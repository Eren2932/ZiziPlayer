package dev.kentra.domain.repository

import dev.kentra.domain.model.Entitlement
import dev.kentra.domain.model.Plan
import dev.kentra.domain.model.SubscriptionSource
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface ProfileRepository {
    fun observeProfiles(): Flow<List<VpnProfile>>
    fun observeActiveProfileId(): Flow<String?>
    suspend fun getProfile(id: String): VpnProfile?
    suspend fun upsert(profile: VpnProfile)
    suspend fun upsertAll(profiles: List<VpnProfile>)
    suspend fun delete(id: String)
    suspend fun setActiveProfileId(id: String?)
}

/** Parses user-pasted keys. Implemented in :vpn:link, pure Kotlin, heavily unit tested. */
interface LinkParser {
    fun parse(uri: String): VpnProfile?

    /** Accepts a newline list, a base64 blob, or a single link. Returns everything it could read. */
    fun parseMany(payload: String): List<VpnProfile>
}

interface SubscriptionRepository {
    fun observeSources(): Flow<List<SubscriptionSource>>
    suspend fun add(name: String, url: String): Result<SubscriptionSource>
    suspend fun refresh(sourceId: String): Result<Int>
    suspend fun refreshAll(): Result<Int>
    suspend fun remove(sourceId: String)
}

interface BillingRepository {
    suspend fun plans(): Result<List<Plan>>
    fun observeEntitlement(): Flow<Entitlement?>
    /** Returns the URL of the external checkout: in-app purchases are deliberately not used. */
    suspend fun createCheckout(planId: String): Result<String>
    suspend fun activateCode(code: String): Result<Entitlement>
    suspend fun syncEntitlement(): Result<Entitlement?>
}

/** Port to the VPN process. The UI talks to the tunnel ONLY through this. */
interface TunnelController {
    val state: StateFlow<TunnelState>
    val traffic: Flow<TrafficSample>
    suspend fun connect(profile: VpnProfile)
    suspend fun disconnect()
}
