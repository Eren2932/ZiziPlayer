package dev.kentra.domain.usecase

import dev.kentra.core.common.AppError
import dev.kentra.core.common.appRunCatching
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.LinkParser
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.TunnelController

class ImportKeysUseCase(
    private val parser: LinkParser,
    private val profiles: ProfileRepository,
) {
    /** @return number of imported profiles, or [AppError.Parse] when nothing was recognised. */
    suspend operator fun invoke(payload: String): Result<Int> = appRunCatching {
        val parsed = parser.parseMany(payload)
        if (parsed.isEmpty()) throw AppError.Parse("no supported link found")
        profiles.upsertAll(parsed)
        parsed.size
    }
}

class ConnectUseCase(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
) {
    suspend operator fun invoke(profileId: String): Result<Unit> = appRunCatching {
        val profile = profiles.getProfile(profileId) ?: throw AppError.NotFound("profile $profileId")
        profiles.setActiveProfileId(profileId)
        tunnel.connect(profile)
    }
}

class DisconnectUseCase(private val tunnel: TunnelController) {
    suspend operator fun invoke(): Result<Unit> = appRunCatching { tunnel.disconnect() }
}

class DeleteProfileUseCase(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
) {
    suspend operator fun invoke(profile: VpnProfile): Result<Unit> = appRunCatching {
        tunnel.disconnect()
        profiles.delete(profile.id)
    }
}
