# --- kotlinx.serialization -------------------------------------------------
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class dev.kentra.**$$serializer { *; }
-keepclassmembers class dev.kentra.** { *** Companion; }
-keepclasseswithmembers class dev.kentra.** { kotlinx.serialization.KSerializer serializer(...); }

# --- Room ------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# --- Koin ------------------------------------------------------------------
-keep class org.koin.** { *; }
-keepclassmembers class * { public <init>(...); }

# --- Ktor / OkHttp ---------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn io.ktor.**
-keepclassmembers class io.ktor.** { volatile <fields>; }

# --- VpnService ------------------------------------------------------------
-keep class dev.kentra.vpn.service.KentraVpnService { *; }

# --- Phase 2: libbox (gomobile) — JNI entry points must survive R8 ---------
# -keep class io.nekohasekai.libbox.** { *; }
# -keep class go.** { *; }
