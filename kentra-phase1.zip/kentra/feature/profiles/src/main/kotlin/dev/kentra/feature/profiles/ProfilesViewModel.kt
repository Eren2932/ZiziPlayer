package dev.kentra.feature.profiles

import androidx.lifecycle.viewModelScope
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.SubscriptionRepository
import dev.kentra.domain.usecase.DeleteProfileUseCase
import dev.kentra.domain.usecase.ImportKeysUseCase
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class ProfilesViewModel(
    private val profiles: ProfileRepository,
    private val subscriptions: SubscriptionRepository,
    private val importKeys: ImportKeysUseCase,
    private val deleteProfile: DeleteProfileUseCase,
) : MviViewModel<ProfilesIntent, ProfilesState, ProfilesEffect>(ProfilesState()) {

    init {
        combine(profiles.observeProfiles(), profiles.observeActiveProfileId()) { list, activeId ->
            reduce { copy(profiles = list, activeProfileId = activeId) }
        }.launchIn(viewModelScope)

        subscriptions.observeSources()
            .onEach { sources -> reduce { copy(sources = sources) } }
            .launchIn(viewModelScope)
    }

    override suspend fun handle(intent: ProfilesIntent) {
        when (intent) {
            ProfilesIntent.OpenImport -> reduce { copy(importSheetVisible = true, importText = "") }
            ProfilesIntent.CloseImport -> reduce { copy(importSheetVisible = false) }
            is ProfilesIntent.ImportTextChanged -> reduce { copy(importText = intent.text) }
            ProfilesIntent.ConfirmImport -> confirmImport()
            is ProfilesIntent.Select -> profiles.setActiveProfileId(intent.profileId)
            is ProfilesIntent.Delete -> deleteProfile(intent.profile)
            ProfilesIntent.RefreshSubscriptions -> refresh()
        }
    }

    private suspend fun confirmImport() {
        val payload = currentState.importText.trim()
        if (payload.isEmpty()) return
        reduce { copy(busy = true) }

        // A subscription URL is preferred over a bare key: it can be rotated server-side.
        val result = if (payload.startsWith("http", ignoreCase = true)) {
            subscriptions.add(name = "", url = payload).map { 1 }
        } else {
            importKeys(payload)
        }

        reduce { copy(busy = false) }
        result
            .onSuccess { count ->
                reduce { copy(importSheetVisible = false, importText = "") }
                effect(ProfilesEffect.ShowMessage("Добавлено: $count"))
                effect(ProfilesEffect.ImportSucceeded)
            }
            .onFailure { error ->
                effect(ProfilesEffect.ShowMessage(error.message ?: "Не удалось распознать ключ"))
            }
    }

    private suspend fun refresh() {
        reduce { copy(busy = true) }
        val result = subscriptions.refreshAll()
        reduce { copy(busy = false) }
        result
            .onSuccess { effect(ProfilesEffect.ShowMessage("Обновлено ключей: $it")) }
            .onFailure { effect(ProfilesEffect.ShowMessage(it.message ?: "Ошибка обновления")) }
    }
}
