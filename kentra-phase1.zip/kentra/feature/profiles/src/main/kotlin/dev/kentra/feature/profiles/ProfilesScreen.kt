package dev.kentra.feature.profiles

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.KentraCard
import dev.kentra.core.designsystem.KentraTokens
import dev.kentra.core.ui.CollectEffects
import dev.kentra.domain.model.VpnProfile
import org.koin.androidx.compose.koinViewModel

@Composable
fun ProfilesRoute(viewModel: ProfilesViewModel = koinViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    CollectEffects(viewModel.effects) { effect ->
        when (effect) {
            is ProfilesEffect.ShowMessage -> snackbar.showSnackbar(effect.text)
            ProfilesEffect.ImportSucceeded -> Unit
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(onClick = { viewModel.dispatch(ProfilesIntent.OpenImport) }) {
                Text("+", style = MaterialTheme.typography.titleLarge)
            }
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = KentraTokens.SpaceMd),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Ключи", style = MaterialTheme.typography.titleLarge)
                if (state.sources.isNotEmpty()) {
                    TextButton(onClick = { viewModel.dispatch(ProfilesIntent.RefreshSubscriptions) }) {
                        Text("Обновить")
                    }
                }
            }

            if (state.profiles.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(KentraTokens.SpaceSm)) {
                    items(state.profiles, key = { it.id }) { profile ->
                        ProfileRow(
                            profile = profile,
                            selected = profile.id == state.activeProfileId,
                            onSelect = { viewModel.dispatch(ProfilesIntent.Select(profile.id)) },
                            onDelete = { viewModel.dispatch(ProfilesIntent.Delete(profile)) },
                        )
                    }
                }
            }
        }
    }

    if (state.importSheetVisible) {
        ImportDialog(
            text = state.importText,
            busy = state.busy,
            onTextChange = { viewModel.dispatch(ProfilesIntent.ImportTextChanged(it)) },
            onConfirm = { viewModel.dispatch(ProfilesIntent.ConfirmImport) },
            onDismiss = { viewModel.dispatch(ProfilesIntent.CloseImport) },
        )
    }
}

@Composable
private fun EmptyState() {
    KentraCard {
        Text("Пока пусто", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(KentraTokens.SpaceSm))
        Text(
            "Вставьте ключ, купленный где угодно: vless://, trojan://, ss://, vmess://, hysteria2:// " +
                "или ссылку на подписку (http/https). Подписка лучше: ключи в ней можно менять без обновления приложения.",
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun ProfileRow(
    profile: VpnProfile,
    selected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
) {
    KentraCard(modifier = Modifier.clickable(onClick = onSelect)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.padding(end = 8.dp)) {
                Text(
                    text = if (selected) "● ${profile.name}" else profile.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${profile.protocol.name} · ${profile.displayEndpoint}",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            TextButton(onClick = onDelete) { Text("Удалить") }
        }
    }
}

@Composable
private fun ImportDialog(
    text: String,
    busy: Boolean,
    onTextChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить ключ или подписку") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChange,
                    label = { Text("Ссылка или список ссылок") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(KentraTokens.SpaceSm))
                Text(
                    "Можно вставить сразу несколько строк или base64-подписку.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        },
        confirmButton = {
            Button(onClick = onConfirm, enabled = !busy) { Text(if (busy) "Проверяю…" else "Добавить") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
