package dev.kentra.feature.profiles

import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviState
import dev.kentra.domain.model.SubscriptionSource
import dev.kentra.domain.model.VpnProfile

data class ProfilesState(
    val profiles: List<VpnProfile> = emptyList(),
    val sources: List<SubscriptionSource> = emptyList(),
    val activeProfileId: String? = null,
    val importSheetVisible: Boolean = false,
    val importText: String = "",
    val busy: Boolean = false,
) : MviState

sealed interface ProfilesIntent : MviIntent {
    data object OpenImport : ProfilesIntent
    data object CloseImport : ProfilesIntent
    data class ImportTextChanged(val text: String) : ProfilesIntent
    data object ConfirmImport : ProfilesIntent
    data class Select(val profileId: String) : ProfilesIntent
    data class Delete(val profile: VpnProfile) : ProfilesIntent
    data object RefreshSubscriptions : ProfilesIntent
}

sealed interface ProfilesEffect : MviEffect {
    data class ShowMessage(val text: String) : ProfilesEffect
    data object ImportSucceeded : ProfilesEffect
}
