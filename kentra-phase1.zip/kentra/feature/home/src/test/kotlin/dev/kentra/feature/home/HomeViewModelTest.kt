package dev.kentra.feature.home

import app.cash.turbine.test
import dev.kentra.core.common.AppError
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.TunnelController
import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModelTest {

    private val profile = VpnProfile(
        id = "p1",
        name = "NL",
        protocol = VpnProtocol.VLESS,
        server = "1.2.3.4",
        port = 443,
        uuid = "u",
    )

    private val activeId = MutableStateFlow<String?>("p1")
    private val tunnelState = MutableStateFlow<TunnelState>(TunnelState.Idle)
    private var connectResult: Result<Unit> = Result.success(Unit)
    private var disconnectCalls = 0

    private val profileRepo = object : ProfileRepository {
        override fun observeProfiles(): Flow<List<VpnProfile>> = flowOf(listOf(profile))
        override fun observeActiveProfileId(): Flow<String?> = activeId
        override suspend fun getProfile(id: String): VpnProfile? = profile.takeIf { it.id == id }
        override suspend fun upsert(profile: VpnProfile) = Unit
        override suspend fun upsertAll(profiles: List<VpnProfile>) = Unit
        override suspend fun delete(id: String) = Unit
        override suspend fun setActiveProfileId(id: String?) { activeId.value = id }
    }

    private val controller = object : TunnelController {
        override val state: StateFlow<TunnelState> = tunnelState
        override val traffic: Flow<TrafficSample> = MutableStateFlow(TrafficSample())
        override suspend fun connect(profile: VpnProfile) {
            connectResult.getOrThrow()
            tunnelState.value = TunnelState.Connected(profile.id, 0L)
        }
        override suspend fun disconnect() {
            disconnectCalls++
            tunnelState.value = TunnelState.Idle
        }
    }

    private fun viewModel() = HomeViewModel(
        profiles = profileRepo,
        tunnel = controller,
        connect = ConnectUseCase(profileRepo, controller),
        disconnect = DisconnectUseCase(controller),
    )

    @Before
    fun setUp() = Dispatchers.setMain(UnconfinedTestDispatcher())

    @After
    fun tearDown() = Dispatchers.resetMain()

    @Test
    fun `toggle connects the active profile`() = runTest {
        val vm = viewModel()

        vm.dispatch(HomeIntent.ToggleConnection)

        assertEquals(TunnelState.Connected("p1", 0L), vm.state.value.tunnel)
    }

    @Test
    fun `toggle while connected disconnects`() = runTest {
        val vm = viewModel()
        tunnelState.value = TunnelState.Connected("p1", 0L)

        vm.dispatch(HomeIntent.ToggleConnection)

        assertEquals(1, disconnectCalls)
    }

    @Test
    fun `missing vpn consent asks for permission instead of failing silently`() = runTest {
        connectResult = Result.failure(AppError.Permission("vpn-consent"))
        val vm = viewModel()

        vm.effects.test {
            vm.dispatch(HomeIntent.ToggleConnection)
            assertEquals(HomeEffect.RequestVpnPermission, awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
    }
}
