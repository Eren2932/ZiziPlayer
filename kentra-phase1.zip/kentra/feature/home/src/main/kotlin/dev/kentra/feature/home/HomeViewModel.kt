package dev.kentra.feature.home

import androidx.lifecycle.viewModelScope
import dev.kentra.core.common.AppError
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.TunnelController
import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class HomeViewModel(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
    private val connect: ConnectUseCase,
    private val disconnect: DisconnectUseCase,
) : MviViewModel<HomeIntent, HomeState, HomeEffect>(HomeState()) {

    init {
        // Selection is derived, never stored twice: the DB and the active id are the only truth.
        combine(profiles.observeProfiles(), profiles.observeActiveProfileId()) { list, activeId ->
            val active = list.firstOrNull { it.id == activeId } ?: list.firstOrNull()
            reduce { copy(activeProfile = active, profileCount = list.size) }
        }.launchIn(viewModelScope)

        tunnel.state
            .onEach { state ->
                reduce {
                    copy(
                        tunnel = state,
                        busy = state is TunnelState.Preparing || state is TunnelState.Stopping,
                    )
                }
                if (state is TunnelState.Failed) effect(HomeEffect.ShowMessage(state.reason))
            }
            .launchIn(viewModelScope)

        tunnel.traffic
            .onEach { sample -> reduce { copy(traffic = sample) } }
            .launchIn(viewModelScope)
    }

    override suspend fun handle(intent: HomeIntent) {
        when (intent) {
            HomeIntent.ToggleConnection -> toggle()
            HomeIntent.VpnPermissionGranted -> toggle()
            HomeIntent.VpnPermissionDenied ->
                effect(HomeEffect.ShowMessage("Без разрешения VPN подключение невозможно"))
            HomeIntent.OpenProfiles -> effect(HomeEffect.NavigateToProfiles)
            HomeIntent.MessageShown -> reduce { copy(message = null) }
        }
    }

    private fun toggle() {
        val state = currentState
        viewModelScope.launch {
            if (state.tunnel.isActive) {
                disconnect()
                return@launch
            }
            val profile = state.activeProfile
            if (profile == null) {
                effect(HomeEffect.NavigateToProfiles)
                return@launch
            }
            connect(profile.id).onFailure { error ->
                when (error) {
                    is AppError.Permission -> effect(HomeEffect.RequestVpnPermission)
                    else -> effect(HomeEffect.ShowMessage(error.message ?: "Не удалось подключиться"))
                }
            }
        }
    }
}
