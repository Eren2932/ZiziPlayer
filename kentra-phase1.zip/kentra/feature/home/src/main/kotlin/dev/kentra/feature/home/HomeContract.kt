package dev.kentra.feature.home

import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviState
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile

/**
 * The whole screen contract in one file: state, the intents it accepts, the effects it emits.
 * Reviewers can understand a feature without reading the Compose code.
 */
data class HomeState(
    val tunnel: TunnelState = TunnelState.Idle,
    val activeProfile: VpnProfile? = null,
    val profileCount: Int = 0,
    val traffic: TrafficSample = TrafficSample(),
    val busy: Boolean = false,
    val message: String? = null,
) : MviState {
    val canConnect: Boolean get() = activeProfile != null && !busy
}

sealed interface HomeIntent : MviIntent {
    data object ToggleConnection : HomeIntent
    data object VpnPermissionGranted : HomeIntent
    data object VpnPermissionDenied : HomeIntent
    data object OpenProfiles : HomeIntent
    data object MessageShown : HomeIntent
}

sealed interface HomeEffect : MviEffect {
    data object RequestVpnPermission : HomeEffect
    data object NavigateToProfiles : HomeEffect
    data class ShowMessage(val text: String) : HomeEffect
}
