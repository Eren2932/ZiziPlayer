package dev.kentra.feature.store

import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviState
import dev.kentra.domain.model.Entitlement
import dev.kentra.domain.model.Plan

data class StoreState(
    val plans: List<Plan> = emptyList(),
    val entitlement: Entitlement? = null,
    val activationCode: String = "",
    val busy: Boolean = false,
) : MviState

sealed interface StoreIntent : MviIntent {
    data object Load : StoreIntent
    data class Buy(val planId: String) : StoreIntent
    data class ActivationCodeChanged(val code: String) : StoreIntent
    data object Activate : StoreIntent
}

sealed interface StoreEffect : MviEffect {
    data class OpenCheckout(val url: String) : StoreEffect
    data class ShowMessage(val text: String) : StoreEffect
}
