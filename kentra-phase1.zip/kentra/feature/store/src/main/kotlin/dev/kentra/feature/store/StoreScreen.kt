package dev.kentra.feature.store

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.KentraCard
import dev.kentra.core.designsystem.KentraTokens
import dev.kentra.core.ui.CollectEffects
import org.koin.androidx.compose.koinViewModel

@Composable
fun StoreRoute(viewModel: StoreViewModel = koinViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    CollectEffects(viewModel.effects) { effect ->
        when (effect) {
            is StoreEffect.OpenCheckout ->
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(effect.url)))
            is StoreEffect.ShowMessage -> snackbar.showSnackbar(effect.text)
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = KentraTokens.SpaceMd),
            verticalArrangement = Arrangement.spacedBy(KentraTokens.SpaceSm),
        ) {
            Text("Подписка", style = MaterialTheme.typography.titleLarge)

            state.entitlement?.let { entitlement ->
                KentraCard {
                    Text(entitlement.planName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Устройств: ${entitlement.deviceLimit}",
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }

            state.plans.forEach { plan ->
                KentraCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(plan.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${plan.days} дней · до ${plan.deviceLimit} устройств",
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        Button(onClick = { viewModel.dispatch(StoreIntent.Buy(plan.id)) }) {
                            Text("${plan.priceMinor / 100} ₽")
                        }
                    }
                }
            }

            Spacer(Modifier.height(KentraTokens.SpaceSm))

            KentraCard {
                Text("Есть код активации?", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = state.activationCode,
                    onValueChange = { viewModel.dispatch(StoreIntent.ActivationCodeChanged(it)) },
                    label = { Text("Код") },
                    modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { viewModel.dispatch(StoreIntent.Activate) }) { Text("Активировать") }
            }

            Text(
                "Оплата проходит на внешней странице: так мы не платим комиссию магазина " +
                    "и не нарушаем правила о цифровых покупках внутри приложения.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
