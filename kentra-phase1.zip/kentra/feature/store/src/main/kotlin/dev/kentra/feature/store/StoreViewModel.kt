package dev.kentra.feature.store

import androidx.lifecycle.viewModelScope
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.repository.BillingRepository
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class StoreViewModel(
    private val billing: BillingRepository,
) : MviViewModel<StoreIntent, StoreState, StoreEffect>(StoreState()) {

    init {
        billing.observeEntitlement()
            .onEach { entitlement -> reduce { copy(entitlement = entitlement) } }
            .launchIn(viewModelScope)
        dispatch(StoreIntent.Load)
    }

    override suspend fun handle(intent: StoreIntent) {
        when (intent) {
            StoreIntent.Load -> {
                reduce { copy(busy = true) }
                billing.plans()
                    .onSuccess { plans -> reduce { copy(plans = plans, busy = false) } }
                    .onFailure {
                        reduce { copy(busy = false) }
                        effect(StoreEffect.ShowMessage(it.message ?: "Не удалось загрузить тарифы"))
                    }
            }
            is StoreIntent.Buy -> billing.createCheckout(intent.planId)
                .onSuccess { url -> effect(StoreEffect.OpenCheckout(url)) }
                .onFailure { effect(StoreEffect.ShowMessage("Оплата подключается на этапе 4")) }
            is StoreIntent.ActivationCodeChanged -> reduce { copy(activationCode = intent.code) }
            StoreIntent.Activate -> billing.activateCode(currentState.activationCode.trim())
                .onSuccess { effect(StoreEffect.ShowMessage("Подписка активирована")) }
                .onFailure { effect(StoreEffect.ShowMessage("Активация подключается на этапе 4")) }
        }
    }
}
