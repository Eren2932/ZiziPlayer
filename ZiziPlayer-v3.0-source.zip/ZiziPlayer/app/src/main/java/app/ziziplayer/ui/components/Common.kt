package app.ziziplayer.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable

/**
 * Custom seek bar. The stock Material slider fires a seek on every pixel of movement,
 * which is what made the play icon flicker; this one only reports the final value.
 */
@Composable
fun ZiziSlider(
    fraction: Float,
    accent: Color,
    inactive: Color,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var local by remember { mutableFloatStateOf(fraction) }
    var scrubbing by remember { mutableStateOf(false) }
    val shown = (if (scrubbing) local else fraction).coerceIn(0f, 1f)
    val density = LocalDensity.current

    Box(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val target = (offset.x / widthPx).coerceIn(0f, 1f)
                    local = target
                    onScrubEnd(target)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        scrubbing = true
                        local = (offset.x / widthPx).coerceIn(0f, 1f)
                        onScrubStart()
                        onScrub(local)
                    },
                    onDragEnd = {
                        scrubbing = false
                        onScrubEnd(local)
                    },
                    onDragCancel = {
                        scrubbing = false
                        onScrubEnd(local)
                    }
                ) { _, dragAmount ->
                    local = (local + dragAmount / widthPx).coerceIn(0f, 1f)
                    onScrub(local)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            val trackHeight = with(density) { 5.dp.toPx() }
            val radius = trackHeight / 2f
            val centerY = size.height / 2f
            drawRoundRect(
                color = inactive,
                topLeft = Offset(0f, centerY - radius),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(radius, radius)
            )
            val filled = size.width * shown
            if (filled > 0.5f) {
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(filled, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val thumb = with(density) { (if (scrubbing) 9.dp else 7.dp).toPx() }
            drawCircle(color = accent, radius = thumb, center = Offset(filled.coerceIn(thumb, size.width - thumb), centerY))
        }
    }
}

@Composable
fun PillChip(
    label: String,
    icon: ImageVector?,
    active: Boolean,
    palette: ChipColors,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val background = if (active) palette.activeBackground else palette.background
    val content = if (active) palette.activeContent else palette.content
    Row(
        modifier
            .height(50.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(19.dp))
            Box(Modifier.width(9.dp))
        }
        Text(label, color = content, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

data class ChipColors(
    val background: Color,
    val content: Color,
    val activeBackground: Color,
    val activeContent: Color
)

/** Little animated equaliser shown on the row that is currently playing. */
@Composable
fun EqualizerBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "eq")
    val a by transition.animateFloat(
        0.35f, 1f,
        infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "a"
    )
    val b by transition.animateFloat(
        1f, 0.45f,
        infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "b"
    )
    val c by transition.animateFloat(
        0.55f, 0.95f,
        infiniteRepeatable(tween(430), RepeatMode.Reverse), label = "c"
    )
    Canvas(modifier) {
        val heights = if (playing) listOf(a, b, c) else listOf(0.35f, 0.6f, 0.4f)
        val barWidth = size.width / 5f
        heights.forEachIndexed { index, value ->
            val barHeight = size.height * value
            drawRoundRect(
                color = color,
                topLeft = Offset(index * barWidth * 2f, size.height - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}

@Composable
fun RoundIconButton(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: Int = 52,
    iconSize: Int = 24,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .size(size.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize.dp))
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
