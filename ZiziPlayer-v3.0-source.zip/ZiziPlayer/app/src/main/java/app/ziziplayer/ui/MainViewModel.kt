package app.ziziplayer.ui

import android.app.Application
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlaybackState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class LibraryFilter { TRACKS, FAVORITES, PLAYLISTS, FOLDERS }

data class MainUiState(
    val tracks: List<TrackEntity> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val hiddenIds: Set<String> = emptySet(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val stats: Map<String, PlayStatEntity> = emptyMap(),
    val settings: UserSettings = UserSettings(),
    val playback: PlaybackState = PlaybackState(),
    val scanning: Boolean = false,
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = "",
    val openPlaylist: PlaylistEntity? = null,
    val openPlaylistTracks: List<TrackEntity> = emptyList(),
    val openFolder: String? = null
) {
    private val library: List<TrackEntity> by lazy { tracks.filter { it.id !in hiddenIds } }

    val folders: List<Pair<String, Int>> by lazy {
        library.groupBy { it.sourceFolder }.map { it.key to it.value.size }.sortedByDescending { it.second }
    }

    /** Tracks of the section the user is currently looking at, before search and sorting. */
    private val sectionTracks: List<TrackEntity> by lazy {
        when {
            openPlaylist != null -> openPlaylistTracks.filter { it.id !in hiddenIds }
            openFolder != null -> library.filter { it.sourceFolder == openFolder }
            filter == LibraryFilter.FAVORITES -> library.filter { it.id in favoriteIds }
            else -> library
        }
    }

    val visibleTracks: List<TrackEntity> by lazy {
        run {
            val filtered = sectionTracks.filter {
                query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true)
            }
            // a playlist keeps the order the user built by hand
            if (openPlaylist != null) return@run filtered
            when (settings.sortMode) {
                SortMode.TITLE -> filtered.sortedBy { it.title.lowercase() }
                SortMode.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
                SortMode.DURATION -> filtered.sortedByDescending { it.durationMs }
                SortMode.RECENT -> filtered.sortedByDescending { it.dateAdded }
                SortMode.PLAYS -> filtered.sortedByDescending { stats[it.id]?.playCount ?: 0 }
            }
        }
    }

    val currentTrack: TrackEntity? by lazy { tracks.firstOrNull { it.id == playback.currentTrackId } }

    val queueTracks: List<TrackEntity> by lazy {
        val byId = tracks.associateBy { it.id }
        playback.queueIds.mapNotNull { byId[it] }
    }
    val hiddenCount: Int get() = hiddenIds.size
    fun playCount(id: String): Int = stats[id]?.playCount ?: 0
}

private data class LibraryBundle(
    val tracks: List<TrackEntity>,
    val favoriteIds: Set<String>,
    val hiddenIds: Set<String>,
    val playlists: List<PlaylistEntity>,
    val stats: Map<String, PlayStatEntity>
)

private data class ShellBundle(
    val scanning: Boolean,
    val filter: LibraryFilter,
    val query: String,
    val openFolder: String?
)

private data class PlaylistBundle(
    val playlist: PlaylistEntity?,
    val tracks: List<TrackEntity>
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val application = app as ZiziApplication
    private val repo = application.repository
    val player = application.playerController

    private val scanning = MutableStateFlow(false)
    private val filter = MutableStateFlow(LibraryFilter.TRACKS)
    private val query = MutableStateFlow("")
    private val openFolder = MutableStateFlow<String?>(null)
    private val openPlaylistId = MutableStateFlow<Long?>(null)

    private val libraryFlow = combine(
        repo.tracks, repo.favoriteIds, repo.hiddenIds, repo.playlists, repo.stats
    ) { tracks, favorites, hidden, playlists, stats ->
        LibraryBundle(tracks, favorites, hidden, playlists, stats)
    }

    private val shellFlow = combine(scanning, filter, query, openFolder) { isScanning, currentFilter, currentQuery, folder ->
        ShellBundle(isScanning, currentFilter, currentQuery, folder)
    }

    private val playlistFlow: Flow<PlaylistBundle> = combine(openPlaylistId, repo.playlists) { id, playlists ->
        playlists.firstOrNull { it.id == id }
    }.flatMapLatest { playlist ->
        if (playlist == null) flowOf(PlaylistBundle(null, emptyList()))
        else repo.observePlaylistTracks(playlist.id).map { PlaylistBundle(playlist, it) }
    }

    val uiState: StateFlow<MainUiState> = combine(
        libraryFlow, shellFlow, playlistFlow, repo.settings, player.state
    ) { library, shell, playlist, settings, playback ->
        MainUiState(
            tracks = library.tracks,
            favoriteIds = library.favoriteIds,
            hiddenIds = library.hiddenIds,
            playlists = library.playlists,
            stats = library.stats,
            settings = settings,
            playback = playback,
            scanning = shell.scanning,
            filter = shell.filter,
            query = shell.query,
            openPlaylist = playlist.playlist,
            openPlaylistTracks = playlist.tracks,
            openFolder = shell.openFolder
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainUiState())

    init {
        rescan()
        // restore the last session: same track, same position, paused
        viewModelScope.launch {
            val settings = repo.settings.first()
            val trackId = settings.lastTrackId ?: return@launch
            val tracks = repo.tracks.first { it.isNotEmpty() }
            val index = tracks.indexOfFirst { it.id == trackId }
            if (index >= 0 && player.state.value.currentTrackId == null) {
                player.setQueue(tracks, index, play = false, startPositionMs = settings.lastPositionMs)
            }
        }
        // remember the position while playing
        viewModelScope.launch {
            while (true) {
                delay(4_000)
                val playback = player.state.value
                val id = playback.currentTrackId
                if (id != null && playback.positionMs > 0) repo.saveLastPosition(id, playback.positionMs)
            }
        }
        // keep the silence skipper in sync with the settings
        viewModelScope.launch {
            repo.settings.map { it.skipSilence }.distinctUntilChanged().collect { player.setSkipSilence(it) }
        }
        // count plays so "often played" sorting has something to work with
        viewModelScope.launch {
            player.state.map { it.currentTrackId }.filterNotNull().distinctUntilChanged().collect { repo.registerPlay(it) }
        }
        // apply the saved speed / pitch of every new track
        viewModelScope.launch {
            player.state.map { it.currentTrackId }.filterNotNull().distinctUntilChanged().collect { id ->
                val fx = repo.fx(id)
                player.setPlayback(fx.speed, fx.pitch, fx.reverb)
            }
        }
    }

    fun rescan() = viewModelScope.launch {
        scanning.value = true
        runCatching { repo.rescan() }
        scanning.value = false
    }

    fun addFolder(uri: Uri) = viewModelScope.launch {
        scanning.value = true
        runCatching { repo.addFolder(uri) }
        scanning.value = false
    }

    fun setFilter(value: LibraryFilter) {
        filter.value = value
        if (value != LibraryFilter.PLAYLISTS) openPlaylistId.value = null
        if (value != LibraryFilter.FOLDERS) openFolder.value = null
    }

    fun setQuery(value: String) { query.value = value }
    fun openPlaylist(id: Long?) { openPlaylistId.value = id }
    fun openFolder(name: String?) { openFolder.value = name }

    /** True when a back press has something to close inside the library. */
    val canGoBackInLibrary: Boolean get() = openPlaylistId.value != null || openFolder.value != null || query.value.isNotBlank()

    fun goBackInLibrary() {
        when {
            openPlaylistId.value != null -> openPlaylistId.value = null
            openFolder.value != null -> openFolder.value = null
            else -> query.value = ""
        }
    }

    fun play(track: TrackEntity) {
        val list = uiState.value.visibleTracks
        player.setQueue(list, list.indexOfFirst { it.id == track.id }.coerceAtLeast(0))
    }

    fun playAll(tracks: List<TrackEntity>, shuffled: Boolean = false) {
        if (tracks.isEmpty()) return
        val list = if (shuffled) tracks.shuffled() else tracks
        player.setQueue(list, 0)
    }

    fun toggleFavorite(track: TrackEntity) = viewModelScope.launch {
        repo.toggleFavorite(track.id, track.id in uiState.value.favoriteIds)
    }

    fun saveFx(trackId: String, speed: Float, pitch: Float, reverb: Int) = viewModelScope.launch {
        repo.saveFx(TrackFxEntity(trackId, speed, pitch, reverb))
        player.setPlayback(speed, pitch, reverb)
    }

    suspend fun loadFx(trackId: String) = repo.fx(trackId)

    fun createPlaylist(name: String) = viewModelScope.launch { repo.createPlaylist(name.trim().ifBlank { "Новый плейлист" }) }
    fun createPlaylistFrom(name: String, tracks: List<TrackEntity>) = viewModelScope.launch {
        val id = repo.createPlaylist(name.trim().ifBlank { "Очередь" })
        tracks.forEach { repo.addToPlaylist(id, it.id) }
    }
    fun addToPlaylist(playlistId: Long, trackId: String) = viewModelScope.launch { repo.addToPlaylist(playlistId, trackId) }
    fun removeFromPlaylist(playlistId: Long, trackId: String) = viewModelScope.launch { repo.removeFromPlaylist(playlistId, trackId) }
    fun deletePlaylist(id: Long) = viewModelScope.launch {
        if (openPlaylistId.value == id) openPlaylistId.value = null
        repo.deletePlaylist(id)
    }
    fun renamePlaylist(id: Long, name: String) = viewModelScope.launch { repo.renamePlaylist(id, name.trim().ifBlank { "Плейлист" }) }
    fun playPlaylist(playlistId: Long) = viewModelScope.launch {
        val tracks = repo.playlistTracks(playlistId)
        if (tracks.isNotEmpty()) player.setQueue(tracks, 0)
    }

    fun hideTrack(track: TrackEntity) = viewModelScope.launch { repo.hideTrack(track.id) }
    fun restoreHidden() = viewModelScope.launch { repo.clearHidden() }

    /** Returns a confirmation dialog to launch, or null when the file is already gone. */
    fun requestDeleteFile(track: TrackEntity, onIntent: (IntentSender?) -> Unit) = viewModelScope.launch {
        onIntent(repo.requestFileDeletion(track))
    }

    fun onFileDeleted(track: TrackEntity) = viewModelScope.launch { repo.forgetTrack(track.id) }

    fun setTheme(value: AppTheme) = viewModelScope.launch { repo.setTheme(value) }
    fun setDynamicAccent(value: Boolean) = viewModelScope.launch { repo.setDynamicAccent(value) }
    fun setSortMode(value: SortMode) = viewModelScope.launch { repo.setSortMode(value) }
    fun setSkipSilence(value: Boolean) = viewModelScope.launch { repo.setSkipSilence(value) }
    fun removeFolder(uri: String) = viewModelScope.launch { repo.removeFolder(uri) }
    fun setSleepTimer(minutes: Int?) { player.setSleepTimer(minutes) }
}
