package app.ziziplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {
    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE") fun observeTracks(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE id = :id") suspend fun track(id: String): TrackEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTracks(tracks: List<TrackEntity>)
    @Query("DELETE FROM tracks WHERE id NOT IN (:ids)") suspend fun deleteMissing(ids: List<String>)

    @Query("SELECT trackId FROM favorites") fun observeFavoriteIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun favorite(item: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE trackId = :id") suspend fun unfavorite(id: String)

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun observePlaylists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun createPlaylist(item: PlaylistEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addToPlaylist(item: PlaylistTrackEntity)
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId") suspend fun removeFromPlaylist(playlistId: Long, trackId: String)
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") fun observePlaylistTracks(id: Long): Flow<List<TrackEntity>>
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") suspend fun playlistTracks(id: Long): List<TrackEntity>
    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_tracks WHERE playlistId = :id") suspend fun nextPosition(id: Long): Int

    @Query("SELECT * FROM track_fx WHERE trackId = :id") suspend fun fx(id: String): TrackFxEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveFx(item: TrackFxEntity)

    @Query("DELETE FROM tracks WHERE id = :id") suspend fun deleteTrack(id: String)

    @Query("SELECT trackId FROM hidden") fun observeHiddenIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun hide(item: HiddenEntity)
    @Query("DELETE FROM hidden WHERE trackId = :id") suspend fun unhide(id: String)
    @Query("DELETE FROM hidden") suspend fun clearHidden()

    @Query("SELECT * FROM play_stats") fun observeStats(): Flow<List<PlayStatEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun ensureStat(item: PlayStatEntity)
    @Query("UPDATE play_stats SET playCount = playCount + 1, lastPlayedAt = :now WHERE trackId = :id") suspend fun bumpStat(id: String, now: Long)

    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :id") suspend fun clearPlaylist(id: Long)
    @Query("UPDATE playlists SET name = :name WHERE id = :id") suspend fun renamePlaylist(id: Long, name: String)
    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :id") suspend fun playlistSize(id: Long): Int
}
