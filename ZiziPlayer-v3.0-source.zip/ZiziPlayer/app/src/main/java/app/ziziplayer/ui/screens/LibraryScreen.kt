@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.MainUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.EqualizerBars
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.theme.LocalPalette

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    state: MainUiState,
    onOpenPlayer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    var searching by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var menuTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var fxTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmPlaylistDelete by remember { mutableStateOf<PlaylistEntity?>(null) }
    var renaming by remember { mutableStateOf<PlaylistEntity?>(null) }
    var showSleep by remember { mutableStateOf(false) }

    BackHandler(enabled = vm.canGoBackInLibrary || searching) {
        if (searching && state.query.isBlank()) searching = false else vm.goBackInLibrary()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.background)
            .statusBarsPadding()
    ) {
        // ---------------- top bar
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searching) {
                TextField(
                    value = state.query,
                    onValueChange = { vm.setQuery(it) },
                    placeholder = { Text("Поиск по трекам", color = p.subtext) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = p.chip,
                        unfocusedContainerColor = p.chip,
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                        cursorColor = p.accent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { vm.setQuery(""); searching = false }) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = p.text)
                }
            } else {
                Text("Zizi", color = p.text, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { searching = true }) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = p.text)
                }
                IconButton(onClick = { vm.playAll(state.visibleTracks, shuffled = true) }) {
                    Icon(Icons.Filled.Shuffle, contentDescription = null, tint = p.text)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Filled.Tune, contentDescription = null, tint = p.text)
                }
            }
        }

        // ---------------- section tabs
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            val tabs = listOf(
                LibraryFilter.TRACKS to "Треки",
                LibraryFilter.FAVORITES to "Избранное",
                LibraryFilter.PLAYLISTS to "Плейлисты",
                LibraryFilter.FOLDERS to "Папки"
            )
            tabs.forEach { (filter, label) ->
                val active = state.filter == filter
                Box(
                    Modifier
                        .clip(RoundedCornerShape(21.dp))
                        .background(if (active) p.accent else p.chip)
                        .clickable { vm.setFilter(filter) }
                        .padding(horizontal = 17.dp, vertical = 10.dp)
                ) {
                    Text(
                        label,
                        color = if (active) p.onAccent else p.text,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // ---------------- breadcrumb for an open playlist or folder
        val sectionName = state.openPlaylist?.name ?: state.openFolder
        AnimatedVisibility(visible = sectionName != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.goBackInLibrary() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = p.text)
                }
                Column(Modifier.weight(1f)) {
                    Text(sectionName ?: "", color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("${state.visibleTracks.size} треков", color = p.subtext, fontSize = 12.5.sp)
                }
                IconButton(onClick = { vm.playAll(state.visibleTracks) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = p.accent)
                }
                IconButton(onClick = { vm.playAll(state.visibleTracks, shuffled = true) }) {
                    Icon(Icons.Filled.Shuffle, contentDescription = null, tint = p.text)
                }
            }
        }

        if (state.scanning && state.tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = p.accent)
            }
        } else {
            Box(Modifier.weight(1f)) {
                when {
                    state.filter == LibraryFilter.PLAYLISTS && state.openPlaylist == null ->
                        PlaylistList(
                            state = state,
                            onOpen = { vm.openPlaylist(it.id) },
                            onPlay = { vm.playPlaylist(it.id) },
                            onRename = { renaming = it },
                            onDelete = { confirmPlaylistDelete = it },
                            onCreate = { vm.createPlaylist(it) }
                        )
                    state.filter == LibraryFilter.FOLDERS && state.openFolder == null ->
                        FolderList(state = state, onOpen = { vm.openFolder(it) }, onPickFolder = onPickFolder)
                    state.visibleTracks.isEmpty() -> EmptyState(onPickFolder = onPickFolder, query = state.query)
                    else -> TrackList(
                        state = state,
                        tracks = state.visibleTracks,
                        onPlay = {
                            vm.play(it)
                            onOpenPlayer()
                        },
                        onFavorite = { vm.toggleFavorite(it) },
                        onMenu = { menuTrack = it }
                    )
                }
            }
        }

        // ---------------- mini player
        val current = state.currentTrack
        if (current != null) {
            MiniPlayer(state = state, track = current, onOpen = onOpenPlayer, vm = vm)
        }
        Spacer(Modifier.navigationBarsPadding())
    }

    // ---------------- sheets and dialogs
    if (showSettings) {
        SettingsSheet(vm, state, onDismiss = { showSettings = false }, onPickFolder = {
            showSettings = false
            onPickFolder()
        })
    }
    fxTrack?.let { track ->
        FxSheet(vm, track) { fxTrack = null }
    }
    if (showSleep) {
        SleepSheet(state.playback.sleepMinutesLeft, onPick = { vm.setSleepTimer(it) }) { showSleep = false }
    }
    playlistTarget?.let { track ->
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id) },
            onCreate = { name -> vm.createPlaylistFrom(name, listOf(track)) },
            onDismiss = { playlistTarget = null }
        )
    }
    menuTrack?.let { track ->
        TrackMenuSheet(
            state = state,
            track = track,
            inPlaylist = state.openPlaylist,
            onDismiss = { menuTrack = null },
            onFx = { menuTrack = null; fxTrack = track },
            onSleep = { menuTrack = null; showSleep = true },
            onAddToPlaylist = { menuTrack = null; playlistTarget = track },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                menuTrack = null
            },
            onToggleFavorite = { vm.toggleFavorite(track); menuTrack = null },
            onHide = { vm.hideTrack(track); menuTrack = null },
            onDeleteFile = { menuTrack = null; confirmDelete = track },
            onShare = { onShare(track); menuTrack = null }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства безвозвратно.",
            confirm = "Удалить",
            onConfirm = { onDeleteFile(target); confirmDelete = null },
            onDismiss = { confirmDelete = null }
        )
    }
    confirmPlaylistDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить плейлист?",
            message = "«${target.name}» будет удалён. Сами треки останутся на месте.",
            confirm = "Удалить",
            onConfirm = { vm.deletePlaylist(target.id); confirmPlaylistDelete = null },
            onDismiss = { confirmPlaylistDelete = null }
        )
    }
    renaming?.let { target ->
        var name by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            containerColor = p.surface,
            title = { Text("Переименовать", color = p.text, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                        focusedBorderColor = p.accent,
                        unfocusedBorderColor = p.chip,
                        cursorColor = p.accent
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.renamePlaylist(target.id, name); renaming = null }) {
                    Text("Сохранить", color = p.accent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Отмена", color = p.text) } }
        )
    }
}

@Composable
private fun TrackList(
    state: MainUiState,
    tracks: List<TrackEntity>,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 12.dp)
    ) {
        items(tracks, key = { it.id }) { track ->
            val playing = track.id == state.playback.currentTrackId
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                    .clickable { onPlay(track) }
                    .padding(horizontal = 18.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                    TrackArtwork(
                        track = track,
                        maxPx = ARTWORK_ROW_PX,
                        glyphSize = 20,
                        modifier = Modifier.size(58.dp).clip(RoundedCornerShape(14.dp))
                    )
                    if (playing) {
                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = 0.45f)))
                        EqualizerBars(p.accent, state.playback.isPlaying, Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        track.title,
                        color = if (playing) p.accent else p.text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
                }
                val favorite = track.id in state.favoriteIds
                IconButton(onClick = { onFavorite(track) }) {
                    Icon(
                        if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = null,
                        tint = if (favorite) p.accent else p.subtext,
                        modifier = Modifier.size(21.dp)
                    )
                }
                IconButton(onClick = { onMenu(track) }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = null, tint = p.subtext, modifier = Modifier.size(21.dp))
                }
            }
        }
    }
}

@Composable
private fun PlaylistList(
    state: MainUiState,
    onOpen: (PlaylistEntity) -> Unit,
    onPlay: (PlaylistEntity) -> Unit,
    onRename: (PlaylistEntity) -> Unit,
    onDelete: (PlaylistEntity) -> Unit,
    onCreate: (String) -> Unit
) {
    val p = LocalPalette.current
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { creating = true }
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, contentDescription = null, tint = p.text) }
                Spacer(Modifier.width(14.dp))
                Text("Новый плейлист", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        items(state.playlists, key = { it.id }) { playlist ->
            var expanded by remember(playlist.id) { mutableStateOf(false) }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(playlist) }
                    .padding(horizontal = 18.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = p.accent) }
                Spacer(Modifier.width(14.dp))
                Text(playlist.name, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                IconButton(onClick = { onPlay(playlist) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = p.text)
                }
                Box {
                    IconButton(onClick = { expanded = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = null, tint = p.subtext)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(
                            text = { Text("Переименовать", color = p.text) },
                            onClick = { expanded = false; onRename(playlist) }
                        )
                        DropdownMenuItem(
                            text = { Text("Удалить", color = Color(0xFFFF6B6B)) },
                            onClick = { expanded = false; onDelete(playlist) }
                        )
                    }
                }
            }
        }
    }
    if (creating) {
        AlertDialog(
            onDismissRequest = { creating = false },
            containerColor = p.surface,
            title = { Text("Новый плейлист", color = p.text, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                        focusedBorderColor = p.accent,
                        unfocusedBorderColor = p.chip,
                        cursorColor = p.accent
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = { onCreate(name); name = ""; creating = false }) {
                    Text("Создать", color = p.accent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { creating = false }) { Text("Отмена", color = p.text) } }
        )
    }
}

@Composable
private fun FolderList(state: MainUiState, onOpen: (String) -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onPickFolder)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.CreateNewFolder, contentDescription = null, tint = p.accent) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Добавить папку", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text("Через файловый менеджер", color = p.subtext, fontSize = 12.5.sp)
                }
            }
        }
        items(state.folders, key = { it.first }) { (folder, count) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(folder) }
                    .padding(horizontal = 18.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(p.chip),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Folder, contentDescription = null, tint = p.text) }
                Spacer(Modifier.width(14.dp))
                Text(folder, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("$count", color = p.subtext, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
            }
        }
    }
}

@Composable
private fun EmptyState(onPickFolder: () -> Unit, query: String) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = p.subtext, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(14.dp))
        Text(
            if (query.isNotBlank()) "Ничего не найдено" else "Здесь пока пусто",
            color = p.text,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (query.isNotBlank()) "Попробуйте другой запрос" else "Добавьте папку с музыкой — треки появятся тут",
            color = p.subtext,
            fontSize = 14.sp
        )
        if (query.isBlank()) {
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onPickFolder,
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Выбрать папку", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun MiniPlayer(state: MainUiState, track: TrackEntity, onOpen: () -> Unit, vm: MainViewModel) {
    val p = LocalPalette.current
    val duration = maxOf(state.playback.durationMs, track.durationMs, 1L)
    val progress = (state.playback.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    Column(
        Modifier
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.surface)
            .clickable(onClick = onOpen)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 18,
                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1)
            }
            IconButton(onClick = { vm.player.playPause() }) {
                Icon(
                    if (state.playback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = p.text,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { vm.player.next() }) {
                Icon(Icons.Filled.SkipNext, contentDescription = null, tint = p.text, modifier = Modifier.size(26.dp))
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            color = p.accent,
            trackColor = p.chip,
            modifier = Modifier.fillMaxWidth().height(2.dp)
        )
    }
}
