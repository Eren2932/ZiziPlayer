package app.ziziplayer.data

import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class MusicRepository(
    private val context: Context,
    private val dao: MusicDao,
    private val settingsStore: SettingsStore,
    private val scanner: MusicScanner
) {
    val tracks = dao.observeTracks()
    val favoriteIds = dao.observeFavoriteIds().map { it.toSet() }
    val hiddenIds = dao.observeHiddenIds().map { it.toSet() }
    val playlists = dao.observePlaylists()
    val stats: Flow<Map<String, PlayStatEntity>> = dao.observeStats().map { list -> list.associateBy { it.trackId } }
    val settings = settingsStore.settings

    suspend fun rescan() {
        val folders = settings.first().folderUris
        val all = (scanner.scanMediaStore() + folders.flatMap { scanner.scanTree(Uri.parse(it)) })
            .distinctBy { "${it.title.lowercase()}|${it.artist.lowercase()}|${it.durationMs / 1000}" }
        if (all.isNotEmpty()) {
            dao.upsertTracks(all)
            dao.deleteMissing(all.map { it.id })
        }
    }

    suspend fun addFolder(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        settingsStore.addFolder(uri)
        rescan()
    }

    suspend fun removeFolder(uri: String) {
        settingsStore.removeFolder(uri)
        rescan()
    }

    suspend fun toggleFavorite(id: String, favorite: Boolean) {
        if (favorite) dao.unfavorite(id) else dao.favorite(FavoriteEntity(id))
    }

    suspend fun saveFx(fx: TrackFxEntity) = dao.saveFx(fx)
    suspend fun fx(id: String) = dao.fx(id) ?: TrackFxEntity(id)

    suspend fun createPlaylist(name: String) = dao.createPlaylist(PlaylistEntity(name = name))
    suspend fun addToPlaylist(playlistId: Long, trackId: String) =
        dao.addToPlaylist(PlaylistTrackEntity(playlistId, trackId, dao.nextPosition(playlistId)))
    suspend fun removeFromPlaylist(playlistId: Long, trackId: String) = dao.removeFromPlaylist(playlistId, trackId)
    suspend fun deletePlaylist(id: Long) {
        dao.clearPlaylist(id)
        dao.deletePlaylist(id)
    }
    suspend fun renamePlaylist(id: Long, name: String) = dao.renamePlaylist(id, name)
    suspend fun playlistTracks(playlistId: Long) = dao.playlistTracks(playlistId)
    fun observePlaylistTracks(playlistId: Long) = dao.observePlaylistTracks(playlistId)

    /** "Remove from my set": the track stays on the phone, it just never shows up again. */
    suspend fun hideTrack(id: String) = dao.hide(HiddenEntity(id))
    suspend fun unhideTrack(id: String) = dao.unhide(id)
    suspend fun clearHidden() = dao.clearHidden()

    suspend fun registerPlay(id: String) {
        dao.ensureStat(PlayStatEntity(id))
        dao.bumpStat(id, System.currentTimeMillis())
    }

    /** Forgets a row after its file is gone. */
    suspend fun forgetTrack(id: String) {
        dao.unfavorite(id)
        dao.deleteTrack(id)
    }

    /**
     * Deletes the real file. Android 11+ requires user confirmation for MediaStore items,
     * so we hand the IntentSender back to the activity instead of failing silently.
     */
    suspend fun requestFileDeletion(track: TrackEntity): IntentSender? {
        val uri = runCatching { Uri.parse(track.uri) }.getOrNull() ?: return null
        val resolver = context.contentResolver
        if (DocumentsContract.isDocumentUri(context, uri)) {
            runCatching { DocumentsContract.deleteDocument(resolver, uri) }
            forgetTrack(track.id)
            return null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return runCatching { MediaStore.createDeleteRequest(resolver, listOf(uri)).intentSender }.getOrNull()
        }
        runCatching { resolver.delete(uri, null, null) }
        forgetTrack(track.id)
        return null
    }

    suspend fun setTheme(theme: AppTheme) = settingsStore.setTheme(theme)
    suspend fun setDynamicAccent(value: Boolean) = settingsStore.setDynamicAccent(value)
    suspend fun setSkipSilence(value: Boolean) = settingsStore.setSkipSilence(value)
    suspend fun setSortMode(value: SortMode) = settingsStore.setSortMode(value)
    suspend fun saveLastPosition(trackId: String, positionMs: Long) = settingsStore.saveLastPosition(trackId, positionMs)
}
