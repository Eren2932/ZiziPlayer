package app.ziziplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.material3.Text
import androidx.palette.graphics.Palette
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections

/**
 * One shared bitmap cache for the whole app. Without it every row of a 400+ track list
 * re-decodes its cover on each scroll pass, which is exactly what makes lists stutter.
 */
object ArtworkCache {
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 6L).toInt().coerceIn(8 * 1024, 96 * 1024)
    private val cache = object : LruCache<String, Bitmap>(maxKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val empty = Collections.synchronizedSet(HashSet<String>())
    private val gate = Semaphore(3)

    private fun key(id: String, maxPx: Int) = "$id@$maxPx"

    fun peek(track: TrackEntity?, maxPx: Int): Bitmap? {
        val id = track?.id ?: return null
        return cache.get(key(id, maxPx))
    }

    fun known(track: TrackEntity?): Boolean = track != null && empty.contains(track.id)

    suspend fun load(context: Context, track: TrackEntity, maxPx: Int): Bitmap? {
        val cacheKey = key(track.id, maxPx)
        cache.get(cacheKey)?.let { return it }
        if (empty.contains(track.id)) return null
        return gate.withPermit {
            cache.get(cacheKey)?.let { return@withPermit it }
            withContext(Dispatchers.IO) {
                val bytes = readBytes(context, track)
                if (bytes == null) {
                    empty.add(track.id)
                    null
                } else {
                    val bitmap = decode(bytes, maxPx)
                    if (bitmap == null) empty.add(track.id) else cache.put(cacheKey, bitmap)
                    bitmap
                }
            }
        }
    }

    private fun readBytes(context: Context, track: TrackEntity): ByteArray? {
        val embedded = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(track.uri))
                retriever.embeddedPicture
            } finally {
                runCatching { retriever.release() }
            }
        }.getOrNull()
        if (embedded != null) return embedded
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { it.readBytes() }
        }.getOrNull()
    }

    private fun decode(bytes: ByteArray, maxPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        while (largest / sample > maxPx * 2) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

const val ARTWORK_ROW_PX = 192
const val ARTWORK_FULL_PX = 720

@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int): Bitmap? {
    val context = LocalContext.current
    val state = produceState<Bitmap?>(ArtworkCache.peek(track, maxPx), track?.id, maxPx) {
        val target = track
        if (target == null) {
            value = null
            return@produceState
        }
        if (value == null) value = ArtworkCache.load(context, target, maxPx)
    }
    return state.value
}

/** Stable pleasant colour pair for tracks that simply have no cover art. */
private val fallbackHues = listOf(
    Color(0xFF6C7BFF) to Color(0xFF2B2FA8),
    Color(0xFFFF7A9A) to Color(0xFF9C1F4B),
    Color(0xFF4ED8C0) to Color(0xFF126E7A),
    Color(0xFFFFB169) to Color(0xFFA84E14),
    Color(0xFFB98BFF) to Color(0xFF5B2C9E),
    Color(0xFF7ED0FF) to Color(0xFF1B5C9B),
    Color(0xFFFFD36B) to Color(0xFF9A6C10),
    Color(0xFF8CE07A) to Color(0xFF2C7A32)
)

fun fallbackColors(track: TrackEntity?): Pair<Color, Color> {
    val seedText = ((track?.title ?: "zizi") + (track?.artist ?: "")).lowercase()
    var hash = 7
    for (char in seedText) hash = hash * 31 + char.code
    val index = ((hash % fallbackHues.size) + fallbackHues.size) % fallbackHues.size
    return fallbackHues[index]
}

/** Colour that drives the whole UI tint for the given track. */
@Composable
fun rememberArtworkSeed(track: TrackEntity?, enabled: Boolean): Color? {
    val bitmap = rememberArtwork(track, ARTWORK_ROW_PX)
    val fallback = remember(track?.id) { fallbackColors(track).second }
    val extracted by produceState<Color?>(null, bitmap, enabled) {
        val source = bitmap
        value = if (!enabled || source == null) null else withContext(Dispatchers.Default) {
            runCatching {
                val palette = Palette.from(source).maximumColorCount(20).generate()
                val rgb = palette.vibrantSwatch?.rgb
                    ?: palette.lightVibrantSwatch?.rgb
                    ?: palette.mutedSwatch?.rgb
                    ?: palette.dominantSwatch?.rgb
                rgb?.let { Color(it) }
            }.getOrNull()
        }
    }
    if (!enabled) return null
    return extracted ?: if (bitmap == null && track != null) fallback else null
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44
) {
    val bitmap = rememberArtwork(track, maxPx)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val (light, dark) = fallbackColors(track)
            Canvas(Modifier.fillMaxSize()) {
                drawRect(
                    Brush.linearGradient(
                        listOf(light, dark),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height)
                    )
                )
            }
            Text(
                text = "\u266A",
                color = Color.White.copy(alpha = 0.82f),
                fontSize = glyphSize.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
