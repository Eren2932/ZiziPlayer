@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.SortMode
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.EqualizerBars
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
private fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun MenuItem(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    trailing: String? = null,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
        if (trailing != null) Text(trailing, color = p.subtext, fontSize = 14.sp)
    }
}

@Composable
private fun ToggleItem(icon: ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 22.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = p.text, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = p.onAccent,
                checkedTrackColor = p.accent,
                uncheckedTrackColor = p.chip
            )
        )
    }
}

@Composable
private fun ZiziSheetScaffold(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        contentColor = p.text,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        dragHandle = {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(p.subtext.copy(alpha = 0.45f)))
            }
        }
    ) {
        Column(Modifier.padding(bottom = 26.dp)) { content() }
    }
}

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }
    var loaded by remember(track.id) { mutableStateOf(false) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
        loaded = true
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Реверб", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$reverb%", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = reverb.toFloat(),
                onValueChange = { reverb = it.roundToInt() },
                onValueChangeFinished = { apply() },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(6.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", current?.let { "Осталось $it мин" } ?: "Выключен")
        listOf(10, 15, 20, 30, 45, 60, 90).forEach { minutes ->
            MenuItem(Icons.Filled.Bedtime, "$minutes минут") { onPick(minutes); onDismiss() }
        }
        if (current != null) {
            MenuItem(Icons.Filled.Close, "Выключить таймер") { onPick(null); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var newName by remember { mutableStateOf("") }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Добавить в плейлист")
        playlists.forEach { playlist ->
            MenuItem(Icons.Filled.QueueMusic, playlist.name) { onPick(playlist.id); onDismiss() }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.accent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* ------------------------------------------------------------------ track menu */

@Composable
fun TrackMenuSheet(
    state: MainUiState,
    track: TrackEntity,
    inPlaylist: PlaylistEntity?,
    onDismiss: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit
) {
    val p = LocalPalette.current
    val favorite = track.id in state.favoriteIds
    val plays = state.playCount(track.id)
    ZiziSheetScaffold(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 20,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(10.dp))
        MenuItem(Icons.Filled.Speed, "Скорость и тональность", onClick = onFx)
        MenuItem(
            if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            if (favorite) "Убрать из избранного" else "В избранное",
            onClick = onToggleFavorite
        )
        MenuItem(Icons.Filled.PlaylistAdd, "Добавить в плейлист", onClick = onAddToPlaylist)
        if (inPlaylist != null) {
            MenuItem(Icons.Filled.PlaylistRemove, "Убрать из «${inPlaylist.name}»", onClick = onRemoveFromPlaylist)
        }
        MenuItem(Icons.Filled.Bedtime, "Таймер сна", trailing = state.playback.sleepMinutesLeft?.let { "$it мин" }, onClick = onSleep)
        MenuItem(Icons.Filled.Share, "Поделиться файлом", onClick = onShare)
        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(Icons.Filled.VisibilityOff, "Скрыть из библиотеки", onClick = onHide)
        MenuItem(Icons.Filled.DeleteOutline, "Удалить файл с устройства", tint = Color(0xFFFF6B6B), onClick = onDeleteFile)
        Text(
            "${track.sourceFolder} · ${formatTime(track.durationMs)}" + if (plays > 0) " · прослушан $plays раз" else "",
            color = p.subtext,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
        )
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    state: MainUiState,
    onPick: (Int) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val tracks = state.queueTracks
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
            itemsIndexed(tracks, key = { _, item -> item.id }) { index, track ->
                val playing = track.id == state.playback.currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(index) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(11.dp))
                        )
                        if (playing) {
                            Box(Modifier.size(46.dp).clip(RoundedCornerShape(11.dp)).background(Color.Black.copy(alpha = 0.45f)))
                            EqualizerBars(p.accent, state.playback.isPlaying, Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

@Composable
fun SettingsSheet(vm: MainViewModel, state: MainUiState, onDismiss: () -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Настройки")
        Text("Тема", color = p.subtext, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp))
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val names = mapOf(
                AppTheme.GRAPHITE to "Графит",
                AppTheme.MIDNIGHT to "Полночь",
                AppTheme.AMOLED to "AMOLED",
                AppTheme.SUNSET to "Закат"
            )
            AppTheme.entries.forEach { theme ->
                val active = state.settings.theme == theme
                Box(
                    Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(if (active) p.accent else p.chip)
                        .clickable { vm.setTheme(theme) }
                        .padding(horizontal = 18.dp, vertical = 11.dp)
                ) {
                    Text(
                        names[theme] ?: theme.name,
                        color = if (active) p.onAccent else p.text,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        ToggleItem(Icons.Filled.Palette, "Цвет из обложки", state.settings.accentFromArtwork) { vm.setDynamicAccent(it) }
        ToggleItem(Icons.Filled.GraphicEq, "Пропускать тишину", state.settings.skipSilence) { vm.setSkipSilence(it) }
        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        Text("Сортировка", color = p.subtext, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp))
        val sortNames = mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
        SortMode.entries.forEach { mode ->
            MenuItem(
                if (state.settings.sortMode == mode) Icons.Filled.RadioButtonChecked else Icons.Filled.RadioButtonUnchecked,
                sortNames[mode] ?: mode.name,
                tint = if (state.settings.sortMode == mode) p.accent else null
            ) { vm.setSortMode(mode) }
        }
        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(Icons.Filled.FolderOpen, "Добавить папку с музыкой", onClick = onPickFolder)
        MenuItem(Icons.Filled.Refresh, "Пересканировать", trailing = "${state.tracks.size} треков") { vm.rescan() }
        if (state.hiddenCount > 0) {
            MenuItem(Icons.Filled.Visibility, "Вернуть скрытые треки", trailing = "${state.hiddenCount}") { vm.restoreHidden() }
        }
        state.settings.folderUris.forEach { uri ->
            MenuItem(Icons.Filled.Close, uri.substringAfterLast("/").ifBlank { uri }, tint = p.subtext) { vm.removeFolder(uri) }
        }
    }
}

/* ------------------------------------------------------------------ confirm */

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}
