package app.ziziplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_FULL_PX
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.PillChip
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziSlider
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Proportions measured directly from the reference screenshots (1080 px wide device). */
private const val COVER_PLAYING = 0.831f
private const val COVER_PAUSED_SCALE = 0.898f

@Composable
fun PlayerScreen(
    vm: MainViewModel,
    state: MainUiState,
    onClose: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    val haptics = LocalHapticFeedback.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val queue = state.queueTracks
    val current = state.currentTrack
    val playing = state.playback.isPlaying
    val index = state.playback.currentIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
    val indexHolder = rememberUpdatedState(index)

    var showFx by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }

    var fxLabel by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(current?.id, showFx) {
        val track = current
        fxLabel = if (track == null) null else {
            val fx = vm.loadFx(track.id)
            if (abs(fx.speed - 1f) > 0.01f || abs(fx.pitch - 1f) > 0.01f) "×%.2f".format(fx.speed) else null
        }
    }

    // ---- seek bar state: the position only jumps once, when the finger is lifted
    var scrub by remember { mutableStateOf<Float?>(null) }
    var pending by remember { mutableStateOf<Long?>(null) }
    val duration = maxOf(state.playback.durationMs, current?.durationMs ?: 0L, 1L)
    LaunchedEffect(pending, state.playback.positionMs) {
        val target = pending ?: return@LaunchedEffect
        if (abs(state.playback.positionMs - target) < 700) pending = null
    }
    LaunchedEffect(pending) {
        if (pending != null) {
            delay(1500)
            pending = null
        }
    }
    val positionMs = when {
        scrub != null -> (duration * scrub!!).toLong()
        pending != null -> pending!!
        else -> state.playback.positionMs
    }
    val fraction = (positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)

    // ---- carousel <-> player, single source of truth
    val pagerState = rememberPagerState(initialPage = index) { queue.size }
    var programmatic by remember { mutableStateOf(false) }
    LaunchedEffect(pagerState, queue.size) {
        snapshotFlow { pagerState.settledPage }
            .drop(1)
            .distinctUntilChanged()
            .collect { page ->
                if (!programmatic && page != indexHolder.value && page in queue.indices) {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    vm.player.seekToIndex(page)
                }
            }
    }
    LaunchedEffect(index, queue.size) {
        if (index in queue.indices && pagerState.currentPage != index && !pagerState.isScrollInProgress) {
            programmatic = true
            if (abs(pagerState.currentPage - index) <= 1) pagerState.animateScrollToPage(index)
            else pagerState.scrollToPage(index)
            programmatic = false
        }
    }

    // ---- swipe the whole player down to close it
    val dragY = remember { Animatable(0f) }
    val dismissAt = with(density) { 140.dp.toPx() }
    val closeHolder = rememberUpdatedState(onClose)

    BackHandler(enabled = true) { onClose() }

    val coverScale by animateFloatAsState(
        targetValue = if (playing) 1f else COVER_PAUSED_SCALE,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
        label = "coverScale"
    )
    val neighbourAlpha by animateFloatAsState(
        targetValue = if (!playing || pagerState.isScrollInProgress) 0.88f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "neighbourAlpha"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(p.background)
            .graphicsLayer {
                translationY = dragY.value
                alpha = (1f - dragY.value / (size.height * 1.4f)).coerceIn(0.35f, 1f)
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (dragY.value > dismissAt) {
                                closeHolder.value()
                                dragY.snapTo(0f)
                            } else {
                                dragY.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow))
                            }
                        }
                    },
                    onDragCancel = { scope.launch { dragY.animateTo(0f) } }
                ) { _, delta ->
                    scope.launch { dragY.snapTo((dragY.value + delta).coerceAtLeast(0f)) }
                }
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ---------------- header
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(
                    icon = Icons.Filled.KeyboardArrowDown,
                    tint = p.text,
                    background = Color.Transparent,
                    size = 46,
                    iconSize = 30,
                    onClick = onClose
                )
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (state.openPlaylist != null) "ПЛЕЙЛИСТ" else "ПАПКА НА УСТРОЙСТВЕ",
                        color = p.subtext,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp,
                        maxLines = 1
                    )
                    Text(
                        text = state.openPlaylist?.name ?: current?.sourceFolder ?: "Zizi",
                        color = p.text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
                RoundIconButton(
                    icon = Icons.Filled.Share,
                    tint = p.text,
                    background = Color.Transparent,
                    size = 46,
                    iconSize = 23,
                    onClick = { current?.let(onShare) }
                )
            }

            // ---------------- carousel
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val screenWidth = maxWidth
                val coverSize = screenWidth * COVER_PLAYING
                val sidePadding = (screenWidth - coverSize) / 2
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(coverSize + 26.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // soft glow in the artwork colour, cheaper than a real blur and works on every Android
                    Box(
                        Modifier
                            .size(coverSize * 1.25f)
                            .background(
                                Brush.radialGradient(
                                    listOf(p.accent.copy(alpha = 0.20f), Color.Transparent)
                                )
                            )
                    )
                    if (queue.isEmpty()) {
                        TrackArtwork(
                            track = current,
                            maxPx = ARTWORK_FULL_PX,
                            glyphSize = 64,
                            modifier = Modifier.size(coverSize).clip(RoundedCornerShape(26.dp))
                        )
                    } else {
                        HorizontalPager(
                            state = pagerState,
                            contentPadding = PaddingValues(horizontal = sidePadding),
                            pageSpacing = 17.dp,
                            beyondViewportPageCount = 1,
                            modifier = Modifier.fillMaxWidth().height(coverSize)
                        ) { page ->
                            val track = queue.getOrNull(page)
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        val distance = abs(
                                            (page - pagerState.currentPage) - pagerState.currentPageOffsetFraction
                                        ).coerceIn(0f, 1f)
                                        val scale = coverScale * (1f - 0.04f * distance)
                                        scaleX = scale
                                        scaleY = scale
                                        alpha = 1f - distance * (1f - neighbourAlpha)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                TrackArtwork(
                                    track = track,
                                    maxPx = ARTWORK_FULL_PX,
                                    glyphSize = 64,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .shadow(
                                            elevation = 22.dp,
                                            shape = RoundedCornerShape(26.dp),
                                            ambientColor = p.accent,
                                            spotColor = Color.Black
                                        )
                                        .clip(RoundedCornerShape(26.dp))
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---------------- title + the single overflow button
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = current?.title ?: "Нет трека",
                        color = p.text,
                        fontSize = 29.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = current?.artist ?: "Выберите папку с музыкой",
                        color = p.subtext,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                }
                Spacer(Modifier.width(10.dp))
                val favorite = current != null && current.id in state.favoriteIds
                RoundIconButton(
                    icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    tint = if (favorite) p.accent else p.text,
                    background = p.chip,
                    size = 52,
                    iconSize = 24,
                    onClick = { current?.let { vm.toggleFavorite(it) } }
                )
                Spacer(Modifier.width(11.dp))
                RoundIconButton(
                    icon = Icons.Filled.MoreVert,
                    tint = p.text,
                    background = p.chip,
                    size = 52,
                    iconSize = 24,
                    onClick = { if (current != null) showMenu = true }
                )
            }

            Spacer(Modifier.height(16.dp))

            // ---------------- chips, each one does its own thing
            val chipColors = ChipColors(
                background = p.chip,
                content = p.text,
                activeBackground = p.accent,
                activeContent = p.onAccent
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 22.dp),
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                PillChip(
                    label = fxLabel ?: "Скорость и тон",
                    icon = Icons.Filled.Speed,
                    active = fxLabel != null,
                    palette = chipColors,
                    onClick = { if (current != null) showFx = true }
                )
                val sleepLeft = state.playback.sleepMinutesLeft
                PillChip(
                    label = sleepLeft?.let { "Сон · $it мин" } ?: "Таймер сна",
                    icon = Icons.Filled.Bedtime,
                    active = sleepLeft != null,
                    palette = chipColors,
                    onClick = { showSleep = true }
                )
                PillChip(
                    label = "В плейлист",
                    icon = Icons.Filled.PlaylistAdd,
                    active = false,
                    palette = chipColors,
                    onClick = { if (current != null) showPlaylists = true }
                )
                PillChip(
                    label = "Ещё",
                    icon = Icons.Filled.MoreHoriz,
                    active = false,
                    palette = chipColors,
                    onClick = { if (current != null) showMenu = true }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ---------------- seek bar
            Column(Modifier.padding(horizontal = 22.dp)) {
                ZiziSlider(
                    fraction = fraction,
                    accent = p.text,
                    inactive = p.text.copy(alpha = 0.22f),
                    onScrubStart = { },
                    onScrub = { scrub = it },
                    onScrubEnd = { value ->
                        val target = (duration * value).toLong()
                        scrub = null
                        pending = target
                        vm.player.seekTo(target)
                    }
                )
                Row(Modifier.fillMaxWidth().padding(top = 2.dp)) {
                    Text(formatTime(positionMs), color = p.subtext, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Text("-" + formatTime((duration - positionMs).coerceAtLeast(0)), color = p.subtext, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(10.dp))

            // ---------------- transport
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RoundIconButton(
                    icon = Icons.Filled.Shuffle,
                    tint = if (state.playback.shuffle) p.accent else p.text,
                    background = Color.Transparent,
                    size = 52,
                    iconSize = 25,
                    onClick = { vm.player.toggleShuffle() }
                )
                RoundIconButton(
                    icon = Icons.Filled.SkipPrevious,
                    tint = p.text,
                    background = Color.Transparent,
                    size = 58,
                    iconSize = 38,
                    onClick = { vm.player.previous() }
                )
                RoundIconButton(
                    icon = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    tint = p.text,
                    background = Color.Transparent,
                    size = 76,
                    iconSize = 54,
                    onClick = { vm.player.playPause() }
                )
                RoundIconButton(
                    icon = Icons.Filled.SkipNext,
                    tint = p.text,
                    background = Color.Transparent,
                    size = 58,
                    iconSize = 38,
                    onClick = { vm.player.next() }
                )
                val repeatIcon = when (state.playback.repeatMode) {
                    Player.REPEAT_MODE_ONE -> Icons.Filled.RepeatOne
                    else -> Icons.Filled.Repeat
                }
                RoundIconButton(
                    icon = repeatIcon,
                    tint = if (state.playback.repeatMode == Player.REPEAT_MODE_OFF) p.text else p.accent,
                    background = Color.Transparent,
                    size = 52,
                    iconSize = 25,
                    onClick = { vm.player.cycleRepeat() }
                )
            }

            Spacer(Modifier.weight(1f))

            // ---------------- bottom bar: queue + folders (no lyrics, we are local)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(p.bottom.copy(alpha = 0.92f))
                    .height(72.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { showQueue = true },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = p.text, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Очередь", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(p.chip)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("${queue.size}", color = p.text, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(onClick = onPickFolder),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = p.text, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Папки", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // small hint that the player can be swiped away
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 2.dp)
                .size(width = 34.dp, height = 3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(p.subtext.copy(alpha = 0.35f))
        )
    }

    // ---------------- sheets
    val track = current
    if (track != null && showFx) FxSheet(vm, track) { showFx = false }
    if (showSleep) {
        SleepSheet(state.playback.sleepMinutesLeft, onPick = { vm.setSleepTimer(it) }) { showSleep = false }
    }
    if (track != null && showPlaylists) {
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id) },
            onCreate = { name -> vm.createPlaylistFrom(name, listOf(track)) },
            onDismiss = { showPlaylists = false }
        )
    }
    if (showQueue) {
        QueueSheet(
            state = state,
            onPick = { vm.player.seekToIndex(it) },
            onSaveAsPlaylist = { vm.createPlaylistFrom("Очередь", queue) },
            onDismiss = { showQueue = false }
        )
    }
    if (track != null && showMenu) {
        TrackMenuSheet(
            state = state,
            track = track,
            inPlaylist = state.openPlaylist,
            onDismiss = { showMenu = false },
            onFx = { showMenu = false; showFx = true },
            onSleep = { showMenu = false; showSleep = true },
            onAddToPlaylist = { showMenu = false; showPlaylists = true },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                showMenu = false
            },
            onToggleFavorite = { vm.toggleFavorite(track); showMenu = false },
            onHide = { vm.hideTrack(track); showMenu = false },
            onDeleteFile = { showMenu = false; confirmDelete = track },
            onShare = { onShare(track); showMenu = false }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства безвозвратно.",
            confirm = "Удалить",
            onConfirm = {
                onDeleteFile(target)
                confirmDelete = null
            },
            onDismiss = { confirmDelete = null }
        )
    }
}
