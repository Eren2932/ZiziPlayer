package app.ziziplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.rememberArtworkSeed
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.animatePalette
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private var deleteTarget: TrackEntity? = null
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { vm.addFolder(it) }
        }
        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = deleteTarget
            deleteTarget = null
            if (result.resultCode == RESULT_OK && target != null) vm.onFileDeleted(target)
        }
        val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) vm.rescan()
        }

        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        } else {
            vm.rescan()
        }

        setContent {
            ZiziApp(
                vm = vm,
                onPickFolder = { folderLauncher.launch(null) },
                onShare = ::shareTrack,
                onDeleteFile = ::deleteTrackFile
            )
        }
    }

    private fun shareTrack(track: TrackEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(track.uri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, track.title)) }
    }

    /** Android 11+ asks the user itself, so we forward its confirmation dialog. */
    private fun deleteTrackFile(track: TrackEntity) {
        vm.requestDeleteFile(track) { sender ->
            if (sender == null) return@requestDeleteFile
            deleteTarget = track
            runCatching { deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
        }
    }
}

@Composable
private fun ZiziApp(
    vm: MainViewModel,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    // one colour seed drives the whole app: player, library, sheets, mini player
    val seed = rememberArtworkSeed(state.currentTrack, state.settings.accentFromArtwork)
    val target = basePalette(state.settings.theme).tintedWith(seed).withAccent(seed)
    val palette = animatePalette(target)

    CompositionLocalProvider(LocalPalette provides palette) {
        ZiziTheme(palette) {
            var playerOpen by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxSize().background(palette.background)) {
                AnimatedContent(
                    targetState = playerOpen,
                    transitionSpec = {
                        if (targetState) {
                            (slideInVertically(tween(240, easing = FastOutSlowInEasing)) { height -> height / 5 } +
                                fadeIn(tween(140))) togetherWith fadeOut(tween(160))
                        } else {
                            fadeIn(tween(160)) togetherWith
                                (slideOutVertically(tween(220, easing = FastOutSlowInEasing)) { height -> height / 5 } +
                                    fadeOut(tween(130)))
                        }
                    },
                    label = "screens"
                ) { open ->
                    if (open) {
                        PlayerScreen(
                            vm = vm,
                            state = state,
                            onClose = { playerOpen = false },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    } else {
                        LibraryScreen(
                            vm = vm,
                            state = state,
                            onOpenPlayer = { playerOpen = true },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    }
                }
            }
        }
    }
}
