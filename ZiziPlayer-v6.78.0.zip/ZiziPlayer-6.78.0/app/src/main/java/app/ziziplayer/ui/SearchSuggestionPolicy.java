package app.ziziplayer.ui;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Pure policy, shared by production and JVM tests. No synthetic history or catalog scores. */
public final class SearchSuggestionPolicy {
    private SearchSuggestionPolicy() {}
    public static final int LIMIT = 5;
    private static final Pattern SPACE = Pattern.compile("[\\s\\p{Z}]+");
    // Only completion text is folded. Playable track titles/ids/versions are never changed.
    private static final Pattern VERSION = Pattern.compile(
        "(?i)(?:\\s*[-–—]\\s*|\\s*\\()(?:ultra |super |extra )?" +
        "(?:slowed(?: down)?|sped up|speed up)(?:\\s*(?:\\+|&|and)\\s*reverb)?\\)?$");

    public static final class Suggestion {
        public final String text;
        public final boolean recent;
        public Suggestion(String text, boolean recent) { this.text = text; this.recent = recent; }
        public String key() { return normalize(text); }
    }

    public static String clean(String value) {
        return SPACE.matcher(value == null ? "" : Normalizer.normalize(value, Normalizer.Form.NFKC))
            .replaceAll(" ").trim();
    }
    public static String normalize(String value) { return clean(value).toLowerCase(Locale.ROOT); }

    /** Word-boundary matches only; 'mon' must not match 'lemon'. Prefixes rank first. */
    public static boolean matches(String value, String query) {
        String text = normalize(value), needle = normalize(query);
        if (needle.isEmpty()) return false;
        int from = 0;
        while (from <= text.length()) {
            int at = text.indexOf(needle, from);
            if (at < 0) return false;
            if (at == 0 || !Character.isLetterOrDigit(text.codePointBefore(at))) return true;
            from = at + 1;
        }
        return false;
    }

    /** Provider order first, real metadata fallback, then up to two reserved history slots.
     * More history fills unused slots. Duplicates retain HISTORY provenance regardless of source.
     * Metadata version variants collapse into one completion, not five almost identical rows.
     */
    public static List<Suggestion> build(String query, List<String> remote,
                                          List<String> history, List<String> metadata) {
        String needle = normalize(query);
        if (needle.length() < 2) return java.util.Collections.emptyList();
        Map<String, String> recent = new LinkedHashMap<>();
        for (String value : history) if (matches(value, needle)) recent.putIfAbsent(normalize(value), clean(value));
        Map<String, String> normal = new LinkedHashMap<>();
        for (String value : remote) add(normal, value); // Provider may legitimately correct spelling.

        List<String> matched = new ArrayList<>();
        Map<String, Integer> words = new LinkedHashMap<>();
        for (String value : metadata) {
            String title = clean(value);
            if (!matches(title, needle)) continue;
            String canonical = VERSION.matcher(title).replaceFirst("").trim();
            if (canonical.isEmpty()) canonical = title;
            matched.add(canonical);
            String first = normalize(canonical).split(" ", 2)[0];
            if (first.startsWith(needle) && first.length() > needle.length()) words.merge(first, 1, Integer::sum);
        }
        // A shared leading word is taken verbatim from actual metadata, never hard-coded.
        for (Map.Entry<String, Integer> word : words.entrySet()) if (word.getValue() >= 2) add(normal, word.getKey());
        for (String value : matched) if (normalize(value).startsWith(needle)) add(normal, value);
        for (String value : matched) add(normal, value);
        normal.keySet().removeAll(recent.keySet());
        List<Suggestion> out = new ArrayList<>();
        int regularSlots = LIMIT - Math.min(2, recent.size());
        for (String value : normal.values()) {
            if (out.size() >= regularSlots) break;
            out.add(new Suggestion(value, false));
        }
        for (String value : recent.values()) {
            if (out.size() >= LIMIT) break;
            out.add(new Suggestion(value, true));
        }
        return out;
    }
    private static void add(Map<String, String> target, String value) {
        String text = clean(value);
        if (!text.isEmpty()) target.putIfAbsent(normalize(text), text);
    }
}
