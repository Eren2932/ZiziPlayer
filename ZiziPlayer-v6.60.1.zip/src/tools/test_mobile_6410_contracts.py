#!/usr/bin/env python3
"""Контракты редизайна 6.41.0 по эталону: шапка поиска, лупа, знак медиатеки, панель, капсула.

6.41.1: обновлены намеренно изменённые размеры поля/кнопок; неизменённые свойства защищены.
Это проверка ИСХОДНИКОВ, а не компиляции и не отрисовки. Смысл файла — не дать следующему
релизу «поправить на глаз» числа, снятые с эталона попиксельно: каждая константа ниже привязана
к замеру, который записан в KDoc соответствующего места.
"""
from pathlib import Path
import os
import unittest

ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
JAVA = ROOT / 'app/src/main/java/app/ziziplayer'


def read(path):
    return (JAVA / path).read_text()


class Mobile6410Contracts(unittest.TestCase):
    def test_version_and_preflight(self):
        gradle = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 113', gradle)
        self.assertIn('versionName = "6.60.1"', gradle)
        preflight = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn("'test_mobile_6410_contracts.py'", preflight)

    def test_lens_geometry_is_the_reference_one(self):
        """Голова больше, линия тоньше: отношения 0.885 и 0.090 против прежних 0.816 и 0.113."""
        icons = read('ui/components/ZiziIcons.kt')
        self.assertIn('internal const val LENS_STROKE = 2.0f', icons)
        self.assertIn('circle(10.5f, 10.5f, 8.9f)', icons)
        self.assertIn('moveTo(16.5f, 16.5f); lineTo(22.0f, 22.0f)', icons)
        self.assertIn('heavy("zizi_search", LENS_STROKE)', icons)
        self.assertIn('heavy("zizi_search_off", LENS_STROKE)', icons)
        # Прежней геометрии не осталось нигде: иначе два разных знака лупы в одном приложении.
        self.assertNotIn('circle(10.6f, 10.6f, 6.4f)', icons)

    def test_library_icon_is_shelves_and_frame(self):
        icons = read('ui/components/ZiziIcons.kt')
        self.assertIn('mixed(', icons)
        self.assertIn('name = "zizi_library"', icons)
        self.assertIn('roundedRect(2.65f, 9.8f, 20.85f, 22.35f, 2.3f)', icons)
        self.assertIn('moveTo(7.5f, 1.6f); lineTo(17.4f, 1.6f)', icons)
        self.assertIn('moveTo(5.2f, 5.3f); lineTo(20.3f, 5.3f)', icons)
        # Треугольник именно ЗАЛИТЫЙ: обводкой на 19 dp он слипается в пятно.
        self.assertIn('fillPath = {', icons)
        self.assertNotIn('circle(13.6f, 16.4f, 2.6f)', icons)

    def test_mic_exists_and_is_wired_to_system_recognizer(self):
        self.assertIn('val Mic: ImageVector', read('ui/components/ZiziIcons.kt'))
        search = read('ui/screens/SearchScreen.kt')
        self.assertIn('RecognizerIntent.ACTION_RECOGNIZE_SPEECH', search)
        self.assertIn('rememberLauncherForActivityResult', search)
        # Тихий отказ, а не жалоба человеку на отсутствие чужого приложения.
        self.assertIn('catch (e: ActivityNotFoundException)', search)
        self.assertIn('VoiceSearchButton(onResult = onSubmit)', search)

    def test_search_chrome_two_layers_with_measured_alphas(self):
        chrome = read('ui/components/TopChrome.kt')
        self.assertIn('fun Modifier.searchChrome(brand: Color, cover: Color)', chrome)
        self.assertIn('brand.copy(alpha = 0.26f)', chrome)
        self.assertIn('cover.copy(alpha = 0.23f)', chrome)
        self.assertIn('SEARCH_CHROME_BASE.copy(alpha = 0.74f)', chrome)
        self.assertIn('Color(0xFF121212)', chrome)

    def test_search_header_block_metrics(self):
        search = read('ui/screens/SearchScreen.kt')
        self.assertIn('.searchChrome(p.brand, p.top)', search)
        self.assertIn('Spacer(Modifier.height(9.dp))', search)
        self.assertIn('.heightIn(min = 48.dp)', search)  # 6.41.3: header fits the touch target
        self.assertIn('Spacer(Modifier.height(20.dp))', search)
        self.assertIn('fontSize = 25.sp', search)
        self.assertIn('"Популярно сейчас"', search)
        self.assertIn('"все жанры"', search)
        self.assertIn('hubList.animateScrollToItem(genresIndex)', search)

    def test_search_field_is_dark_with_brand_border(self):
        search = read('ui/screens/SearchScreen.kt')
        self.assertIn('.background(Color(0xFF1B171B))', search)
        self.assertIn('.border(1.2.dp, p.brand, RoundedCornerShape(12.dp))', search)
        self.assertIn('.heightIn(min = 51.5.dp)', search)
        self.assertIn('modifier = Modifier.size(21.dp)', search)
        # Белого поля больше нет: это и был главный спор шапки с содержимым раздела.
        self.assertNotIn('if (focusedSurface) Color(0xFF292929) else Color.White', search)

    def test_refresh_button_is_ringed_and_white(self):
        search = read('ui/screens/SearchScreen.kt')
        self.assertIn('.size(32.4.dp)', search)
        self.assertIn('.border(1.dp, Color.White.copy(alpha = 0.20f), CircleShape)', search)
        self.assertIn('tint = if (refreshing) p.brand else Color.White.copy(alpha = 0.92f)', search)

    def test_tab_bar_has_no_surface_and_carries_a_dot(self):
        tab = read('ui/components/TabBar.kt')
        self.assertIn('val TAB_BAR_HEIGHT = 46.dp', tab)
        self.assertIn('LIBRARY("Медиатека", ZiziIcons.Library, 19.dp)', tab)
        self.assertIn('SEARCH("Поиск", ZiziIcons.Search, 17.5.dp)', tab)
        self.assertIn('fontSize = 9.5.sp', tab)
        self.assertIn('.size(3.5.dp)', tab)
        self.assertIn('background(dot.copy(alpha = emphasis))', tab)
        self.assertIn('active = p.text', tab)
        # Подложки панели нет: её роль взяла на себя плавающая капсула плеера.
        self.assertNotIn('.background(p.surface.copy(alpha = 0.97f))', tab)

    def test_mini_player_is_a_floating_capsule(self):
        lib = read('ui/screens/LibraryScreen.kt')
        self.assertIn('private val MINI_HEIGHT = 59.dp', lib)
        self.assertIn('.padding(horizontal = 20.dp)', lib)
        self.assertIn('.padding(bottom = 12.dp)', lib)
        self.assertIn('.shadow(10.dp, CircleShape, clip = false)', lib)
        self.assertIn('.size(42.dp)', lib)
        self.assertIn('.clip(CircleShape)', lib)
        self.assertIn('MiniProgressLine(vm, Modifier.fillMaxWidth())', lib)
        self.assertIn('MiniEqualizerBars(', lib)
        self.assertIn('IconButton(onClick = vm::next, modifier = Modifier.size(48.dp))', lib)

    def test_mini_equalizer_has_four_bars_on_reference_grid(self):
        common = read('ui/components/Common.kt')
        self.assertIn('fun MiniEqualizerBars(', common)
        self.assertIn('size.width * 0.15f', common)
        self.assertIn('size.width * 0.2667f', common)
        self.assertIn('bar(color, step * 3f, fourth, barWidth, radius)', common)
        # Прежний трёхполосный знак не тронут: он стоит в десятке строк списков.
        self.assertIn('fun EqualizerBars(', common)

    def test_app_name_is_gone_from_visible_texts(self):
        """Внутри приложения названия нет — ровно как на эталоне.

        Исключения осознанные: путь папки загрузок Музыка/Zizi (её переименование оторвало бы
        уже скачанные файлы), User-Agent и заголовки сети, тема письма со сбоем и ярлык
        запуска — это не тексты интерфейса, а внешняя идентификация приложения.
        """
        import re
        for path in (
            'ui/screens/LibraryScreen.kt',
            'ui/screens/SearchScreen.kt',
            'ui/screens/PlaylistShareSheets.kt',
            'ui/components/VaultAuthDialog.kt',
            'ui/MainViewModel.kt',
        ):
            for literal in re.findall(r'"([^"\n]*)"', read(path)):
                self.assertNotIn('Zizi', literal, f'название приложения осталось в {path}: {literal}')
        sheets = read('ui/screens/Sheets.kt')
        self.assertIn('"Скрыть из плеера"', sheets)
        self.assertIn('label = "Приложение"', sheets)
        strings = (ROOT / 'app/src/main/res/values/strings.xml').read_text()
        self.assertIn('<string name="import_playlist">Импорт плейлиста</string>', strings)


if __name__ == '__main__':
    unittest.main(verbosity=2)
