#!/usr/bin/env python3
"""Production Java plus source wiring guards, not Kotlin/Compose execution."""
from pathlib import Path
import ast
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
SCREENS = SRC / 'ui/screens'

class Collection6601(unittest.TestCase):
    def test_production_geometry(self):
        files = [SRC / 'ui/CollectionGeometry.java', SRC / 'ui/CollectionCollapseMath.java',
                 ROOT / 'app/src/test/java/app/ziziplayer/ui/Collection6601Checks.java']
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                            '-d', out, *map(str, files)], check=True)
            subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.Collection6601Checks'], check=True)

    def test_menu_has_no_expanded_hit_target(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        menu = s.split('if (onMenu != null && bannerAlpha > 0f) {', 1)[1].split('// One Play instance', 1)[0]
        for part in ['enabled = toolbarVisibleForSemantics', 'alpha = bannerAlpha', 'Modifier.clearAndSetSemantics {}']:
            self.assertIn(part, menu)
        self.assertEqual(s.count('"Меню плейлиста"'), 1)

    def test_panel_title_and_menu_share_fade(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        self.assertEqual(s.count('alpha = bannerAlpha'), 3)
        self.assertIn('val toolbarVisibleForSemantics = bannerAlpha >= 1f', s)
        self.assertIn('remember(list, heroPx, expandedPx, pinnedPx)', s)
        self.assertIn('if (heroPx > 0) collapse() else 0f', s)

    def test_search_removed_from_all_shared_collection_routes(self):
        for name in ['UnifiedLocalCollectionScreen.kt', 'HomeCollectionScreen.kt', 'RemoteCollectionScreen.kt']:
            s = (SCREENS / name).read_text()
            for bad in ['Поиск в подборке', 'OutlinedTextField(', 'BasicTextField(', 'vm.setQuery(']:
                self.assertNotIn(bad, s)
            self.assertIn('CollectionActionsRow(', s)
            self.assertNotIn('ZiziIcons.Shuffle', s)  # sole shared layout, no stray left shuffle

    def test_actions_use_same_size_end_and_bottom(self):
        s = (SCREENS / 'PinnedCollectionScaffold.kt').read_text()
        self.assertIn('val playSize = G.ACTION_SIZE.dp', s)
        self.assertIn('padding(end = G.ACTION_END.dp)', s)
        row = s.split('internal fun CollectionActionsRow(', 1)[1]
        for part in ['padding(end = G.ACTION_SIZE.dp)', 'verticalAlignment = Alignment.Bottom',
                     'Modifier.weight(1f)', 'FlowRow(', 'Modifier.size(G.ACTION_SIZE.dp)',
                     'Modifier.size(G.SHUFFLE_ICON_SIZE.dp)']:
            self.assertIn(part, row)
        for name in ['UnifiedLocalCollectionScreen.kt', 'HomeCollectionScreen.kt', 'RemoteCollectionScreen.kt']:
            s = (SCREENS / name).read_text()
            self.assertIn('padding(horizontal = G.ACTION_END.dp)', s)
            self.assertIn('G.ACTION_BOTTOM_GAP.dp', s)

    def test_existing_local_actions_and_source_identity_preserved(self):
        s = (SCREENS / 'UnifiedLocalCollectionScreen.kt').read_text()
        for part in ['onClick = onSort', 'onClick = onAdd', 'showDownloads = true',
                     'CollectionDownloadDialog(vm, state.collectionTracks', 'PlaylistActionsHost(',
                     'vm.play(it, shuffled, destination)', 'playback.queueSourceId == destination']:
            self.assertIn(part, s)

    def test_no_hidden_filter_on_navigation(self):
        s = (SRC / 'ui/MainViewModel.kt').read_text()
        for method in ['setFilter', 'openPlaylist', 'openFolder']:
            block = s.split('fun ' + method + '(', 1)[1].split('\n    }', 1)[0]
            self.assertIn('query = ""', block)
            self.assertIn('searchOpen = false', block)

    def test_empty_lists_disable_shuffle_on_all_routes(self):
        for name, data in [('UnifiedLocalCollectionScreen.kt', 'state.visible'),
                           ('HomeCollectionScreen.kt', 'tracks'), ('RemoteCollectionScreen.kt', 'open.tracks')]:
            self.assertIn('shuffleEnabled = ' + data + '.isNotEmpty()', (SCREENS / name).read_text())

    def test_release_identity(self):
        s = (ROOT / 'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 113', s)
        self.assertIn('versionName = "6.60.1"', s)

    def test_connected_to_existing_ci_preflight(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        main = next(n for n in ast.parse(s).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        self.assertIn('test_collection_6601.py', ast.get_source_segment(s, main))

if __name__ == '__main__':
    unittest.main(verbosity=2)
