package app.ziziplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.screens.CollectionActionsRow
import app.ziziplayer.ui.screens.PinnedCollectionScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import kotlin.math.abs

/** Instrumentation regressions: must be compiled/run on Android, NOT offline source checks. */
class CollectionHeader6601Test {
    @get:Rule val compose = createComposeRule()
    private var menuClicks = 0
    private var shuffleClicks = 0
    private var playClicks = 0

    private fun mount(count: Int = 40, fontScale: Float = 1f, width: Int = 360, withMenu: Boolean = true) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalPalette provides basePalette(), LocalDensity provides Density(density, fontScale)) {
                Box(Modifier.requiredSize(width.dp, 640.dp)) {
                    PinnedCollectionScaffold(destination = "test:6601", title = "Collection with a long title",
                        tint = Color.DarkGray, trackCount = count, playingHere = false, playEnabled = count > 0,
                        onBack = {}, onPlay = { playClicks++ },
                        onMenu = if (withMenu) { { menuClicks++ } } else null,
                        artwork = { Box(Modifier.fillMaxSize().background(Color.Gray)) },
                        hero = {
                            Column(Modifier.fillMaxWidth().padding(horizontal = CollectionGeometry.ACTION_END.dp)) {
                                Text("Collection with a long title")
                                CollectionActionsRow(onShuffle = { shuffleClicks++ }, shuffleEnabled = count > 0) {
                                    IconButton(onClick = {}) { Text("D") }
                                    IconButton(onClick = {}) { Text("S") }
                                    TextButton(onClick = {}) { Text("Импорт") }
                                }
                                Spacer(Modifier.height(CollectionGeometry.ACTION_BOTTOM_GAP.dp))
                            }
                        }) {
                        items(count) { Text("Track $it", Modifier.fillMaxWidth().height(64.dp)) }
                    }
                }
            }
        }
    }

    private fun assertAdjacent() {
        compose.waitForIdle()
        val play = compose.onNodeWithTag("collection:play").fetchSemanticsNode().boundsInRoot
        val shuffle = compose.onNodeWithTag("collection:shuffle").fetchSemanticsNode().boundsInRoot
        assertTrue("Shuffle must be visible", shuffle.width > 0 && shuffle.height > 0)
        assertTrue("Same button width", abs(play.width - shuffle.width) <= 1f)
        assertTrue("Same vertical center", abs(play.center.y - shuffle.center.y) <= 1f)
        assertTrue("Adjacent, non-overlapping touch targets", abs(play.left - shuffle.right) <= 1f)
    }

    @Test fun expandedHeaderHasNoMenuOrHiddenMenuAction() {
        mount()
        compose.onNodeWithTag("collection:menu", useUnmergedTree = true).assertDoesNotExist()
        compose.onNodeWithContentDescription("Меню плейлиста").assertDoesNotExist()
    }

    @Test fun pinnedMenuWorksAndDisappearsAfterReturningToTop() {
        mount()
        compose.onNodeWithTag("collection:list").performScrollToIndex(10)
        compose.onNodeWithContentDescription("Меню плейлиста").assertIsDisplayed().assertIsEnabled().performClick()
        compose.runOnIdle { assertEquals(1, menuClicks) }
        compose.onAllNodesWithContentDescription("Слушать подборку").assertCountEquals(1)
        compose.onNodeWithTag("collection:list").performScrollToIndex(0)
        compose.onNodeWithContentDescription("Меню плейлиста").assertDoesNotExist()
    }

    @Test fun normalActionsAreAdjacentAndCallbacksRemainSeparate() {
        mount()
        assertAdjacent()
        compose.onNodeWithTag("collection:shuffle").performClick()
        compose.onNodeWithTag("collection:play").performClick()
        compose.runOnIdle { assertEquals(1, shuffleClicks); assertEquals(1, playClicks); assertEquals(0, menuClicks) }
    }

    @Test fun narrowWidthAndLargeFontKeepRightControlsAligned() {
        mount(width = 320, fontScale = 2f)
        assertAdjacent()
    }

    @Test fun emptyCollectionDisablesBothPlaybackActions() {
        mount(count = 0)
        assertAdjacent()
        compose.onNodeWithTag("collection:shuffle").assertIsNotEnabled()
        compose.onNodeWithTag("collection:play").assertIsNotEnabled()
    }

    @Test fun oneTrackStillAllowsPinnedMenu() {
        mount(count = 1)
        compose.onNodeWithTag("collection:list").performScrollToIndex(1)
        compose.onNodeWithContentDescription("Меню плейлиста").assertIsDisplayed().assertIsEnabled()
    }

    @Test fun destinationsWithoutMenuDoNotAcquireOne() {
        mount(withMenu = false)
        compose.onNodeWithTag("collection:list").performScrollToIndex(10)
        compose.onNodeWithContentDescription("Меню плейлиста").assertDoesNotExist()
    }
}
