package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.CollectionGeometry as G
import app.ziziplayer.ui.CollectionCollapseMath as M
import app.ziziplayer.ui.components.ArtworkCache
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.roundToInt

@Stable
internal class CollectionCollapseState(initial: Float = 0f) {
    var fraction by mutableFloatStateOf(M.clamp(initial, 1f))
    fun consume(dy: Float, range: Float): Float {
        if (range <= 0f) return 0f
        val old = fraction * range
        val next = M.next(old, dy, range)
        fraction = next / range
        return old - next
    }
    companion object {
        val saver = Saver<CollectionCollapseState, Float>(save = { it.fraction },
            restore = { CollectionCollapseState(it) })
    }
}

/** Shared by local collections, home mixes and remote albums/playlists; NOT artists.
 * No timer animates scroll: consumed distance, cover size and pinned controls agree.
 */
@Composable
internal fun PinnedCollectionScaffold(
    destination: String,
    title: String,
    tint: Color,
    trackCount: Int,
    playingHere: Boolean,
    playEnabled: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    artwork: @Composable () -> Unit,
    hero: @Composable () -> Unit,
    onMenu: (() -> Unit)? = null,
    selectionToolbar: (@Composable () -> Unit)? = null,
    collectionRows: LazyListScope.() -> Unit
) {
    val p = LocalPalette.current
    val base = Color(0xFF121212)
    val density = LocalDensity.current
    val list = rememberSaveable(destination, saver = LazyListState.Saver) { LazyListState() }
    LaunchedEffect(list) {
        snapshotFlow { list.isScrollInProgress }.collectLatest { moving ->
            while (moving) { ArtworkCache.markBusy(); delay(120) }
        }
    }
    val collapseState = rememberSaveable(destination, saver = CollectionCollapseState.saver) { CollectionCollapseState() }
    var heroPx by remember(destination, density.fontScale) { mutableIntStateOf(0) }
    BoxWithConstraints(Modifier.fillMaxSize().background(base)) {
        val status = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val toolbar = 56.dp
        val playSize = G.ACTION_SIZE.dp
        val coverMax = (maxWidth * 0.66f).coerceAtMost(280.dp)
        val coverMin = (coverMax * 0.44f).coerceAtLeast(64.dp).coerceAtMost(coverMax)
        val rangePx = with(density) { (coverMax - coverMin).toPx() }
        val connection = remember(collapseState, list, rangePx) {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
                    Offset(0f, if (available.y < 0f && list.firstVisibleItemIndex == 0 &&
                        list.firstVisibleItemScrollOffset == 0) collapseState.consume(available.y, rangePx) else 0f)
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
                    Offset(0f, if (available.y > 0f && list.firstVisibleItemIndex == 0 &&
                        list.firstVisibleItemScrollOffset == 0) collapseState.consume(available.y, rangePx) else 0f)
            }
        }
        val toolbarPx = with(density) { toolbar.toPx() }
        val playPx = with(density) { playSize.toPx() }
        val playBottomGapPx = with(density) { G.ACTION_BOTTOM_GAP.dp.toPx() }
        val pinnedPx = toolbarPx - playPx / 2f
        val expandedPx = (heroPx - playPx - playBottomGapPx).coerceAtLeast(pinnedPx)
        val bottom = LocalBottomChromeInset.current + 24.dp
        // Conservative for BOTH width-scaled local rows and fixed 71dp remote rows.
        val minimumRows = (G.ROW * maxWidth.value / G.REFERENCE_WIDTH).dp
            .coerceAtMost(MediaDimensions.trackRow) * trackCount
        val tail = G.minimumPinnedTail((maxHeight - status).value, minimumRows.value, bottom.value,
            playSize.value, G.ACTION_BOTTOM_GAP, (toolbar - playSize / 2).value).dp
        fun scrollPx(): Float = if (list.firstVisibleItemIndex == 0)
            list.firstVisibleItemScrollOffset.toFloat() else heroPx.toFloat()
        fun collapse(): Float = M.banner(scrollPx(), expandedPx - pinnedPx)
        // One visibility source for the scrim, title and menu. Re-key measured travel
        // after width/font/hero changes; a remembered lambda must not retain old geometry.
        val bannerAlpha by remember(list, heroPx, expandedPx, pinnedPx) {
            derivedStateOf { if (heroPx > 0) collapse() else 0f }
        }
        val toolbarVisibleForSemantics = bannerAlpha >= 1f
        Box(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(tint))
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            LazyColumn(state = list, modifier = Modifier.fillMaxSize().nestedScroll(connection).testTag("collection:list"),
                contentPadding = PaddingValues(bottom = bottom)) {
                item(key = "selection:hero", contentType = "hero") {
                    Column(Modifier.fillMaxWidth().onSizeChanged { heroPx = it.height }
                        .background(Brush.verticalGradient(listOf(tint, base)))) {
                        Spacer(Modifier.height(toolbar + 12.dp))
                        Box(Modifier.fillMaxWidth().padding(bottom = 20.dp), contentAlignment = Alignment.Center) {
                            val coverSize = M.coverSize(coverMax.value, coverMin.value, collapseState.fraction).dp
                            Box(Modifier.size(coverSize).testTag("collection:cover").clip(RoundedCornerShape(8.dp))) { artwork() }
                        }
                        hero()
                    }
                }
                collectionRows()
                item(key = "selection:tail", contentType = "spacer") { Spacer(Modifier.height(tail)) }
            }
            Box(Modifier.fillMaxWidth().height(toolbar)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .clearAndSetSemantics { }
                .graphicsLayer { alpha = bannerAlpha }.background(tint))
            if (selectionToolbar != null) Box(Modifier.fillMaxWidth().height(toolbar).background(tint)) { selectionToolbar() }
            else {
                Row(Modifier.fillMaxWidth().height(toolbar).padding(start = 6.dp, end = (G.ACTION_END + G.ACTION_SIZE + 8f).dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).testTag("collection:banner").padding(start = 8.dp).graphicsLayer { alpha = bannerAlpha }
                            .then(if (toolbarVisibleForSemantics) Modifier else Modifier.clearAndSetSemantics {}))
                    // No invisible hit target or TalkBack action over the expanded cover.
                    if (onMenu != null && bannerAlpha > 0f) {
                        IconButton(onClick = onMenu, enabled = toolbarVisibleForSemantics,
                            modifier = Modifier.size(48.dp).testTag("collection:menu")
                                .graphicsLayer { alpha = bannerAlpha }
                                .then(if (toolbarVisibleForSemantics) Modifier else Modifier.clearAndSetSemantics {})) {
                            Icon(ZiziIcons.More, "Меню плейлиста", tint = Color.White)
                        }
                    }
                }
                // One Play instance moves with the measured hero and pins to the toolbar.
                IconButton(onClick = onPlay, enabled = playEnabled && heroPx > 0,
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = G.ACTION_END.dp)
                        .offset { IntOffset(0, G.pinnedPlayTop(scrollPx(), expandedPx, pinnedPx).roundToInt()) }
                        .graphicsLayer { alpha = if (heroPx > 0) 1f else 0f }
                        .size(playSize).testTag("collection:play").clip(CircleShape).background(if (playEnabled) p.brand else p.chip)) {
                    Icon(if (playingHere) ZiziIcons.Pause else ZiziIcons.CollectionPlayFilled,
                        if (playingHere) "Пауза" else "Слушать подборку", tint = Color.Black,
                        modifier = Modifier.size(if (playingHere) 26.dp else playSize))
                }
            }
        }
    }
}

/** The hero reserves exactly the overlaid Play disk's width at the right.
 * Shuffle sits immediately to its left, with the same 48dp touch target and baseline.
 * Left actions wrap independently at large font scales; neither right control is squeezed.
 * Only Play pins on scroll; Shuffle remains part of the hero, as in the reference.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun CollectionActionsRow(
    onShuffle: () -> Unit,
    shuffleEnabled: Boolean,
    shuffleDescription: String = "Перемешать подборку",
    actions: @Composable () -> Unit = {}
) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = G.ACTION_SIZE.dp).padding(end = G.ACTION_SIZE.dp),
        verticalAlignment = Alignment.Bottom) {
        FlowRow(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            actions()
        }
        IconButton(onClick = onShuffle, enabled = shuffleEnabled,
            modifier = Modifier.size(G.ACTION_SIZE.dp).testTag("collection:shuffle")) {
            Icon(ZiziIcons.Shuffle, shuffleDescription,
                tint = if (shuffleEnabled) p.brand else p.subtext,
                modifier = Modifier.size(G.SHUFFLE_ICON_SIZE.dp))
        }
    }
}
