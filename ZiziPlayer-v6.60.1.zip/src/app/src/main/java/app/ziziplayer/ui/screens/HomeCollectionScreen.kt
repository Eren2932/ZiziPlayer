package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.CollectionGeometry as G
import app.ziziplayer.ui.HomeCollectionKind
import app.ziziplayer.ui.components.CollectionCoverImage
import app.ziziplayer.ui.components.rememberCollectionCover
import app.ziziplayer.ui.theme.ArtworkColorMath
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.sin

/** Stage 1 is a finite local list, deliberately not a recommendation session. */
@Composable
internal fun HomeCollectionScreen(
    kind: HomeCollectionKind,
    tracks: List<TrackEntity>,
    playback: PlaybackState,
    onBack: () -> Unit,
    onToggle: () -> Unit,
    onPlay: (TrackEntity, List<TrackEntity>, String) -> Unit,
    onMenu: (TrackEntity) -> Unit,
    title: String = kind.title,
    sourceId: String = kind.sourceId,
    loading: Boolean = false,
    error: String? = null,
    hasMore: Boolean = false,
    onMore: () -> Unit = {}
) {
    val p = LocalPalette.current
    val cover = rememberCollectionCover(track = if (kind == HomeCollectionKind.WAVE) null else tracks.firstOrNull())
    // WAVE is procedural orange artwork, not a hidden track cover.
    val tint = if (kind == HomeCollectionKind.WAVE) Color(ArtworkColorMath.coverTop(0xFFB44E18.toInt())) else cover.tint
    val ownsQueue = playback.queueSourceId == sourceId
    PinnedCollectionScaffold(
        destination = sourceId, title = title, tint = tint, trackCount = tracks.size,
        playingHere = ownsQueue && playback.isPlaying,
        playEnabled = tracks.isNotEmpty() || ownsQueue,
        onBack = onBack,
        onPlay = {
            if (ownsQueue) onToggle()
            else tracks.firstOrNull()?.let { onPlay(it, tracks, sourceId) }
        },
        artwork = {
            if (kind == HomeCollectionKind.WAVE) WaveArtwork(Modifier.fillMaxSize())
            else CollectionCoverImage(cover, Modifier.fillMaxSize())
        },
        hero = {
            Column(Modifier.fillMaxWidth().padding(horizontal = G.ACTION_END.dp).padding(bottom = G.ACTION_BOTTOM_GAP.dp)) {
                Text(title, color = p.text, fontSize = 30.sp, lineHeight = 34.sp,
                    fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp))
                Text(trackCountLabel(tracks.size), color = Color(0xFFE0E0E0), fontSize = 14.sp,
                    modifier = Modifier.padding(vertical = 10.dp))
                CollectionActionsRow(
                    onShuffle = {
                        val shuffled = tracks.shuffled()
                        shuffled.firstOrNull()?.let { onPlay(it, shuffled, sourceId) }
                    },
                    shuffleEnabled = tracks.isNotEmpty()
                )
            }
        }
    ) {
        if (tracks.isEmpty() && !loading && error == null) item(key = "selection:empty") {
            Text("Нет доступных треков", color = p.subtext, modifier = Modifier.padding(20.dp))
        }
        if (loading) item(key = "selection:loading") { Text("Загружаем треки…", color = p.subtext, modifier = Modifier.padding(20.dp)) }
        if (error != null) item(key = "selection:error") {
            Column(Modifier.padding(20.dp)) {
                Text(error, color = p.subtext)
                androidx.compose.material3.TextButton(onClick = onMore, enabled = !loading) { Text("Повторить", color = p.text) }
            }
        }
        items(tracks, key = { it.id }, contentType = { "track" }) { track ->
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                CollectionTrackRow(track, maxWidth.value / 1080f, track.id == playback.currentTrackId,
                    selected = false, picking = false,
                    onPlay = { onPlay(track, tracks, sourceId) }, onSelect = {},
                    onLongPress = { onMenu(track) }, onMenu = { onMenu(track) })
            }
        }
        if (hasMore) item(key = "selection:more") {
            androidx.compose.material3.TextButton(onClick = onMore, enabled = !loading) { Text("Показать ещё", color = p.text) }
        }
    }
}

/** Original procedural artwork: no downloaded reference assets or animation load. */
@Composable
internal fun WaveArtwork(modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.linearGradient(listOf(Color(0xFFB44E18), Color(0xFF351C15))))
        .drawWithCache {
            val steps = 90
            val paths = (0 until 17).map { line ->
                Path().apply {
                    for (step in 0..steps) {
                        val x = size.width * step / steps
                        val phase = step.toFloat() / steps * 7f + line * 0.18f
                        val y = size.height * (0.16f + line * 0.041f + sin(phase) * 0.14f)
                        if (step == 0) moveTo(x, y) else lineTo(x, y)
                    }
                }
            }
            val stroke = Stroke(1.5.dp.toPx())
            onDrawBehind {
                paths.forEachIndexed { line, path ->
                    drawPath(path, Color(0xFFFFBE79).copy(alpha = 0.24f + line * 0.025f), style = stroke)
                }
            }
        })
}
