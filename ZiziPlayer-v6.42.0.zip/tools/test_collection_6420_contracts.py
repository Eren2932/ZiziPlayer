#!/usr/bin/env python3
"""6.42.0 source wiring checks. NOT Kotlin compilation or UI screenshot tests."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(name): return (SRC/name).read_text()
class CollectionContracts(unittest.TestCase):
    def test_distinct_destination_not_library_chips(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('if (detailPage) {\n        LocalCollectionScreen(', s)
        self.assertIn('state.filter == LibraryFilter.FAVORITES || state.filter == LibraryFilter.TRACKS', s)
        detail = read('ui/screens/LocalCollectionScreen.kt')
        self.assertNotIn('LibraryFilterBar(', detail)
        self.assertNotIn('LibraryHeader(', detail)
        self.assertIn('rememberSaveable(destination, saver = LazyListState.Saver)', detail)
    def test_one_scroll_owner_one_play_button(self):
        s = read('ui/screens/LocalCollectionScreen.kt')
        self.assertEqual(s.count('LazyColumn('), 1)
        self.assertEqual(s.count('else ZiziIcons.CollectionPlayFilled'), 1)
        self.assertIn('G.playTop(scrollUnits(), fontExtra)', s)
        self.assertIn('G.headerAlpha(scrollUnits())', s)
        self.assertIn('G.titleAlpha(scrollUnits())', s)
        self.assertIn('onTextLayout = { titleHeightPx = it.size.height }', s)
    def test_root_sort_scrolls_in_both_views(self):
        s = read('ui/screens/LibraryScreen.kt')
        header = s.split('Column(Modifier.fillMaxWidth().libraryChrome())')[1].split('Box(Modifier.weight(1f))')[0]
        self.assertNotIn('LibrarySurfaceBar(', header)
        self.assertEqual(s.count('item(key = "surface:sort", contentType = "sort") { surfaceBar() }'), 2)
        self.assertIn('listState = collectionListState', s)
    def test_scrim_draws_past_dock_without_child_alpha(self):
        s = read('ui/components/TopChrome.kt').split('fun Modifier.bottomChrome()')[1]
        for fragment in ['val lead = 48.dp.toPx()', 'val start = -lead', 'Brush.verticalGradient',
                         'CollectionGeometry.scrimAlpha(t)', 'onDrawBehind', 'size.height + lead']:
            self.assertIn(fragment, s)
        self.assertNotIn('graphicsLayer', s)
        self.assertNotIn('clip(', s)
    def test_downloads_use_full_membership_off_main(self):
        vm = read('ui/MainViewModel.kt')
        self.assertIn('collectionTracks = base', vm)
        s = read('ui/screens/LocalCollectionScreen.kt')
        self.assertIn('CollectionDownloadDialog(vm, state.collectionTracks, downloads)', s)
        self.assertIn('withContext(Dispatchers.IO)', s)
        self.assertNotIn('(null, unique, live)', s) # no disk scans for progress ticks
        self.assertIn('vm.cancelCollectionDownloads(unique)', s)
    def test_batch_uses_existing_engine_and_guards_registration(self):
        s = read('playback/OfflineDownloads.kt')
        self.assertIn('private const val MAX_PARALLEL = 2', s)
        self.assertIn('batchPolicy.mayStart(track.id, request)', s)
        self.assertIn('scope.launch(start = CoroutineStart.LAZY)', s)
        self.assertLess(s.index('jobs[track.id] = job'), s.index('job.start()'))
        self.assertIn('jobs.remove(track.id, job)', s)
        self.assertIn('job.invokeOnCompletion', s)
        self.assertIn('jobs[trackId]?.cancel()', s)
        self.assertIn('batchPolicy.cancelAll()', s)
        self.assertIn('OfflineStore.save(context, track, temp', s)
    def test_playlist_display_sort_does_not_rewrite_membership(self):
        s = read('ui/MainViewModel.kt')
        self.assertIn('openPlaylist != null && !sel.playlistSortChosen', s)
        self.assertIn('saved["playlistSortChosen"]', s)
    def test_existing_transport_and_safe_insets_remain(self):
        s = read('ui/screens/LocalCollectionScreen.kt')
        self.assertIn('LocalBottomChromeInset.current + 24.dp', s)
        self.assertIn('vm.startSelection(track.id)', s)
        self.assertIn('onMenu(track)', s)
        self.assertIn('ArtworkCache.markBusy()', s)
        self.assertIn('selectionHeader()', s)
        self.assertIn('G.minimumTail(viewportUnits, heroUnits', s)
        self.assertIn('collection:collapse-room', s)
if __name__ == '__main__': unittest.main(verbosity=2)
