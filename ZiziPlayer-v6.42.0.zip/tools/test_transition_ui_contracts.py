#!/usr/bin/env python3
"""Source integration guards only. Passing is not a Kotlin build or a rendered frame."""
from pathlib import Path
import os
import unittest
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
APP = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (APP / name).read_text()
def block(s, start, end): return s.split(start, 1)[1].split(end, 1)[0]

class TransitionUiContracts(unittest.TestCase):
    def test_only_real_drag_can_seek(self):
        s = block(read('ui/screens/PlayerScreen.kt'), 'private fun PagerPlaybackSync(', '/**\n * Absolute page coordinates')
        for text in ('interactionSource.interactions.collect', 'DragInteraction.Start', 'DragInteraction.Stop',
                     'DragInteraction.Cancel', 'gesture.finish(', 'gesture.ready('):
            self.assertIn(text, s)
        self.assertNotIn('.drop(1)', s)
        self.assertNotIn('delay(80)', s)
        self.assertNotIn('var pending', s)
    def test_programmatic_retarget_observes_id_queue_and_gesture(self):
        s = read('ui/screens/PlayerScreen.kt')
        self.assertIn('LaunchedEffect(pagerState, queueIds, playerTrackId, gestureRevision)', s)
        self.assertIn('if (gesture.isActive) return@LaunchedEffect', s)
        self.assertIn('!pagerState.isScrollInProgress) return@LaunchedEffect', s)
        self.assertIn('pagerState.currentPageOffsetFraction.absoluteValue < 0.0001f', s)
        self.assertIn('animationSpec = tween(220, easing = FastOutSlowInEasing)', s)
    def test_page_identity_not_media3_index(self):
        s = read('ui/screens/PlayerScreen.kt')
        self.assertIn('queue.indexOfFirst { it.id == playback.currentTrackId }', s)
        self.assertIn('vm.playFromQueue(trackId)', s)
        self.assertNotIn('vm.seekToIndex(page)', s)
        self.assertIn('queue.map { it.id }', s)
    def test_transport_cancels_gesture_even_if_track_id_stays_same(self):
        s = block(read('ui/screens/PlayerScreen.kt'), 'fun transport(action:', 'var showFx')
        self.assertLess(s.index('gesture.cancel()'), s.index('action()'))
        self.assertIn('blend.cancelGesture()', s)
        self.assertIn('gestureRevision++', s)
        self.assertNotIn('delay(', s)
    def test_queue_change_and_disposal_clear_ownership(self):
        s = read('ui/screens/PlayerScreen.kt')
        self.assertIn('DisposableEffect(pagerState, queueIds)', s)
        self.assertIn('onDispose { blend.cancelGesture() }', s)
        self.assertIn('vm.playback.value.currentTrackId != trackId', s)
    def test_swipe_colours_are_absolute_and_cache_only(self):
        s = block(read('ui/screens/PlayerScreen.kt'), 'private fun BackdropSwipeBlend(', '/**\n * 6.34.0.')
        self.assertIn('pagerState.currentPage + pagerState.currentPageOffsetFraction', s)
        self.assertIn('floor(position)', s)
        self.assertNotIn('playerIndex', s)
        self.assertNotIn('rememberArtSwatches', s)
        self.assertNotIn('load(', s)
        self.assertIn('livePaletteAt(left), livePaletteAt(right)', s)
    def test_palette_memo_is_bounded_and_fallback_is_lazy(self):
        s = block(read('ui/screens/PlayerScreen.kt'), 'private class PagePaletteCache', '/**\n * Only a real pointer')
        self.assertIn('size > 4', s)
        self.assertIn('cached ?: fallbackSwatches(track)', s)
        self.assertLess(s.index('return it.second'), s.index('fallbackSwatches(track)'))
    def test_backgrounds_do_not_compete_for_hold(self):
        s = block(read('ui/theme/ZiziTheme.kt'), 'fun ZiziBackdrop(', '@Composable\nfun ZiziTheme')
        self.assertNotIn('LaunchedEffect', s)
        self.assertNotIn('remember { Animatable', s)
        self.assertNotIn('clearOverride()', s)
        main = read('MainActivity.kt')
        self.assertEqual(main.count('SyncBackdropPalette('), 1)
        self.assertIn('BackdropBlend(palette)', main)
    def test_handoff_verifies_owner_and_adopts_before_release(self):
        s = block(read('ui/theme/ZiziTheme.kt'), 'fun SyncBackdropPalette(', '/**\n * Mixes two ramp stops')
        self.assertIn('PlayerTransitionPolicy.handoff(', s)
        self.assertIn('playingTrackId, paletteTrackId', s)
        snap = block(s, 'PlayerTransitionPolicy.SNAP ->', 'else ->')
        self.assertLess(snap.index('blend.snapTo(palette)'), snap.index('blend.clearOverride()'))
        self.assertIn('blend.visiblePalette(palette)', s)
        self.assertNotIn('delay(', s)
    def test_status_tint_fixed_once_above_screens(self):
        s = read('MainActivity.kt')
        self.assertEqual(s.count('StatusBarTint('), 1)
        self.assertGreater(s.index('StatusBarTint('), s.index('EqualizerScreen(vm'))
        self.assertIn('controller.isAppearanceLightStatusBars = false', s)
        chrome = read('ui/components/TopChrome.kt')
        self.assertIn('windowInsetsTopHeight(WindowInsets.statusBars)', chrome)
        for text in ('.blur(', '.graphicsLayer', '.pointerInput', '.clickable', 'rememberInfiniteTransition'):
            self.assertNotIn(text, chrome)
    def test_library_surface_and_outgoing_content_use_different_draw_order(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('Column(Modifier.fillMaxWidth().libraryChrome())', s)
        self.assertIn('Box(Modifier.weight(1f))', s)
        self.assertNotIn('.topContentTint()', s)
        self.assertEqual(s.count('item(key = "surface:sort", contentType = "sort") { surfaceBar() }'), 2)
        chrome = read('ui/components/TopChrome.kt')
        header = block(chrome, 'fun Modifier.libraryChrome()', '/** Dims real')
        self.assertIn('onDrawBehind', header)
        overlay = chrome.split('fun Modifier.topContentTint()', 1)[1]
        self.assertIn('onDrawWithContent', overlay)
        self.assertLess(overlay.index('drawContent()'), overlay.index('drawRect(tint'))
    def test_accessibility_has_explicit_transport_not_implicit_scroll(self):
        s = read('ui/screens/PlayerScreen.kt')
        self.assertIn('modifier.clearAndSetSemantics', s)
        self.assertIn('CustomAccessibilityAction("Предыдущий трек") { onPrevious(); true }', s)
        self.assertIn('CustomAccessibilityAction("Следующий трек") { onNext(); true }', s)
    def test_carousel_performance_guards_are_preserved(self):
        s = read('ui/screens/PlayerScreen.kt')
        for text in ('beyondViewportPageCount = 1', 'ArtworkCache.markBusy()', 'delay(120)',
                     'maxPx = ARTWORK_FULL_PX', 'allowSlow = true', 'key = { index -> queue.getOrNull(index)?.id',
                     'val playFactor = remember { Animatable', 'COVER_PLAYING = 0.872f'):
            self.assertIn(text, s)
    def test_tests_are_wired_into_existing_preflight(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn('test_transition_ui_contracts.py', s)
        self.assertIn('test_player_transition_policy.py', s)
        self.assertIn('PlayerTransitionChecks.runAll()', (ROOT / 'app/src/test/java/app/ziziplayer/ui/PlayerTransitionPolicyTest.kt').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
