package app.ziziplayer.ui

import app.ziziplayer.data.remote.CatalogPolicy
import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.MusicRepository
import app.ziziplayer.data.RecentEntity
import app.ziziplayer.data.RecentKind
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.HubCache
import app.ziziplayer.data.remote.RemoteCatalog
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.SearchPage
import app.ziziplayer.data.remote.DeezerCatalog
import app.ziziplayer.data.remote.InnertubeCatalog
import app.ziziplayer.data.remote.ZiziResolve
import app.ziziplayer.data.remote.providerLabel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Which of the three faces of the section is showing.
 *
 * Three, not two, and not one screen with flags. The reference player has exactly this shape and
 * the reason is not aesthetic: the hub is a browsing surface with vertical shelves, the suggestion
 * list is a keyboard-driven surface that must never move under the finger, and the result list is a
 * paged surface. Collapsing them into "search screen with a query or without one" is how you end up
 * with a hub that reflows while the user types.
 */
/**
 * Четыре поверхности раздела, а не три.
 *
 * [RECENT] появился в 6.27.0 и закрывает состояние «поле нажато, но ещё ничего не набрано».
 * Раньше в этот момент под клавиатурой оставался хаб — то есть человеку, который уже потянулся
 * к клавиатуре, показывали витрину жанров, а его собственную вчерашнюю сессию прятали в ленту
 * чипов над ней. Теперь это отдельный экран, и он же — единственное место, где живёт история.
 */
enum class SearchStage { HUB, RECENT, SUGGEST, RESULTS }

/**
 * The result tabs, and the provider filter each one maps to.
 *
 * [ALL] deliberately sends no filter at all rather than merging four filtered calls: one unfiltered
 * request is one round trip and it returns the provider's own idea of relevance, which is better
 * than anything we could re-rank client side.
 */
enum class SearchTab(val label: String, val kind: RemoteKind?) {
    ALL("Все", null),
    TRACKS("Треки", RemoteKind.TRACK),
    ALBUMS("Альбомы", RemoteKind.ALBUM),
    PLAYLISTS("Плейлисты", RemoteKind.PLAYLIST),
    ARTISTS("Исполнители", RemoteKind.ARTIST)
}

/**
 * One tab's worth of results.
 *
 * [appending] is separate from [loading] because they draw differently and confusing them is a
 * visible bug: a first load replaces the list with a spinner, a page append must leave the list
 * exactly where it is and put the spinner at the bottom. One boolean cannot express both.
 */
@Immutable
data class TabResults(
    val items: List<RemoteItem> = emptyList(),
    val nextToken: String? = null,
    val loading: Boolean = false,
    val appending: Boolean = false,
    val error: String? = null,
    /** Which catalogue actually answered - not which one was asked. */
    val provider: String? = null
) {
    val isEmpty: Boolean get() = items.isEmpty() && !loading && error == null
    val canLoadMore: Boolean get() = nextToken != null && !loading && !appending && error == null
}

/** An album / playlist / artist opened out into its tracks. */
@Immutable
data class OpenCollection(
    val collection: RemoteCollection,
    val tracks: List<RemoteTrack> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null,
    val nextToken: String? = null,
    val appending: Boolean = false,
    val total: Int? = null
)

@Immutable
data class SearchUiState(
    val stage: SearchStage = SearchStage.HUB,
    /** What is in the text field right now. Not the same thing as [query]. */
    val field: String = "",
    /** The last query that was actually submitted. Results belong to this, not to the field. */
    val query: String = "",
    val tab: SearchTab = SearchTab.ALL,
    val suggestions: List<String> = emptyList(),
    val previewTracks: List<RemoteTrack> = emptyList(),
    val previewLoading: Boolean = false,
    val previewError: String? = null,
    val history: List<String> = emptyList(),
    /** Недавние объекты: треки, сборники и запросы, свежие сверху. Поверхность [SearchStage.RECENT]. */
    val recents: List<RecentEntity> = emptyList(),
    val shelves: List<DiscoverShelf> = emptyList(),
    val hubLoading: Boolean = false,
    /**
     * Запрос подборок в полёте — включая тихое обновление за уже нарисованными полками (6.27.1).
     *
     * Отдельно от [hubLoading], и по той же причине, по которой [TabResults.appending] отделено от
     * `loading`: это два разных события с разным изображением. `hubLoading` означает «смотреть
     * не на что, показываем крутилку вместо содержимого» и по замыслу равен false, когда полки
     * уже есть. Кнопка «обновить» в шапке обязана вращаться именно в этом случае — иначе нажатие
     * не даёт вообще никакого отклика, и кнопка выглядит заглушкой. Одним флагом это невыразимо.
     */
    val hubRefreshing: Boolean = false,
    val hubError: String? = null,
    /**
     * Results per tab, kept for the lifetime of one query.
     *
     * Tabs are a filter over the same query, so the fetched pages stay valid while the query does.
     * Re-requesting on every tab tap would cost a round trip and - worse - lose the scroll position
     * and every page the user had already loaded. Switching back to a tab you were on must show it
     * as you left it.
     */
    val results: Map<SearchTab, TabResults> = emptyMap(),
    val collection: OpenCollection? = null
) {
    val current: TabResults get() = results[tab] ?: TabResults()
}

/**
 * Everything the "Поиск" section does, kept out of [MainViewModel] on purpose.
 *
 * The library view model owns a 3000 row pipeline that recombines on every keystroke of the LOCAL
 * search. Hanging network paging, suggestion debouncing and per-tab caches off the same object
 * would put two unrelated failure domains in one place: a broken catalogue would recompose the
 * library, and a rescan would recompose the results. They share the repository and nothing else.
 */
/**
 * [saved] is what makes the section remember where the user was.
 *
 * Not a preference file, deliberately: `SavedStateHandle` is wiped when the task is finished (the
 * user swipes the app away, or backs out of it) and survives when it is not (the system reclaims the
 * process while the app sits in the background). That is exactly the behaviour we want - "come back
 * to where I was" while minimised, "start clean" after closing - and it comes for free from the
 * platform instead of from a timestamp heuristic we would have to tune forever.
 */
class SearchViewModel(
    application: Application,
    private val saved: SavedStateHandle
) : AndroidViewModel(application) {

    private val repo: MusicRepository = (application as ZiziApplication).repository

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    /** Ids of remote tracks the user chose to keep. Drives the "+" / "✓" on every result row. */
    val savedIds: StateFlow<Set<String>> = repo.tracks
        .map { tracks -> tracks.asSequence().filter { it.isRemote }.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private var suggestJob: Job? = null
    private val pageJobs = mutableMapOf<SearchTab, Job>()
    private var queryGeneration = 0L
    private var collectionGeneration = 0L
    private var editorReturnStage = SearchStage.HUB
    private var collectionJob: Job? = null

    private val hubMessages = Channel<String>(Channel.CONFLATED)
    val messages = hubMessages.receiveAsFlow()
    private val hub = HubRefreshController(
        scope = viewModelScope,
        preferred = { repo.settings.first().catalogProvider },
        readCache = { provider ->
            withContext(Dispatchers.IO) {
                HubCache.read(getApplication<Application>(), provider)?.let {
                    HubSnapshot(it.shelves, it.fresh)
                }
            }
        },
        discover = { preferred ->
            // Parse and normalize catalog metadata off the UI thread. Each provider gets
            // a bounded attempt, leaving time for fallback within the controller's deadline.
            withContext(Dispatchers.IO) {
                repo.catalogs.withFallback(preferred) { catalog ->
                    withTimeoutOrNull(8_000L) { catalog.discover() }
                        ?: throw CatalogException(CatalogException.Reason.OFFLINE, "Источник не успел ответить")
                }
            }
        },
        writeCache = { provider, shelves ->
            withContext(Dispatchers.IO) { HubCache.write(getApplication<Application>(), provider, shelves) }
        },
        message = { hubMessages.trySend(it) },
        describeError = { error ->
            when (error) {
                is CatalogException -> explain(error)
                is java.io.IOException -> "Нет соединения"
                else -> "Не удалось прочитать ответ источника. Попробуй ещё раз"
            }
        }
    )

    init {
        restorePlace()
        viewModelScope.launch {
            hub.state.collect { current ->
                _state.value = _state.value.copy(
                    shelves = current.shelves, hubLoading = current.loading,
                    hubRefreshing = current.refreshing, hubError = current.error
                )
            }
        }
        viewModelScope.launch {
            repo.searchHistory.collect { entries ->
                _state.value = _state.value.copy(history = entries.map { it.query })
            }
        }
        viewModelScope.launch {
            repo.recents.collect { entries ->
                _state.value = _state.value.copy(recents = entries.filter { entry ->
                    entry.kind == RecentKind.QUERY || CatalogPolicy.supports(entry.provider, entry.remoteId)
                })
            }
        }
        // One writer for the whole section instead of a `saved[...] =` in every mutator. A StateFlow
        // conflates, so this costs a handful of string writes per user action, and no call site can
        // ever forget to record itself.
        viewModelScope.launch { state.collect { rememberPlace(it) } }
        loadHub()
    }

    // ---------------------------------------------------------------- the place

    private fun rememberPlace(current: SearchUiState) {
        saved[KEY_FIELD] = current.field
        saved[KEY_QUERY] = current.query
        saved[KEY_STAGE] = current.stage.name
        saved[KEY_TAB] = current.tab.name
        // 6.19.0: из полей вырезается сам разделитель.
        //
        // Склейка шести значений через \u001f разбирается обратно по количеству частей ("не шесть
        // — не восстанавливаем"). Значения приходят от провайдера, то есть извне: название
        // альбома, содержащее этот символ, давало семь частей, и после поворота экрана открытый
        // сборник просто не восстанавливался. Символ невидимый, в названиях музыки ему делать
        // нечего, потерять его не жалко — а вот молча терять место, где был человек, жалко.
        saved[KEY_COLLECTION] = current.collection?.collection?.let {
            listOf(it.provider, it.remoteId, it.kind.name, it.title, it.subtitle, it.artworkUrl ?: "")
                .joinToString(UNIT_SEP) { part -> part.replace(UNIT_SEP, " ") }
        }
    }

    /**
     * Results are not stored, only the query that produced them: a page of results is up to a
     * hundred items with artwork URLs, it goes stale, and re-asking costs one request. What has to
     * survive is the user's position, not the provider's answer.
     */
    private fun restorePlace() {
        val field = saved.get<String>(KEY_FIELD) ?: return
        val query = saved.get<String>(KEY_QUERY).orEmpty()
        val stored = runCatching { SearchStage.valueOf(saved.get<String>(KEY_STAGE) ?: "") }
            .getOrDefault(SearchStage.HUB)
        val tab = runCatching { SearchTab.valueOf(saved.get<String>(KEY_TAB) ?: "") }
            .getOrDefault(SearchTab.ALL)
        // SUGGEST is never restored. It is a keyboard-driven surface, and coming back to a half-typed
        // suggestion list with the keyboard popping up unasked is not "where I was", it is a jump
        // scare. It resolves to whatever was underneath it.
        // RECENT восстанавливается так же, как SUGGEST, и по той же причине: обе поверхности
        // существуют только пока на экране клавиатура, и «вернуть человека» на них означает
        // поднять клавиатуру, которую он не звал. Разрешаются в то, что было под ними.
        val stage = when {
            stored == SearchStage.SUGGEST && query.isNotBlank() -> SearchStage.RESULTS
            stored == SearchStage.SUGGEST -> SearchStage.HUB
            stored == SearchStage.RECENT -> SearchStage.HUB
            else -> stored
        }
        _state.value = _state.value.copy(field = field, query = query, stage = stage, tab = tab)
        if (stage == SearchStage.RESULTS && query.isNotBlank()) fetch(tab, append = false)

        val parts = saved.get<String>(KEY_COLLECTION)?.split(UNIT_SEP) ?: return
        if (parts.size != 6 || !CatalogPolicy.supports(parts[0], parts[1])) return

        val kind = runCatching { RemoteKind.valueOf(parts[2]) }.getOrNull() ?: return
        openCollection(
            RemoteCollection(
                provider = parts[0],
                remoteId = parts[1],
                kind = kind,
                title = parts[3],
                subtitle = parts[4],
                artworkUrl = parts[5].ifEmpty { null }
            )
        )
    }

    // ---------------------------------------------------------------- the hub

    /** Disk-first for startup; manual taps force a bounded, single-flight network refresh. */
    fun loadHub(force: Boolean = false) = hub.load(force)

    // ---------------------------------------------------------------- typing

    /** Explicit first-surface entry: history first, no network request until text is typed. */
    fun openSearch() {
        editorReturnStage = SearchStage.HUB
        onField("")
    }

    fun onField(text: String) {
        editorReturnStage = SearchNavigation.editOrigin(_state.value.stage, editorReturnStage)
        val query = text.trim()
        suggestJob?.cancel()
        _state.value = _state.value.copy(
            field = text,
            stage = if (query.isBlank()) SearchStage.RECENT else SearchStage.SUGGEST,
            suggestions = SearchPresentation.completions(query, emptyList(), _state.value.history, emptyList()),
            previewTracks = emptyList(), previewLoading = query.length >= 2, previewError = null
        )
        if (query.length < 2) return
        suggestJob = viewModelScope.launch {
            delay(220)
            val preferred = repo.settings.first().catalogProvider
            // Independent children: slow autocomplete must not hold back already fetched covers.
            launch {
                val fetched = try {
                    withTimeoutOrNull(1500L) { repo.catalogs.withFallback(preferred) { it.suggest(query) } }
                        ?: emptyList()
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { emptyList() }
                currentCoroutineContext().ensureActive()
                if (isCurrentSuggestion(query)) {
                    val current = _state.value
                    _state.value = current.copy(suggestions = SearchPresentation.completions(
                        query, fetched, current.history,
                        current.previewTracks.flatMap { listOf(it.title, it.artist) }
                    ))
                }
            }
            launch {
                try {
                    val tracks = withTimeoutOrNull(2200L) {
                        repo.catalogs.withFallback(preferred) { it.preview(query) }
                    }
                    currentCoroutineContext().ensureActive()
                    if (isCurrentSuggestion(query)) {
                        val current = _state.value
                        val preview = tracks.orEmpty().distinctBy { it.trackId }.take(4)
                        _state.value = current.copy(
                            previewTracks = preview, previewLoading = false,
                            previewError = if (tracks == null) "Предпросмотр задерживается — можно открыть полный поиск" else null,
                            suggestions = SearchPresentation.completions(query, current.suggestions,
                                current.history, preview.flatMap { listOf(it.title, it.artist) })
                        )
                    }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) {
                    if (isCurrentSuggestion(query)) _state.value = _state.value.copy(
                        previewLoading = false,
                        previewError = if (e is CatalogException) explain(e) else "Предпросмотр недоступен — попробуй полный поиск"
                    )
                }
            }
        }
    }

    private fun isCurrentSuggestion(query: String): Boolean =
        _state.value.stage == SearchStage.SUGGEST && _state.value.field.trim() == query

    fun clearField() = onField("")

    fun onFieldFocused() {
        val current = _state.value
        if (current.stage != SearchStage.SUGGEST && current.stage != SearchStage.RECENT) {
            onField(current.field)
        }
    }

    // ---------------------------------------------------------------- searching

    fun submit(raw: String) {
        val query = raw.trim()
        if (query.isEmpty()) return
        suggestJob?.cancel()
        pageJobs.values.forEach { it.cancel() }
        pageJobs.clear()
        queryGeneration++
        collectionJob?.cancel()
        collectionGeneration++
        _state.value = _state.value.copy(
            field = query,
            query = query,
            stage = SearchStage.RESULTS,
            tab = SearchTab.ALL,
            suggestions = emptyList(), previewTracks = emptyList(), previewLoading = false, previewError = null,
            // Every tab's cache belongs to the previous query and every entry in it is now wrong.
            results = emptyMap(),
            collection = null
        )
        viewModelScope.launch {
            repo.rememberQuery(query)
            // Запрос ложится в «Недавние» наравне с объектами. Он там не навсегда: как только по
            // этому запросу что-то открыли, наверху окажется сам объект, а строка уедет вниз
            // естественным порядком, по времени. Это дешевле и честнее, чем удалять запрос
            // вручную при первом открытии, — человек мог открыть не то, что искал.
            repo.rememberRecent(
                RecentEntity(
                    key = "q:" + query.lowercase(java.util.Locale.ROOT),
                    kind = RecentKind.QUERY,
                    title = query
                )
            )
        }
        fetch(SearchTab.ALL, append = false)
    }

    fun setTab(tab: SearchTab) {
        val current = _state.value
        if (current.tab == tab) return
        _state.value = current.copy(tab = tab)
        if (current.results[tab] == null) fetch(tab, append = false)
    }

    fun loadMore() {
        val current = _state.value
        if (!current.current.canLoadMore) return
        fetch(current.tab, append = true)
    }

    fun retry() {
        val current = _state.value
        fetch(current.tab, append = current.current.items.isNotEmpty() && current.current.nextToken != null)
    }

    private fun fetch(tab: SearchTab, append: Boolean) {
        val query = _state.value.query
        if (query.isBlank()) return
        val existing = _state.value.results[tab] ?: TabResults()
        val token = if (append) existing.nextToken else null
        if (append && token == null) return

        // Each tab owns its request. Switching A -> B -> A cannot leave A permanently loading.
        val generation = queryGeneration
        pageJobs[tab]?.cancel()
        update(tab) {
            it.copy(
                loading = !append,
                appending = append,
                error = null,
                items = if (append) it.items else emptyList()
            )
        }
        pageJobs[tab] = viewModelScope.launch {
            try {
                val preferred = repo.settings.first().catalogProvider
                var answered: RemoteCatalog? = null
                val page: SearchPage = if (append && existing.provider != null) {
                    val catalog = repo.catalogs.byId(existing.provider)
                        ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник недоступен")
                    answered = catalog
                    catalog.search(query, tab.kind, token)
                } else repo.catalogs.withFallback(preferred) { catalog ->
                    answered = catalog
                    catalog.search(query, tab.kind, token)
                }
                currentCoroutineContext().ensureActive()
                if (generation != queryGeneration) return@launch
                // The catalogue may legitimately return the same row twice across two pages
                // (continuations overlap on shelf boundaries). De-duplicating on append rather
                // than trusting the provider keeps the LazyColumn keys unique, which is otherwise
                // a crash and not a cosmetic problem.
                val merged = if (append) dedupe(existing.items + page.items) else dedupe(page.items)
                update(tab) {
                    it.copy(
                        items = merged,
                        // A token that returns nothing is a token that will keep returning
                        // nothing; treat it as the end of the list instead of an infinite footer.
                        nextToken = SearchPresentation.nextPage(page.nextToken, token, page.items.size),
                        loading = false,
                        appending = false,
                        error = null,
                        provider = answered?.id
                    )
                }
                // Remote rows are written to the database as soon as they are seen, not when they
                // are played: the mini player, the queue and the play counters all resolve by id,
                // and a row that does not exist yet cannot be favourited or queued. Unsaved rows
                // are swept later - see MusicRepository.sweepRemote.
                val songs = page.items.filterIsInstance<RemoteItem.Song>().map { it.track }
                if (songs.isNotEmpty()) repo.rememberRemote(songs)
                currentCoroutineContext().ensureActive()
                if (generation == queryGeneration) warmTop(songs)
            } catch (e: CatalogException) {
                currentCoroutineContext().ensureActive()
                if (generation == queryGeneration) {
                    update(tab) { it.copy(loading = false, appending = false, error = explain(e)) }
                }
            }
        }
    }

    /**
     * 6.22.0: прогрев первых результатов поиска.
     *
     * Замер по видео 30.08: тап по треку из поиска — 16.5 секунды пустого таймлайна, из которых
     * ни одна не ушла на байты (файл кладётся на диск сервера за 0.11 с). Всё это время занимал
     * холодный резолв: Innertube, PO-токен, Deno на n-challenge.
     *
     * Прогрев очереди у нас был с 6.18, но он срабатывал только ПОСЛЕ начала воспроизведения, на
     * соседях по очереди. Поиск не грелся никогда, поэтому первый тап по найденному треку всегда
     * платил полную цену. Здесь мы отправляем серверу id первых [WARM_TOP] песен, как только
     * страница результатов отрисовалась: пока человек читает список и целится пальцем, сервер уже
     * держит ССЫЛКУ наготове.
     *
     * 6.22.1: байты здесь больше не греются. В 6.22.0 прогрев тянул треки целиком, и по замеру
     * 30.08 это стоило 329 МБ канала на 79 МБ прослушанного: живой резолв распухал с 6 до 17
     * секунд, а фоновые задачи доходили до 252. Ссылка стоит один запрос и живёт часами — вот
     * её и греем.
     *
     * Почему только три, а не вся страница: на сервере одно ядро и один слот на извлечение.
     * Прогрев тридцати треков не ускорил бы ничего — он поставил бы в очередь тот самый тап,
     * который мы пытаемся ускорить. Три — это то, куда попадает палец в подавляющем большинстве
     * случаев, и ровно столько, сколько сервер успеет пережевать за время чтения списка.
     *
     * Вызов безопасен и намеренно молчалив: [ZiziResolve.prefetch] сам отбрасывает уже известные
     * приговоры, дедуплицирует id по кулдауну и работает в своей области видимости. Ошибка
     * прогрева ничего не значит — трек просто отрезолвится вживую, как раньше.
     */
    private fun warmTop(songs: List<RemoteTrack>) {
        if (!ZiziResolve.configured) return
        // 6.37.0. Раньше здесь стоял фильтр `provider == InnertubeCatalog.ID`, и с 6.30.0, когда
        // наверху появился микс, он не пропускал НИ ОДНОГО результата: у всех песен провайдер
        // стал "mix", а настоящий источник уехал в префикс remoteId (`dz:3135556`, `yt:JhulB...`).
        // То есть прогрев, ради которого писалась 6.22.0, три релиза подряд молча не делал ничего,
        // и каждый первый тап платил полную холодную цену. Теперь префикс разбирается.
        val yt = mutableListOf<String>()
        val dz = mutableListOf<String>()
        for (song in songs) {
            if (song.remoteId.isBlank()) continue
            val (provider, inner) = when (song.provider) {
                MIX_ID -> {
                    val cut = song.remoteId.indexOf(':')
                    if (cut <= 0) continue
                    song.remoteId.substring(0, cut) to song.remoteId.substring(cut + 1)
                }
                else -> song.provider to song.remoteId
            }
            if (inner.isBlank()) continue
            when (provider) {
                InnertubeCatalog.ID -> if (yt.size < WARM_TOP) yt += inner
                DEEZER_ID -> if (dz.size < WARM_TOP) dz += inner
            }
            if (yt.size >= WARM_TOP && dz.size >= WARM_TOP) break
        }
        // Только ССЫЛКИ. Байты первых результатов поиска в 6.22.0 забивали канал сервера и
        // замедляли тот самый тап, который прогрев должен был ускорить.
        if (yt.isNotEmpty()) ZiziResolve.prefetch(yt, bytes = false)
        // Витрине нужен свой прогрев, и он дешевле резолва: сервер сопоставляет запись с
        // источником звука и кладёт videoId в SQLite. Один раз на трек, навсегда, для всех.
        if (dz.isNotEmpty()) DeezerCatalog.warm(dz)
    }


    private fun dedupe(items: List<RemoteItem>): List<RemoteItem> {
        val seen = HashSet<String>(items.size * 2)
        return items.filter { item ->
            val key = when (item) {
                is RemoteItem.Song -> item.track.trackId
                is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
            }
            seen.add(key)
        }
    }

    private inline fun update(tab: SearchTab, block: (TabResults) -> TabResults) {
        val current = _state.value
        val updated = block(current.results[tab] ?: TabResults())
        _state.value = current.copy(results = current.results + (tab to updated))
    }

    // ---------------------------------------------------------------- collections

    fun openCollection(collection: RemoteCollection) {
        suggestJob?.cancel()
        _state.value = _state.value.copy(previewLoading = false)
        collectionJob?.cancel()
        collectionGeneration++
        if (!CatalogPolicy.supports(collection.provider, collection.remoteId)) {
            _state.value = _state.value.copy(collection = OpenCollection(
                collection.copy(artworkUrl = null, subtitle = ""), loading = false,
                error = "Этот источник больше не поддерживается. Найди исполнителя заново"
            ))
            return
        }
        _state.value = _state.value.copy(collection = OpenCollection(collection))
        fetchCollection(append = false)
    }

    fun loadMoreCollection() {
        val open = _state.value.collection ?: return
        if (!open.loading && !open.appending && open.error == null && open.nextToken != null) {
            fetchCollection(append = true)
        }
    }

    fun retryCollection() {
        val open = _state.value.collection ?: return
        fetchCollection(append = open.tracks.isNotEmpty() && open.nextToken != null)
    }

    private fun fetchCollection(append: Boolean) {
        val open = _state.value.collection ?: return
        val target = open.collection
        val generation = collectionGeneration
        val token = if (append) open.nextToken ?: return else null
        collectionJob?.cancel()
        _state.value = _state.value.copy(collection = open.copy(
            loading = !append, appending = append, error = null
        ))
        collectionJob = viewModelScope.launch {
            try {
                val catalog = repo.catalogs.byId(target.provider)
                    ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник недоступен")
                val page = catalog.collectionPage(target, token)
                currentCoroutineContext().ensureActive()
                if (generation != collectionGeneration) return@launch
                // Playlist duplicates and order are deliberate; UI keys include the position.
                val tracks = if (append) open.tracks + page.tracks else page.tracks
                _state.value = _state.value.copy(collection = OpenCollection(
                    collection = page.collection, tracks = tracks, loading = false,
                    nextToken = SearchPresentation.nextPage(page.nextToken, token, page.tracks.size),
                    total = page.total ?: open.total
                ))
                if (page.tracks.isNotEmpty()) repo.rememberRemote(page.tracks)
                currentCoroutineContext().ensureActive()
                if (!append && generation == collectionGeneration) warmTop(page.tracks)
            } catch (e: CatalogException) {
                currentCoroutineContext().ensureActive()
                if (generation == collectionGeneration) {
                    val current = _state.value.collection ?: return@launch
                    _state.value = _state.value.copy(collection = current.copy(
                        loading = false, appending = false, error = explain(e)
                    ))
                }
            }
        }
    }

    fun closeCollection() {
        collectionGeneration++
        collectionJob?.cancel()
        _state.value = _state.value.copy(collection = null)
    }

    // ---------------------------------------------------------------- history

    fun forgetQuery(query: String) { viewModelScope.launch { repo.forgetQuery(query) } }
    fun clearHistory() { viewModelScope.launch { repo.clearSearchHistory() } }

    // ---------------------------------------------------------------- recents

    /**
     * Запомнить трек как недавний.
     *
     * Вызывается на ВОСПРОИЗВЕДЕНИИ, а не на добавлении. Это принципиально другое событие, чем
     * «+»: «+» кладёт трек в медиатеку и меняет savedAt, а недавнее не кладёт никуда и ничего
     * не меняет — оно только помнит, что человек здесь был. Смешать их значило бы либо засорять
     * медиатеку прослушиванием (ровно то, чего этот проект избегает с 6.4), либо забывать всё,
     * что не сохранено, — то есть почти всё.
     *
     * Ключ строится из provider и remoteId, а не из заголовка: один и тот же трек, открытый из
     * поиска, из полки и из альбома, обязан быть одной строкой, которая поднимается наверх, а не
     * тремя одинаковыми.
     */
    fun rememberRecent(track: RemoteTrack) {
        viewModelScope.launch {
            repo.rememberRecent(
                RecentEntity(
                    key = "t:" + track.trackId,
                    kind = RecentKind.TRACK,
                    title = track.title,
                    subtitle = track.artist,
                    artworkUrl = track.artworkUrl,
                    provider = track.provider,
                    remoteId = track.remoteId,
                    trackId = track.trackId,
                    durationMs = track.durationMs
                )
            )
        }
    }

    fun rememberRecent(collection: RemoteCollection) {
        viewModelScope.launch {
            repo.rememberRecent(
                RecentEntity(
                    key = "c:" + collection.provider + ":" + collection.remoteId,
                    kind = when (collection.kind) {
                        RemoteKind.ALBUM -> RecentKind.ALBUM
                        RemoteKind.ARTIST -> RecentKind.ARTIST
                        RemoteKind.PLAYLIST -> RecentKind.PLAYLIST
                        RemoteKind.TRACK -> RecentKind.TRACK
                    },
                    title = collection.title,
                    subtitle = collection.subtitle,
                    artworkUrl = collection.artworkUrl,
                    provider = collection.provider,
                    remoteId = collection.remoteId
                )
            )
        }
    }

    fun forgetRecent(key: String) { viewModelScope.launch { repo.forgetRecent(key) } }
    fun clearRecents() { viewModelScope.launch { repo.clearRecents() } }

    /**
     * One back step inside the section, or false to let the app handle it.
     *
     * Collection -> results -> hub. Editing returns to the surface that opened it:
     * hub entry -> history -> hub; result field -> suggestions -> the existing results.
     * The last submitted query/results survive a new history entry until a new query is submitted.
     */
    fun back(): Boolean {
        val current = _state.value
        return when {
            current.collection != null -> { closeCollection(); true }
            current.stage == SearchStage.SUGGEST || current.stage == SearchStage.RECENT -> {
                suggestJob?.cancel()
                _state.value = current.copy(
                    stage = SearchNavigation.backFromEditor(editorReturnStage, current.query),
                    previewLoading = false
                )
                true
            }
            current.stage == SearchStage.RESULTS -> {
                _state.value = current.copy(stage = SearchStage.HUB)
                true
            }
            else -> false
        }
    }

    private fun explain(e: CatalogException): String = when (e.reason) {
        CatalogException.Reason.OFFLINE -> "Нет соединения"
        CatalogException.Reason.RATE_LIMITED -> "Источник просит подождать. Попробуй через минуту"
        CatalogException.Reason.METERED_BLOCKED -> "Включено «только Wi-Fi»"
        CatalogException.Reason.UNAVAILABLE -> e.message ?: "Недоступно"
        // Deliberately verbatim. A protocol error means the provider changed its answers and this
        // app is the broken side; hiding that behind "что-то пошло не так" is how a two line fix
        // turns into an evening of guessing.
        CatalogException.Reason.PROTOCOL -> e.message ?: "Источник ответил неожиданно"
    }

    fun providerName(id: String?): String = id?.let { providerLabel(it) } ?: ""

    private companion object {
        const val KEY_FIELD = "search.field"
        const val KEY_QUERY = "search.query"
        const val KEY_STAGE = "search.stage"
        const val KEY_TAB = "search.tab"
        const val KEY_COLLECTION = "search.collection"

        /** ASCII unit separator: cannot occur in a title, an id or a provider name. */
        const val UNIT_SEP = "\u001f"

        /** Сколько первых треков страницы отдаём на прогрев резолверу (6.22.0). */
        const val WARM_TOP = 3

        /** Идентификаторы источников, которые разбирает [warmTop]. Строками — их знает реестр. */
        const val MIX_ID = "mix"
        const val DEEZER_ID = "dz"
    }
}
