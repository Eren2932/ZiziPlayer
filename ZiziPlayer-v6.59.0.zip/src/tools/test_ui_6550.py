#!/usr/bin/env python3
"""Production Java geometry + source wiring; explicitly NOT Kotlin/APK or device tests."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (SRC / path).read_text()

class Ui6550(unittest.TestCase):
    def test_production_geometry(self):
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                str(SRC/'ui/CollectionGeometry.java'), str(SRC/'ui/AccountUiGeometry.java'),
                str(ROOT/'app/src/test/java/app/ziziplayer/ui/AccountUi6550Checks.java')], check=True)
            subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.AccountUi6550Checks'], check=True)

    def test_single_drawer_clock_and_no_frame_recomposition(self):
        s = read('ui/components/AccountDrawerHost.kt')
        self.assertEqual(s.count('Animatable('), 1)
        self.assertIn('tween(280, easing = FastOutSlowInEasing)', s)
        self.assertIn('translationX = travel * (progress.value - 1f)', s)
        self.assertIn('translationX = travel * progress.value', s)
        self.assertIn('.roundToInt().toFloat()', s)
        self.assertIn('derivedStateOf { open || progress.value > 0f }', s)
        for forbidden in ['snapTo(', 'delay(', 'animateContentSize', 'RenderEffect', 'launch {']:
            self.assertNotIn(forbidden, s)

    def test_drawer_single_host_and_outgoing_input_guard(self):
        s = read('MainActivity.kt')
        self.assertEqual(s.count('AccountDrawerHost(open'), 1)
        self.assertEqual(s.count('AccountDrawer(account'), 1)
        self.assertNotIn('if (accountDrawer) AccountDrawer', s)
        host = s[:s.index('override fun onNewIntent')]
        self.assertGreater(host.index('StatusBarTint('), host.index('ZiziApp('))
        self.assertIn('accountDrawer -> accountDrawer = false', s)
        host = read('ui/components/AccountDrawerHost.kt')
        self.assertIn('if (!open) Box(Modifier.fillMaxSize().blockSurfaceInput())', host)
        self.assertIn('Modifier.clearAndSetSemantics', host)
        self.assertIn('indication = null', host)

    def test_drawer_background_never_has_ripple(self):
        s = read('ui/screens/AccountScreen.kt').split('fun AccountDrawer(')[1]
        self.assertIn('.surfaceInputBoundary()', s)
        self.assertNotIn('clickable(enabled = true, onClick = {})', s)
        self.assertIn('Color(0xFF202020)', s)
        guard = read('ui/components/SurfaceInput.kt')
        self.assertIn('PointerEventPass.Main', guard)
        self.assertIn('it.consume()', guard)
        self.assertNotIn('clickable', guard)

    def test_avatar_click_has_accessibility_but_no_flash(self):
        s = read('ui/screens/HomeScreen.kt').split('onClickLabel = "Открыть меню аккаунта"')[0]
        self.assertIn('interactionSource = remember { MutableInteractionSource() }, indication = null,', s)
        self.assertIn('role = Role.Button', s)

    def test_avatar_decode_is_bounded_shared_and_off_main(self):
        s = read('ui/components/AccountAvatar.kt')
        for required in ['key(avatar)', 'produceState(AvatarBitmapCache.get(avatar), avatar)',
                         'withContext(Dispatchers.Default)', 'LruCache<String, ImageBitmap>(4)',
                         'Mutex()', 'decodeLock.withLock', 'bounds.outWidth !in 1..256',
                         'bounds.outHeight !in 1..256', 'avatar.length > 410000']:
            self.assertIn(required, s)
        self.assertNotIn('value = null', s)
        self.assertEqual(s.count('Base64.decode('), 1)

    def test_profile_lazy_rows_and_restored_deep_scroll(self):
        s = read('ui/screens/AccountScreen.kt').split('fun AccountDrawer(')[0]
        self.assertIn('items(playlists, key = { "profile:playlist:${it.id}" }', s)
        self.assertNotIn('playlists.forEach', s)
        self.assertIn('contentPadding = PaddingValues(bottom = bottom + 24.dp)', s)
        self.assertIn('if (list.firstVisibleItemIndex > 0) 1f', s)
        self.assertIn('.onSizeChanged { heroPx = it.height }', s)
        self.assertEqual(s.count('PinnedPageHeader('), 1)
        self.assertEqual(s.count('onClick = onClose'), 0) # back exists only in the shared toolbar

    def test_history_clear_is_pinned_and_still_confirmed(self):
        s = read('ui/screens/HomeScreen.kt')
        self.assertIn('item("history:header-space")', s)
        self.assertIn('PinnedPageHeader(title = "История"', s)
        self.assertIn('action = { TextButton(onClick = { confirmClear = true })', s)
        self.assertIn('if (confirmClear) AlertDialog', s)
        self.assertEqual(s.count('home.clearHistory()'), 1)
        self.assertIn('historyScroll.firstVisibleItemScrollOffset.toFloat()', s)

    def test_chrome_85_percent_does_not_dim_children_or_use_blur(self):
        s = read('ui/components/TopChrome.kt').split('fun Modifier.pinnedPageChrome')[1].split('fun Modifier.bottomChrome')[0]
        self.assertIn('AccountUiGeometry.TOP_SCRIM_ALPHA', s)
        self.assertIn('CollectionGeometry.smoothstep(t)', s)
        self.assertIn('onDrawBehind', s)
        for forbidden in ['graphicsLayer', 'saveLayer', 'RenderEffect', '.blur(']:
            self.assertNotIn(forbidden, s)
        header = read('ui/components/PinnedPageHeader.kt')
        self.assertIn('.blockSurfaceInput()', header)
        self.assertIn('derivedStateOf', header)
        self.assertIn('Modifier.clearAndSetSemantics', header)

    def test_profile_and_settings_are_under_single_dock(self):
        s = read('MainActivity.kt')
        profile = s.index('if (accountOpen) {')
        settings = s.index('if (accountSettings) {', profile)
        dock = s.index('.bottomChrome()')
        self.assertLess(profile, settings)
        self.assertLess(settings, dock)
        self.assertEqual(s.count('.bottomChrome()'), 1)
        self.assertEqual(s.count('MiniPlayer('), 1)
        profile_body = s[profile:settings]
        self.assertNotIn('.padding(bottom = dockInset)', profile_body)
        self.assertIn('.background(app.ziziplayer.ui.theme.basePalette().surface)', profile_body)
        self.assertIn('if (!accountOpen && !accountSettings) drawContent()', s)
        self.assertIn('if (!accountSettings) drawContent()', profile_body)

    def test_neutral_palette_and_material_theme(self):
        main = read('MainActivity.kt')
        self.assertIn('ZiziTheme(app.ziziplayer.ui.theme.basePalette())', main)
        settings = read('ui/screens/Sheets.kt').split('fun SettingsSheet(')[1].split('private fun DevCodeDialog')[0]
        self.assertIn('CompositionLocalProvider(LocalPalette provides app.ziziplayer.ui.theme.basePalette())', settings)
        self.assertIn('ZiziTheme(app.ziziplayer.ui.theme.basePalette())', settings)
        self.assertNotIn('withAccent', settings)

    def test_no_added_player_listener_or_dependency(self):
        for file in ['ui/components/AccountDrawerHost.kt', 'ui/components/PinnedPageHeader.kt',
                     'ui/screens/AccountScreen.kt', 'ui/components/AccountAvatar.kt']:
            s = read(file)
            for forbidden in ['addListener(', 'addObserver(', 'rememberInfiniteTransition', 'MediaController']:
                self.assertNotIn(forbidden, s)
        gradle = (ROOT/'app/build.gradle.kts').read_text()
        self.assertIn('versionCode = 110', gradle)
        self.assertIn('versionName = "6.59.0"', gradle)

if __name__ == '__main__': unittest.main(verbosity=2)
