# Сервер 1.29-version-guard (комплект 6.100.1)

Заменяет: `zizi_versions.py`, `zizi_match.py`, `zizi_ytm.py`, `zizi_browse.py`, `zizi_import.py`, `zizi_catalog.py`. Остальные модули комплекта без изменений.

## Установка (как раньше, единый установщик)
```
cd <распакованный комплект>/server   # каталог с tools/deploy_server.py; он сам находит каталог сервера (/opt/zizi)
/opt/zizi/venv/bin/python tools/deploy_server.py --check      # ничего не пишет: план и проверка баз
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply # бэкап, тесты, замена, проверка /catalog/health, откат при сбое
sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>
```
Успех = `/catalog/health`: `version == 1.29-version-guard`, `import_rev == 3` (плюс прежние match_engine/reco/import контракты).
Если `--check` отвечает «unknown server edit: <файл>», на VPS файл правился руками или это не 1.27.2/1.28: пришлите его, не форсируйте.

## Что изменится после деплоя
- Весь кэш `/match` и кэш импорта начнёт наполняться заново (RULES 9, префикс `r3:`). Старые строки импорта удаляются при старте.
- Поиск: версии без запроса на них (минус, концерт, ремикс, другой язык) идут после обычных записей внутри страницы выдачи.
- Миграции БД нет, env не меняется.

## Откат
`--rollback` возвращает файлы из бэкапа; клиент с 1.28 совместим (поле `album` у кандидата необязательное).
