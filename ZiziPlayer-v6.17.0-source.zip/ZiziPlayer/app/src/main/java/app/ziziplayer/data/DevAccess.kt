package app.ziziplayer.data

import app.ziziplayer.BuildConfig
import java.security.MessageDigest

/**
 * Служебный доступ (6.17.0). Бывший «режим отладки», закрытый по-настоящему.
 *
 * ЧТО БЫЛО. Технические строки — адрес резолвера, токен, обход клиентов YouTube, полная
 * диагностика потока — открывались семью тапами по строке «О приложении». Тестер нашёл их
 * случайно, ткнув в строку несколько раз подряд. Это не дыра в безопасности в строгом смысле
 * (токен и так вшит в APK, и разобрать APK умеет любой), но это интерфейс, которого пользователь
 * видеть не должен: одна опечатка в адресе резолвера — и приложение перестаёт играть, а виноват
 * в этом будет разработчик.
 *
 * ЧТО СТАЛО. Секрет перенесён из жеста в знание:
 *
 *  1. жест сам по себе ничего не открывает — длинное нажатие лишь показывает поле для кода;
 *  2. код проверяется по SHA-256, вшитому на этапе сборки (`-PdevUnlockCode=...`); в репозитории
 *     и в APK лежит только хеш;
 *  3. сборка без вшитого хеша, но с боевым токеном резолвера, не открывается ВООБЩЕ — для релиза
 *     это и есть правильное состояние;
 *  4. доступ живёт сессией (15 минут) и НЕ переживает перезапуск приложения: раньше флаг лежал
 *     в DataStore, и «случайно открыл» означало «открыто навсегда»;
 *  5. три неверных попытки — десять минут тишины, чтобы код нельзя было подобрать перебором.
 *
 * Сравнение хеша идёт за постоянное время. На локальном коде это паранойя, стоящая четырёх строк.
 */
object DevAccess {

    private const val SALT = "zizi-dev-v1:"
    private const val MAX_ATTEMPTS = 3
    private const val LOCKOUT_MS = 10L * 60 * 1000

    /** Сколько живёт открытая сессия. */
    const val SESSION_MS = 15L * 60 * 1000

    /** Сборка, где служебные строки должны быть закрыты (то есть любая настоящая релизная). */
    val protected: Boolean
        get() = BuildConfig.RESOLVER_TOKEN.isNotBlank() || BuildConfig.DEV_UNLOCK_HASH.isNotBlank()

    /** Есть ли вообще чем открывать. Нет хеша — нет и способа войти. */
    val unlockable: Boolean get() = BuildConfig.DEV_UNLOCK_HASH.isNotBlank()

    private var failedAttempts = 0
    private var lockedUntil = 0L

    fun lockoutLeftMs(now: Long = System.currentTimeMillis()): Long =
        (lockedUntil - now).coerceAtLeast(0L)

    /** true — код верный. Любой другой исход неотличим снаружи: ни подсказок, ни разных ошибок. */
    fun check(code: String): Boolean {
        val now = System.currentTimeMillis()
        if (!unlockable || lockoutLeftMs(now) > 0L) return false
        val ok = constantTimeEquals(sha256(SALT + code.trim()), BuildConfig.DEV_UNLOCK_HASH.lowercase())
        if (ok) {
            failedAttempts = 0
            return true
        }
        failedAttempts++
        if (failedAttempts >= MAX_ATTEMPTS) {
            failedAttempts = 0
            lockedUntil = now + LOCKOUT_MS
        }
        return false
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { byte -> "%02x".format(byte) }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
