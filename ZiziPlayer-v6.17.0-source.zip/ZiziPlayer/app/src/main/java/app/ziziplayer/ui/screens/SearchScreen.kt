package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.remote.DiscoverShelf
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.providerLabel
import app.ziziplayer.ui.MainViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.ui.OpenCollection
import app.ziziplayer.ui.SearchStage
import app.ziziplayer.ui.SearchTab
import app.ziziplayer.ui.SearchUiState
import app.ziziplayer.ui.SearchViewModel
import app.ziziplayer.ui.TabResults
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.PillChip
import app.ziziplayer.ui.components.NowPlayingBadge
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.TrackTitle
import app.ziziplayer.ui.components.fallbackSwatchesFor
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.key
import androidx.compose.ui.platform.LocalDensity

/** Materialised once: `values()` allocates a fresh array on every call, this is a LazyRow key. */
private val SEARCH_TABS: List<SearchTab> = SearchTab.values().toList()

private val ROW_ART = 46.dp
private val CARD = 128.dp

/**
 * "Поиск" - the section that makes the app more than a file browser.
 *
 * The shape is borrowed openly from the big players, because that shape is not a style choice: a
 * catalogue of millions of items has exactly one usable entry pattern - a field, a browsable hub
 * behind it for when you have nothing to type, suggestions while you type, paged results when you
 * commit. What is NOT borrowed is the content of the hub. A wall of invented genre tiles is the
 * tell of a screen designed by someone who has no data; this hub is built out of the artists
 * already in the user's own library plus whatever the provider's real charts return, so it says
 * something true from the first launch and nothing at all when it cannot.
 *
 * The other deliberate difference from the reference: every remote row carries a "+" and only the
 * "+" puts anything in the library. Listening never does. See TrackEntity.savedAt - without that
 * split, one evening of poking at search buries a hand-curated local library.
 */
@Composable
fun SearchScreen(
    vm: MainViewModel,
    search: SearchViewModel,
    state: SearchUiState,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    /** Artists from the user's own library, most played first. The hub's tiles. */
    seeds: List<String>
) {
    val p = LocalPalette.current
    val chips = remember(p.chip, p.text, p.accent, p.onAccent) {
        ChipColors(p.chip, p.text, p.accent, p.onAccent)
    }

    // 6.17.0 — сборники, которые уже добавлены к себе, и цель для нового добавления.
    val links by vm.collectionLinks.collectAsStateWithLifecycle()
    val playlists by vm.playlistsForPicker.collectAsStateWithLifecycle()
    var savePicker by remember { mutableStateOf<OpenCollection?>(null) }
    var confirmRemove by remember { mutableStateOf<OpenCollection?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text(
                text = "Поиск",
                color = p.text,
                fontSize = 27.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = 18.dp, top = 10.dp, bottom = 8.dp)
            )

            SearchField(
                text = state.field,
                onText = search::onField,
                onSubmit = { search.submit(it) },
                onClear = search::clearField,
                onFocused = search::onFieldFocused,
                // Autofocus only when the user arrived at an empty hub. Focusing the field on the
                // way back from a result throws the keyboard over the list they just asked to see.
                autofocus = false
            )

            when (state.stage) {
                SearchStage.HUB -> HubBody(
                    state = state,
                    seeds = seeds,
                    onSearch = search::submit,
                    onOpen = search::openCollection,
                    onPlay = { track -> vm.playRemote(listOf(track), 0) },
                    onForget = search::forgetQuery,
                    onClearHistory = search::clearHistory,
                    onRetryHub = { search.loadHub(force = true) }
                )

                SearchStage.SUGGEST -> SuggestBody(
                    field = state.field,
                    suggestions = state.suggestions,
                    history = state.history,
                    onPick = search::submit
                )

                SearchStage.RESULTS -> ResultsBody(
                    state = state,
                    chips = chips,
                    savedIds = savedIds,
                    currentTrackId = currentTrackId,
                    isPlaying = isPlaying,
                    onTab = search::setTab,
                    onLoadMore = search::loadMore,
                    onRetry = search::retry,
                    onPlay = { list, index -> vm.playRemote(list, index) },
                    onSave = vm::saveRemote,
                    onUnsave = { vm.setRemoteSaved(it, false) },
                    onOpen = search::openCollection,
                    importedKeys = links.keys
                )
            }
        }

        state.collection?.let { open ->
            val key = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            CollectionSheet(
                open = open,
                savedIds = savedIds,
                currentTrackId = currentTrackId,
                isPlaying = isPlaying,
                onClose = search::closeCollection,
                onPlay = { index -> vm.playRemote(open.tracks, index) },
                onShuffle = {
                    val shuffled = open.tracks.shuffled()
                    vm.playRemote(shuffled, 0)
                },
                imported = links.containsKey(key),
                onAddCollection = { savePicker = open },
                onRemoveCollection = { confirmRemove = open },
                onSave = vm::saveRemote,
                onUnsave = { vm.setRemoteSaved(it, false) }
            )
        }

        /*
         * СОХРАНЕНИЕ СБОРНИКА (6.17.0).
         *
         * Раньше здесь была одна кнопка «+ всё», которая помечала каждый трек сохранённым — и всё
         * добавленное из поиска, независимо от того, из какого альбома оно пришло, оседало в одной
         * папке «YouTube Music». Теперь сборник спрашивает, КУДА его положить, и по умолчанию
         * предлагает завести плейлист с его же именем.
         */
        savePicker?.let { open ->
            val key = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            PlaylistPickerSheet(
                playlists = playlists,
                title = "Сохранить к себе",
                subtitle = "«${open.collection.title}» · ${open.tracks.size}",
                defaultName = open.collection.title,
                onPick = { id ->
                    vm.saveCollectionAsPlaylist(key, open.collection.title, open.tracks, intoPlaylistId = id)
                    savePicker = null
                },
                onCreate = { name ->
                    vm.saveCollectionAsPlaylist(key, open.collection.title, open.tracks, newName = name)
                    savePicker = null
                },
                onDismiss = { savePicker = null }
            )
        }

        confirmRemove?.let { open ->
            val key = vm.collectionKey(open.collection.provider, open.collection.remoteId)
            val link = links[key]
            if (link == null) confirmRemove = null
            else ConfirmDialog(
                title = if (link.owned) "Удалить плейлист?" else "Убрать треки?",
                message = if (link.owned)
                    "«${link.title}» пропадёт из медиатеки целиком. Сам сборник останется в поиске — добавить заново можно в любой момент."
                else "Треки этого сборника уйдут из плейлиста «${link.title}». Остальное в плейлисте не тронем.",
                confirm = if (link.owned) "Удалить" else "Убрать",
                onConfirm = {
                    vm.removeCollection(key, open.tracks.map { it.trackId })
                    confirmRemove = null
                },
                onDismiss = { confirmRemove = null }
            )
        }
    }
}

// ------------------------------------------------------------------ the field

@Composable
private fun SearchField(
    text: String,
    onText: (String) -> Unit,
    onSubmit: (String) -> Unit,
    onClear: () -> Unit,
    onFocused: () -> Unit,
    autofocus: Boolean
) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(autofocus) { if (autofocus) focus.requestFocus() }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(p.chip.copy(alpha = 0.8f))
            .padding(start = 14.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = p.subtext, modifier = Modifier.size(21.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = text,
            // Unlike the library field, this one publishes every keystroke to the view model and
            // does NOT debounce here. The debounce that matters is on the network request, and it
            // lives in SearchViewModel where it can be cancelled; duplicating it in the widget
            // would only add lag between the key and the letter.
            onValueChange = onText,
            singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium),
            cursorBrush = SolidColor(p.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                onSubmit(text)
                keyboard?.hide()
            }),
            modifier = Modifier
                .weight(1f)
                .focusRequester(focus)
                .onFocusChanged { if (it.isFocused) onFocused() },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) {
                        Text("Что хочешь послушать?", color = p.subtext, fontSize = 16.sp)
                    }
                    inner()
                }
            }
        )
        if (text.isNotEmpty()) {
            // Positional, not a trailing lambda: RoundIconButton takes `modifier` after `onClick`,
            // so `{ ... }` outside the parentheses does not compile.
            RoundIconButton(
                icon = Icons.Filled.Close,
                tint = p.subtext,
                background = Color.Transparent,
                size = 38,
                iconSize = 20,
                onClick = {
                    onClear()
                    focus.requestFocus()
                }
            )
        }
    }
    Spacer(Modifier.height(10.dp))
}

// ------------------------------------------------------------------ the hub

@Composable
private fun HubBody(
    state: SearchUiState,
    seeds: List<String>,
    onSearch: (String) -> Unit,
    onOpen: (RemoteCollection) -> Unit,
    onPlay: (RemoteTrack) -> Unit,
    onForget: (String) -> Unit,
    onClearHistory: () -> Unit,
    onRetryHub: () -> Unit
) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        if (state.history.isNotEmpty()) {
            item(key = "history-head") {
                SectionHead("Ты искал", action = "Очистить", onAction = onClearHistory)
            }
            item(key = "history-strip") {
                HistoryStrip(
                    history = state.history,
                    onPick = onSearch,
                    onForget = onForget
                )
            }
        }

        if (seeds.isNotEmpty()) {
            item(key = "seeds-head") { SectionHead("Из твоей медиатеки") }
            // Two per row, built by hand rather than with a LazyVerticalGrid: nesting a grid inside
            // a LazyColumn needs a fixed height, and a fixed height is exactly what breaks when the
            // user's font scale is 1.3.
            items(seeds.chunked(2), key = { it.first() }) { pair ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { name ->
                        SeedTile(name, Modifier.weight(1f)) { onSearch(name) }
                    }
                    // Keeps a lone tile at half width instead of stretching it across the row.
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (state.hubError != null) {
            item(key = "hub-error") {
                NoticeStrip(
                    text = "Подборки не загрузились: ${state.hubError}",
                    action = "Повторить",
                    onAction = onRetryHub
                )
            }
        }

        if (state.hubLoading && state.shelves.isEmpty()) {
            item(key = "hub-loading") { LoadingRow("Загружаем подборки…") }
        }

        items(state.shelves, key = { "s:${it.title}" }) { shelf ->
            Shelf(shelf, onOpen = onOpen, onPlay = onPlay)
        }

        if (state.history.isEmpty() && seeds.isEmpty() && state.shelves.isEmpty() && !state.hubLoading) {
            item(key = "hub-empty") {
                Text(
                    "Введи название трека, артиста или альбома",
                    color = p.subtext,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 24.dp)
                )
            }
        }
    }
}

/**
 * A tile for an artist the user already listens to.
 *
 * The gradient comes from [fallbackSwatchesFor], the same deterministic palette the coverless
 * artwork uses, so the tiles are stable between launches and belong to the app's own colour world
 * instead of being five hand-picked neons.
 */
@Composable
private fun SeedTile(name: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val colors = remember(name) { fallbackSwatchesFor(name) }
    Box(
        modifier
            .height(62.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithCache {
                val brush = Brush.linearGradient(
                    listOf(colors.primary, colors.deep),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height)
                )
                onDrawBehind { drawRect(brush) }
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            name,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun Shelf(
    shelf: DiscoverShelf,
    onOpen: (RemoteCollection) -> Unit,
    onPlay: (RemoteTrack) -> Unit
) {
    SectionHead(shelf.title)
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(shelf.items, key = { keyOf(it) }) { item ->
            when (item) {
                is RemoteItem.Song -> ShelfCard(
                    art = item.track.artworkUrl,
                    seed = item.track.trackId,
                    title = item.track.title,
                    subtitle = item.track.artist,
                    round = false,
                    onClick = { onPlay(item.track) }
                )
                is RemoteItem.Group -> ShelfCard(
                    art = item.collection.artworkUrl,
                    seed = item.collection.remoteId,
                    title = item.collection.title,
                    subtitle = item.collection.subtitle.ifBlank { kindLabel(item.collection.kind) },
                    round = item.collection.kind == RemoteKind.ARTIST,
                    onClick = { onOpen(item.collection) }
                )
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun ShelfCard(
    art: String?,
    seed: String,
    title: String,
    subtitle: String,
    round: Boolean,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .width(CARD)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        RemoteArtwork(
            url = art,
            seed = seed,
            // Requested at row size, not card size: the CDN is asked for 240 px (see
            // ArtworkCache.sizedUrl) which is already more than a 128 dp card needs on a 3x screen,
            // and it means the same bytes serve the card, the row and the mini player.
            maxPx = ARTWORK_ROW_PX,
            modifier = Modifier
                .size(CARD)
                .clip(if (round) CircleShape else RoundedCornerShape(8.dp)),
            glyphSize = 34
        )
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            color = p.text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (subtitle.isNotBlank()) {
            Text(subtitle, color = p.subtext, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------------ suggestions

@Composable
private fun SuggestBody(
    field: String,
    suggestions: List<String>,
    history: List<String>,
    onPick: (String) -> Unit
) {
    val p = LocalPalette.current
    val needle = field.trim().lowercase()
    // The user's own past queries outrank the provider's guesses, and are never shown twice.
    val mine = remember(needle, history) {
        if (needle.isEmpty()) emptyList()
        else history.filter { it.lowercase().contains(needle) }.take(4)
    }
    val theirs = remember(mine, suggestions) {
        suggestions.filterNot { suggestion -> mine.any { it.equals(suggestion, ignoreCase = true) } }
    }

    LazyColumn(Modifier.fillMaxSize()) {
        items(mine, key = { "m:$it" }) { query ->
            SuggestRow(query, Icons.Rounded.History, p.subtext) { onPick(query) }
        }
        items(theirs, key = { "t:$it" }) { query ->
            SuggestRow(query, Icons.Filled.Search, p.subtext) { onPick(query) }
        }
        if (mine.isEmpty() && theirs.isEmpty()) {
            item {
                Text(
                    "Нажми поиск на клавиатуре",
                    color = p.subtext,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp)
                )
            }
        }
    }
}

@Composable
private fun SuggestRow(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(14.dp))
        Text(text, color = p.text, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ------------------------------------------------------------------ results

@Composable
private fun ResultsBody(
    state: SearchUiState,
    chips: ChipColors,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onTab: (SearchTab) -> Unit,
    onLoadMore: () -> Unit,
    onRetry: () -> Unit,
    onPlay: (List<RemoteTrack>, Int) -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit,
    onOpen: (RemoteCollection) -> Unit,
    /** Ключи сборников, уже добавленных к себе: на них в списке стоит галочка (6.17.0). */
    importedKeys: Set<String> = emptySet()
) {
    val p = LocalPalette.current
    val results: TabResults = state.current
    val listState = rememberLazyListState()

    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(SEARCH_TABS, key = { it.name }) { tab ->
            PillChip(tab.label, null, state.tab == tab, chips, { onTab(tab) })
        }
    }
    Spacer(Modifier.height(6.dp))

    // The tracks of this list, in list order. Tapping a row plays FROM that row and keeps the rest
    // of the results as the queue - a search result you tap is a queue, not a single track, which
    // is the difference between a player and a preview button.
    val songs = remember(results.items) {
        results.items.filterIsInstance<RemoteItem.Song>().map { it.track }
    }

    // Endless scroll, armed four rows from the bottom so the next page is already arriving by the
    // time the user reaches it. derivedStateOf keeps this out of the recomposition path: reading
    // layoutInfo directly in composition would recompose the whole list on every scrolled pixel.
    val nearEnd by remember(results.items.size) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: return@derivedStateOf false
            last >= results.items.size - 4
        }
    }
    LaunchedEffect(nearEnd, state.tab, state.query, results.nextToken) {
        if (nearEnd) onLoadMore()
    }

    Box(Modifier.fillMaxSize()) {
        when {
            results.loading -> LoadingRow("Ищем…")

            results.error != null && results.items.isEmpty() -> ErrorBlock(results.error, onRetry)

            results.isEmpty -> Text(
                "По запросу «${state.query}» ничего не нашлось",
                color = p.subtext,
                fontSize = 14.5.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 22.dp)
            )

            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                itemsIndexed(results.items, key = { _, item -> keyOf(item) }) { _, item ->
                    when (item) {
                        is RemoteItem.Song -> {
                            val track = item.track
                            ResultTrackRow(
                                track = track,
                                saved = savedIds.contains(track.trackId),
                                playing = currentTrackId == track.trackId && isPlaying,
                                current = currentTrackId == track.trackId,
                                onPlay = {
                                    val index = songs.indexOfFirst { it.trackId == track.trackId }
                                    onPlay(songs, index.coerceAtLeast(0))
                                },
                                onSave = { onSave(track) },
                                onUnsave = { onUnsave(track.trackId) }
                            )
                        }
                        is RemoteItem.Group -> ResultGroupRow(
                            collection = item.collection,
                            imported = importedKeys.contains("${'$'}{item.collection.provider}:${'$'}{item.collection.remoteId}"),
                            onClick = { onOpen(item.collection) }
                        )
                    }
                }

                if (results.appending) {
                    item(key = "appending") { LoadingRow("Ещё…") }
                }
                if (results.error != null && results.items.isNotEmpty()) {
                    // A page that failed after the first one must not blank the results already on
                    // screen. It gets a strip at the bottom and nothing else moves.
                    item(key = "tail-error") {
                        NoticeStrip(results.error, "Ещё раз", onRetry)
                    }
                }
                if (results.provider != null) {
                    item(key = "provider") {
                        Text(
                            "Источник: ${providerLabel(results.provider)}",
                            color = p.subtext.copy(alpha = 0.7f),
                            fontSize = 11.5.sp,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultTrackRow(
    track: RemoteTrack,
    saved: Boolean,
    playing: Boolean,
    current: Boolean,
    onPlay: () -> Unit,
    onSave: () -> Unit,
    onUnsave: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = 14.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.Center) {
            RemoteArtwork(
                url = track.artworkUrl,
                seed = track.trackId,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier
                    .size(ROW_ART)
                    .clip(RoundedCornerShape(7.dp)),
                glyphSize = 18
            )
            // 6.13.0: было `Icon(PlayArrow)` — ▶ у играющего трека против ⏸ в мини-плеере.
            NowPlayingBadge(current = current, playing = playing, size = ROW_ART, corner = 7.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            TrackTitle(
                title = track.title,
                color = if (current) p.accent else p.text,
                dim = p.text.copy(alpha = 0.45f),
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (track.explicit) {
                    ExplicitBadge()
                    Spacer(Modifier.width(5.dp))
                }
                Text(
                    buildString {
                        append(track.artist)
                        if (track.durationMs > 0) append(" · ").append(formatTime(track.durationMs))
                    },
                    color = p.subtext,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        // The one control on the row, and it says what it does: plus means "не у меня", check means
        // "у меня". Nothing here deletes anything - unsaving only removes the row from the library,
        // the track keeps playing if it is playing.
        RoundIconButton(
            icon = if (saved) Icons.Rounded.Check else Icons.Rounded.Add,
            tint = if (saved) p.accent else p.text,
            background = Color.Transparent,
            size = 42,
            iconSize = 22,
            onClick = { if (saved) onUnsave() else onSave() }
        )
    }
}

@Composable
private fun ResultGroupRow(collection: RemoteCollection, imported: Boolean = false, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 10.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteArtwork(
            url = collection.artworkUrl,
            seed = collection.remoteId,
            maxPx = ARTWORK_ROW_PX,
            modifier = Modifier
                .size(ROW_ART)
                .clip(if (collection.kind == RemoteKind.ARTIST) CircleShape else RoundedCornerShape(7.dp)),
            glyphSize = 18
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                collection.title,
                color = p.text,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                buildString {
                    append(kindLabel(collection.kind))
                    if (collection.subtitle.isNotBlank()) append(" · ").append(collection.subtitle)
                },
                color = p.subtext,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        // Галочка вместо стрелки: сборник уже лежит у тебя, открывать его заново незачем — но
        // если откроешь, там будет «Сохранён» и повторное нажатие уберёт.
        if (imported) {
            Icon(Icons.Rounded.Check, null, tint = p.accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(2.dp))
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = p.subtext, modifier = Modifier.size(22.dp))
    }
}

// ------------------------------------------------------------------ collection

/**
 * An album / playlist / artist, opened.
 *
 * A full-bleed layer rather than a modal bottom sheet: the content is a list of unknown length, and
 * a sheet that can be dragged while its list scrolls is the single most common way to make a
 * screen feel broken. This one has a back arrow and nothing to fight with.
 */
@Composable
private fun CollectionSheet(
    open: OpenCollection,
    savedIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onClose: () -> Unit,
    onPlay: (Int) -> Unit,
    onShuffle: () -> Unit,
    /** Сборник уже добавлен к себе (6.17.0). */
    imported: Boolean,
    onAddCollection: () -> Unit,
    onRemoveCollection: () -> Unit,
    onSave: (RemoteTrack) -> Unit,
    onUnsave: (String) -> Unit
) {
    val p = LocalPalette.current
    val collection = open.collection
    Column(
        Modifier
            .fillMaxSize()
            .background(p.bottom)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 6.dp, end = 10.dp, top = 6.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(Icons.Filled.Close, p.text, Color.Transparent, 42, 22, onClose)
            Spacer(Modifier.width(4.dp))
            Text(
                kindLabel(collection.kind),
                color = p.subtext,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
            item(key = "head") {
                Column(Modifier.padding(horizontal = 18.dp)) {
                    RemoteArtwork(
                        url = collection.artworkUrl,
                        seed = collection.remoteId,
                        maxPx = 320,
                        modifier = Modifier
                            .size(148.dp)
                            .clip(
                                if (collection.kind == RemoteKind.ARTIST) CircleShape
                                else RoundedCornerShape(12.dp)
                            ),
                        glyphSize = 46
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        collection.title,
                        color = p.text,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (collection.subtitle.isNotBlank()) {
                        Text(collection.subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 2)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (open.tracks.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ActionButton("Слушать", Icons.Rounded.PlayArrow, filled = true) { onPlay(0) }
                            ActionButton("Перемешать", Icons.Rounded.Shuffle, filled = false, onClick = onShuffle)
                            /*
                             * БАГ «ПЛЮС С ПЛЮСИКОМ» (6.15.0).
                             *
                             * Было: ActionButton("+ всё", Icons.Rounded.Add) — иконка-плюс и текст,
                             * начинающийся с плюса. На экране это выглядело как два плюса разного
                             * размера подряд. Кнопка теперь называется глаголом, а знак ставит
                             * только иконка; заодно она честно показывает состояние.
                             */
                            if (imported) {
                                ActionButton("Сохранён", Icons.Rounded.Check, filled = true, onClick = onRemoveCollection)
                            } else {
                                ActionButton("Сохранить", Icons.Rounded.PlaylistAdd, filled = false, onClick = onAddCollection)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }

            when {
                open.loading -> item(key = "loading") { LoadingRow("Открываем…") }
                open.error != null -> item(key = "error") { ErrorBlock(open.error, null) }
                open.tracks.isEmpty() -> item(key = "empty") {
                    Text(
                        "Здесь нет доступных треков",
                        color = p.subtext,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(18.dp)
                    )
                }
                else -> itemsIndexed(open.tracks, key = { _, t -> t.trackId }) { index, track ->
                    ResultTrackRow(
                        track = track,
                        saved = savedIds.contains(track.trackId),
                        playing = currentTrackId == track.trackId && isPlaying,
                        current = currentTrackId == track.trackId,
                        onPlay = { onPlay(index) },
                        onSave = { onSave(track) },
                        onUnsave = { onUnsave(track.trackId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    filled: Boolean,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (filled) p.accent else p.chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            null,
            tint = if (filled) p.onAccent else p.text,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            label,
            color = if (filled) p.onAccent else p.text,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

// ------------------------------------------------------------------ small parts

@Composable
private fun SectionHead(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 14.dp, top = 14.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            color = p.text,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (action != null && onAction != null) {
            Text(
                action,
                color = p.subtext,
                fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

/**
 * The search history, capped at [HISTORY_VISIBLE] rows with its own scroll.
 *
 * The list is capped at 20 entries in the database, and before this it was rendered as 20 items of
 * the hub's own `LazyColumn`. That is what pushed the shelves off the first screen: the more the
 * user searched, the further "New albums" travelled down, until the hub stopped looking like a hub.
 *
 * Nesting a vertical scroll inside a vertical `LazyColumn` is legal exactly when the child gets a
 * bounded height, which is why the height is computed rather than left to `wrapContentHeight`. It
 * is derived from `fontScale` instead of being a hard `220.dp`, because a hard value clips the last
 * row at 1.3x text size - the same trap as the fixed sheet heights elsewhere in this file.
 */
private const val HISTORY_VISIBLE = 5

@Composable
private fun HistoryStrip(
    history: List<String>,
    onPick: (String) -> Unit,
    onForget: (String) -> Unit
) {
    val p = LocalPalette.current
    if (history.size <= HISTORY_VISIBLE) {
        Column(Modifier.fillMaxWidth()) {
            history.forEach { query ->
                HistoryRow(query, onPick = { onPick(query) }, onForget = { onForget(query) })
            }
        }
        return
    }

    val scale = LocalDensity.current.fontScale.coerceIn(1f, 1.6f)
    val rowHeight = 44.dp * scale
    val scroll = rememberScrollState()
    Box(
        Modifier
            .fillMaxWidth()
            .height(rowHeight * HISTORY_VISIBLE)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(end = 6.dp)
        ) {
            history.forEach { query ->
                key(query) {
                    HistoryRow(query, onPick = { onPick(query) }, onForget = { onForget(query) })
                }
            }
        }
        // A thin indicator, drawn from the scroll state itself. No library, no gesture handling: it
        // exists so the strip does not look like a clipped list with no way out.
        val maxScroll = scroll.maxValue.toFloat()
        if (maxScroll > 0f) {
            val fraction = (scroll.value / maxScroll).coerceIn(0f, 1f)
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .fillMaxHeight()
                    .width(3.dp)
                    .padding(vertical = 4.dp)
            ) {
                val visible = HISTORY_VISIBLE.toFloat() / history.size.toFloat()
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val thumb = (maxHeight * visible).coerceAtLeast(18.dp)
                    Box(
                        Modifier
                            .offset(y = (maxHeight - thumb) * fraction)
                            .height(thumb)
                            .fillMaxWidth()
                            .background(p.subtext.copy(alpha = 0.35f), CircleShape)
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(query: String, onPick: () -> Unit, onForget: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onPick)
            .padding(start = 18.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.History, null, tint = p.subtext, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(14.dp))
        Text(
            query,
            color = p.text,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        RoundIconButton(Icons.Filled.Close, p.subtext, Color.Transparent, 36, 17, onForget)
    }
}

@Composable
private fun ExplicitBadge() {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(13.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(p.subtext.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center
    ) {
        Text("E", color = p.bottom, fontSize = 9.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun LoadingRow(text: String) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = p.accent,
            strokeWidth = 2.dp
        )
        Spacer(Modifier.width(12.dp))
        Text(text, color = p.subtext, fontSize = 14.sp)
    }
}

@Composable
private fun NoticeStrip(text: String, action: String?, onAction: (() -> Unit)?) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(p.chip.copy(alpha = 0.7f))
            .padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = p.subtext, fontSize = 13.sp, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action,
                color = p.accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun ErrorBlock(text: String, onRetry: (() -> Unit)?) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text,
            color = p.text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
        if (onRetry != null) {
            Spacer(Modifier.height(14.dp))
            ActionButton("Повторить", Icons.Rounded.Refresh, filled = false, onClick = onRetry)
        }
    }
}

private fun keyOf(item: RemoteItem): String = when (item) {
    is RemoteItem.Song -> item.track.trackId
    is RemoteItem.Group -> "g:${item.collection.provider}:${item.collection.remoteId}"
}

private fun kindLabel(kind: RemoteKind): String = when (kind) {
    RemoteKind.TRACK -> "Трек"
    RemoteKind.ALBUM -> "Альбом"
    RemoteKind.PLAYLIST -> "Плейлист"
    RemoteKind.ARTIST -> "Артист"
}
