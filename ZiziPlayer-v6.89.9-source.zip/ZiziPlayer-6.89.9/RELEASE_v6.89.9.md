# ZiziPlayer 6.89.9 — исправление компиляции 6.89.8

База: `ZiziPlayer-v6.89.8-source.zip` (225). Новая версия: **6.89.9 / 226**. Полный проект исходников, **не APK**.

## Что упало

GitHub Actions, шаг «Kotlin compile and JVM tests»: `:app:compileDebugKotlin` и `:app:compileReleaseKotlin`,
`ArtistPageScaffold.kt:201` и `:205`:
`Function invocation 'height(...)' expected`, `Cannot infer type for this parameter`, `Argument type mismatch`.

## Причина

В `drawWithCache { ... buildList { add(y / size.height to ...) } }` внутри лямбды билдера неявный получатель — `MutableList`,
поэтому `size` — это `Int` (размер списка), а не `Size` области рисования. Остальные сообщения — каскад от этой строки.
Мои эвристические проверки Kotlin не компилируют, поэтому ошибку не видели; это была моя ошибка в 6.89.8.

## Исправление

`val heroPx = size.height` читается **до** `buildList`; внутри билдера используется только `heroPx`.
Типы стопов заданы явно (`Array<Pair<Float, Color>>`). Формулы, кривые, палитра и порядок отрисовки — без изменений.

## Защита

`tools/test_kotlin_scope_size_6899.py` сканирует все `.kt` под `app/src` и падает, если внутри `buildList/buildSet/buildMap/buildString`
есть `size.width/height/...`. Проверено: на архиве 6.89.8 находит строки 201 и 205; на 6.89.9 — чисто. Подключена в `tools/check_selftest.py`.

## Что НЕ проверено

Kotlin/Gradle-сборка, Android-тесты и телефон — **NOT RUN** (нет Android SDK/Gradle). Первая реальная компиляция — в вашем CI.
Если упадёт снова, пришлите новый `logs_*.zip`: пройдусь по реальным ошибкам.
