package app.ziziplayer.ui;

import java.util.Random;

/** Production math only. Does not measure rendered frames or pointer dispatch. */
public final class Reorder66920Checks {
    private static long assertions;
    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for (float density : new float[]{1f, 1.5f, 2.75f, 3f, 4f}) {
            float hero = 360 * density, h = 64 * density;
            float top = 56 * density, bottom = 760 * density;
            check(ReorderMath.trackTop(-100000, h, top, bottom, hero, 1000 * density) == hero,
                "cannot drag into expanded hero");
            check(ReorderMath.trackTop(-100000, h, top, bottom, hero + h, 1100 * density) == hero + h,
                "artist import action is not a track slot");
            check(ReorderMath.trackTop(100000, h, top, bottom, hero, hero + 3*h) == hero + 2*h,
                "short list cannot drag into decorative tail");
            check(ReorderMath.trackTop(-100000, h, top, bottom, Float.NEGATIVE_INFINITY,
                Float.POSITIVE_INFINITY) == top, "off-screen first track uses toolbar boundary");
            check(ReorderMath.trackTop(100000, h, top, bottom, Float.NEGATIVE_INFINITY,
                Float.POSITIVE_INFINITY) == bottom-h, "bottom chrome stays excluded");
            for (int i = 0; i <= 500; i++) {
                float first = hero - i*density;
                float result = ReorderMath.trackTop(-100000, h, top, bottom, first, Float.POSITIVE_INFINITY);
                check(result == Math.max(top, first), "moving hero boundary has no lag/overshoot");
            }
        }
        Random r = new Random(66920);
        for (int n = 0; n < 100000; n++) {
            float low = r.nextFloat()*300, height = 24+r.nextFloat()*250;
            float first = low + r.nextFloat()*300;
            float bottom = first + height + r.nextFloat()*1500;
            float last = first + height + r.nextFloat()*(bottom-first-height);
            float raw = (r.nextFloat()-.5f)*10000;
            float t = ReorderMath.trackTop(raw, height, low, bottom, first, last);
            check(t >= first, "row top never enters header");
            check(t + height <= Math.min(bottom,last)+.001f, "row bottom never enters tail/chrome");
            check(Math.abs(t-ReorderMath.trackTop(t+height/2, height, low,bottom,first,last)) < .001f,
                "clamp is idempotent, no accumulated pixel drift");
            check(ReorderMath.trackTop(raw+1,height,low,bottom,first,last) >= t,
                "monotone response to finger movement");
        }
        check(!ReorderMath.animatePlacement(false, false), "ordinary header resize is not a reorder");
        check(!ReorderMath.animatePlacement(false, true), "stale lifted flag cannot animate scrolling");
        check(!ReorderMath.animatePlacement(true, true), "finger owns lifted row, not spring");
        check(ReorderMath.animatePlacement(true, false), "neighbours animate during reorder/landing");
        System.out.println("PASS: " + assertions + " v6.69.20 production geometry assertions (not Android rendering)");
    }
}
