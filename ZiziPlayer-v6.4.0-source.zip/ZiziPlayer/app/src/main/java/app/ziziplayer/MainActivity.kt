package app.ziziplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ArtworkPrefetcher
import app.ziziplayer.ui.components.rememberArtSwatches
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziBackdrop
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private var deleteTarget: TrackEntity? = null
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ArtworkCache.attach(this)

        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { vm.addFolder(it) }
        }
        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = deleteTarget
            deleteTarget = null
            if (result.resultCode == RESULT_OK && target != null) vm.onFileDeleted(target)
        }
        val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) vm.rescan()
        }
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        }

        setContent {
            ZiziApp(
                vm = vm,
                onPickFolder = { folderLauncher.launch(null) },
                onShare = ::shareTrack,
                onDeleteFile = ::deleteTrackFile,
                onExit = { finish() }
            )
        }
    }

    /** No position polling and no artwork work at all while the UI is off screen. */
    override fun onStart() {
        super.onStart()
        vm.setUiActive(true)
        // The composition survives backgrounding, so cover indexing has to be woken up by hand.
        ArtworkPrefetcher.resume()
    }

    override fun onStop() {
        vm.setUiActive(false)
        vm.savePosition()
        // Nothing may keep parsing audio files once the UI is gone.
        ArtworkPrefetcher.stop()
        ArtworkCache.flushIndex()
        super.onStop()
    }

    private fun shareTrack(track: TrackEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(track.uri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, track.title)) }
    }

    private fun deleteTrackFile(track: TrackEntity) {
        vm.requestDeleteFile(track) { sender ->
            if (sender == null) return@requestDeleteFile
            deleteTarget = track
            runCatching { deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
        }
    }
}

@Composable
private fun ZiziApp(
    vm: MainViewModel,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit,
    onExit: () -> Unit
) {
    val library by vm.library.collectAsStateWithLifecycle()
    val playback by vm.playback.collectAsStateWithLifecycle()
    val current by vm.currentTrack.collectAsStateWithLifecycle()

    // Three cover shades drive the whole app: one hue, one chroma level, one brightness. They
    // only change when the track changes.
    val swatches = rememberArtSwatches(current, library.settings.accentFromArtwork)
    val palette = remember(library.settings.theme, swatches) {
        basePalette(library.settings.theme).tintedWith(swatches).withAccent(swatches)
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(vm) {
        vm.messages.collect { message ->
            val result = snackbar.showSnackbar(
                message = message.text,
                actionLabel = message.actionLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) message.action?.invoke()
        }
    }

    CompositionLocalProvider(LocalPalette provides palette) {
        ZiziTheme(palette) {
            var playerOpen by remember { mutableStateOf(false) }
            var screenHeight by remember { mutableFloatStateOf(0f) }
            val slide = remember { Animatable(0f) }
            var mounted by remember { mutableStateOf(false) }
            // Read inside the draw phase only, so toggling it costs no recomposition.
            val libraryDrawn = remember { mutableStateOf(true) }

            LaunchedEffect(playerOpen, screenHeight) {
                if (screenHeight <= 0f) return@LaunchedEffect
                if (playerOpen) {
                    if (!mounted) { slide.snapTo(screenHeight); mounted = true }
                    libraryDrawn.value = true
                    slide.animateTo(0f, spring(dampingRatio = 0.88f, stiffness = Spring.StiffnessMediumLow))
                    // Fully covered: stop drawing the library underneath.
                    if (slide.value == 0f) libraryDrawn.value = false
                } else if (mounted) {
                    libraryDrawn.value = true
                    slide.animateTo(screenHeight, tween(210, easing = FastOutLinearInEasing))
                    mounted = false
                }
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { screenHeight = it.height.toFloat() }
            ) {
                // The glow is now a hint, not the effect. In 6.3 the ramp was flat and the radial
                // wash was doing all the work, which is why it had to be strong enough to be
                // obvious - and obvious radial washes are what made warm covers look blown out.
                // The crest at y = 0.20 carries the cover colour; this just softens its edge.
                ZiziBackdrop(palette, glowAlpha = 0.05f, glowCenter = 0.20f)

                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent { if (libraryDrawn.value) drawContent() }
                ) {
                    LibraryScreen(
                        vm = vm,
                        state = library,
                        playback = playback,
                        currentTrack = current,
                        onOpenPlayer = { playerOpen = true },
                        onPickFolder = onPickFolder,
                        onShare = onShare,
                        onDeleteFile = onDeleteFile
                    )
                }

                if (mounted) {
                    val dragState = rememberDraggableState { delta ->
                        scope.launch { slide.snapTo((slide.value + delta).coerceIn(0f, screenHeight)) }
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer { translationY = slide.value }
                            .draggable(
                                state = dragState,
                                orientation = Orientation.Vertical,
                                onDragStarted = { libraryDrawn.value = true },
                                onDragStopped = { velocity ->
                                    val shouldClose = slide.value > screenHeight * 0.16f || velocity > 1400f
                                    if (shouldClose) playerOpen = false
                                    else {
                                        slide.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium))
                                        if (slide.value == 0f) libraryDrawn.value = false
                                    }
                                }
                            )
                    ) {
                        ZiziBackdrop(palette, glowAlpha = 0.11f, glowCenter = 0.22f)
                        PlayerScreen(
                            vm = vm,
                            state = library,
                            playback = playback,
                            currentTrack = current,
                            onClose = { playerOpen = false },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    }
                }

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 84.dp)
                )
            }

            // Single back path: player -> drill-down -> app exit. The system side swipe follows it too.
            BackHandler(enabled = true) {
                when {
                    playerOpen -> playerOpen = false
                    vm.handleBack() -> Unit
                    else -> onExit()
                }
            }
        }
    }
}
