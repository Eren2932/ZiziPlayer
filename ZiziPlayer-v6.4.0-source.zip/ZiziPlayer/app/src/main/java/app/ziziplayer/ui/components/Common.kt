package app.ziziplayer.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import android.util.LruCache
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit

/**
 * Custom seek bar. The stock Material slider fires a seek on every pixel of movement,
 * which is what made the play icon flicker; this one only reports the final value.
 */
@Composable
fun ZiziSlider(
    fraction: Float,
    accent: Color,
    inactive: Color,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var local by remember { mutableFloatStateOf(fraction) }
    var scrubbing by remember { mutableStateOf(false) }
    val shown = (if (scrubbing) local else fraction).coerceIn(0f, 1f)
    val density = LocalDensity.current

    Box(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            // ONE gesture detector.
            //
            // v4 attached a tap detector AND a horizontal drag detector to the same box. A short
            // finger movement satisfied both, so two different seeks were dispatched for a single
            // gesture - that is exactly the twitching when nudging the thumb a little. On top of
            // that the tap path used an absolute position while the drag path accumulated relative
            // deltas, so the two disagreed about where the finger actually was.
            //
            // Now a press, a drag and a tap are the same code path, always absolute, one seek.
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scrubbing = true
                    local = (down.position.x / widthPx).coerceIn(0f, 1f)
                    onScrubStart()
                    onScrub(local)
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val next = (change.position.x / widthPx).coerceIn(0f, 1f)
                        if (next != local) { local = next; onScrub(next) }
                        change.consume()
                    }
                    scrubbing = false
                    onScrubEnd(local)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            val trackHeight = with(density) { 5.dp.toPx() }
            val radius = trackHeight / 2f
            val centerY = size.height / 2f
            drawRoundRect(
                color = inactive,
                topLeft = Offset(0f, centerY - radius),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(radius, radius)
            )
            val filled = size.width * shown
            if (filled > 0.5f) {
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(0f, centerY - radius),
                    size = Size(filled, trackHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
            val thumb = with(density) { (if (scrubbing) 9.dp else 7.dp).toPx() }
            // coerceIn throws when min > max, which happens the moment the bar is laid out
            // narrower than the thumb (a very small window, a 0 px first frame). A crash inside
            // the draw phase takes the whole screen down, so the bounds are ordered explicitly.
            val minX = thumb.coerceAtMost(size.width / 2f)
            val maxX = (size.width - thumb).coerceAtLeast(minX)
            drawCircle(color = accent, radius = thumb, center = Offset(filled.coerceIn(minX, maxX), centerY))
        }
    }
}

@Composable
fun PillChip(
    label: String,
    icon: ImageVector?,
    active: Boolean,
    palette: ChipColors,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val background = if (active) palette.activeBackground else palette.background
    val content = if (active) palette.activeContent else palette.content
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(19.dp))
            Box(Modifier.width(9.dp))
        }
        Text(label, color = content, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

data class ChipColors(
    val background: Color,
    val content: Color,
    val activeBackground: Color,
    val activeContent: Color
)

/** Little animated equaliser shown on the row that is currently playing. */
@Composable
fun EqualizerBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    // v3 read the animated values during composition, so this tiny widget recomposed 60 times a
    // second - and it never stopped, even on pause. Now the values are read inside the draw
    // lambda (draw-phase only) and the animation exists exclusively while something is playing.
    if (!playing) {
        Canvas(modifier) { drawEqualizerBars(color, 0.35f, 0.6f, 0.4f) }
        return
    }
    val transition = rememberInfiniteTransition(label = "eq")
    val a = transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "a")
    val b = transition.animateFloat(1f, 0.45f, infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "b")
    val c = transition.animateFloat(0.55f, 0.95f, infiniteRepeatable(tween(430), RepeatMode.Reverse), label = "c")
    Canvas(modifier) { drawEqualizerBars(color, a.value, b.value, c.value) }
}

private fun DrawScope.drawEqualizerBars(color: Color, first: Float, second: Float, third: Float) {
    // listOf(...) here allocated a list plus three boxed Floats on EVERY frame of the animation,
    // for every visible playing row. Sixty times a second, straight into the young generation.
    val barWidth = size.width / 5f
    val radius = CornerRadius(barWidth / 2f, barWidth / 2f)
    bar(color, 0f, first, barWidth, radius)
    bar(color, barWidth * 2f, second, barWidth, radius)
    bar(color, barWidth * 4f, third, barWidth, radius)
}

private fun DrawScope.bar(color: Color, x: Float, value: Float, width: Float, radius: CornerRadius) {
    val height = size.height * value
    drawRoundRect(
        color = color,
        topLeft = Offset(x, size.height - height),
        size = Size(width, height),
        cornerRadius = radius
    )
}

/**
 * Round icon button (v6.2).
 *
 * Three things were wrong before:
 *   - `RoundedCornerShape(percent = 50)` is only a circle when the box is square, and the ripple was
 *     clipped to it, so shuffle / repeat read as rounded SQUARES on press. Now: [CircleShape] plus an
 *     unbounded ripple that overshoots the bounds slightly, the way every system player does it.
 *   - there was no active state, so "shuffle on" was a tint change of a couple of percent contrast.
 *     [active] paints a soft circular wash behind the glyph.
 *   - repeat-one was distinguishable only by the tiny "1" inside the glyph. [activeDot] adds the
 *     indicator dot underneath.
 *
 * [active] and [activeDot] are trailing defaults, so every existing call site is untouched.
 */
@Composable
fun RoundIconButton(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: Int = 52,
    iconSize: Int = 24,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    activeDot: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(
                interactionSource = interaction,
                indication = ripple(bounded = false, radius = (size / 2 + 4).dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        if (active) {
            Box(
                Modifier
                    .matchParentSize()
                    .padding((size * 0.10f).dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.16f))
            )
        }
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize.dp))
        if (activeDot) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = (size * 0.13f).dp)
                    .size(3.5.dp)
                    .clip(CircleShape)
                    .background(tint)
            )
        }
    }
}

/**
 * Titles in a real library are 60 % metadata: "0_0 Slowed + Reverb", "pursuit (super slowed)",
 * "AUTOMOTIVO DO MAL V1 (Super Slowed)". The reference player renders that trailing modifier in a
 * dimmer colour, which is what makes a screen of long titles scannable instead of a wall of bold.
 *
 * The split point is cached by title string, so scrolling 3000 rows runs the regex once per unique
 * title for the whole session, never once per frame.
 */
private val DIM_TAIL = Regex(
    """[\s\-–—|(\[]*\b((?:super|ultra|mega)\s+)?(slowed|slow(?:ed)?\s*[&+]\s*reverb|sped\s*up|speed\s*up|nightcore|reverb|remix|bass\s*boosted?|extended\s*mix|instrumental|mashup|8d\s*audio|lo-?fi)\b.*$""",
    RegexOption.IGNORE_CASE
)

private val dimTailCache = LruCache<String, Int>(2048)

fun dimTailStart(title: String): Int {
    dimTailCache.get(title)?.let { return it }
    val at = DIM_TAIL.find(title)?.range?.first?.takeIf { it >= 3 } ?: -1
    dimTailCache.put(title, at)
    return at
}

@Composable
fun TrackTitle(
    title: String,
    color: Color,
    dim: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier
) {
    val split = remember(title) { dimTailStart(title) }
    if (split < 0) {
        Text(
            text = title,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    } else {
        val annotated = remember(title, color, dim) {
            buildAnnotatedString {
                withStyle(SpanStyle(color = color)) { append(title.substring(0, split)) }
                withStyle(SpanStyle(color = dim)) { append(title.substring(split)) }
            }
        }
        Text(
            text = annotated,
            fontSize = fontSize,
            fontWeight = fontWeight,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
