package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import okhttp3.Request
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/**
 * Parallel-group coordinator: LRCLIB and ZiziLyrics server run simultaneously; OVH follows
 * sequentially only if both miss. These tests verify the 6.64.0-lyrics-timing fix:
 * a synced LRCLIB result must not be delayed by the server's budget.
 */
class LyricsHybridParallelTest {
    private val track = TrackEntity(id = "test", uri = "", title = "Synthetic",
        artist = "Test Artist", durationMs = 100_000L)

    private fun plain(source: String = "test") = JSONObject()
        .put("source", source).put("plainLyrics", "synthetic line one\nsynthetic line two")
        .put("matchVerified", true)
    private fun synced(source: String = "test") = plain(source)
        .put("syncedLyrics", "[00:01.000]synthetic\n[00:02.000]next")

    private fun p(name: String, budget: Long = 1_000L, run: suspend () -> JSONObject?) =
        object : LyricsProvider {
            override val id = name
            override val budgetMs = budget
            override suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
                trace: LyricsLookupTrace?) = run()
        }

    /** Two parallel providers + optional sequential tail. */
    private fun parallel2(a: LyricsProvider, b: LyricsProvider,
        tail: LyricsProvider? = null): LyricsHybridLookup {
        val list = if (tail != null) listOf(a, b, tail) else listOf(a, b)
        return LyricsHybridLookup(list, { 0L }, upgradePlain = true, parallelCount = 2)
    }

    // ── Core timing fix ───────────────────────────────────────────────────────────────

    @Test fun lrclibSyncedWinsImmediately() = runBlocking {
        // LRCLIB (first in list) returns synced → returned without waiting for server.
        val lrcSynced = synced("LRCLIB")
        var progressCalled = false
        val result = parallel2(p("LRCLIB") { lrcSynced }, p("ZiziLyrics") { plain("ZiziLyrics") })
            .lookup(track, { _, _ -> error("no HTTP") }, null) { progressCalled = true }
        assertTrue(result.optString("syncedLyrics").isNotBlank())
        // Synced must not go through the onProgress pathway.
        assertFalse("Plain must not be published when synced found in parallel", progressCalled)
    }

    @Test fun serverPlainWithLrclibMissReturnsServerPlain() = runBlocking {
        // ZiziLyrics (second in parallel list) returns plain; LRCLIB misses.
        val serverPlain = plain("ZiziLyrics")
        val result = parallel2(p("LRCLIB") { null }, p("ZiziLyrics") { serverPlain })
            .lookup(track, { _, _ -> error("no HTTP") }, null)
        assertEquals("ZiziLyrics", result.getString("source"))
        assertTrue(result.optString("plainLyrics").isNotBlank())
    }

    @Test fun serverSyncedWinsWhenLrclibMisses() = runBlocking {
        val serverSynced = synced("ZiziLyrics")
        val result = parallel2(p("LRCLIB") { null }, p("ZiziLyrics") { serverSynced })
            .lookup(track, { _, _ -> error("no HTTP") }, null)
        assertTrue(result.optString("syncedLyrics").isNotBlank())
        assertEquals("ZiziLyrics", result.getString("source"))
    }

    // ── Sequential tail ───────────────────────────────────────────────────────────────

    @Test fun bothParallelMissTriggersSequentialTail() = runBlocking {
        var tailCalled = false
        val ovh = p("ovh") { tailCalled = true; plain("ovh").put("matchVerified", false) }
        parallel2(p("LRCLIB") { null }, p("ZiziLyrics") { null }, tail = ovh)
            .lookup(track, { _, _ -> error("no HTTP") }, null)
        assertTrue("OVH must run when both parallel providers miss", tailCalled)
    }

    @Test fun parallelPlainUpgradedBySyncFromSequentialTail() = runBlocking {
        val serverPlain = plain("ZiziLyrics")
        val tailSynced = synced("ovh-synced")
        var progressCalledWith: String? = null
        val result = parallel2(
            p("LRCLIB") { null },
            p("ZiziLyrics") { serverPlain },
            tail = p("ovh-synced") { tailSynced }
        ).lookup(track, { _, _ -> error("no HTTP") }, null) {
            progressCalledWith = it.optString("source")
        }
        // Plain shown from parallel phase, then synced from tail returned.
        assertEquals("ZiziLyrics", progressCalledWith)
        assertTrue(result.optString("syncedLyrics").isNotBlank())
    }

    @Test fun tailNotCalledWhenParallelHasSynced() = runBlocking {
        var tailCalled = false
        parallel2(p("LRCLIB") { synced("LRCLIB") }, p("ZiziLyrics") { null },
            tail = p("tail") { tailCalled = true; plain("tail") })
            .lookup(track, { _, _ -> error("no HTTP") }, null)
        assertFalse("Tail must not run when parallel group already has synced result", tailCalled)
    }

    // ── Cancellation and error propagation ────────────────────────────────────────────

    @Test fun audioBusyFromParallelStopsEverything() = runBlocking {
        var tailCalled = false
        val lookup = parallel2(
            p("primary") { throw LyricsRepository.AudioBusy() },
            p("secondary") { plain() },
            tail = p("tail") { tailCalled = true; plain() }
        )
        try {
            lookup.lookup(track, { _, _ -> "" }, null)
            fail("AudioBusy must propagate out of the parallel group")
        } catch (e: LyricsRepository.AudioBusy) { /* expected */ }
        assertFalse("Sequential tail must not start after AudioBusy", tailCalled)
    }

    @Test fun cancellationFromParallelPropagates() = runBlocking {
        var tailCalled = false
        val lookup = parallel2(
            p("primary") { throw CancellationException("track changed") },
            p("secondary") { plain() },
            tail = p("tail") { tailCalled = true; plain() }
        )
        try {
            lookup.lookup(track, { _, _ -> "" }, null)
            fail("CancellationException must propagate")
        } catch (_: CancellationException) { /* expected */ }
        assertFalse(tailCalled)
    }

    @Test fun parallelErrorPlusParallelMissProducesError() = runBlocking {
        val lookup = parallel2(
            p("primary") { throw IOException("upstream offline") },
            p("secondary") { null }
        )
        try {
            lookup.lookup(track, { _, _ -> "" }, null)
            fail("Outage is not a miss; must not produce NoLyrics")
        } catch (e: IOException) {
            assertFalse("Outage + miss must not become NoLyrics", e is LyricsRepository.NoLyrics)
        }
    }

    @Test fun bothParallelMissDegradesToNoLyrics() = runBlocking {
        val lookup = parallel2(p("LRCLIB") { null }, p("ZiziLyrics") { null })
        try {
            lookup.lookup(track, { _, _ -> "" }, null)
            fail()
        } catch (e: IOException) {
            assertTrue(e is LyricsRepository.NoLyrics)
        }
    }

    // ── Budget constraint with parallel-max semantics ─────────────────────────────────

    @Test fun budgetConstraintUsesParallelMax() {
        // max(26000, 6000) + 8000 = 34000: accepted.
        LyricsHybridLookup(
            listOf(p("LRCLIB", 26_000L) { null }, p("ZiziLyrics", 6_000L) { null },
                p("ovh", 8_000L) { null }),
            { 0L }, true, parallelCount = 2
        )
        // max(26000, 6000) + 9000 = 35000: rejected.
        try {
            LyricsHybridLookup(
                listOf(p("LRCLIB", 26_000L) { null }, p("ZiziLyrics", 6_000L) { null },
                    p("ovh", 9_000L) { null }),
                { 0L }, true, parallelCount = 2
            )
            fail("Over-budget config must be rejected")
        } catch (_: IllegalArgumentException) {}
    }

    @Test fun parallelCountMustNotExceedProviderListSize() {
        try {
            LyricsHybridLookup(listOf(p("only") { null }), { 0L }, parallelCount = 2)
            fail()
        } catch (_: IllegalArgumentException) {}
    }
}
