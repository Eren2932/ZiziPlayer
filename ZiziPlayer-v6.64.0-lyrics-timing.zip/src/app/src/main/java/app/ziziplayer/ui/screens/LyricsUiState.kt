package app.ziziplayer.ui.screens

import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.lyrics.LyricsLookupTrace
import app.ziziplayer.lyrics.LyricsRepository
import app.ziziplayer.ui.MainViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** One owner in the ViewModel: opening/closing a screen never restarts a request. */
@Stable
internal class LyricsUiState(val track: TrackEntity? = null) {
    var document by mutableStateOf<LyricsDocument?>(null)
    var diagnostic by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var advanceMs by mutableLongStateOf(0L)
        private set
    fun seed(previous: LyricsUiState) {
        document = previous.document
        advanceMs = previous.advanceMs
    }
    private data class Request(val revision: Int = 0, val uri: Uri? = null)
    private val requests = MutableStateFlow(Request())
    private var offsetWrite: Job? = null
    private var persistAdvance: ((Long) -> Unit)? = null
    fun retry() { requests.value = Request(requests.value.revision + 1) }
    fun importFile(uri: Uri) { requests.value = Request(requests.value.revision + 1, uri) }
    fun shift(value: Long) {
        advanceMs = value.coerceIn(-60000L, 60000L)
        persistAdvance?.invoke(advanceMs)
    }
    private suspend fun fetchAutomatically(repository: LyricsRepository, current: TrackEntity, force: Boolean,
        awaitNetworkSlot: suspend () -> Unit, trace: LyricsLookupTrace): LyricsDocument {
        repeat(3) { attempt ->
            trace.add("Attempt ${attempt + 1}; manual=$force")
            try { return repository.fetch(current, force = force && attempt == 0, awaitNetworkSlot = awaitNetworkSlot, trace = trace, onProgress = { document = it }) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                trace.add("Attempt failed: ${e.javaClass.simpleName}")
                val wait = repository.retryDelay(e)
                if (attempt == 2 || wait == null) throw e
                message = if (e is LyricsRepository.AudioBusy) e.message
                    else "Сервис текста недоступен. Повторяем загрузку…"
                delay(wait)
            }
        }
        error("Unreachable lyrics retry state")
    }
    suspend fun observe(repository: LyricsRepository, networkAllowed: Boolean, scope: CoroutineScope,
        awaitNetworkSlot: suspend () -> Unit) {
        val current = track ?: return
        advanceMs = repository.advance(current)
        persistAdvance = { value ->
            val previous = offsetWrite
            offsetWrite = scope.launch { previous?.join(); repository.saveAdvance(current, value) }
        }
        requests.collectLatest { request ->
            busy = true
            message = null
            val trace = LyricsLookupTrace()
            trace.add("ZiziPlayer 6.64.0-lyrics-timing / LRCLIB + lyrics.ovh + optional ZiziLyrics")
            trace.add("Title: ${current.title}")
            trace.add("Artist: ${current.artist}")
            trace.add("Album: ${current.album}")
            trace.add("Lookup durationMs=${current.durationMs}; auto=$networkAllowed")
            try {
                document = if (request.uri != null) repository.importLrc(current, request.uri) else {
                    val cached = if (request.revision == 0) repository.cached(current) else null
                    // Duration refinement often changes the cache key by a few milliseconds.
                    // Keep valid synchronized text without issuing the same provider search again.
                    // Plain-only text is not reused here: resolved timing may upgrade it to LRC.
                    val retained = if (request.revision == 0) document?.takeIf {
                        it.lines.isNotEmpty() && LrcTimeline.durationMatches(current.durationMs, it.durationMs)
                    } else null
                    if (cached != null) trace.add("Cache hit: ${cached.source}; durationMs=${cached.durationMs}; cues=${cached.lines.size}; instrumental=${cached.instrumental}")
                    if (retained != null) trace.add("Retained synchronized document")
                    cached ?: retained ?: if (networkAllowed) {
                        // Avoid starting HTTP for transient queue items during rapid Next taps.
                        delay(200)
                        // Includes gate waits, fallback calls and retry delays. A provider
                        // outage cannot leave the screen permanently in a loading state.
                        kotlinx.coroutines.withTimeoutOrNull(45_000L) {
                            fetchAutomatically(repository, current, force = request.revision > 0, awaitNetworkSlot = awaitNetworkSlot, trace = trace)
                        } ?: throw java.io.IOException("Поиск текста занял слишком долго. Можно повторить поиск или импортировать LRC")
                    } else {
                        if (request.revision > 0) message = "Автозагрузка отключена в настройках. Доступен импорт LRC."
                        document
                    }
                }
                trace.add("Result: source=${document?.source}; hasText=${document?.hasText}; cues=${document?.lines?.size}")
                if (request.uri != null) shift(0L)
                if (document != null && networkAllowed) message = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = e.message ?: "Не удалось загрузить текст"
                trace.add("Stopped: ${e.javaClass.simpleName}")
            } finally {
                diagnostic = trace.render()
                busy = false
            }
        }
    }
}

@Composable
internal fun rememberLyricsUiState(vm: MainViewModel, track: TrackEntity?): LyricsUiState {
    val owned by vm.lyricsUi.collectAsStateWithLifecycle()
    val empty = remember(track?.id) { LyricsUiState() }
    return if (owned.track?.id == track?.id) owned else empty
}
