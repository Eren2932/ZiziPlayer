package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.HomeCollectionKind
import app.ziziplayer.ui.HomeViewModel
import app.ziziplayer.ui.HomeState
import app.ziziplayer.ui.HomeFeedState
import app.ziziplayer.ui.HomeFeedPolicy
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
internal fun HomeScreen(
    home: HomeViewModel,
    vm: MainViewModel,
    playback: PlaybackState,
    favoriteIds: Set<String>,
    onPlay: (TrackEntity, List<TrackEntity>) -> Unit,
    onPlaylist: (Long) -> Unit,
    onFavorites: () -> Unit,
    onLibrary: () -> Unit,
    onArtist: (String) -> Unit,
    account: app.ziziplayer.account.AccountLocalState,
    profile: app.ziziplayer.account.AccountProfile,
    onOpenAccount: () -> Unit
) {
    val raw by home.state.collectAsStateWithLifecycle()
    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as ZiziApplication
    val gate by app.repository.vault.state.collectAsStateWithLifecycle()
    // Synchronous privacy boundary; do not render a stale projection for even one frame.
    val hiddenSnapshot by home.hidden.collectAsStateWithLifecycle()
    val hidden = hiddenSnapshot.orEmpty()
    val state = if (hiddenSnapshot != null && raw.vaultFolders == gate.folders && raw.hiddenIds == hidden) raw else HomeState()
    val rawFeed by home.recommendations.state.collectAsStateWithLifecycle()
    val feed = if (rawFeed.folders == gate.folders && rawFeed.hidden == hidden) rawFeed else HomeFeedState()
    val catalogTracks by home.catalogTracks.collectAsStateWithLifecycle()
    val collectionBusy by home.collectionBusy.collectAsStateWithLifecycle()
    val collectionError by home.collectionError.collectAsStateWithLifecycle()
    val hasMore by home.hasMore.collectAsStateWithLifecycle()
    val viewport = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.toFloat()
    val inset = HomeFeedPolicy.inset(viewport).dp
    var feedFilter by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(state.loading, state.vaultFolders, state.hiddenIds) { if (!state.loading) home.refreshFeed() }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(home, lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) home.leaveHome()
            if (event == androidx.lifecycle.Lifecycle.Event.ON_START) home.refreshFeed()
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); home.leaveHome() }
    }
    val allTracks = remember(state.tracks, feed.shelves, catalogTracks, gate.folders, hidden) {
        val extras = if (rawFeed.folders == gate.folders && rawFeed.hidden == hidden) catalogTracks else emptyList()
        (state.tracks + feed.shelves.flatMap { shelf -> shelf.cards.flatMap { it.tracks } } + extras)
            .filter { it.id !in hidden && (it.isRemote || it.sourceFolder !in gate.folders) }.distinctBy { it.id }
    }
    val wave = feed.wave.ifEmpty { state.offline }
    val historyOpen by home.historyOpen.collectAsStateWithLifecycle()
    val openCollection by home.collection.collectAsStateWithLifecycle()
    LaunchedEffect(openCollection, historyOpen) {
        if (openCollection == null && !historyOpen && !state.loading) home.refreshFeed()
    }
    val message by home.message.collectAsStateWithLifecycle()
    val problem by home.storageProblem.collectAsStateWithLifecycle()
    val p = LocalPalette.current
    val bottom = LocalBottomChromeInset.current
    var managePins by rememberSaveable { mutableStateOf(false) }
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    var historyLimit by rememberSaveable { mutableIntStateOf(50) }
    val homeScroll = rememberLazyListState()
    val historyScroll = rememberLazyListState()
    LaunchedEffect(home) { home.entered() }
    var menuTrackId by rememberSaveable { mutableStateOf<String?>(null) }
    var playlistTrackId by rememberSaveable { mutableStateOf<String?>(null) }
    val activeTracks = remember(openCollection, allTracks) {
        val byId = allTracks.associateBy { it.id }
        openCollection?.trackIds?.mapNotNull(byId::get).orEmpty()
    }
    val dateFormat = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    val selection = openCollection?.takeIf { it.kind != HomeCollectionKind.DISCOVERY || (rawFeed.folders == gate.folders && rawFeed.hidden == hidden) }
    if (selection != null) {
        HomeCollectionScreen(selection.kind, activeTracks, playback,
            title = selection.title, sourceId = selection.sourceId,
            loading = collectionBusy, error = collectionError, hasMore = hasMore, onMore = home::loadCollectionPage,
            onBack = { home.back() }, onToggle = vm::playPause,
            onPlay = { track, tracks, source -> home.useTracks(tracks) { ready -> ready.firstOrNull { it.id == track.id }?.let { vm.play(it, ready, source) } } },
            onMenu = { track -> home.useTracks(listOf(track)) { menuTrackId = track.id } })
    } else LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color(0xFF111111)).statusBarsPadding(),
        state = if (historyOpen) historyScroll else homeScroll,
        contentPadding = PaddingValues(start = inset, end = inset, top = if (!account.isGuest && !historyOpen) 0.dp else 12.dp, bottom = bottom + 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (account.isGuest || historyOpen) item("header") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (historyOpen) IconButton(onClick = { home.back() }) {
                    Icon(ZiziIcons.ArrowBack, contentDescription = "На главную", tint = p.text)
                }
                Text(if (historyOpen) "История" else "Главная", color = p.text,
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { if (historyOpen) confirmClear = true else home.openHistory() }) {
                    Text(if (historyOpen) "Очистить" else "История", color = p.text)
                }
            }
        }
        if (!historyOpen) stickyHeader(key = "home-filters") {
            Row(Modifier.fillMaxWidth().background(p.surface), verticalAlignment = Alignment.CenterVertically) {
            if (!account.isGuest) {
                Box(Modifier.size(48.dp).clickable(role = Role.Button, onClickLabel = "Открыть меню аккаунта", onClick = onOpenAccount),
                    contentAlignment = Alignment.CenterStart) {
                    app.ziziplayer.ui.components.AccountAvatar(account.userId.orEmpty(), profileName(account, profile),
                        profile.avatar, (30.7f * accountScale()).dp)
                }
            }
            LazyRow(Modifier.weight(1f).padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Все", "Для тебя", "Без интернета")) { label ->
                    val index = listOf("Все", "Для тебя", "Без интернета").indexOf(label)
                    Text(label, color = if (feedFilter == index) p.bottom else p.text,
                        fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (feedFilter == index) p.brand else p.surface)
                            .semantics { selected = feedFilter == index }.clickable(role = Role.Tab) { feedFilter = index }.padding(horizontal = 16.dp, vertical = 12.dp))
                }
            }
            }
        }
        if (problem != null) item("storage-problem") { Text(problem.orEmpty(), color = p.subtext) }
        if (message != null) item("message") {
            TextButton(onClick = home::dismissMessage) { Text(message.orEmpty(), color = p.text) }
        }
        if (state.loading) item("loading") { Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = p.brand) } }
        else if (historyOpen) {
            item("totals") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface).padding(18.dp)) {
                    Text("${listeningTime(state.listenedMs)} воспроизведения", color = p.text,
                        fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Зачтено: ${state.qualified} · Дослушано: ${state.completed} · Пропущено: ${state.skipped}",
                        color = p.subtext, modifier = Modifier.padding(top = 8.dp))
                    Text("За сохранённую историю: до 180 дней и 10 000 сессий. Старые счётчики сюда не переносятся.",
                        color = p.subtext, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
            if (state.history.isEmpty()) item("empty-history") {
                HomeEmpty("Здесь появится музыка, которую ты действительно включал. Паузы и загрузка не добавляют время.")
            }
            items(state.history.take(historyLimit), key = { it.session.sessionId }) { entry ->
                val session = entry.session
                val outcome = when (session.outcome) {
                    "active" -> "Сессия открыта"
                    "ended" -> if (session.completed) "Дослушано" else "Достигнут конец"
                    "skipped" -> if (session.listenedMs < 10_000) "Ранний пропуск" else "Пропущено"
                    "error" -> "Ошибка воспроизведения"
                    "interrupted" -> "Сессия прервана"
                    "replaced" -> "Заменена очередь"
                    "removed" -> "Убрано из очереди"
                    else -> "Остановлено"
                }
                HomeTrackRow(entry.track, session.title, session.artist,
                    "${dateFormat.format(Date(session.startedAt))} · ${listeningTime(session.listenedMs)} · $outcome" +
                        if (entry.track == null) " · Источник недоступен" else "",
                    enabled = entry.track != null,
                    onClick = { entry.track?.let { onPlay(it, listOf(it)) } })
            }
            if (historyLimit < state.history.size) item("more-history") {
                TextButton(onClick = { historyLimit += 50 }) { Text("Показать ещё", color = p.text) }
            }
        } else {
            item("wave") {
                HomeWaveCard(
                    enabled = wave.isNotEmpty() || playback.queueSourceId == HomeCollectionKind.WAVE.sourceId,
                    playingHere = playback.queueSourceId == HomeCollectionKind.WAVE.sourceId && playback.isPlaying,
                    onOpen = { home.openCollection(HomeCollectionKind.WAVE) },
                    onPlay = {
                        if (playback.queueSourceId == HomeCollectionKind.WAVE.sourceId) vm.playPause()
                        else wave.firstOrNull()?.let { vm.play(it, wave, HomeCollectionKind.WAVE.sourceId) }
                    }
                )
            }
            item("quick-actions") {
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val columns = if (maxWidth < 300.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale > 1.3f) 1 else 2
                    val pinned = state.playlists.filter { it.pinned }
                    val cards = (pinned + state.playlists.filterNot { it.pinned }).take(6)
                    val labels = listOf("Избранное", "Моя музыка") + cards.map { it.playlist.name }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        labels.indices.toList().chunked(columns).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { index ->
                                    Row(Modifier.weight(1f).heightIn(min = 50.dp).clip(RoundedCornerShape(4.dp))
                                        .background(p.surface).clickable(role = Role.Button) {
                                            when (index) { 0 -> onFavorites(); 1 -> onLibrary(); else -> onPlaylist(cards[index - 2].playlist.id) }
                                        }, verticalAlignment = Alignment.CenterVertically) {
                                        if (index > 1) TrackArtwork(cards[index - 2].cover, 160, Modifier.size(50.dp))
                                        else Box(Modifier.size(50.dp).background(p.brand.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                                            Icon(if (index == 0) ZiziIcons.HeartFilled else ZiziIcons.Library, labels[index], tint = p.text)
                                        }
                                        Text(labels[index], color = p.text, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(8.dp))
                                    }
                                }
                                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
            if (state.playlists.isNotEmpty()) item("playlist-heading") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Быстрый доступ", color = p.subtext, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { managePins = true }) { Text("Закрепления", color = p.subtext) }
                }
            }
            if (feedFilter != 2) item("feed-status") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(feed.error ?: if (feed.loading) "Обновляем подборки…" else "Твоя музыка и каталог",
                        color = p.subtext, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(enabled = !feed.loading, onClick = { home.refreshFeed(force = true) }) { Text("Обновить", color = p.subtext) }
                }
            }
            homeFeedShelves(feed.shelves.filter { shelf -> when (feedFilter) {
                1 -> shelf.id !in setOf("catalog-playlists", "catalog-artists", "chart", "offline")
                2 -> shelf.id == "offline"
                else -> true
            } }, onOpen = home::openFeed,
                onPlay = { track, tracks, source -> home.useTracks(tracks) { ready -> ready.firstOrNull { it.id == track.id }?.let { vm.play(it, ready, source) } } },
                onMenu = { track -> home.useTracks(listOf(track)) { menuTrackId = track.id } })
            if (state.recentAdded.isNotEmpty()) {
                item("added-heading") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HomeHeading("Недавно добавлено", Modifier.weight(1f))
                        TextButton(onClick = { home.openCollection(HomeCollectionKind.RECENT_ADDED) }) {
                            Text("Все", color = p.subtext)
                        }
                    }
                }
                item("added-tracks") { Column { state.recentAdded.filter { feedFilter != 2 || it.id in state.availableOfflineIds }.take(3).forEach { track ->
                    // Parent supplies the same edge inset; retain the full-screen row scale.
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        CollectionTrackRow(track, viewport / 1080f, track.id == playback.currentTrackId,
                            selected = false, picking = false,
                            onPlay = { vm.play(track, state.recentAdded.filter { feedFilter != 2 || it.id in state.availableOfflineIds }, HomeCollectionKind.RECENT_ADDED.sourceId) },
                            onSelect = {}, onLongPress = { menuTrackId = track.id }, onMenu = { menuTrackId = track.id }, horizontalInset = 0.dp)
                    }
                } } }
            }

        }
    }
    // Use the application's real sheet/actions; no dead demo menu entries.
    allTracks.firstOrNull { it.id == menuTrackId }?.let { track ->
        CompositionLocalProvider(LocalPalette provides basePalette()) {
        ZiziSheetScaffold(onDismiss = { menuTrackId = null }) {
            val exit = LocalSheetExit.current
            TrackMenuHeader(track, downloaded = track.isRemote && track.id in state.availableOfflineIds, onClose = { exit {} })
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                TrackMenuAction(if (track.id in favoriteIds) ZiziIcons.HeartFilled else ZiziIcons.Heart,
                    if (track.id in favoriteIds) "Убрать из избранного" else "В избранное") { vm.toggleFavorite(track) }
                TrackMenuAction(ZiziIcons.PlayNext, "Играть следующим") { exit { vm.playNext(track) } }
                TrackMenuAction(ZiziIcons.QueueAdd, "Добавить в очередь") { exit { vm.addToQueue(track) } }
                TrackMenuAction(ZiziIcons.Plus, "Добавить в плейлист") { exit { playlistTrackId = track.id } }
                TrackMenuAction(ZiziIcons.Search, "К исполнителю", navigate = true) { exit { onArtist(track.artist) } }
            }
        }
    }
    }
    allTracks.firstOrNull { it.id == playlistTrackId }?.let { track ->
        AlertDialog(onDismissRequest = { playlistTrackId = null }, title = { Text("Добавить в плейлист") },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    item("new") {
                        TextButton(onClick = { vm.createPlaylist(track.title, listOf(track)); playlistTrackId = null }) {
                            Text("Новый плейлист")
                        }
                    }
                    items(state.playlists, key = { it.playlist.id }) { card ->
                        TextButton(onClick = { vm.addToPlaylist(card.playlist.id, track.id); playlistTrackId = null }) {
                            Text(card.playlist.name)
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { playlistTrackId = null }) { Text("Отмена") } })
    }
    if (managePins) AlertDialog(onDismissRequest = { managePins = false }, title = { Text("Под рукой · до 6 плейлистов") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (state.playlists.isEmpty()) item { Text("Сначала создай плейлист в медиатеке.") }
                items(state.playlists, key = { it.playlist.id }) { card ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(card.playlist.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { home.setPinned(card.playlist.id, !card.pinned) }) {
                            Text(if (card.pinned) "Убрать" else "Закрепить")
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { managePins = false }) { Text("Готово") } })
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Очистить историю?") },
        text = { Text("Сессии и их время будут удалены. Музыка, избранное, плейлисты и старые счётчики медиатеки останутся. Текущее слушание начнёт новую сессию.") },
        confirmButton = { TextButton(onClick = { confirmClear = false; home.clearHistory() }) { Text("Очистить") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } })
}

private fun listeningTime(ms: Long): String {
    val seconds = ms.coerceAtLeast(0) / 1000
    return when {
        seconds >= 3600 -> "${seconds / 3600} ч ${seconds % 3600 / 60} мин"
        seconds >= 60 -> "${seconds / 60} мин ${seconds % 60} с"
        else -> "$seconds с"
    }
}

@Composable
private fun HomeHeading(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, color = LocalPalette.current.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
}
@Composable
private fun HomeEmpty(text: String) { Text(text, color = LocalPalette.current.subtext, modifier = Modifier.padding(vertical = 12.dp)) }
@Composable
private fun HomeTrackRow(track: TrackEntity?, title: String, artist: String, detail: String, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).clip(RoundedCornerShape(12.dp))
        .clickable(enabled = enabled, onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TrackArtwork(track, 160, Modifier.size(53.dp).clip(RoundedCornerShape(6.dp)))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(artist, color = p.subtext, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            if (detail.isNotEmpty()) Text(detail, color = p.subtext, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HomeWaveCard(enabled: Boolean, playingHere: Boolean, onOpen: () -> Unit, onPlay: () -> Unit) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxWidth().heightIn(min = 160.dp).clip(RoundedCornerShape(22.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF57331F), Color(0xFF211915))))
        .clickable(role = Role.Button, onClick = onOpen)) {
        WaveArtwork(Modifier.align(Alignment.CenterEnd).width(170.dp).height(160.dp))
        Box(Modifier.matchParentSize().background(Brush.horizontalGradient(
            listOf(Color(0xFF2B201A), Color(0xFF2B201A).copy(alpha = 0.75f), Color.Transparent))))
        Text("Моя волна", color = p.text, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 24.dp, end = 90.dp, bottom = 24.dp))
        IconButton(onClick = onPlay, enabled = enabled || playingHere,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp).size(56.dp).clip(CircleShape)
                .background(if (enabled || playingHere) p.brand else p.chip)) {
            Icon(if (playingHere) ZiziIcons.Pause else ZiziIcons.CollectionPlayFilled,
                if (playingHere) "Пауза" else "Слушать мою волну",
                tint = Color.Black, modifier = Modifier.size(if (playingHere) 26.dp else 56.dp))
        }
    }
}
