package app.ziziplayer.ui.screens

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure navigation tests; executed by :app:testDebugUnitTest in CI, not UI screenshots. */
class AuthPageTest {
    @Test fun entryPagesCloseToCaller() {
        assertNull(AuthPage.LoginEmail.parent)
        assertNull(AuthPage.RegisterEmail.parent)
        assertTrue(AuthPage.LoginEmail.emailEntry)
        assertTrue(AuthPage.RegisterEmail.emailEntry)
        assertFalse(AuthPage.LoginPassword.emailEntry)
    }
    @Test fun passwordBackKeepsTheChosenFlow() {
        assertEquals(AuthPage.LoginEmail, AuthPage.LoginPassword.parent)
        assertEquals(AuthPage.RegisterEmail, AuthPage.RegisterPassword.parent)
    }
    @Test fun recoveryBackIsDeterministic() {
        assertEquals(AuthPage.Forgot, AuthPage.Reset.parent)
        assertEquals(AuthPage.LoginPassword, AuthPage.Forgot.parent)
        assertEquals(AuthPage.LoginEmail, AuthPage.Verify.parent)
    }
    @Test fun everyBackChainTerminates() {
        for (start in AuthPage.entries) {
            var page: AuthPage? = start
            val visited = mutableSetOf<AuthPage>()
            while (page != null) {
                assertTrue("Back cycle at $page", visited.add(page))
                page = page.parent
            }
        }
    }
}
