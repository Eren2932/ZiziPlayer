# Серверное обновление 1.25-quality-rc1 (качество потока `?q=`)

Цель: пункты «Экономное / Обычное / Высокое» в приложении должны играть разные форматы. До 1.25 сервер всегда отдавал один:
самый крупный m4a (itag 140, AAC-LC ~129 кбит/с), параметр качества до него не доезжал.

Клиент: нужен 6.88.0 для эффекта. Старый клиент работает без изменений (нет `q` = `normal` = как раньше).

Статус: серверные тесты зелёные в песочнице на фикстурах (`test_quality_125.py` в комплекте; `smoke_stage2.py` в песочнице
не запускается из-за отсутствия `uvicorn`). **Живой YouTube не гонялся: какие из клиентов `android_vr,tv,web_music` отдают Opus
с вашего VPS, определит только проверка ниже.** Если Opus не находится, «Высокое» играет как «Обычное» и это честно видно в ответе.

## Ступени

| q | Что отдаём | Реально, кбит/с |
|---|---|---|
| `low` | Opus itag 249/250, запасной HE-AAC 139 | ~50-70 |
| `normal` | AAC itag 140 (ровно как до 1.25) | ~129 |
| `high` | Opus itag 251; нет Opus — как `normal` | до ~160 VBR |

Выше YouTube без Premium не отдаёт. Premium-куки не используются (чужой аккаунт, ToS, бан). Если Premium-куки подложат сами,
`high` возьмёт itag 141 (AAC 256): выбор идёт по «эквивалентному AAC-битрейту», а не по названию кодека.

## Что изменено

- `zizi_resolver.py`: `?q=` в `/resolve`, `/stream`, `/prefetch`; один кэш-ключ `videoId`, внутри записи три ступени (второго
  резолва не нужно); «докупка» Opus к уже закэшированной записи (до `ZIZI_HQ_UPGRADE_BUDGET`, 10 с); дисковый кэш и
  закачки разделены по `format_id` (имя `<id>.m4a` для itag 140 прежнее: диск, набранный до 1.25, жив); при обновлении
  ссылки берётся ТОТ ЖЕ формат (байты двух файлов не клеятся); заголовки ответа `x-zizi-quality/codec/format/abr` сообщают реальную ступень.
- `zizi_catalog.py`: только версия 1.25 (прогрев поиска на сервере греет `normal`; Opus добирается при первом `q=high`, либо клиентским `/prefetch?q=high`).
- `/resolve` отдаёт `codec`, `tier`, `abr`, `quality` (клиент показывает их в плеере). `/stats`: `quality_contract: 1`, `hq_clients`, `opus_eff`; `/catalog/health`: версия 1.25-quality-rc1.
- `tools/deploy_server.py`, `server_known.json`, `server_bundle_seal.json`: версия, печать, проверка требует `quality_contract=1` в `/stats`.

## Переменные окружения (все необязательные)

| Переменная | По умолчанию | Смысл |
|---|---|---|
| `ZIZI_HQ_CLIENTS` | `android_vr,tv,web_music` | клиенты yt-dlp, которые пробуются первыми ради Opus; пусто = Opus отключён |
| `ZIZI_HQ_MAX_TRIES` | 2 | сколько клиентов пробовать (каждая проба ~6 с) |
| `ZIZI_HQ_UPGRADE_BUDGET` | 10 | потолок ожидания «докупки» Opus, секунды |
| `ZIZI_OPUS_EFF` | 1.3 | сколько кбит/с AAC-LC стоит 1 кбит/с Opus при выборе ступени |

## Установка

```bash
mkdir -p ~/zizi-1.25 && unzip -o ZiziServer-1.25.zip -d ~/zizi-1.25

# 1. Проверка. Ничего не пишет.
/opt/zizi/venv/bin/python ~/zizi-1.25/server/tools/deploy_server.py --check

# 2. Бэкап базы (WAL: копировать .db на ходу нельзя).
sqlite3 "$ZIZI_CATALOG_DB" ".backup '/opt/zizi/catalog.before-1.25.db'"

# 3. Установка (откат автоматический, если health не сошёлся).
sudo /opt/zizi/venv/bin/python ~/zizi-1.25/server/tools/deploy_server.py --apply

# Ручной откат
sudo /opt/zizi/venv/bin/python ~/zizi-1.25/server/tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>
```

Если `--check` пишет `unknown server edit: <файл> (sha256 …)`: на VPS файл правился руками. Не форсируйте, пришлите sha256 и файл.

## Проверка после установки (обязательна: живого YouTube в песочнице не было)

```bash
H="Authorization: Bearer $T"; B=https://<ваш-хост>; V=dQw4w9WgXcQ   # любой videoId
curl -s -H "$H" $B/catalog/health | jq '{version}'                               # "1.25-quality-rc1"
curl -s -H "$H" $B/stats | jq '{quality_contract, hq_clients, opus_eff}'            # 1, [...], 1.3
for q in low normal high; do
  curl -s -H "$H" "$B/resolve?id=$V&q=$q" | jq -c '{q:"'$q'", tier, codec, abr, mime}'
done
# ожидание: low -> opus ~50-70, normal -> aac ~129, high -> opus ~130-160 (если высокий = aac, Opus не нашёлся)
curl -s -H "$H" $B/stats | jq .quality                                              # q_low/q_normal/q_high, served_opus/served_aac
yt-dlp -F "https://www.youtube.com/watch?v=$V" | grep -E "audio only"              # что у ролика есть на самом деле
journalctl -u <служба> -n 80 | grep -iE 'hq|opus|quality'
```

Если `high` стабильно возвращает `aac`: `yt-dlp -F --extractor-args "youtube:player_client=android_vr" <url>` с VPS покажет,
есть ли там Opus 251; если нет, поменяйте `ZIZI_HQ_CLIENTS`. Полностью отключить Opus без отката: `ZIZI_HQ_CLIENTS=` и рестарт.
