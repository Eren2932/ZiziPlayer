package app.ziziplayer.data.remote

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CompleteCollectionLoaderTest {
    private val target = RemoteCollection("dz", "playlist:1", RemoteKind.PLAYLIST, "Search title")
    private fun track(id: Int) = RemoteTrack("dz", "$id", "Track $id", "Artist")

    @Test fun allPagesAreLoadedAndDuplicatesKeepFirstOrder() = runBlocking {
        val tokens = mutableListOf<String?>()
        val result = loadCompleteCollection(target) { collection, token ->
            assertEquals(target, collection)
            tokens.add(token)
            when (token) {
                null -> CollectionPage(target, listOf(track(1), track(2)), "next", 4)
                else -> CollectionPage(target.copy(title = "Canonical"), listOf(track(2), track(3)), total = 4)
            }
        }
        assertEquals(listOf(null, "next"), tokens)
        assertEquals(listOf(track(1), track(2), track(3)), result.tracks)
        assertEquals("Canonical", result.collection.title)
        assertNull(result.nextToken)
    }

    @Test fun failureOnLaterPageNeverReturnsPartialSuccess() = runBlocking {
        var calls = 0
        try {
            loadCompleteCollection(target) { _, _ ->
                if (++calls == 1) CollectionPage(target, listOf(track(1)), "next")
                else throw CatalogException(CatalogException.Reason.OFFLINE, "offline")
            }
            fail("must not return first page")
        } catch (e: CatalogException) { assertEquals(CatalogException.Reason.OFFLINE, e.reason) }
        assertEquals(2, calls)
    }

    @Test fun knownTruncationIsRejected() = runBlocking {
        try {
            loadCompleteCollection(target) { _, _ -> CollectionPage(target, listOf(track(1)), total = 50) }
            fail("truncated")
        } catch (e: IllegalStateException) { assertTrue(e.message!!.contains("не сохранён")) }
    }

    @Test fun cyclicTokenIsRejected() = runBlocking {
        var calls = 0
        try {
            loadCompleteCollection(target) { _, _ -> CollectionPage(target, listOf(track(++calls)), "same") }
            fail("loop")
        } catch (e: IllegalStateException) { assertEquals(2, calls) }
    }

    @Test fun cancellationIsNotConvertedToSuccess() = runBlocking {
        try {
            loadCompleteCollection(target) { _, _ -> throw CancellationException("cancel") }
            fail("cancelled")
        } catch (e: CancellationException) { assertEquals("cancel", e.message) }
    }

    @Test fun emptyCollectionIsNotSaved() = runBlocking {
        try {
            loadCompleteCollection(target) { _, _ -> CollectionPage(target, emptyList()) }
            fail("empty")
        } catch (e: CatalogException) { assertEquals(CatalogException.Reason.UNAVAILABLE, e.reason) }
    }
}
