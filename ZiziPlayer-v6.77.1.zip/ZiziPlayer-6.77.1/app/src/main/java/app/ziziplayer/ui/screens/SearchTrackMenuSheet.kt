package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.material3.rememberStandardBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.collapse
import androidx.compose.ui.semantics.dismiss
import androidx.compose.ui.semantics.expand
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.SearchMenuGeometry
import app.ziziplayer.ui.SearchResultGeometry
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

internal data class SearchTrackAction(
    val id: String, val label: String, val icon: ImageVector,
    val enabled: Boolean = true, val run: () -> Unit
)

/** One dialog, one fixed set of anchors, and one bounded scrolling viewport.
 * Material owns dragging/nested scroll. The inner viewport is the visible intersection,
 * not the full translated sheet (which extends below the window at the partial anchor).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SearchTrackMenuSheet(
    track: RemoteTrack,
    actions: List<SearchTrackAction>,
    onDismiss: () -> Unit,
    prepareAction: suspend (SearchTrackAction) -> (() -> Unit) = { it.run }
) = NeutralSurfaceTheme {
    val p = LocalPalette.current
    val state = rememberStandardBottomSheetState(initialValue = SheetValue.Hidden, skipHiddenState = false)
    val scaffold = rememberBottomSheetScaffoldState(bottomSheetState = state)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val latestDismiss by rememberUpdatedState(onDismiss)
    val latestPrepare by rememberUpdatedState(prepareAction)
    var appeared by remember { mutableStateOf(false) }
    var exiting by remember { mutableStateOf(false) }
    var dispatched by remember { mutableStateOf(false) }
    var preparingId by remember { mutableStateOf<String?>(null) }
    var preparation by remember { mutableStateOf<Job?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val finish: (() -> Unit) -> Unit = { action ->
        if (!dispatched) { dispatched = true; latestDismiss(); action() }
    }
    val exit: (() -> Unit) -> Unit = { action ->
        if (!exiting && !dispatched) {
            exiting = true
            scope.launch {
                try {
                    state.hide()
                    if (!state.isVisible) finish(action)
                } finally { exiting = false }
            }
        }
    }
    val dismissMenu: () -> Unit = {
        preparation?.cancel()
        preparingId = null
        exit { }
    }
    val select: (SearchTrackAction) -> Unit = { action ->
        if (appeared && action.enabled && preparingId == null && !exiting && !dispatched) {
            preparingId = action.id
            error = null
            preparation = scope.launch {
                try {
                    val run = latestPrepare(action)
                    // Even a non-cooperative callback cannot dispatch after Back/outside-tap.
                    if (!exiting && !dispatched && preparingId == action.id) exit(run)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    error = "Не удалось выполнить действие. Нажмите нужный пункт ещё раз."
                } finally { preparingId = null }
            }
        }
    }
    LaunchedEffect(state) {
        snapshotFlow { state.hasPartiallyExpandedState }.first { it }
        // A restored expanded sheet (rotation) is already visible: do not reopen it.
        if (state.currentValue == SheetValue.Hidden) state.partialExpand()
        appeared = true
    }
    LaunchedEffect(state.currentValue, appeared) {
        if (appeared && state.currentValue == SheetValue.Hidden && !exiting) {
            preparation?.cancel()
            finish { }
        }
    }
    Dialog(onDismissRequest = dismissMenu, properties = DialogProperties(
        usePlatformDefaultWidth = false, decorFitsSystemWindows = false
    )) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            // Only the sheet slides in. Do not also animate the platform dialog window.
            window?.setWindowAnimations(0)
            window?.setDimAmount(0.48f)
        }
        Box(Modifier.fillMaxSize()) {
            // Apply bottom + side insets ONCE, to the real window constraints. This protects
            // gesture/3-button navigation, landscape cutouts and an IME during window resize.
            BoxWithConstraints(Modifier.fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                .testTag("search-track-menu-host")) {
                val density = LocalDensity.current
                val hostHeightPx = with(density) { maxHeight.roundToPx() }
                val safeTop = WindowInsets.safeDrawing.asPaddingValues().calculateTopPadding()
                val top = maxOf(safeTop, maxHeight * SearchResultGeometry.MENU_TOP_FRACTION).coerceAtMost(maxHeight)
                val expandedHeight = (maxHeight - top).coerceAtLeast(0.dp)
                val peek = (maxHeight * SearchResultGeometry.MENU_PEEK_FRACTION).coerceAtMost(expandedHeight)
                val scrollHeader = SearchMenuGeometry.scrollHeader(peek.value, density.fontScale)
                BottomSheetScaffold(
                    scaffoldState = scaffold,
                    sheetPeekHeight = peek,
                    sheetMaxWidth = Dp.Unspecified,
                    containerColor = Color.Transparent,
                    sheetContainerColor = p.surface,
                    sheetContentColor = p.text,
                    sheetShape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                    sheetShadowElevation = 0.dp,
                    sheetTonalElevation = 0.dp,
                    sheetSwipeEnabled = appeared && preparingId == null && !exiting,
                    sheetDragHandle = null,
                    sheetContent = {
                        // This shell NEVER changes size as the sheet moves. Otherwise measuring
                        // the visible viewport would move the anchors and cause a feedback loop.
                        Box(Modifier.fillMaxWidth().height(expandedHeight).testTag("search-track-menu")) {
                            Column(Modifier.fillMaxWidth().layout { measurable, constraints ->
                                val offset = runCatching { state.requireOffset() }.getOrDefault(Float.NaN)
                                val visible = SearchMenuGeometry.visibleHeight(hostHeightPx, constraints.maxHeight, offset)
                                val child = measurable.measure(constraints.copy(minHeight = visible, maxHeight = visible))
                                layout(child.width, constraints.maxHeight) { child.placeRelative(0, 0) }
                            }.clipToBounds().testTag("search-track-menu-viewport")) {
                                Box(Modifier.fillMaxWidth().height(28.dp).testTag("search-track-menu-handle")
                                    .semantics {
                                        if (appeared && preparingId == null && !exiting) {
                                            if (state.currentValue == SheetValue.PartiallyExpanded) {
                                                expand("Раскрыть меню") { scope.launch { state.expand() }; true }
                                            } else {
                                                collapse("Свернуть меню") { scope.launch { state.partialExpand() }; true }
                                            }
                                            dismiss("Закрыть меню") { dismissMenu(); true }
                                        }
                                    }, contentAlignment = Alignment.Center) {
                                    Box(Modifier.size(36.dp, 4.dp).clip(RoundedCornerShape(2.dp))
                                        .background(p.subtext.copy(alpha = 0.45f)))
                                }
                                if (!scrollHeader) SearchMenuHeader(track)
                                LazyColumn(Modifier.fillMaxWidth().weight(1f).testTag("search-track-menu-actions"),
                                    state = listState, contentPadding = PaddingValues(bottom = 16.dp)) {
                                    if (scrollHeader) item("header") { SearchMenuHeader(track) }
                                    if (error != null) item("error") {
                                        Text(error.orEmpty(), color = p.text,
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                                                .testTag("search-track-menu-error").semantics { liveRegion = LiveRegionMode.Polite })
                                    }
                                    items(actions, key = { it.id }) { action ->
                                        Row(Modifier.fillMaxWidth().heightIn(min = SearchResultGeometry.MENU_ROW_DP.dp)
                                            .clickable(enabled = appeared && action.enabled && preparingId == null && !exiting,
                                                role = Role.Button) { select(action) }
                                            .padding(horizontal = 16.5.dp, vertical = 12.dp)
                                            .testTag("search-track-action-${action.id}"), verticalAlignment = Alignment.CenterVertically) {
                                            if (preparingId == action.id) CircularProgressIndicator(
                                                Modifier.size(24.dp), color = p.subtext, strokeWidth = 2.dp)
                                            else Icon(action.icon, contentDescription = null, tint = p.subtext, modifier = Modifier.size(24.dp))
                                            Spacer(Modifier.width(13.dp))
                                            Text(action.label, color = p.text, fontSize = 17.sp,
                                                fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                ) {
                    // Dialog owns the dimming; this is only a hit target, not a second scrim.
                    Box(Modifier.fillMaxSize().testTag("search-track-menu-outside")
                        .clickable(enabled = !exiting, onClickLabel = "Закрыть меню трека", onClick = dismissMenu))
                }
            }
        }
    }
}

@Composable
private fun SearchMenuHeader(track: RemoteTrack) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().testTag("search-track-menu-header")) {
        Row(Modifier.fillMaxWidth().heightIn(min = 72.dp)
            .padding(horizontal = 16.5.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            RemoteArtwork(track.artworkUrl, track.trackId, maxPx = ARTWORK_ROW_PX,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(3.dp)), glyphSize = 20)
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(track.title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = p.subtext, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        HorizontalDivider(color = p.subtext.copy(alpha = 0.18f), thickness = 1.dp)
    }
}
