package app.ziziplayer.ui;

/** Pixel bounds for a translated sheet. Anchors use the fixed outer height; only the
 * inner viewport follows the visible intersection. No screen-size or density guesses. */
public final class SearchMenuGeometry {
    private SearchMenuGeometry() {}

    public static int visibleHeight(int hostHeight, int sheetHeight, float offset) {
        if (hostHeight <= 0 || sheetHeight <= 0 || !Float.isFinite(offset)) return 0;
        // Ceil the top: rounding down can expose one pixel under the window's bottom edge.
        int top = (int) Math.ceil(Math.max(0f, Math.min((float) hostHeight, offset)));
        return Math.min(sheetHeight, Math.max(0, hostHeight - top));
    }

    /** Short windows / large accessibility fonts must not reserve a pinned header. */
    public static boolean scrollHeader(float peekHeightDp, float fontScale) {
        return peekHeightDp < 320f || fontScale >= 1.5f;
    }
}
