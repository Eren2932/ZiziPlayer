package app.ziziplayer.ui

import androidx.compose.ui.graphics.Color
import app.ziziplayer.ui.components.ArtSwatches
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Requires Android Gradle's test classpath. The portable Java suite cannot run Compose types. */
class ArtSwatchesCodecTest {
    @Test fun fourColoursRoundTripWithoutReassigningPrimary() {
        val swatches = ArtSwatches(Color(0xFFBFC733), Color(0xFF30612B), Color(0xFF555A19), Color(0xFF446D2F))
        assertEquals(swatches, ArtSwatches.unpack(swatches.pack()))
    }
    @Test fun oldAndIncompleteVerdictsMustBeRecomputed() {
        for (value in listOf(null, "", "2;-1,-2,-3", "3;-1,-2,-3", "3;-1,-2,-3,bad", "3;-1,-2,-3,-4,-5")) {
            assertNull(ArtSwatches.unpack(value))
        }
    }
    @Test fun syntheticSwatchesDefaultBodyToPrimary() {
        val swatches = ArtSwatches(Color.Red, Color.Blue, Color.Green)
        assertEquals(swatches.primary, swatches.body)
        assertEquals(swatches, ArtSwatches.unpack(swatches.pack()))
    }
}
