package app.ziziplayer.ui;

import app.ziziplayer.ui.theme.ArtworkColorMath;
import app.ziziplayer.ui.theme.ArtworkSurfaceMath;
import app.ziziplayer.ui.theme.ArtworkSurfaceSampler;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Random;

/** Production execution. Screenshot crops are evidence, not Android-rendered screenshots. */
public final class ArtworkContextMathChecks {
    private static final float[] POS = {0f, .10f, .28f, .46f, .64f, .82f, 1f};
    private static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    private static int c(int rgb, int shift) { return (rgb >>> shift) & 255; }
    private static void near(int a, int b, int tolerance, String why) {
        for (int shift : new int[]{16, 8, 0}) check(Math.abs(c(a, shift) - c(b, shift)) <= tolerance,
                why + " actual=" + Integer.toHexString(a) + " expected=" + Integer.toHexString(b));
    }
    private static double contrast(int a, int b) {
        double x = ArtworkColorMath.luminance(a), y = ArtworkColorMath.luminance(b);
        return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
    }
    private static int[] fill(int color) { int[] pixels = new int[4096]; Arrays.fill(pixels, color); return pixels; }
    private static void roles(int primary, int deep, int body) {
        int[] ramp = ArtworkSurfaceMath.playerBackdrop(primary, deep, body);
        check(Arrays.equals(ramp, ArtworkSurfaceMath.playerBackdrop(primary, deep, body)), "Determinism");
        check(ramp[6] == 0xff111111, "Neutral endpoint");
        check(ArtworkColorMath.luminance(ramp[0]) >= .0119, "Invisible top");
        double previous = ArtworkColorMath.luminance(ramp[0]);
        for (int i = 0; i < 6; i++) for (int step = 0; step <= 32; step++) {
            float t = step / 32f;
            int sample = ArtworkColorMath.mix(ramp[i], ramp[i+1], t);
            int direct = ArtworkColorMath.mix(ramp[0], ramp[6], POS[i] + (POS[i+1] - POS[i]) * t);
            near(sample, direct, 1, "Unexpected gradient hump");
            double y = ArtworkColorMath.luminance(sample);
            check(y <= previous + .0008, "Non-monotone beyond rounding"); previous = y;
            check(contrast(ArtworkSurfaceMath.PLAYER_HEADER_INK, sample) >= 4.5, "Header contrast");
            check((sample >>> 24) == 255, "Player transparency");
        }
        for (int sample : new int[]{ArtworkSurfaceMath.miniPlayer(primary, deep, body),
                ArtworkSurfaceMath.collectionTop(primary, body), ArtworkSurfaceMath.chip(primary, deep, body)}) {
            check((sample >>> 24) == 255, "Surface transparency");
            check(contrast(ArtworkSurfaceMath.SECONDARY_INK, sample) >= 4.5, "Surface contrast");
        }
    }
    public static void runAll() {
        int grid = 0;
        for (int r = 0; r < 256; r += 17) for (int g = 0; g < 256; g += 17) for (int b = 0; b < 256; b += 17) {
            int rgb = 0xff000000 | r << 16 | g << 8 | b;
            int deep = ArtworkColorMath.mix(0xff000000, rgb, .4f);
            for (int body : new int[]{rgb, deep, 0xff000000 | b << 16 | r << 8 | g}) { roles(rgb, deep, body); grid++; }
        }
        for (int v = 0; v < 256; v++) {
            int grey = 0xff000000 | v << 16 | v << 8 | v;
            for (int rgb : new int[]{ArtworkSurfaceMath.playerTop(grey, 0xff0011bb, 0xff226622),
                    ArtworkSurfaceMath.miniPlayer(grey, 0xff550011, 0xff882200), ArtworkSurfaceMath.collectionTop(grey, 0xff002299)})
                check(c(rgb, 16) == c(rgb, 8) && c(rgb, 8) == c(rgb, 0), "Invented neutral hue");
        }
        for (int input : new int[]{0xffff0000, 0xffffff00, 0xff22dd55, 0xff2277dd, 0xff8866bb, 0xff888888})
            near(ArtworkSurfaceSampler.body(fill(input), input), input, 1, "Uniform sample hue changed");
        int[] logo = fill(0xffdddd33); Arrays.fill(logo, 0, 40, 0xff338833);
        near(ArtworkSurfaceSampler.body(logo, 0xffdddd33), 0xffdddd33, 1, "Tiny logo supplied the body");
        int[] transparent = fill(0x00ff0000); Arrays.fill(transparent, 0, 2000, 0xff228888);
        near(ArtworkSurfaceSampler.body(transparent, 0xff228888), 0xff228888, 1, "Hidden alpha RGB voted");
        check(ArtworkSurfaceSampler.body(fill(0x8000ff00), 0xff444444) == 0xff444444, "Alpha fallback");
        check(ArtworkSurfaceSampler.body(null, 0xff445566) == 0xff445566, "Null fallback");
        check(ArtworkSurfaceSampler.body(new int[0], 0xff445566) == 0xff445566, "Empty fallback");
        boolean rejected = false;
        try { ArtworkSurfaceSampler.body(new int[4097], 0xff444444); } catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "Unbounded sample accepted");
        int bright = 0xffeecc11, deep = 0xff665522;
        check(ArtworkSurfaceMath.miniPlayer(bright, deep, 0xff112288) == ArtworkSurfaceMath.miniPlayer(bright, deep, bright), "Rival blue body voted");
        Random random = new Random(6740);
        for (int n = 0; n < 64; n++) {
            int[] pixels = new int[4096]; for (int i = 0; i < pixels.length; i++) pixels[i] = random.nextInt();
            int[] saved = pixels.clone(); int body = ArtworkSurfaceSampler.body(pixels, 0xff444444);
            check(body == ArtworkSurfaceSampler.body(pixels, 0xff444444), "Random body nondeterminism");
            check(Arrays.equals(saved, pixels), "Shared pixels mutated");
        }
        // Hold a nontrivial body fixed while one primary channel changes across every gate.
        for (int v = 40; v <= 240; v += 20) for (int n = 0; n < 255; n++) {
            int a = 0xff000000 | v << 16 | n << 8 | 65;
            near(ArtworkSurfaceMath.miniPlayer(a, a, 0xff486e32),
                    ArtworkSurfaceMath.miniPlayer(a + 256, a + 256, 0xff486e32), 8, "Context continuity");
        }
        System.out.println("PASS context invariants: " + grid + " role contexts, " + (grid * 198)
                + " interpolated ramp samples; 256 neutrals; 64 random samples; bounds, alpha, continuity.");
    }
    private static void fixtures(Path folder) throws Exception {
        int count = 0;
        try (var paths = Files.list(folder)) {
            for (Path p : paths.filter(f -> f.toString().endsWith(".argb")).sorted().toList()) {
                byte[] raw = Files.readAllBytes(p); int[] pixels = new int[raw.length / 4];
                ByteBuffer.wrap(raw).asIntBuffer().get(pixels);
                int[] sw = ArtworkColorMath.extract(pixels);
                int body = ArtworkSurfaceSampler.body(pixels, sw[0]);
                int top = ArtworkSurfaceMath.playerTop(sw[0], sw[2], body);
                int mini = ArtworkSurfaceMath.miniPlayer(sw[0], sw[2], body);
                int collection = ArtworkSurfaceMath.collectionTop(sw[0], body);
                String name = p.getFileName().toString();
                if (name.startsWith("PASSO_GREEN")) {
                    near(mini, 0xff1c2b14, 7, name + " green capsule");
                    near(collection, 0xff355226, 9, name + " green header");
                    check(c(mini, 8) > c(mini, 16) * 1.25, "Still olive/yellow");
                    check(ArtworkColorMath.luminance(mini) < .035, "Still too luminous");
                } else if (name.startsWith("MANDALA")) {
                    near(top, 0xff606aa5, 12, name + " muted player");
                    near(mini, 0xff444d78, 10, name + " muted capsule");
                    // Reference at 64% of the content-height is #2D3246, not a blue plateau.
                    near(ArtworkSurfaceMath.playerBackdrop(sw[0], sw[2], body)[4], 0xff2d3246, 7, name + " gradient tail");
                }
                roles(sw[0], sw[2], body);
                System.out.printf("FIXTURE,%s,%08X,%08X,%08X,%08X,%08X%n", name, sw[0], body, top, mini, collection);
                count++;
            }
        }
        check(count == 16, "Fixture coverage changed: " + count);
        Path old = folder.resolveSibling("surfaces-6730");
        String[] names = {"RAYA", "RAYA_REF", "PASSO", "PASSO_REF", "ABNORMAL", "ABNORMAL_REF"};
        int[] expected = {0xff380504, 0xff380504, 0xff14646f, 0xff14646f, 0xff292929, 0xff292929};
        for (int i = 0; i < names.length; i++) {
            byte[] raw = Files.readAllBytes(old.resolve(names[i] + ".argb")); int[] pixels = new int[4096];
            ByteBuffer.wrap(raw).asIntBuffer().get(pixels); int[] sw = ArtworkColorMath.extract(pixels);
            int body = ArtworkSurfaceSampler.body(pixels, sw[0]);
            near(ArtworkSurfaceMath.miniPlayer(sw[0], sw[2], body), expected[i], 7, "Existing capsule " + names[i]);
        }
        System.out.println("PASS: 16 new crop/size fixtures and 6 existing reference capsule tolerances.");
    }
    public static void main(String[] args) throws Exception { runAll(); if (args.length > 0) fixtures(Path.of(args[0])); }
}
