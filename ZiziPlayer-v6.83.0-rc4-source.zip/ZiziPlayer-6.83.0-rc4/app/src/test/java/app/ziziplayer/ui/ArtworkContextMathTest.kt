package app.ziziplayer.ui

import org.junit.Test

class ArtworkContextMathTest {
    @Test fun contextualSurfaceInvariants() = ArtworkContextMathChecks.runAll()
}
