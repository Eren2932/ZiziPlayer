#!/usr/bin/env python3
"""RC2 tests execute production engine, SQLite and threads. No live/network claim."""
import math,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'_stub'),str(HERE.parent),str(HERE)]
import zizi_reco as reco
from test_zizi_reco import Clock,NOW,dz_track

class Capture(reco.Engine):
    def _cooc_boost(self,score,seeds,add=False):
        self.captured=dict(score)
        return super()._cooc_boost(score,seeds,add)

def make():
    calls=[]
    def fake(path,**kw):
        calls.append(path);bits=path.split('/');aid=int(bits[1])
        if len(bits)==2:return {'id':aid,'name':'Artist '+str(aid),'nb_fan':500,'picture_big':'https://img/'+str(aid)}
        if bits[2]=='related' and aid<=30:
            return {'data':[{'id':100000+aid,'name':'Neighbor '+str(aid),'nb_fan':500,'picture_big':'https://img/'+str(100000+aid)}]}
        if bits[2]=='radio' and aid<=30:
            return {'data':[{'id':200000+aid,'title':'Track '+str(aid),'duration':180,'rank':500000,
                'artist':{'id':100000+aid,'name':'Neighbor '+str(aid)},'album':{'id':300000+aid,'title':'Release','cover_big':'https://img/al'}}]}
        return {'data':[]}
    c=Clock();e=Capture(reco.Upstream(fake,None,c,reco.Bucket(10000,10000)),dz_track,c)
    return e,calls,c

def p30(weighted=False):
    return reco.parse_profile(s='|'.join(str(i)+'~'+str(round(1-(i-1)*.02,3) if weighted else 1) for i in range(1,31)))

class Coverage(unittest.TestCase):
    def test_all_thirty_have_related_and_radio_opportunity(self):
        e,calls,_=make();self.addCleanup(e.pool.shutdown,wait=True)
        result=e.home(p30());self.assertTrue(result['complete'])
        self.assertEqual(result['seed_coverage'],{'requested':30,'resolved':30,'related_ready':30,'related_expected':30})
        for kind in ('related','radio'):
            actual={int(x.split('/')[1]) for x in calls if x.endswith('/'+kind) and int(x.split('/')[1])<=30}
            self.assertEqual(actual,set(range(1,31)))
        self.assertEqual(len(e.captured),30)
        self.assertAlmostEqual(min(e.captured.values()),max(e.captured.values()))
    def test_weighted_tail_contributes_instead_of_being_dropped(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True);e.home(p30(True))
        self.assertIn('100030',e.captured)
        self.assertAlmostEqual(e.captured['100030']/e.captured['100001'],.42)
    def test_negative_artist_is_not_reintroduced_by_tail(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True)
        p=p30();p.neg_ids.add('100030');r=e.home(p)
        self.assertNotIn('100030',e.captured)
        self.assertFalse(any(card.get('artist_id')=='100030' or card.get('id')=='100030' for s in r['shelves'] for card in s['items']))
    def test_missing_graph_is_not_declared_complete_without_exception(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True)
        original=e.related;e.related=lambda aid,budget:None if aid=='30' else original(aid,budget)
        r=e._build(p30(),NOW,reco.day_number(NOW),NOW+20)
        self.assertFalse(r['complete']);self.assertEqual(r['seed_coverage']['related_ready'],29)

class PairStats(unittest.TestCase):
    def test_same_set_cannot_reach_threshold_by_weekly_replay(self):
        c=Clock();co=reco.CoStats(None,c)
        self.assertTrue(co.record(['1','2']))
        for week in (1,2,10):
            c.t=NOW+week*7*86400;self.assertFalse(co.record(['2','1']))
        self.assertEqual(co.mem_pairs,{('1','2'):1});self.assertEqual(co.neighbours('1'),[])
    def test_all_thirty_ids_participate_and_pair_order_is_canonical(self):
        co=reco.CoStats(None,Clock());ids=[str(i) for i in range(30,0,-1)]
        self.assertTrue(co.record(ids));self.assertEqual(len(co.mem_single),30);self.assertEqual(len(co.mem_pairs),435)
        self.assertEqual(co.mem_pairs[('1','30')],1);self.assertFalse(co.record(list(reversed(ids))))
    def test_sqlite_pairs_do_not_split_when_input_order_changes(self):
        with tempfile.TemporaryDirectory() as d:
            co=reco.CoStats(str(Path(d)/'co.sqlite'),Clock())
            for ids in (['20','10','30'],['10','20','40'],['20','10','50']):self.assertTrue(co.record(ids))
            result=dict(co.neighbours('10'))
            self.assertAlmostEqual(result['20'],1);self.assertTrue(all(0<=x<=1 for x in result.values()))

class Background(unittest.TestCase):
    def test_pending_profile_reuses_partial_without_second_foreground_build(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True)
        entered=threading.Event();release=threading.Event();calls=[]
        self.addCleanup(release.set)
        p=p30();key=p.key(reco.day_number(NOW));partial={'complete':False,'shelves':[],'seeds':[],'retry_ms':2000}
        def build(*args):calls.append(1);entered.set();release.wait(2);return partial
        e._build=build;e._refresh_later(p,key,p.key(0),20,partial);self.assertTrue(entered.wait(1))
        self.assertIs(e.home(p),partial);self.assertEqual(len(calls),1)
        release.set()
    def test_background_threads_are_bounded(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True);release=threading.Event();self.addCleanup(release.set)
        def blocked_build(*args):
            release.wait(2);return {'complete':False,'shelves':[]}
        e._build=blocked_build
        p=p30()
        for i in range(20):e._refresh_later(p,'k'+str(i),'s'+str(i),20,{'complete':False})
        self.assertLessEqual(len(e.refreshing),reco.MAX_BACKGROUND_REFRESHES);release.set()
    def test_metadata_queue_refuses_unbounded_work(self):
        e,_,_=make();self.addCleanup(e.pool.shutdown,wait=True)
        e.submit_gate=threading.BoundedSemaphore(1);release=threading.Event();self.addCleanup(release.set)
        first=e._submit(lambda _:release.wait(2),None);second=e._submit(lambda _:True,None)
        self.assertIsInstance(second.exception(),RuntimeError);release.set();first.result(timeout=2)
        self.assertTrue(e._submit(lambda _:True,None).result(timeout=1))

class IdentityHints(unittest.TestCase):
    def test_same_name_wrong_track_is_not_accepted(self):
        calls=[]
        def fake(path,**params):
            calls.append(path)
            if path=='search/track':return {'data':[
                {'title':'Different Song','artist':{'id':111,'name':'Same Name'}},
                {'title':'Target Song','artist':{'id':222,'name':'Same Name'}}]}
            return {'data':[]}
        c=Clock();e=reco.Engine(reco.Upstream(fake,None,c,reco.Bucket(100,100)),dz_track,c);self.addCleanup(e.pool.shutdown,wait=True)
        self.assertEqual(e.resolve(('name','same name'),1,False,'Target Song')['id'],'222')
        self.assertEqual(calls,['search/track'])
    def test_no_consent_hint_means_no_track_title_search(self):
        calls=[]
        def fake(path,**params):
            calls.append(path);return {'data':[{'id':333,'name':'Same Name','nb_fan':500}]} if path=='search/artist' else {}
        c=Clock();e=reco.Engine(reco.Upstream(fake,None,c,reco.Bucket(100,100)),dz_track,c);self.addCleanup(e.pool.shutdown,wait=True)
        e.resolve(('name','same name'),1,False,None)
        self.assertNotIn('search/track',calls)
if __name__=='__main__':unittest.main(verbosity=2)
