#!/usr/bin/env python3
"""Единый установщик сервера: умный подбор (1.14) + персональная главная и лента (Reco 1.1) за одну остановку.

    /opt/zizi/venv/bin/python tools/deploy_server.py --check            # ничего не пишет
    sudo /opt/zizi/venv/bin/python tools/deploy_server.py --apply
    sudo /opt/zizi/venv/bin/python tools/deploy_server.py --rollback /opt/zizi/server-backups/<папка>

Почему он один. До 6.82.0 было два установщика (apply_smart_update.py и deploy_reco.py), и каждый знал только
свой набор файлов. Второй, собранный на 6.80.1, не видел 1.14 и ставил каталог без неё. Здесь набор файлов один,
хеши комплекта запечатаны (server_bundle_seal.json), а успех установки — это не «служба ответила», а три факта
из /catalog/health: match_engine == "smart", reco_contract == 1, reco_feed == 1 и версия комплекта.
Любой другой исход — автоматический откат всех файлов из бэкапа.

Что ставится: zizi_match.py, zizi_reco.py, zizi_browse.py, zizi_catalog.py (всегда из комплекта) и zizi_versions.py
(только если развёрнутый файл не знает нужного API). zizi_browse.py на проде — Browse 1 RC1 (sha256 d4c07d16…, из
BROWSE_CHANGE_MANIFEST): обновление 6.47.0 (album_id в коллекции альбома) на сервер так и не ставилось. Теперь оно едет
в комплекте, а RC1 известен как база. Остальные модули не пишутся, но обязаны быть теми, на которых прошли тесты.
Env, базы, аудио и юнит systemd не трогаются. Проверка тестов нельзя отключить: упавший тест останавливает
установку и печатает свой вывод.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.request
from datetime import datetime
from pathlib import Path

from deploy_stage2 import digest, replace, service
from smoke_stage2 import RECO_POST_PATHS

ROOT = Path(__file__).resolve().parent.parent
SEAL = ROOT / 'tools' / 'server_bundle_seal.json'
KNOWN = ROOT / 'tools' / 'server_known.json'
BUNDLE = ('zizi_match.py', 'zizi_reco.py', 'zizi_browse.py', 'zizi_catalog.py')   # модули раньше каталога: он их импортирует
VERSIONS = 'zizi_versions.py'
MANAGED = BUNDLE + (VERSIONS,)
VERSIONS_API = ('def speed_compatible', 'def speed_family', 'def version_tags', 'def strip_version_phrases',
                'SPEED_TAGS', 'def normalized')
RESOLVER_VERSION = '1.7-stage2'
HEALTH_TRIES = 60                 # по 0.25 с: служба с прогревом поднимается не мгновенно
BACKUPS = 'server-backups'
TESTS = ['test_zizi_reco.py', 'test_reco2.py', 'test_reco2_rc2.py', 'test_zizi_feed.py', 'test_smart_match.py', 'test_version_family.py',
         'test_server_deploy.py', 'test_catalog_wiring.py', 'test_browse.py', 'test_browse_deploy.py',
         'test_zizi_guard.py', 'test_stage2.py', 'test_resolver_stage2.py',
         'test_smoke_stage2.py', 'smoke_stage2.py']


class DeployError(RuntimeError):
    pass


# ----------------------------------------------------------------------------- комплект и печать

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def load_seal(root=None, seal_path=None):
    """Хеши файлов комплекта должны совпасть с печатью: иначе комплект повреждён или правился после сборки."""
    root = root or ROOT
    seal = json.loads((seal_path or SEAL).read_text(encoding='utf-8'))
    payloads = {}
    for name in MANAGED:
        data = (root / name).read_bytes()
        if sha_bytes(data) != seal['files'][name]:
            raise DeployError('%s: хеш не совпадает с печатью комплекта. Файл изменён после сборки или комплект '
                              'повреждён; возьмите целый архив.' % name)
        compile(data, name, 'exec')                     # только синтаксис: ни импорта, ни сети
        payloads[name] = data
    return seal, payloads


def versions_api_ok(data):
    text = data.decode('utf-8', 'replace')
    return all(token in text for token in VERSIONS_API)


# ----------------------------------------------------------------------------- план

def plan(dest, payloads, known):
    """[(имя, действие, пояснение)]. Ничего не пишет. Неизвестный или правленный руками файл = отказ."""
    steps = []
    bases = {'zizi_catalog.py': known['catalog_bases'], 'zizi_reco.py': known['reco_bases'],
             'zizi_match.py': known.get('match_bases', {}), 'zizi_browse.py': known['browse_bases']}
    for name in BUNDLE + (VERSIONS,):
        path = dest / name
        new = payloads[name]
        if path.is_symlink():
            raise DeployError('refusing symlink: ' + name)
        if not path.exists():
            if name == 'zizi_catalog.py':
                raise DeployError('zizi_catalog.py не найден: это не каталог сервера (ожидается /opt/zizi) '
                                  'или Stage 2 / Browse 1 не установлен')
            steps.append((name, 'install', 'файла нет: ставится'))
            continue
        old = path.read_bytes()
        if sha_bytes(old) == sha_bytes(new):
            steps.append((name, 'skip', 'уже актуален'))
        elif name == VERSIONS:
            if versions_api_ok(old):
                steps.append((name, 'skip', 'развёрнутый файл уже содержит нужный API: не трогаю'))
            else:
                steps.append((name, 'replace', 'нет speed_compatible/SPEED_TAGS: заменяется'))
        else:
            base = bases[name].get(sha_bytes(old))
            if base is None:
                raise DeployError('unknown server edit: %s (sha256 %s). Файл правился руками или собран из другой '
                                  'ветки; слепая замена сотрёт эти правки. Сравните вручную или передайте файл '
                                  'на разбор.' % (name, sha_bytes(old)))
            steps.append((name, 'replace', 'база ' + base))
    for name, checksum in known['unchanged'].items():
        path = dest / name
        if path.is_symlink() or not path.is_file() or digest(path) != checksum:
            raise DeployError('requires the tested module unchanged: ' + name)
    return steps


def bundle_version(payloads):
    match = re.search(rb'^VERSION\s*=\s*"([^"]+)"', payloads['zizi_catalog.py'], re.M)
    if not match:
        raise DeployError('в zizi_catalog.py не найден VERSION')
    return match.group(1).decode()


# ----------------------------------------------------------------------------- здоровье

def fetch_json(opener, url):
    with opener.open(url, timeout=1.5) as r:
        return json.load(r)


def check_health(expect, base='http://127.0.0.1:8080'):
    """(ok, причина). expect=None — «служба жива и каталог отвечает» (после отката)."""
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    reason = 'нет ответа'
    for _ in range(HEALTH_TRIES):
        try:
            resolver = fetch_json(opener, base + '/health')
            catalog = fetch_json(opener, base + '/catalog/health')
            problems = []
            if resolver.get('version') != RESOLVER_VERSION:
                problems.append('resolver version %r' % resolver.get('version'))
            if not resolver.get('scheduler', {}).get('resolver_attached'):
                problems.append('scheduler не подключён')
            if not catalog.get('ok'):
                problems.append('catalog ok=false')
            if catalog.get('browse_contract') != 1:
                problems.append('browse_contract %r' % catalog.get('browse_contract'))
            for key, want in (expect or {}).items():
                if catalog.get(key) != want:
                    problems.append('%s=%r, ожидалось %r' % (key, catalog.get(key), want))
            if expect and not problems:
                # Flags in health are not proof that the advertised client routes were mounted.
                # OpenAPI checks the running app without tokens, user profiles or upstream work.
                schema = fetch_json(opener, base + '/openapi.json')
                paths = schema.get('paths', {}) if isinstance(schema, dict) else {}
                for path in RECO_POST_PATHS:
                    operations = paths.get(path, {}) if isinstance(paths, dict) else {}
                    if not isinstance(operations, dict) or 'post' not in operations:
                        problems.append('POST %s не зарегистрирован в работающем ASGI-приложении' % path)
            if not problems:
                return True, 'ok'
            reason = '; '.join(problems)
        except (OSError, ValueError) as exc:
            reason = '%s: %s' % (type(exc).__name__, exc)
        time.sleep(.25)
    return False, reason


def expectations(payloads):
    return {'version': bundle_version(payloads), 'match_engine': 'smart', 'reco_contract': 1, 'reco_feed': 1}


# ----------------------------------------------------------------------------- тесты

def test_environment(tmp):
    """Tests must not inherit production credentials, caches, databases or proxy settings."""
    return {
        'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'HOME': str(tmp), 'TMPDIR': str(tmp),
        'PYTHONUNBUFFERED': '1', 'PYTHONIOENCODING': 'utf-8',
        'ZIZI_CATALOG_DB': str(tmp) + '/catalog.db', 'ZIZI_RECO_DB': str(tmp) + '/reco.db',
        'ZIZI_EXTRA_DB': str(tmp) + '/extra.db', 'ZIZI_IMG_DIR': str(tmp) + '/img',
        'ZIZI_AUDIO_DIR': str(tmp) + '/audio', 'ZIZI_CACHE_FILE': str(tmp) + '/cache.json',
        'ZIZI_EXTRA_ENABLED': '0', 'ZIZI_PROXY_MODE': 'off',
    }


def test_output(stdout, stderr):
    # TimeoutExpired can carry bytes even with text=True.
    def text(value):
        return value.decode('utf-8', 'replace') if isinstance(value, bytes) else (value or '')
    return '\n'.join((text(stdout) + '\n' + text(stderr)).strip().splitlines()[-30:])


def run_tests(tests=None, root=None):
    root = root or ROOT
    for test in (tests or TESTS):
        with tempfile.TemporaryDirectory(prefix='zizi-server-test-') as tmp:
            try:
                result = subprocess.run([sys.executable, str(root / 'tools' / test)], cwd=root,
                                        env=test_environment(tmp), capture_output=True, text=True,
                                        encoding='utf-8', timeout=180)
            except subprocess.TimeoutExpired as exc:
                raise DeployError('%s: превышен таймаут 180 с. Установка остановлена, файлы не тронуты. Вывод:\n%s'
                                  % (test, test_output(exc.stdout, exc.stderr))) from exc
            if result.returncode:
                raise DeployError('%s не прошёл (код %d). Установка остановлена, файлы не тронуты. Вывод:\n%s'
                                  % (test, result.returncode, test_output(result.stdout, result.stderr)))
        print('PASS ' + test, flush=True)


# ----------------------------------------------------------------------------- бэкап и откат

def validate_backup(backup):
    manifest = json.loads((backup / 'manifest.json').read_text())
    if not set(manifest) <= set(MANAGED):
        raise DeployError('invalid backup manifest')
    for name, value in manifest.items():
        if value is not None and digest(backup / name) != value:
            raise DeployError('corrupt backup: ' + name)
    return manifest


def restore(dest, backup):
    manifest = validate_backup(backup)                  # сначала проверка, потом запись
    for name, value in manifest.items():
        if value is None:
            (dest / name).unlink(missing_ok=True)
        else:
            replace(backup / name, dest / name)


def make_backup(dest, steps):
    backup = dest / BACKUPS / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + str(os.getpid()))
    backup.mkdir(parents=True, mode=0o700)
    manifest = {}
    for name, action, _ in steps:
        if action == 'skip':
            continue
        path = dest / name
        manifest[name] = digest(path) if path.exists() else None
        if path.exists():
            replace(path, backup / name)
    (backup / 'manifest.json').write_text(json.dumps(manifest))
    return backup


def verify_on_disk(dest, payloads, steps):
    for name, action, _ in steps:
        if action != 'skip' and sha_bytes((dest / name).read_bytes()) != sha_bytes(payloads[name]):
            raise DeployError('%s: после записи на диске другой файл' % name)


# ----------------------------------------------------------------------------- main

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--check', action='store_true', help='по умолчанию: только проверка')
    mode.add_argument('--apply', action='store_true')
    mode.add_argument('--rollback', type=Path)
    parser.add_argument('--dest', type=Path, default=Path('/opt/zizi'))
    args = parser.parse_args(argv)
    dest = args.dest.resolve()
    if args.rollback:
        if os.geteuid() != 0:
            raise DeployError('rollback requires root')
        backup = args.rollback.resolve()
        if backup.parent != dest / BACKUPS:
            raise DeployError('backup must be in dest/' + BACKUPS)
        validate_backup(backup)                         # до остановки службы
        service('stop')
        try:
            restore(dest, backup)
        finally:
            service('start')
        ok, why = check_health(None)
        if not ok:
            raise DeployError('файлы восстановлены, но служба нездорова (%s). Смотрите journalctl -u zizi-resolver' % why)
        print('Откат выполнен; env и базы не менялись (catalog.db.reco, если есть, безвредный кэш).')
        return 0

    known = json.loads(KNOWN.read_text(encoding='utf-8'))
    seal, payloads = load_seal()
    steps = plan(dest, payloads, known)
    for name, action, why in steps:
        print('  %-18s %-8s %s' % (name, action, why))
    wd = subprocess.check_output(['systemctl', 'show', 'zizi-resolver', '-p', 'WorkingDirectory', '--value'],
                                 text=True, timeout=5).strip()
    if Path(wd).resolve() != dest:
        raise DeployError('service WorkingDirectory (%s) differs from --dest (%s)' % (wd, dest))
    run_tests()
    expect = expectations(payloads)
    if all(action == 'skip' for _, action, _ in steps):
        ok, why = check_health(expect)
        print('Файлы уже актуальны. Здоровье: %s (%s)' % ('ok' if ok else 'НЕТ', why))
        return 0 if ok else 4
    if not args.apply:
        print('CHECK ONLY: ничего не записано, служба не перезапускалась. --apply прервёт музыку на несколько секунд.')
        return 0
    if os.geteuid() != 0:
        raise DeployError('--apply requires root')
    backup = make_backup(dest, steps)
    print('Backup: ' + str(backup), flush=True)
    service('stop')
    try:
        for name, action, _ in steps:
            if action != 'skip':
                replace(ROOT / name, dest / name)
        verify_on_disk(dest, payloads, steps)
        service('start')
        ok, why = check_health(expect)
        if not ok:
            raise DeployError('Server health failed: %s' % why)
    except BaseException:
        service('stop')
        try:
            restore(dest, backup)
        finally:
            service('start')
        ok, why = check_health(None)
        print('Автоматический откат выполнен. Здоровье после отката: %s (%s)' % (ok, why), flush=True)
        raise
    print('Установлено: %s. match_engine=smart, reco_contract=1, reco_feed=1. '
          'Resolver/scheduler/guard/extra/process/env/базы не менялись.' % expect['version'])
    print('Откат: %s %s --rollback %s' % (sys.executable, Path(__file__).resolve(), backup))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except DeployError as exc:
        print('ОТКАЗ: %s' % exc, file=sys.stderr)
        raise SystemExit(2)
