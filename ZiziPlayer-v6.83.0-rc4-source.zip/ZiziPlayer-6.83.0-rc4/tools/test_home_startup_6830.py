#!/usr/bin/env python3
"""Startup linkage + real Java snapshot arbitration. Not an Android frame-time test."""
import subprocess
import tempfile
import unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
J=R/'app/src/main/java/app/ziziplayer'
class HomeStartup(unittest.TestCase):
    def test_actual_java_snapshot_arbitration(self):
        with tempfile.TemporaryDirectory() as out:
            src=Path(out)/'SnapshotChecks.java'
            src.write_text('''import app.ziziplayer.ui.HomeSnapshotPolicy;
public class SnapshotChecks {
 public static void main(String[] args) {
  int checks=0;
  for(int old=0;old<=20;old++) for(int fresh=0;fresh<=20;fresh++) for(boolean oc:new boolean[]{false,true}) for(boolean nc:new boolean[]{false,true}) {
   boolean expected=fresh>0 && (nc || old<=0 || (!oc && fresh>=old));
   if(HomeSnapshotPolicy.shouldReplace(old,oc,fresh,nc)!=expected) throw new AssertionError("snapshot downgrade");
   checks++;
  }
  System.out.print(checks);
 }
}''')
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,str(J/'ui/HomeSnapshotPolicy.java'),str(src)],check=True,capture_output=True,text=True)
            p=subprocess.run(['java','-cp',out,'SnapshotChecks'],check=True,capture_output=True,text=True)
            self.assertEqual(int(p.stdout),1764)
    def test_snapshot_restores_before_room_and_without_network(self):
        text=(J/'ui/HomeRecommendations.kt').read_text()
        bootstrap=text[text.index('    init {'):text.index('    private fun prefetch(')]
        self.assertIn('hidden.filterNotNull()',bootstrap)
        self.assertIn('epoch != generation || !safe(snapshot)',bootstrap)
        self.assertIn('val restored = withContext(Dispatchers.Default) { catalog.parseRecoHome(raw) }',bootstrap)
        self.assertIn('loadedAt = 0L, fromSnapshot = true',bootstrap)
        for forbidden in ('observeSessions','observeFavoriteIds','recommendHome(','discover('):self.assertNotIn(forbidden,bootstrap)
        load=text[text.index('    fun load('):]
        self.assertLess(load.index('restoreSnapshot(snapshot, now)'),load.index('observeFavoriteIds().first()'))
        self.assertIn('if (replace && reco.raw.isNotEmpty()) vault.writeHome(',load)
    def test_partial_nonempty_response_is_persistable(self):
        catalog=(J/'data/remote/DeezerCatalog.kt').read_text()
        self.assertIn('if (keepRaw && shelves.isNotEmpty()) json.toString() else ""',catalog)
        self.assertNotIn('keepRaw && complete && shelves.isNotEmpty()',catalog)
        vault=(J/'ui/RecoVault.kt').read_text()
        write=vault[vault.index('    fun writeHome('):vault.index('    fun dropHome(')]
        self.assertIn('wrapper.toByteArray(Charsets.UTF_8).size > HOME_MAX_BYTES',write)
        self.assertNotIn('homeFile.delete()',write)
    def test_cached_remote_content_can_render_before_library(self):
        ui=(J/'ui/screens/HomeScreen.kt').read_text()
        self.assertIn('hiddenSnapshot != null && rawFeed.folders == gate.folders && rawFeed.hidden == hidden',ui)
        self.assertIn('state.loading && (historyOpen || !feed.serverContent)',ui)
    def test_local_tags_cannot_fabricate_favorite_artists(self):
        text=(J/'ui/HomeRecommendations.kt').read_text()
        self.assertNotIn('"Твои любимые исполнители"',text)
        self.assertNotIn('val artists = mixes.filter',text)
        self.assertIn('val chosenArtists = vaultState.picks',text)
        self.assertIn('remoteId = "artist:${it.id}"',text)
        self.assertIn('"Миксы из твоей музыки"',text)
        self.assertIn('"Локальные подборки · не новые рекомендации"',text)
        self.assertIn('c.id != null || key in vaultState.ids',text)
if __name__=='__main__':unittest.main(verbosity=2)
