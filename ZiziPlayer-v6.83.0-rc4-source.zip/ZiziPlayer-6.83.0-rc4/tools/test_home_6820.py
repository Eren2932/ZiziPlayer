#!/usr/bin/env python3
"""6.82.0: быстрый старт главной и бесконечная лента «Для тебя».

Две части, и граница между ними названа прямо:
  * арифметика (HomeFeedStreamPolicy / HomeFeedRefreshPolicy / HomeRecoPolicy) — настоящая Java, исполняется на JVM;
  * Kotlin (HomeScreen, HomeRecoFeed, HomeViewModel, каталог) — только контракты по исходнику: Gradle здесь нет.
"""
import re
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
J = ROOT / 'app/src/main/java/app/ziziplayer'


def read(path):
    return (J / path).read_text(encoding='utf-8')


class Arithmetic(unittest.TestCase):
    def test_policies_execute_on_the_jvm(self):
        with tempfile.TemporaryDirectory() as out:
            files = [J / 'ui/HomeFeedPolicy.java', J / 'ui/HomeFeedRefreshPolicy.java', J / 'ui/HomeRecoPolicy.java',
                     J / 'ui/HomeFeedStreamPolicy.java', ROOT / 'app/src/test/java/app/ziziplayer/ui/HomeFeed6820Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out, *map(str, files)], check=True)
            run = subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.HomeFeed6820Checks'], check=True, capture_output=True, text=True)
            self.assertRegex(run.stdout, r'HomeFeed6820Checks passed: \d+')


class QuickStart(unittest.TestCase):
    def test_waiting_for_player_is_bounded_everywhere(self):
        for name in ('ui/HomeRecommendations.kt', 'ui/HomeRecoFeed.kt'):
            text = read(name)
            self.assertIn('HomeFeedRefreshPolicy.AUDIO_GRACE_MS', text, name)
            self.assertIn('if (app.playerController.state.value.connected && app.playerController.state.value.isLoadingAudio)', text)
            self.assertIn('withTimeoutOrNull(HomeFeedRefreshPolicy.AUDIO_GRACE_MS)', text)
            self.assertIn('app.playerController.state.first { !it.connected || !it.isLoadingAudio }', text)

    def test_empty_incomplete_answer_is_a_quick_retry_not_a_success(self):
        text = read('ui/HomeRecommendations.kt')
        for token in ('HomeRecoPolicy.RETRY -> { warming = true', 'HomeFeedRefreshPolicy.quickRetryDelayMs(quickAttempt, quickHintMs)',
                      'reco?.complete ?: true', 'builder.reco = lastReco', 'HomeSnapshotPolicy.shouldReplace(', 'if (replace) lastReco = reco', 'builder.reco = lastReco; publish()',
                      '.sortedBy { HomeRecoPolicy.shelfRank(it.kind.name) }'):
            self.assertIn(token, text, token)

    def test_shelf_kinds_the_server_sends_all_have_a_rank(self):
        kinds = re.search(r'enum class RecoShelfKind \{([^}]*)\}', read('data/remote/RecoModels.kt')).group(1)
        policy = read('ui/HomeRecoPolicy.java')
        for kind in re.findall(r'[A-Z]+', kinds):
            self.assertIn('case "%s"' % kind, policy, kind)

    def test_old_waiting_phrase_is_gone_from_the_app(self):
        for path in (J).rglob('*.kt'):
            self.assertNotIn('Подбираем', path.read_text(encoding='utf-8'), str(path))


class Feed(unittest.TestCase):
    def test_home_screen_renders_and_loads_the_feed(self):
        home = read('ui/screens/HomeScreen.kt')
        for token in ('homeFeedSkeleton(sectionTop)', 'homeRecoFeed(recoFeed,', 'home.recommendations.feed.state',
                      'rawRecoFeed.folders == gate.folders && rawRecoFeed.hidden == hidden',
                      'HomeFeedStreamPolicy.shouldLoadMore(lastVisible, f.tracks.size, f.more, f.loading, f.stalled)',
                      'HomeFeedStreamPolicy.indexOfKey(it.key)', 'home.loadMoreFeed()', 'home.playFeed(index)',
                      'onRetry = home::retryFeed', '+ recoFeed.tracks'):
            self.assertIn(token, home, token)

    def test_feed_rows_are_keyed_by_the_index_the_policy_parses(self):
        ui = read('ui/screens/HomeRecoFeedUi.kt')
        self.assertIn('HomeFeedStreamPolicy.keyOf(index)', ui)
        self.assertIn('"reco-feed:"', read('ui/HomeFeedStreamPolicy.java'))

    def test_feed_is_serialised_and_pinned_to_one_profile(self):
        feed = read('ui/HomeRecoFeed.kt')
        for token in ('private val lock = Mutex()', 'lock.withLock {', 'private var profile: RecoProfile? = null',
                      'seen.offer(it.trackId, it.artist, it.title)', 'HomeFeedStreamPolicy.MAX_TRACKS'):
            self.assertIn(token, feed, token)

    def test_feed_transport_matches_the_server_route(self):
        catalog = read('data/remote/DeezerCatalog.kt')
        self.assertIn('post("/reco/feed", query)', catalog)
        server = (ROOT / 'server/zizi_reco.py').read_text(encoding='utf-8') + (ROOT / 'server/zizi_catalog.py').read_text(encoding='utf-8')
        self.assertIn('/reco/feed', server)
        models = read('data/remote/RecoModels.kt')
        for key in ('"c"', '"n"', 'coerceIn(10, 50)'):
            self.assertIn(key, models)

    def test_player_queue_refills_only_the_feed_and_never_under_shuffle(self):
        vm = read('ui/HomeViewModel.kt')
        for token in ('HomeFeedStreamPolicy.queueNeedsMore(', 'st.queueSourceId, st.shuffle', 'feed.takeForQueue(from, HomeFeedStreamPolicy.QUEUE_BATCH)',
                      'st.queueSourceId != HomeFeedStreamPolicy.SOURCE_ID || st.shuffle', 'feedQueueNext = -1'):
            self.assertIn(token, vm, token)


if __name__ == '__main__':
    unittest.main(verbosity=2)
