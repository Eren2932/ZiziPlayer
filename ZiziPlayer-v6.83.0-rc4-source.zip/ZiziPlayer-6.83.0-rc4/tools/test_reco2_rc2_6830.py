#!/usr/bin/env python3
"""RC2 production Java execution + real SQLite aggregate, Kotlin wiring is source-only."""
import re,sqlite3,subprocess,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];J=ROOT/'app/src/main/java/app/ziziplayer'
class Rc2(unittest.TestCase):
    def test_production_java_executes(self):
        with tempfile.TemporaryDirectory() as out:
            files=[J/'data/remote/DeezerArtistRef.java',J/'ui/HomeTasteRefreshPolicy.java',
                   ROOT/'app/src/test/java/app/ziziplayer/ui/HomeReco6830Rc2Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            x=subprocess.run(['java','-cp',out,'app.ziziplayer.ui.HomeReco6830Rc2Checks'],check=True,capture_output=True,text=True)
            self.assertIn('HomeReco6830Rc2Checks passed:',x.stdout)
    def test_real_sqlite_meaningful_signals_not_checkpoints(self):
        text=(J/'data/ListeningDao.kt').read_text()
        end=text.index('fun observeRecoListeningSignal()');start=text.rfind('@Query("""',0,end)
        query=text[start+len('@Query("""'):text.index('""")',start)]
        con=sqlite3.connect(':memory:')
        con.execute('CREATE TABLE listening_sessions(sessionId TEXT,startedAt INTEGER,qualified INTEGER,outcome TEXT,updatedAt INTEGER,listenedMs INTEGER)')
        signal=lambda:con.execute(query).fetchone()
        self.assertEqual(signal(),(0,0,0,0))
        con.execute("INSERT INTO listening_sessions VALUES('a',100,0,'active',100,0)")
        before=signal();con.execute("UPDATE listening_sessions SET updatedAt=500,listenedMs=400")
        self.assertEqual(signal(),before)
        con.execute('UPDATE listening_sessions SET qualified=1')
        self.assertEqual(signal(),(1,0,100,0))
        con.execute('UPDATE listening_sessions SET updatedAt=900,listenedMs=800')
        self.assertEqual(signal(),(1,0,100,0))
        con.execute("INSERT INTO listening_sessions VALUES('b',200,0,'active',200,0)")
        self.assertEqual(signal(),(1,0,100,0))
        con.execute("UPDATE listening_sessions SET outcome='skipped' WHERE sessionId='b'")
        self.assertEqual(signal(),(1,1,100,200))
        con.execute('DELETE FROM listening_sessions');self.assertEqual(signal(),(0,0,0,0))
    def test_id_parser_is_used_for_both_surfaces(self):
        vm=(J/'ui/HomeViewModel.kt').read_text();profile=(J/'ui/HomeRecommendations.kt').read_text()
        self.assertIn('DeezerArtistRef.parse(artist.provider, artist.remoteId)',vm)
        self.assertIn('DeezerArtistRef.parse(r.provider, rid)',profile)
        self.assertNotIn("it.remoteId.all { c -> c in '0'..'9' }",vm)
    def test_taste_revision_invalidates_fresh_and_inflight_results(self):
        vm=(J/'ui/HomeViewModel.kt').read_text();home=(J/'ui/screens/HomeScreen.kt').read_text();reco=(J/'ui/HomeRecommendations.kt').read_text()
        for token in ['music.observeFavoriteIds()', 'dao.observeRecoListeningSignal()', 'tasteRevision.value += 1L']:
            self.assertIn(token,vm)
        self.assertIn('state.hiddenIds, state.tasteRevision)',home)
        self.assertIn('lastTasteRevision != snapshot.tasteRevision',reco)
        self.assertIn('if (tasteChanged) job?.cancel()',reco)
        self.assertIn('if (!tasteChanged && !HomeFeedRefreshPolicy.shouldLoad',reco)
        self.assertLess(reco.index('                publish()'),reco.index('delay(tasteWaitMs)'))
        self.assertIn('vaultState.dislikedArtists.asReversed()',reco)
        self.assertIn('HomeTasteLibraryKey(tracks, playlistIds)',vm)
        self.assertIn('it.id in favorites || it.id in playlistIds',vm)
        self.assertNotIn('lastSeenAt',vm[vm.index('val tracks = library.sources.tracks.filter'):vm.index('HomeTasteSignals(favorites, listening, recents, HomeTasteLibraryKey')])
    def test_feed_profile_changes_preserve_queue_epoch_and_seen(self):
        text=(J/'ui/HomeRecoFeed.kt').read_text();start=text.index('if (this.profile != null && this.profile != profile)');end=text.index('if (this.profile != null) {',start)
        block=text[start:end]
        self.assertIn('this.profile = profile; cursor = null',block)
        self.assertNotIn('generation +=',block);self.assertNotIn('seen.clear()',block)
        self.assertNotIn('startedAt = now',block)
        self.assertIn('now - startedAt >= HomeFeedStreamPolicy.PROFILE_AGE_MS',text)
        self.assertIn('if (pinned != profile) return HomeFeedStreamPolicy.PAGE_RETRY',text)
    def test_ci_executes_debug_and_release_compile_before_assemble(self):
        text=(ROOT/'.github/workflows/build.yml').read_text()
        build=text.split('  build:',1)[1]
        self.assertLess(build.index('- name: JDK 17'),build.index('- name: Самотест проверок'))
        self.assertIn(':app:compileDebugKotlin :app:compileReleaseKotlin :app:testDebugUnitTest',build)
        self.assertIn('selftest.log',build)
        self.assertNotIn('continue-on-error: true',build)
        self.assertIn("'test_reco2_rc2_6830.py'",(ROOT/'tools/check_selftest.py').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
