#!/usr/bin/env python3
"""Guard Kotlin -> Java profile TTL linkage and server/client TTL agreement."""
import ast
import re
import subprocess
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
J=ROOT/'app/src/main/java/app/ziziplayer/ui'
class FeedProfileTtl(unittest.TestCase):
    def test_real_java_constant_matches_server_feed_ttl(self):
        tree=ast.parse((ROOT/'server/zizi_reco.py').read_text())
        node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FEED_TTL' for t in n.targets))
        self.assertTrue(all(isinstance(n,(ast.Expression,ast.BinOp,ast.Mult,ast.Constant)) for n in ast.walk(ast.Expression(node))))
        seconds=eval(compile(ast.Expression(node),'<FEED_TTL>','eval'),{'__builtins__':{}},{})
        with tempfile.TemporaryDirectory() as out:
            src=Path(out)/'ReadProfileTtl.java'
            src.write_text('import app.ziziplayer.ui.HomeFeedStreamPolicy; public class ReadProfileTtl { public static void main(String[] a) { System.out.print(HomeFeedStreamPolicy.PROFILE_AGE_MS); } }')
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,str(J/'HomeFeedStreamPolicy.java'),str(J/'HomeFeedPolicy.java'),str(src)],check=True,capture_output=True,text=True)
            run=subprocess.run(['java','-cp',out,'ReadProfileTtl'],check=True,capture_output=True,text=True)
            self.assertEqual(int(run.stdout),seconds*1000)
            self.assertGreater(seconds,0)
    def test_every_kotlin_policy_reference_has_a_java_member(self):
        source=(J/'HomeFeedStreamPolicy.java').read_text()
        declared=set(re.findall(r'public\s+(?:static\s+)?(?:final\s+)?(?:class\s+)?[\w\[\]<>]+\s+(\w+)\s*(?:[=({;])',source))
        declared.update(re.findall(r'public static (?:final )?class\s+(\w+)',source))
        for p in (ROOT/'app/src').rglob('*.kt'):
            for ref in re.findall(r'HomeFeedStreamPolicy\.(\w+)',p.read_text()):
                self.assertIn(ref,declared,str(p.relative_to(ROOT))+': '+ref)
if __name__=='__main__':unittest.main(verbosity=2)
