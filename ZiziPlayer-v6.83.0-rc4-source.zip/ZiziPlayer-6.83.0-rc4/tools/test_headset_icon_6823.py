#!/usr/bin/env python3
"""UI/source regression guards. No Compose rendering, Android compilation or hardware test."""
from pathlib import Path
import re
import unittest
from release_identity import assert_release_at_least
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
def read(path): return (SRC / path).read_text()
class HeadsetIcon6823(unittest.TestCase):
    def test_legacy_headphones_for_wired_and_known_bluetooth_headsets(self):
        source = read('ui/components/AudioOutputUi.kt')
        self.assertIn('OutputKind.WIRED, OutputKind.BLUETOOTH -> ZiziIcons.Headphones', source)
    def test_unclassified_a2dp_also_uses_legacy_headphones(self):
        source = read('ui/components/AudioOutputUi.kt')
        self.assertIn('OutputKind.BLUETOOTH_OTHER -> ZiziIcons.Headphones', source)
        self.assertNotIn('ZiziIcons.BluetoothAudio', source)
    def test_phone_speaker_usb_and_unknown_preserve_their_icons(self):
        source = read('ui/components/AudioOutputUi.kt')
        self.assertIn('OutputKind.PHONE -> if (large) ZiziIcons.ConnectPhone else ZiziIcons.ConnectDevices', source)
        self.assertIn('OutputKind.BLUETOOTH_SPEAKER -> ZiziIcons.ConnectSpeaker', source)
        self.assertIn('OutputKind.USB, OutputKind.EXTERNAL, OutputKind.UNKNOWN -> ZiziIcons.ConnectDevices', source)
    def test_both_player_controls_and_sheet_use_shared_helper(self):
        mini = read('ui/components/MiniPlayerCard.kt')
        self.assertIn('MiniControl(audioOutputIcon(output), "Устройства: ${output.name}", audioOutputTint(output)', mini)
        self.assertIn('audioOutputIcon(output)', read('ui/screens/PlayerScreen.kt'))
        sheet = read('ui/screens/AudioOutputSheet.kt')
        self.assertIn('audioOutputIcon(active, large = true)', sheet)
        self.assertIn('audioOutputIcon(device, large = true)', sheet)
    def test_small_bluetooth_transport_badge_is_preserved_like_reference(self):
        mini = read('ui/components/MiniPlayerCard.kt')
        self.assertIn('Icon(if (output.isBluetooth) ZiziIcons.BluetoothAudio else audioOutputIcon(output)', mini)
        self.assertIn('Text(output.name, color = ConnectedDeviceAccent', mini)
    def test_original_headphones_vector_is_reused_not_redrawn(self):
        icons = read('ui/components/ZiziIcons.kt')
        vector = icons.split('val Headphones: ImageVector by lazy {', 1)[1].split('val BluetoothAudio:', 1)[0]
        for token in ('heavy("zizi_headphones", 2.14f)', 'arcTo(10.93f, 10.93f', 'moveTo(2.00f, 16.86f)', 'moveTo(22.00f, 16.86f)'):
            self.assertIn(token, vector)
    def test_no_new_bluetooth_permission_or_fake_route_classification(self):
        output = read('playback/AudioOutput.kt')
        self.assertIn('AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> OutputKind.BLUETOOTH_OTHER', output)
        self.assertIn('if (hasBluetoothPermission(context))', output)
        self.assertIn('AudioRoutePolicy.select(actual?.id', output)
        self.assertIn('OutputKind.BLUETOOTH_OTHER -> "Bluetooth-устройство"', output)
        self.assertNotIn('BLUETOOTH_SCAN', (ROOT/'app/src/main/AndroidManifest.xml').read_text())
    def test_colour_and_transport_label_are_not_replaced_with_reference_brand(self):
        source = read('ui/components/AudioOutputUi.kt')
        self.assertIn('val ConnectedDeviceAccent = ZiziBrand', source)
        self.assertIn('OutputKind.BLUETOOTH, OutputKind.BLUETOOTH_SPEAKER, OutputKind.BLUETOOTH_OTHER -> "Bluetooth"', source)
    def test_preflight_includes_regression(self):
        self.assertIn("'test_headset_icon_6823.py'", (ROOT/'tools/check_selftest.py').read_text())
        gradle = (ROOT/'app/build.gradle.kts').read_text()
        assert_release_at_least(self, gradle, 171, '6.82.3')
if __name__ == '__main__': unittest.main(verbosity=2)
