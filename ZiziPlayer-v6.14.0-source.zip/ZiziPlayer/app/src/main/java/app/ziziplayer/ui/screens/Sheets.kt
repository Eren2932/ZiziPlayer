@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.remote.RemoteQuality
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.SortMode
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.NowPlayingBadge
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
private fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun MenuItem(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    trailing: String? = null,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
        if (trailing != null) Text(trailing, color = p.subtext, fontSize = 14.sp)
    }
}

/**
 * [scrollable] exists for the queue. A LazyColumn nested inside a verticalScroll parent is the
 * classic Compose performance trap: the two scrollables fight over the same gesture and the lazy
 * list loses most of its item reuse, so a 100 track queue scrolled worse than the 3000 track
 * library. The queue passes false and drives its own LazyColumn.
 */
@Composable
private fun ZiziSheetScaffold(
    onDismiss: () -> Unit,
    scrollable: Boolean = true,
    partial: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        contentColor = p.text,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = !partial),
        dragHandle = {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(p.subtext.copy(alpha = 0.45f)))
            }
        }
    ) {
        // Content scrolls: the settings sheet is taller than a phone screen in landscape and the
        // v5 version simply clipped the last rows away.
        Column(
            Modifier
                .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(bottom = 26.dp),
            content = content
        )
    }
}

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Реверб", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$reverb%", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = reverb.toFloat(),
                onValueChange = { reverb = it.roundToInt() },
                onValueChangeFinished = { apply() },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(6.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", current?.let { "Осталось $it мин" } ?: "Выключен")
        listOf(10, 15, 20, 30, 45, 60, 90).forEach { minutes ->
            MenuItem(Icons.Filled.Bedtime, "$minutes минут") { onPick(minutes); onDismiss() }
        }
        if (current != null) {
            MenuItem(Icons.Filled.Close, "Выключить таймер") { onPick(null); onDismiss() }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var newName by remember { mutableStateOf("") }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Добавить в плейлист")
        playlists.forEach { playlist ->
            MenuItem(Icons.Filled.QueueMusic, playlist.name) { onPick(playlist.id); onDismiss() }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.accent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* ------------------------------------------------------------------ track menu */

@Composable
fun TrackMenuSheet(
    favorite: Boolean,
    plays: Int,
    sleepMinutesLeft: Int?,
    track: TrackEntity,
    inPlaylist: PlaylistEntity?,
    onDismiss: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit
) {
    val p = LocalPalette.current
    // partial = true: лист открывается на половину экрана — то, чем пользуются каждый день,
    // видно сразу, а редкое и опасное (удаление) доезжает только после протяжки вверх.
    ZiziSheetScaffold(onDismiss, partial = true) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 20,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickAction(
                icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                label = "Избранное",
                active = favorite,
                onClick = onToggleFavorite
            )
            QuickAction(Icons.Filled.PlaylistAdd, "В плейлист", onClick = onAddToPlaylist)
            QuickAction(Icons.Filled.Speed, "Скорость", onClick = onFx)
            QuickAction(Icons.Filled.Share, "Поделиться", onClick = onShare)
        }
        Spacer(Modifier.height(14.dp))
        MenuItem(Icons.Filled.Bedtime, "Таймер сна", trailing = sleepMinutesLeft?.let { "$it мин" }, onClick = onSleep)
        if (inPlaylist != null) {
            MenuItem(Icons.Filled.PlaylistRemove, "Убрать из «${inPlaylist.name}»", onClick = onRemoveFromPlaylist)
        }
        HorizontalDivider(color = p.chip.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 6.dp))
        MenuItem(Icons.Filled.DeleteOutline, "Убрать из Zizi", tint = Color(0xFFFF8A8A), onClick = onHide)
        MenuItem(Icons.Filled.DeleteForever, "Удалить файл с устройства", tint = Color(0xFFFF5555), onClick = onDeleteFile)
    }
}

/**
 * Круглая кнопка быстрого действия. Подпись — часть кнопки, а не пояснение:
 * пояснительные строки («Файл останется на устройстве…», «прослушан N раз») убраны целиком.
 */
@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(if (active) p.accent.copy(alpha = 0.22f) else p.chip.copy(alpha = 0.75f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (active) p.accent else p.text, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = if (active) p.accent else p.subtext, fontSize = 11.sp, maxLines = 1)
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    tracks: List<TrackEntity>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPick: (Int) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        // The queue opens straight at the track that is playing instead of at the top.
        val queueState = rememberLazyListState()
        // Same rule as the library list: while the finger moves, background indexing stands still.
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.isScrollInProgress }.collectLatest { scrolling ->
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
        }
        LaunchedEffect(currentTrackId) {
            val index = tracks.indexOfFirst { it.id == currentTrackId }
            if (index > 1) queueState.scrollToItem((index - 1).coerceAtLeast(0))
        }
        LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = maxHeight),
            state = queueState
        ) {
            itemsIndexed(
                tracks,
                key = { _, item -> item.id },
                // A declared contentType lets the lazy layout reuse a row's whole subtree instead of
                // building a new one, and the fixed height below means no row is ever re-measured.
                contentType = { _, _ -> "queue" }
            ) { index, track ->
                val playing = track.id == currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clickable { onPick(index) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                        )
                        // 6.14.0: третья копия того же маркера убрана — здесь `playing` значит
                        // «эта строка и есть текущий трек», а `isPlaying` — играет ли он сейчас.
                        NowPlayingBadge(
                            current = playing,
                            playing = isPlaying,
                            size = 48.dp,
                            corner = 8.dp,
                            barSize = 17.dp
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

/**
 * A titled card. The old settings screen was one flat stream of 14 rows, dividers and radio
 * buttons - everything at the same visual weight, which is exactly why it read as "thrown
 * together". Now every row lives in a group with a heading, and the group is a card.
 */
@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        text = title.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 26.dp, top = 16.dp, bottom = 8.dp)
    )
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.chip.copy(alpha = 0.38f))
            .padding(vertical = 4.dp),
        content = content
    )
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    label: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: Color? = null,
    onClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val color = tint ?: p.text
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null) {
                Text(subtitle, color = p.subtext, fontSize = 12.5.sp, maxLines = 2)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, label: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    SettingRow(
        icon = icon,
        label = label,
        subtitle = subtitle,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }
    )
}

@Composable
fun SettingsSheet(vm: MainViewModel, state: LibraryUiState, onDismiss: () -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    var sortOpen by remember { mutableStateOf(false) }
    val themeNames = remember {
        mapOf(
            AppTheme.GRAPHITE to "Графит",
            AppTheme.MIDNIGHT to "Полночь",
            AppTheme.AMOLED to "AMOLED",
            AppTheme.SUNSET to "Закат"
        )
    }
    val sortNames = remember {
        mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Настройки", "${state.tracks.size} треков в библиотеке")

        SettingsGroup("Оформление") {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppTheme.entries.forEach { theme ->
                    val active = state.settings.theme == theme
                    val preview = remember(theme) { basePalette(theme) }
                    Column(
                        Modifier
                            .width(76.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) p.accent.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable { vm.setTheme(theme) }
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(preview.background)
                                .then(
                                    if (active) Modifier.border(1.5.dp, p.accent, RoundedCornerShape(10.dp))
                                    else Modifier
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            themeNames[theme] ?: theme.name,
                            color = if (active) p.accent else p.subtext,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }
            }
            SettingSwitch(
                icon = Icons.Filled.Palette,
                label = "Цвет из обложки",
                subtitle = "Фон повторяет оттенки текущей обложки",
                checked = state.settings.accentFromArtwork,
                onChange = vm::setDynamicAccent
            )
        }

        SettingsGroup("Библиотека") {
            SettingRow(
                icon = Icons.Filled.SortByAlpha,
                label = "Сортировка",
                subtitle = sortNames[state.settings.sortMode],
                trailing = {
                    Icon(
                        if (sortOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = null,
                        tint = p.subtext,
                        modifier = Modifier.size(22.dp)
                    )
                },
                onClick = { sortOpen = !sortOpen }
            )
            if (sortOpen) {
                SortMode.entries.forEach { mode ->
                    val active = state.settings.sortMode == mode
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.setSortMode(mode) }
                            .padding(start = 60.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            sortNames[mode] ?: mode.name,
                            color = if (active) p.accent else p.text,
                            fontSize = 14.5.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (active) Icon(Icons.Filled.Check, null, tint = p.accent, modifier = Modifier.size(19.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
            SettingRow(
                icon = Icons.Filled.CreateNewFolder,
                label = "Добавить папку с музыкой",
                subtitle = if (state.settings.folderUris.isEmpty()) "Ничего не подключено"
                else "Подключено: ${state.settings.folderUris.size}",
                onClick = onPickFolder
            )
            state.settings.folderUris.forEach { uri ->
                Row(
                    Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uri.substringAfterLast("/").ifBlank { uri },
                        color = p.subtext,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { vm.removeFolder(uri) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Close, null, tint = p.subtext, modifier = Modifier.size(16.dp)) }
                }
            }
            SettingRow(
                icon = Icons.Filled.Refresh,
                label = "Пересканировать",
                subtitle = if (state.scanning) "Идёт сканирование…" else "Найдено ${state.tracks.size} треков",
                onClick = vm::rescan
            )
            if (state.hiddenCount > 0) {
                SettingRow(
                    icon = Icons.Filled.Visibility,
                    label = "Вернуть скрытые треки",
                    subtitle = "Скрыто: ${state.hiddenCount}",
                    onClick = vm::restoreAllHidden
                )
            }
        }

        NetworkCatalogGroup(vm, state)

        SettingsGroup("Звук") {
            SettingSwitch(
                icon = Icons.Filled.GraphicEq,
                label = "Пропускать тишину",
                subtitle = "Убирает паузы в начале и в конце трека",
                checked = state.settings.skipSilence,
                onChange = vm::setSkipSilence
            )
        }

        // DEV UNLOCK (6.11.0).
        //
        // Seven taps on the version row. Not a joke and not an easter egg: the resolver rows and the
        // client walker are the only way to tell "сервер лежит" from "трек удалён" without a cable,
        // and a user who has been told the tap count is a user who can send a useful screenshot.
        // Deleting them outright would mean the next breakage is diagnosed by rebuilding the APK.
        var taps by remember { mutableStateOf(0) }
        SettingsGroup("О приложении") {
            SettingRow(
                icon = Icons.Filled.Info,
                label = "ZiziPlayer",
                subtitle = if (state.settings.devMode)
                    "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · режим отладки включён"
                else if (taps in 3..6)
                    "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · ещё ${7 - taps}…"
                else "Версия ${app.ziziplayer.BuildConfig.VERSION_NAME} · Media3 · Compose",
                onClick = {
                    if (state.settings.devMode) {
                        taps = 0
                        vm.setDevMode(false)
                    } else {
                        taps++
                        if (taps >= 7) { taps = 0; vm.setDevMode(true) }
                    }
                }
            )
        }
        Spacer(Modifier.height(6.dp))
    }
}

/* ------------------------------------------------------------------ confirm */

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    title: String = "Переименовать",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.accent,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Готово", color = p.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/**
 * The report, in full, on a screen you can read and in a form you can paste.
 *
 * Three properties, and every one of them is a lesson from 6.8.0: it does not truncate (each client
 * gets its own line, wrapped, not ellipsised), it scrolls (eight clients plus a header do not fit on
 * a phone), and it copies (a screenshot of a wrapped Russian sentence is not a bug report - the
 * verbatim status string is).
 */
@Composable
private fun StreamReportDialog(lines: List<String>, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    val text = lines.joinToString("\n")
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Диагностика потока", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                lines.forEach { line ->
                    Text(
                        text = line,
                        color = if (line.contains("HTTP 2")) p.text else p.subtext,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) {
                Text("Скопировать", color = p.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = p.text) } }
    )
}

/**
 * Network catalogue settings, plus the connection probe.
 *
 * The probe is not a debug leftover: this section talks to a private API that is guaranteed to break
 * eventually, and when it does, the difference between "поиск не работает" and a message naming the
 * provider and the exact refusal is the difference between a patch and a guessing game. It stays.
 */
/**
 * The four rows a listener actually has decisions to make about. Shared by both variants of the
 * group so that hiding the technical part cannot silently drop them.
 */
@Composable
private fun ColumnScope.StreamUserRows(vm: MainViewModel, settings: app.ziziplayer.data.UserSettings) {
    SettingSwitch(
        icon = Icons.Filled.Wifi,
        label = "Только Wi-Fi",
        subtitle = "Не тратить мобильный трафик на потоки",
        checked = settings.wifiOnly,
        onChange = vm::setWifiOnly
    )
    SettingRow(
        icon = Icons.Filled.GraphicEq,
        label = "Качество потока",
        subtitle = when (settings.streamQuality) {
            RemoteQuality.LOW -> "Экономно, около 64 кбит/с"
            RemoteQuality.NORMAL -> "Обычное, около 128 кбит/с"
            RemoteQuality.HIGH -> "Высокое, около 256 кбит/с"
        },
        onClick = vm::cycleStreamQuality
    )
    SettingSwitch(
        icon = Icons.Filled.Storage,
        label = "Кэшировать потоки",
        subtitle = "До ${settings.streamCacheMb} МБ: мгновенная перемотка и повтор без трафика",
        checked = settings.streamCacheEnabled,
        onChange = vm::setStreamCacheEnabled
    )
    SettingRow(
        icon = Icons.Filled.DeleteSweep,
        label = "Очистить кэш потоков",
        subtitle = vm.streamCacheLabel(),
        onClick = vm::clearStreamCache
    )
}

@Composable
private fun NetworkCatalogGroup(vm: MainViewModel, state: LibraryUiState) {
    val probe by vm.catalogProbe.collectAsState()
    val report by vm.streamReport.collectAsState()
    val reportRunning by vm.reportRunning.collectAsState()
    val resolverStatus by vm.resolverStatus.collectAsState()
    val settings = state.settings
    // Hoisted next to the report dialog for the same reason: the group recomposes while a probe runs.
    var resolverUrlDialog by remember { mutableStateOf(false) }
    var resolverTokenDialog by remember { mutableStateOf(false) }

    if (resolverUrlDialog) {
        RenameDialog(
            initial = settings.resolverUrl,
            title = "Адрес резолвера",
            onConfirm = { value -> vm.setResolverUrl(value); resolverUrlDialog = false },
            onDismiss = { resolverUrlDialog = false }
        )
    }
    if (resolverTokenDialog) {
        RenameDialog(
            initial = settings.resolverToken,
            title = "Токен резолвера",
            onConfirm = { value -> vm.setResolverToken(value); resolverTokenDialog = false },
            onDismiss = { resolverTokenDialog = false }
        )
    }

    // The dialog is hoisted here so it survives the group recomposing while the report runs.
    report?.let { lines ->
        StreamReportDialog(lines = lines, onDismiss = vm::dismissStreamReport)
    }

    // 6.11.0 — две разные группы вместо одной.
    //
    // Пользователю нужны четыре решения: качество, мобильный трафик, кэш, очистка. Всё остальное в
    // этой группе появилось из отладки бот-чека и гео-блока и для него бессмысленно: адрес сервера
    // и токен теперь вшиты в сборку (BuildConfig.RESOLVER_URL / RESOLVER_TOKEN), а диагностика
    // открывается семью тапами по версии.
    if (!settings.devMode) {
        SettingsGroup("Поток из сети") {
            StreamUserRows(vm, settings)
        }
        return
    }

    SettingsGroup("Сетевой каталог") {
        /*
         * OWN RESOLVER (6.10.0) — first rows of the group, because this is now the main path.
         *
         * 6.9.4 diagnostics: eight internal YouTube clients, both host families, valid poToken,
         * LOGIN_REQUIRED eight times out of eight. The same track answered on the first try when
         * yt-dlp asked from a VPS. Attestation cannot be passed by an APK Google did not sign, so
         * the resolve moved to a machine that has Python, a JS engine and daily yt-dlp updates.
         * Search stays on Innertube: it never broke, it is not attested.
         */
        SettingRow(
            icon = Icons.Filled.Dns,
            label = "Свой резолвер",
            subtitle = if (settings.resolverUrl.isBlank())
                "Не задан — поток берётся у YouTube напрямую (не работает: бот-чек)"
            else settings.resolverUrl,
            onClick = { resolverUrlDialog = true }
        )
        if (settings.resolverUrl.isNotBlank()) {
            SettingRow(
                icon = Icons.Filled.Key,
                label = "Токен резолвера",
                subtitle = if (settings.resolverToken.isBlank()) "Не задан — сервер ответит 401"
                    else "Задан, " + settings.resolverToken.length + " симв. (нажми, чтобы заменить)",
                onClick = { resolverTokenDialog = true }
            )
            SettingSwitch(
                icon = Icons.Filled.CloudDownload,
                label = "Гнать звук через сервер",
                subtitle = "Вкл: /stream, ссылка не привязана к IP телефона. Выкл: прямая ссылка, трафик мимо сервера",
                checked = settings.resolverProxy,
                onChange = vm::setResolverProxy
            )
            SettingRow(
                icon = Icons.Filled.NetworkCheck,
                label = "Проверить сервер",
                subtitle = resolverStatus ?: "Спросит /health: живой ли сервис и сколько в кэше",
                onClick = vm::probeResolver
            )
        }
        SettingRow(
            icon = Icons.Filled.Language,
            label = "Источник",
            subtitle = if (settings.catalogProvider == "yt") "YouTube Music" else "Audius",
            onClick = { vm.setCatalogProvider(if (settings.catalogProvider == "yt") "audius" else "yt") }
        )
        StreamUserRows(vm, settings)
        // What is playing, in provider terms.
        //
        // Not a debug leftover either: the stream is produced by picking one of five internal
        // YouTube clients at runtime, and which one survives is decided by attestation, not by us.
        // When playback breaks, the first question is always "which client answered" - this row is
        // the answer, without a build, a log or a cable.
        vm.streamStatusLabel()?.let { status ->
            SettingRow(
                icon = Icons.Filled.GraphicEq,
                label = "Активный поток",
                subtitle = status,
                onClick = {}
            )
        }
        SettingRow(
            icon = Icons.Filled.Search,
            label = "Проверить подключение",
            subtitle = probe ?: "Спросит у источника «phonk» и покажет, что он ответил",
            onClick = { vm.probeCatalog() }
        )
        if (probe != null) {
            // The row that finds the 403.
            //
            // "Проверить подключение" proves the catalogue parses; it says nothing about whether
            // the URL it produced can be fetched, and that is precisely where YouTube failed in
            // 6.6.0 - search fine, resolve fine, GET refused. This asks the CDN for two bytes and
            // prints the client that answered plus the HTTP code, which turns "треки сами
            // свайпаются" into one line naming one layer.
            SettingRow(
                icon = Icons.Filled.NetworkCheck,
                label = "Проверить поток",
                subtitle = "Резолвит первый трек и запрашивает 2 байта с CDN",
                onClick = vm::probeStream
            )
            // FULL DIAGNOSTICS (6.8.1).
            //
            // "Проверить поток" answers with the LAST client's complaint, in a two line subtitle,
            // which is how `LOGIN_REQUIRED «Войдите, чтобы подтвердить, что вы не робот»` reached
            // the user as `ANDROID_VR: Войдите в` and cost a release. This walks every internal
            // client and opens the result in a dialog that can be copied out whole.
            SettingRow(
                icon = Icons.Filled.BugReport,
                label = if (reportRunning) "Опрашиваю клиентов…" else "Полная диагностика потока",
                subtitle = "Все клиенты YouTube по очереди, с копированием отчёта",
                onClick = { vm.runStreamReport() }
            )
            SettingRow(
                icon = Icons.Filled.PlayArrow,
                label = "Включить найденное",
                subtitle = "Полный тракт: резолв ссылки, кэш, декодер",
                onClick = vm::playProbeResults
            )
        }
    }
}
