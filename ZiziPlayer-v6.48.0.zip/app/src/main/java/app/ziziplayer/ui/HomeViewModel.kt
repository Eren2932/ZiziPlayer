package app.ziziplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.remote.CatalogPolicy
import app.ziziplayer.data.HomePinEntity
import app.ziziplayer.data.ListeningSessionEntity
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.PlaylistVaultRow
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.OfflineDownloads
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

internal data class HomePlaylist(val playlist: PlaylistEntity, val cover: TrackEntity?, val count: Int, val pinned: Boolean)
internal data class HomeHistory(val session: ListeningSessionEntity, val track: TrackEntity?)
internal enum class HomeCollectionKind(val title: String, val sourceId: String) {
    WAVE("Моя волна", "home:wave-local-v1"),
    RECENT_ADDED("Недавно добавлено", "home:recent-added")
}
internal data class HomeCollection(val kind: HomeCollectionKind, val trackIds: List<String>)
internal data class HomeState(
    val loading: Boolean = true,
    val vaultFolders: Set<String> = emptySet(),
    val playlists: List<HomePlaylist> = emptyList(),
    val recentAdded: List<TrackEntity> = emptyList(),
    val offline: List<TrackEntity> = emptyList(),
    val tracks: List<TrackEntity> = emptyList(),
    val availableOfflineIds: Set<String> = emptySet(),
    val history: List<HomeHistory> = emptyList(),
    val listenedMs: Long = 0,
    val qualified: Int = 0,
    val completed: Int = 0,
    val skipped: Int = 0
)
private data class HomeSources(
    val tracks: List<TrackEntity>, val playlists: List<PlaylistEntity>,
    val membership: List<PlaylistVaultRow>, val hidden: Set<String>, val pins: List<HomePinEntity>
)
private data class HomeLibrary(val sources: HomeSources, val offlineIds: Set<String>)

/** Local-first projections. No playback clock, network calls or mutable player state here. */
@OptIn(UnstableApi::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as ZiziApplication
    private val music = app.database.musicDao()
    private val dao = app.database.listeningDao()
    private val refresh = MutableStateFlow(0L)
    private val _historyOpen = MutableStateFlow(false)
    val historyOpen = _historyOpen.asStateFlow()
    private val _collection = MutableStateFlow<HomeCollection?>(null)
    internal val collection = _collection.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    val storageProblem = app.listeningStore.problem

    private val sources = combine(music.observeAllTracks(), music.observePlaylists(),
        music.observePlaylistVaultRows(), app.repository.hiddenIds, dao.observePins()) { tracks, playlists, membership, hidden, pins ->
        HomeSources(tracks, playlists, membership, hidden, pins)
    }.distinctUntilChanged()
    // File existence is checked off-main and NOT on each listening checkpoint.
    private val local = combine(sources, OfflineDownloads.states, refresh) { source, _, _ ->
        HomeLibrary(source, source.tracks.filter { !it.isRemote || OfflineDownloads.isComplete(app, it) }
            .mapTo(HashSet()) { it.id })
    }.flowOn(Dispatchers.IO)

    // Opening Home must not deserialize 10,000 listening sessions. History owns
    // that subscription; Stage 1 shelves only use library projections.
    private val historySessions = _historyOpen.flatMapLatest { open ->
        if (open) dao.observeSessions() else flowOf(emptyList<ListeningSessionEntity>())
    }
    internal val state = combine(local, historySessions, app.repository.vault.state) { library, sessions, gate ->
        val source = library.sources
        fun allowed(t: TrackEntity) = t.id !in source.hidden &&
            (!t.isRemote || CatalogPolicy.supports(t.provider, t.remoteId)) &&
            (t.isRemote || t.sourceFolder !in gate.folders)
        val tracks = source.tracks.filter(::allowed)
        val byId = tracks.associateBy { it.id }
        val knownIds = source.tracks.mapTo(HashSet()) { it.id }
        val members = source.membership.groupBy { it.playlistId }
        val pins = source.pins.associateBy { it.playlistId }
        val playlists = source.playlists.mapNotNull { playlist ->
            val rows = members[playlist.id].orEmpty()
            // Do not reveal a protected playlist's title/cover through a new home surface.
            if (rows.any { !allowed(it.track) }) return@mapNotNull null
            HomePlaylist(playlist, rows.firstOrNull()?.track, rows.size, playlist.id in pins)
        }.sortedWith(compareByDescending<HomePlaylist> { pins[it.playlist.id]?.pinnedAt ?: 0L }
            .thenByDescending { it.playlist.createdAt })
        val history = sessions.filter { row -> row.trackId !in source.hidden &&
            (row.source != "local" || row.sourceFolder !in gate.folders) &&
            (row.trackId !in knownIds || byId.containsKey(row.trackId))
        }.map { HomeHistory(it, byId[it.trackId]) }
        HomeState(loading = false, vaultFolders = gate.folders, playlists = playlists,
            tracks = tracks, availableOfflineIds = tracks.filter { it.id in library.offlineIds }.mapTo(HashSet()) { it.id },
            recentAdded = tracks.filter { !it.isRemote || it.savedAt != null }
                .sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(100),
            offline = tracks.filter { it.id in library.offlineIds }.sortedWith(compareByDescending<TrackEntity> { it.savedAt ?: it.dateAdded }.thenBy { it.id }).take(50),
            history = history, listenedMs = history.sumOf { it.session.listenedMs },
            qualified = history.count { it.session.qualified }, completed = history.count { it.session.completed },
            skipped = history.count { it.session.outcome == "skipped" })
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState())

    fun entered() { refresh.value += 1 }
    fun openHistory() { _historyOpen.value = true }
    internal fun openCollection(kind: HomeCollectionKind) {
        val tracks = when (kind) {
            HomeCollectionKind.WAVE -> state.value.offline
            HomeCollectionKind.RECENT_ADDED -> state.value.recentAdded
        }
        // Stable ordering while open. Later changes can remove forbidden/deleted
        // IDs but never reorder a list under the user's finger.
        _collection.value = HomeCollection(kind, tracks.map { it.id })
    }
    fun back(): Boolean {
        if (_collection.value != null) { _collection.value = null; return true }
        if (!_historyOpen.value) return false
        _historyOpen.value = false
        return true
    }
    fun dismissMessage() { _message.value = null }
    fun setPinned(id: Long, pinned: Boolean) = viewModelScope.launch {
        try {
            if (state.value.playlists.none { it.playlist.id == id }) return@launch
            if (!dao.setPinned(id, pinned, System.currentTimeMillis())) _message.value = "Можно закрепить до шести плейлистов"
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось изменить закрепления" }
    }
    fun clearHistory() = viewModelScope.launch {
        try { app.listeningStore.clearHistory(); _message.value = "История очищена. Старые счётчики медиатеки сохранены" }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Не удалось очистить историю" }
    }
}
