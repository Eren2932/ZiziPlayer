package app.ziziplayer.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.HomeCollectionKind
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.sin

/** Stage 1 is a finite local list, deliberately not a recommendation session. */
@Composable
internal fun HomeCollectionScreen(
    kind: HomeCollectionKind,
    tracks: List<TrackEntity>,
    playback: PlaybackState,
    onBack: () -> Unit,
    onToggle: () -> Unit,
    onPlay: (TrackEntity, List<TrackEntity>, String) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    val tint = if (kind == HomeCollectionKind.WAVE) Color(0xFF6F3A22) else Color(0xFF345B79)
    val ownsQueue = playback.queueSourceId == kind.sourceId
    PinnedCollectionScaffold(
        destination = kind.sourceId, title = kind.title, tint = tint, trackCount = tracks.size,
        playingHere = ownsQueue && playback.isPlaying,
        playEnabled = tracks.isNotEmpty() || ownsQueue,
        onBack = onBack,
        onPlay = {
            if (ownsQueue) onToggle()
            else tracks.firstOrNull()?.let { onPlay(it, tracks, kind.sourceId) }
        },
        hero = {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(tint, Color(0xFF121212))))
                .padding(top = 72.dp, bottom = 16.dp)) {
                BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size((maxWidth * 0.62f).coerceAtMost(240.dp)).clip(RoundedCornerShape(18.dp))) {
                    if (kind == HomeCollectionKind.WAVE) WaveArtwork(Modifier.fillMaxSize())
                    else TrackArtwork(tracks.firstOrNull(), 640, Modifier.fillMaxSize(), glyphSize = 64)
                }
                }
                Text(kind.title, color = p.text, fontSize = 30.sp, lineHeight = 34.sp,
                    fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp))
                Text(trackCountLabel(tracks.size), color = p.subtext, fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                // Measured action area reserves the sole overlaid Play button's space.
                Row(Modifier.fillMaxWidth().height(56.dp).padding(start = 12.dp, end = 88.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        val shuffled = tracks.shuffled()
                        shuffled.firstOrNull()?.let { onPlay(it, shuffled, kind.sourceId) }
                    }, enabled = tracks.isNotEmpty(), modifier = Modifier.size(48.dp)) {
                        Icon(ZiziIcons.Shuffle, "Перемешать подборку", tint = p.brand, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    ) {
        if (tracks.isEmpty()) item(key = "selection:empty") {
            Text("Нет доступных треков", color = p.subtext, modifier = Modifier.padding(20.dp))
        }
        items(tracks, key = { it.id }, contentType = { "track" }) { track ->
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                CollectionTrackRow(track, maxWidth.value / 1080f, track.id == playback.currentTrackId,
                    selected = false, picking = false,
                    onPlay = { onPlay(track, tracks, kind.sourceId) }, onSelect = {},
                    onLongPress = { onMenu(track) }, onMenu = { onMenu(track) })
            }
        }
    }
}

/** Original procedural artwork: no downloaded reference assets or animation load. */
@Composable
internal fun WaveArtwork(modifier: Modifier = Modifier) {
    Canvas(modifier.background(Brush.linearGradient(listOf(Color(0xFFB44E18), Color(0xFF351C15))))) {
        val steps = 90
        for (line in 0 until 17) {
            val path = Path()
            for (step in 0..steps) {
                val x = size.width * step / steps
                val phase = step.toFloat() / steps * 7f + line * 0.18f
                val y = size.height * (0.16f + line * 0.041f + sin(phase) * 0.14f)
                if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, Color(0xFFFFBE79).copy(alpha = 0.24f + line * 0.025f), style = Stroke(1.5.dp.toPx()))
        }
    }
}
