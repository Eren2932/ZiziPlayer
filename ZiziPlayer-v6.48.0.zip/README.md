# ZiziPlayer — Android 6.48.0

Исходники этапов **«Главная и подборки» + «Строгий поиск каталога»**. VersionCode **97**. Основа — 6.47.0 (96). **Не APK и не подтверждённая Android-сборка.**

Новая Главная: «Моя волна», закрепления, «Недавно добавлено». Новый общий экран подборок: измеряемая шапка, одна прилипающая оранжевая Play-кнопка, реальные строки и действия плеера. Пока волна запускает конечный локальный список до 50 записей — бесконечный генератор, анализ доступности и сессионный прогрев будут этапом 3.

Полный отчёт и ограничения: [RELEASE_v6.48.0.md](RELEASE_v6.48.0.md). Сервер: [server/STRICT_MATCH_UPDATE.md](server/STRICT_MATCH_UPDATE.md). Итоговые проверки: `verification/v6.48.0/results.json`. Предыдущие документы и отчёты оставлены как история.

## Обновление репозитория и сборка

Загрузить **ZiziPlayer-v6.48.0.zip** в корень `Eren2932/ZiziPlayer`, ветка main. Текущий workflow распакует максимальный versionCode 97; старый ZIP 96 можно оставить. Desktop, workflow и секреты менять не нужно. Серверный комплект к Android-сборке не относится.

Дождаться зелёного Actions и скачать его APK. Для обновления поверх старого приложения нужен прежний ключ подписи — не удалять пользовательские данные ради установки.

В the Computer выполнены статические проверки, Java-геометрия, SQLite и офлайн-серверные тесты. Gradle, Kotlin/Compose-компиляция, UI на устройстве, реальный VPS и живое аудио здесь не проверялись.

````bash
python3 tools/check_selftest.py
python3 tools/check_kotlin_syntax.py app/src
python3 tools/check_imports.py app/src/main
python3 tools/check_static_refs.py app/src/main
python3 tools/check_call_args.py app/src/main
python3 server/tools/test_strict_match.py

# В готовом Android-окружении: SDK 36, Gradle 8.11.1, JDK 17
gradle --no-daemon :app:testDebugUnitTest :app:assembleRelease --stacktrace
````
