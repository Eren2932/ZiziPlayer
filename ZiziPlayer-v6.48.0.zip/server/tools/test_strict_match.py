#!/usr/bin/env python3
"""Production matcher + real SQLite; upstream candidate fixtures, NOT live ASGI/audio."""
import json
from contextlib import closing
import math
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tools/_stub'))
import zizi_catalog as c


def candidate(title='Artist - Song', artist='Artist - Topic', duration=180, vid='abcdefghijk'):
    return dict(vid=vid, title=title, uploader=artist, dur=duration)


class StrictMatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = self.tmp.name + '/catalog.db'
        self.dbpatch = patch.object(c, 'DB_PATH', self.db)
        self.dbpatch.start()
        self.addCleanup(self.dbpatch.stop)
        with c._db() as con:
            con.commit()
        con.close()

    def match(self, candidates, title='Song', artist='Artist', duration=180, **kwargs):
        with patch.object(c, '_hunt', return_value=candidates):
            return c.match_track(title, artist, duration, **kwargs)

    def assert_miss(self, candidates, title='Song', artist='Artist', duration=180, **kwargs):
        with self.assertRaises(c.HTTPException) as ctx:
            self.match(candidates, title, artist, duration, **kwargs)
        self.assertEqual(ctx.exception.status_code, 404)

    def test_original_accepts_official_and_returns_evidence(self):
        r = self.match([candidate('Artist - Song (Official Audio)')])
        self.assertTrue(r['strict']); self.assertTrue(r['confident'])
        self.assertFalse(r['cached']); self.assertGreaterEqual(r['score'], 70)
        with patch.object(c, '_hunt', side_effect=AssertionError('must hit cache')):
            again = c.match_track('Song', 'Artist', 180)
        self.assertTrue(again['cached'])
        self.assertEqual(again['score'], r['score'])
        self.assertEqual(again['picked'], r['picked'])

    def test_reject_wrong_versions_even_same_duration_and_topic_bonus(self):
        for version in ['Slowed', 'Super Slowed', 'Ultra Slowed', 'Sped Up', 'Nightcore',
                        'Remix', 'Reverb', 'Cover', 'Karaoke', 'Live', 'Instrumental',
                        'Acoustic', 'Bass Boosted', '8D', 'VIP Mix', 'Extended', 'Radio Edit',
                        'Remastered', 'Bootleg', 'Flip', 'RMX']:
            with self.subTest(version=version):
                # Different title/key so each test really executes matching, not prior miss.
                title = 'Tune ' + str(len(version)) + version.replace(' ', '')
                # Identity query itself must not acquire standalone version markers.
                title = 'Tune' + str(sum(map(ord, version)))
                self.assert_miss([candidate('Artist - ' + title + ' (' + version + ')')], title=title)

    def test_slowed_super_ultra_are_not_interchangeable(self):
        for want, got in [('Slowed','Super Slowed'),('Super Slowed','Ultra Slowed'),
                          ('Ultra Slowed','Slowed'),('Super Slowed','')]:
            with self.subTest(want=want, got=got):
                self.assert_miss([candidate('Song (' + got + ')')], title='Song (' + want + ')')

    def test_requested_version_is_not_rejected_in_principle(self):
        for version in ['Super Slowed','Slowed + Reverb','Remix','Acoustic']:
            with self.subTest(version=version):
                title = 'Song (' + version + ')'
                self.assertEqual('abcdefghijk', self.match([candidate('Artist - ' + title)], title=title)['vid'])

    def test_named_remix_requires_qualifier(self):
        self.assert_miss([candidate('Artist - Song (Bob Remix)')], title='Song (Alice Remix)')

    def test_later_correct_recording_wins_over_high_scoring_remix(self):
        bad = candidate('Artist - Song (Remix)')
        good = candidate('Artist - Song', vid='lmnopqrstuv')
        self.assertEqual(self.match([bad, good])['vid'], good['vid'])

    def test_unknown_candidate_duration_rejected_when_reference_known(self):
        self.assert_miss([candidate(duration=0)])

    def test_duration_boundary(self):
        for delta, accepted in [(5,True), (7.2,True), (7.21,False), (20,False)]:
            with self.subTest(delta=delta):
                self.assertEqual(c.strict_candidate(candidate(duration=180+delta), 'Song','Artist',180), accepted)

    def test_unknown_reference_requires_other_strong_evidence(self):
        self.assertTrue(self.match([candidate(duration=0)], duration=0)['confident'])
        self.assert_miss([candidate('Artist - Song B', artist='Artist', duration=0)], title='Song B', duration=0)

    def test_wrong_artist_and_substring_do_not_pass(self):
        self.assert_miss([candidate('Other - Song', 'Other - Topic')])
        self.assertFalse(c.strict_candidate(candidate('Artist - Songs'), 'Song','Artist',180))
        self.assertFalse(c.strict_candidate(candidate('ArtistX - Song', 'ArtistX - Topic'), 'Song','Artist',180))

    def test_unicode_and_accents(self):
        self.assertTrue(self.match([candidate('ZXVREN - MONTAGEM DELÍRIO (Super Slowed)', 'ZXVREN - Topic')],
                                  title='MONTAGEM DELÍRIO (Super Slowed)', artist='ZXVREN')['confident'])
        self.assertTrue(self.match([candidate('СИЯЙ - Песня о любви', 'СИЯЙ - Topic')],
                                  title='Песня о любви', artist='СИЯЙ')['confident'])

    def test_legacy_isrc_and_q2_cache_are_ignored_without_deleting(self):
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute('INSERT INTO match VALUES(?,?,?,?)', ('ISRC', 'badbadbadba', 999, int(time.time())))
            db.execute('INSERT INTO match VALUES(?,?,?,?)', ('q2:old', 'badbadbadba', 999, int(time.time())))
        r = self.match([candidate()], isrc='ISRC')
        self.assertFalse(r['cached']); self.assertEqual(r['vid'], 'abcdefghijk')
        with closing(sqlite3.connect(self.db)) as db, db:
            self.assertEqual(db.execute("SELECT vid FROM match WHERE key='ISRC'").fetchone()[0], 'badbadbadba')

    def test_isrc_does_not_merge_versions_or_modes(self):
        keys = [c.match_key(title, 'Artist', 180, 'SAME-ISRC', weak)
                for title in ['Song','Song (Remix)','Song (Super Slowed)'] for weak in [True,False]]
        self.assertEqual(len(set(keys)), 6)

    def test_unproven_row_in_current_namespace_researched(self):
        key = c.match_key('Song','Artist',180,'',False)
        c.cache_put(key, 'badbadbadba', 999)
        self.assertFalse(self.match([candidate()])['cached'])

    def test_corrupt_cached_versions_cannot_bypass_strict_mode(self):
        key = c.match_key('Song','Artist',180,'',False)
        c.cache_put(key, 'badbadbadba', 999, candidate('Artist - Song (Remix)', vid='badbadbadba'))
        r = self.match([candidate()])
        self.assertFalse(r['cached']); self.assertEqual(r['vid'], 'abcdefghijk')

    def test_rescore_required_even_if_cached_score_is_high(self):
        key = c.match_key('Song','Artist',180,'',False)
        c.cache_put(key, 'badbadbadba', 999, candidate('Other - Song', 'Other - Topic', vid='badbadbadba'))
        self.assertFalse(self.match([candidate()])['cached'])

    def test_cached_low_score_is_not_reclassified_as_confident(self):
        key = c.match_key('Song','Artist',180,'',False)
        c.cache_put(key, 'abcdefghijk', 19, candidate())
        self.assertFalse(self.match([candidate()])['cached'])

    def test_ttl_and_future_timestamps(self):
        key = c.match_key('Song','Artist',180,'',False)
        for timestamp in [0, int(time.time())-c.MATCH_TTL-2, int(time.time())+10000]:
            c.cache_put(key, 'abcdefghijk', 100, candidate())
            with closing(sqlite3.connect(self.db)) as db, db:
                db.execute('UPDATE match SET ts=? WHERE key=?',(timestamp,key))
            self.assertFalse(self.match([candidate()])['cached'])

    def test_malformed_proof_fails_closed(self):
        key = c.match_key('Song','Artist',180,'',False)
        for metadata in ['{', 'null', '[]', '{"vid":"abcdefghijk"}']:
            c.cache_put(key, 'abcdefghijk', 100, candidate())
            with closing(sqlite3.connect(self.db)) as db, db:
                db.execute('UPDATE match_proof SET metadata=? WHERE key=?',(metadata,key))
            self.assertFalse(self.match([candidate()])['cached'])

    def test_changed_policy_and_wrong_vid_are_not_trusted(self):
        key = c.match_key('Song','Artist',180,'',False)
        c.cache_put(key,'abcdefghijk',100,candidate(vid='badbadbadba'))
        self.assertFalse(self.match([candidate()])['cached'])
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute('UPDATE match_proof SET policy=1 WHERE key=?',(key,))
        self.assertFalse(self.match([candidate()])['cached'])

    def test_explicit_weak_mode_never_poison_strict_cache(self):
        r = self.match([candidate('Artist - Song (Remix)')], allow_weak=True)
        self.assertFalse(r['strict']); self.assertFalse(r['confident'])
        self.assert_miss([candidate('Artist - Song (Remix)')])
        with patch.object(c, '_hunt', side_effect=AssertionError('weak cache still available')):
            self.assertTrue(c.match_track('Song','Artist',180,allow_weak=True)['cached'])

    def test_negative_caches_are_mode_isolated(self):
        self.assert_miss([])
        self.assertFalse(self.match([candidate()], allow_weak=True)['cached'])

    def test_partial_failure_does_not_poison_miss_cache(self):
        candidates = c.HuntResults([candidate('Artist - Song (Remix)')]); candidates.complete=False
        with patch.object(c, '_hunt', return_value=candidates):
            with self.assertRaises(c.HTTPException) as ctx: c.match_track('Song','Artist',180)
        self.assertEqual(ctx.exception.status_code,503)
        self.assertIsNone(c.miss_get(c.match_key('Song','Artist',180,'',False)))
        self.assertTrue(self.match([candidate()])['confident'])

    def test_busy_does_not_poison_miss_cache(self):
        with patch.object(c,'_hunt',side_effect=c.ExtractBusy(2)):
            with self.assertRaises(c.HTTPException) as ctx: c.match_track('Song','Artist',180)
        self.assertEqual(ctx.exception.status_code,429)
        self.assertIsNone(c.miss_get(c.match_key('Song','Artist',180,'',False)))

    def test_malformed_candidates_are_skipped(self):
        for bad in [None, {}, candidate(duration=float('nan')), candidate(duration=float('inf')),
                    candidate(duration=-1), candidate(duration=True), candidate(vid='bad')]:
            self.assertFalse(c.valid_candidate(bad))
        self.assertTrue(self.match([None, {}, candidate()])['confident'])

    def test_duplicate_id_with_better_metadata_is_evaluated(self):
        self.assertTrue(self.match([candidate('Unrelated','Unknown'), candidate()])['confident'])

    def test_hunt_must_not_stop_early_on_instrumental(self):
        with patch.object(c, 'yt_search', side_effect=[[candidate('Artist - Song (Instrumental)')], [candidate()]] ) as search:
            result=c._hunt('Song','Artist','',180)
        self.assertEqual(search.call_count,2)
        self.assertEqual(len(result),2)

    def test_hunt_invalid_metadata_is_incomplete_not_a_negative_result(self):
        with patch.object(c, 'yt_search', return_value=[{'title': []}]):
            result = c._hunt('Song','Artist','',180)
        self.assertFalse(result.complete)
        with patch.object(c, '_hunt', return_value=result):
            with self.assertRaises(c.HTTPException) as ctx: c.match_track('Song','Artist',180)
        self.assertEqual(ctx.exception.status_code,503)

    def test_public_routes_default_to_strict_and_forward_override(self):
        with patch.object(c,'match_track',return_value={}) as match:
            c.match('Song','Artist',180)
            self.assertFalse(match.call_args.kwargs['allow_weak'])
            c.match('Song','Artist',180,strict=False)
            self.assertTrue(match.call_args.kwargs['allow_weak'])
        with patch.object(c,'dz_get',return_value={}), patch.object(c,'dz_track',return_value={
            'title':'Song','artist':'Artist','dur':180,'isrc':'','id':'1'}), patch.object(c,'match_track',return_value={}) as match:
            c.match_deezer('1')
            self.assertFalse(match.call_args.kwargs['allow_weak'])

    def test_invalid_input_does_not_hunt(self):
        for title, artist, duration in [('', 'Artist',180),('Song',' ',180),('Song','Artist',-1)]:
            with patch.object(c,'_hunt') as hunt:
                with self.assertRaises(c.HTTPException) as ctx: c.match_track(title,artist,duration)
                self.assertEqual(ctx.exception.status_code,422); hunt.assert_not_called()


if __name__ == '__main__': unittest.main(verbosity=2)
