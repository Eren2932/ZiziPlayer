# Сборка Нур 0.5.0

Нужны JDK 17, Gradle 8.9, Android SDK Platform 34 / Build Tools 34.0.0 и Python 3.10+. Kotlin 2.0.20, AGP 8.5.2 и Compose BOM 2024.09.00 сохранены. Новых библиотечных зависимостей нет.

Полного Gradle Wrapper в исходной версии нет; используйте установленный `gradle`, а не `./gradlew`. Зависимости первоначально загружаются из Google Maven, Maven Central и Gradle.

## Проверки исходников

````bash
python3 tools/check_compose_actions.py
python3 tools/test_compose_actions.py
python3 tools/kt_sanity.py
python3 tools/kt_symbols.py
python3 tools/source_audit.py
python3 tools/test_amoled_source.py
python3 tools/test_source_archive.py
python3 tools/test_kt_symbols.py
python3 tools/verify_cities.py
python3 tools/verify_uz_table.py
python3 tools/test_build_regressions.py
````

Все 11 команд выполнены в the Computer, логи находятся в `docs/qa-0.5.0/`. Это не Kotlin-компиляция.

## Сборка и тесты Android

````bash
gradle --no-daemon :app:compileDebugKotlin :app:compileReleaseKotlin :app:compileDebugUnitTestKotlin :app:compileDebugAndroidTestKotlin --stacktrace
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease :app:assembleDebugAndroidTest --stacktrace
gradle :app:connectedDebugAndroidTest
````

Последняя команда требует подключённого эмулятора или устройства. В исходниках 136 JVM- и 24 Android UI-теста; здесь они не запускались. CI настроен на запуск UI-тестов на API 26 и 34, но новый run не был запущен при подготовке архива.

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`. Release APK: `app/build/outputs/apk/release/app-release.apk`.

Release по-прежнему подписывается debug-ключом для тестовой установки, не для публикации. Для настоящего релиза нужен постоянный собственный ключ. Не удаляйте приложение для обхода конфликта подписей без резервной копии настроек.

## Preview

Выберите debug variant и откройте `app/src/debug/java/com/nur/prayer/preview/AmoledPreviews.kt`. Все девять Preview вызывают настоящие composable с тестовыми датой и датчиком. Это способ просмотра после Gradle Sync, а не уже проверенные изображения.
