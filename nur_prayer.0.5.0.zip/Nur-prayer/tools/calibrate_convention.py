#!/usr/bin/env python3
"""
Derives CalendarConvention.DUM_RT from the printed poster instead of guessing it.

The problem
-----------
A printed calendar disagrees with true astronomy by *seconds*, not minutes, and the only thing
that matters is which side of a minute boundary those seconds fall on. Kazan sunrise is the clean
proof: the true instants are 04:14:50, 04:16:47, 04:18:43, 04:20:40 and the poster prints
04:15, 04:17, 04:19, 04:20. No whole-minute correction can produce that sequence with any single
rounding mode. A shift of +18 s with truncation produces it exactly, including the last day where
04:20:58 barely stays inside the twentieth minute.

The method
----------
For each column, take the true instant of every published day and find the complete set of integer
second shifts x for which floor(true + x) equals the printed minute on *every* day. If that set is
empty the poster is internally inconsistent (or our astronomy is wrong); if it is not, its centre
is the most robust choice, furthest from both minute boundaries.
"""
import sys, os
from datetime import date, datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prayer_port import (Coordinates, Params, SolarTime, METHODS, SAHAR, SUNRISE, DHUHR, ASR,
                         MAGHRIB, ISHA, FAJR)

KAZAN = Coordinates(55.7963, 49.1088)
TZ = timezone(timedelta(hours=3))          # Europe/Moscow, no DST since 2014
METHOD = METHODS["SPIRITUAL_BOARD_TATARSTAN"]

# "Ике атнага намаз уку тәртибе", Казань, август 2026, transcribed from the photograph.
POSTER = {
    15: {SAHAR: "01:11", FAJR: "02:45", SUNRISE: "04:15", DHUHR: "11:47", ASR: "16:53", MAGHRIB: "19:19", ISHA: "21:34"},
    16: {SAHAR: "01:17", FAJR: "02:47", SUNRISE: "04:17", DHUHR: "11:47", ASR: "16:52", MAGHRIB: "19:17", ISHA: "21:30"},
    17: {SAHAR: "01:22", FAJR: "02:49", SUNRISE: "04:19", DHUHR: "11:47", ASR: "16:50", MAGHRIB: "19:14", ISHA: "21:26"},
    18: {SAHAR: "01:27", FAJR: "02:50", SUNRISE: "04:20", DHUHR: "11:47", ASR: "16:48", MAGHRIB: "19:12", ISHA: "21:22"},
}
LABEL = {SAHAR: "Сәхәр тәмам", SUNRISE: "Кояш чыга", DHUHR: "Зәвәл",
         ASR: "Икенде", MAGHRIB: "Ахшам", ISHA: "Ястү"}


def true_instant(d: date, column: str) -> datetime:
    """Unrounded, uncorrected astronomical moment, as a UTC datetime."""
    solar = SolarTime.of(d, KAZAN)
    base = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    if column == SAHAR:
        hours = solar.hour_angle(-METHOD.fajr_angle, False)
    elif column == SUNRISE:
        hours = solar.sunrise
    elif column == DHUHR:
        hours = solar.transit
    elif column == ASR:
        hours = solar.afternoon(2.0)             # Hanafi, as the board prints it
    elif column == MAGHRIB:
        hours = solar.sunset
    elif column == ISHA:
        hours = solar.hour_angle(-METHOD.isha_angle, True)
    else:
        raise ValueError(column)
    return base + timedelta(seconds=hours * 3600.0)


def printed_minute_of_day(value: str) -> int:
    h, m = value.split(":")
    return int(h) * 60 + int(m)


def admissible_shifts(column: str, lo: int = -900, hi: int = 900):
    """Every integer second shift that reproduces the poster on all four days."""
    good = []
    for x in range(lo, hi + 1):
        if all(
            int(((true_instant(date(2026, 8, day), column) + timedelta(seconds=x))
                 .astimezone(TZ).hour * 60
                 + (true_instant(date(2026, 8, day), column) + timedelta(seconds=x))
                 .astimezone(TZ).minute)) == printed_minute_of_day(POSTER[day][column])
            for day in POSTER
        ):
            good.append(x)
    return good


def contiguous_runs(values):
    runs, start = [], None
    for i, v in enumerate(values):
        if start is None:
            start = v
        elif v != values[i - 1] + 1:
            runs.append((start, values[i - 1]))
            start = v
    if start is not None:
        runs.append((start, values[-1]))
    return runs


def main() -> int:
    print("Истинные астрономические мгновения (Казань, местное время):")
    for day in sorted(POSTER):
        row = "  %02d.08  " % day
        for column in (SAHAR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA):
            t = true_instant(date(2026, 8, day), column).astimezone(TZ)
            row += "%s %s   " % (LABEL[column].split()[0][:6], t.strftime("%H:%M:%S"))
        print(row)

    print("\nДопустимые сдвиги (секунды), при которых floor(истина + x) = печатная минута:")
    print("%-14s %-26s %8s %8s" % ("столбец", "интервал", "центр", "запас"))
    chosen = {}
    failed = False
    for column in (SAHAR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA):
        shifts = admissible_shifts(column)
        if not shifts:
            print("%-14s %s" % (LABEL[column], "ПУСТО — плакат несовместим с астрономией"))
            failed = True
            continue
        runs = contiguous_runs(shifts)
        lo, hi = max(runs, key=lambda r: r[1] - r[0])
        centre = (lo + hi) // 2
        chosen[column] = centre
        print("%-14s [%+5d, %+5d] с%s %+7d %7s" % (
            LABEL[column], lo, hi, "" if len(runs) == 1 else " (+%d др.)" % (len(runs) - 1),
            centre, "±%d с" % ((hi - lo) // 2)))

    print("\nKotlin (CalendarConvention.kt):")
    names = {SAHAR: "Prayer.SAHAR", SUNRISE: "Prayer.SUNRISE", DHUHR: "Prayer.DHUHR",
             ASR: "Prayer.ASR", MAGHRIB: "Prayer.MAGHRIB", ISHA: "Prayer.ISHA"}
    for column, value in chosen.items():
        print("    %-16s to MarkerPolicy(RoundingMode.DOWN, %+d)," % (names[column], value))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
