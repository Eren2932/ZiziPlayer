#!/usr/bin/env python3
import unittest
from check_compose_actions import violations


class ComposeActionRegressionTest(unittest.TestCase):
    def test_original_failure(self):
        self.assertEqual([(1, 'performTextInput')], violations('node.performTextInput("заинс").performImeAction()'))

    def test_fixed_separate_calls(self):
        self.assertEqual([], violations('node.performTextInput("заинс")\nnode.performImeAction()'))

    def test_newline_and_comment_still_chain(self):
        self.assertEqual([(1, 'performTextInput')], violations('node.performTextInput(\nquery("("))\n/* note */ .performImeAction()'))

    def test_comments_and_strings_are_not_code(self):
        self.assertEqual([], violations('// node.performTextInput("a").bad()\nval x = "performImeAction().bad()"'))

    def test_assertion_chain_is_valid(self):
        self.assertEqual([], violations('node.assertIsDisplayed().performClick().assertIsOn()'))

    def test_other_unit_actions(self):
        for action in ('performImeAction', 'performTextReplacement', 'performTextClearance'):
            self.assertEqual(1, len(violations(f'node.{action}().performClick()')))


if __name__ == '__main__':
    unittest.main(verbosity=2)
