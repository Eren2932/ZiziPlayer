#!/usr/bin/env python3
"""Narrow preflight for Unit-returning Compose test actions; NOT a Kotlin compiler.

Compose's performTextInput/performImeAction do not return SemanticsNodeInteraction.
Chaining any call after them caused compileDebugAndroidTestKotlin to fail in 0.3.2.
Strings/comments are blanked before walking balanced parentheses (including multiline calls).
"""
from pathlib import Path
import re
from kt_sanity import strip_noise

UNIT_ACTIONS = ('performTextInput', 'performTextReplacement', 'performTextClearance', 'performImeAction')
CALL = re.compile(r'\b(' + '|'.join(UNIT_ACTIONS) + r')\s*\(')


def violations(source):
    code = strip_noise(source)
    findings = []
    for match in CALL.finditer(code):
        depth, end = 1, match.end()
        while end < len(code) and depth:
            depth += (code[end] == '(') - (code[end] == ')')
            end += 1
        if depth == 0 and re.match(r'\s*\??\.', code[end:]):
            findings.append((source.count('\n', 0, match.start()) + 1, match[1]))
    return findings


def main():
    root = Path(__file__).resolve().parents[1]
    failures = []
    files = sorted((root / 'app/src/androidTest').rglob('*.kt'))
    for path in files:
        for line, action in violations(path.read_text()):
            failures.append(f'{path.relative_to(root)}:{line}: {action} returns Unit; use a separate node action')
    if failures:
        raise SystemExit('\n'.join(failures))
    print(f'PASS: {len(files)} Android test files checked for Unit action chains (source preflight only).')


if __name__ == '__main__':
    main()
