#!/usr/bin/env python3
"""
Catches the build breakers that do not need the Android SDK to find.

Release 0.2.2 died in CI on a single line: `sourceLabel`'s `when` over `TimeSource` was not updated
after two entries were added to the enum. Kotlin treats a non-exhaustive `when` used as an
expression as an *error*, and finding that out costs a full Gradle run — 35 s of compile plus a
minute of setup — for information that is visible in the source text.

Checks, all without a compiler:

  1. exhaustive `when`      a `when` used as an expression, branching on enum entries, that misses
                            an entry and has no `else`;
  2. unknown enum entry     `SomeEnum.WHATEVER` where the enum is declared in this project and has
                            no such entry (catches renames and typos);
  3. balanced delimiters    braces, parens and brackets per file (catches a truncated write);
  4. undefined call         a capitalised call with no declaration in the project and no import
                            that could provide it (catches a Composable that was never written).

Exit code 1 on any finding. Meant to run as the first CI step, before Gradle.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from typing import Dict, List, Set, Tuple

KOTLIN_BUILTINS: Set[str] = {
    # Types and functions that are visible without an import.
    "Any", "Array", "Boolean", "Byte", "Char", "CharSequence", "Comparable", "Double", "Enum",
    "Exception", "Float", "IllegalArgumentException", "IllegalStateException", "Int", "Iterable",
    "LinkedHashMap", "List", "Long", "Map", "MutableList", "MutableMap", "MutableSet", "Nothing",
    "Number", "Pair", "RuntimeException", "Set", "Short", "String", "StringBuilder", "Throwable",
    "Triple", "Unit", "ArrayList", "HashMap", "HashSet", "Math", "System", "Thread", "Regex",
    "Result", "Runnable", "Object", "Void", "Error", "Sequence", "Lazy", "Comparator",
    "IndexOutOfBoundsException", "NumberFormatException", "UnsupportedOperationException",
    "FloatArray", "IntArray", "DoubleArray", "LongArray", "BooleanArray", "CharArray",
    "Deprecated", "JvmStatic", "JvmOverloads", "JvmField", "Suppress", "OptIn", "Volatile",
    "Synchronized", "Throws", "SuppressLint", "RequiresApi", "TargetApi", "StringRes", "DrawableRes",
}

STRING_OR_COMMENT = re.compile(
    r'"""(?:.|\n)*?"""|"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'|//[^\n]*|/\*(?:.|\n)*?\*/'
)


def strip_noise(text: str) -> str:
    """Blank out strings and comments, preserving offsets and newlines."""
    def blank(match: re.Match) -> str:
        return "".join("\n" if ch == "\n" else " " for ch in match.group(0))
    return STRING_OR_COMMENT.sub(blank, text)


def line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def kotlin_files(root: str) -> List[str]:
    found = []
    for base, dirs, names in os.walk(root, followlinks=True):
        dirs[:] = [d for d in dirs if d not in {"build", ".git", ".gradle", ".idea"}]
        for name in names:
            if name.endswith(".kt"):
                found.append(os.path.join(base, name))
    return sorted(found)


def matching_brace(text: str, open_index: int) -> int:
    depth = 0
    for i in range(open_index, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return -1


def collect_enums(
    sources: Dict[str, str],
    companions: Dict[str, Set[str]] | None = None,
) -> Dict[str, Set[str]]:
    """enum name -> set of entry names, over the whole project.

    [companions] is filled, if given, with the non-entry members of each enum (companion constants,
    computed properties, helper functions) so that `check_enum_entries` does not mistake them for
    misspelled entries.
    """
    enums: Dict[str, Set[str]] = {}
    if companions is None:
        companions = {}
    pattern = re.compile(r"\benum\s+class\s+(\w+)")
    for path, clean in sources.items():
        for match in pattern.finditer(clean):
            name = match.group(1)
            brace = clean.find("{", match.end())
            if brace < 0:
                continue
            end = matching_brace(clean, brace)
            body = clean[brace + 1:end if end > 0 else len(clean)]
            # Entries are the leading comma-separated list, terminated by ';' or by a member.
            head = re.split(r";", body)[0]
            head = re.split(r"\n\s*(?:(?:public|private|internal|protected)\s+)?"
                            r"(?:override\s+|abstract\s+|open\s+)*(?:fun|val|var|companion|init)\b",
                            head)[0]
            entries = set()
            depth = 0
            token = ""
            for ch in head:
                if ch in "({[":
                    depth += 1
                elif ch in ")}]":
                    depth -= 1
                elif ch == "," and depth == 0:
                    candidate = token.strip().split("(")[0].split("{")[0].strip()
                    if re.fullmatch(r"[A-Z][A-Z0-9_]*", candidate):
                        entries.add(candidate)
                    token = ""
                    continue
                token += ch
            candidate = token.strip().split("(")[0].split("{")[0].strip()
            if re.fullmatch(r"[A-Z][A-Z0-9_]*", candidate):
                entries.add(candidate)
            if entries:
                enums[name] = entries
                # Members declared *inside* the enum are not entries, but `Enum.MEMBER` is legal
                # Kotlin for a companion constant. Without this the checker reported
                # `AzanSound.RAW_RES_ID` — an `Int` in a companion object — as a missing entry, and a
                # checker that cries wolf is a checker people stop reading.
                for member in re.finditer(
                    r"\b(?:const\s+)?(?:val|var)\s+([A-Za-z_]\w*)", body
                ):
                    companions.setdefault(name, set()).add(member.group(1))
                for member in re.finditer(r"\bfun\s+([A-Za-z_]\w*)", body):
                    companions.setdefault(name, set()).add(member.group(1))
    return enums


def collect_declarations(sources: Dict[str, str]) -> Set[str]:
    declared: Set[str] = set()
    pattern = re.compile(
        r"\b(?:class|interface|object|enum\s+class|annotation\s+class|data\s+class|"
        r"value\s+class|sealed\s+class|sealed\s+interface)\s+(\w+)|\bfun\s+(?:<[^>]*>\s*)?(\w+)"
    )
    for clean in sources.values():
        for match in pattern.finditer(clean):
            declared.add(match.group(1) or match.group(2))
    return declared


def check_exhaustive_when(path: str, clean: str, enums: Dict[str, Set[str]]) -> List[str]:
    problems = []
    for match in re.finditer(r"\bwhen\s*\(", clean):
        # Only `when` used as an expression can be non-exhaustive at compile time.
        prefix = clean[max(0, match.start() - 220):match.start()]
        used_as_expression = bool(re.search(r"(=|->|return|\?:)\s*$", prefix.rstrip()))
        brace = clean.find("{", match.end())
        if brace < 0:
            continue
        end = matching_brace(clean, brace)
        if end < 0:
            continue
        body = clean[brace + 1:end]
        if not used_as_expression:
            continue
        if re.search(r"(^|\n)\s*else\s*->", body):
            continue
        referenced: Dict[str, Set[str]] = {}
        for enum_name, entries in enums.items():
            hit = set(re.findall(rf"\b{enum_name}\.([A-Z][A-Z0-9_]*)\b", body))
            # Bare entry names are legal inside `when` on an enum subject; count them too.
            bare = set(re.findall(r"(?:^|\n)\s*([A-Z][A-Z0-9_]*)\s*(?:,\s*[A-Z][A-Z0-9_]*\s*)*->",
                                  body))
            hit |= (bare & entries)
            if hit:
                referenced[enum_name] = hit & entries
        for enum_name, hit in referenced.items():
            missing = enums[enum_name] - hit
            if hit and missing and len(hit) >= max(2, len(enums[enum_name]) // 2):
                problems.append(
                    f"{path}:{line_of(clean, match.start())}: `when` по {enum_name} не покрывает "
                    f"{', '.join(sorted(missing))} и не имеет ветви else"
                )
    return problems


def check_enum_entries(
    path: str,
    clean: str,
    enums: Dict[str, Set[str]],
    companions: Dict[str, Set[str]] | None = None,
) -> List[str]:
    problems = []
    companions = companions or {}
    for enum_name, entries in enums.items():
        for match in re.finditer(rf"\b{enum_name}\.([A-Za-z][A-Za-z0-9_]*)\b", clean):
            member = match.group(1)
            if member in entries or member in companions.get(enum_name, ()):
                continue
            if member in {"entries", "values", "valueOf", "name", "ordinal", "Companion"}:
                continue
            if re.fullmatch(r"[A-Z][A-Z0-9_]*", member):
                problems.append(
                    f"{path}:{line_of(clean, match.start())}: у {enum_name} нет значения {member}"
                )
    return problems


def check_delimiters(path: str, clean: str) -> List[str]:
    pairs = {"{": "}", "(": ")", "[": "]"}
    stack: List[Tuple[str, int]] = []
    for index, ch in enumerate(clean):
        if ch in pairs:
            stack.append((ch, index))
        elif ch in pairs.values():
            if not stack:
                return [f"{path}:{line_of(clean, index)}: лишняя закрывающая {ch}"]
            opener, _ = stack.pop()
            if pairs[opener] != ch:
                return [f"{path}:{line_of(clean, index)}: ждали {pairs[opener]}, нашли {ch}"]
    if stack:
        opener, index = stack[-1]
        return [f"{path}:{line_of(clean, index)}: не закрыта {opener}"]
    return []


def check_undefined_calls(path: str, clean: str, declared: Set[str]) -> List[str]:
    imported = {line.rsplit(".", 1)[-1].strip()
                for line in re.findall(r"^import\s+([\w.]+(?:\.\*)?)", clean, re.M)}
    wildcard = any(name == "*" for name in imported)
    problems = []
    if wildcard:
        return problems
    for match in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\s*\(", clean):
        name = match.group(1)
        if name in declared or name in imported or name in KOTLIN_BUILTINS:
            continue
        problems.append(
            f"{path}:{line_of(clean, match.start())}: {name}(...) не объявлен в проекте "
            f"и не импортирован"
        )
    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default="app/src")
    args = parser.parse_args()

    paths = kotlin_files(args.root)
    if not paths:
        print(f"kt_sanity: не нашёл ни одного .kt под {args.root}", file=sys.stderr)
        return 1

    sources: Dict[str, str] = {}
    for path in paths:
        with open(path, encoding="utf-8") as handle:
            sources[path] = strip_noise(handle.read())

    enum_members: Dict[str, Set[str]] = {}
    enums = collect_enums(sources, enum_members)
    declared = collect_declarations(sources)
    # An enum entry with constructor arguments looks exactly like a call; it is a declaration.
    for entries in enums.values():
        declared |= entries

    problems: List[str] = []
    for path, clean in sources.items():
        problems += check_delimiters(path, clean)
        problems += check_exhaustive_when(path, clean, enums)
        problems += check_enum_entries(path, clean, enums, enum_members)
        problems += check_undefined_calls(path, clean, declared)

    print(f"kt_sanity: {len(paths)} файлов, перечислений {len(enums)}, "
          f"объявлений {len(declared)}")
    if problems:
        print(f"\nНАЙДЕНО {len(problems)}:")
        for line in problems:
            print("  " + line)
        return 1
    print("замечаний нет")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
