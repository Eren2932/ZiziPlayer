#!/usr/bin/env python3
"""
Reproduces KazanCalendarTest on the Python port: the four photographed days of the DUM RT poster,
all seven columns, exact minute equality. Run after any change to CalendarConvention or the root
solver - it is the only test that compares the engine to a printed authority instead of to itself.
"""
import os, sys
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prayer_port import Coordinates, Params, PrayerTimes, ORDER

KAZAN = Coordinates(55.7963, 49.1088)
ZONE = ZoneInfo("Europe/Moscow")
PUBLISHED = {
    15: ["1:11", "2:45", "4:15", "11:47", "16:53", "19:19", "21:34"],
    16: ["1:17", "2:47", "4:17", "11:47", "16:52", "19:17", "21:30"],
    17: ["1:22", "2:49", "4:19", "11:47", "16:50", "19:14", "21:26"],
    18: ["1:27", "2:50", "4:20", "11:47", "16:48", "19:12", "21:22"],
}

def main() -> int:
    params = Params(method="SPIRITUAL_BOARD_TATARSTAN", convention="DUM_RT")
    misses, checked = [], 0
    for day_of_month, expected in sorted(PUBLISHED.items()):
        d = date(2026, 8, day_of_month)
        offset = datetime.combine(d, time(12, 0), ZONE).utcoffset().total_seconds() / 3600.0
        times = PrayerTimes(d, KAZAN, params, offset)
        row = []
        for prayer, printed in zip(ORDER, expected):
            value = times.times[prayer]
            actual = value.astimezone(ZONE).strftime("%H:%M") if value else "--:--"
            target = "%02d:%02d" % tuple(int(x) for x in printed.split(":"))
            checked += 1
            ok = actual == target
            if not ok:
                misses.append(f"{day_of_month}.08 {prayer}: календарь {target}, движок {actual}")
            row.append(("OK " if ok else "!! ") + actual)
        print(f"  {day_of_month}.08  " + "  ".join(row))
    print(f"\nсовпадений {checked - len(misses)} из {checked}")
    for m in misses:
        print("  " + m)
    return 1 if misses else 0

if __name__ == "__main__":
    raise SystemExit(main())
