#!/usr/bin/env python3
"""Numerical cross-checks for the 0.3.0 CI failures, using the existing Python port.

These tests DO NOT execute Kotlin or replace :app:testDebugUnitTest. The altitude
extremum uses fresh solar coordinates, independently of the root interpolation.
Run from the project root: python3 tools/test_build_regressions.py
"""
import math
import unittest
from datetime import date

from prayer_port import (
    Coordinates, Params, PrayerTimes, SolarTime, METHODS, ORDER,
    SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA,
    SEVENTH_OF_THE_NIGHT,
)
from verify_tangency import extremum
from verify_roots import altitude_at


class BuildRegressionTest(unittest.TestCase):
    volgograd = Coordinates(48.7071, 44.5169)
    murmansk = Coordinates(68.9585, 33.0827)

    def twilight(self, method, day=date(2026, 6, 14)):
        params = Params(method=method, high_latitude_rule=SEVENTH_OF_THE_NIGHT,
                        convention="ASTRONOMICAL")
        return PrayerTimes(day, self.volgograd, params, 3.0)

    def assert_order(self, times):
        self.assertEqual([SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA], list(times))
        self.assertTrue(all(v is not None for v in times.values()))
        for previous, current in zip(ORDER, ORDER[1:]):
            if (previous, current) == (SAHAR, FAJR):
                self.assertLessEqual(times[previous], times[current])
            else:
                self.assertLess(times[previous], times[current])

    def test_volgograd_minimum_reaches_17_but_not_18_degrees(self):
        day = date(2026, 6, 14)
        solar = SolarTime(day, self.volgograd, 9.0)
        minimum, _ = extremum(day, self.volgograd, solar.transit + 12)
        self.assertGreater(minimum, -18.0)
        self.assertLess(minimum, -17.0)
        self.assertAlmostEqual(-17.99895191, minimum, places=6)
        self.assertTrue(math.isnan(solar.hour_angle(-18.0, True)))
        root = solar.hour_angle(-17.0, True)
        self.assertTrue(math.isfinite(root))
        # A genuine evening crossing, independently evaluated a minute to each side.
        self.assertGreater(altitude_at(day, self.volgograd, root - 1 / 60), -17.0)
        self.assertLess(altitude_at(day, self.volgograd, root + 1 / 60), -17.0)

    def test_karachi_18_degree_fixture_uses_night_fraction(self):
        self.assertEqual(18.0, METHODS["KARACHI"].isha_angle)
        result = self.twilight("KARACHI")
        self.assertEqual("NIGHT_FRACTION", result.isha_source)
        self.assert_order(result.times)

    def test_mwl_17_degree_counterexample_keeps_real_angle(self):
        self.assertEqual(17.0, METHODS["MUSLIM_WORLD_LEAGUE"].isha_angle)
        result = self.twilight("MUSLIM_WORLD_LEAGUE")
        self.assertEqual("ANGLE", result.isha_source)
        self.assert_order(result.times)

    def test_ust_kamenogorsk_17_degree_boundary_is_preserved(self):
        params = Params(method="MUSLIM_WORLD_LEAGUE", convention="ASTRONOMICAL",
                        high_latitude_rule=SEVENTH_OF_THE_NIGHT)
        coords = Coordinates(49.9787, 82.6014)
        result = PrayerTimes(date(2026, 6, 10), coords, params, 5.0)
        self.assertEqual("NIGHT_FRACTION", result.isha_source)
        self.assert_order(result.times)

    def test_ordinary_august_night_keeps_karachi_angle(self):
        result = self.twilight("KARACHI", date(2026, 8, 20))
        self.assertEqual("ANGLE", result.isha_source)
        self.assert_order(result.times)

    def test_murmansk_fajr_equals_dawn_when_the_gap_is_too_early(self):
        result = PrayerTimes(date(2026, 5, 14), self.murmansk, Params(), 3.0)
        self.assertTrue(result.is_publishable)
        self.assertEqual("DAWN_BOUND", result.fajr_source)
        self.assertEqual(result.times[SAHAR], result.times[FAJR])
        self.assert_order(result.times)

    def test_zero_congregational_gap_does_not_invent_an_extra_minute(self):
        result = PrayerTimes(date(2026, 3, 21), Coordinates(55.7558, 37.6173),
                             Params(congregational_fajr_minutes=0), 3.0)
        self.assertEqual(result.times[SAHAR], result.times[FAJR])
        self.assert_order(result.times)

    def test_polar_donor_shape_contains_seven_ordered_markers(self):
        # Numerically cross-check the noon-offset transplant in PrayerEngine. This is
        # still Python, NOT execution of the Kotlin public API or its JUnit tests.
        from datetime import timedelta
        for day in (date(2026, 6, 21), date(2026, 12, 21)):
            direct = PrayerTimes(day, self.murmansk, Params(), 3.0)
            self.assertFalse(direct.is_publishable)
            donor = None
            for offset in range(1, 184):
                for signed in (-offset, offset):
                    candidate = PrayerTimes(day + timedelta(days=signed), self.murmansk, Params(), 3.0)
                    if candidate.is_publishable:
                        donor = candidate
                        break
                if donor is not None:
                    break
            self.assertIsNotNone(donor)
            times = {p: direct.times[DHUHR] + (value - donor.times[DHUHR])
                     for p, value in donor.times.items()}
            self.assertEqual(7, len(times))
            self.assertEqual(5, len([p for p in times if p not in (SAHAR, SUNRISE)]))
            self.assert_order(times)
            self.assertEqual(day, (times[DHUHR] + timedelta(hours=3)).date())


if __name__ == "__main__":
    unittest.main(verbosity=2)
