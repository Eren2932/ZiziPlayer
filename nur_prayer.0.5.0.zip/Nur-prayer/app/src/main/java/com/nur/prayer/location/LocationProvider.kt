package com.nur.prayer.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.nur.prayer.core.astro.Coordinates
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

sealed interface LocationOutcome {
    data class Fix(
        val coordinates: Coordinates,
        val accuracyMeters: Float,
        val ageMillis: Long,
        val provider: String,
        val timeMillis: Long,
        val fromCache: Boolean = false,
        val precisePermission: Boolean = true
    ) : LocationOutcome

    data object NoPermission : LocationOutcome
    data object LocationDisabled : LocationOutcome
    data object TimedOut : LocationOutcome
    data object Unavailable : LocationOutcome
}

/** Platform GPS, network and fused providers; no dependency on Google Play Services. */
class LocationProvider(private val context: Context) {
    fun hasPrecisePermission(): Boolean = ContextCompat.checkSelfPermission(context,
        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasPermission(): Boolean = hasPrecisePermission() || ContextCompat.checkSelfPermission(context,
        Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(): Boolean = manager()?.let {
        runCatching { LocationManagerCompat.isLocationEnabled(it) }.getOrDefault(false)
    } ?: false

    private fun manager(): LocationManager? = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    @SuppressLint("MissingPermission")
    suspend fun current(forceFresh: Boolean = true): LocationOutcome = withContext(Dispatchers.Main.immediate) {
        if (!hasPermission()) return@withContext LocationOutcome.NoPermission
        val manager = manager() ?: return@withContext LocationOutcome.Unavailable
        if (!isLocationEnabled()) return@withContext LocationOutcome.LocationDisabled
        val precise = hasPrecisePermission()
        val installed = runCatching { manager.allProviders }.getOrDefault(emptyList())
        val providers = listOf("fused", LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { it in installed && (precise || it != LocationManager.GPS_PROVIDER) && enabled(manager, it) }
        // No usable provider is different from the system-wide location switch being off.
        if (providers.isEmpty()) return@withContext LocationOutcome.Unavailable

        val cached = (providers + LocationManager.PASSIVE_PROVIDER).distinct()
            .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
            .filter { usable(it) }
            .minByOrNull { score(it) }
        if (cached != null && LocationFixPolicy.mayUseCacheImmediately(forceFresh, cached.accuracy, age(cached))) {
            return@withContext outcome(cached, fromCache = true, precise = precise)
        }
        val live = race(manager, providers, precise)
        when {
            live is LocationOutcome.Fix -> live // a live fix always outranks an older precise cache
            !hasPermission() -> LocationOutcome.NoPermission
            !isLocationEnabled() -> LocationOutcome.LocationDisabled
            cached != null && usable(cached) -> outcome(cached, fromCache = true, precise = precise)
            else -> live
        }
    }

    private fun enabled(manager: LocationManager, provider: String): Boolean =
        runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)

    /** All registration, callbacks and cleanup are serialized on the main looper. */
    @SuppressLint("MissingPermission")
    private suspend fun race(manager: LocationManager, providers: List<String>, precise: Boolean): LocationOutcome =
        suspendCancellableCoroutine { continuation ->
            val handler = Handler(Looper.getMainLooper())
            val settled = AtomicBoolean(false)
            val started = SystemClock.elapsedRealtimeNanos()
            var best: Location? = null
            var listener: LocationListener? = null
            var deadline: Runnable? = null
            var grace: Runnable? = null

            fun finish(failure: LocationOutcome = LocationOutcome.TimedOut) {
                if (!settled.compareAndSet(false, true)) return
                listener?.let { runCatching { manager.removeUpdates(it) } }
                deadline?.let { handler.removeCallbacks(it) }
                grace?.let { handler.removeCallbacks(it) }
                val result = when {
                    !hasPermission() -> LocationOutcome.NoPermission
                    !isLocationEnabled() -> LocationOutcome.LocationDisabled
                    else -> best?.takeIf { usable(it) }?.let { outcome(it, fromCache = false, precise = precise) } ?: failure
                }
                if (continuation.isActive) continuation.resume(result)
            }

            val racer = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (settled.get() || !usable(location) ||
                        !LocationFixPolicy.isLiveCallback(location.elapsedRealtimeNanos, started, age(location))) return
                    val previous = best
                    if (previous == null || score(location) < score(previous)) best = Location(location)
                    val leader = best ?: return
                    if (leader.accuracy <= LocationFixPolicy.TARGET_ACCURACY_METERS || !precise) {
                        finish()
                    } else if (leader.accuracy <= LocationFixPolicy.ADDRESS_ACCURACY_METERS && grace == null) {
                        // A near-block-level fix gets a short improvement window. A coarse tower
                        // fix keeps waiting for GPS until the full deadline; it must not win early.
                        val task = Runnable { finish() }
                        grace = task
                        handler.postDelayed(task, LocationFixPolicy.NETWORK_GRACE_MILLIS)
                    }
                }
                @Deprecated("Required on older Android versions")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) {
                    if (!isLocationEnabled()) finish(LocationOutcome.LocationDisabled)
                }
            }
            listener = racer
            continuation.invokeOnCancellation { handler.post { finish(LocationOutcome.Unavailable) } }
            if (!continuation.isActive) return@suspendCancellableCoroutine
            val timeout = Runnable { finish() }
            deadline = timeout
            handler.postDelayed(timeout, DEADLINE_MILLIS)
            var registered = false
            providers.forEach { provider ->
                if (!settled.get()) runCatching {
                    manager.requestLocationUpdates(provider, 0L, 0f, racer, Looper.getMainLooper())
                }.onSuccess { registered = true }
            }
            if (!registered) finish(LocationOutcome.Unavailable)
        }

    private fun age(location: Location): Long = LocationFixPolicy.ageMillis(
        SystemClock.elapsedRealtimeNanos(), location.elapsedRealtimeNanos, System.currentTimeMillis(), location.time)

    private fun usable(location: Location): Boolean = location.hasAccuracy() && LocationFixPolicy.usable(
        location.latitude, location.longitude, location.accuracy, age(location))

    private fun score(location: Location): Double = LocationFixPolicy.score(location.accuracy, age(location))

    private fun outcome(location: Location, fromCache: Boolean, precise: Boolean) = LocationOutcome.Fix(
        coordinates = Coordinates(location.latitude, location.longitude), accuracyMeters = location.accuracy,
        ageMillis = age(location), provider = location.provider ?: "система",
        // Persist actual fix age, not an untrusted wall-clock timestamp from before a clock change.
        timeMillis = (System.currentTimeMillis() - age(location)).coerceAtLeast(1L),
        fromCache = fromCache, precisePermission = precise)

    companion object {
        const val DEADLINE_MILLIS = LocationFixPolicy.DEADLINE_MILLIS
    }
}
