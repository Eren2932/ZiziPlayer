package com.nur.prayer.ui.theme

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer

val Ink = Color(0xFF000000)
val InkSoft = Color(0xFF101010)
val Gold = Color(0xFFD1DDCF)
val GoldSoft = Color(0xFFE4EBE2)
val Mint = Color(0xFF9DD6B5)
val Violet = Color(0xFFC0ACFF)
val Azure = Color(0xFF8BCBFF)
val Amber = Color(0xFFE5B97C)
val Rose = Color(0xFFF07C8C)
val Crimson = Color(0xFFF08A93)
val TextPrimary = Color(0xFFF6F7F8)
val TextSecondary = Color(0xFFABABAB)
val TextTertiary = Color(0xFF858585)
val SurfaceRaised = Color(0xFF1B1B1B)
val SurfaceInset = Color(0xFF0B0B0B)
val SurfaceEdge = Color(0xFF292929)
val SystemBar = Ink

@androidx.compose.runtime.Immutable
data class PhasePalette(
    val zenith: Color,
    val mid: Color,
    val horizon: Color,
    val glow: Color,
    val ribbonA: Color,
    val ribbonB: Color,
    val accent: Color,
    val accentSoft: Color,
    val starIntensity: Float,
    val auroraIntensity: Float,
    val name: String
)


private val AmoledPalette = PhasePalette(
    zenith = Ink, mid = Ink, horizon = Ink, glow = Color.Transparent,
    ribbonA = Color.Transparent, ribbonB = Color.Transparent,
    accent = Gold, accentSoft = GoldSoft, starIntensity = 0f, auroraIntensity = 0f, name = "AMOLED"
)

@Suppress("UNUSED_PARAMETER")
fun paletteFor(prayer: Prayer): PhasePalette = AmoledPalette

fun solidTone(accent: Color, amount: Float = 0.16f): Color =
    androidx.compose.ui.graphics.lerp(InkSoft, accent.copy(alpha = 1f), amount.coerceIn(0f, 1f))
