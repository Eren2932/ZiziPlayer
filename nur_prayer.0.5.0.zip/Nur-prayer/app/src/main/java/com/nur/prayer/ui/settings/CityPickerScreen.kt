package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.data.Place
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.Instant
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Immutable
private data class CityResult(val city: City, val utc: String)
private data class SearchState(val query: String = "", val rows: List<CityResult> = emptyList(),
    val loading: Boolean = true, val error: Boolean = false)

/** One scroll container, transparent viewport and content-sized opaque cards, even for one result. */
@Composable
fun CityPickerScreen(
    palette: PhasePalette, selectedCityId: Int, search: suspend (String) -> List<City>,
    onPick: (City) -> Unit, onBack: () -> Unit, onUseLocation: () -> Unit,
    locating: Boolean, locationStatus: String? = null, modifier: Modifier = Modifier,
    currentPlace: Place? = null, locationButtonLabel: String = "Определить местоположение",
    onOpenLocationPermissions: (() -> Unit)? = null
) {
    val ui = uiScale()
    var query by rememberSaveable { mutableStateOf("") }
    val normalized = remember(query) { query.trim().lowercase(Locale.ROOT) }
    val searchFn by rememberUpdatedState(search)
    val keyboard = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    var retry by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf(SearchState()) }
    LaunchedEffect(normalized, retry) {
        result = SearchState(query = normalized)
        if (normalized.isNotEmpty()) delay(80)
        try {
            val rows = withContext(Dispatchers.Default) {
                val cities = searchFn(normalized)
                val instant = Instant.now()
                val offsets = cities.map { it.timeZoneId }.distinct().associateWith {
                    runCatching { CityTimeZones.label(it, instant) }.getOrDefault("UTC?")
                }
                cities.map { CityResult(it, offsets.getValue(it.timeZoneId)) }
            }
            result = SearchState(normalized, rows, loading = false)
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            result = SearchState(normalized, loading = false, error = true)
        }
    }
    var previousQuery by rememberSaveable { mutableStateOf(normalized) }
    LaunchedEffect(normalized) {
        if (previousQuery != normalized) {
            listState.scrollToItem(0)
            previousQuery = normalized
        }
    }
    val busy = result.loading || result.query != normalized
    val usingDeviceLocation = currentPlace?.fromDeviceLocation == true
    Column(modifier.fillMaxSize().background(com.nur.prayer.ui.theme.Ink).navigationBarsPadding().imePadding().padding(horizontal = ui.s(22f))) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { keyboard?.hide(); onBack() }) { Text("‹ Назад", color = palette.accentSoft) }
            Spacer(Modifier.weight(1f))
            Text("Город", color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Medium)
        }
        // Controls scroll too: keyboard, landscape and a large font must not squeeze results out.
        // Never paint the full remaining height as a card; only each actual row has a background.
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().testTag("city-scroll"),
            contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item(key = "search") {
                Row(Modifier.fillMaxWidth().nurPanel(RoundedCornerShape(12.dp), PanelLevel.INSET)
                    .heightIn(min = 52.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Город, регион или страна", color = TextTertiary, fontSize = ui.t(15f))
                        BasicTextField(query, onValueChange = { query = it }, singleLine = true,
                            textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(15f)), cursorBrush = SolidColor(palette.accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
                            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Поиск города" })
                    }
                    if (query.isNotEmpty()) TextButton(onClick = { query = "" },
                        modifier = Modifier.semantics { contentDescription = "Очистить поиск" }) {
                        Text("×", color = TextPrimary)
                    }
                }
            }
            item(key = "locate") {
                NurButton(if (locating) "Определяем координаты…" else locationButtonLabel,
                    palette.accent, { keyboard?.hide(); query = ""; onUseLocation() }, enabled = !locating)
            }
            if (onOpenLocationPermissions != null && normalized.isEmpty()) item(key = "location-permissions") {
                TextButton(onClick = { keyboard?.hide(); onOpenLocationPermissions() }) {
                    Text("Разрешения и точность Android", color = palette.accentSoft, fontSize = ui.t(12f))
                }
            }
            if (currentPlace != null && normalized.isEmpty()) item(key = "current-place") {
                Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)) {
                    Text("Сейчас: ${currentPlace.label}", color = palette.accentSoft, fontSize = ui.t(13f))
                    Text(if (usingDeviceLocation) currentPlace.subtitle else "Город выбран вручную",
                        color = TextTertiary, fontSize = ui.t(11f))
                }
            }
            if (locationStatus != null && normalized.isEmpty()) item(key = "location-status") {
                Text(locationStatus, color = TextSecondary, fontSize = ui.t(12f),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp))
            }
            item(key = "results-caption") {
                Row(Modifier.padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(14.dp), color = palette.accent, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(when {
                        busy -> "Поиск…"
                        result.error -> "Не удалось открыть базу городов"
                        normalized.isEmpty() -> "Города"
                        else -> "Найдено: ${result.rows.size}"
                    }, color = TextSecondary, fontSize = ui.t(12f))
                }
            }
            when {
                busy -> Unit // never let stale matches be selected while a new query is running
                result.error -> item(key = "error") {
                    Column(Modifier.fillMaxWidth().nurPanel(RoundedCornerShape(12.dp)).padding(16.dp)) {
                        Text("Не удалось прочитать базу. Повторите загрузку; текущий город и настройки сохранены.", color = TextSecondary)
                        TextButton(onClick = { retry++ }) { Text("Повторить", color = palette.accentSoft) }
                    }
                }
                result.rows.isEmpty() -> item(key = "empty") {
                    Text("Совпадений нет. Попробуйте часть названия, регион или страну.",
                        color = TextSecondary, fontSize = ui.t(14f),
                        modifier = Modifier.fillMaxWidth().nurPanel(RoundedCornerShape(12.dp)).padding(16.dp).testTag("city-empty"))
                }
                else -> items(result.rows, key = { it.city.id }, contentType = { "city" }) { row ->
                    CityRow(row, selected = row.city.id == selectedCityId && !usingDeviceLocation,
                        nearby = row.city.id == selectedCityId && usingDeviceLocation, accent = palette.accent) {
                        keyboard?.hide()
                        onPick(it)
                    }
                }
            }
        }
    }
}

@Composable
private fun CityRow(row: CityResult, selected: Boolean, nearby: Boolean, accent: Color, onPick: (City) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().background(if (selected) com.nur.prayer.ui.theme.InkSoft else Color.Transparent)
            .selectable(selected = selected, role = Role.RadioButton, onClick = { onPick(row.city) })
            .heightIn(min = 76.dp).testTag("city-row-${row.city.id}")
            .padding(horizontal = 8.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(row.city.name, color = if (selected) accent else TextPrimary, fontSize = ui.t(17f),
                    fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(row.city.subtitle, color = TextSecondary, fontSize = ui.t(12f), maxLines = 2,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(row.utc, color = TextSecondary, fontSize = ui.t(12f), fontFamily = FontFamily.Monospace)
                if (selected || nearby) Text(if (selected) "✓" else "Рядом", color = accent, fontSize = ui.t(12f))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(com.nur.prayer.ui.theme.SurfaceEdge))
    }
}
