package com.nur.prayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette

@Suppress("UNUSED_PARAMETER")
@Composable
fun NightSky(palette: PhasePalette, modifier: Modifier = Modifier, motionEnabled: Boolean = false) {
    Box(modifier.fillMaxSize().background(Ink))
}
