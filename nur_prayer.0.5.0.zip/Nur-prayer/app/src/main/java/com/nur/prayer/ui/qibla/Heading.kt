package com.nur.prayer.ui.qibla

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.view.Surface
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/** Which sensor stack produced the current reading. */
enum class HeadingSource {
    /** Accelerometer + gyroscope + magnetometer, fused by the platform. The good one. */
    FUSED,

    /** Accelerometer + magnetometer fused by the platform (no gyroscope on this device). */
    GEOMAGNETIC,

    /** Raw accelerometer + magnetometer, fused by us. Noisier, still correct. */
    RAW,

    /** No usable sensors. */
    NONE
}

/**
 * Device heading, in degrees clockwise from **true** north.
 *
 * Everything that makes a phone compass wrong is handled here explicitly:
 *
 *  - **Magnetic vs true north.** The magnetometer points at magnetic north. Across Russia the
 *    declination runs from about +8° in Kaliningrad to +20° in Yakutia, and it is negative in parts
 *    of the west. We add the WMM correction from [GeomagneticField] for the user's own coordinates.
 *    Without it the Qibla arrow is off by a whole sector.
 *  - **Screen rotation.** Sensor axes are tied to the *natural* orientation of the device, not to
 *    what you see. On a landscape-natural tablet, or with the screen rotated, a naive reading is off
 *    by 90°. We remap the rotation matrix through the current display rotation.
 *  - **Tilt.** `getOrientation` is only meaningful while the device is roughly flat; held upright it
 *    degenerates (gimbal lock at pitch ±90°). When we detect the phone is being held up, we remap
 *    the matrix (AXIS_X, AXIS_Z) so the azimuth becomes "where the back of the phone looks" — the
 *    reading the user actually expects — and we still report [tiltDegrees] so the UI can ask for a
 *    flatter hold.
 *  - **Wrap-around.** Smoothing 359° and 1° arithmetically gives 180°. We low-pass the *unit
 *    vector* (sin, cos) instead of the angle, so there is no discontinuity anywhere on the circle.
 *  - **Interference.** Earth's field is 25–65 µT. A speaker magnet, a car dashboard or a metal table
 *    pushes the magnitude out of that band; we detect it and say so instead of silently lying.
 *  - **Calibration state.** `SENSOR_STATUS_ACCURACY_*` of the magnetometer is surfaced, with the
 *    figure-eight hint.
 */
@androidx.compose.runtime.Immutable
data class Heading(
    /** Degrees clockwise from true north. */
    val azimuth: Float = 0f,
    /** Raw reading before the declination correction, for the diagnostics panel. */
    val magneticAzimuth: Float = 0f,
    /** WMM declination at the user's coordinates, degrees east. */
    val declination: Float = 0f,
    /** SensorManager.SENSOR_STATUS_ACCURACY_*, -1 when unknown. */
    val accuracy: Int = -1,
    /** Angle between the screen plane and the horizontal plane, degrees. 0 = perfectly flat. */
    val tiltDegrees: Float = 0f,
    /** Measured magnetic field magnitude, µT. 0 when unknown. */
    val fieldStrength: Float = 0f,
    val source: HeadingSource = HeadingSource.NONE
) {
    val available: Boolean get() = source != HeadingSource.NONE

    /** True when the field magnitude is outside the plausible band for Earth's field. */
    val interference: Boolean
        get() = fieldStrength > 1f && (fieldStrength < 22f || fieldStrength > 72f)

    /** True while the phone is held flat enough for the reading to be first-class. */
    val heldFlat: Boolean get() = tiltDegrees <= 30f

    /** Everything is calibrated, undisturbed and level. */
    val trustworthy: Boolean
        get() = available && !interference && accuracy >= SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM
}

@Composable
fun rememberHeading(latitude: Double, longitude: Double): Heading {
    val context = LocalContext.current
    var heading by remember { mutableStateOf(Heading()) }
    val lifecycleState by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val active = lifecycleState.isAtLeast(Lifecycle.State.RESUMED)

    DisposableEffect(latitude, longitude, context, active) {
        if (!active) return@DisposableEffect onDispose { }
        val manager = context.getSystemService(SensorManager::class.java)
        val declination = runCatching {
            GeomagneticField(
                latitude.toFloat(),
                longitude.toFloat(),
                0f,
                System.currentTimeMillis()
            ).declination
        }.getOrDefault(0f)

        if (manager == null) {
            heading = Heading(declination = declination, source = HeadingSource.NONE)
            return@DisposableEffect onDispose { }
        }

        // Never show a stale lock after resuming or changing coordinates. Wait for a fresh sample.
        heading = Heading(declination = declination)
        val rotationSensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val geomagneticSensor = manager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)
        val magnetSensor = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val accelSensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val vectorSensor = rotationSensor ?: geomagneticSensor
        val source = when {
            rotationSensor != null -> HeadingSource.FUSED
            geomagneticSensor != null -> HeadingSource.GEOMAGNETIC
            magnetSensor != null && accelSensor != null -> HeadingSource.RAW
            else -> HeadingSource.NONE
        }

        if (source == HeadingSource.NONE) {
            heading = Heading(declination = declination, source = HeadingSource.NONE)
            return@DisposableEffect onDispose { }
        }

        val filter = HeadingFilter()
        val rotationMatrix = FloatArray(9)
        val displayMatrix = FloatArray(9)
        val finalMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        val gravity = FloatArray(3)
        val geomagnetic = FloatArray(3)
        var hasGravity = false
        var hasGeomagnetic = false
        var fieldStrength = 0f
        var magnetAccuracy = -1
        var lastEmit = 0L

        fun publish(magneticAzimuth: Float, tilt: Float) {
            val trueAzimuth = normalize(magneticAzimuth + declination)
            val smoothed = filter.push(trueAzimuth)
            val now = android.os.SystemClock.elapsedRealtime()
            val changed = abs(angleDelta(heading.azimuth, smoothed)) > 0.12f
            // 30 Hz publication cap; the UI interpolates between samples. Monotonic timing.
            if (!changed && now - lastEmit < 250L) return
            if (now - lastEmit < 33L) return
            lastEmit = now
            heading = Heading(
                azimuth = smoothed,
                magneticAzimuth = normalize(magneticAzimuth),
                declination = declination,
                accuracy = magnetAccuracy,
                tiltDegrees = tilt,
                fieldStrength = fieldStrength,
                source = source
            )
        }

        /** Turns a device->world rotation matrix into (azimuth, tilt), handling screen and hold. */
        fun fromRotationMatrix(matrix: FloatArray) {
            // Screen rotation: sensor axes follow the natural orientation of the device.
            val (axisX, axisY) = displayAxes(context)
            if (!SensorManager.remapCoordinateSystem(matrix, axisX, axisY, displayMatrix)) {
                displayMatrix.indices.forEach { displayMatrix[it] = matrix[it] }
            }

            // Tilt: angle between the screen plane and the horizon. matrix[8] is the vertical
            // component of the device Z axis, so acos() of it is exactly that angle.
            val vertical = displayMatrix[8].coerceIn(-1f, 1f)
            val tilt = Math.toDegrees(acos(vertical).toDouble()).toFloat()

            val upright = tilt > 55f
            val active = if (upright) {
                // Held up like a camera: read where the back of the phone looks.
                if (SensorManager.remapCoordinateSystem(
                        displayMatrix,
                        SensorManager.AXIS_X,
                        SensorManager.AXIS_Z,
                        finalMatrix
                    )
                ) {
                    finalMatrix
                } else {
                    displayMatrix
                }
            } else {
                displayMatrix
            }

            SensorManager.getOrientation(active, orientation)
            val azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
            publish(azimuth, tilt)
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when (event.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR,
                    Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                        if (source == HeadingSource.FUSED &&
                            event.sensor.type == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR
                        ) {
                            return
                        }
                        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                        fromRotationMatrix(rotationMatrix)
                    }

                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        geomagnetic[0] = event.values[0]
                        geomagnetic[1] = event.values[1]
                        geomagnetic[2] = event.values[2]
                        hasGeomagnetic = true
                        fieldStrength = sqrt(
                            event.values[0] * event.values[0] +
                                event.values[1] * event.values[1] +
                                event.values[2] * event.values[2]
                        )
                        if (source == HeadingSource.RAW && hasGravity) {
                            if (SensorManager.getRotationMatrix(
                                    rotationMatrix, null, gravity, geomagnetic
                                )
                            ) {
                                fromRotationMatrix(rotationMatrix)
                            }
                        }
                    }

                    Sensor.TYPE_ACCELEROMETER -> {
                        // Light low-pass: gravity only, without the hand shake.
                        gravity[0] = gravity[0] * 0.82f + event.values[0] * 0.18f
                        gravity[1] = gravity[1] * 0.82f + event.values[1] * 0.18f
                        gravity[2] = gravity[2] * 0.82f + event.values[2] * 0.18f
                        hasGravity = true
                        if (source == HeadingSource.RAW && hasGeomagnetic) {
                            if (SensorManager.getRotationMatrix(
                                    rotationMatrix, null, gravity, geomagnetic
                                )
                            ) {
                                fromRotationMatrix(rotationMatrix)
                            }
                        }
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                if (sensor?.type == Sensor.TYPE_MAGNETIC_FIELD ||
                    sensor?.type == Sensor.TYPE_ROTATION_VECTOR ||
                    sensor?.type == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR
                ) {
                    magnetAccuracy = accuracy
                    heading = heading.copy(accuracy = accuracy)
                }
            }
        }

        if (vectorSensor != null) {
            manager.registerListener(listener, vectorSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        // The magnetometer is always registered: it is our interference and calibration probe.
        if (magnetSensor != null) {
            manager.registerListener(listener, magnetSensor, SensorManager.SENSOR_DELAY_UI)
        }
        if (source == HeadingSource.RAW && accelSensor != null) {
            manager.registerListener(listener, accelSensor, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose { manager.unregisterListener(listener) }
    }

    return heading
}

/** Axis pair that maps sensor space to what the user currently sees. */
internal fun displayAxes(context: Context): Pair<Int, Int> {
    val rotation = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(WindowManager::class.java)?.defaultDisplay?.rotation
                ?: Surface.ROTATION_0
        }
    }.getOrDefault(Surface.ROTATION_0)

    return when (rotation) {
        Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
        Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
        Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
        else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
    }
}
