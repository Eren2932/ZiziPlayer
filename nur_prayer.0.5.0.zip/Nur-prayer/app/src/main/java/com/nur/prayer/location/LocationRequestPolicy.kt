package com.nur.prayer.location

enum class LocationRequestStep(val buttonLabel: String) {
    LOCATE("Определить местоположение"),
    REQUEST_PERMISSION("Разрешить местоположение"),
    OPEN_APP_SETTINGS("Открыть разрешения приложения"),
    OPEN_LOCATION_SETTINGS("Включить геолокацию")
}

/** A granted approximate permission is usable; never force a user to grant precise access. */
object LocationRequestPolicy {
    fun next(hasPermission: Boolean, askedBefore: Boolean, showRationale: Boolean, locationEnabled: Boolean): LocationRequestStep = when {
        !hasPermission && askedBefore && !showRationale -> LocationRequestStep.OPEN_APP_SETTINGS
        !hasPermission -> LocationRequestStep.REQUEST_PERMISSION
        !locationEnabled -> LocationRequestStep.OPEN_LOCATION_SETTINGS
        else -> LocationRequestStep.LOCATE
    }
}
