package com.nur.prayer.ui

import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver

internal const val TAB_HOME = "home"
internal const val TAB_SCHEDULE = "schedule"
internal const val TAB_QIBLA = "qibla"
internal const val TAB_SETTINGS = "settings"
internal const val ROUTE_CITY = "city"
internal val TABS = listOf(TAB_HOME, TAB_SCHEDULE, TAB_QIBLA, TAB_SETTINGS)

/** Bounded, validated history. Restored together with each route's saveable UI state. */
@Stable
internal class NurNavigator(initial: String = TAB_HOME, history: List<String> = emptyList()) {
    var current by mutableStateOf(initial.takeIf { it in TABS || it == ROUTE_CITY } ?: TAB_HOME)
        private set
    private val stack = mutableStateListOf<String>().apply {
        addAll(history.filter { (it in TABS || it == ROUTE_CITY) && it != current }.distinct().takeLast(12))
        if (current == ROUTE_CITY && isEmpty()) add(TAB_HOME)
    }
    val canGoBack get() = stack.isNotEmpty()
    val selectedTab get() = if (current in TABS) current else stack.lastOrNull { it in TABS } ?: TAB_HOME
    val isOverlay get() = current !in TABS
    fun go(destination: String) {
        if (destination == current || (destination !in TABS && destination != ROUTE_CITY)) return
        stack.remove(destination)
        stack.add(current)
        while (stack.size > 12) stack.removeAt(0)
        current = destination
    }
    fun back(): Boolean {
        if (stack.isEmpty()) return false
        current = stack.removeAt(stack.lastIndex)
        return true
    }
    fun snapshot(): List<String> = listOf(current) + stack
    companion object {
        val Saver = listSaver<NurNavigator, String>(save = { it.snapshot() },
            restore = { NurNavigator(it.firstOrNull() ?: TAB_HOME, it.drop(1)) })
    }
}
