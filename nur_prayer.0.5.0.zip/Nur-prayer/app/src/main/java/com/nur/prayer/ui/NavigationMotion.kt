package com.nur.prayer.ui

object NavigationMotion {
    const val TAB_ENTER_MILLIS = 180
    const val DETAIL_ENTER_MILLIS = 280
    const val EXIT_MILLIS = 140
    const val DETAIL_EXIT_MILLIS = 210
    const val EDITOR_ENTER_MILLIS = 240
    const val DOCK_MILLIS = 200
}
