package com.nur.prayer.core.astro

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.floor

/** Geographic coordinates in decimal degrees. */
data class Coordinates(val latitude: Double, val longitude: Double)

/** Apparent solar coordinates for a given Julian Day. */
internal class SolarCoordinates(julianDay: Double) {
    /** Apparent declination of the Sun, degrees. */
    val declination: Double

    /** Apparent right ascension of the Sun, degrees. */
    val rightAscension: Double

    /** Apparent sidereal time at Greenwich, degrees. */
    val apparentSiderealTime: Double

    init {
        val t = julianCentury(julianDay)
        val l0 = meanSolarLongitude(t)
        val lp = meanLunarLongitude(t)
        val omega = ascendingLunarNodeLongitude(t)
        val lambda = apparentSolarLongitude(t, l0)
        val theta0 = meanSiderealTime(t)
        val dPsi = nutationInLongitude(l0, lp, omega)
        val dEpsilon = nutationInObliquity(l0, lp, omega)
        val epsilon0 = meanObliquityOfTheEcliptic(t)
        val epsilonApparent = apparentObliquityOfTheEcliptic(t, epsilon0)

        declination = dasin(epsilonApparent.dsin() * lambda.dsin())
        rightAscension = unwindAngle(datan2(epsilonApparent.dcos() * lambda.dsin(), lambda.dcos()))
        apparentSiderealTime = theta0 + (dPsi * 3600 * (epsilon0 + dEpsilon).dcos()) / 3600
    }
}

/**
 * Solar events for one calendar day at a given location.
 * All values are hours of UTC counted from 00:00 UTC of [date]; [Double.NaN] when the event
 * does not happen (polar day / polar night).
 *
 * [anchorHours] says where local noon sits in that frame (12 - UTC offset). It is not a nicety.
 * [approximateTransit] returns a fraction of the *UTC* day, which is ambiguous by exactly one day
 * wherever a place's solar noon falls near the UTC day boundary. Anadyr, longitude 177.5 in UTC+12,
 * sits within a minute of it: the fraction came back as 0.9997 on 1-4 December 2026 and as 0.0003
 * from the 5th, so the entire frame - transit, sunrise, dawn, Isha - jumped a day back and forth.
 * On 4 December that produced a "tomorrow's sunrise" earlier than "today's sunset", a negative
 * night length, and a day whose seven markers collapsed into three minutes around sunrise.
 * Choosing the transit nearest to local noon pins the frame to the day the user is looking at, and
 * every event is then computed from the Sun's position on that day. Verified against a brute-force
 * altitude scan: exact to the second for Anadyr across the whole transition.
 */
internal class SolarTime(
    date: LocalDate,
    private val coordinates: Coordinates,
    anchorHours: Double = 12.0
) {

    companion object {
        private const val LIMIT = 96

        private data class CacheKey(
            val date: LocalDate,
            val coordinates: Coordinates,
            val anchorHours: Double
        )

        private val cache = object : LinkedHashMap<CacheKey, SolarTime>(LIMIT, 0.75f, true) {
            override fun removeEldestEntry(
                eldest: MutableMap.MutableEntry<CacheKey, SolarTime>
            ): Boolean = size > LIMIT
        }
        private val lock = Any()

        /**
         * Consecutive days share solar coordinates: computing day N needs day N+1 as well, so a
         * fourteen-day schedule asks for every date twice and each request costs three full
         * nutation / obliquity evaluations. Memoising here halves the trigonometry outright.
         */
        fun of(
            date: LocalDate,
            coordinates: Coordinates,
            anchorHours: Double = 12.0
        ): SolarTime {
            val key = CacheKey(date, coordinates, anchorHours)
            synchronized(lock) { cache[key] }?.let { return it }
            val value = SolarTime(date, coordinates, anchorHours)
            synchronized(lock) { cache[key] = value }
            return value
        }
    }

    private val previous: SolarCoordinates
    private val solar: SolarCoordinates
    private val next: SolarCoordinates
    private val approximateTransit: Double

    /** Solar noon. */
    val transit: Double
    val sunrise: Double
    val sunset: Double

    init {
        val jd = julianDay(date.year, date.monthValue, date.dayOfMonth)
        previous = SolarCoordinates(jd - 1)
        solar = SolarCoordinates(jd)
        next = SolarCoordinates(jd + 1)
        val rawTransit = approximateTransit(
            coordinates.longitude, solar.apparentSiderealTime, solar.rightAscension
        )
        // Shift by whole days so the transit is the one closest to local noon.
        approximateTransit = rawTransit + floor(anchorHours / 24.0 - rawTransit + 0.5)
        // Standard refraction + solar disc correction for sunrise/sunset.
        val solarAltitude = -50.0 / 60.0

        transit = correctedTransit(
            approximateTransit, coordinates.longitude, solar.apparentSiderealTime,
            solar.rightAscension, previous.rightAscension, next.rightAscension
        )
        sunrise = hourAngle(solarAltitude, afterTransit = false)
        sunset = hourAngle(solarAltitude, afterTransit = true)
    }

    fun hourAngle(angle: Double, afterTransit: Boolean): Double = correctedHourAngle(
        approximateTransit, angle, coordinates.latitude, coordinates.longitude, afterTransit,
        solar.apparentSiderealTime, solar.rightAscension, previous.rightAscension, next.rightAscension,
        solar.declination, previous.declination, next.declination
    )

    /**
     * Time when the shadow of an object reaches [shadowLength] times its own height
     * (1x = Shafi'i/Maliki/Hanbali Asr, 2x = Hanafi Asr).
     */
    fun afternoon(shadowLength: Double): Double {
        val tangent = abs(coordinates.latitude - solar.declination)
        val inverse = shadowLength + tangent.dtan()
        val angle = Math.toDegrees(atan(1.0 / inverse))
        return hourAngle(angle, afterTransit = true)
    }
}
