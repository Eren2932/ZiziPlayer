package com.nur.prayer.ui.schedule

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun MonthCalendar(
    month: YearMonth, selected: LocalDate, today: LocalDate, hijriOffset: Int,
    palette: PhasePalette, onMonth: (YearMonth) -> Unit, onSelect: (LocalDate) -> Unit,
    onToday: () -> Unit, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val base = YearMonth.from(today)
    val min = base.minusMonths(12)
    val max = base.plusMonths(12)
    val changeMonth by rememberUpdatedState(onMonth)
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onToday, contentPadding = PaddingValues(0.dp), modifier = Modifier.testTag("calendar-today")) {
                Text("Сегодня", color = palette.accent, fontSize = ui.t(13f))
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { onMonth(month.minusMonths(1)) }, enabled = month > min,
                contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)
                    .semantics { contentDescription = "Предыдущий месяц" }) {
                Text("‹", color = if (month > min) TextPrimary else TextTertiary, fontSize = ui.t(28f))
            }
            TextButton(onClick = { onMonth(month.plusMonths(1)) }, enabled = month < max,
                contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)
                    .semantics { contentDescription = "Следующий месяц" }) {
                Text("›", color = if (month < max) TextPrimary else TextTertiary, fontSize = ui.t(28f))
            }
        }
        AutoSizeText(Format.monthYear(month.atDay(1)), color = TextPrimary, fontSize = ui.t(32f),
            fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth().testTag("calendar-month"))
        val startHijri = remember(month, hijriOffset) { HijriCalendar.monthAndYear(month.atDay(1), hijriOffset) }
        val endHijri = remember(month, hijriOffset) { HijriCalendar.monthAndYear(month.atEndOfMonth(), hijriOffset) }
        Text(if (startHijri == endHijri) startHijri else "$startHijri — $endHijri", color = TextSecondary,
            fontSize = ui.t(11f), modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEachIndexed { i, label ->
                Text(label, color = if (i == 4) palette.accent else TextSecondary, fontSize = ui.t(12f),
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        AnimatedContent(targetState = month, transitionSpec = {
            val direction = if (targetState > initialState) 1 else -1
            ((slideInHorizontally(tween(220)) { it / 8 * direction } + fadeIn(tween(180))) togetherWith
                (slideOutHorizontally(tween(160)) { -it / 8 * direction } + fadeOut(tween(140)))).using(null)
        }, label = "calendarMonth", modifier = Modifier.fillMaxWidth().testTag("calendar-grid")
            .pointerInput(month, min, max) {
                var distance = 0f
                detectHorizontalDragGestures(onDragStart = { distance = 0f }, onDragCancel = { distance = 0f },
                    onHorizontalDrag = { change, amount -> change.consume(); distance += amount },
                    onDragEnd = {
                        val threshold = 48.dp.toPx()
                        if (distance < -threshold && month < max) changeMonth(month.plusMonths(1))
                        if (distance > threshold && month > min) changeMonth(month.minusMonths(1))
                    })
            }) { visibleMonth ->
            val cells = remember(visibleMonth) {
                val original = CalendarMonthModel.cells(visibleMonth)
                List(42) { original.first().plusDays(it.toLong()) }
            }
            Column {
                cells.chunked(7).forEach { week ->
                    Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        week.forEach { date ->
                            val inMonth = YearMonth.from(date) == visibleMonth
                            val active = date == selected && inMonth
                            val isToday = date == today
                            val hijri = remember(date, hijriOffset) { HijriCalendar.dayOfMonth(date, hijriOffset) }
                            val label = remember(date, hijriOffset, isToday) {
                                "${Format.fullDate(date)}, ${HijriCalendar.format(date, hijriOffset)}" + if (isToday) ", сегодня" else ""
                            }
                            val shape = RoundedCornerShape(8.dp)
                            Column(Modifier.weight(1f).height(50.dp).padding(horizontal = 1.dp).clip(shape)
                                .background(if (active) palette.accent else Color.Transparent)
                                .border(1.dp, if (isToday && !active && inMonth) palette.accent else Color.Transparent, shape)
                                .selectable(selected = active, enabled = inMonth, role = Role.Button, onClick = { onSelect(date) })
                                .semantics(mergeDescendants = true) { contentDescription = label }
                                .testTag("calendar-day-$date"), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Text(date.dayOfMonth.toString(), fontSize = ui.t(17f),
                                    fontWeight = if (active || isToday) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (active) Ink else if (inMonth) TextPrimary else TextTertiary.copy(alpha = 0.5f))
                                Text(hijri.toString(), fontSize = ui.t(10f), color = if (active) Ink.copy(alpha = 0.8f)
                                    else if (inMonth) TextSecondary else TextTertiary.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
            }
        }
    }
}
