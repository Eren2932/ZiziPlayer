package com.nur.prayer.ui

import java.time.LocalDate
import java.time.ZonedDateTime

/** The date can roll over before the next prayer. Manual clock changes can also leave the window. */
object TimelinePolicy {
    fun needsRefresh(now: ZonedDateTime, displayedDate: LocalDate,
        currentStart: ZonedDateTime, nextStart: ZonedDateTime): Boolean =
        now.withZoneSameInstant(nextStart.zone).toLocalDate() != displayedDate ||
            now.isBefore(currentStart) || !now.isBefore(nextStart)
}
