package com.nur.prayer.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nur.prayer.MainActivity
import com.nur.prayer.R
import com.nur.prayer.core.astro.Prayer

object NotificationHelper {

    /** Silent: [AzanPlayerService] is making the sound and owns the Stop button. */
    const val CHANNEL_AZAN_MUTE = "nur.azan.mute.v2"

    /** Carries the recording itself. Used only when the service could not be started. */
    const val CHANNEL_AZAN_SOUND = "nur.azan.sound.v2"

    /** The phone's own notification sound. */
    const val CHANNEL_AZAN_SYSTEM = "nur.azan.system.v2"

    /** Low-importance channel for the ongoing "adhan is playing" notification. */
    const val CHANNEL_AZAN_PLAYING = "nur.azan.playing.v2"

    const val CHANNEL_PRE = "nur.pre_alert"

    private fun azanUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${AzanSound.RAW_RES_ID}")

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        // USAGE_ALARM, not USAGE_NOTIFICATION: on the notification stream a three-minute adhan is
        // mixed with the ringtone volume and is routinely inaudible on a phone in a bag.
        val alarmAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val vibration = longArrayOf(0, 350, 250, 350)

        val mute = NotificationChannel(
            CHANNEL_AZAN_MUTE, "Время намаза", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Наступление времени намаза. Азан проигрывает само приложение."
            enableVibration(true)
            vibrationPattern = vibration
            setSound(null, null)
        }

        val withAzan = NotificationChannel(
            CHANNEL_AZAN_SOUND, "Время намаза — азан", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Резервный канал: азан играет системой, если приложение остановлено."
            enableVibration(true)
            vibrationPattern = vibration
            setSound(azanUri(context), alarmAttributes)
        }

        val system = NotificationChannel(
            CHANNEL_AZAN_SYSTEM, "Время намаза — системный звук", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Обычный звук уведомления телефона в момент намаза."
            enableVibration(true)
            vibrationPattern = vibration
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }

        val playing = NotificationChannel(
            CHANNEL_AZAN_PLAYING, "Азан играет", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Пока звучит азан — с кнопкой «Остановить»."
            enableVibration(false)
            setSound(null, null)
        }

        val pre = NotificationChannel(
            CHANNEL_PRE, "Напоминание заранее", NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Предупреждение за несколько минут до намаза"
            enableVibration(true)
        }

        listOf(mute, withAzan, system, playing, pre).forEach(manager::createNotificationChannel)

        // Channels from 0.2.6 whose sound can no longer be changed. Leaving them in place would show
        // the user three stale entries in system notification settings and, worse, keep whatever
        // sound they had.
        listOf("nur.adhan", "nur.silent").forEach { legacy ->
            runCatching { manager.deleteNotificationChannel(legacy) }
        }
    }

    fun canPost(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else true

    fun notifyPrayer(
        context: Context,
        prayer: Prayer,
        timeText: String,
        placeName: String,
        isPreAlert: Boolean,
        minutesBefore: Int,
        sound: AzanSound
    ) {
        if (!canPost(context)) return

        val title = if (isPreAlert) {
            "${PrayerLabels.title(prayer)} через $minutesBefore мин"
        } else {
            "${PrayerLabels.title(prayer)} · $timeText"
        }
        val text = if (isPreAlert) {
            "Начало в $timeText · $placeName"
        } else {
            "Наступило время намаза · $placeName"
        }

        // The player is tried first; only its refusal turns the sound over to the system.
        val playerStarted = !isPreAlert && AzanPlayerService.play(context, title, text, sound)

        val channel = when {
            isPreAlert -> CHANNEL_PRE
            playerStarted -> CHANNEL_AZAN_MUTE
            sound.playsAzan -> CHANNEL_AZAN_SOUND
            sound == AzanSound.SYSTEM -> CHANNEL_AZAN_SYSTEM
            else -> CHANNEL_AZAN_MUTE
        }

        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText(PrayerLabels.arabic(prayer))
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n${PrayerLabels.hint(prayer)}"))
            .setPriority(if (isPreAlert) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(contentIntent)
            .build()

        runCatching {
            NotificationManagerCompat.from(context)
                .notify(prayer.ordinal + if (isPreAlert) 100 else 0, notification)
        }
    }
}
