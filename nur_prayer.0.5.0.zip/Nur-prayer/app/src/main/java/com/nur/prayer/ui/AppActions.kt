package com.nur.prayer.ui

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.notify.AzanSound

/** Everything the screens can ask the host activity / view model to do. */
/*
 * `@Immutable` because it is: function references, assembled once and never mutated. Without
 * the annotation Compose treats a bag of lambdas as unstable, and Settings — which takes this as a
 * parameter — could not be skipped on any recomposition of the root.
 */
@androidx.compose.runtime.Immutable
data class AppActions(
    val openCityPicker: () -> Unit,
    val requestLocation: () -> Unit,
    val openExactAlarmSettings: () -> Unit,
    val openBatterySettings: () -> Unit,
    val openNotificationSettings: () -> Unit,
    /** null hands the choice back to the country of the place. */
    val setMethod: (CalculationMethod?) -> Unit,
    val setMadhab: (Madhab) -> Unit,
    val setHighLatitudeRule: (HighLatitudeRule) -> Unit,
    val setRounding: (RoundingMode) -> Unit,
    val setNotification: (Prayer, Boolean) -> Unit,
    val setOffset: (Prayer, Int) -> Unit,
    val setPreAlert: (Int) -> Unit,
    val setAzanSound: (AzanSound) -> Unit,
    /** Plays the recording so the choice can be heard before it wakes anybody at four in the morning. */
    val previewAzan: (AzanSound) -> Unit,
    val stopAzan: () -> Unit,
    val setHijriOffset: (Int) -> Unit,
    val openLocationPermissions: () -> Unit = {}
)
