package com.nur.prayer.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.data.PlaceResolver
import com.nur.prayer.location.LocationAddressResolver
import com.nur.prayer.location.LocationFixPolicy
import com.nur.prayer.location.LocationOutcome
import com.nur.prayer.location.LocationProvider
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.notify.PrayerAlarmScheduler
import java.time.LocalDate
import java.time.ZonedDateTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.transformLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Everything the screens need, computed once per settings change. */
@androidx.compose.runtime.Immutable
data class PrayerData(
    val place: Place,
    val days: List<PrayerDay>,
    val window: PrayerWindow,
    val qibla: Double,
    val kaabaDistanceKm: Double,
    val hijri: String,
    val settings: AppSettings,
    /** Which regional calendar produced these times, and how well it is verified. */
    val profile: com.nur.prayer.core.astro.RegionalProfile,
    /** The parameters actually used, override and country default already resolved. */
    val params: com.nur.prayer.core.astro.PrayerParams
) {
    val today: PrayerDay get() = days.first()

    /** True when the tradition of this place has no separate congregational Fajr. */
    val fajrEqualsDawn: Boolean
        get() = params.fajrBeforeSunriseMinutes == 0
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val settingsRepository = Graph.settings(application)
    private val cityRepository = Graph.cities(application)
    private val locationProvider = LocationProvider(application)
    private val addressResolver = LocationAddressResolver(application)
    private var locationJob: Job? = null
    private var locationGeneration = 0L
    private var lastLocationAttemptElapsed: Long? = null
    private var automaticLocationSuppressed = false
    private var resumeLocationRequest = false

    private val refreshTrigger = MutableStateFlow(0)
    private val foreground = MutableStateFlow(false)

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val data: StateFlow<PrayerData?> = combine(settingsRepository.settings, refreshTrigger) { s, _ -> s }
        .transformLatest { s ->
            // Fast first emission, then the two-week schedule. transformLatest prevents an older
            // settings computation from publishing after a newer selection has arrived.
            emit(withContext(Dispatchers.Default) { compute(s, FIRST_PAINT_DAYS) })
            emit(withContext(Dispatchers.Default) { compute(s, DAYS_AHEAD) })
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _now = MutableStateFlow(ZonedDateTime.now())
    val now: StateFlow<ZonedDateTime> = _now.asStateFlow()

    private val _locating = MutableStateFlow(false)
    val locating: StateFlow<Boolean> = _locating.asStateFlow()

    /**
     * The last thing location has to say, or null when there is nothing to report.
     *
     * 0.2.5 had no such channel: a refusal from the system looked exactly like a success that had
     * not arrived yet, so the only feedback was the button becoming pressable again. Now every
     * branch produces a sentence — including the good one, which states the radius, because a fix
     * the user cannot judge is a fix the user has to trust blindly.
     */
    private val _locationStatus = MutableStateFlow<String?>(null)
    val locationStatus: StateFlow<String?> = _locationStatus.asStateFlow()
    private val _locationStep = MutableStateFlow(LocationRequestStep.LOCATE)
    val locationStep: StateFlow<LocationRequestStep> = _locationStep.asStateFlow()

    init {
        // One-second heartbeat drives the countdown; it also rolls the prayer window over.
        //
        // Two details that matter for smoothness. First, the tick is aligned to the wall-clock
        // second instead of sleeping a flat 1000 ms: a flat delay drifts by the cost of the work
        // done in between, so the visible seconds occasionally skipped or repeated a digit.
        // Second, the value is only published when the displayed second actually changes, so a
        // resumed screen no longer recomposes the whole tree on a value identical to the last one.
        viewModelScope.launch {
            var lastSecond = Long.MIN_VALUE
            var lastRefreshKey: Pair<java.time.Instant, LocalDate>? = null
            while (isActive) {
                foreground.first { it }
                val snapshot = data.value
                val zone = snapshot?.place?.zone
                val current = if (zone != null) ZonedDateTime.now(zone) else ZonedDateTime.now()
                val second = current.toEpochSecond()
                if (second != lastSecond) {
                    lastSecond = second
                    _now.value = current
                }
                if (snapshot != null && TimelinePolicy.needsRefresh(current, snapshot.today.date,
                        snapshot.window.currentStart, snapshot.window.nextStart)) {
                    val key = snapshot.window.nextStart.toInstant() to snapshot.today.date
                    if (key != lastRefreshKey) {
                        lastRefreshKey = key
                        refreshTrigger.value += 1
                    }
                } else {
                    lastRefreshKey = null
                }
                delay(1_000L - System.currentTimeMillis() % 1_000L)
            }
        }
        // Refresh only an opted-in device location, only in the foreground. No background
        // permission or continuous GPS tracking. Stored settings may arrive after onResume.
        viewModelScope.launch {
            combine(settings, foreground) { s, active -> s to active }.collectLatest { (s, active) ->
                if (active && s.useDeviceLocation) {
                    while (isActive) {
                        refreshLocationIfNeeded()
                        delay(LocationFixPolicy.AUTO_REFRESH_MILLIS)
                    }
                }
            }
        }
        // Keep the alarm chain in sync with the settings at all times.
        viewModelScope.launch {
            settingsRepository.settings.collect { s ->
                withContext(Dispatchers.Default) {
                    PrayerAlarmScheduler.reschedule(app, s)
                }
            }
        }
    }

    /**
     * @param days how many days to compute. The first emission asks for [FIRST_PAINT_DAYS] and the
     * next one for [DAYS_AHEAD]: the home screen needs today and tomorrow, the schedule needs two
     * weeks, and making the very first frame wait for fourteen days of Newton iterations was
     * costing a visible "Считаем солнце…" on cold start.
     */
    private fun compute(settings: AppSettings, days: Int): PrayerData {
        val place = PlaceResolver.resolve(app, settings)
        val params = settings.paramsFor(place.country)
        val today = LocalDate.now(place.zone)
        val computed = PrayerEngine.days(today, days, place.coordinates, place.zone, params)
        val window = PrayerEngine.window(
            ZonedDateTime.now(place.zone), place.coordinates, place.zone, params
        )
        return PrayerData(
            place = place,
            profile = settings.profileFor(place.country),
            params = params,
            days = computed,
            window = window,
            qibla = qiblaBearing(place.coordinates),
            kaabaDistanceKm = distanceToKaabaKm(place.coordinates),
            hijri = HijriCalendar.format(today, settings.hijriOffset),
            settings = settings
        )
    }

    suspend fun cities(query: String): List<City> = withContext(Dispatchers.Default) {
        cityRepository.search(query)
    }

    fun setForeground(value: Boolean) {
        foreground.value = value
        if (value) {
            _now.value = data.value?.place?.zone?.let { ZonedDateTime.now(it) } ?: ZonedDateTime.now()
            if (resumeLocationRequest) useDeviceLocation(forceFresh = true)
        } else {
            if (_locating.value) {
                resumeLocationRequest = true
                _locationStatus.value = "Запрос приостановлен до возврата в приложение; прежнее место сохранено."
            } else if (locationJob?.isActive == true) {
                _locationStatus.value = _locationStatus.value?.removeSuffix(" Уточняем адрес…")
            }
            cancelLocationRequest()
        }
    }

    fun selectCity(city: City) {
        // Immediate intent guard: DataStore publication is asynchronous. A periodic refresh
        // must not start in the gap between this tap and the saved manual-city setting.
        automaticLocationSuppressed = true
        resumeLocationRequest = false
        cancelLocationRequest()
        _locationStatus.value = null
        _locationStep.value = LocationRequestStep.LOCATE
        viewModelScope.launch { settingsRepository.setCity(city) }
    }

    fun hasLocationPermission(): Boolean = locationProvider.hasPermission()
    fun isLocationEnabled(): Boolean = locationProvider.isLocationEnabled()

    fun locationNeedsAction(step: LocationRequestStep, message: String) {
        _locationStep.value = step
        _locationStatus.value = message
    }

    private fun cancelLocationRequest() {
        locationGeneration++
        locationJob?.cancel()
        locationJob = null
        _locating.value = false
    }

    fun useDeviceLocation(forceFresh: Boolean = true) {
        if (_locating.value) return
        if (forceFresh) automaticLocationSuppressed = false
        resumeLocationRequest = false
        cancelLocationRequest() // cancel an optional old geocoder before starting a newer fix
        val generation = locationGeneration
        lastLocationAttemptElapsed = SystemClock.elapsedRealtime()
        _locating.value = true
        _locationStep.value = LocationRequestStep.LOCATE
        _locationStatus.value = "Ищем свежую точку: GPS, сеть и системная геолокация…"
        locationJob = viewModelScope.launch {
            try {
                when (val outcome = locationProvider.current(forceFresh)) {
                    is LocationOutcome.Fix -> {
                        val nearest = withContext(Dispatchers.Default) { cityRepository.nearest(outcome.coordinates) }
                        if (generation != locationGeneration) return@launch
                        // Apply coordinates FIRST. A slow/unavailable address service must never
                        // keep the calculation on Moscow or snap a GPS fix to a city centre.
                        settingsRepository.setDeviceLocation(
                            latitude = outcome.coordinates.latitude, longitude = outcome.coordinates.longitude,
                            nearestCityId = nearest.id, accuracyMeters = outcome.accuracyMeters.toDouble(),
                            fixedAtMillis = outcome.timeMillis)
                        if (generation != locationGeneration) return@launch
                        val summary = buildString {
                            append("${if (outcome.fromCache) "Последняя доступная точка" else "Местоположение определено"}: ${nearest.name}, ±${outcome.accuracyMeters.toInt()} м")
                            append(" (${providerName(outcome.provider)}")
                            if (outcome.fromCache) append(", ${outcome.ageMillis / 1000} с назад")
                            append(").")
                            if (!outcome.precisePermission) append(" Разрешена приблизительная геолокация. Для улицы и дома включите «Точное местоположение» в разрешениях Android.")
                        }
                        _locating.value = false
                        _locationStatus.value = "$summary Уточняем адрес…"
                        val address = try {
                            addressResolver.resolve(outcome.coordinates)?.let {
                                // A coarse point must not present somebody else's street/index as
                                // the user's address. Locality remains useful at city-level accuracy.
                                if (!LocationFixPolicy.mayDescribeStreet(outcome.precisePermission, outcome.accuracyMeters))
                                    it.copy(detail = null, postalCode = null) else it
                            }
                        } catch (cancel: CancellationException) { throw cancel }
                        catch (_: Exception) { null }
                        if (generation != locationGeneration) return@launch
                        val savedAddress = try {
                            if (address != null) settingsRepository.setLocationAddress(
                                outcome.coordinates.latitude, outcome.coordinates.longitude,
                                outcome.timeMillis, address.locality, address.detail, address.postalCode)
                            address
                        } catch (cancel: CancellationException) { throw cancel }
                        catch (_: Exception) { null } // coordinates were already committed successfully
                        if (generation != locationGeneration) return@launch
                        _locationStatus.value = buildString {
                            append(summary)
                            val details = listOfNotNull(savedAddress?.locality, savedAddress?.detail,
                                savedAddress?.postalCode?.let { "индекс $it" }).distinct()
                            if (details.isNotEmpty()) append(" Адрес по системному сервису: ${details.joinToString(", ")}.")
                            else append(" Адрес и индекс недоступны; расписание уже рассчитано по полученным координатам.")
                        }
                    }
                    LocationOutcome.NoPermission -> locationNeedsAction(LocationRequestStep.REQUEST_PERMISSION,
                        "Нет разрешения на местоположение. Нажмите кнопку, чтобы выдать доступ. Прежнее место сохранено.")
                    LocationOutcome.LocationDisabled -> locationNeedsAction(LocationRequestStep.OPEN_LOCATION_SETTINGS,
                        "Геолокация выключена в Android. Нажмите «Включить геолокацию»: после возврата запрос продолжится автоматически. Прежнее место сохранено.")
                    LocationOutcome.TimedOut -> locationNeedsAction(LocationRequestStep.LOCATE,
                        "За ${LocationProvider.DEADLINE_MILLIS / 1000} с не удалось получить свежую точку. Попробуйте у окна, проверьте Wi-Fi и точность геолокации Android. Прежнее место сохранено.")
                    LocationOutcome.Unavailable -> locationNeedsAction(LocationRequestStep.LOCATE,
                        "Нет доступного источника координат. Проверьте системную геолокацию и разрешения или выберите город вручную. Прежнее место сохранено.")
                }
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Exception) {
                if (generation == locationGeneration) locationNeedsAction(LocationRequestStep.LOCATE,
                    "Не удалось обновить местоположение. Прежнее место сохранено; повторите запрос.")
            } finally {
                if (generation == locationGeneration) _locating.value = false
            }
        }
    }

    private fun refreshLocationIfNeeded() {
        if (!foreground.value || _locating.value || automaticLocationSuppressed) return
        val current = settings.value
        if (!current.useDeviceLocation || !locationProvider.hasPermission() || !locationProvider.isLocationEnabled()) return
        val age = current.locationFixedAtMillis?.let { System.currentTimeMillis() - it }
        val lastAttempt = lastLocationAttemptElapsed
        val mayRetry = lastAttempt == null || SystemClock.elapsedRealtime() - lastAttempt >= LocationFixPolicy.AUTO_REFRESH_MILLIS
        if (mayRetry && (age == null || age < 0L || age >= LocationFixPolicy.AUTO_REFRESH_MILLIS)) {
            useDeviceLocation(forceFresh = false)
        }
    }

    private fun providerName(provider: String): String = when (provider) {
        "gps" -> "спутники"
        "network" -> "сеть"
        "fused" -> "система"
        "passive" -> "кэш системы"
        else -> provider
    }

    fun refresh() {
        refreshTrigger.value += 1
        refreshLocationIfNeeded()
    }

    val repository get() = settingsRepository

    fun onPermissionsChanged() = viewModelScope.launch {
        withContext(Dispatchers.Default) { PrayerAlarmScheduler.reschedule(app) }
    }

    fun setNotification(prayer: Prayer, enabled: Boolean) =
        viewModelScope.launch { settingsRepository.setNotification(prayer, enabled) }

    fun setOffset(prayer: Prayer, minutes: Int) =
        viewModelScope.launch { settingsRepository.setOffset(prayer, minutes) }

    companion object {
        const val DAYS_AHEAD = 14

        /** Today, tomorrow and one spare — everything the home screen can possibly show. */
        const val FIRST_PAINT_DAYS = 3
    }
}
