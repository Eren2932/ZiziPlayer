package com.nur.prayer.notify

import com.nur.prayer.R

/**
 * What the phone does at the moment a prayer time arrives.
 *
 * The recording bundled in `res/raw` is the adhan of Mohammad Bashir, re-encoded to mono 48 kbit/s
 * at 32 kHz — 1.26 MB for three and a half minutes. The original stereo 212 kbit/s file was 5.9 MB,
 * which is two thirds of the whole APK for audio that is played through a phone speaker.
 *
 * [limitSeconds] is why there is no second audio file: the short option is the same recording
 * stopped early with a fade, so "short" costs zero bytes.
 */
enum class AzanSound(
    val title: String,
    val explanation: String,
    /** 0 = play to the end. */
    val limitSeconds: Int,
    val playsAzan: Boolean
) {
    AZAN_FULL(
        "Азан полностью",
        "Голос муэдзина, 3:35. В уведомлении есть кнопка «Остановить».",
        limitSeconds = 0,
        playsAzan = true
    ),
    AZAN_SHORT(
        "Начало азана",
        "Первые 25 секунд с плавным затуханием — слышно, но не на весь дом.",
        limitSeconds = 25,
        playsAzan = true
    ),
    SYSTEM(
        "Системный звук",
        "Обычный звук уведомления телефона.",
        limitSeconds = 0,
        playsAzan = false
    ),
    SILENT(
        "Без звука",
        "Только вибрация и уведомление на экране.",
        limitSeconds = 0,
        playsAzan = false
    );

    companion object {
        val RAW_RES_ID: Int = R.raw.azan_bashir
    }
}
