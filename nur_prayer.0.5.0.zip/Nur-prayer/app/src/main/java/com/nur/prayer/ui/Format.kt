package com.nur.prayer.ui

import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime

object Format {

    private val weekdays = arrayOf(
        "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"
    )
    private val weekdaysShort = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val monthsGenitive = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )

    fun time(value: ZonedDateTime): String =
        String.format(java.util.Locale.getDefault(), "%02d:%02d", value.hour, value.minute)

    /** "1:04:37" while more than an hour is left, otherwise "04:37". */
    fun countdown(duration: Duration): String {
        val total = CountdownMath.secondsRemaining(duration)
        val hours = total / 3600
        val minutes = (total % 3600) / 60
        val seconds = total % 60
        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun shortCountdown(duration: Duration): String {
        val total = duration.seconds.coerceAtLeast(0)
        val hours = total / 3600
        val minutes = (total % 3600) / 60
        return when {
            hours > 0 -> "через ${hours} ч ${minutes} мин"
            minutes > 0 -> "через ${minutes} мин"
            else -> "меньше минуты"
        }
    }

    fun weekday(date: LocalDate): String = weekdays[date.dayOfWeek.value - 1]

    fun weekdayShort(date: LocalDate): String = weekdaysShort[date.dayOfWeek.value - 1]

    fun dayMonth(date: LocalDate): String = "${date.dayOfMonth} ${monthsGenitive[date.monthValue - 1]}"

    fun fullDate(date: LocalDate): String = "${weekday(date)}, ${dayMonth(date)}"

    private val monthsNominative = arrayOf(
        "январь", "февраль", "март", "апрель", "май", "июнь",
        "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"
    )

    /** "август 2026" for the calendar header. */
    fun monthYear(date: LocalDate): String =
        "${monthsNominative[date.monthValue - 1]} ${date.year}"

    /** Minutes of difference, signed and human: "+2 мин", "-1 мин", "так же". */
    fun signedMinutes(minutes: Long): String = when {
        minutes > 0 -> "+$minutes мин"
        minutes < 0 -> "$minutes мин"
        else -> "без изменений"
    }

    /** "8 ч 42 мин" for a duration of daylight. */
    fun hoursMinutes(duration: Duration): String {
        val total = duration.seconds.coerceAtLeast(0)
        return "${total / 3600} ч ${(total % 3600) / 60} мин"
    }
}
