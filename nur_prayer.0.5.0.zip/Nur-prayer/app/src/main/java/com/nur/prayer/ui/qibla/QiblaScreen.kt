package com.nur.prayer.ui.qibla

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.KaabaIcon
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun QiblaScreen(
    data: PrayerData, palette: PhasePalette, modifier: Modifier = Modifier,
    headingOverride: Heading? = null
) {
    val ui = uiScale()
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val heading = headingOverride ?: rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val usable = heading.available && heading.trustworthy && heading.heldFlat && delta.isFinite()
    val aligned = QiblaGuidance.aligned(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    val markColor by animateColorAsState(if (aligned) Mint else TextPrimary, tween(220), label = "qiblaMark")
    var rotationTarget by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(heading.azimuth, usable) {
        if (usable) rotationTarget = nearestDialRotation(rotationTarget, heading.azimuth)
    }
    val rotation = animateFloatAsState(rotationTarget, tween(90), label = "qiblaRotation")
    val instruction = QiblaGuidance.instruction(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val warning = when {
        !heading.available -> "На устройстве нет доступного датчика направления. Используйте азимут кыблы по карте или другому компасу."
        heading.interference -> "Отойдите от металла, магнитного чехла и динамиков."
        !heading.trustworthy -> "Проведите телефоном «восьмёркой» для калибровки."
        !heading.heldFlat -> "Держите телефон экраном вверх."
        else -> null
    }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f)),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Кыбла", color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f))
            AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(13f), maxLines = 2,
                textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
        }
        Spacer(Modifier.height(if (ui.compact) 12.dp else 28.dp))
        Box(Modifier.widthIn(max = if (ui.compact) 270.dp else 330.dp).fillMaxWidth().aspectRatio(1f)
            .testTag("qibla-instrument").semantics {
                stateDescription = if (aligned) "Направление найдено" else if (usable) "Поиск направления" else "Нет достоверного направления"
            }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension * 0.43f
                if (r < 4f) return@Canvas
                drawCircle(SurfaceEdge, r, style = Stroke(1.dp.toPx()))
                drawLine(TextSecondary, Offset(center.x, center.y - r - 8.dp.toPx()),
                    Offset(center.x, center.y - r + 4.dp.toPx()), 2.dp.toPx(), StrokeCap.Round)
            }
            if (usable) {
                Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation.value + qibla }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension * 0.43f
                        val tip = Offset(center.x, center.y - r * 0.60f)
                        drawLine(markColor, Offset(center.x, center.y + r * 0.24f), tip, 3.dp.toPx(), StrokeCap.Round)
                        val arrow = Path().apply {
                            moveTo(tip.x - 9.dp.toPx(), tip.y + 12.dp.toPx())
                            lineTo(tip.x, tip.y)
                            lineTo(tip.x + 9.dp.toPx(), tip.y + 12.dp.toPx())
                        }
                        drawPath(arrow, markColor, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                    }
                    KaabaIcon(markColor, Modifier.align(Alignment.TopCenter).padding(top = 28.dp).size(28.dp)
                        .graphicsLayer { rotationZ = -rotation.value - qibla }
                        .semantics { contentDescription = "Кааба — направление кыблы" })
                }
            } else {
                KaabaIcon(TextTertiary, Modifier.size(38.dp).semantics { contentDescription = "Кааба — направление кыблы" })
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(if (usable) "${abs(delta).roundToInt()}°" else "—", color = markColor,
            fontSize = ui.t(52f), fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
        AutoSizeText(instruction, color = if (aligned) Mint else TextSecondary, fontSize = ui.t(15f),
            maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        if (warning != null) Text(warning, color = Amber, fontSize = ui.t(12f), lineHeight = ui.t(18f),
            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(30.dp))
        InfoRow("Азимут кыблы", QiblaGuidance.degrees(qibla))
        InfoRow("До Каабы", "${data.kaabaDistanceKm.roundToInt()} км")
        Box(Modifier.fillMaxWidth().padding(top = 16.dp).height(1.dp).background(SurfaceEdge))
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
            .clickable(role = Role.Button, onClick = { showDetails = !showDetails })
            .semantics { stateDescription = if (showDetails) "Развёрнуто" else "Свёрнуто" },
            verticalAlignment = Alignment.CenterVertically) {
            Text("Точность и датчики", color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
            Text(if (showDetails) "−" else "+", color = palette.accent, fontSize = ui.t(22f))
        }
        AnimatedVisibility(showDetails) {
            Column {
                InfoRow("Курс устройства", if (heading.available) QiblaGuidance.degrees(heading.azimuth) else "—")
                InfoRow("Магнитный курс", if (heading.available) QiblaGuidance.degrees(heading.magneticAzimuth) else "—")
                InfoRow("Магнитная поправка", "${heading.declination.roundToInt()}°")
                InfoRow("Наклон", if (heading.available) "${heading.tiltDegrees.roundToInt()}°" else "—")
                InfoRow("Магнитное поле", if (heading.fieldStrength > 0f) "${heading.fieldStrength.roundToInt()} мкТл" else "—")
                InfoRow("Калибровка", when (heading.accuracy) {
                    3 -> "Высокая"
                    2 -> "Средняя"
                    1 -> "Низкая"
                    else -> "Не определена"
                })
                InfoRow("Датчики", when (heading.source) {
                    HeadingSource.FUSED -> "Гироскоп, магнитометр"
                    HeadingSource.GEOMAGNETIC -> "Магнитометр, акселерометр"
                    HeadingSource.RAW -> "Сырые показания"
                    HeadingSource.NONE -> "Недоступны"
                })
                Text("Азимут отсчитывается от истинного севера. Магнитная поправка учтена. Зелёный указатель — отклонение не более 2,5° по показаниям датчика, а не гарантия его точности.",
                    color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f), modifier = Modifier.padding(top = 12.dp))
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
        Spacer(Modifier.width(16.dp))
        AutoSizeText(value, color = TextPrimary, fontSize = ui.t(14f), maxLines = 2,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
