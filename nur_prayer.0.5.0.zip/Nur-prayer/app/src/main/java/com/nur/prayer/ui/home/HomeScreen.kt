package com.nur.prayer.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

@Composable
fun HomeScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    onOpenCity: () -> Unit, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f))) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(role = Role.Button, onClickLabel = "Выбрать город", onClick = onOpenCity)
                .heightIn(min = 48.dp).padding(vertical = 6.dp)) {
                AutoSizeText(data.place.label + "  ›", color = TextPrimary, fontSize = ui.t(22f),
                    minFontSize = ui.t(16f), fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth())
                Text(Format.dayMonth(data.today.date), color = TextSecondary, fontSize = ui.t(12f))
            }
            Spacer(Modifier.width(16.dp))
            AutoSizeText(data.hijri, color = TextSecondary, fontSize = ui.t(12f), minFontSize = ui.t(10f),
                textAlign = TextAlign.End, maxLines = 2, modifier = Modifier.weight(0.8f))
        }
        CountdownRing(
            data.window.currentStart.toInstant().toEpochMilli(), data.window.nextStart.toInstant().toEpochMilli(),
            now, palette.accent, palette.accentSoft,
            Modifier.fillMaxWidth().height(if (ui.compact) 236.dp else 280.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("До ${PrayerLabels.title(data.window.next)}", color = palette.accent, fontSize = ui.t(18f))
                Spacer(Modifier.height(14.dp))
                CountdownReadout(data.window, now)
                Spacer(Modifier.height(12.dp))
                Text("Начало в ${Format.time(data.window.nextStart)}", color = TextSecondary, fontSize = ui.t(14f))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Сегодня", color = TextPrimary, fontSize = ui.t(21f), fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(PrayerLabels.title(data.window.current), color = TextSecondary, fontSize = ui.t(12f))
        }
        Prayer.entries.forEachIndexed { index, prayer ->
            if (index > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
            PrayerRow(prayer, data.today.times[prayer]?.let { Format.time(it) } ?: "—",
                prayer == data.window.next, data.settings.notifications[prayer] == true, palette.accent)
        }
        data.today.note?.let {
            Text(it, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(18f),
                modifier = Modifier.padding(top = 20.dp))
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

@Composable
private fun CountdownReadout(window: PrayerWindow, now: State<ZonedDateTime>) {
    val ui = uiScale()
    val text = Format.countdown(window.remaining(now.value))
    AutoSizeText(text, color = TextPrimary, fontSize = ui.t(66f), minFontSize = ui.t(32f),
        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Light, textAlign = TextAlign.Center,
        letterSpacing = ui.t(-3f), resizeKey = text.length,
        modifier = Modifier.fillMaxWidth().clearAndSetSemantics {
            contentDescription = "До ${PrayerLabels.title(window.next)}: $text"
        })
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, next: Boolean, notify: Boolean, accent: Color) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().heightIn(min = 58.dp).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(22.dp).background(if (next) accent else Color.Transparent))
        Spacer(Modifier.width(12.dp))
        Text(PrayerLabels.title(prayer), color = if (next) accent else TextPrimary,
            fontSize = ui.t(16f), fontWeight = if (next) FontWeight.Medium else FontWeight.Normal,
            modifier = Modifier.weight(1f))
        if (prayer.isPrayer && !notify) {
            Canvas(Modifier.width(16.dp).height(16.dp).semantics { contentDescription = "Уведомление выключено" }) {
                val w = size.width
                val h = size.height
                val bell = Path().apply {
                    moveTo(w * 0.22f, h * 0.72f)
                    lineTo(w * 0.3f, h * 0.38f)
                    quadraticBezierTo(w * 0.5f, 0f, w * 0.7f, h * 0.38f)
                    lineTo(w * 0.78f, h * 0.72f)
                    close()
                }
                drawPath(bell, TextTertiary, style = Stroke(1.dp.toPx()))
                drawLine(TextTertiary, Offset(w * 0.12f, h * 0.12f), Offset(w * 0.9f, h * 0.9f), 1.dp.toPx(), StrokeCap.Round)
            }
            Spacer(Modifier.width(14.dp))
        }
        Text(time, color = if (next) accent else TextPrimary, fontSize = ui.t(23f), fontFamily = FontFamily.Monospace)
    }
}
