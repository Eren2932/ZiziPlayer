package com.nur.prayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised

enum class PanelLevel { RAISED, FLAT, INSET }

@Suppress("UNUSED_PARAMETER")
fun Modifier.nurPanel(shape: Shape, level: PanelLevel = PanelLevel.RAISED, accent: Color? = null): Modifier {
    val fill = when (level) {
        PanelLevel.RAISED -> InkSoft
        PanelLevel.FLAT -> SurfaceRaised
        PanelLevel.INSET -> SurfaceInset
    }
    return clip(shape).background(fill)
}

@Composable
fun AtlasPanel(
    modifier: Modifier = Modifier, corner: Dp = 16.dp, contentPadding: Dp = 16.dp,
    level: PanelLevel = PanelLevel.RAISED, accent: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.nurPanel(RoundedCornerShape(corner), level, accent).padding(contentPadding), content = content)
}
