package com.nur.prayer.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.PlaceResolver
import kotlinx.coroutines.flow.first
import java.time.ZonedDateTime

/**
 * Exact, chained alarms.
 *
 * Android does not let an app keep dozens of exact alarms alive reliably, so we always keep
 * exactly ONE pending alarm: the next event. When it fires, the receiver posts the notification
 * and immediately schedules the following one. Boot, time-zone change, settings change and every
 * app launch re-arm the chain, so it self-heals.
 */
object PrayerAlarmScheduler {

    private const val REQUEST_CODE = 7710
    const val EXTRA_PRAYER = "prayer"
    const val EXTRA_TIME = "time_text"
    const val EXTRA_PLACE = "place"
    const val EXTRA_PRE = "pre_alert"
    const val EXTRA_PRE_MINUTES = "pre_minutes"

    suspend fun reschedule(context: Context) {
        val settings = Graph.settings(context).settings.first()
        reschedule(context, settings)
    }

    fun reschedule(context: Context, settings: AppSettings) {
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        val place = PlaceResolver.resolve(context, settings)
        val now = ZonedDateTime.now(place.zone)

        data class Event(val prayer: Prayer, val at: ZonedDateTime, val isPre: Boolean, val target: ZonedDateTime)

        val events = ArrayList<Event>()
        PrayerEngine.upcoming(
            now, place.coordinates, place.zone, settings.paramsFor(place.country), limit = 24
        )
            .forEach { (prayer, time) ->
                if (settings.notifications[prayer] != true) return@forEach
                events.add(Event(prayer, time, false, time))
                val pre = settings.preAlertMinutes
                if (pre > 0 && prayer.isPrayer) {
                    val preTime = time.minusMinutes(pre.toLong())
                    if (preTime.isAfter(now)) events.add(Event(prayer, preTime, true, time))
                }
            }

        val next = events.minByOrNull { it.at } ?: run { cancel(context); return }

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.nur.prayer.PRAYER_ALARM"
            putExtra(EXTRA_PRAYER, next.prayer.name)
            putExtra(EXTRA_TIME, formatTime(next.target))
            putExtra(EXTRA_PLACE, place.label)
            putExtra(EXTRA_PRE, next.isPre)
            putExtra(EXTRA_PRE_MINUTES, settings.preAlertMinutes)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = next.at.toInstant().toEpochMilli()

        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else true

        runCatching {
            if (canExact) {
                // AlarmClock alarms survive Doze and battery saver on every OEM skin we tested.
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(triggerAt, pendingIntent),
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.nur.prayer.PRAYER_ALARM"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return false
        return alarmManager.canScheduleExactAlarms()
    }

    private fun formatTime(time: ZonedDateTime): String =
        String.format(java.util.Locale.getDefault(), "%02d:%02d", time.hour, time.minute)
}
