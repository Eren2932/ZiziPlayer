package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.theme.SurfaceEdge
import java.time.ZonedDateTime

@Suppress("UNUSED_PARAMETER")
@Composable
fun CountdownRing(
    startMillis: Long, endMillis: Long, now: State<ZonedDateTime>, accent: Color,
    accentSoft: Color, modifier: Modifier = Modifier, stroke: Dp = 2.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            if (size.minDimension < 8f) return@Canvas
            val progress = CountdownMath.progress(startMillis, endMillis, now.value.toInstant().toEpochMilli())
            val y = size.height - stroke.toPx()
            drawLine(SurfaceEdge, Offset(0f, y), Offset(size.width, y), stroke.toPx(), StrokeCap.Round)
            if (progress > 0f) drawLine(accent, Offset(0f, y), Offset(size.width * progress, y), stroke.toPx(), StrokeCap.Round)
        }
        content()
    }
}
