package com.nur.prayer.core.astro

import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * Low-level astronomical helpers, following Jean Meeus, "Astronomical Algorithms" (2nd ed.).
 * All public functions work in DEGREES, unless stated otherwise.
 */

internal fun Double.dsin(): Double = sin(Math.toRadians(this))
internal fun Double.dcos(): Double = cos(Math.toRadians(this))
internal fun Double.dtan(): Double = tan(Math.toRadians(this))
internal fun dasin(x: Double): Double = Math.toDegrees(asin(x))
internal fun dacos(x: Double): Double = Math.toDegrees(acos(x))
internal fun datan2(y: Double, x: Double): Double = Math.toDegrees(atan2(y, x))

internal fun normalizeWithBound(value: Double, max: Double): Double =
    value - max * floor(value / max)

internal fun unwindAngle(angle: Double): Double = normalizeWithBound(angle, 360.0)

internal fun quadrantShiftAngle(angle: Double): Double =
    if (angle >= -180.0 && angle <= 180.0) angle
    else angle - 360.0 * Math.round(angle / 360.0)

/** Julian Day for a Gregorian calendar date (Meeus 7.1). */
internal fun julianDay(year: Int, month: Int, day: Int, hours: Double = 0.0): Double {
    val y = if (month > 2) year else year - 1
    val m = if (month > 2) month else month + 12
    val d = day + hours / 24.0
    val a = floor(y / 100.0)
    val b = 2 - a + floor(a / 4.0)
    return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
}

/** Julian centuries since the J2000.0 epoch (Meeus 22.1). */
internal fun julianCentury(jd: Double): Double = (jd - 2451545.0) / 36525.0

/** Geometric mean longitude of the Sun, degrees (Meeus 25.2). */
internal fun meanSolarLongitude(t: Double): Double =
    unwindAngle(280.4664567 + t * (36000.76983 + t * 0.0003032))

/** Mean longitude of the Moon, degrees (Meeus 47.1). */
internal fun meanLunarLongitude(t: Double): Double =
    unwindAngle(218.3165 + 481267.8813 * t)

/** Longitude of the ascending node of the lunar orbit, degrees (Meeus 47.7). */
internal fun ascendingLunarNodeLongitude(t: Double): Double = unwindAngle(
    125.04452 - 1934.136261 * t + 0.0020708 * t * t + (t * t * t) / 450000.0
)

/** Mean anomaly of the Sun, degrees (Meeus 25.3). */
internal fun meanSolarAnomaly(t: Double): Double =
    unwindAngle(357.52911 + t * (35999.05029 - 0.0001537 * t))

/** Equation of the center of the Sun, degrees (Meeus p. 164). */
internal fun solarEquationOfTheCenter(t: Double, meanAnomaly: Double): Double {
    val m = meanAnomaly
    return m.dsin() * (1.914602 - t * (0.004817 + 0.000014 * t)) +
        (2 * m).dsin() * (0.019993 - t * 0.000101) +
        (3 * m).dsin() * 0.000289
}

/** Apparent longitude of the Sun, degrees (Meeus 25.10). */
internal fun apparentSolarLongitude(t: Double, meanLongitude: Double): Double {
    val trueLongitude = meanLongitude + solarEquationOfTheCenter(t, meanSolarAnomaly(t))
    val omega = 125.04 - 1934.136 * t
    return unwindAngle(trueLongitude - 0.00569 - 0.00478 * omega.dsin())
}

/** Mean obliquity of the ecliptic, degrees (Meeus 22.2). */
internal fun meanObliquityOfTheEcliptic(t: Double): Double =
    23.439291 - t * (0.013004167 + t * (0.0000001639 - t * 0.0000005036))

/** Apparent obliquity of the ecliptic, degrees (Meeus 25.8). */
internal fun apparentObliquityOfTheEcliptic(t: Double, meanObliquity: Double): Double =
    meanObliquity + 0.00256 * (125.04 - 1934.136 * t).dcos()

/** Mean sidereal time at Greenwich, degrees (Meeus 12.4). */
internal fun meanSiderealTime(t: Double): Double {
    val jd = t * 36525.0 + 2451545.0
    val theta = 280.46061837 + 360.98564736629 * (jd - 2451545.0) +
        0.000387933 * t * t - (t * t * t) / 38710000.0
    return unwindAngle(theta)
}

internal fun nutationInLongitude(l0: Double, lp: Double, omega: Double): Double =
    (-17.2 / 3600) * omega.dsin() -
        (-1.32 / 3600) * (2 * l0).dsin() -
        (0.23 / 3600) * (2 * lp).dsin() +
        (0.21 / 3600) * (2 * omega).dsin()

internal fun nutationInObliquity(l0: Double, lp: Double, omega: Double): Double =
    (9.2 / 3600) * omega.dcos() +
        (0.57 / 3600) * (2 * l0).dcos() +
        (0.10 / 3600) * (2 * lp).dcos() -
        (0.09 / 3600) * (2 * omega).dcos()

/** Altitude of a celestial body above the horizon, degrees (Meeus 13.6). */
internal fun altitudeOfCelestialBody(latitude: Double, declination: Double, localHourAngle: Double): Double =
    dasin(latitude.dsin() * declination.dsin() + latitude.dcos() * declination.dcos() * localHourAngle.dcos())

/** Approximate transit of the Sun, as a fraction of a day (Meeus p. 102). */
internal fun approximateTransit(longitude: Double, siderealTime: Double, rightAscension: Double): Double {
    val lw = longitude * -1
    return normalizeWithBound((rightAscension + lw - siderealTime) / 360.0, 1.0)
}

/** Three-point interpolation (Meeus 3.3). */
internal fun interpolate(y2: Double, y1: Double, y3: Double, factor: Double): Double {
    val a = y2 - y1
    val b = y3 - y2
    val c = b - a
    return y2 + ((factor / 2) * (a + b + factor * c))
}

/** Three-point interpolation for angles wrapping at 360 degrees. */
internal fun interpolateAngles(y2: Double, y1: Double, y3: Double, factor: Double): Double {
    val a = unwindAngle(y2 - y1)
    val b = unwindAngle(y3 - y2)
    val c = b - a
    return y2 + ((factor / 2) * (a + b + factor * c))
}

/** Corrected solar transit, in hours of UTC (Meeus p. 102). */
internal fun correctedTransit(
    approximateTransit: Double,
    longitude: Double,
    siderealTime: Double,
    rightAscension: Double,
    previousRightAscension: Double,
    nextRightAscension: Double
): Double {
    val lw = longitude * -1
    val theta = unwindAngle(siderealTime + 360.985647 * approximateTransit)
    val alpha = unwindAngle(
        interpolateAngles(rightAscension, previousRightAscension, nextRightAscension, approximateTransit)
    )
    val hourAngle = quadrantShiftAngle(theta - lw - alpha)
    val delta = hourAngle / -360.0
    return (approximateTransit + delta) * 24
}

/**
 * How close the recomputed altitude must sit to the requested angle for a root to count, degrees.
 *
 * 0.005° is about a second of twilight travel at mid latitudes and still hundreds of times looser
 * than double precision needs. The previous 0.05° was wide enough to swallow a whole class of
 * white-night tangencies (see [correctedHourAngle]).
 */
private const val ROOT_TOLERANCE_DEGREES = 0.005

/** Half a minute, as a fraction of a day: the probe used to test the residual's sign change. */
private const val SIGN_PROBE_DAYS = 30.0 / 86400.0

/**
 * Corrected hour angle for a given solar altitude, in hours of UTC (Meeus p. 102).
 * Returns [Double.NaN] when the Sun never reaches the requested altitude on that day.
 */
/**
 * Hours (in the frame of [approximateTransit]) at which the Sun's altitude equals [angle].
 *
 * ### Why this is an iteration and not one correction step
 *
 * The textbook recipe guesses the time from the declination *at transit*, then applies a single
 * Newton correction. That is fine in the middle of the year and quietly catastrophic near a season
 * boundary: the derivative it divides by, `360·cosδ·cosφ·sin H`, goes to zero exactly where the
 * twilight arc only grazes the requested angle, so one step can throw the root hours away from any
 * real event. Veliky Novgorod, 17 August 2026, Karachi method: Isha came back as 20:37, one minute
 * after Maghrib, while the true 18° crossing that night is around midnight. That is the same
 * "Isha 20:37" the user reported.
 *
 * So the root is now solved properly: Newton with the step clamped to half an hour per iteration,
 * then *verified* by recomputing the Sun's altitude at the answer. If the residual is bigger than
 * [ROOT_TOLERANCE_DEGREES], or the root drifted to the wrong side of noon, this returns [Double.NaN]
 * — the honest "no such moment tonight" — and the engine falls back to the interval the calendar
 * prints. A wrong number is worse than no number.
 *
 * ### Why the residual alone is not enough (0.2.6)
 *
 * The old check accepted anything within a twentieth of a degree. On an ordinary night that is
 * harmless: the twilight arc sweeps past the angle at a quarter of a degree per minute, so 0.05°
 * is a few seconds of slack. At the edge of the white-night season the arc flattens out at its
 * lowest point, and a night that misses the angle by four hundredths of a degree still passes the
 * test. Volgograd, 14 June 2026: the Sun bottoms out at -17.9989°, never reaching the 18° Isha
 * angle, yet Newton parked on the flat minimum with a residual of 0.001° and the engine published
 * an Isha near 23:30 instead of falling back to "sunset + 90". Same shape in Ust-Kamenogorsk on
 * 10 June. This is the evening twin of the morning bug fixed in 0.2.4 — back then only the dawn
 * branch was hardened.
 *
 * Two guards now, both cheap:
 *  - the residual must be within [ROOT_TOLERANCE_DEGREES] (0.005°, a fifth of an arcsecond of
 *    twilight travel — still generous for double arithmetic, ten times stricter than before);
 *  - the residual must actually *change sign* across the answer. A crossing has opposite signs
 *    half a minute either side; a tangency has the same sign twice. If the Sun only kisses the
 *    angle, there is no event, and the interval is the honest answer.
 */
internal fun correctedHourAngle(
    approximateTransit: Double,
    angle: Double,
    latitude: Double,
    longitude: Double,
    afterTransit: Boolean,
    siderealTime: Double,
    rightAscension: Double,
    previousRightAscension: Double,
    nextRightAscension: Double,
    declination: Double,
    previousDeclination: Double,
    nextDeclination: Double
): Double {
    val lw = longitude * -1

    // Reused instead of returning a Pair: this function is the hot spot of the whole engine
    // (seven markers x sixteen days x two neighbouring days per screen) and a Pair per iteration
    // was pure allocation churn on the frame the schedule is composed in.
    val scratch = DoubleArray(2)

    /** scratch[0] = altitude - angle, degrees; scratch[1] = d(altitude)/dx, degrees per day. */
    fun residual(x: Double) {
        val theta = unwindAngle(siderealTime + 360.985647 * x)
        val alpha = unwindAngle(
            interpolateAngles(rightAscension, previousRightAscension, nextRightAscension, x)
        )
        val delta = interpolate(declination, previousDeclination, nextDeclination, x)
        val hourAngle = theta - lw - alpha
        scratch[0] = altitudeOfCelestialBody(latitude, delta, hourAngle) - angle
        scratch[1] = 360.0 * delta.dcos() * latitude.dcos() * hourAngle.dsin()
    }

    /**
     * Accepts [m] as an event or rejects it. Three independent questions, all of which a real
     * crossing answers yes: does the Sun actually sit at the angle there, does the residual change
     * sign across it, and does it belong to this branch of this day?
     */
    fun verify(m: Double): Double {
        residual(m)
        if (abs(scratch[0]) > ROOT_TOLERANCE_DEGREES) return Double.NaN
        residual(m - SIGN_PROBE_DAYS)
        val before = scratch[0]
        residual(m + SIGN_PROBE_DAYS)
        val after = scratch[0]
        if (before * after > 0.0) return Double.NaN
        val offsetFromNoon = m - approximateTransit
        if (afterTransit && offsetFromNoon <= 0.0) return Double.NaN
        if (!afterTransit && offsetFromNoon >= 0.0) return Double.NaN
        if (abs(offsetFromNoon) > 0.5) return Double.NaN
        return m * 24
    }

    // ---- Attempt 1: Meeus's guess plus clamped Newton. Converges in three or four iterations
    // everywhere the twilight arc crosses the angle at a decent slope, which is most of the year.
    val term1 = angle.dsin() - latitude.dsin() * declination.dsin()
    val term2 = latitude.dcos() * declination.dcos()
    val ratio = term1 / term2
    if (!ratio.isNaN() && ratio <= 1.0 && ratio >= -1.0) {
        val h0 = dacos(ratio)
        var m = if (afterTransit) approximateTransit + (h0 / 360.0) else approximateTransit - (h0 / 360.0)
        val maxStep = 0.5 / 24.0
        var usable = true
        for (iteration in 0 until 8) {
            residual(m)
            val value = scratch[0]
            val slope = scratch[1]
            if (abs(value) < 1e-7) break
            if (abs(slope) < 1e-9) {
                usable = false
                break
            }
            m += (value / slope).coerceIn(-maxStep, maxStep)
        }
        if (usable) {
            val verified = verify(m)
            if (!verified.isNaN()) return verified
        }
    }

    // ---- Attempt 2: bracket the branch and bisect.
    //
    // Newton needs a slope, and the slope is exactly what vanishes at the bottom of a summer night.
    // Ekaterinburg, 8 August 2026, 17 deg Isha: the Sun does spend fifty-two minutes below the
    // angle, but the crossing sits twenty-six minutes before solar midnight where the derivative is
    // near zero, so Newton either stalled or was thrown away by the guard - and the app printed an
    // interval while a true astronomical Isha existed. Walking outwards from local noon in
    // two-minute steps finds the *first* sign change on this branch, which is the event by
    // definition (dawn is the last crossing before noon, Isha the first after it), and forty
    // bisections pin it to well under a second. Cost is a few hundred trig evaluations, and only
    // on the nights where Newton already failed.
    val direction = if (afterTransit) 1.0 else -1.0
    val step = 2.0 / (24.0 * 60.0)
    var previousX = approximateTransit
    residual(previousX)
    var previousValue = scratch[0]
    if (previousValue == 0.0) return verify(previousX)
    var x = previousX + direction * step
    while (abs(x - approximateTransit) <= 0.5) {
        residual(x)
        val value = scratch[0]
        if (value == 0.0) return verify(x)
        if ((previousValue < 0.0) != (value < 0.0)) {
            var lo = previousX
            var hi = x
            var loNegative = previousValue < 0.0
            repeat(40) {
                val mid = (lo + hi) / 2.0
                residual(mid)
                if ((scratch[0] < 0.0) == loNegative) {
                    lo = mid
                    loNegative = scratch[0] < 0.0
                } else {
                    hi = mid
                }
            }
            return verify((lo + hi) / 2.0)
        }
        previousX = x
        previousValue = value
        x += direction * step
    }
    return Double.NaN
}
