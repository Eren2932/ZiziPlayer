package com.nur.prayer.core.astro

import java.time.Instant
import java.time.ZoneOffset

/** Apparent position of the Sun for one exact moment, seen from one point on Earth. */
data class SunPosition(
    /** Degrees clockwise from **true** north. */
    val azimuth: Double,
    /** Degrees above the horizon, negative below it. */
    val altitude: Double
)

/**
 * Where the Sun is right now.
 *
 * This exists to make the Qibla verifiable without trusting the magnetometer at all. A compass can
 * be off by ten degrees near a steel door frame and look perfectly confident while doing it; the
 * Sun cannot. Knowing the solar azimuth turns a shadow into a reference direction: hold a straight
 * object upright, and its shadow points along solar azimuth + 180°. Compare that with
 * [qiblaBearing] and the direction is settled by geometry instead of by a sensor.
 *
 * Same Meeus apparent-coordinates chain the prayer times use, so the accuracy is the same order —
 * well under a tenth of a degree, far below anything a phone compass can resolve.
 */
fun sunPosition(instant: Instant, coordinates: Coordinates): SunPosition {
    val utc = instant.atZone(ZoneOffset.UTC)
    val hours = utc.hour + utc.minute / 60.0 + (utc.second + utc.nano / 1_000_000_000.0) / 3600.0
    val jd = julianDay(utc.year, utc.monthValue, utc.dayOfMonth, hours)
    val solar = SolarCoordinates(jd)

    // Local hour angle, measured westward from the local meridian.
    val hourAngle = unwindAngle(solar.apparentSiderealTime + coordinates.longitude - solar.rightAscension)
    val altitude = altitudeOfCelestialBody(coordinates.latitude, solar.declination, hourAngle)

    // atan2 form: stable at every hour angle, unlike the classic acos version which loses the
    // east / west half of the sky and silently mirrors the morning onto the afternoon.
    val fromSouth = datan2(
        hourAngle.dsin(),
        hourAngle.dcos() * coordinates.latitude.dsin() - solar.declination.dtan() * coordinates.latitude.dcos()
    )
    return SunPosition(azimuth = unwindAngle(fromSouth + 180.0), altitude = altitude)
}

/**
 * Angle you must turn from the Sun's current direction to face the Qibla, degrees clockwise.
 * Negative means counter-clockwise. Lets the Qibla screen say "turn 34° right from the Sun".
 */
fun qiblaOffsetFromSun(instant: Instant, coordinates: Coordinates): Double {
    val delta = qiblaBearing(coordinates) - sunPosition(instant, coordinates).azimuth
    return quadrantShiftAngle(unwindAngle(delta))
}
