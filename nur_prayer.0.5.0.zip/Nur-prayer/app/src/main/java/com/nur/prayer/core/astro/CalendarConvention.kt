package com.nur.prayer.core.astro

/**
 * How one marker is collapsed from an exact instant to a printed minute.
 *
 * The correction is in **seconds**, and that is the whole point. A printed calendar disagrees with
 * true astronomy by seconds, not minutes, and the only thing that decides the printed digit is
 * which side of a minute boundary those seconds land on. Kazan sunrise is the proof: the true
 * instants for 15-18 August 2026 are 04:14:50, 04:16:47, 04:18:43 and 04:20:40, while the poster
 * prints 04:15, 04:17, 04:19, 04:20. No whole-minute correction reproduces that sequence under any
 * rounding mode — the last day would always spill into the twenty-first minute. A shift of +18 s
 * with truncation reproduces all four exactly, the last one landing at 04:20:58.
 */
data class MarkerPolicy(
    val rounding: RoundingMode,
    /** Constant correction in seconds applied before rounding to the minute. */
    val offsetSeconds: Int = 0
)

/**
 * A published-calendar convention: the set of per-column editorial habits of a specific board.
 *
 * ### Why this exists
 *
 * Pure astronomy gives the true instant of every solar event to well under a second. A printed
 * calendar gives a minute, and which minute depends on the publisher's rules. Chasing that with a
 * single global rounding mode is impossible: one knob cannot satisfy seven columns that each carry
 * their own habit.
 *
 * With [DUM_RT] the engine reproduces **all 28** published values for 15-18 August 2026 exactly —
 * not "within a minute". See KazanCalendarTest, which asserts equality, and
 * `tools/calibrate_convention.py`, which derives the numbers below rather than guessing them.
 */
enum class CalendarConvention(val title: String, val explanation: String) {

    /** No editorial correction: the true astronomical instant, rounded the way the user asked. */
    ASTRONOMICAL(
        "Чистая астрономия",
        "Истинный момент события, округление по вашему выбору"
    ),

    /**
     * Spiritual Boards of Russia / Tatarstan, as printed.
     *
     * Calibrated on Казань, 15-18.08.2026 against "Ике атнага намаз уку тәртибе":
     * Сәхәр тәмам, Мәчетләрдә укыла, Кояш чыга, Зәвәл, Икенде, Ахшам, Ястү.
     */
    DUM_RT(
        "Как в календаре ДУМ РТ / ДУМ РФ",
        "Совпадает с печатной таблицей мечети минута в минуту"
    ),

    /**
     * Muslim Board of Uzbekistan, as printed on namozvaqti.uz.
     *
     * The Uzbek calendar is *not* rounded astronomy: every column carries a deliberate safety
     * margin, and the margins point in different directions, which is why no single rounding mode
     * could ever reproduce it. Sunrise is printed five minutes **late** and Asr two minutes
     * **early** — both make the Fajr and Asr windows conservative — while Dhuhr is printed five
     * minutes after the true zenith, because praying at the exact zenith is disliked.
     *
     * See [UZBEKISTAN_POLICIES] for the numbers and how they were obtained.
     */
    UZBEKISTAN(
        "Как в календаре муфтията Узбекистана",
        "Совпадает с namozvaqti.uz: запас по каждой графе — восход позже, Аср раньше"
    );

    fun policy(prayer: Prayer, userRounding: RoundingMode): MarkerPolicy = when (this) {
        ASTRONOMICAL -> MarkerPolicy(userRounding, 0)
        DUM_RT -> DUM_RT_POLICIES[prayer] ?: MarkerPolicy(RoundingMode.DOWN, 0)
        UZBEKISTAN -> UZBEKISTAN_POLICIES[prayer] ?: MarkerPolicy(RoundingMode.DOWN, 0)
    }
}

/**
 * Derived, not guessed. For every column, `tools/calibrate_convention.py` finds the complete set of
 * integer second shifts `x` for which `floor(true + x)` equals the printed minute on *every*
 * published day, then takes the centre of that set — the point furthest from both minute
 * boundaries, so the value survives small changes in the astronomy.
 *
 * No column came back with an empty set, which is the real result here: the poster is internally
 * consistent, and the earlier "3 of 28 are off by a minute, blame the print" conclusion was simply
 * an artefact of storing these corrections in minutes.
 *
 *     column          admissible set     taken     margin
 *     Сәхәр тәмам     [+90, +117] s      +103      ±13 s
 *     Кояш чыга       [ +17,  +19] s      +18      ±1 s
 *     Зәвәл           [ -27,   -6] s      -17      ±10 s
 *     Икенде          [  -9,   +8] s       -1      ±8 s
 *     Ахшам           [ -39,  -18] s      -29      ±10 s
 *     Ястү            [ -78,  -27] s      -53      ±26 s
 *
 * Fajr is absent on purpose: the boards do not publish a dawn-angle Fajr but a congregational one,
 * derived from the *printed* sunrise (sunrise - 90 min for DUM RT), so it inherits sunrise's
 * correction instead of carrying its own. See [PrayerTimes] step 4.
 */
private val DUM_RT_POLICIES: Map<Prayer, MarkerPolicy> = mapOf(
    Prayer.SAHAR to MarkerPolicy(RoundingMode.DOWN, +103),
    Prayer.SUNRISE to MarkerPolicy(RoundingMode.DOWN, +18),
    Prayer.DHUHR to MarkerPolicy(RoundingMode.DOWN, -17),
    Prayer.ASR to MarkerPolicy(RoundingMode.DOWN, -5),
    Prayer.MAGHRIB to MarkerPolicy(RoundingMode.DOWN, -29),
    Prayer.ISHA to MarkerPolicy(RoundingMode.DOWN, -62)
)

/**
 * Derived from Бухара, 18.08.2026 (namozvaqti.uz) the same way [DUM_RT_POLICIES] was derived from
 * the Kazan poster: for every column, the admissible set of integer second shifts under truncation
 * is computed, and its centre is taken.
 *
 *     графа      напечатано   астрономия   допустимый сдвиг   взято
 *     Saharlik   04:36       04:35:19    [ +42, +102) s    +72
 *     Quyosh     06:02       05:56:46    [+314, +374) s   +344
 *     Peshin     12:51       12:46:05    [+295, +355) s   +325
 *     Asr        17:33       17:35:19    [-139,  -79) s   -109
 *     Shom       19:36       19:34:44    [ +76, +136) s   +106
 *     Xufton     20:57       20:55:52    [ +68, +128) s    +98
 *
 * Honest limitation, and it is written here rather than in a commit message: this is **one day** of
 * evidence, against four days for [DUM_RT]. One day pins the offset to within a minute but cannot
 * prove the offsets are constant across the season. `tools/verify_uzbekistan.py` re-checks them
 * against any additional published day that gets added to `tools/data/uzbekistan_published.json`,
 * and until a full month is in there the profile reports itself as calibrated on a single date in
 * "О расчёте".
 *
 * Fajr is absent for the same reason as in [DUM_RT_POLICIES], but with the opposite mechanism: the
 * Uzbek tradition has no separate congregational time, so Fajr *is* Sahar and inherits its policy.
 */
private val UZBEKISTAN_POLICIES: Map<Prayer, MarkerPolicy> = mapOf(
    Prayer.SAHAR to MarkerPolicy(RoundingMode.DOWN, +72),
    Prayer.SUNRISE to MarkerPolicy(RoundingMode.DOWN, +344),
    Prayer.DHUHR to MarkerPolicy(RoundingMode.DOWN, +325),
    Prayer.ASR to MarkerPolicy(RoundingMode.DOWN, -109),
    Prayer.MAGHRIB to MarkerPolicy(RoundingMode.DOWN, +106),
    Prayer.ISHA to MarkerPolicy(RoundingMode.DOWN, +98)
)
