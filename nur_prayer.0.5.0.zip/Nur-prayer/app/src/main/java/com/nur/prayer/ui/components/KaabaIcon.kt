package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun KaabaIcon(edge: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        if (s < 4f) return@Canvas
        drawRect(edge, Offset(s * 0.14f, s * 0.15f), Size(s * 0.72f, s * 0.72f), style = Stroke(s * 0.055f))
        drawLine(edge, Offset(s * 0.14f, s * 0.36f), Offset(s * 0.86f, s * 0.36f), s * 0.085f)
        drawRect(edge, Offset(s * 0.61f, s * 0.59f), Size(s * 0.12f, s * 0.23f))
    }
}
