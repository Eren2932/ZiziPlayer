package com.nur.prayer

import com.nur.prayer.ui.schedule.CalendarMonthModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalendarMonthModelTest {
    @Test fun septemberBeginsUnderTuesday() {
        val cells = CalendarMonthModel.cells(YearMonth.of(2026, 9))
        assertEquals(LocalDate.of(2026, 8, 31), cells.first())
        assertEquals(LocalDate.of(2026, 9, 1), cells[1])
        assertEquals(35, cells.size)
    }
    @Test fun februaryCanBeExactlyFourWeeks() {
        val cells = CalendarMonthModel.cells(YearMonth.of(2021, 2))
        assertEquals(28, cells.size)
        assertEquals(LocalDate.of(2021, 2, 28), cells.last())
    }
    @Test fun leapFebruaryIncludesThe29th() {
        val month = YearMonth.of(2028, 2)
        val cells = CalendarMonthModel.cells(month)
        assertEquals(29, cells.count { YearMonth.from(it) == month })
        assertTrue(LocalDate.of(2028, 2, 29) in cells)
    }
    @Test fun longMonthCanNeedSixWeeks() {
        assertEquals(42, CalendarMonthModel.cells(YearMonth.of(2026, 8)).size)
    }
    @Test fun yearBoundaryDatesStayConsecutive() {
        val cells = CalendarMonthModel.cells(YearMonth.of(2027, 1))
        assertEquals(LocalDate.of(2026, 12, 28), cells.first())
        cells.zipWithNext().forEach { (a, b) -> assertEquals(a.plusDays(1), b) }
    }
    @Test fun selectionClampsAtShortMonthInsteadOfThrowing() {
        assertEquals(LocalDate.of(2027, 2, 28), CalendarMonthModel.moveSelection(
            LocalDate.of(2027, 1, 31), YearMonth.of(2027, 2)))
        assertEquals(LocalDate.of(2028, 2, 29), CalendarMonthModel.moveSelection(
            LocalDate.of(2028, 1, 31), YearMonth.of(2028, 2)))
    }
    @Test fun ordinaryDayIsPreservedAcrossYearBoundary() {
        assertEquals(LocalDate.of(2027, 1, 17), CalendarMonthModel.moveSelection(
            LocalDate.of(2026, 12, 17), YearMonth.of(2027, 1)))
    }
    @Test fun fullGregorianCycleHasCompleteMondayFirstGrids() {
        for (year in 2000..2399) for (monthNumber in 1..12) {
            val month = YearMonth.of(year, monthNumber)
            val cells = CalendarMonthModel.cells(month)
            assertEquals(DayOfWeek.MONDAY, cells.first().dayOfWeek)
            assertEquals(DayOfWeek.SUNDAY, cells.last().dayOfWeek)
            assertTrue(cells.size in listOf(28, 35, 42))
            assertEquals(cells.size, cells.distinct().size)
            assertEquals(month.lengthOfMonth(), cells.count { YearMonth.from(it) == month })
        }
    }
}
