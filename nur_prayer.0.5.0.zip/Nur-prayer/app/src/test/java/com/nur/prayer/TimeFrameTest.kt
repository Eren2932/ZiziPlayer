package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.CalendarConvention
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RoundingMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId

/**
 * Guards the solar frame against the UTC day boundary.
 *
 * Solar events are computed as hours offset from 00:00 UTC of a date, and the transit that anchors
 * them is a fraction of the *UTC* day. Where a city's solar noon falls near that boundary the
 * fraction is ambiguous by exactly one day: Anadyr sits at longitude 177.5 in UTC+12, ten minutes
 * away from it, and the released build flipped between the two readings from one day to the next.
 * On 4 December 2026 that gave a "tomorrow's sunrise" earlier than "today's sunset", a negative
 * night, and a day whose seven markers collapsed into three minutes around sunrise:
 *
 *     сухур 09:45  фаджр 09:45  восход 09:46  зухр 12:00  аср 12:28  магриб 14:13  иша 14:14
 *
 * These tests would have caught it, so they exist now.
 */
class TimeFrameTest {

    private val params = PrayerParams(
        method = CalculationMethod.RUSSIA_DUM,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST,
        convention = CalendarConvention.DUM_RT
    )

    private val order = listOf(
        Prayer.SAHAR, Prayer.FAJR, Prayer.SUNRISE,
        Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
    )

    /** Cities whose solar noon is close enough to the UTC day boundary to be dangerous. */
    private val farEast = listOf(
        Triple("Анадырь", Coordinates(64.7314, 177.5015), "Asia/Anadyr"),
        Triple("Петропавловск-Камчатский", Coordinates(53.0370, 158.6559), "Asia/Kamchatka"),
        Triple("Магадан", Coordinates(59.5638, 150.8035), "Asia/Magadan"),
        Triple("Южно-Сахалинск", Coordinates(46.9591, 142.7380), "Asia/Sakhalin"),
        Triple("Владивосток", Coordinates(43.1155, 131.8855), "Asia/Vladivostok")
    )

    @Test
    fun `noon stays at noon and the day never collapses in the far east`() {
        for ((name, place, zoneId) in farEast) {
            val zone = ZoneId.of(zoneId)
            var date = LocalDate.of(2026, 1, 1)
            while (date.year == 2026) {
                val day = PrayerEngine.day(date, place, zone, params)
                val dhuhr = day.at(Prayer.DHUHR)

                assertEquals(
                    "$name $date: зухр уехал с своей даты на ${dhuhr.toLocalDate()}",
                    date, dhuhr.toLocalDate()
                )
                assertTrue(
                    "$name $date: зухр в ${dhuhr.toLocalTime()}, это не полдень",
                    dhuhr.toLocalTime().hour in 10..13
                )

                val span = Duration.between(day.at(Prayer.SUNRISE), day.at(Prayer.MAGHRIB))
                // `note` is non-null exactly when the day needed a substitute rule, which is the
                // only situation where a compressed day is legitimate.
                if (day.note == null) {
                    assertTrue(
                        "$name $date: от восхода до магриба ${span.toMinutes()} мин — день схлопнулся",
                        span.toMinutes() >= 60
                    )
                }

                var previous = day.at(order.first())
                for (prayer in order.drop(1)) {
                    val value = day.at(prayer)
                    assertTrue(
                        "$name $date ${prayer.name}: порядок нарушен, $previous -> $value",
                        !value.isBefore(previous)
                    )
                    previous = value
                }
                date = date.plusDays(1)
            }
        }
    }

    @Test
    fun `sunrise advances smoothly across the UTC boundary that used to flip`() {
        // The failure was invisible in a single day and obvious in a sequence: 4 and 5 December
        // produced the very same sunrise because one of them had silently borrowed the other's Sun.
        val zone = ZoneId.of("Asia/Anadyr")
        val place = Coordinates(64.7314, 177.5015)
        var date = LocalDate.of(2026, 11, 25)
        var previous = PrayerEngine.day(date, place, zone, params).at(Prayer.SUNRISE)
        while (date.isBefore(LocalDate.of(2026, 12, 15))) {
            date = date.plusDays(1)
            val sunrise = PrayerEngine.day(date, place, zone, params).at(Prayer.SUNRISE)
            val step = Duration.between(previous, sunrise).toMinutes() - 24 * 60
            assertTrue(
                "$date: восход сдвинулся на $step мин за сутки — кадр перепрыгнул день",
                step in 1..6
            )
            previous = sunrise
        }
    }
}
