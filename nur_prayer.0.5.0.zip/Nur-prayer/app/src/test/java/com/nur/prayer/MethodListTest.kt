package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.RegionalProfiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The settings list must offer what applies here and nothing else.
 *
 * Until 0.2.7 "Метод расчёта" listed all fifteen methods everywhere, so a user in Kazan scrolled
 * past the printed calendars of Uzbekistan, Turkey, Saudi Arabia, Qatar, Kuwait and Egypt. Each of
 * those reproduces one country's calendar and is wrong by minutes in any other, so offering them
 * was not choice, it was a trap with extra scrolling.
 */
class MethodListTest {

    @Test
    fun `each country leads with its own default`() {
        listOf(
            "Россия" to CalculationMethod.RUSSIA_DUM,
            "Узбекистан" to CalculationMethod.UZBEKISTAN_BOARD,
            "Турция" to CalculationMethod.TURKEY,
            "Саудовская Аравия" to CalculationMethod.UMM_AL_QURA
        ).forEach { (country, expected) ->
            assertEquals(country, expected, RegionalProfiles.methodsFor(country).first())
        }
    }

    @Test
    fun `no country is offered another country's printed calendar`() {
        val uzbek = CalculationMethod.UZBEKISTAN_BOARD
        assertFalse("Узбекистан в списке для Казани", uzbek in RegionalProfiles.methodsFor("Россия"))
        assertFalse(uzbek in RegionalProfiles.methodsFor("Турция"))
        assertTrue(uzbek in RegionalProfiles.methodsFor("Узбекистан"))

        assertFalse(CalculationMethod.RUSSIA_DUM in RegionalProfiles.methodsFor("Узбекистан"))
        assertFalse(CalculationMethod.TURKEY in RegionalProfiles.methodsFor("Россия"))
        assertFalse(CalculationMethod.UMM_AL_QURA in RegionalProfiles.methodsFor("Казахстан"))
    }

    @Test
    fun `the international sets are everywhere`() {
        val everywhere = listOf(
            CalculationMethod.MUSLIM_WORLD_LEAGUE,
            CalculationMethod.KARACHI
        )
        listOf("Россия", "Узбекистан", "Казахстан", "Германия", "Неизвестная страна").forEach { country ->
            val offered = RegionalProfiles.methodsFor(country)
            everywhere.forEach { method ->
                assertTrue("$method пропал в списке для $country", method in offered)
            }
        }
    }

    @Test
    fun `an unknown country still gets a usable, deduplicated list`() {
        val offered = RegionalProfiles.methodsFor("Атлантида")
        assertEquals(offered.size, offered.distinct().size)
        assertTrue(offered.isNotEmpty())
        assertEquals(RegionalProfiles.forCountry("Атлантида").method, offered.first())
    }

    @Test
    fun `neighbours keep the methods their communities actually use`() {
        // Azerbaijan is majority Ja'fari, so Tehran stays one tap away there — and only there.
        assertTrue(CalculationMethod.TEHRAN in RegionalProfiles.methodsFor("Азербайджан"))
        assertFalse(CalculationMethod.TEHRAN in RegionalProfiles.methodsFor("Россия"))
        // Belarus follows the Russian board's calendar, and its profile says so.
        assertTrue(CalculationMethod.RUSSIA_DUM in RegionalProfiles.methodsFor("Беларусь"))
    }

    @Test
    fun `isForeignTo is honest in both directions`() {
        assertTrue(RegionalProfiles.isForeignTo(CalculationMethod.UZBEKISTAN_BOARD, "Россия"))
        assertFalse(RegionalProfiles.isForeignTo(CalculationMethod.UZBEKISTAN_BOARD, "Узбекистан"))
        assertFalse(RegionalProfiles.isForeignTo(CalculationMethod.MUSLIM_WORLD_LEAGUE, "Россия"))
    }
}
