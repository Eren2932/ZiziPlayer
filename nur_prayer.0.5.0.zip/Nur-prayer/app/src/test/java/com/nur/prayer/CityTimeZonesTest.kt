package com.nur.prayer

import com.nur.prayer.ui.settings.CityTimeZones
import java.time.Instant
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Test

class CityTimeZonesTest {
    @Test fun fractionalOffsetsAreNotTruncated() {
        assertEquals("UTC+5:30", CityTimeZones.label(ZoneOffset.of("+05:30")))
        assertEquals("UTC+5:45", CityTimeZones.label(ZoneOffset.of("+05:45")))
        assertEquals("UTC−3:30", CityTimeZones.label(ZoneOffset.of("-03:30")))
        assertEquals("UTC±0", CityTimeZones.label(ZoneOffset.UTC))
    }
    @Test fun daylightSavingUsesTheRequestedInstant() {
        assertEquals("UTC+1", CityTimeZones.label("Europe/Berlin", Instant.parse("2026-01-01T12:00:00Z")))
        assertEquals("UTC+2", CityTimeZones.label("Europe/Berlin", Instant.parse("2026-07-01T12:00:00Z")))
    }
}
