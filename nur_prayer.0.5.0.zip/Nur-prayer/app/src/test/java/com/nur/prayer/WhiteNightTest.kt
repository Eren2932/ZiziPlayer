package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.CalendarConvention
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.PrayerTimes
import com.nur.prayer.core.astro.RoundingMode
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId

/**
 * The white-night season, north of Kazan.
 *
 * Three separate bugs lived here and none of them could be seen in a four-day test around one city:
 *
 * 1. **Suhoor in the previous evening.** The board's rule "suhoor = sunrise − 120 min" assumes a
 *    night that is at least that long. Murmansk on 19 May 2026 has 106 minutes of night, so the
 *    rule produced 23:36 while the Sun had not even set (23:50) — the fast ending before it began.
 * 2. **A night too short to publish at all.** Squeezing the interval into a twenty-minute night is
 *    arithmetically fine and religiously useless: Salekhard on 5 June got a three-minute suhoor
 *    window. Such a night is now declared unpublishable and the day is resolved by Aqrab al-Ayyam,
 *    the same way the boards do it.
 * 3. **A phantom Isha right after Maghrib.** The old single-step root finder divided by a
 *    derivative that vanishes at the season boundary. Veliky Novgorod, 17 August 2026, Karachi
 *    method: Isha came back as 20:37, one minute after Maghrib — the very "Isha 20:37" symptom the
 *    user reported. The root finder now iterates and verifies its answer against the Sun's altitude.
 */
class WhiteNightTest {

    private val zone: ZoneId = ZoneId.of("Europe/Moscow")

    private fun params(method: CalculationMethod) = PrayerParams(
        method = method,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST,
        convention = CalendarConvention.DUM_RT
    )

    /** Latitudes where the season actually bites, plus the two cities that failed. */
    private val north = listOf(
        Triple("Мурманск", Coordinates(68.9585, 33.0827), "Europe/Moscow"),
        Triple("Норильск", Coordinates(69.3558, 88.1893), "Asia/Krasnoyarsk"),
        Triple("Салехард", Coordinates(66.5299, 66.6014), "Asia/Yekaterinburg"),
        Triple("Новый Уренгой", Coordinates(66.0833, 76.6333), "Asia/Yekaterinburg"),
        Triple("Архангельск", Coordinates(64.5401, 40.5433), "Europe/Moscow"),
        Triple("Северодвинск", Coordinates(64.5635, 39.8302), "Europe/Moscow"),
        Triple("Санкт-Петербург", Coordinates(59.9311, 30.3609), "Europe/Moscow"),
        Triple("Великий Новгород", Coordinates(58.5215, 31.2755), "Europe/Moscow")
    )

    @Test
    fun `suhoor never ends before the fast has begun`() {
        for ((name, place, zoneId) in north) {
            val cityZone = ZoneId.of(zoneId)
            var date = LocalDate.of(2026, 4, 15)
            while (date.isBefore(LocalDate.of(2026, 9, 1))) {
                val previous = PrayerEngine.day(date.minusDays(1), place, cityZone, params(CalculationMethod.RUSSIA_DUM))
                val day = PrayerEngine.day(date, place, cityZone, params(CalculationMethod.RUSSIA_DUM))
                val sahar = day.at(Prayer.SAHAR)
                assertTrue(
                    "$name $date: сухур ${sahar.toLocalDateTime()} раньше заката " +
                        "${previous.at(Prayer.MAGHRIB).toLocalDateTime()}",
                    sahar.isAfter(previous.at(Prayer.MAGHRIB))
                )
                assertTrue(
                    "$name $date: сухур позже фаджра",
                    !sahar.isAfter(day.at(Prayer.FAJR))
                )
                val window = Duration.between(sahar, day.at(Prayer.SUNRISE)).toMinutes()
                assertTrue(
                    "$name $date: от сухура до восхода $window мин — это не окно, а опечатка",
                    window >= 20
                )
                date = date.plusDays(1)
            }
        }
    }

    @Test
    fun `a night too short to publish goes to Aqrab al-Ayyam instead of being squeezed`() {
        val place = Coordinates(66.5299, 66.6014)          // Салехард
        val cityZone = ZoneId.of("Asia/Yekaterinburg")
        val date = LocalDate.of(2026, 6, 5)
        val raw = PrayerTimes(date, place, params(CalculationMethod.RUSSIA_DUM), cityZone)

        assertTrue("Ночь 5 июня в Салехарде обязана считаться непубликуемой", raw.nightUnusable)
        assertFalse(raw.isPublishable)

        val day = PrayerEngine.day(date, place, cityZone, params(CalculationMethod.RUSSIA_DUM))
        assertTrue(
            "Такой день обязан объясняться пользователю, а не молча схлопываться",
            day.note != null
        )
        assertTrue(
            "$date: окно сухура ${Duration.between(day.at(Prayer.SAHAR), day.at(Prayer.SUNRISE)).toMinutes()} мин",
            Duration.between(day.at(Prayer.SAHAR), day.at(Prayer.SUNRISE)).toMinutes() >= 20
        )
    }

    @Test
    fun `Isha never lands a minute after Maghrib at a season boundary`() {
        val place = Coordinates(58.5215, 31.2755)          // Великий Новгород
        for (method in CalculationMethod.values()) {
            var date = LocalDate.of(2026, 5, 1)
            while (date.isBefore(LocalDate.of(2026, 9, 15))) {
                val day = PrayerEngine.day(date, place, zone, params(method))
                val gap = Duration.between(day.at(Prayer.MAGHRIB), day.at(Prayer.ISHA)).toMinutes()
                assertTrue(
                    "${method.name} $date: магриб→иша $gap мин",
                    gap >= 30
                )
                date = date.plusDays(1)
            }
        }
    }
}
