package com.nur.prayer

import com.nur.prayer.ui.NurNavigator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NurNavigatorTest {
    @Test fun cityReturnsToItsCaller() {
        val nav = NurNavigator()
        nav.go("settings"); nav.go("city")
        assertEquals("settings", nav.selectedTab)
        assertTrue(nav.isOverlay)
        nav.back()
        assertEquals("settings", nav.current)
        nav.back()
        assertEquals("home", nav.current)
        assertFalse(nav.back())
    }
    @Test fun repeatedTapsDoNotGrowHistory() {
        val nav = NurNavigator()
        repeat(1000) { nav.go("qibla"); nav.go("home") }
        assertTrue(nav.snapshot().size <= 5)
        val before = nav.snapshot()
        nav.go(nav.current); nav.go("invalid")
        assertEquals(before, nav.snapshot())
    }
    @Test fun restoreKeepsHistoryAndHighlight() {
        val nav = NurNavigator()
        nav.go("schedule"); nav.go("city")
        val saved = nav.snapshot()
        val restored = NurNavigator(saved.first(), saved.drop(1))
        assertEquals(saved, restored.snapshot())
        assertEquals("schedule", restored.selectedTab)
        assertTrue(restored.back())
        assertEquals("schedule", restored.current)
    }
    @Test fun invalidRestoreIsSafeAndOverlayAlwaysHasExit() {
        assertEquals("home", NurNavigator("bad").current)
        val nav = NurNavigator("city")
        assertTrue(nav.back())
        assertEquals("home", nav.current)
    }
}
