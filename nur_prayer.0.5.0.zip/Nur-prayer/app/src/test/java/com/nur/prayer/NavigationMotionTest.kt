package com.nur.prayer

import com.nur.prayer.ui.NavigationMotion
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationMotionTest {
    @Test fun routesHaveBoundedDurationsWithoutDelayingStateChanges() {
        assertTrue(NavigationMotion.TAB_ENTER_MILLIS in 120..220)
        assertTrue(NavigationMotion.DETAIL_ENTER_MILLIS in 220..320)
        assertTrue(NavigationMotion.EDITOR_ENTER_MILLIS in 200..300)
        assertTrue(NavigationMotion.EXIT_MILLIS < NavigationMotion.TAB_ENTER_MILLIS)
        assertTrue(NavigationMotion.DETAIL_EXIT_MILLIS < NavigationMotion.DETAIL_ENTER_MILLIS)
        assertTrue(NavigationMotion.DOCK_MILLIS in 120..240)
    }
}
