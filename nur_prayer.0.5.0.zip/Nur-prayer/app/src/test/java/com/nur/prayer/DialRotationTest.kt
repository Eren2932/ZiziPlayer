package com.nur.prayer

import com.nur.prayer.ui.qibla.nearestDialRotation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class DialRotationTest {
    @Test fun northCrossingIsTwoDegreesNotFullTurn() {
        assertEquals(-361f, nearestDialRotation(-359f, 1f), 0.001f)
        assertEquals(1f, nearestDialRotation(-1f, 359f), 0.001f)
    }
    @Test fun repeatedRevolutionsKeepShortPath() {
        var rotation = 0f
        for (heading in 0..10000) {
            val next = nearestDialRotation(rotation, (heading % 360).toFloat())
            assertTrue(abs(next - rotation) <= 1.01f)
            rotation = next
        }
    }
}
