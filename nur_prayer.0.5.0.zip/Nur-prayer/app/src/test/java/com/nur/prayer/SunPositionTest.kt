package com.nur.prayer

import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.core.astro.qiblaOffsetFromSun
import com.nur.prayer.core.astro.sunPosition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneOffset
import kotlin.math.abs

/**
 * The Sun is the only reference direction a phone cannot get wrong, so the compass screen is
 * allowed to lean on it. These tests need no external data: they check the solar azimuth against
 * facts that follow from the definition of a transit.
 */
class SunPositionTest {

    private val kazan = Coordinates(55.7963, 49.1064)

    private fun utc(y: Int, mo: Int, d: Int, h: Int, mi: Int, s: Int) =
        LocalDateTime.of(y, mo, d, h, mi, s).toInstant(ZoneOffset.UTC)

    @Test
    fun `at solar transit the Sun stands due south`() {
        // Solar noon in Kazan on 15 August 2026 is 08:48:06 UTC.
        val position = sunPosition(utc(2026, 8, 15, 8, 48, 6), kazan)
        assertEquals(180.0, position.azimuth, 0.05)
    }

    @Test
    fun `at transit the altitude equals ninety minus the zenith distance`() {
        val position = sunPosition(utc(2026, 8, 15, 8, 48, 6), kazan)
        // declination that day is +13.99, latitude 55.7963 -> 90 - (55.7963 - 13.99)
        assertEquals(48.20, position.altitude, 0.05)
    }

    @Test
    fun `at sunrise the Sun sits on the refracted horizon`() {
        val position = sunPosition(utc(2026, 8, 15, 1, 14, 52), kazan)
        // The engine defines sunrise at -50 arcminutes to account for refraction plus solar radius.
        assertEquals(-0.8333, position.altitude, 0.02)
        assertTrue("Восход обязан быть на востоке, получили ${position.azimuth}", position.azimuth in 45.0..90.0)
    }

    @Test
    fun `azimuth grows through the whole day and never jumps`() {
        var previous = Double.NaN
        var unwrapped = 0.0
        for (step in 0 until 24 * 6) {
            val instant = utc(2026, 8, 15, 0, 0, 0).plusSeconds(step * 600L)
            var azimuth = sunPosition(instant, kazan).azimuth
            if (!previous.isNaN() && azimuth < previous - 180.0) azimuth += 360.0
            if (!previous.isNaN()) {
                assertTrue("азимут пошёл назад на шаге $step", azimuth > previous)
                assertTrue("скачок азимута на шаге $step", azimuth - previous < 10.0)
                unwrapped += azimuth - previous
            }
            previous = azimuth
        }
        // A full rotation, minus one ten minute step.
        assertTrue("за сутки азимут обязан описать круг, получили $unwrapped", abs(unwrapped - 360.0) < 6.0)
    }

    @Test
    fun `the offset from the Sun to the Qibla is consistent with the bearing`() {
        val instant = utc(2026, 8, 15, 8, 48, 6)
        val sun = sunPosition(instant, kazan).azimuth
        val offset = qiblaOffsetFromSun(instant, kazan)
        val reconstructed = ((sun + offset) % 360.0 + 360.0) % 360.0
        assertEquals(qiblaBearing(kazan), reconstructed, 0.01)
        assertTrue("смещение обязано лежать в пределах полукруга", abs(offset) <= 180.0)
    }
}
