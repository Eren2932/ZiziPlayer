package com.nur.prayer

import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.Format
import java.time.Duration
import org.junit.Assert.assertEquals
import org.junit.Test

class CountdownMathTest {
    @Test fun remainingRoundsUpUntilActualBoundary() {
        assertEquals(1L, CountdownMath.secondsRemaining(Duration.ofNanos(1)))
        assertEquals(2L, CountdownMath.secondsRemaining(Duration.ofMillis(1001)))
        assertEquals(1L, CountdownMath.secondsRemaining(Duration.ofSeconds(1)))
    }
    @Test fun expiredWindowNeverShowsNegativeTime() {
        assertEquals(0L, CountdownMath.secondsRemaining(Duration.ZERO))
        assertEquals(0L, CountdownMath.secondsRemaining(Duration.ofNanos(-1)))
        assertEquals("00:00", Format.countdown(Duration.ofSeconds(-3)))
    }
    @Test fun readoutHandlesHourBoundary() {
        assertEquals("1:00:00", Format.countdown(Duration.ofSeconds(3600)))
        assertEquals("59:59", Format.countdown(Duration.ofSeconds(3599)))
        assertEquals("00:01", Format.countdown(Duration.ofMillis(1)))
    }
    @Test fun progressIsClampedAndSafeForInvalidWindow() {
        assertEquals(0f, CountdownMath.progress(10, 10, 20), 0f)
        assertEquals(0f, CountdownMath.progress(20, 10, 20), 0f)
        assertEquals(0f, CountdownMath.progress(10, 30, 0), 0f)
        assertEquals(0.5f, CountdownMath.progress(10, 30, 20), 0.0001f)
        assertEquals(1f, CountdownMath.progress(10, 30, 50), 0f)
    }
}
