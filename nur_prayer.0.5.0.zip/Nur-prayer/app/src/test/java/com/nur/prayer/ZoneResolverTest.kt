package com.nur.prayer

import com.nur.prayer.location.ZoneCandidate
import com.nur.prayer.location.ZoneResolver
import com.nur.prayer.location.ZoneSource
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

/**
 * The zone of a raw fix, decided on the JVM without a device.
 *
 * Every input is a parameter, so the cases that used to need a plane ticket - a phone that stayed on
 * Moscow time while its owner landed in Tashkent, a fix on the Tatarstan/Bashkortostan border where
 * two database cities thirteen kilometres apart live an hour apart - are ordinary unit tests.
 */
class ZoneResolverTest {

    private val summer: Instant = Instant.parse("2026-06-15T09:00:00Z")
    private val winter: Instant = Instant.parse("2026-01-15T09:00:00Z")

    @Test
    fun `phone zone wins when the neighbourhood agrees with it`() {
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("Europe/Moscow"),
            longitude = 49.1088,
            nearby = listOf(ZoneCandidate(ZoneId.of("Europe/Moscow"), 3.0)),
            instant = summer
        )
        assertEquals(ZoneId.of("Europe/Moscow"), decision.zone)
        assertEquals(ZoneSource.DEVICE, decision.source)
    }

    @Test
    fun `stale phone zone loses to a unanimous neighbourhood`() {
        // Landed in Tashkent, phone still on Moscow time: every city around says +05.
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("Europe/Moscow"),
            longitude = 69.2401,
            nearby = listOf(
                ZoneCandidate(ZoneId.of("Asia/Tashkent"), 2.0),
                ZoneCandidate(ZoneId.of("Asia/Tashkent"), 40.0)
            ),
            instant = summer
        )
        assertEquals(ZoneId.of("Asia/Tashkent"), decision.zone)
        assertEquals(ZoneSource.NEIGHBOURHOOD, decision.source)
    }

    @Test
    fun `on a zone boundary the phone decides`() {
        // Oktyabrsky (+05) and Urussu (+03) are 13 km apart. The neighbourhood is split, and only
        // the operator's network knows which side of the line this tower is on.
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("Asia/Yekaterinburg"),
            longitude = 53.4700,
            nearby = listOf(
                ZoneCandidate(ZoneId.of("Europe/Moscow"), 9.0),
                ZoneCandidate(ZoneId.of("Asia/Yekaterinburg"), 11.0)
            ),
            instant = summer
        )
        assertEquals(ZoneId.of("Asia/Yekaterinburg"), decision.zone)
        assertEquals(ZoneSource.DEVICE, decision.source)
    }

    @Test
    fun `no cities nearby keeps a plausible phone zone`() {
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("Asia/Almaty"),
            longitude = 70.0,
            nearby = emptyList(),
            instant = winter
        )
        assertEquals(ZoneId.of("Asia/Almaty"), decision.zone)
        assertEquals(ZoneSource.DEVICE, decision.source)
    }

    @Test
    fun `an impossible phone zone falls back to the nearest city`() {
        // Phone insists on New York while the fix is in the Fergana valley: nine hours of daylight
        // apart. The city is not next door, so it is used only because the clock is unusable.
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("America/New_York"),
            longitude = 71.7864,
            nearby = listOf(ZoneCandidate(ZoneId.of("Asia/Tashkent"), 30.0)),
            instant = summer
        )
        assertEquals(ZoneId.of("Asia/Tashkent"), decision.zone)
        assertEquals(ZoneSource.NEIGHBOURHOOD, decision.source)
    }

    @Test
    fun `with nothing to trust the longitude sets a fixed offset`() {
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.of("America/New_York"),
            longitude = 90.0,
            nearby = emptyList(),
            instant = summer
        )
        assertEquals(ZoneOffset.ofHours(6), decision.zone)
        assertEquals(ZoneSource.LONGITUDE, decision.source)
    }

    @Test
    fun `daylight saving is read at the given instant, not at class load`() {
        // Berlin is +01 in January and +02 in June; the same fix must therefore be judged twice.
        val berlin = ZoneId.of("Europe/Berlin")
        assertEquals(1.0, ZoneResolver.offsetHours(berlin, winter), 1e-9)
        assertEquals(2.0, ZoneResolver.offsetHours(berlin, summer), 1e-9)
    }
}
