# Nur — R8 configuration.
#
# Compose and Kotlin metadata are handled by the AGP defaults (proguard-android-optimize.txt plus the
# consumer rules shipped inside the androidx artifacts), so this file only states what is specific to
# this app.

# Entry points declared in the manifest. AGP keeps them by itself, but naming them here documents the
# contract and survives a future manifest refactor.
-keep class com.nur.prayer.MainActivity
-keep class com.nur.prayer.NurApplication
-keep class com.nur.prayer.notify.AzanPlayerService
-keep class com.nur.prayer.notify.AlarmReceiver
-keep class com.nur.prayer.notify.BootReceiver

# Enum names are persisted in DataStore and read back with valueOf(), so the *names* must survive
# obfuscation even though the classes themselves may be renamed... which is why the whole enum stays.
# This is 0.2.7's replacement for `-keep class com.nur.prayer.notify.** { *; }`: that rule pinned every
# member of every notification class, including the ones R8 could have inlined.
-keepclassmembers enum com.nur.prayer.core.astro.** { *; }
-keepclassmembers enum com.nur.prayer.notify.AzanSound { *; }

# Kotlin coroutines: the debug agent is not shipped.
-dontwarn kotlinx.coroutines.debug.**

# Stack traces from users are worth more than the last few kilobytes.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
