# Как получить APK

## Вариант 1 — GitHub Actions (ничего ставить не надо)

1. Залей содержимое зипа в репозиторий (ветка `main`).
2. Вкладка **Actions** → workflow **APK**. Он запускается сам на пуш; кнопка **Run workflow**
   запускает вручную.
3. Открой завершившийся запуск → блок **Artifacts** → **nur-release-apk**.
4. Распакуй, перекинь `.apk` на телефон, поставь (Android спросит про «установку из этого
   источника» — это нормально для сборки не из магазина).

`nur-release-apk` минифицирован R8, ресурсы обрезаны, подписан debug-ключом Gradle — ставится
обычным способом. `nur-debug-apk` берут только для отладки: он почти вдвое тяжелее.

Если сборка **красная** — открой артефакт `nur-test-reports`: там HTML-отчёты юнит-тестов. Тесты
здесь не формальность, они сверяют расчёт с печатными календарями и валят сборку при расхождении в
одну минуту.

## Вариант 2 — локально

Нужны JDK 17 и Android SDK (platform 34, build-tools 34).

```bash
# Обёртки в репозитории нет: gradle-wrapper.jar — бинарный файл. Создаётся одной командой,
# версия берётся из gradle/wrapper/gradle-wrapper.properties (8.7).
gradle wrapper

./gradlew test              # расчёты, база городов, часовой пояс, календари
./gradlew assembleRelease   # app/build/outputs/apk/release/
./gradlew installRelease    # сразу на подключённый телефон
```

## Проверки, которые не требуют Android SDK

```bash
python3 tools/kt_sanity.py            # exhaustive when, опечатки в enum'ах, парность скобок
python3 tools/kt_symbols.py           # необъявленные имена и именованные аргументы
python3 tools/verify_kazan.py         # календарь ДУМ РТ, 28 значений, 4 дня
python3 tools/verify_uzbekistan.py    # namozvaqti.uz, Бухара, 6 граф + глубина солнца
python3 tools/verify_cities.py        # 424 города: id, страны, пояса, дубли координат
python3 tools/verify_roots.py         # каждый корень движка подтверждён сканом высоты Солнца
python3 tools/verify_tangency.py      # ложные и потерянные корни; --legacy показывает регресс 0.2.5
```

`verify_tangency.py` на всей базе идёт около трёх минут; `--cities 60` — секунд тридцать.
