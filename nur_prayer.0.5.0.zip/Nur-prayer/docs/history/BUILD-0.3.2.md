# Сборка и проверка Nur 0.3.2

## Требования

JDK 17, Gradle 8.9, Android SDK Platform 34 / Build Tools 34.0.0. Зависимости скачиваются из обычных
Google/Maven/Gradle репозиториев. В ZIP нет полноценного Gradle wrapper: используйте установленный
`gradle`, а не несуществующий `./gradlew`. В Android Studio откройте каталог с `settings.gradle.kts`.
При желании обёртку можно сгенерировать командой `gradle wrapper --gradle-version 8.9`.

## До APK

````bash
python3 tools/kt_sanity.py
python3 tools/kt_symbols.py
python3 tools/source_audit.py
python3 tools/test_source_archive.py
python3 tools/test_kt_symbols.py
python3 tools/test_build_regressions.py
python3 tools/verify_cities.py
python3 tools/verify_uz_table.py
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease :app:assembleDebugAndroidTest --stacktrace
````

Lint оставлен в исходном режиме `abortOnError=false`, поэтому обязательно прочитайте HTML-отчёт:
зелёная сборка сама по себе не означает отсутствие lint-замечаний. JVM-тесты и ошибка компиляции
должны останавливать CI. APK: `app/build/outputs/apk/debug/` и `release/`.

## На устройстве или эмуляторе

Подключите устройство с USB debugging либо запустите эмулятор API 26+. Затем:

````bash
gradle :app:connectedDebugAndroidTest
gradle :app:installDebug
````

Пять UI smoke-тестов проверяют поиск/выбор города, компактную карточку, пустой поиск,
действие геолокации и семантику переключателя. Они не заменяют сценарии устройства из
`docs/DEVICE-CHECK-0.3.2.md` и старую матрицу экранов из `docs/QA-0.3.0.md`.

Для сравнения прокрутки используйте release-сборки одинаково подписанных 0.3.1 и 0.3.2,
одно устройство, одинаковые настройки/заряд/температуру. Сбросьте gfxinfo, выполните один и тот же
сценарий поиска и десять быстрых прокруток, затем сохраните framestats. Сравнивайте долю медленных
кадров и p50/p95, а не только визуальное впечатление. В этом пакете такие измерения не выполнены.

## Важное о подписи

Исходная конфигурация сохранена: release минифицируется, но подписывается **тестовым debug-ключом**.
Это удобно для проверки, но не производственная подпись. CI может создавать другой ключ на новом
runner, и APK тогда не установится поверх предыдущего с тем же applicationId. Для настоящих обновлений
настройте постоянный release keystore через GitHub Secrets. Не кладите keystore или пароли в ZIP.

Не удаляйте старое приложение только ради установки бездумно: удаление может стереть настройки.
Сначала обеспечьте тот же сертификат подписи или сохраните необходимые параметры. Debug-вариант
использует суффикс `.debug` и может стоять отдельно; переключение между debug/release не переносит DataStore.

## Граница выполненной проверки

Для 0.3.2 выполнены проверки из `docs/QA-0.3.2.md`. В частности, 23 новых чистых JVM-теста
скомпилированы без изменения исходников отдельным Kotlin 1.5.31 и выполнены на JRE 21;
это не проектная Android-сборка и не замена Kotlin 2.0.20 в Gradle. Проверяемые файлы и версии
внешних smoke-зависимостей перечислены в `docs/jvm-smoke-toolchain-0.3.2.json`.

Повтор изолированной проверки при наличии перечисленных JAR:

````sh
bash tools/verify_location_jvm.sh /path/to/jvm-tool-jars
````

Полные 122 JVM-теста, Android Lint, R8 и APK требуют обычного Gradle CI выше. Пять UI-тестов
нужно запускать на устройстве/эмуляторе; текущий workflow собирает UI-test APK, но не выполняет
тесты. Сценарии телефона перечислены в `docs/DEVICE-CHECK-0.3.2.md`.

В the Computer отсутствуют Gradle и Android SDK. Репозиторий и GitHub Actions от вашего имени
не изменялись. Внешний workflow уже совместим с `nur_prayer.0.3.2.zip`, его менять не требуется.
