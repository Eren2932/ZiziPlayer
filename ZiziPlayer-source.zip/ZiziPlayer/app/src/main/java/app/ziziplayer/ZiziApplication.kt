package app.ziziplayer

import android.app.Application
import androidx.room.Room
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlayerController

class ZiziApplication : Application() {
    lateinit var database: ZiziDatabase; private set
    lateinit var repository: MusicRepository; private set
    lateinit var playerController: PlayerController; private set

    override fun onCreate() {
        super.onCreate()
        database=Room.databaseBuilder(this,ZiziDatabase::class.java,"zizi.db").fallbackToDestructiveMigration().build()
        val settings=SettingsStore(this)
        repository=MusicRepository(this,database.musicDao(),settings,MusicScanner(this))
        playerController=PlayerController(this)
    }
}
