package app.ziziplayer.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [TrackEntity::class, FavoriteEntity::class, PlaylistEntity::class, PlaylistTrackEntity::class, TrackFxEntity::class],
    version = 1,
    exportSchema = true
)
abstract class ZiziDatabase : RoomDatabase() { abstract fun musicDao(): MusicDao }
