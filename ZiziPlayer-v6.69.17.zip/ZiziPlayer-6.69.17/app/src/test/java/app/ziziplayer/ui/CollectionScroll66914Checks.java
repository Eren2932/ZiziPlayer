package app.ziziplayer.ui;

import java.util.Random;

/** Executable production-state tests. No Android or emulated touch claims. */
public final class CollectionScroll66914Checks {
    private static int assertions;
    private static void require(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static void near(double actual, double expected, double tolerance, String message) {
        require(Double.isFinite(actual) && Math.abs(actual - expected) <= tolerance,
            message + ": " + actual + " vs " + expected);
    }
    private static float visual(CollectionScrollPrecision.Sample s) {
        return s.visualScroll(s.index, s.offset, 1000f, 369.04f);
    }
    private static void roundingBoundaryAndHold() {
        CollectionScrollPrecision.Sample s = CollectionScrollPrecision.at(0, 200);
        s = s.rebase(0, 200).after(-.49f, 0, 200);
        float first = visual(s);
        double firstExact = s.pixels;
        s = s.rebase(0, 200).after(-.02f, 0, 201);
        near(visual(s) - first, .02, .00003, "subpixel reversal must not become an integer jump");
        near(s.pixels - firstExact, .02f, 1e-10, "exact consumed input");
        float legacy = CollectionCollapseMath.visualScroll(0, 201, 1000, 369.04f)
            - CollectionCollapseMath.visualScroll(0, 200, 1000, 369.04f);
        near(legacy, 1, 0, "legacy integer jump fixture");
        System.out.printf(java.util.Locale.ROOT,
            "Boundary input %.5f px: legacy %.5f px, precise %.5f px (not a device measurement)%n",
            .02f, legacy, visual(s) - first);
        for (int i=0; i<10000; i++) {
            s = s.rebase(0, 201).after(0f, 0, 201);
            near(visual(s), first + .02f, .00003, "held input stays fixed");
            s = s.rebase(0, 201).after(.02f, 0, 200);
            near(s.pixels, firstExact, 0, "round-trip has no accumulator drift");
            near(visual(s), first, 0, "round-trip restores the same float");
            s = s.rebase(0, 200).after(-.02f, 0, 201);
        }
    }

    /** Compose 1.7.6 retains fractional scrollToBeConsumed and rounds only its layout.
     * This is an independent model of that documented source behavior, not Android execution. */
    private static void quantizedListModel() {
        Random random = new Random(66914);
        double maxError = 0;
        for (float initialPending : new float[]{-.49f, -.20f, 0f, .20f, .49f}) {
            int offset = 240;
            float pending = initialPending;
            double expected = offset;
            CollectionScrollPrecision.Sample s = CollectionScrollPrecision.at(0, offset);
            for (int i=0; i<40000; i++) {
                float dy = (random.nextFloat() - .5f) * .36f;
                s = s.rebase(0, offset);
                pending += dy;
                if (Math.abs(pending) > .5f) {
                    int applied = Math.round(pending);
                    offset -= applied;
                    pending -= applied;
                }
                expected -= (double) dy;
                s = s.after(dy, 0, offset);
                near(s.pixels, expected, 1e-8, "continuous input at a quantized layout");
                near(visual(s), expected, .00004, "float projection must retain subpixels");
                maxError = Math.max(maxError, Math.abs(s.pixels - offset));
                require(Math.abs(s.pixels - offset) <= 1.0001, "bounded real-list anchor");
            }
        }
        System.out.printf(java.util.Locale.ROOT,
            "200000 noisy consumed events: max distance to integer layout %.6f px%n", maxError);
    }

    private static void sampleRateAndContact() {
        CameraMorphGeometry.Target target = new CameraMorphGeometry.Target(521.5f, 49.5f, 558.5f, 86.5f);
        float travel = 369.04f;
        float contact = 0;
        for (int i=130; i<850; i++) {
            float px = i/1000f*travel;
            CameraMorphGeometry.Frame f = frame(px, target);
            CameraMorphGeometry.Goo g = CameraMorphGeometry.goo(target, f);
            if (g != null && g.joined) { contact = px; break; }
        }
        require(contact > 0, "contact fixture exists");
        // Use a half-pixel crossing close to contact, not an arbitrary expanded-header sample.
        int offset = Math.round(contact);
        CollectionScrollPrecision.Sample s = CollectionScrollPrecision.at(0, offset)
            .after(-.49f, 0, offset);
        float before = visual(s);
        float after = visual(s.rebase(0, offset).after(-.02f, 0, offset + 1));
        CameraMorphGeometry.Frame a = frame(before, target), b = frame(after, target);
        CameraMorphGeometry.Frame legacyA = frame(offset, target), legacyB = frame(offset+1, target);
        require(Math.abs(b.width-a.width) < Math.abs(legacyB.width-legacyA.width)*.04f,
            "contact body no longer receives an integer size step");
        System.out.printf(java.util.Locale.ROOT,
            "Contact fixture scroll %.3f px: body-width change legacy %.6f, precise %.6f px%n",
            contact, legacyB.width-legacyA.width, b.width-a.width);
        for (int hz : new int[]{60, 90, 120, 144, 240}) {
            // Different partitions of an identical one-second displacement.
            int start = 200, measured = start;
            float pending = 0;
            CollectionScrollPrecision.Sample v = CollectionScrollPrecision.at(0, measured);
            for (int i=0;i<hz;i++) {
                float dy = -1f/hz;
                v = v.rebase(0, measured);
                pending += dy;
                if (Math.abs(pending) > .5f) {
                    int applied = Math.round(pending);
                    measured -= applied; pending -= applied;
                }
                v = v.after(dy,0,measured);
            }
            near(visual(v), 201f, .00003, "sample-rate invariant displacement");
            double held = v.pixels;
            for (int i=0;i<hz*3;i++) v = v.rebase(0, measured).after(0f,0,measured);
            near(v.pixels, held, 0, "no clock motion during a three-second hold");
        }
    }
    private static CameraMorphGeometry.Frame frame(float scroll, CameraMorphGeometry.Target target) {
        return CameraMorphGeometry.frame(716f, 315.04f, 1f, scroll, 540f, 148f, 18f,
            369.04f, 94f, target);
    }
    private static void restorationAndExternalScroll() {
        CollectionScrollPrecision.Sample s = CollectionScrollPrecision.at(0, 200).after(-.25f,0,200);
        near(s.visualScroll(0, 40, 0, 369), 40, 0, "direct scroll uses actual list immediately");
        s = s.rebase(0, 40);
        near(s.pixels, 40, 0, "next gesture anchors after direct scroll");
        s = s.after(-.125f, 0, 40);
        near(s.pixels, 40.125, 0, "fraction restarts after reanchor");
        s = s.rebase(0,40).after(-.125f,0,85);
        near(s.pixels,85,0,"external layout changes cannot accumulate drift");
        s = s.after(Float.NaN,0,84);
        near(s.pixels,84,0,"NaN is never a visual coordinate");
        s = s.after(Float.POSITIVE_INFINITY,0,84);
        near(s.pixels,84,0,"infinite input is rejected");
        for (int i : new int[]{1,2,12,800}) {
            CollectionScrollPrecision.Sample deep = CollectionScrollPrecision.at(i, 43);
            near(deep.visualScroll(i,43,0,369),369,0,"deep restored hero remains absorbed");
            near(deep.visualScroll(i,43,1400,369),1400,0,"measured deep hero preserved");
            near(deep.after(4f,0,360).pixels,360,0,"reentry anchors without guessing row sizes");
        }
        s=CollectionScrollPrecision.at(0,0).after(100f,0,0);
        near(s.pixels,0,0,"top clamp does not go negative");
        near(s.visualScroll(0,0,0,369),0,0,"expanded header remains expanded");
        require(s.matches(0,0),"anchor identity");
        // Instances are per destination/density; no persisted subpixel offset from another page.
        near(CollectionScrollPrecision.at(0,70).pixels,70,0,"new owner starts from actual layout");
    }
    public static void main(String[] args) {
        roundingBoundaryAndHold(); quantizedListModel(); sampleRateAndContact(); restorationAndExternalScroll();
        System.out.println("PASS: " + assertions + " subpixel/hold/restoration assertions (pure JVM)");
    }
}
