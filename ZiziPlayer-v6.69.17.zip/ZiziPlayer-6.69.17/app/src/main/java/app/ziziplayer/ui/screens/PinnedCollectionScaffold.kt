package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.CollectionHeaderGeometry as H
import app.ziziplayer.ui.CollectionGeometry as G
import app.ziziplayer.ui.CollectionCollapseMath as M
import app.ziziplayer.ui.CollectionScrollPrecision
import app.ziziplayer.ui.components.CameraMorphDebug
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.CollectionCoverMorphOverlay
import app.ziziplayer.ui.components.rememberCameraCutout
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.roundToInt

@Stable
internal class CollectionCollapseState(initial: Float = 0f) {
    var fraction by mutableFloatStateOf(M.clamp(initial, 1f))
    fun consume(dy: Float, range: Float): Float {
        if (range <= 0f) return 0f
        val old = fraction * range
        val next = M.next(old, dy, range)
        fraction = next / range
        return old - next
    }
    companion object {
        val saver = Saver<CollectionCollapseState, Float>(save = { it.fraction },
            restore = { CollectionCollapseState(it) })
    }
}

/** Shared by local collections, home mixes and remote albums/playlists; NOT artists.
 * No timer animates scroll: consumed distance, cover size and pinned controls agree.
 */
@Composable
internal fun PinnedCollectionScaffold(
    destination: String,
    title: String,
    tint: Color,
    trackCount: Int,
    playingHere: Boolean,
    playEnabled: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    artwork: @Composable () -> Unit,
    hero: @Composable () -> Unit,
    selectionToolbar: (@Composable () -> Unit)? = null,
    collectionRows: LazyListScope.() -> Unit
) {
    val p = LocalPalette.current
    val base = Color(0xFF121212)
    val density = LocalDensity.current
    val camera = rememberCameraCutout()
    val list = rememberSaveable(destination, saver = LazyListState.Saver) { LazyListState() }
    LaunchedEffect(list) {
        snapshotFlow { list.isScrollInProgress }.collectLatest { moving ->
            while (moving) { ArtworkCache.markBusy(); delay(120) }
        }
    }
    val collapseState = rememberSaveable(destination, saver = CollectionCollapseState.saver) { CollectionCollapseState() }
    // Not saveable: integer list state is the restoration anchor. Keep this sample
    // across gestures (including finger-up) so there is no rounding snap on release.
    var preciseScroll by remember(list, density) {
        mutableStateOf(CollectionScrollPrecision.at(list.firstVisibleItemIndex,
            list.firstVisibleItemScrollOffset))
    }
    var heroPx by remember(destination, density.fontScale) { mutableIntStateOf(0) }
    BoxWithConstraints(Modifier.fillMaxSize().background(base).testTag("collection:viewport")) {
        val status = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val toolbar = 56.dp
        val metrics = CollectionHeaderMetrics(H.unit(maxWidth.value))
        val playSize = metrics.touchSize
        val coverMax = (H.COVER_SIZE * metrics.unit).dp
        val coverMin = (coverMax * 0.44f).coerceAtLeast(64.dp).coerceAtMost(coverMax)
        val rangePx = with(density) { (coverMax - coverMin).toPx() }
        val connection = remember(collapseState, list, rangePx, density) {
            object : NestedScrollConnection {
                private var before = preciseScroll
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    before = preciseScroll.rebase(list.firstVisibleItemIndex,
                        list.firstVisibleItemScrollOffset)
                    return Offset(0f, if (available.y < 0f && list.firstVisibleItemIndex == 0 &&
                        list.firstVisibleItemScrollOffset == 0) collapseState.consume(available.y, rangePx) else 0f)
                }
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    val index = list.firstVisibleItemIndex
                    val offset = list.firstVisibleItemScrollOffset
                    preciseScroll = before.after(consumed.y, index, offset)
                    val expanded = if (available.y > 0f && index == 0 && offset == 0)
                        collapseState.consume(available.y, rangePx) else 0f
                    // The shrink phase still owns the top of the list. A private pending
                    // LazyList fraction must not force frame() into phase two on reversal.
                    if (index == 0 && offset == 0 && collapseState.fraction < 1f)
                        preciseScroll = CollectionScrollPrecision.at(index, offset)
                    CameraMorphDebug.recordScroll(index, offset,
                        preciseScroll.pixels.toFloat(), consumed.y, available.y)
                    return Offset(0f, expanded)
                }
            }
        }
        val toolbarPx = with(density) { toolbar.toPx() }
        val playPx = with(density) { playSize.toPx() }
        val playBottomGapPx = with(density) { metrics.bottomGap.toPx() }
        val pinnedPx = toolbarPx - playPx / 2f
        val expandedPx = (heroPx - playPx - playBottomGapPx).coerceAtLeast(pinnedPx)
        val bottom = LocalBottomChromeInset.current + 24.dp
        // Conservative for BOTH width-scaled local rows and fixed 71dp remote rows.
        val minimumRows = (G.ROW * maxWidth.value / G.REFERENCE_WIDTH).dp
            .coerceAtMost(MediaDimensions.trackRow) * trackCount
        val tail = G.minimumPinnedTail((maxHeight - status).value, minimumRows.value, bottom.value,
            playSize.value, metrics.bottomGap.value, (toolbar - playSize / 2).value).dp
        val morphTravelPx = with(density) { (coverMin + (H.COVER_TOP * metrics.unit).dp).toPx() }
        // The lazy hero is absent on a restored deep list. Its missing measurement
        // must not resurrect the cover, toolbar or unpinned Play button.
        fun scrollPx(): Float = preciseScroll.visualScroll(list.firstVisibleItemIndex,
            list.firstVisibleItemScrollOffset, heroPx.toFloat(), morphTravelPx)
        val headerReady by remember(list, heroPx) {
            derivedStateOf { heroPx > 0 || list.firstVisibleItemIndex > 0 }
        }
        fun collapse(): Float = M.banner(scrollPx(), expandedPx - pinnedPx)
        // One visibility source for the scrim, title and menu. Re-key measured travel
        // after width/font/hero changes; a remembered lambda must not retain old geometry.
        val bannerAlpha by remember(list, density, heroPx, expandedPx, pinnedPx, morphTravelPx) {
            derivedStateOf {
                if (list.firstVisibleItemIndex > 0) 1f else if (heroPx > 0) collapse() else 0f
            }
        }
        val toolbarVisibleForSemantics = bannerAlpha >= 1f
        val statusPx = with(density) { status.toPx() }
        // One window-space ramp: no independently coloured status strip. Its position
        // follows the same measured hero/list pixels, so there is no seam while scrolling.
        Box(Modifier.fillMaxSize().drawWithCache {
            onDrawBehind {
                val top = statusPx - scrollPx()
                if (heroPx > 0) drawRect(Brush.verticalGradient(listOf(tint, base),
                    startY = top, endY = top + heroPx))
                else drawRect(tint, size = Size(size.width, statusPx))
                // Continue the pinned toolbar's tint under system icons, not black glass.
                if (bannerAlpha > 0f) drawRect(tint, size = Size(size.width, statusPx),
                    alpha = bannerAlpha)
            }
        })
        // Only the list viewport is inset/clipped. The artwork overlay can reach the cutout.
        LazyColumn(state = list, modifier = Modifier.fillMaxSize().padding(top = status).nestedScroll(connection).testTag("collection:list"),
            contentPadding = PaddingValues(bottom = bottom)) {
            item(key = "selection:hero", contentType = "hero") {
                Column(Modifier.fillMaxWidth().onSizeChanged { heroPx = it.height }) {
                    Spacer(Modifier.height((H.COVER_TOP * metrics.unit).dp))
                    Box(Modifier.fillMaxWidth().padding(bottom = (H.COVER_TITLE_GAP * metrics.unit).dp), contentAlignment = Alignment.Center) {
                        val coverSize = M.coverSize(coverMax.value, coverMin.value, collapseState.fraction).dp
                        // Measured slot only; the image is composed exactly once in the overlay.
                        Box(Modifier.size(coverSize).testTag("collection:cover"))
                    }
                    CompositionLocalProvider(LocalCollectionHeaderMetrics provides metrics,
                        LocalCollectionActionsAlpha provides (1f - bannerAlpha)) { hero() }
                }
            }
            collectionRows()
            item(key = "selection:tail", contentType = "spacer") { Spacer(Modifier.height(tail)) }
        }
        CollectionCoverMorphOverlay(
            camera = camera, maximum = coverMax, minimum = coverMin,
            coverTop = (H.COVER_TOP * metrics.unit).dp,
            corner = (H.COVER_RADIUS * metrics.unit).dp, status = status,
            fraction = { collapseState.fraction }, scroll = { scrollPx() }, artwork = artwork
        )
        // Controls stay above the passive artwork layer and below Android system icons.
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            if (bannerAlpha > 0f) Box(Modifier.fillMaxWidth().height(toolbar)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .clearAndSetSemantics { }
                .graphicsLayer { alpha = bannerAlpha }.background(tint))
            if (selectionToolbar != null) Box(Modifier.fillMaxWidth().height(toolbar).background(tint)) { selectionToolbar() }
            else {
                Row(Modifier.fillMaxWidth().height(toolbar).padding(start = 6.dp, end = metrics.touchEnd + playSize + 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).testTag("collection:banner").padding(start = 8.dp).graphicsLayer { alpha = bannerAlpha }
                            .then(if (toolbarVisibleForSemantics) Modifier else Modifier.clearAndSetSemantics {}))

                }
                // One Play instance moves with the measured hero and pins to the toolbar.
                IconButton(onClick = onPlay, enabled = playEnabled && headerReady,
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = metrics.touchEnd)
                        .offset { IntOffset(0, G.pinnedPlayTop(scrollPx(), expandedPx, pinnedPx).roundToInt()) }
                        .graphicsLayer { alpha = if (headerReady) 1f else 0f }
                        .size(playSize).testTag("collection:play")) {
                    Box(Modifier.size(metrics.playDisk).clip(CircleShape)
                        .background(if (playEnabled) p.brand else p.chip), contentAlignment = Alignment.Center) {
                        Icon(if (playingHere) ZiziIcons.Pause else ZiziIcons.CollectionPlayFilled,
                            if (playingHere) "Пауза" else "Слушать подборку", tint = Color.Black,
                            modifier = Modifier.size(if (playingHere) metrics.playDisk * 0.46f else metrics.playDisk))
                    }
                }
            }
        }
    }
}

/** Hero-only controls; the menu scrolls away with this row, never pins into the banner. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun CollectionActionsRow(
    onShuffle: () -> Unit,
    shuffleEnabled: Boolean,
    shuffleDescription: String = "Перемешать подборку",
    onMenu: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    val p = LocalPalette.current
    val m = LocalCollectionHeaderMetrics.current
    val actionAlpha = LocalCollectionActionsAlpha.current
    val actionsEnabled = actionAlpha > 0f
    Row(Modifier.fillMaxWidth().heightIn(min = m.touchSize)
        .padding(start = (H.CONTENT_START * m.unit).dp,
            end = m.touchEnd + m.touchSize + m.actionGap).testTag("collection:actions")
            .graphicsLayer { alpha = actionAlpha }
            .then(if (actionsEnabled) Modifier else Modifier.clearAndSetSemantics {}),
        verticalAlignment = Alignment.Bottom) {
        FlowRow(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            actions()
            if (onMenu != null) IconButton(onClick = onMenu, enabled = actionsEnabled,
                modifier = Modifier.size(m.touchSize).testTag("collection:menu")) {
                Icon(ZiziIcons.More, "Меню плейлиста", tint = p.subtext)
            }
        }
        IconButton(onClick = onShuffle, enabled = actionsEnabled && shuffleEnabled,
            modifier = Modifier.size(m.touchSize).testTag("collection:shuffle")) {
            Icon(ZiziIcons.Shuffle, shuffleDescription,
                tint = if (shuffleEnabled) p.brand else p.subtext,
                modifier = Modifier.size((H.SHUFFLE_CANVAS * m.unit).dp))
        }
    }
}
