package app.ziziplayer.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PixelMap
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.test.filters.SdkSuppress
import app.ziziplayer.ui.components.CameraCutoutSnapshot
import app.ziziplayer.ui.components.CameraMorphDebug
import app.ziziplayer.ui.components.CollectionCoverMorphOverlay
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** REAL Compose/RenderEffect tests. JVM preflight cannot mark these as passed. */
@SdkSuppress(minSdkVersion = 31)
class CameraGooey66915UiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private val cutoutReady = mutableStateOf(true)
    private val progress = mutableFloatStateOf(0f)
    private val redraw = mutableIntStateOf(0)
    private val background = Color(0xFF304050)
    private var frame: CameraMorphGeometry.Frame? = null
    private var target: CameraMorphGeometry.Target? = null
    private var status = 0f
    private var mounts = 0
    private var disposals = 0

    @After fun stopTrace() { compose.runOnIdle { CameraMorphDebug.stopTrace() } }

    @Suppress("DEPRECATION")
    private fun mount(pattern: Boolean = false, corner: Boolean = false, right: Boolean = false, physicalHole: Boolean = false) {
        compose.activity.runOnUiThread {
            WindowCompat.setDecorFitsSystemWindows(compose.activity.window, false)
            compose.activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            compose.activity.window.isStatusBarContrastEnforced = false
        }
        compose.runOnIdle { CameraMorphDebug.startTrace() }
        compose.setContent {
            BoxWithConstraints(Modifier.fillMaxSize().background(background).testTag("gooey:66915")) {
                val density = LocalDensity.current
                val w = with(density) { maxWidth.toPx() }
                val h = with(density) { maxHeight.toPx() }
                val statusPx = WindowInsets.statusBars.getTop(density)
                status = statusPx.toFloat()
                val snapshot = remember(w, h, statusPx, corner, right, cutoutReady.value) {
                    val diameter = statusPx*.55f
                    val x = w * if (right) .88f else if (corner) .12f else .5f
                    val t = CameraMorphGeometry.Target(x-diameter/2, statusPx*.5f-diameter/2,
                        x+diameter/2, statusPx*.5f+diameter/2)
                    CameraCutoutSnapshot(target=if(cutoutReady.value) t else null, outline=Path().apply {
                        addOval(Rect(t.left,t.top,t.right,t.bottom))
                    }, windowWidth=w.roundToInt(), windowHeight=h.roundToInt(),
                        statusTop=statusPx, exact=true, reason="Gooey GPU fixture")
                }
                val unit = CollectionHeaderGeometry.unit(maxWidth.value)
                val maximum = (CollectionHeaderGeometry.COVER_SIZE*unit).dp
                val minimum = (maximum*.44f).coerceAtLeast(64.dp).coerceAtMost(maximum)
                val top = (CollectionHeaderGeometry.COVER_TOP*unit).dp
                val travel = with(density) { (minimum+top).toPx() }
                target = snapshot.target
                frame = CameraGooeyGeometry.frame(with(density) { maximum.toPx() },
                    with(density) { minimum.toPx() },1f,progress.floatValue*travel,w*.5f,
                    statusPx+with(density) { top.toPx() },0f,travel,statusPx.toFloat(),snapshot.target)
                CollectionCoverMorphOverlay(camera=snapshot, maximum=maximum, minimum=minimum,
                    coverTop=top, corner=0.dp, status=with(density) { statusPx.toDp() },
                    fraction={ 1f }, scroll={ progress.floatValue*travel }, artwork={
                        DisposableEffect(Unit) { mounts++; onDispose { disposals++ } }
                        Canvas(Modifier.fillMaxSize()) {
                            check(redraw.intValue >= 0)
                            drawRect(Color.White)
                            if (pattern) {
                                val stripe = size.width/64f
                                for (i in 0 until 64 step 2) drawRect(Color.Black,
                                    topLeft=Offset(i*stripe,0f), size=Size(stripe,size.height))
                            }
                        }
                    })
                // Model a NON-RENDERABLE hardware hole ABOVE the app image. A test
                // that only sees the software circle cannot prove physical attachment.
                if (physicalHole) Canvas(Modifier.fillMaxSize()) {
                    snapshot.target?.let { t ->
                        drawCircle(Color.Black, t.width()*.5f, Offset(t.cx(),t.cy()))
                    }
                }
            }
        }
        compose.waitForIdle()
        compose.runOnIdle {
            assertEquals("Tests must exercise DEFAULT GPU route", "gooey-gpu", CameraMorphDebug.lastFrame?.renderer)
        }
    }
    private fun at(p: Float): PixelMap {
        compose.runOnIdle { progress.floatValue=p }
        compose.waitForIdle()
        return compose.onNodeWithTag("gooey:66915").captureToImage().toPixelMap()
    }
    private fun foreground(c: Color): Boolean =
        abs(c.red-background.red)+abs(c.green-background.green)+abs(c.blue-background.blue) > .12f
    private fun same(a: PixelMap, b: PixelMap) {
        assertEquals(a.width,b.width); assertEquals(a.height,b.height)
        var error=0f
        for (y in ceil(status).toInt()+1 until minOf(a.height,(status+a.width).toInt()) step 2) {
            for (x in 0 until a.width step 2) {
                val c=a[x,y]; val d=b[x,y]
                error=maxOf(error,abs(c.red-d.red),abs(c.green-d.green),abs(c.blue-d.blue))
            }
        }
        assertTrue("Same subpixel position must restore pixels: $error", error<=.025f)
    }
    private fun midGap(p: Float): Pair<PixelMap, Offset> {
        val image=at(p); val t=requireNotNull(target); val f=requireNotNull(frame)
        return image to Offset(t.cx(), (t.bottom+f.top())*.5f)
    }
    private fun connected(p: Float): Boolean {
        val (image, point)=midGap(p)
        return foreground(image[point.x.roundToInt(),point.y.roundToInt()])
    }
    @Test fun centralGpuFirstBridgeIsThinAndGrows() {
        mount()
        var low=.005f; var high=.65f
        assertTrue("Separated before approach",!connected(low))
        assertTrue("Blur tails must join before completion",connected(high))
        repeat(10) { val p=(low+high)*.5f; if(connected(p)) high=p else low=p }
        val (image,point)=midGap(high)
        val t=requireNotNull(target); val f=requireNotNull(frame)
        assertTrue("A real bridge, not overlapping bodies",f.top()>t.bottom+1f)
        val x=point.x.roundToInt(); val y=point.y.roundToInt()
        fun width(pixels: PixelMap, cx: Int, cy: Int): Int {
            var l=cx; var r=cx
            while(l>0 && foreground(pixels[l-1,cy])) l--
            while(r+1<pixels.width && foreground(pixels[r+1,cy])) r++
            return r-l+1
        }
        val first=width(image,x,y)
        assertTrue("Initial waist must not be a full-width slab: $first",first<t.width())
        val (later,laterPoint)=midGap((high+.03f).coerceAtMost(.65f))
        assertTrue("Neck widens after contact",width(later,laterPoint.x.roundToInt(),laterPoint.y.roundToInt())>=first)
    }
    @Test fun gpuCutoutDiscoveryDoesNotRemountArtwork() {
        cutoutReady.value=false
        mount(pattern=true)
        at(.2f)
        compose.runOnIdle { cutoutReady.value=true }
        at(.2f)
        compose.runOnIdle { assertEquals(1,mounts); assertEquals(0,disposals) }
    }
    @Test fun gpuBodyBothSidesRemainFilled() {
        mount()
        for(p in listOf(.10f,.25f,.40f,.55f,.65f)) {
            val image=at(p); val f=requireNotNull(frame)
            for(side in listOf(-.25f,0f,.25f)) {
                val x=(f.cx+side*f.width).roundToInt(); val y=(f.cy+.2f*f.height).roundToInt()
                assertTrue("Body probe below status",y>status)
                assertTrue("No hole in body p=$p side=$side",foreground(image[x,y]))
            }
        }
    }
    @Test fun gpuHoldSubpixelReverseKeepsOneArtwork() {
        mount(pattern=true)
        val a=at(.4f)
        repeat(3) { compose.runOnIdle { redraw.intValue++ }; compose.waitForIdle(); same(a,at(.4f)) }
        repeat(4) { at(.40003f); same(a,at(.4f)); at(.39997f); same(a,at(.4f)) }
        compose.mainClock.advanceTimeBy(3000)
        same(a,at(.4f))
        compose.runOnIdle { assertEquals(1,mounts); assertEquals(0,disposals) }
    }
    @Test fun gpuCompletionClearsCutoutAndReversalRestores() {
        mount()
        val before=at(.4f)
        for(p in listOf(1f,1.2f)) {
            val image=at(p); val t=requireNotNull(target)
            for(y in t.top.toInt()..t.bottom.toInt()) for(x in t.left.toInt()..t.right.toInt()) {
                val c=image[x,y]
                assertEquals(background.red,c.red,.015f)
                assertEquals(background.green,c.green,.015f)
                assertEquals(background.blue,c.blue,.015f)
            }
        }
        same(before,at(.4f))
    }
    @Test fun gpuDetailPassActuallyBlurs() {
        mount(pattern=true)
        fun variance(image: PixelMap): Pair<Float,Float> {
            val f=requireNotNull(frame)
            var sum=0f; var square=0f; var n=0
            for(y in (f.cy+.15f*f.height).toInt()..(f.cy+.2f*f.height).toInt()) {
                for(x in (f.cx-.2f*f.width).toInt()..(f.cx+.2f*f.width).toInt()) {
                    val v=image[x,y].red; sum+=v; square+=v*v; n++
                }
            }
            return sum/n to (square/n-(sum/n)*(sum/n)).coerceAtLeast(0f)
        }
        val sharp=variance(at(0f)); val blurred=variance(at(.4f))
        assertTrue("Pattern has detail",sharp.second>.10f)
        assertTrue("RenderEffect removes high-frequency detail",blurred.second<sharp.second*.45f)
        assertTrue("Not merely a black replacement",blurred.first>.20f)
    }
    @Test fun cornerGpuRoundTripUsesCutoutNotScreenCenter() {
        mount(pattern=true,corner=true)
        val a=at(.55f); val f=requireNotNull(frame); val t=requireNotNull(target)
        assertTrue("Artwork approaches actual corner cutout",abs(f.cx-t.cx())<t.width()*2)
        at(.7f); same(a,at(.55f)); at(.3f); same(a,at(.55f))
    }
    // 6.69.16: previous tests only proved the artwork-side bridge. They did not
    // detect a camera lobe erased by blur, or a dot floating below a physical hole.
    private fun cameraEmerges(corner: Boolean = false, right: Boolean = false) {
        mount(corner=corner,right=right,physicalHole=true)
        // 6.69.17: one 15px kernel (reference). The hole disc itself shrinks under the
        // threshold; what leaves the hole is the camera seed, whose h peaks at p=.5.
        val image=at(.5f)
        val t=requireNotNull(target); val f=requireNotNull(frame)
        val dx=f.cx-t.cx(); val dy=f.cy-t.cy()
        val length=kotlin.math.hypot(dx,dy)
        val radius=t.width()*.5f
        assertTrue("Nominal bodies are separate",length>radius+f.width*.5f)
        // Probe beyond the hardware mask, not its always-black centre. At every
        // pixel between the edge and this tip there must be app-generated ink.
        val extension=maxOf(2f,radius*.20f)
        val steps=ceil(extension).toInt()
        for(i in 1..steps) {
            val distance=radius+i*extension/steps
            val x=(t.cx()+dx/length*distance).roundToInt()
            val y=(t.cy()+dy/length*distance).roundToInt()
            assertTrue("Camera lobe missing outside physical hole at ($x,$y)",foreground(image[x,y]))
        }
    }
    @Test fun centralPhysicalHoleGrowsItsOwnLobe66916() { cameraEmerges() }
    @Test fun leftPhysicalHoleGrowsItsOwnLobe66916() { cameraEmerges(corner=true) }
    @Test fun rightPhysicalHoleGrowsItsOwnLobe66916() { cameraEmerges(right=true) }

    @Test fun physicalHoleAndArtworkRemainJoinedUntilAbsorption66916() {
        mount(physicalHole=true)
        for(p in listOf(.60f,.75f,.88f)) {
            val image=at(p); val t=requireNotNull(target); val f=requireNotNull(frame)
            for(i in 0..100) {
                val u=i/100f
                val x=(t.cx()+(f.cx-t.cx())*u).roundToInt()
                val y=(t.cy()+(f.cy-t.cy())*u).roundToInt()
                assertTrue("Detached dot/neck at p=$p y=$y",foreground(image[x,y]))
            }
        }
        val final=at(1f); val t=requireNotNull(target)
        assertEquals("Hardware camera remains",0f,final[t.cx().roundToInt(),t.cy().roundToInt()].red,.01f)
        // The hardware is static; only app-generated pixels must disappear.
        for(y in ceil(t.bottom+2f).toInt()..ceil(t.bottom+t.height()).toInt()) {
            assertTrue("No residual marker below camera",!foreground(final[t.cx().roundToInt(),y]))
        }
        val forward=at(.25f); at(.8f); same(forward,at(.25f))
    }

}
