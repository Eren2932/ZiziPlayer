package app.ziziplayer.ui;

import java.util.Locale;

/** Production geometry tests. Raster tests consume the samples from THIS Java code. */
public final class CameraAnchor66916Checks {
    private static int assertions;
    private static void check(boolean ok, String why) {
        assertions++;
        if (!ok) throw new AssertionError(why);
    }
    private static void near(float a, float b, String why) {
        check(Float.isFinite(a) && Math.abs(a-b) < .001f, why + ": " + a + " != " + b);
    }
    public static void main(String[] args) {
        boolean samples = args.length > 0 && args[0].equals("samples");
        for (float density : new float[]{1f, 2f, 2.75f, 3f, 4f}) {
            for (float diameterDp : new float[]{8f, 12.333333f, 20f, 32f}) {
                for (float xFraction : new float[]{.12f, .5f, .88f}) {
                    float width = 360f*density, height = 800f*density;
                    float cx = width*xFraction, cy = 22.666666f*density;
                    float radius = diameterDp*density*.5f;
                    var t = new CameraMorphGeometry.Target(cx-radius,cy-radius,cx+radius,cy+radius);
                    float blur = CameraGooeyGeometry.cameraBlurRadius(t);
                    check(blur > 0f && blur <= CameraGooeyGeometry.BLUR_RADIUS, "Bounded positive kernel");
                    check(2f*blur*CameraGooeyGeometry.GOO_SCALE <= radius+.001f,
                        "Camera core must survive before threshold");
                    for (int i=0;i<=100;i++) {
                        float p=i/100f;
                        var f = CameraGooeyGeometry.frame(238.66667f*density,105.01333f*density,
                            1f,123.01333f*density*p,width*.5f,49.33333f*density,6f*density,
                            123.01333f*density,31.33333f*density,t);
                        var s = CameraGooeyGeometry.seeds(t,f,density);
                        near(blur,CameraGooeyGeometry.cameraBlurRadius(t),"Kernel does not pulse with scroll");
                        if (samples && i % 5 == 0) {
                            System.out.printf(Locale.ROOT,"%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f",
                                density,diameterDp,xFraction,p,cx,cy,radius,blur,f.cx,f.cy,f.width,f.imageAlpha);
                            for(float v:s.camera) System.out.printf(Locale.ROOT," %.6f",v);
                            for(float v:s.artwork) System.out.printf(Locale.ROOT," %.6f",v);
                            System.out.println();
                        }
                    }
                    var raw = new CameraMorphGeometry.Target(cx-radius,0,cx+radius,36.66667f*density);
                    var estimate = CameraMorphGeometry.compactTopEstimate(raw,width,height,36.66667f*density,density);
                    // The existing admission rejects overly tall or wide reservations; no guessing.
                    if (estimate != null) {
                        near(estimate.width(),2*radius,"Do not shrink the system width");
                        near(estimate.bottom,raw.bottom,"Do not shift the system bottom");
                        near(estimate.cx(),cx,"No hard-coded horizontal camera position");
                    }
                }
            }
        }
        near(CameraGooeyGeometry.cameraBlurRadius(null),15f,"Null is finite");
        near(CameraGooeyGeometry.cameraBlurRadius(new CameraMorphGeometry.Target(0,0,Float.NaN,30)),15f,"NaN is finite");
        near(CameraGooeyGeometry.cameraBlurRadius(new CameraMorphGeometry.Target(0,0,300,300)),15f,"Large hole keeps upstream kernel");
        if (!samples) System.out.println("PASS: "+assertions+" production camera-core assertions (not Android rendering)");
    }
}
