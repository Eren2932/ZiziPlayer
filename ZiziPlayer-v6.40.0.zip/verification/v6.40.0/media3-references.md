# Проверенные исходники Media3 1.5.1

Это сверка API и порядка вызовов, не компиляция проекта.

- https://github.com/androidx/media/blob/1.5.1/libraries/common/src/main/java/androidx/media3/common/ForwardingPlayer.java
- https://github.com/androidx/media/blob/1.5.1/libraries/session/src/main/java/androidx/media3/session/MediaSessionImpl.java
- https://github.com/androidx/media/blob/1.5.1/libraries/session/src/main/java/androidx/media3/session/MediaSessionService.java
- https://github.com/androidx/media/blob/1.5.1/libraries/session/src/main/java/androidx/media3/session/MediaNotificationManager.java

Сигнатуры set/add/replaceMediaItem(s) и play/pause доступны в используемой
версии. MediaSessionImpl.handleMediaControllerPlayRequest вызывает
onPlayRequested до передачи play проигрывателю. Сохранён путь штатной
медиасессии к foreground; фактический запуск из уведомления на API 35/36
остаётся в обязательной приёмке на устройстве.
