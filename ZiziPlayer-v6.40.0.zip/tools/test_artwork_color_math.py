#!/usr/bin/env python3
"""Compile and execute the real platform-free Java core; no translated/mirrored algorithm."""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))

def main():
    with tempfile.TemporaryDirectory(prefix='zizi-colour-jvm-') as out:
        sources = [ROOT / 'app/src/main/java/app/ziziplayer/ui/theme/ArtworkColorMath.java',
                   ROOT / 'app/src/test/java/app/ziziplayer/ui/ArtworkColorMathChecks.java']
        # The compiler module is available even on JDK images without a javac launcher.
        # source/target 17 also works in the offline JDK image whose ct.sym is absent.
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                        '-d', out, *map(str, sources)], check=True)
        subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.ArtworkColorMathChecks',
                        str(ROOT / 'tools/fixtures/artwork')], check=True)

if __name__ == '__main__':
    main()
