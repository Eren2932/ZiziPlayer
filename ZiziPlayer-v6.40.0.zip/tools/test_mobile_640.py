#!/usr/bin/env python3
"""Compile and execute actual production Java rules, not a Python reimplementation."""
from pathlib import Path
import os
import subprocess
import tempfile
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
if __name__ == '__main__':
    paths = ['app/src/main/java/app/ziziplayer/playback/AudioInterruptionPolicy.java',
             'app/src/main/java/app/ziziplayer/privacy/PrivacyRules.java',
             'app/src/test/java/app/ziziplayer/privacy/Mobile640Checks.java']
    with tempfile.TemporaryDirectory(prefix='zizi-640-') as output:
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                        *[str(ROOT / p) for p in paths]], check=True)
        subprocess.run(['java', '-cp', output, 'app.ziziplayer.privacy.Mobile640Checks'], check=True)
