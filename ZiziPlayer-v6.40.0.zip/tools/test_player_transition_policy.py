#!/usr/bin/env python3
"""Compile/execute real platform-free Java ownership policy, not a Python port."""
from pathlib import Path
import os
import subprocess
import tempfile
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
def main():
    with tempfile.TemporaryDirectory(prefix='zizi-transition-jvm-') as out:
        sources = [ROOT / 'app/src/main/java/app/ziziplayer/ui/motion/PlayerTransitionPolicy.java',
                   ROOT / 'app/src/test/java/app/ziziplayer/ui/PlayerTransitionChecks.java']
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                        '-d', out, *map(str, sources)], check=True)
        subprocess.run(['java', '-cp', out, 'app.ziziplayer.ui.PlayerTransitionChecks'], check=True)
if __name__ == '__main__':
    main()
