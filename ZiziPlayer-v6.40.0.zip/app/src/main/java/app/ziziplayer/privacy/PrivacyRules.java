package app.ziziplayer.privacy;

import java.util.Set;

/** Shared production rules; not a simulated copy of Android UI logic. */
public final class PrivacyRules {
    private PrivacyRules() {}
    public static boolean blocks(boolean unlocked, boolean remote, String folder, Set<String> hidden) {
        return !unlocked && !remote && hidden.contains(folder);
    }
    public static long retryDelay(int failures) {
        if (failures < 5) return 0L;
        return Math.min(300_000L, 30_000L * (1L << Math.min(4, failures - 5)));
    }
    /** Includes the skipped center node exactly like Android's pattern grid. */
    public static String appendPattern(String path, int node) {
        char next = (char) ('0' + node);
        if (node < 0 || node > 8 || path.indexOf(next) >= 0) return path;
        if (path.isEmpty()) return String.valueOf(next);
        int last = path.charAt(path.length() - 1) - '0';
        int dx = node % 3 - last % 3, dy = node / 3 - last / 3;
        if ((Math.abs(dx) == 2 || Math.abs(dy) == 2) && dx % 2 == 0 && dy % 2 == 0) {
            char middle = (char) ('0' + (last + node) / 2);
            if (path.indexOf(middle) < 0) path += middle;
        }
        return path + next;
    }
}
