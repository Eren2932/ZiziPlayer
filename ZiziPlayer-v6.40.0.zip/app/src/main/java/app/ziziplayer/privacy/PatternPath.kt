package app.ziziplayer.privacy

/** The same production path rule is executed in offline JVM checks. */
object PatternPath {
    fun append(path: String, node: Int): String = PrivacyRules.appendPattern(path, node)
}
