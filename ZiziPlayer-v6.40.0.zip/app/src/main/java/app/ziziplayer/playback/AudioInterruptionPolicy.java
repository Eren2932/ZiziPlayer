package app.ziziplayer.playback;

/** Platform-free resume intent. Android focus callbacks are interpreted only by FocusPlayer. */
public final class AudioInterruptionPolicy {
    private boolean resumePending;
    public boolean isResumePending() { return resumePending; }
    public void transientLoss(boolean wasPlaying) { resumePending = resumePending || wasPlaying; }
    public boolean gain() { boolean resume = resumePending; resumePending = false; return resume; }
    /** User pause, noisy route, stop, permanent loss, failed/replaced request and release. */
    public void cancel() { resumePending = false; }
    public static final float DUCK_GAIN = 0.08f;
    public static final long ATTACK_MS = 180L;
    public static final long RELEASE_MS = 450L;
    public static float interpolate(float start, float target, float fraction) {
        float t = Math.max(0f, Math.min(1f, fraction));
        return start + (target - start) * t * t * (3f - 2f * t);
    }
}
