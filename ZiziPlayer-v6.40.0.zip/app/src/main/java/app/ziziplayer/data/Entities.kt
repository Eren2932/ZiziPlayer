package app.ziziplayer.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Where a row came from.
 *
 * Plain string constants rather than an enum with a TypeConverter, for one blunt reason: the
 * migration below has to declare `DEFAULT 'local'` at the SQL level, and the column Room expects
 * must match that byte for byte or the database refuses to open on every device that upgrades.
 * A converter adds a layer between those two facts for no benefit.
 */
object TrackSource {
    const val LOCAL = "local"
    const val REMOTE = "remote"
}

@Entity(
    tableName = "tracks",
    indices = [
        Index(value = ["uri"], unique = true),
        // Every library query filters on it, on every keystroke.
        Index(value = ["source"]),
        // One row per remote track, whatever path led to it. NULLs are distinct in SQLite, so all
        // local rows (provider = NULL) coexist happily under a unique index.
        Index(value = ["provider", "remoteId"], unique = true),
        // 6.19.0 — три индекса под то, что список делает на каждом кадре.
        //
        // observeTracks() сортирует по title COLLATE NOCASE, экран папки фильтрует по
        // sourceFolder, сортировка «недавние» — по dateAdded. Без индексов каждая из этих операций
        // это полный проход по таблице с временной сортировкой в памяти SQLite: на 5000 треков
        // ощутимо, и хуже всего это видно там, где заметнее всего — на первом кадре после запуска.
        // Цена индекса здесь честная и низкая: таблица пишется пачками при сканировании, а
        // читается непрерывно.
        Index(value = ["title"]),
        Index(value = ["sourceFolder"]),
        Index(value = ["dateAdded"])
    ]
)
data class TrackEntity(
    /** Derived from the file, not from the provider row. See [TrackId]. */
    @PrimaryKey val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long,
    val artworkUri: String? = null,
    val sourceFolder: String = "Устройство",
    val dateAdded: Long = System.currentTimeMillis(),
    /**
     * Part of the identity, and the reason a rescan can skip re-reading tags: a file whose size is
     * unchanged has unchanged metadata.
     */
    @ColumnInfo(defaultValue = "0") val sizeBytes: Long = 0L,
    /**
     * The id this row would have had under the v6.2 scheme. Filled by the scanner and consumed
     * exactly once, by the one-shot remap in [MusicRepository]; null afterwards for new rows.
     */
    val legacyId: String? = null,
    /** [TrackSource.LOCAL] or [TrackSource.REMOTE]. */
    @ColumnInfo(defaultValue = TrackSource.LOCAL) val source: String = TrackSource.LOCAL,
    /** Catalogue id for remote rows, null for local ones. */
    val provider: String? = null,
    /** The provider's own id, needed to resolve a stream. */
    val remoteId: String? = null,
    /**
     * When the user chose to keep this remote track.
     *
     * This one nullable Long is what separates "я это слушал" from "это моё". Only saved remote
     * tracks appear in the library; the rest exist purely so the mini player, the queue and the
     * play counters can resolve an id, and they are swept later. Without the split, one evening of
     * poking at search would bury a hand-curated local library under hundreds of strangers.
     */
    val savedAt: Long? = null,
    /** Last time this row was played or returned by search. Drives the sweep of unsaved rows. */
    @ColumnInfo(defaultValue = "0") val lastSeenAt: Long = 0L
) {
    val isRemote: Boolean get() = source == TrackSource.REMOTE
}

/** A query the user actually ran, for the search hub's history list. */
@Entity(tableName = "search_history")
data class SearchQueryEntity(
    @PrimaryKey val query: String,
    val queriedAt: Long = System.currentTimeMillis()
)

/**
 * Недавнее — то, что человек ОТКРЫВАЛ, а не то, что он вводил (6.27.0).
 *
 * Таблица нарочно плоская и нарочно без внешнего ключа на `tracks`. Причина та же, по которой
 * во всей базе нет каскадов (см. MIGRATION_5_6): `upsertTracks` работает через REPLACE, то есть
 * DELETE + INSERT, а `sweepRemote` регулярно подметает временные удалённые треки. Ссылка на
 * `tracks.id` умирала бы при каждом пересканировании и каждой чистке кэша — и «Недавние»
 * пустели бы сами по себе, без единого действия человека. Здесь хранится копия того минимума,
 * которого хватает, чтобы нарисовать строку и собрать объект обратно.
 *
 * [key] — ключ идентичности, а не строка отображения: `t:r:<провайдер>:<id>` для трека,
 * `c:<провайдер>:<id>` для сборника, `q:<запрос в нижнем регистре>` для запроса. Один и тот же
 * объект, открытый тремя разными путями, обязан быть ОДНОЙ строкой, которая всплывает наверх,
 * а не тремя одинаковыми: REPLACE по этому ключу и делает всплытие.
 *
 * Индекс по [openedAt] стоит потому, что единственный запрос к этой таблице — «последние 30 по
 * убыванию времени», и без индекса это сортировка всей таблицы на каждом кадре подписки.
 */
@Entity(tableName = "recents", indices = [Index("openedAt")])
data class RecentEntity(
    @PrimaryKey val key: String,
    /** См. [RecentKind]. Строка, а не enum: enum в Room — это конвертер ради четырёх значений. */
    val kind: String,
    val title: String,
    val subtitle: String = "",
    val artworkUrl: String? = null,
    val provider: String? = null,
    val remoteId: String? = null,
    /** Для трека — тот же id, что в `tracks`. Нужен, чтобы строка знала про «+» и про играющее. */
    val trackId: String? = null,
    val durationMs: Long = 0L,
    val openedAt: Long = System.currentTimeMillis()
)

object RecentKind {
    const val TRACK = "track"
    const val ALBUM = "album"
    const val PLAYLIST = "playlist"
    const val ARTIST = "artist"
    const val QUERY = "query"
}

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val trackId: String, val addedAt: Long = System.currentTimeMillis())

/**
 * Копия трека, которая переживает потерю самого трека (6.27.1).
 *
 * Жалоба «избранное не отображается» разбиралась на две разные причины, и обе лечатся тут.
 *
 * Первая: сетевой трек, отмеченный сердцем, но не сохранённый в медиатеку, вообще не попадал в
 * [MusicDao.observeTracks] — тот отдаёт `source = 'local' OR savedAt IS NOT NULL`. Фильтр
 * «Избранное» строился фильтрацией этого же списка, то есть искал лайкнутый трек в списке, где
 * его по определению нет. Сердце горело, экран был пуст. Это лечится отдельным запросом
 * [MusicDao.observeFavoriteTracks] — избранное берётся JOIN'ом по таблице, а не выборкой из
 * медиатеки.
 *
 * Вторая: строка трека действительно могла умереть. `upsertTracks` работает через REPLACE
 * (DELETE + INSERT), `rescan` удаляет всё, чего не нашёл на диске, а `pruneFavorites` вычищал
 * лайки, у которых не осталось трека. Цепочка сходилась молча и необратимо: файл переехал —
 * лайка нет. Здесь лежит тот минимум, из которого трек собирается обратно, поэтому теперь
 * потеря строки — это ремонтируемая ситуация, а не потеря данных.
 *
 * Таблица плоская и без внешнего ключа — ровно по той же причине, что и `recents`: ссылка на
 * `tracks.id` умирала бы вместе с тем, что она обязана переживать.
 */
@Entity(tableName = "favorite_shadow")
data class FavoriteShadowEntity(
    @PrimaryKey val trackId: String,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val artworkUri: String?,
    val sourceFolder: String,
    val source: String,
    val provider: String?,
    val remoteId: String?,
    val addedAt: Long
)

/**
 * [coverUri] — 6.27.1. NULL означает «обложку никто не задавал», и тогда её выбирает экран:
 * первый трек плейлиста, а если плейлист пуст — базовая обложка, сгенерированная из имени.
 *
 * Колонка нужна ровно для одного правила: обложку плейлисту даёт ПЕРВЫЙ добавленный в него
 * сборник, и никакой из следующих её не перебивает (см. [MusicDao.setPlaylistCoverIfEmpty]).
 * Без колонки «первый добавленный» было бы невыразимо: состав меняется, порядок треков
 * меняется, а обложка обязана стоять на месте — по ней человек узнаёт свой плейлист в списке.
 */
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val coverUri: String? = null
)

/**
 * Составной первичный ключ (playlistId, trackId) индексирует только тот порядок, в котором он
 * объявлен, — то есть поиск «треки этого плейлиста» быстрый, а поиск «в каких плейлистах этот
 * трек» и любой JOIN по trackId идут полным проходом. Именно так работают все пять prune-запросов
 * и подсчёт общего времени, поэтому второй индекс добавлен явно (6.19.0).
 */
@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "trackId"],
    indices = [Index(value = ["trackId"])]
)
data class PlaylistTrackEntity(val playlistId: Long, val trackId: String, val position: Int)

/**
 * Связь «сборник из поиска -> мой плейлист» (6.17.0).
 *
 * Нужна ровно для двух вещей, и обе видны пользователю: галочка на альбоме/плейлисте, который он
 * уже добавлял, и повторное нажатие, которое этот плейлист убирает. Хранить связь в имени
 * плейлиста было бы дешевле на одну таблицу и дороже на всё остальное: имя человек переименует
 * в тот же вечер, и отметка отвалится.
 *
 * Строка живёт, пока жив плейлист: [MusicDao.unlinkPlaylist] вызывается при удалении, а
 * [MusicDao.pruneLinks] подчищает то, что удалили в обход (импорт, миграция, ручная правка).
 */
@Entity(tableName = "playlist_links", indices = [Index(value = ["playlistId"])])
data class PlaylistLinkEntity(
    /** "<provider>:<remoteId>" — то, чем сборник опознаётся в каталоге. */
    @PrimaryKey val collectionKey: String,
    val playlistId: Long,
    val title: String,
    /**
     * true — плейлист СОЗДАН из этого сборника, значит повторное нажатие вправе удалить его
     * целиком. false — пользователь добавил сборник в свой давний плейлист, и удалять чужое
     * приложение не имеет права: оттуда убираются только треки сборника.
     */
    val owned: Boolean = true,
    val linkedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "track_fx")
data class TrackFxEntity(
    @PrimaryKey val trackId: String,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    /**
     * Наследие 6.x: проценты прошивочного `PresetReverb`. Колонка НЕ удаляется и не обнуляется.
     * Её читает [app.ziziplayer.playback.dsp.DspConfig.withLegacyReverb] ровно один раз — когда у
     * трека ещё нет [eqConfig], — и превращает старую настройку в наш ревер. Удалить колонку
     * значило бы молча стереть то, что человек крутил руками полгода.
     */
    val reverb: Int = 0,
    /**
     * 6.24.4. Весь звуковой тракт трека одной строкой `DspCodec` (`v1|on=1;bands=...`).
     *
     * NULL, а не пустая строка, и разница принципиальная: NULL означает «у этого трека тракт
     * никогда не настраивали» — тогда в дело идёт [reverb] и/или глобальный профиль. Пустая
     * строка или `on=0` означают «человек сознательно выключил обработку», и глобальный профиль
     * поверх этого решения уже не лезет.
     */
    val eqConfig: String? = null
)

/**
 * 6.24.4. Пользовательский пресет эквалайзера — имя плюс та же самая строка [DspCodec].
 *
 * Отдельной таблицей, а не набором колонок: пресетов может быть сколько угодно, а схема при
 * добавлении нового параметра в тракт не меняется вообще — строка кодека версионирована сама.
 * Ключ — имя: два пресета «Бас» это ошибка ввода, а не две записи, и REPLACE по имени делает
 * «сохранить поверх» бесплатно.
 */
@Entity(tableName = "eq_profiles")
data class EqProfileEntity(
    @PrimaryKey val name: String,
    val config: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "hidden")
data class HiddenEntity(@PrimaryKey val trackId: String, val hiddenAt: Long = System.currentTimeMillis())

@Entity(tableName = "play_stats")
data class PlayStatEntity(
    @PrimaryKey val trackId: String,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L
)

/** Projection used to show "N tracks" next to a playlist without loading its rows. */
data class PlaylistCount(val playlistId: Long, val total: Int)

/** Сумма длительностей плейлиста, считается тем же запросом, что и количество (6.17.0). */
data class PlaylistDuration(val playlistId: Long, val totalMs: Long)

/** То, что подпись под плейлистом показывает целиком: «12 треков · 48 мин». */
data class PlaylistMeta(
    val count: Int = 0,
    val totalMs: Long = 0L,
    /**
     * Первый трек плейлиста — источник обложки, когда своей у плейлиста нет (6.27.1).
     *
     * Именно первый по позиции, а не «первый с картинкой»: плейлист узнаётся по началу, и если
     * начало сменилось, обложка обязана смениться вместе с ним. Пропускать треки без картинки
     * значило бы, что обложка плейлиста берётся из середины списка, и человек не мог бы понять,
     * почему она такая.
     */
    val cover: TrackEntity? = null
)

/** Строка «первый трек плейлиста». См. [PlaylistMeta.cover]. */
data class PlaylistCoverRow(val playlistId: Long, @Embedded val track: TrackEntity)

/** Ordered playlist projection for privacy-safe covers, counts and durations. */
data class PlaylistVaultRow(val playlistId: Long, @Embedded val track: TrackEntity)
