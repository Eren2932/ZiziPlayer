package app.ziziplayer.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.AudioOutput
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.OutputKind
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalBackdropBlend
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziPalette
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import app.ziziplayer.ui.motion.PlayerTransitionPolicy
import kotlin.math.floor
import kotlin.math.absoluteValue
import androidx.media3.common.Player
import app.ziziplayer.ui.components.ZiziIcons

@Composable
fun PlayerScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onClose: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    val queue by vm.queue.collectAsStateWithLifecycle()
    // 6.33.0. Куда уходит звук прямо сейчас. Читается ровно одним местом — нижней строкой.
    val audioOutput by vm.audioOutput.collectAsStateWithLifecycle()
    val blend = LocalBackdropBlend.current
    val tintEnabled = state.settings.accentFromArtwork

    /*
     * THE MISMATCH BUG, and why it was structural rather than a race to patch.
     *
     * The carousel is a pager over the QUEUE, so the cover on screen is `queue[page]`. The title
     * under it was read from `currentTrack`, i.e. from whatever the PLAYER says is playing. Two
     * independent sources for one statement: the instant they disagree - a fast flick whose settle
     * handler has not fired, an auto-advance that landed mid-gesture, a seek the controller latched
     * - the screen shows one cover and names a different track. A faster handshake could only
     * narrow that window; it could never close it.
     *
     * The pager state is hoisted here and the PAGE is now the single source of truth for
     * everything the screen SAYS. Cover and title are the same fact and cannot disagree by
     * construction, whatever the player is doing behind them.
     */
    // The visible queue can omit unavailable library rows: Media3's raw index is not a page.
    val playerPage = remember(queue, playback.currentTrackId) {
        queue.indexOfFirst { it.id == playback.currentTrackId }
    }
    val pagerState = rememberPagerState(initialPage = playerPage.coerceAtLeast(0)) { queue.size }
    val shownTrack = queue.getOrNull(pagerState.currentPage) ?: currentTrack
    val gesture = remember(pagerState) { PlayerTransitionPolicy.Gesture() }
    var gestureRevision by remember(pagerState) { mutableIntStateOf(0) }
    // At most four small colour entries, never a queue-wide scan or image decode per frame.
    val pagePalettes = remember(tintEnabled) { PagePaletteCache() }

    /** Palette of any queue page, from cached swatches only - never blocks a gesture. */
    fun paletteOf(track: TrackEntity?): ZiziPalette {
        if (track == null || !tintEnabled) return basePalette()
        val swatches = ArtworkCache.peekSwatches(track)
        return pagePalettes.get(track, swatches)
    }

    if (queue.isNotEmpty()) {
        PagerPlaybackSync(
            pagerState = pagerState,
            queue = queue,
            playerTrackId = playback.currentTrackId,
            playingId = { vm.playback.value.currentTrackId },
            gesture = gesture,
            gestureRevision = gestureRevision,
            onGestureChanged = { gestureRevision++ },
            onGestureStarted = { if (tintEnabled) blend.beginGesture() },
            onGestureCancelled = { blend.cancelGesture() },
            onSettled = { trackId ->
                val track = queue.firstOrNull { it.id == trackId }
                val origin = vm.playback.value.currentTrackId
                if (track != null && tintEnabled) blend.hold(origin, trackId, paletteOf(track))
                else blend.cancelGesture()
                // Identity, not page number: the UI queue and Media3 timeline may differ.
                vm.playFromQueue(trackId)
                if (vm.playback.value.currentTrackId != trackId) blend.cancelGesture()
            }
        )
        BackdropSwipeBlend(
            pagerState = pagerState,
            gesture = gesture,
            gestureRevision = gestureRevision,
            tintEnabled = tintEnabled,
            paletteAt = { page -> paletteOf(queue.getOrNull(page)) }
        )
    }
    // A transport tap supersedes an unfinished gesture, even at the end of the queue where
    // Media3 keeps the same id. No debounce, sleep or dropped clicks are introduced.
    fun transport(action: () -> Unit) {
        gesture.cancel()
        blend.cancelGesture()
        action()
        gestureRevision++
    }
    DisposableEffect(pagerState) { onDispose { blend.cancelGesture() } }

    var showFx by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        PlayerHeader(
            // 6.8.0 said "ПАПКА НА УСТРОЙСТВЕ" over every track, including the ones streaming from
            // a CDN. A caption that is false for half the queue is worse than no caption: it sent
            // us looking for a local file that never existed.
            caption = if (shownTrack?.isRemote == true) "ПОТОК ИЗ СЕТИ" else "ПАПКА НА УСТРОЙСТВЕ",
            source = shownTrack?.sourceFolder ?: "ZIZI",
            onClose = onClose,
            onMenu = { if (shownTrack != null) showMenu = true }
        )

        // 6.34.0. ОБЛОЖКА БОЛЬШЕ НЕ ВИСИТ ПОД ШАПКОЙ.
        //
        // До этого свободное место было одно и стояло ПОД обложкой: `Spacer(6.dp)` сверху и
        // `weight(1f)` снизу. Из-за этого обложка прижималась к шапке, а весь низ уезжал к
        // краю экрана — на кадре 1080x2400 наша обложка стояла на y=291 при 448 у референса,
        // а ряд транспорта сидел на 112 px ниже эталонного. Это и есть «плеер спустился вниз»:
        // на самом деле вниз уехал низ, а обложка уехала вверх.
        //
        // Теперь свободного места ДВА, и оно делится в измеренной пропорции. Замер эталонного
        // кадра (1080x2400, 2.75 px/dp): от низа шапки до верха обложки 173.5 px, от низа
        // обложки до верха подписи 202 px. Доли 0.462 / 0.538 — это они и есть. Доли, а не dp:
        // на экране другой высоты воздух должен делиться в той же пропорции, иначе на коротком
        // экране обложка снова прилипнет к шапке, а на длинном оторвётся от подписи.
        Spacer(Modifier.weight(COVER_SPACE_ABOVE))

        CoverCarousel(
            queue = queue,
            pagerState = pagerState,
            isPlaying = playback.isPlaying,
            onPrevious = { transport(vm::previous) },
            onNext = { transport(vm::next) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.weight(COVER_SPACE_BELOW))

        // 6.33.0. ПОДПИСЬ ПОД ОБЛОЖКОЙ ПЕРЕСОБРАНА ПО ЭТАЛОННОМУ КАДРУ.
        //
        // Замер (кадр 576x1280, 1.5556 px/dp): высота прописной в названии 24 px = 15.4 dp, то
        // есть кегль 21.5 sp, а не 25; у исполнителя 19 px = 16.5 sp, а не 15. Это не «сделать
        // помельче»: в референсе разница между строками мала намеренно — они читаются как одна
        // подпись, а не как заголовок и сноска. Расстояние между базовыми линиями 33 px = 21.2 dp,
        // при новых кеглях естественный интервал даёт 22.3, поэтому вторая строка поднята на
        // 1.1 dp сдвигом в фазе layout (высота колонки при этом не врёт).
        //
        // Отступ слева 24 dp — тот же, что у дорожки и у нижней строки: в референсе весь контент
        // стоит по одной левой линии, и любое «22 тут, 20 там» видно глазом как дрожь края.
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                // Scrolled, not truncated: this is the one screen whose whole job is to tell you
                // what is playing, and it was ending half the library in an ellipsis.
                MarqueeText(
                    text = shownTrack?.title ?: "Ничего не играет",
                    color = p.text,
                    fontSize = 21.5.sp,
                    fontWeight = FontWeight.Bold
                )
                // The artist line stays static on purpose: two things moving under one cover is
                // restless, and the reference scrolls the title only.
                Text(
                    text = shownTrack?.artist ?: "—",
                    color = p.subtext,
                    fontSize = 16.5.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.offset(y = (-1.1).dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            val favorite = shownTrack != null && state.favoriteIds.contains(shownTrack.id)
            // 6.33.0. Кружок стал 29 dp — ровно как отметка в референсе (45 px на кадре), —
            // но палец по-прежнему бьёт по 46 dp: рисунок ужался, площадь нажатия нет. Внешний
            // Box держит прежний габарит и центрирует знак, поэтому правый край кружка встаёт на
            // те же 24.5 dp от края экрана, что и в оригинале.
            //
            // Отмеченное состояние теперь ЗАЛИТО брендовым оранжевым, как зелёная отметка в
            // референсе: цвет знака на тёмной плашке — это «включено», а залитый кружок — «уже
            // в вашей музыке». Разница видна с метра, а не с двадцати сантиметров.
            Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                RoundIconButton(
                    icon = ZiziIcons.HeartFilled,
                    tint = if (favorite) p.onAccent else p.text.copy(alpha = 0.62f),
                    background = if (favorite) p.brand else p.chip.copy(alpha = 0.55f),
                    size = 29,
                    iconSize = 17,
                    onClick = { shownTrack?.let { vm.toggleFavorite(it) } }
                )
            }
            // Второе троеточие стояло здесь. Убрано: две кнопки в 46 dp друг от друга, ведущие в
            // одно и то же меню, — это не удобство, а грязь и промахи пальцем. Сердечко остаётся:
            // избранное это одно движение, ради него меню открывать не надо.
        }

        // 6.33.0. РЯДА «ТАБЛЕТОК» БОЛЬШЕ НЕТ.
        //
        // «Скорость и тон», «Таймер сна», «В плейлист», «Папки» уехали в троеточие в шапке
        // целиком, вместе со своей логикой: экран плеера показывает, ЧТО играет, и управляет
        // воспроизведением, а настройки трека — это меню. Четыре плашки под названием съедали
        // 62 dp по вертикали и заставляли всё остальное — дорожку, время, транспорт — стоять
        // ниже, чем в референсе, и жаться друг к другу.
        //
        // Ни одно действие не потеряно и ни одно состояние не осталось висеть: showFx,
        // showSleep и showPlaylists теперь поднимаются из TrackMenuSheet, «Папки» — пункт того
        // же меню и кнопка внизу. Таймер сна виден в меню строкой «12 мин», активная скорость —
        // в самом листе эффектов.
        //
        // Вертикальные интервалы ниже — не «на глаз». Замер эталонного кадра (1.5556 px/dp):
        // базовая линия исполнителя -> центр дорожки 32.8 dp; центр дорожки -> верх цифр
        // времени 12.2 dp; низ цифр -> верх круга Play 12.2 dp; низ круга -> центр нижней
        // строки 40.5 dp. Числа в Spacer'ах — это те же расстояния за вычетом собственных
        // метрик шрифта и высоты компонентов, посчитанные один раз и записанные здесь.
        // 6.34.0: 12.2 -> 8.6 dp. Перемер на полном кадре 1080x2400 (а не на уменьшенном
        // 576x1280, с которого снимали 6.33.0): от верха прописной в названии до центра
        // дорожки в референсе 200 px, у нас было 210.
        Spacer(Modifier.height(8.6.dp))

        // Isolated: the position updates twice per second and must not touch the rest of the screen.
        PlayerProgress(vm)

        // 6.34.0. Здесь больше нет отступа, и это не экономия, а исправление.
        //
        // Расстояние «центр дорожки -> центр круга Play» у нас было 213.5 px против 188 у
        // референса. Складывалось оно из половины полосы жеста (41 px), высоты строки времени
        // и этого отступа. Полосу жеста трогать нельзя — палец, — поэтому лишние 25.5 px сняты
        // с высоты строки времени (см. PlayerProgress) и с этого отступа целиком.
        PlayerControls(
            isPlaying = playback.isPlaying,
            shuffle = playback.shuffle,
            repeatMode = playback.repeatMode,
            onShuffle = vm::toggleShuffle,
            onPrevious = { transport(vm::previous) },
            onPlayPause = vm::playPause,
            onNext = { transport(vm::next) },
            onRepeat = vm::cycleRepeat
        )

        Spacer(Modifier.height(11.5.dp))

        PlayerBottomBar(
            output = audioOutput,
            onQueue = { showQueue = true },
            onFolders = { vm.setFilter(LibraryFilter.FOLDERS); onClose() }
        )

        // 6.34.0. ВОЗДУХ ПОД НИЖНЕЙ СТРОКОЙ.
        //
        // В референсе центр нижней строки стоит в 200 px от края экрана, у нас — в 89. Мы
        // упирали строку в самый низ, потому что под ней не было ничего, кроме системного
        // отступа, а он на жестовой навигации равен нулю. 40 dp — это те самые 110 px, и
        // именно они поднимают ВЕСЬ низ плеера (кнопки, время, дорожку, подпись) на место:
        // всё, что стоит после гибкого промежутка, прижато к низу колонки.
        Spacer(Modifier.height(40.dp))
    }

    // Sheets that talk ABOUT the track follow the page, like the title does. FX are the one
    // exception: they retune the audio, so they belong to whatever is actually audible.
    val track = shownTrack
    if (showFx && currentTrack != null) {
        FxSheet(
            vm = vm,
            track = currentTrack,
            onOpenEqualizer = { showFx = false; onOpenEqualizer() },
            onDismiss = { showFx = false }
        )
    }
    if (showSleep) SleepSheet(playback.sleepMinutesLeft, { vm.setSleepTimer(it); showSleep = false }) { showSleep = false }
    if (showQueue) QueueSheet(
        tracks = queue,
        currentTrackId = playback.currentTrackId,
        isPlaying = playback.isPlaying,
        onPick = { vm.playFromQueue(it) },
        onSaveAsPlaylist = { vm.saveQueueAsPlaylist("Очередь ${queue.size}"); showQueue = false },
        onDismiss = { showQueue = false }
    )
    if (showPlaylists && track != null) PlaylistPickerSheet(
        playlists = state.playlists,
        onPick = { vm.addToPlaylist(it, track.id); showPlaylists = false },
        onCreate = { vm.createPlaylist(it, listOf(track)); showPlaylists = false },
        onDismiss = { showPlaylists = false }
    )
    // Only the open menu / info sheet needs the disk-backed state; never block the player frame.
    val menuDownload = rememberMenuDownloadState(
        vm, track.takeIf { showMenu || showInfo }, track?.let { downloads[it.id] }
    )
    val downloadStatus = menuDownload.status
    if (showMenu && track != null) TrackMenuSheet(
        favorite = state.favoriteIds.contains(track.id),
        sleepMinutesLeft = playback.sleepMinutesLeft,
        track = track,
        inPlaylist = state.openPlaylist,
        queueSize = queue.size,
        download = downloadStatus,
        downloadChecking = menuDownload.checking,
        onPlayNext = { vm.playNext(track); showMenu = false },
        onAddToQueue = { vm.addToQueue(track); showMenu = false },
        onQueue = { showMenu = false; showQueue = true },
        onGoToArtist = { showMenu = false; vm.openArtist(track.artist); onClose() },
        onDownload = { vm.download(track) },
        onCancelDownload = { vm.cancelDownload(track) },
        onRemoveDownload = { vm.removeDownload(track) },
        onInfo = { showMenu = false; showInfo = true },
        onDismiss = { showMenu = false },
        onFx = { showMenu = false; showFx = true },
        onSleep = { showMenu = false; showSleep = true },
        onAddToPlaylist = { showMenu = false; showPlaylists = true },
        onFolders = { showMenu = false; vm.setFilter(LibraryFilter.FOLDERS); onClose() },
        onRemoveFromPlaylist = {
            state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
            showMenu = false
        },
        onToggleFavorite = { vm.toggleFavorite(track) },
        onHide = { vm.removeFromApp(track); showMenu = false },
        onDeleteFile = { showMenu = false; confirmDelete = track },
        onShare = { onShare(track); showMenu = false }
    )
    if (showInfo && track != null) TrackInfoSheet(
        track = track,
        plays = state.stats[track.id]?.playCount ?: 0,
        downloaded = downloadStatus == DownloadStatus.Done,
        downloadChecking = menuDownload.checking,
        streamLabel = vm.streamStatusLabel(),
        onDismiss = { showInfo = false }
    )
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Это действие нельзя отменить.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
}

@Composable
private fun PlayerHeader(caption: String, source: String, onClose: () -> Unit, onMenu: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(
            icon = ZiziIcons.ChevronDown,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            // 6.29.3: 31 против 30 — габарит шеврона в референсе 19.65 dp, у нас было 19.06.
            iconSize = 31,
            onClick = onClose
        )
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                caption,
                color = p.subtext.copy(alpha = 0.85f),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp
            )
            Text(
                text = source,
                color = p.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
        // 6.23.0: здесь была «Поделиться» — одна функция на самом дорогом месте экрана, при том
        // что поделиться можно было и из меню у названия. Теперь тут единственное троеточие на
        // весь плеер, как в Spotify и YT Music, а «поделиться» стало одним из его пунктов.
        RoundIconButton(
            icon = ZiziIcons.More,
            tint = p.text,
            background = Color.Transparent,
            size = 46,
            // 6.29.3: 24 против 22 — общая высота троеточия в референсе 18.92 dp.
            iconSize = 24,
            onClick = onMenu
        )
    }
}

/**
 * Cover carousel.
 *
 * Geometry is measured from the VK reference on a 1080 px screen: the paused cover is 808 px
 * (74.6 % of the width) and its neighbours peek out by 89 px. So the pager is laid out at the
 * PAUSED size and the playing state only scales the focused page up by 1.114 inside a
 * graphicsLayer. Nothing is re-measured when playback starts or stops, which is why the
 * transition cannot stutter, and the side covers become clearly visible on pause.
 */
/** Bounded memoisation for cached/fallback swatches, including late cache replacement. */
private class PagePaletteCache {
    private val values = object : LinkedHashMap<String, Pair<ArtSwatches, ZiziPalette>>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<ArtSwatches, ZiziPalette>>?): Boolean = size > 4
    }
    fun get(track: TrackEntity, cached: ArtSwatches?): ZiziPalette {
        values[track.id]?.takeIf { cached == null || it.first == cached }?.let { return it.second }
        // Fallback is also memoised: never allocate/rehash its colours for every drag sample.
        val swatches = cached ?: fallbackSwatches(track)
        val palette = basePalette().tintedWith(swatches).withAccent(swatches)
        values[track.id] = swatches to palette
        return palette
    }
}

/**
 * Only a real pointer drag owns a seek. Cancelling/re-targeting animateScrollToPage never
 * becomes a user command. There is no pending-index lock and no timing-based 80 ms handshake.
 * A newer player target cancels the previous animation and starts from its actual offset.
 */
@Composable
private fun PagerPlaybackSync(
    pagerState: PagerState,
    queue: List<TrackEntity>,
    playerTrackId: String?,
    playingId: () -> String?,
    gesture: PlayerTransitionPolicy.Gesture,
    gestureRevision: Int,
    onGestureChanged: () -> Unit,
    onGestureStarted: () -> Unit,
    onGestureCancelled: () -> Unit,
    onSettled: (String) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val liveQueue by rememberUpdatedState(queue)
    val livePlayingId by rememberUpdatedState(playingId)
    val changed by rememberUpdatedState(onGestureChanged)
    val started by rememberUpdatedState(onGestureStarted)
    val cancelled by rememberUpdatedState(onGestureCancelled)
    val settle by rememberUpdatedState(onSettled)
    val revision by rememberUpdatedState(gestureRevision)
    // Replacing/reordering the queue invalidates the gesture's page identity, not just its size.
    val queueIds = remember(queue) { queue.map { it.id } }
    DisposableEffect(pagerState, queueIds) {
        onDispose {
            gesture.cancel()
            cancelled()
            changed()
        }
    }

    LaunchedEffect(pagerState) {
        pagerState.interactionSource.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> { gesture.start(); started(); changed() }
                is DragInteraction.Stop -> { gesture.stop(); changed() }
                is DragInteraction.Cancel -> { gesture.cancel(); cancelled(); changed() }
            }
        }
    }
    LaunchedEffect(pagerState) {
        snapshotFlow {
            revision // Java policy has no dependency on Compose; this is its invalidation signal.
            gesture.ready(pagerState.isScrollInProgress)
        }.collect { ready ->
            if (!ready) return@collect
            val trackId = liveQueue.getOrNull(pagerState.currentPage)?.id
            val requested = gesture.finish(pagerState.isScrollInProgress, trackId, livePlayingId())
            if (requested != null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                settle(requested)
            } else cancelled()
            changed()
        }
    }

    LaunchedEffect(pagerState, queueIds, playerTrackId, gestureRevision) {
        if (gesture.isActive) return@LaunchedEffect
        // Read the controller's published value directly: a just-issued swipe command may
        // already be acknowledged while the composable's playerTrackId is one emission behind.
        val target = queueIds.indexOf(livePlayingId())
        if (target < 0) return@LaunchedEffect
        if (pagerState.currentPage == target &&
            pagerState.currentPageOffsetFraction.absoluteValue < 0.0001f &&
            !pagerState.isScrollInProgress) return@LaunchedEffect
        if ((pagerState.currentPage - target).absoluteValue > 2) pagerState.scrollToPage(target)
        else pagerState.animateScrollToPage(target, animationSpec = tween(220, easing = FastOutSlowInEasing))
    }
}

/**
 * Absolute page coordinates, independent of the playing index. At page B we paint B,
 * including the frame where Media3 changes A -> B. Programmatic scrolls do not write here.
 * No loads: existing carousel requests fill the artwork cache; misses use the same fallback
 * as the app theme. Palette conversions are memoised, the fraction never enters composition.
 */
@Composable
private fun BackdropSwipeBlend(
    pagerState: PagerState,
    gesture: PlayerTransitionPolicy.Gesture,
    gestureRevision: Int,
    tintEnabled: Boolean,
    paletteAt: (Int) -> ZiziPalette
) {
    val blend = LocalBackdropBlend.current
    val livePaletteAt by rememberUpdatedState(paletteAt)
    val revision by rememberUpdatedState(gestureRevision)
    LaunchedEffect(pagerState, tintEnabled) {
        if (!tintEnabled) { blend.cancelGesture(); return@LaunchedEffect }
        snapshotFlow {
            revision
            if (gesture.isActive) pagerState.currentPage + pagerState.currentPageOffsetFraction else null
        }.collect { position ->
            if (position == null) return@collect
            val left = floor(position).toInt().coerceIn(0, (pagerState.pageCount - 1).coerceAtLeast(0))
            val right = (left + 1).coerceAtMost((pagerState.pageCount - 1).coerceAtLeast(0))
            blend.drag(livePaletteAt(left), livePaletteAt(right), (position - left).coerceIn(0f, 1f))
        }
    }
}

/**
 * 6.34.0. ГЕОМЕТРИЯ ОБЛОЖКИ — ОДНИМ МЕСТОМ.
 *
 * Замер эталонного кадра 1080x2400 (2.75 px/dp), обложка снята по краю, а не по контенту:
 * сторона 942 px = 0.872 ширины экрана, радиус угла 20-21 px = 0.022 стороны, верх на y=448.
 * У нас было 897 px (0.831) и радиус 76 px — то есть обложка была мельче на 45 px и заметно
 * круглее по углам: 0.085 стороны против 0.022. Отсюда и ощущение «у нас мягче, у них квадрат».
 *
 * [COVER_PAUSED] не изменился: это размер обложки на паузе, от него же считается вылет соседей
 * в карусели. Изменился множитель игры — теперь он ровно [COVER_PLAYING] / [COVER_PAUSED], и
 * играющая обложка приходит точно в эталонный размер, а не «примерно туда».
 */
private const val COVER_PAUSED = 0.746f
private const val COVER_PLAYING = 0.872f
private const val COVER_PLAY_SCALE = COVER_PLAYING / COVER_PAUSED
private const val COVER_CORNER = 0.022f

/** Доли свободного места над обложкой и под ней. Замер: 173.5 px и 202 px эталонного кадра. */
private const val COVER_SPACE_ABOVE = 0.462f
private const val COVER_SPACE_BELOW = 0.538f

@Composable
private fun CoverCarousel(
    queue: List<TrackEntity>,
    pagerState: PagerState,
    isPlaying: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (queue.isEmpty()) {
        BoxWithConstraints(modifier) {
            val size = maxWidth * COVER_PAUSED
            Box(
                Modifier
                    .size(maxWidth * COVER_PLAYING)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                TrackArtwork(
                    track = null,
                    maxPx = ARTWORK_FULL_PX,
                    modifier = Modifier
                        .size(size)
                        .clip(RoundedCornerShape(size * COVER_CORNER)),
                    glyphSize = 64,
                    allowSlow = true
                )
            }
        }
        return
    }

    // Playing/paused factor: animated as a plain Animatable and read only inside graphicsLayer, so
    // the whole transition happens in the draw phase without a single recomposition.
    val playFactor = remember { Animatable(if (isPlaying) 1f else 0f) }
    LaunchedEffect(isPlaying) {
        playFactor.animateTo(
            if (isPlaying) 1f else 0f,
            spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium)
        )
    }

    // Swiping covers is also a scroll: nothing expensive may start behind it.
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.isScrollInProgress }.collectLatest { scrolling ->
            while (scrolling) {
                ArtworkCache.markBusy()
                delay(120)
            }
        }
    }

    // The pager <-> player handshake now lives in PagerPlaybackSync, next to the screen that owns
    // the pager state. A view that both REPORTS a gesture and OBEYS a correction cannot keep the
    // two straight - that is how the cover and the title drifted apart in the first place.
    val accessibleTrack = queue.getOrNull(pagerState.currentPage)
    // TalkBack actions go through the same explicit transport path. Hiding Pager's implicit
    // scroll semantics avoids a non-pointer accessibility scroll moving only the picture.
    BoxWithConstraints(modifier.clearAndSetSemantics {
        contentDescription = accessibleTrack?.let { "Обложка: ${it.title}, ${it.artist}" } ?: "Обложка"
        customActions = listOf(
            CustomAccessibilityAction("Предыдущий трек") { onPrevious(); true },
            CustomAccessibilityAction("Следующий трек") { onNext(); true }
        )
    }) {
        val screenWidth = maxWidth
        val pausedCover = screenWidth * COVER_PAUSED
        val playingCover = screenWidth * COVER_PLAYING
        val sidePadding = (screenWidth - pausedCover) / 2
        val corner = pausedCover * COVER_CORNER
        val shape = remember(corner) { RoundedCornerShape(corner) }

        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = sidePadding),
            pageSpacing = 17.dp,
            beyondViewportPageCount = 1,
            key = { index -> queue.getOrNull(index)?.id ?: index.toString() },
            modifier = Modifier
                .fillMaxWidth()
                .height(playingCover)
        ) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(pausedCover)
                        .graphicsLayer {
                            // Deferred reads: scroll offset and play factor only trigger a redraw.
                            val distance = ((pagerState.currentPage - page) +
                                pagerState.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            val focus = 1f - distance
                            val play = playFactor.value
                            val scale = lerp(0.94f, lerp(1f, COVER_PLAY_SCALE, play), focus)
                            scaleX = scale
                            scaleY = scale
                            // Paused: neighbours are clearly visible.
                            // Playing: neighbours are fully transparent AT REST and fade in
                            // proportionally to the swipe, so exactly one cover is on screen while
                            // the music plays without making the gesture feel unresponsive.
                            val drag = pagerState.currentPageOffsetFraction.absoluteValue.coerceIn(0f, 1f)
                            val neighbour = lerp(0.92f, 0.95f * drag, play)
                            alpha = lerp(neighbour, 1f, focus)
                        }
                        // 6.5: the accent-coloured drop shadow is GONE.
                        //
                        // `shadow(18.dp, ambientColor = accent, spotColor = accent)` painted a
                        // coloured halo around every cover and kept painting it on pause, at rest,
                        // in a screenshot. Nothing in the reference does that: the cover goes down
                        // as a plain rounded rectangle and the BACKDROP carries the colour, which
                        // is exactly what the Oklch ramp is for. Nothing replaces it - artwork-
                        // tinted elevation is the clearest tell that a machine picked the styling.
                        .clip(shape)
                ) {
                    TrackArtwork(
                        track = queue.getOrNull(page),
                        maxPx = ARTWORK_FULL_PX,
                        modifier = Modifier.fillMaxSize(),
                        glyphSize = 62,
                        // The player is the ONE place allowed to parse the file itself: three
                        // covers at a time, one after another, never during a list scroll.
                        allowSlow = true
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerProgress(vm: MainViewModel) {
    val p = LocalPalette.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var scrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }
    var releaseJob by remember { mutableStateOf<Job?>(null) }
    // Читается внутри корутины отпускания: делегат отдаёт актуальное значение на каждом обращении,
    // а захваченная копия — то, что было на момент жеста. Разница здесь принципиальна.
    val liveProgress by rememberUpdatedState(progress)

    /**
     * 6.32.0. ТРЕК, О КОТОРОМ ГОВОРИТ ЭТА ДОРОЖКА.
     *
     * Здесь закрывается тот самый баг: «перемотал в начале трека — унесло на следующий, и там
     * ползунок стоит на том же месте». Второй половиной («и там стоит на том же месте») был
     * этот экран, а не плеер. Удержание пальца жило в `scrubbing`, которое снималось только по
     * сходимости позиции с целью. Трек за это время сменился, позиция обнулилась, к цели она
     * больше никогда не сходилась — и удержание оставалось включённым, показывая на новом
     * треке долю, выбранную на предыдущем. С этой доли можно было уехать ещё дальше: жест по
     * уже сдвинувшейся дорожке отправлял перемотку в конец нового трека.
     *
     * Смена идентификатора обнуляет удержание немедленно. Не «быстрее реагирует» — обнуляет.
     */
    val trackId = progress.trackId
    LaunchedEffect(trackId) {
        releaseJob?.cancel()
        releaseJob = null
        scrubbing = false
        scrubFraction = 0f
    }

    // The controller now falls back to the duration stored in our own database, so this is never
    // the bogus 1 ms that used to send a seek straight to the end of the track.
    val duration = progress.durationMs.coerceAtLeast(1L)
    val seekable = progress.durationMs > 0L
    val fraction = if (scrubbing) scrubFraction
    else (progress.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    val shownPosition = if (scrubbing) (scrubFraction * duration).toLong() else progress.positionMs

    // 6.33.0. Отступ 24 dp вместо 20: в референсе дорожка стоит по той же левой линии, что и
    // название трека и нижняя строка (37 px на кадре = 23.8 dp).
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        ZiziSlider(
            fraction = fraction,
            /**
             * 6.28.0: белый, а не акцент из обложки.
             *
             * Дорожка плеера лежит прямо под обложкой, во всю ширину, и красить её цветом,
             * взятым ИЗ этой же обложки, — верный способ её потерять: на оранжевом арте
             * оранжевая линия, на синем синяя. Белый не спорит ни с одной обложкой и ни с
             * одной из четырёх тем, а буферный слой рисуется тем же цветом с альфой 0.30 и
             * остаётся из той же семьи (см. ZiziSlider).
             *
             * Не чистый 0xFFFFFFFF: на тёмном фоне абсолютно белая линия «звенит» по краям.
             * 0xFFF2F2F2 — тот же приятный белый, которым набраны названия треков.
             */
            accent = Color(0xFFF2F2F2),
            inactive = p.chip,
            buffered = if (seekable) (progress.bufferedMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f,
            seekable = seekable,
            resetKey = trackId,
            onScrubStart = { releaseJob?.cancel(); scrubbing = true; scrubFraction = fraction },
            onScrub = { scrubFraction = it },
            onScrubCancel = { releaseJob?.cancel(); releaseJob = null; scrubbing = false },
            onScrubEnd = { value ->
                // Covers taps too: hold the thumb where the finger left it, no jump back.
                scrubbing = true
                scrubFraction = value
                val target = (value * duration).toLong()
                // Перемотка уходит ВМЕСТЕ с именем трека: если за время жеста плеер уже уехал
                // на следующий, контроллер её отбросит, а не приложит к чужому треку.
                if (seekable) vm.seekTo(target, trackId)
                // 6.31.0. Держим палец-позицию до СХОДИМОСТИ, а не 260 мс по таймеру.
                //
                // Фиксированная задержка — это ставка на то, что плеер успеет перемотаться за
                // четверть секунды. Локальный файл успевает, поток — нет: там новый Range-запрос,
                // и через 260 мс экран возвращался к позиции, которая ещё не сдвинулась. Ползунок
                // отскакивал назад, потом защёлка контроллера подтягивала его вперёд, потом снова
                // назад. Это и есть «катается туда-сюда»: два независимых механизма удержания с
                // разными сроками. Теперь один: отпускаем ровно тогда, когда плеер доехал.
                releaseJob?.cancel()
                releaseJob = scope.launch {
                    val deadline = System.currentTimeMillis() + 4000
                    while (System.currentTimeMillis() < deadline) {
                        // Условий выхода теперь два, и второе важнее первого: трек сменился —
                        // держать больше нечего и незачем. Одно условие сходимости оставляло
                        // удержание включённым навсегда, потому что к цели прошлого трека новый
                        // не сойдётся никогда.
                        if (liveProgress.trackId != trackId) break
                        if ((liveProgress.positionMs - target).absoluteValue < 400L) break
                        delay(40)
                    }
                    scrubbing = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            // Замер эталона: дорожка 5 px (3.2 dp), бегунок 16 px в диаметре (радиус 5.2 dp).
            // Прежние 4.0 / 7.0 давали заметно более толстую полосу и крупную «каплю».
            trackHeightDp = 3.2.dp,
            thumbRadiusDp = 5.2.dp
        )
        // Время подтянуто к дорожке. Полоса жеста остаётся 30 dp (палец не должен промахиваться),
        // поэтому цифры поднимаются сдвигом: центр дорожки -> верх цифр = 35 px эталона.
        //
        // 6.34.0. У строки теперь ЗАДАНА высота, и это важнее сдвига.
        //
        // Своя высота у неё бралась из интерлиньяжа темы (24 sp), а не из кегля 12.5 sp: строка
        // из двух цифр занимала 73 px при 26 px самих цифр. Эти лишние 47 px стояли между
        // дорожкой и кругом Play и растаскивали низ плеера ровно на ту величину, которая была
        // видна глазом. 19.5 dp — измеренная высота этого места в референсе; цифры при этом не
        // обрезаются: `wrapContentHeight(unbounded = true)` меряет их без ограничения и просто
        // кладёт в отведённое место сверху.
        Row(
            Modifier
                .fillMaxWidth()
                .height(19.5.dp)
                .wrapContentHeight(Alignment.Top, unbounded = true)
                .offset(y = (-10.8).dp)
        ) {
            Text(formatTime(shownPosition), color = p.subtext, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(
                "-" + formatTime((duration - shownPosition).coerceAtLeast(0)),
                color = p.subtext,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Ряд транспорта.
 *
 * Что было не так до 6.25.0. Пять кнопок стояли в `Row` с `SpaceBetween` и `padding` 18 dp:
 * положение каждой кнопки было следствием её собственного диаметра и остатка ширины, поделённого
 * на четыре. Отсюда две беды. Первая: центры получались равномерными, а в референсе они не
 * равномерны — замер по эталонному кадру даёт 0.097 / 0.316 / 0.500 / 0.682 / 0.903 ширины, то
 * есть промежуток play↔skip (0.182) заметно меньше промежутка skip↔shuffle (0.219). Это не
 * случайность вёрстки: play и skip — одна смысловая группа, а перемешать/повторять — режимы, и
 * пауза между группами больше, чем внутри группы. Вторая: диаметры были константами в dp, так
 * что на 1.5K-экране (448 dp против эталонных 411) ряд занимал меньшую долю ширины.
 *
 * Теперь всё считается от [BoxWithConstraints]: и диаметры (доли ширины), и центры (те же доли).
 * Каждая кнопка позиционируется своим центром — `offset(x = centreFraction * w - d / 2)`, — а не
 * распределением остатка, поэтому неравномерность групп сохраняется, а не зависит от того, какой
 * диаметр у соседа. На 411 dp это даёт play 78 dp (был 74), skip 61 (был 58), боковые 49 (был 48):
 * заметно крупнее, при этом ряд не шире экрана — суммарная ширина 0.903 + половина боковой
 * кнопки = 0.963 ширины, по 1.8 % воздуха с каждой стороны.
 *
 * Высота ряда привязана к диаметру play, а не задана в dp: иначе на широком экране кнопки растут,
 * а полоса под ними — нет, и ряд начинает жать по вертикали.
 */
@Composable
private fun PlayerControls(
    isPlaying: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    onShuffle: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit
) {
    val p = LocalPalette.current
    // 6.18.0: «перемешать» и «повторять» больше не material-глифы.
    // 6.25.0: и транспорт тоже. Rounded-набор снял острые стыки, но рисунок остался прежним:
    // ломаные под 45° и разная плотность линий рядом с крупным Play. Теперь весь ряд — один
    // набор (см. ZiziIcons): единый вес обводки, круглые торцы, треугольник Play уравновешен
    // по центру масс внутри глифа.
    //
    // 6.29.2, «повторять». Три состояния и ничего сверх них: выключено — знак цветом текста,
    // «весь список» — знак брендовым оранжевым и точка под ним, «один» — то же плюс «1» в
    // разрыве рамки. Круглая подложка активного состояния снята: на тёмном фоне плеера она
    // читалась как вторая кнопка вокруг первой, а состояние и так несут цвет и точка. Цвет
    // здесь brand, а не accent: accent пересчитывается от обложки каждой песни, и «повторять»
    // менял бы цвет от трека к треку, хотя показывает настройку, к треку не относящуюся.
    val idle = p.text.copy(alpha = 0.92f)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth
        val playD = w * PLAY_D
        val skipD = w * SKIP_D
        val sideD = w * SIDE_D
        // Высота ряда РАВНА диаметру круга Play, а не 1.18 от него: круг теперь настоящий, с
        // заливкой, и его край — это край ряда. Любой запас сверху и снизу сместил бы весь ряд
        // относительно времени и нижней строки, а они замерены от края круга.
        Box(
            Modifier
                .fillMaxWidth()
                .height(playD)
        ) {
            TransportSlot(w, C_SHUFFLE, sideD) {
                TransportButton(
                    icon = ZiziIcons.Shuffle,
                    // 6.29.3: как у «повторять» — состояние показывает точка и фирменный цвет,
                    // а не подложка. Круглая плашка под знаком спорила с разрывом в рисунке:
                    // на активном режиме перехлёст пропадал в подсветке.
                    tint = if (shuffle) p.brand else idle,
                    diameter = sideD,
                    glyphFraction = G_SHUFFLE,
                    onClick = onShuffle,
                    dot = shuffle,
                    dotOffsetFraction = 0.514f,
                    dotSizeFraction = 0.107f
                )
            }
            TransportSlot(w, C_PREVIOUS, skipD) {
                TransportButton(
                    icon = ZiziIcons.SkipPrevious,
                    tint = p.text,
                    diameter = skipD,
                    glyphFraction = G_SKIP,
                    onClick = onPrevious
                )
            }
            TransportSlot(w, C_PLAY, playD) {
                TransportButton(
                    icon = if (isPlaying) ZiziIcons.Pause else ZiziIcons.PlayFilled,
                    // 6.33.0. Play стал КРУГОМ, как в референсе: белая заливка, тёмный знак.
                    // Голый глиф на фоне обложки был самой слабой точкой ряда — главная команда
                    // экрана весила столько же, сколько «перемешать». Белый тот же, что у
                    // дорожки (0xFFF2F2F2): чистый #FFFFFF на тёмном фоне звенит по краю.
                    tint = p.onAccent,
                    background = Color(0xFFF2F2F2),
                    diameter = playD,
                    // Пауза — две вертикали во всю высоту глифа, Play — треугольник, вписанный в
                    // ту же высоту, но пустой по углам. При одной доле пауза читается тяжелее, и
                    // на переключении кнопка «дёргается» по массе. 0.62 против 0.70 выравнивает
                    // это по площади заливки, а не по габариту.
                    // Доли пересчитаны от диаметра КРУГА: треугольник в эталоне 30 px в высоту
                    // при круге 99 px. Пауза чуть меньше по кеглю — при равном габарите две
                    // сплошные вертикали читаются тяжелее треугольника с пустыми углами.
                    glyphFraction = if (isPlaying) 0.490f else 0.512f,
                    onClick = onPlayPause
                )
            }
            TransportSlot(w, C_NEXT, skipD) {
                TransportButton(
                    icon = ZiziIcons.SkipNext,
                    tint = p.text,
                    diameter = skipD,
                    glyphFraction = G_SKIP,
                    onClick = onNext
                )
            }
            TransportSlot(w, C_REPEAT, sideD) {
                TransportButton(
                    icon = if (repeatMode == Player.REPEAT_MODE_ONE) ZiziIcons.RepeatOne else ZiziIcons.Repeat,
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) idle else p.brand,
                    diameter = sideD,
                    dotOffsetFraction = 0.672f,
                    dotSizeFraction = 0.134f,
                    // 0.45 против 0.49 у «перемешать»: рамка занимает всю ширину глифа, а не
                    // вписанный квадрат, поэтому на равном кегле она выглядела бы крупнее ряда.
                    // На этой доле обводка знака даёт на экране 2.05 dp — вес всего набора.
                    glyphFraction = G_REPEAT,
                    onClick = onRepeat,
                    dot = repeatMode != Player.REPEAT_MODE_OFF
                )
            }
        }
    }
}

/*
 * Замер референса: доли ширины экрана. 6.33.0 — пересняты с эталонного кадра целиком, включая
 * РИСУНОК знаков, а не только их центры.
 *
 * Кадр 576x1280 при 1.5556 px/dp. Что намерено:
 *   круг Play        99 px  -> 0.1719 ширины (это теперь видимый круг, а не площадь нажатия);
 *   знак «вперёд»    34x38  -> глиф 0.0825 ширины по высоте (сам рисунок перерисован, см. ZiziIcons);
 *   «перемешать»     35 px  -> глиф 0.0816 ширины;
 *   «повторять»      35 px  -> глиф 0.0646 ширины (рамка занимает всю ширину знака, кегль меньше);
 *   центры           0.0965 / 0.2891 / 0.5000 / 0.7109 / 0.9035.
 *
 * Главное отличие от 6.25.0 — центры skip: было 0.316 / 0.682, стало 0.2891 / 0.7109. Кнопки
 * «назад» и «вперёд» стоят ДАЛЬШЕ от Play, чем считалось, и ряд от этого дышит.
 *
 * Диаметры кнопок (площадь нажатия) оставлены прежними у skip и боковых: палец бьёт по кругу,
 * которого не видно, и уменьшать его вслед за рисунком незачем. Доли глифа пересчитаны так,
 * чтобы НАРИСОВАННЫЙ знак совпал с эталоном при этих диаметрах.
 */
private const val PLAY_D = 0.1719f
private const val SKIP_D = 0.149f
private const val SIDE_D = 0.119f
private const val C_SHUFFLE = 0.0965f
private const val C_PREVIOUS = 0.2891f
private const val C_PLAY = 0.500f
private const val C_NEXT = 0.7109f
private const val C_REPEAT = 0.9035f

/* Доли глифа от диаметра своей кнопки: 0.0825/0.149, 0.0816/0.119, 0.0646/0.119. */
private const val G_SKIP = 0.554f
private const val G_SHUFFLE = 0.686f
private const val G_REPEAT = 0.543f

/* Нижняя строка: центры знаков «папки» и «очередь» с эталонного кадра. */
private const val C_FOLDERS = 0.7778f
private const val C_QUEUE = 0.9115f

/**
 * Ставит кнопку центром на [centre] (доля ширины [width]), по вертикали — по центру ряда.
 *
 * Смещение считается в Dp и уходит в `offset(Dp, Dp)`, который применяется в фазе layout без
 * повторного measure содержимого. Вариант «`Spacer` с weight между кнопками» дал бы те же центры
 * только при равных диаметрах — а они здесь разные, и именно в этом весь смысл.
 */
@Composable
private fun BoxScope.TransportSlot(
    width: Dp,
    centre: Float,
    diameter: Dp,
    content: @Composable () -> Unit
) {
    Box(
        Modifier
            .align(Alignment.CenterStart)
            .offset(x = width * centre - diameter / 2)
    ) { content() }
}

/**
 * Нижняя строка плеера. 6.33.0 — переснята с эталонного кадра целиком.
 *
 * Что было: два одинаковых блока «знак + слово» на половину ширины каждый, на чёрной плашке
 * 0.22. Три беды. Первая: плашка отделяла строку от экрана, хотя это часть плеера, а не панель
 * системы — в референсе никакой подложки нет. Вторая: слова «Очередь» и «Папки» кеглем 15 sp
 * весили больше, чем название трека после пересчёта (21.5 sp), и глаз шёл вниз, а не к обложке.
 * Третья, главная: слева пустовало место, в котором любой нормальный плеер говорит САМОЕ
 * полезное — куда сейчас идёт звук.
 *
 * Что стало (замер кадра, 1.5556 px/dp):
 *   центр знака вывода   47.5 px -> 30.5 dp от левого края (padding 18 + 2 + половина 20 dp);
 *   имя устройства       кегль 11.5 sp, цвет — фирменный оранжевый (в референсе тут зелёный
 *                        фирменный, и это ровно та же роль: «это ТВОЙ маршрут звука»);
 *   центры правых знаков 0.7778 и 0.9115 ширины — те же, что у «поделиться» и «очередь» в
 *                        оригинале, поэтому строка садится на привычные пальцу места.
 *
 * Счётчик очереди из строки убран: цифра рядом со знаком уводила его центр с замеренной доли, а
 * само число всё равно написано первой строкой в листе очереди. Если оно понадобится на экране —
 * это бейдж поверх знака, а не текст сбоку.
 */
@Composable
private fun PlayerBottomBar(output: AudioOutput, onQueue: () -> Unit, onFolders: () -> Unit) {
    val p = LocalPalette.current
    val context = LocalContext.current
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
    ) {
        val w = maxWidth
        Row(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 18.dp)
                .clip(RoundedCornerShape(10.dp))
                // Нажатие открывает системный переключатель вывода — тот же, что в шторке. Своё
                // окно со списком устройств здесь было бы вторым источником правды о железе, а
                // системное умеет и переключать, и спрашивать разрешения, и знает про LE Audio.
                .clickable { openOutputSwitcher(context) }
                .padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                outputIcon(output.kind),
                contentDescription = null,
                tint = p.brand,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(9.dp))
            Text(
                text = output.name,
                color = p.brand,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                // Длинное имя гарнитуры не имеет права доехать до правых знаков: 168 dp — это
                // ровно до начала «папок» на 411 dp с запасом на узкие экраны.
                modifier = Modifier.widthIn(max = 168.dp)
            )
        }
        TransportSlot(w, C_FOLDERS, 40.dp) {
            TransportButton(
                icon = ZiziIcons.FolderMusic,
                tint = p.text,
                diameter = 40.dp,
                glyphFraction = 0.55f,
                onClick = onFolders
            )
        }
        TransportSlot(w, C_QUEUE, 40.dp) {
            TransportButton(
                icon = ZiziIcons.Queue,
                tint = p.text,
                diameter = 40.dp,
                glyphFraction = 0.55f,
                onClick = onQueue
            )
        }
    }
}

/**
 * Знак вывода по роду устройства.
 *
 * Наушники рисуются наушниками, колонка — колонкой, Bluetooth-колонка — руной Bluetooth. Один
 * универсальный «значок звука» на все случаи был бы ложью в половине из них: человек смотрит
 * сюда, чтобы за полсекунды понять, играет ли в наушниках или на весь автобус.
 */
private fun outputIcon(kind: OutputKind) = when (kind) {
    OutputKind.BLUETOOTH, OutputKind.WIRED, OutputKind.USB -> ZiziIcons.Headphones
    OutputKind.BLUETOOTH_SPEAKER -> ZiziIcons.BluetoothAudio
    OutputKind.PHONE, OutputKind.EXTERNAL -> ZiziIcons.PhoneSpeaker
}

/**
 * Системный переключатель вывода. Панель настроек есть с Android 10; если её нет или
 * производитель её вырезал — уходим в звук, а не падаем и не молчим.
 */
private fun openOutputSwitcher(context: Context) {
    val panel = Intent("com.android.settings.panel.action.MEDIA_OUTPUT")
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val sound = Intent(Settings.ACTION_SOUND_SETTINGS)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { context.startActivity(panel) }.isFailure) {
        runCatching { context.startActivity(sound) }
    }
}
