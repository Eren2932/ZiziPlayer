package app.ziziplayer.ui.motion;

import java.util.Objects;

/** Platform-free ownership rules used by the Compose adapter, not a second player queue. */
public final class PlayerTransitionPolicy {
    private PlayerTransitionPolicy() {}
    public static final int WAIT = 0;
    public static final int SNAP = 1;
    public static final int ANIMATE = 2;

    /** A colour can only acknowledge the track that actually produced it. */
    public static int handoff(String origin, String target, String playing, String paletteOwner) {
        if (!Objects.equals(playing, paletteOwner)) return WAIT;
        if (target == null) return ANIMATE;
        if (Objects.equals(target, playing)) return SNAP;
        if (Objects.equals(origin, playing)) return WAIT;
        return ANIMATE; // an external change superseded the swipe
    }

    /** Only a real Drag.Start followed by Drag.Stop may issue a seek on settling. */
    public static final class Gesture {
        private boolean active;
        private boolean released;
        public boolean isActive() { return active; }
        public void start() { active = true; released = false; }
        public void stop() { if (active) released = true; }
        public void cancel() { active = false; released = false; }
        public boolean ready(boolean scrolling) { return active && released && !scrolling; }
        public String finish(boolean scrolling, String shown, String playing) {
            if (!ready(scrolling)) return null;
            cancel();
            return shown != null && !Objects.equals(shown, playing) ? shown : null;
        }
    }
}
