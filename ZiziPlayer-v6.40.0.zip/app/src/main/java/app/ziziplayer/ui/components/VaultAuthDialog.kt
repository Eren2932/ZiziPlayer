package app.ziziplayer.ui.components

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import app.ziziplayer.privacy.FolderVault
import app.ziziplayer.privacy.PatternPath
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.launch

private fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activity()
    else -> null
}

@Composable
fun VaultAuthDialog(vault: FolderVault, onSuccess: () -> Unit, onDismiss: () -> Unit) {
    val setup = !vault.configured
    var pattern by remember { mutableStateOf(vault.pattern) }
    var input by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = context.activity()
    val keyguard = context.getSystemService(KeyguardManager::class.java)
    var cancellation by remember { mutableStateOf<CancellationSignal?>(null) }
    val success by rememberUpdatedState(onSuccess)
    var live by remember { mutableStateOf(true) }
    DisposableEffect(Unit) { onDispose { live = false; cancellation?.cancel() } }
    val credential = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (live && result.resultCode == Activity.RESULT_OK && !setup) { vault.unlockWithDevice(); success() }
    }
    fun submit() {
        if (busy) return
        val valid = if (pattern) input.length in 4..9 else input.length in 6..12
        if (!valid) { error = if (pattern) "Соедини минимум 4 точки" else "PIN: от 6 до 12 цифр"; return }
        if (setup && first == null) { first = input; input = ""; error = null; return }
        if (setup && first != input) { first = null; input = ""; error = "Не совпало. Задай ключ заново"; return }
        val secret = input
        input = ""
        busy = true
        scope.launch {
            try {
                if (setup) { vault.configure(secret, pattern); success() }
                else if (vault.verify(secret)) success()
                else error = if (vault.remainingSeconds() > 0) "Повтори через ${vault.remainingSeconds()} с" else "Неверный ключ"
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (_: Exception) { error = "Не удалось проверить или сохранить ключ. Попробуй снова" }
            finally { busy = false }
        }
    }
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = p.surface,
        properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn),
        title = { Text(if (setup) (if (first == null) "Защита папок" else "Повтори ключ") else "Скрытые папки", color = p.text) },
        text = {
            Column {
                if (setup) {
                    Text("Ключ защищает раздел внутри Zizi, но не шифрует файлы. Запомни его: восстановления нет.", color = p.subtext)
                    if (first == null) Row {
                        TextButton(onClick = { pattern = false; input = "" }) { Text(if (!pattern) "✓ PIN" else "PIN", color = p.brand) }
                        TextButton(onClick = { pattern = true; input = "" }) { Text(if (pattern) "✓ Рисунок" else "Рисунок", color = p.brand) }
                    }
                }
                if (pattern) {
                    PatternPad(input, !busy, { input = it }, p.brand)
                    TextButton(onClick = { input = "" }, enabled = !busy) { Text("Очистить рисунок", color = p.brand) }
                } else OutlinedTextField(
                    value = input, onValueChange = { value -> input = value.filter { it in '0'..'9' }.take(12) },
                    label = { Text("PIN · 6–12 цифр") }, singleLine = true, enabled = !busy,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                error?.let { Text(it, color = p.brand) }
                if (busy) CircularProgressIndicator(Modifier.size(24.dp), color = p.brand)
                if (!setup && keyguard != null && keyguard.isDeviceSecure && activity != null) {
                    if (Build.VERSION.SDK_INT >= 28) TextButton(enabled = !busy, onClick = {
                        cancellation?.cancel()
                        val signal = CancellationSignal(); cancellation = signal
                        val builder = BiometricPrompt.Builder(activity).setTitle("Скрытые папки Zizi")
                        if (Build.VERSION.SDK_INT >= 30) builder.setAllowedAuthenticators(
                            android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_STRONG or
                                android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                        else builder.setNegativeButton("Ввести ключ Zizi", activity.mainExecutor) { _, _ -> }
                        try {
                            builder.build().authenticate(signal, activity.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                    if (live) { vault.unlockWithDevice(); success() }
                                }
                                override fun onAuthenticationError(code: Int, message: CharSequence) {
                                    if (live) error = "Системное подтверждение закрыто или недоступно. Используй ключ Zizi"
                                }
                            })
                        } catch (_: Exception) { error = "Биометрия недоступна. Используй ключ Zizi" }
                    }) { Text("Биометрия телефона", color = p.brand) }
                    TextButton(enabled = !busy, onClick = {
                        @Suppress("DEPRECATION")
                        val intent = keyguard.createConfirmDeviceCredentialIntent("Скрытые папки Zizi", "Подтверди доступ кодом телефона")
                        if (intent != null) credential.launch(intent)
                    }) { Text("Код блокировки телефона", color = p.brand) }
                }
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = ::submit) { Text(if (setup && first == null) "Далее" else "Подтвердить", color = p.brand) } },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена", color = p.subtext) } }
    )
}

@Composable
private fun PatternPad(value: String, enabled: Boolean, onChange: (String) -> Unit, color: Color) {
    val livePath = remember { mutableStateOf(value) }
    SideEffect { livePath.value = value }
    val change by rememberUpdatedState(onChange)
    val haptics = LocalHapticFeedback.current
    fun append(node: Int) {
        val next = PatternPath.append(livePath.value, node)
        if (next != livePath.value) { livePath.value = next; change(next); haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).semantics {
        contentDescription = "Графический ключ, выбрано ${value.length} точек"
        customActions = (0..8).map { node -> CustomAccessibilityAction("Точка ${node + 1}") { if (enabled) append(node); enabled } }
    }.pointerInput(enabled) {
        if (!enabled) return@pointerInput
        fun hit(pos: Offset): Int? = (0..8).minByOrNull { i ->
            (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance()
        }?.takeIf { i -> (pos - Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)).getDistance() < size.width / 7f }
        detectDragGestures(onDragStart = { pos -> livePath.value = ""; change(""); hit(pos)?.let { append(it) } },
            onDrag = { event, _ -> event.consume(); hit(event.position)?.let(::append) })
    }.pointerInput(enabled) {
        if (enabled) detectTapGestures { pos ->
            val col = (pos.x / (size.width / 3f)).toInt().coerceIn(0, 2)
            val row = (pos.y / (size.height / 3f)).toInt().coerceIn(0, 2)
            append(row * 3 + col)
        }
    }) {
        fun center(i: Int) = Offset(size.width * ((i % 3) + 0.5f) / 3, size.height * ((i / 3) + 0.5f) / 3)
        value.zipWithNext().forEach { (a, b) -> drawLine(color.copy(alpha = 0.6f), center(a - '0'), center(b - '0'), 5.dp.toPx()) }
        for (i in 0..8) drawCircle(if (('0' + i) in value) color else Color.Gray, 9.dp.toPx(), center(i))
    }
}
