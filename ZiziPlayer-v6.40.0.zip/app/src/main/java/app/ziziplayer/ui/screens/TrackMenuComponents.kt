package app.ziziplayer.ui.screens

import androidx.compose.animation.Animatable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.MenuPresentation
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.components.rememberArtwork
import app.ziziplayer.ui.theme.ArtworkColorMath
import app.ziziplayer.ui.theme.LocalPalette

/** Navigation callbacks run AFTER the sheet leaves, not halfway through its animation. */
internal val LocalSheetExit = staticCompositionLocalOf<(() -> Unit) -> Unit> {
    { action -> action() }
}

@Composable
internal fun TrackMenuHeader(track: TrackEntity, downloaded: Boolean, onClose: () -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(24.dp)
    // Deliberately independent of the global cover-colour toggle and playing track.
    // Shares the exact 160px cache/inflight request with TrackArtwork below; no new size,
    // no URL request for decoration, no MediaMetadataRetriever work on opening the menu.
    val art = rememberArtwork(track, ARTWORK_ROW_PX)
    val primary = art?.swatches?.primary
    val target = remember(primary) {
        primary?.let { Color(ArtworkColorMath.cardTop(it.toArgb())) } ?: Color(0xFF242424)
    }
    val backgroundTop = remember(track.id) { Animatable(target) }
    LaunchedEffect(track.id, target) { backgroundTop.animateTo(target, tween(220)) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(shape)
            .drawWithCache {
                val brush = Brush.linearGradient(listOf(backgroundTop.value, Color(0xFF191919)))
                onDrawBehind { drawRect(brush) }
            }
            .border(1.dp, p.text.copy(alpha = 0.06f), shape)
            .padding(start = 14.dp, top = 14.dp, bottom = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TrackArtwork(
            track = track, maxPx = ARTWORK_ROW_PX, glyphSize = 24,
            modifier = Modifier.size(68.dp).clip(RoundedCornerShape(17.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (track.artist.isNotBlank() && track.artist != "—") {
                Text(track.artist, color = Color(0xFFD6D6D6), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(6.dp))
            val source = when {
                !track.isRemote -> "На устройстве"
                downloaded -> "Скачан"
                else -> "Из сети"
            }
            Text(
                source + if (track.durationMs > 0) " · " + formatTime(track.durationMs) else "",
                color = Color(0xFFD6D6D6), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onClose, modifier = Modifier.size(48.dp).align(Alignment.Top)) {
            Icon(ZiziIcons.Close, contentDescription = "Закрыть меню трека", tint = Color(0xFFD6D6D6), modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
internal fun TrackMenuQuickActions(
    favorite: Boolean,
    shareFile: Boolean,
    onFavorite: () -> Unit,
    onPlaylist: () -> Unit,
    onFx: () -> Unit,
    onShare: () -> Unit
) {
    val fontScale = LocalDensity.current.fontScale
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns = MenuPresentation.quickColumns(maxWidth.value, fontScale)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (start in 0 until 4 step columns) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (index in start until minOf(start + columns, 4)) {
                        val icon = when (index) {
                            0 -> if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart
                            1 -> ZiziIcons.QueueAdd
                            2 -> ZiziIcons.Speed
                            else -> ZiziIcons.Share
                        }
                        val label = when (index) {
                            0 -> "Избранное"
                            1 -> "В плейлист"
                            2 -> "Скорость"
                            else -> if (shareFile) "Файлом" else "Поделиться"
                        }
                        val action = when (index) {
                            0 -> onFavorite
                            1 -> onPlaylist
                            2 -> onFx
                            else -> onShare
                        }
                        TrackMenuQuickAction(
                            icon = icon, label = label, active = index == 0 && favorite,
                            stateLabel = if (index == 0) (if (favorite) "В избранном" else "Не в избранном") else null,
                            modifier = Modifier.weight(1f), onClick = action
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackMenuQuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean,
    stateLabel: String?,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // Read animation values at the layer stage; no remeasurement on every frame.
    val scale = animateFloatAsState(if (pressed) 0.96f else 1f, tween(110), label = "menu-press")
    val tint by animateColorAsState(if (active) p.brand else p.text, tween(150), label = "menu-favorite")
    val shape = RoundedCornerShape(19.dp)
    Column(
        modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .clip(shape)
            .background(if (active) p.brand.copy(alpha = 0.14f) else p.chip.copy(alpha = 0.6f))
            .border(1.dp, if (active) p.brand.copy(alpha = 0.28f) else p.text.copy(alpha = 0.05f), shape)
            .semantics { if (stateLabel != null) stateDescription = stateLabel }
            .clickable(interactionSource = interaction, indication = androidx.compose.material3.ripple(), role = Role.Button, onClick = onClick)
            .heightIn(min = 78.dp).padding(horizontal = 4.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(8.dp))
        Text(label, color = tint, fontSize = 11.sp, fontWeight = FontWeight.Medium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
internal fun TrackMenuGroup(title: String, danger: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(20.dp)
    Text(title, color = p.subtext, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp))
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (danger) DANGER.copy(alpha = 0.045f) else p.chip.copy(alpha = 0.45f))
            .border(1.dp, if (danger) DANGER.copy(alpha = 0.12f) else p.text.copy(alpha = 0.045f), shape),
        content = content
    )
}

@Composable
internal fun TrackMenuAction(
    icon: ImageVector,
    label: String,
    trailing: String? = null,
    navigate: Boolean = false,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val tint = if (danger) DANGER else p.text
    Row(
        Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = 56.dp).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(21.dp))
        Spacer(Modifier.width(13.dp))
        Text(label, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            Text(trailing, color = p.subtext, fontSize = 11.sp, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(p.text.copy(alpha = 0.055f))
                    .padding(horizontal = 7.dp, vertical = 4.dp))
        }
        if (navigate) {
            Spacer(Modifier.width(6.dp))
            Icon(ZiziIcons.ChevronRight, contentDescription = null, tint = p.subtext.copy(alpha = 0.65f), modifier = Modifier.size(16.dp))
        }
    }
}
