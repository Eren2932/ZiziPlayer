package app.ziziplayer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.theme.LocalPalette

/** Only consume the downward remainder AFTER the collection has reached its top. */
@Composable
fun VaultPullSurface(enabled: Boolean, unlocked: Boolean, onOpen: () -> Unit, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val threshold = with(density) { 72.dp.toPx() }
    val haptic = LocalHapticFeedback.current
    val openVaultAction by rememberUpdatedState(onOpen)
    var pull by remember(enabled) { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    var releasedNormally by remember { mutableStateOf(false) }
    var buzzed by remember { mutableStateOf(false) }
    val connection = remember(enabled, threshold) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput) return Offset.Zero
                if (pull > 0 && available.y < 0) {
                    val consumed = maxOf(available.y, -pull / 0.55f)
                    pull = (pull + consumed * 0.55f).coerceAtLeast(0f)
                    return Offset(0f, consumed)
                }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!enabled || source != NestedScrollSource.UserInput || available.y <= 0) return Offset.Zero
                dragging = true
                pull = (pull + available.y * 0.55f).coerceAtMost(threshold * 1.55f)
                if (pull >= threshold && !buzzed) {
                    buzzed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                return Offset(0f, available.y)
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                val hadPull = pull > 0
                val armed = enabled && releasedNormally && pull >= threshold
                pull = 0f; dragging = false; buzzed = false
                if (armed) openVaultAction.invoke()
                return if (hadPull) available else Velocity.Zero
            }
        }
    }
    val height by animateFloatAsState(pull, tween(if (dragging) 0 else 200), label = "vault-pull")
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize().nestedScroll(connection).pointerInput(enabled) {
        if (enabled) awaitEachGesture {
            var normalEnd = false
            releasedNormally = false
            try {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val pressed = event.changes.any { it.pressed }
                    if (!pressed) { normalEnd = true; releasedNormally = true }
                } while (pressed)
            } finally {
                if (!normalEnd) { pull = 0f; dragging = false; buzzed = false; releasedNormally = false }
            }
        }
    }) {
        Box(Modifier.fillMaxWidth().height(with(density) { height.toDp() })
            .background(if (unlocked) p.brand else p.surface).clickable(enabled = enabled, onClick = onOpen),
            contentAlignment = Alignment.Center) {
            if (height > threshold * 0.3f) Text(
                if (unlocked) "Скрытые папки · открыто" else if (pull >= threshold) "Отпусти для открытия" else "Потяни для скрытых папок",
                color = if (unlocked) p.onBrand else p.text, maxLines = 1
            )
        }
        Box(Modifier.weight(1f)) { content.invoke() }
    }
}
