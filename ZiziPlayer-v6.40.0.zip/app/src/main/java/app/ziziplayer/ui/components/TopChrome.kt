package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Fixed, translucent tint ABOVE app content and BELOW Android's system icons.
 * Mount once as the last visual layer in the window host, not inside the moving player.
 * Future lyrics/scrolling content can pass underneath without any change to this component.
 * This is tint glass, not blur: no bitmap capture, RenderEffect or offscreen compositing layer.
 * The Spacer has no input/semantics handlers, so system gestures and app hits are untouched.
 */
@Composable
fun StatusBarTint(modifier: Modifier = Modifier) {
    Spacer(
        modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).drawWithCache {
            val tint = Color.Black.copy(alpha = 0.24f)
            onDrawBehind { drawRect(tint) }
        }
    )
}

/** A single translucent surface under title, filters AND sort controls, with a quiet edge. */
fun Modifier.libraryChrome(): Modifier = drawWithCache {
    val tint = Brush.verticalGradient(
        0f to Color.Black.copy(alpha = 0.19f),
        1f to Color.Black.copy(alpha = 0.11f)
    )
    val edge = 0.5.dp.toPx()
    onDrawBehind {
        drawRect(tint)
        drawRect(
            Color.White.copy(alpha = 0.055f),
            topLeft = Offset(0f, (size.height - edge).coerceAtLeast(0f)),
            size = Size(size.width, edge)
        )
    }
}

/** Dims real outgoing text/art at the list edge, not only the background underneath it. */
fun Modifier.topContentTint(): Modifier = drawWithCache {
    val height = 14.dp.toPx().coerceAtMost(size.height)
    val tint = Brush.verticalGradient(
        colors = listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent),
        startY = 0f,
        endY = height.coerceAtLeast(1f)
    )
    onDrawWithContent {
        drawContent()
        if (height > 0f) drawRect(tint, size = Size(size.width, height))
    }
}
