package app.ziziplayer.ui

import org.junit.Test

/** The same production-core checks run standalone in preflight and under Gradle/JUnit. */
class ArtworkColorMathTest {
    @Test fun coverColourMathRegressions() {
        ArtworkColorMathChecks.runAll()
    }
}
