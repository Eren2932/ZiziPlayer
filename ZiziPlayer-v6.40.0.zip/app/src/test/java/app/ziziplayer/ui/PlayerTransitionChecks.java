package app.ziziplayer.ui;

import app.ziziplayer.ui.motion.PlayerTransitionPolicy;
import app.ziziplayer.ui.motion.PlayerTransitionPolicy.Gesture;
import java.util.Objects;
import java.util.Random;

/** Executes the actual production policy. Does not simulate Compose animations or Media3. */
public final class PlayerTransitionChecks {
    private static int checks;
    private static void equal(Object expected, Object actual, String label) {
        checks++;
        if (!Objects.equals(expected, actual)) throw new AssertionError(label + ": expected=" + expected + ", actual=" + actual);
    }
    public static void runAll() {
        checks = 0;
        Gesture g = new Gesture();
        equal(null, g.finish(false, "B", "A"), "opening must not seek");
        for (int i = 0; i < 10000; i++) {
            g.stop(); // an unrelated finish cannot invent a Drag.Start
            equal(null, g.finish(false, "page-" + i, "playing-" + (i + 1)), "rapid programmatic retarget");
        }
        g.start();
        equal(null, g.finish(false, "B", "A"), "finger still down at zero offset");
        g.stop();
        equal(false, g.ready(true), "fling still running");
        equal(null, g.finish(true, "B", "A"), "mid-fling does not seek");
        equal("B", g.finish(false, "B", "A"), "one seek at settle");
        equal(null, g.finish(false, "B", "A"), "duplicate idle emission");
        g.start(); g.stop();
        equal(null, g.finish(false, "A", "A"), "return to same track never restarts audio");
        g.start(); g.stop(); g.start();
        equal(false, g.ready(false), "new drag owns old fling");
        g.stop(); equal("D", g.finish(false, "D", "A"), "multi-page gesture");
        for (String reason : new String[]{"transport", "queue replacement", "queue shrink", "dispose", "drag cancel"}) {
            g.start(); g.stop(); g.cancel();
            equal(null, g.finish(false, "B", "A"), reason);
        }
        g.start(); g.stop(); equal("C", g.finish(false, "C", "B"), "gesture wins auto-advance");
        g.start(); g.stop(); equal(null, g.finish(false, null, "B"), "deleted visible row");
        equal(false, g.isActive(), "no stale lock after deleted row");
        // IDs deliberately unrelated to indices: the visible queue may omit rows.
        g.start(); g.stop(); equal("track:900", g.finish(false, "track:900", "track:4"), "identity, not index");
        equal(PlayerTransitionPolicy.WAIT, PlayerTransitionPolicy.handoff("A", "B", "A", "A"), "hold before ack");
        equal(PlayerTransitionPolicy.WAIT, PlayerTransitionPolicy.handoff("A", "B", "B", "A"), "new track, old palette");
        equal(PlayerTransitionPolicy.SNAP, PlayerTransitionPolicy.handoff("A", "B", "B", "B"), "ack adopts preview");
        equal(PlayerTransitionPolicy.WAIT, PlayerTransitionPolicy.handoff("A", "B", "C", "B"), "external change, stale palette");
        equal(PlayerTransitionPolicy.ANIMATE, PlayerTransitionPolicy.handoff("A", "B", "C", "C"), "external supersedes hold");
        equal(PlayerTransitionPolicy.ANIMATE, PlayerTransitionPolicy.handoff(null, null, "B", "B"), "ordinary button");
        equal(PlayerTransitionPolicy.ANIMATE, PlayerTransitionPolicy.handoff(null, null, null, null), "empty queue");
        equal(PlayerTransitionPolicy.SNAP, PlayerTransitionPolicy.handoff("A", "B", "B", "B"), "identical colours still acknowledge by ID");
        // Independent event-history oracle: at most one seek per released, uncancelled drag.
        Random random = new Random(6399L);
        boolean started = false, released = false;
        g.cancel();
        for (int i = 0; i < 100000; i++) {
            int event = random.nextInt(6);
            if (event == 0) { g.start(); started = true; released = false; }
            else if (event == 1) { g.stop(); if (started) released = true; }
            else if (event == 2) { g.cancel(); started = false; released = false; }
            else {
                boolean scrolling = event == 3;
                String shown = event == 4 ? "B" : "A";
                boolean allowed = started && released && !scrolling;
                equal(allowed, g.ready(scrolling), "random ready " + i);
                equal(allowed && !shown.equals("A") ? shown : null, g.finish(scrolling, shown, "A"), "random seek " + i);
                if (allowed) { started = false; released = false; }
            }
            equal(started, g.isActive(), "random ownership " + i);
        }
        System.out.println("PASS: " + checks + " policy assertions, 10,000 programmatic settles and 100,000 seeded events.");
        System.out.println("This executes production ownership rules, NOT Compose/Media3/device timing.");
    }
    public static void main(String[] args) { runAll(); }
}
