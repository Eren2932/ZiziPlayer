package app.ziziplayer.ui

import org.junit.Test

class PlayerTransitionPolicyTest {
    @Test fun gestureAndHandoffOwnership() = PlayerTransitionChecks.runAll()
}
