package app.ziziplayer.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.session.SessionCommand
import app.ziziplayer.data.TrackEntity
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlin.math.absoluteValue

/**
 * Structural playback state. Deliberately WITHOUT position:
 * position changes several times per second and would invalidate every consumer of this state.
 * Position lives in [PlayerController.progress] so that only the seek bar reacts to it.
 */
@androidx.compose.runtime.Immutable
data class PlaybackState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentIndex: Int = 0,
    val currentTrackId: String? = null,
    val queueIds: List<String> = emptyList(),
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val sleepMinutesLeft: Int? = null
)

/** Position stream, updated only while playing and only while the UI is on screen. */
data class Progress(val positionMs: Long = 0L, val durationMs: Long = 0L)

@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {

    private companion object {
        /** Seeking closer than this to the end makes ExoPlayer treat the track as finished. */
        const val END_GUARD_MS = 1200L
        /** How long a fresh seek target wins over the session's own (lagging) reports. */
        const val SEEK_LATCH_MS = 1000L
        const val SEEK_LATCH_TOLERANCE_MS = 700L
        const val TICK_MS = 250L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingQueue: PendingQueue? = null
    private var sleepJob: Job? = null
    private var tickerJob: Job? = null
    private var sleepEndAtMs: Long? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress
    private val _connected = MutableStateFlow(false)

    /** Cached queue ids: rebuilt only when the timeline actually changes, never on every tick. */
    private var cachedQueueIds: List<String> = emptyList()
    private var uiActive = false
    private var queueEpoch = 0

    /**
     * Duration taken from our own database, keyed by media id.
     *
     * Right after a track change the session reports an unknown duration. v4 published that as 0,
     * so the seek bar computed its fraction against a one millisecond track: dragging anywhere
     * jumped to the very end, and a seek past the end made ExoPlayer skip to the next track.
     * That is exactly the "slider glitches and switches tracks" bug.
     */
    private var knownDurations: Map<String, Long> = emptyMap()

    private var seekTargetMs = 0L
    private var latchUntilMs = 0L

    private data class PendingQueue(val tracks: List<TrackEntity>, val index: Int, val play: Boolean, val positionMs: Long)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_TIMELINE_CHANGED)) invalidateQueue()
            // A new track invalidates any pending seek target immediately.
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) latchUntilMs = 0L
            publish()
            if (events.contains(Player.EVENT_POSITION_DISCONTINUITY) ||
                events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                events.contains(Player.EVENT_IS_PLAYING_CHANGED) ||
                events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED)
            ) publishProgress()
            syncTicker()
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync().also { f ->
            f.addListener({
                runCatching { f.get() }.onSuccess { c ->
                    controller = c
                    c.addListener(listener)
                    pendingQueue?.also { q -> pendingQueue = null; setQueue(q.tracks, q.index, q.play, q.positionMs) }
                    invalidateQueue(); publish(); publishProgress(); syncTicker()
                    _connected.value = true
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }

    /** Suspends until the session is bound. Callers that inspect the live queue must await this. */
    suspend fun awaitConnected() { _connected.first { it } }

    /** True when a session is already playing something: restoring over it would rewind the user. */
    fun hasQueue(): Boolean = (controller?.mediaItemCount ?: 0) > 0

    /** Called from the Activity lifecycle: no polling at all while the UI is not visible. */
    fun setUiActive(active: Boolean) {
        if (uiActive == active) return
        uiActive = active
        if (active) { publish(); publishProgress() }
        syncTicker()
    }

    private fun syncTicker() {
        val shouldTick = uiActive && _state.value.isPlaying
        if (shouldTick) {
            if (tickerJob?.isActive == true) return
            tickerJob = scope.launch {
                while (isActive) { delay(TICK_MS); publishProgress(); publishSleep() }
            }
        } else {
            tickerJob?.cancel(); tickerJob = null
        }
    }

    private fun invalidateQueue() {
        val p = controller ?: return
        cachedQueueIds = ArrayList<String>(p.mediaItemCount).apply {
            for (i in 0 until p.mediaItemCount) add(p.getMediaItemAt(i).mediaId)
        }
    }

    private fun publish() {
        val p = controller ?: return
        // playWhenReady instead of isPlaying: the icon must not flicker while the player buffers after a seek
        val playing = p.playWhenReady && p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        val next = PlaybackState(
            connected = true,
            isPlaying = playing,
            currentIndex = p.currentMediaItemIndex.coerceAtLeast(0),
            currentTrackId = p.currentMediaItem?.mediaId,
            queueIds = cachedQueueIds,
            shuffle = p.shuffleModeEnabled,
            repeatMode = p.repeatMode,
            sleepMinutesLeft = minutesLeft()
        )
        if (next != _state.value) _state.value = next
    }

    /** Session duration when it is known, our own metadata otherwise. Never zero for a real track. */
    private fun durationOf(p: MediaController): Long {
        val reported = p.duration
        if (reported > 0L) return reported
        val id = p.currentMediaItem?.mediaId ?: return 0L
        return knownDurations[id] ?: 0L
    }

    private fun publishProgress() {
        val p = controller ?: return
        val duration = durationOf(p)
        val reported = p.currentPosition.coerceAtLeast(0L)
        // While latched the freshly seeked target wins, so the thumb never snaps back.
        val latched = SystemClock.elapsedRealtime() < latchUntilMs
        val position = if (latched && (reported - seekTargetMs).absoluteValue > SEEK_LATCH_TOLERANCE_MS) {
            seekTargetMs
        } else {
            if (latched) latchUntilMs = 0L
            reported
        }
        val next = Progress(position, duration)
        if (next != _progress.value) _progress.value = next
    }

    private fun publishSleep() {
        val left = minutesLeft()
        if (left != _state.value.sleepMinutesLeft) _state.value = _state.value.copy(sleepMinutesLeft = left)
    }

    private fun minutesLeft(): Int? = sleepEndAtMs?.let { end ->
        val left = end - System.currentTimeMillis()
        if (left <= 0) null else ((left + 59_999) / 60_000).toInt()
    }

    /**
     * Building hundreds of MediaItems takes tens of milliseconds, which used to be spent on the
     * main thread right after a tap - that is exactly the "button feels slow" symptom. The list is
     * now built on a background dispatcher and only handed to the controller on the main thread.
     */
    fun setQueue(tracks: List<TrackEntity>, startIndex: Int, play: Boolean = true, startPositionMs: Long = 0L) {
        if (tracks.isEmpty()) return
        val p = controller ?: run { pendingQueue = PendingQueue(tracks, startIndex, play, startPositionMs); return }
        val epoch = ++queueEpoch
        scope.launch {
            val prepared = withContext(Dispatchers.Default) {
                val durations = HashMap<String, Long>(tracks.size * 2)
                // Fall back to the audio file itself for artwork: the service reads the embedded
                // cover from it, so the system notification is never left without art. See
                // mediaItemOf, which owns that rule for both call sites.
                val items = tracks.map { t ->
                    durations[t.id] = t.durationMs
                    mediaItemOf(t)
                }
                items to durations
            }
            if (epoch != queueEpoch) return@launch
            knownDurations = prepared.second
            latchUntilMs = 0L
            val items = prepared.first
            p.setMediaItems(items, startIndex.coerceIn(items.indices), startPositionMs.coerceAtLeast(0))
            p.prepare(); if (play) p.play()
            invalidateQueue(); publish(); publishProgress(); syncTicker()
        }
    }

    /**
     * One MediaItem. Extracted in 6.6 so [setQueue] and [enqueue] cannot drift apart: the artwork
     * fallback to the audio file itself is what keeps the notification from losing its cover, and
     * that detail existed in exactly one place before.
     */
    private fun mediaItemOf(t: TrackEntity): MediaItem =
        MediaItem.Builder().setMediaId(t.id).setUri(t.uri).setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .setArtworkUri(Uri.parse(t.artworkUri ?: t.uri))
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .build()
        ).build()

    /**
     * Inserts a single track without disturbing what is playing (6.6).
     *
     * [playNext] puts it straight after the current item, otherwise it lands at the end. With an
     * empty queue there is nothing to insert into, so it starts playing instead. The duration is
     * registered too: [durationOf] falls back to this map before the player has prepared the item,
     * and a missing entry would show the new track as 0:00 in the queue sheet.
     */
    fun enqueue(track: TrackEntity, playNext: Boolean) {
        val p = controller ?: run { pendingQueue = PendingQueue(listOf(track), 0, true, 0L); return }
        if (p.mediaItemCount == 0) { setQueue(listOf(track), 0, play = true); return }
        knownDurations = HashMap(knownDurations).apply { put(track.id, track.durationMs) }
        val at = if (playNext) (p.currentMediaItemIndex + 1).coerceIn(0, p.mediaItemCount) else p.mediaItemCount
        p.addMediaItem(at, mediaItemOf(track))
        invalidateQueue(); publish()
    }

    /** Used when a track is removed from the library: it must leave the running queue too. */
    fun removeFromQueue(trackId: String) {
        val p = controller ?: return
        val index = cachedQueueIds.indexOf(trackId)
        if (index < 0) return
        if (p.mediaItemCount <= 1) { p.pause(); p.clearMediaItems() } else p.removeMediaItem(index)
        invalidateQueue(); publish(); publishProgress()
    }

    fun playPause() { controller?.let { if (it.playWhenReady) it.pause() else it.play() }; publish(); syncTicker() }

    fun seekTo(positionMs: Long) {
        val p = controller ?: return
        val duration = durationOf(p)
        // Never land inside the last moment of a track: that is what made it jump to the next one.
        val max = if (duration > 0L) (duration - END_GUARD_MS).coerceAtLeast(0L) else Long.MAX_VALUE
        val target = positionMs.coerceAtLeast(0L).coerceAtMost(max)
        seekTargetMs = target
        latchUntilMs = SystemClock.elapsedRealtime() + SEEK_LATCH_MS
        p.seekTo(target)
        _progress.value = Progress(target, duration)
    }

    fun seekToIndex(index: Int) { latchUntilMs = 0L; controller?.seekToDefaultPosition(index); publish(); publishProgress() }
    fun next() { latchUntilMs = 0L; controller?.seekToNextMediaItem(); publish(); publishProgress() }
    fun previous() {
        val p = controller ?: return
        latchUntilMs = 0L
        // Standard behaviour: restart the track if we are past 3 seconds, otherwise go back
        if (p.currentPosition > 3000) p.seekTo(0) else p.seekToPreviousMediaItem()
        publish(); publishProgress()
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; publish() }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
        publish()
    }
    fun setPlayback(speed: Float, pitch: Float, reverb: Int = 0) {
        controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_REVERB, Bundle.EMPTY), Bundle().apply { putInt("percent", reverb) })
    }
    fun setSkipSilence(enabled: Boolean) {
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_SKIP_SILENCE, Bundle.EMPTY), Bundle().apply { putBoolean("enabled", enabled) })
    }
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel(); sleepJob = null
        if (minutes == null || minutes <= 0) { sleepEndAtMs = null; publishSleep(); return }
        sleepEndAtMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause(); sleepEndAtMs = null; publish(); publishSleep()
        }
        publishSleep()
    }
    fun release() {
        sleepJob?.cancel(); tickerJob?.cancel()
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        scope.cancel()
    }
}
