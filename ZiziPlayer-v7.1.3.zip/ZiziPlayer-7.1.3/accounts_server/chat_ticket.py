"""Short-lived ticket for the realtime chat daemon (zizi-chat), Accounts 1.4.

The chat daemon never touches accounts.sqlite and never sees JWTs or cookies. The client first asks THIS
service (full session check: signature, revocation, disabled flag) for a ticket, then opens the WebSocket
with ``X-Zizi-Ticket: <ticket>``. The ticket is an HMAC-SHA256 envelope over a small JSON payload, valid
for 60 seconds. The shared secret lives only in the two env files (accounts.env, chat.env), never in the APK.

Wire format (must stay byte-identical with chat_server/chatlib.py):
    ticket = b64url(payload_json) + "." + b64url(HMAC_SHA256(secret, b"zizi-chat-ticket\\0" + b64url(payload_json)))
Payload keys: v=1, u=user id, n=display name (<=32), r=role, pr=profile revision, cr=account created (unix),
iat, exp, j=random id.
"""
import base64
import hashlib
import hmac
import json
import re
import secrets
import unicodedata

from core import AuthError

TICKET_SECONDS = 60
MIN_SECRET = 32
NAME_MAX = 32
AVATAR_BATCH = 4          # avatars are up to ~400 KB of base64 each: small batches keep one response under ~1.6 MB
UID_RE = re.compile(r'^[0-9a-f]{32}$')


def _b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')


def sign(secret, body):
    mac = hmac.new(secret.encode('utf-8'), b'zizi-chat-ticket\0' + body.encode('ascii'), hashlib.sha256).digest()
    return _b64(mac)


def display_name(raw, uid):
    """What other people see. Never an e-mail; falls back to a stable short handle."""
    text = unicodedata.normalize('NFC', raw or '')
    text = ''.join(ch if not unicodedata.category(ch).startswith('C') else ' ' for ch in text)
    text = ' '.join(text.split())[:NAME_MAX].strip()
    if text:
        return text
    return 'Zizi-' + hashlib.sha256(uid.encode('utf-8')).hexdigest()[:4]


def issue(accounts, user, secret):
    """`user` is the dict returned by Accounts.authenticate()['user']."""
    if not isinstance(secret, str) or len(secret) < MIN_SECRET:
        raise AuthError('chat_not_configured', 503)
    uid = user['id']
    with accounts.connection() as c:
        profile = c.execute('SELECT name, revision FROM account_profiles WHERE uid=?', (uid,)).fetchone()
        row = c.execute('SELECT role, created, verified FROM users WHERE id=? AND disabled=0', (uid,)).fetchone()
    if not row or not row['verified']:
        raise AuthError('forbidden', 403)
    now = accounts.now()
    payload = {'v': 1, 'u': uid, 'n': display_name(profile['name'] if profile else '', uid), 'r': row['role'],
               'pr': int(profile['revision']) if profile else 0, 'cr': int(row['created']),
               'iat': now, 'exp': now + TICKET_SECONDS, 'j': secrets.token_hex(8)}
    body = _b64(json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode('utf-8'))
    return {'ticket': body + '.' + sign(secret, body), 'exp': payload['exp'], 'me': uid, 'name': payload['n']}


def avatars(accounts, payload):
    """Avatars of chat participants, for the client's local cache (Accounts 1.4.1).

    Request:  {"uids": [<=4 user ids], "known": {uid: revision the client already holds}}
    Response: {"items": [{"u": uid, "rev": profile revision, "a": base64 avatar}]}  ("a" is left out when the client's
    revision is current, so a refresh of an unchanged avatar costs ~60 bytes; "" means the user has no avatar).

    Any signed-in user may ask: the avatar is exactly what the chat shows next to the person's messages anyway, user ids
    are 128-bit random values that are only learned from the chat itself, and the caller is rate limited by the route.
    """
    if not isinstance(payload, dict) or not set(payload) <= {'uids', 'known'}:
        raise AuthError('bad_request', 400)
    uids = payload.get('uids')
    known = payload.get('known', {})
    if not isinstance(uids, list) or not 1 <= len(uids) <= AVATAR_BATCH or not isinstance(known, dict):
        raise AuthError('bad_request', 400)
    if not all(isinstance(u, str) and UID_RE.match(u) for u in uids):
        raise AuthError('bad_request', 400)
    uids = list(dict.fromkeys(uids))
    have = {k: v for k, v in known.items() if k in uids and isinstance(v, int) and not isinstance(v, bool)}
    marks = ','.join('?' * len(uids))
    with accounts.connection() as c:
        rows = {r['uid']: r for r in c.execute(
            'SELECT uid, avatar, revision FROM account_profiles WHERE uid IN (' + marks + ')', uids)}
    items = []
    for u in uids:
        row = rows.get(u)
        rev = int(row['revision']) if row else 0
        item = {'u': u, 'rev': rev}
        if have.get(u) != rev:
            item['a'] = (row['avatar'] or '') if row else ''
        items.append(item)
    return {'items': items}
