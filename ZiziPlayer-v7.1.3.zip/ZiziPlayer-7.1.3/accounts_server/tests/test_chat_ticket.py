"""Chat ticket endpoint (Accounts 1.4): auth, rate limit, payload contents, secret handling, daemon compatibility."""
import base64
import json
import os
import sys
import unittest

import test_accounts as existing
from core import AuthError
from web import ACCESS_COOKIE, Application
import chat_ticket

SECRET = 'unit-test-secret-0123456789abcdef0123456789'


def payload_of(ticket):
    body = ticket.split('.')[0]
    return json.loads(base64.urlsafe_b64decode(body + '=' * (-len(body) % 4)))


class ChatTicketTest(unittest.TestCase):
    setUpClass = classmethod(existing.AccountsTest.setUpClass.__func__)
    setUp = existing.AccountsTest.setUp
    verified = existing.AccountsTest.verified
    http = existing.AccountsTest.http

    def app(self, secret=SECRET):
        self.web = Application(self.a, 'https://accounts.example.org', lambda *args: None, chat_secret=secret)

    def user(self):
        p = self.verified()
        return p, ACCESS_COOKIE + '=' + p['access']

    def second_user(self):
        code = self.a.register('other@example.org', existing.PASSWORD)
        self.a.redeem(code, 'verify')
        return ACCESS_COOKIE + '=' + self.a.login('other@example.org', existing.PASSWORD)['access']

    def test_requires_login_and_secret(self):
        self.app()
        self.assertEqual(self.http('/auth/chat/ticket', {})[0], 401)
        _, jar = self.user()
        self.app('')
        status, _, body = self.http('/auth/chat/ticket', {}, jar=jar)
        self.assertEqual(status, 503)
        self.app('short')
        self.assertEqual(self.http('/auth/chat/ticket', {}, jar=jar)[0], 503)

    def test_ticket_contents_and_ttl(self):
        self.app()
        p, jar = self.user()
        status, _, body = self.http('/auth/chat/ticket', {}, jar=jar)
        self.assertEqual(status, 200)
        pl = payload_of(body['ticket'])
        self.assertEqual((pl['v'], pl['u'], pl['r'], pl['exp'] - pl['iat']), (1, p['user']['id'], 'user', 60))
        self.assertEqual(body['me'], p['user']['id'])
        self.assertRegex(pl['n'], r'^Zizi-[0-9a-f]{4}$')               # no profile yet: stable handle, never the e-mail
        self.assertNotIn('@', json.dumps(pl))
        self.assertEqual(body['ticket'].split('.')[1], chat_ticket.sign(SECRET, body['ticket'].split('.')[0]))
        again = self.http('/auth/chat/ticket', {}, jar=jar)[2]
        self.assertNotEqual(again['ticket'], body['ticket'])           # random jti

    def test_profile_name_is_used(self):
        self.app()
        p, jar = self.user()
        self.http('/auth/profile', {'name': 'Томиока  Гию', 'avatar': '', 'expected_revision': '0'}, jar=jar)
        pl = payload_of(self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket'])
        self.assertEqual((pl['n'], pl['pr']), ('Томиока Гию', 1))

    def test_rate_limit(self):
        self.app()
        _, jar = self.user()
        codes = [self.http('/auth/chat/ticket', {}, jar=jar)[0] for _ in range(22)]
        self.assertEqual(codes[:20], [200] * 20)
        self.assertEqual(set(codes[20:]), {429})

    def test_display_name_rules(self):
        uid = 'a' * 32
        self.assertEqual(chat_ticket.display_name('  A\u0000\n B  ', uid), 'A B')
        self.assertEqual(len(chat_ticket.display_name('x' * 99, uid)), 32)
        self.assertRegex(chat_ticket.display_name('', uid), r'^Zizi-[0-9a-f]{4}$')
        self.assertEqual(chat_ticket.display_name('\u200f\u0007', uid)[:5], 'Zizi-')

    def test_daemon_accepts_what_accounts_issues(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'chat_server'))
        import chatlib
        self.app()
        p, jar = self.user()
        ticket = self.http('/auth/chat/ticket', {}, jar=jar)[2]['ticket']
        got = chatlib.verify_ticket(SECRET, ticket, self.now, {})
        self.assertEqual((got['u'], got['r']), (p['user']['id'], 'user'))

    # ---- 1.4.1: avatars of chat participants -------------------------------------------------------------------

    def set_profile(self, jar, name, avatar):
        """Profile through the real route (revision rules apply); avatar is written straight into the row, the PNG
        validation of the profile route is covered by its own tests."""
        self.http('/auth/profile', {'name': name, 'avatar': '', 'expected_revision': '0'}, jar=jar)
        uid = self.http('/auth/chat/ticket', {}, jar=jar)[2]['me']
        with self.a.connection() as c:
            c.execute('UPDATE account_profiles SET avatar=? WHERE uid=?', (avatar, uid))
        return uid

    def test_avatars_payload_known_revision_and_missing(self):
        self.app()
        _, jar = self.user()
        other = self.second_user()
        uid = self.set_profile(other, 'Томиока', 'QUJD')
        ghost = 'f' * 32
        status, _, body = self.http('/auth/chat/avatars', {'uids': [uid, ghost]}, jar=jar)
        self.assertEqual(status, 200)
        self.assertEqual(body['items'], [{'u': uid, 'rev': 1, 'a': 'QUJD'}, {'u': ghost, 'rev': 0, 'a': ''}])
        self.assertRegex(body['me'], r'^[0-9a-f]{32}$')
        again = self.http('/auth/chat/avatars', {'uids': [uid, ghost], 'known': {uid: 1, ghost: 0}}, jar=jar)[2]
        self.assertEqual(again['items'], [{'u': uid, 'rev': 1}, {'u': ghost, 'rev': 0}])      # nothing re-sent
        stale = self.http('/auth/chat/avatars', {'uids': [uid], 'known': {uid: 0}}, jar=jar)[2]
        self.assertEqual(stale['items'], [{'u': uid, 'rev': 1, 'a': 'QUJD'}])

    def test_avatars_validation_and_auth(self):
        self.app()
        self.assertEqual(self.http('/auth/chat/avatars', {'uids': ['a' * 32]})[0], 401)
        _, jar = self.user()
        good = 'a' * 32
        for bad in ({}, {'uids': []}, {'uids': [good] * 5}, {'uids': ['A' * 32]}, {'uids': ["x'--"]}, {'uids': [1]},
                    {'uids': good}, {'uids': [good], 'known': []}, {'uids': [good], 'extra': 1}):
            self.assertEqual(self.http('/auth/chat/avatars', bad, jar=jar)[0], 400, bad)
        dup = self.http('/auth/chat/avatars', {'uids': [good, good], 'known': {good: True, 'z': 1}}, jar=jar)
        self.assertEqual((dup[0], dup[2]['items']), (200, [{'u': good, 'rev': 0, 'a': ''}]))   # dedupe, bool is not a revision

    def test_avatars_rate_limit(self):
        self.app()
        _, jar = self.user()
        codes = [self.http('/auth/chat/avatars', {'uids': ['a' * 32]}, jar=jar)[0] for _ in range(62)]
        self.assertEqual(codes[:60], [200] * 60)
        self.assertEqual(set(codes[60:]), {429})


if __name__ == '__main__':
    unittest.main()
