package app.ziziplayer.ui;

/** Measured on the supplied 1080 x 2400 reference, below its 108 px status bar.
 * Scale by available width; screenshots do not encode Android density.
 */
public final class CollectionGeometry {
    private CollectionGeometry() {}
    public static final float REFERENCE_WIDTH = 1080f;
    public static final float HERO = 896f;
    public static final float COLLAPSE_SCROLL = 688f;
    public static final float TOOLBAR = 162f;
    public static final float PLAY_SIZE = 140f;
    public static final float PLAY_TOP = 713f;
    public static final float PLAY_PINNED_TOP = 95f;
    public static final float PLAY_END = 28f;
    public static final float ROW = 184f;
    public static final float ART = 140f;
    public static final float CONTENT_INSET = 46f;

    public static float playTop(float scroll, float extra) {
        return Math.max(PLAY_PINNED_TOP, PLAY_TOP + Math.max(0f, extra) - Math.max(0f, scroll));
    }
    /** Short lists must still have enough scroll range to collapse the entire header.
     * Padding is content, not a second nested scroller or a viewport inset.
     */
    public static float minimumTail(float viewport, float hero, int tracks, float bottomInset) {
        float collapse = COLLAPSE_SCROLL + Math.max(0f, hero - HERO);
        float body = hero + ROW * (Math.max(0, tracks) + 1);
        return Math.max(0f, viewport + collapse - body - bottomInset);
    }
    public static float smoothstep(float value) {
        float t = Math.max(0f, Math.min(1f, value));
        return t * t * (3f - 2f * t);
    }
    public static float headerAlpha(float scroll) { return smoothstep((scroll - 350f) / 268f); }
    public static float titleAlpha(float scroll) { return smoothstep((scroll - 460f) / 158f); }
    public static float scrimAlpha(float progress) { return 0.65f * smoothstep(progress); }
}
