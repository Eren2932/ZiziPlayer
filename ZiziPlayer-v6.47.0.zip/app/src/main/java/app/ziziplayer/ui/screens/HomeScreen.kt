package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.HomeViewModel
import app.ziziplayer.ui.HomeState
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun HomeScreen(
    home: HomeViewModel,
    current: TrackEntity?,
    playing: Boolean,
    onContinue: () -> Unit,
    onOpenPlayer: () -> Unit,
    onPlay: (TrackEntity, List<TrackEntity>) -> Unit,
    onPlaylist: (Long) -> Unit,
    onFavorites: () -> Unit,
    onLibrary: () -> Unit,
    onDiscover: () -> Unit
) {
    val raw by home.state.collectAsStateWithLifecycle()
    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as ZiziApplication
    val gate by app.repository.vault.state.collectAsStateWithLifecycle()
    // Synchronous privacy boundary; do not render a stale projection for even one frame.
    val state = if (raw.vaultFolders == gate.folders) raw else HomeState()
    val historyOpen by home.historyOpen.collectAsStateWithLifecycle()
    val message by home.message.collectAsStateWithLifecycle()
    val problem by home.storageProblem.collectAsStateWithLifecycle()
    val p = LocalPalette.current
    val bottom = LocalBottomChromeInset.current
    var managePins by rememberSaveable { mutableStateOf(false) }
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    var historyLimit by rememberSaveable { mutableIntStateOf(50) }
    val homeScroll = rememberLazyListState()
    val historyScroll = rememberLazyListState()
    LaunchedEffect(home) { home.entered() }
    val safeCurrent = current?.takeIf { it.isRemote || it.sourceFolder !in gate.folders }
    val dateFormat = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        state = if (historyOpen) historyScroll else homeScroll,
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = bottom + 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item("header") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (historyOpen) IconButton(onClick = { home.back() }) {
                    Icon(ZiziIcons.ChevronDown, contentDescription = "На главную", tint = p.text)
                }
                Text(if (historyOpen) "История" else "Главная", color = p.text,
                    fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { if (historyOpen) confirmClear = true else home.openHistory() }) {
                    Text(if (historyOpen) "Очистить" else "История", color = p.text)
                }
            }
        }
        if (problem != null) item("storage-problem") { Text(problem.orEmpty(), color = p.subtext) }
        if (message != null) item("message") {
            TextButton(onClick = home::dismissMessage) { Text(message.orEmpty(), color = p.text) }
        }
        if (state.loading) item("loading") { Text("Собираем твою музыку…", color = p.subtext) }
        else if (historyOpen) {
            item("totals") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface).padding(18.dp)) {
                    Text("${listeningTime(state.listenedMs)} воспроизведения", color = p.text,
                        fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Зачтено: ${state.qualified} · Дослушано: ${state.completed} · Пропущено: ${state.skipped}",
                        color = p.subtext, modifier = Modifier.padding(top = 8.dp))
                    Text("За сохранённую историю: до 180 дней и 10 000 сессий. Старые счётчики сюда не переносятся.",
                        color = p.subtext, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
            if (state.history.isEmpty()) item("empty-history") {
                HomeEmpty("Здесь появится музыка, которую ты действительно включал. Паузы и загрузка не добавляют время.")
            }
            items(state.history.take(historyLimit), key = { it.session.sessionId }) { entry ->
                val session = entry.session
                val outcome = when (session.outcome) {
                    "active" -> "Сессия открыта"
                    "ended" -> if (session.completed) "Дослушано" else "Достигнут конец"
                    "skipped" -> if (session.listenedMs < 10_000) "Ранний пропуск" else "Пропущено"
                    "error" -> "Ошибка воспроизведения"
                    "interrupted" -> "Сессия прервана"
                    "replaced" -> "Заменена очередь"
                    "removed" -> "Убрано из очереди"
                    else -> "Остановлено"
                }
                HomeTrackRow(entry.track, session.title, session.artist,
                    "${dateFormat.format(Date(session.startedAt))} · ${listeningTime(session.listenedMs)} · $outcome" +
                        if (entry.track == null) " · Источник недоступен" else "",
                    enabled = entry.track != null,
                    onClick = { entry.track?.let { onPlay(it, listOf(it)) } })
            }
            if (historyLimit < state.history.size) item("more-history") {
                TextButton(onClick = { historyLimit += 50 }) { Text("Показать ещё", color = p.text) }
            }
        } else {
            if (safeCurrent != null) item("continue") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.surface).padding(16.dp)) {
                    Text(if (playing) "Сейчас играет" else "Продолжить", color = p.subtext, fontSize = 13.sp)
                    HomeTrackRow(safeCurrent, safeCurrent.title, safeCurrent.artist, "", onClick = onOpenPlayer)
                    TextButton(onClick = if (playing) onOpenPlayer else onContinue) {
                        Text(if (playing) "Открыть плеер" else "Продолжить воспроизведение", color = p.text)
                    }
                }
            }
            item("quick-actions") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HomeAction("Избранное", Modifier.weight(1f), onFavorites)
                    HomeAction("Моя музыка", Modifier.weight(1f), onLibrary)
                }
            }
            item("playlist-heading") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HomeHeading(if (state.playlists.any { it.pinned }) "Под рукой" else "Твои плейлисты", Modifier.weight(1f))
                    TextButton(onClick = { managePins = true }) { Text("Закрепить", color = p.subtext) }
                }
            }
            val cards = state.playlists.filter { it.pinned }.ifEmpty { state.playlists.take(4) }
            if (cards.isEmpty()) item("empty-playlists") { HomeEmpty("Создай плейлист в медиатеке и закрепи его здесь.") }
            else item("playlists") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(cards, key = { it.playlist.id }) { card ->
                        Column(Modifier.width(144.dp).clip(RoundedCornerShape(16.dp)).clickable { onPlaylist(card.playlist.id) }) {
                            TrackArtwork(card.cover, 320, Modifier.size(144.dp).clip(RoundedCornerShape(16.dp)))
                            Text(card.playlist.name, color = p.text, fontWeight = FontWeight.SemiBold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                            Text("${card.count} треков", color = p.subtext, fontSize = 12.sp)
                        }
                    }
                }
            }
            val recent = state.history.filter { it.session.listenedMs > 0 }
                .mapNotNull { it.track }.distinctBy { it.id }.take(4)
            if (recent.isNotEmpty()) {
                item("recent-heading") { HomeHeading("Недавно слушал") }
                items(recent, key = { "recent:" + it.id }) { track ->
                    HomeTrackRow(track, track.title, track.artist, "", onClick = { onPlay(track, recent) })
                }
            }
            if (state.recentAdded.isNotEmpty()) {
                item("added-heading") { HomeHeading("Недавно добавлено") }
                item("added") { HomeTrackShelf(state.recentAdded, onPlay) }
            }
            if (state.offline.isNotEmpty()) {
                item("offline-heading") { HomeHeading("На устройстве") }
                item("offline-description") { Text("Локальные файлы и завершённые загрузки", color = p.subtext, fontSize = 12.sp) }
                item("offline") { HomeTrackShelf(state.offline, onPlay) }
            }
            item("discover") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface)
                    .clickable(onClick = onDiscover).padding(20.dp)) {
                    HomeHeading("Открой новое")
                    Text("Артисты, альбомы и подборки каталога →", color = p.subtext, modifier = Modifier.padding(top = 8.dp))
                }
            }
            item("privacy") { Text("Твоя история хранится только на устройстве. Защищённые папки в неё не попадают.", color = p.subtext, fontSize = 12.sp) }
        }
    }
    if (managePins) AlertDialog(onDismissRequest = { managePins = false }, title = { Text("Под рукой · до 6 плейлистов") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (state.playlists.isEmpty()) item { Text("Сначала создай плейлист в медиатеке.") }
                items(state.playlists, key = { it.playlist.id }) { card ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(card.playlist.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { home.setPinned(card.playlist.id, !card.pinned) }) {
                            Text(if (card.pinned) "Убрать" else "Закрепить")
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { managePins = false }) { Text("Готово") } })
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Очистить историю?") },
        text = { Text("Сессии и их время будут удалены. Музыка, избранное, плейлисты и старые счётчики медиатеки останутся. Текущее слушание начнёт новую сессию.") },
        confirmButton = { TextButton(onClick = { confirmClear = false; home.clearHistory() }) { Text("Очистить") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } })
}

private fun listeningTime(ms: Long): String {
    val seconds = ms.coerceAtLeast(0) / 1000
    return when {
        seconds >= 3600 -> "${seconds / 3600} ч ${seconds % 3600 / 60} мин"
        seconds >= 60 -> "${seconds / 60} мин ${seconds % 60} с"
        else -> "$seconds с"
    }
}

@Composable
private fun HomeHeading(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, color = LocalPalette.current.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
}
@Composable
private fun HomeEmpty(text: String) { Text(text, color = LocalPalette.current.subtext, modifier = Modifier.padding(vertical = 12.dp)) }
@Composable
private fun HomeAction(text: String, modifier: Modifier, action: () -> Unit) {
    val p = LocalPalette.current
    Box(modifier.heightIn(min = 64.dp).clip(RoundedCornerShape(16.dp)).background(p.surface)
        .clickable(onClick = action).padding(14.dp), contentAlignment = Alignment.CenterStart) {
        Text(text, color = p.text, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun HomeTrackShelf(tracks: List<TrackEntity>, onPlay: (TrackEntity, List<TrackEntity>) -> Unit) {
    val p = LocalPalette.current
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(tracks, key = { it.id }) { track ->
            Column(Modifier.width(144.dp).clip(RoundedCornerShape(16.dp)).clickable { onPlay(track, tracks) }) {
                TrackArtwork(track, 320, Modifier.size(144.dp).clip(RoundedCornerShape(16.dp)))
                Text(track.title, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold)
                Text(track.artist, color = p.subtext, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
            }
        }
    }
}
@Composable
private fun HomeTrackRow(track: TrackEntity?, title: String, artist: String, detail: String, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).clip(RoundedCornerShape(12.dp))
        .clickable(enabled = enabled, onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TrackArtwork(track, 160, Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(artist, color = p.subtext, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            if (detail.isNotEmpty()) Text(detail, color = p.subtext, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}
