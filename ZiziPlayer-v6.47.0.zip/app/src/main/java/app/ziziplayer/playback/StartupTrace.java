package app.ziziplayer.playback;

import java.util.ArrayDeque;

/** In-memory timings only. No track metadata, URLs, credentials, disk writes or network uploads. */
public final class StartupTrace {
    public enum Stage { TAP_REMOTE, PREPARE_QUEUE, ITEM_CHANGED, AUDIO_LOADING, AUDIO_PREPARED,
        AUDIO_PLAYING, MATCH, RESOLVE, NETWORK_OPEN, LYRICS_HTTP }
    public enum Outcome { OK, ERROR, CANCELLED }
    private static final int LIMIT = 128;
    private static final long ORIGIN = System.nanoTime();
    private static final ArrayDeque<String> events = new ArrayDeque<>();
    private static long sequence;
    private StartupTrace() {}
    public static final class Span {
        private final long id, started;
        private final Stage stage;
        private boolean ended;
        private Span(long id, Stage stage) { this.id = id; this.stage = stage; started = System.nanoTime(); }
    }
    private static void append(String text) {
        while (events.size() >= LIMIT) events.removeFirst();
        events.addLast((System.nanoTime() - ORIGIN) / 1_000_000L + " ms | " + text);
    }
    public static synchronized void mark(Stage stage) { append(stage.name()); }
    public static synchronized Span begin(Stage stage) {
        Span span = new Span(++sequence, stage);
        append("#" + span.id + " " + stage.name() + " START");
        return span;
    }
    public static synchronized void finish(Span span, Outcome outcome) {
        if (span == null || span.ended) return;
        span.ended = true;
        append("#" + span.id + " " + span.stage.name() + " " + outcome.name() + " took=" +
            (System.nanoTime() - span.started) / 1_000_000L + " ms");
    }
    public static synchronized String snapshot() {
        return "Local startup timings; milliseconds since process trace start. Last 128 events.\n" +
            "No track names, IDs, URLs or tokens. AUDIO_PLAYING is a player event, not acoustic measurement.\n" +
            String.join("\n", events);
    }
}
