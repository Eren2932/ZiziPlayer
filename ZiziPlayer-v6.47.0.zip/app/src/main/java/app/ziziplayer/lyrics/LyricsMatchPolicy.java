package app.ziziplayer.lyrics;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Metadata equivalence, NOT audio recognition. Version qualifiers are never discarded. */
public final class LyricsMatchPolicy {
    private LyricsMatchPolicy() {}
    private static final Pattern COSMETIC = Pattern.compile(
        "(?i)\\s*[\\[(](?:official\\s+(?:audio|music\\s+video|video)|lyrics?|lyric\\s+video|audio)[\\])]\\s*");
    private static final Pattern PUNCTUATION = Pattern.compile("[\\p{P}\\p{S}]");
    private static final Pattern SPACE = Pattern.compile("\\s+");
    public static String searchTitle(String title) {
        return COSMETIC.matcher(title == null ? "" : title).replaceAll(" ").trim();
    }
    private static String normalized(String value) {
        String unicode = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFKC);
        return SPACE.matcher(PUNCTUATION.matcher(unicode).replaceAll(" ").trim())
            .replaceAll(" ").toLowerCase(Locale.ROOT);
    }
    public static boolean identityMatches(String title, String artist, String otherTitle, String otherArtist) {
        String t = normalized(searchTitle(title));
        String a = normalized(artist).replace(" ", "");
        return !t.isEmpty() && !a.isEmpty() && t.equals(normalized(searchTitle(otherTitle)))
            && a.equals(normalized(otherArtist).replace(" ", ""));
    }
    /** A close recording may supply plain lyrics; only the strict timeline gate enables karaoke. */
    public static boolean textDurationMatches(long expected, long actual) {
        if (actual <= 0) return false;
        return expected <= 0 || Math.abs(expected - actual) <= Math.max(15000L, expected / 10L);
    }
    public static long retryDelay(long now, long deadline) {
        return Math.max(1L, deadline - now);
    }
}
