package app.ziziplayer.data.remote

import app.ziziplayer.playback.StartupTrace
import okhttp3.Callback
import okhttp3.Response
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Dispatcher
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * The one HTTP client in the process.
 *
 * It is shared with Media3 (`OkHttpDataSource.Factory(ZiziHttp.client)`) on purpose: one connection
 * pool, one DNS cache, one TLS session cache. A second client would mean a second full TCP+TLS
 * handshake for the audio stream right after the search request just finished talking to the same
 * host - which is exactly the "first second of playback stutters" case.
 *
 * Redirects remain enabled for supported media and CDN endpoints.
 */
object ZiziHttp {

    /** A plain mobile browser UA. No fingerprinting games, no impersonating an app we are not. */
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val json = "application/json; charset=utf-8".toMediaType()

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            // Last word on identity and session payload. Media3 shares this client, therefore the
            // same policy is enforced for catalogue JSON, artwork and stream requests.
            .addInterceptor(SessionHeadersInterceptor())
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            // Audio is a long lived read; a pool that closes idle connections too eagerly makes
            // every track change pay for a new handshake.
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /**
     * Клиент для запросов, которые ЗАКОННО долгие (6.37.0).
     *
     * Один потребитель — `/match/deezer`. Сопоставление витрины со звуком это несколько поисковых
     * заходов на стороне сервера, то есть секунды процессорного времени, а не миллисекунды сети.
     * Общий [client] отваливается через 20 секунд, и в 6.36.0 это давало ровно ту картину, из-за
     * которой релиз считался нерабочим: сервер честно искал трек, находил его и клал в кэш, а
     * телефон к этому моменту уже отменил запрос, показал ошибку и перескочил на следующий трек.
     *
     * Пул соединений общий с [client] — это тот же хост, и переиспользовать TLS-сессию дешевле,
     * чем открывать вторую. Отличается только терпение.
     */
    // Foreground stream metadata must not queue behind search/warm JSON. newBuilder shares
    // the connection pool and auth policy; only the asynchronous request queue is isolated.
    private val resolverClient: OkHttpClient by lazy {
        client.newBuilder().dispatcher(Dispatcher()).build()
    }

    val slowClient: OkHttpClient by lazy {
        resolverClient.newBuilder()
            .readTimeout(75, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }

    suspend fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody(json))
                .header("User-Agent", USER_AGENT)
                .header("Content-Type", "application/json")
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    suspend fun getJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .get()
                .header("User-Agent", USER_AGENT)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(client.newCall(request), url)
        }

    /**
     * [getJson] через [slowClient]: тот же контракт, другое терпение (6.37.0).
     */
    suspend fun getJsonSlow(url: String, headers: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .get()
                .header("User-Agent", USER_AGENT)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            execute(slowClient.newCall(request), url)
        }

    /**
     * 6.10.1 - like [getJson], but does NOT throw on a non-2xx: returns the code and the body if
     * the body parses as JSON.
     *
     * Why it exists. Our own resolver answers with a meaningful status - 451 geo-blocked, 404 gone,
     * 403 bot-check, 402 members-only - plus a human `detail`. [execute] collapses all of that into
     * a single "PROTOCOL HTTP 451" and throws the reason away. That reason is the whole point: a
     * track blocked in the server's region is a permanent verdict (do not retry, do not mint a
     * poToken, tell the user the truth), while a bot-check is worth another attempt. Same HTTP
     * call, opposite consequence.
     */
    suspend fun getJsonStatus(
        url: String,
        headers: Map<String, String> = emptyMap()
    ): Pair<Int, JSONObject?> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", USER_AGENT)
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .build()
        val transport = if (request.url.encodedPath == "/resolve") resolverClient else client
        executeParsed(transport.newCall(request)) { response ->
            response.use { r ->
                val body = r.body?.string().orEmpty()
                val json = try {
                    if (body.isNotBlank()) JSONObject(body) else null
                } catch (_: org.json.JSONException) {
                    null
                }
                r.code to json
            }
        }
    }

    /**
     * Two bytes of the real stream, and what the server said about them.
     *
     * This exists because of a class of failure that is invisible from the API layer: the catalogue
     * answers, the parse succeeds, a URL comes out - and the GET of that URL is refused. From
     * inside the app that looks exactly like a track that "just skips". A one-byte ranged request
     * with the right agent settles it in 200 ms and reports the code, which is the difference
     * between guessing and knowing.
     *
     * Never used on the playback path. It is a diagnostic, called only from settings.
     */
    suspend fun probeStream(
        url: String,
        userAgent: String?,
        headers: Map<String, String> = emptyMap()
    ): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", userAgent ?: USER_AGENT)
            .header("Range", "bytes=0-1")
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .build()
        try {
            client.newCall(request).execute().use { r ->
                val type = r.header("Content-Type") ?: "?"
                val length = r.header("Content-Range") ?: r.header("Content-Length") ?: "?"
                if (r.isSuccessful) "HTTP ${r.code} · $type · $length"
                else "HTTP ${r.code} · отказ · $type"
            }
        } catch (e: IOException) {
            "нет ответа: ${e.javaClass.simpleName}"
        }
    }

    /**
     * The same two bytes as [probeStream], but as a bare HTTP code, and ON the playback path.
     *
     * This is what turns "resolve succeeded" into "the CDN will actually serve this": the catalogue
     * calls it before handing a URL back, and a refusal makes it try the next internal client
     * instead of handing the player a dead address to auto-skip over. Its own timeouts, short ones -
     * a probe that hangs for twenty seconds would be worse than no probe at all, because the user is
     * staring at a track that is supposedly starting.
     *
     * Returns null when there was no answer at all, which the caller treats exactly like a refusal.
     */
    private val probeClient: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()
    }

    suspend fun statusOf(url: String, userAgent: String?): Int? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", userAgent ?: USER_AGENT)
            .header("Range", "bytes=0-1")
            .build()
        try {
            probeClient.newCall(request).execute().use { r -> r.code }
        } catch (e: IOException) {
            null
        }
    }

    /**
     * Cover bytes. Blocking on purpose: the only caller is the artwork pipeline, which is already
     * on a gated IO dispatcher and already owns a permit, and handing it a suspending call would
     * mean a second dispatch per tile.
     */
    fun fetchBytes(url: String, limitBytes: Int = 1_500_000): ByteArray? {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", USER_AGENT)
            // 6.24.3. Обложка — единственный запрос в приложении, который можно не сделать.
            // Метка снимается в SessionHeadersInterceptor и в сеть не уходит; она нужна, чтобы
            // ожидание токена сессии для обложки было секундой, а не двенадцатью.
            .header(SessionRequestPolicy.deferrableHeader, "1")
            .build()
        return try {
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return null
                val body = r.body ?: return null
                if ((r.header("Content-Length")?.toLongOrNull() ?: 0L) > limitBytes) return null
                // Read by hand rather than with InputStream.readNBytes: that method is API 33,
                // this app supports API 26, and the lint for it is not enforced on a call inside
                // a runCatching-style block - it would have shipped and crashed on half the
                // install base.
                val out = java.io.ByteArrayOutputStream(64 * 1024)
                val buffer = ByteArray(16 * 1024)
                body.byteStream().use { input ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        if (out.size() > limitBytes) return null
                    }
                }
                out.toByteArray()
            }
        } catch (e: IOException) {
            null
        }
    }

    /**
     * Turns transport reality into [CatalogException].
     *
     * Every branch here exists because the UI has to do something different: 429 must back off,
     * 403/404 on a single track must skip it, a DNS failure must not be reported as "провайдер
     * сломался", and a 200 that is not JSON means the shape changed and that is our bug.
     */
    private suspend fun execute(call: Call, url: String): JSONObject =
        executeParsed(call) { response -> parseResponse(response, url) }

    /** Status-preserving resolver calls and ordinary JSON use the same cancellation bridge. */
    private suspend fun <T> executeParsed(call: Call, parse: (Response) -> T): T = suspendCancellableCoroutine { continuation ->
        // Cancelling a coroutine around blocking execute() did not cancel the socket: each
        // keystroke could leave another 20-second request behind. Cancel the actual OkHttp Call.
        val span = when (call.request().url.encodedPath) {
            "/match/deezer" -> StartupTrace.begin(StartupTrace.Stage.MATCH)
            "/resolve" -> StartupTrace.begin(StartupTrace.Stage.RESOLVE)
            else -> null
        }
        continuation.invokeOnCancellation {
            StartupTrace.finish(span, StartupTrace.Outcome.CANCELLED)
            call.cancel()
        }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                StartupTrace.finish(span, StartupTrace.Outcome.ERROR)
                val message = when (e) {
                    is UnknownHostException -> "Нет соединения"
                    is SocketTimeoutException -> "Сервер не отвечает"
                    else -> "Сеть недоступна"
                }
                continuation.resumeWith(Result.failure(CatalogException(CatalogException.Reason.OFFLINE, message, e)))
            }

            override fun onResponse(call: Call, response: Response) {
                if (!continuation.isActive) { response.close(); return }
                // Parsing and body reading stay on the OkHttp worker, never on the UI thread.
                val result = try { Result.success(parse(response)) }
                catch (e: IOException) {
                    Result.failure<T>(CatalogException(CatalogException.Reason.OFFLINE, "Обрыв ответа", e))
                }
                catch (e: Exception) { Result.failure<T>(e) }
                StartupTrace.finish(span, if (result.isSuccess && response.isSuccessful)
                    StartupTrace.Outcome.OK else StartupTrace.Outcome.ERROR)
                continuation.resumeWith(result)
            }
        })
    }

    private fun parseResponse(response: Response, url: String): JSONObject {
        response.use { r ->
            val code = r.code
            if (code == 429) throw CatalogException(CatalogException.Reason.RATE_LIMITED, "Слишком много запросов")
            if (code == 403 || code == 404 || code == 410) {
                throw CatalogException(CatalogException.Reason.UNAVAILABLE, "Недоступно ($code)")
            }
            if (!r.isSuccessful) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "HTTP $code от ${host(url)}")
            }
            val text = try {
                r.body?.string()
            } catch (e: IOException) {
                throw CatalogException(CatalogException.Reason.OFFLINE, "Обрыв ответа", e)
            }
            if (text.isNullOrBlank()) {
                throw CatalogException(CatalogException.Reason.PROTOCOL, "Пустой ответ от ${host(url)}")
            }
            return try {
                JSONObject(text)
            } catch (e: Exception) {
                throw CatalogException(
                    CatalogException.Reason.PROTOCOL,
                    "Ответ ${host(url)} не JSON (${text.length} байт)",
                    e
                )
            }
        }
    }

    private fun host(url: String): String = runCatching { java.net.URL(url).host }.getOrDefault(url)
}
