# ZiziPlayer — Android 6.46.1

Нативный Android-плеер: Kotlin, Compose, Media3, Room/DataStore, локальная музыка, сетевой каталог и офлайн-файлы.

**Исходники с исправлением ошибки компиляции 6.46.0; versionCode 95. Не готовый APK и не подтверждённая Android-сборка.** В LyricsScreen ширина BoxWithConstraints захватывается до вложенного Column. Устранены пять неявных обращений к скрытому layout receiver; формулы и поведение плеера не изменены.

Отчёт: `RELEASE_v6.46.1.md`. Свежие результаты: `verification/v6.46.1/`. Предыдущие документы и логи оставлены как история, а не доказательство проверки новой версии.

## Обновить публичный репозиторий

Загрузить **ZiziPlayer-v6.46.1.zip** в корень Eren2932/ZiziPlayer, в ветку main. Распаковывать его в корень репозитория не нужно. Архив 6.46.0 можно оставить: существующий workflow выбирает максимальный versionCode, теперь 95 вместо 94. Не добавлять второй проектный архив с кодом 95. Desktop, current.json, workflow и секреты менять не требуется.

Дождаться успешного Actions для нового коммита: компиляция Kotlin/JVM-тесты, затем assembleRelease. После этого скачать APK из артефакта ZiziPlayer-APK-v6.46.1 и проверить на телефоне. Для установки поверх прежнего приложения необходим тот же ключ подписи; удалять приложение и его данные ради установки не следует.

## Что проверено

В the Computer завершились с кодом 0 все 52 команды в `verification/v6.46.1/results.json`: статические проверки исходников, исполняемые Java-ядра и офлайн-регрессии сервера. Часть наборов также вызывается внутри check_selftest: это 52 команды, не 52 независимых Android-теста. Новая узкая проверка обнаруживает исходную ошибку 6.46.0 и возврат каждого из пяти проблемных обращений.

Gradle, компиляция Kotlin/Compose, Android APK, устройство и живые сетевые провайдеры здесь не запускались. В the Computer нет Gradle/Kotlin compiler/Android SDK. Java-ядра проверены установленным JDK 21 с source/target 17; CI использует JDK 17.

````bash
python tools/check_selftest.py
python tools/check_kotlin_syntax.py app/src
python tools/check_imports.py app/src/main
python tools/check_static_refs.py app/src/main
python tools/check_call_args.py app/src/main
# В подготовленном Android-окружении (SDK 36, Gradle 8.11.1, JDK 17):
gradle --no-daemon :app:testDebugUnitTest :app:assembleRelease --stacktrace
````

Как и в исходной базе, готовых gradlew/wrapper JAR нет; CI устанавливает Gradle отдельно. Зависимости не менялись. Для функциональной проверки изменений 6.46.0 остаётся актуален `DEVICE_CHECKLIST_v6.46.0.md`; проверки исправления описаны в новом отчёте.
