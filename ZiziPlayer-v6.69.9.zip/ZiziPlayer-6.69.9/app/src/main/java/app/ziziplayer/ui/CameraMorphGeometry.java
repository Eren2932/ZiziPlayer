package app.ziziplayer.ui;

/** 6.69.9. Pure pixel geometry and scroll-driven material; no Android, animation clock, device-name table or I/O. */
public final class CameraMorphGeometry {
    private CameraMorphGeometry() {}

    public static final class Target {
        public final float left, top, right, bottom;
        public Target(float left, float top, float right, float bottom) {
            this.left = left; this.top = top; this.right = right; this.bottom = bottom;
        }
        public float width() { return right - left; }
        public float height() { return bottom - top; }
        public float cx() { return (left + right) * .5f; }
        public float cy() { return (top + bottom) * .5f; }
    }

    /** Conservative admission, not a claim that an OEM bounding rect is the physical hole. */
    public static boolean supported(Target t, float width, float height, float status, float density,
            boolean exactPath) {
        if (t == null || !finite(t.left, t.top, t.right, t.bottom, width, height, status, density)
                || width <= 0 || height <= width || status <= 0 || density <= 0) return false;
        float w = t.width(), h = t.height();
        if (t.left < 0 || t.top <= 0 || t.right > width || t.bottom > status + 8 * density
                || t.top >= status || w < 4 * density || h < 4 * density
                || w > Math.min(width * .28f, 104 * density) || h > 64 * density) return false;
        float aspect = w / h;
        // A wide notch / waterfall / top-to-hole safe-inset rectangle is NOT a round camera.
        return exactPath ? aspect >= .65f && aspect <= 3f
                : t.top > 0 && aspect >= .8f && aspect <= 1.25f && w <= 48 * density;
    }

    /** Some OEMs report the reserved strip from the display edge to a punch hole,
     * not the physical circle. Estimate ONLY from a narrow, top-attached system rect.
     * Its width becomes the diameter; its bottom fixes the bottom of the estimate.
     * Never use status-bar height as diameter, screen center, or a device-name table.
     * This is explicitly approximate: Android's reserved bounds are not a calibration.
     */
    public static Target compactTopEstimate(Target bounds, float width, float height,
            float status, float density) {
        if (bounds == null || !finite(bounds.left, bounds.top, bounds.right, bounds.bottom,
                width, height, status, density) || density <= 0 || status <= 0
                || width <= 0 || height <= width) return null;
        float w = bounds.width(), h = bounds.height();
        if (bounds.left < 0 || bounds.right > width || bounds.top < 0 || bounds.top > 1f
                || w < 8*density || w > 32*density || w > width*.12f
                || h <= w || h > 3*w || bounds.bottom > status + 8*density) return null;
        Target estimate = new Target(bounds.left, bounds.bottom-w, bounds.right, bounds.bottom);
        return supported(estimate, width, height, status, density, false) ? estimate : null;
    }

    public static final class Frame {
        public final float cx, cy, width, height, radius, progress;
        public final float imageAlpha, topBlack, bottomBlack, anchorAlpha;
        Frame(float cx, float cy, float width, float height, float radius, float progress,
                float imageAlpha, float topBlack, float bottomBlack, float anchorAlpha) {
            this.cx = cx; this.cy = cy; this.width = width; this.height = height;
            this.radius = radius; this.progress = progress; this.imageAlpha = imageAlpha;
            this.topBlack = topBlack; this.bottomBlack = bottomBlack; this.anchorAlpha = anchorAlpha;
        }
        public float left() { return cx - width * .5f; }
        public float top() { return cy - height * .5f; }
    }

    public static float unit(float x) {
        return Float.isFinite(x) ? Math.max(0f, Math.min(1f, x)) : 0f;
    }
    public static float smooth(float x) { float t = unit(x); return t * t * (3f - 2f * t); }
    private static float positive(float x) { return Float.isFinite(x) ? Math.max(0f, x) : 0f; }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static boolean finite(float... xs) {
        for (float x : xs) if (!Float.isFinite(x)) return false;
        return true;
    }

    /** Monotone cubic Hermite: match the incoming scroll velocity, stop without overshoot.
     * velocity is pixels / scroll-pixel. Limiting the initial tangent to 3*delta is sufficient
     * for monotonicity when the outgoing tangent is zero.
     */
    public static float hermite(float start, float end, float velocity, float travel, float progress) {
        float t = unit(progress), delta = end - start;
        float tangent = velocity * positive(travel);
        if (tangent * delta <= 0) tangent = 0;
        else tangent = Math.copySign(Math.min(Math.abs(tangent), 3f * Math.abs(delta)), delta);
        float t2 = t * t, t3 = t2 * t;
        float value = (2*t3 - 3*t2 + 1)*start + (t3 - 2*t2 + t)*tangent + (-2*t3 + 3*t2)*end;
        return Math.max(Math.min(start, end), Math.min(Math.max(start, end), value));
    }

    /** Two existing scroll phases, one reversible picture. The first phase continues to consume
     * the exact same pixel range as 6.69.1; the second uses the list's real offset, not a timer.
     * During phase one d(size)/ds=-1 and d(centerY)/ds=-.5. Hermite preserves those derivatives
     * at the handoff for ordinary compact holes. No new nested scroller is introduced.
     */
    public static Frame frame(float maximum, float minimum, float fraction, float scroll,
            float centerX, float coverTop, float initialRadius, float travel, float fallbackY,
            Target target) {
        maximum = positive(maximum);
        minimum = Math.min(maximum, positive(minimum));
        scroll = positive(scroll);
        float f = scroll > 0 ? 1f : unit(fraction);
        float startSize = lerp(maximum, minimum, f);
        float p = unit(scroll / Math.max(1f, positive(travel)));
        float endW = target == null ? 0f : positive(target.width());
        float endH = target == null ? 0f : positive(target.height());
        float endX = target == null ? centerX : target.cx();
        float endY = target == null ? fallbackY : target.cy();
        float w = hermite(startSize, endW, -1f, travel, p);
        float h = hermite(startSize, endH, -1f, travel, p);
        // Finish lateral travel before entering the status bar; do not cut a diagonal
        // artwork through the clock/network area on corner-camera devices.
        float x = lerp(centerX, endX, smooth(target == null ? p : p / .75f));
        float y;
        if (target == null) {
            y = hermite(coverTop + startSize * .5f, endY, -.5f, travel, p);
        } else {
            // First shrink below the status bar, then enter the hole as a compact softened shape.
            // Both top segments have zero endpoint slope. This avoids a wide artwork cap being
            // chopped by the narrow status-bar safety corridor, especially on corner cameras.
            float stagingTop = Math.min(coverTop, fallbackY);
            float top = p <= .75f ? lerp(coverTop, stagingTop, smooth(p / .75f))
                    : lerp(stagingTop, target.top, smooth((p - .75f) / .25f));
            y = top + h * .5f;
        }
        float radius = lerp(Math.min(positive(initialRadius), startSize * .5f), startSize * .5f, smooth(f));
        radius = startSize > 0 ? radius * Math.min(w, h) / startSize : 0f;
        float alpha = 1f - smooth((p - (target == null ? .35f : .90f)) / (target == null ? .65f : .10f));
        return new Frame(x, y, w, h, radius, p, alpha,
                target == null ? 0f : smooth(p / .18f),
                target == null ? 0f : smoother((p - .78f) / .20f),
                // The system cutout is physical; its app-painted anchor is temporary.
                // Fade only in the final 10%, with C2 endpoints and exact zero at p=1.
                target == null ? 0f : smooth(p / .18f) * (1f - smoother((p - .90f) / .10f)));
    }

    /** C2 endpoints: blur and final absorption stop without a slope/acceleration step. */
    public static float smoother(float x) {
        float t = unit(x);
        return unit(t*t*t*(t*(t*6f-15f)+10f));
    }

    /** Radius in unscaled artwork coordinates / artwork side, not display-density pixels.
     * The parent scales the filtered image afterwards. No clock or direction-dependent state.
     */
    public static float blurFraction(float progress) {
        return .075f * smoother(unit(progress) / .65f);
    }

    /* ------------------------------------------------------------------------------------
     * 6.69.9 "symbiote" contact, shaped from measurements of the reference recording
     * Screenrecording_20260927_125830.mp4 (1080x2400, variable frame rate, estimated camera r = 18.5 px).
     * All distances are in camera radii U = min(target.w, target.h) / 2, so the picture is the
     * same on every density. rawU = gap / U, gap = distance between the camera's front edge and the
     * artwork's near edge along the camera->artwork axis. u is rawU admitted through a
     * C2 scroll gate for initially close OEM bounds. Pure function of geometry: forward
     * and reverse scroll give bit-identical shapes.
     *
     *   u >= 4.40  nothing; the camera is a plain dot
     *   4.40..3.07 the camera first leaks alone; the artwork responds later with a small tent.
     *              At contact the gap share is 57% camera / 43% artwork; NOT joined before it
     *   3.07       tips touch; the waist is born with zero width
     *   3.07..2.45 the waist widens with a C2 ramp up to the swollen camera width,
     *              black ink runs down the neck into the artwork's top edge
     * ------------------------------------------------------------------------------------ */
    public static final float GOO_ONSET = 4.40f, GOO_CONTACT = 3.07f, GOO_FULL = 2.45f;
    static final float CAMERA_SHARE = .57f;
    // Fraction of the gap already bridged by drop + tent (measured, frames 84..121).
    static final float[] REACH_U = {3.07f, 3.35f, 3.58f, 3.84f, 4.10f, 4.40f};
    static final float[] REACH_V = {1f,    .33f,  .20f,  .115f, .05f,  0f};
    // The noisy near-contact samples are deliberately regularized. Reproducing the
    // measured sqrt-like opening literally creates a rapid neck/ink step on corner
    // trajectories. Match the final width, with C2 zero-width birth instead.
    // Lateral camera swelling (a / U - 1), measured on the camera's centre row.
    static final float[] SWELL_U = {2.48f, 2.78f, 3.04f, 3.27f, 3.84f, 4.40f};
    static final float[] SWELL_V = {.30f,  .22f,  .19f,  .14f,  .10f,  0f};
    static final float APEX_INK_FROM = 3.60f, INK_FADE_BELOW_EDGE = .35f, INK_CAMERA_START = .62f;
    static final float KAPPA = .5522848f;

    /** Monotone (Fritsch-Carlson) interpolation; xs ascending. Flat outside the table,
     * zero slope at both ends, so nothing kinks where a phase starts or stops. */
    static float table(float[] xs, float[] ys, float x) {
        int n = xs.length;
        if (!Float.isFinite(x) || x <= xs[0]) return ys[0];
        if (x >= xs[n-1]) return ys[n-1];
        int k = 0;
        while (x > xs[k+1]) k++;
        float h = xs[k+1]-xs[k], t = (x-xs[k])/h;
        float m0 = slope(xs, ys, k), m1 = slope(xs, ys, k+1);
        float t2 = t*t, t3 = t2*t;
        float v = (2*t3-3*t2+1)*ys[k] + (t3-2*t2+t)*h*m0 + (-2*t3+3*t2)*ys[k+1] + (t3-t2)*h*m1;
        float lo = Math.min(ys[k], ys[k+1]), hi = Math.max(ys[k], ys[k+1]);
        return Math.max(lo, Math.min(hi, v));
    }
    private static float slope(float[] xs, float[] ys, int i) {
        int n = xs.length;
        if (i == 0 || i == n-1) return 0f;
        float d0 = (ys[i]-ys[i-1])/(xs[i]-xs[i-1]), d1 = (ys[i+1]-ys[i])/(xs[i+1]-xs[i]);
        if (d0*d1 <= 0) return 0f;
        return 3*(xs[i+1]-xs[i-1]) / ((2*xs[i+1]-xs[i]-xs[i-1])/d0 + (xs[i+1]+xs[i]-2*xs[i-1])/d1);
    }
    public static float reach(float u) { return table(REACH_U, REACH_V, u); }
    public static float waist(float u) { return 2.62f * smoother((GOO_CONTACT - u) / (GOO_CONTACT - GOO_FULL)); }
    public static float swell(float u) { return table(SWELL_U, SWELL_V, u); }

    /** Path in window pixels. ops: 0 move(x,y), 1 cubic(x1,y1,x2,y2,x,y), 2 close. */
    public static final class Goo {
        public final float u, gap;
        public final boolean joined;
        /** Black ink on the canvas below the artwork (camera blob, later the whole neck). */
        public final float[] ink;
        /** Extra region shown by the artwork layer (tent, later the neck); null = none. */
        public final float[] flesh;
        public final float originX, originY, axisX, axisY;
        public final float inkStart, inkEnd, inkAlpha;
        /** Corridor half-width the safety clip must allow around the camera, px. */
        public final float swellPx;
        Goo(float u, float gap, boolean joined, float[] ink, float[] flesh, float ox, float oy,
                float ax, float ay, float inkStart, float inkEnd, float inkAlpha, float swellPx) {
            this.u = u; this.gap = gap; this.joined = joined; this.ink = ink; this.flesh = flesh;
            originX = ox; originY = oy; axisX = ax; axisY = ay;
            this.inkStart = inkStart; this.inkEnd = inkEnd; this.inkAlpha = inkAlpha;
            this.swellPx = swellPx;
        }
        /** Contact ink opacity at a window point: inkAlpha up to inkStart, linear to 0 at inkEnd. */
        public float inkAt(float x, float y) {
            float s = (x-originX)*axisX + (y-originY)*axisY;
            if (inkEnd <= inkStart) return s <= inkStart ? inkAlpha : 0f;
            return inkAlpha * unit((inkEnd-s)/(inkEnd-inkStart));
        }
    }

    /** Local frame: s along camera->artwork axis from the camera centre, t lateral. */
    private static final class Pen {
        final double ox, oy, nx, ny; final float[] buf = new float[256]; int n;
        Pen(double ox, double oy, double nx, double ny) { this.ox=ox; this.oy=oy; this.nx=nx; this.ny=ny; }
        private void pt(double s, double t) {
            buf[n++] = (float)(ox + s*nx - t*ny); buf[n++] = (float)(oy + s*ny + t*nx);
        }
        void move(double s, double t) { buf[n++] = 0; pt(s, t); }
        void cubic(double s1, double t1, double s2, double t2, double s, double t) {
            buf[n++] = 1; pt(s1, t1); pt(s2, t2); pt(s, t);
        }
        void close() { buf[n++] = 2; }
        float[] done() { float[] out = new float[n]; System.arraycopy(buf, 0, out, 0, n); n = 0; return out; }
    }

    /** Arc of the artwork circle, angle th measured from -s toward -t; th0 < th1. */
    private static void arc(Pen p, double cs, double r, double th0, double th1) {
        int parts = (int)Math.ceil((th1-th0)/(Math.PI/2) - 1e-9);
        double step = (th1-th0)/parts, h = 4.0/3.0*Math.tan(step/4)*r;
        for (int i = 0; i < parts; i++) {
            double a = th0+i*step, b = a+step;
            double s0 = cs - r*Math.cos(a), t0 = -r*Math.sin(a);
            double s1 = cs - r*Math.cos(b), t1 = -r*Math.sin(b);
            p.cubic(s0 + h*Math.sin(a), t0 - h*Math.cos(a), s1 - h*Math.sin(b), t1 + h*Math.cos(b), s1, t1);
        }
    }

    /** Exact cubic subdivision; the shared point and tangent agree on both halves. */
    private static double[][] split(double[] p, double t) {
        double[] a = new double[6], b = new double[4], q = new double[2];
        for (int i=0;i<6;i++) a[i] = p[i] + (p[i+2]-p[i])*t;
        for (int i=0;i<4;i++) b[i] = a[i] + (a[i+2]-a[i])*t;
        for (int i=0;i<2;i++) q[i] = b[i] + (b[i+2]-b[i])*t;
        return new double[][]{{p[0],p[1],a[0],a[1],b[0],b[1],q[0],q[1]},
            {q[0],q[1],b[2],b[3],a[4],a[5],p[6],p[7]}};
    }
    private static void curve(Pen p, double[] c, boolean mirrorReverse) {
        if (mirrorReverse) p.cubic(c[4],-c[5],c[2],-c[3],c[0],-c[1]);
        else p.cubic(c[2],c[3],c[4],c[5],c[6],c[7]);
    }

    public static Goo goo(Target target, Frame f) {
        if (target == null || f == null || f.progress <= .12f || f.progress >= 1
                || !finite(target.left, target.top, target.right, target.bottom,
                    f.cx, f.cy, f.width, f.height, f.progress)) return null;
        float U = Math.min(target.width(), target.height()) * .5f;
        float r2 = Math.min(f.width, f.height) * .5f;
        double dx = f.cx - target.cx(), dy = f.cy - target.cy(), d = Math.hypot(dx, dy);
        if (!(U > .1f) || !(r2 > .1f) || !Double.isFinite(d) || d < 1e-3) return null;
        double nx = dx/d, ny = dy/d;
        // Camera half extents along/against the axis (ellipse support of the target box).
        double hn = Math.hypot(nx*target.width()*.5, ny*target.height()*.5);
        double am = Math.hypot(ny*target.width()*.5, nx*target.height()*.5);
        double gap = d - hn - r2;
        float rawU = (float)(gap / U);
        if (rawU >= GOO_ONSET) return null;
        // A large OEM reservation can already be closer than CONTACT at scroll handoff.
        // Ramp its effective proximity from ONSET, otherwise a complete neck appears in
        // the very first frame. Spatial gating + C2 scroll ramp; no clock or history.
        float u = lerp(GOO_ONSET, rawU, smoother((f.progress - .12f) / .43f));
        if (u >= GOO_ONSET) return null;
        // Swelling relaxes while the artwork itself enters the hole (end of the absorption).
        double inside = smooth((float)((d - Math.abs(hn - r2)) / hn));
        double a = am + swell(u) * U * inside;
        Pen pen = new Pen(target.cx(), target.cy(), nx, ny);
        double k = KAPPA;
        float coverEdge = (float)(d - r2);
        float inkEnd = coverEdge + INK_FADE_BELOW_EDGE * U;
        float swellPx = (float)(a - am);
        if (u > GOO_CONTACT) {
            // Two separate bodies: camera drop and artwork tent.
            double reach = reach(u) * gap;
            double cameraShare = lerp(1f, CAMERA_SHARE,
                smoother((GOO_ONSET - u - .20f) / (GOO_ONSET - GOO_CONTACT - .20f)));
            double b = hn + cameraShare * reach;             // drop tip, from camera centre
            double apex = d - r2 - (1 - cameraShare) * reach;
            pen.move(0, -a);
            pen.cubic(k*b, -a, b, -k*a, b, 0);
            pen.cubic(b, k*a, k*b, a, 0, a);
            pen.cubic(-k*hn, a, -hn, k*a, -hn, 0);
            pen.cubic(-hn, -k*a, -k*hn, -a, 0, -a);
            pen.close();
            float[] ink = pen.done();
            float[] flesh = null;
            double tent = d - r2 - apex;
            if (tent > 1e-3) {
                double th = Math.min(Math.PI * .5, 2.3 * Math.acos(Math.max(-1, Math.min(1, r2 / (r2 + tent)))));
                double qs = d - r2*Math.cos(th), qt = r2*Math.sin(th);
                double len = Math.hypot(qs - apex, qt);
                double h3 = Math.min(.20*len, U), h4 = .30*len;
                pen.move(apex, 0);
                pen.cubic(apex, -h3, qs - h4*Math.sin(th), -qt + h4*Math.cos(th), qs, -qt);
                pen.cubic(qs, -qt/3, qs, qt/3, qs, qt);          // chord, inside the artwork
                pen.cubic(qs - h4*Math.sin(th), qt - h4*Math.cos(th), apex, h3, apex, 0);
                pen.close();
                flesh = pen.done();
            }
            float apexInk = (float)Math.pow(unit((APEX_INK_FROM - u) / (APEX_INK_FROM - GOO_CONTACT)), 2.2);
            return new Goo(u, (float)gap, false, ink, flesh, target.cx(), target.cy(),
                    (float)nx, (float)ny, (float)apex, inkEnd, apexInk, swellPx);
        }
        // Joined: one outline, camera -> waist -> artwork.
        double w = Math.min(waist(u) * U, Math.min(2*a, 2*r2*.92));
        double sw = hn + CAMERA_SHARE * gap;
        double eps = .05 * U;
        sw = Math.max(.1*hn, sw);
        double half = w * .5;
        double psi = Math.PI * .5 * smooth((float)(w / (.5 * U)));
        double sin = Math.sin(psi), cos = Math.cos(psi);
        // Artwork contact angle: tangent from the waist point, never narrower than the waist.
        double vs = sw - d, vt = -half, D = Math.hypot(vs, vt);
        double th = D > r2*1.0001 ? Math.atan2(-vt, -vs) + Math.acos(r2 / D) : 0;
        th *= 2.3;
        th = Math.max(th, Math.asin(Math.min(1, (half + .5*U) / r2)));
        th = Math.min(th, Math.PI * .5);
        double qs = d - r2*Math.cos(th), qt = r2*Math.sin(th);
        if (qs < sw + eps) sw = Math.max(eps, qs - eps);
        if (sw <= eps || qs <= sw) {
            // Artwork engulfs the camera: nothing left to bridge.
            return new Goo(u, (float)gap, true, null, null, target.cx(), target.cy(),
                    (float)nx, (float)ny, inkEnd - .8f * U, inkEnd, 1f, swellPx);
        }
        double h1 = k*sw;
        double h2 = (1-sin)*k*Math.max(a - half, 0) + sin*.5*k*sw;
        double len = Math.hypot(qs - sw, qt - half);
        double h3 = (1-sin)*Math.min(.20*len, U) + sin*.45*(qs - sw);
        double h4 = .30*len;
        // Round the nascent waist locally. The two old cubic segments met at an
        // angle until psi reached PI/2. Trim them with de Casteljau, then join their
        // exact tangents; the rounding region itself shrinks to zero at first touch.
        double trim = .20 * smoother((float)(w / (.5 * U)));
        double[][] cameraSide = split(new double[]{0,-a, h1,-a,
            sw-h2*sin,-half-h2*cos, sw,-half}, 1-trim);
        double[][] artworkSide = split(new double[]{sw,-half,
            sw+h3*sin,-half-h3*cos, qs-h4*Math.sin(th),-qt+h4*Math.cos(th), qs,-qt}, trim);
        double[] join = {cameraSide[0][6],cameraSide[0][7], cameraSide[1][2],cameraSide[1][3],
            artworkSide[0][4],artworkSide[0][5], artworkSide[0][6],artworkSide[0][7]};
        pen.move(0, -a);
        curve(pen, cameraSide[0], false);
        curve(pen, join, false);
        curve(pen, artworkSide[1], false);
        arc(pen, d, r2, th, 2*Math.PI - th);
        curve(pen, artworkSide[1], true);
        curve(pen, join, true);
        curve(pen, cameraSide[0], true);
        pen.cubic(-k*hn, a, -hn, k*a, -hn, 0);
        pen.cubic(-hn, -k*a, -k*hn, -a, 0, -a);
        pen.close();
        float[] path = pen.done();
        // Ink: black down to inkStart, which climbs from the waist to inside the camera
        // as the neck opens (reference: gradient starts ~0.6 U below the camera centre).
        double open = smoother((GOO_CONTACT - u) / (GOO_CONTACT - GOO_FULL));
        // Keep a nonzero gradient span during overlap: allowing end <= start
        // turns a spatial blend into a step and flashes on slow reverse scroll.
        float inkStart = Math.min((float)(sw + (INK_CAMERA_START*hn - sw) * open), inkEnd - .8f * U);
        return new Goo(u, (float)gap, true, path, path, target.cx(), target.cy(),
                (float)nx, (float)ny, inkStart, inkEnd, 1f, swellPx);
    }

    /** Uniform body darkening stays reserved for the final absorption (6.69.6 policy):
     * a white artwork body must not turn grey while it is merely touching the neck. */
    public static float bodyBlack(Frame f) { return f == null ? 0f : f.bottomBlack; }

    /** Maximum corridor widening the safety clip needs for the swollen camera, px. */
    public static float maxSwellPx(Target target) {
        return target == null ? 0f : SWELL_V[0] * Math.min(target.width(), target.height()) * .5f;
    }
}
