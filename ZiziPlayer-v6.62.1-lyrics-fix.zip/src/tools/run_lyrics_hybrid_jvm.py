#!/usr/bin/env python3
"""Optional isolated JVM harness, NOT Gradle/Android/Kotlin-2.1 compilation.

Uses production LyricsHybridLookup/OvhLyricsProvider and all 21 JUnit tests.
Android-only TrackEntity is replaced by a five-field data fixture. Exception class
DEFINITIONS are extracted from the real repository; networking/cache/UI are not
executed. Compiler 1.6.21 + compile-only coroutines 1.6.4; EXECUTION uses project's
stdlib 2.1.0, coroutines 1.9.0, OkHttp 4.12.0 and real org.json/JUnit.

No downloads here. Supply the pinned JARs via --deps; dependency names and hashes
from the actual run are saved in environment.json. --repeat runs each mode N times.
The authoritative integration gate remains :app:testDebugUnitTest in Android CI.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT/'app/src/main/java/app/ziziplayer/lyrics'
TEST = ROOT/'app/src/test/java/app/ziziplayer/lyrics'
COMPILER = ['kotlin-compiler-embeddable-1.6.21.jar', 'kotlin-stdlib-1.6.21.jar',
            'kotlin-reflect-1.6.21.jar', 'trove4j-1.0.20200330.jar', 'annotations-13.0.jar']
COMMON = ['okhttp-4.12.0.jar', 'okio-jvm-3.6.0.jar', 'json-20240303.jar',
          'junit-4.13.2.jar', 'hamcrest-core-1.3.jar', 'annotations-13.0.jar']
COMPILE = COMMON + ['kotlin-stdlib-1.6.21.jar', 'kotlinx-coroutines-core-jvm-1.6.4.jar']
RUNTIME = COMMON + ['kotlin-stdlib-2.1.0.jar', 'kotlinx-coroutines-core-jvm-1.9.0.jar']


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--deps', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--repeat', type=int, default=1)
    args = ap.parse_args()
    if not 1 <= args.repeat <= 100:
        ap.error('--repeat must be in 1..100')
    args.deps = args.deps.resolve()
    args.out.mkdir(parents=True, exist_ok=True)
    deps = sorted(set(COMPILER + COMPILE + RUNTIME))
    for name in deps:
        if not (args.deps/name).is_file():
            ap.error('Missing JAR: ' + name)
    env = {'scope': 'isolated JVM; not Android/Gradle; compile-time Kotlin differs from project',
           'java': subprocess.run(['java', '--version'], capture_output=True, text=True, check=True).stdout,
           'compiler': '1.6.21', 'compile_coroutines': '1.6.4',
           'runtime_stdlib': '2.1.0', 'runtime_coroutines': '1.9.0',
           'dependency_sha256': {n: hashlib.sha256((args.deps/n).read_bytes()).hexdigest() for n in deps}}
    (args.out/'environment.json').write_text(json.dumps(env, indent=2) + '\n')
    def cp(names):
        return ':'.join(str(args.deps/n) for n in names)
    def run(cmd, name):
        result = subprocess.run(cmd, capture_output=True, text=True)
        (args.out/name).write_text('COMMAND: ' + ' '.join(cmd) + '\n' + result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout + result.stderr)
            raise SystemExit(result.returncode)
        return result.stdout
    with tempfile.TemporaryDirectory(prefix='lyrics-jvm-') as work:
        work = Path(work)
        classes = work/'classes'
        classes.mkdir()
        repo = (MAIN/'LyricsRepository.kt').read_text()
        errors = '\n'.join(l for l in repo.splitlines() if l.startswith('    internal class '))
        if len(re.findall(r'internal class (?:AudioBusy|DeferredLyrics|NoLyrics|HttpFailure)\b', errors)) != 4:
            raise SystemExit('Exception layout changed; review harness extraction')
        (work/'LyricsRepository.kt').write_text('package app.ziziplayer.lyrics\nimport java.io.IOException\nclass LyricsRepository {\n' + errors + '\n}\n')
        (work/'TrackEntity.kt').write_text('package app.ziziplayer.data\ndata class TrackEntity(val id: String, val uri: String, val title: String, val artist: String, val durationMs: Long)\n')
        run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', str(classes),
             *[str(MAIN/(n+'.java')) for n in ['LrcTimeline', 'LyricsFallbackText', 'LyricsLookupTrace']]], 'compile-java.log')
        tests = sorted(TEST.glob('LyricsHybrid*Test.kt'))
        sources = [work/'LyricsRepository.kt', work/'TrackEntity.kt', MAIN/'LyricsHybridLookup.kt', MAIN/'OvhLyricsProvider.kt', *tests]
        env['production_and_test_sha256'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources if p.is_relative_to(ROOT)}
        (args.out/'environment.json').write_text(json.dumps(env, indent=2) + '\n')
        run(['java', '-cp', cp(COMPILER), 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
             '-no-stdlib', '-no-reflect', '-Xskip-metadata-version-check', '-jvm-target', '17',
             '-classpath', cp(COMPILE)+':'+str(classes), '-d', str(classes), *map(str, sources)], 'compile-kotlin.log')
        summary = []
        for mode in ['on', 'off']:
            for index in range(args.repeat):
                out = run(['java', '-ea', '-Dkotlinx.coroutines.debug='+mode,
                           '-Dkotlinx.coroutines.stacktrace.recovery=true', '-cp', cp(RUNTIME)+':'+str(classes),
                           'org.junit.runner.JUnitCore', *['app.ziziplayer.lyrics.'+p.stem for p in tests]],
                          f'junit-debug-{mode}-{index+1:02d}.log')
                matched = re.search(r'OK \((\d+) tests\)', out)
                if not matched or int(matched[1]) != 21:
                    raise SystemExit('Unexpected JUnit test count; review harness')
                summary.append({'debug': mode, 'run': index+1, 'tests': int(matched[1]), 'failures': 0})
        (args.out/'results.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(f'PASS: 21 distinct tests x {args.repeat} repeats x 2 debug modes. Not an APK/Gradle build.')


if __name__ == '__main__':
    main()
