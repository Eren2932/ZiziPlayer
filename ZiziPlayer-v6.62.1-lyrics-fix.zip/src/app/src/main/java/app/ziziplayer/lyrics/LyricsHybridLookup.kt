package app.ziziplayer.lyrics

import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/** Provider boundaries: a null result is an actual miss, an exception is NOT a miss. */
internal interface LyricsProvider {
    val id: String
    val budgetMs: Long
    val requestLimit: Int get() = 1
    suspend fun lookup(track: TrackEntity, http: suspend (Request) -> String,
        trace: LyricsLookupTrace?): JSONObject?
}

/** Sequential, bounded fallback. Never shares resolver credentials or downloads audio.
 * The first provider can supply checked LRC/plain/instrumental; the second only plain text.
 * Adding another provider requires revisiting precedence and the 45-second UI deadline.
 */
internal class LyricsHybridLookup(
    private val providers: List<LyricsProvider>,
    private val clockMs: () -> Long
) {
    private val lock = Mutex()
    private val backoffUntil = mutableMapOf<String, Long>()
    private data class Completed(val payload: JSONObject?)

    init {
        require(providers.isNotEmpty() && providers.map { it.id }.distinct().size == providers.size)
        require(providers.all { it.budgetMs > 0 && it.requestLimit in 1..3 } && providers.sumOf { it.budgetMs } <= 34_000L)
    }

    suspend fun lookup(track: TrackEntity, transport: suspend (LyricsProvider, Request) -> String,
        trace: LyricsLookupTrace?): JSONObject {
        var firstFailure: Exception? = null
        for (provider in providers) {
            // Mutex/withTimeout fast paths need not suspend. Check cancellation explicitly
            // before a new provider, including when an adapter reports cancellation as I/O.
            currentCoroutineContext().ensureActive()
            val deadline = lock.withLock { backoffUntil[provider.id] ?: 0L }
            val now = clockMs()
            if (now < deadline) {
                trace?.add("${provider.id}: backoff; trying next source")
                if (firstFailure == null) firstFailure = LyricsRepository.DeferredLyrics(deadline - now)
                continue
            }
            try {
                trace?.add("${provider.id}: begin; budgetMs=${provider.budgetMs}")
                // A wrapper distinguishes a completed miss (null payload) from a timeout.
                // withTimeoutOrNull handles only OUR timeout; parent cancellation propagates.
                val completed = withTimeoutOrNull(provider.budgetMs) {
                    currentCoroutineContext().ensureActive()
                    var requests = 0
                    Completed(provider.lookup(track, { request ->
                        currentCoroutineContext().ensureActive()
                        if (++requests > provider.requestLimit) throw IOException("${provider.id}: лимит запросов")
                        try {
                            // Three LRCLIB requests fit inside its 26-second budget, so a slow
                            // search can fail without throwing away a previously found plain text.
                            withTimeoutOrNull(7_000L) { transport(provider, request) }
                                ?: throw IOException("${provider.id}: запрос занял слишком долго")
                        }
                        catch (e: CancellationException) { throw e }
                        catch (e: LyricsRepository.HttpFailure) {
                            if (e.status == 429) {
                                lock.withLock { backoffUntil[provider.id] = clockMs() + 60_000L }
                                trace?.add("${provider.id}: HTTP 429; backoffMs=60000")
                            }
                            throw e
                        }
                    }, trace))
                } ?: throw IOException("${provider.id}: превышено время поиска")
                currentCoroutineContext().ensureActive()
                val payload = completed.payload
                if (payload != null) {
                    trace?.add("${provider.id}: selected")
                    return payload
                }
                trace?.add("${provider.id}: not found")
            } catch (e: CancellationException) {
                throw e
            } catch (e: LyricsRepository.AudioBusy) {
                // Audio owns the network slot. Do not bypass this gate using another source.
                throw e
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                trace?.add("${provider.id}: ${e.javaClass.simpleName}; trying next source")
                if (firstFailure == null) firstFailure = if (e is IOException) e
                    else IOException("${provider.id}: некорректный ответ сервиса", e)
            }
        }
        // A 429, timeout, malformed response or network outage must never enter the miss cache.
        throw (firstFailure ?: LyricsRepository.NoLyrics(
            "В LRCLIB и lyrics.ovh текст не найден. Можно повторить поиск или импортировать LRC"))
    }
}
