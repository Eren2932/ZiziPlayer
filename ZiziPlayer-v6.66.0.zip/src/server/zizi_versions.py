"""Conservative title-version ranking; channel identity is never artist identity."""
import re
import unicodedata


def normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text or '').casefold().split())


# 6.66.0. Степени замедления и ускорения.
#
# Первопричина «играет не то, что выбрал»: список знал 'sped up', 'speed up' и 'nightcore',
# но НЕ знал 'super speed' и одиночное 'speed'. Для матчера «Montagem Alquimia (Super Speed)»
# была песней БЕЗ пометки версии, то есть неотличимой от оригинала, — и оригинал молча
# подставлялся вместо ускоренной версии. В фонке так подписана заметная часть выдачи.
#
# Степени пишутся по-разному в разных сценах (br/ru/en), поэтому написания сводятся к одному
# виду. Это нормализация написания, а не утверждение, что 'mega' и 'ultra' звучат одинаково:
# каждая степень остаётся отдельной пометкой.
_DEGREE = r'(?:ultra|super|mega|hiper|hyper|extreme|extra)'
_DEGREE_CANON = {'hyper': 'hiper', 'extra': 'extreme'}
DEGREES = ('ultra', 'super', 'mega', 'hiper', 'extreme')

_SLOWED = re.compile(rf'\b(?:({_DEGREE})[\s_+-]*)?slow(?:ed|ing)?\b')
_SPED_UP = re.compile(rf'\b(?:({_DEGREE})[\s_+-]*)?(?:sped|speed)[\s_-]*up\b')
_DEGREE_SPEED = re.compile(rf'\b({_DEGREE})[\s_+-]*speed\b')
_NIGHTCORE = re.compile(r'\bnightcore\b')
_QUALIFIER = re.compile(r'[\[(]([^\])]*)[\])]')
_BARE_SPEED = re.compile(r'\bspeed\b')

# Семейство — это направление изменения скорости. Степень внутри семейства это «насколько».
SLOWED, SPED_UP = 'slowed', 'sped_up'
SPEED_TAGS = frozenset(
    [SLOWED, SPED_UP] + [f'{d}_{base}' for d in DEGREES for base in (SLOWED, SPED_UP)]
)


def _canon(degree):
    return _DEGREE_CANON.get(degree, degree) if degree else ''


def _tag(degree, base):
    return f'{_canon(degree)}_{base}' if degree else base


def speed_family(tags):
    """Направление изменения скорости: {'slowed'}, {'sped_up'} или пустое множество.

    Смена семейства — это другая запись. Смена степени — та же запись в другой обработке.
    """
    families = set()
    for tag in tags:
        if tag == SLOWED or tag.endswith('_' + SLOWED):
            families.add(SLOWED)
        elif tag == SPED_UP or tag.endswith('_' + SPED_UP):
            families.add(SPED_UP)
    return families


def _degrees(tags, family):
    """Какие степени заявлены для семейства. Пустая строка — «просто slowed», без уточнения."""
    out = set()
    for tag in tags:
        if tag == family:
            out.add('')
        elif tag.endswith('_' + family):
            out.add(tag[:-len(family) - 1])
    return out


def speed_compatible(want, got):
    """Можно ли считать `got` той же записью по скорости, что и `want`.

    Семейство обязано совпасть точно: замедленная, ускоренная и оригинал — три разные записи.

    Внутри семейства действует одно послабление: неуточнённая степень («Slowed») совместима с
    уточнённой («Mega Slowed»), потому что «Slowed» — это общая подпись, под которой лежит в
    том числе и она. А вот две РАЗНЫЕ явные степени («Ultra» против «Super») несовместимы:
    это два конкурирующих утверждения о звуке, и выбрать между ними за человека нельзя.
    """
    if speed_family(want) != speed_family(got):
        return False
    for family in speed_family(want):
        mine, theirs = _degrees(want, family), _degrees(got, family)
        if mine == theirs:
            continue
        # Совместимы, только если хоть одна сторона не уточняла степень.
        if '' not in mine and '' not in theirs:
            return False
    return True


def version_tags(text):
    text = normalized(text)
    tags = set()
    slowed = _SLOWED.search(text)
    if slowed:
        tags.add(_tag(slowed.group(1), SLOWED))
    sped = _SPED_UP.search(text) or _DEGREE_SPEED.search(text)
    if sped:
        tags.add(_tag(sped.group(1), SPED_UP))
    elif _NIGHTCORE.search(text):
        tags.add(SPED_UP)
    elif any(_BARE_SPEED.search(part) for part in _QUALIFIER.findall(text)):
        # Одиночное 'speed' считается пометкой ТОЛЬКО внутри скобок: «(Speed)» — это версия,
        # а «Need For Speed» в названии песни — нет.
        tags.add(SPED_UP)
    for tag, pattern in [('reverb', r'\breverb\b'), ('remix', r'\b(?:remix|bootleg)\b'),
                         ('live', r'\b(?:live|concert)\b'), ('cover', r'\b(?:cover|karaoke)\b')]:
        if re.search(pattern, text):
            tags.add(tag)
    return tags


def strip_version_phrases(text):
    """Убирает ИМЕННО те слова, которые уже учтены пометками версии.

    Нужно для сравнения названий: слова «mega», «slowed», «speed up» не должны требоваться как
    слова НАЗВАНИЯ, иначе «Montagem Alquimia (Mega Slowed)» перестаёт совпадать с той же
    записью, подписанной «(Slowed)», — из-за слова «mega», а не из-за звука. Имя ремиксера
    при этом остаётся на месте: оно пометкой версии не является.
    """
    for pattern in (_SLOWED, _SPED_UP, _DEGREE_SPEED, _NIGHTCORE):
        text = pattern.sub(' ', text)
    return _QUALIFIER.sub(lambda m: ' ' if _BARE_SPEED.search(m.group(1)) else m.group(0), text)


def rank_tracks(items, query):
    want = version_tags(query)
    def key(item):
        got = version_tags(item['title'])
        # Семейство важнее степени: «ускоренная вместо замедленной» — грубая ошибка,
        # «ultra вместо mega» — та же обработка другой силы.
        return (speed_family(want) != speed_family(got),
                (want & SPEED_TAGS) != (got & SPEED_TAGS),
                len(want ^ got))
    # Stable sort: no fabricated duration reference or uploader popularity.
    result = []
    for item in sorted(items, key=key):
        got = version_tags(item['title'])
        result.append(dict(item, version_tags=sorted(got),
                           version_match='exact' if got == want else 'different'))
    return result
