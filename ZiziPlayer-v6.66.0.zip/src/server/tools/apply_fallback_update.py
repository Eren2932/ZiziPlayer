#!/usr/bin/env python3
"""Opt-in atomic replacement of the exact known base. Never restarts services."""
import argparse
import datetime
import hashlib
import os
from pathlib import Path
import stat
import tempfile

# Известные базы, поверх которых установка разрешена. Их две, и это не послабление защиты:
# сервер может стоять как на 1.11, так и на уже установленной 1.12, а отказ обновить рабочий
# сервер только потому, что он не отстал на две версии, — это не безопасность, а неудобство.
BASE_SHA256 = (
    '7a1783db8f7c0d29cae94b65c3e1de84be4c8f8841963bcd8755d0fd0896316c',  # 1.11-metadata-match, ZIP 6.48.1
    '4a7f0d05bcd3e75a8ec29c4a842a3b2eb0f7ceb373866461994a6c6d1c1d86b7',  # 1.12-fallback-match, ZIP 6.65.0
)
NEW_SHA256 = '78637061e3101961ecfd211456578b1b4f74a54a009bcec57d17bf3be1de0e57'  # 1.13-version-family, ZIP 6.66.0


def digest(content):
    return hashlib.sha256(content).hexdigest()


def known_base(current):
    """Совпадает ли развёрнутый файл с одной из проверенных баз.

    Строка тоже принимается: так этот же код остаётся пригодным для проверки против одной
    конкретной базы, не требуя от вызывающего знать, сколько их сейчас.
    """
    return current == BASE_SHA256 if isinstance(BASE_SHA256, str) else current in BASE_SHA256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, required=True, help='Existing deployed zizi_catalog.py')
    parser.add_argument('--apply', action='store_true', help='Write update; otherwise check only')
    args = parser.parse_args()
    target = args.target
    if target.is_symlink() or not target.is_file():
        parser.error('Target must be an existing regular file, not a symlink')
    payload = (Path(__file__).resolve().parents[1] / 'zizi_catalog.py').read_bytes()
    if digest(payload) != NEW_SHA256:
        parser.error('Update payload hash mismatch; stop and get the intact bundle')
    compile(payload, 'zizi_catalog.py', 'exec')  # syntax only, no import or network
    old = target.read_bytes()
    current = digest(old)
    if current == NEW_SHA256:
        print('Already updated; no files changed.')
        return
    if not known_base(current):
        parser.error('Unknown deployed version. Refusing to overwrite; compare with the patch manually.')
    if not args.apply:
        print('Known base verified. Dry run: no files changed. Add --apply to install with a backup.')
        return
    info = target.stat()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup = target.with_name(target.name + '.before-fallback-' + stamp)
    # Exclusive backup, never overwrite an earlier backup.
    with backup.open('xb') as stream:
        stream.write(old)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(backup, stat.S_IMODE(info.st_mode))
    if os.geteuid() == 0:
        os.chown(backup, info.st_uid, info.st_gid)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.zizi-catalog-', delete=False) as stream:
            temp = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, stat.S_IMODE(info.st_mode))
        if os.geteuid() == 0:
            os.chown(temp, info.st_uid, info.st_gid)
        # Проверка гонки: файл не должен был измениться между чтением и заменой.
        if digest(target.read_bytes()) != current:
            raise RuntimeError('Target changed during update; refusing replacement')
        os.replace(temp, target)
        temp = None
        print('Updated:', target)
        print('Backup:', backup)
        print('No service was restarted. Restart your resolver and check /catalog/health.')
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


if __name__ == '__main__': main()
