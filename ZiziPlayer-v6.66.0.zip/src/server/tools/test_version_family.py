#!/usr/bin/env python3
"""Регрессии 6.66.0: семейства версий, слова версии и мягкие приговоры резолвера.

Это проверки нашего кода на заглушках. Они НЕ доказывают, что конкретный трек найдётся
в реальной выдаче: это свойство источника, а не наших правил.
"""
import asyncio
from pathlib import Path
import sys
import time
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent), str(HERE / '_stub')]

import test_strict_match as base                      # общая обвязка каталога и фикстуры
import test_resolver_stage2 as stage2                 # уже поднятый резолвер с заглушками
from zizi_versions import version_tags, speed_family, speed_compatible, strip_version_phrases

c = base.c
resolver = stage2.resolver


class SpeedLabelTests(unittest.TestCase):
    """Разметка скорости. Все названия — из настоящей выдачи по «Montagem Alquimia»."""

    def test_super_speed_is_recognised_as_sped_up(self):
        # Главная первопричина подмены: раньше пометок не было вовсе, и трек выглядел
        # неотличимым от оригинала.
        self.assertEqual(version_tags('Montagem Alquimia (Super Speed)'), {'super_sped_up'})
        self.assertEqual(speed_family(version_tags('Montagem Alquimia (Super Speed)')), {'sped_up'})

    def test_bare_speed_counts_only_inside_brackets(self):
        self.assertEqual(version_tags('Montagem Alquimia (Speed)'), {'sped_up'})
        self.assertEqual(version_tags('Need For Speed'), set())

    def test_degrees_are_normalised_but_kept_distinct(self):
        self.assertEqual(version_tags('Track (Hyper Slowed)'), version_tags('Track (Hiper Slowed)'))
        self.assertNotEqual(version_tags('Track (Ultra Slowed)'), version_tags('Track (Super Slowed)'))

    def test_version_words_leave_the_title_but_names_stay(self):
        self.assertNotIn('mega', strip_version_phrases('montagem alquimia (mega slowed)'))
        self.assertIn('alice', strip_version_phrases('song (alice remix)'))


class CompatibilityTests(unittest.TestCase):
    def test_family_must_match_in_both_directions(self):
        for want, got in (('Song (Ultra Slowed)', 'Song'), ('Song', 'Song (Slowed)'),
                          ('Song (Super Speed)', 'Song'), ('Song (Slowed)', 'Song (Speed Up)')):
            self.assertFalse(speed_compatible(version_tags(want), version_tags(got)), (want, got))

    def test_unspecified_degree_is_compatible_both_ways(self):
        self.assertTrue(speed_compatible(version_tags('Song (Mega Slowed)'), version_tags('Song (Slowed)')))
        self.assertTrue(speed_compatible(version_tags('Song (Slowed)'), version_tags('Song (Mega Slowed)')))

    def test_two_explicit_degrees_never_substitute(self):
        self.assertFalse(speed_compatible(version_tags('Song (Ultra Slowed)'),
                                          version_tags('Song (Super Slowed)')))


class MontagemAlquimiaTests(base.StrictMatchTests):
    """Сквозной подбор на реальном примере: DJ Asul — Montagem Alquimia (Super Speed), 1:23."""

    QUERY, ARTIST, DUR = 'Montagem Alquimia (Super Speed)', 'DJ Asul', 83

    def test_original_is_not_served_instead_of_the_sped_up_version(self):
        with self.assertRaises(c.HTTPException) as ctx:
            self.match([base.candidate('DJ Asul - Montagem Alquimia', 'DJ Asul - Topic', 120)],
                       title=self.QUERY, artist=self.ARTIST, duration=self.DUR)
        self.assertEqual(ctx.exception.status_code, 404)

    def test_same_version_from_another_uploader_is_accepted(self):
        r = self.match([base.candidate('DJ Asul - Montagem Alquimia (Super Speed)', 'PhonkHub', 83)],
                       title=self.QUERY, artist=self.ARTIST, duration=self.DUR)
        self.assertTrue(r['strict'])

    def test_degree_words_no_longer_block_the_same_recording(self):
        # «Mega Slowed» против «Slowed»: раньше отказ приходил из-за слова «mega» в названии.
        r = self.match([base.candidate('DJ Asul - Montagem Alquimia (Slowed)', 'PhonkHub', 129)],
                       title='Montagem Alquimia (Mega Slowed)', artist=self.ARTIST, duration=129)
        self.assertTrue(r['fallback'])
        self.assertFalse(r['confident'])


class SoftVerdictTests(unittest.TestCase):
    """Отказ доступа — не доказательство удаления и не приговор на десять минут."""

    def setUp(self):
        resolver._cache.clear(); resolver._neg.clear(); resolver._locks.clear()

    def _oembed(self, status):
        class Client:
            async def get(self, *a, **kw): return types.SimpleNamespace(status_code=status)
        with patch.object(resolver, 'get_client', return_value=Client()), \
             patch.object(resolver, 'OEMBED_CHECK', True), \
             patch.object(resolver.httpx, 'Timeout', lambda *a, **kw: None, create=True):
            return asyncio.run(resolver._video_exists('abcdefghijk'))

    def test_access_refusal_is_unknown_not_deleted(self):
        for status in (400, 401, 403):
            self.assertIsNone(self._oembed(status), status)

    def test_only_404_means_gone_and_200_means_alive(self):
        self.assertIs(self._oembed(404), False)
        self.assertIs(self._oembed(200), True)

    def test_bot_check_is_cached_softly(self):
        async def refused(*a, **kw): return None, 403, 'Sign in to confirm you are not a bot'
        with patch.object(resolver, '_try_route', side_effect=refused), \
             patch.object(resolver, '_routes', return_value=[False]), \
             patch.object(resolver, '_throttled', return_value=False):
            with self.assertRaises(resolver.HTTPException):
                asyncio.run(resolver._resolve_locked('abcdefghijk', True))
        verdict = resolver._neg['abcdefghijk']
        self.assertTrue(verdict['soft'], 'бот-чек — состояние выхода, а не свойство записи')
        self.assertLessEqual(verdict['until'] - time.time(), resolver.NEG_TTL_SOFT + 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
