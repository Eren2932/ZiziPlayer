package app.ziziplayer.data.remote

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test

/** JVM coroutine tests; compile/run with :app:testDebugUnitTest, not the Python verifier. */
class ProgressivePreviewTest {
    private fun song(id: String) = RemoteItem.Song(RemoteTrack("dz", id, "Song $id", "Artist"))
    private fun merge(lanes: List<List<RemoteItem>>) = lanes.flatten()

    @Test fun fastLanePublishesBeforeSlowLaneCompletes() { runBlocking {
        val releaseSlow = CompletableDeferred<Unit>()
        val first = CompletableDeferred<List<RemoteItem>>()
        val snapshots = mutableListOf<List<RemoteItem>>()
        val collector = launch {
            progressivePreview(listOf(
                flow { emit(listOf(song("fast"))) },
                flow { releaseSlow.await(); emit(listOf(song("slow"))) }
            ), ::merge).collect { rows -> snapshots += rows; first.complete(rows) }
        }
        try {
            assertEquals(listOf(song("fast")), withTimeout(2000) { first.await() })
            assertFalse("Slow lane must still be waiting", collector.isCompleted)
            releaseSlow.complete(Unit)
            withTimeout(2000) { collector.join() }
            assertEquals(listOf(song("fast"), song("slow")), snapshots.last())
        } finally { collector.cancelAndJoin() }
    } }

    @Test fun failedPeerCannotEraseSuccessfulLane() { runBlocking {
        val failure: Flow<List<RemoteItem>> = flow {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Test failure")
        }
        val snapshots = withTimeout(2000) { progressivePreview(listOf(
            flow { emit(listOf(song("ok"))) }, failure
        ), ::merge).toList() }
        assertEquals(listOf(song("ok")), snapshots.last())
        assertTrue(snapshots.all { it.isNotEmpty() })
    } }

    @Test fun allFailedLanesRemainAnError() { runBlocking {
        val failure: Flow<List<RemoteItem>> = flow {
            throw CatalogException(CatalogException.Reason.OFFLINE, "Test failure")
        }
        try {
            withTimeout(2000) { progressivePreview(listOf(failure, failure), ::merge).toList() }
            fail("All-lane failure cannot be an empty success")
        } catch (error: CatalogException) { assertEquals(CatalogException.Reason.OFFLINE, error.reason) }
    } }

    @Test fun cancellingCollectorCancelsEveryProducer() { runBlocking {
        val started = List(2) { CompletableDeferred<Unit>() }
        val stopped = List(2) { CompletableDeferred<Unit>() }
        val sources = (0..1).map { index -> flow<List<RemoteItem>> {
            started[index].complete(Unit)
            try { awaitCancellation() } finally { stopped[index].complete(Unit) }
        } }
        val collector = launch { progressivePreview(sources, ::merge).collect { } }
        try { withTimeout(2000) { started.forEach { it.await() } } }
        finally { collector.cancelAndJoin() }
        assertTrue(stopped.all { it.isCompleted })
    } }

    @Test fun noSourcesProducesOneEmptySnapshot() { runBlocking {
        val snapshots = progressivePreview(emptyList(), ::merge).toList()
        assertEquals(1, snapshots.size)
        assertTrue(snapshots.single().isEmpty())
    } }
}
