#!/usr/bin/env python3
"""Production Java execution, extracted SQL, and wiring guards. NOT a Kotlin compiler."""
from pathlib import Path
import ast, re, sqlite3, subprocess, tempfile, unittest
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/app/ziziplayer'
def read(p):return (SRC/p).read_text()
class Collection6600(unittest.TestCase):
    def test_production_java_math(self):
        with tempfile.TemporaryDirectory() as out:
            files=[SRC/'ui/CollectionCollapseMath.java', SRC/'ui/CollectionGeometry.java',
                   SRC/'ui/ProfilePlaylistPolicy.java', SRC/'ui/theme/ArtworkColorMath.java',
                   ROOT/'app/src/test/java/app/ziziplayer/ui/Collection6600Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Collection6600Checks'],check=True)
    def test_image_and_tint_share_decoded_art(self):
        s=read('ui/components/CollectionCover.kt')
        for text in ['rememberUrlArtwork(url, 640)', 'rememberArtwork(track, 640, allowSlow = true)',
                     'art?.swatches?.primary', 'ArtworkColorMath.coverTop', 'CollectionCover(art, tint)',
                     'bitmap = art.image', 'Color(0xFF292929)']:self.assertIn(text,s)
        self.assertNotIn('currentTrack',s)
    def test_three_destinations_share_one_surface(self):
        for file in ['HomeCollectionScreen.kt','UnifiedLocalCollectionScreen.kt','RemoteCollectionScreen.kt']:
            s=read('ui/screens/'+file)
            for text in ['PinnedCollectionScaffold(', 'rememberCollectionCover(', 'CollectionCoverImage(']:self.assertIn(text,s)
            self.assertNotIn('LazyColumn(',s)
        self.assertIn('if (state.openArtist == null)',read('ui/screens/LocalCollectionScreen.kt'))
        s=read('ui/screens/CollectionPageScreen.kt')
        self.assertIn('if (!artist) {\n        RemoteCollectionScreen(',s)
    def test_scroll_distance_has_one_owner_and_no_timer(self):
        s=read('ui/screens/PinnedCollectionScaffold.kt')
        for text in ['nestedScroll(connection)', 'collapseState.consume(available.y, rangePx)',
                     'list.firstVisibleItemScrollOffset == 0', 'M.coverSize(', 'M.banner(',
                     'rememberSaveable(destination, saver = CollectionCollapseState.saver)',
                     'G.pinnedPlayTop(', 'G.minimumPinnedTail(', 'LocalBottomChromeInset.current + 24.dp']:
            self.assertIn(text,s)
        self.assertIn('ArtworkCache.markBusy()',s)
        self.assertIn('.coerceAtMost(MediaDimensions.trackRow)',s)
        self.assertEqual(s.count('LazyColumn('),1)
        self.assertEqual(s.count('else ZiziIcons.CollectionPlayFilled'),1)
        for bad in ['animateFloatAsState','animateDpAsState','GlobalScope']:
            self.assertNotIn(bad,s)
    def test_local_full_membership_cover_and_actions(self):
        s=read('ui/screens/UnifiedLocalCollectionScreen.kt')
        for text in ['state.playlistMeta[playlist.id]?.cover', 'url = playlist?.coverUri',
                     'state.collectionTracks.maxByOrNull', 'CollectionDownloadDialog(vm, state.collectionTracks',
                     'vm.startSelection(track.id)', 'vm.play(track, state.visible, destination)',
                     'playback.queueSourceId == destination', 'selectionHeader(56.dp)']:
            self.assertIn(text,s)
    def test_profile_selection_is_restorable_and_reversible(self):
        s=read('ui/screens/ProfilePlaylistsScreen.kt')
        for text in ['rememberSaveable(hiddenMode)', 'ProfilePlaylistPolicy.eligible',
                     'allSelected', 'hiddenMode = !hiddenMode', 'hidden = !hiddenMode',
                     'p.brand', 'Role.Checkbox', 'onCheckedChange = null', 'busy = true',
                     'catch (e: CancellationException)', 'finally { busy = false }']:
            self.assertIn(text,s)
        self.assertNotIn('deletePlaylist',s)
    def test_profile_filters_only_presentation(self):
        s=read('ui/screens/AccountScreen.kt')
        self.assertIn('playlists.filterNot { it.profileKey in hiddenPlaylists }',s)
        self.assertIn('items(visiblePlaylists',s)
        self.assertIn('onClick = onManagePlaylists',s)
        vm=read('ui/MainViewModel.kt')
        build=vm.split('return LibraryUiState(',1)[1].split('// ---------------- navigation')[0]
        self.assertIn('playlists = source.playlists',build)
        self.assertNotIn('profileHiddenPlaylists',build)
    def test_persistent_atomic_preferences_not_room_schema_change(self):
        s=read('data/SettingsStore.kt')
        self.assertIn('stringSetPreferencesKey("profile_hidden_playlists_v1")',s)
        self.assertIn('profileHiddenPlaylists = p[profileHiddenKey] ?: emptySet()',s)
        block=s.split('suspend fun setProfilePlaylistsHidden(',1)[1].split('suspend fun setAutoLyrics',1)[0]
        self.assertIn('context.dataStore.edit',block)
        self.assertIn('ProfilePlaylistPolicy.update(',block)
        self.assertNotIn('profileHidden',read('data/Entities.kt'))
    def test_confirmed_delete_checks_identity_in_transaction(self):
        s=read('data/MusicDao.kt')
        self.assertIn('@Transaction\n    suspend fun deletePlaylistIfCurrent',s)
        b=s.split('suspend fun deletePlaylistIfCurrent',1)[1].split('@Query',1)[0]
        self.assertLess(b.index('playlistById(id)?.createdAt != createdAt'),b.index('deletePlaylistFull(id)'))
        b=s.split('suspend fun deletePlaylistFull',1)[1].split('    @Query',1)[0]
        for text in ['unlinkPlaylist(id)','clearPlaylist(id)','deletePlaylist(id)']:self.assertIn(text,b)
        for bad in ['deleteTrack','deleteFile','removeDownload']:self.assertNotIn(bad,b)
    def test_actual_rename_query_rejects_reused_identity(self):
        s=read('data/MusicDao.kt')
        sql=re.search(r'@Query\("([^"\n]+)"\)\s+suspend fun renamePlaylistIfCurrent',s).group(1)
        db=sqlite3.connect(':memory:');self.addCleanup(db.close)
        db.execute('CREATE TABLE playlists(id INTEGER,createdAt INTEGER,name TEXT)')
        db.execute("INSERT INTO playlists VALUES(1,100,'Original')")
        self.assertEqual(db.execute(sql,dict(id=1,createdAt=99,name='Wrong')).rowcount,0)
        self.assertEqual(db.execute(sql,dict(id=1,createdAt=100,name='New')).rowcount,1)
        self.assertEqual(db.execute('SELECT name FROM playlists').fetchone()[0],'New')
    def test_copy_does_not_move_or_copy_into_self(self):
        s=read('data/MusicDao.kt').split('suspend fun copyPlaylistTracksIfCurrent',1)[1].split('/** Identity',1)[0]
        for text in ['source.id == target.id','playlistById(source.id)?.createdAt',
                     'playlistById(target.id)?.createdAt', 'ids.filter { it in current }']:
            self.assertIn(text,s)
        for bad in ['delete','removeTracks','moveTracks']:self.assertNotIn(bad,s)
    def test_real_menu_used_at_all_entrypoints(self):
        for file in ['LibraryScreen.kt','UnifiedLocalCollectionScreen.kt','ProfilePlaylistsScreen.kt']:
            self.assertIn('PlaylistActionsHost(',read('ui/screens/'+file))
        self.assertIn('PlaylistActionsHost(',read('MainActivity.kt'))
        s=read('ui/screens/PlaylistActionsHost.kt')
        for action in ['vm.play(', 'vm.copyPlaylistContents(', 'vm.renamePlaylistConfirmed(',
                       'vm.deletePlaylistConfirmed(', 'vm.setProfilePlaylistsHidden(',
                       'PlaylistShareSheet(', 'CollectionDownloadDialog(']:self.assertIn(action,s)
        for stage in ['share','rename','copy','delete']:
            self.assertNotIn('exit { stage = "'+stage+'" }',s) # exit calls parent onDismiss
        self.assertIn('enabled = !busy',s)
        self.assertIn('catch (e: CancellationException)',s)
    def test_new_regressions_are_in_existing_preflight(self):
        source=(ROOT/'tools/check_selftest.py').read_text()
        main=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        self.assertIn('test_collection_6600.py',ast.get_source_segment(source,main))
if __name__=='__main__':unittest.main(verbosity=2)
