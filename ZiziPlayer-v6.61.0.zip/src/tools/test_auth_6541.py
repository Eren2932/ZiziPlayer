"""Executed Java navigation + static Compose wiring; NOT Android compilation/rendering."""
from pathlib import Path
import subprocess
import tempfile
import unittest
import check_imports
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'

class Auth6541(unittest.TestCase):
    def test_production_navigation(self):
        with tempfile.TemporaryDirectory() as d:
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', d,
                str(S/'ui/screens/AuthHistory.java'),
                str(R/'app/src/test/java/app/ziziplayer/ui/screens/AuthHistoryChecks.java')], check=True)
            subprocess.run(['java', '-cp', d, 'app.ziziplayer.ui.screens.AuthHistoryChecks'], check=True)

    def test_missing_text_import_regression(self):
        body = 'fun Example() { Text("hello") }'
        self.assertTrue(check_imports.library_problems('fixture.kt', body, set(), set(), set(), set()))
        # Fully qualifying TextButton must NOT count as qualifying Text.
        text_button = body + '\nfun Other() { androidx.compose.material3.TextButton({}) {} }'
        self.assertTrue(check_imports.library_problems('fixture.kt', text_button, set(), set(), set(), set()))
        self.assertFalse(check_imports.library_problems('fixture.kt', body, {'Text'}, set(), set(), set()))
        self.assertFalse(check_imports.library_problems('fixture.kt', body, set(), {'androidx.compose.material3'}, set(), set()))
        self.assertIn('import androidx.compose.material3.Text\n', (S/'MainActivity.kt').read_text())

    def test_home_avatar_not_resolved_through_local_app(self):
        home = (S/'ui/screens/HomeScreen.kt').read_text()
        self.assertIn('import app.ziziplayer.ui.components.AccountAvatar\n', home)
        self.assertIn('AccountAvatar(account.userId', home)
        self.assertNotIn('app.ziziplayer.ui.components.AccountAvatar(', home)

    def test_back_is_history_transaction_with_synchronous_lock(self):
        ui = (S/'ui/screens/AccountAuthScreen.kt').read_text()
        for text in ('AuthHistory(initial)', 'BackHandler { back() }', 'history.back()',
                     'history.isMoving', 'history.settle(transition.currentState.revision)',
                     'navigationMoving = history.isMoving', 'targetState.backwards',
                     'shownRoute == route', 'transition.currentState == transition.targetState',
                     'if (drafts.values.any { it.dirty }) discard = true'):
            self.assertIn(text, ui)
        self.assertNotIn('page.parent', ui)
        self.assertNotIn('var backwards by', ui)
        main = (S/'MainActivity.kt').read_text()
        self.assertIn('interactive = authInteractive', main)
        host = (S/'ui/components/BookOverlayHost.kt').read_text()
        self.assertIn('open && progress.value == 1f && !progress.isRunning', host)

    def test_drafts_are_separate_and_not_reset_on_back(self):
        ui = (S/'ui/screens/AccountAuthScreen.kt').read_text()
        draft = (S/'ui/screens/AuthDraft.kt').read_text()
        self.assertIn('AuthFlow.entries.associateWith { AuthDraft() }', ui)
        back = ui.split('fun back() {', 1)[1].split('BackHandler', 1)[0]
        switch = ui.split('fun switch(', 1)[1].split('fun close()', 1)[0]
        for body in (back, switch): self.assertNotIn('clearSecrets', body)
        self.assertIn('clearOnSettle?.let { drafts.getValue(it).clearSecrets() }', ui)
        self.assertIn('if (email.trim() != value.trim()) clearSecrets()', draft)
        for forbidden in ('rememberSaveable', 'SharedPreferences', 'Log.', 'println('):
            self.assertNotIn(forbidden, ui + draft)

    def test_ime_footer_outside_body_scroll(self):
        ui = (S/'ui/screens/AccountAuthScreen.kt').read_text()
        for text in ('.displayCutoutPadding().imePadding()', '.using(null)',
                     'Column(Modifier.weight(1f).fillMaxWidth().verticalScroll',
                     'heightIn(max = viewport * 0.4f)', 'Modifier.heightIn(min = 48.dp)',
                     'widthIn(max = 560.dp)'):
            self.assertIn(text, ui)
        self.assertNotIn('SizeTransform(', ui)
        self.assertNotIn('viewport * 0.24f', ui)
        self.assertIn('android:windowSoftInputMode="adjustResize"', (R/'app/src/main/AndroidManifest.xml').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
