#!/usr/bin/env python3
"""Execute reference geometry and guard hero-only menu wiring; NOT a Kotlin compiler."""
from pathlib import Path
import ast, subprocess, tempfile, unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'
SCREENS = SRC / 'ui/screens'

class Collection6602(unittest.TestCase):
    def test_production_geometry(self):
        sources = [SRC/'ui/CollectionHeaderGeometry.java', SRC/'ui/CollectionGeometry.java',
                   SRC/'ui/CollectionCollapseMath.java', ROOT/'app/src/test/java/app/ziziplayer/ui/Collection6602Checks.java']
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,sources)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Collection6602Checks'],check=True)

    def test_cover_no_longer_reserves_entire_toolbar(self):
        s = (SCREENS/'PinnedCollectionScaffold.kt').read_text()
        self.assertNotIn('toolbar + 12.dp', s)
        self.assertIn('Spacer(Modifier.height((H.COVER_TOP * metrics.unit).dp))', s)
        self.assertIn('H.COVER_SIZE * metrics.unit', s)
        self.assertIn('H.COVER_TITLE_GAP * metrics.unit', s)
        self.assertIn('H.COVER_RADIUS * metrics.unit', s)
        self.assertEqual(s.count('.statusBarsPadding()'), 1)

    def test_expanded_artwork_is_not_blocked_by_transparent_scrim(self):
        s = (SCREENS/'PinnedCollectionScaffold.kt').read_text()
        self.assertIn('if (bannerAlpha > 0f) Box(', s)
        self.assertIn('nestedScroll(connection)', s)

    def test_no_menu_in_scaffold_signature_or_pinned_row(self):
        s = (SCREENS/'PinnedCollectionScaffold.kt').read_text().split('internal fun CollectionActionsRow(',1)[0]
        self.assertNotIn('onMenu', s)
        self.assertNotIn('ZiziIcons.More', s)
        self.assertNotIn('"collection:menu"', s)

    def test_existing_menu_callback_is_passed_to_hero_actions(self):
        s = (SCREENS/'UnifiedLocalCollectionScreen.kt').read_text()
        row = s.split('CollectionActionsRow(',1)[1].split('CollectionDownloadDialog',1)[0]
        self.assertIn('onMenu = if (playlist != null) { { playlistMenu = true } } else null', row)
        self.assertIn('PlaylistActionsHost(', s)
        for callback in ['onClick = onSort', 'onClick = onAdd', 'showDownloads = true']:
            self.assertIn(callback,row)

    def test_all_routes_share_measured_metadata_and_title_layout(self):
        for name in ['UnifiedLocalCollectionScreen.kt','HomeCollectionScreen.kt','RemoteCollectionScreen.kt']:
            s = (SCREENS/name).read_text()
            self.assertIn('CollectionHeroContent(',s)
            self.assertNotIn('fontSize = 28.sp',s)
            self.assertNotIn('fontSize = 30.sp',s)
        s = (SCREENS/'CollectionHeroContent.kt').read_text()
        for part in ['heightIn(min = (H.DETAILS_MIN_HEIGHT * u).dp)', 'Arrangement.SpaceBetween',
                     'H.TITLE_SIZE * u', 'H.TITLE_LINE * u', 'H.META_BOTTOM_GAP * u', 'maxLines = 3']:
            self.assertIn(part,s)
        self.assertNotIn('.height((H.DETAILS_MIN_HEIGHT',s)

    def test_visual_disk_and_touch_target_are_separate(self):
        s = (SCREENS/'PinnedCollectionScaffold.kt').read_text()
        self.assertIn('val playSize = metrics.touchSize',s)
        self.assertIn('Box(Modifier.size(metrics.playDisk).clip(CircleShape)',s)
        self.assertIn('CompositionLocalProvider(LocalCollectionHeaderMetrics provides metrics,',s)
        self.assertEqual(s.count('else ZiziIcons.CollectionPlayFilled'),1)

    def test_hero_actions_are_hidden_and_disabled_when_play_pins(self):
        s = (SCREENS/'PinnedCollectionScaffold.kt').read_text()
        self.assertIn('LocalCollectionActionsAlpha provides (1f - bannerAlpha)',s)
        row = s.split('internal fun CollectionActionsRow(',1)[1]
        self.assertIn('val actionsEnabled = actionAlpha > 0f',row)
        self.assertIn('Modifier.clearAndSetSemantics {}',row)
        self.assertIn('onClick = onMenu, enabled = actionsEnabled',row)
        self.assertIn('enabled = actionsEnabled && shuffleEnabled',row)
        for name in ['UnifiedLocalCollectionScreen.kt','RemoteCollectionScreen.kt']:
            self.assertIn('enabled = LocalCollectionActionsAlpha.current > 0f',(SCREENS/name).read_text())

    def test_ci_runs_new_regressions(self):
        s=(ROOT/'tools/check_selftest.py').read_text()
        main=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        self.assertIn('test_collection_6602.py',ast.get_source_segment(s,main))

if __name__ == '__main__': unittest.main(verbosity=2)
