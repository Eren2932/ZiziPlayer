#!/usr/bin/env python3
"""Trial update of a KNOWN 6.37.3/stage1 server. Default: checks only.
Use the service venv Python. --apply stops/restarts music and installs 7 modules.
Does not edit zizi.env, tokens, systemd config or existing databases/audio cache.
Unknown on-disk hotfixes are rejected rather than overwritten. Requires workers=1.
"""
import argparse
import ast
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT=Path(__file__).resolve().parent.parent
MODULES=['zizi_resolver.py','zizi_catalog.py','zizi_guard.py','zizi_extra.py',
         'zizi_scheduler.py','zizi_process.py','zizi_versions.py']


def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def service(action):
    subprocess.run(['systemctl',action,'zizi-resolver'],check=True,timeout=30)


def health(base, expected=True):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(40):
        try:
            with opener.open(base+'/health',timeout=1) as r: a=json.load(r)
            with opener.open(base+'/catalog/health',timeout=1) as r: b=json.load(r)
            if expected:
                assert a['version']=='1.7-stage2' and b['version']=='1.9-stage2'
                assert a['scheduler']['resolver_attached'] and a['scheduler']['slots']==1
                assert not b['extra']['enabled'], 'trial deployment requires extra disabled'
            return True
        except (OSError,ValueError,KeyError,AssertionError): time.sleep(.25)
    return False


def replace(source,target):
    # Same-filesystem rename; service is stopped for the multi-file transaction.
    fd,tmp=tempfile.mkstemp(prefix='.stage2-',dir=target.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(source.read_bytes()); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp,0o644); os.replace(tmp,target)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def restore(dest,backup):
    manifest=json.loads((backup/'manifest.json').read_text())
    if set(manifest)!=set(MODULES): raise RuntimeError('invalid backup manifest')
    # Validate the WHOLE backup before changing a single installed file.
    for name in MODULES:
        if manifest[name] is not None and digest(backup/name)!=manifest[name]:
            raise RuntimeError('backup checksum mismatch: '+name)
    for name in MODULES:
        if manifest[name] is None:
            (dest/name).unlink(missing_ok=True)
        else:
            replace(backup/name,dest/name)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    mode=p.add_mutually_exclusive_group()
    mode.add_argument('--check',action='store_true'); mode.add_argument('--apply',action='store_true')
    mode.add_argument('--rollback',type=Path)
    p.add_argument('--dest',type=Path,default=Path('/opt/zizi'))
    args=p.parse_args(); dest=args.dest.resolve(); base='http://127.0.0.1:8080'
    if args.rollback:
        if os.geteuid()!=0: raise RuntimeError('rollback requires root')
        backup=args.rollback.resolve()
        # Prevent using a foreign backup directory as an arbitrary file source.
        if backup.parent!=dest/'stage2-backups': raise RuntimeError('backup must be inside dest/stage2-backups')
        service('stop')
        try: restore(dest,backup)
        finally: service('start')
        if not health(base,False): raise RuntimeError('rollback files restored, but health failed')
        print('Rollback complete; databases/env unchanged.'); return 0
    known=json.loads((ROOT/'tools/stage2_base_hashes.json').read_text())
    for name in MODULES:
        ast.parse((ROOT/name).read_text(),filename=name)
        current=dest/name
        if current.is_symlink(): raise RuntimeError('refusing symlink: '+name)
        if current.exists() and digest(current) not in known[name] and digest(current)!=digest(ROOT/name):
            raise RuntimeError('unknown installed revision: '+name+'; compare your server hotfix before applying')
        if not current.exists() and name in MODULES[:3]:
            raise RuntimeError('not an installed 6.37.3 server: missing '+name)
    unit=subprocess.check_output(['systemctl','show','zizi-resolver','-p','ExecStart','--value'],text=True,timeout=5)
    if not re.search(r'--workers(?:=|\s+)1(?:\s|;|$)',unit):
        raise RuntimeError('service must explicitly use --workers 1')
    wd=subprocess.check_output(['systemctl','show','zizi-resolver','-p','WorkingDirectory','--value'],text=True,timeout=5).strip()
    if Path(wd).resolve()!=dest: raise RuntimeError('service WorkingDirectory differs from --dest')
    for test in ['test_zizi_guard.py','test_zizi_device.py','test_catalog_wiring.py',
                 'test_zizi_extra.py','test_stage2.py','test_resolver_stage2.py','test_stage2_tools.py','smoke_stage2.py']:
        result=subprocess.run([sys.executable,str(ROOT/'tools'/test)],cwd=ROOT,capture_output=True,timeout=60)
        if result.returncode:
            # Tests use only fixture credentials. Do not dump service environment/logs.
            raise RuntimeError(test+' failed; run it separately with the service venv Python')
        print('PASS '+test,flush=True)
    if not args.apply:
        print('CHECK ONLY: service and installed files were not changed. --apply will interrupt music.')
        return 0
    if os.geteuid()!=0: raise RuntimeError('--apply requires root')
    backup=dest/'stage2-backups'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid()))
    backup.mkdir(parents=True,mode=0o700)
    manifest={}
    for name in MODULES:
        source=dest/name
        manifest[name]=digest(source) if source.exists() else None
        if source.exists(): shutil.copy2(source,backup/name)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Backup: '+str(backup),flush=True)
    service('stop')
    try:
        for name in MODULES: replace(ROOT/name,dest/name)
        service('start')
        if not health(base): raise RuntimeError('post-install health/feature check failed')
    except BaseException:
        service('stop')
        try: restore(dest,backup)
        finally: service('start')
        raise RuntimeError('update failed; previous module files restored, check service health') from None
    print('Trial installed. Extra stays OFF. No APK update is required for these server changes.')
    print('Rollback: '+sys.executable+' '+str(Path(__file__).resolve())+' --rollback '+str(backup))
    return 0


if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as e:
        print('ABORT: '+str(e),file=sys.stderr); raise SystemExit(1)
