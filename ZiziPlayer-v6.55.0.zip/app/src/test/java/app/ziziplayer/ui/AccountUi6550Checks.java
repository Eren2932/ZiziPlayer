package app.ziziplayer.ui;

/** Executes production math only, NOT Compose hit testing or frame timing. */
public final class AccountUi6550Checks {
    private static int count;
    private static void check(boolean condition) {
        count++;
        if (!condition) throw new AssertionError("check " + count);
    }
    private static boolean close(float a, float b) { return Math.abs(a - b) < 0.0001f; }
    public static void main(String[] args) {
        check(close(AccountUiGeometry.DRAWER_FRACTION, 0.9f));
        check(close(AccountUiGeometry.TOP_SCRIM_ALPHA, 0.75f));
        check(close(CollectionGeometry.scrimAlpha(1f), 0.65f));
        check(close(AccountUiGeometry.collapse(10f, 0f, 56f), 0f));
        check(close(AccountUiGeometry.historyCollapse(10f, 0f), 0f));
        for (float toolbar : new float[] {48f, 56f, 84f, 168f}) {
            for (float hero : new float[] {toolbar, 200f, 340f, 680f, 1200f}) {
                float end = Math.max(toolbar, hero - toolbar);
                check(close(AccountUiGeometry.collapse(-100f, hero, toolbar), 0f));
                check(close(AccountUiGeometry.collapse(0f, hero, toolbar), 0f));
                check(close(AccountUiGeometry.collapse(end, hero, toolbar), 1f));
                check(close(AccountUiGeometry.collapse(end - toolbar, hero, toolbar), 0f));
                check(close(AccountUiGeometry.collapse(end - toolbar / 2f, hero, toolbar), 0.5f));
                float previous = 0f;
                for (int i = 0; i <= 1000; i++) {
                    float value = AccountUiGeometry.collapse(i * (hero + toolbar) / 1000f, hero, toolbar);
                    check(value >= 0f && value <= 1f);
                    check(value >= previous);
                    previous = value;
                }
            }
            check(close(AccountUiGeometry.historyCollapse(-1f, toolbar), 0f));
            check(close(AccountUiGeometry.historyCollapse(toolbar, toolbar), 1f));
            check(close(AccountUiGeometry.historyCollapse(toolbar / 2f, toolbar), 0.5f));
        }
        // Layout invariant used by the two translationX expressions in AccountDrawerHost.
        for (float width : new float[] {320f, 360f, 692f, 1080f, 2400f}) {
            float travel = Math.round(width * AccountUiGeometry.DRAWER_FRACTION);
            for (int i = 0; i <= 1000; i++) {
                float progress = i / 1000f;
                float menuRight = travel * (progress - 1f) + travel;
                float pageLeft = travel * progress;
                check(Math.abs(menuRight - pageLeft) < 0.001f);
            }
            check(Math.abs(width - travel - width * 0.1f) <= 0.5001f);
        }
        // System status tint remains an additional independent overlay: total 81%, not 99%.
        check(close(1f - (1f - 0.75f) * (1f - 0.24f), 0.81f));
        System.out.println("PASS: " + count + " geometry assertions; no Android/Compose/device execution.");
    }
}
