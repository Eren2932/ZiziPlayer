package app.ziziplayer.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Fixed, translucent tint ABOVE app content and BELOW Android's system icons.
 * Mount once as the last visual layer in the window host, not inside the moving player.
 * Future lyrics/scrolling content can pass underneath without any change to this component.
 * This is tint glass, not blur: no bitmap capture, RenderEffect or offscreen compositing layer.
 * The Spacer has no input/semantics handlers, so system gestures and app hits are untouched.
 */
@Composable
fun StatusBarTint(modifier: Modifier = Modifier) {
    Spacer(
        modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).drawWithCache {
            val tint = Color.Black.copy(alpha = 0.24f)
            onDrawBehind { drawRect(tint) }
        }
    )
}

/** A single translucent surface under title, filters AND sort controls, with a quiet edge. */
fun Modifier.libraryChrome(): Modifier = drawWithCache {
    val tint = Brush.verticalGradient(
        0f to Color.Black.copy(alpha = 0.19f),
        1f to Color.Black.copy(alpha = 0.11f)
    )
    val edge = 0.5.dp.toPx()
    onDrawBehind {
        drawRect(tint)
        drawRect(
            Color.White.copy(alpha = 0.055f),
            topLeft = Offset(0f, (size.height - edge).coerceAtLeast(0f)),
            size = Size(size.width, edge)
        )
    }
}

/**
 * ФОН ШАПКИ ПОИСКА (6.41.0).
 *
 * Это не «другой цвет сзади», как кажется по скриншоту, а отдельный слой с собственной
 * геометрией, и собрать его одним диагональным градиентом нельзя: у эталона максимум стоит в
 * ДВУХ верхних углах сразу, а не на одной диагонали.
 *
 * Замер эталона (1080 px, срезы по строкам): левый верх R79 G41 B20 — это в точности бренд
 * #F97316 с альфой 0.26 на базе #121212 (0.26*249 + 0.74*18 = 78). Правый верх R43 G30 B40 —
 * верхний цвет рампы обложки с альфой около 0.23. К низу блока всё уходит в базу: на 540-й
 * строке слева остаётся R34, то есть альфа 0.069 — падение ровно в 3.8 раза.
 *
 * Отсюда два слоя вместо одного: горизонтальный градиент бренд → обложка с верхними альфами,
 * поверх — вертикальная вуаль базы от прозрачной до 0.74. Произведение и даёт измеренные 0.069
 * внизу слева (0.26 * 0.26). Два `drawRect` на кадр, ни одного offscreen-слоя.
 */
fun Modifier.searchChrome(brand: Color, cover: Color): Modifier = drawWithCache {
    val wash = Brush.horizontalGradient(
        0f to brand.copy(alpha = 0.26f),
        1f to cover.copy(alpha = 0.23f)
    )
    val fade = Brush.verticalGradient(
        0f to Color.Transparent,
        1f to SEARCH_CHROME_BASE.copy(alpha = 0.74f)
    )
    onDrawBehind {
        drawRect(wash)
        drawRect(fade)
    }
}

/** База приложения. Вуаль шапки уходит именно в неё, а не в чёрный: чёрный дал бы провал. */
private val SEARCH_CHROME_BASE = Color(0xFF121212)

/** Measured overlay height, consumed as lazy-list content padding, never viewport padding. */
val LocalBottomChromeInset = compositionLocalOf { 0.dp }


/** 75% black at full collapse. Smoothstep edge like the dock; progress read only in draw. */
fun Modifier.pinnedPageChrome(progress: () -> Float): Modifier = drawWithCache {
    val lead = 16.dp.toPx()
    val stops = (0..24).map { index ->
        val t = index / 24f
        t to Color.Black.copy(alpha = app.ziziplayer.ui.AccountUiGeometry.TOP_SCRIM_ALPHA *
            (1f - app.ziziplayer.ui.CollectionGeometry.smoothstep(t)))
    }.toTypedArray()
    val edge = Brush.verticalGradient(*stops, startY = size.height, endY = size.height + lead)
    onDrawBehind {
        val fraction = progress().coerceIn(0f, 1f)
        drawRect(Color.Black.copy(alpha = app.ziziplayer.ui.AccountUiGeometry.TOP_SCRIM_ALPHA * fraction))
        drawRect(edge, topLeft = Offset(0f, size.height), size = Size(size.width, lead), alpha = fraction)
    }
}

/**
 * Full-bleed scrim, not a dock-shaped surface. The transparent lead-in extends above
 * the capsule; smoothstep has zero slope at both ends. Controls remain opaque.
 * 65% is the maximum BLACK opacity (35% transmittance), not child alpha.
 */
fun Modifier.bottomChrome(): Modifier = drawWithCache {
    val lead = 48.dp.toPx()
    val start = -lead
    val end = size.height * 0.72f
    val stops = (0..24).map { index ->
        val t = index / 24f
        val alpha = app.ziziplayer.ui.CollectionGeometry.scrimAlpha(t)
        t to Color.Black.copy(alpha = alpha)
    }.toTypedArray()
    val tint = Brush.verticalGradient(*stops, startY = start, endY = end)
    onDrawBehind {
        drawRect(tint, topLeft = Offset(0f, start), size = Size(size.width, size.height + lead))
    }
}
