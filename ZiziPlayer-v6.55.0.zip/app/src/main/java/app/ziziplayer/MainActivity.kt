package app.ziziplayer

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import app.ziziplayer.account.AccountGate
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountRepository
import app.ziziplayer.ui.screens.AccountAuthScreen
import app.ziziplayer.account.AccountProfileStore
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.ui.screens.AccountDrawer
import app.ziziplayer.ui.screens.AccountEditScreen
import app.ziziplayer.ui.screens.SettingsSheet
import app.ziziplayer.account.AccountStore
import app.ziziplayer.ui.screens.AccountScreen
import app.ziziplayer.library.LibrarySync
import app.ziziplayer.ui.screens.LibraryStorageScreen
import app.ziziplayer.ui.screens.WelcomeScreen
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import app.ziziplayer.ui.components.AccountDrawerHost
import app.ziziplayer.ui.components.blockSurfaceInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalDensity
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.LocalSearchFocusRegion
import app.ziziplayer.ui.components.SearchFocusRegion
import app.ziziplayer.ui.components.bottomChrome
import app.ziziplayer.ui.components.ProvideAudioSpectrum
import app.ziziplayer.ui.components.ProvidePlaybackIndicatorMotion
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadEvent
import app.ziziplayer.playback.DownloadEvents
import app.ziziplayer.playback.OfflineStore
import app.ziziplayer.playback.RemoteUri
import app.ziziplayer.share.PlaylistShare
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.SearchViewModel
import app.ziziplayer.ui.components.StatusBarTint
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.ArtworkPrefetcher
import app.ziziplayer.ui.components.rememberArtSwatches
import app.ziziplayer.ui.components.ZiziTab
import app.ziziplayer.ui.components.ZiziTabBar
import app.ziziplayer.ui.screens.EqualizerScreen
import app.ziziplayer.ui.screens.LibraryScreen
import app.ziziplayer.ui.screens.MiniPlayer
import app.ziziplayer.ui.screens.PlayerScreen
import app.ziziplayer.ui.screens.PlaylistImportSheet
import app.ziziplayer.ui.screens.SearchScreen
import app.ziziplayer.ui.theme.BackdropBlend
import app.ziziplayer.ui.theme.LocalBackdropBlend
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.SyncBackdropPalette
import app.ziziplayer.ui.theme.ZiziBackdrop
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.prefersDarkSystemIcons
import app.ziziplayer.ui.theme.tintedWith
import app.ziziplayer.ui.theme.withAccent
import kotlinx.coroutines.launch

/** Метка «этот интент мы уже разобрали». Живёт в самом интенте, поэтому переживает поворот. */
private const val EXTRA_HANDLED = "app.ziziplayer.intent.handled"

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private val searchVm: SearchViewModel by viewModels()
    private val homeVm: app.ziziplayer.ui.HomeViewModel by viewModels()

    private var deleteTarget: TrackEntity? = null
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>

    /** Разрешение на чтение локальной музыки: с Android 13 оно точечное, до неё — общее. */
    private fun readAudioPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 6.40.1: only VaultAuthDialog owns a secure window. Folder configuration must
        // never disable screenshots or blank recents for the whole Activity.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // 6.17.0 — системные полосы больше не красятся сами.
        //
        // Прозрачность задана и в теме, но OEM-прошивки любят подставить свой «контрастный» скрим
        // под навбар и статус-бар: именно он и выглядел как чёрная плашка поверх нашего градиента.
        // Отключаем его явно; цвет иконок ставится в ZiziApp по светлоте гребня.
        @Suppress("DEPRECATION")
        run {
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.decorView.isForceDarkAllowed = false
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        ArtworkCache.attach(this)

        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { vm.addFolder(it) }
        }
        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = deleteTarget
            deleteTarget = null
            if (result.resultCode == RESULT_OK && target != null) vm.onFileDeleted(target)
        }
        // 6.24.1: разрешения запрашиваются пачкой, потому что их стало три, и два из них нужны
        // именно загрузкам. Система показывает диалоги по очереди сама — два отдельных launcher'а
        // подряд, наоборот, гонятся друг с другом и второй молча теряется.
        val permissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
                if (granted[readAudioPermission()] == true) vm.rescan()
            }
        val wanted = buildList {
            add(readAudioPermission())
            // Без POST_NOTIFICATIONS уведомление загрузки на Android 13+ просто не появляется:
            // foreground-сервис живёт, процент идёт, а человек не видит ни прогресса, ни отмены.
            // Разрешение было объявлено в манифесте с 6.20.0 и ни разу не запрошено.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
            // До Android 10 запись в общую «Музыку» требует разрешения. 6.24.0 его ПРОВЕРЯЛА и
            // отказывалась качать, но никогда не просила — на Android 8 и 9 скачать было нельзя
            // вообще, и сделать с этим из приложения было нельзя ничего.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionLauncher.launch(wanted.toTypedArray())

        // 6.24.1: итог загрузки говорится вслух ровно один раз. Раньше он существовал только
        // подписью внутри меню трека — то есть исчезал вместе с закрытым меню, и «ничего не
        // произошло» было единственным, что видел человек.
        lifecycleScope.launch {
            DownloadEvents.stream.collect { event ->
                val text = when (event) {
                    is DownloadEvent.Saved ->
                        if (event.visible) "Сохранено: " + event.where
                        // Публичной папки прошивка не дала: файл есть и играет, но в «Музыке» его
                        // не будет. Честно сказать это сразу дешевле, чем поиски в проводнике.
                        else "Сохранено внутри приложения: " + event.where
                    is DownloadEvent.Failed -> event.title + " — " + event.reason
                }
                Toast.makeText(this@MainActivity, text, Toast.LENGTH_LONG).show()
            }
        }

        handleShareIntent(intent)

        setContent {
            /**
             * 6.50.0 — приветствие про аккаунты решается ДО остального приложения.
             *
             * Состояние читается синхронно (см. AccountStore), поэтому первый кадр уже знает
             * ответ: медиатека не успевает мигнуть под окном, которое через мгновение её накроет.
             */
            val account by accounts.state.collectAsStateWithLifecycle()
            val librarySync = remember { LibrarySync.get(this@MainActivity) }
            val libraryState by librarySync.state.collectAsStateWithLifecycle()
            var libraryOpen by remember { mutableStateOf(false) }
            LaunchedEffect(account.userId) {
                librarySync.connect(account.userId)
                if (account.userId != null) {
                    lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                        librarySync.refresh()
                        while (true) {
                            kotlinx.coroutines.delay(15_000)
                            librarySync.flush()
                        }
                    }
                }
            }
            LaunchedEffect(libraryState.needsChoice) {
                if (libraryState.needsChoice) libraryOpen = true
            }
            var authOpen by remember { mutableStateOf(false) }
            var authRegister by remember { mutableStateOf(false) }
            var signingOut by remember { mutableStateOf(false) }
            val accountScope = rememberCoroutineScope()
            LaunchedEffect(accountRepository) {
                try {
                    accountRepository.restore()?.let { accounts.markSignedIn(it.getString("email"), it.getString("id")) }
                } catch (error: kotlinx.coroutines.CancellationException) {
                    throw error
                } catch (_: Exception) {
                    // Offline is not a signed-in identity. Music and guest mode remain available.
                }
            }
            val signOutAction: (Boolean) -> Unit = { allSessions ->
                if (!signingOut) {
                    signingOut = true
                    accountScope.launch {
                        try {
                            val revoked = accountRepository.signOut(allSessions)
                            accounts.signOut()
                            if (!revoked) Toast.makeText(this@MainActivity,
                                "Вышли на этом устройстве. Отзыв сессии на сервере не подтверждён: нет связи.",
                                Toast.LENGTH_LONG).show()
                        } finally { signingOut = false }
                    }
                }
            }
            Box(Modifier.fillMaxSize()) {
            // if/else, а не ранний return: ветвление композиции читается однозначно и не
            // зависит от того, как компилятор Compose обойдётся с выходом из лямбды.
            if (account.showWelcome) {
                WelcomeGate(
                    signInOffered = AccountGate.signInOffered(accountServiceUrl.isNotEmpty()),
                    // Open credentials UI; only a verified server response marks the user signed in.
                    onSignIn = { authRegister = false; authOpen = true },
                    onGuest = { accounts.chooseGuest() },
                    onRegister = { authRegister = true; authOpen = true }
                )
            } else {
            val gate by vm.folderVault.state.collectAsStateWithLifecycle()
            androidx.compose.runtime.key(if (gate.folders.isEmpty()) "public" else vm.folderVault.uiSessionKey, gate.lockRevision) { ZiziApp(
                vm = vm,
                searchVm = searchVm,
                homeVm = homeVm,
                onPickFolder = { folderLauncher.launch(null) },
                onShare = ::shareTrack,
                onDeleteFile = ::deleteTrackFile,
                onExit = { finish() },
                account = account,
                accountServiceUrl = accountServiceUrl,
                onSignIn = { authRegister = false; authOpen = true },
                onSignOut = { signOutAction(false) },
                onSignOutAll = { signOutAction(true) },
                onOpenLibrary = { libraryOpen = true }
            ) }
            }
            AnimatedVisibility(
                visible = authOpen,
                enter = slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { it },
                exit = slideOutHorizontally(tween(220, easing = FastOutSlowInEasing)) { it }
            ) {
                val authPalette = app.ziziplayer.ui.theme.basePalette()
                CompositionLocalProvider(LocalPalette provides authPalette) {
                    ZiziTheme(authPalette) {
                        AccountAuthScreen(
                            activity = this@MainActivity,
                            repository = accountRepository,
                            onSignedIn = { email, id -> accounts.markSignedIn(email, id); authOpen = false; libraryOpen = true },
                            onClose = { authOpen = false },
                            initialRegister = authRegister,
                            interactive = authOpen && transition.currentState == transition.targetState
                        )
                    }
                }
            }
            if (libraryOpen && !authOpen) {
                val storagePalette = app.ziziplayer.ui.theme.basePalette()
                CompositionLocalProvider(LocalPalette provides storagePalette) {
                    ZiziTheme(storagePalette) {
                        LibraryStorageScreen(libraryState, !account.isGuest, onClose = { libraryOpen = false })
                    }
                }
            }
            }
        }
    }

    /**
     * Приложение уже живо, а нам прислали плейлист.
     *
     * `launchMode="singleTop"` в манифесте гарантирует, что мы попадём сюда, а не создадим вторую
     * копию экрана. `setIntent` обязателен: без него `getIntent()` до конца жизни активити
     * возвращает тот интент, с которым её запустили в самый первый раз.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    /**
     * Разбирает, принесли ли нам плейлист, и в каком виде: ссылкой, файлом или текстом.
     *
     * Интент помечается как обработанный. Без метки поворот экрана или возврат приложения из фона
     * заново открывал бы предпросмотр импорта того же плейлиста — с точки зрения человека
     * приложение просто «липнет» к одному и тому же чужому плейлисту и не даёт от него уйти.
     */
    private fun handleShareIntent(intent: Intent?) {
        if (intent == null || intent.getBooleanExtra(EXTRA_HANDLED, false)) return
        val data = intent.data
        val handled = when {
            intent.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true -> {
                vm.offerImport(intent.getStringExtra(Intent.EXTRA_TEXT)); true
            }
            intent.action != Intent.ACTION_VIEW || data == null -> false
            data.scheme == PlaylistShare.URI_SCHEME -> {
                vm.offerImport(data.toString()); true
            }
            else -> {
                vm.offerImportFile(data); true
            }
        }
        if (handled) intent.putExtra(EXTRA_HANDLED, true)
    }

    /** No position polling and no artwork work at all while the UI is off screen. */
    override fun onStart() {
        super.onStart()
        vm.setUiActive(true)
        // The composition survives backgrounding, so cover indexing has to be woken up by hand.
        ArtworkPrefetcher.resume()
    }

    override fun onStop() {
        app.ziziplayer.privacy.FolderVault.get(this).lock()
        vm.setUiActive(false)
        vm.savePosition()
        // Nothing may keep parsing audio files once the UI is gone.
        ArtworkPrefetcher.stop()
        ArtworkCache.flushIndex()
        super.onStop()
    }

    /**
     * 6.19.0: сетевой трек отправляется текстом, а не как файл.
     *
     * У сетевого трека в `uri` лежит `zizi://<источник>/<id>` — наша внутренняя схема, которую не
     * понимает ни одно приложение на телефоне. Отправка её в EXTRA_STREAM с MIME-типом audio выглядела
     * для человека так: выбрал мессенджер, получил либо пустое вложение, либо ошибку от
     * мессенджера, и ни малейшего намёка на причину. Файла не существует — отдавать нечего, и
     * честнее отдать то, что действительно есть: название и исполнителя.
     */
    private fun shareTrack(track: TrackEntity) {
        if (vm.folderVault.state.value.blocks(track)) return
        // 1. Скачанный сетевой трек — теперь это НАСТОЯЩИЙ файл в «Музыка/Zizi», и уходит он
        //    вложением. Ровно то, чего ждёт человек, нажимая «поделиться» у скачанного трека:
        //    до 6.24.0 файла не существовало (байты лежали фрагментами внутри кэша), поэтому
        //    отправлялся текст — и это выглядело как «приложение не умеет отправлять музыку».
        val downloaded = OfflineStore.shareTarget(this, track)
        val intent = when {
            downloaded != null -> Intent(Intent.ACTION_SEND).apply {
                val (uri, mime) = downloaded
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, track.title)
                // clipData вместе с EXTRA_STREAM: часть приложений (в том числе несколько
                // мессенджеров) читает разрешение на чтение именно оттуда, и без него получает
                // SecurityException уже у себя — снаружи это «отправилось пустое вложение».
                clipData = ClipData.newUri(contentResolver, track.title, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            // 2. Сетевой и не скачанный: в `uri` лежит `zizi://<источник>/<id>` — наша внутренняя
            //    схема, которую не понимает ни одно приложение на телефоне. Отдавать её как
            //    вложение значит отдать пустоту, поэтому уходит то, что действительно есть.
            RemoteUri.isRemote(track.uri) -> Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "${track.artist} — ${track.title}")
                putExtra(Intent.EXTRA_SUBJECT, track.title)
            }
            // 3. Свой файл из медиатеки — как было.
            else -> Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                val uri = Uri.parse(track.uri)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(contentResolver, track.title, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        runCatching { startActivity(Intent.createChooser(intent, track.title)) }
    }

    /**
     * 6.50.0 — локальное решение об аккаунте. Создаётся здесь, а не во ViewModel: его читает
     * первый кадр, до того как ViewModel успевает что-либо отдать потоком.
     */
    private val accounts by lazy { AccountStore(this) }
    private val accountRepository by lazy { AccountRepository.get(this) }

    /**
     * Адрес сервиса аккаунтов из сборки, уже проверенный.
     *
     * Пустая строка означает «входа нет», и именно она по умолчанию: сборка без сервера обязана
     * молчать про сохранность, а не предлагать кнопку, за которой ничего не стоит. Проверка
     * живёт в AccountGate, поэтому опечатка в -PaccountUrl или адрес по http не включат вход.
     */
    private val accountServiceUrl by lazy { AccountGate.normalizeServiceUrl(BuildConfig.ACCOUNT_URL) }

    private fun deleteTrackFile(track: TrackEntity) {
        if (vm.folderVault.state.value.blocks(track)) return
        vm.requestDeleteFile(track) { sender ->
            if (sender == null) return@requestDeleteFile
            deleteTarget = track
            runCatching { deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
        }
    }
}

@Composable
private fun ZiziApp(
    vm: MainViewModel,
    searchVm: SearchViewModel,
    homeVm: app.ziziplayer.ui.HomeViewModel,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit,
    onExit: () -> Unit,
    account: AccountLocalState,
    accountServiceUrl: String,
    onSignIn: () -> Unit,
    onSignOutAll: () -> Unit,
    onSignOut: () -> Unit,
    onOpenLibrary: () -> Unit
) {
    val rawLibrary by vm.library.collectAsStateWithLifecycle()
    val vaultGate by vm.folderVault.state.collectAsStateWithLifecycle()
    // StateFlow pipelines may deliver their database projections one frame after a lock.
    // Apply the gate synchronously at the render boundary as well.
    val library = remember(rawLibrary, vaultGate) {
        if (vaultGate.unlocked || vaultGate.folders.isEmpty()) rawLibrary else {
            val allowed = rawLibrary.tracks.filterNot(vaultGate::blocks)
            val allowedArtists = allowed.mapTo(HashSet()) { it.artist }
            val blockedIds = rawLibrary.tracks.filter(vaultGate::blocks).mapTo(HashSet()) { it.id }
            rawLibrary.copy(
                tracks = allowed,
                visible = rawLibrary.visible.filterNot(vaultGate::blocks),
                favoriteIds = rawLibrary.favoriteIds - blockedIds,
                playlistMeta = rawLibrary.playlistMeta.mapValues { (_, meta) -> meta.copy(cover = meta.cover?.takeUnless(vaultGate::blocks)) },
                folders = rawLibrary.folders.filterNot { it.name in vaultGate.folders },
                artists = rawLibrary.artists.filter { it.name in allowedArtists }.map { it.copy(cover = it.cover?.takeUnless(vaultGate::blocks)) },
                openFolder = rawLibrary.openFolder?.takeUnless { it in vaultGate.folders },
                openArtist = rawLibrary.openArtist?.takeIf { it in allowedArtists }
            )
        }
    }
    val playback by vm.playback.collectAsStateWithLifecycle()
    val rawCurrent by vm.currentTrack.collectAsStateWithLifecycle()
    val current = rawCurrent?.takeUnless(vaultGate::blocks)
    val search by searchVm.state.collectAsStateWithLifecycle()
    val pendingImport by vm.import.collectAsStateWithLifecycle()
    val savedRemoteIds by searchVm.savedIds.collectAsStateWithLifecycle()

    /**
     * The artists the hub offers as starting points.
     *
     * Local rows only, most-frequent first, and recomputed only when the library's SIZE changes -
     * not on every emission. The list flow re-emits on a favourite toggle and on every play count
     * bump, and grouping 3000 rows on the main thread each time would be a stutter you could feel
     * in the tab bar. Sixteen names is two screens of tiles; nobody scrolls further for a seed.
     */
    val seeds = remember(library.tracks.size) {
        library.tracks.asSequence()
            .filter { !it.isRemote }
            .map { it.artist.trim() }
            .filter { it.isNotEmpty() && !it.equals("<unknown>", ignoreCase = true) }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(16)
            .map { it.key }
    }

    // Three cover shades drive the whole app: one hue, one chroma level, one brightness. They
    // only change when the track changes.
    val swatches = rememberArtSwatches(current, library.settings.accentFromArtwork)
    val palette = remember(swatches) {
        basePalette().tintedWith(swatches).withAccent(swatches)
    }

    // Цвет часов и батареи следует за обложкой, а не за строкой в styles.xml.
    val view = LocalView.current
    val darkSystemIcons = palette.prefersDarkSystemIcons()
    LaunchedEffect(darkSystemIcons, view) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        // The fixed tint layer keeps the status bar dark, even during a cover transition.
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = darkSystemIcons
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(vm) {
        vm.messages.collect { message ->
            val result = snackbar.showSnackbar(
                message = message.text,
                actionLabel = message.actionLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) message.action?.invoke()
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(searchVm, lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            searchVm.messages.collect { message ->
                snackbar.showSnackbar(message = message, duration = SnackbarDuration.Short)
            }
        }
    }

    // One blend per process, shared by both backdrops: the library's and the player's ramps stay
    // on the same colour, so sliding the player down never crosses a seam.
    val blend = remember { BackdropBlend(palette) }
    SyncBackdropPalette(blend, palette, current?.id ?: playback.currentTrackId, playback.currentTrackId)

    CompositionLocalProvider(LocalPalette provides palette, LocalBackdropBlend provides blend) {
        ZiziTheme(palette) {
          ProvidePlaybackIndicatorMotion(playing = playback.isPlaying) {
            val focusRegion = remember { SearchFocusRegion() }
            val focusManager = LocalFocusManager.current
            val keyboard = LocalSoftwareKeyboardController.current
            val density = LocalDensity.current
            val imeInsets = WindowInsets.ime
            // IME animates in pixels; only the Boolean belongs in composition.
            val imeVisible by remember(imeInsets, density) {
                derivedStateOf { imeInsets.getBottom(density) > 0 }
            }
            var dockHeightPx by remember { mutableIntStateOf(0) }
            val dockInset = if (imeVisible) 0.dp else with(density) { dockHeightPx.toDp() }
            CompositionLocalProvider(
                LocalSearchFocusRegion provides focusRegion,
                LocalBottomChromeInset provides dockInset
            ) {
            // Saveable, same reasoning as `tab` below: a process death while the player sheet was
            // open used to land the user on the library with the music still playing.
            var playerOpen by rememberSaveable { mutableStateOf(false) }
            /**
             * 6.24.4. Эквалайзер живёт ЗДЕСЬ, а не внутри PlayerScreen, хотя открывается оттуда.
             *
             * Причина ровно одна и она про кнопку «назад». BackHandler'ы складываются в стек
             * диспетчера, и выигрывает добавленный последним; корневой обработчик этого экрана
             * добавляется после всего, что нарисовано выше, поэтому «назад» из эквалайзера,
             * объявленного внутри плеера, закрыл бы ПЛЕЕР, а эквалайзер остался бы висеть поверх
             * медиатеки. Один стек навигации на приложение, одна ветка в одном обработчике —
             * и ошибиться негде.
             */
            var eqOpen by rememberSaveable { mutableStateOf(false) }
            /**
             * 6.50.0. Экран аккаунта объявлен ЗДЕСЬ по той же причине, что и эквалайзер выше:
             * один стек навигации на приложение. Объявленный внутри настроек, он закрывался бы
             * кнопкой «назад» вместе с листом настроек или, наоборот, оставался бы висеть
             * поверх медиатеки.
             */
            var accountOpen by rememberSaveable { mutableStateOf(false) }
            var accountDrawer by rememberSaveable { mutableStateOf(false) }
            var profileEdit by rememberSaveable { mutableStateOf(false) }
            var accountSettings by rememberSaveable { mutableStateOf(false) }
            var confirmAccountLogout by remember { mutableStateOf(false) }
            val profileContext = androidx.compose.ui.platform.LocalContext.current
            val profileStore = remember { AccountProfileStore.get(profileContext) }
            val rawProfile by profileStore.state.collectAsStateWithLifecycle()
            val profile = rawProfile.takeIf { it.userId == account.userId } ?: AccountProfile()
            val profileScope = rememberCoroutineScope()
            LaunchedEffect(account.userId) {
                profileEdit = false; accountDrawer = false
                profileStore.connect(account.userId)
            }
            LaunchedEffect(accountOpen) {
                if (accountOpen && account.userId != null) profileStore.connect(account.userId)
            }
            // Saveable: a rotation or a process death that lands the user back on the library
            // after they had opened search is a small betrayal, and it costs one Parcelable int.
            var tab by rememberSaveable { mutableStateOf(ZiziTab.HOME) }
            val destinationState = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
            var screenHeight by remember { mutableFloatStateOf(0f) }
            val slide = remember { Animatable(0f) }
            var mounted by remember { mutableStateOf(false) }
            // Read inside the draw phase only, so toggling it costs no recomposition.
            val libraryDrawn = remember { mutableStateOf(true) }

            LaunchedEffect(playerOpen, screenHeight) {
                if (screenHeight <= 0f) return@LaunchedEffect
                if (playerOpen) {
                    if (!mounted) { slide.snapTo(screenHeight); mounted = true }
                    libraryDrawn.value = true
                    slide.animateTo(0f, spring(dampingRatio = 0.88f, stiffness = Spring.StiffnessMediumLow))
                    // Fully covered: stop drawing the library underneath.
                    if (slide.value == 0f) libraryDrawn.value = false
                } else if (mounted) {
                    libraryDrawn.value = true
                    slide.animateTo(screenHeight, tween(210, easing = FastOutLinearInEasing))
                    mounted = false
                }
            }

            Box(Modifier.fillMaxSize()) {
            AccountDrawerHost(open = accountDrawer, onClose = { accountDrawer = false }, drawer = {
                CompositionLocalProvider(LocalPalette provides app.ziziplayer.ui.theme.basePalette()) {
                    AccountDrawer(account, profile,
                        onProfile = { accountDrawer = false; accountOpen = true },
                        onHistory = { accountDrawer = false; tab = ZiziTab.HOME; homeVm.openHistory() },
                        onSettings = { accountDrawer = false; accountSettings = true },
                        onLibrary = { accountDrawer = false; onOpenLibrary() })
                }
            }) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { screenHeight = it.height.toFloat() }
                    .pointerInput(focusManager, keyboard) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                val bounds = focusRegion.bounds
                                if (focusRegion.focused && bounds != null && event.changes.any {
                                    it.pressed && !it.previousPressed && !bounds.contains(it.position)
                                }) {
                                    // Observe only. The original tap must still reach its button/list.
                                    focusManager.clearFocus(force = true)
                                    keyboard?.hide()
                                }
                            }
                        }
                    }
            ) {
                // No wash, no halo: the crest at y = 0.20 carries the cover's colour on its own.
                ZiziBackdrop(palette)

                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent { if (libraryDrawn.value) drawContent() }
                ) {
                    Box(Modifier.fillMaxSize()
                        .drawWithContent { if (!accountOpen && !accountSettings) drawContent() }
                        .then(if (accountOpen || accountSettings) Modifier.clearAndSetSemantics { } else Modifier)) {
                    Box(Modifier.fillMaxSize().imePadding()) {
                        Box(Modifier.fillMaxSize()) {
                            // Screen state belongs to its ViewModel; the dock overlays either destination.
                            destinationState.SaveableStateProvider(tab.name) {
                            if (tab == ZiziTab.HOME) {
                                CompositionLocalProvider(LocalPalette provides app.ziziplayer.ui.theme.basePalette()) {
                                app.ziziplayer.ui.screens.HomeScreen(
                                    home = homeVm, vm = vm, playback = playback,
                                    favoriteIds = library.favoriteIds,
                                    onPlay = { track, tracks -> vm.play(track, tracks) },
                                    onPlaylist = { id -> vm.openPlaylist(id); tab = ZiziTab.LIBRARY },
                                    onFavorites = { vm.setFilter(app.ziziplayer.ui.LibraryFilter.FAVORITES); tab = ZiziTab.LIBRARY },
                                    onLibrary = { vm.setFilter(app.ziziplayer.ui.LibraryFilter.COLLECTION); tab = ZiziTab.LIBRARY },
                                    onArtist = { artist -> vm.openArtist(artist); tab = ZiziTab.LIBRARY },
                                    account = account, profile = profile,
                                    onOpenAccount = { accountDrawer = true }
                                )
                                }
                            } else if (tab == ZiziTab.LIBRARY) {
                                LibraryScreen(
                                    vm = vm,
                                    state = library,
                                    playback = playback,
                                    currentTrack = current,
                                    onOpenPlayer = { playerOpen = true },
                                    onPickFolder = onPickFolder,
                                    onShare = onShare,
                                    onDeleteFile = onDeleteFile,
                                    onOpenEqualizer = { eqOpen = true },
                                    accountGuest = account.isGuest,
                                    onOpenAccount = { accountOpen = true },
                                    onOpenSettings = { accountSettings = true }
                                )
                            } else {
                                Column(Modifier.fillMaxSize().then(
                                    if (search.collection == null) Modifier.statusBarsPadding() else Modifier
                                )) {
                                    SearchScreen(
                                        vm = vm,
                                        search = searchVm,
                                        state = search,
                                        savedIds = savedRemoteIds,
                                        currentTrackId = playback.currentTrackId,
                                        isPlaying = playback.isPlaying,
                                        seeds = seeds
                                    )
                                }
                            }
                            }
                        }

                    }

                    }

                CompositionLocalProvider(LocalPalette provides app.ziziplayer.ui.theme.basePalette()) {
                ZiziTheme(app.ziziplayer.ui.theme.basePalette()) {
                // Opaque destinations extend UNDER the shared dock, not just up to its top edge.
                if (accountOpen) {
                    Box(Modifier.fillMaxSize().background(app.ziziplayer.ui.theme.basePalette().surface).blockSurfaceInput()
                        .drawWithContent { if (!accountSettings) drawContent() }
                        .then(if (accountSettings) Modifier.clearAndSetSemantics { } else Modifier)) {
                        AccountScreen(
                            state = account, profile = profile,
                            playlists = library.playlists, playlistMeta = library.playlistMeta,
                            onPlaylist = { id -> accountOpen = false; vm.openPlaylist(id); tab = ZiziTab.LIBRARY },
                            signInOffered = AccountGate.signInOffered(accountServiceUrl.isNotEmpty()),
                            onSignIn = onSignIn,
                            onSignOutAll = onSignOutAll,
                            onSignOut = onSignOut,
                            onOpenLibrary = onOpenLibrary,
                            onSettings = { accountSettings = true },
                            onEdit = { profileEdit = true },
                            onRefresh = { profileScope.launch { profileStore.connect(account.userId) } },
                            onClose = { accountOpen = false }
                        )
                    }
                }
                if (accountSettings) {
                    Box(Modifier.fillMaxSize().background(app.ziziplayer.ui.theme.basePalette().surface).blockSurfaceInput().padding(bottom = dockInset)) {
                        SettingsSheet(vm = vm, state = library, onDismiss = { accountSettings = false },
                            onPickFolder = onPickFolder,
                            onOpenEqualizer = { accountSettings = false; accountOpen = false; eqOpen = true },
                            accountGuest = account.isGuest,
                            onOpenAccount = { accountSettings = false; accountOpen = true },
                            fullScreen = true,
                            onSignOut = { confirmAccountLogout = true })
                    }
                }
                }

                } // Neutral destination theme

                    // 6.41.3: a permanent window-bottom overlay, OUTSIDE imePadding.
                    // Android's keyboard covers/reveals it; it never rides the resized body,
                    // unmounts its artwork/controls, or teleports during IME animation.
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .onSizeChanged { dockHeightPx = it.height }
                            .drawWithContent {
                                // No GPU work for a dock completely covered by the IME.
                                // Read pixels in draw, not composition; placement stays fixed.
                                if (imeInsets.getBottom(density).toFloat() < size.height) drawContent()
                            }
                            .bottomChrome()
                            .blockSurfaceInput()
                    ) {
                        current?.let { track ->
                            MiniPlayer(
                                vm = vm,
                                track = track,
                                isPlaying = playback.isPlaying,
                                onOpen = { accountOpen = false; accountSettings = false; playerOpen = true },
                                animateTitle = !mounted
                            )
                        }
                        ZiziTabBar(current = tab, onPick = { accountOpen = false; accountSettings = false; tab = it })
                        Spacer(Modifier.navigationBarsPadding())
                    }
                }

                if (mounted) {
                    var dragOffset by remember { mutableFloatStateOf(0f) }
                    // The child scrolls lyrics first. Only a downward remainder at the top
                    // moves the sheet. No second pointer detector or coroutine per drag delta.
                    val sheetScroll = remember(slide) {
                        object : NestedScrollConnection {
                            private fun move(delta: Float): Offset {
                                if (!playerOpen || slide.isRunning || screenHeight <= 0f) return Offset.Zero
                                val previous = dragOffset
                                dragOffset = (previous + delta).coerceIn(0f, screenHeight)
                                if (dragOffset > 0f) libraryDrawn.value = true
                                return Offset(0f, dragOffset - previous)
                            }
                            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
                                if (source == NestedScrollSource.UserInput && dragOffset > 0f) move(available.y) else Offset.Zero

                            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
                                if (source == NestedScrollSource.UserInput && available.y > 0f) move(available.y) else Offset.Zero

                            override suspend fun onPreFling(available: Velocity): Velocity {
                                if (dragOffset <= 0f) return Velocity.Zero
                                val position = dragOffset
                                slide.snapTo(position)
                                dragOffset = 0f
                                if (position > screenHeight * 0.16f || available.y > 1400f) playerOpen = false
                                else {
                                    slide.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium))
                                    if (slide.value == 0f) libraryDrawn.value = false
                                }
                                return Velocity(0f, available.y)
                            }
                        }
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer { translationY = slide.value + dragOffset }
                            .nestedScroll(sheetScroll)
                    ) {
                        ZiziBackdrop(palette)
                        PlayerScreen(
                            vm = vm,
                            state = library,
                            playback = playback,
                            currentTrack = current,
                            onClose = { playerOpen = false },
                            onOpenEqualizer = { eqOpen = true },
                            onPickFolder = onPickFolder,
                            onShare = onShare,
                            onDeleteFile = onDeleteFile
                        )
                    }
                }

                // Поверх всего, включая плеер: эквалайзер открывается из него и обязан его
                // перекрыть, иначе жест закрытия плеера ловится сквозь экран настройки звука.
                if (eqOpen) {
                    Box(Modifier.fillMaxSize()) {
                        ZiziBackdrop(palette)
                        ProvideAudioSpectrum(playing = playback.isPlaying) {
                            EqualizerScreen(vm = vm, onClose = { eqOpen = false })
                        }
                    }
                }

                if (profileEdit && !account.isGuest) {
                    CompositionLocalProvider(LocalPalette provides app.ziziplayer.ui.theme.basePalette()) {
                        AccountEditScreen(account, profile, onClose = { profileEdit = false })
                    }
                }
                if (confirmAccountLogout) androidx.compose.material3.AlertDialog(
                    onDismissRequest = { confirmAccountLogout = false },
                    title = { Text("Выйти из аккаунта?") },
                    text = { Text("Библиотека останется на телефоне. Перед выходом проверьте подтверждение облачного сохранения.") },
                    confirmButton = { androidx.compose.material3.TextButton(onClick = {
                        confirmAccountLogout = false; accountSettings = false; onSignOut()
                    }) { Text("Выйти") } },
                    dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmAccountLogout = false }) { Text("Отмена") } })

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .imePadding()
                        .padding(bottom = dockInset + 8.dp)
                )
            }

            } // AccountDrawerHost
            // Window-owned tint: never slides with the drawer, destination or player.
            StatusBarTint(Modifier.align(Alignment.TopCenter))
            }

            // Предпросмотр импорта живёт здесь, а не в медиатеке: плейлист может прийти из
            // мессенджера в любой момент, в том числе когда открыт плеер или поиск.
            pendingImport?.let { PlaylistImportSheet(vm, it) { vm.cancelImport() } }

            // Single back path: player -> drill-down -> app exit. The system side swipe follows it too.
            BackHandler(enabled = !profileEdit && !accountSettings) {
                focusManager.clearFocus(force = true)
                keyboard?.hide()
                when {
                    accountDrawer -> accountDrawer = false
                    accountOpen -> accountOpen = false
                    eqOpen -> eqOpen = false
                    playerOpen -> playerOpen = false
                    // Inside search, back unwinds the section's own stack first (collection ->
                    // results -> hub) and only then leaves the tab. Dropping straight to the
                    // library from a result list is the behaviour every user reads as a bug.
                    tab == ZiziTab.SEARCH && searchVm.back() -> Unit
                    tab == ZiziTab.SEARCH -> tab = ZiziTab.HOME
                    tab == ZiziTab.LIBRARY && vm.handleBack() -> Unit
                    tab == ZiziTab.LIBRARY -> tab = ZiziTab.HOME
                    tab == ZiziTab.HOME && homeVm.back() -> Unit
                    else -> onExit()
                }
            }
            }
          }
        }
    }
}

/**
 * Приветствие в собственной композиции: своя палитра, свой фон, ни одного потока медиатеки.
 *
 * Здесь сознательно НЕ используется подкраска обложкой: трека ещё нет, а первый экран приложения
 * обязан выглядеть одинаково у всех. Медиатека под окном не рисуется вообще — не только ради
 * кадра, но и ради смысла: пока человек не ответил, приложение не делает вид, что уже работает.
 */
@Composable
private fun WelcomeGate(
    signInOffered: Boolean,
    onSignIn: () -> Unit,
    onGuest: () -> Unit,
    onRegister: () -> Unit
) {
    val palette = app.ziziplayer.ui.theme.basePalette()
    CompositionLocalProvider(LocalPalette provides palette) {
        ZiziTheme(palette) {
            Box(Modifier.fillMaxSize()) {
                ZiziBackdrop(palette)
                WelcomeScreen(
                    signInOffered = signInOffered,
                    onSignIn = onSignIn,
                    onGuest = onGuest,
                    onRegister = onRegister
                )
            }
        }
    }
}
