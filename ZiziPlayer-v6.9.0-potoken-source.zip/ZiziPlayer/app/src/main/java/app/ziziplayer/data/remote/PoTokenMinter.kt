package app.ziziplayer.data.remote

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

/**
 * poToken: the attestation YouTube has been asking us for since 6.6.0 (NEW IN 6.9.0).
 *
 * ## What the previous four releases were actually fighting
 *
 * 6.8.1 asked eight different internal clients for a stream and got the same answer from every one
 * of them: `LOGIN_REQUIRED · «Войдите в аккаунт, чтобы подтвердить, что вы не бот»`, zero formats,
 * no URL. That result is not a bug in any of them - it is the whole ladder being answered by one
 * gate, and the gate is not asking for an account. It is asking for a *proof of origin*: a token
 * that can only be produced by running Google's own obfuscated JavaScript (BotGuard) in a real
 * browser engine, on the same session identity that is making the request.
 *
 * There is no way to compute that token from Kotlin. There is no endpoint that hands it out. The
 * only way to obtain one is to run the JavaScript. So we run it - once per session, in an
 * off-screen WebView, and then never again for hours.
 *
 * ## The shape of the thing
 *
 * ```
 *   visitorData (6.8.1)  ──┐
 *                          ├──► BotGuard in WebView ──► integrity token (TTL ~6 h)
 *   REQUEST_KEY (public) ──┘                                    │
 *                                                               ▼
 *                                              local minter function (pure, instant)
 *                                                    │                    │
 *                                    poToken(visitorData)          poToken(videoId)
 *                                    = SESSION token              = CONTENT token
 *                                    (player request +            (used by the browser-shaped
 *                                     `pot=` on the CDN URL)       clients)
 * ```
 *
 * The two-token split is not decoration. A poToken is *bound* to the identifier it was minted for,
 * and the server checks the binding: a token minted for our visitorData proves that this session is
 * a browser, and a token minted for a videoId proves that this playback is. Sending the wrong one
 * is the same as sending none. This is also, finally, the answer to why 6.8.1's visitorData work
 * was a prerequisite and not a detour: without a stable session identity there is nothing to bind a
 * session token to.
 *
 * ## Cost, honestly
 *
 *  - one WebView instance in the process, created lazily, on first remote playback, never shown;
 *  - about 1-3 s and two HTTPS requests for the first token of a session;
 *  - 0 ms and 0 requests for every token after that, including the per-track content tokens: the
 *    minter is a pure function that stays alive in the page;
 *  - one re-run when the integrity token expires (its own TTL, floored to 4 h by us) or when
 *    playback tells us a token was rejected ([invalidate]).
 *
 * ## Why this file cannot crash the app
 *
 * It is called from the Media3 loader thread through `runBlocking`, i.e. from the one place where a
 * hang is audible. So: every wait has a timeout, every failure is remembered rather than thrown, a
 * failed attempt backs off for ten minutes instead of retrying per track, and `session()` returning
 * null means "carry on exactly like 6.8.1 did". A WebView that refuses to work degrades the app to
 * its previous behaviour; it does not break it.
 *
 * ## Maintenance, also honestly
 *
 * This is the one node in the app that is expected to rot: it runs somebody else's obfuscated code
 * whose entry points move. Everything fragile is therefore *discovered* rather than hardcoded (see
 * the asset), and everything that can still break reports its own step name into the diagnostics
 * row, so the next fix starts from a sentence like `snapshot → snapshot не ответил за 15000 мс`
 * instead of from a bisect.
 */
object PoTokenMinter {

    private const val ASSET = "potoken/botguard.html"
    /** The origin the attestation service expects to be talking to. */
    private const val BASE_URL = "https://www.youtube.com/"
    /** Desktop Chrome: BotGuard is served to browsers and behaves differently for a WebView UA. */
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/131.0.0.0 Safari/537.36"

    /** Hard ceiling on one full attestation run, including page load. */
    private const val RUN_TIMEOUT_MS = 30_000L
    /** Never trust an integrity token longer than this, whatever TTL it claims. */
    private const val MAX_AGE_MS = 4 * 60 * 60 * 1000L
    /** After a failure, do not try again for this long - a broken WebView must not cost a probe per track. */
    private const val BACKOFF_MS = 10 * 60 * 1000L

    @Volatile private var appContext: Context? = null

    /** One run at a time, process wide: eight clients asking in parallel would mint eight times. */
    private val gate = Mutex()

    @Volatile private var web: WebView? = null
    @Volatile private var boundTo: String? = null
    @Volatile private var sessionToken: String? = null
    @Volatile private var mintedAtMs: Long = 0L
    @Volatile private var ttlMs: Long = 0L
    @Volatile private var lastError: String? = null
    @Volatile private var failedAtMs: Long = 0L
    @Volatile private var runs: Int = 0
    @Volatile private var lastRunMs: Long = 0L

    /** Content tokens are pure functions of a videoId, so they are cached for the session's lifetime. */
    private val contentTokens = HashMap<String, String>()

    fun install(context: Context) { appContext = context.applicationContext }

    private fun fresh(now: Long): Boolean {
        val token = sessionToken ?: return false
        if (token.isEmpty()) return false
        val age = now - mintedAtMs
        return age < minOf(if (ttlMs > 0) ttlMs else MAX_AGE_MS, MAX_AGE_MS)
    }

    /**
     * The session token for [visitorData], minting it if necessary.
     *
     * Null is a valid answer and means "no attestation available right now" - the caller sends the
     * request without it, which is exactly what 6.8.1 did.
     */
    suspend fun session(visitorData: String): String? {
        if (visitorData.isBlank()) return null
        val now = System.currentTimeMillis()
        if (boundTo == visitorData && fresh(now)) return sessionToken
        return gate.withLock {
            val inner = System.currentTimeMillis()
            // Somebody else may have minted while we waited for the lock.
            if (boundTo == visitorData && fresh(inner)) return@withLock sessionToken
            if (lastError != null && inner - failedAtMs < BACKOFF_MS) return@withLock null
            mint(visitorData)
        }
    }

    /**
     * A token bound to one video, for the browser-shaped clients.
     *
     * Requires a live minter, which means a successful [session] call first. It never triggers an
     * attestation run of its own: a per-track WebView run is exactly the cost this design exists to
     * avoid.
     */
    suspend fun content(videoId: String): String? {
        if (videoId.isBlank() || !fresh(System.currentTimeMillis())) return null
        synchronized(contentTokens) { contentTokens[videoId] }?.let { return it }
        val minted = try {
            withTimeout(4_000L) { evaluate("window.ziziMint(" + JSONObject.quote(videoId) + ")") }
        } catch (e: TimeoutCancellationException) {
            null
        } catch (e: Throwable) {
            null
        }
        if (minted.isNullOrEmpty()) return null
        synchronized(contentTokens) {
            if (contentTokens.size > 128) contentTokens.clear()
            contentTokens[videoId] = minted
        }
        return minted
    }

    /**
     * Called when a request carrying our token was refused anyway.
     *
     * The token is dropped but the backoff is not armed: a rejected token is a reason to mint a new
     * one, not a reason to stop trying.
     */
    fun invalidate() {
        sessionToken = null
        boundTo = null
        ttlMs = 0L
        synchronized(contentTokens) { contentTokens.clear() }
    }

    /** One line for the diagnostics dialog. Never guesses: it prints what actually happened. */
    fun diagnostics(): String {
        val now = System.currentTimeMillis()
        val token = sessionToken
        return when {
            token != null && fresh(now) -> {
                val ageMin = (now - mintedAtMs) / 60_000L
                "есть, " + token.length + " симв., возраст " + ageMin + " мин, минтов " + runs +
                    ", последний прогон " + lastRunMs + " мс"
            }
            lastError != null -> {
                val waitMin = ((BACKOFF_MS - (now - failedAtMs)).coerceAtLeast(0L)) / 60_000L
                "НЕТ · " + lastError + (if (waitMin > 0) " · повтор через " + waitMin + " мин" else "")
            }
            appContext == null -> "НЕТ · минтер не инициализирован"
            else -> "НЕТ · ещё не запрашивался"
        }
    }

    // ---------------------------------------------------------------- the run itself

    private suspend fun mint(visitorData: String): String? {
        val context = appContext ?: run {
            lastError = "нет Context (install не вызван)"
            failedAtMs = System.currentTimeMillis()
            return null
        }
        val html = try {
            context.assets.open(ASSET).use { it.readBytes().toString(Charsets.UTF_8) }
        } catch (e: Throwable) {
            lastError = "ассет не читается: " + e.javaClass.simpleName
            failedAtMs = System.currentTimeMillis()
            return null
        }

        val answer = CompletableDeferred<String>()
        val startedAt = System.currentTimeMillis()
        // A fresh page per run: the BotGuard VM is single-use, and reusing a page that already ran
        // once is how you get a snapshot that never calls back.
        withContext(Dispatchers.Main) { load(context, html, visitorData, answer) }

        val token = try {
            withTimeout(RUN_TIMEOUT_MS) { answer.await() }
        } catch (e: TimeoutCancellationException) {
            lastError = "прогон не завершился за " + RUN_TIMEOUT_MS + " мс"
            failedAtMs = System.currentTimeMillis()
            null
        } catch (e: Throwable) {
            lastError = e.message ?: e.javaClass.simpleName
            failedAtMs = System.currentTimeMillis()
            null
        }
        lastRunMs = System.currentTimeMillis() - startedAt
        if (token.isNullOrEmpty()) return null

        sessionToken = token
        boundTo = visitorData
        mintedAtMs = System.currentTimeMillis()
        lastError = null
        failedAtMs = 0L
        runs += 1
        synchronized(contentTokens) { contentTokens.clear() }
        return token
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun load(
        context: Context,
        html: String,
        visitorData: String,
        answer: CompletableDeferred<String>
    ) {
        // Reuse the WebView object (creating one is the expensive part) but always reload the page.
        val view = web ?: WebView(context).also { created ->
            created.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                userAgentString = UA
                // BotGuard fetches nothing but its own RPCs; everything else stays default-off.
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            created.addJavascriptInterface(Bridge, "ZiziPo")
            web = created
        }
        pending = answer
        identifier = visitorData
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                // The page defines the entry points on load; starting is our call, not its.
                view.evaluateJavascript(
                    "window.ziziStart(" + JSONObject.quote(identifier ?: "") + ")",
                    null
                )
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                // Only the document itself matters; a failed sub-resource is BotGuard's business.
                if (request?.isForMainFrame == true) {
                    val text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        error?.description?.toString() ?: "ошибка загрузки"
                    } else {
                        "ошибка загрузки"
                    }
                    Bridge.fail("load → " + text)
                }
            }
        }
        view.loadDataWithBaseURL(BASE_URL, html, "text/html", "utf-8", null)
    }

    @Volatile private var pending: CompletableDeferred<String>? = null
    @Volatile private var identifier: String? = null

    /** Minting after the first success is local, so this is a plain JS call with a value callback. */
    private suspend fun evaluate(script: String): String? {
        val view = web ?: return null
        val result = CompletableDeferred<String?>()
        withContext(Dispatchers.Main) {
            view.evaluateJavascript(script) { raw ->
                // evaluateJavascript hands back a JSON literal, so "abc" arrives with the quotes on.
                val value = when {
                    raw == null || raw == "null" -> null
                    raw.length >= 2 && raw.startsWith("\"") && raw.endsWith("\"") ->
                        JSONObject("{\"v\":" + raw + "}").optString("v", "")
                    else -> raw
                }
                result.complete(value?.takeIf { it.isNotEmpty() })
            }
        }
        return result.await()
    }

    /**
     * The JS -> Kotlin edge. Two methods, both terminal, both idempotent.
     *
     * `@JavascriptInterface` methods are called on a WebView-owned thread, never the main one, so
     * they only ever touch a CompletableDeferred - which is exactly what that type is for.
     */
    private object Bridge {

        @JavascriptInterface
        fun ready(payload: String?) {
            val deferred = pending ?: return
            val token = try {
                val json = JSONObject(payload ?: "{}")
                val ttlSeconds = json.optLong("ttl", 0L)
                if (ttlSeconds > 0) ttlMs = ttlSeconds * 1000L
                json.optString("token", "")
            } catch (e: Throwable) {
                ""
            }
            if (token.isEmpty()) deferred.completeExceptionally(IllegalStateException("минтер вернул пустой токен"))
            else deferred.complete(token)
        }

        @JavascriptInterface
        fun fail(message: String?) {
            pending?.completeExceptionally(IllegalStateException(message ?: "неизвестный сбой"))
        }
    }
}
