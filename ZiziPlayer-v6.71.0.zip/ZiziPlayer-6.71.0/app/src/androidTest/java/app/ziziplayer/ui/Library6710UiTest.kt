package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.screens.LibrarySearchBlock
import app.ziziplayer.ui.screens.LibraryToolbar
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Real Compose gesture tests. Run on an Android device/emulator; not source-test substitutes. */
class Library6710UiTest {
    @get:Rule val compose = createComposeRule()
    private val view = mutableStateOf(LibraryView.GRID)
    private val expanded = mutableStateOf(false)
    private val importing = mutableStateOf(false)

    private fun toolbar(width: Dp = 360.dp) {
        compose.setContent {
            Box(Modifier.width(width)) {
                LibraryToolbar("Недавние", view.value, expanded.value, importing.value,
                    onExpanded = { expanded.value = it }, onView = { view.value = it },
                    onSort = {}, onSearch = {}, onShuffle = {}, onImport = { importing.value = !importing.value })
            }
        }
    }
    @Test fun holdDoesNotCycle() {
        toolbar()
        compose.onNodeWithTag("library-view-toggle").performTouchInput { longClick() }
        compose.runOnIdle { assertTrue(expanded.value); assertEquals(LibraryView.GRID, view.value) }
        compose.onNodeWithTag("library-view-GRID").assertIsSelected()
        compose.onNodeWithTag("library-view-COMPACT").assertExists()
        compose.onNodeWithTag("library-view-LIST").assertExists()
        compose.onNodeWithTag("library-view-LARGE_GRID").assertExists()
    }
    @Test fun tapCycles() {
        toolbar()
        listOf(LibraryView.LARGE_GRID, LibraryView.COMPACT, LibraryView.LIST, LibraryView.GRID).forEach { next ->
            compose.onNodeWithTag("library-view-toggle").performClick()
            compose.runOnIdle { assertEquals(next, view.value); assertFalse(expanded.value) }
        }
    }
    @Test fun choosingModeCollapsesPicker() {
        toolbar()
        compose.onNodeWithTag("library-view-toggle").performTouchInput { longClick() }
        compose.onNodeWithTag("library-view-LIST").performClick()
        compose.runOnIdle { assertEquals(LibraryView.LIST, view.value); assertFalse(expanded.value) }
        compose.onNodeWithTag("library-view-toggle").assertExists()
        compose.onNodeWithTag("library-view-LIST").assertDoesNotExist()
    }
    @Test fun plusIsAToggleNotImmediateImport() {
        toolbar()
        compose.onNodeWithContentDescription("Показать импорт").performClick()
        compose.runOnIdle { assertTrue(importing.value) }
        compose.onNodeWithContentDescription("Скрыть импорт").performClick()
        compose.runOnIdle { assertFalse(importing.value) }
    }
    @Test fun narrowToolbarDoesNotOverlap() {
        toolbar(280.dp)
        compose.onNodeWithTag("library-view-toggle").performTouchInput { longClick() }
        compose.waitForIdle()
        val compact = compose.onNodeWithTag("library-view-COMPACT").fetchSemanticsNode().boundsInRoot
        val list = compose.onNodeWithTag("library-view-LIST").fetchSemanticsNode().boundsInRoot
        assertTrue("Options must not overlap", compact.right <= list.left + 1f)
        compose.onNodeWithTag("library-view-LARGE_GRID").performScrollTo().assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(LibraryView.LARGE_GRID, view.value) }
    }
    @Test fun searchClearsAndCloses() {
        val open = mutableStateOf(true)
        val query = mutableStateOf("")
        compose.setContent {
            LibrarySearchBlock(open.value, query.value, "Поиск по медиатеке",
                onQuery = { if (open.value) query.value = it },
                onClose = { open.value = false; query.value = "" })
        }
        compose.onNodeWithTag("library-search-field").performTextInput("night")
        compose.waitUntil(3000) { query.value == "night" }
        compose.onNodeWithContentDescription("Очистить поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertTextEquals("")
        compose.runOnIdle { assertEquals("", query.value) }
        compose.onNodeWithContentDescription("Закрыть поиск").performClick()
        compose.onNodeWithTag("library-search-field").assertDoesNotExist()
        compose.runOnIdle { assertFalse(open.value); assertEquals("", query.value) }
    }
}
