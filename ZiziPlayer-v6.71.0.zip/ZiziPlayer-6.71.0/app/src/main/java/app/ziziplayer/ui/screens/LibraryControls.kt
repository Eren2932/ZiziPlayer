package app.ziziplayer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.LibraryView
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziFontFamily
import kotlinx.coroutines.delay

internal fun libraryViewLabel(view: LibraryView): String = when (view) {
    LibraryView.COMPACT -> "Компактный список"
    LibraryView.LIST -> "Список с обложками"
    LibraryView.GRID -> "Три колонки"
    LibraryView.LARGE_GRID -> "Две колонки"
}

/** One width animation pushes the adjacent actions left; no overlay over their hit targets. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun LibraryToolbar(
    sortLabel: String,
    view: LibraryView,
    expanded: Boolean,
    importExpanded: Boolean,
    onExpanded: (Boolean) -> Unit,
    onView: (LibraryView) -> Unit,
    onSort: () -> Unit,
    onSearch: () -> Unit,
    onShuffle: () -> Unit,
    onImport: () -> Unit
) {
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    val panelWidth by animateDpAsState(if (expanded) 160.dp else 36.dp, tween(220), label = "library-view-width")
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val sortWidth = (maxWidth - 108.dp - panelWidth).coerceAtLeast(40.dp)
        // On a narrow split-screen the row scrolls instead of overlapping or losing actions.
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).height(48.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.width(sortWidth).height(48.dp).clip(RoundedCornerShape(8.dp))
                .clickable(role = Role.Button, onClickLabel = "Сортировка: $sortLabel", onClick = onSort)
                .padding(end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(ZiziIcons.SortSwap, "Сортировка", tint = p.text, modifier = Modifier.size(16.dp))
                if (sortWidth > 64.dp) {
                    Spacer(Modifier.width(7.dp))
                    Text(sortLabel, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            LibraryToolButton(ZiziIcons.Search, "Поиск по медиатеке", onSearch)
            LibraryToolButton(ZiziIcons.Shuffle, "Перемешать всё", onShuffle)
            LibraryToolButton(if (importExpanded) ZiziIcons.Close else ZiziIcons.Plus,
                if (importExpanded) "Скрыть импорт" else "Показать импорт", onImport)
            Box(Modifier.width(panelWidth).height(44.dp).clip(CircleShape)
                .background(if (expanded) p.chip else Color.Transparent)) {
                if (expanded) {
                    Row(Modifier.requiredWidth(160.dp).align(Alignment.CenterEnd)) {
                        listOf(LibraryView.COMPACT, LibraryView.LIST, LibraryView.GRID, LibraryView.LARGE_GRID).forEach { option ->
                            val active = view == option
                            Box(Modifier.size(40.dp, 44.dp).padding(vertical = 2.dp).clip(CircleShape)
                                .background(if (active) p.text else Color.Transparent)
                                .semantics { selected = active; contentDescription = libraryViewLabel(option) }
                                .testTag("library-view-${option.name}")
                                .clickable(role = Role.RadioButton) { onView(option); onExpanded(false) },
                                contentAlignment = Alignment.Center) {
                                LibraryViewGlyph(option, if (active) p.surface else p.subtext)
                            }
                        }
                    }
                } else {
                    Box(Modifier.align(Alignment.CenterEnd).size(36.dp, 44.dp)
                        .testTag("library-view-toggle")
                        .semantics { contentDescription = "Вид: ${libraryViewLabel(view)}" }
                        .combinedClickable(role = Role.Button,
                            onClickLabel = "Следующий вид",
                            onLongClickLabel = "Выбрать вид медиатеки",
                            onClick = { onView(view.next()) },
                            onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onExpanded(true) }),
                        contentAlignment = Alignment.Center) {
                        LibraryViewGlyph(view, p.text)
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryToolButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(Modifier.size(36.dp, 48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Icon(icon, label, tint = LocalPalette.current.text, modifier = Modifier.size(22.dp))
    }
}

/** The four silhouettes match the supplied segmented-control reference. */
@Composable
private fun LibraryViewGlyph(view: LibraryView, tint: Color) {
    Canvas(Modifier.size(21.dp)) {
        val u = size.width / 24f
        val stroke = Stroke(1.7f * u)
        if (view == LibraryView.COMPACT || view == LibraryView.LIST) {
            repeat(4) { row ->
                val y = (3f + row * 5.5f) * u
                if (view == LibraryView.COMPACT) drawCircle(tint, 1.15f * u, Offset(2.5f * u, y + u))
                else drawRoundRect(tint, Offset(u, y - u), Size(3.8f * u, 3.8f * u), CornerRadius(0.4f * u), style = stroke)
                drawLine(tint, Offset(8f * u, y + u), Offset(22f * u, y + u), 1.9f * u, StrokeCap.Round)
            }
        } else {
            val columns = view.columns
            val box = if (columns == 3) 4.5f else 8f
            val gap = if (columns == 3) 3f else 4f
            repeat(columns) { col ->
                val x = (1.5f + col * (box + gap)) * u
                repeat(if (columns == 3) 2 else 1) { row ->
                    drawRoundRect(tint, Offset(x, (2f + row * 8f) * u), Size(box * u, box * u), CornerRadius(0.5f * u), style = stroke)
                }
                val lineY = if (columns == 3) 20f else 15f
                drawLine(tint, Offset(x, lineY * u), Offset(x + box * u, lineY * u), 1.7f * u, StrokeCap.Round)
                if (columns == 2) drawLine(tint, Offset(x, 20f * u), Offset(x + 5f * u, 20f * u), 1.7f * u, StrokeCap.Round)
            }
        }
    }
}

internal const val LIBRARY_SEARCH_MS = 180

/** Separate full-width search block. Closing never leaves an invisible focus/IME owner. */
@Composable
internal fun LibrarySearchBlock(
    open: Boolean,
    query: String,
    hint: String,
    onQuery: (String) -> Unit,
    onClose: () -> Unit
) {
    val p = LocalPalette.current
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val requester = remember { FocusRequester() }
    DisposableEffect(Unit) { onDispose { focus.clearFocus(); keyboard?.hide() } }
    var text by remember(open) { mutableStateOf(query) }
    val latestQuery by rememberUpdatedState(onQuery)
    LaunchedEffect(text, open) {
        if (!open) return@LaunchedEffect
        delay(130)
        if (text != query) latestQuery(text)
    }
    LaunchedEffect(open) {
        if (open) {
            delay(LIBRARY_SEARCH_MS.toLong())
            withFrameNanos { }
            requester.requestFocus()
            keyboard?.show()
        } else {
            focus.clearFocus()
            keyboard?.hide()
        }
    }
    AnimatedVisibility(open, enter = expandVertically(tween(LIBRARY_SEARCH_MS)) + fadeIn(),
        exit = shrinkVertically(tween(LIBRARY_SEARCH_MS)) + fadeOut()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp)).background(p.chip).padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(ZiziIcons.Search, null, tint = p.subtext, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            BasicTextField(value = text, onValueChange = { text = it }, enabled = open, singleLine = true,
                textStyle = TextStyle(fontFamily = ZiziFontFamily, color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.brand),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { latestQuery(text); focus.clearFocus(); keyboard?.hide() }),
                modifier = Modifier.weight(1f).focusRequester(requester).testTag("library-search-field")
                    .semantics { contentDescription = hint },
                decorationBox = { inner ->
                    Box { if (text.isEmpty()) Text(hint, color = p.subtext, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); inner() }
                })
            if (text.isNotEmpty()) LibraryToolButton(ZiziIcons.Close, "Очистить поиск") { text = ""; latestQuery("") }
            LibraryToolButton(ZiziIcons.ArrowBack, "Закрыть поиск") { if (open) onClose() }
        }
    }
}
