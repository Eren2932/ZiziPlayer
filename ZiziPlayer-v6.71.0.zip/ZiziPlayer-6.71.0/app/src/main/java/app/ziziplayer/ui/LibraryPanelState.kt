package app.ziziplayer.ui

/** Transient chrome state, owned by MainViewModel so the root Back owner can unwind it. */
data class LibraryPanelState(val viewExpanded: Boolean = false, val importExpanded: Boolean = false) {
    val isOpen: Boolean get() = viewExpanded || importExpanded
    fun dismissTop(): LibraryPanelState = if (viewExpanded) copy(viewExpanded = false) else copy(importExpanded = false)
}
