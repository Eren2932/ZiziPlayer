package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.Closeable
import java.nio.file.Path
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import java.util.prefs.Preferences

/** Stable identity is never a resolved URL. Remote playback does not add to the library. */
data class PlayerTrack(val source: String, val title: String, val artist: String = "", val durationMs: Long? = null,
    val artworkUrl: String? = null, val artwork: ByteArray? = null) {
    val id: String get() = source
    override fun toString(): String = "PlayerTrack(redacted)"
}
enum class PlaybackPhase { IDLE, LOADING, PLAYING, PAUSED, ENDED, ERROR }
data class PlayerState(val track: PlayerTrack? = null, val phase: PlaybackPhase = PlaybackPhase.IDLE, val generation: Long = 0,
    val message: String = "Выбери музыку", val seekable: Boolean = false)
data class PlayerProgress(val trackId: String? = null, val generation: Long = 0, val positionMs: Long = 0, val durationMs: Long? = null)

/** Public commands run on the supplied UI scope. Blocking I/O and audio have separate owners.
 * The generation invalidates all late metadata, completion and progress events immediately.
 */
class DesktopPlayer(
    private val scope: CoroutineScope,
    private val decoderFactory: (String, String, Long) -> Decoder = { exe, input, offset -> FfmpegDecoder(exe, input, offset) },
    private val sinkFactory: () -> Sink = { JavaSoundSink(160) },
    private val metadataReader: (String, String, Boolean) -> Metadata.Info = Metadata::read
) {
    private val mutableState = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = mutableState.asStateFlow()
    private val mutableProgress = MutableStateFlow(PlayerProgress())
    val progress: StateFlow<PlayerProgress> = mutableProgress.asStateFlow()
    private val mutableMetadata = MutableStateFlow<Map<String, PlayerTrack>>(emptyMap())
    val metadata: StateFlow<Map<String, PlayerTrack>> = mutableMetadata.asStateFlow()
    var queue: List<PlayerTrack> = emptyList(); private set
    var gain = 0.35f; private set
    var config = DspConfig.NEUTRAL; private set
    var ffmpeg = System.getenv("FFMPEG_PATH")?.takeIf { it.isNotBlank() } ?: if (System.getProperty("os.name").startsWith("Windows")) "ffmpeg.exe" else "ffmpeg"
    var client: ZiziClient? = null
    private var generation = 0L
    private var desiredPaused = false
    private var handover: Job? = null
    private var worker: Job? = null
    private var controls: Controls? = null
    private var closed = false
    private val handoverLock = Mutex()
    private val currentSink = AtomicReference<Sink?>()
    private val currentDecoder = AtomicReference<Decoder?>()
    private val currentBridge = AtomicReference<StreamBridge?>()
    private var ticker: Job? = null

    fun volume(value: Float) { if (value.isFinite()) { gain = value.coerceIn(0f, 1f); controls?.gain?.set(gain) } }
    fun dsp(value: DspConfig) { config = value.sanitized(); controls?.config?.set(config) }
    fun play(track: PlayerTrack, tracks: List<PlayerTrack> = queue) {
        if (closed) return
        queue = if (tracks.any { it.id == track.id }) tracks.toList() else listOf(track)
        launchTrack(mutableMetadata.value[track.id] ?: track, 0, false)
    }
    fun adjacent(delta: Int) {
        val i = queue.indexOfFirst { it.id == state.value.track?.id }
        queue.getOrNull(if (i < 0) 0 else i + delta)?.let { play(it) }
    }
    fun togglePause() {
        if (closed) return
        val s = state.value
        if (s.phase in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.ERROR)) {
            (s.track ?: queue.firstOrNull())?.let { play(it) }; return
        }
        desiredPaused = !desiredPaused
        controls?.pause(desiredPaused)
        mutableState.value = s.copy(phase = if (desiredPaused) PlaybackPhase.PAUSED else if (s.phase == PlaybackPhase.LOADING) PlaybackPhase.LOADING else PlaybackPhase.PLAYING,
            message = if (desiredPaused) "Пауза" else "Воспроизведение")
    }
    fun seek(positionMs: Long) {
        val s = state.value; val duration = s.track?.durationMs ?: return
        if (!s.seekable || closed) return
        launchTrack(s.track, positionMs.coerceIn(0, (duration - 1).coerceAtLeast(0)), desiredPaused)
    }
    private suspend fun releasePrevious() {
        // Resource handover must finish even when superseded by a newer command.
        withContext(NonCancellable + Dispatchers.IO) {
            controls?.stop()
            currentSink.getAndSet(null)?.let { runCatching { it.interrupt() } }
            currentDecoder.getAndSet(null)?.let { runCatching { it.close() } }
            currentBridge.getAndSet(null)?.let { runCatching { it.close() } }
            worker?.cancelAndJoin()
        }
        controls = null; worker = null
    }
    private fun launchTrack(original: PlayerTrack, offset: Long, paused: Boolean) {
        generation++; val ticket = generation
        desiredPaused = paused
        ticker?.cancel(); handover?.cancel()
        mutableState.value = PlayerState(original, PlaybackPhase.LOADING, ticket, "Открываем источник…", false)
        mutableProgress.value = PlayerProgress(original.id, ticket, offset, original.durationMs)
        handover = scope.launch {
            handoverLock.withLock {
                releasePrevious(); ensureActive()
                val control = Controls("off", gain).also { it.config.set(config); it.pause(desiredPaused) }
                controls = control
                val exe = ffmpeg; val api = client
                worker = scope.launch(Dispatchers.IO) {
                    var bridge: StreamBridge? = null
                    var decoder: Decoder? = null
                    var sink: Sink? = null
                    try {
                        val remote = original.source.startsWith("zizi://")
                        val network = remote || original.source.startsWith("https://") || original.source.startsWith("http://")
                        val input = if (network) {
                            val target = runInterruptible {
                                if (remote) (api ?: error("SERVER_NOT_CONFIGURED")).resolve(original.source)
                                else StreamTarget(HttpTransport.safeUri(original.source)) { emptyMap() }
                            }
                            ensureActive()
                            StreamBridge(target).also { bridge = it; currentBridge.set(it) }.input
                        } else original.source
                        var track = original
                        if (track.durationMs == null) {
                            val info = try { runInterruptible { metadataReader(exe, input, !network) } }
                                catch (e: CancellationException) { throw e } catch (_: Exception) { null }
                            info?.let { track = track.copy(title = if (!network) it.title ?: track.title else track.title,
                                artist = if (!network) it.artist ?: track.artist else track.artist, durationMs = it.durationMs, artwork = it.cover ?: track.artwork) }
                        }
                        ensureActive()
                        decoder = decoderFactory(exe, input, offset).also { currentDecoder.set(it) }
                        ensureActive()
                        sink = sinkFactory().also { currentSink.set(it) }
                        val audioSink = sink
                        val resolvedTrack = track
                        scope.launch {
                            if (generation == ticket) {
                                if (!network) {
                                    val cache = LinkedHashMap(mutableMetadata.value)
                                    cache.remove(track.id); cache[track.id] = track
                                    while (cache.size > 64) cache.remove(cache.keys.first())
                                    mutableMetadata.value = cache
                                }
                                mutableState.value = PlayerState(resolvedTrack, if (desiredPaused) PlaybackPhase.PAUSED else PlaybackPhase.LOADING,
                                    ticket, if (desiredPaused) "Пауза" else "Буферизация…", track.durationMs != null)
                                ticker = scope.launch {
                                    while (generation == ticket && isActive) {
                                        val frames = audioSink.playedFrames()
                                        val position = (offset + frames * 1000 / Pcm.RATE).let { p -> track.durationMs?.let { p.coerceAtMost(it) } ?: p }
                                        mutableProgress.value = PlayerProgress(track.id, ticket, position, track.durationMs)
                                        if (frames > 0 && !desiredPaused && mutableState.value.phase == PlaybackPhase.LOADING)
                                            mutableState.value = mutableState.value.copy(phase = PlaybackPhase.PLAYING, message = "Воспроизведение")
                                        delay(100)
                                    }
                                }
                            }
                        }
                        val result = AudioEngine(control, 300).play(decoder, audioSink)
                        scope.launch {
                            if (generation == ticket) {
                                ticker?.cancel()
                                if (!result.cancelled) {
                                    val end = offset + result.frames * 1000 / Pcm.RATE
                                    mutableProgress.value = PlayerProgress(track.id, ticket, end, track.durationMs)
                                    mutableState.value = mutableState.value.copy(phase = PlaybackPhase.ENDED, message = "Трек завершён")
                                    val i = queue.indexOfFirst { it.id == track.id }
                                    if (i >= 0) queue.getOrNull(i + 1)?.let { play(it) }
                                }
                            }
                        }
                    } catch (_: CancellationException) { /* Superseded request, not a playback error. */ }
                    catch (e: Exception) {
                        scope.launch {
                            if (generation == ticket && !control.stopped.get()) {
                                ticker?.cancel()
                                val message = when {
                                    e is NetworkFailure -> when (e.code) {
                                        401 -> "Сервер: проверь токен доступа"
                                        403 -> "Сервер отказал в доступе"
                                        429 -> "Квота сервера исчерпана. Повтори позже"
                                        else -> "Сервер ответил HTTP ${e.code}"
                                    }
                                    remoteMissing(original, api) -> "Укажи HTTPS-сервер в настройках"
                                    else -> "Не удалось воспроизвести. Проверь источник, сеть, FFmpeg и аудиоустройство"
                                }
                                mutableState.value = mutableState.value.copy(phase = PlaybackPhase.ERROR, message = message, seekable = false)
                            }
                        }
                    } finally {
                        runCatching { sink?.close() }; runCatching { decoder?.close() }; runCatching { bridge?.close() }
                        sink?.let { currentSink.compareAndSet(it, null) }
                        decoder?.let { currentDecoder.compareAndSet(it, null) }
                        bridge?.let { currentBridge.compareAndSet(it, null) }
                    }
                }
            }
        }
    }
    private fun remoteMissing(track: PlayerTrack, api: ZiziClient?) = track.source.startsWith("zizi://") && api == null
    fun stop(after: (() -> Unit)? = null) {
        generation++; ticker?.cancel(); handover?.cancel(); desiredPaused = false
        mutableState.value = state.value.copy(phase = PlaybackPhase.IDLE, generation = generation, message = "Остановлено", seekable = false)
        mutableProgress.value = PlayerProgress(state.value.track?.id, generation, 0, state.value.track?.durationMs)
        handover = scope.launch { handoverLock.withLock { releasePrevious() }; after?.invoke() }
    }
    fun close(after: () -> Unit) { closed = true; stop(after) }
}

/** Only nonsecret preferences; tokens intentionally live in ZiziClient memory for this preview. */
object DesktopPreferences {
    private val prefs = Preferences.userRoot().node("app/ziziplayer/desktop")
    val installId: String = prefs.get("installId", "").ifBlank { UUID.randomUUID().toString().also { prefs.put("installId", it) } }
    var server: String get() = prefs.get("server", ""); set(value) { prefs.put("server", value) }
    var ffmpeg: String get() = prefs.get("ffmpeg", ""); set(value) { prefs.put("ffmpeg", value) }
}
