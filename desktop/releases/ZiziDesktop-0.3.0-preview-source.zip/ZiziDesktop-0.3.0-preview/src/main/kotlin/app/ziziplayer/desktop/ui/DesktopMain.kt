package app.ziziplayer.desktop.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.ziziplayer.desktop.*
import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.ZiziIcons
import java.io.File
import javax.imageio.ImageIO
import javax.swing.JFileChooser
import javax.swing.filechooser.FileNameExtensionFilter
import kotlinx.coroutines.*

private val Brand = Color(0xFFF97316)
private val Base = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Muted = Color(0xFF9A9A9A)

private class DesktopUi(val scope: CoroutineScope) {
    val player = DesktopPlayer(scope)
    var tracks by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var results by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    var searchMessage by mutableStateOf("Поиск по серверному каталогу Deezer · звук через YouTube")
    var config by mutableStateOf(DspConfig.NEUTRAL); private set
    var gain by mutableStateOf(0.35f); private set
    var client by mutableStateOf<ZiziClient?>(null); private set
    var server by mutableStateOf(DesktopPreferences.server)
    var ffmpeg by mutableStateOf(DesktopPreferences.ffmpeg.ifBlank { player.ffmpeg })
    private var searchJob: Job? = null
    init { player.ffmpeg = ffmpeg }
    fun add(files: List<File>) { tracks = (tracks + files.map { PlayerTrack(it.absolutePath, it.nameWithoutExtension) }).distinctBy { it.id } }
    fun addSource(raw: String) {
        val source = raw.trim()
        if (source.startsWith("zizi://")) RemoteIdentity.parse(source) else HttpTransport.safeUri(source)
        val name = if (source.startsWith("zizi://")) "Трек Zizi · ${RemoteIdentity.parse(source).first.uppercase()}" else "Сетевой трек"
        tracks = (tracks + PlayerTrack(source, name)).distinctBy { it.id }
    }
    fun dsp(value: DspConfig) { player.dsp(value); config = player.config }
    fun volume(value: Float) { player.volume(value); gain = player.gain }
    fun connect(base: String, token: String, executable: String) {
        val api = if (base.isBlank()) null else ZiziClient(base, token, DesktopPreferences.installId)
        searchJob?.cancel(); results = emptyList(); searching = false
        server = base.trim().trimEnd('/'); ffmpeg = executable.trim().removeSurrounding("\"")
        client = api; player.client = api; player.ffmpeg = ffmpeg
        DesktopPreferences.server = server; DesktopPreferences.ffmpeg = ffmpeg
        searchMessage = if (api == null) "Укажи сервер в настройках" else "Настройки применены. Введи запрос для проверки подключения"
    }
    fun search(query: String) {
        searchJob?.cancel(); results = emptyList()
        val api = client
        if (api == null) { searching = false; searchMessage = "Открой настройки и подключи сервер"; return }
        if (query.isBlank()) { searching = false; searchMessage = "Введи название трека или исполнителя"; return }
        searching = true; searchMessage = "Ищем музыку…"
        searchJob = scope.launch {
            try {
                val found = runInterruptible(Dispatchers.IO) { api.search(query.trim()) }
                results = found; searchMessage = if (found.isEmpty()) "Ничего не найдено" else "${found.size} треков · нажми для воспроизведения"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                searchMessage = if (e is NetworkFailure) when (e.code) {
                    401 -> "Неверный токен. Проверь настройки сервера"
                    429 -> "Слишком много запросов. Повтори позже"
                    else -> "Ошибка сервера HTTP ${e.code}"
                } else "Не удалось подключиться: проверь адрес, TLS и сеть"
            } finally { if (isActive) searching = false }
        }
    }
}

private data class CoverData(val image: ImageBitmap, val accent: Color)
private object Covers {
    private val cache = object : LinkedHashMap<String, CoverData>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CoverData>?): Boolean = size > 64
    }
    fun load(track: PlayerTrack, api: ZiziClient?): CoverData? {
        if (track.artwork == null && (track.artworkUrl == null || api == null)) return null
        val key = track.id + ":" + System.identityHashCode(api) + ":" + System.identityHashCode(track.artwork)
        synchronized(cache) { cache[key] }?.let { return it }
        return runCatching {
            val bytes = track.artwork ?: api!!.artwork(track.artworkUrl!!)
            ImageIO.createImageInputStream(bytes.inputStream()).use { input ->
                val readers = ImageIO.getImageReaders(input)
                check(readers.hasNext())
                val reader = readers.next()
                try {
                    reader.input = input
                    val w = reader.getWidth(0); val h = reader.getHeight(0)
                    require(w in 1..8192 && h in 1..8192 && w.toLong() * h <= 20_000_000)
                    val parameters = reader.defaultReadParam
                    val scale = maxOf(w, h) / 480
                    if (scale > 1) parameters.setSourceSubsampling(scale, scale, 0, 0)
                    val image = reader.read(0, parameters)
                    var r = 0L; var g = 0L; var b = 0L; var count = 0
                    for (y in 0 until image.height step 6) for (x in 0 until image.width step 6) {
                        val c = image.getRGB(x, y); r += c shr 16 and 255; g += c shr 8 and 255; b += c and 255; count++
                    }
                    CoverData(image.toComposeImageBitmap(), Color((r / count).toInt(), (g / count).toInt(), (b / count).toInt()))
                        .also { synchronized(cache) { cache[key] = it } }
                } finally { reader.dispose() }
            }
        }.getOrNull()
    }
}
@Composable private fun coverData(track: PlayerTrack?, api: ZiziClient?): CoverData? {
    val cover by produceState<CoverData?>(null, track?.id, track?.artwork, api) {
        value = null
        if (track != null) value = withContext(Dispatchers.IO) { Covers.load(track, api) }
    }
    return cover
}
@Composable private fun Artwork(track: PlayerTrack?, api: ZiziClient?, size: Dp) {
    val cover = coverData(track, api)
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Panel), contentAlignment = Alignment.Center) {
        if (cover != null) Image(cover.image, "Обложка", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(ZiziIcons.FolderMusic, null, Modifier.size(size * 0.4f), tint = Muted)
    }
}
private fun chooseFiles(): List<File> {
    val picker = JFileChooser().apply {
        dialogTitle = "Добавить музыку в Zizi"; isMultiSelectionEnabled = true
        fileFilter = FileNameExtensionFilter("Аудио", "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFiles.toList() else emptyList()
}
private fun time(ms: Long): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(seconds / 60, seconds % 60) }

fun main() = application {
    val scope = rememberCoroutineScope()
    val ui = remember { DesktopUi(scope) }
    var closing by remember { mutableStateOf(false) }
    Window(onCloseRequest = { if (!closing) { closing = true; ui.player.close { exitApplication() } } },
        title = "ZiziPlayer · Desktop 0.3 preview", state = rememberWindowState(width = 1240.dp, height = 820.dp)) {
        LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(920, 650) }
        MaterialTheme(colorScheme = darkColorScheme(primary = Brand, onPrimary = Color.Black, background = Base, surface = Panel)) {
            Surface(Modifier.fillMaxSize(), color = Base) { DesktopContent(ui, closing) }
        }
    }
}
@Composable private fun DesktopContent(s: DesktopUi, closing: Boolean) {
    val state by s.player.state.collectAsState()
    val metadata by s.player.metadata.collectAsState()
    var page by remember { mutableStateOf("Медиатека") }
    var query by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(false) }
    var sourceDialog by remember { mutableStateOf(false) }
    var effects by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    val cover = coverData(state.track, s.client)
    Column(Modifier.fillMaxSize().onKeyEvent {
        if (!editing && !settings && !sourceDialog && !closing && it.type == KeyEventType.KeyUp && it.key == Key.Spacebar) {
            s.player.togglePause(); true
        } else false
    }) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.width(184.dp).fillMaxHeight().background(Color(0xFF111111)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Zizi", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("DESKTOP · 0.3 PREVIEW", color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(16.dp))
                for ((label, icon) in listOf("Медиатека" to ZiziIcons.FolderMusic, "Поиск" to ZiziIcons.Search, "Очередь" to ZiziIcons.Queue)) {
                    TextButton(onClick = { page = label; query = "" }, modifier = Modifier.fillMaxWidth()) {
                        Icon(icon, null, tint = if (page == label) Brand else Muted)
                        Spacer(Modifier.width(10.dp)); Text(label, color = if (page == label) Color.White else Muted)
                    }
                }
                HorizontalDivider()
                TextButton(onClick = { s.add(chooseFiles()) }, enabled = !closing) { Text("Добавить файлы") }
                TextButton(onClick = { sourceDialog = true }) { Text("Открыть ссылку") }
                Spacer(Modifier.weight(1f))
                Text(if (s.client != null) "Сервер настроен" else "Сервер не подключён", color = Muted, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { settings = true }) { Icon(ZiziIcons.Server, null); Spacer(Modifier.width(8.dp)); Text("Настройки") }
            }
            Column(Modifier.weight(1f).fillMaxHeight().background(Brush.verticalGradient(listOf((cover?.accent ?: Brand).copy(alpha = 0.15f), Base))).padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(page, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { effects = !effects }) { Icon(ZiziIcons.Equalizer, "Звук Zizi", tint = if (effects) Brand else Color.White) }
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(query, { query = it }, singleLine = true,
                        placeholder = { Text(if (page == "Поиск") "Что хочешь послушать?" else "Найти в списке") },
                        leadingIcon = { Icon(ZiziIcons.Search, null) }, modifier = Modifier.weight(1f).onFocusChanged { editing = it.isFocused }.onPreviewKeyEvent {
                            if (page == "Поиск" && it.key == Key.Enter && it.type == KeyEventType.KeyUp) { s.search(query); true } else false
                        })
                    if (page == "Поиск") Button(onClick = { s.search(query) }, enabled = query.isNotBlank() && !s.searching) { Text("Найти") }
                }
                Spacer(Modifier.height(16.dp))
                val all = when (page) { "Поиск" -> s.results; "Очередь" -> s.player.queue; else -> s.tracks }
                val visible = if (page == "Поиск") all else all.filter { (it.title + " " + it.artist).contains(query, true) }
                Text(if (page == "Поиск") s.searchMessage else "${all.size} треков · список этой сессии", color = Muted, style = MaterialTheme.typography.bodySmall)
                if (s.searching && page == "Поиск") LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 10.dp))
                Spacer(Modifier.height(12.dp))
                if (visible.isEmpty() && !s.searching) {
                    Column(Modifier.fillMaxWidth().padding(top = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(if (page == "Поиск") ZiziIcons.Search else ZiziIcons.FolderMusic, null, Modifier.size(64.dp), tint = Brand)
                        Spacer(Modifier.height(18.dp))
                        Text(if (page == "Поиск") "Твоя музыка — не только на диске" else "Здесь будет твоя музыка", style = MaterialTheme.typography.titleLarge)
                        Text(if (page == "Поиск") "Подключи свой сервер в настройках и найди первый трек" else "Добавь файлы или открой zizi://-ссылку", color = Muted, modifier = Modifier.padding(top = 8.dp))
                    }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(visible, key = { it.id }) { original ->
                        val selected = original.id == state.track?.id
                        val track = if (selected) state.track!! else metadata[original.id] ?: original
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Brand.copy(alpha = 0.12f) else Color.Transparent)
                            .clickable(enabled = !closing) { s.player.play(track, all) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Artwork(track, s.client, 54.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (selected) Brand else Color.White)
                                Text(track.artist.ifBlank { if (track.source.startsWith("zizi://")) "Поток Zizi" else if (track.source.startsWith("http")) "Сетевое аудио" else "Локальный файл" }, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(track.durationMs?.let(::time) ?: "—", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (effects) EffectsPanel(s, Modifier.width(300.dp).fillMaxHeight().background(Panel).padding(18.dp))
        }
        Transport(s, closing) { expanded = true }
    }
    if (settings) SettingsDialog(s) { settings = false }
    if (sourceDialog) SourceDialog(s) { sourceDialog = false }
    if (expanded) AlertDialog(onDismissRequest = { expanded = false }, title = { Text("Сейчас играет") }, text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Artwork(state.track, s.client, 280.dp); Spacer(Modifier.height(16.dp))
            Text(state.track?.title ?: "Музыка не выбрана", style = MaterialTheme.typography.titleLarge)
            Text(state.track?.artist.orEmpty(), color = Muted)
        }
    }, confirmButton = { TextButton(onClick = { expanded = false }) { Text("Свернуть") } })
}
@Composable private fun Transport(s: DesktopUi, closing: Boolean, expand: () -> Unit) {
    val state by s.player.state.collectAsState()
    val progress by s.player.progress.collectAsState()
    val valid = progress.trackId == state.track?.id && progress.generation == state.generation
    val duration = if (valid) progress.durationMs ?: 0 else 0
    val position = if (valid) progress.positionMs else 0
    var drag by remember(state.generation) { mutableStateOf<Float?>(null) }
    HorizontalDivider(color = Color(0xFF292929))
    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 22.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(time((drag?.toLong() ?: position)), color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            Slider(value = drag ?: position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
                onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { s.player.seek(it.toLong()) }; drag = null },
                enabled = state.seekable && duration > 0 && !closing, valueRange = 0f..duration.coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f).height(24.dp))
            Text(if (duration > 0) time(duration) else "—:—", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 12.dp).width(48.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.clickable(onClick = expand)) { Artwork(state.track, s.client, 54.dp) }
            Column(Modifier.weight(1f)) {
                Text(state.track?.title ?: "Zizi готов к музыке", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(if (closing) "Закрываем аудиосеанс…" else state.message, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { s.player.adjacent(-1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipPrevious, "Предыдущий трек") }
            FilledIconButton(onClick = { s.player.togglePause() }, enabled = !closing && state.track != null, modifier = Modifier.size(52.dp)) {
                val pauses = state.phase in setOf(PlaybackPhase.PLAYING, PlaybackPhase.LOADING)
                Icon(if (pauses) ZiziIcons.Pause else ZiziIcons.PlayFilled, if (pauses) "Пауза" else "Воспроизвести")
            }
            IconButton(onClick = { s.player.adjacent(1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipNext, "Следующий трек") }
            IconButton(onClick = { s.player.stop() }, enabled = !closing && state.track != null) { Icon(ZiziIcons.Stop, "Остановить") }
            Text("${(s.gain * 100).toInt()}%", color = Muted)
            Slider(s.gain, s::volume, modifier = Modifier.width(110.dp))
        }
    }
}
@Composable private fun SettingsDialog(s: DesktopUi, dismiss: () -> Unit) {
    var base by remember { mutableStateOf(s.server) }
    var token by remember { mutableStateOf("") }
    var executable by remember { mutableStateOf(s.ffmpeg) }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, title = { Text("Подключение Zizi") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("URL и путь сохраняются. Токен — только в памяти до закрытия приложения. Применение заменяет текущий токен; повторно введи его при изменении настроек.", color = Muted)
            OutlinedTextField(base, { base = it }, label = { Text("HTTPS-адрес сервера") }, singleLine = true)
            OutlinedTextField(token, { token = it }, label = { Text("Bootstrap-токен") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(executable, { executable = it }, label = { Text("Путь к FFmpeg") }, singleLine = true)
            TextButton(onClick = { val picker = JFileChooser(); if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) executable = picker.selectedFile.absolutePath }) { Text("Выбрать FFmpeg…") }
            Text("ffprobe должен лежать рядом с FFmpeg: он читает длительность и теги. Изменения аудио применяются при следующем открытии трека.", color = Muted, style = MaterialTheme.typography.bodySmall)
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        try { s.connect(base, token, executable); token = ""; dismiss() }
        catch (_: Exception) { error = "Проверь HTTPS-адрес: без логина, query и fragment. Для локального теста разрешён HTTP loopback." }
    }) { Text("Применить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun SourceDialog(s: DesktopUi, dismiss: () -> Unit) {
    var source by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, title = { Text("Открыть ссылку") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("zizi://dz/ID, zizi://yt/VIDEO_ID, zizi://mix/dz%3AID или прямая HTTPS-ссылка на аудио. Не страница YouTube. HLS/DASH и HTTP-редиректы пока не поддерживаются.")
            OutlinedTextField(source, { source = it }, singleLine = true, label = { Text("Адрес трека") })
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        try { s.addSource(source); source = ""; dismiss() } catch (_: Exception) { error = "Некорректная или неподдерживаемая ссылка" }
    }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable
private fun EffectsPanel(s: DesktopUi, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Звук Zizi", style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DSP", Modifier.weight(1f)); Switch(s.config.enabled, { s.dsp(s.config.copy(enabled = it)) })
        }
        Text("Оригинальные пресеты 6.39.9", style = MaterialTheme.typography.bodySmall)
        for ((title, presets) in listOf("Тембр" to DspPresets.curve, "Объём" to DspPresets.space, "Устройство" to DspPresets.device)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                DropdownMenu(expanded, { expanded = false }) {
                    presets.forEach { preset -> DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                        s.dsp(preset.transform(s.config)); expanded = false
                    }) }
                }
            }
        }
        TextButton(onClick = { s.dsp(DspConfig.NEUTRAL) }) { Text("Сбросить всё") }
        Text("Преамп: ${"%.1f".format(s.config.preampDb)} дБ")
        Slider(s.config.preampDb, { s.dsp(s.config.copy(preampDb = it)) }, valueRange = -12f..6f)
        val bands = listOf("31 Гц", "62 Гц", "125 Гц", "250 Гц", "500 Гц", "1 кГц", "2 кГц", "4 кГц", "8 кГц", "16 кГц")
        bands.forEachIndexed { index, label ->
            Text("$label · ${"%.1f".format(s.config.bandsDb[index])} дБ", style = MaterialTheme.typography.labelSmall)
            Slider(s.config.bandsDb[index], { value ->
                s.dsp(s.config.copy(enabled = true, bandsDb = s.config.bandsDb.toMutableList().also { it[index] = value }))
            }, valueRange = -12f..12f, modifier = Modifier.height(30.dp))
        }
        Text("Реверберация")
        Slider(s.config.reverbMix, { s.dsp(s.config.copy(enabled = true, reverbMix = it)) })
        Text("8D · глубина вращения")
        Slider(s.config.rotation, { s.dsp(s.config.copy(enabled = true, rotation = it)) })
        Text("Под водой")
        Slider(s.config.underwater, { s.dsp(s.config.copy(enabled = true, underwater = it)) })
        Text("Профили, speed/pitch и спектр будут отдельными доработками.", style = MaterialTheme.typography.bodySmall)
    }
}
