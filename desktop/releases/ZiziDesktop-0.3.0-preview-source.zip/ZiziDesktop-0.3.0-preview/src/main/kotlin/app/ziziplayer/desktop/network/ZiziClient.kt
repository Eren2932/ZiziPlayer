package app.ziziplayer.desktop.network

import app.ziziplayer.desktop.PlayerTrack
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

class NetworkFailure(val code: Int) : Exception("ZIZI_HTTP_$code")
object RemoteIdentity {
    fun parse(raw: String): Pair<String, String> {
        val uri = URI(raw)
        require(uri.scheme == "zizi" && uri.userInfo == null && uri.port == -1 && uri.query == null && uri.fragment == null)
        val path = uri.rawPath.removePrefix("/")
        require(path.isNotBlank() && '/' !in path)
        // URI.path decodes percent escapes, but unlike URLDecoder keeps literal '+'.
        val id = uri.path.removePrefix("/")
        val pair = if (uri.host == "mix") id.substringBefore(':') to id.substringAfter(':', "") else uri.host to id
        require(pair.first in setOf("dz", "yt"))
        if (pair.first == "dz") require(pair.second.matches(Regex("[0-9]{1,20}")))
        else require(pair.second.matches(Regex("[A-Za-z0-9_-]{11}")))
        return pair.first to pair.second
    }
}
object HttpTransport {
    fun safeUri(raw: String): URI {
        val uri = URI(raw)
        require(uri.userInfo == null && uri.fragment == null && !uri.host.isNullOrBlank())
        require(uri.scheme == "https" || (uri.scheme == "http" && uri.host in setOf("127.0.0.1", "localhost", "[::1]"))) {
            "HTTPS_REQUIRED"
        }
        return uri
    }
    fun open(uri: URI, headers: Map<String, String> = emptyMap(), method: String = "GET"): HttpURLConnection {
        safeUri(uri.toString())
        val connection = uri.toURL().openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = false // Never forward auth to another origin.
        connection.connectTimeout = 15_000
        connection.readTimeout = 15_000
        connection.requestMethod = method
        connection.setRequestProperty("User-Agent", "ZiziDesktop/0.3.0")
        connection.setRequestProperty("Accept-Encoding", "identity")
        for ((key, value) in headers) {
            require(!key.contains('\r') && !key.contains('\n') && !value.contains('\r') && !value.contains('\n'))
            connection.setRequestProperty(key, value)
        }
        return connection
    }
    fun bytes(uri: URI, headers: Map<String, String>, max: Int): ByteArray {
        val c = open(uri, headers)
        try {
            val code = c.responseCode
            if (code != 200) throw NetworkFailure(code)
            require(c.contentLengthLong <= max) { "RESPONSE_TOO_LARGE" }
            val bytes = c.inputStream.use { it.readNBytes(max + 1) }
            require(bytes.size <= max) { "RESPONSE_TOO_LARGE" }
            return bytes
        } finally { c.disconnect() }
    }
}
/** Settings snapshot: replace the entire client when the origin or bootstrap changes.
 * No token is persisted, included in toString, URLs, FFmpeg arguments or exception messages.
 */
class ZiziClient(base: String, private val bootstrap: String, private val installId: String = UUID.randomUUID().toString()) {
    private val base = HttpTransport.safeUri(base.trim().trimEnd('/')).also {
        require(it.query == null)
    }.toString().trimEnd('/')
    private var deviceToken = ""
    private var expiresAt = 0L
    private var renewAt = 0L
    private var retryAt = 0L
    private fun endpoint(path: String, parameters: Map<String, String> = emptyMap()): URI {
        val query = parameters.entries.joinToString("&") { (k, v) -> "$k=${URLEncoder.encode(v, StandardCharsets.UTF_8)}" }
        return URI(base + path + if (query.isEmpty()) "" else "?$query")
    }
    private fun json(path: String, parameters: Map<String, String> = emptyMap()): JSONObject =
        JSONObject(String(HttpTransport.bytes(endpoint(path, parameters), headers(), 2 * 1024 * 1024), StandardCharsets.UTF_8))
    @Synchronized fun headers(): Map<String, String> {
        val now = System.currentTimeMillis()
        if (bootstrap.isNotBlank() && now >= renewAt && now >= retryAt) {
            retryAt = now + 300_000 // No refresh storms on 401/429/503.
            try {
                val auth = mapOf("Authorization" to "Bearer ${bootstrap.trim()}", "X-Zizi-Install" to installId)
                val response = JSONObject(String(HttpTransport.bytes(endpoint("/auth/device"), auth, 64 * 1024), StandardCharsets.UTF_8))
                val token = response.getString("token")
                val ttl = response.getLong("expires_in")
                require(token.isNotBlank() && ttl in 1..604800)
                deviceToken = token; expiresAt = System.currentTimeMillis() + ttl * 1000
                renewAt = expiresAt - minOf(600_000L, ttl * 500); retryAt = 0
            } catch (_: Exception) { /* Compatible bootstrap fallback, as on mobile. */ }
        }
        val bearer = if (deviceToken.isNotBlank() && now < expiresAt) deviceToken else bootstrap.trim()
        return buildMap {
            put("X-Zizi-Install", installId)
            if (bearer.isNotBlank()) put("Authorization", "Bearer $bearer")
        }
    }
    fun search(query: String): List<PlayerTrack> {
        require(query.isNotBlank() && query.length <= 300)
        // Explicit Deezer: never reinterpret another catalog's ID as a Deezer ID.
        val items = json("/catalog/search", mapOf("q" to query, "src" to "deezer", "limit" to "30")).getJSONArray("items")
        return (0 until items.length()).mapNotNull { index ->
            val row = items.getJSONObject(index)
            val id = row.optString("id")
            if (!id.matches(Regex("[0-9]{1,20}")) || row.optString("src", "deezer") != "deezer") null
            else PlayerTrack("zizi://dz/$id", row.optString("title", "Без названия"), row.optString("artist"),
                artworkUrl = row.optString("art").takeIf { it.isNotBlank() && it != "null" })
            // Catalog duration isn't guaranteed to equal the matched recording. Probe the stream.
        }.distinctBy { it.id }
    }
    fun resolve(source: String): StreamTarget {
        val (provider, id) = RemoteIdentity.parse(source)
        val video = if (provider == "yt") id else json("/match/deezer", mapOf("id" to id)).getString("vid")
        require(video.matches(Regex("[A-Za-z0-9_-]{11}"))) { "INVALID_VIDEO_ID" }
        val resolved = json("/resolve", mapOf("id" to video))
        require(resolved.optString("url").isNotBlank()) { "RESOLVER_EMPTY" }
        // Server proxy mode preserves the server IP that resolved the YouTube stream.
        return StreamTarget(endpoint("/stream", mapOf("id" to video)), ::headers)
    }
    fun artwork(raw: String): ByteArray {
        // Use the mobile server image route and its host policy, not arbitrary authenticated URLs.
        return HttpTransport.bytes(endpoint("/img", mapOf("u" to raw)), headers(), 5 * 1024 * 1024)
    }
}
class StreamTarget(val uri: URI, val headers: () -> Map<String, String>)
