package app.ziziplayer.desktop.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.ziziplayer.desktop.*
import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.ZiziIcons
import java.io.File
import javax.imageio.ImageIO
import javax.swing.JFileChooser
import javax.swing.filechooser.FileNameExtensionFilter
import kotlinx.coroutines.*

private val Brand = Color(0xFFF97316)
private val Base = Color.Black
private val Panel = Color(0xFF101010)
private val Chip = Color(0xFF1B1B1B)
private val Ink = Color(0xFFF6F7F8)
private val Muted = Color(0xFF9A9A9A)

private class DesktopUi(val scope: CoroutineScope) {
    val player = DesktopPlayer(scope)
    var tracks by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var results by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    var searchMessage by mutableStateOf("Поиск по серверному каталогу Deezer · звук через YouTube")
    var config by mutableStateOf(DspConfig.NEUTRAL); private set
    var gain by mutableStateOf(0.35f); private set
    var client by mutableStateOf<ZiziClient?>(null); private set
    var connectionMessage by mutableStateOf("Подключение не настроено в сборке"); private set
    var httpCompatibility by mutableStateOf(false); private set
    var recentSearches by mutableStateOf(DesktopPreferences.recentSearches); private set
    var ffmpeg by mutableStateOf(DesktopPreferences.ffmpeg.ifBlank { player.ffmpeg })
    private var searchJob: Job? = null
    init {
        player.ffmpeg = ffmpeg
        try {
            val connection = BundledConnection.load()
            if (connection != null) {
                val api = connection.client(DesktopPreferences.installId)
                client = api; player.client = api; httpCompatibility = connection.usesHttp
                connectionMessage = "Конфигурация загружена · сеть ещё не проверена"
                // Warm the device exchange away from Compose. A cold request also waits only on IO.
                scope.launch { withContext(Dispatchers.IO) { api.headers() } }
            }
        } catch (_: Exception) {
            connectionMessage = "Ошибка конфигурации сборки · проверь параметры CI"
        }
    }
    fun audioSettings(executable: String) {
        ffmpeg = executable.trim().removeSurrounding("\"")
        player.ffmpeg = ffmpeg; DesktopPreferences.ffmpeg = ffmpeg
    }
    fun clearHistory() { recentSearches = emptyList(); DesktopPreferences.recentSearches = emptyList() }
    fun cancelSearch() { searchJob?.cancel(); searching = false; results = emptyList() }
    fun add(files: List<File>) { tracks = (tracks + files.map { PlayerTrack(it.absolutePath, it.nameWithoutExtension) }).distinctBy { it.id } }
    fun addSource(raw: String) {
        val source = raw.trim()
        if (source.startsWith("zizi://")) RemoteIdentity.parse(source) else HttpTransport.safeUri(source)
        val name = if (source.startsWith("zizi://")) "Трек Zizi · ${RemoteIdentity.parse(source).first.uppercase()}" else "Сетевой трек"
        tracks = (tracks + PlayerTrack(source, name)).distinctBy { it.id }
    }
    fun dsp(value: DspConfig) { player.dsp(value); config = player.config }
    fun volume(value: Float) { player.volume(value); gain = player.gain }
    fun search(query: String) {
        searchJob?.cancel(); results = emptyList()
        val api = client
        if (api == null) { searching = false; searchMessage = connectionMessage; return }
        if (query.isBlank()) { searching = false; searchMessage = "Введи название трека или исполнителя"; return }
        if (query.trim().length > 300) { searching = false; searchMessage = "Запрос слишком длинный"; return }
        recentSearches = (listOf(query.trim()) + recentSearches).distinctBy { it.lowercase(java.util.Locale.ROOT) }.take(20)
        DesktopPreferences.recentSearches = recentSearches
        searching = true; searchMessage = "Ищем музыку…"
        searchJob = scope.launch {
            try {
                val found = runInterruptible(Dispatchers.IO) { api.search(query.trim()) }
                results = found; connectionMessage = "Каталог доступен"; searchMessage = if (found.isEmpty()) "Ничего не найдено" else "${found.size} треков · нажми для воспроизведения"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                connectionMessage = "Не удалось выполнить запрос"
                searchMessage = if (e is NetworkFailure) when (e.code) {
                    401 -> "Сервер отклонил авторизацию · проверь конфигурацию релиза"
                    429 -> "Слишком много запросов. Повтори позже"
                    else -> "Ошибка сервера HTTP ${e.code}"
                } else "Не удалось подключиться: проверь адрес, TLS и сеть"
            } finally { if (isActive) searching = false }
        }
    }
}

private data class CoverData(val image: ImageBitmap)
private object Covers {
    private val cache = object : LinkedHashMap<String, CoverData>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CoverData>?): Boolean = size > 64
    }
    fun load(track: PlayerTrack, api: ZiziClient?): CoverData? {
        if (track.artwork == null && (track.artworkUrl == null || api == null)) return null
        val key = track.id + ":" + System.identityHashCode(api) + ":" + System.identityHashCode(track.artwork)
        synchronized(cache) { cache[key] }?.let { return it }
        return runCatching {
            val bytes = track.artwork ?: api!!.artwork(track.artworkUrl!!)
            ImageIO.createImageInputStream(bytes.inputStream()).use { input ->
                val readers = ImageIO.getImageReaders(input)
                check(readers.hasNext())
                val reader = readers.next()
                try {
                    reader.input = input
                    val w = reader.getWidth(0); val h = reader.getHeight(0)
                    require(w in 1..8192 && h in 1..8192 && w.toLong() * h <= 20_000_000)
                    val parameters = reader.defaultReadParam
                    val scale = maxOf(w, h) / 480
                    if (scale > 1) parameters.setSourceSubsampling(scale, scale, 0, 0)
                    val image = reader.read(0, parameters)
                    CoverData(image.toComposeImageBitmap())
                        .also { synchronized(cache) { cache[key] = it } }
                } finally { reader.dispose() }
            }
        }.getOrNull()
    }
}
@Composable private fun coverData(track: PlayerTrack?, api: ZiziClient?): CoverData? {
    val cover by produceState<CoverData?>(null, track?.id, track?.artwork, api) {
        value = null
        if (track != null) value = withContext(Dispatchers.IO) { Covers.load(track, api) }
    }
    return cover
}
@Composable private fun Artwork(track: PlayerTrack?, api: ZiziClient?, size: Dp) {
    val cover = coverData(track, api)
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Panel), contentAlignment = Alignment.Center) {
        if (cover != null) Image(cover.image, "Обложка", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(ZiziIcons.FolderMusic, null, Modifier.size(size * 0.4f), tint = Muted)
    }
}
private fun chooseFiles(): List<File> {
    val picker = JFileChooser().apply {
        dialogTitle = "Добавить музыку в Zizi"; isMultiSelectionEnabled = true
        fileFilter = FileNameExtensionFilter("Аудио", "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFiles.toList() else emptyList()
}
private fun time(ms: Long): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(seconds / 60, seconds % 60) }

fun main() = application {
    val scope = rememberCoroutineScope()
    val ui = remember { DesktopUi(scope) }
    var closing by remember { mutableStateOf(false) }
    Window(onCloseRequest = { if (!closing) { closing = true; ui.player.close { exitApplication() } } },
        title = "ZiziPlayer · Desktop 0.3.1 preview", state = rememberWindowState(width = 1240.dp, height = 820.dp)) {
        LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(920, 650) }
        MaterialTheme(colorScheme = darkColorScheme(primary = Ink, onPrimary = Color.Black, background = Base,
            onBackground = Ink, surface = Panel, onSurface = Ink, surfaceVariant = Chip,
            onSurfaceVariant = Muted, secondaryContainer = Chip, onSecondaryContainer = Ink,
            surfaceTint = Color.Transparent, outline = Color(0xFF303030))) {
            Surface(Modifier.fillMaxSize(), color = Base) { DesktopContent(ui, closing) }
        }
    }
}
@Composable private fun DesktopContent(s: DesktopUi, closing: Boolean) {
    val state by s.player.state.collectAsState()
    val metadata by s.player.metadata.collectAsState()
    var page by remember { mutableStateOf("Медиатека") }
    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    fun submitSearch(value: String) {
        if (value.isBlank()) return
        query = value; submitted = true; focusManager.clearFocus(); s.search(value)
    }
    var settings by remember { mutableStateOf(false) }
    var sourceDialog by remember { mutableStateOf(false) }
    var effects by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().onKeyEvent {
        if (!editing && !settings && !sourceDialog && !closing && it.type == KeyEventType.KeyUp && it.key == Key.Spacebar) {
            s.player.togglePause(); true
        } else false
    }) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.width(184.dp).fillMaxHeight().background(Panel).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Zizi", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("DESKTOP · 0.3.1 PREVIEW", color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(16.dp))
                for ((label, icon) in listOf("Медиатека" to ZiziIcons.FolderMusic, "Поиск" to ZiziIcons.Search, "Очередь" to ZiziIcons.Queue)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (page == label) Chip else Color.Transparent)
                        .clickable { s.cancelSearch(); page = label; query = ""; submitted = false; focusManager.clearFocus() }
                        .padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, null, tint = if (page == label) Brand else Muted, modifier = Modifier.size(23.dp))
                        Spacer(Modifier.width(12.dp)); Text(label, color = if (page == label) Ink else Muted)
                    }
                }
                HorizontalDivider()
                TextButton(onClick = { s.add(chooseFiles()) }, enabled = !closing) { Text("Добавить файлы") }
                TextButton(onClick = { sourceDialog = true }) { Text("Открыть ссылку") }
                Spacer(Modifier.weight(1f))
                Text(s.connectionMessage, color = Muted, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { settings = true }) { Icon(ZiziIcons.Server, null); Spacer(Modifier.width(8.dp)); Text("Настройки") }
            }
            Column(Modifier.weight(1f).fillMaxHeight().background(Base).padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(page, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { effects = !effects }) { Icon(ZiziIcons.Equalizer, "Звук Zizi", tint = if (effects) Brand else Color.White) }
                }
                Spacer(Modifier.height(16.dp))
                if (page == "Поиск") {
                    DesktopSearchField(query, { query = it; submitted = false; s.cancelSearch() },
                        onSubmit = { submitSearch(query) }, onFocus = { editing = it })
                } else {
                    DesktopSearchField(query, { query = it }, onSubmit = { focusManager.clearFocus() },
                        onFocus = { editing = it }, hint = "Найти в списке", mobileSearch = false)
                }
                Spacer(Modifier.height(16.dp))
                val all = when (page) { "Поиск" -> if (submitted) s.results else emptyList(); "Очередь" -> s.player.queue; else -> s.tracks }
                val visible = if (page == "Поиск") all else all.filter { (it.title + " " + it.artist).contains(query, true) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (page == "Поиск") {
                        if (submitted) s.searchMessage else if (query.isBlank()) "Поиск музыки" else "Нажми Enter для поиска"
                    } else "${all.size} треков · список этой сессии", color = Muted,
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    if (page == "Поиск") SearchRefresh(s.searching, query.isNotBlank()) { submitSearch(query) }
                }
                if (page == "Поиск" && !submitted) {
                    val suggestions = if (query.isBlank()) s.recentSearches.take(6) else
                        app.ziziplayer.ui.SearchPresentation.completions(query, emptyList(), s.recentSearches,
                            s.tracks.map { it.title })
                    if (suggestions.isNotEmpty()) {
                        Spacer(Modifier.height(17.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (query.isBlank()) "Недавние" else "Из истории и медиатеки", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (query.isBlank()) TextButton(onClick = s::clearHistory) { Text("Очистить", color = Muted) }
                        }
                        suggestions.forEach { suggestion ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).clickable { submitSearch(suggestion) }
                                .padding(vertical = 14.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(ZiziIcons.Search, null, tint = Muted, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(17.dp)); Text(suggestion, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (visible.isEmpty() && !s.searching && (page != "Поиск" || submitted || (query.isBlank() && s.recentSearches.isEmpty()))) {
                    Column(Modifier.fillMaxWidth().padding(top = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(if (page == "Поиск") ZiziIcons.Search else ZiziIcons.FolderMusic, null, Modifier.size(64.dp), tint = Brand)
                        Spacer(Modifier.height(18.dp))
                        Text(if (page == "Поиск") if (submitted) "Ничего не найдено" else "Что хочешь послушать?" else "Здесь будет твоя музыка", style = MaterialTheme.typography.titleLarge)
                        Text(if (page == "Поиск") if (s.client != null) "Треки и исполнители · поиск по каталогу Zizi" else s.connectionMessage else "Добавь файлы или открой zizi://-ссылку", color = Muted, modifier = Modifier.padding(top = 8.dp))
                    }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(visible, key = { it.id }) { original ->
                        val selected = original.id == state.track?.id
                        val track = if (selected) state.track!! else metadata[original.id] ?: original
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Brand.copy(alpha = 0.12f) else Color.Transparent)
                            .clickable(enabled = !closing) { s.player.play(track, all) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Artwork(track, s.client, 54.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (selected) Brand else Color.White)
                                Text(track.artist.ifBlank { if (track.source.startsWith("zizi://")) "Поток Zizi" else if (track.source.startsWith("http")) "Сетевое аудио" else "Локальный файл" }, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(track.durationMs?.let(::time) ?: "—", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            AnimatedVisibility(effects,
                enter = expandHorizontally(tween(260, easing = FastOutSlowInEasing)) + fadeIn(tween(180)),
                exit = shrinkHorizontally(tween(220, easing = FastOutSlowInEasing)) + fadeOut(tween(140))) {
                EffectsPanel(s, Modifier.width(300.dp).fillMaxHeight().background(Panel).padding(18.dp))
            }
        }
        Transport(s, closing) { expanded = true }
    }
    if (settings) SettingsDialog(s) { settings = false }
    if (sourceDialog) SourceDialog(s) { sourceDialog = false }
    if (expanded) AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = { expanded = false }, title = { Text("Сейчас играет") }, text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Artwork(state.track, s.client, 280.dp); Spacer(Modifier.height(16.dp))
            Text(state.track?.title ?: "Музыка не выбрана", style = MaterialTheme.typography.titleLarge)
            Text(state.track?.artist.orEmpty(), color = Muted)
        }
    }, confirmButton = { TextButton(onClick = { expanded = false }) { Text("Свернуть") } })
}
@Composable private fun Transport(s: DesktopUi, closing: Boolean, expand: () -> Unit) {
    val state by s.player.state.collectAsState()
    val progress by s.player.progress.collectAsState()
    val valid = progress.trackId == state.track?.id && progress.generation == state.generation
    val duration = if (valid) progress.durationMs ?: 0 else 0
    val position = if (valid) progress.positionMs else 0
    var drag by remember(state.generation) { mutableStateOf<Float?>(null) }
    HorizontalDivider(color = Color(0xFF292929))
    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 22.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(time((drag?.toLong() ?: position)), color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            Slider(value = drag ?: position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
                onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { s.player.seek(it.toLong()) }; drag = null },
                enabled = state.seekable && duration > 0 && !closing, valueRange = 0f..duration.coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f).height(24.dp))
            Text(if (duration > 0) time(duration) else "—:—", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 12.dp).width(48.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.clickable(onClick = expand)) { Artwork(state.track, s.client, 54.dp) }
            Column(Modifier.weight(1f)) {
                Text(state.track?.title ?: "Zizi готов к музыке", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(if (closing) "Закрываем аудиосеанс…" else state.message, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { s.player.adjacent(-1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipPrevious, "Предыдущий трек") }
            FilledIconButton(onClick = { s.player.togglePause() }, enabled = !closing && state.track != null, modifier = Modifier.size(52.dp)) {
                val pauses = state.phase in setOf(PlaybackPhase.PLAYING, PlaybackPhase.LOADING)
                Icon(if (pauses) ZiziIcons.Pause else ZiziIcons.PlayFilled, if (pauses) "Пауза" else "Воспроизвести")
            }
            IconButton(onClick = { s.player.adjacent(1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipNext, "Следующий трек") }
            IconButton(onClick = { s.player.stop() }, enabled = !closing && state.track != null) { Icon(ZiziIcons.Stop, "Остановить") }
            Text("${(s.gain * 100).toInt()}%", color = Muted)
            Slider(s.gain, s::volume, modifier = Modifier.width(110.dp))
        }
    }
}
@Composable private fun SettingsDialog(s: DesktopUi, dismiss: () -> Unit) {
    var executable by remember { mutableStateOf(s.ffmpeg) }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss,
        title = { Text("Настройки Zizi") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(17.dp)) {
            Text("Подключение", fontWeight = FontWeight.SemiBold)
            Text(s.connectionMessage, color = Muted)
            Text("Сервер и авторизация настраиваются в сборке. Ввод ключей в приложении не нужен.", color = Muted)
            if (s.httpCompatibility) Text("Режим совместимости HTTP: трафик до сервера не зашифрован. Для защиты соединения нужен HTTPS.",
                color = Brand, style = MaterialTheme.typography.bodySmall)
            HorizontalDivider(color = Chip)
            Text("Аудиодекодер", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(executable, { executable = it }, label = { Text("Путь к FFmpeg") }, singleLine = true,
                modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { val picker = JFileChooser(); if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) executable = picker.selectedFile.absolutePath }) { Text("Выбрать FFmpeg…") }
            Text("ffprobe должен лежать рядом с FFmpeg. Изменения применяются при следующем открытии трека.", color = Muted,
                style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { s.audioSettings(executable); dismiss() }) { Text("Готово") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun SourceDialog(s: DesktopUi, dismiss: () -> Unit) {
    var source by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss, title = { Text("Открыть ссылку") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("zizi://dz/ID, zizi://yt/VIDEO_ID, zizi://mix/dz%3AID или прямая HTTPS-ссылка на аудио. Не страница YouTube. HLS/DASH и HTTP-редиректы пока не поддерживаются.")
            OutlinedTextField(source, { source = it }, singleLine = true, label = { Text("Адрес трека") })
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        try { s.addSource(source); source = ""; dismiss() } catch (_: Exception) { error = "Некорректная или неподдерживаемая ссылка" }
    }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable
private fun EffectsPanel(s: DesktopUi, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Звук Zizi", style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DSP", Modifier.weight(1f)); Switch(s.config.enabled, { s.dsp(s.config.copy(enabled = it)) })
        }
        Text("Оригинальные пресеты 6.39.9", style = MaterialTheme.typography.bodySmall)
        for ((title, presets) in listOf("Тембр" to DspPresets.curve, "Объём" to DspPresets.space, "Устройство" to DspPresets.device)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                DropdownMenu(expanded, { expanded = false }) {
                    presets.forEach { preset -> DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                        s.dsp(preset.transform(s.config)); expanded = false
                    }) }
                }
            }
        }
        TextButton(onClick = { s.dsp(DspConfig.NEUTRAL) }) { Text("Сбросить всё") }
        Text("Преамп: ${"%.1f".format(s.config.preampDb)} дБ")
        Slider(s.config.preampDb, { s.dsp(s.config.copy(preampDb = it)) }, valueRange = -12f..6f)
        val bands = listOf("31 Гц", "62 Гц", "125 Гц", "250 Гц", "500 Гц", "1 кГц", "2 кГц", "4 кГц", "8 кГц", "16 кГц")
        bands.forEachIndexed { index, label ->
            Text("$label · ${"%.1f".format(s.config.bandsDb[index])} дБ", style = MaterialTheme.typography.labelSmall)
            Slider(s.config.bandsDb[index], { value ->
                s.dsp(s.config.copy(enabled = true, bandsDb = s.config.bandsDb.toMutableList().also { it[index] = value }))
            }, valueRange = -12f..12f, modifier = Modifier.height(30.dp))
        }
        Text("Реверберация")
        Slider(s.config.reverbMix, { s.dsp(s.config.copy(enabled = true, reverbMix = it)) })
        Text("8D · глубина вращения")
        Slider(s.config.rotation, { s.dsp(s.config.copy(enabled = true, rotation = it)) })
        Text("Под водой")
        Slider(s.config.underwater, { s.dsp(s.config.copy(enabled = true, underwater = it)) })
        Text("Профили, speed/pitch и спектр будут отдельными доработками.", style = MaterialTheme.typography.bodySmall)
    }
}

/** Desktop adapter of Android 6.39.9 SearchField: exact heights, radius, type and colors.
 * Enter / submit icon replace Android's IME action. No outlined Material input here.
 */
@Composable private fun DesktopSearchField(
    text: String, onText: (String) -> Unit, onSubmit: () -> Unit,
    onFocus: (Boolean) -> Unit, hint: String = "Что хочешь послушать?", mobileSearch: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val light = mobileSearch && !focused
    val foreground = if (light) Color(0xFF121212) else Ink
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.fillMaxWidth().height(if (focused) 52.dp else 49.5.dp)
            .clip(RoundedCornerShape(3.5.dp)).background(if (light) Color.White else Color(0xFF292929))
            .padding(start = 9.5.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (focused) IconButton(onClick = { focusManager.clearFocus() }) {
                Icon(ZiziIcons.ArrowBack, "Закрыть ввод", tint = foreground, modifier = Modifier.size(23.dp))
            } else Icon(ZiziIcons.Search, null, tint = foreground, modifier = Modifier.size(29.dp))
            Spacer(Modifier.width(11.dp))
            BasicTextField(text, { onText(it.take(300)) }, singleLine = true,
                textStyle = TextStyle(color = foreground, fontSize = 17.sp,
                    fontWeight = if (focused) FontWeight.Medium else FontWeight.Bold),
                cursorBrush = SolidColor(Brand),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
                    .onPreviewKeyEvent {
                        if (it.key == Key.Enter && it.type == KeyEventType.KeyUp) { onSubmit(); true } else false
                    }, decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) Text(hint, color = if (light) Color(0xFF6E6E6E) else Muted,
                            fontSize = 16.sp, fontWeight = if (focused) FontWeight.Normal else FontWeight.SemiBold)
                        inner()
                    }
                })
            if (text.isNotEmpty()) {
                IconButton(onClick = { onText("") }) { Icon(ZiziIcons.Close, "Очистить", tint = foreground, modifier = Modifier.size(22.dp)) }
                if (mobileSearch) IconButton(onClick = onSubmit) { Icon(ZiziIcons.Search, "Найти", tint = foreground, modifier = Modifier.size(23.dp)) }
            }
        }
    }
}
/** Mobile refresh motion: 900 ms linear turn, 340 ms settling to the complete turn. */
@Composable private fun SearchRefresh(refreshing: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) {
                angle.animateTo(angle.value + 360f, tween(900, easing = LinearEasing))
                angle.snapTo(angle.value % 360f)
            }
        } else if (angle.value != 0f) {
            angle.animateTo(360f, tween(340, easing = FastOutSlowInEasing))
            angle.snapTo(0f)
        }
    }
    IconButton(onClick = { if (!refreshing) onClick() }, enabled = enabled,
        modifier = Modifier.size(42.dp).graphicsLayer { rotationZ = angle.value }) {
        Icon(ZiziIcons.Refresh, "Повторить поиск", tint = if (enabled) Brand else Muted, modifier = Modifier.size(23.dp))
    }
}
