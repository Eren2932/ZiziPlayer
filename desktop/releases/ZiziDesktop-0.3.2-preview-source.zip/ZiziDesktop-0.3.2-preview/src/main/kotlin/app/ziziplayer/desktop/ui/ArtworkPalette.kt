package app.ziziplayer.desktop.ui

import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import app.ziziplayer.ui.theme.ArtworkColorMath
import java.awt.image.BufferedImage
import kotlin.math.*

internal data class MattePalette(val surface: Color = Color(0xFF101010), val card: Color = Color(0xFF101010),
    val chip: Color = Color(0xFF1B1B1B), val accent: Color = Color.White)
internal val LocalMatte = staticCompositionLocalOf { MattePalette() }

/** Same visible square and 64x64 sample positions as Android Artwork.sample. */
internal fun sampleArtwork(image: BufferedImage): Int? {
    val side = minOf(image.width, image.height)
    if (side <= 0) return null
    val n = minOf(side, ArtworkColorMath.SAMPLE_SIDE)
    val left = (image.width - side) / 2; val top = (image.height - side) / 2
    val pixels = IntArray(n * n)
    for (y in 0 until n) for (x in 0 until n) {
        pixels[y * n + x] = image.getRGB(left + ((x + .5f) * side / n).toInt().coerceAtMost(side - 1),
            top + ((y + .5f) * side / n).toInt().coerceAtMost(side - 1))
    }
    return ArtworkColorMath.extract(pixels)?.get(0)
}
internal fun artworkPalette(primary: Int?): MattePalette {
    if (primary == null) return MattePalette()
    val lch = Color(primary).toOklch()
    val accent = if (lch[1] < .012f) oklch(.90f, 0f, 0f)
        else oklch(.80f, (.055f + lch[1] * .52f).coerceIn(.055f, .170f), lch[2])
    return MattePalette(Color(ArtworkColorMath.surface(primary)), Color(ArtworkColorMath.cardTop(primary)),
        Color(ArtworkColorMath.chip(primary)), accent)
}
/** One interruptible 380ms owner; no image sampling or gradients in the draw path. */
@Composable internal fun animatedMatte(target: MattePalette): MattePalette {
    val progress = remember { Animatable(1f) }
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    fun visible(): MattePalette = MattePalette(blendOklch(from.surface, to.surface, progress.value),
        blendOklch(from.card, to.card, progress.value), blendOklch(from.chip, to.chip, progress.value),
        blendOklch(from.accent, to.accent, progress.value))
    LaunchedEffect(target) {
        from = visible(); to = target; progress.snapTo(0f)
        progress.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
    }
    return visible()
}

// Colour conversion and shorter-hue interpolation ported from mobile 6.39.9 ZiziTheme.kt.
private fun cbrtf(value: Float): Float = Math.cbrt(value.toDouble()).toFloat()

private fun toLinear(channel: Float): Float =
    if (channel <= 0.04045f) channel / 12.92f else ((channel + 0.055f) / 1.055f).pow(2.4f)

private fun fromLinear(channel: Float): Float =
    if (channel <= 0.0031308f) channel * 12.92f else 1.055f * channel.pow(1f / 2.4f) - 0.055f

/** sRGB -> Oklch. Returns [L, C, h(deg)]. */
private fun Color.toOklch(): FloatArray {
    val r = toLinear(red)
    val g = toLinear(green)
    val b = toLinear(blue)
    val l = cbrtf(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b)
    val m = cbrtf(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b)
    val s = cbrtf(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b)
    val okL = 0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s
    val okA = 1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s
    val okB = 0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s
    var hue = atan2(okB, okA) * 57.29578f
    if (hue < 0f) hue += 360f
    return floatArrayOf(okL, hypot(okA, okB), hue)
}

/**
 * Oklch -> sRGB with a gamut walk: if the requested chroma cannot be shown at this lightness,
 * chroma is given up in 6 % steps. The hue and the lightness are never touched, which is the
 * whole point - a band getting darker must not drift towards another colour.
 */
private fun oklch(lightness: Float, chroma: Float, hueDeg: Float): Color {
    val okL = lightness.coerceIn(0f, 1f)
    val rad = hueDeg * 0.017453292f
    val dirA = cos(rad)
    val dirB = sin(rad)
    var c = chroma.coerceAtLeast(0f)
    var attempt = 0
    while (true) {
        val okA = dirA * c
        val okB = dirB * c
        val lp = okL + 0.3963377774f * okA + 0.2158037573f * okB
        val mp = okL - 0.1055613458f * okA - 0.0638541728f * okB
        val sp = okL - 0.0894841775f * okA - 1.2914855480f * okB
        val l = lp * lp * lp
        val m = mp * mp * mp
        val s = sp * sp * sp
        val r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s
        val g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s
        val b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s
        val inGamut = r >= -0.001f && r <= 1.001f && g >= -0.001f && g <= 1.001f &&
            b >= -0.001f && b <= 1.001f
        if (inGamut || attempt >= 24 || c <= 0.0005f) {
            return Color(
                red = fromLinear(r.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                green = fromLinear(g.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                blue = fromLinear(b.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            )
        }
        c *= 0.94f
        attempt++
    }
}

private fun blendOklch(from: Color, to: Color, fraction: Float): Color {
    if (fraction <= 0.001f) return from
    if (fraction >= 0.999f) return to
    val a = from.toOklch()
    val b = to.toOklch()
    var delta = b[2] - a[2]
    if (delta > 180f) delta -= 360f
    if (delta < -180f) delta += 360f
    // A colourless stop has no meaningful hue: borrow the other one's instead of rotating half
    // way round the circle to reach it.
    val hue = when {
        a[1] < 0.004f -> b[2]
        b[1] < 0.004f -> a[2]
        else -> a[2] + delta * fraction
    }
    return oklch(
        a[0] + (b[0] - a[0]) * fraction,
        a[1] + (b[1] - a[1]) * fraction,
        hue
    )
}

