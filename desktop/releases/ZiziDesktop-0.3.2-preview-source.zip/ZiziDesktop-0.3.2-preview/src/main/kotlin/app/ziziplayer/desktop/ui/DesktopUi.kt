package app.ziziplayer.desktop.ui

import androidx.compose.runtime.*
import app.ziziplayer.desktop.*
import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import java.io.File
import java.nio.file.Files
import javax.swing.JFileChooser

internal class DesktopUi(val scope: CoroutineScope, val store: LibraryStore, initial: LibrarySnapshot) {
    val player = DesktopPlayer(scope)
    val offline = OfflineFiles(store.directory.resolve("downloads"))
    var downloaded by mutableStateOf<Set<String>>(emptySet()); private set
    var downloadId by mutableStateOf<String?>(null); private set
    var downloadProgress by mutableStateOf(""); private set
    var downloadStats by mutableStateOf(0 to 0L); private set
    private var downloadJob: Job? = null
    var library by mutableStateOf(initial); private set
    val tracks get() = library.tracks
    val prefs get() = library.settings
    var results by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var groups by mutableStateOf<List<CatalogCollection>>(emptyList()); private set
    var nextBrowse by mutableStateOf<Int?>(null); private set
    var searchKind by mutableStateOf("track"); private set
    var searching by mutableStateOf(false); private set
    var searchMessage by mutableStateOf("Что хочешь послушать?"); private set
    var openPage by mutableStateOf<CatalogPage?>(null); private set
    var opening by mutableStateOf(false); private set
    var pageError by mutableStateOf(""); private set
    var notice by mutableStateOf("")
    var scanning by mutableStateOf(false); private set
    var scanMessage by mutableStateOf(""); private set
    var config by mutableStateOf(DspConfig.NEUTRAL); private set
    var gain by mutableStateOf(prefs.volume); private set
    var client by mutableStateOf<ZiziClient?>(null); private set
    var connectionMessage by mutableStateOf("Каталог недоступен в этой сборке"); private set
    var httpCompatibility by mutableStateOf(false); private set
    var recentSearches by mutableStateOf(DesktopPreferences.recentSearches); private set
    var ffmpeg by mutableStateOf(DesktopPreferences.ffmpeg.ifBlank { player.ffmpeg })
    private var searchJob: Job? = null
    private var pageJob: Job? = null
    private var scanJob: Job? = null
    private var folderJob: Job? = null
    private var lastQuery = ""
    private data class Write(val value: LibrarySnapshot, val ack: CompletableDeferred<Boolean>? = null)
    private val writes = Channel<Write>(Channel.UNLIMITED)
    private val writer = scope.launch(Dispatchers.IO) {
        for (first in writes) {
            var latest = first
            val acknowledgements = mutableListOf<CompletableDeferred<Boolean>>()
            first.ack?.let { acknowledgements.add(it) }
            while (true) {
                val next = writes.tryReceive().getOrNull() ?: break
                latest = next; next.ack?.let { acknowledgements.add(it) }
            }
            val success = runCatching { store.save(latest.value) }.isSuccess
            if (!success) withContext(Dispatchers.Main) { notice = "Не удалось сохранить библиотеку. Проверь свободное место и доступ к папке данных." }
            acknowledgements.forEach { it.complete(success) }
        }
    }

    private var periodic: Job? = null
    private var shuttingDown = false
    init {
        player.ffmpeg = ffmpeg; player.volume(prefs.volume)
        player.localSource = offline::existing
        refreshDownloads()
        player.repeatMode = prefs.repeat; player.shuffled = prefs.shuffle
        player.restore(initial.queue, initial.selected, initial.positionMs)
        player.configForTrack = { track -> dspFor(track.id).also { config = it } }
        config = dspFor(initial.selected)
        player.dsp(config)
        player.onQueueChanged = { persist() }
        if (!store.writable) notice = "Файл библиотеки повреждён или создан более новой версией. Исходные файлы сохранены; запись заблокирована."
        else if (store.recovered) notice = "Библиотека восстановлена из резервной копии."
        try {
            val connection = BundledConnection.load()
            if (connection != null) {
                val api = connection.client(DesktopPreferences.installId)
                client = api; player.client = api; httpCompatibility = connection.usesHttp
                connectionMessage = "Конфигурация загружена"
                scope.launch { withContext(Dispatchers.IO) { api.headers() } }
            }
        } catch (_: Exception) { connectionMessage = "Ошибка конфигурации сборки" }
        periodic = scope.launch {
            while (isActive) { delay(5000); if (player.state.value.track != null) persist() }
        }
        // Keep probed local metadata, not only the last session's filename.
        scope.launch {
            player.metadata.collect { map ->
                if (map.isNotEmpty() && !shuttingDown) {
                    library = library.copy(tracks = library.tracks.map { original ->
                        map[original.id]?.copy(artwork = null) ?: original
                    }); persist()
                }
            }
        }
    }
    private fun dspFor(id: String?): DspConfig = DspCodec.decode(
        if (prefs.dspGlobal) prefs.globalDsp else id?.let { prefs.trackDsp[it] })
    private fun snapshot(): LibrarySnapshot {
        val state = player.state.value; val progress = player.progress.value
        return library.copy(queue = player.queue, selected = state.track?.id,
            positionMs = if (progress.trackId == state.track?.id && progress.generation == state.generation) progress.positionMs else 0)
    }
    private fun persist() { if (store.writable && !shuttingDown) writes.trySend(Write(snapshot())) }
    fun shutdown(done: () -> Unit, failed: () -> Unit) {
        shuttingDown = true
        periodic?.cancel(); searchJob?.cancel(); pageJob?.cancel(); scanJob?.cancel(); folderJob?.cancel()
        val final = snapshot()
        scope.launch {
            downloadJob?.cancelAndJoin()
            val ack = CompletableDeferred<Boolean>()
            if (store.writable) { writes.send(Write(final, ack)); if (!ack.await()) { shuttingDown = false; failed(); return@launch } }
            writes.close(); writer.join()
            player.close(done)
        }
    }
    fun settings(value: DesktopSettings) {
        library = library.copy(settings = value)
        player.repeatMode = value.repeat; player.shuffled = value.shuffle
        config = dspFor(player.state.value.track?.id); player.dsp(config); persist()
    }
    fun audioSettings(executable: String) {
        ffmpeg = executable.trim().removeSurrounding("\"")
        player.ffmpeg = ffmpeg; DesktopPreferences.ffmpeg = ffmpeg
    }
    fun clearHistory() { recentSearches = emptyList(); DesktopPreferences.recentSearches = emptyList() }
    fun dsp(value: DspConfig) {
        player.dsp(value); config = player.config
        val encoded = DspCodec.encode(config); val id = player.state.value.track?.id
        library = library.copy(settings = if (prefs.dspGlobal) prefs.copy(globalDsp = encoded)
            else if (id != null) prefs.copy(trackDsp = prefs.trackDsp + (id to encoded)) else prefs)
        persist()
    }
    fun volume(value: Float) {
        player.volume(value); gain = player.gain
        library = library.copy(settings = prefs.copy(volume = gain)) // periodic + shutdown persist; no disk writes per slider pixel
    }
    fun save(track: PlayerTrack) {
        if (tracks.none { it.id == track.id }) library = library.copy(tracks = tracks + track)
        persist()
    }
    fun favorite(track: PlayerTrack) {
        save(track)
        library = library.copy(favorites = if (track.id in library.favorites) library.favorites - track.id else library.favorites + track.id)
        persist()
    }
    fun forget(id: String) {
        library = library.copy(tracks = tracks.filterNot { it.id == id }, favorites = library.favorites - id,
            playlists = library.playlists.map { it.copy(trackIds = it.trackIds - id) },
            settings = prefs.copy(trackDsp = prefs.trackDsp - id)); persist()
    }
    fun playlist(title: String, selection: List<PlayerTrack> = emptyList()): String? {
        val name = title.trim().take(100); if (name.isBlank()) return null
        val list = UserPlaylist(title = name, trackIds = selection.map { it.id }.distinct())
        library = library.copy(tracks = (tracks + selection).distinctBy { it.id }, playlists = library.playlists + list)
        persist(); return list.id
    }
    fun renamePlaylist(id: String, title: String) {
        if (title.isBlank()) return
        library = library.copy(playlists = library.playlists.map { if (it.id == id) it.copy(title = title.trim().take(100)) else it }); persist()
    }
    fun deletePlaylist(id: String) { library = library.copy(playlists = library.playlists.filterNot { it.id == id }); persist() }
    fun addToPlaylist(id: String, track: PlayerTrack) {
        save(track); library = library.copy(playlists = library.playlists.map {
            if (it.id == id) it.copy(trackIds = (it.trackIds + track.id).distinct()) else it
        }); persist()
    }
    fun playlistRemove(id: String, track: String) {
        library = library.copy(playlists = library.playlists.map { if (it.id == id) it.copy(trackIds = it.trackIds - track) else it }); persist()
    }
    fun playlistMove(id: String, track: String, delta: Int) {
        library = library.copy(playlists = library.playlists.map { list ->
            if (list.id != id) list else {
                val ids = list.trackIds.toMutableList(); val at = ids.indexOf(track)
                if (at >= 0 && at + delta in ids.indices) ids.add(at + delta, ids.removeAt(at))
                list.copy(trackIds = ids)
            }
        }); persist()
    }
    fun playlistTracks(id: String): List<PlayerTrack> {
        val map = tracks.associateBy { it.id }
        return library.playlists.find { it.id == id }?.trackIds.orEmpty().mapNotNull { map[it] }
    }
    fun sorted(input: List<PlayerTrack>): List<PlayerTrack> = when (prefs.sort) {
        TrackSort.TITLE -> input.sortedBy { it.title.lowercase() }
        TrackSort.ARTIST -> input.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
        TrackSort.RECENT -> input.reversed()
        TrackSort.DURATION -> input.sortedBy { it.durationMs ?: Long.MAX_VALUE }
    }
    fun add(files: List<File>) {
        library = library.copy(tracks = (tracks + files.map { PlayerTrack(it.absolutePath, it.nameWithoutExtension) }).distinctBy { it.id }); persist()
        if (files.isEmpty() || scanning) return
        scanJob = scope.launch {
            scanning = true
            try {
                val exe = ffmpeg
                for ((index, file) in files.withIndex()) {
                    scanMessage = "${index + 1} / ${files.size}"
                    ensureActive()
                    val info = withContext(Dispatchers.IO) { runCatching { Metadata.read(exe, file.absolutePath, true, false) }.getOrNull() }
                    if (info != null) library = library.copy(tracks = tracks.map {
                        if (it.id == file.absolutePath) it.copy(title = info.title ?: it.title, artist = info.artist ?: it.artist, durationMs = info.durationMs) else it
                    })
                }
                persist()
            } finally { scanning = false; scanMessage = ""; persist() }
        }
    }
    fun scanFolder(folder: File) {
        if (scanning) return
        folderJob = scope.launch {
            scanning = true
            try {
                val path = withContext(Dispatchers.IO) { folder.canonicalPath }
                val files = withContext(Dispatchers.IO) {
                    Files.walk(File(path).toPath()).use { stream -> stream.filter { Files.isRegularFile(it) &&
                        it.toString().substringAfterLast('.').lowercase() in setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma") }
                        .limit(10000).map { it.toFile() }.toList() }
                }
                if (files.size >= 10000) notice = "За один проход добавляются до 10 000 файлов. Для большой медиатеки добавляй подпапки отдельно."
                library = library.copy(folders = (library.folders + path).distinct()); scanning = false; add(files)
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { notice = "Не удалось прочитать папку. Проверь доступ." }
            finally { if (scanJob?.isActive != true) scanning = false }
        }
    }
    fun cancelScan() { folderJob?.cancel(); scanJob?.cancel() }
    fun removeFolder(path: String) {
        library = library.copy(folders = library.folders - path); persist()
    }
    fun folderTracks(path: String) = tracks.filter {
        !it.source.contains("://") && runCatching { File(it.source).toPath().normalize().startsWith(File(path).toPath().normalize()) }.getOrDefault(false)
    }
    fun addSource(raw: String) {
        val input = raw.trim()
        val source = if (input.startsWith("zizi://")) {
            val (provider, id) = RemoteIdentity.parse(input); "zizi://$provider/$id"
        } else HttpTransport.safeUri(input).toString()
        save(PlayerTrack(source, if (source.startsWith("zizi://")) "Трек Zizi" else "Сетевой трек"))
    }
    fun refreshDownloads() {
        scope.launch {
            val ids = tracks.map { it.id }
            val status = withContext(Dispatchers.IO) {
                ids.filter { offline.existing(it) != null }.toSet() to offline.statistics()
            }
            downloaded = status.first; downloadStats = status.second
        }
    }
    fun download(track: PlayerTrack) {
        if (downloadJob?.isActive == true) { notice = "Дождись текущей загрузки или отмени её."; return }
        val api = client ?: return
        save(track); downloadId = track.id; downloadProgress = "Подготовка…"
        downloadJob = scope.launch {
            try {
                val exe = ffmpeg
                offline.download(track, api, exe) { bytes, total ->
                    scope.launch {
                        downloadProgress = if (total != null && total > 0) "${bytes * 100 / total}%" else "${bytes / (1024 * 1024)} МБ"
                    }
                }
                downloaded = downloaded + track.id; notice = "Трек доступен офлайн."
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { notice = "Загрузка не завершена. Проверь сеть, свободное место и FFmpeg." }
            finally { downloadId = null; downloadProgress = ""; refreshDownloads() }
        }
    }
    fun cancelDownload() { downloadJob?.cancel() }
    fun deleteDownload(id: String) {
        if (id == player.state.value.track?.id || id == downloadId) { notice = "Сначала выбери другой трек и дождись окончания загрузки."; return }
        scope.launch {
            try { withContext(Dispatchers.IO) { offline.remove(id) }; downloaded = downloaded - id; refreshDownloads() }
            catch (_: Exception) { notice = "Не удалось удалить загрузку. Файл может быть занят." }
        }
    }
    fun showDataFolder(downloads: Boolean = false) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                val path = if (downloads) offline.directory else store.directory
                Files.createDirectories(path)
                if (java.awt.Desktop.isDesktopSupported()) java.awt.Desktop.getDesktop().open(path.toFile())
            }.onFailure { withContext(Dispatchers.Main) { notice = "Не удалось открыть папку в проводнике." } }
        }
    }
    fun selectSearchKind(kind: String) { searchKind = kind; cancelSearch() }
    fun cancelSearch() { searchJob?.cancel(); searching = false; results = emptyList(); groups = emptyList(); nextBrowse = null }
    fun search(query: String, kind: String = searchKind, more: Boolean = false) {
        searchJob?.cancel()
        val q = query.trim(); if (q.isBlank() || q.length > 300) return
        val api = client ?: run { searchMessage = connectionMessage; return }
        val offset = if (more) nextBrowse ?: return else 0
        searchKind = kind; lastQuery = q
        if (!more) { results = emptyList(); groups = emptyList(); nextBrowse = null }
        recentSearches = (listOf(q) + recentSearches).distinctBy { it.lowercase() }.take(20)
        DesktopPreferences.recentSearches = recentSearches
        searching = true; searchMessage = "Ищем музыку…"
        searchJob = scope.launch {
            try {
                if (kind == "track") results = runInterruptible(Dispatchers.IO) { api.search(q) }
                else {
                    val page = runInterruptible(Dispatchers.IO) { api.browse(q, kind, offset) }
                    groups = (if (more) groups + page.items else page.items).distinctBy { it.key }; nextBrowse = page.nextOffset
                }
                connectionMessage = "Каталог доступен"
                searchMessage = if (results.isEmpty() && groups.isEmpty()) "Ничего не найдено" else "Результаты поиска"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { searchMessage = networkMessage(e) }
            finally { if (isActive) searching = false }
        }
    }
    fun moreSearch() = search(lastQuery, searchKind, true)
    fun closePage() { pageJob?.cancel(); openPage = null; opening = false; pageError = "" }
    fun open(collection: CatalogCollection, more: Boolean = false) {
        pageJob?.cancel(); val api = client ?: return
        val offset = if (more) openPage?.nextOffset ?: return else 0
        if (!more) openPage = CatalogPage(collection, emptyList(), null, null)
        opening = true; pageError = ""
        pageJob = scope.launch {
            try {
                val page = runInterruptible(Dispatchers.IO) { api.collection(collection, offset) }
                openPage = if (more) page.copy(tracks = (openPage!!.tracks + page.tracks).distinctBy { it.id }) else page
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { pageError = networkMessage(e) }
            finally { if (isActive) opening = false }
        }
    }
    private fun networkMessage(e: Exception): String = if (e is NetworkFailure) when (e.code) {
        401, 403 -> "Не удалось подтвердить доступ. Попробуй позже."
        404 -> "Этот раздел пока недоступен на сервере."
        429 -> "Слишком много запросов. Повтори позже."
        else -> "Не удалось загрузить: HTTP ${e.code}"
    } else "Не удалось загрузить. Проверь соединение и повтори."
}
