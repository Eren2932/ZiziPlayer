package app.ziziplayer.desktop.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.ziziplayer.desktop.*
import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.ZiziIcons
import java.io.File
import javax.imageio.ImageIO
import javax.swing.JFileChooser
import javax.swing.filechooser.FileNameExtensionFilter
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withPermit
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.graphics.vector.ImageVector

private val Brand = Color(0xFFF97316)
private val Base = Color.Black
private val Panel = Color(0xFF101010)
private val Chip = Color(0xFF1B1B1B)
private val Ink = Color(0xFFF6F7F8)
private val Muted = Color(0xFF9A9A9A)

private data class CoverData(val image: ImageBitmap, val palette: MattePalette)
private object Covers {
    val gate = kotlinx.coroutines.sync.Semaphore(3)
    private val directory = LibraryStore.defaultDirectory().resolve("artwork")
    private val cache = object : LinkedHashMap<String, CoverData>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CoverData>?): Boolean = size > 64
    }
    private val failed = object : LinkedHashMap<String, Long>(128, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean = size > 128
    }
    private var writes = 0
    fun clear() {
        synchronized(cache) { cache.clear(); failed.clear() }
        if (java.nio.file.Files.isDirectory(directory)) java.nio.file.Files.list(directory).use { stream ->
            stream.filter { it.fileName.toString().matches(Regex("[0-9a-f]{64}\\.img")) }
                .forEach { runCatching { java.nio.file.Files.deleteIfExists(it) } }
        }
    }
    private fun rememberDisk(key: String, bytes: ByteArray) {
        runCatching {
            java.nio.file.Files.createDirectories(directory)
            val target = diskPath(key)
            val tmp = java.nio.file.Files.createTempFile(directory, "cover-", ".tmp")
            try {
                java.nio.file.Files.write(tmp, bytes)
                java.nio.file.Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            } finally { java.nio.file.Files.deleteIfExists(tmp) }
            synchronized(cache) { writes++ }
            // Bounded disk cache. Decoding/sampling are never done on the UI thread.
            if (writes % 16 == 0) {
                val files = java.nio.file.Files.list(directory).use { it.filter { p -> p.fileName.toString().endsWith(".img") }.toList() }
                var total = files.sumOf { java.nio.file.Files.size(it) }
                for (path in files.sortedBy { java.nio.file.Files.getLastModifiedTime(it).toMillis() }) {
                    if (total <= 96L * 1024 * 1024) break
                    val size = java.nio.file.Files.size(path)
                    if (java.nio.file.Files.deleteIfExists(path)) total -= size
                }
            }
        }
    }
    private fun diskPath(key: String): java.nio.file.Path {
        val hash = java.security.MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        return directory.resolve("$hash.img")
    }
    fun load(track: PlayerTrack, api: ZiziClient?): CoverData? {
        val local = !track.source.contains("://") && !track.source.startsWith("collection:")
        val key = track.id + ":" + track.artworkUrl + if (local) ":" + File(track.source).lastModified() else ""
        synchronized(cache) {
            cache[key]?.let { return it }
            if ((failed[key] ?: 0L) > System.currentTimeMillis() && track.artwork == null) return null
        }
        val result = runCatching {
            val path = diskPath(key)
            val cached = runCatching { if (java.nio.file.Files.isRegularFile(path) && java.nio.file.Files.size(path) <= 5 * 1024 * 1024)
                java.nio.file.Files.readAllBytes(path) else null }.getOrNull()
            val bytes = track.artwork ?: cached ?: if (local) Metadata.read(
                DesktopPreferences.ffmpeg.ifBlank { System.getenv("FFMPEG_PATH")?.takeIf { it.isNotBlank() } ?:
                    if (System.getProperty("os.name").startsWith("Windows")) "ffmpeg.exe" else "ffmpeg" },
                track.source, true).cover else if (track.artworkUrl != null && api != null) api.artwork(track.artworkUrl) else null
            if (bytes == null) return@runCatching null
            ImageIO.createImageInputStream(bytes.inputStream()).use { input ->
                val readers = ImageIO.getImageReaders(input); check(readers.hasNext())
                val reader = readers.next()
                try {
                    reader.input = input
                    val w = reader.getWidth(0); val h = reader.getHeight(0)
                    require(w in 1..8192 && h in 1..8192 && w.toLong() * h <= 20_000_000)
                    val parameters = reader.defaultReadParam
                    val scale = maxOf(w, h) / 480
                    if (scale > 1) parameters.setSourceSubsampling(scale, scale, 0, 0)
                    val image = reader.read(0, parameters)
                    if (cached == null) rememberDisk(key, bytes)
                    CoverData(image.toComposeImageBitmap(), artworkPalette(sampleArtwork(image)))
                } finally { reader.dispose() }
            }
        }.getOrNull()
        synchronized(cache) {
            if (result != null) { cache[key] = result; failed.remove(key) }
            else failed[key] = System.currentTimeMillis() + 60_000
        }
        return result
    }
}
@Composable private fun coverData(track: PlayerTrack?, api: ZiziClient?): CoverData? {
    val cover by produceState<CoverData?>(null, track?.id, track?.artwork, api) {
        value = null
        if (track != null) value = Covers.gate.withPermit { withContext(Dispatchers.IO) { Covers.load(track, api) } }
    }
    return cover
}
@Composable private fun Artwork(track: PlayerTrack?, api: ZiziClient?, size: Dp) {
    val cover = coverData(track, api)
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Panel), contentAlignment = Alignment.Center) {
        if (cover != null) Image(cover.image, "Обложка", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(ZiziIcons.FolderMusic, null, Modifier.size(size * 0.4f), tint = Muted)
    }
}
private fun chooseFiles(): List<File> {
    val picker = JFileChooser().apply {
        dialogTitle = "Добавить музыку в Zizi"; isMultiSelectionEnabled = true
        fileFilter = FileNameExtensionFilter("Аудио", "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFiles.toList() else emptyList()
}
private fun time(ms: Long): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(seconds / 60, seconds % 60) }

fun main() = application {
    val scope = rememberCoroutineScope()
    val store = remember { LibraryStore() }
    val initial by produceState<LibrarySnapshot?>(null) { value = withContext(Dispatchers.IO) { store.load() } }
    val snapshot = initial
    if (snapshot != null) {
        val ui = remember { DesktopUi(scope, store, snapshot) }
        var closing by remember { mutableStateOf(false) }
        Window(onCloseRequest = { if (!closing) { closing = true; ui.shutdown(done = { exitApplication() }, failed = { closing = false }) } },
            title = "ZiziPlayer · Desktop 0.3.2 preview", state = rememberWindowState(width = 1240.dp, height = 820.dp)) {
            LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(960, 680) }
            val state by ui.player.state.collectAsState()
            // Retain previous palette while the next cover decodes; obsolete loads cannot publish.
            val target by produceState(MattePalette(), state.track?.id, state.track?.artwork, state.track?.artworkUrl, ui.ffmpeg, ui.client, ui.prefs.artworkColor) {
                value = if (!ui.prefs.artworkColor || state.track == null) MattePalette() else
                    Covers.gate.withPermit { withContext(Dispatchers.IO) { Covers.load(state.track!!, ui.client)?.palette ?: MattePalette() } }
            }
            val matte = animatedMatte(target)
            CompositionLocalProvider(LocalMatte provides matte) {
                MaterialTheme(colorScheme = darkColorScheme(primary = matte.accent, onPrimary = Color(0xFF0B0B0C), background = Base,
                    onBackground = Ink, surface = Panel, onSurface = Ink, surfaceVariant = Chip,
                    onSurfaceVariant = Muted, secondaryContainer = Chip, onSecondaryContainer = Ink,
                    surfaceTint = Color.Transparent, outline = Color(0xFF303030))) {
                    Surface(Modifier.fillMaxSize(), color = Base) { DesktopContent(ui, closing) }
                }
            }
        }
    }
}
private data class LibraryCard(val key: String, val title: String, val subtitle: String,
    val icon: ImageVector, val cover: PlayerTrack? = null)

@Composable private fun DesktopContent(s: DesktopUi, closing: Boolean) {
    val state by s.player.state.collectAsState()
    val queue by s.player.queueState.collectAsState()
    var page by remember { mutableStateOf("Медиатека") }
    var detail by remember { mutableStateOf<LibraryCard?>(null) }
    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var sourceDialog by remember { mutableStateOf(false) }
    var effects by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var playlistDialog by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    fun navigate(label: String) {
        s.cancelSearch(); s.closePage(); page = label; detail = null; query = ""; submitted = false; focus.clearFocus()
    }
    fun search(value: String, kind: String = s.searchKind) {
        if (value.isBlank()) return
        query = value; submitted = true; focus.clearFocus(); s.search(value, kind)
    }
    fun artist(track: PlayerTrack) {
        if (!track.source.contains("://")) {
            s.closePage(); page = "Исполнители"; query = ""
            detail = LibraryCard("artist:${track.artist}", track.artist, "Локальная медиатека", ZiziIcons.Person, track)
            return
        }
        s.closePage(); detail = null; page = "Поиск"
        if (track.artistId != null) s.open(CatalogCollection(track.artistId, "artist", track.artist))
        else search(track.artist, "artist") // Name opens explicit choices, never guesses a catalog identity.
    }
    Column(Modifier.fillMaxSize().onKeyEvent {
        if (!editing && !sourceDialog && !playlistDialog && page != "Настройки" && !closing &&
            it.type == KeyEventType.KeyUp && it.key == Key.Spacebar) { s.player.togglePause(); true } else false
    }) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.width(190.dp).fillMaxHeight().background(Panel).padding(16.dp)) {
                Text("Zizi", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("ТВОЯ МУЗЫКА", color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(22.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    for ((label, icon) in listOf("Медиатека" to ZiziIcons.Library, "Поиск" to ZiziIcons.Search,
                        "Избранное" to ZiziIcons.Heart, "Плейлисты" to ZiziIcons.Queue,
                        "Папки" to ZiziIcons.Folder, "Исполнители" to ZiziIcons.Person, "Загрузки" to ZiziIcons.DownloadDone, "Очередь" to ZiziIcons.PlayNext)) {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (page == label) Chip else Color.Transparent)
                            .clickable { navigate(label) }.padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, null, tint = if (page == label) Brand else Muted, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp)); Text(label, color = if (page == label) Ink else Muted)
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Chip)
                    TextButton(onClick = { s.add(chooseFiles()) }, enabled = !closing) { Text("Добавить файлы") }
                    TextButton(onClick = { chooseFolder()?.let(s::scanFolder) }, enabled = !s.scanning) { Text("Добавить папку") }
                    TextButton(onClick = { sourceDialog = true }) { Text("Открыть ссылку") }
                }
                TextButton(onClick = { navigate("Настройки") }) {
                    Icon(ZiziIcons.Tune, null, Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)); Text("Настройки")
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().background(Base).padding(24.dp)) {
                if (!s.store.writable) Text("Библиотека доступна только для чтения. Изменения этого сеанса не сохранятся.", color = Brand, modifier = Modifier.padding(bottom = 12.dp))
                if (s.notice.isNotEmpty()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Chip).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(s.notice, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { s.notice = "" }) { Icon(ZiziIcons.Close, "Закрыть сообщение") }
                }
                val detailTitle = detail?.let { card ->
                    if (card.key.startsWith("pl:")) s.library.playlists.find { it.id == card.key.removePrefix("pl:") }?.title ?: card.title else card.title
                }
                val remote = s.openPage
                if (remote != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = s::closePage) { Icon(ZiziIcons.ArrowBack, "Назад") }
                        Text(if (remote.collection.kind == "artist") "Исполнитель" else if (remote.collection.kind == "album") "Альбом" else "Плейлист",
                            color = Muted, modifier = Modifier.weight(1f))
                        IconButton(onClick = { effects = !effects }) { Icon(ZiziIcons.Equalizer, "Эквалайзер") }
                    }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        item {
                            CollectionHero(remote.collection.title, remote.collection.subtitle,
                                remote.collection.artworkTrack(), s, remote.collection.kind == "artist")
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Загружено ${remote.tracks.size}" + (remote.total?.let { " из $it" } ?: ""), color = Muted, modifier = Modifier.weight(1f))
                                IconButton(onClick = { remote.tracks.shuffled().let { it.firstOrNull()?.let { t -> s.player.play(t, it) } } }, enabled = remote.tracks.isNotEmpty()) { Icon(ZiziIcons.Shuffle, "Перемешать загруженные треки") }
                                FilledTonalButton(onClick = { remote.tracks.firstOrNull()?.let { s.player.play(it, remote.tracks) } }, enabled = remote.tracks.isNotEmpty()) { Text("Слушать") }
                            }
                            TextButton(onClick = { s.playlist(remote.collection.title, remote.tracks); s.notice = "Загруженные треки сохранены отдельным плейлистом." }, enabled = remote.tracks.isNotEmpty()) { Text("Сохранить загруженные треки") }
                            if (s.pageError.isNotBlank()) Text(s.pageError, color = MaterialTheme.colorScheme.error)
                            if (s.opening) LinearProgressIndicator(Modifier.fillMaxWidth())
                        }
                        items(remote.tracks, key = { it.id }) { track -> TrackRow(s, track, remote.tracks, closing, onArtist = ::artist) }
                        item {
                            if (s.pageError.isNotBlank()) TextButton(onClick = { s.open(remote.collection, remote.tracks.isNotEmpty() && remote.nextOffset != null) }) { Text("Повторить") }
                            if (remote.nextOffset != null) OutlinedButton(onClick = { s.open(remote.collection, true) }, enabled = !s.opening) { Text("Загрузить ещё") }
                        }
                    }
                } else if (page == "Настройки") {
                    SettingsContent(s) { effects = true }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (detail != null) IconButton(onClick = { detail = null; query = "" }) { Icon(ZiziIcons.ArrowBack, "Назад") }
                        Text(detailTitle ?: page, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (page in listOf("Плейлисты", "Медиатека")) IconButton(onClick = { playlistDialog = true }) { Icon(ZiziIcons.Plus, "Создать плейлист") }
                        IconButton(onClick = { effects = !effects }) { Icon(ZiziIcons.Equalizer, "Эквалайзер", tint = if (effects) Brand else Ink) }
                    }
                    Spacer(Modifier.height(16.dp))
                    DesktopSearchField(query, { query = it; if (page == "Поиск") { submitted = false; s.cancelSearch() } },
                        onSubmit = { if (page == "Поиск") search(query) else focus.clearFocus() }, onFocus = { editing = it },
                        hint = if (page == "Поиск") "Что хочешь послушать?" else "Найти в списке", mobileSearch = page == "Поиск")
                    Spacer(Modifier.height(12.dp))
                    if (page == "Поиск") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for ((kind, label) in listOf("track" to "Треки", "artist" to "Исполнители", "album" to "Альбомы", "playlist" to "Плейлисты"))
                                FilterChip(selected = s.searchKind == kind, onClick = { if (query.isNotBlank()) search(query, kind) else s.selectSearchKind(kind) }, label = { Text(label) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (submitted) s.searchMessage else "Поиск музыки", color = Muted, modifier = Modifier.weight(1f))
                            SearchRefresh(s.searching, query.isNotBlank()) { search(query) }
                        }
                        if (!submitted) {
                            val suggestions = if (query.isBlank()) s.recentSearches.take(8) else app.ziziplayer.ui.SearchPresentation.completions(query, emptyList(), s.recentSearches, s.tracks.map { it.title })
                            LazyColumn(Modifier.weight(1f)) {
                                item { if (query.isBlank() && suggestions.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Недавние", Modifier.weight(1f)); TextButton(onClick = s::clearHistory) { Text("Очистить") }
                                } }
                                items(suggestions) { text -> Row(Modifier.fillMaxWidth().clickable { search(text) }.padding(16.dp)) {
                                    Icon(ZiziIcons.History, null, tint = Muted); Spacer(Modifier.width(16.dp)); Text(text)
                                } }
                            }
                        } else if (s.searchKind != "track") {
                            val cards = s.groups.map { LibraryCard(it.key, it.title, it.subtitle,
                                if (it.kind == "artist") ZiziIcons.Person else ZiziIcons.Queue, it.artworkTrack()) }
                            CollectionCards(cards, s, Modifier.weight(1f)) { card -> s.groups.find { it.key == card.key }?.let { s.open(it) } }
                            if (s.nextBrowse != null) TextButton(onClick = s::moreSearch, enabled = !s.searching) { Text("Загрузить ещё") }
                        } else {
                            LazyColumn(Modifier.weight(1f)) { items(s.results, key = { it.id }) { track -> TrackRow(s, track, s.results, closing, onArtist = ::artist) } }
                        }
                    } else {
                        val localArtists = s.tracks.filter { !it.source.contains("://") && it.artist.isNotBlank() }.groupBy { it.artist }
                        val cards = when (page) {
                            "Медиатека" -> listOf(LibraryCard("tracks", "Все треки", "${s.tracks.size} треков", ZiziIcons.Library, s.tracks.firstOrNull()),
                                LibraryCard("favorites", "Избранное", "${s.library.favorites.size} треков", ZiziIcons.HeartFilled,
                                    s.tracks.find { it.id in s.library.favorites })) +
                                s.library.playlists.map { LibraryCard("pl:" + it.id, it.title, "${it.trackIds.size} треков", ZiziIcons.Queue, s.playlistTracks(it.id).firstOrNull()) } +
                                s.library.folders.map { LibraryCard("dir:$it", File(it).name, "${s.folderTracks(it).size} треков", ZiziIcons.Folder, s.folderTracks(it).firstOrNull()) }
                            "Плейлисты" -> s.library.playlists.map { LibraryCard("pl:" + it.id, it.title, "${it.trackIds.size} треков", ZiziIcons.Queue, s.playlistTracks(it.id).firstOrNull()) }
                            "Папки" -> s.library.folders.map { LibraryCard("dir:$it", File(it).name, "${s.folderTracks(it).size} треков", ZiziIcons.Folder, s.folderTracks(it).firstOrNull()) }
                            "Исполнители" -> localArtists.map { (name, tracks) -> LibraryCard("artist:$name", name, "${tracks.size} локальных треков", ZiziIcons.Person, tracks.firstOrNull()) }
                            else -> emptyList()
                        }
                        if (detail == null && page in listOf("Медиатека", "Плейлисты", "Папки", "Исполнители")) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (s.scanning) "Читаем медиатеку…" else "${cards.size} коллекций", color = Muted, modifier = Modifier.weight(1f))
                                IconButton(onClick = { s.settings(s.prefs.copy(grid = !s.prefs.grid)) }) { Icon(if (s.prefs.grid) ZiziIcons.ViewList else ZiziIcons.ViewGrid, "Сменить вид") }
                                if (page == "Исполнители") TextButton(onClick = { navigate("Поиск"); s.selectSearchKind("artist") }) { Text("Найти в каталоге") }
                            }
                            if (cards.isEmpty()) Text("Добавь музыку или создай свою коллекцию.", color = Muted, modifier = Modifier.padding(vertical = 24.dp))
                            CollectionCards(cards.filter { it.title.contains(query, true) }, s, Modifier.weight(1f)) { detail = it; query = "" }
                        } else {
                            val key = detail?.key.orEmpty()
                            val playlistId = key.takeIf { it.startsWith("pl:") }?.removePrefix("pl:")
                            val all = when {
                                page == "Очередь" -> queue
                                page == "Загрузки" -> s.sorted(s.tracks.filter { it.id in s.downloaded })
                                key.startsWith("pl:") -> s.playlistTracks(key.removePrefix("pl:"))
                                key.startsWith("dir:") -> s.sorted(s.folderTracks(key.removePrefix("dir:")))
                                key.startsWith("artist:") -> s.sorted(localArtists[key.removePrefix("artist:")].orEmpty())
                                key == "favorites" || page == "Избранное" -> s.sorted(s.tracks.filter { it.id in s.library.favorites })
                                else -> s.sorted(s.tracks)
                            }
                            val visible = all.filter { (it.title + " " + it.artist).contains(query, true) }
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                item {
                                    if (detail != null) CollectionHero(detailTitle.orEmpty(), "${all.size} треков", all.firstOrNull(), s, false)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("${all.size} треков", Modifier.weight(1f), color = Muted)
                                        if (playlistId != null) PlaylistControls(s, playlistId) { detail = null }
                                        IconButton(onClick = { all.shuffled().let { list -> list.firstOrNull()?.let { s.player.play(it, list) } } }, enabled = all.isNotEmpty()) { Icon(ZiziIcons.Shuffle, "Перемешать") }
                                        FilledTonalButton(onClick = { all.firstOrNull()?.let { s.player.play(it, all) } }, enabled = all.isNotEmpty()) { Text("Слушать") }
                                    }
                                    if (all.isEmpty()) Text("Здесь пока нет треков.", color = Muted, modifier = Modifier.padding(vertical = 30.dp))
                                }
                                items(visible, key = { it.id }) { track -> TrackRow(s, track, all, closing, page == "Очередь", playlistId, ::artist) }
                            }
                        }
                    }
                }
            }
            AnimatedVisibility(effects, enter = expandHorizontally(tween(260)) + fadeIn(tween(180)),
                exit = shrinkHorizontally(tween(220)) + fadeOut(tween(140))) {
                EffectsPanel(s, Modifier.width(280.dp).fillMaxHeight().background(Panel).padding(18.dp))
            }
        }
        Transport(s, closing) { expanded = true }
    }
    if (sourceDialog) SourceDialog(s) { sourceDialog = false }
    if (playlistDialog) NameDialog("Новый плейлист", "", { s.playlist(it); playlistDialog = false }) { playlistDialog = false }
    if (expanded) Dialog(onDismissRequest = { expanded = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.widthIn(max = 780.dp).fillMaxWidth().padding(24.dp), shape = RoundedCornerShape(24.dp), color = LocalMatte.current.card) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Сейчас играет", Modifier.weight(1f), color = Ink)
                    IconButton(onClick = { expanded = false }) { Icon(ZiziIcons.Close, "Свернуть") }
                }
                Artwork(state.track, s.client, 300.dp); Spacer(Modifier.height(20.dp))
                Text(state.track?.title ?: "Музыка не выбрана", style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                TextButton(onClick = { state.track?.let(::artist); expanded = false }, enabled = !state.track?.artist.isNullOrBlank()) { Text(state.track?.artist.orEmpty()) }
                Transport(s, closing) { expanded = false }
            }
        }
    }
}

private fun chooseFolder(): File? {
    val picker = JFileChooser().apply { dialogTitle = "Выбрать папку с музыкой"; fileSelectionMode = JFileChooser.DIRECTORIES_ONLY }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFile else null
}
@Composable private fun CollectionHero(title: String, subtitle: String, track: PlayerTrack?, s: DesktopUi, artist: Boolean) {
    val cover = coverData(track, s.client)
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp).clip(RoundedCornerShape(16.dp)).background(cover?.palette?.card ?: Panel)) {
        if (artist) {
            Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
                if (cover != null) Image(cover.image, "Фото исполнителя", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(ZiziIcons.Person, null, Modifier.size(72.dp), tint = Muted)
            }
            Column(Modifier.padding(20.dp)) {
                Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                if (subtitle.isNotBlank()) Text(subtitle, color = Ink.copy(alpha = .8f))
            }
        } else Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(track, s.client, 150.dp); Spacer(Modifier.width(24.dp))
            Column { Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Ink.copy(alpha = .8f), modifier = Modifier.padding(top = 12.dp)) }
        }
    }
}
@Composable private fun CollectionCards(cards: List<LibraryCard>, s: DesktopUi, modifier: Modifier, open: (LibraryCard) -> Unit) {
    BoxWithConstraints(modifier) {
        val columns = if (s.prefs.grid) (maxWidth.value / 190f).toInt().coerceIn(1, 6) else 1
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(cards.chunked(columns)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { card ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Panel).clickable { open(card) }.padding(14.dp)) {
                            if (s.prefs.grid) {
                                if (card.cover != null) Artwork(card.cover, s.client, 130.dp)
                                else Box(Modifier.size(130.dp).clip(RoundedCornerShape(10.dp)).background(Chip), contentAlignment = Alignment.Center) { Icon(card.icon, null, Modifier.size(46.dp), tint = Muted) }
                                Spacer(Modifier.height(12.dp))
                                Text(card.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                Text(card.subtitle, color = Muted, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                            } else Row(verticalAlignment = Alignment.CenterVertically) {
                                Artwork(card.cover, s.client, 52.dp); Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) { Text(card.title, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(card.subtitle, color = Muted) }
                                Icon(ZiziIcons.ChevronRight, null, tint = Muted)
                            }
                        }
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
@Composable private fun TrackRow(s: DesktopUi, original: PlayerTrack, all: List<PlayerTrack>, closing: Boolean,
    queue: Boolean = false, playlistId: String? = null, onArtist: (PlayerTrack) -> Unit) {
    val state by s.player.state.collectAsState()
    val metadata by s.player.metadata.collectAsState()
    val selected = original.id == state.track?.id
    val track = if (selected) state.track!! else metadata[original.id] ?: original
    var menu by remember { mutableStateOf(false) }
    var playlists by remember { mutableStateOf(false) }
    var remove by remember { mutableStateOf(false) }
    val saved = s.tracks.any { it.id == track.id }
    val favorite = track.id in s.library.favorites
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (selected) LocalMatte.current.chip else Color.Transparent)
        .clickable(enabled = !closing) { s.player.play(track, all) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(track, s.client, 52.dp); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) LocalMatte.current.accent else Ink)
            if (track.id in s.downloaded) Text("Скачано", color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(track.artist.ifBlank { if (track.source.startsWith("zizi://")) "Zizi" else "Локальный файл" }, color = Muted,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable(enabled = track.artist.isNotBlank()) { onArtist(track) })
        }
        if (queue || playlistId != null) {
            IconButton(onClick = { if (queue) s.player.move(track.id, -1) else s.playlistMove(playlistId!!, track.id, -1) }, enabled = all.indexOfFirst { it.id == track.id } > 0) { Icon(ZiziIcons.ChevronUp, "Переместить выше", Modifier.size(20.dp)) }
            IconButton(onClick = { if (queue) s.player.move(track.id, 1) else s.playlistMove(playlistId!!, track.id, 1) }, enabled = all.indexOfFirst { it.id == track.id } < all.lastIndex) { Icon(ZiziIcons.ChevronDown, "Переместить ниже", Modifier.size(20.dp)) }
        }
        IconButton(onClick = { s.favorite(track) }) { Icon(if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart,
            if (favorite) "Убрать из избранного" else "В избранное", tint = if (favorite) Brand else Muted, modifier = Modifier.size(20.dp)) }
        Text(track.durationMs?.let(::time) ?: "—", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(42.dp))
        Box {
            IconButton(onClick = { menu = true }) { Icon(ZiziIcons.More, "Действия с треком") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text(if (saved) "Убрать из медиатеки" else "Сохранить в медиатеку") }, onClick = { menu = false; if (saved) remove = true else s.save(track) })
                DropdownMenuItem(text = { Text("Добавить в плейлист") }, onClick = { menu = false; playlists = true })
                DropdownMenuItem(text = { Text("Слушать следующим") }, onClick = { s.player.enqueue(track, true); menu = false })
                DropdownMenuItem(text = { Text("В конец очереди") }, onClick = { s.player.enqueue(track); menu = false })
                if (track.source.startsWith("zizi://") && track.id !in s.downloaded)
                    DropdownMenuItem(text = { Text("Скачать для офлайн") }, onClick = { s.download(track); menu = false })
                if (track.artist.isNotBlank()) DropdownMenuItem(text = { Text("Перейти к исполнителю") }, onClick = { menu = false; onArtist(track) })
                if (queue) DropdownMenuItem(text = { Text("Удалить из очереди") }, onClick = { s.player.remove(track.id); menu = false })
                if (playlistId != null) DropdownMenuItem(text = { Text("Убрать из плейлиста") }, onClick = { s.playlistRemove(playlistId, track.id); menu = false })
            }
        }
    }
    if (remove) ConfirmDialog("Убрать из медиатеки?", "Трек будет убран также из избранного и твоих плейлистов. Файл на диске останется.",
        { s.forget(track.id); remove = false }) { remove = false }
    if (playlists) PlaylistPicker(s, track) { playlists = false }
}
@Composable private fun PlaylistPicker(s: DesktopUi, track: PlayerTrack, dismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text("Добавить в плейлист") }, text = {
        Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
            s.library.playlists.forEach { list -> TextButton(onClick = { s.addToPlaylist(list.id, track); dismiss() }) { Text(list.title) } }
            OutlinedTextField(title, { title = it.take(100) }, label = { Text("Название нового плейлиста") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { s.playlist(title, listOf(track)); dismiss() }, enabled = title.isNotBlank()) { Text("Создать и добавить") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun NameDialog(title: String, initial: String, confirm: (String) -> Unit, dismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text(title) }, text = {
        OutlinedTextField(text, { text = it.take(100) }, singleLine = true, label = { Text("Название") })
    }, confirmButton = { TextButton(onClick = { confirm(text) }, enabled = text.isNotBlank()) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun ConfirmDialog(title: String, text: String, confirm: () -> Unit, dismiss: () -> Unit) {
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = confirm) { Text("Удалить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun PlaylistControls(s: DesktopUi, id: String, deleted: () -> Unit) {
    var rename by remember { mutableStateOf(false) }; var remove by remember { mutableStateOf(false) }
    IconButton(onClick = { rename = true }) { Icon(ZiziIcons.Edit, "Переименовать плейлист") }
    IconButton(onClick = { remove = true }) { Icon(ZiziIcons.Trash, "Удалить плейлист") }
    if (rename) NameDialog("Переименовать плейлист", s.library.playlists.find { it.id == id }?.title.orEmpty(),
        { s.renamePlaylist(id, it); rename = false }) { rename = false }
    if (remove) ConfirmDialog("Удалить плейлист?", "Треки останутся в медиатеке, файлы не будут удалены.",
        { s.deletePlaylist(id); remove = false; deleted() }) { remove = false }
}
@Composable private fun Transport(s: DesktopUi, closing: Boolean, expand: () -> Unit) {
    val state by s.player.state.collectAsState()
    val progress by s.player.progress.collectAsState()
    val valid = progress.trackId == state.track?.id && progress.generation == state.generation
    val duration = if (valid) progress.durationMs ?: 0 else 0
    val position = if (valid) progress.positionMs else 0
    var drag by remember(state.generation) { mutableStateOf<Float?>(null) }
    HorizontalDivider(color = Color(0xFF292929))
    Column(Modifier.fillMaxWidth().background(LocalMatte.current.surface).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(time((drag?.toLong() ?: position)), color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            Slider(value = drag ?: position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
                onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { s.player.seek(it.toLong()) }; drag = null },
                enabled = state.seekable && duration > 0 && !closing, valueRange = 0f..duration.coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f).height(24.dp))
            Text(if (duration > 0) time(duration) else "—:—", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 12.dp).width(48.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(Modifier.clickable(onClick = expand)) { Artwork(state.track, s.client, 54.dp) }
            Column(Modifier.weight(1f)) {
                Text(state.track?.title ?: "Zizi готов к музыке", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(if (closing) "Закрываем аудиосеанс…" else if (s.downloadId != null) "Загрузка · ${s.downloadProgress}" else state.message, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { s.settings(s.prefs.copy(shuffle = !s.prefs.shuffle)) }, enabled = !closing) {
                Icon(ZiziIcons.Shuffle, "Случайный порядок: ${if (s.prefs.shuffle) "включён" else "выключен"}", tint = if (s.prefs.shuffle) LocalMatte.current.accent else Muted)
            }
            IconButton(onClick = { s.player.adjacent(-1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipPrevious, "Предыдущий трек") }
            FilledIconButton(onClick = { s.player.togglePause() }, enabled = !closing && state.track != null, modifier = Modifier.size(52.dp)) {
                val pauses = state.phase in setOf(PlaybackPhase.PLAYING, PlaybackPhase.LOADING)
                Icon(if (pauses) ZiziIcons.Pause else ZiziIcons.PlayFilled, if (pauses) "Пауза" else "Воспроизвести")
            }
            IconButton(onClick = { s.player.adjacent(1) }, enabled = !closing && s.player.queue.isNotEmpty()) { Icon(ZiziIcons.SkipNext, "Следующий трек") }
            IconButton(onClick = { s.player.stop() }, enabled = !closing && state.track != null) { Icon(ZiziIcons.Stop, "Остановить") }
            IconButton(onClick = { s.settings(s.prefs.copy(repeat = RepeatMode.entries[(s.prefs.repeat.ordinal + 1) % RepeatMode.entries.size])) }, enabled = !closing) {
                Icon(if (s.prefs.repeat == RepeatMode.ONE) ZiziIcons.RepeatOne else ZiziIcons.Repeat,
                    "Повтор: " + when (s.prefs.repeat) { RepeatMode.OFF -> "выключен"; RepeatMode.ALL -> "вся очередь"; RepeatMode.ONE -> "один трек" },
                    tint = if (s.prefs.repeat == RepeatMode.OFF) Muted else LocalMatte.current.accent)
            }
            Text("${(s.gain * 100).toInt()}%", color = Muted)
            Slider(s.gain, s::volume, modifier = Modifier.width(90.dp))
        }
    }
}
private data class SettingsSection(val title: String, val icon: ImageVector, val keywords: String)
private val settingSections = listOf(
    SettingsSection("Оформление", ZiziIcons.Palette, "цвет из обложки amoled тема палитра"),
    SettingsSection("Библиотека", ZiziIcons.Library, "папки сканирование сортировка сетка список"),
    SettingsSection("Звук", ZiziIcons.Equalizer, "эквалайзер dsp громкость эффекты глобально"),
    SettingsSection("Загрузки", ZiziIcons.DownloadDone, "офлайн скачанные память диск"),
    SettingsSection("Поиск", ZiziIcons.Search, "история недавние запросы"),
    SettingsSection("О приложении", ZiziIcons.Info, "версия диагностика ffmpeg сеть сервер"))

@Composable private fun SettingsContent(s: DesktopUi, effects: () -> Unit) {
    var section by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("") }
    var diagnostics by remember { mutableStateOf(false) }
    var confirmHistory by remember { mutableStateOf(false) }
    val state by s.player.state.collectAsState()
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (section != null) IconButton(onClick = { section = null; filter = "" }) { Icon(ZiziIcons.ArrowBack, "Все настройки") }
        Text(section ?: "Настройки", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(20.dp))
    DesktopSearchField(filter, { filter = it; section = null }, onSubmit = {}, onFocus = {}, hint = "Найти настройку", mobileSearch = false)
    Spacer(Modifier.height(20.dp))
    val shown = settingSections.filter { entry -> (section == null || entry.title == section) &&
        filter.trim().split(Regex("\\s+")).all { (entry.title + " " + entry.keywords).contains(it, true) } }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (section == null && filter.isBlank()) {
            items(settingSections.chunked(2)) { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    pair.forEach { item ->
                        Column(Modifier.weight(1f).height(135.dp).clip(RoundedCornerShape(18.dp)).background(Panel)
                            .clickable { section = item.title }.padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(item.icon, null, Modifier.size(30.dp), tint = if (item.title == "Оформление") LocalMatte.current.accent else Ink)
                            Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        } else {
            items(shown) { entry ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(entry.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    when (entry.title) {
                        "Оформление" -> {
                            SettingToggle("Цвет из обложки", s.prefs.artworkColor) { s.settings(s.prefs.copy(artworkColor = it)) }
                            Row(Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(14.dp)).background(LocalMatte.current.card).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(ZiziIcons.Palette, null, tint = LocalMatte.current.accent)
                                Spacer(Modifier.width(16.dp)); Text("Матовый AMOLED", color = Ink)
                            }
                        }
                        "Библиотека" -> {
                            SettingToggle("Сетка коллекций", s.prefs.grid) { s.settings(s.prefs.copy(grid = it)) }
                            Text("Сортировка треков", fontWeight = FontWeight.SemiBold)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for ((mode, label) in listOf(TrackSort.TITLE to "Название", TrackSort.ARTIST to "Исполнитель", TrackSort.RECENT to "Добавлены", TrackSort.DURATION to "Длительность"))
                                    FilterChip(s.prefs.sort == mode, { s.settings(s.prefs.copy(sort = mode)) }, label = { Text(label) })
                            }
                            HorizontalDivider(color = Chip)
                            s.library.folders.forEach { path ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(File(path).name); Text(path, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 2) }
                                    IconButton(onClick = { s.scanFolder(File(path)) }, enabled = !s.scanning) { Icon(ZiziIcons.Refresh, "Пересканировать папку") }
                                    IconButton(onClick = { s.removeFolder(path) }) { Icon(ZiziIcons.Close, "Отключить папку, оставить треки и файлы") }
                                }
                            }
                            TextButton(onClick = { chooseFolder()?.let(s::scanFolder) }, enabled = !s.scanning) { Text(if (s.scanning) "Сканирование · ${s.scanMessage}" else "Добавить папку") }
                            if (s.scanning) TextButton(onClick = s::cancelScan) { Text("Остановить сканирование") }
                        }
                        "Звук" -> {
                            SettingToggle("Один эквалайзер для всей музыки", s.prefs.dspGlobal) { s.settings(s.prefs.copy(dspGlobal = it)) }
                            Text(if (s.prefs.dspGlobal) "Общие настройки звука" else "Эффекты сохраняются отдельно для каждого трека", color = Muted)
                            FilledTonalButton(onClick = effects) { Icon(ZiziIcons.Equalizer, null); Spacer(Modifier.width(10.dp)); Text("Открыть эквалайзер") }
                            Text("Громкость · ${(s.gain * 100).toInt()}%")
                            Slider(s.gain, s::volume)
                        }
                        "Загрузки" -> {
                            Text("${s.downloadStats.first} треков · ${s.downloadStats.second / (1024 * 1024)} МБ", color = Muted)
                            if (s.downloadId != null) Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Загрузка · ${s.downloadProgress}", Modifier.weight(1f))
                                TextButton(onClick = s::cancelDownload) { Text("Отменить") }
                            }
                            TextButton(onClick = { s.showDataFolder(true) }) { Text("Открыть папку загрузок") }
                            TextButton(onClick = s::refreshDownloads) { Text("Проверить файлы") }
                            TextButton(onClick = { s.scope.launch { withContext(Dispatchers.IO) { Covers.clear() }; s.notice = "Кэш обложек очищен. Аудиозагрузки сохранены." } }) { Text("Очистить кэш обложек") }
                            s.tracks.filter { it.id in s.downloaded }.forEach { track -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(track.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                var confirm by remember(track.id) { mutableStateOf(false) }
                                IconButton(onClick = { confirm = true }, enabled = track.id != state.track?.id) { Icon(ZiziIcons.Trash, "Удалить скачанный файл") }
                                if (confirm) ConfirmDialog("Удалить скачанный файл?", "Трек останется в медиатеке и будет воспроизводиться из сети.",
                                    { s.deleteDownload(track.id); confirm = false }) { confirm = false }
                            } }
                        }
                        "Поиск" -> {
                            Text("История запросов · ${s.recentSearches.size}", color = Muted)
                            TextButton(onClick = { confirmHistory = true }, enabled = s.recentSearches.isNotEmpty()) { Text("Очистить историю поиска") }
                        }
                        "О приложении" -> {
                            Text("ZiziPlayer Desktop 0.3.2 preview")
                            TextButton(onClick = { s.showDataFolder() }) { Text("Открыть папку данных") }
                            TextButton(onClick = { diagnostics = true }) { Text("Диагностика и аудиодекодер") }
                        }
                    }
                }
            }
            if (shown.isEmpty()) item { Text("Настройка не найдена", color = Muted) }
        }
    }
    if (diagnostics) AudioToolsDialog(s) { diagnostics = false }
    if (confirmHistory) ConfirmDialog("Очистить историю?", "Сохранённые треки и плейлисты не изменятся.",
        { s.clearHistory(); confirmHistory = false }) { confirmHistory = false }
}
@Composable private fun SettingToggle(title: String, value: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Spacer(Modifier.width(16.dp)); Switch(value, change)
    }
}
@Composable private fun AudioToolsDialog(s: DesktopUi, dismiss: () -> Unit) {
    var executable by remember { mutableStateOf(s.ffmpeg) }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss,
        title = { Text("Диагностика") }, text = {
        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(s.connectionMessage, color = Muted)
            if (s.httpCompatibility) Text("Соединение с сервером использует HTTP и не зашифровано.", color = Brand)
            HorizontalDivider(color = Chip)
            Text("Аудиодекодер", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(executable, { executable = it }, label = { Text("Путь к FFmpeg") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { val picker = JFileChooser(); if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) executable = picker.selectedFile.absolutePath }) { Text("Выбрать FFmpeg…") }
            Text("ffprobe должен лежать рядом. Новый путь применяется при следующем открытии трека.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { s.audioSettings(executable); dismiss() }, enabled = executable.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun SourceDialog(s: DesktopUi, dismiss: () -> Unit) {
    var source by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss, title = { Text("Открыть ссылку") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("zizi://dz/ID, zizi://yt/VIDEO_ID, zizi://mix/dz%3AID или прямая HTTPS-ссылка на аудио. Не страница YouTube. HLS/DASH и HTTP-редиректы пока не поддерживаются.")
            OutlinedTextField(source, { source = it }, singleLine = true, label = { Text("Адрес трека") })
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        try { s.addSource(source); source = ""; dismiss() } catch (_: Exception) { error = "Некорректная или неподдерживаемая ссылка" }
    }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable
private fun EffectsPanel(s: DesktopUi, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Звук Zizi", style = MaterialTheme.typography.titleLarge)
        SettingToggle("Для всей музыки", s.prefs.dspGlobal) { s.settings(s.prefs.copy(dspGlobal = it)) }
        val state by s.player.state.collectAsState()
        if (!s.prefs.dspGlobal && state.track == null) {
            Text("Выбери трек для настройки его звучания.", color = Muted)
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DSP", Modifier.weight(1f)); Switch(s.config.enabled, { s.dsp(s.config.copy(enabled = it)) })
        }
        Text("Оригинальные пресеты 6.39.9", style = MaterialTheme.typography.bodySmall)
        for ((title, presets) in listOf("Тембр" to DspPresets.curve, "Объём" to DspPresets.space, "Устройство" to DspPresets.device)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                DropdownMenu(expanded, { expanded = false }) {
                    presets.forEach { preset -> DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                        s.dsp(preset.transform(s.config)); expanded = false
                    }) }
                }
            }
        }
        TextButton(onClick = { s.dsp(DspConfig.NEUTRAL) }) { Text("Сбросить всё") }
        Text("Преамп: ${"%.1f".format(s.config.preampDb)} дБ")
        Slider(s.config.preampDb, { s.dsp(s.config.copy(preampDb = it)) }, valueRange = -12f..6f)
        val bands = listOf("31 Гц", "62 Гц", "125 Гц", "250 Гц", "500 Гц", "1 кГц", "2 кГц", "4 кГц", "8 кГц", "16 кГц")
        bands.forEachIndexed { index, label ->
            Text("$label · ${"%.1f".format(s.config.bandsDb[index])} дБ", style = MaterialTheme.typography.labelSmall)
            Slider(s.config.bandsDb[index], { value ->
                s.dsp(s.config.copy(enabled = true, bandsDb = s.config.bandsDb.toMutableList().also { it[index] = value }))
            }, valueRange = -12f..12f, modifier = Modifier.height(30.dp))
        }
        Text("Реверберация")
        Slider(s.config.reverbMix, { s.dsp(s.config.copy(enabled = true, reverbMix = it)) })
        Text("8D · глубина вращения")
        Slider(s.config.rotation, { s.dsp(s.config.copy(enabled = true, rotation = it)) })
        Text("Под водой")
        Slider(s.config.underwater, { s.dsp(s.config.copy(enabled = true, underwater = it)) })
        Text("Ширина стерео")
        Slider(s.config.width, { s.dsp(s.config.copy(enabled = true, width = it)) }, valueRange = -1f..1f)
        Text("Насыщение баса")
        Slider(s.config.bassDrive, { s.dsp(s.config.copy(enabled = true, bassDrive = it)) })
        Text("Воздух")
        Slider(s.config.air, { s.dsp(s.config.copy(enabled = true, air = it)) })
        Text("Размер помещения")
        Slider(s.config.reverbSize, { s.dsp(s.config.copy(enabled = true, reverbSize = it)) })
        Text("Поглощение верха")
        Slider(s.config.reverbDamp, { s.dsp(s.config.copy(enabled = true, reverbDamp = it)) })
        Text("Ламповое насыщение")
        Slider(s.config.drive, { s.dsp(s.config.copy(enabled = true, drive = it)) })
        SettingToggle("Лимитер", s.config.limiter) { s.dsp(s.config.copy(limiter = it)) }
    }
}

/** Desktop adapter of Android 6.39.9 SearchField: exact heights, radius, type and colors.
 * Enter / submit icon replace Android's IME action. No outlined Material input here.
 */
@Composable private fun DesktopSearchField(
    text: String, onText: (String) -> Unit, onSubmit: () -> Unit,
    onFocus: (Boolean) -> Unit, hint: String = "Что хочешь послушать?", mobileSearch: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val light = mobileSearch && !focused
    val foreground = if (light) Color(0xFF121212) else Ink
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.fillMaxWidth().height(if (focused) 52.dp else 49.5.dp)
            .clip(RoundedCornerShape(3.5.dp)).background(if (light) Color.White else Color(0xFF292929))
            .padding(start = 9.5.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (focused) IconButton(onClick = { focusManager.clearFocus() }) {
                Icon(ZiziIcons.ArrowBack, "Закрыть ввод", tint = foreground, modifier = Modifier.size(23.dp))
            } else Icon(ZiziIcons.Search, null, tint = foreground, modifier = Modifier.size(29.dp))
            Spacer(Modifier.width(11.dp))
            BasicTextField(text, { onText(it.take(300)) }, singleLine = true,
                textStyle = TextStyle(color = foreground, fontSize = 17.sp,
                    fontWeight = if (focused) FontWeight.Medium else FontWeight.Bold),
                cursorBrush = SolidColor(Brand),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
                    .onPreviewKeyEvent {
                        if (it.key == Key.Enter && it.type == KeyEventType.KeyUp) { onSubmit(); true } else false
                    }, decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) Text(hint, color = if (light) Color(0xFF6E6E6E) else Muted,
                            fontSize = 16.sp, fontWeight = if (focused) FontWeight.Normal else FontWeight.SemiBold)
                        inner()
                    }
                })
            if (text.isNotEmpty()) {
                IconButton(onClick = { onText("") }) { Icon(ZiziIcons.Close, "Очистить", tint = foreground, modifier = Modifier.size(22.dp)) }
                if (mobileSearch) IconButton(onClick = onSubmit) { Icon(ZiziIcons.Search, "Найти", tint = foreground, modifier = Modifier.size(23.dp)) }
            }
        }
    }
}
/** Mobile refresh motion: 900 ms linear turn, 340 ms settling to the complete turn. */
@Composable private fun SearchRefresh(refreshing: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) {
                angle.animateTo(angle.value + 360f, tween(900, easing = LinearEasing))
                angle.snapTo(angle.value % 360f)
            }
        } else if (angle.value != 0f) {
            angle.animateTo(360f, tween(340, easing = FastOutSlowInEasing))
            angle.snapTo(0f)
        }
    }
    IconButton(onClick = { if (!refreshing) onClick() }, enabled = enabled,
        modifier = Modifier.size(42.dp).graphicsLayer { rotationZ = angle.value }) {
        Icon(ZiziIcons.Refresh, "Повторить поиск", tint = if (enabled) Brand else Muted, modifier = Modifier.size(23.dp))
    }
}
