# Проверки Desktop 0.3.4 preview

Выполнены на the Computer без Gradle/Compose зависимостей:

- 59 статических source contracts, включая семь upstream SHA-256.
- Проверка скобок/строк/комментариев Kotlin: 0 файлов с проблемами. Это НЕ компилятор.
- Реальное исполнение Java production math: 19 сценариев, цветовые/случайные выборки.
- Реальное исполнение Java production layout: 17 286 конфигураций, плюс размеры hero/прогресса.
- Независимая модель 4096 цветов: минимальный контраст #F6F7F8 к новому solid header ~5.221:1.
- 9 Python-тестов безопасного подключения — прошли.

Добавлены восемь Kotlin/JUnit-тестов (семь DesktopRefinementTest и один CatalogBrowseTest). Они НЕ запускались здесь. Существующие Kotlin/audio tests также не запускались. Java-проверки не проверяют Compose layout или Kotlin API compatibility.

Windows EXE не собран; реальный рендер, pointer input, hotplug и переключение гарнитуры на Windows не испытаны. Никаких новых зависимостей не установлено. Финальная проверка ZIP/hash/extract — во внешнем docs/desktop/VALIDATION_0.3.4.txt.
