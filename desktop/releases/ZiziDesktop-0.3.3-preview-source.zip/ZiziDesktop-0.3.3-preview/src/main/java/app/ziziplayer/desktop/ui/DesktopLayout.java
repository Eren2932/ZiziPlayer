package app.ziziplayer.desktop.ui;

/** Logical Compose dp, not screenshot pixels. Kept pure for real JVM geometry checks. */
public final class DesktopLayout {
    private DesktopLayout() {}
    public static float searchWidth(float width) { return Math.min(480f, Math.max(0f, width - 24f) * .46f); }
    public static float sidebarWidth(float width, int mode, boolean rightOpen) {
        if (mode == 0) return 0f;
        return mode == 1 || (width < 1180f && rightOpen) ? 64f : 300f;
    }
    public static float rightWidth(float width) { return width < 1180f ? 280f : 330f; }
    public static int columns(float width) { return Math.max(1, (int)(width / 168f)); }
    public static float artworkSize(float width, int columns) {
        if (columns < 1) throw new IllegalArgumentException("columns");
        return Math.max(0f, Math.min(184f, (width - 12f * (columns - 1)) / columns - 20f));
    }
}
