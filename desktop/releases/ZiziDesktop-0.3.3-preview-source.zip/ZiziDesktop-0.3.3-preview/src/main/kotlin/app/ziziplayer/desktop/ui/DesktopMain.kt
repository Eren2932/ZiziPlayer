@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package app.ziziplayer.desktop.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.border
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.VerticalScrollbar
import androidx.compose.foundation.rememberScrollbarAdapter
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.ziziplayer.desktop.*
import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.ZiziIcons
import java.io.File
import javax.imageio.ImageIO
import javax.swing.JFileChooser
import javax.swing.filechooser.FileNameExtensionFilter
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withPermit
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.graphics.vector.ImageVector

private val Brand = Color(0xFFF97316)
private val Base = Color.Black
private val Panel = Color(0xFF101010)
private val Chip = Color(0xFF1B1B1B)
private val Ink = Color(0xFFF6F7F8)
private val Muted = Color(0xFF9A9A9A)

private data class CoverData(val image: ImageBitmap, val palette: MattePalette, val primary: Int?)
private object Covers {
    val gate = kotlinx.coroutines.sync.Semaphore(3)
    private val loadLocks = Array(32) { Any() }
    private val directory = LibraryStore.defaultDirectory().resolve("artwork")
    private val cache = object : LinkedHashMap<String, CoverData>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CoverData>?): Boolean = size > 64
    }
    private val failed = object : LinkedHashMap<String, Long>(128, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean = size > 128
    }
    private var writes = 0
    fun clear() {
        synchronized(cache) { cache.clear(); failed.clear() }
        if (java.nio.file.Files.isDirectory(directory)) java.nio.file.Files.list(directory).use { stream ->
            stream.filter { it.fileName.toString().matches(Regex("[0-9a-f]{64}\\.img")) }
                .forEach { runCatching { java.nio.file.Files.deleteIfExists(it) } }
        }
    }
    private fun rememberDisk(key: String, bytes: ByteArray) {
        runCatching {
            java.nio.file.Files.createDirectories(directory)
            val target = diskPath(key)
            val tmp = java.nio.file.Files.createTempFile(directory, "cover-", ".tmp")
            try {
                java.nio.file.Files.write(tmp, bytes)
                java.nio.file.Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            } finally { java.nio.file.Files.deleteIfExists(tmp) }
            synchronized(cache) { writes++ }
            // Bounded disk cache. Decoding/sampling are never done on the UI thread.
            if (writes % 16 == 0) {
                val files = java.nio.file.Files.list(directory).use { it.filter { p -> p.fileName.toString().endsWith(".img") }.toList() }
                var total = files.sumOf { java.nio.file.Files.size(it) }
                for (path in files.sortedBy { java.nio.file.Files.getLastModifiedTime(it).toMillis() }) {
                    if (total <= 96L * 1024 * 1024) break
                    val size = java.nio.file.Files.size(path)
                    if (java.nio.file.Files.deleteIfExists(path)) total -= size
                }
            }
        }
    }
    private fun diskPath(key: String): java.nio.file.Path {
        val hash = java.security.MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        return directory.resolve("$hash.img")
    }
    fun load(track: PlayerTrack, api: ZiziClient?): CoverData? =
        synchronized(loadLocks[(track.id.hashCode() and Int.MAX_VALUE) % loadLocks.size]) { loadLocked(track, api) }
    private fun loadLocked(track: PlayerTrack, api: ZiziClient?): CoverData? {
        val local = !track.source.contains("://") && !track.source.startsWith("collection:")
        val key = track.id + ":" + track.artworkUrl + if (local) ":" + File(track.source).lastModified() else ""
        synchronized(cache) {
            cache[key]?.let { return it }
            if ((failed[key] ?: 0L) > System.currentTimeMillis() && track.artwork == null) return null
        }
        val result = runCatching {
            val path = diskPath(key)
            val cached = runCatching { if (java.nio.file.Files.isRegularFile(path) && java.nio.file.Files.size(path) <= 5 * 1024 * 1024)
                java.nio.file.Files.readAllBytes(path) else null }.getOrNull()
            val bytes = track.artwork ?: cached ?: if (local) Metadata.read(
                DesktopPreferences.ffmpeg.ifBlank { System.getenv("FFMPEG_PATH")?.takeIf { it.isNotBlank() } ?:
                    if (System.getProperty("os.name").startsWith("Windows")) "ffmpeg.exe" else "ffmpeg" },
                track.source, true).cover else if (track.artworkUrl != null && api != null) api.artwork(track.artworkUrl) else null
            if (bytes == null) return@runCatching null
            ImageIO.createImageInputStream(bytes.inputStream()).use { input ->
                val readers = ImageIO.getImageReaders(input); check(readers.hasNext())
                val reader = readers.next()
                try {
                    reader.input = input
                    val w = reader.getWidth(0); val h = reader.getHeight(0)
                    require(w in 1..8192 && h in 1..8192 && w.toLong() * h <= 20_000_000)
                    val parameters = reader.defaultReadParam
                    val scale = maxOf(w, h) / 480
                    if (scale > 1) parameters.setSourceSubsampling(scale, scale, 0, 0)
                    val image = reader.read(0, parameters)
                    if (cached == null) rememberDisk(key, bytes)
                    sampleArtwork(image).let { primary -> CoverData(image.toComposeImageBitmap(), artworkPalette(primary), primary) }
                } finally { reader.dispose() }
            }
        }.getOrNull()
        synchronized(cache) {
            if (result != null) { cache[key] = result; failed.remove(key) }
            else failed[key] = System.currentTimeMillis() + 60_000
        }
        return result
    }
}
@Composable private fun coverData(track: PlayerTrack?, api: ZiziClient?): CoverData? {
    val cover by produceState<CoverData?>(null, track?.id, track?.artwork, track?.artworkUrl, api) {
        value = null
        if (track != null) value = Covers.gate.withPermit { withContext(Dispatchers.IO) { Covers.load(track, api) } }
    }
    return cover
}
@Composable private fun Artwork(track: PlayerTrack?, api: ZiziClient?, size: Dp, artist: Boolean = false) {
    val cover = coverData(track, api)
    Box(Modifier.size(size).clip(if (artist) CircleShape else RoundedCornerShape(4.dp)).background(Panel), contentAlignment = Alignment.Center) {
        if (cover != null) Image(cover.image, "Обложка", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(ZiziIcons.FolderMusic, null, Modifier.size(size * 0.4f), tint = Muted)
    }
}
private fun chooseFiles(): List<File> {
    val picker = JFileChooser().apply {
        dialogTitle = "Добавить музыку в Zizi"; isMultiSelectionEnabled = true
        fileFilter = FileNameExtensionFilter("Аудио", "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFiles.toList() else emptyList()
}
private fun time(ms: Long): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(seconds / 60, seconds % 60) }

fun main() = application {
    val scope = rememberCoroutineScope()
    val store = remember { LibraryStore() }
    val initial by produceState<LibrarySnapshot?>(null) { value = withContext(Dispatchers.IO) { store.load() } }
    val snapshot = initial
    if (snapshot != null) {
        val ui = remember { DesktopUi(scope, store, snapshot) }
        var closing by remember { mutableStateOf(false) }
        Window(onCloseRequest = { if (!closing) { closing = true; ui.shutdown(done = { exitApplication() }, failed = { closing = false }) } },
            title = "ZiziPlayer · Desktop 0.3.3 preview", state = rememberWindowState(width = 1440.dp, height = 850.dp)) {
            LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(960, 680) }
            val state by ui.player.state.collectAsState()
            // Retain previous palette while the next cover decodes; obsolete loads cannot publish.
            val target by produceState(MattePalette(), state.track?.id, state.track?.artwork, state.track?.artworkUrl, ui.ffmpeg, ui.client, ui.prefs.artworkColor) {
                value = if (!ui.prefs.artworkColor || state.track == null) MattePalette() else
                    Covers.gate.withPermit { withContext(Dispatchers.IO) { Covers.load(state.track!!, ui.client)?.palette ?: MattePalette() } }
            }
            val matte = animatedMatte(target)
            CompositionLocalProvider(LocalMatte provides matte) {
                MaterialTheme(colorScheme = darkColorScheme(primary = Brand, onPrimary = Color(0xFF0B0B0C), background = Base,
                    onBackground = Ink, surface = Panel, onSurface = Ink, surfaceVariant = Chip,
                    onSurfaceVariant = Muted, secondaryContainer = Chip, onSecondaryContainer = Ink,
                    surfaceTint = Color.Transparent, outline = Color(0xFF303030))) {
                    Surface(Modifier.fillMaxSize(), color = Base) { DesktopContent(ui, closing) }
                }
            }
        }
    }
}
private data class LibraryCard(val key: String, val title: String, val subtitle: String,
    val icon: ImageVector, val cover: PlayerTrack? = null)

@Composable private fun DesktopContent(s: DesktopUi, closing: Boolean) {
    val state by s.player.state.collectAsState()
    val queue by s.player.queueState.collectAsState()
    var page by remember { mutableStateOf("Медиатека") }
    var detail by remember { mutableStateOf<LibraryCard?>(null) }
    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var sourceDialog by remember { mutableStateOf(false) }
    var effects by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var suggestionsOpen by remember { mutableStateOf(false) }
    var suggestionIndex by remember { mutableStateOf(-1) }
    var sidebarMode by remember { mutableStateOf(2) } // 2: library, 1: icon rail, 0: hidden
    var queueOpen by remember { mutableStateOf(false) }
    var libraryFilter by remember { mutableStateOf("Все") }
    var playlistDialog by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    fun navigate(label: String) {
        s.cancelPreview(); suggestionsOpen = false; s.cancelSearch(); s.closePage(); page = label; detail = null; query = ""; submitted = false; focus.clearFocus()
    }
    fun search(value: String, kind: String = s.searchKind) {
        if (value.isBlank()) return
        s.cancelPreview(); suggestionsOpen = false; searchText = value; query = value; page = "Поиск"; detail = null; s.closePage(); submitted = true; focus.clearFocus(); s.search(value, kind)
    }
    fun artist(track: PlayerTrack) {
        suggestionsOpen = false; s.cancelPreview(); focus.clearFocus()
        if (!track.source.contains("://")) {
            s.closePage(); page = "Исполнители"; query = ""
            detail = LibraryCard("artist:${track.artist}", track.artist, "Локальная медиатека", ZiziIcons.Person, track)
            return
        }
        s.closePage(); detail = null; page = "Поиск"
        if (track.artistId != null) s.open(CatalogCollection(track.artistId, "artist", track.artist))
        else search(track.artist, "artist") // Name opens explicit choices, never guesses a catalog identity.
    }
    val localArtists = remember(s.tracks) { s.tracks.filter { !it.source.contains("://") && it.artist.isNotBlank() }.groupBy { it.artist } }
    val libraryCards = remember(s.tracks, s.library.playlists, s.library.folders, s.library.favorites) {
        val byId = s.tracks.associateBy { it.id }
        listOf(LibraryCard("tracks", "Все треки", "${s.tracks.size} треков", ZiziIcons.Library, s.tracks.firstOrNull()),
            LibraryCard("favorites", "Избранное", "${s.library.favorites.size} треков", ZiziIcons.HeartFilled, s.tracks.find { it.id in s.library.favorites })) +
            s.library.playlists.map { LibraryCard("pl:" + it.id, it.title, "Плейлист · ${it.trackIds.size} треков", ZiziIcons.Queue, it.trackIds.firstNotNullOfOrNull { id -> byId[id] }) } +
            s.library.folders.map { LibraryCard("dir:$it", File(it).name, "Папка · ${s.folderTracks(it).size} треков", ZiziIcons.Folder, s.folderTracks(it).firstOrNull()) } +
            localArtists.map { (name, tracks) -> LibraryCard("artist:$name", name, "Исполнитель · локальные треки", ZiziIcons.Person, tracks.firstOrNull()) }
    }
    fun openCard(card: LibraryCard) { navigate("Медиатека"); detail = card }
    val previewMatches = remember(searchText, s.previewTracks, s.tracks) {
        val q = searchText.trim()
        if (q.length < 2) emptyList() else (s.previewTracks.asSequence() + s.tracks.asSequence().filter {
            (it.title + " " + it.artist).contains(q, true)
        }).distinctBy { it.id }.take(6).toList()
    }
    val completions = remember(searchText, s.recentSearches, previewMatches) {
        if (searchText.isBlank()) s.recentSearches.take(5) else
            app.ziziplayer.ui.SearchPresentation.completions(searchText, emptyList(), s.recentSearches, previewMatches.map { it.title })
    }
    fun activateSuggestion() {
        val selected = suggestionIndex
        if (selected in completions.indices) search(completions[selected])
        else if (selected - completions.size in previewMatches.indices) {
            val track = previewMatches[selected - completions.size]
            s.player.play(track, previewMatches); suggestionsOpen = false; s.cancelPreview(); focus.clearFocus()
        } else search(searchText)
    }
    LaunchedEffect(completions, previewMatches) { suggestionIndex = -1 }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val searchWidth = DesktopLayout.searchWidth(maxWidth.value).dp
    val sideTarget = DesktopLayout.sidebarWidth(maxWidth.value, sidebarMode, queueOpen || effects).dp
    val sideWidth by animateDpAsState(sideTarget, tween(220))
    val rightWidth = DesktopLayout.rightWidth(maxWidth.value).dp
    Column(Modifier.fillMaxSize().onPreviewKeyEvent {
        if (!closing && it.isCtrlPressed && it.key == Key.Spacebar && it.type == KeyEventType.KeyDown) {
            s.player.togglePause(); true
        } else false
    }) {
        Box(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp)) {
            Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { sidebarMode = if (sidebarMode == 0) 2 else 0 }) { Icon(ZiziIcons.Library,
                    if (sidebarMode == 0) "Показать медиатеку" else "Скрыть медиатеку", tint = if (sidebarMode == 0) Muted else Brand) }
                TextButton(onClick = { navigate("Медиатека") }) { Text("Zizi", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Black) }
            }
            Box(Modifier.align(Alignment.Center).width(searchWidth)) {
                DesktopSearchField(searchText, {
                    searchText = it; suggestionIndex = -1; suggestionsOpen = true; s.preview(it)
                }, onSubmit = ::activateSuggestion, onFocus = {
                    editing = it
                    if (it) { suggestionsOpen = true; s.preview(searchText) }
                }, onMove = { delta ->
                    suggestionsOpen = true
                    val count = completions.size + previewMatches.size
                    if (count > 0) suggestionIndex = (suggestionIndex + delta).coerceIn(0, count - 1)
                }, onDismiss = { suggestionsOpen = false; s.cancelPreview(); focus.clearFocus() })
                if (suggestionsOpen && editing) {
                    val density = LocalDensity.current
                    Popup(alignment = Alignment.TopStart, offset = IntOffset(0, with(density) { 52.dp.roundToPx() }),
                        onDismissRequest = { suggestionsOpen = false; s.cancelPreview() }, properties = PopupProperties(focusable = false)) {
                        SearchSuggestions(s, completions, previewMatches, suggestionIndex, closing,
                            width = searchWidth, onQuery = { search(it) },
                            onTrack = { track -> s.player.play(track, previewMatches); suggestionsOpen = false; s.cancelPreview(); focus.clearFocus() },
                            onAll = { search(searchText) })
                    }
                }
            }
            IconButton(onClick = { navigate("Настройки") }, modifier = Modifier.align(Alignment.CenterEnd)) { Icon(ZiziIcons.Tune, "Настройки") }
        }
        Row(Modifier.weight(1f).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (sideWidth > 0.dp) LibrarySidebar(s, libraryCards, page, detail?.key,
                collapsed = sideTarget <= 64.dp, modifier = Modifier.width(sideWidth).fillMaxHeight(),
                onCollapse = { sidebarMode = if (sidebarMode == 2) 1 else 2 }, onNavigate = ::navigate,
                onCard = ::openCard, onCreate = { playlistDialog = true }, onSource = { sourceDialog = true }, closing = closing)
            Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(Panel).padding(horizontal = if (detail != null || s.openPage != null) 0.dp else 20.dp, vertical = 0.dp)) {
                if (!s.store.writable) Text("Библиотека доступна только для чтения. Изменения этого сеанса не сохранятся.", color = Brand, modifier = Modifier.padding(bottom = 12.dp))
                if (s.notice.isNotEmpty()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Chip).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(s.notice, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { s.notice = "" }) { Icon(ZiziIcons.Close, "Закрыть сообщение") }
                }
                val detailTitle = detail?.let { card ->
                    if (card.key.startsWith("pl:")) s.library.playlists.find { it.id == card.key.removePrefix("pl:") }?.title ?: card.title else card.title
                }
                val remote = s.openPage
                if (remote != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = s::closePage) { Icon(ZiziIcons.ArrowBack, "Назад") }
                        Text(if (remote.collection.kind == "artist") "Исполнитель" else if (remote.collection.kind == "album") "Альбом" else "Плейлист",
                            color = Muted, modifier = Modifier.weight(1f))
                        IconButton(onClick = { effects = !effects; if (effects) queueOpen = false }) { Icon(ZiziIcons.Equalizer, "Эквалайзер") }
                    }
                    val remoteListState = rememberLazyListState()
                    LaunchedEffect(remote.collection.key) { remoteListState.scrollToItem(0) }
                    val remoteCollapsed by remember { derivedStateOf { remoteListState.firstVisibleItemIndex > 0 } }
                    ScrollList(Modifier.weight(1f), state = remoteListState) {
                        item {
                            CollectionHero(remote.collection.title, remote.collection.subtitle,
                                remote.collection.artworkTrack(), s, remote.collection.kind == "artist",
                                kind = when (remote.collection.kind) { "artist" -> "Исполнитель"; "album" -> "Альбом"; else -> "Плейлист" }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CollectionPlay(s, remote.tracks, closing); Spacer(Modifier.width(16.dp))
                                Text("Загружено ${remote.tracks.size}" + (remote.total?.let { " из $it" } ?: ""), color = Muted, modifier = Modifier.weight(1f))
                                IconButton(onClick = { remote.tracks.shuffled().let { it.firstOrNull()?.let { t -> s.player.play(t, it) } } }, enabled = remote.tracks.isNotEmpty()) { Icon(ZiziIcons.Shuffle, "Перемешать загруженные треки") }
                            }
                            TextButton(onClick = { s.playlist(remote.collection.title, remote.tracks); s.notice = "Загруженные треки сохранены отдельным плейлистом." }, enabled = remote.tracks.isNotEmpty()) { Text("Сохранить загруженные треки") }
                            if (s.pageError.isNotBlank()) Text(s.pageError, color = MaterialTheme.colorScheme.error)
                            if (s.opening) LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                        }
                        stickyHeader { TrackTableHeader(remote.collection.title, s, remote.tracks, closing, remoteCollapsed) }
                        itemsIndexed(remote.tracks, key = { _, it -> it.id }) { index, track -> TrackRow(s, track, remote.tracks, closing, onArtist = ::artist, number = index + 1) }
                        item {
                            if (s.pageError.isNotBlank()) TextButton(onClick = { s.open(remote.collection, remote.tracks.isNotEmpty() && remote.nextOffset != null) }) { Text("Повторить") }
                            if (remote.nextOffset != null) OutlinedButton(onClick = { s.open(remote.collection, true) }, enabled = !s.opening) { Text("Загрузить ещё") }
                        }
                    }
                } else if (page == "Настройки") {
                    SettingsContent(s) { effects = true; queueOpen = false }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (detail != null) IconButton(onClick = { detail = null; query = "" }) { Icon(ZiziIcons.ArrowBack, "Назад") }
                        Text(if (detail != null) "Медиатека" else page, style = if (detail != null) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (page in listOf("Плейлисты", "Медиатека")) IconButton(onClick = { playlistDialog = true }) { Icon(ZiziIcons.Plus, "Создать плейлист") }
                        IconButton(onClick = { effects = !effects; if (effects) queueOpen = false }) { Icon(ZiziIcons.Equalizer, "Эквалайзер", tint = if (effects) Brand else Ink) }
                    }
                    if (detail == null) Spacer(Modifier.height(8.dp))
                    if (page != "Поиск" && detail == null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.width(260.dp)) {
                            DesktopSearchField(query, { query = it }, onSubmit = { focus.clearFocus() }, onFocus = {},
                                hint = "Искать в медиатеке", mobileSearch = false)
                        }
                    }
                    if (detail == null) Spacer(Modifier.height(8.dp))
                    if (page == "Поиск") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for ((kind, label) in listOf("track" to "Треки", "artist" to "Исполнители", "album" to "Альбомы", "playlist" to "Плейлисты"))
                                FilterChip(selected = s.searchKind == kind, onClick = { if (query.isNotBlank()) search(query, kind) else s.selectSearchKind(kind) }, label = { Text(label) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (submitted) s.searchMessage else "Введи запрос в строке сверху — подсказки появятся во время ввода", color = Muted, modifier = Modifier.weight(1f))
                            SearchRefresh(s.searching, query.isNotBlank()) { search(query) }
                        }
                        if (!submitted) {
                            val suggestions = if (query.isBlank()) s.recentSearches.take(8) else app.ziziplayer.ui.SearchPresentation.completions(query, emptyList(), s.recentSearches, s.tracks.map { it.title })
                            LazyColumn(Modifier.weight(1f)) {
                                item { if (query.isBlank() && suggestions.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Недавние", Modifier.weight(1f)); TextButton(onClick = s::clearHistory) { Text("Очистить") }
                                } }
                                items(suggestions) { text -> Row(Modifier.fillMaxWidth().clickable { search(text) }.padding(16.dp)) {
                                    Icon(ZiziIcons.History, null, tint = Muted); Spacer(Modifier.width(16.dp)); Text(text)
                                } }
                            }
                        } else if (s.searchKind != "track") {
                            val cards = s.groups.map { LibraryCard(it.key, it.title, it.subtitle,
                                if (it.kind == "artist") ZiziIcons.Person else ZiziIcons.Queue, it.artworkTrack()) }
                            CollectionCards(cards, s, Modifier.weight(1f)) { card -> s.groups.find { it.key == card.key }?.let { s.open(it) } }
                            if (s.nextBrowse != null) TextButton(onClick = s::moreSearch, enabled = !s.searching) { Text("Загрузить ещё") }
                        } else {
                            LazyColumn(Modifier.weight(1f)) { items(s.results, key = { it.id }) { track -> TrackRow(s, track, s.results, closing, onArtist = ::artist) } }
                        }
                    } else {
                        val cards = when (page) {
                            "Медиатека" -> libraryCards
                            "Плейлисты" -> s.library.playlists.map { LibraryCard("pl:" + it.id, it.title, "${it.trackIds.size} треков", ZiziIcons.Queue, s.playlistTracks(it.id).firstOrNull()) }
                            "Папки" -> s.library.folders.map { LibraryCard("dir:$it", File(it).name, "${s.folderTracks(it).size} треков", ZiziIcons.Folder, s.folderTracks(it).firstOrNull()) }
                            "Исполнители" -> localArtists.map { (name, tracks) -> LibraryCard("artist:$name", name, "${tracks.size} локальных треков", ZiziIcons.Person, tracks.firstOrNull()) }
                            else -> emptyList()
                        }
                        if (detail == null && page in listOf("Медиатека", "Плейлисты", "Папки", "Исполнители")) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (s.scanning) "Читаем медиатеку…" else "${cards.size} коллекций", color = Muted, modifier = Modifier.weight(1f))
                                IconButton(onClick = { s.settings(s.prefs.copy(grid = !s.prefs.grid)) }) { Icon(if (s.prefs.grid) ZiziIcons.ViewList else ZiziIcons.ViewGrid, "Сменить вид") }
                                if (page == "Исполнители") TextButton(onClick = { navigate("Поиск"); s.selectSearchKind("artist") }) { Text("Найти в каталоге") }
                            }
                            if (cards.isEmpty()) Text("Добавь музыку или создай свою коллекцию.", color = Muted, modifier = Modifier.padding(vertical = 24.dp))
                            if (page == "Медиатека") Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Все", "Плейлисты", "Исполнители", "Папки").forEach { label ->
                                    FilterChip(libraryFilter == label, { libraryFilter = label }, label = { Text(label, fontSize = 12.sp) })
                                }
                            }
                            CollectionCards(cards.filter { card -> card.title.contains(query, true) && (page != "Медиатека" || when (libraryFilter) {
                                "Плейлисты" -> card.key.startsWith("pl:") || card.key == "favorites"
                                "Исполнители" -> card.key.startsWith("artist:")
                                "Папки" -> card.key.startsWith("dir:")
                                else -> true
                            }) }, s, Modifier.weight(1f)) { detail = it; query = "" }
                        } else {
                            val key = detail?.key.orEmpty()
                            val playlistId = key.takeIf { it.startsWith("pl:") }?.removePrefix("pl:")
                            val all = when {
                                page == "Очередь" -> queue
                                page == "Загрузки" -> s.sorted(s.tracks.filter { it.id in s.downloaded })
                                key.startsWith("pl:") -> s.playlistTracks(key.removePrefix("pl:"))
                                key.startsWith("dir:") -> s.sorted(s.folderTracks(key.removePrefix("dir:")))
                                key.startsWith("artist:") -> s.sorted(localArtists[key.removePrefix("artist:")].orEmpty())
                                key == "favorites" || page == "Избранное" -> s.sorted(s.tracks.filter { it.id in s.library.favorites })
                                else -> s.sorted(s.tracks)
                            }
                            val visible = all.filter { (it.title + " " + it.artist).contains(query, true) }
                            val localListState = rememberLazyListState()
                            val localCollapsed by remember { derivedStateOf { localListState.firstVisibleItemIndex > 0 } }
                            LaunchedEffect(key, page) { localListState.scrollToItem(0) }
                            ScrollList(Modifier.weight(1f), state = localListState) {
                                item {
                                    CollectionHero(detailTitle ?: page, "${all.size} треков", all.firstOrNull(), s, key.startsWith("artist:"),
                                        kind = when { key.startsWith("artist:") -> "Исполнитель · локальная медиатека"; playlistId != null -> "Плейлист"; else -> "Медиатека" }) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            CollectionPlay(s, all, closing); Spacer(Modifier.width(16.dp))
                                            IconButton(onClick = { all.shuffled().let { list -> list.firstOrNull()?.let { s.player.play(it, list) } } }, enabled = all.isNotEmpty() && !closing) { Icon(ZiziIcons.Shuffle, "Перемешать") }
                                            if (playlistId != null) PlaylistControls(s, playlistId) { detail = null }
                                            Spacer(Modifier.weight(1f)); Text("${all.size} треков", color = Muted, fontSize = 12.sp)
                                        }
                                        if (all.isEmpty()) Text("Здесь пока нет треков.", color = Muted, modifier = Modifier.padding(vertical = 20.dp))
                                    }
                                }
                                stickyHeader { TrackTableHeader(detailTitle ?: page, s, all, closing, localCollapsed) }
                                itemsIndexed(visible, key = { _, it -> it.id }) { index, track -> TrackRow(s, track, all, closing, page == "Очередь", playlistId, ::artist, index + 1) }
                            }
                        }
                    }
                }
            }
            AnimatedVisibility(queueOpen || effects, enter = expandHorizontally(tween(220)) + fadeIn(tween(160)),
                exit = shrinkHorizontally(tween(220)) + fadeOut(tween(120))) {
                if (queueOpen) QueuePanel(s, closing, Modifier.width(rightWidth).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(Panel),
                    close = { queueOpen = false }, onArtist = ::artist)
                else EffectsPanel(s, Modifier.width(rightWidth).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(Panel).padding(18.dp))
            }
        }
        Transport(s, closing, queueOpen, effects, onQueue = { queueOpen = !queueOpen; if (queueOpen) effects = false },
            onEffects = { effects = !effects; if (effects) queueOpen = false }, onArtist = ::artist) { expanded = true }
    }
    }
    if (sourceDialog) SourceDialog(s) { sourceDialog = false }
    if (playlistDialog) NameDialog("Новый плейлист", "", { s.playlist(it); playlistDialog = false }) { playlistDialog = false }
    if (expanded) Dialog(onDismissRequest = { expanded = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.widthIn(max = 780.dp).fillMaxWidth().padding(24.dp), shape = RoundedCornerShape(24.dp), color = LocalMatte.current.card) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Сейчас играет", Modifier.weight(1f), color = Ink)
                    IconButton(onClick = { expanded = false }) { Icon(ZiziIcons.Close, "Свернуть") }
                }
                Artwork(state.track, s.client, 300.dp); Spacer(Modifier.height(20.dp))
                Text(state.track?.title ?: "Музыка не выбрана", style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                TextButton(onClick = { state.track?.let(::artist); expanded = false }, enabled = !state.track?.artist.isNullOrBlank()) { Text(state.track?.artist.orEmpty()) }
                Transport(s, closing) { expanded = false }
            }
        }
    }
}

private fun chooseFolder(): File? {
    val picker = JFileChooser().apply { dialogTitle = "Выбрать папку с музыкой"; fileSelectionMode = JFileChooser.DIRECTORIES_ONLY }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFile else null
}
@Composable private fun CollectionHero(title: String, subtitle: String, track: PlayerTrack?, s: DesktopUi, artist: Boolean,
    kind: String = if (artist) "Исполнитель" else "Коллекция", actions: @Composable () -> Unit = {}) {
    val cover = coverData(track, s.client)
    val tone = animatedCollectionTone(if (s.prefs.artworkColor) collectionTone(cover?.primary) else Color(0xFF424242))
    // One continuous brush through hero AND action zone; no seam at the section boundary.
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(
        0f to tone, .58f to tone.copy(alpha = .60f), 1f to Panel))) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val small = maxWidth < 680.dp
            val artSize = if (small) 144.dp else 184.dp
            Row(Modifier.fillMaxWidth().heightIn(min = if (small) 220.dp else 252.dp).padding(20.dp), verticalAlignment = Alignment.Bottom) {
                Box(Modifier.size(artSize).clip(if (artist) CircleShape else RoundedCornerShape(4.dp)).background(Chip), contentAlignment = Alignment.Center) {
                    if (cover != null) Image(cover.image, if (artist && track?.source?.startsWith("collection:") == true) "Фото исполнителя" else "Обложка коллекции",
                        Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(if (artist) ZiziIcons.Person else ZiziIcons.FolderMusic, null, Modifier.size(64.dp), tint = Muted)
                }
                Spacer(Modifier.width(if (small) 18.dp else 24.dp))
                Column(Modifier.weight(1f).padding(bottom = 4.dp)) {
                    Text(kind, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    val titleSize = when { small -> 34.sp; title.length > 28 -> 40.sp; title.length > 18 -> 48.sp; else -> 64.sp }
                    Text(title, fontSize = titleSize, lineHeight = titleSize * 1.06f, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (subtitle.isNotBlank()) Text(subtitle, color = Ink, fontSize = 13.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 16.dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) { actions() }
    }
}
@Composable private fun CollectionCards(cards: List<LibraryCard>, s: DesktopUi, modifier: Modifier, open: (LibraryCard) -> Unit) {
    BoxWithConstraints(modifier) {
        val contentWidth = (maxWidth - 10.dp).coerceAtLeast(0.dp)
        val columns = if (s.prefs.grid) DesktopLayout.columns(contentWidth.value) else 1
        val artSize = DesktopLayout.artworkSize(contentWidth.value, columns).dp
        ScrollList(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(cards.chunked(columns), key = { it.first().key }) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { card ->
                        val interaction = remember(card.key) { MutableInteractionSource() }
                        val hovered by interaction.collectIsHoveredAsState()
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(6.dp))
                            .background(if (hovered) Color(0xFF252525) else Color.Transparent).hoverable(interaction).clickable { open(card) }.padding(10.dp)) {
                            if (s.prefs.grid) {
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CardArtwork(card, s, artSize) }
                                Spacer(Modifier.height(12.dp))
                                Text(card.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(card.subtitle, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                            } else Row(verticalAlignment = Alignment.CenterVertically) {
                                CardArtwork(card, s, 48.dp); Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(card.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                    Text(card.subtitle, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                                }
                                Icon(ZiziIcons.ChevronRight, null, tint = Muted)
                            }
                        }
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
@Composable private fun CollectionPlay(s: DesktopUi, tracks: List<PlayerTrack>, closing: Boolean) {
    FilledIconButton(onClick = { tracks.firstOrNull()?.let { s.player.play(it, tracks) } }, enabled = tracks.isNotEmpty() && !closing,
        modifier = Modifier.size(52.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Brand, contentColor = Base)) {
        Icon(ZiziIcons.PlayFilled, "Слушать коллекцию", Modifier.size(28.dp))
    }
}
@Composable private fun TrackTableHeader(title: String, s: DesktopUi, tracks: List<PlayerTrack>, closing: Boolean, collapsed: Boolean) {
    Column(Modifier.fillMaxWidth().background(Panel)) {
        if (collapsed) Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledIconButton(onClick = { tracks.firstOrNull()?.let { s.player.play(it, tracks) } }, enabled = tracks.isNotEmpty() && !closing, modifier = Modifier.size(36.dp)) {
                Icon(ZiziIcons.PlayFilled, "Слушать коллекцию", Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp)); Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 64.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("#", Modifier.width(28.dp), color = Muted, fontSize = 12.sp)
            Text("Название", Modifier.weight(1f), color = Muted, fontSize = 12.sp)
            Icon(ZiziIcons.Clock, "Длительность", Modifier.size(16.dp), tint = Muted)
        }
        HorizontalDivider(color = Color(0xFF292929))
    }
}
@Composable private fun TrackRow(s: DesktopUi, original: PlayerTrack, all: List<PlayerTrack>, closing: Boolean,
    queue: Boolean = false, playlistId: String? = null, onArtist: (PlayerTrack) -> Unit, number: Int? = null) {
    val state by s.player.state.collectAsState()
    val metadata by s.player.metadata.collectAsState()
    val selected = original.id == state.track?.id
    val track = if (selected) state.track!! else metadata[original.id] ?: original
    var menu by remember { mutableStateOf(false) }
    var playlists by remember { mutableStateOf(false) }
    var remove by remember { mutableStateOf(false) }
    val saved = s.tracks.any { it.id == track.id }
    val favorite = track.id in s.library.favorites
    val interaction = remember { MutableInteractionSource() }; val hovered by interaction.collectIsHoveredAsState()
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(if (hovered) Color(0xFF282828) else if (selected) Chip else Color.Transparent)
        .hoverable(interaction).clickable(enabled = !closing) { if (selected) s.player.togglePause() else s.player.play(track, all) }
        .padding(horizontal = 20.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        if (number != null) Box(Modifier.width(28.dp), contentAlignment = Alignment.CenterStart) {
            if (hovered) Icon(ZiziIcons.PlayFilled, null, Modifier.size(16.dp), tint = Ink)
            else Text(number.toString(), color = if (selected) Brand else Muted, fontSize = 13.sp)
        }
        Artwork(track, s.client, 36.dp); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) Brand else Ink, fontSize = 14.sp)
            if (track.id in s.downloaded) Text("Скачано", color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(track.artist.ifBlank { if (track.source.startsWith("zizi://")) "Zizi" else "Локальный файл" }, color = Muted,
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable(enabled = track.artist.isNotBlank()) { onArtist(track) })
        }
        if (queue || playlistId != null) {
            IconButton(onClick = { if (queue) s.player.move(track.id, -1) else s.playlistMove(playlistId!!, track.id, -1) }, enabled = all.indexOfFirst { it.id == track.id } > 0) { Icon(ZiziIcons.ChevronUp, "Переместить выше", Modifier.size(20.dp)) }
            IconButton(onClick = { if (queue) s.player.move(track.id, 1) else s.playlistMove(playlistId!!, track.id, 1) }, enabled = all.indexOfFirst { it.id == track.id } < all.lastIndex) { Icon(ZiziIcons.ChevronDown, "Переместить ниже", Modifier.size(20.dp)) }
        }
        IconButton(onClick = { s.favorite(track) }) { Icon(if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart,
            if (favorite) "Убрать из избранного" else "В избранное", tint = if (favorite) Brand else Muted, modifier = Modifier.size(20.dp)) }
        Text(track.durationMs?.let(::time) ?: "—", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(42.dp))
        Box {
            IconButton(onClick = { menu = true }) { Icon(ZiziIcons.More, "Действия с треком") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text(if (saved) "Убрать из медиатеки" else "Сохранить в медиатеку") }, onClick = { menu = false; if (saved) remove = true else s.save(track) })
                DropdownMenuItem(text = { Text("Добавить в плейлист") }, onClick = { menu = false; playlists = true })
                DropdownMenuItem(text = { Text("Слушать следующим") }, onClick = { s.player.enqueue(track, true); menu = false })
                DropdownMenuItem(text = { Text("В конец очереди") }, onClick = { s.player.enqueue(track); menu = false })
                if (track.source.startsWith("zizi://") && track.id !in s.downloaded)
                    DropdownMenuItem(text = { Text("Скачать для офлайн") }, onClick = { s.download(track); menu = false })
                if (track.artist.isNotBlank()) DropdownMenuItem(text = { Text("Перейти к исполнителю") }, onClick = { menu = false; onArtist(track) })
                if (queue) DropdownMenuItem(text = { Text("Удалить из очереди") }, onClick = { s.player.remove(track.id); menu = false })
                if (playlistId != null) DropdownMenuItem(text = { Text("Убрать из плейлиста") }, onClick = { s.playlistRemove(playlistId, track.id); menu = false })
            }
        }
    }
    if (remove) ConfirmDialog("Убрать из медиатеки?", "Трек будет убран также из избранного и твоих плейлистов. Файл на диске останется.",
        { s.forget(track.id); remove = false }) { remove = false }
    if (playlists) PlaylistPicker(s, track) { playlists = false }
}
@Composable private fun PlaylistPicker(s: DesktopUi, track: PlayerTrack, dismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text("Добавить в плейлист") }, text = {
        Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
            s.library.playlists.forEach { list -> TextButton(onClick = { s.addToPlaylist(list.id, track); dismiss() }) { Text(list.title) } }
            OutlinedTextField(title, { title = it.take(100) }, label = { Text("Название нового плейлиста") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { s.playlist(title, listOf(track)); dismiss() }, enabled = title.isNotBlank()) { Text("Создать и добавить") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun NameDialog(title: String, initial: String, confirm: (String) -> Unit, dismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text(title) }, text = {
        OutlinedTextField(text, { text = it.take(100) }, singleLine = true, label = { Text("Название") })
    }, confirmButton = { TextButton(onClick = { confirm(text) }, enabled = text.isNotBlank()) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun ConfirmDialog(title: String, text: String, confirm: () -> Unit, dismiss: () -> Unit) {
    AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = confirm) { Text("Удалить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun PlaylistControls(s: DesktopUi, id: String, deleted: () -> Unit) {
    var rename by remember { mutableStateOf(false) }; var remove by remember { mutableStateOf(false) }
    IconButton(onClick = { rename = true }) { Icon(ZiziIcons.Edit, "Переименовать плейлист") }
    IconButton(onClick = { remove = true }) { Icon(ZiziIcons.Trash, "Удалить плейлист") }
    if (rename) NameDialog("Переименовать плейлист", s.library.playlists.find { it.id == id }?.title.orEmpty(),
        { s.renamePlaylist(id, it); rename = false }) { rename = false }
    if (remove) ConfirmDialog("Удалить плейлист?", "Треки останутся в медиатеке, файлы не будут удалены.",
        { s.deletePlaylist(id); remove = false; deleted() }) { remove = false }
}
@Composable private fun Transport(s: DesktopUi, closing: Boolean, queueOpen: Boolean = false, effectsOpen: Boolean = false,
    onQueue: (() -> Unit)? = null, onEffects: (() -> Unit)? = null, onArtist: ((PlayerTrack) -> Unit)? = null, expand: () -> Unit) {
    val state by s.player.state.collectAsState()
    val progress by s.player.progress.collectAsState()
    val valid = progress.trackId == state.track?.id && progress.generation == state.generation
    val duration = if (valid) progress.durationMs ?: 0 else 0
    val position = if (valid) progress.positionMs else 0
    var drag by remember(state.generation) { mutableStateOf<Float?>(null) }
    val sliderColors = SliderDefaults.colors(thumbColor = Brand, activeTrackColor = Brand,
        inactiveTrackColor = Color(0xFF454545), disabledThumbColor = Color(0xFF5A3826), disabledActiveTrackColor = Color(0xFF5A3826))
    BoxWithConstraints(Modifier.fillMaxWidth().height(90.dp).background(Base).padding(horizontal = 12.dp)) {
        val wide = maxWidth > 1000.dp
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(.29f), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable(onClick = expand)) { Artwork(state.track, s.client, if (wide) 54.dp else 44.dp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(state.track?.title ?: "Zizi готов к музыке", fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = expand))
                    Text(state.track?.artist.orEmpty(), color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(enabled = onArtist != null && !state.track?.artist.isNullOrBlank()) { state.track?.let { onArtist?.invoke(it) } })
                    if (closing || s.downloadId != null || state.phase in setOf(PlaybackPhase.LOADING, PlaybackPhase.ERROR))
                        Text(if (closing) "Закрываем аудиосеанс…" else if (s.downloadId != null) "Загрузка · ${s.downloadProgress}" else state.message,
                            color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (wide) IconButton(onClick = { state.track?.let(s::favorite) }, enabled = state.track != null && !closing) {
                    Icon(if (state.track?.id in s.library.favorites) ZiziIcons.HeartFilled else ZiziIcons.Heart, "Избранное", Modifier.size(19.dp), tint = Brand)
                }
            }
            Column(Modifier.weight(.42f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.height(44.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { s.settings(s.prefs.copy(shuffle = !s.prefs.shuffle)) }, enabled = !closing, modifier = Modifier.size(34.dp)) {
                        Icon(ZiziIcons.Shuffle, "Случайный порядок: ${s.prefs.shuffle}", Modifier.size(19.dp), tint = if (s.prefs.shuffle) Brand else Muted)
                    }
                    IconButton(onClick = { s.player.adjacent(-1) }, enabled = !closing && s.player.queue.isNotEmpty(), modifier = Modifier.size(34.dp)) { Icon(ZiziIcons.SkipPrevious, "Предыдущий трек", Modifier.size(21.dp)) }
                    FilledIconButton(onClick = { s.player.togglePause() }, enabled = !closing && state.track != null,
                        modifier = Modifier.size(36.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Brand, contentColor = Base)) {
                        val pauses = state.phase in setOf(PlaybackPhase.PLAYING, PlaybackPhase.LOADING)
                        Icon(if (pauses) ZiziIcons.Pause else ZiziIcons.PlayFilled, if (pauses) "Пауза" else "Воспроизвести", Modifier.size(22.dp))
                    }
                    IconButton(onClick = { s.player.adjacent(1) }, enabled = !closing && s.player.queue.isNotEmpty(), modifier = Modifier.size(34.dp)) { Icon(ZiziIcons.SkipNext, "Следующий трек", Modifier.size(21.dp)) }
                    IconButton(onClick = { s.settings(s.prefs.copy(repeat = RepeatMode.entries[(s.prefs.repeat.ordinal + 1) % RepeatMode.entries.size])) }, enabled = !closing, modifier = Modifier.size(34.dp)) {
                        Icon(if (s.prefs.repeat == RepeatMode.ONE) ZiziIcons.RepeatOne else ZiziIcons.Repeat, "Повтор: ${s.prefs.repeat}",
                            Modifier.size(19.dp), tint = if (s.prefs.repeat == RepeatMode.OFF) Muted else Brand)
                    }
                }
                Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(time(drag?.toLong() ?: position), color = Muted, fontSize = 10.sp, modifier = Modifier.width(40.dp))
                    Slider(value = drag ?: position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
                        onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { s.player.seek(it.toLong()) }; drag = null },
                        enabled = state.seekable && duration > 0 && !closing, valueRange = 0f..duration.coerceAtLeast(1).toFloat(),
                        colors = sliderColors, modifier = Modifier.weight(1f).height(24.dp))
                    Text(if (duration > 0) time(duration) else "—:—", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 8.dp).width(36.dp))
                }
            }
            Row(Modifier.weight(.29f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (wide) IconButton(onClick = { s.player.stop() }, enabled = !closing && state.track != null, modifier = Modifier.size(32.dp)) { Icon(ZiziIcons.Stop, "Остановить", Modifier.size(17.dp), tint = Muted) }
                if (onEffects != null) IconButton(onClick = onEffects, modifier = Modifier.size(34.dp)) { Icon(ZiziIcons.Equalizer, "Эквалайзер", Modifier.size(19.dp), tint = if (effectsOpen) Brand else Muted) }
                if (onQueue != null) IconButton(onClick = onQueue, modifier = Modifier.size(34.dp)) { Icon(ZiziIcons.Queue, if (queueOpen) "Закрыть очередь" else "Открыть очередь", Modifier.size(19.dp), tint = if (queueOpen) Brand else Muted) }
                Text("${(s.gain * 100).toInt()}%", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 6.dp))
                Slider(s.gain, s::volume, enabled = !closing, colors = sliderColors, modifier = Modifier.width(if (wide) 90.dp else 64.dp))
                if (wide) IconButton(onClick = expand, modifier = Modifier.size(32.dp)) { Icon(ZiziIcons.ChevronUp, "Развернуть плеер", Modifier.size(19.dp), tint = Muted) }
            }
        }
    }
}

private data class SettingsSection(val title: String, val icon: ImageVector, val keywords: String)
private val settingSections = listOf(
    SettingsSection("Оформление", ZiziIcons.Palette, "цвет из обложки amoled тема палитра"),
    SettingsSection("Библиотека", ZiziIcons.Library, "папки сканирование сортировка сетка список"),
    SettingsSection("Звук", ZiziIcons.Equalizer, "эквалайзер dsp громкость эффекты глобально"),
    SettingsSection("Загрузки", ZiziIcons.DownloadDone, "офлайн скачанные память диск"),
    SettingsSection("Поиск", ZiziIcons.Search, "история недавние запросы"),
    SettingsSection("О приложении", ZiziIcons.Info, "версия диагностика ffmpeg сеть сервер"))

@Composable private fun SettingsContent(s: DesktopUi, effects: () -> Unit) {
    var section by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("") }
    var diagnostics by remember { mutableStateOf(false) }
    var confirmHistory by remember { mutableStateOf(false) }
    val state by s.player.state.collectAsState()
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (section != null) IconButton(onClick = { section = null; filter = "" }) { Icon(ZiziIcons.ArrowBack, "Все настройки") }
        Text(section ?: "Настройки", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(20.dp))
    DesktopSearchField(filter, { filter = it; section = null }, onSubmit = {}, onFocus = {}, hint = "Найти настройку", mobileSearch = false)
    Spacer(Modifier.height(20.dp))
    val shown = settingSections.filter { entry -> (section == null || entry.title == section) &&
        filter.trim().split(Regex("\\s+")).all { (entry.title + " " + entry.keywords).contains(it, true) } }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (section == null && filter.isBlank()) {
            items(settingSections.chunked(2)) { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    pair.forEach { item ->
                        Column(Modifier.weight(1f).height(135.dp).clip(RoundedCornerShape(18.dp)).background(Panel)
                            .clickable { section = item.title }.padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(item.icon, null, Modifier.size(30.dp), tint = if (item.title == "Оформление") LocalMatte.current.accent else Ink)
                            Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        } else {
            items(shown) { entry ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(entry.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    when (entry.title) {
                        "Оформление" -> {
                            SettingToggle("Цвет из обложки", s.prefs.artworkColor) { s.settings(s.prefs.copy(artworkColor = it)) }
                            Row(Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(14.dp)).background(LocalMatte.current.card).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(ZiziIcons.Palette, null, tint = LocalMatte.current.accent)
                                Spacer(Modifier.width(16.dp)); Text("Матовый AMOLED", color = Ink)
                            }
                        }
                        "Библиотека" -> {
                            SettingToggle("Сетка коллекций", s.prefs.grid) { s.settings(s.prefs.copy(grid = it)) }
                            Text("Сортировка треков", fontWeight = FontWeight.SemiBold)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for ((mode, label) in listOf(TrackSort.TITLE to "Название", TrackSort.ARTIST to "Исполнитель", TrackSort.RECENT to "Добавлены", TrackSort.DURATION to "Длительность"))
                                    FilterChip(s.prefs.sort == mode, { s.settings(s.prefs.copy(sort = mode)) }, label = { Text(label) })
                            }
                            HorizontalDivider(color = Chip)
                            s.library.folders.forEach { path ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(File(path).name); Text(path, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 2) }
                                    IconButton(onClick = { s.scanFolder(File(path)) }, enabled = !s.scanning) { Icon(ZiziIcons.Refresh, "Пересканировать папку") }
                                    IconButton(onClick = { s.removeFolder(path) }) { Icon(ZiziIcons.Close, "Отключить папку, оставить треки и файлы") }
                                }
                            }
                            TextButton(onClick = { chooseFolder()?.let(s::scanFolder) }, enabled = !s.scanning) { Text(if (s.scanning) "Сканирование · ${s.scanMessage}" else "Добавить папку") }
                            if (s.scanning) TextButton(onClick = s::cancelScan) { Text("Остановить сканирование") }
                        }
                        "Звук" -> {
                            SettingToggle("Один эквалайзер для всей музыки", s.prefs.dspGlobal) { s.settings(s.prefs.copy(dspGlobal = it)) }
                            Text(if (s.prefs.dspGlobal) "Общие настройки звука" else "Эффекты сохраняются отдельно для каждого трека", color = Muted)
                            FilledTonalButton(onClick = effects) { Icon(ZiziIcons.Equalizer, null); Spacer(Modifier.width(10.dp)); Text("Открыть эквалайзер") }
                            Text("Громкость · ${(s.gain * 100).toInt()}%")
                            Slider(s.gain, s::volume)
                        }
                        "Загрузки" -> {
                            Text("${s.downloadStats.first} треков · ${s.downloadStats.second / (1024 * 1024)} МБ", color = Muted)
                            if (s.downloadId != null) Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Загрузка · ${s.downloadProgress}", Modifier.weight(1f))
                                TextButton(onClick = s::cancelDownload) { Text("Отменить") }
                            }
                            TextButton(onClick = { s.showDataFolder(true) }) { Text("Открыть папку загрузок") }
                            TextButton(onClick = s::refreshDownloads) { Text("Проверить файлы") }
                            TextButton(onClick = { s.scope.launch { withContext(Dispatchers.IO) { Covers.clear() }; s.notice = "Кэш обложек очищен. Аудиозагрузки сохранены." } }) { Text("Очистить кэш обложек") }
                            s.tracks.filter { it.id in s.downloaded }.forEach { track -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(track.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                var confirm by remember(track.id) { mutableStateOf(false) }
                                IconButton(onClick = { confirm = true }, enabled = track.id != state.track?.id) { Icon(ZiziIcons.Trash, "Удалить скачанный файл") }
                                if (confirm) ConfirmDialog("Удалить скачанный файл?", "Трек останется в медиатеке и будет воспроизводиться из сети.",
                                    { s.deleteDownload(track.id); confirm = false }) { confirm = false }
                            } }
                        }
                        "Поиск" -> {
                            Text("История запросов · ${s.recentSearches.size}", color = Muted)
                            TextButton(onClick = { confirmHistory = true }, enabled = s.recentSearches.isNotEmpty()) { Text("Очистить историю поиска") }
                        }
                        "О приложении" -> {
                            Text("ZiziPlayer Desktop 0.3.3 preview")
                            TextButton(onClick = { s.showDataFolder() }) { Text("Открыть папку данных") }
                            TextButton(onClick = { diagnostics = true }) { Text("Диагностика и аудиодекодер") }
                        }
                    }
                }
            }
            if (shown.isEmpty()) item { Text("Настройка не найдена", color = Muted) }
        }
    }
    if (diagnostics) AudioToolsDialog(s) { diagnostics = false }
    if (confirmHistory) ConfirmDialog("Очистить историю?", "Сохранённые треки и плейлисты не изменятся.",
        { s.clearHistory(); confirmHistory = false }) { confirmHistory = false }
}
@Composable private fun SettingToggle(title: String, value: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Spacer(Modifier.width(16.dp)); Switch(value, change)
    }
}
@Composable private fun AudioToolsDialog(s: DesktopUi, dismiss: () -> Unit) {
    var executable by remember { mutableStateOf(s.ffmpeg) }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss,
        title = { Text("Диагностика") }, text = {
        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(s.connectionMessage, color = Muted)
            if (s.httpCompatibility) Text("Соединение с сервером использует HTTP и не зашифровано.", color = Brand)
            HorizontalDivider(color = Chip)
            Text("Аудиодекодер", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(executable, { executable = it }, label = { Text("Путь к FFmpeg") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { val picker = JFileChooser(); if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) executable = picker.selectedFile.absolutePath }) { Text("Выбрать FFmpeg…") }
            Text("ffprobe должен лежать рядом. Новый путь применяется при следующем открытии трека.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { s.audioSettings(executable); dismiss() }, enabled = executable.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable private fun SourceDialog(s: DesktopUi, dismiss: () -> Unit) {
    var source by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    AlertDialog(containerColor = Panel, tonalElevation = 0.dp, onDismissRequest = dismiss, title = { Text("Открыть ссылку") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("zizi://dz/ID, zizi://yt/VIDEO_ID, zizi://mix/dz%3AID или прямая HTTPS-ссылка на аудио. Не страница YouTube. HLS/DASH и HTTP-редиректы пока не поддерживаются.")
            OutlinedTextField(source, { source = it }, singleLine = true, label = { Text("Адрес трека") })
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        try { s.addSource(source); source = ""; dismiss() } catch (_: Exception) { error = "Некорректная или неподдерживаемая ссылка" }
    }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } })
}
@Composable
private fun EffectsPanel(s: DesktopUi, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Звук Zizi", style = MaterialTheme.typography.titleLarge)
        SettingToggle("Для всей музыки", s.prefs.dspGlobal) { s.settings(s.prefs.copy(dspGlobal = it)) }
        val state by s.player.state.collectAsState()
        if (!s.prefs.dspGlobal && state.track == null) {
            Text("Выбери трек для настройки его звучания.", color = Muted)
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DSP", Modifier.weight(1f)); Switch(s.config.enabled, { s.dsp(s.config.copy(enabled = it)) })
        }
        Text("Оригинальные пресеты 6.39.9", style = MaterialTheme.typography.bodySmall)
        for ((title, presets) in listOf("Тембр" to DspPresets.curve, "Объём" to DspPresets.space, "Устройство" to DspPresets.device)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                DropdownMenu(expanded, { expanded = false }) {
                    presets.forEach { preset -> DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                        s.dsp(preset.transform(s.config)); expanded = false
                    }) }
                }
            }
        }
        TextButton(onClick = { s.dsp(DspConfig.NEUTRAL) }) { Text("Сбросить всё") }
        Text("Преамп: ${"%.1f".format(s.config.preampDb)} дБ")
        Slider(s.config.preampDb, { s.dsp(s.config.copy(preampDb = it)) }, valueRange = -12f..6f)
        val bands = listOf("31 Гц", "62 Гц", "125 Гц", "250 Гц", "500 Гц", "1 кГц", "2 кГц", "4 кГц", "8 кГц", "16 кГц")
        bands.forEachIndexed { index, label ->
            Text("$label · ${"%.1f".format(s.config.bandsDb[index])} дБ", style = MaterialTheme.typography.labelSmall)
            Slider(s.config.bandsDb[index], { value ->
                s.dsp(s.config.copy(enabled = true, bandsDb = s.config.bandsDb.toMutableList().also { it[index] = value }))
            }, valueRange = -12f..12f, modifier = Modifier.height(30.dp))
        }
        Text("Реверберация")
        Slider(s.config.reverbMix, { s.dsp(s.config.copy(enabled = true, reverbMix = it)) })
        Text("8D · глубина вращения")
        Slider(s.config.rotation, { s.dsp(s.config.copy(enabled = true, rotation = it)) })
        Text("Под водой")
        Slider(s.config.underwater, { s.dsp(s.config.copy(enabled = true, underwater = it)) })
        Text("Ширина стерео")
        Slider(s.config.width, { s.dsp(s.config.copy(enabled = true, width = it)) }, valueRange = -1f..1f)
        Text("Насыщение баса")
        Slider(s.config.bassDrive, { s.dsp(s.config.copy(enabled = true, bassDrive = it)) })
        Text("Воздух")
        Slider(s.config.air, { s.dsp(s.config.copy(enabled = true, air = it)) })
        Text("Размер помещения")
        Slider(s.config.reverbSize, { s.dsp(s.config.copy(enabled = true, reverbSize = it)) })
        Text("Поглощение верха")
        Slider(s.config.reverbDamp, { s.dsp(s.config.copy(enabled = true, reverbDamp = it)) })
        Text("Ламповое насыщение")
        Slider(s.config.drive, { s.dsp(s.config.copy(enabled = true, drive = it)) })
        SettingToggle("Лимитер", s.config.limiter) { s.dsp(s.config.copy(limiter = it)) }
    }
}

/** Native desktop pill; popup input keeps focus while pointer and keyboard select results. */
@Composable private fun DesktopSearchField(
    text: String, onText: (String) -> Unit, onSubmit: () -> Unit,
    onFocus: (Boolean) -> Unit, hint: String = "Что хочешь послушать?", mobileSearch: Boolean = true,
    onMove: (Int) -> Unit = {}, onDismiss: () -> Unit = {}
) {
    var focused by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(if (mobileSearch) 44.dp else 36.dp)
        .clip(RoundedCornerShape(if (mobileSearch) 24.dp else 6.dp)).background(Color(0xFF242424))
        .border(if (focused) 1.5.dp else 0.dp, if (focused) Ink else Color.Transparent, RoundedCornerShape(if (mobileSearch) 24.dp else 6.dp))
        .padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ZiziIcons.Search, null, tint = Muted, modifier = Modifier.size(if (mobileSearch) 23.dp else 18.dp))
        Spacer(Modifier.width(12.dp))
        BasicTextField(text, { onText(it.take(300)) }, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = if (mobileSearch) 14.sp else 12.sp), cursorBrush = SolidColor(Brand),
            modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
                .onPreviewKeyEvent {
                    if (it.type != KeyEventType.KeyDown) false else when (it.key) {
                        Key.Enter -> { onSubmit(); true }
                        Key.DirectionDown -> if (mobileSearch) { onMove(1); true } else false
                        Key.DirectionUp -> if (mobileSearch) { onMove(-1); true } else false
                        Key.Escape -> { onDismiss(); true }
                        else -> false
                    }
                }, decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) Text(hint, color = Muted, fontSize = if (mobileSearch) 14.sp else 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        inner()
                    }
                })
        if (text.isNotEmpty()) IconButton(onClick = { onText("") }, modifier = Modifier.size(30.dp)) { Icon(ZiziIcons.Close, "Очистить поиск", tint = Muted, modifier = Modifier.size(20.dp)) }
    }
}

/** Mobile refresh motion: 900 ms linear turn, 340 ms settling to the complete turn. */
@Composable private fun SearchRefresh(refreshing: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) {
                angle.animateTo(angle.value + 360f, tween(900, easing = LinearEasing))
                angle.snapTo(angle.value % 360f)
            }
        } else if (angle.value != 0f) {
            angle.animateTo(360f, tween(340, easing = FastOutSlowInEasing))
            angle.snapTo(0f)
        }
    }
    IconButton(onClick = { if (!refreshing) onClick() }, enabled = enabled,
        modifier = Modifier.size(42.dp).graphicsLayer { rotationZ = angle.value }) {
        Icon(ZiziIcons.Refresh, "Повторить поиск", tint = if (enabled) Brand else Muted, modifier = Modifier.size(23.dp))
    }
}

/** The sidebar uses real local collections only; no dummy subscriptions or recommendations. */
@Composable private fun LibrarySidebar(s: DesktopUi, cards: List<LibraryCard>, page: String, selectedKey: String?,
    collapsed: Boolean, modifier: Modifier, onCollapse: () -> Unit, onNavigate: (String) -> Unit,
    onCard: (LibraryCard) -> Unit, onCreate: () -> Unit, onSource: () -> Unit, closing: Boolean) {
    var filter by remember { mutableStateOf("Все") }
    var addMenu by remember { mutableStateOf(false) }
    val shown = cards.filter { when (filter) {
        "Плейлисты" -> it.key.startsWith("pl:") || it.key == "favorites"
        "Исполнители" -> it.key.startsWith("artist:")
        "Папки" -> it.key.startsWith("dir:")
        else -> true
    } }
    Column(modifier.clip(RoundedCornerShape(8.dp)).background(Panel).padding(if (collapsed) 4.dp else 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCollapse) { Icon(if (collapsed) ZiziIcons.ChevronRight else ZiziIcons.ArrowBack,
                if (collapsed) "Развернуть боковую медиатеку" else "Свернуть до значков", tint = Muted) }
            if (!collapsed) {
                Text("Моя медиатека", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Box {
                    IconButton(onClick = { addMenu = true }) { Icon(ZiziIcons.Plus, "Создать или добавить", tint = Brand) }
                    DropdownMenu(addMenu, { addMenu = false }) {
                        DropdownMenuItem(text = { Text("Создать плейлист") }, onClick = { addMenu = false; onCreate() })
                        DropdownMenuItem(text = { Text("Добавить файлы") }, onClick = { addMenu = false; s.add(chooseFiles()) }, enabled = !closing)
                        DropdownMenuItem(text = { Text("Добавить папку") }, onClick = { addMenu = false; chooseFolder()?.let(s::scanFolder) }, enabled = !s.scanning)
                        DropdownMenuItem(text = { Text("Открыть ссылку") }, onClick = { addMenu = false; onSource() })
                    }
                }
            }
        }
        if (!collapsed) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Все", "Плейлисты", "Исполнители", "Папки").forEach { label ->
                    FilterChip(filter == label, { filter = label }, label = { Text(label, fontSize = 12.sp) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onNavigate("Медиатека") }) { Text("Открыть всё", fontSize = 12.sp) }
                Spacer(Modifier.weight(1f)); Text("${shown.size}", color = Muted, fontSize = 12.sp)
            }
        }
        ScrollList(Modifier.weight(1f), reserveScrollbar = !collapsed, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(shown, key = { it.key }) { card ->
                val interaction = remember { MutableInteractionSource() }
                val hovered by interaction.collectIsHoveredAsState()
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp))
                    .background(if (selectedKey == card.key) Color(0xFF292929) else if (hovered) Chip else Color.Transparent)
                    .hoverable(interaction).clickable { onCard(card) }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    CardArtwork(card, s, if (collapsed) 40.dp else 44.dp)
                    if (!collapsed) {
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(card.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(card.subtitle, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (collapsed) Arrangement.Center else Arrangement.SpaceBetween) {
            IconButton(onClick = { onNavigate("Загрузки") }) { Icon(ZiziIcons.DownloadDone, "Скачанные треки", tint = if (page == "Загрузки") Brand else Muted) }
            if (!collapsed) {
                IconButton(onClick = { onNavigate("Поиск") }) { Icon(ZiziIcons.Search, "Поиск в каталоге", tint = Muted) }
                IconButton(onClick = { onNavigate("Настройки") }) { Icon(ZiziIcons.Tune, "Настройки", tint = Muted) }
            }
        }
    }
}
@Composable private fun CardArtwork(card: LibraryCard, s: DesktopUi, size: Dp) {
    if (card.key == "favorites") Box(Modifier.size(size).clip(RoundedCornerShape(4.dp))
        .background(Brush.linearGradient(listOf(Color(0xFFA8380C), Brand, Color(0xFFFFD2A8)))), contentAlignment = Alignment.Center) {
        Icon(ZiziIcons.HeartFilled, null, Modifier.size(size * .42f), tint = Ink)
    } else if (card.cover != null) Artwork(card.cover, s.client, size, card.icon == ZiziIcons.Person)
    else Box(Modifier.size(size).clip(if (card.icon == ZiziIcons.Person) CircleShape else RoundedCornerShape(4.dp)).background(Chip), contentAlignment = Alignment.Center) {
        Icon(card.icon, null, Modifier.size(size * .4f), tint = Muted)
    }
}
@Composable private fun SearchSuggestions(s: DesktopUi, completions: List<String>, tracks: List<PlayerTrack>, selected: Int,
    closing: Boolean, width: Dp, onQuery: (String) -> Unit, onTrack: (PlayerTrack) -> Unit, onAll: () -> Unit) {
    Surface(Modifier.width(width).heightIn(max = 560.dp), color = Color(0xFF282828), shape = RoundedCornerShape(8.dp), shadowElevation = 16.dp) {
        LazyColumn(Modifier.fillMaxWidth().padding(6.dp)) {
            item { Text("↑ ↓ выбрать · Enter открыть · Esc закрыть", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(10.dp)) }
            itemsIndexed(completions) { index, text ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(if (index == selected) Color(0xFF424242) else Color.Transparent)
                    .clickable { onQuery(text) }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(ZiziIcons.Search, null, Modifier.size(20.dp), tint = Muted); Spacer(Modifier.width(16.dp))
                    Text(buildAnnotatedString {
                        val query = s.previewQuery.trim()
                        val at = if (query.isBlank()) -1 else text.indexOf(query, ignoreCase = true)
                        if (at < 0) append(text) else {
                            append(text.substring(0, at))
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Ink)) { append(text.substring(at, at + query.length)) }
                            append(text.substring(at + query.length))
                        }
                    }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                }
            }
            if (tracks.isNotEmpty()) item { Text("Треки", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(10.dp)) }
            itemsIndexed(tracks, key = { _, it -> it.id }) { index, track ->
                val interaction = remember { MutableInteractionSource() }; val hover by interaction.collectIsHoveredAsState()
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp))
                    .background(if (selected == completions.size + index || hover) Color(0xFF424242) else Color.Transparent)
                    .hoverable(interaction).clickable(enabled = !closing) { onTrack(track) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(track, s.client, 42.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(track.artist.ifBlank { "Трек" }, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { s.save(track) }, enabled = s.tracks.none { it.id == track.id }) {
                        Icon(if (s.tracks.any { it.id == track.id }) ZiziIcons.Check else ZiziIcons.Plus, "Сохранить в медиатеку", Modifier.size(19.dp), tint = Brand)
                    }
                }
            }
            item {
                if (s.previewLoading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Brand)
                if (s.previewMessage.isNotBlank()) Text(s.previewMessage, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                if (!s.previewLoading && tracks.isEmpty() && completions.isEmpty()) Text(
                    if (s.previewQuery.length < 2) "Введи минимум два символа" else "Совпадений нет", color = Muted, modifier = Modifier.padding(12.dp))
                if (s.previewQuery.isNotBlank()) TextButton(onClick = onAll) { Text("Показать все результаты") }
            }
        }
    }
}
@Composable private fun QueuePanel(s: DesktopUi, closing: Boolean, modifier: Modifier, close: () -> Unit, onArtist: (PlayerTrack) -> Unit) {
    val state by s.player.state.collectAsState()
    val queue by s.player.queueState.collectAsState()
    var previous by remember { mutableStateOf(false) }
    val current = queue.indexOfFirst { it.id == state.track?.id }
    // Queue positions are not claimed to be a listening history, especially when shuffle is on.
    val shown = if (previous) queue.take(current.coerceAtLeast(0)) else queue.drop(if (current < 0) 0 else current + 1)
    Column(modifier.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Очередь", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            IconButton(onClick = close) { Icon(ZiziIcons.Close, "Закрыть очередь", tint = Muted) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(!previous, { previous = false }, label = { Text("Далее") })
            FilterChip(previous, { previous = true }, label = { Text("Выше в очереди") })
        }
        ScrollList(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item {
                Text("Сейчас играет", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(vertical = 14.dp))
                state.track?.let { QueueTrack(s, it, queue, closing, current = true, onArtist = onArtist) }
                    ?: Text("Выбери музыку", color = Muted, fontSize = 13.sp)
                Text(if (previous) "Выше текущего трека" else if (s.prefs.shuffle) "Далее · случайный порядок" else "Далее", fontWeight = FontWeight.Bold,
                    fontSize = 13.sp, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                if (s.prefs.shuffle) Text("Список показывает расположение в очереди, не порядок перемешивания.", color = Muted, fontSize = 12.sp)
                if (shown.isEmpty()) Text("Здесь пока пусто", color = Muted, fontSize = 13.sp)
            }
            items(shown, key = { it.id }) { track -> QueueTrack(s, track, queue, closing, onArtist = onArtist) }
        }
    }
}
@Composable private fun QueueTrack(s: DesktopUi, track: PlayerTrack, queue: List<PlayerTrack>, closing: Boolean,
    current: Boolean = false, onArtist: (PlayerTrack) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }; val hover by interaction.collectIsHoveredAsState()
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(if (hover) Chip else Color.Transparent)
        .hoverable(interaction).clickable(enabled = !closing) { if (current) s.player.togglePause() else s.player.play(track, queue) }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(track, s.client, 40.dp); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = if (current) Brand else Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clickable(enabled = track.artist.isNotBlank()) { onArtist(track) })
        }
        Box {
            IconButton(onClick = { menu = true }, modifier = Modifier.size(30.dp)) { Icon(ZiziIcons.More, "Действия в очереди", Modifier.size(18.dp), tint = Muted) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Выше") }, onClick = { s.player.move(track.id, -1); menu = false }, enabled = queue.indexOfFirst { it.id == track.id } > 0)
                DropdownMenuItem(text = { Text("Ниже") }, onClick = { s.player.move(track.id, 1); menu = false }, enabled = queue.indexOfFirst { it.id == track.id } in 0 until queue.lastIndex)
                DropdownMenuItem(text = { Text("Удалить из очереди") }, onClick = { s.player.remove(track.id); menu = false }, enabled = !closing)
            }
        }
    }
}

/** Native desktop scrollbar shares exactly the same state as wheel/trackpad scrolling. */
@Composable private fun ScrollList(modifier: Modifier = Modifier, state: LazyListState = rememberLazyListState(),
    verticalArrangement: Arrangement.Vertical = Arrangement.Top, reserveScrollbar: Boolean = true, content: LazyListScope.() -> Unit) {
    Box(modifier) {
        LazyColumn(Modifier.fillMaxSize().padding(end = if (reserveScrollbar) 10.dp else 0.dp), state = state, verticalArrangement = verticalArrangement, content = content)
        VerticalScrollbar(rememberScrollbarAdapter(state), Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(8.dp))
    }
}
