package app.ziziplayer.desktop.ui;

public final class DesktopLayoutChecks {
    static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        int cases = 0;
        for (int width = 960; width <= 3840; width++) {
            float search = DesktopLayout.searchWidth(width);
            check(search <= 480 && search >= 400, "search bounds");
            check((width - search) / 2 > 140, "search overlaps navigation");
            for (int mode = 0; mode <= 2; mode++) for (boolean right : new boolean[]{false, true}) {
                float sidebar = DesktopLayout.sidebarWidth(width, mode, right);
                float center = width - 12 - sidebar - (sidebar > 0 ? 6 : 0)
                    - (right ? DesktopLayout.rightWidth(width) + 6 : 0);
                check(center >= 510, "main content squeezed");
                float gridWidth = center - 40;
                int columns = DesktopLayout.columns(gridWidth);
                float artwork = DesktopLayout.artworkSize(gridWidth, columns);
                check(artwork >= 72 && artwork <= 184, "artwork bounds");
                check((artwork + 20) * columns + 12 * (columns - 1) <= gridWidth + .01, "grid overflow");
                check(center - 40 - (center < 680 ? 144 + 18 : 184 + 24) >= 300, "hero text too narrow");
                cases++;
            }
        }
        check(DesktopLayout.sidebarWidth(960, 0, true) == 0, "hidden sidebar");
        check(DesktopLayout.sidebarWidth(960, 2, true) == 64, "automatic rail");
        check(DesktopLayout.sidebarWidth(1920, 2, true) == 300, "wide library");
        check(DesktopLayout.artworkSize(40, 1) == 20, "tiny transitional column");
        System.out.println("PASS " + cases + " production layout configurations (not a Compose render)");
    }
}
