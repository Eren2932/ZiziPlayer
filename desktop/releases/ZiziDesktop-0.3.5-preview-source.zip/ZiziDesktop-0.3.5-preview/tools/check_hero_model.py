"""Independent numerical model; not execution of Kotlin, Compose or a screenshot test."""
import math


def visibility(scroll, height):
    t = max(0.0, min(1.0, scroll / max(height, 1)))
    return 1 - t * t * (3 - 2 * t)

checks = 0
for height in (252, 316, 340, 420):
    previous = 1.0
    for step in range(-100, 20001):
        scroll = step / 10
        a = visibility(scroll, height)
        assert math.isfinite(a) and 0 <= a <= 1
        assert a <= previous + 1e-12
        assert previous - a < .001
        if scroll >= height:
            assert a == 0
        previous = a
        checks += 1
    for step in range(1001):
        a = step / 1000
        for tone in (0, .1, .3, .7, 1):
            panel = 16 / 255
            landing = panel + (tone - panel) * .62
            faded_tail = panel * (1 - a) + landing * a
            seam = panel + (tone - panel) * (.62 * a)
            assert abs(faded_tail - seam) < 1e-12
            checks += 1
print(f'PASS independent hero fade/seam model: {checks} numeric assertions')
print('NOT a Kotlin execution; motion, contrast over photographs and render require Windows acceptance.')
