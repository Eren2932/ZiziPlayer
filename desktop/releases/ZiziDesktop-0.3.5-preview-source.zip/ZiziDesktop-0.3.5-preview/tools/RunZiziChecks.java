import javax.tools.ToolProvider;
import java.nio.file.*;
import java.net.*;
public class RunZiziChecks {
 public static void main(String[] args) throws Exception {
  Path root = Path.of(args[0]); Path out = Files.createTempDirectory("zizi-jvm-checks");
  String[] files = {"src/main/java/app/ziziplayer/ui/theme/ArtworkColorMath.java", "src/test/java/app/ziziplayer/ui/ArtworkColorMathChecks.java", "src/main/java/app/ziziplayer/desktop/ui/DesktopLayout.java", "src/test/java/app/ziziplayer/desktop/ui/DesktopLayoutChecks.java"};
  String[] compile = new String[files.length+2]; compile[0]="-d"; compile[1]=out.toString();
  for(int i=0;i<files.length;i++) compile[i+2]=root.resolve(files[i]).toString();
  int code = ToolProvider.getSystemJavaCompiler().run(null, null, null, compile);
  if(code!=0) throw new AssertionError("Java compilation failed");
  try(var loader = new URLClassLoader(new URL[]{out.toUri().toURL()})) {
   for(String name : new String[]{"app.ziziplayer.ui.ArtworkColorMathChecks", "app.ziziplayer.desktop.ui.DesktopLayoutChecks"})
    loader.loadClass(name).getMethod("main", String[].class).invoke(null,(Object)new String[0]);
  }
 }
}
