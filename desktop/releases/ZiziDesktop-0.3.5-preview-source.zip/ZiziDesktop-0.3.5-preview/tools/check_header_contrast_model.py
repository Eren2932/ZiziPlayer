import numpy as np
# Independent numerical check of the documented Oklch header bounds, not a Kotlin execution.
values=np.array([(r,g,b) for r in range(0,256,17) for g in range(0,256,17) for b in range(0,256,17)])/255
linear=np.where(values<=.04045,values/12.92,((values+.055)/1.055)**2.4)
M=np.array([[.4122214708,.5363325363,.0514459929],[.2119034982,.6806995451,.1073969566],[.0883024619,.2817188376,.6299787005]])
N=np.array([[.2104542553,.7936177850,-.0040720468],[1.9779984951,-2.4285922050,.4505937099],[.0259040371,.7827717662,-.8086757660]])
lab=np.cbrt(linear@M.T)@N.T
L=np.clip(lab[:,0],.36,.50); C=np.minimum(np.hypot(lab[:,1],lab[:,2])*1.18,.22); h=np.arctan2(lab[:,2],lab[:,1])
def convert(L,C,h):
 a=C*np.cos(h); b=C*np.sin(h)
 l=(L+.3963377774*a+.2158037573*b)**3;m=(L-.1055613458*a-.0638541728*b)**3;s=(L-.0894841775*a-1.2914855480*b)**3
 return np.array([4.0767416621*l-3.3077115913*m+.2309699292*s,-1.2684380046*l+2.6097574011*m-.3413193965*s,-.0041960863*l-.7034186147*m+1.7076147010*s]).T
for _ in range(25):
 rgb=convert(L,C,h); outside=((rgb<-.001)|(rgb>1.001)).any(axis=1); C[outside]*=.94
rgb=convert(L,C,h).clip(0,1)
lum=rgb@np.array([.2126,.7152,.0722]);ink=np.array([246,247,248])/255;inklum=(((ink+.055)/1.055)**2.4)@np.array([.2126,.7152,.0722]); contrast=(inklum+.05)/(lum+.05)
print('Independent 4096-colour Oklch model: minimum solid text contrast =',contrast.min())
assert contrast.min()>=4.5
