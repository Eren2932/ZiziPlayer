import java.util.Properties

plugins {
    kotlin("jvm") version "2.1.0"
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.0"
    id("org.jetbrains.compose") version "1.7.3"
}
group = "app.ziziplayer.desktop"
version = "0.3.5"
kotlin { jvmToolchain(21) }
dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.json:json:20240303")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")
    testImplementation("junit:junit:4.13.2")
}
tasks.test {
    useJUnit()
    systemProperty("zizi.ffmpeg", providers.gradleProperty("ffmpegPath").getOrElse(""))
    systemProperty("zizi.requireFfmpeg", "true")
    testLogging { events("passed", "skipped", "failed") }
}
compose.desktop {
    application {
        mainClass = "app.ziziplayer.desktop.ui.DesktopMainKt"
        nativeDistributions {
            packageName = "ZiziDesktop"
            packageVersion = "0.3.5"
            includeAllModules = true
        }
    }
}

// Build inputs match Android. Never pass bootstrap in command-line arguments or print it.
// A packaged public client cannot keep this bootstrap secret from its owner.
val connectionResources = layout.buildDirectory.dir("generated/connectionResources")
val generateConnectionResources by tasks.registering {
    val resolverUrl = providers.environmentVariable("RESOLVER_URL").orElse("")
    val resolverToken = providers.environmentVariable("RESOLVER_TOKEN").orElse("")
    val allowHttp = providers.environmentVariable("DESKTOP_ALLOW_HTTP").orElse("false")
    outputs.dir(connectionResources)
    outputs.upToDateWhen { false }
    doLast {
        val output = connectionResources.get().file("zizi-connection.properties").asFile
        output.parentFile.mkdirs()
        val values = Properties()
        values.setProperty("resolver.url", resolverUrl.get().trim())
        values.setProperty("resolver.bootstrap", resolverToken.get().trim())
        values.setProperty("resolver.allowHttp", allowHttp.get())
        output.outputStream().use { values.store(it, "Zizi build configuration; do not log") }
    }
}
sourceSets { main { resources.srcDir(connectionResources) } }
tasks.named("processResources") { dependsOn(generateConnectionResources) }
