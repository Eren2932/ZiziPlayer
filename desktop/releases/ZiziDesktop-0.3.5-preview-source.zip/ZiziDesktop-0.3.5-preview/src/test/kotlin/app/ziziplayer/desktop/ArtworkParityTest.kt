package app.ziziplayer.desktop
import app.ziziplayer.ui.ArtworkColorMathChecks
import org.junit.Test
class ArtworkParityTest {
    @Test fun mobileColorRegressions() { ArtworkColorMathChecks.main(emptyArray()) }
}
