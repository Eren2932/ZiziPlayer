package app.ziziplayer.desktop

import app.ziziplayer.desktop.ui.*
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class DesktopRefinementTest {
    @Test fun sameDockButtonClosesWithoutSelectingAnotherPanel() {
        for (panel in DesktopDock.entries.filter { it != DesktopDock.NONE }) {
            assertEquals(DesktopDock.NONE, panel.toggle(panel))
            assertEquals(panel, DesktopDock.NONE.toggle(panel))
        }
    }
    @Test fun switchingDocksHasOneOwnerForEveryTransition() {
        for (from in DesktopDock.entries) for (to in DesktopDock.entries.filter { it != DesktopDock.NONE })
            assertEquals(if (from == to) DesktopDock.NONE else to, from.toggle(to))
    }
    @Test fun rapidToggleSequenceNeverFallsThroughToEffects() {
        var dock = DesktopDock.NONE
        repeat(10000) {
            dock = dock.toggle(DesktopDock.QUEUE)
            assertEquals(DesktopDock.QUEUE, dock)
            dock = dock.toggle(DesktopDock.QUEUE)
            assertEquals(DesktopDock.NONE, dock)
            dock = dock.toggle(DesktopDock.DEVICES)
            assertEquals(DesktopDock.DEVICES, dock)
            dock = dock.toggle(DesktopDock.DEVICES)
        }
    }
    @Test fun gradientTailIsOpaqueAndReachesPanelExactly() {
        val tone = collectionTone(0xFFDA2830.toInt())
        assertEquals(tone, shadeCollectionTone(tone, 1f))
        assertEquals(Color(0xFF101010), shadeCollectionTone(tone, 0f))
        for (step in 0..100) assertEquals(1f, shadeCollectionTone(tone, step / 100f).alpha, .0001f)
    }
    @Test fun brokenSearchShelfDoesNotThrowAwaySiblingResults() = runBlocking {
        supervisorScope {
            val good = async { searchPart { listOf("real result") } }
            val bad = async { searchPart<List<String>> { throw IllegalStateException("offline") } }
            assertEquals(listOf("real result"), good.await().getOrNull())
            assertTrue(bad.await().isFailure)
        }
    }
    @Test fun cancelledSearchIsNotConvertedToEmptySuccess() = runBlocking {
        try {
            searchPart<List<String>> { throw CancellationException("superseded") }
            fail("Cancellation must propagate")
        } catch (_: CancellationException) { }
    }
    @Test fun systemOutputSelectionDoesNotInventAnActiveHeadset() {
        val outputs = AudioOutputs()
        assertNull(outputs.active.value)
        outputs.select(OutputDevice("missing-for-test", "Test headphones"))
        assertNull(outputs.active.value)
        assertEquals("missing-for-test", outputs.selectedId)
        outputs.select(null)
        assertNull(outputs.selectedId)
    }
}
