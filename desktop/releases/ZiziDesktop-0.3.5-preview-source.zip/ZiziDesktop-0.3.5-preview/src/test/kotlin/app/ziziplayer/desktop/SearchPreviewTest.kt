package app.ziziplayer.desktop

import app.ziziplayer.desktop.ui.SearchPreview
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class SearchPreviewTest {
    private fun track(name: String) = PlayerTrack("/music/$name.wav", name)
    @Test fun debounceOnlyRequestsLastQuery() = runBlocking {
        val calls = mutableListOf<String>()
        val finished = CompletableDeferred<Unit>()
        val preview = SearchPreview(this, { calls.add(it); finished.complete(Unit); listOf(track(it)) }, { "error" }, 20)
        preview.request("mo"); preview.request("mon"); preview.request("montagem")
        withTimeout(3000) { finished.await(); while (preview.loading) yield() }
        assertEquals(listOf("montagem"), calls); assertEquals("montagem", preview.tracks.single().title)
        preview.cancel()
    }
    @Test fun obsoleteUncooperativeResponseCannotReplaceNewResult() = runBlocking {
        val started = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>(); val latest = CompletableDeferred<Unit>()
        val preview = SearchPreview(this, { q ->
            if (q == "old") { started.complete(Unit); withContext(NonCancellable) { release.await() } }
            else latest.complete(Unit)
            listOf(track(q))
        }, { "error" }, 0)
        preview.request("old"); withTimeout(3000) { started.await() }
        preview.request("new"); withTimeout(3000) { latest.await(); while (preview.loading) yield() }
        release.complete(Unit); yield()
        assertEquals("new", preview.tracks.single().title); assertFalse(preview.loading)
        preview.cancel()
    }
    @Test fun dismissCancelsPendingNetworkRequest() = runBlocking {
        var calls = 0
        val preview = SearchPreview(this, { calls++; emptyList() }, { "error" }, 20)
        preview.request("query"); preview.cancel(); delay(40)
        assertEquals(0, calls); assertTrue(preview.tracks.isEmpty()); assertFalse(preview.loading)
    }
    @Test fun shortInputDoesNotCallServerAndResultsAreBounded() = runBlocking {
        var calls = 0; val finished = CompletableDeferred<Unit>()
        val preview = SearchPreview(this, { calls++; finished.complete(Unit); (0..19).flatMap { listOf(track("$it"), track("$it")) } }, { "error" }, 0)
        preview.request("a"); yield(); assertEquals(0, calls)
        preview.request("ab"); withTimeout(3000) { finished.await(); while (preview.loading) yield() }
        assertEquals(6, preview.tracks.size); assertEquals(6, preview.tracks.distinctBy { it.id }.size)
        preview.cancel()
    }
    @Test fun offlineAndErrorsHaveExplicitState() = runBlocking {
        var fail = false
        val preview = SearchPreview(this, { if (fail) throw IllegalStateException("do not expose raw error") else null }, { "Безопасное сообщение" }, 0)
        preview.request("ab"); withTimeout(3000) { while (preview.loading) yield() }
        assertTrue(preview.message.contains("медиатеки")); fail = true
        preview.request("abc"); withTimeout(3000) { while (preview.loading) yield() }
        assertEquals("Безопасное сообщение", preview.message); assertTrue(preview.tracks.isEmpty())
        preview.cancel()
    }
}
