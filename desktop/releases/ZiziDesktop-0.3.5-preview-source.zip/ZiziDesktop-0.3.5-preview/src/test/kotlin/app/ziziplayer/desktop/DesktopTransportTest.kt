package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.net.InetSocketAddress
import java.net.URI
import java.nio.file.Files
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class DesktopTransportTest {
    private class FakeSink : Sink {
        val frames = AtomicLong()
        val closed = AtomicBoolean()
        @Volatile var paused = false
        override fun start() {}
        override fun pause(value: Boolean) { paused = value }
        override fun playedFrames() = frames.get()
        override fun write(bytes: ByteArray, count: Int) {
            while (paused && !closed.get()) Thread.sleep(2)
            if (!closed.get()) { frames.addAndGet(count / 4L); Thread.sleep(5) }
        }
        override fun finish() {}
        override fun interrupt() { close() }
        override fun close() { closed.set(true) }
    }
    private fun decoder(): Decoder = object : Decoder {
        override val pcm = ByteArrayInputStream(ByteArray(Pcm.RATE * 8 * 20))
        override fun checkExit() {}
        override fun close() { pcm.close() }
    }
    private fun withPlayer(block: suspend (DesktopPlayer, CopyOnWriteArrayList<Long>, CopyOnWriteArrayList<FakeSink>) -> Unit) = runBlocking {
        val dispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
        val scope = CoroutineScope(SupervisorJob() + dispatcher)
        val offsets = CopyOnWriteArrayList<Long>(); val sinks = CopyOnWriteArrayList<FakeSink>()
        val player = DesktopPlayer(scope, { _, _, offset -> offsets.add(offset); decoder() },
            { FakeSink().also { sinks.add(it) } }, { _, _, _ -> Metadata.Info(null, null, 20_000) })
        try { withTimeout(8000) { withContext(dispatcher) { block(player, offsets, sinks) } } }
        finally {
            val finished = CompletableDeferred<Unit>()
            withContext(dispatcher) { player.close { finished.complete(Unit) } }
            withTimeout(5000) { finished.await() }
            scope.cancel(); dispatcher.close()
        }
    }
    private suspend fun playing(player: DesktopPlayer) = withTimeout(4000) { player.state.first { it.phase == PlaybackPhase.PLAYING } }
    @Test fun pauseFreezesDeviceClockAndResumeKeepsDecoder() = withPlayer { p, offsets, sinks ->
        p.play(PlayerTrack("/fake-a", "A", durationMs = 20_000)); playing(p)
        p.togglePause(); delay(80)
        val frozen = sinks.last().frames.get(); delay(120)
        assertEquals(frozen, sinks.last().frames.get())
        assertEquals(PlaybackPhase.PAUSED, p.state.value.phase)
        p.togglePause(); delay(100)
        assertTrue(sinks.last().frames.get() > frozen); assertEquals(listOf(0L), offsets.toList())
    }
    @Test fun seekCreatesNewDecoderAndPreservesPause() = withPlayer { p, offsets, _ ->
        p.play(PlayerTrack("/fake-a", "A", durationMs = 20_000)); playing(p); p.togglePause()
        p.seek(5000)
        withTimeout(3000) { p.state.first { it.phase == PlaybackPhase.PAUSED && it.seekable } }
        delay(100)
        assertEquals(listOf(0L, 5000L), offsets.toList())
        assertEquals(5000L, p.progress.value.positionMs)
        assertEquals(p.state.value.generation, p.progress.value.generation)
    }
    @Test fun rapidSwitchAndStopCannotPublishOldProgress() = withPlayer { p, _, _ ->
        val a = PlayerTrack("/a", "A", durationMs = 20_000); val b = PlayerTrack("/b", "B", durationMs = 20_000)
        repeat(20) { p.play(if (it % 2 == 0) a else b) }; playing(p)
        assertEquals(b.id, p.state.value.track?.id)
        assertEquals(b.id, p.progress.value.trackId)
        assertEquals(p.state.value.generation, p.progress.value.generation)
        p.stop(); delay(200)
        assertEquals(PlaybackPhase.IDLE, p.state.value.phase); assertEquals(0L, p.progress.value.positionMs)
    }
    @Test fun seekWithoutDurationIsDisabled() = withPlayer { p, offsets, _ ->
        p.play(PlayerTrack("/a", "A")); p.seek(5000); playing(p)
        assertEquals(listOf(0L), offsets.toList())
    }
    @Test fun pauseBeforeEngineStartIsApplied() {
        val controls = Controls("off", 0.2f); controls.pause(true)
        val seen = mutableListOf<Boolean>()
        controls.attachPause { seen.add(it) }; controls.pause(false); controls.attachPause(null)
        assertEquals(listOf(true, false), seen)
    }
    @Test fun identityMatchesMobileEncodedMixAndRejectsInvalidProviders() {
        assertEquals("dz" to "123", RemoteIdentity.parse("zizi://mix/dz%3A123"))
        assertEquals("yt" to "abcdefghijk", RemoteIdentity.parse("zizi://yt/abcdefghijk"))
        for (bad in listOf("zizi://sp/123", "zizi://dz/123/456", "zizi://yt/short", "zizi://mix/zz%3A123", "zizi://dz/123?token=x"))
            assertThrows(IllegalArgumentException::class.java) { RemoteIdentity.parse(bad) }
    }
    @Test fun secretTransportRequiresHttpsAndNoUserinfo() {
        for (bad in listOf("http://example.org", "https://user:pass@example.org", "file:///tmp/a"))
            assertThrows(IllegalArgumentException::class.java) { HttpTransport.safeUri(bad) }
    }
    @Test fun ffmpegSeekIsBeforeInputAndDisallowsPlaylists() {
        val args = FfmpegDecoder.command("ffmpeg", "https://example.org/a", 1234)
        assertEquals("1.234", args[args.indexOf("-ss") + 1]); assertTrue(args.indexOf("-ss") < args.indexOf("-i"))
        assertFalse(args[args.indexOf("-format_whitelist") + 1].contains("hls"))
    }
    private fun server() = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    private fun base(server: HttpServer) = "http://127.0.0.1:${server.address.port}"
    @Test fun serverContractUsesDeviceKeyAndDeezerMatch() {
        val server = server(); val calls = CopyOnWriteArrayList<String>(); val errors = CopyOnWriteArrayList<String>()
        server.createContext("/") { e ->
            val path = e.requestURI.path; calls.add(path)
            if (e.requestHeaders.getFirst("X-Zizi-Install") != "test-install-123") errors.add("install")
            val expected = if (path == "/auth/device") "Bearer fixture-bootstrap" else "Bearer fixture-device"
            if (e.requestHeaders.getFirst("Authorization") != expected) errors.add("auth")
            val body = when (path) {
                "/auth/device" -> """{"token":"fixture-device","expires_in":86400}"""
                "/catalog/search" -> {
                    if (!e.requestURI.rawQuery.contains("src=deezer")) errors.add("source")
                    """{"items":[{"src":"deezer","id":"123","title":"Песня","artist":"Артист","dur":120}]}"""
                }
                "/match/deezer" -> """{"vid":"abcdefghijk"}"""
                "/resolve" -> """{"url":"https://example.org/private?token=fixture","mime":"webm"}"""
                else -> "{}"
            }.toByteArray(Charsets.UTF_8)
            e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }; e.close()
        }
        server.start()
        try {
            val client = ZiziClient(base(server), "fixture-bootstrap", "test-install-123")
            val track = client.search("Песня").single()
            assertEquals("zizi://dz/123", track.id)
            assertEquals(120_000L, track.durationMs)
            val target = client.resolve(track.id)
            assertEquals("/stream", target.uri.path); assertEquals("id=abcdefghijk", target.uri.query)
            assertEquals("Bearer fixture-device", target.headers()["Authorization"])
            assertTrue(errors.toString(), errors.isEmpty())
            assertEquals(listOf("/auth/device", "/catalog/search", "/match/deezer", "/resolve"), calls.toList())
        } finally { server.stop(0) }
    }
    @Test fun bridgePreservesRangeAndHidesUpstream() {
        val server = server(); val errors = CopyOnWriteArrayList<String>()
        server.createContext("/stream") { e ->
            if (e.requestHeaders.getFirst("Authorization") != "Bearer fixture") errors.add("auth")
            if (e.requestHeaders.getFirst("Range") != "bytes=2-4") errors.add("range")
            e.responseHeaders.set("Content-Range", "bytes 2-4/8"); e.responseHeaders.set("Accept-Ranges", "bytes")
            e.sendResponseHeaders(206, 3); e.responseBody.use { it.write(byteArrayOf(2, 3, 4)) }; e.close()
        }
        server.start()
        try {
            StreamBridge(StreamTarget(URI(base(server) + "/stream?private=fixture")) { mapOf("Authorization" to "Bearer fixture") }).use { bridge ->
                val args = FfmpegDecoder.command("ffmpeg", bridge.input)
                assertFalse(args.joinToString().contains("fixture")); assertFalse(args.joinToString().contains("Authorization"))
                val c = HttpTransport.open(URI(bridge.input), mapOf("Range" to "bytes=2-4"))
                try { assertEquals(206, c.responseCode); assertEquals("bytes 2-4/8", c.getHeaderField("Content-Range")); assertArrayEquals(byteArrayOf(2, 3, 4), c.inputStream.readBytes()) }
                finally { c.disconnect() }
                val wrong = HttpTransport.open(URI(bridge.input + "/wrong"))
                try { assertEquals(404, wrong.responseCode) } finally { wrong.disconnect() }
            }
            assertTrue(errors.toString(), errors.isEmpty())
        } finally { server.stop(0) }
    }
    @Test fun bridgeRejectsRedirectWithoutForwardingToken() {
        val server = server(); val redirectHit = AtomicBoolean()
        server.createContext("/redirect") { e -> e.responseHeaders.set("Location", base(server) + "/secret"); e.sendResponseHeaders(302, -1); e.close() }
        server.createContext("/secret") { e -> redirectHit.set(true); e.sendResponseHeaders(200, -1); e.close() }
        server.start()
        try {
            StreamBridge(StreamTarget(URI(base(server) + "/redirect")) { mapOf("Authorization" to "Bearer fixture") }).use { bridge ->
                val c = HttpTransport.open(URI(bridge.input))
                try { assertEquals(502, c.responseCode) } finally { c.disconnect() }
            }
            assertFalse(redirectHit.get())
        } finally { server.stop(0) }
    }
    @Test fun authFailureBacksOffAndCatalogQuotaIsNotSuccess() {
        val server = server(); val authCalls = AtomicLong()
        server.createContext("/auth/device") { e -> authCalls.incrementAndGet(); e.sendResponseHeaders(503, -1); e.close() }
        server.createContext("/catalog/search") { e -> e.sendResponseHeaders(429, -1); e.close() }
        server.start()
        try {
            val client = ZiziClient(base(server), "fixture-bootstrap", "test-install-123")
            repeat(2) {
                val error = assertThrows(NetworkFailure::class.java) { client.search("track") }
                assertEquals(429, error.code)
            }
            assertEquals(1L, authCalls.get())
        } finally { server.stop(0) }
    }
    @Test fun bridgePreservesHeadAndRejectsPlaylists() {
        val server = server()
        server.createContext("/audio") { e ->
            e.responseHeaders.set("Content-Length", "1234"); e.responseHeaders.set("Accept-Ranges", "bytes")
            e.sendResponseHeaders(200, -1); e.close()
        }
        server.createContext("/playlist") { e ->
            e.responseHeaders.set("Content-Type", "application/vnd.apple.mpegurl")
            e.sendResponseHeaders(200, -1); e.close()
        }
        server.start()
        try {
            StreamBridge(StreamTarget(URI(base(server) + "/audio")) { emptyMap() }).use { bridge ->
                val c = HttpTransport.open(URI(bridge.input), method = "HEAD")
                try { assertEquals(200, c.responseCode); assertEquals(1234L, c.contentLengthLong) } finally { c.disconnect() }
            }
            StreamBridge(StreamTarget(URI(base(server) + "/playlist")) { emptyMap() }).use { bridge ->
                val c = HttpTransport.open(URI(bridge.input))
                try { assertEquals(415, c.responseCode) } finally { c.disconnect() }
            }
        } finally { server.stop(0) }
    }
    @Test fun javaSoundPauseStopsLineWithoutFlushingAndClockUsesDevice() {
        var running = false; var flushes = 0; var clock = 0L
        val line = java.lang.reflect.Proxy.newProxyInstance(javaClass.classLoader,
            arrayOf(javax.sound.sampled.SourceDataLine::class.java)) { _, method, args ->
            when (method.name) {
                "start" -> { running = true; null }
                "stop" -> { running = false; null }
                "flush" -> { flushes++; null }
                "getLongFramePosition" -> clock
                "available", "getBufferSize" -> 16384
                "write" -> args!![2] as Int
                "isOpen", "isRunning", "isActive" -> running
                else -> null
            }
        } as javax.sound.sampled.SourceDataLine
        JavaSoundSink(160) { line }.use { sink ->
            sink.start(); assertTrue(running)
            sink.write(ByteArray(4096), 4096)
            assertEquals(0L, sink.playedFrames()) // Submitted PCM isn't device position.
            clock = 256; assertEquals(256L, sink.playedFrames())
            sink.pause(true); assertFalse(running); assertEquals(0, flushes)
            sink.pause(false); assertTrue(running); assertEquals(0, flushes)
            clock = 0; assertEquals(256L, sink.playedFrames()) // Closed/reset driver cannot rewind UI.
        }
        assertEquals(1, flushes)
    }
    @Test(timeout = 60000) fun realFfmpegAndProbeThroughAuthenticatedBridgeWithRange() {
        val exe = System.getProperty("zizi.ffmpeg")
        val dir = Files.createTempDirectory("zizi-bridge-decode-"); val wav = dir.resolve("tone.wav")
        val server = server(); val errors = CopyOnWriteArrayList<String>()
        try {
            WavSink(wav).use { it.write(ByteArray(Pcm.RATE * 4 * 2), Pcm.RATE * 4 * 2) }
            val bytes = Files.readAllBytes(wav)
            server.createContext("/stream") { e ->
                if (e.requestHeaders.getFirst("Authorization") != "Bearer fixture") errors.add("auth")
                val range = e.requestHeaders.getFirst("Range")
                val start = range?.substringAfter("bytes=")?.substringBefore('-')?.toIntOrNull() ?: 0
                if (start >= bytes.size) { e.sendResponseHeaders(416, -1); e.close() }
                else {
                    e.responseHeaders.set("Content-Type", "audio/wav"); e.responseHeaders.set("Accept-Ranges", "bytes")
                    if (range != null) e.responseHeaders.set("Content-Range", "bytes $start-${bytes.lastIndex}/${bytes.size}")
                    e.sendResponseHeaders(if (range == null) 200 else 206, (bytes.size - start).toLong())
                    runCatching { e.responseBody.use { it.write(bytes, start, bytes.size - start) } }; e.close()
                }
            }
            server.start()
            StreamBridge(StreamTarget(URI(base(server) + "/stream")) { mapOf("Authorization" to "Bearer fixture") }).use { bridge ->
                assertEquals(2000L, Metadata.read(exe, bridge.input, false).durationMs)
                val result = AudioEngine(Controls("off", 0.3f), 0).play(FfmpegDecoder(exe, bridge.input, 1250), WavSink(dir.resolve("tail.wav")))
                assertEquals(36_000L, result.frames)
            }
            assertTrue(errors.toString(), errors.isEmpty())
        } finally { server.stop(0); Files.list(dir).use { it.forEach { p -> Files.deleteIfExists(p) } }; Files.deleteIfExists(dir) }
    }
    @Test(timeout = 60000) fun realFfmpegSeekAndMetadata() {
        val exe = System.getProperty("zizi.ffmpeg")
        assertFalse(exe.isNullOrBlank())
        val dir = Files.createTempDirectory("zizi-seek-"); val wav = dir.resolve("tone.wav")
        try {
            WavSink(wav).use { it.write(ByteArray(Pcm.RATE * 4 * 2), Pcm.RATE * 4 * 2) }
            val info = Metadata.read(exe, wav.toString(), true)
            assertEquals(2000L, info.durationMs)
            val out = dir.resolve("tail.wav")
            val result = AudioEngine(Controls("off", 0.3f), 0).play(FfmpegDecoder(exe, wav.toString(), 1250), WavSink(out))
            assertEquals(36_000L, result.frames)
        } finally { Files.list(dir).use { it.forEach { p -> Files.deleteIfExists(p) } }; Files.deleteIfExists(dir) }
    }
}
