package app.ziziplayer.desktop

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class QueueTest {
    private class SinkStub : Sink {
        private var frames = 0L
        override fun start() {}
        override fun pause(value: Boolean) {}
        override fun playedFrames() = frames
        override fun write(bytes: ByteArray, count: Int) { frames += count / 4; Thread.sleep(2) }
        override fun finish() {}
        override fun interrupt() {}
        override fun close() {}
    }
    private fun playerTest(block: suspend (DesktopPlayer, CopyOnWriteArrayList<String>) -> Unit) = runBlocking {
        val dispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
        val scope = CoroutineScope(SupervisorJob() + dispatcher)
        val opened = CopyOnWriteArrayList<String>()
        val player = DesktopPlayer(scope, { _, source, _ ->
            opened.add(source)
            object : Decoder {
                override val pcm = ByteArrayInputStream(ByteArray(32768))
                override fun checkExit() {}
                override fun close() { pcm.close() }
            }
        }, { SinkStub() }, { _, _, _ -> Metadata.Info(null, null, 1000) })
        try { withTimeout(5000) { withContext(dispatcher) { block(player, opened) } } }
        finally {
            val closed = CompletableDeferred<Unit>()
            withContext(dispatcher) { player.close { closed.complete(Unit) } }
            withTimeout(5000) { closed.await() }; scope.cancel(); dispatcher.close()
        }
    }
    private val a = PlayerTrack("/a", "A", durationMs = 1000, artwork = byteArrayOf())
    private val b = PlayerTrack("/b", "B", durationMs = 1000, artwork = byteArrayOf())
    @Test fun repeatOneRestartsDecoderAndManualNextStillWorks() = playerTest { p, opened ->
        p.repeatMode = RepeatMode.ONE; p.play(a, listOf(a, b))
        while (opened.size < 3) delay(10)
        assertTrue(opened.all { it == a.source })
        p.adjacent(1)
        while (b.source !in opened) delay(10)
        assertEquals(b.id, p.state.value.track?.id)
    }
    @Test fun offStopsAtEndAndAllWraps() = playerTest { p, opened ->
        p.play(b, listOf(a, b))
        while (p.state.value.phase != PlaybackPhase.ENDED) delay(10)
        assertEquals(listOf(b.source), opened.toList())
        p.repeatMode = RepeatMode.ALL; p.play(b)
        while (a.source !in opened) delay(10)
        assertTrue(a.source in opened)
    }
    @Test fun queueEditKeepsCurrentIdentityAndRestoresWithoutAutoplay() = playerTest { p, opened ->
        p.restore(listOf(a, b), a.id, 500)
        assertEquals(PlaybackPhase.IDLE, p.state.value.phase); assertTrue(opened.isEmpty())
        assertEquals(500, p.progress.value.positionMs.toInt())
        p.move(b.id, -1); assertEquals(listOf(b, a), p.queue)
        assertEquals(a.id, p.state.value.track?.id)
        p.enqueue(b, true); assertEquals(listOf(a, b), p.queue)
        assertEquals(p.queue, p.queueState.value)
    }
    @Test fun shuffleOffDoesNotRepeatBeforeCompletingQueue() = playerTest { p, opened ->
        val c = a.copy(source = "/c", title = "C")
        p.shuffled = true; p.play(a, listOf(a, b, c))
        while (p.state.value.phase != PlaybackPhase.ENDED) delay(10)
        assertEquals(3, opened.size); assertEquals(3, opened.toSet().size)
    }
}
