package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.CatalogCollection
import app.ziziplayer.desktop.ui.DiscoveryArtwork
import app.ziziplayer.desktop.ui.discoveryGenres
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class DiscoveryArtworkTest {
    private fun album(id: Int) = CatalogCollection("$id", "album", "Album $id", artworkUrl = "https://example.org/$id.jpg")
    @Test fun genresHaveUniqueQueriesAndRealSearchInputs() {
        assertEquals(24, discoveryGenres.size)
        assertEquals(24, discoveryGenres.distinctBy { it.query }.size)
        assertTrue(discoveryGenres.all { it.query.length in 2..300 && it.title.isNotBlank() })
    }
    @Test fun resultsAreRealDeduplicatedAlbumsWithArtwork() = runBlocking {
        val cache = DiscoveryArtwork(lookup = { listOf(album(1), album(1), album(2), album(3), CatalogCollection("4", "artist", "Artist")) })
        assertEquals(listOf(album(1), album(2)), cache.albums("phonk"))
        assertEquals(0, cache.active)
    }
    @Test fun overlappingTilesCoalesceSameQuery() = runBlocking {
        var calls = 0
        val cache = DiscoveryArtwork(lookup = { calls++; delay(10); listOf(album(1)) })
        List(10) { async { cache.albums("PHONK") } }.awaitAll()
        assertEquals(1, calls)
    }
    @Test fun noMoreThanTwoAlbumRequestsAtOnce() = runBlocking {
        var inFlight = 0; var max = 0
        val cache = DiscoveryArtwork(lookup = {
            inFlight++; max = maxOf(max, inFlight)
            try { delay(10); listOf(album(1)) } finally { inFlight-- }
        })
        List(24) { async { cache.albums("genre-$it") } }.awaitAll()
        assertTrue(max <= 2); assertEquals(0, cache.active)
    }
    @Test fun refreshReallyInvalidatesCachedArtwork() = runBlocking {
        var calls = 0
        val cache = DiscoveryArtwork(lookup = { calls++; listOf(album(calls)) })
        assertEquals("1", cache.albums("phonk").first().id)
        assertEquals("1", cache.albums("phonk").first().id)
        cache.clear()
        assertEquals("2", cache.albums("phonk").first().id)
    }
    @Test fun failedCategoryHasBackoffAndDoesNotThrow() = runBlocking {
        var calls = 0; var clock = 0L
        val cache = DiscoveryArtwork(lookup = { calls++; throw IllegalStateException("offline") }, now = { clock })
        assertTrue(cache.albums("phonk").isEmpty()); cache.albums("phonk")
        assertEquals(1, calls)
        clock = 60_001; cache.albums("phonk"); assertEquals(2, calls)
    }
    @Test fun successfulCoversExpireAfterTenMinutes() = runBlocking {
        var clock = 0L; var calls = 0
        val cache = DiscoveryArtwork(lookup = { calls++; listOf(album(1)) }, now = { clock })
        cache.albums("phonk"); clock = 599_999; cache.albums("phonk"); assertEquals(1, calls)
        clock = 600_001; cache.albums("phonk"); assertEquals(2, calls)
    }
    @Test fun cancelledLookupIsNotCachedAsEmpty() = runBlocking {
        var cancel = true; var calls = 0
        val cache = DiscoveryArtwork(lookup = { calls++; if (cancel) throw CancellationException("left page"); listOf(album(1)) })
        try { cache.albums("phonk"); fail("Cancellation swallowed") } catch (_: CancellationException) { }
        cancel = false
        assertEquals(listOf(album(1)), cache.albums("phonk")); assertEquals(2, calls); assertEquals(0, cache.active)
    }
    @Test fun staleInFlightResponseDoesNotRepopulateAfterRefresh() = runBlocking {
        val started = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>(); var calls = 0
        val cache = DiscoveryArtwork(lookup = {
            calls++
            if (calls == 1) { started.complete(Unit); release.await() }
            listOf(album(calls))
        })
        val pending = async { cache.albums("phonk") }
        withTimeout(3000) { started.await() }
        cache.clear(); release.complete(Unit); pending.await()
        assertEquals("2", cache.albums("phonk").first().id)
    }
}
