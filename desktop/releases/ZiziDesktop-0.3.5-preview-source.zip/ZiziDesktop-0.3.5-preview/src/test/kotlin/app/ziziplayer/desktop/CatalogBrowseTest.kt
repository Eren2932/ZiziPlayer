package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import org.junit.Assert.*
import org.junit.Test

class CatalogBrowseTest {
    @Test fun collectionHasOwnHeroAndPagedTypedTracks() {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/catalog/browse/collection") { e ->
            val body = """{"contract":1,"src":"deezer","collection":{"id":"17","kind":"artist","title":"Artist","art":"https://example.org/artist.jpg"},"items":[{"id":"42","src":"deezer","title":"Track","artist":"Artist","art":"https://example.org/album.jpg"}],"total":80,"next_offset":50}""".toByteArray()
            e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }
        }
        server.start()
        try {
            val client = ZiziClient("http://127.0.0.1:${server.address.port}", "")
            val page = client.collection(CatalogCollection("17", "artist", "Artist"))
            assertEquals("https://example.org/artist.jpg", page.collection.artworkUrl)
            assertEquals("https://example.org/album.jpg", page.tracks.single().artworkUrl)
            assertEquals("zizi://dz/42", page.tracks.single().source)
            assertEquals(50, page.nextOffset); assertEquals(80, page.total)
            assertNull(page.tracks.single().durationMs)
            assertThrows(IllegalArgumentException::class.java) { client.collection(CatalogCollection("spotify:17", "artist", "Wrong")) }
        } finally { server.stop(0) }
    }
    @Test fun catalogDurationUsesSecondsAndRejectsInvalidBounds() {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/catalog/search") { e ->
            val body = """{"items":[{"id":"1","dur":98},{"id":"2","dur":0},{"id":"3","dur":-1},{"id":"4","dur":604801}]}""".toByteArray()
            e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }
        }
        server.start()
        try {
            val client = ZiziClient("http://127.0.0.1:${server.address.port}", "")
            val tracks = client.search("test")
            assertEquals(98000L, tracks.first().durationMs)
            assertTrue(tracks.drop(1).all { it.durationMs == null })
        } finally { server.stop(0) }
    }
    @Test fun sourceMismatchIsRejected() {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/catalog/browse") { e ->
            val body = """{"contract":1,"src":"spotify","items":[]}""".toByteArray()
            e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }
        }
        server.start()
        try {
            val client = ZiziClient("http://127.0.0.1:${server.address.port}", "")
            assertThrows(IllegalArgumentException::class.java) { client.browse("Artist", "artist") }
        } finally { server.stop(0) }
    }
}
