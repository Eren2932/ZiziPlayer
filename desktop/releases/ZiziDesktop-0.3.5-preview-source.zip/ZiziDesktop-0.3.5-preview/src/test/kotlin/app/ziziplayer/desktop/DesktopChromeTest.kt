package app.ziziplayer.desktop

import app.ziziplayer.desktop.ui.*
import androidx.compose.ui.graphics.Color
import app.ziziplayer.ui.SearchPresentation
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.pow

class DesktopChromeTest {
    @Test fun productionLayoutFitsSupportedWindowSizes() { DesktopLayoutChecks.main(emptyArray()) }
    private fun luminance(c: Color): Double {
        fun linear(v: Float): Double = if (v <= .04045f) v / 12.92 else ((v + .055) / 1.055).pow(2.4)
        return .2126 * linear(c.red) + .7152 * linear(c.green) + .0722 * linear(c.blue)
    }
    @Test fun headerToneMaintainsWhiteTextContrast() {
        for (r in 0..255 step 17) for (g in 0..255 step 17) for (b in 0..255 step 17) {
            val tone = collectionTone((255 shl 24) or (r shl 16) or (g shl 8) or b)
            val contrast = (luminance(Color(0xFFF6F7F8)) + .05) / (luminance(tone) + .05)
            assertTrue("Unreadable header for $r/$g/$b: $contrast", contrast >= 4.5)
        }
    }
    @Test fun absentCoverHasNeutralFallback() {
        val tone = collectionTone(null)
        assertEquals(tone.red, tone.green, .001f); assertEquals(tone.green, tone.blue, .001f)
    }
    @Test fun monochromeCoverDoesNotInventSaturatedHue() {
        for (v in 0..255 step 17) {
            val tone = collectionTone((255 shl 24) or (v shl 16) or (v shl 8) or v)
            assertTrue(kotlin.math.abs(tone.red - tone.green) < .002f)
            assertTrue(kotlin.math.abs(tone.green - tone.blue) < .002f)
        }
    }
    @Test fun completionsUseRealMetadataAndDeduplicate() {
        assertEquals(listOf("Montagem", "Montagem Live"), SearchPresentation.completions("mon", emptyList(),
            listOf("Montagem"), listOf("montagem", "Montagem Live", "Other")))
        assertTrue(SearchPresentation.completions("m", emptyList(), emptyList(), listOf("Montagem")).isEmpty())
    }
}
