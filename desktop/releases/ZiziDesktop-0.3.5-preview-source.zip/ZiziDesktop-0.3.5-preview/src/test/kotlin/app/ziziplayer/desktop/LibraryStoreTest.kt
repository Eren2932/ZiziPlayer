package app.ziziplayer.desktop

import app.ziziplayer.playback.dsp.*
import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class LibraryStoreTest {
    private val a = PlayerTrack("zizi://dz/17", "Музыка", "Исполнитель", artworkUrl = "https://example.org/art.jpg")
    @Test fun roundTripPreservesOrderFavoritesAndDsp() {
        val settings = DesktopSettings(artworkColor = false, grid = false, volume = .2f,
            repeat = RepeatMode.ONE, shuffle = true, trackDsp = mapOf(a.id to DspCodec.encode(DspConfig(enabled = true, bassDrive = .4f))))
        val expected = LibrarySnapshot(listOf(a), setOf(a.id), listOf(UserPlaylist("p", "Мой плейлист", listOf(a.id))),
            listOf("C:/Music"), listOf(a), a.id, 12000, settings)
        val actual = LibraryStore.decode(LibraryStore.encode(expected))
        assertEquals(expected, actual)
        assertEquals(.4f, DspCodec.decode(actual.settings.trackDsp[a.id]).bassDrive, .001f)
    }
    @Test fun interruptedWriteLeavesLastGoodBackupAndRecovers() {
        val dir = Files.createTempDirectory("zizi-library-test")
        val store = LibraryStore(dir)
        store.save(LibrarySnapshot(tracks = listOf(a)))
        store.save(LibrarySnapshot(tracks = listOf(a), favorites = setOf(a.id)))
        Files.writeString(dir.resolve("library-v1.json"), "broken")
        val fresh = LibraryStore(dir)
        assertEquals(listOf(a), fresh.load().tracks)
        assertTrue(fresh.recovered)
        fresh.save(LibrarySnapshot(tracks = listOf(a)))
        assertEquals(listOf(a), LibraryStore(dir).load().tracks)
    }
    @Test fun unknownVersionIsNeverReplacedWithOldBackup() {
        val dir = Files.createTempDirectory("zizi-new-schema")
        val store = LibraryStore(dir)
        store.save(LibrarySnapshot(tracks = listOf(a))); store.save(LibrarySnapshot())
        Files.writeString(dir.resolve("library-v1.json"), "{\"schema\":2}")
        val fresh = LibraryStore(dir); fresh.load()
        assertFalse(fresh.writable)
        assertThrows(IllegalStateException::class.java) { fresh.save(LibrarySnapshot()) }
        assertEquals("{\"schema\":2}", Files.readString(dir.resolve("library-v1.json")))
    }
    @Test fun brokenLibraryWithoutBackupIsReadOnly() {
        val dir = Files.createTempDirectory("zizi-broken")
        Files.writeString(dir.resolve("library-v1.json"), "bad")
        val store = LibraryStore(dir); store.load(); assertFalse(store.writable)
    }
    @Test fun artworkBytesAndResolvedDurationAreNotPersisted() {
        val text = LibraryStore.encode(LibrarySnapshot(tracks = listOf(a.copy(durationMs = 1234, artwork = ByteArray(100000)))))
        assertTrue(text.length < 2000)
        assertNull(LibraryStore.decode(text).tracks.single().durationMs)
    }
    @Test fun orphanPlaylistIdsArePrunedAndDuplicatesRemoved() {
        val state = LibrarySnapshot(tracks = listOf(a, a), favorites = setOf("missing"),
            playlists = listOf(UserPlaylist("p", "P", listOf("missing", a.id, a.id))))
        val actual = LibraryStore.decode(LibraryStore.encode(state))
        assertEquals(1, actual.tracks.size); assertTrue(actual.favorites.isEmpty())
        assertEquals(listOf(a.id), actual.playlists.single().trackIds)
    }
    @Test fun offlinePathsCannotEscapeOwnedDirectory() {
        val dir = Files.createTempDirectory("zizi-offline")
        val files = OfflineFiles(dir)
        for (id in listOf("../../etc/passwd", "zizi://dz/17", "C:/Music/test.mp3")) {
            val path = files.path(id)
            assertEquals(dir, path.parent)
            assertTrue(path.fileName.toString().matches(Regex("[0-9a-f]{64}\\.audio")))
        }
        Files.write(files.path(a.id), byteArrayOf(1, 2, 3))
        assertEquals(1 to 3L, files.statistics()); files.remove(a.id); assertNull(files.existing(a.id))
    }
}
