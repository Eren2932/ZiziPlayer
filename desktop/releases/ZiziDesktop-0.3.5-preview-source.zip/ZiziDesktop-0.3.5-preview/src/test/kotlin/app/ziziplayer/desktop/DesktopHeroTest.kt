package app.ziziplayer.desktop

import app.ziziplayer.desktop.ui.*
import java.awt.Color
import java.awt.image.BufferedImage
import org.junit.Assert.*
import org.junit.Test

class DesktopHeroTest {
    @Test fun scrollHasExactEndpoints() {
        assertEquals(1f, HeroMotion.visibility(0f, 420f), 0f)
        assertEquals(0f, HeroMotion.visibility(420f, 420f), 0f)
        assertEquals(0f, HeroMotion.visibility(10000f, 420f), 0f)
    }
    @Test fun negativeAndEmptyInputsAreBounded() {
        assertEquals(1f, HeroMotion.visibility(-10f, 420f), 0f)
        for (h in listOf(0f, -1f, 1f, 252f, 340f, 420f)) for (s in 0..1000) {
            val value = HeroMotion.visibility(s.toFloat(), h)
            assertTrue(value.isFinite() && value in 0f..1f)
        }
    }
    @Test fun fadeIsMonotonicForEverySupportedHeight() {
        for (h in listOf(252f, 316f, 340f, 420f)) {
            var previous = 1f
            for (s in 0..1000) {
                val value = HeroMotion.visibility(s.toFloat(), h)
                assertTrue(value <= previous)
                assertTrue(previous - value < .007f)
                previous = value
            }
        }
    }
    @Test fun reverseScrollRetracesSameCurveWithoutHysteresis() {
        val forward = (0..420).map { HeroMotion.visibility(it.toFloat(), 420f) }
        val backward = (420 downTo 0).map { HeroMotion.visibility(it.toFloat(), 420f) }.reversed()
        assertEquals(forward, backward)
    }
    @Test fun lazyHeaderDisposalCannotDropAVisibleTail() {
        for (h in listOf(252f, 316f, 340f, 420f)) {
            // First item includes at least hero plus actions; by its disposal alpha is already 0.
            assertEquals(0f, HeroMotion.visibility(h + 104f, h), 0f)
            assertEquals(0f, HeroMotion.visibility(h + 244f, h), 0f)
        }
    }
    @Test fun parallaxMovesSlowerThanText() {
        assertEquals(-28f, HeroMotion.travel(100f, true), .001f)
        assertEquals(-100f, HeroMotion.travel(100f, false), .001f)
        assertEquals(0f, HeroMotion.travel(-10f, true), 0f)
    }
    @Test fun motionHasGentleEndpoints() {
        assertTrue(HeroMotion.smooth(.001f) < .00001f)
        assertTrue(1f - HeroMotion.smooth(.999f) < .00001f)
    }
    @Test fun defaultsUsePanoramaAndBlackCaption() {
        val p = DesktopAppearance()
        assertTrue(p.panoramicArtists); assertTrue(p.motion); assertFalse(p.nativeFrame)
        assertTrue(p.copy(nativeFrame = true).nativeFrame)
        assertFalse(p.copy(motion = false).motion)
    }
    private fun solid(w: Int, h: Int, color: Color): BufferedImage {
        val image = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
        val g = image.createGraphics()
        try { g.color = color; g.fillRect(0, 0, w, h) } finally { g.dispose() }
        return image
    }
    @Test fun realWidePhotoIsNotRecomposed() {
        val wide = solid(1440, 560, Color.BLUE)
        assertSame(wide, prepareHeroArtwork(wide))
    }
    @Test fun squarePortraitBecomesOpaquePanorama() {
        val result = prepareHeroArtwork(solid(1000, 1000, Color.RED))
        assertEquals(1440, result.width); assertEquals(560, result.height)
        assertFalse(result.colorModel.hasAlpha())
        assertEquals(Color.RED.rgb, result.getRGB(893, 280))
    }
    @Test fun tinySourceDoesNotFillEntireHeaderWithUpscaledPixels() {
        val result = prepareHeroArtwork(solid(64, 64, Color.RED))
        assertEquals(Color.RED.rgb, result.getRGB(893, 280))
        assertNotEquals(Color.RED.rgb, result.getRGB(893, 120))
        assertNotEquals(Color.RED.rgb, result.getRGB(80, 280))
    }
    @Test fun preparationDoesNotMutateSource() {
        val source = solid(240, 320, Color.GREEN)
        val before = source.getRGB(0, 0, 240, 320, null, 0, 240)
        prepareHeroArtwork(source)
        assertArrayEquals(before, source.getRGB(0, 0, 240, 320, null, 0, 240))
    }
    @Test fun veryNarrowSourcesRemainValid() {
        for ((w, h) in listOf(1 to 1, 1 to 1000, 1000 to 1, 32 to 320)) {
            val result = prepareHeroArtwork(solid(w, h, Color.GRAY))
            assertTrue(result.width > 0 && result.height > 0)
        }
    }
}
