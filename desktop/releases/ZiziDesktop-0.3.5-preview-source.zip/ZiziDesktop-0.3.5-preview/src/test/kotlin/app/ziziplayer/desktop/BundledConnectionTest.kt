package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import com.sun.net.httpserver.HttpServer
import org.junit.Assert.*
import org.junit.Test
import java.net.InetSocketAddress
import java.net.URI
import java.util.Properties
import java.util.concurrent.atomic.AtomicInteger

class BundledConnectionTest {
    private fun props(url: String, allow: Boolean = false) = Properties().apply {
        setProperty("resolver.url", url); setProperty("resolver.bootstrap", "fixture-bootstrap")
        setProperty("resolver.allowHttp", allow.toString())
    }
    @Test fun bundledHttpsWorksWithoutCompatibilityFlag() {
        assertFalse(BundledConnection.from(props("https://example.org"))!!.usesHttp)
    }
    @Test fun mobileSchemelessOriginNeedsExplicitHttpOptIn() {
        assertThrows(IllegalArgumentException::class.java) { BundledConnection.from(props("example.org:8080")) }
        assertTrue(BundledConnection.from(props("example.org:8080", true))!!.usesHttp)
    }
    @Test fun httpExceptionDoesNotExtendToOtherOrigins() {
        val trusted = URI("http://example.org:8080")
        assertEquals(trusted.resolve("/stream"), HttpTransport.safeUri("http://example.org:8080/stream", trusted))
        for (raw in listOf("http://other.org:8080/stream", "http://example.org:8081/stream", "http://user@example.org:8080", "file:///tmp/a")) {
            assertThrows(IllegalArgumentException::class.java) { HttpTransport.safeUri(raw, trusted) }
        }
        assertThrows(IllegalArgumentException::class.java) { HttpTransport.safeUri("http://example.org:8080/stream") }
    }
    @Test fun bundledConfigRejectsCredentialsQueryAndFragment() {
        for (url in listOf("https://user:pass@example.org", "https://example.org?a=b", "https://example.org#fragment", "https://example.org:70000"))
            assertThrows(IllegalArgumentException::class.java) { BundledConnection.from(props(url)) }
    }
    @Test fun missingConfigStaysOfflineAndDoesNotUseLegacyPreferences() {
        assertNull(BundledConnection.from(Properties()))
    }
    @Test fun cachedDeviceKeySurvivesClientRecreationWithoutBootstrapExchange() {
        val store = MemoryDeviceTokenStore()
        val now = System.currentTimeMillis()
        store.save(DeviceCredential("fixture-device", now + 86400000, now + 85800000))
        repeat(2) {
            val client = ZiziClient("https://example.org", "fixture-bootstrap", "install-fixture", tokenStore = store)
            assertEquals("Bearer fixture-device", client.headers()["Authorization"])
            assertEquals("install-fixture", client.headers()["X-Zizi-Install"])
        }
        assertFalse(store.load().toString().contains("fixture-device"))
    }
    @Test fun expiredCachedKeyIsReplacedAndPersisted() {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/auth/device") { e ->
            val response = """{"token":"fixture-new","expires_in":86400}""".toByteArray()
            e.sendResponseHeaders(200, response.size.toLong()); e.responseBody.use { it.write(response) }; e.close()
        }
        server.start()
        try {
            val store = MemoryDeviceTokenStore().apply { save(DeviceCredential("expired", 1, 1)) }
            val api = ZiziClient("http://127.0.0.1:${server.address.port}", "fixture-bootstrap", "install-fixture", tokenStore = store)
            assertEquals("Bearer fixture-new", api.headers()["Authorization"])
            assertEquals("fixture-new", store.load()!!.token)
            assertTrue(store.load()!!.expiresAt > System.currentTimeMillis())
        } finally { server.stop(0) }
    }
    @Test fun cached401PerformsOneRecoveryAndRetriesCatalog() {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val authCalls = AtomicInteger(); val searches = AtomicInteger()
        server.createContext("/auth/device") { e ->
            authCalls.incrementAndGet()
            val body = """{"token":"fixture-new","expires_in":86400}""".toByteArray()
            e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }; e.close()
        }
        server.createContext("/catalog/search") { e ->
            searches.incrementAndGet()
            if (e.requestHeaders.getFirst("Authorization") == "Bearer fixture-new") {
                val body = """{"items":[]}""".toByteArray()
                e.sendResponseHeaders(200, body.size.toLong()); e.responseBody.use { it.write(body) }
            } else e.sendResponseHeaders(401, -1)
            e.close()
        }
        server.start()
        try {
            val now = System.currentTimeMillis()
            val store = MemoryDeviceTokenStore().apply { save(DeviceCredential("revoked", now + 86400000, now + 85800000)) }
            val api = ZiziClient("http://127.0.0.1:${server.address.port}", "fixture-bootstrap", "install-fixture", tokenStore = store)
            assertTrue(api.search("track").isEmpty())
            assertEquals(1, authCalls.get()); assertEquals(2, searches.get())
        } finally { server.stop(0) }
    }
    @Test fun deviceCredentialIsNotPrintable() {
        assertFalse(DeviceCredential("fixture-sensitive", 1, 1).toString().contains("fixture-sensitive"))
    }
}
