package app.ziziplayer.ui.theme;

/**
 * Cover colour math without Android/Compose dependencies. Runs once per decoded thumbnail,
 * never in a draw callback. Keeping this core platform-free also permits real JVM regression
 * tests without decoding images or starting an emulator.
 */
public final class ArtworkColorMath {
    public static final int SAMPLE_SIDE = 64;
    public static final int SWATCH_VERSION = 2;
    private static final int BINS = 24;
    private static final int BOTTOM = 0xff111111;
    // Same positions as ZiziPalette.background: 0, .10, .28, .46, .64, .82, 1.
    private static final float[] RAMP = {1f, .98f, .88f, .65f, .38f, .16f, 0f};

    private ArtworkColorMath() {}

    /** ARGB samples of the visible square crop, at most 64 x 64. Null means no opaque art. */
    public static int[] extract(int[] pixels) {
        if (pixels == null || pixels.length == 0) return null;
        if (pixels.length > SAMPLE_SIDE * SAMPLE_SIDE) {
            throw new IllegalArgumentException("Artwork sample exceeds 64 x 64");
        }
        float[] weight = new float[BINS];
        float[] xs = new float[BINS];
        float[] ys = new float[BINS];
        float[] sats = new float[BINS];
        float[] vals = new float[BINS];
        float[] darkW = new float[BINS];
        float[] darkX = new float[BINS];
        float[] darkY = new float[BINS];
        float[] darkS = new float[BINS];
        float[] darkV = new float[BINS];
        float[] hsv = new float[3];
        int opaque = 0;
        int coloured = 0;
        float greyValue = 0f;
        for (int pixel : pixels) {
            // Transparent padding must not supply a hidden RGB hue.
            if ((pixel >>> 24) < 192) continue;
            toHsv(pixel, hsv);
            opaque++;
            greyValue += hsv[2];
            float s = hsv[1];
            float v = hsv[2];
            if (s < .12f || v < .08f || (v > .97f && s < .16f)) continue;
            coloured++;
            // Near-black regions can have high HSV saturation but little visible colour.
            // Let lit, colourful areas describe the cover instead of dark compression noise.
            float w = (.25f + .75f * s) * (.08f + v * v);
            int bin = Math.min(BINS - 1, (int) (hsv[0] / 360f * BINS));
            double rad = Math.toRadians(hsv[0]);
            float x = (float) Math.cos(rad) * w;
            float y = (float) Math.sin(rad) * w;
            weight[bin] += w;
            xs[bin] += x;
            ys[bin] += y;
            sats[bin] += s * w;
            vals[bin] += v * w;
            if (v < .48f) {
                darkW[bin] += w;
                darkX[bin] += x;
                darkY[bin] += y;
                darkS[bin] += s * w;
                darkV[bin] += v * w;
            }
        }
        if (opaque == 0) return null;
        // Do not let JPEG noise or a tiny coloured logo repaint a monochrome photograph.
        if (coloured < Math.max(1, (int) Math.ceil(opaque * .025f))) {
            int grey = fromHsv(0f, 0f, greyValue / opaque);
            return new int[] {grey, grey, grey};
        }
        int best = strongest(weight);
        float[] primary = merge(best, weight, xs, ys, sats, vals);
        int second = -1;
        float score = 0f;
        for (int i = 0; i < BINS; i++) {
            if (weight[i] <= 0f) continue;
            float[] candidate = merge(i, weight, xs, ys, sats, vals);
            float gap = Math.abs((candidate[0] - primary[0] + 540f) % 360f - 180f);
            float value = spread(i, weight);
            if (gap >= 45f && value > score) { second = i; score = value; }
        }
        int dark = strongest(darkW);
        int main = fromHsv(primary[0], primary[1], primary[2]);
        int secondary = second < 0 ? main : mergedColor(second, weight, xs, ys, sats, vals);
        int deep = dark < 0 ? fromHsv(primary[0], primary[1], primary[2] * .5f)
                : mergedColor(dark, darkW, darkX, darkY, darkS, darkV);
        // No synthetic hue rotation when a cover contains only one actual colour.
        return new int[] {main, secondary, deep};
    }

    private static int strongest(float[] weights) {
        int best = -1;
        float score = 0f;
        for (int i = 0; i < BINS; i++) {
            if (weights[i] > 0f && spread(i, weights) > score) {
                best = i;
                score = spread(i, weights);
            }
        }
        return best;
    }

    private static float spread(int i, float[] values) {
        return values[(i + BINS - 1) % BINS] + values[i] + values[(i + 1) % BINS];
    }

    private static float[] merge(int i, float[] w, float[] x, float[] y, float[] s, float[] v) {
        float weight = spread(i, w);
        float hue = (float) Math.toDegrees(Math.atan2(spread(i, y), spread(i, x)));
        if (hue < 0f) hue += 360f;
        return new float[] {hue, spread(i, s) / weight, spread(i, v) / weight};
    }

    private static int mergedColor(int i, float[] w, float[] x, float[] y, float[] s, float[] v) {
        float[] hsv = merge(i, w, x, y, s, v);
        return fromHsv(hsv[0], hsv[1], hsv[2]);
    }

    /**
     * Brightest at the top, neutral near-black at the bottom. Primary hue is NOT averaged
     * with secondary/deep: that would turn a red-and-blue cover purple, a colour not on it.
     * Scaling sRGB channels together preserves the source HSV hue/saturation. Luminance is
     * capped explicitly rather than crushing every hue under the old AMOLED Oklab ceiling.
     */
    public static int[] backdrop(int primary) {
        int top = coverTop(primary);
        int[] out = new int[RAMP.length];
        for (int i = 0; i < out.length; i++) out[i] = mix(BOTTOM, top, RAMP[i]);
        return out;
    }

    public static int coverTop(int primary) {
        float[] hsv = new float[3];
        toHsv(primary, hsv);
        float value = clamp(hsv[2] * .84f + .06f, .24f, .72f);
        int candidate = fromHsv(hsv[0], hsv[1], value);
        // A deep blue can be perceptually darker than neutral #111111 even with a
        // non-zero HSV value. Give dark artwork a visible floor without shifting hue.
        if (luminance(candidate) < .020) {
            float low = value;
            float high = 1f;
            for (int i = 0; i < 12; i++) {
                float mid = (low + high) * .5f;
                if (luminance(fromHsv(hsv[0], hsv[1], mid)) < .020) low = mid;
                else high = mid;
            }
            value = high;
            candidate = fromHsv(hsv[0], hsv[1], value);
        }
        // #E0E0E0 secondary text clears 4.5:1 even at the brightest stop.
        if (luminance(candidate) <= .125) return candidate;
        float low = 0f;
        float high = value;
        for (int i = 0; i < 12; i++) {
            float mid = (low + high) * .5f;
            if (luminance(fromHsv(hsv[0], hsv[1], mid)) <= .125) low = mid;
            else high = mid;
        }
        return fromHsv(hsv[0], hsv[1], low);
    }

    /** Opaque, selected-cover-specific card; no orange brand wash or previous-track colour. */
    public static int cardTop(int primary) { return mix(0xff181818, coverTop(primary), .58f); }
    public static int surface(int primary) { return mix(0xff121212, coverTop(primary), .16f); }
    public static int chip(int primary) { return mix(0xff1b1b1b, coverTop(primary), .24f); }

    public static int mix(int from, int to, float fraction) {
        float t = clamp(fraction, 0f, 1f);
        int r = Math.round(channel(from, 16) + (channel(to, 16) - channel(from, 16)) * t);
        int g = Math.round(channel(from, 8) + (channel(to, 8) - channel(from, 8)) * t);
        int b = Math.round(channel(from, 0) + (channel(to, 0) - channel(from, 0)) * t);
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }

    public static double luminance(int rgb) {
        return .2126 * linear(channel(rgb, 16) / 255.0)
                + .7152 * linear(channel(rgb, 8) / 255.0)
                + .0722 * linear(channel(rgb, 0) / 255.0);
    }

    private static double linear(double v) { return v <= .04045 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }
    private static int channel(int rgb, int shift) { return (rgb >>> shift) & 255; }
    private static float clamp(float v, float low, float high) { return Math.max(low, Math.min(high, v)); }

    private static void toHsv(int rgb, float[] out) {
        float r = channel(rgb, 16) / 255f;
        float g = channel(rgb, 8) / 255f;
        float b = channel(rgb, 0) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float delta = max - min;
        float hue = 0f;
        if (delta > 0f) {
            if (max == r) hue = ((g - b) / delta) % 6f;
            else if (max == g) hue = (b - r) / delta + 2f;
            else hue = (r - g) / delta + 4f;
            hue *= 60f;
            if (hue < 0f) hue += 360f;
        }
        out[0] = hue;
        out[1] = max == 0f ? 0f : delta / max;
        out[2] = max;
    }

    private static int fromHsv(float hue, float saturation, float value) {
        float h = ((hue % 360f) + 360f) % 360f / 60f;
        float s = clamp(saturation, 0f, 1f);
        float v = clamp(value, 0f, 1f);
        float c = v * s;
        float x = c * (1f - Math.abs(h % 2f - 1f));
        float m = v - c;
        float r = 0f, g = 0f, b = 0f;
        if (h < 1f) { r = c; g = x; }
        else if (h < 2f) { r = x; g = c; }
        else if (h < 3f) { g = c; b = x; }
        else if (h < 4f) { g = x; b = c; }
        else if (h < 5f) { r = x; b = c; }
        else { r = c; b = x; }
        return 0xff000000 | (Math.round((r + m) * 255f) << 16)
                | (Math.round((g + m) * 255f) << 8) | Math.round((b + m) * 255f);
    }
}
