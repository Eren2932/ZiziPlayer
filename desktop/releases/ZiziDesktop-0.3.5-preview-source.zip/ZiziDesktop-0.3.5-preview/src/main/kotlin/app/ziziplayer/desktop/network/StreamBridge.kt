package app.ziziplayer.desktop.network

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.io.Closeable
import java.net.InetSocketAddress
import java.net.HttpURLConnection
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** One progressive source per session. FFmpeg sees only an ephemeral loopback URL.
 * Range and HEAD are preserved; redirects and playlists are deliberately not supported.
 * This is not a proxy endpoint that accepts arbitrary destinations from callers.
 */
class StreamBridge(private val target: StreamTarget) : Closeable {
    private val connections = ConcurrentHashMap.newKeySet<HttpURLConnection>()
    private val executor = Executors.newFixedThreadPool(4) { r -> Thread(r, "zizi-stream-bridge").apply { isDaemon = true } }
    private val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 8)
    private val path = "/audio/${UUID.randomUUID()}"
    @Volatile private var closed = false
    val input: String get() = "http://127.0.0.1:${server.address.port}$path"
    init {
        HttpTransport.safeUri(target.uri.toString(), target.legacyOrigin)
        server.executor = executor
        server.createContext("/") { exchange -> serve(exchange) }
        server.start()
    }
    private fun serve(e: HttpExchange) {
        var c: HttpURLConnection? = null
        try {
            if (closed || e.requestURI.rawPath != path || e.requestURI.rawQuery != null) {
                e.sendResponseHeaders(404, -1); return
            }
            if (e.requestMethod !in setOf("GET", "HEAD")) { e.sendResponseHeaders(405, -1); return }
            val headers = target.headers().toMutableMap()
            e.requestHeaders.getFirst("Range")?.let {
                if (!it.matches(Regex("bytes=(?:[0-9]+-[0-9]*|-[0-9]+)"))) { e.sendResponseHeaders(400, -1); return }
                headers["Range"] = it
            }
            c = HttpTransport.open(target.uri, headers, e.requestMethod, target.legacyOrigin)
            connections.add(c)
            if (closed) return
            val code = c.responseCode
            if (code !in setOf(200, 206, 416)) { e.sendResponseHeaders(if (code in 400..599) code else 502, -1); return }
            val type = c.contentType.orEmpty().lowercase()
            if (type.contains("mpegurl") || type.contains("dash+xml")) { e.sendResponseHeaders(415, -1); return }
            for (key in listOf("Content-Type", "Content-Range", "Accept-Ranges")) {
                c.getHeaderField(key)?.let { e.responseHeaders.set(key, it) }
            }
            if (e.requestMethod == "HEAD" || code == 416) {
                if (e.requestMethod == "HEAD") c.getHeaderField("Content-Length")?.let { e.responseHeaders.set("Content-Length", it) }
                e.sendResponseHeaders(code, -1); return
            }
            val length = c.contentLengthLong
            e.sendResponseHeaders(code, if (length > 0) length else 0)
            c.inputStream.use { source -> e.responseBody.use { out -> source.copyTo(out, 32 * 1024) } }
        } catch (_: Exception) {
            // Raw exceptions can carry private URLs. Never log or forward them.
            runCatching { e.sendResponseHeaders(502, -1) }
        } finally {
            c?.let { connections.remove(it); it.disconnect() }; e.close()
        }
    }
    override fun close() {
        closed = true
        connections.forEach { it.disconnect() }
        server.stop(0); executor.shutdownNow()
    }
}
