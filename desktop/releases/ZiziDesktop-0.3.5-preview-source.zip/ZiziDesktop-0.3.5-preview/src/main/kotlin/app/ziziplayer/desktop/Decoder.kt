package app.ziziplayer.desktop

import java.io.Closeable
import java.io.InputStream
import java.net.URI
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

interface Decoder : Closeable {
    val pcm: InputStream
    fun checkExit()
}
class FfmpegDecoder(executable: String, input: String, startMs: Long = 0) : Decoder {
    private val process: Process
    private val stderrBytes = AtomicLong()
    private val stderrReader: Thread
    override val pcm: InputStream get() = process.inputStream
    init {
        // No shell concatenation or inherited stdin.
        process = ProcessBuilder(command(executable, input, startMs)).start()
        process.outputStream.close()
        // Never retain raw FFmpeg stderr: it may contain signed URLs/credentials.
        stderrReader = thread(name = "zizi-ffmpeg-stderr", isDaemon = true) {
            try {
                process.errorStream.use { stream ->
                    val buffer = ByteArray(4096)
                    while (true) {
                        val n = stream.read(buffer)
                        if (n < 0) break
                        stderrBytes.addAndGet(n.toLong())
                    }
                }
            } catch (_: Exception) { }
        }
    }
    override fun checkExit() {
        if (!process.waitFor(10, TimeUnit.SECONDS)) throw IllegalStateException("DECODER_EXIT_TIMEOUT")
        if (process.exitValue() != 0) throw IllegalStateException("DECODER_FAILED exit=${process.exitValue()} stderrBytes=${stderrBytes.get()}")
    }
    override fun close() {
        // Kill before closing the pipe, releasing a reader blocked in read().
        process.destroy()
        if (!process.waitFor(700, TimeUnit.MILLISECONDS)) {
            process.destroyForcibly(); process.waitFor(1500, TimeUnit.MILLISECONDS)
        }
        runCatching { process.inputStream.close() }
        runCatching { process.errorStream.close() }
        stderrReader.join(1500)
    }
    companion object {
        fun command(executable: String, input: String, startMs: Long = 0): List<String> {
            require(startMs >= 0) { "Invalid seek position" }
            require(executable.isNotBlank()) { "FFmpeg executable missing" }
            require(input.isNotBlank() && !input.contains('\r') && !input.contains('\n')) { "Invalid source" }
            val network = input.startsWith("http://", true) || input.startsWith("https://", true)
            val source: String
            if (network) {
                val uri = URI(input)
                require(!uri.host.isNullOrBlank() && uri.userInfo == null) { "HTTP source requires a host and no userinfo credentials" }
                source = input
            } else {
                val path = Path.of(input).toAbsolutePath().normalize()
                require(Files.isRegularFile(path)) { "Local input file does not exist" }
                source = path.toString()
            }
            return buildList {
                add(executable)
                addAll(listOf("-hide_banner", "-nostdin", "-loglevel", "error", "-threads", "1"))
                // Network media may not open local files. No automatic reconnect/replay.
                addAll(listOf("-protocol_whitelist", if (network) "http,https,tcp,tls,crypto" else "file,crypto"))
                if (network) {
                    addAll(listOf("-rw_timeout", "15000000"))
                    // Progressive audio only: do not allow playlists to open arbitrary URLs.
                    addAll(listOf("-format_whitelist", "mov,mp3,flac,ogg,wav,matroska,webm,aac"))
                }
                if (startMs > 0) addAll(listOf("-ss", java.math.BigDecimal.valueOf(startMs, 3).toPlainString()))
                addAll(listOf("-i", source, "-map", "0:a:0", "-vn", "-sn", "-dn",
                    "-ac", Pcm.CHANNELS.toString(), "-ar", Pcm.RATE.toString(),
                    "-c:a", "pcm_f32le", "-f", "f32le", "pipe:1"))
            }
        }
    }
}
