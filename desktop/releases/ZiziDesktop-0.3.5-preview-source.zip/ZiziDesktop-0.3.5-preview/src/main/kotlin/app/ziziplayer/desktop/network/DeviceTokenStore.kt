package app.ziziplayer.desktop.network

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.prefs.Preferences

// Deliberately not a data class: generated toString must not expose a bearer credential.
class DeviceCredential(val token: String, val expiresAt: Long, val renewAt: Long)
interface DeviceTokenStore {
    fun load(): DeviceCredential?
    fun save(value: DeviceCredential)
    fun clear()
}
class MemoryDeviceTokenStore : DeviceTokenStore {
    private var value: DeviceCredential? = null
    override fun load() = value
    override fun save(value: DeviceCredential) { this.value = value }
    override fun clear() { value = null }
}
/** Per-user Preferences, equivalent in scope to Android's private preferences, NOT a vault.
 * Windows stores these in HKCU. A process running as this user can read them.
 * Only short-lived device credentials are saved; no bootstrap/server secret is written here.
 */
class PreferencesDeviceTokenStore(base: String, installId: String, bootstrap: String) : DeviceTokenStore {
    private val key = MessageDigest.getInstance("SHA-256")
        .digest((base + "\n" + installId + "\n" + bootstrap).toByteArray(StandardCharsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    private val prefs = Preferences.userRoot().node("app/ziziplayer/desktop/device/$key")
    override fun load(): DeviceCredential? = runCatching {
        val token = prefs.get("token", "")
        val expires = prefs.getLong("expires", 0)
        val renew = prefs.getLong("renew", 0)
        if (token.isBlank() || token.length > 4096 || token.any { it.code < 32 || it.code > 126 } ||
            expires <= System.currentTimeMillis() || renew !in 1..expires) null
        else DeviceCredential(token, expires, renew)
    }.getOrNull()
    override fun save(value: DeviceCredential) {
        runCatching {
            prefs.put("token", value.token); prefs.putLong("expires", value.expiresAt)
            prefs.putLong("renew", value.renewAt); prefs.flush()
        }
    }
    override fun clear() { runCatching { prefs.clear(); prefs.flush() } }
}
