package app.ziziplayer.desktop.ui

import java.awt.AlphaComposite
import java.awt.Color
import java.awt.GradientPaint
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import kotlin.math.min
import kotlin.math.roundToInt

/** IO-only preparation. A small portrait is never cropped into an enormous face.
 * Wide sources stay wide; square/portrait sources get a soft photographic surround.
 * These are existing source pixels, not a fabricated artist banner or AI upscaling.
 */
internal fun prepareHeroArtwork(source: BufferedImage): BufferedImage {
    if (source.width.toFloat() / source.height >= 1.8f && source.width >= 1000) return source
    val width = 1440; val height = 560
    val result = BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
    val g = result.createGraphics()
    try {
        g.color = Color(16, 16, 16); g.fillRect(0, 0, width, height)
        // Strong low-pass background, prepared once, never blurred per animation frame.
        val tiny = BufferedImage(24, 10, BufferedImage.TYPE_INT_RGB)
        tiny.createGraphics().let { small ->
            try { small.drawImage(source, 0, 0, 24, 10, null) } finally { small.dispose() }
        }
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC)
        g.drawImage(tiny, 0, 0, width, height, null)
        g.color = Color(0, 0, 0, 65); g.fillRect(0, 0, width, height)
        // Fit the entire portrait, with a strict 1.25x enlargement ceiling.
        val scale = min(height.toDouble() / source.height, min(width * .60 / source.width, 1.25))
        val w = (source.width * scale).roundToInt().coerceAtLeast(1)
        val h = (source.height * scale).roundToInt().coerceAtLeast(1)
        val portrait = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)
        portrait.createGraphics().let { p ->
            try {
                p.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC)
                p.drawImage(source, 0, 0, w, h, null)
                p.composite = AlphaComposite.DstIn
                val fade = (w * .14f).coerceAtLeast(1f)
                p.paint = GradientPaint(0f, 0f, Color(0, 0, 0, 0), fade, 0f, Color.BLACK)
                p.fillRect(0, 0, fade.toInt() + 1, h)
                p.paint = GradientPaint(w - fade, 0f, Color.BLACK, w.toFloat(), 0f, Color(0, 0, 0, 0))
                p.fillRect((w - fade).toInt(), 0, fade.toInt() + 1, h)
                // Small sources also dissolve at the top/bottom, not a floating hard rectangle.
                if (h < height) {
                    val fy = (h * .12f).coerceAtLeast(1f)
                    p.paint = GradientPaint(0f, 0f, Color(0, 0, 0, 0), 0f, fy, Color.BLACK)
                    p.fillRect(0, 0, w, fy.toInt() + 1)
                    p.paint = GradientPaint(0f, h - fy, Color.BLACK, 0f, h.toFloat(), Color(0, 0, 0, 0))
                    p.fillRect(0, (h - fy).toInt(), w, fy.toInt() + 1)
                }
            } finally { p.dispose() }
        }
        g.drawImage(portrait, (width * .62 - w / 2.0).roundToInt(), (height - h) / 2, null)
    } finally { g.dispose() }
    return result
}
