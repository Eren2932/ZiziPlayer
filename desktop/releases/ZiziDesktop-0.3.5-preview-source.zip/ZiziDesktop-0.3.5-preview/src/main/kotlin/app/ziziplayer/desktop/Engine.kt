package app.ziziplayer.desktop

import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspEngine
import java.io.Closeable
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

object LabPresets {
    val names = listOf("off", "bass", "space", "underwater")
    fun config(name: String): DspConfig = when (name) {
        "off" -> DspConfig.NEUTRAL
        "bass" -> DspConfig(enabled = true, preampDb = -6f,
            bandsDb = listOf(3f, 4f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f), bassDrive = 0.15f)
        "space" -> DspConfig(enabled = true, preampDb = -5f,
            reverbMix = 0.22f, reverbSize = 0.6f, rotation = 0.28f, width = 0.2f)
        "underwater" -> DspConfig(enabled = true, preampDb = -3f, underwater = 0.8f)
        else -> throw IllegalArgumentException("Unknown lab preset; use off/bass/space/underwater")
    }.sanitized()
}
class Controls(preset: String, gain: Float) {
    val config = AtomicReference(LabPresets.config(preset))
    val gain = AtomicReference(gain.also { require(it.isFinite() && it in 0f..1f) })
    val stopped = AtomicBoolean()
    val paused = AtomicBoolean()
    private val pauseGate = Any()
    private var pauseOutput: ((Boolean) -> Unit)? = null
    fun pause(value: Boolean) = synchronized(pauseGate) {
        paused.set(value); pauseOutput?.invoke(value)
    }
    fun attachPause(output: ((Boolean) -> Unit)?) = synchronized(pauseGate) {
        pauseOutput = output; output?.invoke(paused.get())
    }
    @Volatile var wakeOutput: (() -> Unit)? = null
    fun stop() { stopped.set(true); wakeOutput?.invoke() }
}
data class Summary(
    val frames: Long, val sourceWaitEvents: Long, val deviceEmptyHints: Long,
    val clippedSamples: Long, val peak: Float, val maxDspMs: Double, val cancelled: Boolean
)
class Diagnostics(path: Path) : Closeable {
    private val out = Files.newBufferedWriter(path, Charsets.UTF_8, StandardOpenOption.CREATE_NEW)
    private val pending = ArrayBlockingQueue<String>(64)
    private val closing = AtomicBoolean()
    private val logError = AtomicReference<Exception?>(null)
    private val dropped = java.util.concurrent.atomic.AtomicLong()
    // Never perform file writes/flush on the audio thread.
    private val writer = thread(name = "zizi-diagnostics", isDaemon = true) {
        try {
            out.use { file ->
                file.write("elapsed_ms,frames,queued_ms,source_wait_events,device_empty_hints,clipped_samples,peak,max_dsp_ms,status\n")
                while (!closing.get() || pending.isNotEmpty()) {
                    val row = pending.poll(100, TimeUnit.MILLISECONDS) ?: continue
                    file.write(row); file.flush()
                }
            }
        } catch (e: Exception) { logError.set(e) }
    }
    fun write(elapsedMs: Long, s: Summary, queuedMs: Long, status: String) {
        val row = "$elapsedMs,${s.frames},$queuedMs,${s.sourceWaitEvents},${s.deviceEmptyHints},${s.clippedSamples},${s.peak},${s.maxDspMs},$status\n"
        if (!pending.offer(row)) dropped.incrementAndGet()
    }
    override fun close() {
        closing.set(true); writer.join(3000)
        if (writer.isAlive || logError.get() != null || dropped.get() > 0) {
            System.err.println("DIAGNOSTICS_INCOMPLETE: writerPending=${writer.isAlive}, droppedRows=${dropped.get()}, error=${logError.get()?.javaClass?.simpleName ?: "none"}")
        }
    }
}
class AudioEngine(private val controls: Controls, private val prefillMs: Int = 500) {
    private class Chunk { val data = ByteArray(Pcm.BLOCK_BYTES); var size = 0 }
    // About 2 seconds, bounded even if the decoder/file sink is very fast.
    private val capacity = 96
    fun play(decoder: Decoder, sink: Sink, maxSeconds: Double? = null, diagnostics: Diagnostics? = null): Summary {
        require(prefillMs in 0..1500)
        require(maxSeconds == null || (maxSeconds.isFinite() && maxSeconds > 0 && maxSeconds < 86_400))
        val ready = ArrayBlockingQueue<Chunk>(capacity)
        val free = ArrayBlockingQueue<Chunk>(capacity + 2)
        repeat(capacity + 2) { free.add(Chunk()) }
        val done = AtomicBoolean()
        val producerStop = AtomicBoolean()
        val failure = AtomicReference<Throwable?>(null)
        val producer = thread(name = "zizi-pcm-reader", isDaemon = true) {
            try {
                while (!producerStop.get() && !controls.stopped.get()) {
                    val c = free.poll(100, TimeUnit.MILLISECONDS) ?: continue
                    c.size = Pcm.readBlock(decoder.pcm, c.data)
                    if (c.size == 0) { free.offer(c); break }
                    while (!ready.offer(c, 100, TimeUnit.MILLISECONDS)) {
                        if (producerStop.get() || controls.stopped.get()) return@thread
                    }
                }
                if (!producerStop.get() && !controls.stopped.get()) decoder.checkExit()
            } catch (e: Exception) {
                if (!producerStop.get() && !controls.stopped.get()) failure.set(e)
            } finally { done.set(true) }
        }
        controls.wakeOutput = { sink.interrupt() }
        controls.attachPause(sink::pause)
        val dsp = DspEngine(Pcm.RATE, Pcm.CHANNELS)
        var previous: DspConfig? = null
        val samples = FloatArray(Pcm.BLOCK_FRAMES * Pcm.CHANNELS)
        val encoded = ByteArray(Pcm.BLOCK_FRAMES * Pcm.CHANNELS * 2)
        val quantizer = Quantizer()
        var frames = 0L; var waits = 0L; var emptyHints = 0L; var clips = 0L
        var peak = 0f; var maxDspNs = 0L
        var emptyEpisode = false; var waitEpisode = false
        val frameLimit = maxSeconds?.let { (it * Pcm.RATE).toLong().coerceAtLeast(1) }
        val start = System.nanoTime()
        var lastReport = start
        fun summary() = Summary(frames, waits, emptyHints, clips, peak, maxDspNs / 1_000_000.0, controls.stopped.get())
        fun report(status: String) {
            diagnostics?.write((System.nanoTime() - start) / 1_000_000, summary(),
                ready.size.toLong() * Pcm.BLOCK_FRAMES * 1000 / Pcm.RATE, status)
        }
        var hitLimit = false
        try {
            val prefillBlocks = ((prefillMs.toLong() * Pcm.RATE + Pcm.BLOCK_FRAMES * 1000 - 1) / (Pcm.BLOCK_FRAMES * 1000)).toInt()
            val deadline = start + TimeUnit.SECONDS.toNanos(45)
            while (ready.size < prefillBlocks && !done.get() && !controls.stopped.get()) {
                if (System.nanoTime() > deadline) throw IllegalStateException("STARTUP_TIMEOUT_45S")
                Thread.sleep(10)
            }
            if (!controls.stopped.get()) sink.start()
            while (!controls.stopped.get()) {
                while (controls.paused.get() && !controls.stopped.get()) Thread.sleep(10)
                if (controls.stopped.get()) break
                val c = ready.poll(100, TimeUnit.MILLISECONDS)
                if (c == null) {
                    if (done.get() && ready.isEmpty()) break
                    if (frames > 0 && !waitEpisode) { waits++; waitEpisode = true }
                    if (frames > 0 && sink.emptyHint() && !emptyEpisode) { emptyHints++; emptyEpisode = true }
                    if (System.nanoTime() - lastReport >= TimeUnit.SECONDS.toNanos(1)) { report("waiting"); lastReport = System.nanoTime() }
                    continue
                }
                try {
                    waitEpisode = false
                    var blockFrames = c.size / Pcm.FRAME_BYTES
                    if (frameLimit != null) blockFrames = minOf(blockFrames.toLong(), frameLimit - frames).toInt()
                    if (blockFrames <= 0) { hitLimit = true; break }
                    Pcm.decode(c.data, blockFrames * Pcm.FRAME_BYTES, samples)
                    val config = controls.config.get()
                    if (config !== previous) {
                        dsp.setConfig(config)
                        if (config.isNeutral) dsp.reset()
                        previous = config
                    }
                    if (!config.isNeutral) {
                        val t = System.nanoTime()
                        // Only this thread owns/mutates the original DspEngine.
                        dsp.process(samples, blockFrames)
                        maxDspNs = maxOf(maxDspNs, System.nanoTime() - t)
                    }
                    val converted = quantizer.encode(samples, blockFrames * Pcm.CHANNELS, controls.gain.get(), encoded)
                    clips += converted.clippedSamples; peak = maxOf(peak, converted.peak)
                    val emptyNow = frames > 0 && sink.emptyHint()
                    if (emptyNow && !emptyEpisode) emptyHints++
                    emptyEpisode = emptyNow
                    sink.write(encoded, converted.bytes)
                    frames += blockFrames
                    if (System.nanoTime() - lastReport >= TimeUnit.SECONDS.toNanos(1)) { report("playing"); lastReport = System.nanoTime() }
                    if (frameLimit != null && frames >= frameLimit) { hitLimit = true; break }
                } finally { free.offer(c) }
            }
            if (!hitLimit && !controls.stopped.get()) {
                failure.get()?.let { throw IllegalStateException("DECODER_READ_FAILED", it) }
                check(frames > 0) { "NO_AUDIO_FRAMES" }
            }
            if (!controls.stopped.get()) sink.finish()
            report(if (controls.stopped.get()) "cancelled" else "complete")
            return summary()
        } catch (e: Exception) {
            if (controls.stopped.get()) { report("cancelled"); return summary() }
            report("failed")
            throw e
        } finally {
            controls.attachPause(null)
            controls.wakeOutput = null
            producerStop.set(true)
            runCatching { decoder.close() }
            producer.interrupt(); producer.join(2500)
            sink.close()
        }
    }
}
