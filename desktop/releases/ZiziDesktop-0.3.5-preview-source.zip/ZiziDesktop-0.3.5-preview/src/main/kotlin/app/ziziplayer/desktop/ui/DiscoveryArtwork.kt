package app.ziziplayer.desktop.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.ziziplayer.desktop.network.CatalogCollection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import java.util.Locale

internal data class DiscoveryGenre(val title: String, val query: String, val color: Long)
internal val discoveryGenres = listOf(
    DiscoveryGenre("Фонк", "phonk", 0xFF85411D),
    DiscoveryGenre("Бразильский фанк", "brazilian funk", 0xFF8C2549),
    DiscoveryGenre("Замедленные", "slowed reverb", 0xFF583277),
    DiscoveryGenre("Ускоренные", "sped up", 0xFF225878),
    DiscoveryGenre("Русский рэп", "русский рэп", 0xFF82472B),
    DiscoveryGenre("Хип-хоп", "hip hop", 0xFF716121),
    DiscoveryGenre("Электроника", "electronic", 0xFF266557),
    DiscoveryGenre("Рок", "rock", 0xFF863940),
    DiscoveryGenre("Поп", "pop", 0xFF8C3268),
    DiscoveryGenre("Инди", "indie", 0xFF495A85),
    DiscoveryGenre("Техно", "techno", 0xFF594282),
    DiscoveryGenre("Хаус", "house", 0xFF207078),
    DiscoveryGenre("Драм-н-бейс", "drum and bass", 0xFF645C2A),
    DiscoveryGenre("Трэп", "trap", 0xFF653F65),
    DiscoveryGenre("R&B и соул", "rnb soul", 0xFF79472F),
    DiscoveryGenre("Джаз", "jazz", 0xFF285C71),
    DiscoveryGenre("Lo-fi", "lofi", 0xFF5B5379),
    DiscoveryGenre("Эмбиент", "ambient", 0xFF3C6370),
    DiscoveryGenre("Для тренировки", "workout", 0xFF8B392C),
    DiscoveryGenre("Для концентрации", "focus", 0xFF426151),
    DiscoveryGenre("Классика", "classical", 0xFF735635),
    DiscoveryGenre("Саундтреки", "soundtrack", 0xFF495283),
    DiscoveryGenre("Метал", "metal", 0xFF633B47),
    DiscoveryGenre("K-pop", "k pop", 0xFF864569)
)

/** Real album search through the existing catalog, not a pretend recommendation endpoint.
 * At most two requests, visible lazy tiles only, bounded cache and error backoff.
 */
internal class DiscoveryArtwork(
    private val lookup: suspend (String) -> List<CatalogCollection>,
    private val now: () -> Long = System::currentTimeMillis
) {
    private data class Entry(val albums: List<CatalogCollection>, val expires: Long)
    private val lock = Any()
    private val cache = LinkedHashMap<String, Entry>(48, .75f, true)
    private val queryLocks = Array(16) { Mutex() }
    private val gate = Semaphore(2)
    private var generation = 0L
    var active by mutableStateOf(0); private set
    fun clear() = synchronized(lock) { generation++; cache.clear() }
    private fun cached(query: String): List<CatalogCollection>? = synchronized(lock) {
        cache[query]?.takeIf { it.expires > now() }?.albums
    }
    suspend fun albums(raw: String): List<CatalogCollection> {
        val query = raw.trim().lowercase(Locale.ROOT)
        require(query.length in 2..300)
        cached(query)?.let { return it }
        return queryLocks[(query.hashCode() and Int.MAX_VALUE) % queryLocks.size].withLock {
            cached(query)?.let { return@withLock it }
            gate.withPermit {
                val token = synchronized(lock) { generation }
                active++
                try {
                    val found = try {
                        lookup(query).filter { it.kind == "album" && !it.artworkUrl.isNullOrBlank() }.distinctBy { it.key }.take(2)
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) { emptyList() }
                    currentCoroutineContext().ensureActive()
                    synchronized(lock) {
                        if (token == generation) {
                            cache[query] = Entry(found, now() + if (found.isEmpty()) 60_000L else 600_000L)
                            while (cache.size > 48) { val i = cache.entries.iterator(); i.next(); i.remove() }
                        }
                    }
                    found
                } finally { active-- }
            }
        }
    }
}
