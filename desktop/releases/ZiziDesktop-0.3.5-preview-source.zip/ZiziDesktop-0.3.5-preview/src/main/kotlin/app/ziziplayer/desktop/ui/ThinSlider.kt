package app.ziziplayer.desktop.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp

/** 4dp paint, 24dp hit area. No Material track gap, vertical thumb or minimum component size.
 * A cancelled pointer sequence NEVER commits. Identity changes cancel the old seek gesture.
 */
@Composable internal fun ThinSlider(
    value: Float, onValueChange: (Float) -> Unit, onCommit: (Float) -> Unit,
    modifier: Modifier = Modifier, enabled: Boolean = true, label: String,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f, gestureKey: Any? = Unit,
    keyboardStep: Float = (valueRange.endInclusive - valueRange.start) / 100f,
    onCancel: () -> Unit = {}
) {
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var focused by remember { mutableStateOf(false) }
    var dragging by remember(gestureKey) { mutableStateOf(false) }
    val liveGestureKey by rememberUpdatedState(gestureKey)
    val change by rememberUpdatedState(onValueChange)
    val commit by rememberUpdatedState(onCommit)
    val cancel by rememberUpdatedState(onCancel)
    val current by rememberUpdatedState(value.coerceIn(valueRange))
    val range by rememberUpdatedState(valueRange)
    val span = valueRange.endInclusive - valueRange.start
    val fraction = if (span > 0f) ((current - valueRange.start) / span).coerceIn(0f, 1f) else 0f
    val active = enabled && (hovered || focused || dragging)
    fun set(v: Float) { val bounded = v.coerceIn(valueRange); change(bounded); commit(bounded) }
    Canvas(modifier.height(24.dp).hoverable(interaction, enabled)
        .semantics {
            contentDescription = label
            progressBarRangeInfo = ProgressBarRangeInfo(current, valueRange)
            if (!enabled) disabled()
            setProgress { if (enabled) { set(it); true } else false }
        }
        .onPreviewKeyEvent {
            if (!enabled || it.type != KeyEventType.KeyDown) false else {
                val target = when (it.key) {
                    Key.DirectionLeft, Key.DirectionDown -> current - keyboardStep
                    Key.DirectionRight, Key.DirectionUp -> current + keyboardStep
                    Key.MoveHome -> valueRange.start
                    Key.MoveEnd -> valueRange.endInclusive
                    else -> null
                }
                if (target == null) false else { set(target); true }
            }
        }.onFocusChanged { focused = it.isFocused }.focusable(enabled, interaction)
        .pointerInput(enabled, gestureKey) {
            if (!enabled) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown()
                down.consume()
                dragging = true
                var committed = false
                fun at(x: Float): Float {
                    val inset = 5.dp.toPx()
                    val f = ((x - inset) / (size.width - 2 * inset).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    return range.start + f * (range.endInclusive - range.start)
                }
                try {
                    change(at(down.position.x))
                    while (true) {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (pointer.isConsumed) break
                        val v = at(pointer.position.x)
                        pointer.consume()
                        if (!pointer.pressed) {
                            if (liveGestureKey == gestureKey) { committed = true; commit(v) }
                            break
                        }
                        change(v)
                    }
                } finally {
                    dragging = false
                    if (!committed) cancel()
                }
            }
        }) {
        val inset = 5.dp.toPx()
        val start = Offset(inset, size.height / 2)
        val end = Offset((size.width - inset).coerceAtLeast(inset), start.y)
        val thumb = Offset(start.x + (end.x - start.x) * fraction, start.y)
        drawLine(Color(0xFF4D4D4D), start, end, 4.dp.toPx(), StrokeCap.Round)
        if (fraction > 0f) drawLine(if (!enabled) Color(0xFF777777) else if (active) Color(0xFFF97316) else Color(0xFFF6F7F8),
            start, thumb, 4.dp.toPx(), StrokeCap.Round)
        if (active) drawCircle(Color(0xFFF6F7F8), 5.dp.toPx(), thumb)
    }
}
