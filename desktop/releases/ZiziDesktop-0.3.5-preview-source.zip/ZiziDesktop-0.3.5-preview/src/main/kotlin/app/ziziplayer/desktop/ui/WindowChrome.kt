package app.ziziplayer.desktop.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/** No icon font dependency. Native close/Alt+F4 and caption close share the flush/shutdown path. */
@Composable internal fun WindowCaptionButton(label: String, glyph: Int, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    Box(Modifier.width(46.dp).fillMaxHeight()
        .background(if (hovered) { if (glyph == 3) Color(0xFFC42B1C) else Color(0xFF242424) } else Color.Black)
        .hoverable(interaction).semantics { contentDescription = label }
        .clickable(interactionSource = interaction, indication = null, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(12.dp)) {
            val ink = Color(0xFFF6F7F8); val stroke = 1.dp.toPx()
            when (glyph) {
                0 -> drawLine(ink, Offset(1.dp.toPx(), size.height / 2), Offset(size.width - 1.dp.toPx(), size.height / 2), stroke)
                1 -> drawRect(ink, Offset(stroke, stroke), Size(size.width - 2 * stroke, size.height - 2 * stroke), style = Stroke(stroke))
                2 -> {
                    drawRect(ink, Offset(3 * stroke, stroke), Size(size.width - 4 * stroke, size.height - 4 * stroke), style = Stroke(stroke))
                    drawRect(if (hovered) Color(0xFF242424) else Color.Black, Offset(stroke, 3 * stroke), Size(size.width - 4 * stroke, size.height - 4 * stroke))
                    drawRect(ink, Offset(stroke, 3 * stroke), Size(size.width - 4 * stroke, size.height - 4 * stroke), style = Stroke(stroke))
                }
                else -> {
                    drawLine(ink, Offset(stroke, stroke), Offset(size.width - stroke, size.height - stroke), stroke)
                    drawLine(ink, Offset(size.width - stroke, stroke), Offset(stroke, size.height - stroke), stroke)
                }
            }
        }
    }
}
