package app.ziziplayer.desktop

import java.util.concurrent.atomic.AtomicLong
import javax.sound.sampled.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

internal data class OutputDevice(val id: String, val name: String)
internal data class ActiveOutput(val name: String, val selectedId: String?, val token: Long)

/** Java Sound exposes playback mixers, NOT Bluetooth discovery or Spotify Connect.
 * Enumeration never opens lines. A route becomes active only after Sink construction succeeds.
 * Default/primary drivers may conceal the physical endpoint: never guess a headset name.
 */
internal class AudioOutputs {
    @Volatile var selectedId: String? = null; private set
    private val serial = AtomicLong()
    private val mutableActive = MutableStateFlow<ActiveOutput?>(null)
    val active = mutableActive.asStateFlow()
    private fun id(info: Mixer.Info): String = listOf(info.name, info.vendor, info.description, info.version).joinToString("|")
    private fun lineInfo() = DataLine.Info(SourceDataLine::class.java, AudioFormat(Pcm.RATE.toFloat(), 16, Pcm.CHANNELS, true, false))
    fun devices(): List<OutputDevice> = AudioSystem.getMixerInfo().mapNotNull { info ->
        runCatching { if (AudioSystem.getMixer(info).isLineSupported(lineInfo())) OutputDevice(id(info), info.name) else null }.getOrNull()
    }.distinctBy { it.id }
    fun select(device: OutputDevice?) { selectedId = device?.id }
    fun createSink(): Sink {
        val requested = selectedId
        var name = "Системное устройство по умолчанию"
        val sink = JavaSoundSink(160) { format ->
            val info = DataLine.Info(SourceDataLine::class.java, format)
            if (requested == null) AudioSystem.getLine(info) as SourceDataLine
            else {
                val mixerInfo = AudioSystem.getMixerInfo().firstOrNull { id(it) == requested }
                    ?: throw IllegalStateException("AUDIO_OUTPUT_DISCONNECTED")
                name = mixerInfo.name
                AudioSystem.getMixer(mixerInfo).getLine(info) as SourceDataLine
            }
        }
        val route = ActiveOutput(name, requested, serial.incrementAndGet())
        mutableActive.value = route
        return object : Sink by sink {
            override fun close() {
                try { sink.close() } finally { mutableActive.compareAndSet(route, null) }
            }
            override fun interrupt() { close() }
        }
    }
}
