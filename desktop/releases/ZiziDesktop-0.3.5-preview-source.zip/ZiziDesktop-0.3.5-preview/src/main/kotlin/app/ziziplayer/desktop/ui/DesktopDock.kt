package app.ziziplayer.desktop.ui

/** One target, no competing booleans and no outgoing queue replaced by DSP mid-exit.
 * Geometry changes atomically: animating constraints caused text reflow and grid oscillation.
 */
internal enum class DesktopDock {
    NONE, QUEUE, EFFECTS, DEVICES;
    fun toggle(panel: DesktopDock): DesktopDock = if (this == panel) NONE else panel
}
