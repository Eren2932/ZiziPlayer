package app.ziziplayer.desktop

import org.json.JSONObject
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.TimeUnit

object Metadata {
    data class Info(val title: String?, val artist: String?, val durationMs: Long?, val cover: ByteArray? = null)
    private fun probeExe(ffmpeg: String): String {
        val p = Path.of(ffmpeg)
        val name = if (p.fileName.toString().endsWith(".exe", true)) "ffprobe.exe" else "ffprobe"
        return p.parent?.resolve(name)?.toString() ?: name
    }
    private fun capture(command: List<String>, limit: Int): ByteArray {
        val output = Files.createTempFile("zizi-probe-", ".tmp")
        try {
            val process = ProcessBuilder(command).redirectError(ProcessBuilder.Redirect.DISCARD).redirectOutput(output.toFile()).start()
            try {
                check(process.waitFor(20, TimeUnit.SECONDS)) { "PROBE_TIMEOUT" }
                check(process.exitValue() == 0 && Files.size(output) <= limit) { "PROBE_FAILED" }
                return Files.readAllBytes(output)
            } finally {
                if (process.isAlive) { process.destroyForcibly(); process.waitFor(2, TimeUnit.SECONDS) }
            }
        } finally { Files.deleteIfExists(output) }
    }
    fun read(ffmpeg: String, input: String, local: Boolean): Info = read(ffmpeg, input, local, true)
    fun read(ffmpeg: String, input: String, local: Boolean, includeCover: Boolean): Info {
        val protocols = if (local) "file,crypto" else "http,tcp"
        val formats = listOf("-format_whitelist", "mov,mp3,flac,ogg,wav,matroska,webm,aac")
        val data = capture(listOf(probeExe(ffmpeg), "-v", "error", "-protocol_whitelist", protocols) + formats +
            listOf("-show_entries", "format=duration:format_tags=title,artist", "-of", "json", input), 512 * 1024)
        val format = JSONObject(String(data, Charsets.UTF_8)).optJSONObject("format") ?: JSONObject()
        val tags = format.optJSONObject("tags")
        val seconds = format.optString("duration").toDoubleOrNull()
        val duration = seconds?.takeIf { it.isFinite() && it > 0 && it < 86400 * 30 }?.let { (it * 1000).toLong() }
        val cover = if (local && includeCover) runCatching {
            capture(listOf(ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-protocol_whitelist", "file,crypto",
                "-i", input, "-map", "0:v:0", "-frames:v", "1", "-vf", "scale=480:480:force_original_aspect_ratio=decrease",
                "-c:v", "png", "-f", "image2pipe", "pipe:1"), 5 * 1024 * 1024)
        }.getOrNull() else null
        return Info(tags?.optString("title")?.takeIf { it.isNotBlank() }, tags?.optString("artist")?.takeIf { it.isNotBlank() }, duration, cover)
    }
}
