package app.ziziplayer.desktop.ui

import kotlinx.coroutines.CancellationException

/** Isolate a failing shelf, but never turn cancellation into a successful partial response. */
internal suspend fun <T> searchPart(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) { throw e }
catch (e: Exception) { Result.failure(e) }
