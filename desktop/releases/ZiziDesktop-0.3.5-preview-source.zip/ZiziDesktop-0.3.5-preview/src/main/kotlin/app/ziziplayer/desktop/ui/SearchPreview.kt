package app.ziziplayer.desktop.ui

import androidx.compose.runtime.*
import app.ziziplayer.desktop.PlayerTrack
import kotlinx.coroutines.*

/** Single UI-dispatcher owner. No history, submitted-search state, or disk writes. */
internal class SearchPreview(
    private val scope: CoroutineScope,
    private val lookup: suspend (String) -> List<PlayerTrack>?,
    private val errorMessage: (Exception) -> String,
    private val debounceMs: Long = 320
) {
    var tracks by mutableStateOf<List<PlayerTrack>>(emptyList()); private set
    var query by mutableStateOf(""); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf(""); private set
    private var job: Job? = null
    private var generation = 0L
    fun cancel() {
        generation++; job?.cancel(); job = null
        tracks = emptyList(); query = ""; loading = false; message = ""
    }
    fun request(raw: String) {
        cancel()
        val q = raw.trim().take(300); query = q
        if (q.length < 2) return
        val token = generation
        loading = true
        job = scope.launch {
            try {
                delay(debounceMs)
                val matches = lookup(q)
                ensureActive()
                if (token == generation) {
                    tracks = matches.orEmpty().distinctBy { it.id }.take(6)
                    if (matches == null) message = "Показаны совпадения из медиатеки"
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (token == generation) message = errorMessage(e) }
            finally { if (token == generation) loading = false }
        }
    }
}
