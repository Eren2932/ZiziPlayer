package app.ziziplayer.desktop

import java.io.Closeable
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.atomic.AtomicBoolean
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.DataLine
import javax.sound.sampled.SourceDataLine

interface Sink : Closeable {
    fun start()
    fun write(bytes: ByteArray, count: Int)
    fun finish()
    fun interrupt()
    fun emptyHint(): Boolean = false
    fun pause(value: Boolean) {}
    fun playedFrames(): Long = 0L
}
class JavaSoundSink(bufferMs: Int, lineProvider: (AudioFormat) -> SourceDataLine = { format ->
    AudioSystem.getLine(DataLine.Info(SourceDataLine::class.java, format)) as SourceDataLine
}) : Sink {
    private val closed = AtomicBoolean()
    private val line: SourceDataLine
    init {
        require(bufferMs in 80..2000)
        val format = AudioFormat(Pcm.RATE.toFloat(), 16, Pcm.CHANNELS, true, false)
        line = lineProvider(format)
        try { line.open(format, Pcm.RATE * Pcm.CHANNELS * 2 * bufferMs / 1000) }
        catch (e: Exception) { line.close(); throw e }
    }
    private val gate = Any()
    @Volatile private var paused = false
    private var started = false
    private var submittedFrames = 0L
    private val observedFrames = java.util.concurrent.atomic.AtomicLong()
    override fun start() = synchronized(gate) {
        if (!closed.get()) { started = true; if (!paused) line.start() }
    }
    override fun pause(value: Boolean) = synchronized(gate) {
        paused = value
        if (!closed.get()) {
            if (value) line.stop() else if (started) line.start()
        }
    }
    override fun playedFrames(): Long = observedFrames.accumulateAndGet(line.longFramePosition.coerceAtLeast(0), ::maxOf)
    override fun write(bytes: ByteArray, count: Int) {
        var position = 0
        while (position < count && !closed.get()) {
            val written = synchronized(gate) {
                if (paused || closed.get()) 0 else {
                    // Never block in line.write while holding the pause lock.
                    val available = minOf(count - position, line.available()) / 4 * 4
                    if (available > 0) line.write(bytes, position, available) else 0
                }
            }
            if (written > 0) { position += written; submittedFrames += written / 4 }
            else Thread.sleep(5)
        }
        if (position < count) throw IllegalStateException("AUDIO_OUTPUT_CLOSED")
    }
    override fun emptyHint(): Boolean = !closed.get() && !paused && line.available() >= line.bufferSize
    override fun finish() {
        // drain() can hang on a stopped line; this remains pause/stop responsive at EOF.
        while (!closed.get() && playedFrames() < submittedFrames) Thread.sleep(5)
    }
    override fun interrupt() { close() }
    override fun close() = synchronized(gate) {
        if (closed.compareAndSet(false, true)) {
            playedFrames()
            runCatching { line.stop() }; runCatching { line.flush() }; line.close()
        }
    }
}
class WavSink(path: Path) : Sink {
    private val file: RandomAccessFile
    private var dataSize = 0L
    private var closed = false
    init {
        // CREATE_NEW: never overwrite a user's file, even after a race.
        Files.createFile(path)
        file = RandomAccessFile(path.toFile(), "rw")
        file.write(ByteArray(44))
    }
    override fun start() { }
    override fun write(bytes: ByteArray, count: Int) {
        require(count % 4 == 0)
        check(dataSize + count <= 0xffffffffL - 36) { "WAV_TOO_LARGE: classic RIFF limit" }
        file.write(bytes, 0, count); dataSize += count
    }
    override fun finish() { }
    override fun interrupt() { } // Owner closes; no device wait to interrupt.
    override fun close() {
        if (closed) return
        closed = true
        try {
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray(Charsets.US_ASCII)).putInt((dataSize + 36).toInt())
            header.put("WAVEfmt ".toByteArray(Charsets.US_ASCII)).putInt(16)
            header.putShort(1.toShort()).putShort(Pcm.CHANNELS.toShort())
            header.putInt(Pcm.RATE).putInt(Pcm.RATE * 4).putShort(4.toShort()).putShort(16.toShort())
            header.put("data".toByteArray(Charsets.US_ASCII)).putInt(dataSize.toInt())
            file.seek(0); file.write(header.array())
        } finally { file.close() }
    }
}
