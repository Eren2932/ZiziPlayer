package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import kotlinx.coroutines.*
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.security.MessageDigest
import java.io.FileOutputStream

/** Only our hashed files can be deleted. Partial downloads never become playable. */
class OfflineFiles(val directory: Path) {
    fun path(id: String): Path {
        val name = MessageDigest.getInstance("SHA-256").digest(id.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        return directory.resolve("$name.audio")
    }
    fun existing(id: String): String? = path(id).takeIf { Files.isRegularFile(it) && Files.size(it) > 0 }?.toString()
    fun remove(id: String) { Files.deleteIfExists(path(id)) }
    fun statistics(): Pair<Int, Long> {
        if (!Files.isDirectory(directory)) return 0 to 0L
        var count = 0; var bytes = 0L
        Files.list(directory).use { files -> files.filter { it.fileName.toString().matches(Regex("[0-9a-f]{64}\\.audio")) }.forEach {
            if (Files.isRegularFile(it)) { count++; bytes += Files.size(it) }
        } }
        return count to bytes
    }
    suspend fun download(track: PlayerTrack, api: ZiziClient, ffmpeg: String, progress: (Long, Long?) -> Unit): String = withContext(Dispatchers.IO) {
        require(track.source.startsWith("zizi://"))
        Files.createDirectories(directory)
        val target = api.resolve(track.source)
        val tmp = Files.createTempFile(directory, ".download-", ".part")
        try {
            val connection = HttpTransport.open(target.uri, target.headers(), legacyOrigin = target.legacyOrigin)
            try {
                if (connection.responseCode != 200) throw NetworkFailure(connection.responseCode)
                val expected = connection.contentLengthLong.takeIf { it >= 0 }
                val cap = 2L * 1024 * 1024 * 1024
                require(expected == null || expected <= cap)
                var total = 0L; var lastReport = 0L
                connection.inputStream.use { input ->
                    FileOutputStream(tmp.toFile()).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val n = input.read(buffer); if (n < 0) break
                            total += n; require(total <= cap)
                            output.write(buffer, 0, n)
                            val now = System.currentTimeMillis()
                            if (now - lastReport >= 250) { progress(total, expected); lastReport = now }
                        }
                        output.fd.sync()
                    }
                }
                require(total > 0 && (expected == null || total == expected)) { "INCOMPLETE_DOWNLOAD" }
                // Reject error documents even if an upstream returned HTTP 200.
                require(Metadata.read(ffmpeg, tmp.toString(), true, false).durationMs != null) { "INVALID_AUDIO" }
                ensureActive()
                try { Files.move(tmp, path(track.id), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
                catch (_: AtomicMoveNotSupportedException) { Files.move(tmp, path(track.id), StandardCopyOption.REPLACE_EXISTING) }
                progress(total, total)
                path(track.id).toString()
            } finally { connection.disconnect() }
        } finally { Files.deleteIfExists(tmp) }
    }
}
