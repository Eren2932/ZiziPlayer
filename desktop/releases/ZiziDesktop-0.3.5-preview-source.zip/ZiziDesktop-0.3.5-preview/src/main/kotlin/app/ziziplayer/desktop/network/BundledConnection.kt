package app.ziziplayer.desktop.network

import java.net.URI
import java.util.Properties

/** Same RESOLVER_URL / RESOLVER_TOKEN inputs as Android. Not an unextractable secret. */
class BundledConnection private constructor(
    private val base: String,
    private val bootstrap: String,
    private val legacyOrigin: URI?
) {
    val usesHttp: Boolean get() = URI(base).scheme == "http"
    fun client(installId: String): ZiziClient = ZiziClient(base, bootstrap, installId, legacyOrigin,
        PreferencesDeviceTokenStore(base, installId, bootstrap))
    companion object {
        fun load(): BundledConnection? {
            val properties = Properties()
            BundledConnection::class.java.getResourceAsStream("/zizi-connection.properties")?.use {
                properties.load(it)
            } ?: return null
            return from(properties)
        }
        internal fun from(properties: Properties): BundledConnection? {
            val raw = properties.getProperty("resolver.url", "").trim().trimEnd('/')
            if (raw.isBlank()) return null
            // Android normalizes a schemeless address to HTTP. External HTTP still needs a
            // deliberate build-time compatibility opt-in, scoped to this origin only.
            val uri = URI(if (raw.contains("://")) raw else "http://$raw")
            val legacy = uri.takeIf { it.scheme == "http" && properties.getProperty("resolver.allowHttp") == "true" }
            HttpTransport.safeUri(uri.toString(), legacy)
            require(uri.rawQuery == null)
            val token = properties.getProperty("resolver.bootstrap", "").trim()
            require(token.isNotBlank() && token.length <= 4096 && token.all { it.code in 32..126 })
            return BundledConnection(uri.toString(), token, legacy)
        }
    }
}
