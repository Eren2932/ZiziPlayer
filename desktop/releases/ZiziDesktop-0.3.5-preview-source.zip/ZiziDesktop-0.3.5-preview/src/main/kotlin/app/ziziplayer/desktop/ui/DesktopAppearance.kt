package app.ziziplayer.desktop.ui

import java.util.prefs.Preferences

/** UI-only preferences: library schema, DSP and network configuration are untouched. */
internal data class DesktopAppearance(
    val motion: Boolean = true,
    val panoramicArtists: Boolean = true,
    val nativeFrame: Boolean = false
) {
    fun save() {
        val p = preferences()
        p.putBoolean("motion", motion)
        p.putBoolean("panoramicArtists", panoramicArtists)
        p.putBoolean("nativeFrame", nativeFrame)
        p.flush()
    }
    companion object {
        private fun preferences() = Preferences.userRoot().node("app/ziziplayer/desktop/appearance")
        fun load(): DesktopAppearance = runCatching {
            val p = preferences()
            DesktopAppearance(p.getBoolean("motion", true), p.getBoolean("panoramicArtists", true),
                p.getBoolean("nativeFrame", false))
        }.getOrDefault(DesktopAppearance())
    }
}

/** Pure deterministic scroll model: no timer, accumulated wheel delta or direction hysteresis. */
internal object HeroMotion {
    fun progress(scroll: Float, height: Float): Float = (scroll / height.coerceAtLeast(1f)).coerceIn(0f, 1f)
    fun smooth(value: Float): Float { val t = value.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    fun visibility(scroll: Float, height: Float): Float = 1f - smooth(progress(scroll, height))
    fun travel(scroll: Float, motion: Boolean): Float = -scroll.coerceAtLeast(0f) * (if (motion) .28f else 1f)
}
