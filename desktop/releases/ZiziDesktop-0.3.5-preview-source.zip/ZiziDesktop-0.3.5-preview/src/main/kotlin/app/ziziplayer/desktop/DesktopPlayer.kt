package app.ziziplayer.desktop

import app.ziziplayer.desktop.network.*
import app.ziziplayer.playback.dsp.DspConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.Closeable
import java.nio.file.Path
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import java.util.prefs.Preferences

/** Stable identity is never a resolved URL. Remote playback does not add to the library. */
data class PlayerTrack(val source: String, val title: String, val artist: String = "", val durationMs: Long? = null,
    val artworkUrl: String? = null, val artwork: ByteArray? = null, val artistId: String? = null) {
    val id: String get() = source
    override fun toString(): String = "PlayerTrack(redacted)"
}
enum class PlaybackPhase { IDLE, LOADING, PLAYING, PAUSED, ENDED, ERROR }
data class PlayerState(val track: PlayerTrack? = null, val phase: PlaybackPhase = PlaybackPhase.IDLE, val generation: Long = 0,
    val message: String = "Выбери музыку", val seekable: Boolean = false)
data class PlayerProgress(val trackId: String? = null, val generation: Long = 0, val positionMs: Long = 0, val durationMs: Long? = null)

/** Public commands run on the supplied UI scope. Blocking I/O and audio have separate owners.
 * The generation invalidates all late metadata, completion and progress events immediately.
 */
class DesktopPlayer(
    private val scope: CoroutineScope,
    private val decoderFactory: (String, String, Long) -> Decoder = { exe, input, offset -> FfmpegDecoder(exe, input, offset) },
    private val sinkFactory: () -> Sink = { JavaSoundSink(160) },
    private val metadataReader: (String, String, Boolean) -> Metadata.Info = Metadata::read
) {
    private val mutableState = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = mutableState.asStateFlow()
    private val mutableProgress = MutableStateFlow(PlayerProgress())
    val progress: StateFlow<PlayerProgress> = mutableProgress.asStateFlow()
    private val mutableMetadata = MutableStateFlow<Map<String, PlayerTrack>>(emptyMap())
    val metadata: StateFlow<Map<String, PlayerTrack>> = mutableMetadata.asStateFlow()
    private val mutableQueue = MutableStateFlow<List<PlayerTrack>>(emptyList())
    val queueState: StateFlow<List<PlayerTrack>> = mutableQueue.asStateFlow()
    var queue: List<PlayerTrack>
        get() = mutableQueue.value
        private set(value) { mutableQueue.value = value }
    var repeatMode = RepeatMode.OFF
    private val shuffleVisited = mutableSetOf<String>()
    private val playHistory = mutableListOf<String>()
    var shuffled = false
        set(value) {
            if (field != value) { shuffleVisited.clear(); state.value.track?.id?.let { shuffleVisited.add(it) } }
            field = value
        }
    var onQueueChanged: (() -> Unit)? = null
    var configForTrack: ((PlayerTrack) -> DspConfig)? = null
    private var resumePosition = 0L
    fun restore(tracks: List<PlayerTrack>, selected: String?, position: Long) {
        if (state.value.phase != PlaybackPhase.IDLE) return
        queue = tracks.distinctBy { it.id }
        val track = queue.find { it.id == selected } ?: queue.firstOrNull()
        resumePosition = position.coerceAtLeast(0)
        shuffleVisited.clear(); playHistory.clear()
        track?.id?.let { shuffleVisited.add(it); playHistory.add(it) }
        mutableState.value = PlayerState(track, message = "Готово к воспроизведению")
        mutableProgress.value = PlayerProgress(track?.id, 0, resumePosition, track?.durationMs)
    }
    fun enqueue(track: PlayerTrack, next: Boolean = false) {
        if (track.id == state.value.track?.id) return
        val list = queue.filterNot { it.id == track.id }.toMutableList()
        val index = list.indexOfFirst { it.id == state.value.track?.id }
        list.add(if (next && index >= 0) index + 1 else list.size, track)
        queue = list; onQueueChanged?.invoke()
    }
    fun move(id: String, delta: Int) {
        val list = queue.toMutableList(); val i = list.indexOfFirst { it.id == id }
        if (i < 0 || i + delta !in list.indices) return
        list.add(i + delta, list.removeAt(i)); queue = list; onQueueChanged?.invoke()
    }
    fun remove(id: String) {
        val i = queue.indexOfFirst { it.id == id }; if (i < 0) return
        val current = state.value.track?.id == id
        queue = queue.filterNot { it.id == id }; onQueueChanged?.invoke()
        if (current) {
            val replacement = queue.getOrNull(i) ?: queue.lastOrNull()
            if (replacement != null) {
                val paused = desiredPaused
                play(replacement); if (paused) togglePause()
            } else {
                stop()
                mutableState.value = mutableState.value.copy(track = null)
                mutableProgress.value = mutableProgress.value.copy(trackId = null, durationMs = null)
            }
            onQueueChanged?.invoke()
        }
    }
    var gain = 0.35f; private set
    var config = DspConfig.NEUTRAL; private set
    var ffmpeg = System.getenv("FFMPEG_PATH")?.takeIf { it.isNotBlank() } ?: if (System.getProperty("os.name").startsWith("Windows")) "ffmpeg.exe" else "ffmpeg"
    var client: ZiziClient? = null
    var localSource: ((String) -> String?)? = null
    private var generation = 0L
    private var desiredPaused = false
    private var handover: Job? = null
    private var worker: Job? = null
    private var controls: Controls? = null
    private var closed = false
    private val handoverLock = Mutex()
    private val currentSink = AtomicReference<Sink?>()
    private val currentDecoder = AtomicReference<Decoder?>()
    private val currentBridge = AtomicReference<StreamBridge?>()
    private var ticker: Job? = null

    fun volume(value: Float) { if (value.isFinite()) { gain = value.coerceIn(0f, 1f); controls?.gain?.set(gain) } }
    fun dsp(value: DspConfig) { config = value.sanitized(); controls?.config?.set(config) }
    fun play(track: PlayerTrack, tracks: List<PlayerTrack> = queue) {
        if (closed) return
        val nextQueue = if (tracks.any { it.id == track.id }) tracks.distinctBy { it.id } else listOf(track)
        if (nextQueue.map { it.id } != queue.map { it.id }) { shuffleVisited.clear(); playHistory.clear() }
        queue = nextQueue
        shuffleVisited.add(track.id)
        if (playHistory.lastOrNull() != track.id) { playHistory.add(track.id); if (playHistory.size > 1000) playHistory.removeAt(0) }
        resumePosition = 0
        launchTrack(mutableMetadata.value[track.id] ?: track, 0, false)
        onQueueChanged?.invoke()
    }
    fun adjacent(delta: Int) {
        val current = state.value.track?.id
        val i = queue.indexOfFirst { it.id == current }
        val next = if (shuffled && delta > 0) {
            var candidates = queue.filterNot { it.id in shuffleVisited || it.id == current }
            if (candidates.isEmpty() && repeatMode == RepeatMode.ALL) {
                shuffleVisited.clear(); current?.let { shuffleVisited.add(it) }
                candidates = queue.filterNot { it.id == current }
                if (candidates.isEmpty()) candidates = queue
            }
            candidates.randomOrNull()
        } else if (shuffled && delta < 0 && playHistory.size > 1) {
            playHistory.removeAt(playHistory.lastIndex)
            queue.find { it.id == playHistory.lastOrNull() }
        } else queue.getOrNull(if (i < 0) 0 else i + delta)
            ?: if (repeatMode == RepeatMode.ALL && queue.isNotEmpty())
                (if (delta > 0) queue.first() else queue.last()) else null
        next?.let { play(it) }
    }
    fun togglePause() {
        if (closed) return
        val s = state.value
        if (s.phase in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.ERROR)) {
            (s.track ?: queue.firstOrNull())?.let {
                val offset = resumePosition; resumePosition = 0
                if (offset > 0) launchTrack(it, offset, false) else play(it)
            }; return
        }
        desiredPaused = !desiredPaused
        controls?.pause(desiredPaused)
        mutableState.value = s.copy(phase = if (desiredPaused) PlaybackPhase.PAUSED else if (s.phase == PlaybackPhase.LOADING) PlaybackPhase.LOADING else PlaybackPhase.PLAYING,
            message = if (desiredPaused) "Пауза" else "Воспроизведение")
    }
    fun seek(positionMs: Long) {
        val s = state.value; val duration = s.track?.durationMs ?: return
        if (!s.seekable || closed) return
        launchTrack(s.track, positionMs.coerceIn(0, (duration - 1).coerceAtLeast(0)), desiredPaused)
    }
    private suspend fun releasePrevious() {
        // Resource handover must finish even when superseded by a newer command.
        withContext(NonCancellable + Dispatchers.IO) {
            controls?.stop()
            currentSink.getAndSet(null)?.let { runCatching { it.interrupt() } }
            currentDecoder.getAndSet(null)?.let { runCatching { it.close() } }
            currentBridge.getAndSet(null)?.let { runCatching { it.close() } }
            worker?.cancelAndJoin()
        }
        controls = null; worker = null
    }
    private fun launchTrack(original: PlayerTrack, offset: Long, paused: Boolean) {
        configForTrack?.invoke(original)?.let { dsp(it) }
        generation++; val ticket = generation
        desiredPaused = paused
        ticker?.cancel(); handover?.cancel()
        mutableState.value = PlayerState(original, PlaybackPhase.LOADING, ticket, "Открываем источник…", false)
        mutableProgress.value = PlayerProgress(original.id, ticket, offset, original.durationMs)
        handover = scope.launch {
            handoverLock.withLock {
                releasePrevious(); ensureActive()
                val control = Controls("off", gain).also { it.config.set(config); it.pause(desiredPaused) }
                controls = control
                val exe = ffmpeg; val api = client
                worker = scope.launch(Dispatchers.IO) {
                    var bridge: StreamBridge? = null
                    var decoder: Decoder? = null
                    var sink: Sink? = null
                    try {
                        val downloaded = localSource?.invoke(original.id)
                        val remote = original.source.startsWith("zizi://")
                        val network = downloaded == null && (remote || original.source.startsWith("https://") || original.source.startsWith("http://"))
                        val input = if (network) {
                            val target = runInterruptible {
                                if (remote) (api ?: error("SERVER_NOT_CONFIGURED")).resolve(original.source)
                                else StreamTarget(HttpTransport.safeUri(original.source)) { emptyMap() }
                            }
                            ensureActive()
                            StreamBridge(target).also { bridge = it; currentBridge.set(it) }.input
                        } else downloaded ?: original.source
                        var track = original
                        if (track.durationMs == null || (!network && track.artwork == null)) {
                            val info = try { runInterruptible { metadataReader(exe, input, !network) } }
                                catch (e: CancellationException) { throw e } catch (_: Exception) { null }
                            info?.let { track = track.copy(title = if (!network && !remote) it.title ?: track.title else track.title,
                                artist = if (!network && !remote) it.artist ?: track.artist else track.artist, durationMs = it.durationMs, artwork = it.cover ?: track.artwork) }
                        }
                        ensureActive()
                        decoder = decoderFactory(exe, input, offset).also { currentDecoder.set(it) }
                        ensureActive()
                        sink = sinkFactory().also { currentSink.set(it) }
                        val audioSink = sink
                        val resolvedTrack = track
                        scope.launch {
                            if (generation == ticket) {
                                if (!network) {
                                    val cache = LinkedHashMap(mutableMetadata.value)
                                    cache.remove(track.id); cache[track.id] = track
                                    while (cache.size > 64) cache.remove(cache.keys.first())
                                    mutableMetadata.value = cache
                                }
                                mutableState.value = PlayerState(resolvedTrack, if (desiredPaused) PlaybackPhase.PAUSED else PlaybackPhase.LOADING,
                                    ticket, if (desiredPaused) "Пауза" else "Буферизация…", track.durationMs != null)
                                ticker = scope.launch {
                                    while (generation == ticket && isActive) {
                                        val frames = audioSink.playedFrames()
                                        val position = (offset + frames * 1000 / Pcm.RATE).let { p -> track.durationMs?.let { p.coerceAtMost(it) } ?: p }
                                        mutableProgress.value = PlayerProgress(track.id, ticket, position, track.durationMs)
                                        if (frames > 0 && !desiredPaused && mutableState.value.phase == PlaybackPhase.LOADING)
                                            mutableState.value = mutableState.value.copy(phase = PlaybackPhase.PLAYING, message = "Воспроизведение")
                                        delay(100)
                                    }
                                }
                            }
                        }
                        val result = AudioEngine(control, 300).play(decoder, audioSink)
                        scope.launch {
                            if (generation == ticket) {
                                ticker?.cancel()
                                if (!result.cancelled) {
                                    val end = offset + result.frames * 1000 / Pcm.RATE
                                    mutableProgress.value = PlayerProgress(track.id, ticket, end, track.durationMs)
                                    mutableState.value = mutableState.value.copy(phase = PlaybackPhase.ENDED, message = "Трек завершён")
                                    val i = queue.indexOfFirst { it.id == track.id }
                                    if (i >= 0) { if (repeatMode == RepeatMode.ONE) play(track) else adjacent(1) }
                                }
                            }
                        }
                    } catch (_: CancellationException) { /* Superseded request, not a playback error. */ }
                    catch (e: Exception) {
                        scope.launch {
                            if (generation == ticket && !control.stopped.get()) {
                                ticker?.cancel()
                                val message = when {
                                    e is NetworkFailure -> when (e.code) {
                                        401 -> "Не удалось подтвердить доступ к каталогу"
                                        403 -> "Сервер отказал в доступе"
                                        429 -> "Квота сервера исчерпана. Повтори позже"
                                        else -> "Сервер ответил HTTP ${e.code}"
                                    }
                                    remoteMissing(original, api) -> "Каталог недоступен в этой сборке"
                                    else -> "Не удалось воспроизвести. Проверь источник, сеть, FFmpeg и аудиоустройство"
                                }
                                mutableState.value = mutableState.value.copy(phase = PlaybackPhase.ERROR, message = message, seekable = false)
                            }
                        }
                    } finally {
                        runCatching { sink?.close() }; runCatching { decoder?.close() }; runCatching { bridge?.close() }
                        sink?.let { currentSink.compareAndSet(it, null) }
                        decoder?.let { currentDecoder.compareAndSet(it, null) }
                        bridge?.let { currentBridge.compareAndSet(it, null) }
                    }
                }
            }
        }
    }
    private fun remoteMissing(track: PlayerTrack, api: ZiziClient?) = track.source.startsWith("zizi://") && api == null
    fun stop(after: (() -> Unit)? = null) {
        generation++; ticker?.cancel(); handover?.cancel(); desiredPaused = false; resumePosition = 0
        mutableState.value = state.value.copy(phase = PlaybackPhase.IDLE, generation = generation, message = "Остановлено", seekable = false)
        mutableProgress.value = PlayerProgress(state.value.track?.id, generation, 0, state.value.track?.durationMs)
        handover = scope.launch { handoverLock.withLock { releasePrevious() }; after?.invoke() }
    }
    fun close(after: () -> Unit) { closed = true; stop(after) }
}

/** Nonsecret platform preferences. Build bootstrap/device credentials have separate owners. */
object DesktopPreferences {
    private val prefs = Preferences.userRoot().node("app/ziziplayer/desktop")
    val installId: String = prefs.get("installId", "").ifBlank { UUID.randomUUID().toString().also { prefs.put("installId", it) } }
    // Legacy manual server preference is no longer consumed. Never migrate a user-edited
    // origin into the build configuration, otherwise bootstrap could reach the wrong host.
    var recentSearches: List<String>
        get() = runCatching {
            val data = org.json.JSONArray(prefs.get("recentSearches", "[]"))
            (0 until minOf(data.length(), 20)).map { data.getString(it).take(300) }
        }.getOrDefault(emptyList())
        set(value) {
            runCatching {
                val entries = value.take(20).map { it.take(300) }.toMutableList()
                while (org.json.JSONArray(entries).toString().length > 7000) entries.removeAt(entries.lastIndex)
                prefs.put("recentSearches", org.json.JSONArray(entries).toString())
            }
        }
    var ffmpeg: String get() = prefs.get("ffmpeg", ""); set(value) { prefs.put("ffmpeg", value) }
}
