package app.ziziplayer.desktop

import app.ziziplayer.playback.dsp.DspCodec
import app.ziziplayer.playback.dsp.DspConfig
import org.json.JSONArray
import org.json.JSONObject
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.io.FileOutputStream
import java.util.UUID

enum class RepeatMode { OFF, ALL, ONE }
enum class TrackSort { TITLE, ARTIST, RECENT, DURATION }
data class DesktopSettings(
    val artworkColor: Boolean = true, val grid: Boolean = true,
    val sort: TrackSort = TrackSort.TITLE, val volume: Float = .35f,
    val repeat: RepeatMode = RepeatMode.OFF, val shuffle: Boolean = false,
    val dspGlobal: Boolean = false, val globalDsp: String = "",
    val trackDsp: Map<String, String> = emptyMap()
)
data class UserPlaylist(val id: String = UUID.randomUUID().toString(), val title: String,
    val trackIds: List<String> = emptyList())
data class LibrarySnapshot(
    val tracks: List<PlayerTrack> = emptyList(), val favorites: Set<String> = emptySet(),
    val playlists: List<UserPlaylist> = emptyList(), val folders: List<String> = emptyList(),
    val queue: List<PlayerTrack> = emptyList(), val selected: String? = null, val positionMs: Long = 0,
    val settings: DesktopSettings = DesktopSettings()
)

/** One writer owns the file. Temp + fsync + atomic replacement; last good backup survives damage.
 * Credentials and artwork bytes never enter this file. Unknown schema is NOT silently overwritten.
 */
class UnsupportedLibraryVersion : IllegalArgumentException("UNSUPPORTED_LIBRARY_SCHEMA")
class LibraryStore(val directory: Path = defaultDirectory()) {
    private val file = directory.resolve("library-v1.json")
    private val backup = directory.resolve("library-v1.backup.json")
    var writable = true; private set
    var recovered = false; private set
    private fun read(path: Path): LibrarySnapshot {
        require(Files.size(path) <= 32L * 1024 * 1024)
        return decode(Files.readString(path))
    }
    fun load(): LibrarySnapshot {
        if (!Files.exists(file)) {
            if (!Files.exists(backup)) return LibrarySnapshot()
            try { return read(backup).also { recovered = true } }
            catch (_: Exception) { writable = false; return LibrarySnapshot() }
        }
        try { return read(file) }
        catch (_: UnsupportedLibraryVersion) { writable = false; return LibrarySnapshot() }
        catch (_: Exception) {
            try { return read(backup).also { recovered = true } }
            catch (_: Exception) { writable = false; return LibrarySnapshot() }
        }
    }
    @Synchronized fun save(snapshot: LibrarySnapshot) {
        check(writable) { "LIBRARY_READ_ONLY" }
        Files.createDirectories(directory)
        val tmp = Files.createTempFile(directory, "library-", ".tmp")
        try {
            val bytes = encode(snapshot).toByteArray(Charsets.UTF_8)
            require(bytes.size <= 32 * 1024 * 1024) { "LIBRARY_TOO_LARGE" }
            FileOutputStream(tmp.toFile()).use { it.write(bytes); it.fd.sync() }
            if (Files.exists(file) && !recovered) {
                // Do not replace a valid backup with a damaged current file.
                read(file)
                Files.copy(file, backup, StandardCopyOption.REPLACE_EXISTING)
            }
            try { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
            catch (_: AtomicMoveNotSupportedException) { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING) }
            recovered = false
        } finally { Files.deleteIfExists(tmp) }
    }
    companion object {
        fun defaultDirectory(): Path {
            val windows = System.getProperty("os.name").startsWith("Windows")
            val base = if (windows) System.getenv("LOCALAPPDATA") else System.getenv("XDG_DATA_HOME")
            return if (!base.isNullOrBlank()) Path.of(base, "ZiziPlayer")
            else Path.of(System.getProperty("user.home"), if (windows) "AppData/Local/ZiziPlayer" else ".local/share/ZiziPlayer")
        }
        private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList()
            else (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
        private fun track(t: PlayerTrack) = JSONObject().put("source", t.source).put("title", t.title)
            .put("artist", t.artist).put("art", t.artworkUrl).put("artistId", t.artistId)
            .put("duration", if (t.source.startsWith("zizi://")) null else t.durationMs)
        private fun tracks(a: JSONArray?): List<PlayerTrack> = if (a == null) emptyList() else
            (0 until a.length()).map { i ->
                val t = a.getJSONObject(i)
                PlayerTrack(t.getString("source"), t.getString("title"), t.optString("artist"),
                    t.optLong("duration").takeIf { it > 0 },
                    t.optString("art").takeIf { it.isNotBlank() && it != "null" },
                    artistId = t.optString("artistId").takeIf { it.matches(Regex("[0-9]{1,20}")) })
            }.distinctBy { it.id }
        fun encode(s: LibrarySnapshot): String {
            val v = s.settings
            val prefs = JSONObject().put("artworkColor", v.artworkColor).put("grid", v.grid)
                .put("sort", v.sort.name).put("volume", v.volume.toDouble()).put("repeat", v.repeat.name)
                .put("shuffle", v.shuffle).put("dspGlobal", v.dspGlobal).put("globalDsp", v.globalDsp)
                .put("trackDsp", JSONObject(v.trackDsp))
            return JSONObject().put("schema", 1).put("tracks", JSONArray(s.tracks.map(::track)))
                .put("favorites", JSONArray(s.favorites.toList())).put("folders", JSONArray(s.folders))
                .put("playlists", JSONArray(s.playlists.map { JSONObject().put("id", it.id).put("title", it.title)
                    .put("tracks", JSONArray(it.trackIds)) }))
                .put("queue", JSONArray(s.queue.map(::track))).put("selected", s.selected)
                .put("positionMs", s.positionMs).put("settings", prefs).toString(2)
        }
        fun decode(raw: String): LibrarySnapshot {
            require(raw.length <= 32 * 1024 * 1024)
            val j = JSONObject(raw); if (j.getInt("schema") != 1) throw UnsupportedLibraryVersion()
            val v = j.optJSONObject("settings") ?: JSONObject()
            val d = v.optJSONObject("trackDsp") ?: JSONObject()
            val prefs = DesktopSettings(v.optBoolean("artworkColor", true), v.optBoolean("grid", true),
                runCatching { TrackSort.valueOf(v.optString("sort")) }.getOrDefault(TrackSort.TITLE),
                v.optDouble("volume", .35).toFloat().let { if (it.isFinite()) it.coerceIn(0f, 1f) else .35f },
                runCatching { RepeatMode.valueOf(v.optString("repeat")) }.getOrDefault(RepeatMode.OFF),
                v.optBoolean("shuffle"), v.optBoolean("dspGlobal"), v.optString("globalDsp"),
                d.keys().asSequence().associateWith { d.getString(it) })
            val rows = tracks(j.optJSONArray("tracks")); val ids = rows.map { it.id }.toSet()
            val pl = j.optJSONArray("playlists") ?: JSONArray()
            return LibrarySnapshot(rows, strings(j.optJSONArray("favorites")).filter { it in ids }.toSet(),
                (0 until pl.length()).map { val p = pl.getJSONObject(it)
                    UserPlaylist(p.getString("id"), p.getString("title"), strings(p.optJSONArray("tracks")).filter { it in ids }.distinct())
                }.distinctBy { it.id }, strings(j.optJSONArray("folders")).distinct(), tracks(j.optJSONArray("queue")),
                j.optString("selected").takeIf { it.isNotBlank() && it != "null" },
                j.optLong("positionMs").coerceAtLeast(0), prefs)
        }
    }
}
