package app.ziziplayer.desktop.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Desktop-only glyphs; shared mobile vectors remain byte-identical. */
internal object DesktopIcons {
    val Volume = ImageVector.Builder("desktop_volume", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 1.7f,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(13f, 3f); lineTo(5f, 8f); lineTo(2f, 9f); lineTo(2f, 15f)
            lineTo(5f, 16f); lineTo(13f, 21f); close()
            moveTo(13f, 3f); lineTo(13f, 21f)
            moveTo(17f, 7f); curveTo(22.5f, 9.5f, 22.5f, 14.5f, 17f, 17f)
        }
    }.build()
    val Muted = ImageVector.Builder("desktop_muted", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 1.7f,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(13f, 3f); lineTo(5f, 8f); lineTo(2f, 9f); lineTo(2f, 15f)
            lineTo(5f, 16f); lineTo(13f, 21f); close()
            moveTo(18f, 9f); lineTo(23f, 15f); moveTo(23f, 9f); lineTo(18f, 15f)
        }
    }.build()
}
