package app.ziziplayer.desktop.network

import app.ziziplayer.desktop.PlayerTrack
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

class NetworkFailure(val code: Int) : Exception("ZIZI_HTTP_$code")
object RemoteIdentity {
    fun parse(raw: String): Pair<String, String> {
        val uri = URI(raw)
        require(uri.scheme == "zizi" && uri.userInfo == null && uri.port == -1 && uri.query == null && uri.fragment == null)
        val path = uri.rawPath.removePrefix("/")
        require(path.isNotBlank() && '/' !in path)
        // URI.path decodes percent escapes, but unlike URLDecoder keeps literal '+'.
        val id = uri.path.removePrefix("/")
        val pair = if (uri.host == "mix") id.substringBefore(':') to id.substringAfter(':', "") else uri.host to id
        require(pair.first in setOf("dz", "yt"))
        if (pair.first == "dz") require(pair.second.matches(Regex("[0-9]{1,20}")))
        else require(pair.second.matches(Regex("[A-Za-z0-9_-]{11}")))
        return pair.first to pair.second
    }
}
object HttpTransport {
    fun sameOrigin(a: URI, b: URI): Boolean {
        fun port(u: URI) = if (u.port >= 0) u.port else if (u.scheme == "https") 443 else 80
        return a.scheme.equals(b.scheme, true) && a.host.equals(b.host, true) && port(a) == port(b)
    }
    fun safeUri(raw: String, legacyOrigin: URI? = null): URI {
        val uri = URI(raw)
        require(uri.userInfo == null && uri.fragment == null && !uri.host.isNullOrBlank())
        require(uri.port in -1..65535 && uri.port != 0)
        require(uri.scheme == "https" || (uri.scheme == "http" &&
            (uri.host in setOf("127.0.0.1", "localhost", "[::1]") ||
                (legacyOrigin != null && sameOrigin(uri, legacyOrigin))))) {
            "HTTPS_REQUIRED"
        }
        return uri
    }
    fun open(uri: URI, headers: Map<String, String> = emptyMap(), method: String = "GET", legacyOrigin: URI? = null): HttpURLConnection {
        safeUri(uri.toString(), legacyOrigin)
        val connection = uri.toURL().openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = false // Never forward auth to another origin.
        connection.connectTimeout = 15_000
        connection.readTimeout = 15_000
        connection.requestMethod = method
        connection.setRequestProperty("User-Agent", "ZiziDesktop/0.3.2")
        connection.setRequestProperty("Accept-Encoding", "identity")
        for ((key, value) in headers) {
            require(!key.contains('\r') && !key.contains('\n') && !value.contains('\r') && !value.contains('\n'))
            connection.setRequestProperty(key, value)
        }
        return connection
    }
    fun bytes(uri: URI, headers: Map<String, String>, max: Int, legacyOrigin: URI? = null): ByteArray {
        val c = open(uri, headers, legacyOrigin = legacyOrigin)
        try {
            val code = c.responseCode
            if (code != 200) throw NetworkFailure(code)
            require(c.contentLengthLong <= max) { "RESPONSE_TOO_LARGE" }
            val bytes = c.inputStream.use { it.readNBytes(max + 1) }
            require(bytes.size <= max) { "RESPONSE_TOO_LARGE" }
            return bytes
        } finally { c.disconnect() }
    }
}
/** Immutable build-configured origin. Headers/refresh perform IO: never call on the UI thread.
 * Only the expiring device credential is cached; bootstrap is supplied by the build.
 * Neither credential enters URLs, FFmpeg arguments, diagnostics or toString.
 */
class ZiziClient(base: String, private val bootstrap: String,
    private val installId: String = UUID.randomUUID().toString(),
    private val legacyOrigin: URI? = null,
    private val tokenStore: DeviceTokenStore = MemoryDeviceTokenStore()
) {
    private val base = HttpTransport.safeUri(base.trim().trimEnd('/'), legacyOrigin).also {
        require(it.query == null)
    }.toString().trimEnd('/')
    private val cached = tokenStore.load()
    private var deviceToken = cached?.token.orEmpty()
    private var expiresAt = cached?.expiresAt ?: 0L
    private var renewAt = cached?.renewAt ?: 0L
    private var retryAt = 0L
    private fun endpoint(path: String, parameters: Map<String, String> = emptyMap()): URI {
        val query = parameters.entries.joinToString("&") { (k, v) -> "$k=${URLEncoder.encode(v, StandardCharsets.UTF_8)}" }
        return URI(base + path + if (query.isEmpty()) "" else "?$query")
    }
    private fun json(path: String, parameters: Map<String, String> = emptyMap()): JSONObject {
        fun request() = JSONObject(String(HttpTransport.bytes(endpoint(path, parameters), headers(),
            2 * 1024 * 1024, legacyOrigin), StandardCharsets.UTF_8))
        try { return request() } catch (e: NetworkFailure) {
            if (e.code != 401) throw e
            // One recovery attempt for a cached/revoked device credential. Preserve failure backoff.
            synchronized(this) {
                if (deviceToken.isBlank()) throw e
                deviceToken = ""; expiresAt = 0; renewAt = 0; tokenStore.clear()
            }
            return request()
        }
    }
    @Synchronized fun headers(): Map<String, String> {
        val now = System.currentTimeMillis()
        if (bootstrap.isNotBlank() && now >= renewAt && now >= retryAt) {
            retryAt = now + 300_000 // No refresh storms on 401/429/503.
            try {
                val auth = mapOf("Authorization" to "Bearer ${bootstrap.trim()}", "X-Zizi-Install" to installId)
                val response = JSONObject(String(HttpTransport.bytes(endpoint("/auth/device"), auth, 64 * 1024, legacyOrigin), StandardCharsets.UTF_8))
                val token = response.getString("token")
                val ttl = response.getLong("expires_in")
                require(token.isNotBlank() && token.length <= 4096 && token.none { it.code < 32 || it.code > 126 } && ttl in 1..604800)
                deviceToken = token; expiresAt = System.currentTimeMillis() + ttl * 1000
                renewAt = expiresAt - minOf(600_000L, ttl * 500); retryAt = 0
                tokenStore.save(DeviceCredential(deviceToken, expiresAt, renewAt))
            } catch (_: Exception) { /* Compatible bootstrap fallback, as on mobile. */ }
        }
        val bearer = if (deviceToken.isNotBlank() && System.currentTimeMillis() < expiresAt) deviceToken else bootstrap.trim()
        return buildMap {
            put("X-Zizi-Install", installId)
            if (bearer.isNotBlank()) put("Authorization", "Bearer $bearer")
        }
    }
    private fun parseTracks(items: org.json.JSONArray): List<PlayerTrack> =
        (0 until items.length()).mapNotNull { index ->
            val row = items.getJSONObject(index); val id = row.optString("id")
            if (!id.matches(Regex("[0-9]{1,20}")) || row.optString("src", "deezer") != "deezer") null
            else PlayerTrack("zizi://dz/$id", row.optString("title", "Без названия"), row.optString("artist"),
                durationMs = row.optLong("dur", 0).takeIf { it in 1..604800 }?.times(1000),
                artworkUrl = row.optString("art").takeIf { it.isNotBlank() && it != "null" },
                artistId = row.optString("artist_id").takeIf { it.matches(Regex("[0-9]{1,20}")) })
        }.distinctBy { it.id }
    fun search(query: String): List<PlayerTrack> {
        require(query.isNotBlank() && query.length <= 300)
        return parseTracks(json("/catalog/search", mapOf("q" to query, "src" to "deezer", "limit" to "30")).getJSONArray("items"))
    }
    private fun parseCollection(row: JSONObject): CatalogCollection {
        val id = row.getString("id"); val kind = row.getString("kind")
        require(id.matches(Regex("[0-9]{1,20}")) && kind in setOf("artist", "album", "playlist"))
        return CatalogCollection(id, kind, row.optString("title"), row.optString("subtitle"),
            row.optString("art").takeIf { it.isNotBlank() && it != "null" })
    }
    fun browse(query: String, kind: String, offset: Int = 0): CatalogBrowse {
        require(kind in setOf("artist", "album", "playlist"))
        require(query.isNotBlank() && query.length <= 300 && offset in 0..10000)
        val data = json("/catalog/browse", mapOf("q" to query, "kind" to kind, "limit" to "25", "offset" to "$offset"))
        require(data.getInt("contract") == 1 && data.getString("src") == "deezer")
        val rows = data.getJSONArray("items")
        return CatalogBrowse((0 until rows.length()).map { parseCollection(rows.getJSONObject(it)) }
            .distinctBy { it.key }, nextOffset(data, offset))
    }
    private fun nextOffset(data: JSONObject, current: Int): Int? =
        if (data.isNull("next_offset")) null else data.getInt("next_offset").takeIf { it > current && it <= 10000 }
    fun collection(collection: CatalogCollection, offset: Int = 0): CatalogPage {
        require(collection.id.matches(Regex("[0-9]{1,20}")) && collection.kind in setOf("artist", "album", "playlist"))
        require(offset in 0..10000)
        val data = json("/catalog/browse/collection", mapOf("id" to collection.id, "kind" to collection.kind,
            "limit" to "50", "offset" to "$offset"))
        require(data.getInt("contract") == 1 && data.getString("src") == "deezer")
        val info = parseCollection(data.getJSONObject("collection"))
        require(info.key == collection.key)
        return CatalogPage(info, parseTracks(data.getJSONArray("items")), nextOffset(data, offset),
            if (data.isNull("total")) null else data.optInt("total").takeIf { it >= 0 })
    }
    fun resolve(source: String): StreamTarget {
        val (provider, id) = RemoteIdentity.parse(source)
        val video = if (provider == "yt") id else json("/match/deezer", mapOf("id" to id)).getString("vid")
        require(video.matches(Regex("[A-Za-z0-9_-]{11}"))) { "INVALID_VIDEO_ID" }
        val resolved = json("/resolve", mapOf("id" to video))
        require(resolved.optString("url").isNotBlank()) { "RESOLVER_EMPTY" }
        // Server proxy mode preserves the server IP that resolved the YouTube stream.
        return StreamTarget(endpoint("/stream", mapOf("id" to video)), legacyOrigin, ::headers)
    }
    fun artwork(raw: String): ByteArray {
        // Use the mobile server image route and its host policy, not arbitrary authenticated URLs.
        return HttpTransport.bytes(endpoint("/img", mapOf("u" to raw)), headers(), 5 * 1024 * 1024, legacyOrigin)
    }
}
class StreamTarget(val uri: URI, val legacyOrigin: URI? = null, val headers: () -> Map<String, String>)

data class CatalogCollection(val id: String, val kind: String, val title: String,
    val subtitle: String = "", val artworkUrl: String? = null) {
    val key: String get() = "$kind:$id"
    fun artworkTrack() = PlayerTrack("collection:$key", title, artworkUrl = artworkUrl)
}
data class CatalogBrowse(val items: List<CatalogCollection>, val nextOffset: Int?)
data class CatalogPage(val collection: CatalogCollection, val tracks: List<PlayerTrack>, val nextOffset: Int?, val total: Int?)
