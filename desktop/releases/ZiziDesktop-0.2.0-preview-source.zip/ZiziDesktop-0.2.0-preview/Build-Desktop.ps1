﻿[CmdletBinding()]
param(
    [ValidateSet('run','check','package')][string]$Action = 'run',
    [string]$AudioLabPath = '',
    [string]$FfmpegPath = '',
    [string]$GradleHome = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location -LiteralPath $PSScriptRoot
if (-not $AudioLabPath) { $AudioLabPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'ZiziAudioLab-0.1.0' }
if (-not $GradleHome) { $GradleHome = Join-Path $AudioLabPath '.tools/gradle-8.11.1' }
$Gradle = Join-Path $GradleHome 'bin/gradle.bat'
if (-not (Test-Path -LiteralPath $Gradle -PathType Leaf)) { throw 'Gradle not found. Pass -AudioLabPath to the working Audio Lab or -GradleHome to Gradle 8.11.1.' }
if (-not $env:JAVA_HOME) { throw 'Set JAVA_HOME to JDK 21.' }
$Java = Join-Path $env:JAVA_HOME 'bin/java.exe'
if (-not (Test-Path -LiteralPath $Java)) { throw 'JAVA_HOME is invalid.' }
$OldPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$Version = & $Java -version 2>&1
$JavaExit = $LASTEXITCODE
$ErrorActionPreference = $OldPreference
if ($JavaExit -ne 0 -or ($Version | Out-String) -notmatch 'version\s+"21(?:[."]|$)') { throw 'This preview requires JDK 21.' }
if (-not $FfmpegPath -and $env:FFMPEG_PATH) { $FfmpegPath = $env:FFMPEG_PATH }
if (-not $FfmpegPath) {
    $ConfigFile = Join-Path $AudioLabPath '.local-runtime.json'
    if (Test-Path -LiteralPath $ConfigFile) {
        $Config = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $FfmpegPath = $Config.ffmpeg
    }
}
if (-not $FfmpegPath -or -not (Test-Path -LiteralPath $FfmpegPath -PathType Leaf)) { throw 'Pass -FfmpegPath with the full path to ffmpeg.exe.' }
$FfmpegPath = [IO.Path]::GetFullPath($FfmpegPath)
$env:FFMPEG_PATH = $FfmpegPath
$Origin = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'upstream.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($Entry in $Origin.files) {
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $Entry.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.sha256) { throw "Upstream source changed: $($Entry.path)" }
}
$Tasks = @('--no-daemon', '--console=plain', 'test', "-PffmpegPath=$FfmpegPath")
if ($Action -eq 'run') { $Tasks += 'run' }
if ($Action -eq 'package') { $Tasks += 'createDistributable' }
[IO.Directory]::CreateDirectory((Join-Path $PSScriptRoot 'logs')) | Out-Null
$OldPreference = $ErrorActionPreference
try {
    $ErrorActionPreference = 'Continue'
    & $Gradle @Tasks 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'logs/desktop-build.txt')
    $BuildExit = $LASTEXITCODE
} finally { $ErrorActionPreference = $OldPreference }
if ($BuildExit -ne 0) { throw 'Desktop build/run failed. See logs/desktop-build.txt.' }
if ($Action -eq 'package') {
    $Image = Join-Path $PSScriptRoot 'build/compose/binaries/main/app/ZiziDesktop'
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'LICENSE') -Destination $Image
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'THIRD-PARTY.md') -Destination $Image
    Write-Host "EXE image directory: $Image"
    Write-Host 'Keep the entire directory. FFmpeg is external: configure its path in the UI or set FFMPEG_PATH.'
}
