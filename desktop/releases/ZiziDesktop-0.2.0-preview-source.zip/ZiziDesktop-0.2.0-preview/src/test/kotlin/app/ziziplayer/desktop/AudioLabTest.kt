package app.ziziplayer.desktop

import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspEngine
import com.sun.net.httpserver.HttpServer
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class AudioLabTest {
    private fun pcm(frames: Int): ByteArray {
        val b = ByteBuffer.allocate(frames * 8).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) { f ->
            val value = (sin(2.0 * PI * 1000 * f / Pcm.RATE) * 0.2).toFloat()
            b.putFloat(value); b.putFloat(value)
        }
        return b.array()
    }
    private class MemoryDecoder(override val pcm: InputStream, private val fail: Boolean = false) : Decoder {
        override fun checkExit() { if (fail) error("simulated decoder exit") }
        override fun close() { pcm.close() }
    }
    private fun render(bytes: ByteArray, preset: String = "off", seconds: Double? = null): Pair<Summary, ByteArray> {
        val dir = Files.createTempDirectory("zizi-test-"); val out = dir.resolve("result.wav")
        try {
            val result = AudioEngine(Controls(preset, 0.5f), 0).play(MemoryDecoder(ByteArrayInputStream(bytes)), WavSink(out), seconds)
            return result to Files.readAllBytes(out)
        } finally { Files.deleteIfExists(out); Files.deleteIfExists(dir) }
    }
    @Test fun fragmentedInputPreservesFrames() {
        val bytes = pcm(17)
        val input = object : ByteArrayInputStream(bytes) {
            override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, minOf(3, len))
        }
        val out = ByteArray(200)
        assertEquals(bytes.size, Pcm.readBlock(input, out))
        assertArrayEquals(bytes, out.copyOf(bytes.size))
    }
    @Test(expected = java.io.EOFException::class) fun rejectsTruncatedFrames() { Pcm.readBlock(ByteArrayInputStream(ByteArray(9)), ByteArray(16)) }
    @Test fun floatEndianAndNonFinite() {
        val b = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).putFloat(0.5f).putFloat(-0.5f).putFloat(Float.NaN).putFloat(Float.POSITIVE_INFINITY).array()
        val out = FloatArray(4); Pcm.decode(b, 16, out)
        assertArrayEquals(floatArrayOf(0.5f, -0.5f, 0f, 0f), out, 0f)
    }
    @Test fun quantizationClampsAndReports() {
        val out = ByteArray(8)
        val s = Quantizer().encode(floatArrayOf(2f, -2f, Float.NaN, 0f), 4, 1f, out, false)
        assertEquals(2, s.clippedSamples)
        val b = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals(32767, b.short.toInt()); assertEquals(-32767, b.short.toInt()); assertEquals(0, b.short.toInt())
    }
    @Test(timeout = 5000) fun handlesShortTail() {
        val (s, wav) = render(pcm(1234))
        assertEquals(1234L, s.frames); assertEquals(44 + 1234 * 4, wav.size)
    }
    @Test(timeout = 5000) fun sampleAccurateDurationCap() {
        val (s, wav) = render(pcm(10_000), seconds = 0.1)
        assertEquals(4800L, s.frames); assertEquals(44 + 4800 * 4, wav.size)
    }
    @Test fun wavHasCorrectRiffLength() {
        val (_, wav) = render(pcm(100))
        val b = ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals("RIFF", String(wav.copyOfRange(0, 4), Charsets.US_ASCII))
        assertEquals(wav.size - 8, b.getInt(4)); assertEquals(wav.size - 44, b.getInt(40))
        assertEquals(48_000, b.getInt(24))
    }
    @Test(timeout = 5000) fun decoderFailureIsNotSuccess() {
        val dir = Files.createTempDirectory("zizi-fail-"); val out = dir.resolve("failed.wav")
        try {
            try {
                AudioEngine(Controls("off", 0.35f), 0).play(MemoryDecoder(ByteArrayInputStream(pcm(100)), true), WavSink(out))
                fail("must fail")
            } catch (_: IllegalStateException) { }
        } finally { Files.deleteIfExists(out); Files.deleteIfExists(dir) }
    }
    @Test(timeout = 5000) fun cancelBeforePlaybackTerminates() {
        val dir = Files.createTempDirectory("zizi-stop-"); val out = dir.resolve("stopped.wav")
        try {
            val c = Controls("off", 0.35f); c.stop()
            val result = AudioEngine(c).play(MemoryDecoder(ByteArrayInputStream(pcm(100))), WavSink(out))
            assertTrue(result.cancelled); assertEquals(0L, result.frames)
        } finally { Files.deleteIfExists(out); Files.deleteIfExists(dir) }
    }
    @Test fun noOutputOverwrite() {
        val path = Files.createTempFile("zizi-existing-", ".wav")
        try { assertThrows(java.nio.file.FileAlreadyExistsException::class.java) { WavSink(path) } }
        finally { Files.delete(path) }
    }
    @Test fun realUpstreamDspChangesSignalAndStaysFinite() {
        val engine = DspEngine(Pcm.RATE, 2); engine.setConfig(LabPresets.config("underwater"))
        val samples = FloatArray(2048); val original = FloatArray(2048)
        var difference = 0.0
        repeat(80) { block ->
            repeat(samples.size) { i -> samples[i] = (sin(2.0 * PI * 8000 * ((block * 1024 + i / 2).toDouble()) / Pcm.RATE) * 0.2).toFloat() }
            samples.copyInto(original)
            engine.process(samples, 1024)
            assertTrue(samples.all { it.isFinite() })
            for (i in samples.indices) difference += abs(samples[i] - original[i])
        }
        assertTrue("The real DSP must not be a stub", difference > 10)
    }
    @Test fun presetsProduceFiniteOutput() {
        for (preset in LabPresets.names.filter { it != "off" }) {
            val engine = DspEngine(Pcm.RATE, 2); engine.setConfig(LabPresets.config(preset))
            repeat(20) {
                val samples = FloatArray(2048); Pcm.decode(pcm(1024), 8192, samples)
                engine.process(samples, 1024); assertTrue(samples.all { it.isFinite() })
            }
        }
    }
    @Test fun bypassIsNotDspProcessed() {
        val (_, wav) = render(pcm(1000), "off")
        val samples = FloatArray(2000); Pcm.decode(pcm(1000), 8000, samples)
        val b = ByteBuffer.wrap(wav, 44, wav.size - 44).order(ByteOrder.LITTLE_ENDIAN)
        for (sample in samples) assertEquals(sample.toDouble() * 0.5, b.short / 32767.0, 0.0001)
    }
    @Test fun commandHasPcmContractAndNoShell() {
        val c = FfmpegDecoder.command("ffmpeg.exe", "https://example.org/audio.mp3")
        assertEquals("ffmpeg.exe", c.first()); assertEquals("pipe:1", c.last())
        assertTrue(c.contains("pcm_f32le")); assertTrue(c.contains("48000"))
        assertFalse(c.contains("cmd.exe")); assertFalse(c.contains("-reconnect"))
        assertFalse(c[c.indexOf("-protocol_whitelist") + 1].contains("file"))
    }
    @Test fun rejectsUserinfoCredentials() {
        assertThrows(IllegalArgumentException::class.java) { FfmpegDecoder.command("ffmpeg", "https://user:secret@example.org/a.mp3") }
    }
    @Test fun rejectsInvalidGain() {
        assertThrows(IllegalArgumentException::class.java) { Controls("off", Float.NaN) }
        assertThrows(IllegalArgumentException::class.java) { Controls("off", 2f) }
        assertTrue(DspConfig.NEUTRAL.isNeutral)
    }
    private fun ffmpeg(): String {
        val path = System.getProperty("zizi.ffmpeg", "")
        if (System.getProperty("zizi.requireFfmpeg") == "true") assertTrue("FFmpeg integration is required", path.isNotBlank())
        assumeTrue("FFmpeg integration SKIPPED: no -PffmpegPath", path.isNotBlank())
        return path
    }
    private fun ffmpegRun(exe: String, args: List<String>) {
        val process = ProcessBuilder(listOf(exe, "-hide_banner", "-loglevel", "error", "-nostdin") + args)
            .redirectError(ProcessBuilder.Redirect.INHERIT).redirectOutput(ProcessBuilder.Redirect.DISCARD).start()
        try {
            assertTrue("FFmpeg fixture timeout", process.waitFor(20, TimeUnit.SECONDS))
            assertEquals(0, process.exitValue())
        } finally { process.destroyForcibly() }
    }
    private fun fixture(dir: Path): Path {
        val path = dir.resolve("tone.wav")
        render(pcm(24_000)).second.let { Files.write(path, it) }
        return path
    }
    private fun decode(exe: String, source: String, out: Path): Summary {
        val d = FfmpegDecoder(exe, source)
        try { return AudioEngine(Controls("space", 0.35f), 50).play(d, WavSink(out)) }
        finally { d.close() }
    }
    @Test(timeout = 60000) fun integrationLocalFlacThroughRealDsp() {
        val exe = ffmpeg(); val dir = Files.createTempDirectory("zizi-flac-")
        try {
            val wav = fixture(dir); val flac = dir.resolve("tone.flac")
            ffmpegRun(exe, listOf("-i", wav.toString(), "-c:a", "flac", flac.toString()))
            val result = decode(exe, flac.toString(), dir.resolve("render.wav"))
            assertEquals(24_000L, result.frames); assertTrue(result.peak > 0f)
        } finally { Files.list(dir).use { s -> s.forEach { Files.deleteIfExists(it) } }; Files.deleteIfExists(dir) }
    }
    @Test(timeout = 60000) fun integrationHttpMediaThroughRealDsp() {
        val exe = ffmpeg(); val dir = Files.createTempDirectory("zizi-http-")
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        try {
            val bytes = Files.readAllBytes(fixture(dir))
            server.createContext("/tone.wav") { exchange ->
                exchange.responseHeaders.add("Content-Type", "audio/wav")
                exchange.sendResponseHeaders(200, bytes.size.toLong())
                exchange.responseBody.use { it.write(bytes) }
            }
            server.start()
            val result = decode(exe, "http://127.0.0.1:${server.address.port}/tone.wav", dir.resolve("render.wav"))
            assertEquals(24_000L, result.frames); assertTrue(result.peak > 0f)
        } finally {
            server.stop(0)
            Files.list(dir).use { s -> s.forEach { Files.deleteIfExists(it) } }; Files.deleteIfExists(dir)
        }
    }
    @Test(timeout = 60000) fun integrationUnicodeFilePathThroughRealDsp() {
        val exe = ffmpeg(); val dir = Files.createTempDirectory("зизи музыка-")
        try {
            val source = dir.resolve("Егор Крид — Сердца.wav")
            Files.copy(fixture(dir), source)
            val result = decode(exe, source.toString(), dir.resolve("render.wav"))
            assertEquals(24_000L, result.frames); assertTrue(result.peak > 0f)
        } finally { Files.list(dir).use { stream -> stream.forEach { Files.deleteIfExists(it) } }; Files.deleteIfExists(dir) }
    }
}
