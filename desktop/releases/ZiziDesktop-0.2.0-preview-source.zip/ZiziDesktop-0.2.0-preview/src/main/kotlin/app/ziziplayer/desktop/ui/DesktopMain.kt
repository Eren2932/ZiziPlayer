package app.ziziplayer.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.ziziplayer.desktop.*
import app.ziziplayer.playback.dsp.DspConfig
import app.ziziplayer.playback.dsp.DspPresets
import app.ziziplayer.ui.components.ZiziIcons
import java.io.File
import java.nio.file.Files
import java.nio.file.Path
import java.util.UUID
import javax.swing.JFileChooser
import javax.swing.filechooser.FileNameExtensionFilter
import kotlinx.coroutines.*

private val Brand = Color(0xFFF97316)
private val Base = Color(0xFF09090B)
private val Panel = Color(0xFF151518)
private data class Track(val source: String, val title: String)

// All observable state is owned by the UI thread. AudioEngine and DspEngine never run there.
// Preview: sequential resource handover; no automatic queue advance, pause or seek yet.
private class DesktopSession(private val scope: CoroutineScope) {
    var tracks by mutableStateOf<List<Track>>(emptyList()); private set
    var current by mutableStateOf<Track?>(null); private set
    var status by mutableStateOf("Выбери музыку — начни с невысокой громкости"); private set
    var summary by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    var active by mutableStateOf(false); private set
    var gain by mutableStateOf(0.35f); private set
    var config by mutableStateOf(DspConfig.NEUTRAL); private set
    var ffmpeg by mutableStateOf(System.getenv("FFMPEG_PATH")?.takeIf { it.isNotBlank() } ?: "ffmpeg.exe")
    private var controls: Controls? = null
    private var playback: Job? = null
    private val logRoot: Path = Path.of(System.getenv("LOCALAPPDATA") ?: System.getProperty("user.home"), "ZiziDesktopPreview", "logs")

    fun add(files: List<File>) {
        tracks = (tracks + files.map { Track(it.absolutePath, it.name) }).distinctBy { it.source }
    }
    fun addUrl(raw: String) {
        val text = raw.trim()
        val uri = runCatching { java.net.URI(text) }.getOrNull()
        if (uri == null || uri.scheme?.lowercase() !in setOf("http", "https") || uri.host.isNullOrBlank() || uri.userInfo != null) {
            status = "Нужна прямая HTTP(S)-ссылка без логина и пароля в адресе"; return
        }
        tracks = (tracks + Track(text, "HTTP-аудио ${tracks.count { it.source.startsWith("http", true) } + 1}")).distinctBy { it.source }
    }
    fun dsp(value: DspConfig) {
        config = value.sanitized()
        controls?.config?.set(config)
    }
    fun volume(value: Float) {
        gain = value.coerceIn(0f, 1f)
        controls?.gain?.set(gain)
    }
    fun play(track: Track) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val old = controls
                withContext(Dispatchers.IO) { old?.stop() }
                playback?.join()
                val next = Controls("off", gain).also { it.config.set(config) }
                controls = next
                current = track; summary = ""; status = "Сеанс запущен: загрузка / воспроизведение"; active = true
                val exe = ffmpeg
                playback = scope.launch(Dispatchers.IO) {
                    try {
                        Files.createDirectories(logRoot)
                        val log = logRoot.resolve("session-${UUID.randomUUID()}.csv")
                        val result = Diagnostics(log).use { diagnostics ->
                            FfmpegDecoder(exe, track.source).use { decoder ->
                                JavaSoundSink(250).use { sink ->
                                    AudioEngine(next, 500).play(decoder, sink, diagnostics = diagnostics)
                                }
                            }
                        }
                        withContext(Dispatchers.Main) {
                            if (controls === next) {
                                active = false
                                status = if (result.cancelled) "Остановлено" else "Трек завершён"
                                summary = "PCM-кадры: ${result.frames}; ожидания: ${result.sourceWaitEvents}; пустой буфер (косвенно): ${result.deviceEmptyHints}; клиппинг: ${result.clippedSamples}; DSP max: ${"%.2f".format(result.maxDspMs)} мс"
                            }
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            if (controls === next) {
                                active = false
                                // Never put URLs or raw decoder messages in UI/log output.
                                status = if (next.stopped.get()) "Остановлено" else "Ошибка ${e.javaClass.simpleName}: проверь файл, FFmpeg и устройство вывода"
                            }
                        }
                    }
                }
            } finally { busy = false }
        }
    }
    fun adjacent(delta: Int) {
        val index = tracks.indexOfFirst { it.source == current?.source }
        tracks.getOrNull(if (index < 0) 0 else index + delta)?.let(::play)
    }
    fun stop(after: (() -> Unit)? = null) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val old = controls
                withContext(Dispatchers.IO) { old?.stop() }
                playback?.join()
                active = false; status = "Остановлено"
            } finally { busy = false; after?.invoke() }
        }
    }
}

private fun chooseFiles(): List<File> {
    val picker = JFileChooser().apply {
        dialogTitle = "Добавить музыку в Zizi"
        isMultiSelectionEnabled = true
        fileFilter = FileNameExtensionFilter("Аудио", "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    }
    return if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) picker.selectedFiles.toList() else emptyList()
}

fun main() = application {
    val scope = rememberCoroutineScope()
    val session = remember { DesktopSession(scope) }
    var closing by remember { mutableStateOf(false) }
    Window(
        onCloseRequest = {
            if (!closing) {
                closing = true
                scope.launch {
                    while (session.busy) delay(25)
                    session.stop { exitApplication() }
                }
            }
        },
        title = "Zizi Desktop · 0.2 preview",
        state = rememberWindowState(width = 1240.dp, height = 820.dp)
    ) {
        LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(1000, 680) }
        MaterialTheme(colorScheme = darkColorScheme(primary = Brand, onPrimary = Color(0xFF1B0C00), background = Base, surface = Panel)) {
            Surface(Modifier.fillMaxSize(), color = Base) { DesktopContent(session, closing) }
        }
    }
}

@Composable
private fun DesktopContent(s: DesktopSession, closing: Boolean) {
    var query by remember { mutableStateOf("") }
    var urlDialog by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.width(188.dp).fillMaxHeight().background(Panel).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Zizi", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Brand)
                Text("DESKTOP PREVIEW", style = MaterialTheme.typography.labelSmall)
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(ZiziIcons.FolderMusic, null); Spacer(Modifier.width(8.dp)); Text("Локальные треки") }
                TextButton(onClick = { s.add(chooseFiles()) }, enabled = !closing) { Text("Добавить файлы") }
                TextButton(onClick = { urlDialog = true }, enabled = !closing) { Text("Открыть HTTP-аудио") }
                Spacer(Modifier.weight(1f))
                Text("Список пока хранится только до закрытия окна.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { settings = true }) { Text("Путь к FFmpeg") }
            }
            Column(Modifier.weight(1f).padding(22.dp)) {
                Text("Твоя музыка", style = MaterialTheme.typography.headlineMedium)
                Text("Выбор файлов Windows → оригинальный Zizi DSP", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(query, { query = it }, label = { Text("Поиск по имени файла") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                val visible = s.tracks.filter { it.title.contains(query, ignoreCase = true) }
                if (s.tracks.isEmpty()) {
                    Text("Добавь MP3, FLAC или M4A. Русские имена передаются из файлового диалога напрямую — без консольного ввода.", Modifier.padding(vertical = 24.dp))
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(visible, key = { it.source }) { track ->
                        val selected = track.source == s.current?.source
                        Row(Modifier.fillMaxWidth().background(if (selected) Brand.copy(alpha = 0.13f) else Color.Transparent)
                            .clickable(enabled = !s.busy && !closing) { s.play(track) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(ZiziIcons.FolderMusic, null, tint = if (selected) Brand else Color.Gray)
                            Spacer(Modifier.width(12.dp))
                            Text(track.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Text("Один клик запускает трек. Предыдущий/следующий — по порядку добавления, не по фильтру.", style = MaterialTheme.typography.bodySmall)
            }
            EffectsPanel(s, Modifier.width(340.dp).fillMaxHeight().background(Panel).padding(18.dp))
        }
        HorizontalDivider()
        Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 22.dp, vertical = 12.dp)) {
            Text(s.current?.title ?: "Zizi готов к музыке", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(if (closing) "Закрываем аудиосеанс…" else s.status, style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { s.adjacent(-1) }, enabled = !s.busy && !closing && s.tracks.isNotEmpty()) { Text("Пред.") }
                Button(onClick = { (s.current ?: s.tracks.firstOrNull())?.let(s::play) }, enabled = !s.busy && !closing && s.tracks.isNotEmpty()) { Text(if (s.active) "С начала" else "Играть") }
                TextButton(onClick = { s.stop() }, enabled = !s.busy && !closing && s.active) { Text("Стоп") }
                TextButton(onClick = { s.adjacent(1) }, enabled = !s.busy && !closing && s.tracks.isNotEmpty()) { Text("След.") }
                Spacer(Modifier.weight(1f))
                Text("Громкость ${(s.gain * 100).toInt()}%")
                Slider(s.gain, s::volume, modifier = Modifier.width(160.dp))
            }
            Text("Пауза, перемотка, автопереход и обложки ещё не реализованы — это GUI-стенд.", style = MaterialTheme.typography.labelSmall)
            if (s.summary.isNotEmpty()) Text(s.summary, style = MaterialTheme.typography.labelSmall)
        }
    }
    if (urlDialog) AlertDialog(onDismissRequest = { urlDialog = false; url = "" }, title = { Text("Прямое HTTP-аудио") }, text = {
        Column {
            Text("Не страница YouTube и не zizi://. Не вводи секретные ссылки: адрес будет виден в аргументах FFmpeg.")
            OutlinedTextField(url, { url = it }, label = { Text("https://…") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { s.addUrl(url); url = ""; urlDialog = false }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = { url = ""; urlDialog = false }) { Text("Отмена") } })
    if (settings) AlertDialog(onDismissRequest = { settings = false }, title = { Text("FFmpeg") }, text = {
        Column {
            Text("Путь применяется к следующему запуску трека. Пока не сохраняется между запусками.")
            OutlinedTextField(s.ffmpeg, { s.ffmpeg = it.trim().removeSurrounding("\"") }, singleLine = true)
            TextButton(onClick = {
                val picker = JFileChooser().apply { dialogTitle = "Выбери ffmpeg.exe" }
                if (picker.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) s.ffmpeg = picker.selectedFile.absolutePath
            }) { Text("Выбрать файл…") }
        }
    }, confirmButton = { TextButton(onClick = { settings = false }) { Text("Готово") } })
}

@Composable
private fun EffectsPanel(s: DesktopSession, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Звук Zizi", style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DSP", Modifier.weight(1f)); Switch(s.config.enabled, { s.dsp(s.config.copy(enabled = it)) })
        }
        Text("Оригинальные пресеты 6.39.9", style = MaterialTheme.typography.bodySmall)
        for ((title, presets) in listOf("Тембр" to DspPresets.curve, "Объём" to DspPresets.space, "Устройство" to DspPresets.device)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                DropdownMenu(expanded, { expanded = false }) {
                    presets.forEach { preset -> DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                        s.dsp(preset.transform(s.config)); expanded = false
                    }) }
                }
            }
        }
        TextButton(onClick = { s.dsp(DspConfig.NEUTRAL) }) { Text("Сбросить всё") }
        Text("Преамп: ${"%.1f".format(s.config.preampDb)} дБ")
        Slider(s.config.preampDb, { s.dsp(s.config.copy(preampDb = it)) }, valueRange = -12f..6f)
        val bands = listOf("31 Гц", "62 Гц", "125 Гц", "250 Гц", "500 Гц", "1 кГц", "2 кГц", "4 кГц", "8 кГц", "16 кГц")
        bands.forEachIndexed { index, label ->
            Text("$label · ${"%.1f".format(s.config.bandsDb[index])} дБ", style = MaterialTheme.typography.labelSmall)
            Slider(s.config.bandsDb[index], { value ->
                s.dsp(s.config.copy(enabled = true, bandsDb = s.config.bandsDb.toMutableList().also { it[index] = value }))
            }, valueRange = -12f..12f, modifier = Modifier.height(30.dp))
        }
        Text("Реверберация")
        Slider(s.config.reverbMix, { s.dsp(s.config.copy(enabled = true, reverbMix = it)) })
        Text("8D · глубина вращения")
        Slider(s.config.rotation, { s.dsp(s.config.copy(enabled = true, rotation = it)) })
        Text("Под водой")
        Slider(s.config.underwater, { s.dsp(s.config.copy(enabled = true, underwater = it)) })
        Text("Профили, speed/pitch и спектр будут отдельными доработками.", style = MaterialTheme.typography.bodySmall)
    }
}
