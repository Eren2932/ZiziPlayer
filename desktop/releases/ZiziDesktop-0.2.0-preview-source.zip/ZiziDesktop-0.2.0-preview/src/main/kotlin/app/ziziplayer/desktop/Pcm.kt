package app.ziziplayer.desktop

import java.io.EOFException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

object Pcm {
    const val RATE = 48_000
    const val CHANNELS = 2
    const val FRAME_BYTES = CHANNELS * 4
    const val BLOCK_FRAMES = 1024
    const val BLOCK_BYTES = BLOCK_FRAMES * FRAME_BYTES
    // InputStream.read() is NOT a frame boundary. Preserve all fragments.
    fun readBlock(input: InputStream, target: ByteArray): Int {
        require(target.size % FRAME_BYTES == 0)
        var count = 0
        while (count < target.size) {
            val n = input.read(target, count, target.size - count)
            if (n < 0) break
            if (n == 0) {
                val one = input.read()
                if (one < 0) break
                target[count++] = one.toByte()
            } else count += n
        }
        if (count % FRAME_BYTES != 0) throw EOFException("Truncated PCM frame")
        return count
    }
    fun decode(bytes: ByteArray, count: Int, out: FloatArray) {
        require(count % FRAME_BYTES == 0 && count <= bytes.size && count / 4 <= out.size)
        val b = ByteBuffer.wrap(bytes, 0, count).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count / 4) out[i] = b.float.let { if (it.isFinite()) it else 0f }
    }
}
data class Quantized(val bytes: Int, val clippedSamples: Int, val peak: Float)
class Quantizer {
    private var state = 0x2545F491
    private fun noise(): Float {
        var x = state
        x = x xor (x shl 13); x = x xor (x ushr 17); x = x xor (x shl 5)
        state = x
        return x / 2147483648f
    }
    fun encode(samples: FloatArray, count: Int, gain: Float, out: ByteArray, dither: Boolean = true): Quantized {
        require(count <= samples.size && count * 2 <= out.size && gain.isFinite() && gain in 0f..1f)
        var peak = 0f; var clips = 0
        for (i in 0 until count) {
            val value = samples[i].let { if (it.isFinite()) it * gain else 0f }
            peak = maxOf(peak, abs(value))
            if (value > 1f || value < -1f) clips++
            val n = if (dither) (noise() + noise()) * 0.5f else 0f
            val v = (value.coerceIn(-1f, 1f) * 32767f + n).coerceIn(-32768f, 32767f).toInt()
            out[i * 2] = v.toByte(); out[i * 2 + 1] = (v shr 8).toByte()
        }
        return Quantized(count * 2, clips, peak)
    }
}
