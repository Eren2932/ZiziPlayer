plugins {
    kotlin("jvm") version "2.1.0"
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.0"
    id("org.jetbrains.compose") version "1.7.3"
}
group = "app.ziziplayer.desktop"
version = "0.2.0"
kotlin { jvmToolchain(21) }
dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")
    testImplementation("junit:junit:4.13.2")
}
tasks.test {
    useJUnit()
    systemProperty("zizi.ffmpeg", providers.gradleProperty("ffmpegPath").getOrElse(""))
    systemProperty("zizi.requireFfmpeg", "true")
    testLogging { events("passed", "skipped", "failed") }
}
compose.desktop {
    application {
        mainClass = "app.ziziplayer.desktop.ui.DesktopMainKt"
        nativeDistributions {
            packageName = "ZiziDesktop"
            packageVersion = "0.2.0"
            includeAllModules = true
        }
    }
}
