# Third-party components

Mobile base: https://github.com/Eren2932/ZiziPlayer, ZiziPlayer-v6.39.9.zip, version code 81. Source ZIP SHA-256: cd9f3608b68e8ade4d1e148cd5ee3753324f5ac478691523f260a0b9d50a3ef0. The upstream LICENSE is included. Four DSP files and ZiziIcons.kt are byte-identical; see upstream.json.

Audio lab source was recovered from the New-ZiziAudioLab.ps1 and New-ZiziAudioLab.Support.ps1 generators in this conversation. Its four non-CLI engine source files are unchanged. Desktop UI and build integration are new.

Build dependencies include Kotlin, kotlinx.coroutines, Compose Multiplatform, AndroidX Compose, Skiko/Skia and JUnit. Dependencies and native runtimes have their respective licenses. Before public redistribution, audit the resolved dependency tree and distribute applicable notices and runtime licenses. This file is a provenance note, not a completed distribution compliance audit.

FFmpeg is not bundled. FFmpeg binary builds may be LGPL or GPL and have different enabled components; preserve the license and corresponding-source obligations of the actual binary distributed if bundling it later. The local Gradle and JDK installations are not included in this source ZIP.
