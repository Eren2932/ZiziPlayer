# ZiziPlayer — Android 6.48.1

**Исходный патч, versionCode 98. Не APK, Android-компиляция здесь не выполнена.** Основа — 6.48.0 / 97. Новая Главная сохранена.

Исправлены нормализация метаданных строгого подбора, ограничение ожидания текстов, повторные терминальные отказы и диагностические HTTP-коды. Серверный модуль — 1.11-metadata-match / policy 4; strict остаётся включённым. Новых библиотек нет.

Полный отчёт, ограничения и нерешённый вопрос mana gel: [RELEASE_v6.48.1.md](RELEASE_v6.48.1.md). Отдельное обновление VPS: [server/STRICT_MATCH_UPDATE.md](server/STRICT_MATCH_UPDATE.md). Результаты 22 успешных команд: `verification/v6.48.1/results.json`.

## Сборка

Загрузить `ZiziPlayer-v6.48.1.zip` в корень main репозитория. Проверенный корневой workflow выбирает максимальный versionCode 98. Дождаться зелёных JVM-тестов и assembleRelease; установить APK с прежней подписью, сохранив данные. Одного APK недостаточно для исправления серверного матчинга — обновить VPS отдельно по инструкции.

В Android-окружении проекта: SDK 36, JDK 17, Gradle 8.11.1.

````bash
python3 tools/check_selftest.py
gradle --no-daemon :app:testDebugUnitTest :app:assembleRelease --stacktrace
````

Все более старые CHANGELOG/RELEASE/verification сохранены как история, а не инструкция для установки текущего серверного патча.
