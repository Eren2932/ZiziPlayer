#!/usr/bin/env python3
"""Regression fixtures, not claims about real YouTube candidates or available audio."""
import unittest
from unittest.mock import patch
import test_strict_match as strict
candidate, c = strict.candidate, strict.c

class MetadataTests(unittest.TestCase):
    setUp = strict.StrictMatchTests.setUp
    match = strict.StrictMatchTests.match
    assert_miss = strict.StrictMatchTests.assert_miss

    def test_hai_accent_spelling(self):
        self.assertTrue(self.match([candidate('Pháo - Hai Phút Hơn', 'Pháo - Topic', 194)],
                                  title='Hai Phút Hơn', artist='Phao', duration=194)['confident'])
    def test_beast_omitted_guest_needs_exact_duration(self):
        self.assertTrue(self.match([candidate('Beast', 'Mia Martina - Topic', 189)],
                    title='Beast (feat. Waka Flocka)', artist='Mia Martina', duration=189)['confident'])
        self.assertFalse(c.strict_candidate(candidate('Beast', 'Mia Martina - Topic', 194),
                    'Beast (feat. Waka Flocka)', 'Mia Martina', 189))
    def test_beast_guest_aliases(self):
        self.assertTrue(self.match([candidate('Mia Martina - Beast (ft. Waka Flocka)', 'Mia Martina', 189)],
                    title='Beast (feat. Waka Flocka)', artist='Mia Martina', duration=189)['confident'])
    def test_conflicting_guest_rejected(self):
        self.assert_miss([candidate('Beast (feat. Another Singer)', 'Mia Martina - Topic', 189)],
                    title='Beast (feat. Waka Flocka)', artist='Mia Martina', duration=189)
    def test_cosmetic_query(self):
        self.assertTrue(self.match([candidate()], title='Song (Official Audio)')['confident'])
    def test_no_threshold_cliff_within_duration_gate(self):
        self.assertTrue(self.match([candidate('Artist - Song', 'Artist', 187)], duration=180)['confident'])
    def test_beyond_duration_gate_still_rejected(self):
        self.assert_miss([candidate('Artist - Song', 'Artist - Topic', 188)], duration=180)
    def test_new_policy_does_not_reuse_q3_miss(self):
        self.assertEqual(c.MATCH_POLICY, 4)
        self.assertTrue(c.match_key('Song','Artist',180,'',False).startswith('q4:'))
        c.miss_put('q3:old', 'no confident match')
        self.assertTrue(self.match([candidate()])['confident'])
    def test_accent_match_exits_hunt_after_first_query(self):
        with patch.object(c, 'yt_search', return_value=[candidate('Pháo - Hai Phút Hơn', 'Pháo - Topic',194)]) as search:
            result=c._hunt('Hai Phút Hơn','Phao','',194)
        self.assertEqual(search.call_count,1); self.assertEqual(len(result),1)
    def test_named_remix_not_removed_after_guest(self):
        self.assert_miss([candidate('Song feat. Guest (Bob Remix)')], title='Song feat. Guest (Alice Remix)')
    def test_hai_not_replaced_by_remix(self):
        self.assert_miss([candidate('Pháo - Hai Phút Hơn (KAIZ Remix)', 'Pháo - Topic',194)],
                        title='Hai Phút Hơn', artist='Phao',duration=194)

if __name__ == '__main__': unittest.main(verbosity=2)
