#!/usr/bin/env python3
"""Opt-in atomic replacement of the exact known base. Never restarts services."""
import argparse
import datetime
import hashlib
import os
from pathlib import Path
import stat
import tempfile

BASE_SHA256 = '793fb998252d135e4bd9e1ea3ba17f69799d52af48abfa49fa72036a2145fe55'
NEW_SHA256 = '7a1783db8f7c0d29cae94b65c3e1de84be4c8f8841963bcd8755d0fd0896316c'


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, required=True, help='Existing deployed zizi_catalog.py')
    parser.add_argument('--apply', action='store_true', help='Write update; otherwise check only')
    args = parser.parse_args()
    target = args.target
    if target.is_symlink() or not target.is_file():
        parser.error('Target must be an existing regular file, not a symlink')
    payload = (Path(__file__).resolve().parents[1] / 'zizi_catalog.py').read_bytes()
    if digest(payload) != NEW_SHA256:
        parser.error('Update payload hash mismatch; stop and get the intact bundle')
    compile(payload, 'zizi_catalog.py', 'exec')  # syntax only, no import or network
    old = target.read_bytes()
    current = digest(old)
    if current == NEW_SHA256:
        print('Already updated; no files changed.')
        return
    if current != BASE_SHA256:
        parser.error('Unknown deployed version. Refusing to overwrite; compare with the patch manually.')
    if not args.apply:
        print('Known base verified. Dry run: no files changed. Add --apply to install with a backup.')
        return
    info = target.stat()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup = target.with_name(target.name + '.before-strict-' + stamp)
    # Exclusive backup, never overwrite an earlier backup.
    with backup.open('xb') as stream:
        stream.write(old)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(backup, stat.S_IMODE(info.st_mode))
    if os.geteuid() == 0:
        os.chown(backup, info.st_uid, info.st_gid)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.zizi-catalog-', delete=False) as stream:
            temp = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, stat.S_IMODE(info.st_mode))
        if os.geteuid() == 0:
            os.chown(temp, info.st_uid, info.st_gid)
        if digest(target.read_bytes()) != BASE_SHA256:
            raise RuntimeError('Target changed during update; refusing replacement')
        os.replace(temp, target)
        temp = None
        print('Updated:', target)
        print('Backup:', backup)
        print('No service was restarted. Restart your resolver and check /catalog/health.')
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


if __name__ == '__main__': main()
