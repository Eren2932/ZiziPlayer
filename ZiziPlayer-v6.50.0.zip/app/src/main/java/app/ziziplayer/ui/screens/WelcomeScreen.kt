package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette

/**
 * 6.50.0 — приветствие про аккаунты. Первый и единственный раз, дальше решает [app.ziziplayer.account.AccountGate].
 *
 * ГЛАВНОЕ ПРАВИЛО ЭТОГО ЭКРАНА: НЕ ОБЕЩАТЬ ТО, ЧЕГО ПОКА НЕТ
 *
 * Окно входа нарисовать легко, сохранность данных — нет. Поэтому текст здесь говорит о том, ЗАЧЕМ
 * аккаунт, и прямо сообщает, что сейчас медиатека хранится только на телефоне. Когда сервис
 * аккаунтов подключён ([signInOffered]), появляется рабочая кнопка входа. Когда не подключён —
 * строка «готовится», а не кнопка-обманка: кнопка, которая ничего не делает, читается как
 * поломка приложения, и человек перестаёт верить и остальным его обещаниям.
 *
 * Гостевой режим — полноценный выход, а не отказ. Он стоит второй кнопкой, но не спрятан и не
 * окрашен как ошибка: до этой версии все жили именно так, и называть это «неправильным выбором»
 * было бы неуважением к тем, кто годами пользовался плеером без всяких аккаунтов.
 *
 * Экран НИЧЕГО не делает с данными: ни строки в Room, ни одного сетевого запроса. Он только
 * записывает решение человека.
 */
@Composable
fun WelcomeScreen(
    signInOffered: Boolean,
    onSignIn: () -> Unit,
    onGuest: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(p.brand),
            contentAlignment = Alignment.Center
        ) {
            Icon(ZiziIcons.Library, contentDescription = null, tint = p.onBrand, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(
            "Твоя музыка — с тобой",
            color = p.text,
            fontSize = 27.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Аккаунт нужен для одного: чтобы избранное и плейлисты не исчезали после " +
                "переустановки приложения или переезда на другой телефон.",
            color = p.subtext,
            fontSize = 15.sp
        )
        Spacer(Modifier.height(28.dp))

        WelcomeFact(
            icon = ZiziIcons.CloudCheck,
            title = "Сохраняются списки, а не файлы",
            text = "В аккаунт попадают избранное, плейлисты и настройки. Сами аудиофайлы с телефона никуда не загружаются."
        )
        WelcomeFact(
            icon = ZiziIcons.Phone,
            title = "Сейчас всё хранится на телефоне",
            text = "Пока вход не подключён, очистка данных приложения удалит медиатеку. Именно это и решают аккаунты."
        )
        WelcomeFact(
            icon = ZiziIcons.Check,
            title = "Перенос будет с подтверждением",
            text = "Когда вход заработает, приложение сначала покажет, что именно переносит, и спросит согласие."
        )

        Spacer(Modifier.height(28.dp))

        if (signInOffered) {
            WelcomeButton(
                label = "Войти в аккаунт",
                primary = true,
                onClick = onSignIn
            )
            Spacer(Modifier.height(12.dp))
            WelcomeButton(
                label = "Продолжить как гость",
                primary = false,
                onClick = onGuest
            )
        } else {
            // Сервиса нет: единственное рабочее действие — продолжить. Оно и стоит главной кнопкой.
            WelcomeButton(
                label = "Продолжить",
                primary = true,
                onClick = onGuest
            )
            Spacer(Modifier.height(14.dp))
            Text(
                "Вход в аккаунт ещё не подключён в этой сборке. Он появится в настройках, " +
                    "когда сервис аккаунтов будет готов — приложение сообщит об этом само.",
                color = p.subtext,
                fontSize = 12.5.sp
            )
        }
        Spacer(Modifier.height(24.dp))
        Spacer(Modifier.navigationBarsPadding())
    }
}

/** Одна строка «почему»: иконка, короткий заголовок, объяснение без обещаний. */
@Composable
private fun WelcomeFact(icon: ImageVector, title: String, text: String) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(text, color = p.subtext, fontSize = 13.sp)
        }
    }
}

/**
 * Кнопка приветствия. Своя, а не material3 Button: у плеера один язык поверхностей, и фирменная
 * оранжевая плашка с радиусом 16 dp здесь та же, что в остальном приложении.
 */
@Composable
private fun WelcomeButton(label: String, primary: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (primary) p.brand else p.chip.copy(alpha = 0.55f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (primary) p.onBrand else p.text,
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
