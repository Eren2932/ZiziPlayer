package app.ziziplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.CollectionGeometry as G
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.roundToInt

/** Slot-based collection destination: one scroller, one measured hero, one Play.
 * Coordinates are pixels BELOW status bars; font scale changes remeasure the hero.
 * It is independent of track type and can also host remote collection rows later.
 */
@Composable
internal fun PinnedCollectionScaffold(
    destination: String,
    title: String,
    tint: Color,
    trackCount: Int,
    playingHere: Boolean,
    playEnabled: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    hero: @Composable () -> Unit,
    collectionRows: LazyListScope.() -> Unit
) {
    val p = LocalPalette.current
    val base = Color(0xFF121212)
    val density = LocalDensity.current
    val list = rememberSaveable(destination, saver = LazyListState.Saver) { LazyListState() }
    var heroPx by remember(destination, density.fontScale) { mutableIntStateOf(0) }
    BoxWithConstraints(Modifier.fillMaxSize().background(base)) {
        val status = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val toolbar = 56.dp
        val playSize = 56.dp
        val toolbarPx = with(density) { toolbar.toPx() }
        val playPx = with(density) { playSize.toPx() }
        val playBottomGapPx = with(density) { 16.dp.toPx() }
        val pinnedPx = toolbarPx - playPx / 2f
        val expandedPx = (heroPx - playPx - playBottomGapPx).coerceAtLeast(pinnedPx)
        val bottom = LocalBottomChromeInset.current + 24.dp
        // The production row is at least G.ROW units high. This gives even a
        // 1-track selection enough scroll room, without a viewport of empty tail
        // after a long collection. Larger text only makes the body taller.
        val minimumRows = (G.ROW * maxWidth.value / G.REFERENCE_WIDTH).dp * trackCount
        val tail = G.minimumPinnedTail((maxHeight - status).value, minimumRows.value, bottom.value,
            playSize.value, 16f, (toolbar - playSize / 2).value).dp
        fun scrollPx(): Float = if (list.firstVisibleItemIndex == 0)
            list.firstVisibleItemScrollOffset.toFloat() else heroPx.toFloat()
        fun collapse(): Float {
            val travel = (expandedPx - pinnedPx).coerceAtLeast(1f)
            return G.smoothstep(((scrollPx() / travel) - 0.55f) / 0.45f)
        }
        val toolbarVisibleForSemantics by remember(list, heroPx, density) {
            derivedStateOf { scrollPx() >= expandedPx - pinnedPx }
        }
        Box(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(tint))
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            LazyColumn(state = list, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottom)) {
                item(key = "selection:hero", contentType = "hero") {
                    Column(Modifier.fillMaxWidth().onSizeChanged { heroPx = it.height }) { hero() }
                }
                collectionRows()
                item(key = "selection:tail", contentType = "spacer") { Spacer(Modifier.height(tail)) }
            }
            Box(Modifier.fillMaxWidth().height(toolbar)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .clearAndSetSemantics { }
                .graphicsLayer { alpha = collapse() }.background(tint))
            Row(Modifier.fillMaxWidth().height(toolbar).padding(start = 6.dp, end = 80.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                    Icon(ZiziIcons.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.size(28.dp))
                }
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(start = 8.dp).graphicsLayer { alpha = collapse() }
                        .then(if (toolbarVisibleForSemantics) Modifier else Modifier.clearAndSetSemantics {}))
            }
            // One instance moves in placement; no second button/crossfade to steal taps.
            IconButton(onClick = onPlay, enabled = playEnabled && heroPx > 0,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = 16.dp)
                    .offset { IntOffset(0, G.pinnedPlayTop(scrollPx(), expandedPx, pinnedPx).roundToInt()) }
                    .graphicsLayer { alpha = if (heroPx > 0) 1f else 0f }
                    .size(playSize).clip(CircleShape).background(if (playEnabled) p.brand else p.chip)) {
                Icon(if (playingHere) ZiziIcons.Pause else ZiziIcons.CollectionPlayFilled,
                    if (playingHere) "Пауза" else "Слушать подборку", tint = Color.Black,
                    modifier = Modifier.size(if (playingHere) 26.dp else playSize))
            }
        }
    }
}
