package app.ziziplayer.account;

/**
 * Проверки правил аккаунта. Исполняется ПРОДАКШЕН-класс, а не его пересказ на другом языке.
 *
 * Здесь проверяется только то, что решает [AccountGate]: показывать ли приветствие, предлагать
 * ли вход, принимать ли адрес сервиса. Сохранность данных, перенос библиотеки и синхронизация
 * этими проверками НЕ покрыты — их ещё не существует.
 */
public final class AccountGateChecks {

    private static int checks = 0;

    private static void check(boolean condition, String what) {
        checks++;
        if (!condition) throw new AssertionError("FAILED: " + what);
    }

    public static void main(String[] args) {
        // Новая установка и старый пользователь после обновления: окно один раз.
        check(AccountGate.shouldShowWelcome(AccountGate.Mode.UNDECIDED, 0),
                "undecided sees the welcome screen");

        // Выбор гостя уважаем: второй раз тем же окном не спрашиваем.
        check(!AccountGate.shouldShowWelcome(AccountGate.Mode.GUEST, AccountGate.WELCOME_REVISION),
                "guest who saw the current welcome is not asked again");

        // Гость, чья отметка старше текущего приветствия, увидит НОВОЕ сообщение один раз.
        check(AccountGate.shouldShowWelcome(AccountGate.Mode.GUEST, AccountGate.WELCOME_REVISION - 1),
                "guest with an older revision sees a new announcement");

        // Вошедшему окно не показывается никогда, какой бы ни была отметка.
        check(!AccountGate.shouldShowWelcome(AccountGate.Mode.SIGNED_IN, 0),
                "signed-in user never sees the welcome screen");
        check(!AccountGate.shouldShowWelcome(AccountGate.Mode.SIGNED_IN, AccountGate.WELCOME_REVISION),
                "signed-in user never sees the welcome screen, any revision");

        // Главная защита 6.50.0: без реализованного входа кнопка не появляется даже с адресом.
        check(!AccountGate.signInOffered(true),
                "sign-in is not offered while SIGN_IN_IMPLEMENTED is false");
        check(!AccountGate.signInOffered(false),
                "sign-in is not offered without a service address");

        // Адрес: только https, только непустой хост, хвостовой слэш снимается.
        check(AccountGate.normalizeServiceUrl("https://accounts.example.org")
                .equals("https://accounts.example.org"), "https address is accepted");
        check(AccountGate.normalizeServiceUrl("https://accounts.example.org/")
                .equals("https://accounts.example.org"), "trailing slash is trimmed");
        check(AccountGate.normalizeServiceUrl("  https://accounts.example.org  ")
                .equals("https://accounts.example.org"), "surrounding spaces are trimmed");
        check(AccountGate.normalizeServiceUrl("HTTPS://accounts.example.org")
                .equals("HTTPS://accounts.example.org"), "scheme case is accepted");
        check(AccountGate.normalizeServiceUrl("http://accounts.example.org").isEmpty(),
                "http is refused: session identifiers would travel in the clear");
        check(AccountGate.normalizeServiceUrl("accounts.example.org").isEmpty(),
                "a bare host is refused");
        check(AccountGate.normalizeServiceUrl("https://").isEmpty(),
                "an empty host is refused");
        check(AccountGate.normalizeServiceUrl("https:// broken").isEmpty(),
                "a host with a space is refused");
        check(AccountGate.normalizeServiceUrl("").isEmpty(), "an empty address means no service");
        check(AccountGate.normalizeServiceUrl(null).isEmpty(), "null means no service");

        System.out.println("AccountGateChecks: " + checks + " checks passed");
    }
}
