# ZiziPlayer — Android 6.49.0 / сервер 1.12

**Кандидат исходников: versionCode 99, versionName 6.49.0. Это ZIP проекта, не собранный APK.**
Основа мобильного проекта — 6.48.1 / 98. Работа над главной, рекомендациями, волной и экраном
текста сохранена после прерывания; подробности: [RELEASE_v6.49.0.md](RELEASE_v6.49.0.md).

**Рабочая и основная серверная версия — 1.12-fallback-match**, подтверждена владельцем.
Настоящий `server/zizi_catalog.py` 1.12 включён в комплект из опубликованного серверного ZIP.
Это не 1.11 с новым названием. Синхронизация и ограничения: [SERVER_SYNC_1.12.md](SERVER_SYNC_1.12.md).
Если на VPS уже работает 1.12, повторный деплой не нужен. APK сам сервер не обновляет.
В ручной диагностике приложение читает реальную версию через `/catalog/health`.

## Сборка и установка

Загрузить **один `ZiziPlayer-v6.49.0.zip`** в корень main репозитория. Если ранее загружен
другой ZIP с versionCode 99, заменить его, а не держать две различные версии с одним кодом.
Существующий корневой GitHub Actions workflow выбирает максимальный versionCode.
Дождаться зелёных JVM-тестов и assembleRelease; установить APK с прежней подписью,
не удаляя данные приложения. SDK 36, JDK 17, Gradle 8.11.1.

````bash
python3 tools/check_selftest.py
gradle --no-daemon :app:testDebugUnitTest :app:assembleRelease --stacktrace
````

Локальные проверки: `verification/v6.49.0/results.json` (повторены после интеграции 1.12).
Android/Kotlin/Compose-компиляция, запуск APK, аудио и pixel-perfect сравнение здесь не выполнены.
Приёмка на устройстве: [DEVICE_CHECKLIST_v6.49.0.md](DEVICE_CHECKLIST_v6.49.0.md).
Исторические CHANGELOG/RELEASE/verification сохранены как история, не текущая инструкция.
