#!/usr/bin/env python3
"""Run actual production parser/clock Java. Not Android playback or Kotlin compilation."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='lyrics645-') as out:
    paths = ['app/src/main/java/app/ziziplayer/lyrics/LrcTimeline.java',
             'app/src/test/java/app/ziziplayer/lyrics/Lyrics645Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                    *[str(ROOT / p) for p in paths]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.lyrics.Lyrics645Checks'], check=True)
