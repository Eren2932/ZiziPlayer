#!/usr/bin/env python3
"""Source integration checks only; not a Kotlin compiler or device UI test."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/ziziplayer/ui'
def read(name): return (UI/name).read_text()
class PolishContracts(unittest.TestCase):
    def test_no_synthetic_track_colours_or_duplicate_placeholder(self):
        s = read('components/Artwork.kt')
        for old in ('fallbackSwatches', 'fallbackColors', 'HSVToColor', 'Brush.linearGradient'):
            self.assertNotIn(old, s)
        self.assertEqual(s.count('private fun MissingArtwork('), 1)
        self.assertEqual(s.count('MissingArtwork(glyphSize)'), 2)
        self.assertIn('drawRect(MissingArtworkSurface)', s)
        self.assertIn('drawPath(path, ink)', s)
        body = s.split('fun rememberArtSwatches(')[1].split('private fun notePath')[0]
        self.assertIn('else -> null', body)
    def test_same_measured_toolbar_in_both_modes(self):
        s = read('screens/LocalCollectionScreen.kt')
        for part in ('val toolbarHeight = (G.TOOLBAR * unit).dp.coerceAtLeast(48.dp)',
                     'animationSpec = tween(160)', 'selectionHeader(toolbarHeight)',
                     'modifier = Modifier.fillMaxWidth().height(toolbarHeight)'):
            self.assertIn(part, s)
        self.assertNotIn('selectionHeader()', s)
        library = read('screens/LibraryScreen.kt')
        self.assertIn('height = toolbarHeight', library)
        for label in ('Закрыть выбор', 'Выбрать все', 'Слушать выбранные', 'Добавить выбранные в избранное',
                      'Добавить выбранные в плейлист', 'Действия с выбранными'):
            self.assertIn(label, library)
    def test_custom_selection_vectors_use_pathbuilder_not_canvas_api(self):
        s = read('components/ZiziIcons.kt').split('private const val STROKE')[0]
        for name in ('Close', 'All', 'Play', 'Favorite', 'Add', 'More'):
            self.assertIn('val Selection' + name + ' by lazy', s)
        self.assertNotIn('cubicTo(', s)
        self.assertNotIn('quadraticBezierTo(', s)
    def test_download_progress_is_real_and_unknown_length_is_indeterminate(self):
        s = read('screens/LocalCollectionScreen.kt').split('private fun CollectionDownloadDialog(')[1]
        for text in ('CollectionDownloadProgress.fraction(done, unique.size, runningPercent)',
                     'it.percent < 0', 'if (statuses == null || unknownSize)', 'progress = { animatedProgress.value }',
                     'withContext(Dispatchers.IO)', 'vm.downloadCollection(unique)',
                     'vm.cancelCollectionDownloads(unique)', 'Dialog(onDismissRequest = onDismiss)'):
            self.assertIn(text, s)
        self.assertNotIn('AlertDialog(', s)
        self.assertNotIn('если Android не разрешит', s)
    def test_prefetch_empty_list_clears_resume_snapshot(self):
        s = read('components/Artwork.kt').split('fun submit(context: Context, tracks: List<TrackEntity>)')[1]
        self.assertLess(s.index('lastTracks = tracks'), s.index('if (tracks.isEmpty()) return'))
        self.assertLess(s.index('job = null'), s.index('if (tracks.isEmpty()) return'))
    def test_no_legacy_detail_scroll_observers_and_correct_prefetch_identity(self):
        s = read('screens/LibraryScreen.kt')
        self.assertIn('LaunchedEffect(listState, detailPage)', s)
        self.assertIn('if (detailPage) return@LaunchedEffect', s)
        self.assertEqual(s.count('snapshotFlow { listState.'), 1)
        self.assertIn('remember(state.visible) { state.visible.map { it.id } }', s)
        self.assertNotIn('state.visible.size to state.visible.firstOrNull()?.id', s)
    def test_all_tracks_card_has_stable_colour(self):
        s = read('screens/LibraryScreen.kt').split('private fun LibraryCardCover(')[1]
        self.assertIn('card.kind == CardKind.TRACKS -> Box(', s)
        self.assertIn('background(Color(0xFF345B79))', s)
    def test_toolbar_geometry_at_phone_widths(self):
        # Layout budget check, not execution of Compose measurement.
        for width in (320, 344, 360, 384, 393, 412, 480):
            button = 40 if width < 360 else 48
            self.assertGreaterEqual(width - 8 - 6 * button, 64)
if __name__ == '__main__': unittest.main(verbosity=2)
