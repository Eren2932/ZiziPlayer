#!/usr/bin/env python3
"""Source integration contracts, NOT execution of Kotlin/Compose."""
from pathlib import Path
import os
import unittest
ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
APP = ROOT / 'app/src/main/java/app/ziziplayer'
def read(name): return (APP / name).read_text()
def block(s, start, end): return s.split(start, 1)[1].split(end, 1)[0]

class ArtworkUiContracts(unittest.TestCase):
    def test_palette_calls_verified_core_and_has_no_old_ceiling(self):
        s = block(read('ui/theme/ZiziTheme.kt'), 'fun ZiziPalette.tintedWith(', '/**\n * The accent drives')
        self.assertIn('ArtworkColorMath.backdrop(primary)', s)
        self.assertNotIn('peakCeiling', s)
        self.assertIn('glowStrength = 0f', s)
        self.assertIn('if (swatches == null || tintStrength <= 0.01f) return this', s)
    def test_primary_not_averaged_with_rival_swatches(self):
        s = block(read('ui/theme/ZiziTheme.kt'), 'private fun readCover(', '/**\n * Real dominant')
        self.assertIn('swatches.primary.toOklch()', s)
        self.assertNotIn('swatches.secondary', s)
    def test_main_and_swipe_keep_same_palette_path(self):
        for name in ('MainActivity.kt', 'ui/screens/PlayerScreen.kt'):
            self.assertIn('basePalette().tintedWith(swatches).withAccent(swatches)', read(name))
        self.assertIn('rememberArtSwatches(current, library.settings.accentFromArtwork)', read('MainActivity.kt'))
    def test_swipe_uses_only_cached_colours(self):
        s = block(read('ui/screens/PlayerScreen.kt'), 'fun paletteOf(', 'if (queue.isNotEmpty())')
        self.assertIn('ArtworkCache.peekSwatches(track)', s)
        self.assertNotIn('load(', s)
    def test_sampler_is_serial_off_main_and_rechecks_cache(self):
        s = read('ui/components/Artwork.kt')
        self.assertIn('private val swatchGate = Semaphore(1)', s)
        part = block(s, 'private suspend fun finishId(', '// ---------------- covers')
        self.assertIn('swatchGate.withPermit', part)
        self.assertIn('withContext(Dispatchers.Default)', part)
        self.assertEqual(part.count('swatchMemory.get(id)'), 2)
    def test_sample_bound_and_visible_crop(self):
        s = block(read('ui/components/Artwork.kt'), 'private fun sample(', '// ---------------- sources')
        self.assertIn('minOf(bitmap.width, bitmap.height)', s)
        self.assertIn('minOf(side, ArtworkColorMath.SAMPLE_SIDE)', s)
        self.assertIn('IntArray(samples * samples)', s)
        self.assertIn('val left = (bitmap.width - side) / 2', s)
        self.assertIn('val top = (bitmap.height - side) / 2', s)
    def test_hardware_bitmap_fallback_is_preserved(self):
        s = read('ui/components/Artwork.kt')
        self.assertIn('cfg == Bitmap.Config.HARDWARE', s)
        self.assertIn('copy(Bitmap.Config.ARGB_8888, false)', s)
        self.assertIn('if (soft !== source) soft.recycle()', s)
    def test_only_color_verdicts_are_versioned(self):
        s = read('ui/components/Artwork.kt')
        self.assertIn('ArtworkColorMath.SWATCH_VERSION};', s)
        self.assertIn('!raw.startsWith(prefix)', s)
        self.assertIn('no_art_ids_v2', read('ui/components/ArtworkIndex.kt'))
        self.assertIn('File(base, "${hashOf(id)}-$px.webp")', s)
    def test_menu_header_is_neutral_and_loads_cover_once(self):
        s = block(read('ui/screens/TrackMenuComponents.kt'), 'internal fun TrackMenuHeader(', '@Composable\ninternal fun TrackMenuQuickActions')
        self.assertEqual(s.count('TrackArtwork('), 1)
        for obsolete in ['rememberArtwork(', 'ArtworkColorMath.cardTop', 'Animatable(', 'Brush.', 'backgroundTop']:
            self.assertNotIn(obsolete, s)
        self.assertIn('maxPx = ARTWORK_ROW_PX', s)
        self.assertIn('Modifier.size(64.dp)', s)
        self.assertNotIn('allowSlow = true', s)
        self.assertNotIn('ARTWORK_FULL_PX', s)
        sheet = block(read('ui/screens/Sheets.kt'), 'fun TrackMenuSheet(', 'fun TrackInfoSheet(')
        self.assertIn('CompositionLocalProvider(LocalPalette provides basePalette())', sheet)
    def test_backdrop_caches_shader_without_frame_composition(self):
        s = block(read('ui/theme/ZiziTheme.kt'), 'fun ZiziBackdrop(', '@Composable\nfun ZiziTheme')
        self.assertIn('.drawWithCache {', s)
        self.assertIn('onDrawBehind {', s)
        self.assertIn('blendOklch', s)
        self.assertNotIn('rememberInfiniteTransition', s)
        self.assertNotIn('extract(', s)
    def test_loading_gates_and_scroll_pause_preserved(self):
        s = read('ui/components/Artwork.kt')
        for text in ('netGate = Semaphore(2)', 'diskGate = Semaphore(3)', 'remoteDiskGate = Semaphore(2)',
                     'prefetchGate = Semaphore(1)', 'if (!allowSlow) ArtworkCache.awaitIdle()',
                     'inflight.computeIfAbsent(k)', 'noArt.contains(track.id)', 'if (!track.isRemote'):
            self.assertIn(text, s)
    def test_real_jvm_and_source_tests_are_connected(self):
        s = (ROOT / 'tools/check_selftest.py').read_text()
        self.assertIn('test_artwork_color_math.py', s)
        self.assertIn('test_artwork_ui_contracts.py', s)
        self.assertIn('ArtworkColorMathChecks.runAll()', (ROOT / 'app/src/test/java/app/ziziplayer/ui/ArtworkColorMathTest.kt').read_text())

if __name__ == '__main__': unittest.main(verbosity=2)
