#!/usr/bin/env python3
"""Payload integrity + offline real Python health, and separate Android source contracts."""
from pathlib import Path
import hashlib
import sys
import tempfile
import unittest
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/tools'))
import test_strict_match as strict

class Bundle112Tests(unittest.TestCase):
    def test_exact_user_supplied_runtime(self):
        self.assertEqual(hashlib.sha256((ROOT/'server/zizi_catalog.py').read_bytes()).hexdigest(),
                         '4a7f0d05bcd3e75a8ec29c4a842a3b2eb0f7ceb373866461994a6c6d1c1d86b7')

    def test_real_catalog_health_reports_actual_policy(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(strict.c, 'DB_PATH', tmp + '/catalog.db'):
                for enabled in (False, True):
                    with patch.object(strict.c, 'FALLBACK', enabled):
                        health = strict.c.catalog_health()
                        self.assertEqual(health['version'], '1.12-fallback-match')
                        self.assertEqual(health['match_policy'], 4)
                        self.assertTrue(health['strict_default'])
                        self.assertEqual(health['fallback'], enabled)

    def test_android_version_is_live_not_a_hardcoded_claim(self):
        source=(ROOT/'app/src/main/java/app/ziziplayer/data/remote/ZiziResolve.kt').read_text()
        health=source[source.index('    suspend fun health():'):]
        self.assertIn('"/catalog/health"', health)
        self.assertIn('catalog.optString("version", "не указана")', health)
        self.assertIn('catalog.has("fallback")', health)
        self.assertIn('версия каталога недоступна', health)
        self.assertEqual(health.count('catch (e: CancellationException)'), 2)
        self.assertNotIn('1.11', health)
        self.assertNotIn('1.12', health)
        self.assertEqual(health.count('ZiziHttp.getJson('), 2)

    def test_client_accepts_server_selected_video_without_confidence_gate(self):
        source=(ROOT/'app/src/main/java/app/ziziplayer/data/remote/DeezerCatalog.kt').read_text()
        start=source.index('    override suspend fun resolveStream(')
        end=source.index('\n}\n',start)
        method=source[start:end]
        self.assertIn('response.optString("vid")',method)
        self.assertIn('ZiziResolve.resolve(videoId, quality)',method)
        self.assertNotIn('optBoolean("confident"',method)

if __name__ == '__main__':
    unittest.main(verbosity=2)
