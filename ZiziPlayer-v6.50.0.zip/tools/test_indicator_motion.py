#!/usr/bin/env python3
"""Compile and run production Java motion math; not Compose/device execution."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-motion-') as output:
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                    str(ROOT/'app/src/main/java/app/ziziplayer/ui/components/IndicatorMotion.java'),
                    str(ROOT/'app/src/test/java/app/ziziplayer/ui/components/IndicatorMotionChecks.java')], check=True)
    subprocess.run(['java', '-cp', output, 'app.ziziplayer.ui.components.IndicatorMotionChecks'], check=True)
