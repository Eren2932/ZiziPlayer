#!/usr/bin/env python3
"""Execute the production Java trace; no Android timing or live provider claims."""
from pathlib import Path
import subprocess
import tempfile
R = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='startup646-') as out:
    sources = ['app/src/main/java/app/ziziplayer/playback/StartupTrace.java',
               'app/src/test/java/app/ziziplayer/playback/Startup646Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                    *[str(R / p) for p in sources]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.playback.Startup646Checks'], check=True)
