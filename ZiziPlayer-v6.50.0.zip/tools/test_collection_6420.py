#!/usr/bin/env python3
"""Compile and execute production Java, not a Python copy of the formulas."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-collection-') as output:
    files = ['app/src/main/java/app/ziziplayer/ui/CollectionGeometry.java',
             'app/src/main/java/app/ziziplayer/playback/DownloadBatchPolicy.java',
             'app/src/test/java/app/ziziplayer/ui/Collection6420Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                    *[str(ROOT / path) for path in files]], check=True)
    subprocess.run(['java', '-cp', output, 'app.ziziplayer.ui.Collection6420Checks'], check=True)
