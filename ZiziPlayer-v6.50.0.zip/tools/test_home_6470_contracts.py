#!/usr/bin/env python3
"""Source wiring and actual SQLite DDL/queries. NOT Room/Kotlin/Compose execution."""
from pathlib import Path
import ast
import json
import re
import sqlite3
import unittest

R = Path(__file__).resolve().parents[1]
J = R / 'app/src/main/java/app/ziziplayer'
def read(p): return (J / p).read_text()

def migration_sql(version):
    source = read('data/ZiziDatabase.kt')
    block = source.split(f'val MIGRATION_{version} =', 1)[1].split('\n        val MIGRATION_', 1)[0]
    calls = re.findall(r'db\.execSQL\(\s*((?:"(?:[^"\\]|\\.)*"\s*\+?\s*)+)\)', block)
    return [''.join(json.loads(x) for x in re.findall(r'"(?:[^"\\]|\\.)*"', c)) for c in calls]

def setup_old_database():
    db = sqlite3.connect(':memory:')
    # Fixture for the table columns touched by historical migrations, not a Room schema export.
    db.executescript('''
    CREATE TABLE tracks(id TEXT PRIMARY KEY NOT NULL, uri TEXT NOT NULL, title TEXT NOT NULL,
      artist TEXT NOT NULL, album TEXT NOT NULL, durationMs INTEGER NOT NULL, artworkUri TEXT,
      sourceFolder TEXT NOT NULL, dateAdded INTEGER NOT NULL);
    CREATE TABLE favorites(trackId TEXT PRIMARY KEY NOT NULL, addedAt INTEGER NOT NULL);
    CREATE TABLE playlists(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, createdAt INTEGER NOT NULL);
    CREATE TABLE playlist_tracks(playlistId INTEGER NOT NULL, trackId TEXT NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(playlistId,trackId));
    CREATE TABLE track_fx(trackId TEXT PRIMARY KEY NOT NULL, speed REAL NOT NULL, pitch REAL NOT NULL, reverb INTEGER NOT NULL);
    INSERT INTO tracks VALUES('local-1','content://music/1','Song','Artist','Album',60000,NULL,'Music',1);
    INSERT INTO favorites VALUES('local-1',2);
    INSERT INTO playlists VALUES(7,'Keep me',3);
    INSERT INTO playlist_tracks VALUES(7,'local-1',0);
    INSERT INTO track_fx VALUES('local-1',1.0,1.0,0);
    ''')
    for version in ('1_2','2_3','3_4','4_5','5_6','6_7','7_8','8_9'):
        for sql in migration_sql(version): db.execute(sql)
    db.execute("INSERT INTO play_stats VALUES('local-1',42,123456)")
    db.commit()
    return db

def query(method):
    source = read('data/ListeningDao.kt')
    match = re.search(r'@Query\("([^"\n]+)"\)\s+(?:suspend )?fun '+method+r'\(', source)
    assert match, method
    return match.group(1)

class Home647Contracts(unittest.TestCase):
    def test_additive_migration_preserves_every_old_table_and_row(self):
        db = setup_old_database()
        self.addCleanup(db.close)
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        before = {t: db.execute(f'SELECT * FROM {t}').fetchall() for t in tables}
        ddl = db.execute("SELECT name,sql FROM sqlite_master WHERE type IN ('table','index') ORDER BY name").fetchall()
        statements = migration_sql('9_10'); self.assertEqual(len(statements), 5)
        for s in statements: db.execute(s)
        for t, rows in before.items(): self.assertEqual(rows, db.execute(f'SELECT * FROM {t}').fetchall(), t)
        for name, sql in ddl: self.assertEqual(sql, db.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone()[0])
        self.assertEqual(0, db.execute('SELECT COUNT(*) FROM listening_sessions').fetchone()[0])
        self.assertEqual((42,123456), db.execute("SELECT playCount,lastPlayedAt FROM play_stats WHERE trackId='local-1'").fetchone())
        self.assertIn('MIGRATION_9_10', read('ZiziApplication.kt'))
        self.assertIn('version = 10', read('data/ZiziDatabase.kt'))
        self.assertNotIn('fallbackToDestructiveMigration', read('ZiziApplication.kt'))

    def test_new_columns_match_entity_types_nullability_and_primary_keys(self):
        db = setup_old_database()
        self.addCleanup(db.close)
        for sql in migration_sql('9_10'): db.execute(sql)
        entities = read('data/ListeningEntities.kt')
        for table, clazz, primary in [('listening_sessions','ListeningSessionEntity','sessionId'),
                                      ('home_pins','HomePinEntity','playlistId'),('track_catalog','TrackCatalogEntity','trackId')]:
            body = entities.split('data class '+clazz+'(',1)[1].split(')',1)[0]
            declared = {name: (('TEXT' if typ.startswith('String') else 'INTEGER'), int(not typ.endswith('?')))
                        for name,typ in re.findall(r'val (\w+): (\w+\??)',body)}
            actual = {r[1]: (r[2],r[3]) for r in db.execute(f'PRAGMA table_info({table})')}
            self.assertEqual(declared, actual)
            for r in db.execute(f'PRAGMA table_info({table})'):
                self.assertIsNone(r[4], 'No invented SQL defaults')
                self.assertEqual(int(r[1] == primary), r[5])
        self.assertEqual({'index_listening_sessions_trackId','index_listening_sessions_startedAt'},
                         {r[1] for r in db.execute('PRAGMA index_list(listening_sessions)') if r[3] != 'pk'})

    def test_recovery_retention_and_clear_execute_production_queries(self):
        db = setup_old_database()
        self.addCleanup(db.close)
        for sql in migration_sql('9_10'): db.execute(sql)
        def put(sid,at,outcome):
            db.execute('INSERT INTO listening_sessions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                (sid,'local-1','Song','Artist',None,'local','Music',at,at+4000,None,60000,4000,4000,4000,0,0,outcome))
        put('old',1,'ended'); put('live',500,'active'); put('recent',1000,'skipped')
        db.execute(query('recoverInterrupted'))
        self.assertEqual(('interrupted',4500),db.execute("SELECT outcome,endedAt FROM listening_sessions WHERE sessionId='live'").fetchone())
        db.execute(query('trim'),{'before':400})
        self.assertEqual(2,db.execute('SELECT COUNT(*) FROM listening_sessions').fetchone()[0])
        db.execute(query('clearHistory'))
        self.assertEqual(0,db.execute('SELECT COUNT(*) FROM listening_sessions').fetchone()[0])
        self.assertEqual(42,db.execute('SELECT playCount FROM play_stats').fetchone()[0])

    def test_service_owns_clock_and_vm_no_longer_counts(self):
        service = read('playback/PlaybackService.kt'); manager = read('listening/ListeningManager.kt')
        self.assertEqual(1, service.count('app.ziziplayer.listening.ListeningManager('))
        self.assertIn('listening?.checkpoint()',service)
        self.assertLess(service.index('listening?.close()'),service.index('scope.cancel()'))
        self.assertIn('player.addListener(this)',manager); self.assertIn('player.removeListener(this)',manager)
        self.assertNotIn('delay(',manager)
        self.assertNotIn('repo.registerPlay(',read('ui/MainViewModel.kt'))
        self.assertNotIn('lastRegisteredPlay',read('ui/MainViewModel.kt'))
        self.assertIn('ListeningClock',manager)

    def test_idempotency_and_clear_barrier_are_wired(self):
        dao = read('data/ListeningDao.kt'); store = read('listening/ListeningStore.kt')
        self.assertIn('@Transaction\n    suspend fun checkpoint',dao)
        self.assertIn('row.qualified && previous?.qualified != true',dao)
        self.assertLess(dao.index('countQualified(row.trackId'),dao.index('putSession(row)'))
        self.assertIn('ownerGeneration != generation',store)
        self.assertIn('work.first == generation',store)
        self.assertIn('generation += 1; pending.clear()',store)
        self.assertIn('Channel.CONFLATED',store)
        self.assertIn('pending.size >= 256',store)
        self.assertIn('Dispatchers.IO',store)

    def test_home_is_separate_and_has_real_destinations(self):
        tab = read('ui/components/TabBar.kt'); activity = read('MainActivity.kt')
        self.assertLess(tab.index('HOME("'),tab.index('SEARCH("')); self.assertLess(tab.index('SEARCH("'),tab.index('LIBRARY("'))
        for token in ('HomeScreen(', 'vm.openPlaylist(id)', 'LibraryFilter.FAVORITES', 'vm.openArtist(artist)', 'homeVm.back()'):
            self.assertIn(token,activity)
        home = read('ui/HomeViewModel.kt')
        self.assertIn('OfflineDownloads.isComplete',home)
        self.assertIn('dao.observeSessions()',home)
        self.assertIn('WhileSubscribed(5000)',home)
        self.assertNotIn('ZiziResolve',home); self.assertNotIn('registerPlay',home)
        self.assertIn('raw.vaultFolders == gate.folders',read('ui/screens/HomeScreen.kt'))
        self.assertIn('folder !in protectedFolders()',read('listening/ListeningManager.kt'))

    def test_metadata_is_optional_and_old_servers_still_parse(self):
        catalog = read('data/remote/DeezerCatalog.kt')
        for name in ('artist_id','album_id','isrc'): self.assertIn('optString("'+name+'")',catalog)
        for field in ('catalogArtistId','catalogAlbumId','isrc'):
            self.assertIn('val '+field+': String? = null',read('data/remote/RemoteModels.kt'))
        self.assertIn('track.catalogArtistId ?: old?.artistId',read('data/MusicRepository.kt'))
        module = ast.parse((R/'server/zizi_catalog.py').read_text())
        fn = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'dz_track')
        ns = {}; exec(compile(ast.Module(body=[fn],type_ignores=[]),'production-dz-track','exec'),ns)
        row = ns['dz_track']({'id':1,'artist':{'id':2,'name':'A'},'album':{'id':3},'isrc':'X'})
        self.assertEqual(('2','3','X'),(row['artist_id'],row['album_id'],row['isrc']))
        row = ns['dz_track']({'id':1})
        self.assertIsNone(row['artist_id']); self.assertIsNone(row['album_id'])

if __name__ == '__main__': unittest.main(verbosity=2)
