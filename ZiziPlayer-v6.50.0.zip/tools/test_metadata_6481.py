#!/usr/bin/env python3
"""Execute production Java rules + narrow source contracts; not Android runtime."""
from pathlib import Path
import subprocess
import tempfile
R=Path(__file__).resolve().parents[1]
S=R/'app/src/main/java/app/ziziplayer'
with tempfile.TemporaryDirectory() as out:
    sources=[S/'lyrics/LyricsMatchPolicy.java',S/'lyrics/LrcTimeline.java',S/'playback/StartupTrace.java',
             R/'app/src/test/java/app/ziziplayer/lyrics/Metadata6481Checks.java']
    subprocess.run(['java','com.sun.tools.javac.Main','-d',out,*map(str,sources)],check=True)
    subprocess.run(['java','-cp',out,'app.ziziplayer.lyrics.Metadata6481Checks'],check=True)
vm=(S/'ui/MainViewModel.kt').read_text()
assert 'withTimeoutOrNull(45_000L)' in (S/'ui/screens/LyricsUiState.kt').read_text()
assert 'withTimeoutOrNull(8_000L)' in vm and 'LyricsRepository.AudioBusy()' in vm
repo=(S/'lyrics/LyricsRepository.kt').read_text()
assert 'error is AudioBusy -> 5_000L' in repo
assert 'LyricsMatchPolicy.requiresExactDuration' in repo
assert 'StartupTrace.http(span, r.code)' in repo
policy=(S/'playback/ZiziDataSources.kt').read_text()
assert 'CatalogException.Reason.UNAVAILABLE' in policy and 'return androidx.media3.common.C.TIME_UNSET' in policy
assert 'return super.getRetryDelayMsFor(info)' in policy
print('PASS: bounded wait, exact credit-duration gate, HTTP status, terminal retry wiring')
