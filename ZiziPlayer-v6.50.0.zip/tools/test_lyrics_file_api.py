#!/usr/bin/env python3
"""Regression for 6.44.0's Files.readString Android-test compile failure.

Default: narrow source guard plus compilation/execution of the exact file-read
expression on the host JDK. --android-jar adds real Android bootclasspath checks:
the old API must fail compilation and the fixed expression must compile.
Neither mode is a full Android/Gradle build. No downloads are performed.
"""
import argparse
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app/src/test/java/app/ziziplayer/lyrics/LrcTimelineChecks.java'
BAD_API = re.compile(r'\bFiles\s*\.\s*(?:readString|writeString)\s*\(')


def run(command, **kwargs):
    return subprocess.run(command, capture_output=True, **kwargs)


def probe(expression):
    return '''import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
public final class LyricsFileApiProbe {
    public static void main(String[] args) throws Exception {
        String text = %s;
        System.out.write(text.getBytes(StandardCharsets.UTF_8));
    }
}
''' % expression


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--android-jar', type=Path)
    args = parser.parse_args()
    if args.android_jar and not args.android_jar.is_file():
        parser.error('--android-jar must be an existing Android platform JAR')
    # Ensure the narrow guard would catch the original failure (including spaces).
    for bad in ('Files.readString(Path.of(args[0]))', 'Files . readString (p)',
                'Files.writeString(p, text)'):
        if not BAD_API.search(bad):
            raise AssertionError('API guard missed its negative fixture')
    text = SOURCE.read_text(encoding='utf-8')
    if BAD_API.search(text):
        raise AssertionError('Android test source uses Files.readString/writeString; use explicit UTF-8 + byte APIs')
    expressions = re.findall(r'LrcTimeline\.parse\(([^;\n]*args\[0\][^;\n]*)\)', text)
    if len(expressions) != 1:
        raise AssertionError('Expected one CLI file-read expression; update this regression if the CLI changes')
    expression = expressions[0]
    with tempfile.TemporaryDirectory(prefix='zizi-file-api-') as tmp:
        root = Path(tmp)
        java = root / 'LyricsFileApiProbe.java'
        output = root / 'classes'
        output.mkdir()
        if args.android_jar:
            options = ['-source', '8', '-target', '8', '-Xlint:-options',
                       '-bootclasspath', str(args.android_jar.resolve())]
        else:
            options = ['-source', '17', '-target', '17']
        compiler = ['java', 'com.sun.tools.javac.Main', *options, '-d', str(output), str(java)]
        if args.android_jar:
            java.write_text(probe('Files.readString(Paths.get(args[0]))'), encoding='utf-8')
            negative = run(compiler)
            diagnostic = negative.stderr.decode('utf-8', errors='replace')
            if negative.returncode == 0 or 'readString' not in diagnostic or 'cannot find symbol' not in diagnostic:
                raise AssertionError('Old API did not fail as expected:\n' + diagnostic)
            print('PASS: old Files.readString rejected by Android API compiler')
            print(diagnostic.strip())
        java.write_text(probe(expression), encoding='utf-8')
        compiled = run(compiler)
        if compiled.returncode:
            raise AssertionError(compiled.stderr.decode('utf-8', errors='replace'))
        for name, payload in (
            ('unicode.lrc', '\ufeff[00:01.000]Привет, café, 音楽 🎵\r\n[00:02.500]Вторая строка\n'.encode('utf-8')),
            ('empty.lrc', b''),
        ):
            path = root / name
            path.write_bytes(payload)
            # ASCII default makes accidental reliance on the host default visible.
            result = run(['java', '-Dfile.encoding=US-ASCII', '-cp', str(output),
                          'LyricsFileApiProbe', str(path)])
            if result.returncode or result.stdout != payload:
                raise AssertionError('Explicit UTF-8 round-trip failed: ' + name)
        print('PASS: exact source expression compiled; Unicode/BOM/CRLF and empty-file round-trips')
        if not args.android_jar:
            print('NOTE: host JDK only; Android API compile not run (pass --android-jar to enable)')
    print('PASS: file API regression (not a full APK build)')


if __name__ == '__main__':
    main()
