#!/usr/bin/env python3
"""Narrow source regression for the five 6.46.0 DSL-scope compile errors.

Not a Kotlin compiler or a general Compose receiver checker. Enforces the chosen
fix: capture the live outer width before Column and use it at all five call sites.
Negative mutations ensure reintroducing any reported site fails this guard.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app/src/main/java/app/ziziplayer/ui/screens/LyricsScreen.kt'
METHODS = ('headerFont', 'headerLine', 'headerHeight', 'playDiameter', 'bottomGap')


def width_contract_errors(source):
    # Deliberately scoped to this screen, not the independent LyricsBody viewport.
    screen = source.split('internal fun LyricsScreen(', 1)[1].split('\n@Composable', 1)[0]
    # These markers also fail closed on a structural refactor requiring manual review.
    column = '        Column(Modifier.fillMaxSize()) {'
    if screen.count(column) != 1:
        return ['expected exactly one root Column']
    before, inside = screen.split(column, 1)
    errors = []
    if not re.search(r'^        val screenWidth = maxWidth\s*$', before, re.M):
        errors.append('capture the live width in BoxWithConstraints before Column')
    if re.search(r'\b(?:maxWidth|maxHeight)\b', inside):
        errors.append('outer constraints must not be accessed implicitly inside Column')
    for method in METHODS:
        pattern = r'LyricsGeometry\.' + method + r'\(screenWidth\.value\b'
        if len(re.findall(pattern, inside)) != 1:
            errors.append(method + ' must use the captured outer width exactly once')
    return errors


class Lyrics6461Contracts(unittest.TestCase):
    def test_current_source_uses_live_outer_width(self):
        self.assertEqual(width_contract_errors(SOURCE.read_text()), [])

    def test_each_original_failure_is_rejected(self):
        source = SOURCE.read_text()
        for method in METHODS:
            with self.subTest(method=method):
                good = 'LyricsGeometry.' + method + '(screenWidth.value'
                bad = 'LyricsGeometry.' + method + '(maxWidth.value'
                self.assertEqual(source.count(good), 1)
                self.assertTrue(width_contract_errors(source.replace(good, bad, 1)))

    def test_capture_inside_column_is_rejected(self):
        source = SOURCE.read_text()
        capture = '        val screenWidth = maxWidth\n'
        column = '        Column(Modifier.fillMaxSize()) {\n'
        self.assertIn(capture, source)
        moved = source.replace(capture, '', 1).replace(column, column + '    ' + capture, 1)
        self.assertTrue(width_contract_errors(moved))

    def test_remembered_width_is_rejected(self):
        source = SOURCE.read_text()
        stale = source.replace('val screenWidth = maxWidth',
                               'val screenWidth = remember { maxWidth }', 1)
        self.assertNotEqual(stale, source)
        self.assertTrue(width_contract_errors(stale))

    def test_guard_runs_in_existing_ci_preflight(self):
        self.assertIn("'test_lyrics_6461_contracts.py'", (ROOT / 'tools/check_selftest.py').read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
