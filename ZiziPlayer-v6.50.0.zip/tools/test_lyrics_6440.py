#!/usr/bin/env python3
"""Execute production Java parser/search math; no Android build claims."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-lyrics-') as output:
    files = ['app/src/main/java/app/ziziplayer/lyrics/LrcTimeline.java',
             'app/src/test/java/app/ziziplayer/lyrics/LrcTimelineChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output,
                    *[str(ROOT / path) for path in files]], check=True)
    subprocess.run(['java', '-cp', output, 'app.ziziplayer.lyrics.LrcTimelineChecks'], check=True)

    # Exercise the optional CLI branch that broke Android test compilation.
    fixture = Path(output) / 'fixture.lrc'
    fixture.write_text('[00:01.000]Привет\n[00:02.500]Вторая строка\n', encoding='utf-8')
    subprocess.run(['java', '-cp', output, 'app.ziziplayer.lyrics.LrcTimelineChecks', str(fixture)], check=True)
