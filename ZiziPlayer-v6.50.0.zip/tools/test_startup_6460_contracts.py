#!/usr/bin/env python3
"""Source wiring guards, NOT coroutine/OkHttp runtime execution."""
from pathlib import Path
import unittest
R = Path(__file__).resolve().parents[1]
S = R / 'app/src/main/java/app/ziziplayer'
def read(p): return (S / p).read_text()
class StartupContracts(unittest.TestCase):
    def test_status_calls_use_shared_cancellation_bridge(self):
        s = read('data/remote/ZiziHttp.kt')
        status = s.split('suspend fun getJsonStatus(')[1].split('suspend fun probeStream(')[0]
        self.assertIn('executeParsed(transport.newCall(request))', status)
        self.assertNotIn('.execute()', status)
        self.assertIn('r.code to json', status)
        self.assertRegex(s, r'continuation[.]invokeOnCancellation\s*\{[^}]*call[.]cancel\(\)')
        self.assertIn('executeParsed(call) { response -> parseResponse(response, url) }', s)
    def test_cancellation_cannot_enter_fallback_ladder(self):
        s = read('data/remote/InnertubeCatalog.kt')
        resolve = s.split('override suspend fun resolveStream(')[1].split('\n        ensureVisitor()')[0]
        self.assertRegex(resolve, r'catch \(e: CancellationException\)\s*\{\s*throw e')
    def test_resolver_queue_is_separate_but_connection_pool_inherited(self):
        s = read('data/remote/ZiziHttp.kt')
        self.assertIn('client.newBuilder().dispatcher(Dispatcher()).build()', s)
        self.assertIn('resolverClient.newBuilder()', s)
        self.assertIn('if (request.url.encodedPath == "/resolve") resolverClient else client', s)
    def test_prefetch_waits_for_actual_play_and_excludes_current(self):
        s = read('playback/PlayerController.kt')
        method = s.split('private fun schedulePrefetch()')[1].split('private fun prefetchAhead')[0]
        for token in ('!p.isPlaying', 'prefetchJob?.cancel()', 'delay(1500L)',
                      'queueEpoch == owner.first', 'prefetchAhead(p.currentMediaItemIndex + 1)'):
            self.assertIn(token, method)
        transition = s.split('override fun onMediaItemTransition')[1].split('override fun onEvents')[0]
        queue = s.split('fun setQueue(')[1].split('private fun mediaItemOf')[0]
        self.assertNotIn('prefetchAhead(', transition)
        self.assertNotIn('prefetchAhead(', queue)
        self.assertEqual(s.count('c.addListener(listener)'), 1)
    def test_trace_export_is_local_and_user_initiated(self):
        trace = read('playback/StartupTrace.java')
        for forbidden in ('android.', 'java.io.', 'java.net.', 'new Thread', 'trackId', 'url', 'token'):
            # Headers describe omissions; inspect implementation APIs instead of header words.
            self.assertNotIn(forbidden, trace.split('public final class StartupTrace')[1].split('public static synchronized String snapshot')[0])
        self.assertIn('LIMIT = 128', trace)
        self.assertIn('if (span == null || span.ended) return', trace)
        sheets = read('ui/screens/Sheets.kt')
        self.assertIn('Задержки воспроизведения', sheets)
        self.assertIn('StartupTrace.snapshot()', sheets)
    def test_no_high_frequency_lyrics_updates_during_buffering(self):
        s = read('playback/PlayerController.kt')
        self.assertIn('lyricsClockUsers > 0 && !_state.value.isLoadingAudio', s)
        self.assertIn('enabled = !showLyrics', read('ui/screens/PlayerScreen.kt'))
    def test_new_checks_are_in_ci(self):
        s = (R/'tools/check_selftest.py').read_text()
        self.assertIn("'test_startup_6460.py'", s)
        self.assertIn("'test_startup_6460_contracts.py'", s)
if __name__ == '__main__': unittest.main(verbosity=2)
