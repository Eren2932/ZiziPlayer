#!/usr/bin/env python3
"""Offline source-contract regressions. NOT Kotlin execution, APK or device tests."""
from pathlib import Path
import os
import unittest

ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
APP = ROOT / 'app/src/main/java/app/ziziplayer'

def read(name):
    return (APP / name).read_text()

class LiveUiContracts(unittest.TestCase):
    def test_search_minimum_height_extension_is_imported(self):
        s = read('ui/screens/SearchScreen.kt')
        self.assertIn('.heightIn(', s)
        self.assertIn('import androidx.compose.foundation.layout.heightIn', s)

    def test_settings_has_stable_anchor_and_fixed_navigation(self):
        s = read('ui/screens/Sheets.kt')
        self.assertIn('scrollable = false, modifier = Modifier.fillMaxHeight(0.9f)', s)
        self.assertIn('Modifier.weight(1f).fillMaxWidth().verticalScroll(settingsScroll)', s)
        self.assertIn('contentDescription = "К разделам настроек"', s)

    def test_settings_query_does_not_keep_hidden_section_constraint(self):
        self.assertIn('onText = { query = it; section = null }', read('ui/screens/Sheets.kt'))

    def test_report_does_not_read_files_on_ui_thread(self):
        s = read('ui/screens/Sheets.kt')
        self.assertIn('withContext(Dispatchers.IO) { OfflineStore.report(context.applicationContext) }', s)
        self.assertNotIn('onClick = { downloadsReport = OfflineStore.report(context) }', s)

    def test_crash_report_not_read_during_composition(self):
        self.assertIn('withContext(Dispatchers.IO) { vm.crashReport() }', read('ui/screens/Sheets.kt'))

    def test_wipe_claim_is_atomic(self):
        self.assertIn('_wipe.compareAndSet(previous, WipeProgress(kind = kind, running = true))', read('ui/MainViewModel.kt'))

    def test_wipe_measures_actual_delta(self):
        s = read('ui/MainViewModel.kt')
        self.assertIn('(before - measureBytes()).coerceAtLeast(0L)', s)
        self.assertIn('error = failure', s)
        self.assertNotIn('freedBytes = sizeBefore.coerceAtLeast(0L)', s)

    def test_failed_file_delete_keeps_index(self):
        s = read('playback/OfflineStore.kt').split('fun delete(context:', 1)[1].split('fun deleteAll', 1)[0]
        self.assertIn('!file.delete()) throw IOException', s)
        self.assertLess(s.index('throw IOException'), s.index('forget(context, entry)'))

    def test_individual_delete_is_off_main(self):
        s = read('ui/MainViewModel.kt').split('fun removeDownload(', 1)[1].split('/**', 1)[0]
        self.assertIn('launch(Dispatchers.IO)', s)
        self.assertIn('catch (e: Exception)', s)

    def test_http_cancel_reaches_okhttp(self):
        s = read('data/remote/ZiziHttp.kt')
        self.assertIn('private suspend fun execute(', s)
        self.assertRegex(s, r'continuation[.]invokeOnCancellation\s*\{[^}]*call[.]cancel\(\)')
        self.assertIn('call.enqueue(object : Callback', s)
        self.assertIn('response.close(); return', s)

    def test_preview_does_not_prefetch_audio(self):
        s = read('ui/SearchViewModel.kt').split('fun onField(text:', 1)[1].split('// ---------------------------------------------------------------- searching', 1)[0]
        self.assertIn('delay(220)', s)
        self.assertIn('it.preview(query)', s)
        self.assertNotIn('warmTop(', s)
        self.assertNotIn('rememberRemote(', s)

    def test_preview_stale_answers_are_guarded(self):
        s = read('ui/SearchViewModel.kt')
        self.assertGreaterEqual(s.count('isCurrentSuggestion(query)'), 3)
        self.assertIn('_state.value.stage == SearchStage.SUGGEST && _state.value.field.trim() == query', s)

    def test_preview_metadata_request_is_small(self):
        self.assertIn('browse(prefix, RemoteKind.TRACK, 0, 4)', read('data/remote/DeezerCatalog.kt'))

    def test_preview_reuses_playable_artwork_rows(self):
        s = read('ui/screens/SearchScreen.kt').split('private fun SuggestBody(', 1)[1].split('private fun SuggestRow', 1)[0]
        self.assertIn('ResultTrackRow(', s)
        self.assertIn('onSave = { onSave(track) }', s)
        self.assertIn('"preview:${it.trackId}"', s)

    def test_both_grids_use_parent_width_and_three_columns(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertEqual(2, s.count('MediaGeometry.tile(maxWidth.value).dp'))
        self.assertIn('cards.chunked(MediaGeometry.COLUMNS)', s)
        self.assertIn('tracks.chunked(MediaGeometry.COLUMNS)', s)
        self.assertIn('const val COLUMNS = 3', read('ui/MediaGeometry.kt'))
        self.assertNotIn('chunked(2)', s)

    def test_grid_art_does_not_use_row_decode_size(self):
        self.assertIn('LibraryCardCover(card, width, tile = true)', read('ui/screens/LibraryScreen.kt'))

    def test_track_art_metrics_are_shared(self):
        self.assertIn('private val ART_SIZE = MediaDimensions.trackArt', read('ui/screens/LibraryScreen.kt'))
        self.assertIn('private val ROW_ART = MediaDimensions.trackArt', read('ui/screens/SearchScreen.kt'))

    def test_filter_slice_resets_with_filter_not_async_effect(self):
        s = read('ui/screens/LibraryScreen.kt')
        self.assertIn('rememberSaveable(state.filter)', s)
        self.assertNotIn('LaunchedEffect(state.filter) { sliceName = null }', s)

if __name__ == '__main__':
    unittest.main(verbosity=2)
