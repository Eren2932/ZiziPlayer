#!/usr/bin/env python3
"""Execute production Java matching and layout formulae; not a Kotlin/Android runtime test."""
from pathlib import Path
import subprocess
import tempfile
R = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='lyrics646-') as out:
    sources = ['app/src/main/java/app/ziziplayer/lyrics/LrcTimeline.java',
               'app/src/main/java/app/ziziplayer/lyrics/LyricsMatchPolicy.java',
               'app/src/main/java/app/ziziplayer/ui/LyricsGeometry.java',
               'app/src/test/java/app/ziziplayer/lyrics/Lyrics646Checks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', out,
                    *[str(R / p) for p in sources]], check=True)
    subprocess.run(['java', '-cp', out, 'app.ziziplayer.lyrics.Lyrics646Checks'], check=True)
