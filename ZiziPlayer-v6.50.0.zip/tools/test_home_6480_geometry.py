#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='zizi-home-geometry-') as out:
    sources = ['app/src/main/java/app/ziziplayer/ui/CollectionGeometry.java',
               'app/src/test/java/app/ziziplayer/ui/Home6480Checks.java']
    subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,
                    *[str(ROOT / p) for p in sources]],check=True)
    subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Home6480Checks'],check=True)
