"""Shared (collaborative) playlists, Accounts 1.3.

Only metadata lives here: who is a member, which catalog tracks, in which order. No audio, no
yt-dlp, no calls to the music resolver. Everything runs inside the existing accounts SQLite (WAL)
and the existing one-worker/four-thread gunicorn, so every request is short and bounded:

* no long-poll, no WebSocket: clients poll ``GET /auth/shared`` (one cheap digest round-trip);
* sync is a *state delta*, not op replay: each item row carries the playlist revision at which it
  last changed, so "what changed after rev N" is one indexed range scan, and applying it on the
  client is an idempotent upsert/delete. Tombstones are kept for 30 days; a client that is
  older than the purge floor gets a full snapshot instead;
* order uses fractional keys (``pos``), so insert/move touches exactly one row;
* each client operation carries ``op`` (idempotency key), so a retried batch is applied once.

Permissions: owner does everything; editor adds, moves and removes the tracks they added;
viewer only reads. Membership is never leaked: a non-member sees 404 for any playlist id.
Names of other members come from account_profiles only. E-mail addresses are never exposed.
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
from urllib.parse import parse_qs, urlsplit

from core import AuthError

# ---------------------------------------------------------------------------------- limits
MAX_ITEMS = 5000            # live tracks per playlist
MAX_MEMBERS = 50            # members per playlist, owner included
MAX_OWNED = 100             # shared playlists a user can own
MAX_JOINED = 200            # shared playlists a user can be a member of (owned included)
MAX_BATCH = 100             # operations per request
OPS_PER_MINUTE = 300        # applied operations per user per minute
REQUESTS_PER_MINUTE = 240   # shared API requests per user per minute
TOMBSTONE_DAYS = 30         # removed items / deleted playlists are purged after this
OPS_KEEP = 2000             # activity rows kept per playlist (and 30 days at most)
INVITE_MAX_DAYS = 30
INVITE_MAX_USES = 100
CREATE_BODY = 3 * 1024 * 1024   # create carries up to MAX_ITEMS items
BODY = 256 * 1024               # every other shared request
DAY = 86400

ROLES = ('owner', 'editor', 'viewer')
ARTWORK_HOSTS = ('dzcdn.net', 'deezer.com', 'ytimg.com', 'googleusercontent.com', 'ggpht.com')

SCHEMA = '''
CREATE TABLE IF NOT EXISTS shared_playlists(
 id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, rev INTEGER NOT NULL, floor INTEGER NOT NULL DEFAULT 0,
 items INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL, updated INTEGER NOT NULL,
 deleted INTEGER);
CREATE INDEX IF NOT EXISTS shared_playlists_owner ON shared_playlists(owner);
CREATE TABLE IF NOT EXISTS shared_members(
 pid TEXT NOT NULL REFERENCES shared_playlists(id) ON DELETE CASCADE,
 uid TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL CHECK(role IN ('owner','editor','viewer')), joined INTEGER NOT NULL,
 PRIMARY KEY(pid,uid));
CREATE INDEX IF NOT EXISTS shared_members_uid ON shared_members(uid);
CREATE TABLE IF NOT EXISTS shared_items(
 pid TEXT NOT NULL REFERENCES shared_playlists(id) ON DELETE CASCADE,
 id TEXT NOT NULL, ref TEXT NOT NULL, meta TEXT NOT NULL, pos TEXT NOT NULL,
 added_by TEXT NOT NULL, added INTEGER NOT NULL, rev INTEGER NOT NULL, deleted INTEGER,
 PRIMARY KEY(pid,id));
CREATE INDEX IF NOT EXISTS shared_items_rev ON shared_items(pid,rev);
CREATE UNIQUE INDEX IF NOT EXISTS shared_items_live_ref ON shared_items(pid,ref) WHERE deleted IS NULL;
CREATE TABLE IF NOT EXISTS shared_ops(
 pid TEXT NOT NULL REFERENCES shared_playlists(id) ON DELETE CASCADE,
 op TEXT NOT NULL, uid TEXT NOT NULL, rev INTEGER NOT NULL, kind TEXT NOT NULL,
 summary TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(pid,op));
CREATE INDEX IF NOT EXISTS shared_ops_rev ON shared_ops(pid,rev);
CREATE TABLE IF NOT EXISTS shared_invites(
 hash TEXT PRIMARY KEY, pid TEXT NOT NULL REFERENCES shared_playlists(id) ON DELETE CASCADE,
 role TEXT NOT NULL CHECK(role IN ('editor','viewer')), created_by TEXT NOT NULL,
 created INTEGER NOT NULL, expires INTEGER NOT NULL, max_uses INTEGER NOT NULL,
 uses INTEGER NOT NULL DEFAULT 0, revoked INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS shared_invites_pid ON shared_invites(pid);
'''

ID_RE = re.compile(r'[0-9a-f]{32}')
CLIENT_ID_RE = re.compile(r'[A-Za-z0-9_-]{8,40}')
REF_RE = re.compile(r'(?:dz:[0-9]{1,20}|yt:[A-Za-z0-9_-]{6,64})')
POS_RE = re.compile(r'[0-9A-Za-z]{1,128}')
ISRC_RE = re.compile(r'[A-Z]{2}[A-Z0-9]{3}[0-9]{7}')
TOKEN_RE = re.compile(r'[A-Za-z0-9_-]{43}')
CONTROL_RE = re.compile(r'[\x00-\x1f\x7f\u2028\u2029\u202a-\u202e\u2066-\u2069]')
PATH_RE = re.compile(r'/auth/shared/([0-9a-f]{32})(?:/(ops|invite|invites/revoke|members|delete|activity|avatar))?')


def ensure(accounts):
    with accounts.connection() as c:
        c.executescript(SCHEMA)


# ------------------------------------------------------------------- fractional positions
DIGITS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
_VALUE = {ch: i for i, ch in enumerate(DIGITS)}


def valid_pos(value):
    # Keys are base-62 fractions without a trailing zero: there is always room before any key.
    return isinstance(value, str) and POS_RE.fullmatch(value) is not None and value[-1] != '0'


def key_between(a, b):
    """Key strictly between a and b ('' = start, None = end). Mirror of the Kotlin client."""
    a = a or ''
    if b is not None and not a < b:
        raise ValueError('a must be < b')
    if b is not None:
        n = 0
        while n < len(b) and (a[n] if n < len(a) else '0') == b[n]:
            n += 1
        if n > 0:
            return b[:n] + key_between(a[n:], b[n:])
    da = _VALUE[a[0]] if a else 0
    db = _VALUE[b[0]] if b is not None else len(DIGITS)
    if db - da > 1:
        return DIGITS[(da + db) // 2]
    if b is not None and len(b) > 1:
        return b[:1]
    return DIGITS[da] + key_between(a[1:], None)


# ---------------------------------------------------------------------------- validation
def _text(value, limit, required=False):
    if value is None and not required:
        return ''
    if not isinstance(value, str):
        raise ValueError()
    value = ' '.join(CONTROL_RE.sub(' ', value).split())
    if len(value) > limit or (required and not value):
        raise ValueError()
    return value


def title(value):
    try:
        return _text(value, 60, required=True)
    except ValueError:
        raise AuthError('invalid_title', 400) from None


def artwork(value):
    if not isinstance(value, str) or len(value) > 1000:
        return ''
    try:
        parts = urlsplit(value)
    except ValueError:
        return ''
    host = (parts.hostname or '').lower()
    # A member must not be able to make other members' phones fetch an arbitrary tracking URL.
    if parts.scheme != 'https' or parts.username or parts.password or parts.port not in (None, 443):
        return ''
    if not any(host == h or host.endswith('.' + h) for h in ARTWORK_HOSTS):
        return ''
    return value


def meta(value):
    if not isinstance(value, dict) or len(value) > 12:
        raise ValueError()
    out = {'t': _text(value.get('t'), 300, required=True)}
    for key, limit in (('a', 300), ('al', 300)):
        text = _text(value.get(key), limit)
        if text:
            out[key] = text
    duration = value.get('d', 0)
    if type(duration) is not int or not 0 <= duration <= 86_400_000:
        raise ValueError()
    if duration:
        out['d'] = duration
    art = artwork(value.get('art'))
    if art:
        out['art'] = art
    isrc = value.get('isrc')
    if isinstance(isrc, str) and ISRC_RE.fullmatch(isrc):
        out['isrc'] = isrc
    if value.get('ex') is True:
        out['ex'] = True
    return out


def item(value):
    if not isinstance(value, dict):
        raise ValueError()
    iid, ref, pos = value.get('id'), value.get('ref'), value.get('pos')
    if not isinstance(iid, str) or not CLIENT_ID_RE.fullmatch(iid):
        raise ValueError()
    if not isinstance(ref, str) or not REF_RE.fullmatch(ref):
        raise ValueError()
    if not valid_pos(pos):
        raise ValueError()
    return {'id': iid, 'ref': ref, 'pos': pos, 'meta': meta(value.get('meta'))}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def integer(value, low, high, default):
    if value is None or value == '':
        return default
    if isinstance(value, bool):
        raise AuthError('bad_request', 400)
    if isinstance(value, str):
        if not value.isascii() or not value.isdigit() or len(value) > 15:
            raise AuthError('bad_request', 400)
        value = int(value)
    if type(value) is not int or not low <= value <= high:
        raise AuthError('bad_request', 400)
    return value


def query(environ):
    raw = environ.get('QUERY_STRING', '')
    if len(raw) > 512:
        raise AuthError('bad_request', 400)
    try:
        parsed = parse_qs(raw, keep_blank_values=True, strict_parsing=False, max_num_fields=4)
    except ValueError:
        raise AuthError('bad_request', 400) from None
    if any(len(v) != 1 for v in parsed.values()):
        raise AuthError('bad_request', 400)
    return {k: v[0] for k, v in parsed.items()}


def body_limit(path):
    return CREATE_BODY if path == '/auth/shared/create' else BODY


# ------------------------------------------------------------------------------- helpers
def _new_id():
    return secrets.token_hex(16)


def _token_hash(token):
    return hashlib.sha256(('zizi-shared-invite\0' + token).encode('ascii')).hexdigest()


def _bump(accounts, key, n, maximum, window):
    """Fixed-window counter in the existing limits table, incremented by n (ops, not requests)."""
    key = hashlib.sha256(key.encode('utf-8')).hexdigest()
    now = accounts.now()
    with accounts.transaction() as c:
        row = c.execute('SELECT count,expires FROM limits WHERE key=?', (key,)).fetchone()
        if row and row['expires'] > now:
            if row['count'] + n > maximum:
                raise AuthError('rate_limited', 429)
            c.execute('UPDATE limits SET count=count+? WHERE key=?', (n, key))
        else:
            if n > maximum:
                raise AuthError('rate_limited', 429)
            c.execute('INSERT INTO limits VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET count=excluded.count,expires=excluded.expires',
                      (key, n, now + window))


def _membership(c, pid, uid):
    row = c.execute('SELECT p.*, m.role AS my_role FROM shared_playlists p JOIN shared_members m ON m.pid=p.id '
                    'WHERE p.id=? AND m.uid=?', (pid, uid)).fetchone()
    if not row:
        raise AuthError('not_found', 404)
    if row['deleted'] is not None:
        raise AuthError('gone', 410)
    return row


def _members(c, pid):
    rows = c.execute('SELECT m.uid, m.role, m.joined, COALESCE(a.name, \'\') AS name, COALESCE(a.revision, 0) AS prev, '
                     'CASE WHEN COALESCE(a.avatar, \'\')=\'\' THEN 0 ELSE 1 END AS has_avatar '
                     'FROM shared_members m LEFT JOIN account_profiles a ON a.uid=m.uid WHERE m.pid=? '
                     'ORDER BY CASE m.role WHEN \'owner\' THEN 0 WHEN \'editor\' THEN 1 ELSE 2 END, m.joined', (pid,)).fetchall()
    return [{'uid': r['uid'], 'role': r['role'], 'name': r['name'], 'joined': r['joined'],
             'profile_rev': r['prev'], 'avatar': bool(r['has_avatar'])} for r in rows]


def _item_out(r):
    return {'id': r['id'], 'ref': r['ref'], 'meta': json.loads(r['meta']), 'pos': r['pos'],
            'by': r['added_by'], 'at': r['added']}


def _log(c, pid, op, uid, rev, kind, summary, ts):
    c.execute('INSERT OR IGNORE INTO shared_ops VALUES(?,?,?,?,?,?,?)',
              (pid, op, uid, rev, kind, canonical(summary), ts))


def _header(p, role):
    return {'id': p['id'], 'title': p['title'], 'rev': p['rev'], 'role': role, 'owner': p['owner'],
            'items': p['items'], 'updated': p['updated']}


def _delta(c, p, role, since):
    """State delta after revision `since`. Full snapshot if the client is new or behind the purge floor."""
    out = _header(p, role)
    if since == p['rev']:
        out['unchanged'] = True
        return out
    full = since <= 0 or since < p['floor'] or since > p['rev']
    out['full'] = full
    if full:
        rows = c.execute('SELECT * FROM shared_items WHERE pid=? AND deleted IS NULL ORDER BY pos, id', (p['id'],)).fetchall()
        out['items'], out['removed'] = [_item_out(r) for r in rows], []
    else:
        rows = c.execute('SELECT * FROM shared_items WHERE pid=? AND rev>? ORDER BY pos, id', (p['id'], since)).fetchall()
        out['items'] = [_item_out(r) for r in rows if r['deleted'] is None]
        out['removed'] = [r['id'] for r in rows if r['deleted'] is not None]
    out['members'] = _members(c, p['id'])
    return out


# --------------------------------------------------------------------------------- reads
def overview(accounts, uid, known=''):
    """All my shared playlists. With `v` equal to the current digest the answer is one tiny object."""
    with accounts.connection() as c:
        rows = c.execute('SELECT p.*, m.role AS my_role, (SELECT COUNT(*) FROM shared_members x WHERE x.pid=p.id) AS member_count '
                         'FROM shared_members m JOIN shared_playlists p ON p.id=m.pid '
                         'WHERE m.uid=? AND p.deleted IS NULL ORDER BY p.updated DESC', (uid,)).fetchall()
    state = '\n'.join(sorted(f"{r['id']}:{r['rev']}:{r['my_role']}" for r in rows))
    version = hashlib.sha256(state.encode('ascii')).hexdigest()[:24]
    if known == version:
        return {'v': version, 'unchanged': True}
    out = []
    for r in rows:
        head = _header(r, r['my_role'])
        head['members'] = r['member_count']
        out.append(head)
    return {'v': version, 'playlists': out}


def fetch(accounts, uid, pid, since):
    with accounts.connection() as c:
        p = _membership(c, pid, uid)
        return _delta(c, p, p['my_role'], since)


def activity(accounts, uid, pid, limit=60):
    with accounts.connection() as c:
        _membership(c, pid, uid)
        rows = c.execute('SELECT o.uid, o.kind, o.summary, o.ts, o.rev, COALESCE(a.name, \'\') AS name FROM shared_ops o '
                         'LEFT JOIN account_profiles a ON a.uid=o.uid WHERE o.pid=? ORDER BY o.rev DESC, o.ts DESC LIMIT ?',
                         (pid, limit)).fetchall()
    return {'events': [{'uid': r['uid'], 'name': r['name'], 'kind': r['kind'], 'ts': r['ts'], 'rev': r['rev'],
                        **json.loads(r['summary'])} for r in rows]}


def avatar(accounts, uid, pid, member):
    if not isinstance(member, str) or not ID_RE.fullmatch(member):
        raise AuthError('bad_request', 400)
    with accounts.connection() as c:
        _membership(c, pid, uid)
        if not c.execute('SELECT 1 FROM shared_members WHERE pid=? AND uid=?', (pid, member)).fetchone():
            raise AuthError('not_found', 404)
        row = c.execute('SELECT avatar, revision FROM account_profiles WHERE uid=?', (member,)).fetchone()
    return {'uid': member, 'avatar': row['avatar'] if row else '', 'profile_rev': row['revision'] if row else 0}


# -------------------------------------------------------------------------------- writes
def create(accounts, uid, payload):
    name = title(payload.get('title'))
    raw = payload.get('items', [])
    if not isinstance(raw, list) or len(raw) > MAX_ITEMS:
        raise AuthError('too_many_items', 413)
    items, seen_ids, seen_refs, skipped = [], set(), set(), 0
    for value in raw:
        try:
            it = item(value)
        except (ValueError, TypeError):
            raise AuthError('invalid_item', 400) from None
        if it['id'] in seen_ids:
            raise AuthError('invalid_item', 400)
        seen_ids.add(it['id'])
        if it['ref'] in seen_refs:
            skipped += 1      # the same catalog track twice: keep the first occurrence
            continue
        seen_refs.add(it['ref'])
        items.append(it)
    request = payload.get('op')
    if request is not None and (not isinstance(request, str) or not CLIENT_ID_RE.fullmatch(request)):
        raise AuthError('bad_request', 400)
    now = accounts.now()
    with accounts.transaction() as c:
        if request:
            # A lost response must not create a second playlist on retry.
            again = c.execute('SELECT p.* FROM shared_ops o JOIN shared_playlists p ON p.id=o.pid '
                              'WHERE o.op=? AND o.uid=? AND o.kind=\'create\'', (request, uid)).fetchone()
            if again and again['deleted'] is None:
                return {**_delta(c, again, 'owner', 0), 'skipped': skipped}
        if c.execute('SELECT COUNT(*) FROM shared_playlists WHERE owner=? AND deleted IS NULL', (uid,)).fetchone()[0] >= MAX_OWNED:
            raise AuthError('too_many_playlists', 409)
        if c.execute('SELECT COUNT(*) FROM shared_members m JOIN shared_playlists p ON p.id=m.pid '
                     'WHERE m.uid=? AND p.deleted IS NULL', (uid,)).fetchone()[0] >= MAX_JOINED:
            raise AuthError('too_many_playlists', 409)
        pid = _new_id()
        c.execute('INSERT INTO shared_playlists(id,owner,title,rev,floor,items,created,updated) VALUES(?,?,?,?,?,?,?,?)',
                  (pid, uid, name, 1, 0, len(items), now, now))
        c.execute('INSERT INTO shared_members VALUES(?,?,?,?)', (pid, uid, 'owner', now))
        c.executemany('INSERT INTO shared_items VALUES(?,?,?,?,?,?,?,?,NULL)',
                      [(pid, it['id'], it['ref'], canonical(it['meta']), it['pos'], uid, now, 1) for it in items])
        _log(c, pid, request or _new_id(), uid, 1, 'create', {'title': name, 'count': len(items)}, now)
        p = c.execute('SELECT * FROM shared_playlists WHERE id=?', (pid,)).fetchone()
        return {**_delta(c, p, 'owner', 0), 'skipped': skipped}


def _summary(meta_json):
    value = json.loads(meta_json)
    return {'t': value.get('t', '')[:120], 'a': value.get('a', '')[:120]}


def apply_ops(accounts, uid, pid, payload):
    ops = payload.get('ops')
    if not isinstance(ops, list) or len(ops) > MAX_BATCH:
        raise AuthError('bad_request', 400)
    since = integer(payload.get('since'), 0, 10**15, 0)
    if ops:
        _bump(accounts, 'shared-ops:' + uid, len(ops), OPS_PER_MINUTE, 60)
    now = accounts.now()
    results = []
    with accounts.transaction() as c:
        p = _membership(c, pid, uid)
        role = p['my_role']
        rev = p['rev'] + 1
        live = p['items']
        changed = False
        title_now = p['title']
        for raw in ops:
            op = raw.get('op') if isinstance(raw, dict) else None
            if not isinstance(op, str) or not CLIENT_ID_RE.fullmatch(op):
                results.append({'op': op if isinstance(op, str) else '', 'status': 'invalid'})
                continue
            if c.execute('SELECT 1 FROM shared_ops WHERE pid=? AND op=?', (pid, op)).fetchone():
                results.append({'op': op, 'status': 'ok'})      # retried batch: already applied
                continue
            kind = raw.get('kind')
            status = 'ok'
            try:
                if role == 'viewer':
                    status = 'forbidden'
                elif kind == 'add':
                    it = item(raw.get('item'))
                    existing = c.execute('SELECT * FROM shared_items WHERE pid=? AND id=?', (pid, it['id'])).fetchone()
                    if existing:
                        status = 'ok' if existing['ref'] == it['ref'] and existing['deleted'] is None else 'conflict'
                    elif live >= MAX_ITEMS:
                        status = 'limit'
                    elif c.execute('SELECT 1 FROM shared_items WHERE pid=? AND ref=? AND deleted IS NULL', (pid, it['ref'])).fetchone():
                        status = 'exists'
                    else:
                        c.execute('INSERT INTO shared_items VALUES(?,?,?,?,?,?,?,?,NULL)',
                                  (pid, it['id'], it['ref'], canonical(it['meta']), it['pos'], uid, now, rev))
                        live += 1
                        _log(c, pid, op, uid, rev, 'add', {'item': it['id'], 't': it['meta']['t'][:120], 'a': it['meta'].get('a', '')[:120]}, now)
                        changed = True
                elif kind in ('remove', 'move'):
                    iid = raw.get('id')
                    if not isinstance(iid, str) or not CLIENT_ID_RE.fullmatch(iid):
                        raise ValueError()
                    row = c.execute('SELECT * FROM shared_items WHERE pid=? AND id=?', (pid, iid)).fetchone()
                    if not row or row['deleted'] is not None:
                        # Removed already (by anyone): remove is idempotent, a move of a removed track is moot.
                        status = 'ok' if kind == 'remove' else 'missing'
                    elif kind == 'remove':
                        if role != 'owner' and row['added_by'] != uid:
                            status = 'forbidden'
                        else:
                            c.execute('UPDATE shared_items SET deleted=?, rev=? WHERE pid=? AND id=?', (now, rev, pid, iid))
                            live -= 1
                            _log(c, pid, op, uid, rev, 'remove', {'item': iid, **_summary(row['meta'])}, now)
                            changed = True
                    else:
                        pos = raw.get('pos')
                        if not valid_pos(pos):
                            raise ValueError()
                        if pos != row['pos']:
                            c.execute('UPDATE shared_items SET pos=?, rev=? WHERE pid=? AND id=?', (pos, rev, pid, iid))
                            _log(c, pid, op, uid, rev, 'move', {'item': iid, **_summary(row['meta'])}, now)
                            changed = True
                elif kind == 'rename':
                    if role != 'owner':
                        status = 'forbidden'
                    else:
                        name = title(raw.get('title'))
                        if name != title_now:
                            title_now = name
                            c.execute('UPDATE shared_playlists SET title=? WHERE id=?', (name, pid))
                            _log(c, pid, op, uid, rev, 'rename', {'title': name}, now)
                            changed = True
                else:
                    raise ValueError()
            except (ValueError, TypeError, KeyError, AuthError):
                status = 'invalid'
            results.append({'op': op, 'status': status})
        if changed:
            c.execute('UPDATE shared_playlists SET rev=?, items=?, updated=? WHERE id=?', (rev, live, now, pid))
        p = c.execute('SELECT * FROM shared_playlists WHERE id=?', (pid,)).fetchone()
        out = _delta(c, p, role, since)
    out['results'] = results
    return out


def invite(accounts, uid, pid, payload):
    role = payload.get('role', 'editor')
    if role not in ('editor', 'viewer'):
        raise AuthError('bad_request', 400)
    days = integer(payload.get('days'), 1, INVITE_MAX_DAYS, 7)
    uses = integer(payload.get('uses'), 1, INVITE_MAX_USES, 20)
    token = secrets.token_urlsafe(32)        # 43 chars, 256 bits; only its hash is stored
    now = accounts.now()
    with accounts.transaction() as c:
        p = _membership(c, pid, uid)
        if p['my_role'] != 'owner':
            raise AuthError('forbidden', 403)
        active = c.execute('SELECT COUNT(*) FROM shared_invites WHERE pid=? AND revoked=0 AND expires>?', (pid, now)).fetchone()[0]
        if active >= 20:
            raise AuthError('too_many_invites', 409)
        c.execute('INSERT INTO shared_invites(hash,pid,role,created_by,created,expires,max_uses) VALUES(?,?,?,?,?,?,?)',
                  (_token_hash(token), pid, role, uid, now, now + days * DAY, uses))
    return {'token': token, 'role': role, 'expires': now + days * DAY, 'uses': uses}


def revoke_invites(accounts, uid, pid):
    now = accounts.now()
    with accounts.transaction() as c:
        p = _membership(c, pid, uid)
        if p['my_role'] != 'owner':
            raise AuthError('forbidden', 403)
        n = c.execute('UPDATE shared_invites SET revoked=1 WHERE pid=? AND revoked=0 AND expires>?', (pid, now)).rowcount
    return {'revoked': n}


def _invite_row(c, token, now):
    if not isinstance(token, str) or not TOKEN_RE.fullmatch(token):
        raise AuthError('invite_invalid', 404)
    row = c.execute('SELECT i.*, p.title, p.owner, p.items, p.deleted FROM shared_invites i '
                    'JOIN shared_playlists p ON p.id=i.pid WHERE i.hash=?', (_token_hash(token),)).fetchone()
    # One generic answer for unknown / revoked / expired / used up: no oracle for token states.
    if not row or row['revoked'] or row['expires'] <= now or row['uses'] >= row['max_uses'] or row['deleted'] is not None:
        raise AuthError('invite_invalid', 404)
    return row


def peek(accounts, uid, token):
    now = accounts.now()
    with accounts.connection() as c:
        row = _invite_row(c, token, now)
        owner = c.execute('SELECT name FROM account_profiles WHERE uid=?', (row['owner'],)).fetchone()
        members = c.execute('SELECT COUNT(*) FROM shared_members WHERE pid=?', (row['pid'],)).fetchone()[0]
        mine = c.execute('SELECT role FROM shared_members WHERE pid=? AND uid=?', (row['pid'], uid)).fetchone()
    return {'id': row['pid'], 'title': row['title'], 'owner_name': owner['name'] if owner else '',
            'items': row['items'], 'members': members, 'role': row['role'],
            'member': mine is not None, 'my_role': mine['role'] if mine else ''}


def join(accounts, uid, token):
    now = accounts.now()
    with accounts.transaction() as c:
        row = _invite_row(c, token, now)
        pid = row['pid']
        mine = c.execute('SELECT role FROM shared_members WHERE pid=? AND uid=?', (pid, uid)).fetchone()
        if mine:
            # Re-opening a link never changes an existing role and never spends a use.
            return {'id': pid, 'role': mine['role'], 'joined': False}
        if c.execute('SELECT COUNT(*) FROM shared_members WHERE pid=?', (pid,)).fetchone()[0] >= MAX_MEMBERS:
            raise AuthError('playlist_full', 409)
        if c.execute('SELECT COUNT(*) FROM shared_members m JOIN shared_playlists p ON p.id=m.pid '
                     'WHERE m.uid=? AND p.deleted IS NULL', (uid,)).fetchone()[0] >= MAX_JOINED:
            raise AuthError('too_many_playlists', 409)
        c.execute('INSERT INTO shared_members VALUES(?,?,?,?)', (pid, uid, row['role'], now))
        c.execute('UPDATE shared_invites SET uses=uses+1 WHERE hash=?', (row['hash'],))
        rev = c.execute('SELECT rev FROM shared_playlists WHERE id=?', (pid,)).fetchone()[0] + 1
        c.execute('UPDATE shared_playlists SET rev=?, updated=? WHERE id=?', (rev, now, pid))
        _log(c, pid, _new_id(), uid, rev, 'join', {'role': row['role']}, now)
    return {'id': pid, 'role': row['role'], 'joined': True}


def members(accounts, uid, pid, payload):
    action = payload.get('action')
    target = payload.get('uid', uid)
    if action not in ('role', 'remove', 'leave', 'transfer') or not isinstance(target, str) or not ID_RE.fullmatch(target):
        raise AuthError('bad_request', 400)
    now = accounts.now()
    with accounts.transaction() as c:
        p = _membership(c, pid, uid)
        mine = p['my_role']
        if action == 'leave':
            if mine == 'owner':
                raise AuthError('owner_cannot_leave', 409)    # transfer or delete instead
            target = uid
        elif mine != 'owner':
            raise AuthError('forbidden', 403)
        row = c.execute('SELECT role FROM shared_members WHERE pid=? AND uid=?', (pid, target)).fetchone()
        if not row:
            raise AuthError('not_found', 404)
        if action != 'leave' and target == uid:
            raise AuthError('bad_request', 400)
        summary = {'target': target}
        if action == 'role':
            role = payload.get('role')
            if role not in ('editor', 'viewer'):
                raise AuthError('bad_request', 400)
            if row['role'] == role:
                return {'ok': True}
            c.execute('UPDATE shared_members SET role=? WHERE pid=? AND uid=?', (role, pid, target))
            summary['role'] = role
        elif action in ('remove', 'leave'):
            c.execute('DELETE FROM shared_members WHERE pid=? AND uid=?', (pid, target))
        else:
            c.execute('UPDATE shared_members SET role=\'editor\' WHERE pid=? AND uid=?', (pid, uid))
            c.execute('UPDATE shared_members SET role=\'owner\' WHERE pid=? AND uid=?', (pid, target))
            c.execute('UPDATE shared_playlists SET owner=? WHERE id=?', (target, pid))
            # Links minted by the previous owner stop working: the new owner decides who comes in.
            c.execute('UPDATE shared_invites SET revoked=1 WHERE pid=?', (pid,))
        rev = p['rev'] + 1
        c.execute('UPDATE shared_playlists SET rev=?, updated=? WHERE id=?', (rev, now, pid))
        _log(c, pid, _new_id(), uid, rev, action, summary, now)
    return {'ok': True}


def delete(accounts, uid, pid):
    now = accounts.now()
    with accounts.transaction() as c:
        p = _membership(c, pid, uid)
        if p['my_role'] != 'owner':
            raise AuthError('forbidden', 403)
        c.execute('UPDATE shared_playlists SET deleted=?, updated=?, rev=rev+1 WHERE id=?', (now, now, pid))
        c.execute('UPDATE shared_invites SET revoked=1 WHERE pid=?', (pid,))
    return {'ok': True}


# --------------------------------------------------------------------------- maintenance
def purge(c, now):
    """Daily cleanup on a raw sqlite3 connection (maintenance.py) or inside a transaction."""
    if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='shared_playlists'").fetchone():
        return 0
    horizon = now - TOMBSTONE_DAYS * DAY
    c.execute('DELETE FROM shared_playlists WHERE deleted IS NOT NULL AND deleted<=?', (horizon,))
    # Raise the floor first: a client older than the newest purged tombstone must take a full snapshot.
    c.execute('UPDATE shared_playlists SET floor=MAX(floor, (SELECT MAX(rev) FROM shared_items i '
              'WHERE i.pid=shared_playlists.id AND i.deleted IS NOT NULL AND i.deleted<=?)) '
              'WHERE EXISTS(SELECT 1 FROM shared_items i WHERE i.pid=shared_playlists.id AND i.deleted IS NOT NULL AND i.deleted<=?)',
              (horizon, horizon))
    n = c.execute('DELETE FROM shared_items WHERE deleted IS NOT NULL AND deleted<=?', (horizon,)).rowcount
    c.execute('DELETE FROM shared_ops WHERE ts<=? AND kind<>\'create\'', (horizon,))
    c.execute('DELETE FROM shared_ops WHERE rowid IN (SELECT rowid FROM (SELECT rowid, ROW_NUMBER() OVER '
              '(PARTITION BY pid ORDER BY rev DESC, ts DESC) AS n FROM shared_ops) WHERE n>?)', (OPS_KEEP,))
    c.execute('DELETE FROM shared_invites WHERE expires<=? OR (revoked=1 AND created<=?)', (now - DAY, horizon))
    return n


# ---------------------------------------------------------------------------------- HTTP
def handle(accounts, user, method, path, payload, environ):
    """Dispatch for every /auth/shared* route. Returns the JSON result; raises AuthError."""
    uid = user['id']
    accounts.rate('shared:' + uid, REQUESTS_PER_MINUTE, 60)
    if path == '/auth/shared':
        if method != 'GET':
            raise AuthError('method_not_allowed', 405)
        result = overview(accounts, uid, query(environ).get('v', ''))
    elif path == '/auth/shared/create':
        if method != 'POST':
            raise AuthError('method_not_allowed', 405)
        accounts.rate('shared-create:' + uid, 20, 3600)
        result = create(accounts, uid, payload)
    elif path in ('/auth/shared/peek', '/auth/shared/join'):
        if method != 'POST':
            raise AuthError('method_not_allowed', 405)
        accounts.rate('shared-join:' + uid, 30, 600)
        token = payload.get('token')
        result = peek(accounts, uid, token) if path.endswith('peek') else join(accounts, uid, token)
    else:
        match = PATH_RE.fullmatch(path)
        if not match:
            raise AuthError('not_found', 404)
        pid, action = match.group(1), match.group(2)
        if action is None and method == 'GET':
            result = fetch(accounts, uid, pid, integer(query(environ).get('since'), 0, 10**15, 0))
        elif action == 'activity' and method == 'GET':
            result = activity(accounts, uid, pid)
        elif action == 'avatar' and method == 'GET':
            result = avatar(accounts, uid, pid, query(environ).get('uid'))
        elif method != 'POST':
            raise AuthError('method_not_allowed', 405)
        elif action == 'ops':
            result = apply_ops(accounts, uid, pid, payload)
        elif action == 'invite':
            accounts.rate('shared-invite:' + uid, 30, 3600)
            result = invite(accounts, uid, pid, payload)
        elif action == 'invites/revoke':
            result = revoke_invites(accounts, uid, pid)
        elif action == 'members':
            result = members(accounts, uid, pid, payload)
        elif action == 'delete':
            result = delete(accounts, uid, pid)
        else:
            raise AuthError('not_found', 404)
    # Every answer names the account it was computed for: the client drops it after an account switch.
    result['me'] = uid
    return result
