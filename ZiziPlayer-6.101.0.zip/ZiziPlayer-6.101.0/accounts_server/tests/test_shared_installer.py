import contextlib
import io
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from install_accounts_13 import install, V12

PAYLOAD = Path(__file__).resolve().parents[1]
import os
# Каталог accounts_server из релиза 1.2; без него тест апгрейда пропускается.
ORIGINAL = Path(os.environ.get('ZIZI_V12_SOURCES', '/nonexistent'))


class SharedInstallerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.target = Path(self.tmp.name) / 'current'; self.target.mkdir()
        for name in ('core.py', 'library.py', 'profiles.py', 'web.py', 'maintenance.py'):
            shutil.copy2(PAYLOAD / name, self.target / name)
        (self.target / 'accounts.env').write_text('example-preserved-configuration')

    def run_quiet(self, apply):
        with contextlib.redirect_stdout(io.StringIO()): install(self.target, apply)

    def test_fresh_13_payload_is_idempotent_and_adds_shared(self):
        self.run_quiet(False); self.run_quiet(True); self.run_quiet(True)
        for name in ('web.py', 'maintenance.py', 'shared.py'):
            self.assertEqual((self.target / name).read_bytes(), (PAYLOAD / name).read_bytes())
        self.assertEqual((self.target / 'accounts.env').read_text(), 'example-preserved-configuration')

    @unittest.skipUnless(ORIGINAL.is_dir(), 'needs 1.2 sources')
    def test_upgrades_exact_12_release(self):
        for name in V12: shutil.copy2(ORIGINAL / name, self.target / name)
        self.run_quiet(True)
        self.assertEqual((self.target / 'web.py').read_bytes(), (PAYLOAD / 'web.py').read_bytes())
        self.assertTrue((self.target / 'shared.py').is_file())

    def test_modified_web_is_never_overwritten(self):
        p = self.target / 'web.py'; p.write_text(p.read_text() + '\n# deployed custom SMTP fix\n')
        original = p.read_bytes()
        with self.assertRaises(ValueError): install(self.target, True)
        self.assertEqual(p.read_bytes(), original)
        self.assertFalse((self.target / 'shared.py').exists())

    def test_modified_core_blocks_install(self):
        p = self.target / 'core.py'; p.write_text(p.read_text() + '\n# local\n')
        with self.assertRaises(ValueError): install(self.target, True)

    def test_missing_profiles_fails_closed(self):
        (self.target / 'profiles.py').unlink()
        with self.assertRaises(ValueError): install(self.target, True)

    def test_symlink_is_rejected(self):
        (self.target / 'web.py').unlink(); (self.target / 'web.py').symlink_to(PAYLOAD / 'web.py')
        with self.assertRaises(ValueError): install(self.target, True)


if __name__ == '__main__': unittest.main(verbosity=2)
