"""Shared playlists 1.3: real SQLite + WSGI + signed sessions, like the other suites."""
import concurrent.futures
import json
import random
import unittest
import test_accounts as existing
from test_accounts import PASSWORD
from web import ACCESS_COOKIE
import shared


def it(n, ref=None, pos=None, art=None):
    meta = {'t': f'Track {n}', 'a': 'Artist', 'd': 180000}
    if art: meta['art'] = art
    return {'id': f'item{n:06d}', 'ref': ref or f'dz:{1000 + n}', 'pos': pos or shared.DIGITS[1 + n % 60] + 'V', 'meta': meta}


class SharedTest(unittest.TestCase):
    setUpClass = classmethod(existing.AccountsTest.setUpClass.__func__)
    setUp = existing.AccountsTest.setUp

    def http(self, path, data=None, jar='', method=None, q=''):
        return existing.AccountsTest.http(self, path, data, jar, method, extra={'QUERY_STRING': q})

    def user(self, n=0, fresh=True):
        email = f'user{n}@example.org'
        if fresh:
            code = self.a.register(email, PASSWORD); self.a.redeem(code, 'verify')
        p = self.a.login(email, PASSWORD)
        return p['user']['id'], ACCESS_COOKIE + '=' + p['access']

    def create(self, jar, items=(), title='Вечеринка', op=None):
        body = {'title': title, 'items': list(items)}
        if op: body['op'] = op
        s, _, r = self.http('/auth/shared/create', body, jar)
        self.assertEqual(s, 200, r)
        return r

    def ops(self, jar, pid, ops, since=0):
        return self.http(f'/auth/shared/{pid}/ops', {'since': since, 'ops': ops}, jar)

    def invite_join(self, owner, pid, jar, role='editor'):
        s, _, inv = self.http(f'/auth/shared/{pid}/invite', {'role': role}, owner)
        self.assertEqual(s, 200, inv)
        s, _, r = self.http('/auth/shared/join', {'token': inv['token']}, jar)
        self.assertEqual(s, 200, r)
        return inv['token']

    # ------------------------------------------------------------------------- basics
    def test_anonymous_denied(self):
        self.assertEqual(self.http('/auth/shared')[0], 401)
        self.assertEqual(self.http('/auth/shared/create', {'title': 'x', 'items': []})[0], 401)
        self.assertEqual(self.http('/auth/shared/join', {'token': 'a' * 43})[0], 401)

    def test_create_full_snapshot_and_unchanged(self):
        uid, jar = self.user()
        r = self.create(jar, [it(1), it(2), it(3)])
        self.assertEqual(r['rev'], 1); self.assertTrue(r['full']); self.assertEqual(len(r['items']), 3)
        self.assertEqual(r['me'], uid); self.assertEqual(r['role'], 'owner')
        self.assertNotIn('example.org', json.dumps(r))
        s, _, again = self.http(f"/auth/shared/{r['id']}", q='since=1', jar=jar)
        self.assertEqual(s, 200); self.assertTrue(again['unchanged'])
        s, _, ov = self.http('/auth/shared', jar=jar)
        self.assertEqual(len(ov['playlists']), 1); self.assertEqual(ov['playlists'][0]['items'], 3)
        s, _, ov2 = self.http('/auth/shared', jar=jar, q='v=' + ov['v'])
        self.assertEqual(ov2, {'v': ov['v'], 'unchanged': True, 'me': uid})

    def test_create_dedupes_refs_and_is_idempotent(self):
        _, jar = self.user()
        r = self.create(jar, [it(1), it(2, ref='dz:1001')], op='create-op-1')
        self.assertEqual(len(r['items']), 1); self.assertEqual(r['skipped'], 1)
        r2 = self.create(jar, [it(1)], op='create-op-1')
        self.assertEqual(r2['id'], r['id'])
        self.assertEqual(len(self.http('/auth/shared', jar=jar)[2]['playlists']), 1)

    def test_validation(self):
        _, jar = self.user()
        for bad in ({'title': '', 'items': []}, {'title': 'x' * 61, 'items': []},
                    {'title': 'ok', 'items': [dict(it(1), ref='file:/sdcard/a.mp3')]},
                    {'title': 'ok', 'items': [dict(it(1), pos='abc0')]},
                    {'title': 'ok', 'items': [dict(it(1), meta={'t': ''})]},
                    {'title': 'ok', 'items': 'nope'}):
            self.assertEqual(self.http('/auth/shared/create', bad, jar)[0], 400 if bad['items'] != 'nope' else 413, bad)
        r = self.create(jar, [it(1, art='https://evil.example/pixel.gif'), it(2, art='https://e-cdns-images.dzcdn.net/images/cover/1/250x250.jpg')])
        arts = {x['id']: x['meta'].get('art') for x in r['items']}
        self.assertIsNone(arts['item000001']); self.assertTrue(arts['item000002'].startswith('https://e-cdns-images.dzcdn.net/'))

    # ----------------------------------------------------------------------- sharing
    def test_invite_join_peek_and_privacy(self):
        owner_id, owner = self.user(0); friend_id, friend = self.user(1); _, stranger = self.user(2)
        r = self.create(owner, [it(1)])
        pid = r['id']
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=stranger)[0], 404)
        s, _, inv = self.http(f'/auth/shared/{pid}/invite', {'role': 'editor', 'days': 2, 'uses': 1}, owner)
        self.assertEqual(s, 200); self.assertEqual(len(inv['token']), 43)
        s, _, pk = self.http('/auth/shared/peek', {'token': inv['token']}, friend)
        self.assertEqual((s, pk['title'], pk['items'], pk['member']), (200, 'Вечеринка', 1, False))
        self.assertEqual(self.http('/auth/shared/join', {'token': inv['token']}, friend)[2]['joined'], True)
        # Used up: generic invalid for everyone else; re-join by member is a no-op.
        self.assertEqual(self.http('/auth/shared/join', {'token': inv['token']}, stranger)[:3:2], (404, {'error': 'invite_invalid'}))
        s, _, view = self.http(f'/auth/shared/{pid}', jar=friend)
        self.assertEqual((s, view['role']), (200, 'editor'))
        self.assertEqual({m['uid'] for m in view['members']}, {owner_id, friend_id})
        self.assertNotIn('@', json.dumps(view))
        self.assertEqual(self.http('/auth/shared/join', {'token': 'x' * 43}, friend)[0], 404)
        self.assertEqual(self.http(f'/auth/shared/{pid}/invite', {'role': 'editor'}, friend)[0], 403)

    def test_invite_expiry_and_revoke(self):
        _, owner = self.user(0); _, friend = self.user(1)
        pid = self.create(owner)['id']
        tok = self.http(f'/auth/shared/{pid}/invite', {'days': 1}, owner)[2]['token']
        self.now += 86400
        _, owner = self.user(0, fresh=False); _, friend = self.user(1, fresh=False)
        self.assertEqual(self.http('/auth/shared/join', {'token': tok}, friend)[0], 404)
        tok = self.http(f'/auth/shared/{pid}/invite', {}, owner)[2]['token']
        self.assertEqual(self.http(f'/auth/shared/{pid}/invites/revoke', {}, owner)[2]['revoked'], 1)
        self.assertEqual(self.http('/auth/shared/join', {'token': tok}, friend)[0], 404)

    # ------------------------------------------------------------------- operations
    def test_permissions(self):
        owner_id, owner = self.user(0); _, editor = self.user(1); _, viewer = self.user(2)
        pid = self.create(owner, [it(1)])['id']
        self.invite_join(owner, pid, editor); self.invite_join(owner, pid, viewer, role='viewer')
        r = self.ops(editor, pid, [{'op': 'e-add-0001', 'kind': 'add', 'item': it(2)}])[2]
        self.assertEqual(r['results'][0]['status'], 'ok')
        res = self.ops(editor, pid, [{'op': 'e-rm-00001', 'kind': 'remove', 'id': 'item000001'},
                                     {'op': 'e-ren-0001', 'kind': 'rename', 'title': 'Мой'},
                                     {'op': 'e-mv-00001', 'kind': 'move', 'id': 'item000001', 'pos': 'z'}])[2]['results']
        self.assertEqual([x['status'] for x in res], ['forbidden', 'forbidden', 'ok'])
        res = self.ops(viewer, pid, [{'op': 'v-add-0001', 'kind': 'add', 'item': it(3)}])[2]['results']
        self.assertEqual(res[0]['status'], 'forbidden')
        res = self.ops(editor, pid, [{'op': 'e-rm-00002', 'kind': 'remove', 'id': 'item000002'}])[2]['results']
        self.assertEqual(res[0]['status'], 'ok')
        res = self.ops(owner, pid, [{'op': 'o-rm-00001', 'kind': 'remove', 'id': 'item000001'},
                                    {'op': 'o-ren-0001', 'kind': 'rename', 'title': '  Новое   имя '}])[2]
        self.assertEqual([x['status'] for x in res['results']], ['ok', 'ok'])
        self.assertEqual((res['title'], res['items'] if isinstance(res['items'], int) else len(res['items'])), ('Новое имя', 0))

    def test_idempotent_retry_dedupe_and_delta(self):
        _, owner = self.user()
        r = self.create(owner, [it(1, pos='V')])
        pid, rev = r['id'], r['rev']
        batch = [{'op': 'add-000002', 'kind': 'add', 'item': it(2, pos='k')},
                 {'op': 'add-000003', 'kind': 'add', 'item': it(3, ref='dz:1001', pos='m')}]
        first = self.ops(owner, pid, batch, since=rev)[2]
        self.assertEqual([x['status'] for x in first['results']], ['ok', 'exists'])
        self.assertEqual(first['rev'], rev + 1); self.assertFalse(first['full'])
        self.assertEqual([x['id'] for x in first['items']], ['item000002'])
        retry = self.ops(owner, pid, batch, since=first['rev'])[2]
        self.assertEqual(retry['rev'], first['rev']); self.assertTrue(retry['unchanged'])
        mv = self.ops(owner, pid, [{'op': 'move-00001', 'kind': 'move', 'id': 'item000002', 'pos': 'z'},
                                   {'op': 'rm-0000001', 'kind': 'remove', 'id': 'item000001'}], since=first['rev'])[2]
        self.assertEqual(mv['removed'], ['item000001']); self.assertEqual(mv['items'][0]['pos'], 'z')
        full = self.http(f'/auth/shared/{pid}', jar=owner)[2]
        self.assertEqual([x['id'] for x in full['items']], ['item000002'])
        # Re-adding the same catalog track after removal is allowed with a new item id.
        again = self.ops(owner, pid, [{'op': 'add-again1', 'kind': 'add', 'item': dict(it(9, ref='dz:1001'))}])[2]
        self.assertEqual(again['results'][0]['status'], 'ok')

    def test_concurrent_writers_converge(self):
        _, owner = self.user(0); _, friend = self.user(1)
        pid = self.create(owner)['id']
        self.invite_join(owner, pid, friend)
        def write(args):
            jar, base = args
            return self.ops(jar, pid, [{'op': f'c{base:04d}{k:04d}', 'kind': 'add',
                                        'item': it(base + k, pos=shared.key_between('', None) + str(base + k) + '1')} for k in range(1, 21)])[0]
        with concurrent.futures.ThreadPoolExecutor(4) as pool:
            codes = list(pool.map(write, [(owner, 0), (friend, 100), (owner, 200), (friend, 300)]))
        self.assertEqual(codes, [200] * 4)
        full = self.http(f'/auth/shared/{pid}', jar=friend)[2]
        self.assertEqual(len(full['items']), 80); self.assertEqual(full['rev'], 2 + 4)  # create, join, 4 batches

    def test_limits(self):
        _, jar = self.user()
        pid = self.create(jar)['id']
        self.assertEqual(self.ops(jar, pid, [{'op': f'op{n:08d}', 'kind': 'remove', 'id': 'item000001'} for n in range(101)])[0], 400)
        for b in range(3):
            self.assertEqual(self.ops(jar, pid, [{'op': f'b{b}{n:07d}', 'kind': 'remove', 'id': 'item000001'} for n in range(100)])[0], 200)
        self.assertEqual(self.ops(jar, pid, [{'op': 'over000001', 'kind': 'remove', 'id': 'item000001'}])[0], 429)
        self.now += 61
        self.assertEqual(self.ops(jar, pid, [{'op': 'over000001', 'kind': 'remove', 'id': 'item000001'}])[0], 200)

    # --------------------------------------------------------------------- membership
    def test_leave_remove_transfer_delete(self):
        owner_id, owner = self.user(0); friend_id, friend = self.user(1); _, third = self.user(2)
        pid = self.create(owner, [it(1)])['id']
        self.invite_join(owner, pid, friend); self.invite_join(owner, pid, third)
        self.assertEqual(self.http(f'/auth/shared/{pid}/members', {'action': 'leave'}, owner)[0], 409)
        self.assertEqual(self.http(f'/auth/shared/{pid}/members', {'action': 'remove', 'uid': owner_id}, friend)[0], 403)
        self.assertEqual(self.http(f'/auth/shared/{pid}/members', {'action': 'leave'}, third)[0], 200)
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=third)[0], 404)
        self.assertEqual(self.http(f'/auth/shared/{pid}/members', {'action': 'role', 'uid': friend_id, 'role': 'viewer'}, owner)[0], 200)
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=friend)[2]['role'], 'viewer')
        self.assertEqual(self.http(f'/auth/shared/{pid}/members', {'action': 'transfer', 'uid': friend_id}, owner)[0], 200)
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=friend)[2]['role'], 'owner')
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=owner)[2]['role'], 'editor')
        self.assertEqual(self.http(f'/auth/shared/{pid}/delete', {}, owner)[0], 403)
        self.assertEqual(self.http(f'/auth/shared/{pid}/delete', {}, friend)[0], 200)
        self.assertEqual(self.http(f'/auth/shared/{pid}', jar=owner)[0], 410)
        self.assertEqual(self.http('/auth/shared', jar=owner)[2]['playlists'], [])

    def test_activity_and_avatar_member_only(self):
        owner_id, owner = self.user(0); friend_id, friend = self.user(1); _, stranger = self.user(2)
        pid = self.create(owner, [it(1)])['id']
        self.invite_join(owner, pid, friend)
        self.ops(friend, pid, [{'op': 'add-feed01', 'kind': 'add', 'item': it(2)}])
        ev = self.http(f'/auth/shared/{pid}/activity', jar=owner)[2]['events']
        self.assertEqual([e['kind'] for e in ev][:3], ['add', 'join', 'create'])
        self.assertEqual(ev[0]['t'], 'Track 2')
        self.assertEqual(self.http(f'/auth/shared/{pid}/avatar', jar=owner, q='uid=' + friend_id)[0], 200)
        self.assertEqual(self.http(f'/auth/shared/{pid}/avatar', jar=stranger, q='uid=' + friend_id)[0], 404)

    # -------------------------------------------------------------------- maintenance
    def test_purge_raises_floor_and_forces_snapshot(self):
        _, jar = self.user()
        r = self.create(jar, [it(1), it(2)])
        pid = r['id']
        rm = self.ops(jar, pid, [{'op': 'rm-purge01', 'kind': 'remove', 'id': 'item000001'}])[2]
        self.now += 31 * 86400
        with self.a.transaction() as c:
            self.assertEqual(shared.purge(c, self.now), 1)
        _, jar = self.user(0, fresh=False)
        old = self.http(f'/auth/shared/{pid}', jar=jar, q='since=1')[2]
        self.assertTrue(old['full']); self.assertEqual([x['id'] for x in old['items']], ['item000002'])
        cur = self.http(f'/auth/shared/{pid}', jar=jar, q='since=' + str(rm['rev']))[2]
        self.assertTrue(cur['unchanged'])

    def test_body_limit(self):
        _, jar = self.user()
        big = {'title': 'x', 'items': [it(n) for n in range(shared.MAX_ITEMS + 1)]}
        self.assertIn(self.http('/auth/shared/create', big, jar)[0], (413,))

    # ---------------------------------------------------------------- fractional keys
    def test_fractional_keys_fuzz(self):
        rnd = random.Random(7)
        keys = []
        for _ in range(3000):
            i = rnd.randint(0, len(keys))
            a = keys[i - 1] if i > 0 else ''
            b = keys[i] if i < len(keys) else None
            k = shared.key_between(a, b)
            self.assertTrue(shared.valid_pos(k), k)
            self.assertTrue(a < k and (b is None or k < b), (a, k, b))
            keys.insert(i, k)
        self.assertEqual(keys, sorted(keys))
        self.assertLess(max(map(len, keys)), 20)
        # Worst case: always insert right after the same key.
        a, b, longest = 'V', 'W', 0
        for _ in range(500):
            b = shared.key_between(a, b); longest = len(b)
        self.assertLessEqual(longest, 128)


if __name__ == '__main__':
    unittest.main()
