#!/usr/bin/env python3
"""Accounts 1.2 -> 1.3 (shared playlists). Fail-closed source update.

Installs only web.py, maintenance.py and the new shared.py. Never touches accounts.env, SMTP settings,
JWT keys, service/timer files or the database. Shared tables are created by the service on first start.
Run --check first. Stop the service before --apply; start it after all files are installed.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
import tempfile

# Exact 1.2.0 release sources. Anything else live means local edits (e.g. SMTP fixes): refuse, merge by hand.
V12 = {
    'core.py': 'acb8c016ed61123bd41a475462a6d3536e5b46a8ba4394f316875869ad257cf6',
    'web.py': '9e15cc6b11e7b509a8868640392d953520fff097ae6c56518b017de21b1f24bc',
    'library.py': '53274aa2ca66427704c73d9560ad56e65fb45897b73c7c5f8c66dd6e6ccdda4e',
    'profiles.py': '13d33af00229bf61105acac1126d04f93875521ae7229d3e473e27cdf560fd4f',
    'maintenance.py': '301392aa162cc834fc33d906d76936609c649719011cc84c29656fd5bc713696',
}
FILES = ('web.py', 'maintenance.py', 'shared.py')
# 1.3 web.py imports these unchanged 1.2 modules; they must be present and must be the 1.2 release.
REQUIRED = ('core.py', 'library.py', 'profiles.py')


def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def install(target, apply=False):
    target = Path(target).resolve()
    payload = Path(__file__).resolve().parent
    if target == payload: raise ValueError('Refusing to install over the release payload')
    if not target.is_dir(): raise ValueError('Target directory does not exist')
    for name in REQUIRED:
        live = target / name
        if live.is_symlink(): raise ValueError('Refusing symlink: ' + name)
        if not live.is_file(): raise ValueError('Required live file missing: ' + name + '. Install Accounts 1.2 first.')
        if digest(live) not in {V12[name], digest(payload / name)}:
            raise ValueError('Modified live file: ' + name + '. Accounts 1.3 needs the 1.2 release of it; merge manually.')
    for name in FILES:
        if not (payload / name).is_file(): raise ValueError('Incomplete release: ' + name)
        live = target / name
        if live.is_symlink(): raise ValueError('Refusing symlink: ' + name)
        if live.exists():
            allowed = {digest(payload / name)}
            if name in V12: allowed.add(V12[name])
            if digest(live) not in allowed:
                raise ValueError('Modified live file: ' + name + '. Refusing to overwrite; preserve live SMTP/custom fixes and merge manually.')
        elif name != 'shared.py':
            raise ValueError('Required live file missing: ' + name)
    if not apply:
        print('Preflight OK. env, keys, SMTP settings, service files and database will not be modified.')
        return
    backup = Path(tempfile.mkdtemp(prefix='accounts-before-1.3-', dir=target.parent))
    existed = []
    for name in FILES:
        if (target / name).exists(): shutil.copy2(target / name, backup / name); existed.append(name)
    replaced = []
    try:
        for name in FILES:
            staged = target / (name + '.shared-update-tmp')
            with staged.open('xb') as stream: stream.write((payload / name).read_bytes())
            staged.chmod(0o644)
            staged.replace(target / name); replaced.append(name)
    except BaseException:
        for name in reversed(replaced):
            if name in existed: shutil.copy2(backup / name, target / name)
            else: (target / name).unlink()
        raise
    print('Sources installed. Backup: ' + str(backup))
    print('Start the accounts service, then verify /auth/health: version 1.3.0, shared_enabled true.')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target', required=True)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true'); mode.add_argument('--apply', action='store_true')
    args = p.parse_args()
    try: install(args.target, args.apply)
    except (ValueError, OSError) as error: p.exit(1, str(error) + '\n')


if __name__ == '__main__': main()
