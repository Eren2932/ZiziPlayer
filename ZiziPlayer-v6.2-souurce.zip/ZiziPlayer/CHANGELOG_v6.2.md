# ZiziPlayer v6.2.0 (versionCode 8)

Built on the real, working **v6.1** source. The 7.0 / 7.1 changelogs left in the repository have no
matching source and are not a base for anything.

Everything below is measured against the reference screenshots, not eyeballed. The shots are 576 px
wide on a 360 dp screen, i.e. **1.6 px/dp**, which is what every number here is derived from.

---

## 1. Cover colours: own quantiser instead of AndroidX Palette

**Problem.** v6.1 asked `Palette` for `vibrantSwatch` / `mutedSwatch` / `darkVibrantSwatch`. On a
photographic cover that returns a *minority* accent - one bright petal, a logo corner - and
`mutedSwatch` very often lands on the same hue as `vibrant`. Three "different" shades collapsed into
one, so the backdrop looked like it was picked from a handful of canned palettes.

**Fix.** `Artwork.extract()` is now a purpose-built quantiser:

- the thumbnail is walked at a stride (~4096 samples, no per-pixel allocation)
- background-ish pixels are dropped: `S < 0.10`, `V < 0.05`, and blown-out `V > 0.97 && S < 0.16`
  (letterboxing, white studio backdrops, black bars are not identity)
- the rest goes into **24 hue buckets**, weighted by coverage **and** colourfulness:
  `w = (0.35 + S) * (0.45 + 1.10 * V * (1 - 0.55 * V))`
- **circular mean per bucket**, so a hue straddling the 0/360 seam is not averaged into its own
  complement (the old code could turn red into cyan)
- `primary` = heaviest bucket, `secondary` = heaviest bucket **at least 28 deg away** (a genuinely
  different hue, so the gradient travels down the screen the way the reference does),
  `deep` = heaviest bucket among the dark pixels, carrying **its own** saturation and brightness
- a monochrome cover returns a neutral grey triple instead of inventing a hue out of sensor noise

Cost: 1-3 ms on a background thread, once per track for the lifetime of the install (still persisted
next to the thumbnail, so nothing changed about scroll behaviour or the disk cache format).

## 2. Backdrop ramp: saturation is normalised, not scaled

`Color.shade(sat, value, cap)` is gone, replaced by `Color.tone(mul, value, floor, ceiling)`.

The old code did `s = (s * k).coerceAtMost(cap)` - which can only ever push saturation **down**.
Measured off the reference, a dull cover has to come out **more** saturated than it is, so every
muted sleeve collapsed into the same grey-brown. That is the actual reason it looked like the app
owned five hardcoded palettes.

New law, fitted against the ten stops measured on both reference players:

```
S_out = (0.16 + 0.41 * sqrt(S_in)).coerceIn(0.12, 0.44) * perStopMultiplier
```

The square root compresses the top of the range, so a neon sleeve and a pastel one land within a few
percent of each other instead of one blowing out.

**Mean error over the ten measured stops: 0.031. v6.1 was at 0.122 on the vivid cover.**

Brightness stops also came off the measurement - the reference peaks at **68 %** of the height, not
80 %, so the gradient positions moved from `0 / .20 / .52 / .80 / 1` to `0 / .22 / .45 / .68 / 1`:

| stop | V |
|---|---|
| status bar | 0.088 |
| upper | 0.132 |
| middle | 0.178 |
| **peak (68 %)** | **0.240** |
| bottom | 0.122 |

`withAccent()` now lifts the accent into a legible band (`S` 0.30..0.72, `V` 0.94) instead of a flat
multiply, so the progress bar and active icons keep their contrast on any cover. A grey cover yields
a near-white accent rather than a muddy one.

## 3. No more coloured placeholder tiles

`fallbackSwatches()` used to hand a fully saturated hue to any track without artwork, so an untagged
folder turned the library into a paintbox and the player backdrop into lime green. It is now neutral
by design (`S` 0.11..0.15, `V` 0.21..0.44): tiles stay distinguishable from each other, the screen
reads as the graphite base.

The tile itself shows a **monogram** derived from the title (or artist), which identifies a row at a
glance in a list of 3000 untagged files - and costs zero extra drawables. The old note glyph remains
the fallback when there is no letter or digit to use.

## 4. Track list geometry, measured

| | v6.1 | v6.2 | reference |
|---|---|---|---|
| row pitch | 62 dp | **56 dp** | 90 px = 56 dp |
| artwork | 48 dp | 48 dp | 76 px = 48 dp |
| artwork radius | 8 dp | **6 dp** | ~10 px = 6 dp |
| row radius | 10 dp | **8 dp** | - |
| title | 15.5 sp | **16 sp** | ~16 sp |
| artist | 13 sp | **13.5 sp** | ~13.5 sp |
| trailing icons | 40 / 36 dp | **38 / 34 dp** | inset 20 dp |
| list padding | 12 / 6 / 4 | **10 / 8 / 2** | - |

## 5. Dimmed modifier tail in titles

A real library is 60 % metadata: `0_0 Slowed + Reverb`, `pursuit (super slowed)`,
`AUTOMOTIVO DO MAL V1 (Super Slowed)`. The reference renders that trailing modifier in a dimmer
colour, and that is what makes a screen of long titles scannable instead of a wall of bold.

New `TrackTitle()` in `Common.kt` splits the title on a modifier keyword (slowed, sped up, nightcore,
reverb, remix, bass boosted, extended mix, instrumental, mashup, 8d audio, lofi) and dims from there
to the end. Genre words such as *hardstyle* are deliberately **not** in the list, matching the
reference: `escuridao (hardstyle) Slowed` dims only ` Slowed`.

The split index is cached in an `LruCache` keyed by title, so scrolling 3000 rows runs the regex once
per unique title per session - never once per frame.

## 6. Mini player: full-bleed strip

v6.1 drew a floating rounded card: 10/6 dp margins, 16 dp radius, 8 dp inner padding, 44 dp cover,
46 dp buttons - roughly **68 dp** of screen for a strip the reference does in 40.

Now a full-width bar flush on the navigation bar, **46 dp** tall (40 would break the minimum touch
target for the two buttons), with the progress line moved to the **top** where it doubles as the
divider. Cover 34 dp / radius 5, title 13.5 sp with the same dimmed tail, artist 11.5 sp,
buttons 38 / 36 dp.

## 7. Round buttons that are actually round

Three separate bugs in `RoundIconButton`:

- `RoundedCornerShape(percent = 50)` is only a circle when the box is square, and the ripple was
  clipped to it - which is exactly why shuffle and repeat read as rounded **squares** on press. Now
  `CircleShape` plus an unbounded ripple that overshoots the bounds slightly, like every system player.
- there was no active state at all: "shuffle on" was a tint change worth a couple of percent of
  contrast. `active = true` now paints a soft circular wash behind the glyph.
- repeat-one was distinguishable only by a 4 px "1" inside the glyph. `activeDot = true` adds the
  indicator dot underneath.

`Icons.Filled.Shuffle` / `Repeat` are drawn with mitred corners - the other half of the "squarish"
look. The player controls now use the **Rounded** set (same glyphs, round joints and caps).
`material-icons-extended` was already a dependency, so this costs nothing.

Both new parameters are trailing defaults: **every existing call site compiles untouched.**

---

## Files touched

```
app/build.gradle.kts                                  versionCode 7 -> 8, versionName 6.1.0 -> 6.2.0
app/src/main/java/app/ziziplayer/ui/components/Artwork.kt      quantiser, neutral fallback, monogram
app/src/main/java/app/ziziplayer/ui/components/Common.kt       RoundIconButton, TrackTitle
app/src/main/java/app/ziziplayer/ui/theme/ZiziTheme.kt         tone(), ramp, stops, withAccent
app/src/main/java/app/ziziplayer/ui/screens/LibraryScreen.kt   row geometry, mini player
app/src/main/java/app/ziziplayer/ui/screens/PlayerScreen.kt    controls
```

No new dependency, no database migration, no change to the persisted swatch format (still three
packed ints), so existing artwork caches stay valid.

## Not done, on purpose

- **Not compiled.** There is no Android SDK in my sandbox, so this is verified by algorithm
  simulation (the quantiser and the colour law were ported to Python and run against the reference
  screenshots), plus brace/paren/import checks on every file - not by `gradlew assembleDebug`.
  Build it before trusting it.
- The four base themes (Graphite / Midnight / Amoled / Sunset) are left as they are: that is a
  deliberate setting, not the bug you were describing.
