# ZiziPlayer v4.0

Нативный локальный Android-плеер на Kotlin, Jetpack Compose и Media3. Создан для офлайн-музыки: импорт из MediaStore и выбранных системных папок, фоновые сессии, избранное, плейлисты и индивидуальные speed/pitch/reverb-настройки.

## Функции

- Локальные треки из медиатеки Android и папок SAF.
- Постоянное разрешение на выбранные папки.
- Фоновое воспроизведение Media3, системное уведомление и гарнитура.
- Карусель обложек: 892 px в режиме воспроизведения и 801 px на паузе в референсном размере 1080 px.
- Надёжная синхронизация свайпа через `settledPage`, без конфликта плеера с пальцем.
- Избранное и пользовательские плейлисты в Room.
- Скорость 0.5–2.0×, тональность −12…+12 полутонов, пресеты и системная реверберация.
- Сохранение FX отдельно для каждого трека.
- Темы: Графит, Полночь, AMOLED и Закат.

## Получение APK через GitHub

1. Создайте пустой репозиторий на GitHub.
2. Распакуйте ZIP и загрузите **содержимое папки ZiziPlayer** в корень репозитория.
3. Откройте вкладку **Actions** → **Build ZiziPlayer APK** → **Run workflow**.
4. После сборки откройте завершённый запуск и скачайте артефакт **ZiziPlayer-APK**.
5. Внутри будет подписанный `ZiziPlayer-v6.0.0.apk`.

> Workflow создаёт временный release-ключ. Для обновлений установленного APK сохраните собственный постоянный keystore и замените этап подписи через GitHub Secrets.

## Локальная сборка

Требуются JDK 17, Android SDK 35 и Gradle 8.9:

````bash
gradle :app:assembleDebug
````

APK появится в `app/build/outputs/apk/debug/`.

## Разрешения

- Android 13+: `READ_MEDIA_AUDIO`, `POST_NOTIFICATIONS`.
- Android 12 и ниже: `READ_EXTERNAL_STORAGE`.
- Выбранные папки: системный Storage Access Framework с persistable URI permission.

## Структура

- `data/` — Room, DataStore, MediaStore и SAF.
- `playback/` — Media3 service и controller.
- `ui/screens/` — библиотека, темы, полноэкранный плеер и FX.
- `.github/workflows/build.yml` — signed release APK.
