package app.ziziplayer.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class MusicScanner(private val context: Context) {
    suspend fun scanMediaStore(): List<TrackEntity> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val columns = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.RELATIVE_PATH
        )
        val result = mutableListOf<TrackEntity>()
        runCatching { context.contentResolver.query(collection, columns, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, null) }.getOrNull()?.use { c ->
            val idI=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dateI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val albumIdI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val pathI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
            while(c.moveToNext()) {
                val id=c.getLong(idI); val uri=ContentUris.withAppendedId(collection,id)
                val albumId=c.getLong(albumIdI)
                result += TrackEntity(
                    id="media:$id", uri=uri.toString(), title=c.getString(titleI) ?: "Без названия",
                    artist=(c.getString(artistI) ?: "Неизвестный артист").replace("<unknown>", "Неизвестный артист"),
                    album=c.getString(albumI) ?: "", durationMs=c.getLong(durationI),
                    artworkUri=ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString(),
                    sourceFolder=c.getString(pathI)?.trimEnd('/')?.substringAfterLast('/') ?: "Устройство",
                    dateAdded=c.getLong(dateI)*1000
                )
            }
        }
        result
    }

    suspend fun scanTree(treeUri: Uri): List<TrackEntity> = withContext(Dispatchers.IO) {
        val root=DocumentFile.fromTreeUri(context,treeUri) ?: return@withContext emptyList()
        val out=mutableListOf<TrackEntity>()
        fun walk(node: DocumentFile, folder: String) {
            node.listFiles().forEach { file ->
                if(file.isDirectory) walk(file,file.name ?: folder)
                else if(file.isFile && isAudio(file)) {
                    val meta=readMeta(file.uri)
                    out += TrackEntity(
                        id="saf:"+UUID.nameUUIDFromBytes(file.uri.toString().toByteArray()), uri=file.uri.toString(),
                        title=meta.title ?: file.name?.substringBeforeLast('.') ?: "Без названия",
                        artist=meta.artist ?: "Неизвестный артист", album=meta.album ?: "",
                        durationMs=meta.duration, sourceFolder=folder
                    )
                }
            }
        }
        walk(root,root.name ?: "Выбранная папка"); out
    }

    private fun isAudio(file: DocumentFile): Boolean = file.type?.startsWith("audio/") == true ||
        file.name?.substringAfterLast('.',"")?.lowercase() in setOf("mp3","m4a","aac","flac","ogg","wav","opus")

    private data class AudioMeta(val title:String?,val artist:String?,val album:String?,val duration:Long)
    private fun readMeta(uri: Uri): AudioMeta = runCatching {
        val r=android.media.MediaMetadataRetriever()
        try {
            r.setDataSource(context,uri)
            AudioMeta(
                r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally { r.release() }
    }.getOrDefault(AudioMeta(null,null,null,0L))
}
