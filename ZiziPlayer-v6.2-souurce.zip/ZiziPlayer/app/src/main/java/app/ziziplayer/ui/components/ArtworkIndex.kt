package app.ziziplayer.ui.components

import android.content.Context
import java.util.Collections

/**
 * Persists what we already know about covers so the expensive probe is paid once per file, ever:
 * which tracks have no artwork at all, and the colours extracted from the ones that do.
 *
 * Writes are batched - v5 hit SharedPreferences once per discovered track while scrolling.
 */
internal class ArtworkIndex(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("zizi_artwork", Context.MODE_PRIVATE)
    private val colors = context.applicationContext.getSharedPreferences("zizi_art_colors", Context.MODE_PRIVATE)
    private val pendingNoArt = Collections.synchronizedSet(HashSet<String>())
    private val pendingColors = Collections.synchronizedMap(HashMap<String, String>())

    fun noArtIds(): Set<String> = prefs.getStringSet(KEY_NO_ART, emptySet()) ?: emptySet()

    fun swatches(): Map<String, ArtSwatches> {
        val out = HashMap<String, ArtSwatches>()
        colors.all.forEach { (id, raw) ->
            ArtSwatches.unpack(raw as? String)?.let { out[id] = it }
        }
        return out
    }

    fun rememberNoArt(id: String) {
        pendingNoArt.add(id)
        if (pendingNoArt.size >= 16) flushNoArt()
    }

    fun rememberSwatches(id: String, swatches: ArtSwatches) {
        pendingColors[id] = swatches.pack()
        if (pendingColors.size >= 16) flushColors()
    }

    /** Called when a prefetch batch settles and when the app goes to the background. */
    fun flush() { flushNoArt(); flushColors() }

    private fun flushNoArt() {
        val snapshot = synchronized(pendingNoArt) { HashSet(pendingNoArt).also { pendingNoArt.clear() } }
        if (snapshot.isEmpty()) return
        val merged = HashSet(noArtIds())
        merged.addAll(snapshot)
        prefs.edit().putStringSet(KEY_NO_ART, merged).apply()
    }

    private fun flushColors() {
        val snapshot = synchronized(pendingColors) { HashMap(pendingColors).also { pendingColors.clear() } }
        if (snapshot.isEmpty()) return
        val editor = colors.edit()
        snapshot.forEach { (id, packed) -> editor.putString(id, packed) }
        editor.apply()
    }

    companion object { private const val KEY_NO_ART = "no_art_ids" }
}
