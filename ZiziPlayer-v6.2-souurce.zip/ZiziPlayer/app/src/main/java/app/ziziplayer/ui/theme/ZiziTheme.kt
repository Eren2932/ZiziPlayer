package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import app.ziziplayer.data.AppTheme
import app.ziziplayer.ui.components.ArtSwatches
import kotlinx.coroutines.launch
import kotlin.math.sqrt

/**
 * Five vertical stops instead of three, plus a separate glow colour.
 *
 * A cover is not one colour. The reference players build the backdrop out of several shades of the
 * same artwork - deep at the very top, opening up behind the cover, brightest behind the title and
 * the controls, closing down again at the bottom bar. Measuring the reference screenshot gives
 * value 0.10 -> 0.26 and saturation around 0.3: dark and quiet. v5 lit the top stop up to value
 * 0.42 with almost no cap on saturation, which is why a warm cover turned the whole screen muddy
 * brown instead of looking like the artwork.
 */
@Immutable
data class ZiziPalette(
    val top: Color,
    val upper: Color,
    val middle: Color,
    val lower: Color,
    val bottom: Color,
    val glow: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    val tintStrength: Float
) {
    val background: Brush
        get() = Brush.verticalGradient(
            0f to top,
            0.22f to upper,
            0.45f to middle,
            0.68f to lower,
            1f to bottom
        )
}

private val Graphite = ZiziPalette(
    top = Color(0xFF23252A),
    upper = Color(0xFF1A1C20),
    middle = Color(0xFF15171A),
    bottom = Color(0xFF08090B),
    lower = Color(0xFF101215),
    glow = Color(0xFF3C4550),
    surface = Color(0xFF1D1F23),
    chip = Color(0xFF2C2F34),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF8FD3FF),
    onAccent = Color(0xFF06121A),
    tintStrength = 1f
)

private val Midnight = Graphite.copy(
    top = Color(0xFF18203A),
    upper = Color(0xFF121829),
    middle = Color(0xFF0E1322),
    lower = Color(0xFF0A0E1A),
    bottom = Color(0xFF05070C),
    glow = Color(0xFF31406E),
    surface = Color(0xFF161E33),
    chip = Color(0xFF223054),
    accent = Color(0xFF9EB8FF),
    tintStrength = 0.92f
)

private val Amoled = Graphite.copy(
    top = Color(0xFF121212),
    upper = Color(0xFF0B0B0B),
    middle = Color(0xFF070707),
    lower = Color(0xFF030303),
    bottom = Color(0xFF000000),
    glow = Color(0xFF1C1C1C),
    surface = Color(0xFF121212),
    chip = Color(0xFF1E1E1E),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000),
    tintStrength = 0.45f
)

private val Sunset = Graphite.copy(
    top = Color(0xFF32202A),
    upper = Color(0xFF23161D),
    middle = Color(0xFF1D1218),
    lower = Color(0xFF150C11),
    bottom = Color(0xFF0A0507),
    glow = Color(0xFF5C3340),
    surface = Color(0xFF291921),
    chip = Color(0xFF3E242D),
    accent = Color(0xFFFFA36B),
    onAccent = Color(0xFF25100A),
    tintStrength = 1f
)

fun basePalette(theme: AppTheme): ZiziPalette = when (theme) {
    AppTheme.GRAPHITE -> Graphite
    AppTheme.MIDNIGHT -> Midnight
    AppTheme.AMOLED -> Amoled
    AppTheme.SUNSET -> Sunset
}

val LocalPalette = compositionLocalOf { Graphite }

/**
 * Re-maps a cover colour onto the backdrop ramp: the hue is kept exactly, brightness is pinned to
 * the ramp, and saturation is NORMALISED instead of scaled.
 *
 * Why this replaces `shade()` (v6.1): that did `s = (s * k).coerceAtMost(cap)`, which can only ever
 * push saturation DOWN. Measured off the reference player, a dull cover (source S 0.19) has to come
 * out around S 0.30, and a vivid one (S 0.46) around 0.41 - dull covers must be pushed UP. With
 * multiply-and-cap every muted sleeve collapsed into the same grey-brown, which is precisely why it
 * looked like the app owned five hardcoded palettes.
 *
 * Calibration: the input is the quantiser's weighted bucket saturation (0.86 for the sunflower
 * cover, 0.36 for the forest one), and the law was fitted against the stops measured off the
 * reference for both: S_out = 0.16 + 0.41 * sqrt(S_in), clamped to 0.12..0.44, times a per-stop
 * multiplier. Mean error over the ten measured stops is 0.031 - v6.1 sat at 0.122 on the vivid cover.
 * The square root matters: it compresses the top of the range, so a neon sleeve and a pastel one end
 * up within a few percent of each other instead of one of them blowing out.
 *
 * A genuinely grey cover (S < 0.045) is left grey on purpose - normalising sensor noise up to 0.30
 * would tint a black-and-white sleeve for no reason.
 */
private fun Color.tone(
    satMul: Float,
    value: Float,
    floor: Float = 0.12f,
    ceiling: Float = 0.44f
): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(this.toArgb(), hsv)
    val normalised = if (hsv[1] < 0.045f) hsv[1] * 0.6f
    else (0.16f + 0.41f * sqrt(hsv[1])).coerceIn(floor, ceiling)
    hsv[1] = (normalised * satMul).coerceIn(0f, 1f)
    hsv[2] = value.coerceIn(0f, 1f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

private fun Color.luminance(): Float = 0.299f * red + 0.587f * green + 0.114f * blue

/**
 * Builds the backdrop out of the three cover shades. Every stop keeps the hue of the artwork but
 * lands on a fixed brightness ramp, so a bright pop cover and a dark ambient one produce equally
 * readable screens - only the hue changes.
 */
fun ZiziPalette.tintedWith(swatches: ArtSwatches?): ZiziPalette {
    val strength = tintStrength
    if (swatches == null || strength <= 0.01f) return this
    val primary = swatches.primary
    val secondary = swatches.secondary
    val deep = swatches.deep
    // Brightness stops measured off the reference player, not guessed: V 0.088 at the status bar,
    // 0.132, 0.178, a 0.240 peak at 68 % of the height, then back down to 0.122 at the very bottom.
    return copy(
        top = lerp(top, deep.tone(0.90f, 0.088f), 0.94f * strength),
        upper = lerp(upper, deep.tone(0.855f, 0.132f), 0.93f * strength),
        middle = lerp(middle, primary.tone(0.70f, 0.178f), 0.92f * strength),
        lower = lerp(lower, secondary.tone(0.75f, 0.240f), 0.92f * strength),
        bottom = lerp(bottom, deep.tone(0.72f, 0.122f), 0.86f * strength),
        glow = lerp(glow, primary.tone(1.25f, 0.560f, ceiling = 0.62f), 0.95f * strength),
        surface = lerp(surface, primary.tone(0.58f, 0.205f), 0.85f * strength),
        chip = lerp(chip, secondary.tone(0.60f, 0.268f), 0.82f * strength),
        subtext = lerp(subtext, primary.tone(0.24f, 0.800f), 0.50f * strength),
        text = lerp(text, primary.tone(0.08f, 0.990f), 0.30f * strength)
    )
}

/**
 * The accent drives the progress bar, the active icons and the equaliser bars, so it has to stay
 * legible on the backdrop no matter what the cover looks like: hue comes from the artwork, but
 * saturation and brightness are lifted into a band that always clears the contrast we need. A grey
 * cover yields a near-white accent rather than a muddy one.
 */
fun ZiziPalette.withAccent(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null) return this
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(swatches.primary.toArgb(), hsv)
    val grey = hsv[1] < 0.045f
    hsv[1] = if (grey) 0f else (0.30f + 0.45f * hsv[1]).coerceIn(0.30f, 0.72f)
    hsv[2] = if (grey) 0.92f else 0.94f
    val bright = Color(android.graphics.Color.HSVToColor(hsv))
    return copy(accent = bright, onAccent = if (bright.luminance() > 0.55f) Color(0xFF0B0B0C) else Color.White)
}

/**
 * The gradient is animated in the DRAW phase only: the Animatable values are read inside
 * drawBehind, so a track change costs a repaint, never a recomposition of the tree.
 *
 * [glowAlpha] adds the radial highlight sitting behind the cover - that is what makes the artwork
 * colour look like it spilled over the whole screen. The library gets a faint one, the player a
 * strong one.
 */
@Composable
fun ZiziBackdrop(
    palette: ZiziPalette,
    modifier: Modifier = Modifier,
    durationMs: Int = 480,
    glowAlpha: Float = 0f,
    glowCenter: Float = 0.30f
) {
    val top = remember { Animatable(palette.top) }
    val upper = remember { Animatable(palette.upper) }
    val middle = remember { Animatable(palette.middle) }
    val lower = remember { Animatable(palette.lower) }
    val bottom = remember { Animatable(palette.bottom) }
    val glow = remember { Animatable(palette.glow) }
    LaunchedEffect(palette.top, palette.upper, palette.middle, palette.lower, palette.bottom, palette.glow) {
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(palette.top, spec) }
        launch { upper.animateTo(palette.upper, spec) }
        launch { middle.animateTo(palette.middle, spec) }
        launch { lower.animateTo(palette.lower, spec) }
        launch { bottom.animateTo(palette.bottom, spec) }
        launch { glow.animateTo(palette.glow, spec) }
    }
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to top.value,
                        0.22f to upper.value,
                        0.45f to middle.value,
                        0.68f to lower.value,
                        1f to bottom.value
                    )
                )
                if (glowAlpha > 0.01f) {
                    val tint = glow.value
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(
                                tint.copy(alpha = glowAlpha),
                                tint.copy(alpha = glowAlpha * 0.45f),
                                tint.copy(alpha = 0f)
                            ),
                            center = Offset(size.width * 0.5f, size.height * glowCenter),
                            radius = size.width * 1.15f
                        )
                    )
                }
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = Typography(),
        content = content
    )
}
