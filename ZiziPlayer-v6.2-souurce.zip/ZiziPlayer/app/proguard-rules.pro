# ---- ZiziPlayer keep rules (release / R8) ----

# Room: generated implementations and entities are looked up by name.
-keep class app.ziziplayer.data.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.room.paging.**

# ViewModels are instantiated reflectively by ViewModelProvider (`by viewModels()`).
# The lifecycle artifact ships a rule for this, but the app must not depend on that detail:
# losing the constructor is a release-only crash on the very first frame.
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class app.ziziplayer.ui.MainViewModel { *; }

# Application and Media3 session service are resolved through the manifest / IPC.
-keep class app.ziziplayer.ZiziApplication { *; }
-keep class app.ziziplayer.playback.PlaybackService { *; }
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# The promoted-notification flag is read by reflection (Android 16+, absent below it).
-keepclassmembers class android.app.Notification { public static final int FLAG_PROMOTED_ONGOING; }

# Palette + coroutines internals
-keep class androidx.palette.graphics.** { *; }
-dontwarn kotlinx.coroutines.**
