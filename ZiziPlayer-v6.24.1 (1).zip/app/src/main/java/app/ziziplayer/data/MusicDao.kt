package app.ziziplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Потолок переменных в `IN (...)` у SQLite — 999. Берём с запасом. */
private const val IN_CHUNK_DAO = 400

@Dao
interface MusicDao {
    /**
     * The library: everything on this phone, plus the remote tracks the user chose to keep.
     *
     * The `savedAt IS NOT NULL` half is the whole point of the split - see [TrackEntity.savedAt].
     * Remote rows that were merely listened to are deliberately invisible here, which is also why
     * the heavy filter/search/sort pipeline in the ViewModel does not re-run every time somebody
     * taps a search result.
     */
    @Query("SELECT * FROM tracks WHERE source = 'local' OR savedAt IS NOT NULL ORDER BY title COLLATE NOCASE")
    fun observeTracks(): Flow<List<TrackEntity>>

    /**
     * Everything, saved or not. Used only to turn ids into tracks - the mini player, the queue,
     * the FX lookup. A currently playing remote track must resolve here even though it has no
     * business being in the library list yet.
     */
    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE")
    fun observeAllTracks(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE id = :id") suspend fun track(id: String): TrackEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTracks(tracks: List<TrackEntity>)
    /**
     * v4 used "DELETE FROM tracks WHERE id NOT IN (:ids)". SQLite caps a statement at 999 bound
     * variables, so every rescan crashed on libraries larger than that. The stale ids are now
     * computed in Kotlin and deleted in small chunks.
     */
    /**
     * LOCAL ids only, and the filter is not an optimisation - it is the difference between working
     * and losing data.
     *
     * The rescan deletes every id it did not find on disk. A scanner physically cannot find a
     * network track, so before this filter existed the first rescan after adding one - i.e. the
     * next app launch - would delete it, taking its favourite flag, its playlist membership and its
     * play count with it. Remote rows are swept by [forgettableRemoteIds] instead, on their own
     * terms.
     */
    @Query("SELECT id FROM tracks WHERE source = 'local'") suspend fun allTrackIds(): List<String>
    @Query("DELETE FROM tracks WHERE id IN (:ids)") suspend fun deleteTracks(ids: List<String>)

    /**
     * Snapshot used by the scanner to avoid re-reading tags. A file whose name and byte size are
     * unchanged has unchanged metadata, so its row can be carried over verbatim and the
     * MediaMetadataRetriever call - tens of milliseconds, per file - skipped entirely.
     */
    @Query("SELECT * FROM tracks WHERE source = 'local'") suspend fun allTracks(): List<TrackEntity>

    // ---------------------------------------------------------------- remote rows

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIgnoreTracks(tracks: List<TrackEntity>)

    @Query(
        """
        UPDATE tracks SET title = :title, artist = :artist, album = :album,
            durationMs = CASE WHEN :durationMs > 0 THEN :durationMs ELSE durationMs END,
            artworkUri = COALESCE(:artworkUri, artworkUri), lastSeenAt = :now
        WHERE id = :id AND source = 'remote'
        """
    )
    suspend fun refreshRemote(
        id: String, title: String, artist: String, album: String,
        durationMs: Long, artworkUri: String?, now: Long
    )

    /**
     * Records remote tracks without ever clobbering what the user did to them.
     *
     * IGNORE + targeted UPDATE instead of the REPLACE used for local files. REPLACE deletes the row
     * and inserts a new one, which would reset `savedAt` to null - so playing a track you had
     * saved would quietly un-save it - and, because the child tables key off the primary key, it
     * churns them for nothing. The UPDATE also refuses to overwrite a known duration or artwork
     * with a blank one, since a search result carries less metadata than a resolved stream does.
     */
    @Transaction
    suspend fun rememberRemote(tracks: List<TrackEntity>, now: Long = System.currentTimeMillis()) {
        if (tracks.isEmpty()) return
        insertIgnoreTracks(tracks)
        tracks.forEach {
            refreshRemote(it.id, it.title, it.artist, it.album, it.durationMs, it.artworkUri, now)
        }
    }

    @Query("UPDATE tracks SET savedAt = :now WHERE id = :id AND source = 'remote'")
    suspend fun markSaved(id: String, now: Long)

    @Query("UPDATE tracks SET savedAt = NULL WHERE id = :id AND source = 'remote'")
    suspend fun markUnsaved(id: String)

    /**
     * Unsaved remote rows nobody is attached to any more.
     *
     * The NOT IN subquery covers every child table, so a track that was never explicitly saved but
     * sits in a playlist, is favourited, has custom FX, is hidden, or simply has a play count is
     * kept. Anything else is a leftover of browsing and is not worth carrying forever - the
     * database growing without bound is a real failure mode for a table fed by a search screen.
     */
    @Query(
        """
        SELECT id FROM tracks
        WHERE source = 'remote' AND savedAt IS NULL AND lastSeenAt < :before
          AND id NOT IN (
            SELECT trackId FROM favorites
            UNION SELECT trackId FROM playlist_tracks
            UNION SELECT trackId FROM track_fx
            UNION SELECT trackId FROM hidden
            UNION SELECT trackId FROM play_stats
          )
        """
    )
    suspend fun forgettableRemoteIds(before: Long): List<String>

    // ---------------------------------------------------------------- search history

    @Query("SELECT * FROM search_history ORDER BY queriedAt DESC LIMIT 20")
    fun observeSearchHistory(): Flow<List<SearchQueryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun rememberQuery(entry: SearchQueryEntity)

    @Query("DELETE FROM search_history WHERE `query` = :query") suspend fun forgetQuery(query: String)

    @Query("DELETE FROM search_history") suspend fun clearSearchHistory()

    /** Keeps the history list from growing past what the hub can show. */
    @Query("DELETE FROM search_history WHERE `query` NOT IN (SELECT `query` FROM search_history ORDER BY queriedAt DESC LIMIT 20)")
    suspend fun trimSearchHistory()

    /**
     * Every track id the user actually invested something in. Used to keep the one-shot id remap
     * proportional to the user's data instead of to the size of the library: a 3000-track library
     * with 40 favourites needs 40 remaps, not 3000.
     */
    @Query(
        """
        SELECT trackId FROM favorites
        UNION SELECT trackId FROM playlist_tracks
        UNION SELECT trackId FROM track_fx
        UNION SELECT trackId FROM hidden
        UNION SELECT trackId FROM play_stats
        """
    )
    suspend fun referencedTrackIds(): List<String>

    /**
     * Moves everything attached to [oldId] onto [newId], atomically.
     *
     * `OR IGNORE` matters: if both ids are already present - the same file reachable through both
     * MediaStore and a SAF grant, which the old scheme happily stored twice - the UPDATE would
     * violate the primary key and abort the whole transaction. Ignoring keeps the row that is
     * already correct and leaves the stale one to be swept by the prune queries.
     */
    @Transaction
    suspend fun remapTrackId(oldId: String, newId: String) {
        remapFavorite(oldId, newId)
        remapPlaylistTrack(oldId, newId)
        remapFx(oldId, newId)
        remapHidden(oldId, newId)
        remapStat(oldId, newId)
    }

    @Query("UPDATE OR IGNORE favorites SET trackId = :newId WHERE trackId = :oldId") suspend fun remapFavorite(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE playlist_tracks SET trackId = :newId WHERE trackId = :oldId") suspend fun remapPlaylistTrack(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE track_fx SET trackId = :newId WHERE trackId = :oldId") suspend fun remapFx(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE hidden SET trackId = :newId WHERE trackId = :oldId") suspend fun remapHidden(oldId: String, newId: String)
    @Query("UPDATE OR IGNORE play_stats SET trackId = :newId WHERE trackId = :oldId") suspend fun remapStat(oldId: String, newId: String)

    /** Rows pointing at tracks that no longer exist. Without this the database only ever grows. */
    @Query("DELETE FROM favorites WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneFavorites()
    @Query("DELETE FROM playlist_tracks WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun prunePlaylistTracks()
    @Query("DELETE FROM track_fx WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneFx()
    @Query("DELETE FROM play_stats WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneStats()
    @Query("DELETE FROM hidden WHERE trackId NOT IN (SELECT id FROM tracks)") suspend fun pruneHidden()

    @Query("SELECT trackId FROM favorites") fun observeFavoriteIds(): Flow<List<String>>

    /**
     * IGNORE, а не REPLACE (6.19.0).
     *
     * REPLACE переписывал бы строку целиком, а вместе с ней и `addedAt` — то есть «когда я это
     * полюбил» терялось при каждом повторном добавлении. Строка и так одна на трек: первичный ключ
     * это trackId, добавлять второй раз нечего.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun favorite(item: FavoriteEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun favoriteMany(items: List<FavoriteEntity>)
    @Query("DELETE FROM favorites WHERE trackId = :id") suspend fun unfavorite(id: String)
    @Query("DELETE FROM favorites WHERE trackId IN (:ids)") suspend fun unfavoriteMany(ids: List<String>)
    @Query("SELECT COUNT(*) FROM favorites WHERE trackId IN (:ids)") suspend fun favoriteCount(ids: List<String>): Int

    /**
     * Переключение избранного целиком внутри базы (6.19.0).
     *
     * Раньше состояние читалось из UI-потока состояния (`library.value.favoriteIds`), а писалось
     * отдельным вызовом. Между этими двумя моментами лежит весь путь Room -> Flow -> combine ->
     * Dispatchers.Default -> StateFlow, то есть десятки миллисекунд. Двойной тап по сердцу успевал
     * прочитать одно и то же старое значение дважды и поставить «в избранное» два раза вместо
     * «поставить и снять». Здесь читает и пишет одна транзакция, промежутка не существует.
     *
     * Возвращает состояние ПОСЛЕ переключения — тому, кто показывает снекбар, нужно именно оно.
     */
    @Transaction
    suspend fun toggleFavorite(id: String): Boolean {
        val exists = favoriteCount(listOf(id)) > 0
        if (exists) unfavorite(id) else favorite(FavoriteEntity(id))
        return !exists
    }

    /**
     * То же самое для пачки, одной транзакцией и одним уведомлением подписчикам.
     *
     * Цикл из 500 вызовов toggleFavorite — это 1000 обращений к базе и 500 эмитов Flow, каждый из
     * которых заставляет ViewModel пересобрать и заново отсортировать весь список. Пятьсот раз
     * подряд. Именно так «избранное для выбранного» превращалось в замерший экран.
     *
     * Порог `IN (...)` у SQLite — 999 переменных, поэтому и подсчёт, и запись идут чанками.
     */
    @Transaction
    suspend fun toggleFavorites(ids: List<String>): Boolean {
        if (ids.isEmpty()) return false
        var present = 0
        ids.chunked(IN_CHUNK_DAO).forEach { present += favoriteCount(it) }
        val allFavorite = present >= ids.size
        if (allFavorite) {
            ids.chunked(IN_CHUNK_DAO).forEach { unfavoriteMany(it) }
        } else {
            ids.chunked(IN_CHUNK_DAO).forEach { chunk -> favoriteMany(chunk.map { FavoriteEntity(it) }) }
        }
        return !allFavorite
    }

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun observePlaylists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun createPlaylist(item: PlaylistEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addToPlaylist(item: PlaylistTrackEntity)
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId") suspend fun removeFromPlaylist(playlistId: Long, trackId: String)
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") fun observePlaylistTracks(id: Long): Flow<List<TrackEntity>>
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId = t.id WHERE p.playlistId = :id ORDER BY p.position") suspend fun playlistTracks(id: Long): List<TrackEntity>
    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_tracks WHERE playlistId = :id") suspend fun nextPosition(id: Long): Int

    @Query("SELECT * FROM track_fx WHERE trackId = :id") suspend fun fx(id: String): TrackFxEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveFx(item: TrackFxEntity)

    @Query("DELETE FROM tracks WHERE id = :id") suspend fun deleteTrack(id: String)

    @Query("SELECT trackId FROM hidden") fun observeHiddenIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun hide(item: HiddenEntity)
    @Query("DELETE FROM hidden WHERE trackId = :id") suspend fun unhide(id: String)
    @Query("DELETE FROM hidden") suspend fun clearHidden()

    @Query("SELECT * FROM play_stats") fun observeStats(): Flow<List<PlayStatEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun ensureStat(item: PlayStatEntity)
    @Query("UPDATE play_stats SET playCount = playCount + 1, lastPlayedAt = :now WHERE trackId = :id") suspend fun bumpStat(id: String, now: Long)

    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)

    /**
     * Удаление плейлиста целиком, одной транзакцией (6.19.0).
     *
     * Было три отдельных вызова подряд: снять связь со сборником, вычистить состав, удалить сам
     * плейлист. Смерть процесса между вторым и третьим шагом (а «удалить плейлист» человек часто
     * жмёт перед тем, как убрать приложение из недавних) оставляла в базе пустую строку плейлиста
     * без состава — призрак, который видно в списке и нельзя нормально объяснить.
     */
    @Transaction
    suspend fun deletePlaylistFull(id: Long) {
        unlinkPlaylist(id)
        clearPlaylist(id)
        deletePlaylist(id)
    }
    @Query("DELETE FROM playlist_tracks WHERE playlistId = :id") suspend fun clearPlaylist(id: Long)
    @Query("UPDATE playlists SET name = :name WHERE id = :id") suspend fun renamePlaylist(id: Long, name: String)
    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :id") suspend fun playlistSize(id: Long): Int
    @Query("SELECT playlistId AS playlistId, COUNT(*) AS total FROM playlist_tracks GROUP BY playlistId")
    fun observePlaylistCounts(): Flow<List<PlaylistCount>>

    /* ---------------------------------------------------------------- 6.17.0 ---- */

    /**
     * Общее время каждого плейлиста одним запросом.
     *
     * Считает SQLite, а не Kotlin: длительности уже лежат в таблице, и складывать их в UI значило
     * бы протаскивать в состояние экрана все треки всех плейлистов ради одной подписи.
     */
    @Query(
        """
        SELECT p.playlistId AS playlistId, COALESCE(SUM(t.durationMs), 0) AS totalMs
        FROM playlist_tracks p JOIN tracks t ON t.id = p.trackId
        GROUP BY p.playlistId
        """
    )
    fun observePlaylistDurations(): Flow<List<PlaylistDuration>>

    @Query("SELECT trackId FROM playlist_tracks WHERE playlistId = :id") suspend fun playlistTrackIds(id: Long): List<String>

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId IN (:trackIds)")
    suspend fun removeTracksFromPlaylist(playlistId: Long, trackIds: List<String>)

    /**
     * Пакетное добавление в плейлист.
     *
     * Одна транзакция на всю пачку и один пересчёт позиции: цикл из `addToPlaylist` на 60 треках
     * — это 120 обращений к базе и 60 уведомлений подписчикам Flow, то есть 60 перерисовок списка
     * подряд. Дубликаты отсекаются здесь же, иначе «добавить всё» второй раз переставило бы
     * порядок уже лежащих треков (REPLACE по составному ключу).
     */
    @Transaction
    suspend fun addTracksToPlaylist(playlistId: Long, trackIds: List<String>) {
        if (trackIds.isEmpty()) return
        val existing = playlistTrackIds(playlistId).toHashSet()
        var position = nextPosition(playlistId)
        for (trackId in trackIds) {
            if (!existing.add(trackId)) continue
            addToPlaylist(PlaylistTrackEntity(playlistId, trackId, position))
            position++
        }
    }

    /** Перенос: добавить в приёмник и убрать из источника, атомарно. */
    @Transaction
    suspend fun moveTracksBetweenPlaylists(fromPlaylistId: Long, toPlaylistId: Long, trackIds: List<String>) {
        if (fromPlaylistId == toPlaylistId) return
        addTracksToPlaylist(toPlaylistId, trackIds)
        removeTracksFromPlaylist(fromPlaylistId, trackIds)
    }

    @Query("UPDATE tracks SET savedAt = NULL WHERE id IN (:ids) AND source = 'remote'")
    suspend fun markUnsavedMany(ids: List<String>)

    @Query("UPDATE tracks SET savedAt = :now WHERE id IN (:ids) AND source = 'remote'")
    suspend fun markSavedMany(ids: List<String>, now: Long)

    @Query("SELECT * FROM playlist_links") fun observePlaylistLinks(): Flow<List<PlaylistLinkEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun linkCollection(item: PlaylistLinkEntity)
    @Query("DELETE FROM playlist_links WHERE collectionKey = :key") suspend fun unlinkCollection(key: String)
    @Query("DELETE FROM playlist_links WHERE playlistId = :playlistId") suspend fun unlinkPlaylist(playlistId: Long)
    @Query("DELETE FROM playlist_links WHERE playlistId NOT IN (SELECT id FROM playlists)") suspend fun pruneLinks()
}
