package app.ziziplayer.data.remote

import androidx.compose.runtime.Immutable
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.TrackSource
import app.ziziplayer.playback.RemoteUri

/**
 * The shape of a remote catalogue, provider agnostic.
 *
 * Nothing in the UI or in the database knows the word "YouTube" or "Audius": both are reachable
 * only through [RemoteCatalog], and both produce these types. Swapping a provider - or adding a
 * third one, or reacting to one of them going dark - is a change in exactly one file.
 */

enum class RemoteKind { TRACK, ALBUM, PLAYLIST, ARTIST }

/**
 * A track that lives on the network.
 *
 * [trackId] is deliberately derived and deliberately in its own namespace: the local scheme is
 * `f:`/`u:` (a hash of file name and size, see `TrackId`) and cannot exist for something that has
 * no file. `r:<provider>:<id>` can never collide with it, is reproducible from the provider's own
 * id, and stays valid forever - which is what lets favourites, playlists and play counts key off
 * it exactly like they do for local files.
 */
@Immutable
data class RemoteTrack(
    val provider: String,
    val remoteId: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0L,
    val artworkUrl: String? = null,
    val explicit: Boolean = false
) {
    val trackId: String get() = "r:$provider:$remoteId"
}

/** An album, a playlist or an artist: something you open to get tracks out of. */
@Immutable
data class RemoteCollection(
    val provider: String,
    val remoteId: String,
    val kind: RemoteKind,
    val title: String,
    val subtitle: String = "",
    val artworkUrl: String? = null
)

@Immutable
sealed interface RemoteItem {
    val sortTitle: String

    @Immutable
    data class Song(val track: RemoteTrack) : RemoteItem {
        override val sortTitle: String get() = track.title
    }

    @Immutable
    data class Group(val collection: RemoteCollection) : RemoteItem {
        override val sortTitle: String get() = collection.title
    }
}

/**
 * One page of results. [nextToken] is opaque on purpose - Innertube hands back a continuation
 * blob, Audius counts offsets, and the screen must not care which.
 */
@Immutable
data class SearchPage(val items: List<RemoteItem>, val nextToken: String? = null) {
    companion object { val EMPTY = SearchPage(emptyList(), null) }
}

/** A horizontal shelf on the search hub ("Открой новое для себя"). */
@Immutable
data class DiscoverShelf(val title: String, val items: List<RemoteItem>)

/**
 * A playable, expiring address.
 *
 * [ttlMs] is advisory: it is what the provider claims, and it is never trusted as a guarantee.
 * The whole point of resolving inside the data source (see `RemoteUri` / `StreamResolver`) is that
 * a wrong TTL costs one retry instead of a broken queue.
 */
data class StreamInfo(
    val url: String,
    val mimeType: String,
    val bitrateKbps: Int,
    val ttlMs: Long,
    val resolvedAtMs: Long = System.currentTimeMillis(),
    /**
     * The user agent this URL was minted for, or null when the provider does not care.
     *
     * A googlevideo address is tied to the client identity that asked for it, so the fetch has to
     * present the same one. 6.6.0 resolved with a mobile-music client and then fetched with a
     * Chrome UA, which is one of the several reasons every YouTube track came back 403. The value
     * travels into the DataSpec in `StreamResolver`, not into a global setting, because two
     * providers in the same queue can need two different agents.
     */
    val userAgent: String? = null,
    /**
     * Заголовки, без которых этот конкретный адрес не отдаст байты (6.19.0).
     *
     * Появились ради одного: токен резолвера уехал из строки запроса в `Authorization`. Строка
     * запроса — самое неудачное место для секрета из всех возможных: она целиком попадает в
     * access-логи nginx и самого сервера, в `Referer` при любом редиректе и в историю прокси.
     * Заголовок не логируется по умолчанию нигде.
     *
     * Едут в DataSpec на конкретный запрос, а не в фабрику: в одной очереди могут одновременно
     * играть трек через свой резолвер и трек с Audius, и второму этот заголовок отдавать незачем.
     */
    val extraHeaders: Map<String, String> = emptyMap(),
    /** Which provider-internal client answered. Diagnostics only - never shown in normal use. */
    val client: String? = null
) {
    fun isFresh(now: Long = System.currentTimeMillis()): Boolean = now - resolvedAtMs < ttlMs
}

/**
 * One provider-internal client identity: what to call ourselves, and what to look like while doing
 * it. Only Innertube has more than one, but the type lives here because [StreamInfo.userAgent] is
 * the part of it that leaves the data layer.
 */
data class StreamClient(val name: String, val version: String, val ua: String)

/** Requested audio quality. Mapped to provider specific formats inside each catalogue. */
enum class RemoteQuality(val targetKbps: Int) { LOW(64), NORMAL(128), HIGH(256) }

/**
 * Why a catalogue call failed, in terms the UI can act on.
 *
 * The distinction is not cosmetic: [OFFLINE] means "try again later, keep the queue",
 * [UNAVAILABLE] means "this one track is gone, skip to the next", and [PROTOCOL] means the
 * provider changed its response shape and *we* are broken - which must be visible as such instead
 * of hiding behind "нет сети".
 */
class CatalogException(
    val reason: Reason,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause) {
    enum class Reason { OFFLINE, RATE_LIMITED, UNAVAILABLE, PROTOCOL, METERED_BLOCKED }
}

/**
 * A remote track as a row in `tracks`.
 *
 * `uri` is our own `zizi://` address and never an HTTP URL: see [RemoteUri] for why that single
 * decision is what makes expiring links a non-problem.
 *
 * `savedAt` is left null here. It is set only when the user actually saves the track, and the
 * insert path in `MusicDao.rememberRemote` never overwrites an existing value - listening to a
 * track you already saved must not un-save it.
 */
fun RemoteTrack.toEntity(now: Long = System.currentTimeMillis()): TrackEntity = TrackEntity(
    id = trackId,
    uri = RemoteUri.of(provider, remoteId),
    title = title,
    artist = artist,
    album = album,
    durationMs = durationMs,
    artworkUri = artworkUrl,
    sourceFolder = providerLabel(provider),
    dateAdded = now,
    sizeBytes = 0L,
    legacyId = null,
    source = TrackSource.REMOTE,
    provider = provider,
    remoteId = remoteId,
    savedAt = null,
    lastSeenAt = now
)

fun providerLabel(provider: String): String = when (provider) {
    "yt" -> "YouTube Music"
    "audius" -> "Audius"
    else -> provider
}
