package app.ziziplayer.data

import android.content.Context
import android.net.Uri
import app.ziziplayer.BuildConfig
import app.ziziplayer.data.remote.RemoteQuality
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("zizi_settings")

enum class AppTheme { GRAPHITE, MIDNIGHT, AMOLED, SUNSET }
enum class SortMode { TITLE, ARTIST, DURATION, RECENT, PLAYS }

data class UserSettings(
    val theme: AppTheme = AppTheme.GRAPHITE,
    val accentFromArtwork: Boolean = true,
    val folderUris: Set<String> = emptySet(),
    val skipSilence: Boolean = false,
    val sortMode: SortMode = SortMode.TITLE,

    // ---- network catalogue ----
    /** Preferred catalogue id. The other one still answers if this one is broken. */
    val catalogProvider: String = "yt",
    /** Refuse to open a stream on a metered connection. Off by default; nothing is hidden. */
    val wifiOnly: Boolean = false,
    val streamQuality: RemoteQuality = RemoteQuality.NORMAL,
    /** Used instead of [streamQuality] on mobile data, when it is the cheaper of the two. */
    val meteredQuality: RemoteQuality = RemoteQuality.LOW,
    val streamCacheEnabled: Boolean = true,
    /** Cache ceiling in MB. 512 is roughly 8 hours of 128 kbps audio. */
    val streamCacheMb: Int = 512,

    // ---- own resolver (6.10.0) ----
    /**
     * Address of the user's own resolver, e.g. `147.45.166.244:8080`. Empty means the old
     * on-device path, which 6.9.4 proved is refused by attestation on every client.
     */
    val resolverUrl: String = BuildConfig.RESOLVER_URL,
    /** Token printed by the installer. Without it the server answers 401, by design. */
    val resolverToken: String = BuildConfig.RESOLVER_TOKEN,
    /**
     * true: audio is proxied through the server (`/stream`), which sidesteps the fact that a
     * googlevideo URL is minted for the IP that asked for it. false: the phone fetches Google
     * directly and no traffic goes through the VPS - faster and free, but only works when that
     * 403 does not happen.
     */
    val resolverProxy: Boolean = BuildConfig.RESOLVER_PROXY,

    /**
     * 6.11.0 — technical rows of the settings screen.
     *
     * Address, token, `/health`, the client walker and the stream report exist because this app
     * talks to a private API that breaks without notice; they are indispensable when it does and
     * pure noise when it does not. So they are hidden, not deleted: seven taps on the version row.
     *
     * Default: hidden when the build already knows the token (a real release), visible when it
     * does not (a local or fork build, where the address has to be typed by hand anyway).
     */
    val devMode: Boolean = !DevAccess.protected
)

class SettingsStore(private val context: Context) {
    private val theme = stringPreferencesKey("theme")
    private val dynamicAccent = booleanPreferencesKey("dynamic_accent")
    private val folders = stringSetPreferencesKey("folders")
    private val skipSilenceKey = booleanPreferencesKey("skip_silence")
    private val sortModeKey = stringPreferencesKey("sort_mode")
    /**
     * Marks the one-shot rewrite of track ids as finished. Read and written outside [settings] on
     * purpose: it is not user-facing state, and pushing it through that flow would rebuild the whole
     * library pipeline for a housekeeping flag.
     */
    private val idsMigratedKey = booleanPreferencesKey("ids_migrated_v3")
    private val catalogKey = stringPreferencesKey("catalog_provider")
    private val wifiOnlyKey = booleanPreferencesKey("stream_wifi_only")
    private val qualityKey = stringPreferencesKey("stream_quality")
    private val meteredQualityKey = stringPreferencesKey("stream_quality_metered")
    private val cacheEnabledKey = booleanPreferencesKey("stream_cache_enabled")
    private val cacheMbKey = intPreferencesKey("stream_cache_mb")
    private val resolverUrlKey = stringPreferencesKey("resolver_url")
    private val resolverTokenKey = stringPreferencesKey("resolver_token")
    private val resolverProxyKey = booleanPreferencesKey("resolver_proxy")
    private val devModeKey = booleanPreferencesKey("dev_mode")

    private fun quality(raw: String?, fallback: RemoteQuality): RemoteQuality =
        runCatching { RemoteQuality.valueOf(raw ?: fallback.name) }.getOrDefault(fallback)

    val settings: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            theme = runCatching { AppTheme.valueOf(p[theme] ?: AppTheme.GRAPHITE.name) }.getOrDefault(AppTheme.GRAPHITE),
            accentFromArtwork = p[dynamicAccent] ?: true,
            folderUris = p[folders] ?: emptySet(),
            skipSilence = p[skipSilenceKey] ?: false,
            sortMode = runCatching { SortMode.valueOf(p[sortModeKey] ?: SortMode.TITLE.name) }.getOrDefault(SortMode.TITLE),
            catalogProvider = p[catalogKey] ?: "yt",
            wifiOnly = p[wifiOnlyKey] ?: false,
            streamQuality = quality(p[qualityKey], RemoteQuality.NORMAL),
            meteredQuality = quality(p[meteredQualityKey], RemoteQuality.LOW),
            streamCacheEnabled = p[cacheEnabledKey] ?: true,
            streamCacheMb = (p[cacheMbKey] ?: 512).coerceIn(64, 8192),
            // Baked value is the default, a value typed by hand still wins: an old install that
            // already has the address keeps it, and a user with his own server is not locked out.
            resolverUrl = (p[resolverUrlKey] ?: "").ifBlank { BuildConfig.RESOLVER_URL },
            resolverToken = (p[resolverTokenKey] ?: "").ifBlank { BuildConfig.RESOLVER_TOKEN },
            resolverProxy = p[resolverProxyKey] ?: BuildConfig.RESOLVER_PROXY,
            // 6.17.0: в защищённой сборке сохранённый флаг больше не читается вообще. Иначе
            // тестер, случайно открывший отладку в 6.15.0, остался бы с ней навсегда — обновление
            // приложения не трогает DataStore.
            devMode = if (DevAccess.protected) false else (p[devModeKey] ?: true)
        )
    }
    suspend fun setTheme(value: AppTheme) = context.dataStore.edit { it[theme] = value.name }
    suspend fun setDynamicAccent(value: Boolean) = context.dataStore.edit { it[dynamicAccent] = value }
    suspend fun addFolder(uri: Uri) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) + uri.toString() }
    suspend fun removeFolder(uri: String) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) - uri }
    suspend fun setSkipSilence(value: Boolean) = context.dataStore.edit { it[skipSilenceKey] = value }
    suspend fun setSortMode(value: SortMode) = context.dataStore.edit { it[sortModeKey] = value.name }

    suspend fun setCatalogProvider(value: String) = context.dataStore.edit { it[catalogKey] = value }
    suspend fun setWifiOnly(value: Boolean) = context.dataStore.edit { it[wifiOnlyKey] = value }
    suspend fun setStreamQuality(value: RemoteQuality) = context.dataStore.edit { it[qualityKey] = value.name }
    suspend fun setMeteredQuality(value: RemoteQuality) = context.dataStore.edit { it[meteredQualityKey] = value.name }
    suspend fun setStreamCacheEnabled(value: Boolean) = context.dataStore.edit { it[cacheEnabledKey] = value }
    suspend fun setStreamCacheMb(value: Int) = context.dataStore.edit { it[cacheMbKey] = value.coerceIn(64, 8192) }

    suspend fun setResolverUrl(value: String) = context.dataStore.edit { it[resolverUrlKey] = value.trim() }
    suspend fun setResolverToken(value: String) = context.dataStore.edit { it[resolverTokenKey] = value.trim() }
    suspend fun setResolverProxy(value: Boolean) = context.dataStore.edit { it[resolverProxyKey] = value }
    /** Пишется только в незащищённой сборке; в релизе доступ живёт сессией, а не настройкой. */
    suspend fun setDevMode(value: Boolean) {
        if (DevAccess.protected) return
        context.dataStore.edit { it[devModeKey] = value }
    }

    suspend fun idsMigrated(): Boolean = context.dataStore.data.map { it[idsMigratedKey] ?: false }.first()
    suspend fun setIdsMigrated() = context.dataStore.edit { it[idsMigratedKey] = true }
}
