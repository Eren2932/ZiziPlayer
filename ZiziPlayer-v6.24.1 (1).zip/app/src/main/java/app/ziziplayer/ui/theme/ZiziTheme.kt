package app.ziziplayer.ui.theme

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import app.ziziplayer.data.AppTheme
import app.ziziplayer.ui.components.ArtSwatches
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/* ==================================================================================
 *  Oklch, and a ramp that was MEASURED, not quoted (6.4)
 *
 *  Two separate mistakes are fixed here.
 *
 *  (a) 6.3 built the backdrop in HSV. HSV is not perceptual: "value 0.24" is a clean navy at
 *      one hue and olive mud at another, so one ramp read as "the cover" on one sleeve and as
 *      "someone spilled coffee on the screen" on the next. Worse, every stop borrowed a
 *      DIFFERENT swatch, so the hue crawled down the screen - brown at the title, green at the
 *      controls.
 *
 *  (b) The v7.0/v7.1 notes claim the reference peaks at 68 % of the height, under the controls.
 *      It does not. Sampling the left-edge column of the reference capture, converted to Oklch
 *      (three different covers, stable frames 60 / 240 / 310):
 *
 *        y      0.06  0.10  0.16  0.24  0.34  0.50  0.67  0.83  0.90
 *        dark   .144  .173  .193  .193  .184  .168  .152  .113  .097
 *        red    .120  .161  .182  .182  .161  .145  .120  .077  .083
 *        light  .398  .540  .654  .618  .546  .428  .289  .148  .113
 *
 *      The peak sits at y = 0.16..0.24 - BEHIND THE COVER - and the screen darkens all the way
 *      down from there. Any ramp that brightens towards the controls is upside down, which is
 *      exactly why the bottom of our screen looked lit from below.
 *
 *  Three facts drive the model:
 *
 *   1. the hue is CONSTANT down the whole screen (measured drift: 28-40 deg on a warm cover,
 *      41-44 on the red one) and it is the cover's own hue;
 *   2. chroma tracks lightness, C = k * L, and k is a property of the COVER, not a constant:
 *      k = 0.057 on a muted sleeve, 0.27 on the vivid red one. A flat saturation cap cannot
 *      express that, which is why muted and neon covers used to collapse onto each other;
 *   3. the absolute brightness follows the cover too - the same ramp shape sits at peak L 0.18
 *      for a dark cover and 0.65 for a white one. 6.3 pinned it, so every track produced an
 *      equally lit screen and the "theme change" was only ever a hue nudge.
 *
 *  Out-of-gamut colours give up chroma, never hue.
 * ================================================================================== */

/**
 * Stop positions and the ramp SHAPE, relative to the peak.
 *
 * 6.17.0 — ПОЛОСА СОСТОЯНИЯ. До этой версии первый стоп стоял на 0.66 от пика ровно в точке
 * y = 0.00, то есть самая тёмная часть градиента приходилась на те 24–48 dp, где телефон рисует
 * часы, VPN и батарею. Экран честно повторял замеры референса, но человек видел другое: чёрную
 * плашку над шапкой приложения, будто шторка «съела» цвет темы. Замер референса тоже начинался
 * не с нуля, а с y = 0.06 — то, что выше, никем не измерялось и было домыслено линейной
 * экстраполяцией вниз.
 *
 * Теперь ramp держит почти пиковую светлоту до 10 % высоты (там и стоит гребень) и монотонно
 * темнеет вниз. Под статус-баром — цвет шапки, а не провал; ниже гребня форма кривой прежняя.
 */
private val RAMP_POS = floatArrayOf(0.00f, 0.10f, 0.28f, 0.46f, 0.64f, 0.82f, 1.00f)
private val RAMP_REL = floatArrayOf(0.94f, 1.00f, 0.93f, 0.84f, 0.71f, 0.54f, 0.42f)

@Immutable
data class ZiziPalette(
    val top: Color,
    val crest: Color,
    val upper: Color,
    val middle: Color,
    val lower: Color,
    val deep: Color,
    val bottom: Color,
    val glow: Color,
    val surface: Color,
    val chip: Color,
    val text: Color,
    val subtext: Color,
    val accent: Color,
    val onAccent: Color,
    /** How much of the cover's colour this theme accepts at all. */
    val tintStrength: Float,
    /** Peak Oklab lightness this theme allows before the cover has any say. */
    val peakLightness: Float,
    /** Ceiling the cover may lift the peak to. AMOLED keeps it low, which is the whole theme. */
    val peakCeiling: Float
) {
    val background: Brush
        get() = Brush.verticalGradient(
            RAMP_POS[0] to top,
            RAMP_POS[1] to crest,
            RAMP_POS[2] to upper,
            RAMP_POS[3] to middle,
            RAMP_POS[4] to lower,
            RAMP_POS[5] to deep,
            RAMP_POS[6] to bottom
        )
}

/* ---------------------------------------------------------------- colour space ---- */

private fun cbrtf(value: Float): Float = Math.cbrt(value.toDouble()).toFloat()

private fun toLinear(channel: Float): Float =
    if (channel <= 0.04045f) channel / 12.92f else ((channel + 0.055f) / 1.055f).pow(2.4f)

private fun fromLinear(channel: Float): Float =
    if (channel <= 0.0031308f) channel * 12.92f else 1.055f * channel.pow(1f / 2.4f) - 0.055f

/** sRGB -> Oklch. Returns [L, C, h(deg)]. */
private fun Color.toOklch(): FloatArray {
    val r = toLinear(red)
    val g = toLinear(green)
    val b = toLinear(blue)
    val l = cbrtf(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b)
    val m = cbrtf(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b)
    val s = cbrtf(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b)
    val okL = 0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s
    val okA = 1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s
    val okB = 0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s
    var hue = atan2(okB, okA) * 57.29578f
    if (hue < 0f) hue += 360f
    return floatArrayOf(okL, hypot(okA, okB), hue)
}

/**
 * Oklch -> sRGB with a gamut walk: if the requested chroma cannot be shown at this lightness,
 * chroma is given up in 6 % steps. The hue and the lightness are never touched, which is the
 * whole point - a band getting darker must not drift towards another colour.
 */
private fun oklch(lightness: Float, chroma: Float, hueDeg: Float): Color {
    val okL = lightness.coerceIn(0f, 1f)
    val rad = hueDeg * 0.017453292f
    val dirA = cos(rad)
    val dirB = sin(rad)
    var c = chroma.coerceAtLeast(0f)
    var attempt = 0
    while (true) {
        val okA = dirA * c
        val okB = dirB * c
        val lp = okL + 0.3963377774f * okA + 0.2158037573f * okB
        val mp = okL - 0.1055613458f * okA - 0.0638541728f * okB
        val sp = okL - 0.0894841775f * okA - 1.2914855480f * okB
        val l = lp * lp * lp
        val m = mp * mp * mp
        val s = sp * sp * sp
        val r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s
        val g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s
        val b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s
        val inGamut = r >= -0.001f && r <= 1.001f && g >= -0.001f && g <= 1.001f &&
            b >= -0.001f && b <= 1.001f
        if (inGamut || attempt >= 24 || c <= 0.0005f) {
            return Color(
                red = fromLinear(r.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                green = fromLinear(g.coerceIn(0f, 1f)).coerceIn(0f, 1f),
                blue = fromLinear(b.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            )
        }
        c *= 0.94f
        attempt++
    }
}

/* ------------------------------------------------------------------ base themes ---- */

/**
 * Even the untinted themes are built from the measured ramp now. Before, each theme carried five
 * hand-picked hex values, so "no cover colour" and "cover colour" were two differently SHAPED
 * gradients and the first track change visibly re-laid the screen out.
 */
private fun themePalette(
    hue: Float,
    chromaK: Float,
    peakLightness: Float,
    peakCeiling: Float,
    tintStrength: Float,
    surface: Color,
    chip: Color,
    text: Color,
    subtext: Color,
    accent: Color,
    onAccent: Color
): ZiziPalette {
    fun stop(index: Int): Color {
        val l = peakLightness * RAMP_REL[index]
        return oklch(l, chromaK * l, hue)
    }
    return ZiziPalette(
        top = stop(0),
        crest = stop(1),
        upper = stop(2),
        middle = stop(3),
        lower = stop(4),
        deep = stop(5),
        bottom = stop(6),
        glow = oklch((peakLightness * 1.9f).coerceIn(0.16f, 0.52f), chromaK * 0.30f, hue),
        surface = surface,
        chip = chip,
        text = text,
        subtext = subtext,
        accent = accent,
        onAccent = onAccent,
        tintStrength = tintStrength,
        peakLightness = peakLightness,
        peakCeiling = peakCeiling
    )
}

private val Graphite = themePalette(
    hue = 252f,
    chromaK = 0.055f,
    peakLightness = 0.200f,
    peakCeiling = 0.340f,
    tintStrength = 1f,
    surface = Color(0xFF1D1F23),
    chip = Color(0xFF2C2F34),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF8FD3FF),
    onAccent = Color(0xFF06121A)
)

private val Midnight = themePalette(
    hue = 268f,
    chromaK = 0.190f,
    peakLightness = 0.205f,
    peakCeiling = 0.320f,
    tintStrength = 0.94f,
    surface = Color(0xFF161E33),
    chip = Color(0xFF223054),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9DA2A9),
    accent = Color(0xFF9EB8FF),
    onAccent = Color(0xFF06121A)
)

private val Amoled = themePalette(
    hue = 0f,
    chromaK = 0f,
    peakLightness = 0.085f,
    // The cover may lift AMOLED a little, never far: that ceiling IS the theme.
    peakCeiling = 0.150f,
    // 6.3 gave AMOLED tintStrength 0.45, so the cover barely showed and it read as "dynamic
    // colour is broken on this theme". The tint is nearly full strength now; it is the
    // LIGHTNESS that stays AMOLED-dark.
    tintStrength = 0.88f,
    surface = Color(0xFF101010),
    chip = Color(0xFF1B1B1B),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFF9A9A9A),
    accent = Color(0xFFFFFFFF),
    onAccent = Color(0xFF000000)
)

private val Sunset = themePalette(
    hue = 26f,
    chromaK = 0.170f,
    peakLightness = 0.215f,
    peakCeiling = 0.340f,
    tintStrength = 1f,
    surface = Color(0xFF291921),
    chip = Color(0xFF3E242D),
    text = Color(0xFFF6F7F8),
    subtext = Color(0xFFB49AA1),
    accent = Color(0xFFFFA36B),
    onAccent = Color(0xFF25100A)
)

fun basePalette(theme: AppTheme): ZiziPalette = when (theme) {
    AppTheme.GRAPHITE -> Graphite
    AppTheme.MIDNIGHT -> Midnight
    AppTheme.AMOLED -> Amoled
    AppTheme.SUNSET -> Sunset
}

val LocalPalette = compositionLocalOf { Graphite }

/* --------------------------------------------------------------------- tinting ---- */

/** What the three swatches say about the cover as a whole. */
private class CoverReading(val hue: Float, val chroma: Float, val lightness: Float)

/**
 * Chroma-squared weighted circular mean for the hue, so one grey swatch cannot drag a colourful
 * cover, plus the coverage-weighted lightness the backdrop brightness follows.
 */
private fun readCover(swatches: ArtSwatches): CoverReading? {
    val colours = arrayOf(swatches.primary, swatches.secondary, swatches.deep)
    val shares = floatArrayOf(0.5f, 0.3f, 0.2f)
    var sumX = 0f
    var sumY = 0f
    var peakChroma = 0f
    var primaryChroma = 0f
    var lightness = 0f
    var coloured = 0
    for (i in colours.indices) {
        val lch = colours[i].toOklch()
        lightness += lch[0] * shares[i]
        val chroma = lch[1]
        if (i == 0) primaryChroma = chroma
        if (chroma < 0.012f) continue
        // Chroma squared TIMES coverage (6.5). Chroma alone let a 20 % accent shade out-vote the
        // colour the cover is actually made of: on the yellow sleeve the little black scribble's
        // residual hue was pulling the whole screen olive.
        val weight = chroma * chroma * shares[i]
        val rad = lch[2] * 0.017453292f
        sumX += cos(rad) * weight
        sumY += sin(rad) * weight
        if (chroma > peakChroma) peakChroma = chroma
        coloured++
    }
    if (coloured == 0 || (abs(sumX) < 1e-6f && abs(sumY) < 1e-6f)) return null
    var hue = atan2(sumY, sumX) * 57.29578f
    if (hue < 0f) hue += 360f
    // How colourful the SCREEN gets follows the dominant swatch first and the most vivid one
    // second. Driving it off the peak alone is what made a mostly grey sleeve with one neon
    // sticker as loud as a fully saturated cover.
    val chroma = (0.62f * primaryChroma + 0.38f * peakChroma).coerceAtMost(peakChroma)
    return CoverReading(hue, chroma, lightness.coerceIn(0f, 1f))
}

/**
 * One hue, the measured ramp shape, C = k * L, and a peak lightness that follows the cover.
 *
 *  - k = 0.05 + 1.10 * peakChroma, clamped to 0.05..0.30. Fitted against the measurement: a
 *    muted sleeve lands near 0.06 (measured 0.057) and the vivid red one near 0.27 (measured
 *    0.27). This is the single change that stops muted and neon covers looking identical.
 *  - peak L = 0.075 + 0.30 * coverLightness, clamped to the theme's own floor and ceiling.
 *    Fitted against the same measurement: the vivid red cover lands on 0.195 (measured 0.182) and
 *    the muted one on 0.180 (measured 0.193). The reference goes all the way to 0.654 on a white
 *    sleeve; we stop at 0.34, because past that the subtext stops clearing 4.5:1 against the
 *    backdrop and the screen starts to glare. Worst case across the covers checked here: 6.1:1.
 *
 * A genuinely monochrome cover returns the untinted theme on purpose: normalising sensor noise
 * up into a hue is how a black-and-white sleeve used to paint the app teal.
 */
fun ZiziPalette.tintedWith(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null || tintStrength <= 0.01f) return this
    val cover = readCover(swatches) ?: return this
    val k = (0.055f + 1.32f * cover.chroma).coerceIn(0.055f, 0.34f)
    val peak = (0.085f + 0.33f * cover.lightness)
        .coerceIn(peakLightness * 0.85f, peakCeiling)
    val strength = tintStrength.coerceIn(0f, 1f)
    val hue = cover.hue

    fun stop(base: Color, index: Int, mix: Float): Color {
        val l = peak * RAMP_REL[index]
        return lerp(base, oklch(l, k * l, hue), mix * strength)
    }

    return copy(
        top = stop(top, 0, 1f),
        crest = stop(crest, 1, 1f),
        upper = stop(upper, 2, 1f),
        middle = stop(middle, 3, 1f),
        lower = stop(lower, 4, 1f),
        deep = stop(deep, 5, 1f),
        bottom = stop(bottom, 6, 0.96f),
        // ONE glow, and a weak one: the crest at y = 0.20 is what spreads the cover colour now.
        // 7.0 stacked a second radial wash under the controls, which is what blew warm covers out.
        glow = lerp(glow, oklch((peak * 1.9f).coerceIn(0.18f, 0.56f), (k * 0.9f).coerceAtMost(0.14f), hue), 0.95f * strength),
        // Chips and sheets sit ON the backdrop, so they are pinned a step above the crest rather
        // than to a fixed value - otherwise a bright cover swallowed them whole.
        surface = lerp(surface, oklch((peak * 1.25f).coerceIn(0.20f, 0.46f), k * 0.9f * peak, hue), 0.88f * strength),
        chip = lerp(chip, oklch((peak * 1.60f).coerceIn(0.26f, 0.54f), k * 1.0f * peak, hue), 0.85f * strength),
        // 6.17.0: светлота подписи следует за фоном, а не стоит на месте. Пик 0.20 (тёмная
        // обложка) — подпись 0.755, как раньше; пик 0.34 (светлая) — 0.80, иначе на осветлённом
        // гребне серый текст сползает к 3.5:1 и первым «ломается» именно на ярких обложках.
        subtext = lerp(subtext, oklch((0.695f + 0.30f * peak).coerceIn(0.735f, 0.815f), 0.022f, hue), 0.55f * strength),
        text = lerp(text, oklch(0.968f, 0.008f, hue), 0.35f * strength)
    )
}

/**
 * The accent drives the progress bar, the active icons and the equaliser bars, so it has to stay
 * legible over the brightest band whatever the cover looks like: the hue is the cover's, the
 * lightness is pinned high. A grey cover yields a near-white accent instead of a muddy one.
 */
fun ZiziPalette.withAccent(swatches: ArtSwatches?): ZiziPalette {
    if (swatches == null) return this
    val cover = readCover(swatches)
    val accentColour = if (cover == null) {
        oklch(0.90f, 0f, 0f)
    } else {
        oklch(0.80f, (0.055f + cover.chroma * 0.52f).coerceIn(0.055f, 0.170f), cover.hue)
    }
    return copy(
        accent = accentColour,
        onAccent = if (accentColour.toOklch()[0] > 0.66f) Color(0xFF0B0B0C) else Color.White
    )
}

/**
 * Нужны ли системным иконкам тёмные значки (6.17.0).
 *
 * Раньше цвет иконок часов и батареи был прибит в styles.xml (`windowLightStatusBar=false`), то
 * есть белым всегда. Пока все темы были тёмные, это работало; стоило обложке поднять пик к
 * потолку 0.34 и подсветить верх экрана — белое по светлому. Решение принимает сам gradient:
 * порог 0.62 по Oklab-светлоте гребня, ровно там, где белый текст перестаёт держать 4.5:1.
 */
fun ZiziPalette.prefersDarkSystemIcons(): Boolean = crest.toOklch()[0] > 0.62f

/* ---------------------------------------------------------- carousel cross-fade ---- */

/**
 * Lets the carousel drive the backdrop while the finger is still on the screen.
 *
 * Until 6.4 the backdrop only knew about the PLAYING track, so dragging a cover in did nothing
 * to the colour until the page settled and the player switched - and then it cut. The reference
 * players do the opposite: the two covers' colours meet under your thumb, proportionally to the
 * drag. That is the whole "слияние цветов" effect.
 *
 * Everything here is read in the draw phase only. A drag repaints one rect per frame and
 * recomposes nothing.
 */
@Stable
class BackdropBlend {
    /** Palette of the cover being dragged in, or null when there is nothing to mix. */
    var target by mutableStateOf<ZiziPalette?>(null)
        private set

    /** 0 = the playing track's ramp, 1 = the target's ramp. */
    var progress by mutableFloatStateOf(0f)
        private set

    /**
     * Held from the moment a page settles until the real palette catches up.
     *
     * The drag fraction returns to 0 on the frame the fling ends, but the playing track - and so
     * the palette - lands a few frames later. Without the hold the screen would snap back to the
     * previous cover's colour and then animate forward again: a visible bounce on every swipe.
     *
     * A hold is a lock, and 7.1 taught this project what an unowned lock costs, so it is released
     * from exactly two places: [ZiziBackdrop] when the palette arrives, and a timeout if it never
     * does.
     */
    var held by mutableStateOf(false)
        private set

    fun drag(palette: ZiziPalette?, fraction: Float) {
        if (held) return
        target = palette
        progress = if (palette == null) 0f else fraction.coerceIn(0f, 1f)
    }

    fun hold(palette: ZiziPalette?) {
        if (palette == null) {
            release()
            return
        }
        target = palette
        progress = 1f
        held = true
    }

    fun release() {
        held = false
        progress = 0f
        target = null
    }
}

val LocalBackdropBlend = staticCompositionLocalOf { BackdropBlend() }

/**
 * Mixes two ramp stops the way the eye expects: through the shorter hue arc at constant
 * perceptual lightness, never through grey.
 *
 * sRGB interpolation between the yellow sleeve's band and the purple one's passes through a dead
 * olive-brown, because the straight line between two hues in RGB goes through the middle of the
 * cube. That muddy midpoint is exactly what showed up between two covers.
 */
private fun blendOklch(from: Color, to: Color, fraction: Float): Color {
    if (fraction <= 0.001f) return from
    if (fraction >= 0.999f) return to
    val a = from.toOklch()
    val b = to.toOklch()
    var delta = b[2] - a[2]
    if (delta > 180f) delta -= 360f
    if (delta < -180f) delta += 360f
    // A colourless stop has no meaningful hue: borrow the other one's instead of rotating half
    // way round the circle to reach it.
    val hue = when {
        a[1] < 0.004f -> b[2]
        b[1] < 0.004f -> a[2]
        else -> a[2] + delta * fraction
    }
    return oklch(
        a[0] + (b[0] - a[0]) * fraction,
        a[1] + (b[1] - a[1]) * fraction,
        hue
    )
}

/* -------------------------------------------------------------------- backdrop ---- */

/**
 * The gradient is animated in the DRAW phase only: the Animatable values are read inside
 * drawBehind, so a track change costs a repaint, never a recomposition of the tree.
 *
 * 6.5 removed the radial wash entirely. It was added back when the ramp was flat and it was the
 * only thing spreading the cover's colour; with the measured Oklch ramp it is pure overlay, and
 * an overlay that sits behind the artwork at any alpha above zero reads as a halo around the
 * cover - visible even on pause, which is precisely how you spot a generated interface.
 */
@Composable
fun ZiziBackdrop(
    palette: ZiziPalette,
    modifier: Modifier = Modifier,
    durationMs: Int = 380
) {
    val blend = LocalBackdropBlend.current
    val top = remember { Animatable(palette.top) }
    val crest = remember { Animatable(palette.crest) }
    val upper = remember { Animatable(palette.upper) }
    val middle = remember { Animatable(palette.middle) }
    val lower = remember { Animatable(palette.lower) }
    val deep = remember { Animatable(palette.deep) }
    val bottom = remember { Animatable(palette.bottom) }
    LaunchedEffect(
        palette.top, palette.crest, palette.upper, palette.middle,
        palette.lower, palette.deep, palette.bottom
    ) {
        if (blend.held) {
            // The blend is already painting this palette, so moving the ramp onto it is
            // invisible: snap instead of animating, then hand the screen back to the ramp.
            top.snapTo(palette.top)
            crest.snapTo(palette.crest)
            upper.snapTo(palette.upper)
            middle.snapTo(palette.middle)
            lower.snapTo(palette.lower)
            deep.snapTo(palette.deep)
            bottom.snapTo(palette.bottom)
            blend.release()
            return@LaunchedEffect
        }
        val spec = tween<Color>(durationMs, easing = FastOutSlowInEasing)
        launch { top.animateTo(palette.top, spec) }
        launch { crest.animateTo(palette.crest, spec) }
        launch { upper.animateTo(palette.upper, spec) }
        launch { middle.animateTo(palette.middle, spec) }
        launch { lower.animateTo(palette.lower, spec) }
        launch { deep.animateTo(palette.deep, spec) }
        launch { bottom.animateTo(palette.bottom, spec) }
    }
    // The hold's only escape hatch if the track never actually changes (a seek onto the page that
    // is already playing, a queue that shrank under us, the screen closing mid-swipe).
    LaunchedEffect(blend.held) {
        if (!blend.held) return@LaunchedEffect
        delay(1400)
        blend.release()
    }
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                val other = blend.target
                val mix = if (other == null) 0f else blend.progress
                if (other == null || mix <= 0.001f) {
                    drawRect(
                        Brush.verticalGradient(
                            RAMP_POS[0] to top.value,
                            RAMP_POS[1] to crest.value,
                            RAMP_POS[2] to upper.value,
                            RAMP_POS[3] to middle.value,
                            RAMP_POS[4] to lower.value,
                            RAMP_POS[5] to deep.value,
                            RAMP_POS[6] to bottom.value
                        )
                    )
                } else {
                    drawRect(
                        Brush.verticalGradient(
                            RAMP_POS[0] to blendOklch(top.value, other.top, mix),
                            RAMP_POS[1] to blendOklch(crest.value, other.crest, mix),
                            RAMP_POS[2] to blendOklch(upper.value, other.upper, mix),
                            RAMP_POS[3] to blendOklch(middle.value, other.middle, mix),
                            RAMP_POS[4] to blendOklch(lower.value, other.lower, mix),
                            RAMP_POS[5] to blendOklch(deep.value, other.deep, mix),
                            RAMP_POS[6] to blendOklch(bottom.value, other.bottom, mix)
                        )
                    )
                }
            }
    )
}

@Composable
fun ZiziTheme(palette: ZiziPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.bottom,
            surface = palette.surface,
            onSurface = palette.text
        ),
        typography = Typography(),
        content = content
    )
}
