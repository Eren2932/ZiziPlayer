package app.ziziplayer.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.session.SessionCommand
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.ZiziResolve
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlin.math.absoluteValue

/**
 * Structural playback state. Deliberately WITHOUT position:
 * position changes several times per second and would invalidate every consumer of this state.
 * Position lives in [PlayerController.progress] so that only the seek bar reacts to it.
 */
@androidx.compose.runtime.Immutable
data class PlaybackState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentIndex: Int = 0,
    val currentTrackId: String? = null,
    val queueIds: List<String> = emptyList(),
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val sleepMinutesLeft: Int? = null,
    /** Network tracks spend real time loading; the transport controls have to show it. */
    val isBuffering: Boolean = false,
    /** Last playback failure, ready to show. Cleared by [PlayerController.clearError]. */
    val error: String? = null
)

/** Position stream, updated only while playing and only while the UI is on screen. */
data class Progress(val positionMs: Long = 0L, val durationMs: Long = 0L)

@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {

    private companion object {
        /** Seeking closer than this to the end makes ExoPlayer treat the track as finished. */
        const val END_GUARD_MS = 1200L
        /** Consecutive failed remote tracks before we stop skipping and report it. */
        const val MAX_AUTO_SKIPS = 3
        /** How long a fresh seek target wins over the session's own (lagging) reports. */
        const val SEEK_LATCH_MS = 1000L
        const val SEEK_LATCH_TOLERANCE_MS = 700L
        const val TICK_MS = 250L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingQueue: PendingQueue? = null
    private var sleepJob: Job? = null
    private var tickerJob: Job? = null
    private var sleepEndAtMs: Long? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress
    private val _connected = MutableStateFlow(false)

    /** Cached queue ids: rebuilt only when the timeline actually changes, never on every tick. */
    private var cachedQueueIds: List<String> = emptyList()
    // 6.10.1: track uris in queue order, kept only to warm the resolver for what plays next.
    private var queueUris: List<String> = emptyList()
    private var uiActive = false
    private var queueEpoch = 0

    /**
     * Duration taken from our own database, keyed by media id.
     *
     * Right after a track change the session reports an unknown duration. v4 published that as 0,
     * so the seek bar computed its fraction against a one millisecond track: dragging anywhere
     * jumped to the very end, and a seek past the end made ExoPlayer skip to the next track.
     * That is exactly the "slider glitches and switches tracks" bug.
     */
    private var knownDurations: Map<String, Long> = emptyMap()

    private var seekTargetMs = 0L
    private var latchUntilMs = 0L

    private data class PendingQueue(val tracks: List<TrackEntity>, val index: Int, val play: Boolean, val positionMs: Long)

    private var lastError: String? = null
    private var consecutiveErrors = 0

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) { handlePlayerError(error) }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // Something is playing again, so the previous complaint is stale. Clearing it here
            // instead of on a timer is what keeps the message honest: it is on screen exactly while
            // it is true.
            consecutiveErrors = 0
            if (lastError != null) { lastError = null; publish() }
            // 6.10.1: warm the resolver for what comes next. The wait for yt-dlp (2-5 s) now
            // happens while the current track is still playing, instead of after the tap.
            prefetchAhead((controller?.currentMediaItemIndex ?: 0) + 1)
        }

        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_TIMELINE_CHANGED)) invalidateQueue()
            // A new track invalidates any pending seek target immediately.
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) latchUntilMs = 0L
            publish()
            if (events.contains(Player.EVENT_POSITION_DISCONTINUITY) ||
                events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                events.contains(Player.EVENT_IS_PLAYING_CHANGED) ||
                events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED)
            ) publishProgress()
            syncTicker()
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync().also { f ->
            f.addListener({
                runCatching { f.get() }.onSuccess { c ->
                    controller = c
                    c.addListener(listener)
                    pendingQueue?.also { q -> pendingQueue = null; setQueue(q.tracks, q.index, q.play, q.positionMs) }
                    invalidateQueue(); publish(); publishProgress(); syncTicker()
                    _connected.value = true
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }

    /** Suspends until the session is bound. Callers that inspect the live queue must await this. */
    suspend fun awaitConnected() { _connected.first { it } }

    /** True when a session is already playing something: restoring over it would rewind the user. */
    fun hasQueue(): Boolean = (controller?.mediaItemCount ?: 0) > 0

    /** Called from the Activity lifecycle: no polling at all while the UI is not visible. */
    fun setUiActive(active: Boolean) {
        if (uiActive == active) return
        uiActive = active
        if (active) { publish(); publishProgress() }
        syncTicker()
    }

    private fun syncTicker() {
        val shouldTick = uiActive && _state.value.isPlaying
        if (shouldTick) {
            if (tickerJob?.isActive == true) return
            tickerJob = scope.launch {
                while (isActive) { delay(TICK_MS); publishProgress(); publishSleep() }
            }
        } else {
            tickerJob?.cancel(); tickerJob = null
        }
    }

    private fun invalidateQueue() {
        val p = controller ?: return
        cachedQueueIds = ArrayList<String>(p.mediaItemCount).apply {
            for (i in 0 until p.mediaItemCount) add(p.getMediaItemAt(i).mediaId)
        }
    }

    /** Dismisses the current error banner. */
    fun clearError() { if (lastError != null) { lastError = null; publish() } }

    /**
     * Playback errors, which barely existed while this was a local player.
     *
     * A local file fails once in a blue moon and usually stays failed. A network track fails
     * routinely and for reasons that are none of the user's business: a stale link, a track pulled
     * from the catalogue, a gap in coverage. Two rules come out of that:
     *
     *  - a dead REMOTE track must not stop the queue - it skips, the way a scratched CD track does,
     *    because stopping means the user has to pick up the phone to keep the music going;
     *  - a dead LOCAL file must NOT auto-skip - that would silently walk through a whole broken
     *    folder and leave the user staring at the last track with no idea what happened.
     *
     * The skip counter is the guard against the ugly case: a queue where everything fails would
     * otherwise race to the end at full speed. Three in a row and we stop and say so.
     */
    private fun handlePlayerError(error: PlaybackException) {
        val p = controller
        // mediaId, not the URI: Media3 strips localConfiguration from items handed to a controller,
        // so currentMediaItem.localConfiguration is null on this side of the session.
        val remote = p?.currentMediaItem?.mediaId?.startsWith("r:") == true
        lastError = describe(error, remote)
        consecutiveErrors++
        publish()
        if (remote && consecutiveErrors <= MAX_AUTO_SKIPS && p != null && p.hasNextMediaItem()) {
            p.seekToNextMediaItem()
            p.prepare()
            p.play()
        }
    }

    private fun describe(error: PlaybackException, remote: Boolean): String = when (error.errorCode) {
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Нет соединения"
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
        PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ->
            if (remote) "Трек недоступен" else "Источник недоступен"
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
            if (remote) "Трек недоступен" else "Файл не найден"
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
            "Формат не поддерживается"
        else -> generateSequence(error.cause) { it.cause }.lastOrNull()
            ?.message?.takeIf { it.isNotBlank() && it.length <= 120 }
            ?: "Ошибка воспроизведения"
    }

    private fun publish() {
        val p = controller ?: return
        // playWhenReady instead of isPlaying: the icon must not flicker while the player buffers after a seek
        val playing = p.playWhenReady && p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        val next = PlaybackState(
            connected = true,
            isPlaying = playing,
            currentIndex = p.currentMediaItemIndex.coerceAtLeast(0),
            currentTrackId = p.currentMediaItem?.mediaId,
            queueIds = cachedQueueIds,
            shuffle = p.shuffleModeEnabled,
            repeatMode = p.repeatMode,
            sleepMinutesLeft = minutesLeft(),
            // playWhenReady is part of the condition on purpose: a paused player that is filling
            // its buffer is not something the user needs a spinner for.
            isBuffering = p.playbackState == Player.STATE_BUFFERING && p.playWhenReady,
            error = lastError
        )
        if (next != _state.value) _state.value = next
    }

    /** Session duration when it is known, our own metadata otherwise. Never zero for a real track. */
    private fun durationOf(p: MediaController): Long {
        val reported = p.duration
        if (reported > 0L) return reported
        val id = p.currentMediaItem?.mediaId ?: return 0L
        return knownDurations[id] ?: 0L
    }

    private fun publishProgress() {
        val p = controller ?: return
        val duration = durationOf(p)
        val reported = p.currentPosition.coerceAtLeast(0L)
        // While latched the freshly seeked target wins, so the thumb never snaps back.
        val latched = SystemClock.elapsedRealtime() < latchUntilMs
        val position = if (latched && (reported - seekTargetMs).absoluteValue > SEEK_LATCH_TOLERANCE_MS) {
            seekTargetMs
        } else {
            if (latched) latchUntilMs = 0L
            reported
        }
        val next = Progress(position, duration)
        if (next != _progress.value) _progress.value = next
    }

    private fun publishSleep() {
        val left = minutesLeft()
        if (left != _state.value.sleepMinutesLeft) _state.value = _state.value.copy(sleepMinutesLeft = left)
    }

    private fun minutesLeft(): Int? = sleepEndAtMs?.let { end ->
        val left = end - System.currentTimeMillis()
        if (left <= 0) null else ((left + 59_999) / 60_000).toInt()
    }

    /**
     * Building hundreds of MediaItems takes tens of milliseconds, which used to be spent on the
     * main thread right after a tap - that is exactly the "button feels slow" symptom. The list is
     * now built on a background dispatcher and only handed to the controller on the main thread.
     */
    /**
     * 6.10.1 - asks our own resolver to pre-resolve the next few remote tracks.
     *
     * Deliberately best-effort and index-based: under shuffle the guess can be wrong, and that is
     * fine. A wrong guess costs one cached entry on the server; a right guess removes the whole
     * visible delay. Local tracks are skipped, and the resolver itself drops ids it has already
     * seen, so this cannot turn into a request storm.
     */
    private fun prefetchAhead(fromIndex: Int) {
        if (!ZiziResolve.configured || queueUris.isEmpty()) return
        val ids = ArrayList<String>(3)
        var i = fromIndex.coerceAtLeast(0)
        while (i < queueUris.size && ids.size < 3) {
            val parsed = RemoteUri.parse(Uri.parse(queueUris[i]))
            if (parsed != null && parsed.first == "yt") ids.add(parsed.second)
            i++
        }
        // Очередь — единственное место, где прогрев БАЙТОВ оправдан: эти треки почти наверняка
        // будут услышаны, и «вперёд» по ним обязано быть мгновенным.
        if (ids.isNotEmpty()) ZiziResolve.prefetch(ids, bytes = true)
    }

    fun setQueue(tracks: List<TrackEntity>, startIndex: Int, play: Boolean = true, startPositionMs: Long = 0L) {
        if (tracks.isEmpty()) return
        val p = controller ?: run { pendingQueue = PendingQueue(tracks, startIndex, play, startPositionMs); return }
        val epoch = ++queueEpoch
        scope.launch {
            val prepared = withContext(Dispatchers.Default) {
                val durations = HashMap<String, Long>(tracks.size * 2)
                val items = tracks.map { t ->
                    durations[t.id] = t.durationMs
                    mediaItemOf(t)
                }
                items to durations
            }
            if (epoch != queueEpoch) return@launch
            knownDurations = prepared.second
            latchUntilMs = 0L
            val items = prepared.first
            queueUris = tracks.map { it.uri }
            p.setMediaItems(items, startIndex.coerceIn(items.indices), startPositionMs.coerceAtLeast(0))
            p.prepare(); if (play) p.play()
            prefetchAhead(startIndex.coerceIn(items.indices))
            invalidateQueue(); publish(); publishProgress(); syncTicker()
        }
    }

    /**
     * Один способ собрать MediaItem на всё приложение.
     *
     * Был встроен внутрь setQueue; «добавить в очередь» обязано класть в таймлайн ровно такой же
     * item, иначе у добавленного трека была бы другая обложка в шторке — классическое расхождение,
     * которое замечают через неделю и ищут час.
     */
    private fun mediaItemOf(t: TrackEntity): MediaItem =
        MediaItem.Builder().setMediaId(t.id).setUri(t.uri)
            // 6.24.0: адрес ещё и в requestMetadata. Единственная часть элемента, которая
            // гарантированно переживает границу сессии: localConfiguration Media3 срезает, и
            // сервис восстанавливает URI именно отсюда (см. PlaybackService.withUri).
            .setRequestMetadata(
                MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(t.uri)).build()
            )
            .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                // Fall back to the audio file itself: the service reads the embedded
                // cover from it, so the system notification is never left without art.
                .setArtworkUri(Uri.parse(t.artworkUri ?: t.uri))
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .build()
        ).build()

    /**
     * «Играть следующим» / «Добавить в очередь».
     *
     * Вставка в существующий таймлайн, а не пересборка очереди: пересборка сбросила бы позицию
     * текущего трека и порядок шаффла. На пустом плеере ведёт себя как обычный старт.
     */
    fun enqueue(track: TrackEntity, playNext: Boolean) {
        val p = controller ?: run {
            pendingQueue = PendingQueue(listOf(track), 0, play = false, positionMs = 0L)
            return
        }
        knownDurations = knownDurations + (track.id to track.durationMs)
        if (p.mediaItemCount == 0) {
            queueUris = listOf(track.uri)
            p.setMediaItems(listOf(mediaItemOf(track)), 0, 0L)
            p.prepare()
        } else {
            val index = if (playNext) (p.currentMediaItemIndex + 1).coerceAtMost(p.mediaItemCount)
                        else p.mediaItemCount
            // 6.24.0: список адресов держится в синхроне с таймлайном. Раньше добавление в
            // очередь его не трогало, и прогрев резолвера «что играет дальше» после каждого
            // «играть следующим» смотрел на сдвинутый список, то есть греил чужой трек.
            queueUris = ArrayList<String>(queueUris.size + 1).apply {
                addAll(queueUris)
                add(index.coerceIn(0, size), track.uri)
            }
            p.addMediaItem(index, mediaItemOf(track))
        }
        invalidateQueue(); publish(); publishProgress()
    }

    /**
     * Перейти к треку очереди ПО ИДЕНТИФИКАТОРУ, а не по номеру строки (6.24.0).
     *
     * Экран очереди показывает не таймлайн плеера, а результат сопоставления его id с библиотекой
     * (MainViewModel.queue). Любой трек, которого в библиотеке нет — например, найденный поиском и
     * добавленный через «Добавить в очередь», — из списка выпадает, и дальше номера строк на экране
     * и номера элементов в плеере расходятся: человек жмёт одну песню, играет другая. Ошибка тем
     * подлее, что появляется только у тех, кто пользуется поиском и очередью одновременно.
     *
     * Идентификатор такого расхождения не имеет в принципе.
     */
    fun seekToTrack(trackId: String) {
        val index = cachedQueueIds.indexOf(trackId)
        if (index >= 0) seekToIndex(index)
    }

    /** Used when a track is removed from the library: it must leave the running queue too. */
    fun removeFromQueue(trackId: String) {
        val p = controller ?: return
        val index = cachedQueueIds.indexOf(trackId)
        if (index < 0) return
        if (p.mediaItemCount <= 1) { p.pause(); p.clearMediaItems() } else p.removeMediaItem(index)
        invalidateQueue(); publish(); publishProgress()
    }

    fun playPause() { controller?.let { if (it.playWhenReady) it.pause() else it.play() }; publish(); syncTicker() }

    fun seekTo(positionMs: Long) {
        val p = controller ?: return
        val duration = durationOf(p)
        // Never land inside the last moment of a track: that is what made it jump to the next one.
        val max = if (duration > 0L) (duration - END_GUARD_MS).coerceAtLeast(0L) else Long.MAX_VALUE
        val target = positionMs.coerceAtLeast(0L).coerceAtMost(max)
        seekTargetMs = target
        latchUntilMs = SystemClock.elapsedRealtime() + SEEK_LATCH_MS
        p.seekTo(target)
        _progress.value = Progress(target, duration)
    }

    fun seekToIndex(index: Int) { latchUntilMs = 0L; controller?.seekToDefaultPosition(index); publish(); publishProgress() }
    fun next() { latchUntilMs = 0L; controller?.seekToNextMediaItem(); publish(); publishProgress() }
    fun previous() {
        val p = controller ?: return
        latchUntilMs = 0L
        // Standard behaviour: restart the track if we are past 3 seconds, otherwise go back
        if (p.currentPosition > 3000) p.seekTo(0) else p.seekToPreviousMediaItem()
        publish(); publishProgress()
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; publish() }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
        publish()
    }
    fun setPlayback(speed: Float, pitch: Float, reverb: Int = 0) {
        controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_REVERB, Bundle.EMPTY), Bundle().apply { putInt("percent", reverb) })
    }
    fun setSkipSilence(enabled: Boolean) {
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_SKIP_SILENCE, Bundle.EMPTY), Bundle().apply { putBoolean("enabled", enabled) })
    }
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel(); sleepJob = null
        if (minutes == null || minutes <= 0) { sleepEndAtMs = null; publishSleep(); return }
        sleepEndAtMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause(); sleepEndAtMs = null; publish(); publishSleep()
        }
        publishSleep()
    }
    fun release() {
        sleepJob?.cancel(); tickerJob?.cancel()
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        scope.cancel()
    }
}
