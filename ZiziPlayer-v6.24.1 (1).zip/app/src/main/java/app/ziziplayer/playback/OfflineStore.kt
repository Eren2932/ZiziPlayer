package app.ziziplayer.playback

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.FileProvider
import app.ziziplayer.data.TrackEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Хранилище СКАЧАННОГО. 6.24.1: три цели вместо одной, и проверка вместо надежды.
 *
 * ## Что было не так в 6.24.0
 *
 * 6.24.0 сделала правильную вещь — загрузка стала настоящим файлом в «Музыка/Zizi» через
 * `MediaStore` — но сделала её ровно одним способом и без проверки результата. У тестировщика
 * это дало «скачал, а файла нигде нет», причём приложение при этом говорило «скачано».
 * Три конкретных механизма, каждый из которых воспроизводится на живых прошивках:
 *
 * 1. **`IS_PENDING` не снялся.** Строка вставляется невидимой (`IS_PENDING=1`) и становится
 *    видимой только после `update`. `update` мог вернуть **0 обновлённых строк** (часть
 *    прошивок молча отказывает, если владелец строки не совпал или строка была перемещена
 *    системным индексатором) — исключения при этом нет. Владелец, то есть мы сами, свой
 *    pending-файл читать может, поэтому `exists()` отвечал «да», индекс писался, меню
 *    показывало «Скачано» — а для файлового менеджера, чужого плеера и системной медиатеки
 *    файла не существовало. Ровно жалоба тестера, слово в слово.
 * 2. **Собственная уборка добивала загрузку.** `cleanupPending` при следующем запуске удаляла
 *    все pending-строки в нашей папке — то есть именно те, которые не финализировались.
 *    Файл исчезал окончательно, а запись в индексе оставалась.
 * 3. **Одна цель без запасной.** Если `insert` в `MediaStore` не дал строки (а это бывает:
 *    Android 10 с `requestLegacyExternalStorage`, «защищённые папки», SD как primary,
 *    урезанные китайские прошивки, режим экономии памяти), загрузка просто падала. На API
 *    26-28 всё держалось на `WRITE_EXTERNAL_STORAGE`, которое приложение **никогда не
 *    запрашивало** — только проверяло и отказывалось качать.
 *
 * ## Как теперь
 *
 * Байты сначала целиком скачиваются во временный файл в `cacheDir` (см. [OfflineDownloads]),
 * и только потом публикуются. Это даёт две вещи: расширение определяется по настоящему
 * содержимому, а публикация становится атомарной операцией, которую можно проверить и, если
 * она не удалась, повторить другим способом, не теряя уже скачанные байты.
 *
 * Лестница целей, сверху вниз, первая сработавшая побеждает:
 *
 * | Цель | Где лежит | Кому видно |
 * |---|---|---|
 * | [Kind.MEDIA] | `Музыка/Zizi` через MediaStore (API 29+) | всем: проводник, чужие плееры, медиатека |
 * | [Kind.PUBLIC] | `/sdcard/Music/Zizi` обычным файлом + MediaScanner | всем (нужно разрешение, API 26-28) |
 * | [Kind.APP] | `Android/data/<пакет>/files/Music/Zizi` | приложению всегда; проводнику — до Android 11 |
 *
 * Публикация в `MEDIA` считается успешной, только если после снятия `IS_PENDING` **повторный
 * запрос к MediaStore** вернул строку с `IS_PENDING=0` и ненулевым размером. Не вернул —
 * строка удаляется и мы идём на следующую ступень. «Скачано» больше не может означать
 * «где-то есть невидимая строка».
 *
 * У каждой записи хранится человеческий путь ([Entry.path]) — он показывается в меню трека и в
 * настройках, чтобы на вопрос «где мой трек» отвечало приложение, а не тестировщик.
 *
 * Истина по-прежнему на диске: запись, файла которой нет, молча выпадает из индекса.
 */
object OfflineStore {

    /** Папка внутри «Музыки». Видна пользователю, поэтому названа так, как называется приложение. */
    const val FOLDER = "Zizi"
    const val FOLDER_LABEL = "Музыка/Zizi"

    private const val INDEX_FILE = "offline-index.json"
    private const val NAME_LIMIT = 84
    private const val CHECK_TTL_MS = 5_000L

    /** Куда легли байты. Определяет и способ удаления, и то, что написано человеку. */
    enum class Kind { MEDIA, PUBLIC, APP;
        companion object {
            fun of(raw: String?): Kind = when (raw) {
                "public" -> PUBLIC
                "app" -> APP
                else -> MEDIA
            }
        }
        val key: String get() = name.lowercase()
    }

    data class Entry(
        val trackId: String,
        val trackUri: String,
        /** `content://…` для [Kind.MEDIA], абсолютный путь для остальных. */
        val location: String,
        val name: String,
        val mime: String,
        val bytes: Long,
        val savedAt: Long,
        val kind: Kind = Kind.MEDIA,
        /** Человеческий путь для показа на экране. Пустой — значит не знаем, покажем папку. */
        val path: String = ""
    ) {
        val where: String get() = if (path.isNotBlank()) path else FOLDER_LABEL
        /** true — файл лежит там, куда может дойти файловый менеджер и чужой плеер. */
        val visibleToOthers: Boolean get() = kind != Kind.APP
    }

    private val lock = Any()
    private var loaded = false
    /**
     * Когда файл записи последний раз проверялся на существование.
     *
     * Проверка — обращение к ContentResolver, то есть IPC, а статус загрузки читается из
     * композиции. Без этого кэша каждый шаг прогресса стоил бы походом в другой процесс.
     */
    private val checkedAt = HashMap<String, Long>()
    private val byId = LinkedHashMap<String, Entry>()
    private val byUri = HashMap<String, Entry>()

    /* ------------------------------------------------------------------ индекс */

    private fun indexFile(context: Context) = File(context.filesDir, INDEX_FILE)

    private fun ensureLoaded(context: Context) {
        synchronized(lock) { ensureLoadedLocked(context) }
    }

    private fun ensureLoadedLocked(context: Context) {
        if (!loaded) { loaded = true; runCatching { loadInto(context) } }
    }

    private fun loadInto(context: Context) {
        val file = indexFile(context)
        if (!file.exists()) return
        val array = JSONArray(file.readText())
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val entry = Entry(
                trackId = o.optString("id"),
                trackUri = o.optString("track"),
                location = o.optString("at"),
                name = o.optString("name"),
                mime = o.optString("mime", "audio/mp4"),
                bytes = o.optLong("bytes"),
                savedAt = o.optLong("saved"),
                // Записи 6.24.0 этих полей не знают: тогда цель была одна, и она была MEDIA.
                kind = Kind.of(o.optString("kind").ifBlank { null }),
                path = o.optString("path")
            )
            if (entry.trackId.isBlank() || entry.location.isBlank()) continue
            byId[entry.trackId] = entry
            byUri[entry.trackUri] = entry
        }
    }

    private fun persist(context: Context) {
        val snapshot = synchronized(lock) { byId.values.toList() }
        val array = JSONArray()
        snapshot.forEach { e ->
            array.put(
                JSONObject()
                    .put("id", e.trackId)
                    .put("track", e.trackUri)
                    .put("at", e.location)
                    .put("name", e.name)
                    .put("mime", e.mime)
                    .put("bytes", e.bytes)
                    .put("saved", e.savedAt)
                    .put("kind", e.kind.key)
                    .put("path", e.path)
            )
        }
        // Через временный файл: обрыв на записи индекса не должен превращать все загрузки в «нет».
        runCatching {
            val target = indexFile(context)
            val tmp = File(target.parentFile, "$INDEX_FILE.tmp")
            tmp.writeText(array.toString())
            if (!tmp.renameTo(target)) { target.writeText(array.toString()); tmp.delete() }
        }
    }

    /* ------------------------------------------------------------------ чтение */

    /** Запись, ФАЙЛ КОТОРОЙ существует. Пропавший файл вычищается из индекса здесь же. */
    fun entryOf(context: Context, trackId: String): Entry? {
        ensureLoaded(context)
        val entry = synchronized(lock) { byId[trackId] } ?: return null
        if (verified(context, entry)) return entry
        forget(context, entry)
        return null
    }

    fun entryForUri(context: Context, trackUri: String): Entry? {
        ensureLoaded(context)
        val entry = synchronized(lock) { byUri[trackUri] } ?: return null
        if (verified(context, entry)) return entry
        forget(context, entry)
        return null
    }

    /** Все живые загрузки, свежие сверху. Для экрана «Скачанное». */
    fun all(context: Context): List<Entry> {
        ensureLoaded(context)
        val snapshot = synchronized(lock) { byId.values.toList() }
        val alive = snapshot.filter { exists(context, it) }
        if (alive.size != snapshot.size) {
            (snapshot - alive.toSet()).forEach { forget(context, it) }
        }
        return alive.sortedByDescending { it.savedAt }
    }

    /** Файла больше нет на диске: убрать запись, дальше играем из сети. */
    fun forgetUri(context: Context, trackUri: Uri) {
        ensureLoaded(context)
        val entry = synchronized(lock) { byUri[trackUri.toString()] } ?: return
        forget(context, entry)
    }

    fun isDownloaded(context: Context, track: TrackEntity): Boolean = entryOf(context, track.id) != null

    /** Где лежит скачанная копия трека — человеческим текстом. `null` — копии нет. */
    fun whereIs(context: Context, track: TrackEntity): String? = entryOf(context, track.id)?.where

    /** Адрес, из которого играть офлайн. `null` — качать ещё нечего. */
    fun playbackUri(context: Context, trackUri: Uri): Uri? {
        val entry = entryForUri(context, trackUri.toString()) ?: return null
        return locationUri(entry)
    }

    private fun locationUri(entry: Entry): Uri =
        if (entry.location.startsWith("content://")) Uri.parse(entry.location)
        else Uri.fromFile(File(entry.location))

    private fun verified(context: Context, entry: Entry): Boolean {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val last = checkedAt[entry.trackId]
            if (last != null && now - last < CHECK_TTL_MS) return true
        }
        if (!exists(context, entry)) {
            synchronized(lock) { checkedAt.remove(entry.trackId) }
            return false
        }
        synchronized(lock) { checkedAt[entry.trackId] = now }
        return true
    }

    private fun exists(context: Context, entry: Entry): Boolean = runCatching {
        if (entry.location.startsWith("content://")) {
            // Именно openAssetFileDescriptor, а не query: строку могло не остаться, а мог
            // остаться и файл без строки. Открывается — значит играть можно.
            context.contentResolver.openAssetFileDescriptor(Uri.parse(entry.location), "r")?.use { true } ?: false
        } else {
            val file = File(entry.location)
            file.isFile && file.length() > 0L
        }
    }.getOrDefault(false)

    fun count(context: Context): Int { ensureLoaded(context); return synchronized(lock) { byId.size } }

    fun sizeBytes(context: Context): Long {
        ensureLoaded(context)
        return synchronized(lock) { byId.values.sumOf { it.bytes } }
    }

    /**
     * Что отправить в «Поделиться». `null` — файла нет, и врать вложением нельзя.
     *
     * MediaStore-адрес уходит наружу как есть: он и так `content://`, разовое разрешение на
     * чтение выдаётся системой. Файловый путь заворачивается в FileProvider — прямой `file://`
     * в чужое приложение с Android 7 запрещён (FileUriExposedException, то есть падение).
     */
    fun shareTarget(context: Context, track: TrackEntity): Pair<Uri, String>? {
        val entry = entryOf(context, track.id) ?: return null
        val uri = contentUriOf(context, entry) ?: return null
        return uri to entry.mime
    }

    private fun contentUriOf(context: Context, entry: Entry): Uri? =
        if (entry.location.startsWith("content://")) Uri.parse(entry.location)
        else runCatching {
            FileProvider.getUriForFile(context, context.packageName + ".files", File(entry.location))
        }.getOrNull()

    /* ------------------------------------------------------------------ «покажи мне файл» */

    /**
     * Интент «открыть этот файл другим приложением».
     *
     * Это единственный честный способ ответить на «где мой трек»: человек нажимает и видит
     * файл в системном плеере или в проводнике. Ссылка выдаётся с разовым разрешением на
     * чтение — без него сторонний просмотрщик получит SecurityException у себя.
     */
    fun viewIntent(context: Context, track: TrackEntity): Intent? {
        val entry = entryOf(context, track.id) ?: return null
        val uri = contentUriOf(context, entry) ?: return null
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, entry.mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Интент «открыть папку Музыка/Zizi».
     *
     * Единого способа открыть папку в Android нет, поэтому здесь список кандидатов, а не одна
     * попытка: сначала системный «Файлы» через `DocumentsContract` (Android 8+), затем
     * `ACTION_VIEW` по дереву документов. Вызывающий берёт первый, который кто-то может
     * обработать; ни один не подошёл — показываем текстовый путь, тоже честный ответ.
     */
    fun folderIntents(): List<Intent> {
        val docId = "primary:" + Environment.DIRECTORY_MUSIC + "/" + FOLDER
        val out = ArrayList<Intent>(3)
        runCatching {
            val tree = DocumentsContract.buildTreeDocumentUri("com.android.externalstorage.documents", docId)
            val doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            out += Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
        runCatching {
            val doc = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId)
            out += Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
        out += Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://com.android.externalstorage.documents/root/primary"),
                DocumentsContract.Document.MIME_TYPE_DIR)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return out
    }

    /* ------------------------------------------------------------------ запись */

    /** true — на этой версии Android для записи в публичную «Музыку» нужно разрешение, и его нет. */
    fun needsLegacyPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return false
        return context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /**
     * Опубликовать скачанные байты. Пробует цели по очереди и ПРОВЕРЯЕТ результат.
     *
     * @param source временный файл с полностью скачанным треком; удаляется вызывающим.
     * @throws IOException если не сработала ни одна цель — с текстом, который можно показать.
     */
    fun save(context: Context, track: TrackEntity, source: File, mime: String, extension: String): Entry {
        val name = fileName(track, extension)
        val problems = ArrayList<String>(3)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { saveViaMediaStore(context, track, source, name, mime) }
                .onSuccess { if (it != null) return remember(context, it) }
                .onFailure { problems += "медиатека: " + short(it) }
        }
        runCatching { saveToPublicFolder(context, source, name, mime) }
            .onSuccess { if (it != null) return remember(context, entryFrom(track, it, mime, Kind.PUBLIC)) }
            .onFailure { problems += "папка «Музыка»: " + short(it) }

        runCatching { saveToAppFolder(context, source, name) }
            .onSuccess { if (it != null) return remember(context, entryFrom(track, it, mime, Kind.APP)) }
            .onFailure { problems += "память приложения: " + short(it) }

        throw IOException(problems.firstOrNull() ?: "не удалось сохранить файл")
    }

    private fun short(error: Throwable): String =
        error.message?.takeIf { it.isNotBlank() }?.take(80) ?: (error.javaClass.simpleName)

    private fun entryFrom(track: TrackEntity, file: File, mime: String, kind: Kind) = Entry(
        trackId = track.id,
        trackUri = track.uri,
        location = file.absolutePath,
        name = file.name,
        mime = mime,
        bytes = file.length(),
        savedAt = System.currentTimeMillis(),
        kind = kind,
        path = humanPath(file)
    )

    private fun remember(context: Context, entry: Entry): Entry {
        synchronized(lock) {
            ensureLoadedLocked(context)
            byId[entry.trackId] = entry
            byUri[entry.trackUri] = entry
            checkedAt[entry.trackId] = System.currentTimeMillis()
        }
        persist(context)
        return entry
    }

    /**
     * Цель №1: строка в `MediaStore.Audio` внутри `Музыка/Zizi`.
     *
     * Возвращает `null`, а не бросает, когда система вставила строку, но публикация не
     * подтвердилась: это не ошибка приложения, это ступень лестницы, которая не сработала.
     * Незавершённая строка при этом удаляется — невидимый мусор в памяти телефона хуже,
     * чем честное «сохранилось в другое место».
     */
    @androidx.annotation.RequiresApi(Build.VERSION_CODES.Q)
    private fun saveViaMediaStore(
        context: Context,
        track: TrackEntity,
        source: File,
        name: String,
        mime: String
    ): Entry? {
        val relative = Environment.DIRECTORY_MUSIC + "/" + FOLDER + "/"
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, relative)
            put(MediaStore.Audio.Media.TITLE, track.title)
            put(MediaStore.Audio.Media.ARTIST, track.artist)
            if (track.album.isNotBlank()) put(MediaStore.Audio.Media.ALBUM, track.album)
            if (track.durationMs > 0L) put(MediaStore.Audio.Media.DURATION, track.durationMs)
            put(MediaStore.Audio.Media.IS_MUSIC, 1)
            // Невидим для всей системы, пока не дописан: обрыв не может оставить «битый трек».
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val row = context.contentResolver.insert(collection, values) ?: return null

        var ok = false
        try {
            val written = context.contentResolver.openOutputStream(row, "w")?.use { out ->
                source.inputStream().use { input -> input.copyTo(out, 64 * 1024) }
            } ?: return null
            if (written <= 0L) return null

            // Снятие флага + ПРОВЕРКА, что оно действительно применилось. Именно здесь 6.24.0
            // верила системе на слово: update мог вернуть 0 строк без исключения, и файл
            // оставался невидимым для всех, кроме нас самих.
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            context.contentResolver.update(row, done, null, null)
            val published = publishedInfo(context, row) ?: return null
            if (published.bytes <= 0L) return null
            ok = true
            return Entry(
                trackId = track.id,
                trackUri = track.uri,
                location = row.toString(),
                name = published.name.ifBlank { name },
                mime = mime,
                bytes = published.bytes,
                savedAt = System.currentTimeMillis(),
                kind = Kind.MEDIA,
                path = published.path.ifBlank { FOLDER_LABEL + "/" + name }
            )
        } finally {
            if (!ok) runCatching { context.contentResolver.delete(row, null, null) }
        }
    }

    private class Published(val name: String, val path: String, val bytes: Long)

    /** Строка после публикации: не pending, размер больше нуля, путь известен. `null` — не вышло. */
    private fun publishedInfo(context: Context, row: Uri): Published? = runCatching {
        val columns = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            arrayOf(
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.RELATIVE_PATH,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.IS_PENDING
            )
        } else {
            arrayOf(MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE)
        }
        context.contentResolver.query(row, columns, null, null, null)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            val name = cursor.getString(0) ?: ""
            val relative = if (columns.size > 2) cursor.getString(1) ?: "" else ""
            val size = if (columns.size > 2) cursor.getLong(2) else cursor.getLong(1)
            val pending = if (columns.size > 3) cursor.getInt(3) else 0
            if (pending != 0) return@use null
            val human = if (relative.isBlank()) "" else relative.trim('/').replace(
                Environment.DIRECTORY_MUSIC, "Музыка"
            ) + "/" + name
            Published(name, human, size)
        }
    }.getOrNull()

    /**
     * Цель №2: обычный файл в публичной `/Music/Zizi` + MediaScanner.
     *
     * Штатный путь для API 26-28. На Android 10+ обычно недоступен (scoped storage), поэтому
     * `null` здесь — норма, а не сбой: работает как запасной аэродром для прошивок, где
     * MediaStore отказал, но публичная запись всё ещё разрешена (например Android 10 с
     * `requestLegacyExternalStorage` у себя же в манифесте, или SD-карта как основная память).
     */
    private fun saveToPublicFolder(context: Context, source: File, name: String, mime: String): File? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && needsLegacyPermission(context)) {
            throw IOException("нужен доступ к памяти")
        }
        if (Environment.getExternalStorageState() != Environment.MEDIA_MOUNTED) return null
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), FOLDER)
        if (!dir.exists() && !dir.mkdirs()) return null
        if (!dir.canWrite()) return null
        val target = copyInto(dir, name, source) ?: return null
        // Без сканера файл есть, а в медиатеке телефона его нет до перезагрузки.
        runCatching {
            MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf(mime), null)
        }
        return target
    }

    /**
     * Цель №3: `Android/data/<пакет>/files/Music/Zizi`.
     *
     * Последняя ступень и намеренно последняя: с Android 11 файловые менеджеры сюда не
     * пускают, то есть «файл, который видно» здесь уже не обещается. Но офлайн-воспроизведение
     * работает, разрешений не нужно вообще, и это лучше, чем «скачать» с ошибкой на прошивке,
     * которая не дала ни одной публичной цели. Приложение честно пишет, что копия лежит
     * внутри него — см. [Entry.visibleToOthers].
     */
    private fun saveToAppFolder(context: Context, source: File, name: String): File? {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: File(context.filesDir, Environment.DIRECTORY_MUSIC)
        val dir = File(base, FOLDER)
        if (!dir.exists() && !dir.mkdirs()) return null
        return copyInto(dir, name, source)
    }

    /** Копия с разведением имён: «Артист - Трек (2).m4a», а не молчаливая перезапись. */
    private fun copyInto(dir: File, name: String, source: File): File? {
        var target = File(dir, name)
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 2
        while (target.exists()) { target = File(dir, "$stem ($n)$ext"); n++ }
        return runCatching {
            FileOutputStream(target).use { out -> source.inputStream().use { it.copyTo(out, 64 * 1024) } }
            if (target.length() > 0L) target else { target.delete(); null }
        }.getOrElse { target.delete(); throw it }
    }

    private fun humanPath(file: File): String {
        val root = runCatching { Environment.getExternalStorageDirectory().absolutePath }.getOrNull()
        val raw = file.absolutePath
        val trimmed = if (root != null && raw.startsWith(root)) raw.removePrefix(root).trimStart('/') else raw
        return trimmed.replace(Environment.DIRECTORY_MUSIC + "/" + FOLDER, "Музыка/" + FOLDER)
    }

    /* ------------------------------------------------------------------ удаление */

    /** «Удалить загрузку»: файла больше нет, трек остаётся в библиотеке и играет из сети. */
    fun delete(context: Context, trackId: String) {
        val entry = run { ensureLoaded(context); synchronized(lock) { byId[trackId] } } ?: return
        if (entry.location.startsWith("content://")) {
            runCatching { context.contentResolver.delete(Uri.parse(entry.location), null, null) }
        } else {
            val file = File(entry.location)
            runCatching { file.delete() }
            runCatching {
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(entry.mime), null)
            }
        }
        forget(context, entry)
    }

    fun deleteAll(context: Context) {
        ensureLoaded(context)
        synchronized(lock) { byId.keys.toList() }.forEach { delete(context, it) }
    }

    private fun forget(context: Context, entry: Entry) {
        synchronized(lock) {
            checkedAt.remove(entry.trackId)
            byId.remove(entry.trackId)
            if (byUri[entry.trackUri]?.trackId == entry.trackId) byUri.remove(entry.trackUri)
        }
        persist(context)
    }

    /**
     * Уборка pending-строк, оставшихся после убитого процесса.
     *
     * 6.24.1: сначала попытка ДОПУБЛИКОВАТЬ, и только потом удаление, и только для строк,
     * которых нет в нашем индексе. В 6.24.0 этот метод удалял всё pending в папке подряд —
     * то есть добивал именно те загрузки, у которых не снялся флаг, и делал жалобу «файла
     * нигде нет» окончательной.
     */
    fun cleanupPending(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        ensureLoaded(context)
        val known = synchronized(lock) { byId.values.map { it.location }.toSet() }
        runCatching {
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val where = MediaStore.Audio.Media.IS_PENDING + "=1 AND " +
                MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("%" + Environment.DIRECTORY_MUSIC + "/" + FOLDER + "%")
            val ids = ArrayList<Long>()
            context.contentResolver.query(
                collection,
                arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.SIZE),
                where,
                args,
                null
            )?.use { cursor ->
                while (cursor.moveToNext()) ids += cursor.getLong(0)
            }
            ids.forEach { id ->
                val row = ContentUris.withAppendedId(collection, id)
                if (known.contains(row.toString())) {
                    // Наша запись, у которой не снялся флаг: пробуем ещё раз, а не удаляем.
                    val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                    runCatching { context.contentResolver.update(row, done, null, null) }
                } else {
                    runCatching { context.contentResolver.delete(row, null, null) }
                }
            }
        }
    }

    /* ------------------------------------------------------------------ отчёт «где мои файлы» */

    /**
     * Отчёт для человека и для чата с разработчиком.
     *
     * Написан потому, что диагностика «у меня нет скачанного трека нигде» стоила переписки на
     * два дня и одной версии наугад. Теперь тестировщик открывает настройки, нажимает
     * «Проверить загрузки» и присылает текст, в котором видно: версия Android, куда реально
     * легли файлы, сколько их, есть ли они на диске, видит ли их системная медиатека.
     */
    fun report(context: Context): String {
        ensureLoaded(context)
        val entries = synchronized(lock) { byId.values.toList() }
        val lines = ArrayList<String>()
        lines += "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}"
        lines += "Записей в индексе: ${entries.size}"
        val alive = entries.count { exists(context, it) }
        lines += "Файлы на месте: $alive из ${entries.size}"
        val byKind = entries.groupingBy { it.kind }.eachCount()
        if (byKind.isNotEmpty()) {
            lines += "Куда легли: " + byKind.entries.joinToString(", ") { (k, n) ->
                when (k) {
                    Kind.MEDIA -> "медиатека $n"
                    Kind.PUBLIC -> "Музыка/Zizi файлом $n"
                    Kind.APP -> "внутри приложения $n"
                }
            }
        }
        lines += "Видит ли системная медиатека папку: " + mediaStoreCount(context)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            lines += "Разрешение на запись: " + if (needsLegacyPermission(context)) "НЕТ" else "есть"
        }
        val free = runCatching { context.cacheDir.usableSpace / 1024 / 1024 }.getOrDefault(-1L)
        lines += "Свободно: $free МБ"
        entries.sortedByDescending { it.savedAt }.take(5).forEach { e ->
            lines += "• ${e.name} — ${e.where}" + if (exists(context, e)) "" else "  ← ФАЙЛА НЕТ"
        }
        return lines.joinToString("\n")
    }

    private fun mediaStoreCount(context: Context): String = runCatching {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            @Suppress("DEPRECATION") MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val column = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.RELATIVE_PATH
        } else {
            @Suppress("DEPRECATION") MediaStore.Audio.Media.DATA
        }
        var n = 0
        context.contentResolver.query(
            collection,
            arrayOf(MediaStore.Audio.Media._ID),
            "$column LIKE ?",
            arrayOf("%" + Environment.DIRECTORY_MUSIC + "/" + FOLDER + "%"),
            null
        )?.use { n = it.count }
        "$n файлов"
    }.getOrElse { "не удалось спросить" }

    /* ------------------------------------------------------------------ имя файла */

    private fun fileName(track: TrackEntity, extension: String): String {
        val artist = sanitize(track.artist)
        val title = sanitize(track.title).ifBlank { "track" }
        val stem = if (artist.isBlank() || artist == "—") title else "$artist - $title"
        return stem.take(NAME_LIMIT).trimEnd('.', ' ') + "." + extension
    }

    private fun sanitize(raw: String): String = raw
        .replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

/**
 * Чем оказались скачанные байты.
 *
 * Расширение не угадывается по настройкам качества и не берётся из ответа сервера: и то и другое
 * врёт (резолвер может отдать webm там, где просили m4a). Смотрим на первые байты — это и есть
 * единственный честный источник. Неправильное расширение стоит дорого: файл лежит в общей папке
 * «Музыка», и его будут открывать чужие приложения, которые верят расширению, а не содержимому.
 */
internal object AudioFormatSniffer {

    data class Format(val mime: String, val extension: String)

    private val M4A = Format("audio/mp4", "m4a")

    fun of(buffer: ByteArray, length: Int): Format {
        if (length < 12) return M4A
        fun ascii(from: Int, text: String): Boolean {
            if (from + text.length > length) return false
            for (i in text.indices) if (buffer[from + i] != text[i].code.toByte()) return false
            return true
        }
        return when {
            ascii(4, "ftyp") -> M4A
            ascii(0, "OggS") -> Format("audio/ogg", "ogg")
            ascii(0, "ID3") -> Format("audio/mpeg", "mp3")
            ascii(0, "RIFF") -> Format("audio/wav", "wav")
            ascii(0, "fLaC") -> Format("audio/flac", "flac")
            buffer[0] == 0x1A.toByte() && buffer[1] == 0x45.toByte() &&
                buffer[2] == 0xDF.toByte() && buffer[3] == 0xA3.toByte() -> Format("audio/webm", "webm")
            (buffer[0].toInt() and 0xFF) == 0xFF && (buffer[1].toInt() and 0xE0) == 0xE0 ->
                Format("audio/mpeg", "mp3")
            else -> M4A
        }
    }
}
