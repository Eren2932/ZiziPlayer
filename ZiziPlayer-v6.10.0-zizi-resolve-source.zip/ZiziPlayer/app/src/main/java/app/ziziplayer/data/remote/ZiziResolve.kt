package app.ziziplayer.data.remote

/**
 * 6.10.0 — ZiziResolve: поток берётся у СВОЕГО сервера, а не у YouTube напрямую.
 *
 * Почему этот файл вообще существует.
 *
 * До 6.9.4 приложение просило поток у Innertube само, с телефона, восемью внутренними клиентами
 * по очереди. Полная диагностика 6.9.4 дала однозначный ответ: все восемь клиентов, оба семейства
 * хостов, валидный poToken на руках — и `LOGIN_REQUIRED «Войдите в аккаунт, чтобы подтвердить,
 * что вы не бот»` восемь раз из восьми, `форматов 0`. Это не наш баг в разборе ответа: это отказ
 * на входе, аттестация. С неподписанного Google приложения она не проходится в принципе.
 *
 * Тот же самый трек (fBM-Ld2YyRw), запрошенный yt-dlp с VPS, отдался с первой попытки:
 * `rr4---sn-5hne6nz6.googlevideo.com … mime=audio/webm … clen=3071673 … dur=187.381`.
 * Разница не в коде и не в заголовках. Разница в том, ОТКУДА задан вопрос.
 *
 * Поэтому резолв вынесен на сервер, где есть Python, JS-движок (Deno) и обновления yt-dlp раз в
 * сутки — то есть всё, чего в APK нет и не будет. Поиск остаётся у [InnertubeCatalog]: он не
 * ломался ни разу, там аттестация не требуется.
 *
 * Два режима, и разница между ними не косметическая:
 *
 *  - `/stream` (по умолчанию) — сервер сам тянет байты с googlevideo и льёт их плееру, с
 *    поддержкой Range. Ссылка googlevideo чеканится ПОД IP того, кто её попросил: выданная
 *    серверу, с телефона она может отдать 403. Проксирование снимает этот вопрос целиком, а
 *    заодно делает адрес непросроченным — сервер сам перевыпустит его под капотом.
 *  - `direct` — сервер отдаёт прямую ссылку, телефон качает у Google. Трафик через VPS не идёт
 *    вообще, но работает только если 403 не прилетает. Включать осознанно, проверив.
 */
object ZiziResolve {

    /** Адрес твоего сервера: `147.45.166.244:8080` или `http://host:8080`. Пусто = выключено. */
    @Volatile
    var baseUrl: String = ""

    /** Токен из установщика. Без него сервер отвечает 401 — и это правильно. */
    @Volatile
    var token: String = ""

    /** true = `/stream` через сервер, false = прямая ссылка на googlevideo. */
    @Volatile
    var proxyStream: Boolean = true

    val configured: Boolean get() = baseUrl.isNotBlank()

    /**
     * Прямая ссылка живёт ~6 часов (`expire` в URL), но 90 минут — сознательный запас: истёкший
     * адрес в очереди выглядит как «трек сам свайпнулся», а это ровно та болезнь, из-за которой
     * затевалась вся 6.10. Прокси-адрес не истекает: за перевыпуск отвечает сервер.
     */
    private const val TTL_DIRECT = 90L * 60 * 1000
    private const val TTL_PROXY = 12L * 60 * 60 * 1000

    private fun base(): String {
        val raw = baseUrl.trim().trimEnd('/')
        return if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "http://$raw"
    }

    /** Хост без схемы — только для отчёта. */
    fun hostLabel(): String = base().removePrefix("https://").removePrefix("http://").substringBefore('/')

    private fun endpoint(path: String, videoId: String): String {
        val sb = StringBuilder(base()).append('/').append(path).append("?id=").append(videoId)
        if (token.isNotBlank()) sb.append("&token=").append(token)
        return sb.toString()
    }

    fun streamUrl(videoId: String): String = endpoint("stream", videoId)

    /**
     * Спрашивает у сервера поток. Бросает [CatalogException] — вызывающий обрабатывает её так же,
     * как отказ любого другого источника, и уходит на старую лестницу клиентов.
     */
    suspend fun resolve(videoId: String, quality: RemoteQuality): StreamInfo {
        val json = ZiziHttp.getJson(endpoint("resolve", videoId))
        val direct = json.optString("url", "")
        if (direct.isBlank()) {
            throw CatalogException(
                CatalogException.Reason.PROTOCOL,
                "резолвер ответил без url: " + json.optString("detail", "поле url пустое")
            )
        }
        val rawMime = json.optString("mime", "webm")
        val mime = if (rawMime.contains('/')) rawMime else "audio/$rawMime"
        val abr = json.optDouble("abr", 0.0).toInt().let { if (it > 0) it else quality.targetKbps }
        val cached = json.optBoolean("cached", false)

        return if (proxyStream) {
            StreamInfo(
                url = streamUrl(videoId),
                mimeType = mime,
                bitrateKbps = abr,
                ttlMs = TTL_PROXY,
                // Прокси не проверяет UA — байты уже наши.
                userAgent = null,
                client = "ZiziResolve /stream" + if (cached) " (кэш сервера)" else ""
            )
        } else {
            StreamInfo(
                url = direct,
                mimeType = mime,
                bitrateKbps = abr,
                ttlMs = TTL_DIRECT,
                userAgent = null,
                client = "ZiziResolve direct" + if (cached) " (кэш сервера)" else ""
            )
        }
    }

    /** Строка для «Полной диагностики потока». Ничего не бросает — это отчёт, а не тракт. */
    suspend fun report(videoId: String, quality: RemoteQuality): String {
        val info = try {
            resolve(videoId, quality)
        } catch (e: CatalogException) {
            return "отказ ${e.reason}: ${e.message}"
        } catch (e: Throwable) {
            return "сбой ${e.javaClass.simpleName}: ${e.message}"
        }
        // Резолв — половина дела. Вторая половина: отдаются ли байты. Два байта, как в probeStream.
        val bytes = ZiziHttp.probeStream(info.url, info.userAgent)
        return "OK · ${info.client} · ${info.mimeType} · ${info.bitrateKbps} кбит/с · байты: $bytes"
    }

    /** Живой ли сервис вообще. Отдельно от резолва: сервер может стоять, а yt-dlp падать. */
    suspend fun health(): String = try {
        val json = ZiziHttp.getJson(base() + "/health")
        if (json.optBoolean("ok", false)) "сервер жив, кэш: ${json.optInt("cache", 0)} трек(ов)"
        else "сервер ответил, но не ok: $json"
    } catch (e: CatalogException) {
        "нет связи с сервером: ${e.reason} ${e.message}"
    } catch (e: Throwable) {
        "сбой ${e.javaClass.simpleName}: ${e.message}"
    }
}
