package app.ziziplayer.ui

import androidx.compose.runtime.Immutable
import android.app.Application
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import androidx.media3.common.util.UnstableApi
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.ZiziHttp
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteQuality
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.playback.ResolvedStreams
import app.ziziplayer.playback.StreamCache
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.Progress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch

enum class LibraryFilter { TRACKS, FAVORITES, PLAYLISTS, FOLDERS }

@Immutable
data class FolderInfo(val name: String, val count: Int)

/** One-off message for the snackbar (used by "removed from the app" + undo). */
data class UiMessage(val text: String, val actionLabel: String? = null, val action: (() -> Unit)? = null)

/**
 * Library state ONLY. Playback position deliberately lives in a separate flow: in v3 everything
 * was one object, so the 4 Hz position tick rebuilt this state, re-sorted 450 tracks on the main
 * thread and recomposed every row of the list. That was the real source of the lag.
 */
@Immutable
data class LibraryUiState(
    val loading: Boolean = true,
    val scanning: Boolean = false,
    val tracks: List<TrackEntity> = emptyList(),
    val visible: List<TrackEntity> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val playlistCounts: Map<Long, Int> = emptyMap(),
    val folders: List<FolderInfo> = emptyList(),
    val hiddenCount: Int = 0,
    val settings: UserSettings = UserSettings(),
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylist: PlaylistEntity? = null,
    val openFolder: String? = null
) {
    val isDrilledIn: Boolean get() = openPlaylist != null || openFolder != null
}

private data class Selection(
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylistId: Long? = null,
    val openFolder: String? = null
)

private data class LibrarySources(
    val tracks: List<TrackEntity>,
    val favorites: Set<String>,
    val hidden: Set<String>,
    val playlists: List<PlaylistEntity>,
    val counts: Map<Long, Int>
)

private data class LibraryContext(
    val stats: Map<String, PlayStatEntity>,
    val settings: UserSettings,
    val selection: Selection,
    val playlistTracks: List<TrackEntity>,
    val scanning: Boolean
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: MusicRepository = (application as ZiziApplication).repository
    private val player: PlayerController = (application as ZiziApplication).playerController

    private val selection = MutableStateFlow(Selection())
    private val scanning = MutableStateFlow(false)

    /**
     * Scan progress is exposed as its own flow and deliberately kept **out** of [LibraryUiState].
     *
     * It ticks every 25 files. Folding it into the library state would push the whole pipeline -
     * filter, search, folder counting, a full sort of the library - through `Dispatchers.Default`
     * dozens of times per scan and hand Compose a brand new list each time. That is exactly the
     * mistake v3 made with the playback position, and it is what made the list stutter.
     *
     * A `StateFlow` also conflates by nature, so the four worker threads reporting progress cannot
     * outrun the UI.
     */
    private val _scanProgress = MutableStateFlow<ScanProgress?>(null)
    val scanProgress: StateFlow<ScanProgress?> = _scanProgress.asStateFlow()
    private val _messages = Channel<UiMessage>(Channel.BUFFERED)
    val messages: Flow<UiMessage> = _messages.receiveAsFlow()

    private val sources = combine(
        repo.tracks, repo.favoriteIds, repo.hiddenIds, repo.playlists, repo.playlistCounts
    ) { tracks, favorites, hidden, playlists, counts ->
        LibrarySources(tracks, favorites, hidden, playlists, counts)
    }

    private val openPlaylistTracks = selection
        .map { it.openPlaylistId }
        .distinctUntilChanged()
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observePlaylistTracks(id) }

    private val libraryContext = combine(
        repo.stats, repo.settings, selection, openPlaylistTracks, scanning
    ) { stats, settings, sel, playlistTracks, isScanning ->
        LibraryContext(stats, settings, sel, playlistTracks, isScanning)
    }

    /** Everything heavy (filter, search, sort, folder counting) happens off the main thread. */
    val library: StateFlow<LibraryUiState> = combine(sources, libraryContext) { source, ctx ->
        build(source, ctx)
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibraryUiState())

    val playback: StateFlow<PlaybackState> = player.state
    val progress: StateFlow<Progress> = player.progress

    /**
     * repo.allTracks, not repo.tracks.
     *
     * A remote track that is playing but not saved is deliberately absent from the library list, so
     * resolving the current id against that list would leave the mini player and the full player
     * blank for exactly the tracks the search screen just started. Same reason for the queue below.
     */
    val currentTrack: StateFlow<TrackEntity?> = combine(
        repo.allTracks, player.state.map { it.currentTrackId }.distinctUntilChanged()
    ) { tracks, id -> if (id == null) null else tracks.firstOrNull { it.id == id } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val queue: StateFlow<List<TrackEntity>> = combine(
        repo.allTracks, player.state.map { it.queueIds }.distinctUntilChanged()
    ) { tracks, ids ->
        if (ids.isEmpty()) emptyList() else {
            val byId = HashMap<String, TrackEntity>(tracks.size)
            tracks.forEach { byId[it.id] = it }
            ids.mapNotNull { byId[it] }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _fx = MutableStateFlow(TrackFxEntity("", 1f, 1f, 0))
    val fx: StateFlow<TrackFxEntity> = _fx

    private var lastRegisteredPlay: String? = null
    private var scanJob: Job? = null

    init {
        launchScan { withScan { repo.rescan(it) } }
        // FX are per track: load them the moment the track changes and push them to the player.
        viewModelScope.launch {
            player.state.map { it.currentTrackId }.distinctUntilChanged().collect { id ->
                if (id == null) return@collect
                val saved = repo.fx(id)
                _fx.value = saved
                player.setPlayback(saved.speed, saved.pitch, saved.reverb)
                if (lastRegisteredPlay != id) { lastRegisteredPlay = id; repo.registerPlay(id) }
            }
        }
        viewModelScope.launch {
            repo.settings.map { it.skipSilence }.distinctUntilChanged().collect { player.setSkipSilence(it) }
        }
        // Resume where the user stopped, without autoplay.
        //
        // THE "TRACK RESTARTS FROM THE BEGINNING" BUG.
        // The playback session outlives the Activity, but this ViewModel is recreated every time
        // the Activity is (screen off, rotation, coming back after a while in another app). v4 then
        // rebuilt the queue on top of a session that was happily playing, rewinding it to whatever
        // position had been saved earlier. Waiting for the connection and bailing out when a queue
        // already exists means the running session is never touched.
        viewModelScope.launch {
            player.awaitConnected()
            if (player.hasQueue()) return@launch
            val lastId = repo.lastTrackId() ?: return@launch
            val tracks = withTimeoutOrNull(20_000) { repo.tracks.first { it.isNotEmpty() } } ?: return@launch
            if (player.hasQueue()) return@launch
            val hidden = repo.hiddenIds.first()
            val list = tracks.filterNot { hidden.contains(it.id) }
            val index = list.indexOfFirst { it.id == lastId }
            if (index >= 0) player.setQueue(list, index, play = false, startPositionMs = repo.lastPositionMs())
        }
        // Backup only. The service persists the position every four seconds and on every state
        // change, which is what keeps it correct while the screen is off and the UI is dead.
        viewModelScope.launch {
            while (true) {
                delay(5_000)
                val state = player.state.value
                if (!state.isPlaying) continue
                val id = state.currentTrackId ?: continue
                repo.saveLastPosition(id, player.progress.value.positionMs)
            }
        }
    }

    /**
     * lowercase() allocates a brand new String on every call. v4 called it up to four times per
     * track for every keystroke and on every sort, which is tens of thousands of allocations per
     * typed character on a 450 track library - the search felt sticky and the GC churned. The keys
     * are computed once per track. build() always runs on the same background dispatcher, so a
     * plain HashMap needs no synchronisation.
     */
    private class SearchKeys(val title: String, val artist: String)
    private val searchKeys = HashMap<String, SearchKeys>()
    private fun keysOf(track: TrackEntity): SearchKeys =
        searchKeys.getOrPut(track.id) { SearchKeys(track.title.lowercase(), track.artist.lowercase()) }

    // Folder counts only change when the library itself changes, not on every keystroke.
    private var foldersForTracks: List<TrackEntity>? = null
    private var foldersForHidden: Set<String>? = null
    private var foldersCache: List<FolderInfo> = emptyList()

    private fun build(source: LibrarySources, ctx: LibraryContext): LibraryUiState {
        val sel = ctx.selection
        val available = if (source.hidden.isEmpty()) source.tracks
        else source.tracks.filterNot { source.hidden.contains(it.id) }

        if (searchKeys.size > available.size * 2) searchKeys.clear()

        val folders = if (foldersForTracks === source.tracks && foldersForHidden === source.hidden) {
            foldersCache
        } else {
            available
                .groupingBy { it.sourceFolder }
                .eachCount()
                .map { FolderInfo(it.key, it.value) }
                .sortedWith(compareByDescending<FolderInfo> { it.count }.thenBy { it.name.lowercase() })
                .also {
                    foldersForTracks = source.tracks
                    foldersForHidden = source.hidden
                    foldersCache = it
                }
        }

        val openPlaylist = source.playlists.firstOrNull { it.id == sel.openPlaylistId }
        val base = when {
            openPlaylist != null -> ctx.playlistTracks.filterNot { source.hidden.contains(it.id) }
            sel.openFolder != null -> available.filter { it.sourceFolder == sel.openFolder }
            sel.filter == LibraryFilter.FAVORITES -> available.filter { source.favorites.contains(it.id) }
            else -> available
        }

        val searched = if (sel.query.isBlank()) base else {
            val needle = sel.query.trim().lowercase()
            base.filter { track ->
                val keys = keysOf(track)
                keys.title.contains(needle) || keys.artist.contains(needle)
            }
        }

        // A playlist keeps its manual order; everything else follows the chosen sort mode.
        val sorted = if (openPlaylist != null) searched else when (ctx.settings.sortMode) {
            SortMode.TITLE -> searched.sortedBy { keysOf(it).title }
            SortMode.ARTIST -> searched.sortedWith(compareBy({ keysOf(it).artist }, { keysOf(it).title }))
            SortMode.DURATION -> searched.sortedByDescending { it.durationMs }
            SortMode.RECENT -> searched.sortedByDescending { it.dateAdded }
            SortMode.PLAYS -> searched.sortedWith(
                compareByDescending<TrackEntity> { ctx.stats[it.id]?.playCount ?: 0 }
                    .thenByDescending { ctx.stats[it.id]?.lastPlayedAt ?: 0L }
                    .thenBy { keysOf(it).title }
            )
        }

        return LibraryUiState(
            loading = false,
            scanning = ctx.scanning,
            tracks = available,
            visible = sorted,
            favoriteIds = source.favorites,
            playlists = source.playlists,
            playlistCounts = source.counts,
            folders = folders,
            hiddenCount = source.hidden.size,
            settings = ctx.settings,
            filter = sel.filter,
            query = sel.query,
            searchOpen = sel.searchOpen,
            openPlaylist = openPlaylist,
            openFolder = sel.openFolder
        )
    }

    // ---------------- navigation ----------------

    fun setFilter(filter: LibraryFilter) = selection.update {
        it.copy(filter = filter, openPlaylistId = null, openFolder = null)
    }
    fun setQuery(query: String) = selection.update { it.copy(query = query) }
    fun setSearchOpen(open: Boolean) = selection.update { it.copy(searchOpen = open, query = if (open) it.query else "") }
    fun openPlaylist(id: Long) = selection.update { it.copy(openPlaylistId = id, openFolder = null) }
    fun openFolder(name: String) = selection.update { it.copy(openFolder = name, openPlaylistId = null) }

    /** Single back entry point, so the system side-swipe never quits the app by accident. */
    fun handleBack(): Boolean {
        val state = library.value
        return when {
            state.openPlaylist != null -> { selection.update { it.copy(openPlaylistId = null) }; true }
            state.openFolder != null -> { selection.update { it.copy(openFolder = null) }; true }
            state.searchOpen -> { setSearchOpen(false); true }
            state.filter != LibraryFilter.TRACKS -> { setFilter(LibraryFilter.TRACKS); true }
            else -> false
        }
    }

    // ---------------- playback ----------------

    fun play(track: TrackEntity, list: List<TrackEntity>? = null) {
        val source = list ?: library.value.visible.ifEmpty { library.value.tracks }
        val index = source.indexOfFirst { it.id == track.id }
        if (index < 0) player.setQueue(listOf(track), 0) else player.setQueue(source, index)
    }

    fun shuffleAll() {
        val source = library.value.visible.ifEmpty { library.value.tracks }
        if (source.isEmpty()) return
        val shuffled = source.shuffled()
        player.setQueue(shuffled, 0)
    }

    fun playPause() = player.playPause()
    fun next() = player.next()
    fun previous() = player.previous()
    fun seekTo(positionMs: Long) = player.seekTo(positionMs)
    fun seekToIndex(index: Int) = player.seekToIndex(index)
    fun toggleShuffle() = player.toggleShuffle()
    fun cycleRepeat() = player.cycleRepeat()
    fun setSleepTimer(minutes: Int?) = player.setSleepTimer(minutes)

    fun setFx(speed: Float, pitch: Float, reverb: Int) {
        val id = playback.value.currentTrackId ?: return
        val fx = TrackFxEntity(id, speed, pitch, reverb)
        _fx.value = fx
        player.setPlayback(speed, pitch, reverb)
        viewModelScope.launch { repo.saveFx(fx) }
    }

    fun resetFx() = setFx(1f, 1f, 0)

    suspend fun loadFx(id: String): TrackFxEntity = repo.fx(id)

    fun saveFx(id: String, speed: Float, pitch: Float, reverb: Int) {
        val fx = TrackFxEntity(id, speed, pitch, reverb)
        if (id == playback.value.currentTrackId) {
            _fx.value = fx
            player.setPlayback(speed, pitch, reverb)
        }
        viewModelScope.launch { repo.saveFx(fx) }
    }

    // ---------------- library actions ----------------

    fun toggleFavorite(track: TrackEntity) {
        val isFavorite = library.value.favoriteIds.contains(track.id)
        viewModelScope.launch { repo.toggleFavorite(track.id, isFavorite) }
    }

    /**
     * "Remove from the app": the file stays on the phone, the track just leaves the library and
     * the running queue. Reversible from the snackbar, and from Settings for older removals.
     */
    fun removeFromApp(track: TrackEntity) {
        viewModelScope.launch {
            repo.hideTrack(track.id)
            player.removeFromQueue(track.id)
            _messages.trySend(
                UiMessage(
                    text = "Убрано из приложения: ${track.title}",
                    actionLabel = "Вернуть",
                    action = { restoreTrack(track.id) }
                )
            )
        }
    }

    fun restoreTrack(id: String) { viewModelScope.launch { repo.unhideTrack(id) } }

    fun restoreAllHidden() {
        viewModelScope.launch {
            repo.clearHidden()
            _messages.trySend(UiMessage("Скрытые треки возвращены"))
        }
    }

    /** Real file deletion, kept separate and always behind the system confirmation dialog. */
    fun requestDeleteFile(track: TrackEntity, onReady: (IntentSender?) -> Unit) {
        viewModelScope.launch {
            val sender = runCatching { repo.requestFileDeletion(track) }.getOrNull()
            if (sender == null) {
                // Below Android 11 the file is deleted right away, nothing to confirm.
                onFileDeleted(track)
                onReady(null)
            } else onReady(sender)
        }
    }

    fun onFileDeleted(track: TrackEntity) {
        viewModelScope.launch {
            player.removeFromQueue(track.id)
            repo.forgetTrack(track.id)
            _messages.trySend(UiMessage("Файл удалён: ${track.title}"))
        }
    }

    fun addFolder(uri: Uri) {
        launchScan { withScan { repo.addFolder(uri, it) } }
    }

    fun removeFolder(uri: String) {
        launchScan { withScan { repo.removeFolder(uri, it) } }
    }

    fun rescan() {
        launchScan {
            withScan { repo.rescan(it) }
            _messages.trySend(UiMessage("Библиотека обновлена"))
        }
    }

    /**
     * Serialises scans, latest request wins.
     *
     * Two passes must never run at once: they write the same rows, compete for the same four tag
     * readers, and whichever finishes first clears the badge while the other is still going. But
     * *dropping* the newer request is equally wrong, and in one specific case it would be a visible
     * bug: the startup scan begins before the storage permission is granted, so it finds nothing,
     * and the `rescan()` fired the moment the user taps "Allow" is exactly the one that matters. If
     * that were ignored, the library would stay empty until a manual refresh.
     *
     * So the previous scan is cancelled and **joined** - awaited to a full stop - before the new one
     * touches the database. Cancellation is honoured per directory and per file now, so this returns
     * promptly instead of waiting out the whole pass.
     */
    private fun launchScan(block: suspend () -> Unit) {
        val previous = scanJob
        scanJob = viewModelScope.launch {
            previous?.cancelAndJoin()
            block()
        }
    }

    /**
     * Single owner of the scanning flags. Every entry point used to duplicate the set/clear pair,
     * and one of them forgetting the clear on an early return would have left the badge on screen
     * forever. `finally` also covers cancellation - the scan is now cancellable, so that is a real
     * path, not a theoretical one.
     */
    private suspend fun withScan(block: suspend ((ScanProgress) -> Unit) -> Unit) {
        scanning.value = true
        try {
            block { progress -> _scanProgress.value = progress }
        } catch (cancelled: CancellationException) {
            // Never swallowed: swallowing it leaves the parent scope believing the child is alive.
            throw cancelled
        } catch (_: Throwable) {
            // Any other failure must not take the ViewModel down; the library stays as it was.
        } finally {
            _scanProgress.value = null
            scanning.value = false
        }
    }

    fun createPlaylist(name: String, tracks: List<TrackEntity> = emptyList()) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val id = repo.createPlaylist(name.trim())
            tracks.forEach { repo.addToPlaylist(id, it.id) }
        }
    }

    fun addToPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repo.addToPlaylist(playlistId, trackId)
            _messages.trySend(UiMessage("Добавлено в плейлист"))
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch { repo.removeFromPlaylist(playlistId, trackId) }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repo.deletePlaylist(id)
            selection.update { if (it.openPlaylistId == id) it.copy(openPlaylistId = null) else it }
        }
    }

    fun renamePlaylist(id: Long, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { repo.renamePlaylist(id, name.trim()) }
    }

    fun saveQueueAsPlaylist(name: String) = createPlaylist(name, queue.value)

    fun setTheme(theme: AppTheme) { viewModelScope.launch { repo.setTheme(theme) } }
    fun setDynamicAccent(value: Boolean) { viewModelScope.launch { repo.setDynamicAccent(value) } }
    fun setSkipSilence(value: Boolean) { viewModelScope.launch { repo.setSkipSilence(value) } }
    fun setSortMode(mode: SortMode) { viewModelScope.launch { repo.setSortMode(mode) } }

    // ---------------------------------------------------------------- network catalogue (6.6.0)

    fun setCatalogProvider(id: String) { viewModelScope.launch { repo.setCatalogProvider(id) } }
    fun setWifiOnly(value: Boolean) { viewModelScope.launch { repo.setWifiOnly(value) } }
    fun setStreamCacheEnabled(value: Boolean) { viewModelScope.launch { repo.setStreamCacheEnabled(value) } }

    // ---- own resolver (6.10.0) ----
    fun setResolverUrl(value: String) { viewModelScope.launch { repo.setResolverUrl(value) } }
    fun setResolverToken(value: String) { viewModelScope.launch { repo.setResolverToken(value) } }
    fun setResolverProxy(value: Boolean) { viewModelScope.launch { repo.setResolverProxy(value) } }

    /** 6.11.0: unlocks the technical rows. See the version row in SettingsSheet. */
    fun setDevMode(value: Boolean) { viewModelScope.launch { repo.setDevMode(value) } }

    private val _resolverStatus = MutableStateFlow<String?>(null)
    val resolverStatus: StateFlow<String?> = _resolverStatus.asStateFlow()

    /**
     * Asks the server whether it is alive, separately from resolving a track.
     *
     * The two failures are different and must not be confused: an unreachable server is a network
     * or firewall question (port 8080), while a server that answers /health and fails /resolve is
     * yt-dlp or the IP reputation. One row per question.
     */
    fun probeResolver() {
        viewModelScope.launch {
            if (!app.ziziplayer.data.remote.ZiziResolve.configured) {
                _resolverStatus.value = "Адрес сервера не задан"
                return@launch
            }
            _resolverStatus.value = "Проверяю сервер…"
            _resolverStatus.value = app.ziziplayer.data.remote.ZiziResolve.health()
        }
    }

    fun cycleStreamQuality() {
        viewModelScope.launch {
            val next = when (repo.settings.first().streamQuality) {
                RemoteQuality.LOW -> RemoteQuality.NORMAL
                RemoteQuality.NORMAL -> RemoteQuality.HIGH
                RemoteQuality.HIGH -> RemoteQuality.LOW
            }
            repo.setStreamQuality(next)
        }
    }

    @OptIn(UnstableApi::class)
    /**
     * What the last resolved stream actually was, or null before anything has played.
     *
     * Read straight from [ResolvedStreams] rather than mirrored into a StateFlow: it is a
     * diagnostic that is only ever looked at while the settings sheet is open, and giving it a flow
     * would mean the resolver publishing to the UI from the Media3 loader thread for no reader.
     */
    fun streamStatusLabel(): String? = ResolvedStreams.lastLabel

    fun streamCacheLabel(): String {
        val bytes = StreamCache.sizeBytes()
        return if (bytes <= 0) "Кэш пуст" else "Занято %.1f МБ".format(bytes / 1024.0 / 1024.0)
    }

    @OptIn(UnstableApi::class)
    fun clearStreamCache() { viewModelScope.launch(Dispatchers.IO) { StreamCache.clear() } }

    /**
     * Starts playback of remote tracks.
     *
     * The rows are written to the database first, and only then handed to the player: the queue,
     * the mini player and the play counters all work by resolving a track id, so a track that is
     * playing has to exist as a row. It is written unsaved - listening is not keeping.
     */
    fun playRemote(tracks: List<RemoteTrack>, index: Int = 0) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            val entities = repo.rememberRemote(tracks)
            if (entities.isEmpty()) return@launch
            player.setQueue(entities, index.coerceIn(entities.indices))
        }
    }

    fun setRemoteSaved(trackId: String, saved: Boolean) {
        viewModelScope.launch { repo.setRemoteSaved(trackId, saved) }
    }

    /**
     * "+ в медиатеку" from a search result.
     *
     * Two steps, in this order, and the order is the whole function: a result the user has only
     * looked at may not have a row yet, and `setRemoteSaved` is an UPDATE - on a missing row it
     * succeeds, changes nothing, and the plus silently stays a plus. Writing the row first makes
     * the operation work on a track the user never played.
     */
    fun saveRemote(track: RemoteTrack) {
        viewModelScope.launch {
            repo.rememberRemote(listOf(track))
            repo.setRemoteSaved(track.trackId, true)
            _messages.send(
                UiMessage(
                    text = "«${track.title}» в медиатеке",
                    actionLabel = "Отменить",
                    action = { setRemoteSaved(track.trackId, false) }
                )
            )
        }
    }

    /** Saves a whole album or playlist. One database pass, one message. */
    fun saveRemoteAll(tracks: List<RemoteTrack>) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            repo.rememberRemote(tracks)
            tracks.forEach { repo.setRemoteSaved(it.trackId, true) }
            _messages.send(UiMessage("Добавлено: ${tracks.size}"))
        }
    }

    fun clearPlaybackError() = player.clearError()

    /**
     * The connection probe behind "Проверить подключение" in settings.
     *
     * It exists because this feature depends on somebody else's private API, which will break, and
     * when it does the only question that matters is WHICH layer broke. So the probe reports the
     * failure reason verbatim - the provider, the CatalogException reason, the message - instead of
     * a friendly "что-то пошло не так" that carries no information to whoever has to fix it.
     */
    private val _catalogProbe = MutableStateFlow<String?>(null)
    val catalogProbe: StateFlow<String?> = _catalogProbe.asStateFlow()
    private var probeResults: List<RemoteTrack> = emptyList()

    /**
     * 6.7.0 asked for ONE page here and reported its size, which is why the probe said "20 шт." on
     * a catalogue that was in fact paging correctly - and said exactly the same thing on a
     * catalogue whose paging was broken. A probe that cannot tell those two apart is decoration.
     *
     * Three pages, following the token the way the results screen does, so this row now exercises
     * the pagination itself: the count, the number of pages walked, and whether there is more after
     * them are three separate facts and all three are printed.
     */
    fun probeCatalog(query: String = "phonk") {
        viewModelScope.launch {
            _catalogProbe.value = "Проверяю…"
            val preferred = repo.settings.first().catalogProvider
            try {
                val collected = ArrayList<RemoteTrack>()
                var provider = preferred
                var token: String? = null
                var pages = 0
                while (pages < 3) {
                    val cursor = token
                    val page = repo.catalogs.withFallback(preferred) { catalog ->
                        catalog.search(query, RemoteKind.TRACK, cursor) to catalog.id
                    }
                    provider = page.second
                    collected.addAll(page.first.items.filterIsInstance<RemoteItem.Song>().map { it.track })
                    pages++
                    token = page.first.nextToken
                    if (token == null) break
                }
                probeResults = collected.distinctBy { it.trackId }
                val first = probeResults.firstOrNull()
                val more = if (token == null) "конец" else "есть ещё"
                _catalogProbe.value = when {
                    first == null -> "[$provider] ответ разобран, но треков 0"
                    else -> "[$provider] ${probeResults.size} шт. за $pages стр. ($more). " +
                        "Первый: ${first.title} — ${first.artist}"
                }
            } catch (e: CatalogException) {
                probeResults = emptyList()
                _catalogProbe.value = "Отказ ${e.reason}: ${e.message}"
            } catch (e: Throwable) {
                probeResults = emptyList()
                _catalogProbe.value = "Сбой ${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }

    /** Plays what the probe found: the only way to exercise resolve -> cache -> decoder end to end. */
    fun playProbeResults() = playRemote(probeResults, 0)

    /**
     * The probe that 6.6.0 was missing, and the reason YouTube looked "broken" with no error.
     *
     * [probeCatalog] proves the catalogue parses. It says nothing about whether the URL it produced
     * can actually be fetched - and that is exactly where YouTube failed: search worked, resolve
     * worked, and the GET came back 403 because the app clients now require attestation. From
     * inside the player that is indistinguishable from a corrupt file, so the queue skipped, which
     * is what "сам свайпает треки" was.
     *
     * This resolves one real track and asks the CDN for two bytes of it. The answer names the
     * internal client that succeeded and the HTTP code, so a failure is one line long and points at
     * exactly one layer instead of three.
     */
    fun probeStream() {
        viewModelScope.launch {
            val track = probeResults.firstOrNull()
            if (track == null) {
                _catalogProbe.value = "Сначала «Проверить подключение»"
                return@launch
            }
            _catalogProbe.value = "Резолвлю поток…"
            try {
                val quality = repo.settings.first().streamQuality
                val catalog = repo.catalogs.byId(track.provider)
                    ?: throw CatalogException(CatalogException.Reason.PROTOCOL, "Источник не найден")
                val info = catalog.resolveStream(track.remoteId, quality)
                val verdict = ZiziHttp.probeStream(info.url, info.userAgent)
                _catalogProbe.value = buildString {
                    append("[").append(track.provider)
                    info.client?.let { append(" · ").append(it) }
                    append("] ").append(info.bitrateKbps).append(" кбит/с ").append(info.mimeType)
                    append("\n").append(verdict)
                }
            } catch (e: CatalogException) {
                _catalogProbe.value = "Резолв отказал ${e.reason}: ${e.message}"
            } catch (e: Throwable) {
                _catalogProbe.value = "Сбой резолва ${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }

    /**
     * THE ROW THAT SHOULD HAVE EXISTED IN 6.8.0.
     *
     * [probeStream] prints its verdict into a settings subtitle. A subtitle is two lines wide, so
     * the sentence that mattered - `ANDROID_VR: Войдите, чтобы подтвердить, что вы не робот` - was
     * cut off mid-word, and the verdicts of the four other clients were never shown at all. A
     * diagnostic you cannot read is not a diagnostic, and it cost us a whole release.
     *
     * This one runs [RemoteCatalog.streamReport] - every client, every status, verbatim - and puts
     * the result in a dialog with a copy button. It is deliberately slow and deliberately loud.
     */
    private val _streamReport = MutableStateFlow<List<String>?>(null)
    val streamReport: StateFlow<List<String>?> = _streamReport.asStateFlow()
    private val _reportRunning = MutableStateFlow(false)
    val reportRunning: StateFlow<Boolean> = _reportRunning.asStateFlow()

    fun runStreamReport() {
        if (_reportRunning.value) return
        viewModelScope.launch {
            _reportRunning.value = true
            try {
                val track = probeResults.firstOrNull()
                if (track == null) {
                    // The report needs a real track id, so it takes one the same way the user would:
                    // it searches. That also means the row works on a fresh install, without having
                    // to remember to tap "Проверить подключение" first.
                    _streamReport.value = listOf(
                        "Нет трека для проверки.",
                        "Сначала нажми «Проверить подключение» - отчёту нужен реальный id."
                    )
                    return@launch
                }
                val quality = repo.settings.first().streamQuality
                val catalog = repo.catalogs.byId(track.provider)
                if (catalog == null) {
                    _streamReport.value = listOf("Источник ${track.provider} не найден")
                    return@launch
                }
                val header = listOf(
                    "ZiziPlayer 6.9.1 · отчёт по потоку",
                    "провайдер: ${track.provider} · трек: ${track.title} — ${track.artist}",
                    "качество: ${quality.targetKbps} кбит/с",
                    "—"
                )
                _streamReport.value = header + catalog.streamReport(track.remoteId, quality)
            } catch (e: CatalogException) {
                _streamReport.value = listOf("Отчёт оборвался: ${e.reason} · ${e.message}")
            } catch (e: Throwable) {
                _streamReport.value = listOf("Отчёт оборвался: ${e.javaClass.simpleName} · ${e.message}")
            } finally {
                _reportRunning.value = false
            }
        }
    }

    fun dismissStreamReport() { _streamReport.value = null }

    fun setUiActive(active: Boolean) = player.setUiActive(active)

    /** Called from Activity.onStop, while the scope is still alive. */
    fun savePosition() {
        val id = playback.value.currentTrackId ?: return
        val position = progress.value.positionMs
        viewModelScope.launch { repo.saveLastPosition(id, position) }
    }
}
