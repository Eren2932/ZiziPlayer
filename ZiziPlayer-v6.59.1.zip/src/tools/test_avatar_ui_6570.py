"""Source wiring + checker regression tests. NOT a substitute for Kotlin/Compose execution."""
from pathlib import Path
import re
import unittest
import check_imports
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'app/src/main/java/app/ziziplayer'
def read(name): return (SRC/name).read_text()
def missing(text):
    body = check_imports.strip_noise(text)
    imports = re.findall(r'^import\s+([\w.]+\*?)', body, re.M)
    exact = {x.rsplit('.', 1)[-1] for x in imports if not x.endswith('.*')}
    star = {x[:-2] for x in imports if x.endswith('.*')}
    return {x[1] for x in check_imports.library_problems('fixture.kt', body, exact, star, set(), set())}
class Avatar6570(unittest.TestCase):
    def test_actual_search_has_all_four_inset_imports(self):
        text = read('ui/screens/SearchScreen.kt')
        self.assertFalse(missing(text))
        for name in ('WindowInsets', 'statusBars', 'statusBarsPadding', 'windowInsetsTopHeight'):
            line = f'import androidx.compose.foundation.layout.{name}\n'
            self.assertIn(line, text)
            self.assertIn(name, missing(text.replace(line, '')))
        # The original broken version must fail, including lower-case extension names.
        for name in ('WindowInsets', 'statusBars', 'statusBarsPadding', 'windowInsetsTopHeight'):
            text = text.replace(f'import androidx.compose.foundation.layout.{name}\n', '')
        self.assertEqual(missing(text), {'WindowInsets','statusBars','statusBarsPadding','windowInsetsTopHeight'})
    def test_inset_checker_accepts_wildcard_and_ignores_comments(self):
        self.assertFalse(missing('import androidx.compose.foundation.layout.*\nfun f() { Modifier.statusBarsPadding().windowInsetsTopHeight(WindowInsets.statusBars) }'))
        self.assertFalse(missing('// Modifier.statusBarsPadding()\nval note = "WindowInsets.statusBars"'))
    def test_no_old_popup_or_photo_dialog_and_single_pipeline(self):
        screen = read('ui/screens/AccountScreen.kt'); edit = read('ui/screens/AccountEditScreen.kt')
        self.assertNotIn('DropdownMenu', screen)
        self.assertIn('if (menu) ZiziSheetScaffold', screen)
        self.assertNotIn('if (choosing) AlertDialog', edit)
        self.assertNotIn('ActivityResultContracts.OpenDocument', edit)
        for needle in ('AvatarGallerySheet(', 'AvatarCropScreen(', 'AvatarRemovalSheet(', 'AccountPhotoPreview('):
            self.assertIn(needle, edit)
        self.assertNotIn('suspend fun load(', read('account/AvatarImage.kt'))
        all_code = '\n'.join(p.read_text() for p in SRC.rglob('*.kt'))
        self.assertEqual(all_code.count('AvatarImage.encodeCrop('), 1)
    def test_gallery_is_lazy_paged_and_bounded(self):
        ui=read('ui/screens/AvatarGallerySheet.kt'); data=read('account/AvatarGallery.kt')
        for needle in ('LazyVerticalGrid(', 'key = { it.id }', 'onLongClick = { preview = photo.uri }',
                       'scrollable = false, partiallyExpandable = false', 'key(session.intValue)', 'lifecycle.removeObserver(observer)',
                       'ActivityResultContracts.PickVisualMedia.ImageOnly'):
            self.assertIn(needle,ui)
        for needle in ('PAGE_SIZE = 90','QUERY_ARG_LIMIT','_ID} < ?', 'Semaphore(4)', '8 * 1024 * 1024', 'cursor.use', 'Dispatchers.IO'):
            self.assertIn(needle,data)
        self.assertNotIn('GlobalScope',ui+data)
        self.assertNotIn('registerContentObserver',data)
    def test_export_and_preview_share_math_and_no_upload_until_save(self):
        image=read('account/AvatarImage.kt'); crop=read('ui/screens/AvatarCropScreen.kt')
        self.assertIn('AvatarCropGeometry.crop(',image);self.assertIn('AvatarCropGeometry.crop(',crop)
        for s in ('Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)', '300 * 1024', '20 * 1024 * 1024', 'setTargetColorSpace', 'Dispatchers.Default'):
            self.assertIn(s,image)
        self.assertNotIn('AccountProfileStore',crop)
        self.assertNotIn('pointerInput(pose',crop)
        self.assertIn('currentUpdate(gesturePose)',crop)
        edit=read('ui/screens/AccountEditScreen.kt')
        self.assertIn('store.save(id, draftName, draftAvatar, revision)',edit)
        self.assertIn('BackHandler { close() }',edit)
        self.assertLess(edit.index('working = true'),edit.index('scope.launch'))
    def test_default_menus_keep_single_anchor(self):
        s=read('ui/screens/Sheets.kt')
        self.assertIn('partiallyExpandable: Boolean = false',s)
        self.assertIn('skipPartiallyExpanded = !partiallyExpandable',s)
    def test_permissions_are_declared_not_requested_at_startup(self):
        manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
        for n in ('READ_MEDIA_IMAGES','READ_MEDIA_VISUAL_USER_SELECTED'): self.assertIn(n,manifest)
        self.assertNotIn('AvatarGallery.permissions',read('MainActivity.kt'))
if __name__=='__main__': unittest.main(verbosity=2)
