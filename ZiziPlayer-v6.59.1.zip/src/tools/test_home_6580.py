#!/usr/bin/env python3
"""v6.58.0: шапка и сетка главной по референсу 1080 px, автообновление подборок без кнопки,
резкое открытие галереи выбора фото. Офлайн, без Gradle и без Android SDK."""
import io, os, re, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def read(path):
    with io.open(os.path.join(ROOT, path), encoding='utf-8') as f:
        return f.read()

GEOMETRY = 'app/src/main/java/app/ziziplayer/ui/HomeHeaderGeometry.java'
POLICY = 'app/src/main/java/app/ziziplayer/ui/HomeFeedRefreshPolicy.java'
HOME = 'app/src/main/java/app/ziziplayer/ui/screens/HomeScreen.kt'
FEED = 'app/src/main/java/app/ziziplayer/ui/HomeRecommendations.kt'
SHEET = 'app/src/main/java/app/ziziplayer/ui/screens/AvatarGallerySheet.kt'
SHEETS = 'app/src/main/java/app/ziziplayer/ui/screens/Sheets.kt'
GALLERY = 'app/src/main/java/app/ziziplayer/account/AvatarGallery.kt'
CHECKS = 'app/src/test/java/app/ziziplayer/ui/HomeHeader6580Checks.java'

def constant(name):
    m = re.search(r'%s\s*=\s*([0-9.]+)f' % name, read(GEOMETRY))
    assert m, name
    return float(m.group(1))

def scale(viewport, px):
    return px * max(1.0, viewport) / 1080.0


class ReferenceGeometry(unittest.TestCase):
    """Измерено попиксельно на референсе 1080 x 2400; арифметика повторена здесь независимо."""

    def test_measured_constants_match_the_reference_screenshot(self):
        for name, value in (('INSET', 46), ('AVATAR', 92), ('AVATAR_GAP', 35), ('CHIP_HEIGHT', 92),
                            ('CHIP_GAP', 24), ('CHIP_PADDING', 48), ('CHIP_TEXT', 36),
                            ('HEADER_TOP', 26), ('HEADER_BOTTOM', 47), ('TILE_HEIGHT', 139),
                            ('TILE_GAP', 24), ('TILE_RADIUS', 12), ('TILE_TEXT', 38),
                            ('TILE_TEXT_GAP', 24), ('TILE_ICON', 56), ('SECTION_TEXT', 56)):
            self.assertEqual(constant(name), float(value), name)
        # Аватарка и пилюля вкладки одной высоты: иначе шапка «съезжает» по вертикали.
        self.assertEqual(constant('AVATAR'), constant('CHIP_HEIGHT'))

    def test_scaling_is_pixel_exact_on_the_reference_width(self):
        for viewport in (320.0, 360.0, 393.0, 411.0, 480.0, 600.0, 840.0):
            for px in (46.0, 92.0, 139.0):
                back = scale(viewport, px) * 1080.0 / viewport
                self.assertAlmostEqual(back, px, places=4)

    def test_two_tiles_and_one_gap_fill_the_row_exactly(self):
        for viewport in (320.0, 360.0, 393.0, 411.0, 480.0, 600.0, 840.0):
            inset = scale(viewport, constant('INSET'))
            gap = scale(viewport, constant('TILE_GAP'))
            tile = (viewport - 2 * inset - gap) / 2
            self.assertAlmostEqual(2 * tile + gap + 2 * inset, viewport, places=4)
            self.assertGreater(tile, 0)
        inset = scale(1080.0, 46.0)
        self.assertAlmostEqual((1080.0 - 2 * inset - scale(1080.0, 24.0)) / 2, 482.0, places=4)

    def test_tile_colour_is_the_reference_overlay(self):
        # #2A2A2A на #121212: 42 = 18 + a * (255 - 18).
        self.assertIn('24f / 237f', read(GEOMETRY))
        self.assertAlmostEqual(24.0 / 237.0, (42 - 18) / (255 - 18), places=6)

    def test_grid_is_four_rows_of_two_like_the_reference(self):
        self.assertIn('TILES = 8', read(GEOMETRY))
        self.assertIn('HomeHeaderGeometry.TILES - 3', read(HOME))

    def test_java_checks_have_a_junit_entry(self):
        self.assertIn('HomeHeader6580Checks.main', read('app/src/test/java/app/ziziplayer/ui/HomeHeader6580Test.java'))
        self.assertIn('PASS: ', read(CHECKS))


class HeaderAndTiles(unittest.TestCase):
    def test_header_takes_every_size_from_the_measured_geometry(self):
        home = read(HOME)
        for token in ('HomeHeaderGeometry.AVATAR)', 'HomeHeaderGeometry.AVATAR_GAP)',
                      'HomeHeaderGeometry.CHIP_HEIGHT)', 'HomeHeaderGeometry.CHIP_GAP)',
                      'HomeHeaderGeometry.CHIP_PADDING)', 'HomeHeaderGeometry.CHIP_TEXT)',
                      'HomeHeaderGeometry.HEADER_TOP)', 'HomeHeaderGeometry.HEADER_BOTTOM)',
                      'profile.avatar, avatarSize)', 'heightIn(min = chipHeight)'):
            self.assertIn(token, home, token)
        # Прежние подобранные на глаз размеры шапки не возвращаются.
        for token in ('(30.7f * accountScale()).dp', 'Modifier.size(48.dp)', 'fontSize = 14.sp,\n',
                      'horizontal = 16.dp, vertical = 12.dp'):
            self.assertNotIn(token, home, token)

    def test_wave_is_a_grid_tile_and_not_a_banner(self):
        home = read(HOME)
        self.assertNotIn('HomeWaveCard', home)
        self.assertNotIn('item("wave")', home)
        self.assertIn('private fun HomeTile(', home)
        self.assertIn('HomeCollectionKind.WAVE.title', home)
        self.assertIn('home.openCollection(HomeCollectionKind.WAVE)', home)
        # Запуск волны остался: маленькая кнопка внутри обложки плитки.
        self.assertIn('onClickLabel = if (wavePlaying) "Пауза" else "Слушать мою волну"', home)
        self.assertIn('ZiziIcons.CollectionPlayFilled', home)
        # Плитка не режет подпись при крупном системном шрифте.
        self.assertIn('heightIn(min = height)', home)
        self.assertIn('LocalDensity.current.fontScale', home)

    def test_home_owns_its_vertical_rhythm(self):
        self.assertIn('Arrangement.spacedBy(if (historyOpen) 14.dp else 0.dp)', read(HOME))


class SilentRefresh(unittest.TestCase):
    def test_home_has_no_refresh_button_left(self):
        home = read(HOME)
        self.assertNotIn('Text("Обновить"', home)
        self.assertNotIn('Обновляем подборки', home)
        self.assertNotIn('"Обновить", color', home)
        self.assertNotIn('home.refreshFeed(force = true)', home)
        self.assertIn('Подбираем музыку под твой вкус…', home)

    def test_refresh_arithmetic_lives_in_one_place(self):
        policy = read(POLICY)
        for token in ('STALE_MS = 30L * 60_000L', 'ATTEMPT_GAP_MS = 15_000L',
                      'MAX_RETRIES = 3', 'MAX_RETRY_MS = 300_000L',
                      'static long retryDelayMs', 'static boolean shouldLoad', 'static boolean stale'):
            self.assertIn(token, policy, token)

    def test_retry_ladder_is_bounded(self):
        delays = [15_000 * 3 ** (n - 1) for n in (1, 2, 3)]
        self.assertEqual(delays, [15_000, 45_000, 135_000])
        self.assertTrue(all(d <= 300_000 for d in delays))

    def test_feed_retries_itself_inside_the_screen_scope(self):
        feed = read(FEED)
        for token in ('HomeFeedRefreshPolicy.shouldLoad(now, _state.value.loadedAt, lastAttempt, force)',
                      'private fun scheduleRetry(snapshot: HomeState, epoch: Int)',
                      'HomeFeedRefreshPolicy.canRetry(attempt + 1)',
                      'retry?.cancel(); retry = null',
                      'delay(wait + 250L)'):
            self.assertIn(token, feed, token)
        # Автоповтор обязан умирать вместе с экраном: никакой фоновой работы.
        self.assertEqual(feed.count('retry?.cancel()'), 4)
        self.assertNotIn('Попробуй обновить', feed)


class GalleryOpensSharp(unittest.TestCase):
    def test_sheet_exposes_a_settled_signal(self):
        self.assertIn('internal val LocalSheetSettled = staticCompositionLocalOf { true }',
                      read('app/src/main/java/app/ziziplayer/ui/screens/TrackMenuComponents.kt'))
        sheets = read(SHEETS)
        self.assertIn('val settled = sheetState.currentValue != SheetValue.Hidden', sheets)
        self.assertIn('LocalSheetSettled provides settled', sheets)

    def test_heavy_work_waits_for_the_open_animation(self):
        sheet = read(SHEET)
        self.assertIn('partiallyExpandable = false', sheet)
        self.assertIn('val settled = LocalSheetSettled.current', sheet)
        self.assertIn('GalleryGrid(active = settled', sheet)
        self.assertIn('if (!active) return@LaunchedEffect', sheet)
        self.assertIn('LaunchedEffect(request, active)', sheet)

    def test_session_restarts_only_on_a_real_access_change(self):
        sheet = read(SHEET)
        self.assertNotIn('generation', sheet)
        self.assertIn('key(session.intValue)', sheet)
        self.assertIn('AvatarGallery.signature(context)', sheet)
        self.assertIn('now == AvatarGallery.LIMITED', sheet)
        gallery = read(GALLERY)
        for token in ('const val NONE = "none"', 'const val LIMITED = "limited"',
                      'const val FULL = "full"', 'fun signature(context: Context): String'):
            self.assertIn(token, gallery, token)

    def test_list_does_not_jump_while_paging(self):
        sheet = read(SHEET)
        self.assertIn('Box(Modifier.fillMaxWidth().height(3.dp))', sheet)
        self.assertNotIn('photos.size - 12', sheet)
        self.assertIn('photos.size - 24', sheet)
        self.assertIn('Semaphore(4)', read(GALLERY))


if __name__ == '__main__':
    unittest.main(verbosity=2)
