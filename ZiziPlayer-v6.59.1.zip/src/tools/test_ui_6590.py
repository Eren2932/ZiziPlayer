"""Source contracts + execution of shipping Java math. No Android runtime claims."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/ziziplayer'

def read(path): return (SRC / path).read_text()

class Ui6590(unittest.TestCase):
    def test_production_geometry(self):
        with tempfile.TemporaryDirectory() as output:
            sources = [SRC / 'ui/SearchHeaderGeometry.java',
                       ROOT / 'app/src/test/java/app/ziziplayer/ui/SearchHeader6590Checks.java']
            subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17',
                            '-d', output, *map(str, sources)], check=True, capture_output=True)
            result = subprocess.run(['java', '-cp', output, 'app.ziziplayer.ui.SearchHeader6590Checks'],
                                    check=True, capture_output=True, text=True)
            self.assertIn('production geometry assertions', result.stdout)
            print(result.stdout.strip())

    def test_scroll_and_layout_use_measured_shipping_math(self):
        s = read('ui/components/CollapsingSearchHeader.kt')
        for token in ['SearchHeaderGeometry.nextOffset', 'SearchHeaderGeometry.visibleHeight',
                      'state.titleHeight = it.height', 'state.sectionHeight = it.height',
                      'available.y < 0f', 'available.y > 0f', 'onPostScroll', 'clipToBounds',
                      'titleVisible + entryBox.height + sectionVisible', 'clearAndSetSemantics',
                      'Saver<SearchHeaderState, Float>']:
            self.assertIn(token, s)
        self.assertNotIn('tween(', s)
        self.assertIn('Modifier.nestedScroll(hubHeader.connection)', read('ui/screens/SearchScreen.kt'))

    def test_one_unconditional_outer_tint(self):
        s = read('MainActivity.kt')
        self.assertEqual(s.count('StatusBarTint('), 1)
        host = s[:s.index('override fun onNewIntent')]
        self.assertGreater(host.index('StatusBarTint('), host.index('LibraryStorageScreen('))
        self.assertGreater(host.index('StatusBarTint('), host.index('AccountAuthScreen('))
        self.assertNotIn('if (mounted && !eqOpen && !profileEdit)', s)

    def test_real_identity_and_snapshot_previews(self):
        s = read('ui/screens/LibraryStorageScreen.kt')
        for text in ['it.userId == account.userId', 'AccountAvatar(', 'RemoteArtwork(',
                     'LibraryPreview.from(snapshots.capture())', 'state.cloudPreview', 'confirmedPreview',
                     'filesOpen', 'detailsOpen', 'preview.savedTracks', 'preview.favorites', 'preview.playlists',
                     'Сетевые обложки', 'локальные фото', 'Профиль и аватар хранятся отдельно']:
            self.assertIn(text, s)
        p = read('library/LibraryPreview.kt')
        for text in ['getJSONArray("tracks")', 'getJSONArray("favorites")', 'getJSONArray("playlists")',
                     'getJSONArray("favorite_shadow")', 'covers.size < 8', 'minOf(lists.length(), 4)', 'startsWith("https://")']:
            self.assertIn(text, p)

    def test_import_validated_before_confirmation(self):
        s = read('ui/screens/LibraryStorageScreen.kt')
        self.assertLess(s.index('snapshots.previewFile(raw)'), s.index('confirm = "import"'))
        p = read('library/LibrarySnapshot.kt').split('suspend fun previewFile')[1].split('/** Transactional')[0]
        self.assertIn('privacyCheck()', p)
        self.assertIn('validate(value)', p)
        self.assertNotIn('restore(', p)

    def test_cloud_confirmation_cannot_restore_different_snapshot(self):
        s = read('library/LibrarySync.kt').split('suspend fun useCloud')[1].split('private suspend fun flushInside')[0]
        self.assertLess(s.index('LibrarySnapshot.hash(document) != expectedHash'), s.index('snapshots.restore('))
        self.assertIn('AccountApiException(409', s)
        self.assertIn('sync.useCloud(expectedHash = hash)', read('ui/screens/LibraryStorageScreen.kt'))

    def test_restore_still_transactional_and_backed_up(self):
        s = read('library/LibrarySnapshot.kt')
        self.assertLess(s.index('safety.finishWrite'), s.index('DELETE FROM'))
        self.assertIn('room.withTransaction', s)
        self.assertIn('MAX_BYTES = 8 * 1024 * 1024', s)
        self.assertIn('db.insert(table, SQLiteDatabase.CONFLICT_ABORT', s)

if __name__ == '__main__': unittest.main(verbosity=2)
