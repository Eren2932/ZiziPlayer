"""Run the same production Java geometry and checks as the Gradle JUnit test."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as output:
    sources = [ROOT/'app/src/main/java/app/ziziplayer/account/AvatarCropGeometry.java',
               ROOT/'app/src/test/java/app/ziziplayer/account/AvatarCropGeometryChecks.java']
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-source', '17', '-target', '17', '-d', output, *map(str, sources)], check=True)
    subprocess.run(['java', '-cp', output, 'app.ziziplayer.account.AvatarCropGeometryChecks'], check=True)
