#!/usr/bin/env python3
"""Execute production Java. Source contracts are explicitly separate from Android execution."""
from pathlib import Path
import subprocess
import tempfile
import re
import sqlite3
import unittest
ROOT = Path(__file__).resolve().parents[1]
J = ROOT/'app/src/main/java/app/ziziplayer'

def read(p): return (J/p).read_text()

class Home6490Contracts(unittest.TestCase):
    def test_production_ranking(self):
        with tempfile.TemporaryDirectory() as out:
            files = [J/'ui/HomeFeedPolicy.java', ROOT/'app/src/test/java/app/ziziplayer/ui/Home6490Checks.java']
            subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-d',out,*map(str,files)],check=True)
            subprocess.run(['java','-cp',out,'app.ziziplayer.ui.Home6490Checks'],check=True)

    def test_bounded_snapshot_executes_real_sql(self):
        source = read('data/ListeningDao.kt')
        sql = re.search(r'@Query\("([^"\n]+)"\)\s+suspend fun recommendationSnapshot',source).group(1)
        db = sqlite3.connect(':memory:'); self.addCleanup(db.close)
        db.execute('CREATE TABLE listening_sessions(sessionId TEXT, startedAt INTEGER)')
        db.executemany('INSERT INTO listening_sessions VALUES(?,?)', [(str(i),i) for i in range(12000)])
        rows = db.execute(sql).fetchall()
        self.assertEqual(len(rows),500); self.assertEqual(rows[0],('11999',11999)); self.assertEqual(rows[-1],('11500',11500))

    def test_network_bounds_and_shared_runtime(self):
        s = read('ui/HomeRecommendations.kt')
        for t in ['job?.isActive == true', 'HomeFeedRefreshPolicy.shouldLoad(now, _state.value.loadedAt, lastAttempt, force)',
             'builder.seeds.take(3)',
                  'withTimeoutOrNull(45_000L)', 'withTimeoutOrNull(8_000L)', 'app.playerController.state.first { !it.isLoadingAudio }',
                  'epoch == generation', 'snapshot.hiddenIds == hidden.value', 'snapshot.vaultFolders == app.repository.vault.state.value.folders']:
            self.assertIn(t,s)
        for t in ['resolveStream(', 'OkHttpClient(', 'addListener(', 'while (true)', 'observeSessions()']:
            self.assertNotIn(t,s)
        self.assertIn('catch (e: CancellationException) { throw e }',s)
        self.assertIn('stopNetwork = true',s)

    def test_ui_lifecycle_and_shared_artwork(self):
        s = read('ui/screens/HomeScreen.kt'); feed = read('ui/screens/HomeFeedUi.kt')
        self.assertIn('ON_STOP) home.leaveHome()',s)
        self.assertIn('lifecycle.removeObserver(observer)',s)
        self.assertIn('rawFeed.folders == gate.folders && rawFeed.hidden == hidden',s)
        self.assertIn('if (previous != null && previous != privacy) privacyChanged()',read('ui/HomeViewModel.kt'))
        self.assertIn('cards.chunked(3)',feed)
        self.assertIn('rememberUrlArtwork(entry.remote.artworkUrl, 480)',feed)
        self.assertIn('HomeFeedPolicy.card(viewport)',feed)
        self.assertIn('contentType = shelf.layout.name',feed)
        self.assertNotIn('MiniPlayer(',s)

    def test_lyrics_screen_owns_only_its_view_flag(self):
        s = read('ui/screens/LyricsScreen.kt')
        for t in ['DisposableEffect(lyricsView)', 'val previousKeepScreenOn = lyricsView.keepScreenOn',
                  'lyricsView.keepScreenOn = true', 'onDispose { lyricsView.keepScreenOn = previousKeepScreenOn }']:
            self.assertIn(t,s)
        self.assertNotIn('WakeLock',s)
        self.assertNotIn('keepScreenOn',read('ui/screens/LyricsPreview.kt'))

    def test_persistence_pagination_and_back(self):
        s = read('ui/HomeViewModel.kt')
        self.assertLess(s.index('music.rememberRemote(allowed.filter'),s.index('action(current)'))
        for t in ['.take(200)', 'page.nextToken?.takeIf { it != previous }', 'collectionEpoch++',
                  'if (epoch == collectionEpoch) _collectionBusy.value = false', '_catalogTracks.value = emptyList()']:
            self.assertIn(t,s)
        self.assertNotIn('music.rememberRemote(',read('ui/HomeRecommendations.kt'))

    def test_honest_labels_and_visual_duplicates(self):
        s = read('ui/HomeRecommendations.kt')
        for t in ['не твой персональный топ','Найдено в каталоге по исполнителю',
                  'exposures[canonical(it)] ?: 0) < 2','shownGroups.add',
                  'HomeFeedPolicy.normalize(it.artist) == HomeFeedPolicy.normalize(artist)']:
            self.assertIn(t,s)
        self.assertNotIn('Новые релизы',s) # no release-date field: do not invent freshness

if __name__ == '__main__': unittest.main(verbosity=2)
