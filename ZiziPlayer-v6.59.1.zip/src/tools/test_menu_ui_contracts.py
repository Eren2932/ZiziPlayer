#!/usr/bin/env python3
"""Offline source contracts only. They do not execute Kotlin, render Compose or measure FPS."""
from pathlib import Path
import os
import re
import unittest

ROOT = Path(os.environ.get('ZIZI_TEST_ROOT', Path(__file__).resolve().parents[1]))
APP = ROOT / 'app/src/main/java/app/ziziplayer'

def source(path):
    return (APP / path).read_text()

def section(text, start, end):
    return text.split(start, 1)[1].split(end, 1)[0]

class MenuUiContracts(unittest.TestCase):
    def test_no_file_lookup_during_menu_composition(self):
        s = section(source('ui/screens/Sheets.kt'), 'fun TrackMenuSheet(', 'fun TrackInfoSheet(')
        self.assertIn('withContext(Dispatchers.IO) { OfflineStore.whereIs', s)
        self.assertIn('remember(track.id, downloaded)', s)
        self.assertIn('LaunchedEffect(ctx, track.id, downloaded)', s)
        self.assertIn('throw cancelled', s)

    def test_hosts_do_not_query_disk_inline(self):
        for name in ('LibraryScreen.kt', 'PlayerScreen.kt'):
            s = source('ui/screens/' + name)
            self.assertNotIn('vm.downloadStatus(', s)
            self.assertIn('rememberMenuDownloadState(', s)
            self.assertIn('downloadChecking = menuDownload.checking', s)

    def test_cold_status_is_background_and_live_progress_is_immediate(self):
        s = source('ui/screens/MenuDownloadState.kt')
        self.assertIn('if (live != null) return MenuDownloadState(live)', s)
        self.assertIn('withContext(Dispatchers.IO) { vm.downloadStatus(track) }', s)
        self.assertIn('remember(vm, track.id, track.uri)', s)
        self.assertIn('checking = stored == null', s)
        self.assertIn('throw cancelled', s)

    def test_player_checks_storage_only_for_open_sheets(self):
        self.assertIn('track.takeIf { showMenu || showInfo }', source('ui/screens/PlayerScreen.kt'))

    def test_native_exit_finishes_before_callback(self):
        s = section(source('ui/screens/Sheets.kt'), 'internal fun ZiziSheetScaffold(', '/**\n * Строка «Скачать»')
        self.assertIn('if (!exiting)', s)
        self.assertLess(s.index('exiting = true'), s.index('scope.launch'))
        self.assertLess(s.index('sheetState.hide()'), s.index('action()'))
        self.assertLess(s.index('onDismiss()'), s.index('action()'))
        self.assertIn('finally {', s)
        self.assertIn('exiting = false', s)
        self.assertNotIn('delay(', s)
        self.assertIn('partiallyExpandable: Boolean = false', s)
        self.assertIn('skipPartiallyExpanded = !partiallyExpandable', s)

    def test_scroll_ownership_is_exclusive(self):
        s = section(source('ui/screens/Sheets.kt'), 'fun TrackMenuSheet(', 'fun TrackInfoSheet(')
        self.assertIn('scrollable = scrollHeader', s)
        self.assertIn('if (scrollHeader) Modifier else Modifier.weight(1f).verticalScroll(actionScroll)', s)
        self.assertIn('Modifier.fillMaxHeight(0.9f)', s)

    def test_navigation_keeps_all_track_actions(self):
        s = section(source('ui/screens/Sheets.kt'), 'fun TrackMenuSheet(', 'fun TrackInfoSheet(')
        for action in ('onAddToPlaylist', 'onFx', 'onShare', 'onPlayNext', 'onAddToQueue', 'onQueue',
                       'onGoToArtist', 'onSleep', 'onInfo', 'onRemoveFromPlaylist', 'onHide', 'onDeleteFile'):
            self.assertIn('exit(' + action + ')', s)
        for action in ('onDownload', 'onCancelDownload', 'onRemoveDownload'):
            self.assertGreaterEqual(s.count(action), 2)
        self.assertIn('onFolders?.let', s)

    def test_favorite_updates_without_closing_menu(self):
        for name in ('LibraryScreen.kt', 'PlayerScreen.kt'):
            self.assertIn('onToggleFavorite = { vm.toggleFavorite(track) }', source('ui/screens/' + name))
        s = source('ui/screens/TrackMenuComponents.kt')
        self.assertIn('if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart', s)
        self.assertIn('stateDescription = stateLabel', s)

    def test_library_sleep_is_not_a_noop(self):
        s = source('ui/screens/LibraryScreen.kt')
        self.assertIn('onSleep = { menuTrack = null; showSleepTimer = true }', s)
        self.assertIn('SleepSheet(playback.sleepMinutesLeft', s)
        self.assertIn('vm.setSleepTimer(it)', s)

    def test_library_speed_does_not_start_another_track(self):
        s = source('ui/screens/LibraryScreen.kt')
        self.assertIn('onFx = { menuTrack = null; fxTrack = track }', s)
        self.assertIn('FxSheet(vm, track,', s)
        self.assertNotIn('onFx = { menuTrack = null; vm.play(', s)

    def test_idle_menu_has_no_infinite_animation(self):
        s = section(source('ui/screens/Sheets.kt'), 'private fun rememberDownloadSweep(', 'private enum class DownloadPhase')
        self.assertLess(s.index('if (!indeterminate) return'), s.index('rememberInfiniteTransition('))
        menu = section(source('ui/screens/Sheets.kt'), 'private fun DownloadMenuItem(', '/** No spinner')
        self.assertNotIn('rememberInfiniteTransition', menu)
        self.assertIn('phase == DownloadPhase.QUEUED', menu)
        self.assertIn('phase == DownloadPhase.WORKING && percent < 0', menu)
        self.assertIn('startAngle = sweepStart.value', menu)

    def test_download_row_reserves_caption_and_can_grow_for_font_scale(self):
        s = section(source('ui/screens/Sheets.kt'), 'private fun DownloadMenuItem(', '/** No spinner')
        self.assertIn('.heightIn(min = 64.dp)', s)
        self.assertIn('text = caption.orEmpty()', s)
        self.assertIn('minLines = 1, maxLines = 1', s)

    def test_real_file_path_is_not_invented(self):
        s = source('ui/screens/Sheets.kt')
        self.assertIn('where?.let { "Файл: $it" } ?: "Копия на устройстве"', s)
        self.assertNotIn('"Файл: " + (where ?: OfflineStoreLabel)', s)

    def test_show_file_lookup_is_off_main(self):
        s = section(source('ui/screens/Sheets.kt'), 'private suspend fun showDownloadedFile(', 'private fun openDownloadsFolder(')
        self.assertIn('withContext(Dispatchers.IO) { OfflineStore.viewIntent', s)
        self.assertIn('throw cancelled', s)

    def test_quick_actions_adapt_width_and_font_scale(self):
        s = source('ui/screens/TrackMenuComponents.kt')
        self.assertIn('LocalDensity.current.fontScale', s)
        self.assertIn('MenuPresentation.quickColumns(maxWidth.value, fontScale)', s)
        self.assertIn('Modifier.weight(1f)', s)
        self.assertIn('.heightIn(min = 78.dp)', s)
        self.assertIn('role = Role.Button', s)

    def test_press_animation_does_not_change_measurement(self):
        s = source('ui/screens/TrackMenuComponents.kt')
        self.assertIn('graphicsLayer { scaleX = scale.value; scaleY = scale.value }', s)
        self.assertNotIn('animateContentSize', s)
        self.assertNotIn('rememberInfiniteTransition', s)
        self.assertNotIn('blur(', s)

    def test_header_does_not_fabricate_duration(self):
        s = source('ui/screens/TrackMenuComponents.kt')
        self.assertIn('if (track.durationMs > 0)', s)
        self.assertIn('contentDescription = "Закрыть меню трека"', s)
        self.assertIn('maxLines = 2, overflow = TextOverflow.Ellipsis', s)

    def test_pin_is_vector_badge_not_tiny_subtitle_decoration(self):
        s = section(source('ui/screens/LibraryScreen.kt'), 'private fun LibraryCardTile(', '/**\n * Обложка карточки.')
        self.assertIn('Modifier.align(Alignment.TopStart)', s)
        self.assertIn('contentDescription = "Закреплено"', s)
        self.assertIn('LibraryCardSubtitle(card, 11.5.sp, showPin = false)', s)
        self.assertIn('!showPin && card.pinned -> card.meta', s)
        self.assertIn('Modifier.size(16.dp)', s)

    def test_new_ui_uses_only_custom_icons(self):
        s = source('ui/screens/TrackMenuComponents.kt')
        self.assertNotRegex(s, r'(?<!Zizi)Icons\.(Default|Filled|Outlined|Rounded)')
        self.assertIn('val Pin: ImageVector by lazy', source('ui/components/ZiziIcons.kt'))

    def test_ui_regressions_are_connected_to_existing_ci(self):
        preflight = (ROOT / 'tools/check_selftest.py').read_text()
        for name in ('test_live_ui_contracts.py', 'test_menu_ui_contracts.py'):
            self.assertIn(name, preflight)
        workflow = (ROOT / '.github/workflows/build.yml').read_text()
        self.assertIn('python3 tools/check_selftest.py', workflow)

    def test_prior_ci_fixes_preserved(self):
        self.assertIn('import androidx.compose.foundation.layout.heightIn', source('ui/screens/SearchScreen.kt'))
        self.assertIn('except (FileNotFoundError, ProcessLookupError)', (ROOT / 'server/tools/test_stage2.py').read_text())

    def test_file_deletion_still_requires_confirmation_in_both_hosts(self):
        for name in ('LibraryScreen.kt', 'PlayerScreen.kt'):
            s = source('ui/screens/' + name)
            self.assertIn('confirmDelete = track', s)
            self.assertIn('title = "Удалить файл?"', s)
            self.assertIn('if (!track.isRemote)', source('ui/screens/Sheets.kt'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
