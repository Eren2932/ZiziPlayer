"""Source wiring checks; explicitly NOT Android execution."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/app/ziziplayer'
class LibraryContracts(unittest.TestCase):
    def test_actual_policy_is_used(self):
        s=(SRC/'library/LibrarySync.kt').read_text()
        for text in ['LibrarySyncPolicy.choose(', 'LibrarySyncPolicy.pauseEmptyUpload(', 'expectedHash = hash', 'prefs.edit().putString("owner", accountKey)', 'api.librarySave(id, revision, local)']:
            self.assertIn(text,s)
    def test_safety_precedes_mutation(self):
        s=(SRC/'library/LibrarySnapshot.kt').read_text()
        self.assertLess(s.index('validate(value)'),s.index('DELETE FROM'))
        self.assertLess(s.index('safety.finishWrite(stream)'),s.index('DELETE FROM'))
        for text in ['room.withTransaction', 'SQLiteDatabase.CONFLICT_ABORT', 'expectedHash != null && hash(before) != expectedHash', 'folders.isNotEmpty()', 'MAX_BYTES = 8 * 1024 * 1024']:
            self.assertIn(text,s)
        self.assertNotIn('clearAllTables',s)
    def test_imports_do_not_autoupload(self):
        s=(SRC/'library/LibrarySync.kt').read_text().split('suspend fun importFile',1)[1]
        self.assertLess(s.index('enabled = false'),s.index('snapshots.restore(raw)'))
        self.assertLess(s.index('remove("owner")'),s.index('snapshots.restore(raw)'))
    def test_missing_local_metadata_survives_rescan(self):
        self.assertIn("uri NOT LIKE 'zizi-missing:%'",(SRC/'data/MusicDao.kt').read_text())
    def test_api_is_bounded_and_account_checked(self):
        s=(SRC/'account/AccountRepository.kt').read_text()
        for text in ['libraryIdentity(expectedUid)', 'user.getString("id") != expectedUid', 'source.request(limit + 1)', '9L * 1024 * 1024 else 32768L']:
            self.assertIn(text,s)
    def test_first_frame_and_foreground_sync(self):
        s=(SRC/'MainActivity.kt').read_text()
        for text in ['if (account.showWelcome)', 'LaunchedEffect(account.userId)', 'librarySync.connect(account.userId)', 'Lifecycle.State.STARTED', 'kotlinx.coroutines.delay(15_000)', 'librarySync.flush()']:
            self.assertIn(text,s)
    def test_ui_discloses_replacement_not_merge(self):
        s=(SRC/'ui/screens/LibraryStorageScreen.kt').read_text()
        for text in ['не объединены', 'Сохранено в облаке', 'аудиофайлы не удаляются', 'пока приложение открыто']:
            self.assertIn(text.lower(),s.lower())

class LibrarySyncStateContracts(unittest.TestCase):
    """Narrow source guard for the 6.59.0 build failure; NOT a Kotlin compiler."""
    def state_fields(self):
        import re
        source = (SRC/'library/LibrarySync.kt').read_text()
        declaration = source.split('data class LibrarySyncState(', 1)[1]
        return {name: (kind, default.strip()) for name, kind, default in re.findall(
            r'val\s+(\w+):\s*([\w?]+)\s*=\s*([^,\n]+)', declaration)}

    def test_error_is_nonnullable_and_empty_by_default(self):
        self.assertEqual(self.state_fields().get('error'), ('String', '""'))

    def test_preview_is_nullable_and_absent_by_default(self):
        self.assertEqual(self.state_fields().get('cloudPreview'), ('LibraryPreview?', 'null'))

    def test_cloud_hash_is_nullable_and_absent_by_default(self):
        # Empty string is not a safe default: the UI gates restoration with != null.
        self.assertEqual(self.state_fields().get('cloudHash'), ('String?', 'null'))

    def test_storage_screen_state_reads_are_declared(self):
        import re
        screen = (SRC/'ui/screens/LibraryStorageScreen.kt').read_text()
        used = set(re.findall(r'(?<![\w.])(?:state|result)\.(\w+)', screen))
        self.assertFalse(used - self.state_fields().keys(),
                         'Undeclared LibrarySyncState fields: ' + str(used - self.state_fields().keys()))

if __name__=='__main__':unittest.main(verbosity=2)
