package app.ziziplayer.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import app.ziziplayer.ui.components.ArtworkCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** What the settings sheet shows while a pass is running. */
data class EnrichProgress(
    val running: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val matched: Int = 0,
    val offline: Boolean = false
)

/**
 * Fills in what the files themselves do not say: artist, album and a cover, from three open
 * catalogues, cached in the database forever.
 *
 * Why this is a plain coroutine and not WorkManager
 * ------------------------------------------------
 * WorkManager buys deferred execution after the process dies, and costs a dependency I cannot
 * compile-check from my side plus a manifest provider. The resumability it provides is already in
 * the database here: every answer is committed the moment it arrives, and the candidate query is
 * "rows with no verdict yet". Killing the app mid-pass loses at most one in-flight request, and
 * the next launch continues exactly where it stopped. If we ever want it to run with the app
 * closed, that is the moment to add WorkManager - not before.
 *
 * The rules it obeys
 * ------------------
 *  - off by default. Nothing leaves the device until the user turns it on.
 *  - Wi-Fi only by default. Covers are ~50-120 KB each; 300 of them on mobile data without asking
 *    is not a feature, it is a bill.
 *  - never while a list is being scrolled ([ArtworkCache.isBusy]), same rule the cover prefetcher
 *    already follows. The finger always wins.
 *  - one track at a time, with a pause between them. This is a background nicety, not a race.
 *  - a final "no match" verdict is remembered, so a library of DJ edits is not re-queried forever.
 */
class MetadataEnricher(
    context: Context,
    private val dao: MusicDao,
    private val settingsStore: SettingsStore
) {
    private val app = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private val _progress = MutableStateFlow(EnrichProgress())
    val progress: StateFlow<EnrichProgress> = _progress.asStateFlow()

    /** Newly installed covers since the last UI nudge - batched, see [ArtworkCache.notifyChanged]. */
    private var pendingCovers = 0

    fun start(tracks: List<TrackEntity>, force: Boolean = false) {
        if (job?.isActive == true) return
        if (tracks.isEmpty()) return
        job = scope.launch { run(tracks, force) }
    }

    fun stop() {
        job?.cancel()
        job = null
        _progress.value = _progress.value.copy(running = false)
    }

    private suspend fun run(tracks: List<TrackEntity>, force: Boolean) {
        val settings = settingsStore.settings.first()
        if (!settings.enrichFromNet) { _progress.value = EnrichProgress(); return }
        if (!networkAllowed(settings.enrichOnWifiOnly)) {
            _progress.value = EnrichProgress(offline = true)
            return
        }

        val known = dao.allMeta().associateBy { it.trackId }
        val now = System.currentTimeMillis()
        val candidates = tracks.filter { track ->
            val meta = known[track.id]
            when {
                force -> true
                meta == null -> needsHelp(track)
                meta.state == META_MATCHED -> false
                meta.state == META_NO_MATCH -> false
                // Transient failure: exponential backoff, 4 attempts, then left alone until a
                // manual "Уточнить". 15 min, 1 h, 4 h, 16 h.
                else -> meta.attempts < 4 &&
                    now - meta.checkedAt > 900_000L * (1L shl (2 * meta.attempts).coerceAtMost(6))
            }
        }
        if (candidates.isEmpty()) { _progress.value = EnrichProgress(); return }

        _progress.value = EnrichProgress(running = true, total = candidates.size)
        var done = 0
        var matched = 0
        // Accepted answers, keyed by album. See [albumKey] and [adopt] for why this exists.
        val leaders = HashMap<String, TrackMetaEntity>()
        // Albums are asked about together, so the first file of a release pays for the whole one.
        // Sorting only reorders work that was going to happen anyway - it costs one sort of ~300
        // elements and saves entire round trips.
        val ordered = candidates.sortedBy { albumKey(it) ?: "\uffff" }
        for (track in ordered) {
            if (!currentCoroutineContext().isActive) break
            // The finger always wins - same contract as the cover prefetcher.
            while (ArtworkCache.isBusy()) {
                if (!currentCoroutineContext().isActive) break
                delay(200)
            }
            val key = albumKey(track)
            val leader = key?.let { leaders[it] }
            // Same release as a track we already resolved: reuse the answer, ask nobody.
            if (leader != null && adopt(track, leader)) {
                matched++
                done++
                _progress.value = _progress.value.copy(done = done, matched = matched)
                if (done % 8 == 0) flushCovers()
                // No request was made, so there is nothing to be polite about - but the artwork
                // cache was just written to, so yield rather than hammering straight on.
                delay(20)
                continue
            }
            if (!networkAllowed(settings.enrichOnWifiOnly)) {
                _progress.value = _progress.value.copy(running = false, offline = true)
                flushCovers()
                return
            }
            val accepted = runCatching { resolve(track, known[track.id]) }.getOrNull()
            if (accepted != null) {
                matched++
                if (key != null) leaders[key] = accepted
            }
            done++
            _progress.value = _progress.value.copy(done = done, matched = matched)
            if (done % 8 == 0) flushCovers()
            delay(350)
        }
        flushCovers()
        _progress.value = _progress.value.copy(running = false)
    }

    /**
     * The identity of a release, as claimed by the files themselves, or null when they claim
     * nothing usable.
     *
     * Only the LOCAL album and artist tags are used, never a fetched one, and both are normalised
     * through the same [TrackQuery.norm] the matcher uses. That restriction is the whole safety
     * argument: two files that carry the identical album tag are two files the tagger already
     * declared to be one release, so lending them one cover states nothing new. Grouping on a
     * FETCHED album instead would let one confident wrong guess spread across a dozen tracks.
     *
     * The artist is part of the key because "Greatest Hits", "Сборник" and "Unknown Album" are
     * album names thousands of unrelated files share.
     */
    private fun albumKey(track: TrackEntity): String? {
        val album = track.album.trim()
        if (album.isEmpty() || album.equals("<unknown>", ignoreCase = true)) return null
        val normalisedAlbum = TrackQuery.norm(album)
        // A one-character album tag is noise, not a release.
        if (normalisedAlbum.length < 2) return null
        val artist = if (isUnknownArtist(track.artist)) "" else TrackQuery.norm(track.artist)
        return "$normalisedAlbum|$artist"
    }

    /**
     * Gives a track the answer already accepted for another file of the same album, without a
     * single request.
     *
     * Returns false when there would be nothing to gain, and that return value matters: the caller
     * then falls through to a normal lookup instead of writing a verdict. Recording MATCHED for a
     * track that received nothing would make it permanently unaskable - the exact bug class this
     * whole table's `state` column exists to avoid.
     *
     * The title is never copied. A shared album means a shared cover and a shared artist; it does
     * not mean two files are the same recording.
     */
    private suspend fun adopt(track: TrackEntity, leader: TrackMetaEntity): Boolean {
        val gainsArtist = isUnknownArtist(track.artist) && !leader.artist.isNullOrBlank()
        val wantsCover = leader.coverUrl != null && ArtworkCache.hasNoArt(track)
        if (!gainsArtist && !wantsCover) return false

        var cover: String? = null
        if (wantsCover && ArtworkCache.cloneCover(leader.trackId, track.id)) {
            cover = leader.coverUrl
            pendingCovers++
        }
        // The clone can fail (the leader's file was pruned between the two tracks). If that leaves
        // the track with nothing at all, say nothing: let it be asked about normally later.
        if (cover == null && !gainsArtist) return false

        dao.upsertMeta(
            TrackMetaEntity(
                trackId = track.id,
                artist = leader.artist,
                title = null,
                album = leader.album,
                coverUrl = cover,
                source = leader.source,
                state = META_MATCHED,
                attempts = 0,
                // Deliberately one notch below the leader: this answer was inherited, not verified,
                // and a later manual "Уточнить" should be able to tell the two apart.
                score = (leader.score - 1).coerceAtLeast(TrackQuery.ACCEPT_SCORE),
                checkedAt = System.currentTimeMillis()
            )
        )
        return true
    }

    /**
     * Worth asking about? A file that already has both an artist and a cover has nothing to gain,
     * and every request that cannot improve anything is battery and bytes spent for nothing.
     */
    private fun needsHelp(track: TrackEntity): Boolean =
        isUnknownArtist(track.artist) || ArtworkCache.hasNoArt(track)

    private fun isUnknownArtist(artist: String): Boolean {
        val value = artist.trim().lowercase()
        return value.isEmpty() || value == "<unknown>" || value == "unknown" ||
            value == "неизвестный артист" || value == "unknown artist"
    }

    /**
     * One track, all providers, best answer wins.
     *
     * Returns the row it wrote when the answer was accepted, and null otherwise. It returns the
     * row rather than a boolean so the caller can reuse it for the rest of the album - see [adopt].
     */
    private suspend fun resolve(track: TrackEntity, previous: TrackMetaEntity?): TrackMetaEntity? {
        val asks = TrackQuery.asksFor(track)
        if (asks.isEmpty()) {
            // Nothing sensible to ask. Recorded as a final verdict so it is never asked again.
            dao.upsertMeta(
                TrackMetaEntity(
                    trackId = track.id,
                    state = META_NO_MATCH,
                    source = "",
                    checkedAt = System.currentTimeMillis()
                )
            )
            return null
        }

        var best: RemoteMatch? = null
        var bestScore = 0
        var transient = false

        outer@ for (ask in asks) {
            for (provider in PROVIDERS) {
                val results = try {
                    provider(ask)
                } catch (e: RemoteMeta.Transient) {
                    transient = true
                    continue
                } catch (e: Exception) {
                    continue
                }
                results.forEach { candidate ->
                    val score = TrackQuery.score(
                        ask = ask,
                        localDurationMs = track.durationMs,
                        candidateArtist = candidate.artist,
                        candidateTitle = candidate.title,
                        candidateDurationMs = candidate.durationMs
                    )
                    if (score > bestScore) { bestScore = score; best = candidate }
                }
                // A confident hit from the first provider ends the search: the other two would cost
                // three more requests to confirm what we already believe.
                if (bestScore >= 820) break@outer
            }
            if (bestScore >= TrackQuery.ACCEPT_SCORE) break
        }

        val winner = best
        if (winner == null || bestScore < TrackQuery.ACCEPT_SCORE) {
            dao.upsertMeta(
                TrackMetaEntity(
                    trackId = track.id,
                    // A network failure is NOT a "no match": keep it retryable, count the attempt.
                    state = if (transient) META_PENDING else META_NO_MATCH,
                    attempts = if (transient) (previous?.attempts ?: 0) + 1 else 0,
                    score = bestScore,
                    checkedAt = System.currentTimeMillis()
                )
            )
            return null
        }

        // The cover is downloaded straight into the artwork disk cache at both sizes the UI asks
        // for, so the normal load path finds it on its own and nothing in the pipeline had to learn
        // about the internet.
        var installed = false
        val coverUrl = winner.coverUrl
        if (coverUrl != null && ArtworkCache.hasNoArt(track)) {
            val bytes = runCatching { RemoteMeta.fetchImage(coverUrl) }.getOrNull()
            if (bytes != null) {
                installed = ArtworkCache.installRemoteCover(track.id, bytes)
                if (installed) pendingCovers++
            }
        }

        val row = TrackMetaEntity(
            trackId = track.id,
            artist = winner.artist,
            title = winner.title,
            album = winner.album,
            coverUrl = if (installed) coverUrl else null,
            source = winner.source,
            state = META_MATCHED,
            attempts = 0,
            score = bestScore,
            checkedAt = System.currentTimeMillis()
        )
        dao.upsertMeta(row)
        return row
    }

    /**
     * Manual "Уточнить" from the track menu. Clears any previous verdict and asks again, ignoring
     * the Wi-Fi preference - the user is standing there having explicitly asked for it.
     */
    suspend fun refreshOne(track: TrackEntity): Boolean {
        if (!hasNetwork()) return false
        ArtworkCache.forgetNoArt(track.id)
        val previous = dao.meta(track.id)
        val accepted = runCatching { resolve(track, previous?.copy(attempts = 0)) }.getOrNull()
        flushCovers()
        return accepted != null
    }

    /**
     * Free-text search across all three catalogues, for the manual picker.
     *
     * Unlike the automatic pass this asks EVERY provider and applies no threshold: the point of the
     * screen is that the machine already failed, so the human gets to see the weak answers too and
     * decide. Results are still scored, because sorting them by confidence is exactly the help a
     * human wants, and de-duplicated across providers - iTunes and Deezer describe the same single
     * often enough that an undeduplicated list looks broken.
     */
    suspend fun searchCatalog(query: String, durationMs: Long): List<RemoteMatch> {
        val text = query.trim()
        if (text.length < 2) return emptyList()
        // "Artist - Title" is how people type this, and how most of the library is named. Splitting
        // it lets the providers use their artist field instead of matching one long string.
        val parts = text.split(" - ", " – ", " — ", limit = 2)
        val ask = if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
            TrackQuery.Ask(parts[0].trim(), parts[1].trim(), loose = true)
        } else {
            TrackQuery.Ask(null, text, loose = true)
        }

        val seen = HashSet<String>()
        val out = ArrayList<RemoteMatch>(24)
        for (provider in PROVIDERS) {
            val results = try {
                provider(ask)
            } catch (_: Exception) {
                // One dead provider must not empty the list: the other two may well have the track.
                continue
            }
            for (candidate in results) {
                val fingerprint = TrackQuery.norm(candidate.artist) + "|" +
                    TrackQuery.norm(candidate.title) + "|" + TrackQuery.norm(candidate.album ?: "")
                if (!seen.add(fingerprint)) continue
                val score = TrackQuery.score(
                    ask = ask,
                    localDurationMs = durationMs,
                    candidateArtist = candidate.artist,
                    candidateTitle = candidate.title,
                    candidateDurationMs = candidate.durationMs
                )
                out.add(candidate.copy(score = score))
            }
        }
        // A cover is the main thing being picked here, so an entry that has none sorts below one
        // that does, even when its text matches slightly better.
        return out
            .sortedWith(compareByDescending<RemoteMatch> { it.coverUrl != null }.thenByDescending { it.score })
            .take(15)
    }

    /**
     * The user picked a candidate by hand. Accepted with no threshold and no argument.
     *
     * Written with score 1000 so nothing automatic ever overrules it, and the cover is fetched even
     * when the track already has one - replacing a wrong embedded cover is a legitimate reason to
     * open this screen. Cached lyrics are dropped because they were fetched for the old artist.
     */
    suspend fun applyMatch(track: TrackEntity, match: RemoteMatch): Boolean {
        val url = match.coverUrl
        var installed = false
        if (url != null) {
            val bytes = runCatching { RemoteMeta.fetchImage(url) }.getOrNull()
            if (bytes != null) {
                ArtworkCache.forgetNoArt(track.id)
                installed = ArtworkCache.installRemoteCover(track.id, bytes)
                if (installed) pendingCovers++
            }
        }
        dao.upsertMeta(
            TrackMetaEntity(
                trackId = track.id,
                artist = match.artist,
                title = match.title,
                album = match.album,
                coverUrl = if (installed) url else null,
                source = match.source,
                state = META_MATCHED,
                attempts = 0,
                score = 1000,
                checkedAt = System.currentTimeMillis()
            )
        )
        dao.deleteLyrics(track.id)
        flushCovers()
        return installed || match.artist.isNotBlank()
    }

    suspend fun clearCache() {
        stop()
        dao.clearMeta()
        _progress.value = EnrichProgress()
        ArtworkCache.notifyChanged()
    }

    private fun flushCovers() {
        if (pendingCovers == 0) return
        pendingCovers = 0
        // One nudge per batch, never per cover: every nudge invalidates the artwork of every row on
        // screen, and doing that 300 times would undo the scroll work of 6.6.
        ArtworkCache.notifyChanged()
    }

    /* ------------------------------------------------------------------ network */

    private fun capabilities(): NetworkCapabilities? {
        val manager = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return null
        val network = manager.activeNetwork ?: return null
        return manager.getNetworkCapabilities(network)
    }

    fun hasNetwork(): Boolean {
        val caps = capabilities() ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * "Wi-Fi only" is checked as NOT_METERED rather than TRANSPORT_WIFI: a metered hotspot is
     * still someone's mobile data, and an unmetered ethernet dock is not Wi-Fi but is free.
     */
    private fun networkAllowed(wifiOnly: Boolean): Boolean {
        if (!hasNetwork()) return false
        if (!wifiOnly) return true
        val caps = capabilities() ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    private companion object {
        /**
         * Order matters and is not alphabetical: keyless and fast first, rate-limited last.
         */
        val PROVIDERS: List<suspend (TrackQuery.Ask) -> List<RemoteMatch>> = listOf(
            { ask -> RemoteMeta.itunes(ask) },
            { ask -> RemoteMeta.deezer(ask) },
            { ask -> RemoteMeta.musicbrainz(ask) }
        )
    }
}
