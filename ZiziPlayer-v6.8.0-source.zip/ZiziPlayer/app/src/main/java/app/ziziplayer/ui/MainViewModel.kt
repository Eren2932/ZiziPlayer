package app.ziziplayer.ui

import androidx.compose.runtime.Immutable
import android.app.Application
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.ziziplayer.ZiziApplication
import app.ziziplayer.data.*
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.playback.PlayerController
import app.ziziplayer.playback.Progress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch

enum class LibraryFilter { TRACKS, FAVORITES, PLAYLISTS, FOLDERS }

/** Where the text in the search field is looked up: our files, or the catalogues (6.8). */
enum class SearchScope { LIBRARY, NET }

/**
 * State of the network search. Separate from [LibraryUiState] on purpose: the library state is
 * rebuilt by a combine over five flows, and a search that types, loads and fails has nothing to do
 * with favourites or sort order. Coupling them would put a network spinner in the code path that
 * re-sorts 450 tracks.
 *
 * [query] is the query these RESULTS belong to, not what is currently typed - that is what lets the
 * UI tell "you have not asked yet" from "this is the answer" without a second boolean per state.
 */
@Immutable
data class OnlineUiState(
    val query: String = "",
    val loading: Boolean = false,
    val asked: Boolean = false,
    val results: List<OnlineTrack> = emptyList(),
    val error: String? = null,
    val downloading: Set<String> = emptySet(),
    val downloaded: Set<String> = emptySet()
)

@Immutable
data class FolderInfo(val name: String, val count: Int)

/** One-off message for the snackbar (used by "removed from the app" + undo). */
data class UiMessage(val text: String, val actionLabel: String? = null, val action: (() -> Unit)? = null)

/**
 * Library state ONLY. Playback position deliberately lives in a separate flow: in v3 everything
 * was one object, so the 4 Hz position tick rebuilt this state, re-sorted 450 tracks on the main
 * thread and recomposed every row of the list. That was the real source of the lag.
 */
@Immutable
data class LibraryUiState(
    val loading: Boolean = true,
    val scanning: Boolean = false,
    val tracks: List<TrackEntity> = emptyList(),
    val visible: List<TrackEntity> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val playlistCounts: Map<Long, Int> = emptyMap(),
    val folders: List<FolderInfo> = emptyList(),
    val hiddenCount: Int = 0,
    /**
     * Play counters, passed through by reference - the same map the sort already uses, so this
     * costs nothing to carry. The track menu used to be handed a hardcoded `plays = 0`, which is
     * why "прослушан N раз" never appeared for any track, ever.
     */
    val stats: Map<String, PlayStatEntity> = emptyMap(),
    val settings: UserSettings = UserSettings(),
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylist: PlaylistEntity? = null,
    val openFolder: String? = null
) {
    val isDrilledIn: Boolean get() = openPlaylist != null || openFolder != null
}

private data class Selection(
    val filter: LibraryFilter = LibraryFilter.TRACKS,
    val query: String = "",
    val searchOpen: Boolean = false,
    val openPlaylistId: Long? = null,
    val openFolder: String? = null
)

private data class LibrarySources(
    val tracks: List<TrackEntity>,
    val favorites: Set<String>,
    val hidden: Set<String>,
    val playlists: List<PlaylistEntity>,
    val counts: Map<Long, Int>
)

private data class LibraryContext(
    val stats: Map<String, PlayStatEntity>,
    val settings: UserSettings,
    val selection: Selection,
    val playlistTracks: List<TrackEntity>,
    val scanning: Boolean
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: MusicRepository = (application as ZiziApplication).repository
    private val player: PlayerController = (application as ZiziApplication).playerController

    private val selection = MutableStateFlow(Selection())
    private val scanning = MutableStateFlow(false)

    /**
     * Scan progress is exposed as its own flow and deliberately kept **out** of [LibraryUiState].
     *
     * It ticks every 25 files. Folding it into the library state would push the whole pipeline -
     * filter, search, folder counting, a full sort of the library - through `Dispatchers.Default`
     * dozens of times per scan and hand Compose a brand new list each time. That is exactly the
     * mistake v3 made with the playback position, and it is what made the list stutter.
     *
     * A `StateFlow` also conflates by nature, so the four worker threads reporting progress cannot
     * outrun the UI.
     */
    private val _scanProgress = MutableStateFlow<ScanProgress?>(null)
    val scanProgress: StateFlow<ScanProgress?> = _scanProgress.asStateFlow()
    private val _messages = Channel<UiMessage>(Channel.BUFFERED)
    val messages: Flow<UiMessage> = _messages.receiveAsFlow()

    /**
     * The library with fetched metadata folded in - and the ONLY track flow anything downstream is
     * allowed to read.
     *
     * Overlaying here instead of in the list rows is the whole design of 6.7's UI half. The list,
     * the player, the queue, the search index and the sort all read tracks from this one flow, so a
     * fetched artist name reaches every one of them without a single one of them learning that a
     * network exists. Doing it per row would have meant passing a metadata map into six composables
     * and re-implementing the fallback in each.
     *
     * Nothing here is ever written back to the `tracks` table: this overlay lives in memory only.
     * The scanner owns that table and would overwrite it on the next rescan anyway, and the files
     * themselves are never rewritten.
     *
     * `shareIn` rather than `stateIn`: a StateFlow needs an initial value, and the only honest one
     * would be an empty list, which downstream would render for a frame as "no tracks" on every
     * cold start.
     */
    private val enrichedTracks: Flow<List<TrackEntity>> =
        combine(repo.tracks, repo.meta) { tracks, meta -> overlay(tracks, meta) }
            .flowOn(Dispatchers.Default)
            .shareIn(viewModelScope, SharingStarted.Eagerly, replay = 1)

    private val sources = combine(
        enrichedTracks, repo.favoriteIds, repo.hiddenIds, repo.playlists, repo.playlistCounts
    ) { tracks, favorites, hidden, playlists, counts ->
        LibrarySources(tracks, favorites, hidden, playlists, counts)
    }

    private val openPlaylistTracks = selection
        .map { it.openPlaylistId }
        .distinctUntilChanged()
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observePlaylistTracks(id) }

    private val libraryContext = combine(
        repo.stats, repo.settings, selection, openPlaylistTracks, scanning
    ) { stats, settings, sel, playlistTracks, isScanning ->
        LibraryContext(stats, settings, sel, playlistTracks, isScanning)
    }

    /** Everything heavy (filter, search, sort, folder counting) happens off the main thread. */
    val library: StateFlow<LibraryUiState> = combine(sources, libraryContext) { source, ctx ->
        build(source, ctx)
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibraryUiState())

    val playback: StateFlow<PlaybackState> = player.state
    val progress: StateFlow<Progress> = player.progress

    val currentTrack: StateFlow<TrackEntity?> = combine(
        enrichedTracks, player.state.map { it.currentTrackId }.distinctUntilChanged()
    ) { tracks, id -> if (id == null) null else tracks.firstOrNull { it.id == id } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val queue: StateFlow<List<TrackEntity>> = combine(
        enrichedTracks, player.state.map { it.queueIds }.distinctUntilChanged()
    ) { tracks, ids ->
        if (ids.isEmpty()) emptyList() else {
            val byId = HashMap<String, TrackEntity>(tracks.size)
            tracks.forEach { byId[it.id] = it }
            ids.mapNotNull { byId[it] }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Accepted matches, for the "источник: Deezer" line in the track menu. */
    val meta: StateFlow<Map<String, TrackMetaEntity>> = repo.meta
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** Tracks whose lyrics are already cached. Lazily shared: only the player screen asks. */
    val cachedLyricIds: StateFlow<Set<String>> = repo.lyricIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    val enrichProgress: StateFlow<EnrichProgress> = repo.enrichProgress

    private val _fx = MutableStateFlow(TrackFxEntity("", 1f, 1f, 0))
    val fx: StateFlow<TrackFxEntity> = _fx

    private var lastRegisteredPlay: String? = null
    private var scanJob: Job? = null

    init {
        launchScan { withScan { repo.rescan(it) } }
        // FX are per track: load them the moment the track changes and push them to the player.
        viewModelScope.launch {
            player.state.map { it.currentTrackId }.distinctUntilChanged().collect { id ->
                if (id == null) return@collect
                val saved = repo.fx(id)
                _fx.value = saved
                player.setPlayback(saved.speed, saved.pitch, saved.reverb)
                if (lastRegisteredPlay != id) { lastRegisteredPlay = id; repo.registerPlay(id) }
            }
        }
        viewModelScope.launch {
            repo.settings.map { it.skipSilence }.distinctUntilChanged().collect { player.setSkipSilence(it) }
        }
        // Resume where the user stopped, without autoplay.
        //
        // THE "TRACK RESTARTS FROM THE BEGINNING" BUG.
        // The playback session outlives the Activity, but this ViewModel is recreated every time
        // the Activity is (screen off, rotation, coming back after a while in another app). v4 then
        // rebuilt the queue on top of a session that was happily playing, rewinding it to whatever
        // position had been saved earlier. Waiting for the connection and bailing out when a queue
        // already exists means the running session is never touched.
        viewModelScope.launch {
            player.awaitConnected()
            if (player.hasQueue()) return@launch
            val lastId = repo.lastTrackId() ?: return@launch
            val tracks = withTimeoutOrNull(20_000) { repo.tracks.first { it.isNotEmpty() } } ?: return@launch
            if (player.hasQueue()) return@launch
            val hidden = repo.hiddenIds.first()
            val list = tracks.filterNot { hidden.contains(it.id) }
            val index = list.indexOfFirst { it.id == lastId }
            if (index >= 0) player.setQueue(list, index, play = false, startPositionMs = repo.lastPositionMs())
        }
        // Keep the notification and the lock screen in step with the overlay (6.7).
        //
        // `queue` is the enriched queue in playing order, so this fires both when the queue changes
        // and when a catalogue answer lands for something already in it. The debounce is what makes
        // it cheap during a pass: answers arrive one per ~350 ms for minutes, and each one would
        // otherwise walk the whole timeline. `collectLatest` cancels the pending walk on the next
        // answer, so a long pass costs one walk at its end instead of three hundred.
        viewModelScope.launch {
            queue.collectLatest { list ->
                if (list.isEmpty()) return@collectLatest
                delay(1_200)
                player.refreshMetadata(list)
            }
        }
        // The automatic enrichment pass.
        //
        // Started from here rather than from the repository's construction because it must not
        // compete with the first frames: a cold start already scans the library, decodes covers and
        // builds the list, and adding network I/O to that is how a launch turns into two seconds of
        // white screen. The delay lets the cover prefetcher settle first - it is also the thing that
        // decides WHICH tracks have no cover and therefore need asking about.
        //
        // collectLatest restarts on every library or setting change, and start() is a no-op while a
        // pass is already running, so a rescan cannot stack two passes on top of each other.
        viewModelScope.launch {
            combine(
                repo.tracks,
                repo.settings.map { it.enrichFromNet }.distinctUntilChanged()
            ) { tracks, enabled -> tracks to enabled }
                .collectLatest { (tracks, enabled) ->
                    if (!enabled) { repo.stopEnrichment(); return@collectLatest }
                    if (tracks.isEmpty()) return@collectLatest
                    delay(4_000)
                    repo.startEnrichment(tracks)
                }
        }
        // Backup only. The service persists the position every four seconds and on every state
        // change, which is what keeps it correct while the screen is off and the UI is dead.
        viewModelScope.launch {
            while (true) {
                delay(5_000)
                val state = player.state.value
                if (!state.isPlaying) continue
                val id = state.currentTrackId ?: continue
                repo.saveLastPosition(id, player.progress.value.positionMs)
            }
        }
    }

    /**
     * lowercase() allocates a brand new String on every call. v4 called it up to four times per
     * track for every keystroke and on every sort, which is tens of thousands of allocations per
     * typed character on a 450 track library - the search felt sticky and the GC churned. The keys
     * are computed once per track. build() always runs on the same background dispatcher, so a
     * plain HashMap needs no synchronisation.
     */
    private class SearchKeys(val title: String, val artist: String)
    private val searchKeys = HashMap<String, SearchKeys>()
    private fun keysOf(track: TrackEntity): SearchKeys =
        searchKeys.getOrPut(track.id) { SearchKeys(track.title.lowercase(), track.artist.lowercase()) }

    // Folder counts only change when the library itself changes, not on every keystroke.
    private var foldersForTracks: List<TrackEntity>? = null
    private var foldersForHidden: Set<String>? = null
    private var foldersCache: List<FolderInfo> = emptyList()

    private fun build(source: LibrarySources, ctx: LibraryContext): LibraryUiState {
        val sel = ctx.selection
        val available = if (source.hidden.isEmpty()) source.tracks
        else source.tracks.filterNot { source.hidden.contains(it.id) }

        if (searchKeys.size > available.size * 2) searchKeys.clear()

        val folders = if (foldersForTracks === source.tracks && foldersForHidden === source.hidden) {
            foldersCache
        } else {
            available
                .groupingBy { it.sourceFolder }
                .eachCount()
                .map { FolderInfo(it.key, it.value) }
                .sortedWith(compareByDescending<FolderInfo> { it.count }.thenBy { it.name.lowercase() })
                .also {
                    foldersForTracks = source.tracks
                    foldersForHidden = source.hidden
                    foldersCache = it
                }
        }

        val openPlaylist = source.playlists.firstOrNull { it.id == sel.openPlaylistId }
        val base = when {
            openPlaylist != null -> ctx.playlistTracks.filterNot { source.hidden.contains(it.id) }
            sel.openFolder != null -> available.filter { it.sourceFolder == sel.openFolder }
            sel.filter == LibraryFilter.FAVORITES -> available.filter { source.favorites.contains(it.id) }
            else -> available
        }

        val searched = if (sel.query.isBlank()) base else {
            val needle = sel.query.trim().lowercase()
            base.filter { track ->
                val keys = keysOf(track)
                keys.title.contains(needle) || keys.artist.contains(needle)
            }
        }

        // A playlist keeps its manual order; everything else follows the chosen sort mode.
        val sorted = if (openPlaylist != null) searched else when (ctx.settings.sortMode) {
            SortMode.TITLE -> searched.sortedBy { keysOf(it).title }
            SortMode.ARTIST -> searched.sortedWith(compareBy({ keysOf(it).artist }, { keysOf(it).title }))
            SortMode.DURATION -> searched.sortedByDescending { it.durationMs }
            SortMode.RECENT -> searched.sortedByDescending { it.dateAdded }
            SortMode.PLAYS -> searched.sortedWith(
                compareByDescending<TrackEntity> { ctx.stats[it.id]?.playCount ?: 0 }
                    .thenByDescending { ctx.stats[it.id]?.lastPlayedAt ?: 0L }
                    .thenBy { keysOf(it).title }
            )
        }

        return LibraryUiState(
            loading = false,
            scanning = ctx.scanning,
            tracks = available,
            visible = sorted,
            favoriteIds = source.favorites,
            playlists = source.playlists,
            playlistCounts = source.counts,
            folders = folders,
            hiddenCount = source.hidden.size,
            stats = ctx.stats,
            settings = ctx.settings,
            filter = sel.filter,
            query = sel.query,
            searchOpen = sel.searchOpen,
            openPlaylist = openPlaylist,
            openFolder = sel.openFolder
        )
    }

    // ---------------- navigation ----------------

    fun setFilter(filter: LibraryFilter) = selection.update {
        it.copy(filter = filter, openPlaylistId = null, openFolder = null)
    }
    fun setQuery(query: String) = selection.update { it.copy(query = query) }
    fun setSearchOpen(open: Boolean) = selection.update { it.copy(searchOpen = open, query = if (open) it.query else "") }

    /* ------------------------------------------------------------- поиск в сети (6.8) */

    private val _searchScope = MutableStateFlow(SearchScope.LIBRARY)
    val searchScope = _searchScope.asStateFlow()

    private val _online = MutableStateFlow(OnlineUiState())
    val online = _online.asStateFlow()

    /**
     * One search at a time. A second tap while the first pass is still asking a discovery node must
     * cancel it, not race it: two passes finishing out of order would leave the results of the
     * query the user has already replaced.
     */
    private var onlineJob: Job? = null

    fun setSearchScope(scope: SearchScope) { _searchScope.value = scope }

    fun searchOnline(query: String) {
        val q = query.trim()
        if (q.length < 2) return
        onlineJob?.cancel()
        _online.update { it.copy(loading = true, error = null) }
        onlineJob = viewModelScope.launch {
            val found = runCatching { OnlineCatalog.search(q) }
            _online.update { current ->
                found.fold(
                    onSuccess = { list ->
                        current.copy(query = q, loading = false, asked = true, results = list, error = null)
                    },
                    onFailure = {
                        // A failed search must not erase the previous answer: the user may still be
                        // playing something from it. The error is a banner, not a wipe.
                        current.copy(
                            query = q, loading = false, asked = true,
                            error = "Каталоги не ответили. Проверь сеть и попробуй ещё раз."
                        )
                    }
                )
            }
        }
    }

    /**
     * Plays a network track through the existing queue.
     *
     * [OnlineTrack.asTrack] hands PlayerController an ordinary TrackEntity whose `uri` happens to
     * be an https stream, so the queue, the notification, the lock screen, the sleep timer and the
     * speed/pitch controls all work with no new code in playback. The whole result list becomes the
     * queue, exactly like tapping a row in the library.
     */
    fun playOnline(track: OnlineTrack, list: List<OnlineTrack>) {
        val queue = list.ifEmpty { listOf(track) }
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        player.setQueue(queue.map { it.asTrack() }, index, play = true)
    }

    /**
     * Saves a network track into shared Music/ and then rescans, so it becomes an ordinary local
     * track. The rescan closes the loop: without it the file exists and the library does not know,
     * which reads as a download that did nothing.
     */
    fun downloadOnline(track: OnlineTrack) {
        if (track.id in _online.value.downloading) return
        _online.update { it.copy(downloading = it.downloading + track.id) }
        viewModelScope.launch {
            val error = OnlineDownloader.download(getApplication(), track)
            _online.update {
                it.copy(
                    downloading = it.downloading - track.id,
                    downloaded = if (error == null) it.downloaded + track.id else it.downloaded
                )
            }
            if (error == null) {
                _messages.trySend(UiMessage("Сохранено в Music/Zizi"))
                rescan()
            } else {
                _messages.trySend(UiMessage(error))
            }
        }
    }
    fun openPlaylist(id: Long) = selection.update { it.copy(openPlaylistId = id, openFolder = null) }
    fun openFolder(name: String) = selection.update { it.copy(openFolder = name, openPlaylistId = null) }

    /** Single back entry point, so the system side-swipe never quits the app by accident. */
    fun handleBack(): Boolean {
        val state = library.value
        return when {
            state.openPlaylist != null -> { selection.update { it.copy(openPlaylistId = null) }; true }
            state.openFolder != null -> { selection.update { it.copy(openFolder = null) }; true }
            state.searchOpen -> { setSearchOpen(false); true }
            state.filter != LibraryFilter.TRACKS -> { setFilter(LibraryFilter.TRACKS); true }
            else -> false
        }
    }

    // ---------------- playback ----------------

    fun play(track: TrackEntity, list: List<TrackEntity>? = null) {
        val source = list ?: library.value.visible.ifEmpty { library.value.tracks }
        val index = source.indexOfFirst { it.id == track.id }
        if (index < 0) player.setQueue(listOf(track), 0) else player.setQueue(source, index)
    }

    fun shuffleAll() {
        val source = library.value.visible.ifEmpty { library.value.tracks }
        if (source.isEmpty()) return
        val shuffled = source.shuffled()
        player.setQueue(shuffled, 0)
    }

    /**
     * "Играть следующим" / "В конец очереди" (6.6).
     *
     * With nothing playing there is no queue to insert into, so the track simply starts - which is
     * what a user who taps "играть следующим" on a silent app means anyway.
     */
    fun playNext(track: TrackEntity) = player.enqueue(track, playNext = true)
    fun addToQueue(track: TrackEntity) = player.enqueue(track, playNext = false)

    fun playPause() = player.playPause()
    fun next() = player.next()
    fun previous() = player.previous()
    fun seekTo(positionMs: Long) = player.seekTo(positionMs)
    fun seekToIndex(index: Int) = player.seekToIndex(index)
    fun toggleShuffle() = player.toggleShuffle()
    fun cycleRepeat() = player.cycleRepeat()
    fun setSleepTimer(minutes: Int?) = player.setSleepTimer(minutes)

    fun setFx(speed: Float, pitch: Float, reverb: Int) {
        val id = playback.value.currentTrackId ?: return
        val fx = TrackFxEntity(id, speed, pitch, reverb)
        _fx.value = fx
        player.setPlayback(speed, pitch, reverb)
        viewModelScope.launch { repo.saveFx(fx) }
    }

    fun resetFx() = setFx(1f, 1f, 0)

    suspend fun loadFx(id: String): TrackFxEntity = repo.fx(id)

    fun saveFx(id: String, speed: Float, pitch: Float, reverb: Int) {
        val fx = TrackFxEntity(id, speed, pitch, reverb)
        if (id == playback.value.currentTrackId) {
            _fx.value = fx
            player.setPlayback(speed, pitch, reverb)
        }
        viewModelScope.launch { repo.saveFx(fx) }
    }

    // ---------------- library actions ----------------

    fun toggleFavorite(track: TrackEntity) {
        val isFavorite = library.value.favoriteIds.contains(track.id)
        viewModelScope.launch { repo.toggleFavorite(track.id, isFavorite) }
    }

    /**
     * "Remove from the app": the file stays on the phone, the track just leaves the library and
     * the running queue. Reversible from the snackbar, and from Settings for older removals.
     */
    fun removeFromApp(track: TrackEntity) {
        viewModelScope.launch {
            repo.hideTrack(track.id)
            player.removeFromQueue(track.id)
            _messages.trySend(
                UiMessage(
                    text = "Убрано из приложения: ${track.title}",
                    actionLabel = "Вернуть",
                    action = { restoreTrack(track.id) }
                )
            )
        }
    }

    fun restoreTrack(id: String) { viewModelScope.launch { repo.unhideTrack(id) } }

    fun restoreAllHidden() {
        viewModelScope.launch {
            repo.clearHidden()
            _messages.trySend(UiMessage("Скрытые треки возвращены"))
        }
    }

    /** Real file deletion, kept separate and always behind the system confirmation dialog. */
    fun requestDeleteFile(track: TrackEntity, onReady: (IntentSender?) -> Unit) {
        viewModelScope.launch {
            val sender = runCatching { repo.requestFileDeletion(track) }.getOrNull()
            if (sender == null) {
                // Below Android 11 the file is deleted right away, nothing to confirm.
                onFileDeleted(track)
                onReady(null)
            } else onReady(sender)
        }
    }

    fun onFileDeleted(track: TrackEntity) {
        viewModelScope.launch {
            player.removeFromQueue(track.id)
            repo.forgetTrack(track.id)
            _messages.trySend(UiMessage("Файл удалён: ${track.title}"))
        }
    }

    fun addFolder(uri: Uri) {
        launchScan { withScan { repo.addFolder(uri, it) } }
    }

    fun removeFolder(uri: String) {
        launchScan { withScan { repo.removeFolder(uri, it) } }
    }

    /**
     * Applies fetched metadata to the library, conservatively.
     *
     * Two rules, both deliberate:
     *
     *  - a field is only replaced when the local one says nothing. A tag the user's file actually
     *    carries always wins over a catalogue guess, because the file is ground truth about what
     *    the user has and the catalogue is a guess about what it might be.
     *  - the title is NEVER replaced, even when a catalogue offers a prettier one. Titles are how
     *    the user recognises and searches their own files; silently renaming "Грибы, Симптом - Копы"
     *    to "Копы" would make a library people have memorised unsearchable.
     *
     * Returns the original list unchanged when nothing applies, so the identity check downstream
     * skips a recomposition instead of diffing 444 fresh objects.
     */
    private fun overlay(
        tracks: List<TrackEntity>,
        meta: Map<String, TrackMetaEntity>
    ): List<TrackEntity> {
        if (meta.isEmpty() || tracks.isEmpty()) return tracks
        var changed = false
        val out = ArrayList<TrackEntity>(tracks.size)
        for (track in tracks) {
            val found = meta[track.id]
            if (found == null) { out.add(track); continue }
            val artist = if (isUnknownArtist(track.artist) && !found.artist.isNullOrBlank()) {
                found.artist
            } else track.artist
            val album = if (track.album.isBlank() && !found.album.isNullOrBlank()) {
                found.album
            } else track.album
            if (artist != track.artist || album != track.album) {
                changed = true
                out.add(track.copy(artist = artist, album = album))
            } else out.add(track)
        }
        return if (changed) out else tracks
    }

    private fun isUnknownArtist(artist: String): Boolean {
        val value = artist.trim().lowercase()
        return value.isEmpty() || value == "<unknown>" || value == "unknown" ||
            value == "неизвестный артист" || value == "unknown artist"
    }

    /* ------------------------------------------------------------------ enrichment (6.7) */

    fun setEnrichFromNet(value: Boolean) {
        viewModelScope.launch {
            repo.setEnrichFromNet(value)
            if (!value) repo.stopEnrichment()
        }
    }

    fun setEnrichWifiOnly(value: Boolean) { viewModelScope.launch { repo.setEnrichWifiOnly(value) } }
    fun setLyricsFromNet(value: Boolean) { viewModelScope.launch { repo.setLyricsFromNet(value) } }

    /**
     * "Найти обложки сейчас". [force] re-asks even about tracks already given a final verdict,
     * because that is what a user pressing a button by hand means - the automatic pass would
     * otherwise report "нечего искать" and look broken.
     */
    fun enrichNow() {
        viewModelScope.launch {
            if (!repo.hasNetwork()) {
                _messages.trySend(UiMessage("Нет соединения"))
                return@launch
            }
            repo.startEnrichment(library.value.tracks, force = true)
        }
    }

    fun stopEnrichment() = repo.stopEnrichment()

    fun clearMetaCache() {
        viewModelScope.launch {
            repo.clearMetaCache()
            _messages.trySend(UiMessage("Загруженные обложки и текст удалены"))
        }
    }

    /** Per-track "Уточнить" from the menu. Reports the outcome, because silence reads as a bug. */
    fun refreshMeta(track: TrackEntity) {
        viewModelScope.launch {
            if (!repo.hasNetwork()) {
                _messages.trySend(UiMessage("Нет соединения"))
                return@launch
            }
            _messages.trySend(UiMessage("Ищу обложку и артиста…"))
            val ok = repo.refreshMeta(track)
            _messages.trySend(UiMessage(if (ok) "Нашёл" else "Ничего похожего не нашлось"))
        }
    }

    /**
     * What to put in the manual picker's text field before the user types anything.
     *
     * Reuses the matcher's own file-name cleaning ([TrackQuery.asksFor]) instead of pasting the raw
     * title, so the field starts at "Artist - Title" rather than
     * "03_Artist - Title (Official Video) [slowed]". When the cleaner has nothing to offer - which
     * is exactly the case for the recorder-style names it refuses to ask about - the raw fields are
     * used, because an imperfect starting point still beats an empty box.
     */
    fun searchSeedFor(track: TrackEntity): String {
        val ask = TrackQuery.asksFor(track).firstOrNull()
        if (ask != null) {
            return if (ask.artist.isNullOrBlank()) ask.title else "${ask.artist} - ${ask.title}"
        }
        val artist = track.artist.takeIf { it.isNotBlank() && !it.contains("known", ignoreCase = true) &&
            !it.startsWith("Неизвест") }
        return if (artist == null) track.title else "$artist - ${track.title}"
    }

    /**
     * Manual catalogue search, for the picker in the track menu.
     *
     * Returns null to mean "there was no way to even ask" (no connection), which the sheet renders
     * differently from an empty list - "нет соединения" and "ничего не нашлось" are two different
     * things to tell someone, and collapsing them into an empty list is how an app gets accused of
     * lying.
     */
    suspend fun searchCatalog(query: String, durationMs: Long): List<RemoteMatch>? {
        if (!repo.hasNetwork()) return null
        return runCatching { repo.searchCatalog(query, durationMs) }.getOrDefault(emptyList())
    }

    /** The user picked an answer by hand. Applied with no threshold - see MetadataEnricher.applyMatch. */
    fun applyMatch(track: TrackEntity, match: RemoteMatch) {
        viewModelScope.launch {
            val ok = runCatching { repo.applyMatch(track, match) }.getOrDefault(false)
            _messages.trySend(
                UiMessage(if (ok) "Готово: ${match.artist}" else "Не удалось загрузить обложку")
            )
        }
    }

    suspend fun lyricsFor(track: TrackEntity): LyricsEntity? =
        repo.lyricsFor(track, meta.value[track.id]?.artist)

    fun rescan() {
        launchScan {
            withScan { repo.rescan(it) }
            _messages.trySend(UiMessage("Библиотека обновлена"))
        }
    }

    /**
     * Serialises scans, latest request wins.
     *
     * Two passes must never run at once: they write the same rows, compete for the same four tag
     * readers, and whichever finishes first clears the badge while the other is still going. But
     * *dropping* the newer request is equally wrong, and in one specific case it would be a visible
     * bug: the startup scan begins before the storage permission is granted, so it finds nothing,
     * and the `rescan()` fired the moment the user taps "Allow" is exactly the one that matters. If
     * that were ignored, the library would stay empty until a manual refresh.
     *
     * So the previous scan is cancelled and **joined** - awaited to a full stop - before the new one
     * touches the database. Cancellation is honoured per directory and per file now, so this returns
     * promptly instead of waiting out the whole pass.
     */
    private fun launchScan(block: suspend () -> Unit) {
        val previous = scanJob
        scanJob = viewModelScope.launch {
            previous?.cancelAndJoin()
            block()
        }
    }

    /**
     * Single owner of the scanning flags. Every entry point used to duplicate the set/clear pair,
     * and one of them forgetting the clear on an early return would have left the badge on screen
     * forever. `finally` also covers cancellation - the scan is now cancellable, so that is a real
     * path, not a theoretical one.
     */
    private suspend fun withScan(block: suspend ((ScanProgress) -> Unit) -> Unit) {
        scanning.value = true
        try {
            block { progress -> _scanProgress.value = progress }
        } catch (cancelled: CancellationException) {
            // Never swallowed: swallowing it leaves the parent scope believing the child is alive.
            throw cancelled
        } catch (_: Throwable) {
            // Any other failure must not take the ViewModel down; the library stays as it was.
        } finally {
            _scanProgress.value = null
            scanning.value = false
        }
    }

    fun createPlaylist(name: String, tracks: List<TrackEntity> = emptyList()) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val id = repo.createPlaylist(name.trim())
            tracks.forEach { repo.addToPlaylist(id, it.id) }
        }
    }

    fun addToPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repo.addToPlaylist(playlistId, trackId)
            _messages.trySend(UiMessage("Добавлено в плейлист"))
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch { repo.removeFromPlaylist(playlistId, trackId) }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repo.deletePlaylist(id)
            selection.update { if (it.openPlaylistId == id) it.copy(openPlaylistId = null) else it }
        }
    }

    fun renamePlaylist(id: Long, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { repo.renamePlaylist(id, name.trim()) }
    }

    fun saveQueueAsPlaylist(name: String) = createPlaylist(name, queue.value)

    fun setTheme(theme: AppTheme) { viewModelScope.launch { repo.setTheme(theme) } }
    fun setDynamicAccent(value: Boolean) { viewModelScope.launch { repo.setDynamicAccent(value) } }
    fun setSkipSilence(value: Boolean) { viewModelScope.launch { repo.setSkipSilence(value) } }
    fun setSortMode(mode: SortMode) { viewModelScope.launch { repo.setSortMode(mode) } }

    fun setUiActive(active: Boolean) = player.setUiActive(active)

    /** Called from Activity.onStop, while the scope is still alive. */
    fun savePosition() {
        val id = playback.value.currentTrackId ?: return
        val position = progress.value.positionMs
        viewModelScope.launch { repo.saveLastPosition(id, position) }
    }
}
