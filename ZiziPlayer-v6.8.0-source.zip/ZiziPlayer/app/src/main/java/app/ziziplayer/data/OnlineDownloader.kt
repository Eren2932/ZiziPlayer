package app.ziziplayer.data

import android.app.DownloadManager
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Saves a network track into the phone's own Music folder (6.8).
 *
 * WHY DownloadManager AND NOT OUR OWN HTTP LOOP. RemoteMeta is built for 30 KB of JSON and a
 * 200 KB cover: it holds the body in memory with a 512 KB cap and dies with the coroutine. A
 * 6 MB audio file that must survive the user leaving the app, locking the screen, or losing Wi-Fi
 * for a minute is a different problem, and Android already solved it. DownloadManager retries
 * across connectivity changes, resumes, shows its own progress notification and writes straight to
 * disk without ever holding the file in our heap.
 *
 * WHERE IT LANDS. `Music/Zizi/` in shared storage, not our private app directory. That is the
 * whole point of downloading in a local player: the file is the user's, it survives uninstalling
 * Zizi, any other player sees it, and OUR OWN SCANNER picks it up on the next pass - a downloaded
 * track becomes an ordinary library track with favourites, FX and play counts, instead of a
 * second-class citizen in a parallel "downloads" list. Public dirs are also the one legacy path
 * DownloadManager may still write to on Android 10+ without any permission at all.
 */
object OnlineDownloader {

    private const val UA = "ZiziPlayer/6.8 ( https://github.com/Eren2932/ZiziPlayer )"
    private const val SUBDIR = "Zizi"
    private const val POLL_MS = 700L
    private const val MAX_WAIT_MS = 15 * 60 * 1000L

    /** Characters no file system here tolerates, plus the control range. */
    private val ILLEGAL = Regex("""[/\\:*?"<>|\x00-\x1F]""")

    /**
     * "Artist - Title.mp3", and it matters that this is readable.
     *
     * The file is going into shared storage where the user will meet it in file managers, on a PC
     * and in other players for years. A name like `audius-1a2b3c.mp3` there is exactly the
     * "Неизвестный артист" problem 6.7 spent a whole release fixing, recreated by our own hand.
     *
     * Length is capped well under the 255-byte limit because the artist and the title are Cyrillic
     * more often than not, and every one of those characters is two bytes in UTF-8.
     */
    private fun fileName(track: OnlineTrack): String {
        val artist = ILLEGAL.replace(track.artist, " ").trim()
        val title = ILLEGAL.replace(track.title, " ").trim()
        val stem = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" - ")
            .replace(Regex("\\s+"), " ")
            .take(90)
            .ifBlank { "Zizi ${System.currentTimeMillis()}" }
        return "$stem.mp3"
    }

    /**
     * Enqueues the download and suspends until it finishes.
     *
     * Returns null on success, or a short human reason. Deliberately NOT a broadcast receiver for
     * ACTION_DOWNLOAD_COMPLETE: that needs an exported receiver on API 33+, has to be registered
     * somewhere with a lifetime longer than the screen, and delivers for every download in the
     * system including ones that are not ours. Polling a cursor once per 700 ms while ONE download
     * the user is watching runs is cheaper in code and in bugs than a receiver that is wrong in
     * either direction.
     *
     * Cancelling the coroutine (leaving the screen) does not cancel the download - by design. The
     * user asked for a file; DownloadManager finishes it and its own notification reports it.
     */
    suspend fun download(context: Context, track: OnlineTrack): String? = withContext(Dispatchers.IO) {
        if (!track.fullLength) return@withContext "Это превью, а не трек — скачивать нечего"
        val manager = runCatching { context.getSystemService(DownloadManager::class.java) }.getOrNull()
            ?: return@withContext "Загрузчик системы недоступен"

        val id = runCatching {
            val request = DownloadManager.Request(Uri.parse(track.streamUrl))
                .setTitle("${track.artist} — ${track.title}")
                .setDescription("Zizi · ${OnlineTrack.providerLabel(track.provider)}")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "$SUBDIR/${fileName(track)}")
                // The user tapped "download" on a specific track: silently refusing on mobile data
                // and leaving a queued row with no explanation is worse than spending the traffic
                // they just asked us to spend. The Wi-Fi-only rule in settings governs the
                // BACKGROUND enricher, which nobody asked for; this is a foreground request.
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .addRequestHeader("User-Agent", UA)
            manager.enqueue(request)
        }.getOrElse { return@withContext "Не удалось начать загрузку" }

        var waited = 0L
        while (waited < MAX_WAIT_MS) {
            delay(POLL_MS)
            waited += POLL_MS
            val cursor = runCatching {
                manager.query(DownloadManager.Query().setFilterById(id))
            }.getOrNull() ?: return@withContext "Загрузка потерялась"
            cursor.use { c ->
                if (!c.moveToFirst()) return@withContext "Загрузка отменена"
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                        // MediaStore must be told, and this is not optional: a file that exists on
                        // disk but not in MediaStore is invisible to READ_MEDIA_AUDIO queries, so
                        // our own scanner would not find the track we just saved. The user would
                        // see a successful download and an unchanged library.
                        val path = local?.let { runCatching { Uri.parse(it).path }.getOrNull() }
                        if (path != null) {
                            runCatching {
                                MediaScannerConnection.scanFile(
                                    context, arrayOf(path), arrayOf("audio/mpeg"), null
                                )
                            }
                        }
                        return@withContext null
                    }
                    DownloadManager.STATUS_FAILED -> {
                        val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                        return@withContext when (reason) {
                            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Не хватает места"
                            DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "Такой файл уже есть"
                            DownloadManager.ERROR_CANNOT_RESUME -> "Соединение оборвалось"
                            else -> "Загрузка не удалась"
                        }
                    }
                }
            }
        }
        "Загрузка идёт слишком долго — она продолжится в фоне"
    }
}
