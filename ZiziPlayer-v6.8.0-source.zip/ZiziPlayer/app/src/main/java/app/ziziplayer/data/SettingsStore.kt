package app.ziziplayer.data

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("zizi_settings")

enum class AppTheme { GRAPHITE, MIDNIGHT, AMOLED, SUNSET }
enum class SortMode { TITLE, ARTIST, DURATION, RECENT, PLAYS }

data class UserSettings(
    val theme: AppTheme = AppTheme.GRAPHITE,
    val accentFromArtwork: Boolean = true,
    val folderUris: Set<String> = emptySet(),
    val skipSilence: Boolean = false,
    val sortMode: SortMode = SortMode.TITLE,
    /**
     * Off by default, and that is a decision rather than caution: until the user says otherwise,
     * Zizi is an offline player and nothing about their library leaves the phone.
     */
    val enrichFromNet: Boolean = false,
    /** Covers are 50-120 KB each; a few hundred of them on mobile data is a bill, not a feature. */
    val enrichOnWifiOnly: Boolean = true,
    val lyricsFromNet: Boolean = true
)

class SettingsStore(private val context: Context) {
    private val theme = stringPreferencesKey("theme")
    private val dynamicAccent = booleanPreferencesKey("dynamic_accent")
    private val folders = stringSetPreferencesKey("folders")
    private val skipSilenceKey = booleanPreferencesKey("skip_silence")
    private val sortModeKey = stringPreferencesKey("sort_mode")
    private val enrichKey = booleanPreferencesKey("enrich_from_net")
    private val enrichWifiKey = booleanPreferencesKey("enrich_wifi_only")
    private val lyricsKey = booleanPreferencesKey("lyrics_from_net")
    /**
     * Marks the one-shot rewrite of track ids as finished. Read and written outside [settings] on
     * purpose: it is not user-facing state, and pushing it through that flow would rebuild the whole
     * library pipeline for a housekeeping flag.
     */
    private val idsMigratedKey = booleanPreferencesKey("ids_migrated_v3")

    val settings: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            theme = runCatching { AppTheme.valueOf(p[theme] ?: AppTheme.GRAPHITE.name) }.getOrDefault(AppTheme.GRAPHITE),
            accentFromArtwork = p[dynamicAccent] ?: true,
            folderUris = p[folders] ?: emptySet(),
            skipSilence = p[skipSilenceKey] ?: false,
            sortMode = runCatching { SortMode.valueOf(p[sortModeKey] ?: SortMode.TITLE.name) }.getOrDefault(SortMode.TITLE),
            enrichFromNet = p[enrichKey] ?: false,
            enrichOnWifiOnly = p[enrichWifiKey] ?: true,
            lyricsFromNet = p[lyricsKey] ?: true
        )
    }
    suspend fun setTheme(value: AppTheme) = context.dataStore.edit { it[theme] = value.name }
    suspend fun setDynamicAccent(value: Boolean) = context.dataStore.edit { it[dynamicAccent] = value }
    suspend fun addFolder(uri: Uri) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) + uri.toString() }
    suspend fun removeFolder(uri: String) = context.dataStore.edit { it[folders] = (it[folders] ?: emptySet()) - uri }
    suspend fun setSkipSilence(value: Boolean) = context.dataStore.edit { it[skipSilenceKey] = value }
    suspend fun setSortMode(value: SortMode) = context.dataStore.edit { it[sortModeKey] = value.name }
    suspend fun setEnrichFromNet(value: Boolean) = context.dataStore.edit { it[enrichKey] = value }
    suspend fun setEnrichWifiOnly(value: Boolean) = context.dataStore.edit { it[enrichWifiKey] = value }
    suspend fun setLyricsFromNet(value: Boolean) = context.dataStore.edit { it[lyricsKey] = value }

    suspend fun idsMigrated(): Boolean = context.dataStore.data.map { it[idsMigratedKey] ?: false }.first()
    suspend fun setIdsMigrated() = context.dataStore.edit { it[idsMigratedKey] = true }
}
