package app.ziziplayer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * What the internet knows about a local file.
 *
 * Deliberately a SEPARATE table instead of columns on `tracks`, for two reasons that are not
 * stylistic:
 *
 *  - `tracks` is owned by the scanner. Every rescan calls `upsertTracks` with `REPLACE`, so any
 *    fetched value written there would be destroyed by the next scan.
 *  - the tags inside the user's files are never touched. Writing ID3 frames back into an .mp3 is
 *    irreversible, needs write access to every file, and one interrupted write corrupts audio the
 *    user may not have a second copy of. Zizi shows better metadata; it does not rewrite the
 *    library.
 *
 * [state] is what keeps the enricher from asking the same question forever - see the constants.
 */
@Entity(tableName = "track_meta")
data class TrackMetaEntity(
    @PrimaryKey val trackId: String,
    val artist: String? = null,
    val title: String? = null,
    val album: String? = null,
    val coverUrl: String? = null,
    /** "itunes" / "deezer" / "musicbrainz" / "" - shown to the user, never guessed at. */
    val source: String = "",
    val state: Int = META_PENDING,
    /** Transient failures only (no network, 5xx, timeout). Drives the backoff. */
    val attempts: Int = 0,
    val checkedAt: Long = 0L,
    /** 0..1000. Kept so a manual re-check can be told apart from a weak automatic guess. */
    val score: Int = 0
)

/** Never asked yet, or the last answer was inconclusive and may be retried. */
const val META_PENDING = 0
/** A provider answered and the answer passed the match threshold. */
const val META_MATCHED = 1
/**
 * Every provider answered and nothing was close enough. This is a FINAL verdict on purpose: a
 * library full of DJ edits and TikTok rips has hundreds of files no catalogue contains, and
 * re-asking about them on every launch is how an app earns a reputation for eating battery.
 * "Уточнить" in the track menu clears it for one track.
 */
const val META_NO_MATCH = 2

/**
 * Lyrics for one track, cached forever once fetched.
 *
 * [synced] is raw LRC (`[mm:ss.xx] line`), [plain] is the fallback when only unsynced text exists.
 */
@Entity(tableName = "lyrics")
data class LyricsEntity(
    @PrimaryKey val trackId: String,
    val synced: String? = null,
    val plain: String? = null,
    val source: String = "",
    val fetchedAt: Long = 0L,
    /** Distinguishes "not fetched yet" from "asked, and this track has no lyrics anywhere". */
    val missing: Boolean = false
)
