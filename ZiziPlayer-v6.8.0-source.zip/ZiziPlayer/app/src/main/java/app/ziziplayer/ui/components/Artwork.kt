package app.ziziplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

const val ARTWORK_ROW_PX = 160
const val ARTWORK_FULL_PX = 640

/** Quantiser tuning. 24 buckets = 15 deg apart, finer than the eye separates on a backdrop. */
private const val HUE_BINS = 24
private const val SAMPLE_SIDE = 64
private const val MIN_HUE_GAP = 28f

/**
 * Three colours pulled out of one cover: the accent, a second shade for depth, and a deep one for
 * the far ends of the gradient. v5 used a single seed, so the whole screen was one flat wash of
 * colour. Reference players build the backdrop out of several shades of the same cover, which is
 * why it reads as "the cover flew across the screen" instead of "someone tinted the app brown".
 */
@Immutable
data class ArtSwatches(val primary: Color, val secondary: Color, val deep: Color) {
    fun pack(): String = "${primary.toArgb()},${secondary.toArgb()},${deep.toArgb()}"

    companion object {
        fun unpack(raw: String?): ArtSwatches? {
            val parts = raw?.split(',') ?: return null
            if (parts.size != 3) return null
            val ints = parts.map { it.toIntOrNull() ?: return null }
            return ArtSwatches(Color(ints[0]), Color(ints[1]), Color(ints[2]))
        }
    }
}

/** One decoded cover. The ImageBitmap wrapper is built once, not on every recomposition. */
@Immutable
class Art(val image: ImageBitmap, val kb: Int, val swatches: ArtSwatches?)

/**
 * Artwork pipeline, third rewrite - this time for a 3000 track library.
 *
 * The order of attempts:
 *   1. in-memory LruCache                       (instant, no allocation)
 *   2. on-disk thumbnail cache                  (~1 ms, survives app restarts)
 *   3. MediaStore album art / loadThumbnail     (cheap, system side cache)
 *   4. MediaMetadataRetriever                   (20-120 ms - NEVER from a visible row)
 *
 * The single most important rule: a scrolling row is only ever allowed to use steps 1-3.
 * v5 let every row start step 4, so scrolling a 400 track list queued 400 file parses behind a
 * one-permit semaphore - the list could not be smooth, whatever else was optimised. Step 4 now
 * belongs to [ArtworkPrefetcher], which walks the library in the background, pauses while the
 * finger is down, and writes the result to disk so it is paid exactly once per file, ever.
 */
object ArtworkCache {
    // Floor raised from 6 MB in 6.5: at 160 px a cover is ~100 KB, so 6 MB held barely 60 of
    // them. Flicking a long list evicted rows faster than it drew them and every one of them came
    // back through a disk decode - a cache that small is a cache that guarantees jank.
    private val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceIn(12 * 1024, 64 * 1024)
    private val memory = object : LruCache<String, Art>(maxKb) {
        override fun sizeOf(key: String, value: Art): Int = value.kb
    }
    private val swatchMemory = LruCache<String, ArtSwatches>(2048)
    private val noArt = Collections.synchronizedSet(HashSet<String>())
    private val fastGate = Semaphore(2)
    private val slowGate = Semaphore(1)

    /**
     * THE SCROLL BUG. Steps 1-3 were described as "cheap", so step 2 - the disk decode - ran with
     * no gate at all on Dispatchers.IO, which is 64 threads wide. Flicking a 400 row list started
     * up to 64 concurrent BitmapFactory.decodeFile calls; they do not block on IO, they burn CPU
     * and allocate, so they competed with the very frames they were decoding for. The list could
     * not be smooth no matter what else was optimised. Three at a time saturates the decode
     * throughput of a mid-range phone and leaves the render thread alone.
     */
    private val diskGate = Semaphore(3)

    @Volatile private var busyUntilMs = 0L
    @Volatile private var index: ArtworkIndex? = null
    @Volatile private var dir: File? = null

    private fun key(id: String, px: Int) = "$id@$px"

    fun attach(context: Context) {
        if (index != null) return
        val app = context.applicationContext
        val store = ArtworkIndex(app)
        index = store
        noArt.addAll(store.noArtIds())
        store.swatches().forEach { (id, swatches) -> swatchMemory.put(id, swatches) }
        val cacheDir = File(app.cacheDir, "artwork").apply { mkdirs() }
        dir = cacheDir
        // Keep the thumbnail cache bounded: oldest files go first.
        CoroutineScope(Dispatchers.IO).launch { prune(cacheDir) }
    }

    /** Called by every scrollable list: while the finger moves, nothing expensive may start. */
    fun markBusy() { busyUntilMs = System.currentTimeMillis() + 260 }
    fun isBusy(): Boolean = System.currentTimeMillis() < busyUntilMs

    /**
     * Sleeps until the busy window actually expires, instead of waking up every 60 ms to ask.
     *
     * Every visible row waits on this. With a 60 ms poll, twenty rows on screen meant ~200 pointless
     * coroutine resumes per flick, all of them landing on the main dispatcher while the frames they
     * were waiting for were being drawn. The busy window has a known end, so one sleep is enough.
     */
    suspend fun awaitIdle(maxWaitMs: Long = 900L) {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (true) {
            val now = System.currentTimeMillis()
            val remaining = busyUntilMs - now
            if (remaining <= 0L || now >= deadline) return
            delay(remaining.coerceIn(16L, 200L))
        }
    }

    /** Exactly the requested size, or nothing. */
    fun peekExact(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px))
    }

    /**
     * Anything usable right now, including a smaller thumbnail of the same cover. Used purely as a
     * stand-in for the first frame so nothing ever flashes a grey placeholder while the full size
     * decodes - it never replaces the real load.
     */
    fun peek(track: TrackEntity?, px: Int): Art? {
        val id = track?.id ?: return null
        return memory.get(key(id, px)) ?: if (px > ARTWORK_ROW_PX) memory.get(key(id, ARTWORK_ROW_PX)) else null
    }

    fun peekSwatches(track: TrackEntity?): ArtSwatches? = track?.let { swatchMemory.get(it.id) }

    /** Flushes the batched "no art" / colour verdicts to disk. */
    fun flushIndex() { index?.flush() }

    /**
     * Re-applies the 40 MB cap. v6.0 only did this at startup, so a full indexing pass could leave
     * the cache well over the cap until the next launch.
     */
    suspend fun pruneNow() {
        val base = dir ?: return
        withContext(Dispatchers.IO) { prune(base) }
    }

    fun hasNoArt(track: TrackEntity?): Boolean = track != null && noArt.contains(track.id)

    /**
     * Bumped whenever a cover appears for a track that had none - i.e. only when the enricher
     * installs one from the internet.
     *
     * This exists because the pipeline is a cache, not a stream: a row that has already decided
     * "this file has no artwork" holds that answer in a `remember` and will never ask again, so a
     * cover arriving later would stay invisible until the row was scrolled out and back. Reading
     * this value inside [rememberArtwork] subscribes every artwork widget to that one fact.
     *
     * It is a snapshot Int rather than a Flow on purpose: a Flow here would need a collector per
     * row. And it is nudged once per BATCH by the enricher, never once per cover - each nudge
     * re-asks the question for every artless row on screen, which is cheap at 12 rows and
     * ruinous 300 times in a row.
     */
    private val revisionState = mutableIntStateOf(0)
    val revision: Int get() = revisionState.value

    fun notifyChanged() { revisionState.value++ }

    /** Clears the "this file has no cover" verdict so the pipeline is willing to look again. */
    fun forgetNoArt(id: String) {
        noArt.remove(id)
        memory.remove(key(id, ARTWORK_ROW_PX))
        memory.remove(key(id, ARTWORK_FULL_PX))
        index?.forgetNoArt(id)
    }

    /**
     * Installs a cover fetched from a catalogue.
     *
     * Written into the same on-disk thumbnail cache, under the same key, at both sizes the UI ever
     * asks for. The consequence is that nothing else in the pipeline had to learn that the internet
     * exists: the next `load` finds the file at step 2 and behaves exactly as it does for a cover
     * that was embedded in the file all along. Colours are extracted here too, so the player
     * backdrop is right on the first open rather than after a decode.
     *
     * Returns false if the bytes were not a decodable image - a CAA 404 page, a truncated download.
     */
    suspend fun installRemoteCover(id: String, bytes: ByteArray): Boolean = withContext(Dispatchers.IO) {
        val full = decode(bytes, ARTWORK_FULL_PX) ?: return@withContext false
        val row = runCatching {
            Bitmap.createScaledBitmap(full, ARTWORK_ROW_PX, ARTWORK_ROW_PX, true)
        }.getOrNull() ?: return@withContext false
        writeDisk(id, ARTWORK_FULL_PX, full)
        writeDisk(id, ARTWORK_ROW_PX, row)
        extract(row)?.let { swatches ->
            swatchMemory.put(id, swatches)
            index?.rememberSwatches(id, swatches)
        }
        noArt.remove(id)
        index?.forgetNoArt(id)
        // Seed the row size into memory so the list can show it without touching the disk again.
        memory.put(key(id, ARTWORK_ROW_PX), Art(row.asImageBitmap(), (row.byteCount / 1024).coerceAtLeast(1), swatchMemory.get(id)))
        true
    }

    /**
     * Copies a cover already on disk from one track id to another, with no network at all.
     *
     * This is what makes the album-level de-duplication in [MetadataEnricher] possible: twelve
     * files of the same release share one piece of artwork, and asking a catalogue twelve times for
     * the same image is the user's bytes spent twice. Reading the stored WebP back and pushing it
     * through [installRemoteCover] rather than copying the file is deliberate - it is the same code
     * path, so the second track also gets its row-size variant and its extracted colours, which a
     * plain file copy would have silently skipped.
     */
    suspend fun cloneCover(fromId: String, toId: String): Boolean = withContext(Dispatchers.IO) {
        val source = fileFor(fromId, ARTWORK_FULL_PX)?.takeIf { it.exists() } ?: return@withContext false
        val bytes = runCatching { source.readBytes() }.getOrNull() ?: return@withContext false
        if (bytes.isEmpty()) return@withContext false
        installRemoteCover(toId, bytes)
    }

    /** True when this track needs no further work at all - used to skip cheaply while prefetching. */
    fun isSettled(id: String): Boolean =
        memory.get(key(id, ARTWORK_ROW_PX)) != null || noArt.contains(id) || fileFor(id, ARTWORK_ROW_PX)?.exists() == true

    suspend fun load(context: Context, track: TrackEntity, px: Int, allowSlow: Boolean): Art? {
        val cacheKey = key(track.id, px)
        memory.get(cacheKey)?.let { return it }
        if (noArt.contains(track.id)) return null

        // 2. disk (gated - see diskGate). withPermit is inline, so the non-local return below is
        // legal and the permit is still released through its finally block.
        val cached: Bitmap? = diskGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) { readDisk(track.id, px) }
        }
        if (cached != null) return finish(track, px, cached, writeDisk = false)

        // 3. fast system paths
        //
        // THE v6.0 COMPILE ERROR LIVED HERE.
        // The elvis had `Art?` on the left (the memory cache) and `Bitmap?` on the right (the
        // decoders), so Kotlin inferred their only common supertype - `Any` - and the call below
        // failed with "Argument type mismatch: actual type is 'kotlin.Any'" at Artwork.kt:167:52.
        // A cache hit now returns the finished Art immediately (withPermit is inline, so the
        // non-local return is legal and still releases the permit through its finally block) and
        // the remaining expression is a plain `Bitmap?`, which is what finish() wants.
        //
        // The re-check is not just there to satisfy the compiler: this permit is contended, and by
        // the time it is granted another coroutine may have decoded the very same cover already.
        val fast: Bitmap? = fastGate.withPermit {
            memory.get(cacheKey)?.let { return it }
            withContext(Dispatchers.IO) {
                fromArtworkUri(context, track, px) ?: fromThumbnail(context, track, px)
            }
        }
        if (fast != null) return finish(track, px, fast, writeDisk = true)
        if (!allowSlow) return null

        // 4. the expensive one, one at a time, never while scrolling
        val slow = fromEmbedded(context, track, px)
        if (slow != null) return finish(track, px, slow, writeDisk = true)
        noArt.add(track.id)
        index?.rememberNoArt(track.id)
        return null
    }

    private fun finish(track: TrackEntity, px: Int, bitmap: Bitmap, writeDisk: Boolean): Art {
        var swatches = swatchMemory.get(track.id)
        if (swatches == null) {
            swatches = extract(bitmap)
            if (swatches != null) {
                swatchMemory.put(track.id, swatches)
                index?.rememberSwatches(track.id, swatches)
            }
        }
        val art = Art(bitmap.asImageBitmap(), (bitmap.byteCount / 1024).coerceAtLeast(1), swatches)
        memory.put(key(track.id, px), art)
        if (writeDisk) CoroutineScope(Dispatchers.IO).launch { writeDisk(track.id, px, bitmap) }
        return art
    }

    /**
     * Cover colours, own quantiser (v6.2).
     *
     * v6.1 asked AndroidX Palette for vibrantSwatch / mutedSwatch. On a photographic cover that
     * picks a MINORITY accent - one bright petal, a logo corner - and mutedSwatch very often lands
     * on the same hue as vibrant, so three "different" shades collapsed into one. That is what made
     * the app look like it had a handful of canned palettes instead of reading the artwork.
     *
     * Here the thumbnail is walked at a stride, background-ish pixels are dropped, and the rest is
     * binned into 24 hue buckets weighted by coverage AND colourfulness. Circular mean per bucket,
     * so a hue straddling the 0/360 seam is not averaged into its own complement.
     *
     * Cost: ~4096 samples, no allocation per pixel, 1-3 ms on a mid-range phone, once per track for
     * the lifetime of the install (the result is persisted next to the thumbnail).
     */
    private fun extract(source: Bitmap): ArtSwatches? {
        val soft = source.softwareForSampling() ?: return null
        return try {
            sample(soft)
        } finally {
            if (soft !== source) soft.recycle()
        }
    }

    /**
     * `getPixels` throws on `Config.HARDWARE`, and `ContentResolver.loadThumbnail` is entitled to
     * hand one back - it decodes through `ImageDecoder`, which prefers a hardware buffer whenever
     * the device supports it. The old code called `getPixels` straight away inside `runCatching`, so
     * on those devices the throw was swallowed, `extract` returned null, and the UI quietly fell
     * back to the canned palette. That is exactly the "only a handful of fixed palettes" symptom.
     *
     * `Bitmap.copy` to a software config is the one operation that is documented to work on a
     * hardware bitmap, so it is used here rather than `createScaledBitmap`, which would go through a
     * software `Canvas` and throw "Software rendering doesn't support hardware bitmaps".
     */
    private fun Bitmap.softwareForSampling(): Bitmap? {
        val cfg = config
        val needsCopy = cfg == null ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && cfg == Bitmap.Config.HARDWARE)
        if (!needsCopy) return this
        return runCatching { copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
    }

    private fun sample(bitmap: Bitmap): ArtSwatches? = runCatching {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return@runCatching null

        val step = (maxOf(w, h) / SAMPLE_SIDE).coerceAtLeast(1)
        // One row at a time. A 512x512 cover would otherwise need a 1 MB IntArray up front while
        // only every `step`-th row is ever read - on a 3381-track library that is a lot of churn in
        // the young generation for nothing.
        val rowPixels = IntArray(w)

        val weight = FloatArray(HUE_BINS)
        val cosSum = FloatArray(HUE_BINS)
        val sinSum = FloatArray(HUE_BINS)
        val satSum = FloatArray(HUE_BINS)
        val valSum = FloatArray(HUE_BINS)
        val darkWeight = FloatArray(HUE_BINS)
        val darkCos = FloatArray(HUE_BINS)
        val darkSin = FloatArray(HUE_BINS)
        val darkSat = FloatArray(HUE_BINS)
        val darkVal = FloatArray(HUE_BINS)
        var greyWeight = 0f
        var greyValue = 0f

        val hsv = FloatArray(3)
        var y = 0
        while (y < h) {
            bitmap.getPixels(rowPixels, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                android.graphics.Color.colorToHSV(rowPixels[x], hsv)
                val hue = hsv[0]
                val sat = hsv[1]
                val value = hsv[2]
                if (sat < 0.10f || value < 0.05f || (value > 0.97f && sat < 0.16f)) {
                    // Letterboxing, white studio backgrounds and black bars are not identity.
                    greyWeight += 1f
                    greyValue += value
                } else {
                    // Colourfulness times a mid-brightness preference: a colour the eye actually
                    // reads sits away from both ends of the brightness range.
                    val wgt = (0.35f + sat) * (0.45f + 1.10f * value * (1f - 0.55f * value))
                    val bin = ((hue / 360f) * HUE_BINS).toInt().coerceIn(0, HUE_BINS - 1)
                    val rad = hue * 0.017453292f
                    val dx = cos(rad) * wgt
                    val dy = sin(rad) * wgt
                    weight[bin] += wgt
                    cosSum[bin] += dx
                    sinSum[bin] += dy
                    satSum[bin] += sat * wgt
                    valSum[bin] += value * wgt
                    if (value < 0.48f) {
                        darkWeight[bin] += wgt
                        darkCos[bin] += dx
                        darkSin[bin] += dy
                        darkSat[bin] += sat * wgt
                        darkVal[bin] += value * wgt
                    }
                }
                x += step
            }
            y += step
        }

        // A dominant colour that straddles a bucket edge used to lose to its own other half.
        // 15 deg buckets, and a cover's main hue is almost never centred in one: the red sleeve
        // split across two buckets could be beaten by a smaller, perfectly centred accent, and the
        // hue that survived was the edge of the real one. Buckets are now scored together with
        // their two neighbours, and the winner's hue, saturation and value come from all three.
        fun spread(bin: Int, ws: FloatArray): Float =
            ws[(bin + HUE_BINS - 1) % HUE_BINS] + ws[bin] + ws[(bin + 1) % HUE_BINS]

        fun merge(bin: Int, ws: FloatArray, xs: FloatArray, ys: FloatArray, ss: FloatArray, vs: FloatArray): FloatArray {
            val prev = (bin + HUE_BINS - 1) % HUE_BINS
            val next = (bin + 1) % HUE_BINS
            val w = ws[prev] + ws[bin] + ws[next]
            var deg = atan2(ys[prev] + ys[bin] + ys[next], xs[prev] + xs[bin] + xs[next]) * 57.29578f
            if (deg < 0f) deg += 360f
            val safe = if (w > 0f) w else 1f
            return floatArrayOf(deg, (ss[prev] + ss[bin] + ss[next]) / safe, (vs[prev] + vs[bin] + vs[next]) / safe, w)
        }

        var best = -1
        var bestSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (weight[i] <= 0f) continue
            val score = spread(i, weight)
            if (best < 0 || score > bestSpread) { best = i; bestSpread = score }
        }
        if (best < 0) {
            // Monochrome cover: hand back a neutral triple. Inventing a hue out of sensor noise is
            // exactly how a black-and-white sleeve used to end up painting the screen teal.
            val level = (if (greyWeight > 0f) greyValue / greyWeight else 0.24f).coerceIn(0.10f, 0.62f)
            val grey = Color(android.graphics.Color.HSVToColor(floatArrayOf(0f, 0f, level)))
            return@runCatching ArtSwatches(grey, grey, grey)
        }

        fun hueOf(bin: Int, xs: FloatArray, ys: FloatArray): Float {
            var deg = atan2(ys[bin], xs[bin]) * 57.29578f
            if (deg < 0f) deg += 360f
            return deg
        }
        fun colour(hue: Float, sat: Float, value: Float) = Color(
            android.graphics.Color.HSVToColor(
                floatArrayOf(
                    ((hue % 360f) + 360f) % 360f,
                    sat.coerceIn(0f, 1f),
                    value.coerceIn(0.06f, 1f)
                )
            )
        )

        val primary = merge(best, weight, cosSum, sinSum, satSum, valSum)
        val primaryHue = primary[0]
        val primarySat = primary[1]
        val primaryVal = primary[2]

        // A second hue at least MIN_HUE_GAP away, so the backdrop actually travels across the
        // screen the way the reference does instead of being one flat wash. The gap is wider than
        // a bucket, so this can never pick a neighbour that was just merged into the primary.
        var second = -1
        var secondSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (i == best || weight[i] <= 0f) continue
            val delta = abs(((hueOf(i, cosSum, sinSum) - primaryHue + 540f) % 360f) - 180f)
            if (delta < MIN_HUE_GAP) continue
            val score = spread(i, weight)
            if (second < 0 || score > secondSpread) { second = i; secondSpread = score }
        }
        var dark = -1
        var darkSpread = 0f
        for (i in 0 until HUE_BINS) {
            if (darkWeight[i] <= 0f) continue
            val score = spread(i, darkWeight)
            if (dark < 0 || score > darkSpread) { dark = i; darkSpread = score }
        }

        ArtSwatches(
            primary = colour(primaryHue, primarySat, primaryVal),
            secondary = if (second >= 0) {
                val s2 = merge(second, weight, cosSum, sinSum, satSum, valSum)
                colour(s2[0], s2[1], s2[2])
            } else {
                colour(primaryHue + 16f, primarySat * 0.90f, primaryVal * 0.82f)
            },
            // The deep swatch carries the DARK region's own saturation, not the primary's. It drives
            // the top and bottom of the backdrop, and borrowing a vivid primary's saturation is what
            // made the ends of the gradient scream on photographic covers.
            deep = if (dark >= 0) {
                val d2 = merge(dark, darkWeight, darkCos, darkSin, darkSat, darkVal)
                colour(d2[0], d2[1], d2[2])
            } else {
                colour(primaryHue - 10f, primarySat * 0.85f, primaryVal * 0.50f)
            }
        )
    }.getOrNull()

    // ---------------- sources ----------------

    private fun fromArtworkUri(context: Context, track: TrackEntity, px: Int): Bitmap? {
        val artwork = track.artworkUri ?: return null
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(artwork))?.use { decode(it.readBytes(), px) }
        }.getOrNull()
    }

    private fun fromThumbnail(context: Context, track: TrackEntity, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            context.contentResolver.loadThumbnail(Uri.parse(track.uri), android.util.Size(px, px), null)
        }.getOrNull()
    }

    private suspend fun fromEmbedded(context: Context, track: TrackEntity, px: Int): Bitmap? =
        slowGate.withPermit {
            var guard = 0
            while (isBusy() && guard < 60) { delay(80); guard++ }
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(track.uri))
                        retriever.embeddedPicture
                    } finally {
                        runCatching { retriever.release() }
                    }
                }.getOrNull()
            } ?: return@withPermit null
            decode(bytes, px)
        }

    // ---------------- disk ----------------

    private val hexDigits = "0123456789abcdef".toCharArray()

    /**
     * Cache file names, memoised.
     *
     * The old version ran a full `String.format` per byte - twenty of them - plus a fresh SHA-1
     * instance, and it did that for EVERY track on every isSettled/read/write. On a 3400 track
     * library the indexing pass alone paid it ten thousand times. Manual hex over a memoised
     * digest is roughly two orders of magnitude cheaper and allocates one String per track, once.
     */
    private val nameCache = LruCache<String, String>(4096)

    private fun hashOf(id: String): String {
        nameCache.get(id)?.let { return it }
        val digest = MessageDigest.getInstance("SHA-1").digest(id.toByteArray())
        val chars = CharArray(digest.size * 2)
        for (i in digest.indices) {
            val value = digest[i].toInt() and 0xFF
            chars[i * 2] = hexDigits[value ushr 4]
            chars[i * 2 + 1] = hexDigits[value and 0x0F]
        }
        val hex = String(chars)
        nameCache.put(id, hex)
        return hex
    }

    private fun fileFor(id: String, px: Int): File? {
        val base = dir ?: return null
        return File(base, "${hashOf(id)}-$px.webp")
    }

    private fun readDisk(id: String, px: Int): Bitmap? {
        val file = fileFor(id, px)?.takeIf { it.exists() } ?: return null
        val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
        val bitmap = runCatching { BitmapFactory.decodeFile(file.absolutePath, options) }.getOrNull()
        if (bitmap == null) runCatching { file.delete() }
        return bitmap
    }

    private fun writeDisk(id: String, px: Int, bitmap: Bitmap) {
        val file = fileFor(id, px) ?: return
        runCatching {
            val tmp = File(file.absolutePath + ".tmp")
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            }
            tmp.outputStream().use { bitmap.compress(format, 82, it) }
            if (!tmp.renameTo(file)) tmp.delete()
        }
    }

    private fun prune(base: File) {
        runCatching {
            val files = base.listFiles() ?: return
            var total = files.sumOf { it.length() }
            val cap = 40L * 1024 * 1024
            if (total <= cap) return
            files.sortedBy { it.lastModified() }.forEach { file ->
                if (total <= cap / 2) return
                total -= file.length()
                file.delete()
            }
        }
    }

    private fun decode(bytes: ByteArray, px: Int): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        var sample = 1
        while (largest / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }.getOrNull()
    }
}

/**
 * Walks the library in the background and pays the expensive cover probe once per file, writing
 * both the thumbnail and the extracted colours to disk. Pauses whenever a list is being scrolled,
 * so it can never compete with the finger.
 */
object ArtworkPrefetcher {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastTracks: List<TrackEntity> = emptyList()
    private var appContext: Context? = null

    /**
     * Where the user is actually looking. The pass used to start at track 0 and walk to the end,
     * so scrolling to track 2000 meant waiting for 2000 covers you will never see before the ones
     * on screen were even queued - which is why the list "never finished loading" on a big library.
     */
    @Volatile private var focus = 0

    fun focusOn(index: Int) {
        if (index >= 0) focus = index
    }

    fun submit(context: Context, tracks: List<TrackEntity>) {
        job?.cancel()
        if (tracks.isEmpty()) return
        val app = context.applicationContext
        appContext = app
        lastTracks = tracks
        job = scope.launch {
            val total = tracks.size
            val taken = BooleanArray(total)
            var processed = 0
            var done = 0
            while (processed < total) {
                if (!isActive) return@launch
                // Re-aimed on every item, not once at the start: the window the user is looking at
                // is always served next, wherever they scrolled to in the meantime.
                val aim = focus.coerceIn(0, total - 1)
                var index = -1
                var probe = aim
                var steps = 0
                while (steps < total) {
                    if (!taken[probe]) { index = probe; break }
                    probe = (probe + 1) % total
                    steps++
                }
                if (index < 0) break
                taken[index] = true
                processed++
                val track = tracks[index]
                if (ArtworkCache.isSettled(track.id)) continue
                while (ArtworkCache.isBusy()) {
                    if (!isActive) return@launch
                    delay(160)
                }
                ArtworkCache.load(app, track, ARTWORK_ROW_PX, allowSlow = true)
                done++
                if (done % 24 == 0) ArtworkCache.flushIndex()
                delay(8)
            }
            ArtworkCache.flushIndex()
            ArtworkCache.pruneNow()
        }
    }

    fun stop() { job?.cancel(); job = null }

    /**
     * Restarts indexing after the app comes back to the foreground. Without this the composition
     * survives backgrounding, the LaunchedEffect never re-runs, and indexing would stay dead for
     * the rest of the process.
     */
    fun resume() {
        val app = appContext ?: return
        if (job?.isActive == true) return
        submit(app, lastTracks)
    }
}

/**
 * Placeholder colours for a track with no cover at all.
 *
 * v5 picked one of eight hardcoded pairs, so in a folder of 400 untagged files every eighth tile
 * was literally the same green. The hue is now derived from the file identity across the full
 * circle: two different tracks share a shade only by accident, and the player backdrop built from
 * this pair is unique too.
 */
fun fallbackSwatches(track: TrackEntity?): ArtSwatches {
    val id = track?.id ?: "zizi"
    var hash = 0x811C9DC5.toInt()
    for (index in id.indices) hash = (hash xor id[index].code) * 0x01000193
    val hue = ((hash ushr 8) % 360 + 360) % 360
    val drift = 18 + ((hash ushr 3) and 0x1F)
    fun hsv(h: Int, s: Float, v: Float) =
        Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360) + 360f) % 360f, s, v)))
    // Neutral BY DESIGN (v6.2). Until now a track with no cover got a fully saturated hue, so an
    // untagged folder turned the library into a paintbox and the player backdrop into lime green.
    // Only a few degrees of hue and a hint of saturation survive: tiles stay distinguishable from
    // each other, the screen still reads as the graphite base.
    return ArtSwatches(
        primary = hsv(hue, 0.11f, 0.44f),
        secondary = hsv(hue + drift, 0.13f, 0.32f),
        deep = hsv(hue - drift / 2, 0.15f, 0.21f)
    )
}

fun fallbackColors(track: TrackEntity?): Pair<Color, Color> {
    val swatches = fallbackSwatches(track)
    return swatches.primary to swatches.deep
}

/**
 * Deliberately NOT produceState.
 *
 * produceState keeps the previous value when its keys change - it only restarts the producer. In a
 * recycled list row, and in the player when the track changes, that means the widget would keep
 * showing the cover of the *previous* track until the new one finished decoding, and if the new
 * track had no cover at all it would show the wrong artwork forever.
 *
 * remember(key) re-seeds synchronously from the in-memory cache instead: a cached cover appears on
 * the very first frame (no grey flash while scrolling) and a cache miss starts exactly one load.
 */
@Composable
fun rememberArtwork(track: TrackEntity?, maxPx: Int, allowSlow: Boolean = false): Art? {
    val context = LocalContext.current
    val id = track?.id
    // 6.7: reading the revision here is what lets a cover fetched from the internet appear without
    // the row being scrolled off screen. See ArtworkCache.revision for why it is a snapshot Int.
    val revision = ArtworkCache.revision
    val holder = remember(id, maxPx, revision) { mutableStateOf(ArtworkCache.peekExact(track, maxPx)) }

    // 6.6: the coroutine is not merely a no-op for a settled row - it is not STARTED.
    //
    // 6.5 always entered the LaunchedEffect and returned early inside it. Entering costs a
    // coroutine, a Job, a continuation and a cancellation on the way out, per row, per flick. On
    // this library most rows are settled (a cached cover, or a file already known to have none),
    // so the overwhelming majority of those coroutines existed only to return immediately. The
    // decision is now taken during composition and the effect is skipped entirely.
    val needsLoad = track != null && holder.value == null && !ArtworkCache.hasNoArt(track)
    if (needsLoad) {
        LaunchedEffect(id, maxPx, allowSlow) {
            val target = track ?: return@LaunchedEffect
            if (holder.value != null) return@LaunchedEffect
            // A row that is only passing under the finger must not decode at all. Rows that are
            // still on screen when the scroll settles decode ~60 ms later; rows that flew past are
            // cancelled by leaving the composition and cost nothing. The guard is bounded so a
            // stuck busy flag can never leave the list grey.
            if (!allowSlow) ArtworkCache.awaitIdle()
            holder.value = ArtworkCache.load(context, target, maxPx, allowSlow)
        }
    }
    // While a bigger size decodes, the smaller thumbnail of the same cover stands in for it.
    return holder.value ?: ArtworkCache.peek(track, maxPx)
}

/** Colours that drive the whole backdrop. Never blocks: falls back to the per-track hue. */
@Composable
fun rememberArtSwatches(track: TrackEntity?, enabled: Boolean): ArtSwatches? {
    if (!enabled) return null
    val art = rememberArtwork(track, ARTWORK_ROW_PX, allowSlow = true)
    val fallback = remember(track?.id) { fallbackSwatches(track) }
    val cached = ArtworkCache.peekSwatches(track)
    return when {
        art?.swatches != null -> art.swatches
        cached != null -> cached
        track == null -> null
        else -> fallback
    }
}

/**
 * The eighth note that stands in for a missing cover, built out of primitives.
 *
 * Not an ImageVector: a vector drawable is parsed into a node tree and re-rendered per tile, and
 * this is the one glyph in the app that can appear on 3000 rows. Two rounded quads and an ellipse
 * cost one cached Path.
 *
 * Laid out in units of the note's own height inside a 0.86 x 1.0 box, then centred.
 */
private fun notePath(height: Float, canvas: Size): Path {
    val h = height
    val w = h * 0.86f
    val left = (canvas.width - w) / 2f
    val topY = (canvas.height - h) / 2f
    fun x(v: Float) = left + v * h
    fun y(v: Float) = topY + v * h

    return Path().apply {
        // Stem.
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                left = x(0.46f),
                top = y(0.02f),
                right = x(0.57f),
                bottom = y(0.84f),
                radiusX = h * 0.055f,
                radiusY = h * 0.055f
            )
        )
        // Head: an oval, tilted the way a printed note is, which is what makes it read as music
        // rather than as a lollipop.
        addOval(
            androidx.compose.ui.geometry.Rect(
                left = x(0.02f),
                top = y(0.66f),
                right = x(0.50f),
                bottom = y(0.99f)
            )
        )
        // Flag.
        moveTo(x(0.57f), y(0.02f))
        quadraticBezierTo(x(0.90f), y(0.12f), x(0.84f), y(0.42f))
        quadraticBezierTo(x(0.80f), y(0.18f), x(0.57f), y(0.17f))
        close()
    }
}

private fun DrawScope.drawNote(path: Path, color: Color) {
    drawPath(path, color)
}

@Composable
fun TrackArtwork(
    track: TrackEntity?,
    maxPx: Int,
    modifier: Modifier = Modifier,
    glyphSize: Int = 44,
    allowSlow: Boolean = false
) {
    val art = rememberArtwork(track, maxPx, allowSlow)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art.image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val colors = remember(track?.id) { fallbackSwatches(track) }
            // 6.5: a music glyph, not a letter.
            //
            // The monogram was a stand-in from v6, and it is the single most obvious "this was
            // never designed" detail in the app: a wall of tiles reading A, K, N, C, P is a
            // debugging aid, not an interface. Every reference player draws a note.
            //
            // It also pays for itself on the scroll path. The letter was a Text, so a row without
            // a cover cost a full text layout - measure, shape, cache lookup - every time it was
            // recycled, and an untagged folder is nothing but rows without covers. The gradient,
            // the path and the colours are now built once per tile SIZE inside drawWithCache: the
            // row draws two cached objects and allocates nothing per frame.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawWithCache {
                        val brush = Brush.linearGradient(
                            listOf(colors.secondary, colors.deep),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height)
                        )
                        // The caller's glyph hint is honoured, but never allowed to grow past a
                        // proportion of the tile: one rule for a 48 dp row and a 300 dp cover.
                        val noteHeight = minOf(size.minDimension * 0.44f, glyphSize.dp.toPx() * 1.5f)
                        val path = notePath(noteHeight, size)
                        val glyphColor = Color.White.copy(alpha = 0.58f)
                        onDrawBehind {
                            drawRect(brush)
                            drawNote(path, glyphColor)
                        }
                    }
            )
        }
    }
}
