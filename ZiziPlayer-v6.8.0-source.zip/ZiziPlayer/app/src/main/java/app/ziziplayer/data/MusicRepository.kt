package app.ziziplayer.data

import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** SQLite refuses more than 999 bound variables in one statement; stay well below it. */
private const val DELETE_CHUNK = 400

class MusicRepository(
    private val context: Context,
    private val dao: MusicDao,
    private val settingsStore: SettingsStore,
    private val scanner: MusicScanner,
    private val playbackMemory: PlaybackMemory
) {
    val tracks = dao.observeTracks()
    val favoriteIds = dao.observeFavoriteIds().map { it.toSet() }
    val hiddenIds = dao.observeHiddenIds().map { it.toSet() }
    val playlists = dao.observePlaylists()
    val playlistCounts: Flow<Map<Long, Int>> = dao.observePlaylistCounts().map { list -> list.associate { it.playlistId to it.total } }
    val stats: Flow<Map<String, PlayStatEntity>> = dao.observeStats().map { list -> list.associateBy { it.trackId } }
    val settings = settingsStore.settings

    /* ------------------------------------------------------------------ fetched metadata (6.7) */

    private val enricher = MetadataEnricher(context, dao, settingsStore)

    /** Only accepted matches, keyed by track id, for the overlay in [app.ziziplayer.ui.MainViewModel]. */
    val meta: Flow<Map<String, TrackMetaEntity>> =
        dao.observeMatchedMeta().map { list -> list.associateBy { it.trackId } }

    val enrichProgress = enricher.progress

    fun startEnrichment(tracks: List<TrackEntity>, force: Boolean = false) = enricher.start(tracks, force)
    fun stopEnrichment() = enricher.stop()
    fun hasNetwork(): Boolean = enricher.hasNetwork()

    /** Manual re-check for one track from the track menu. */
    suspend fun refreshMeta(track: TrackEntity): Boolean = enricher.refreshOne(track)

    /** Which tracks already have lyrics on disk - drives the dot on the player's "Текст" button. */
    val lyricIds: Flow<Set<String>> = dao.lyricIds().map { it.toSet() }

    /** Manual catalogue picker (6.7): free-text search, and applying whatever the user chose. */
    suspend fun searchCatalog(query: String, durationMs: Long): List<RemoteMatch> =
        enricher.searchCatalog(query, durationMs)

    suspend fun applyMatch(track: TrackEntity, match: RemoteMatch): Boolean =
        enricher.applyMatch(track, match)

    suspend fun clearMetaCache() {
        enricher.clearCache()
        dao.clearLyrics()
    }

    /**
     * Lyrics for one track: database first, network only on a miss, and the miss itself is cached
     * so opening the sheet twice for a track with no lyrics costs one request, not two.
     *
     * Fetched lazily when the sheet is opened rather than in bulk with the covers - lyrics are read
     * for the handful of tracks someone actually sings along to, and pre-fetching 444 of them would
     * be ~2 MB of text nobody asked for.
     */
    suspend fun lyricsFor(track: TrackEntity, artistOverride: String?): LyricsEntity? {
        dao.lyrics(track.id)?.let { return it }
        if (!settings.first().lyricsFromNet) return null
        val asks = TrackQuery.asksFor(track)
        val artist = artistOverride?.takeIf { it.isNotBlank() }
            ?: asks.firstOrNull()?.artist
            ?: return null
        val title = asks.firstOrNull()?.title ?: return null
        val fetched = runCatching { RemoteMeta.lyrics(artist, title, track.durationMs) }.getOrNull()
        val row = LyricsEntity(
            trackId = track.id,
            synced = fetched?.first,
            plain = fetched?.second,
            source = if (fetched != null) "lrclib" else "",
            fetchedAt = System.currentTimeMillis(),
            missing = fetched == null
        )
        // A failed request is stored as "missing" too. Slightly pessimistic - a timeout gets the
        // same verdict as a genuine absence - which is why "Уточнить" clears lyrics as well.
        dao.upsertLyrics(row)
        return row
    }

    /**
     * Rebuilds the library.
     *
     * Order is load-bearing:
     *
     * 1. scan every source;
     * 2. **remap ids before anything is deleted** - the old rows are still in place, so the child
     *    tables can be moved onto the new keys while both ends of the mapping exist;
     * 3. upsert the fresh rows;
     * 4. delete the rows that no longer match a file;
     * 5. prune child rows whose track is gone.
     *
     * Step 5 used to be unreachable whenever nothing had gone stale (the function returned early),
     * so orphan favourites and playlist entries accumulated forever. It now always runs.
     *
     * [onProgress] is called from the scanner's worker threads.
     */
    suspend fun rescan(onProgress: (ScanProgress) -> Unit = {}) {
        val folders = settings.first().folderUris
        onProgress(ScanProgress(0, 0, "Поиск музыки"))

        val fromMediaStore = scanner.scanMediaStore()
        onProgress(ScanProgress(fromMediaStore.size, 0, "Папки"))

        // Handed to the scanner so unchanged files skip tag reading entirely.
        val known = if (folders.isEmpty()) emptyMap() else dao.allTracks().associateBy { it.id }

        val fromFolders = ArrayList<TrackEntity>()
        folders.forEach { folder ->
            val uri = runCatching { Uri.parse(folder) }.getOrNull() ?: return@forEach
            fromFolders += scanner.scanTree(uri, known) { done, total ->
                onProgress(ScanProgress(done, total, "Чтение тегов"))
            }
        }

        // MediaStore comes first, so when the same file is reachable both ways the richer row wins:
        // it carries album art and did not need a decoder. Deduplication is now by identity rather
        // than by the old "title|artist|duration" guess, which merged genuinely different tracks
        // that happened to share a name and length (live versions, remasters, sped-up edits - of
        // which this library has a great many).
        val all = (fromMediaStore + fromFolders).distinctBy { it.id }
        if (all.isEmpty()) return

        migrateLegacyIds(all)

        dao.upsertTracks(all)
        // Stale ids are computed here instead of inside SQL: see MusicDao.deleteTracks.
        val keep = HashSet<String>(all.size * 2)
        all.forEach { keep.add(it.id) }
        val stale = dao.allTrackIds().filterNot { keep.contains(it) }
        stale.chunked(DELETE_CHUNK).forEach { dao.deleteTracks(it) }
        pruneOrphans()
        onProgress(ScanProgress(all.size, all.size, "Готово"))
    }

    /**
     * Moves the user's data from the old provider-derived ids onto the content-derived ones, once.
     *
     * The work is bounded by what the user actually has, not by the library size: only ids that
     * appear in favourites, playlists, FX, hidden or stats are touched. A 3000-track library with 40
     * favourites and 3 playlists does a few dozen updates.
     *
     * The flag is set only after the remap completes, so a process death half way through means the
     * next launch simply tries again - the old rows are still there, and every UPDATE is idempotent.
     */
    private suspend fun migrateLegacyIds(scanned: List<TrackEntity>) {
        if (settingsStore.idsMigrated()) return
        val referenced = dao.referencedTrackIds().toHashSet()
        if (referenced.isNotEmpty()) {
            scanned.forEach { track ->
                val legacy = track.legacyId
                if (legacy != null && legacy != track.id && referenced.contains(legacy)) {
                    dao.remapTrackId(legacy, track.id)
                    playbackMemory.remapLastTrack(legacy, track.id)
                }
            }
        }
        settingsStore.setIdsMigrated()
    }

    /** Favourites, playlist entries, FX and stats that outlived their track. */
    private suspend fun pruneOrphans() {
        dao.pruneFavorites()
        dao.prunePlaylistTracks()
        dao.pruneFx()
        dao.pruneStats()
        dao.pruneHidden()
    }

    suspend fun addFolder(uri: Uri, onProgress: (ScanProgress) -> Unit = {}) {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        settingsStore.addFolder(uri)
        rescan(onProgress)
    }

    suspend fun removeFolder(uri: String, onProgress: (ScanProgress) -> Unit = {}) {
        settingsStore.removeFolder(uri)
        rescan(onProgress)
    }

    /** [isCurrentlyFavorite] is the state BEFORE the tap, so the call flips it. */
    suspend fun toggleFavorite(id: String, isCurrentlyFavorite: Boolean) {
        if (isCurrentlyFavorite) dao.unfavorite(id) else dao.favorite(FavoriteEntity(id))
    }

    suspend fun saveFx(fx: TrackFxEntity) = dao.saveFx(fx)
    suspend fun fx(id: String) = dao.fx(id) ?: TrackFxEntity(id)

    suspend fun createPlaylist(name: String) = dao.createPlaylist(PlaylistEntity(name = name))
    suspend fun addToPlaylist(playlistId: Long, trackId: String) =
        dao.addToPlaylist(PlaylistTrackEntity(playlistId, trackId, dao.nextPosition(playlistId)))
    suspend fun removeFromPlaylist(playlistId: Long, trackId: String) = dao.removeFromPlaylist(playlistId, trackId)
    suspend fun deletePlaylist(id: Long) {
        dao.clearPlaylist(id)
        dao.deletePlaylist(id)
    }
    suspend fun renamePlaylist(id: Long, name: String) = dao.renamePlaylist(id, name)
    suspend fun playlistTracks(playlistId: Long) = dao.playlistTracks(playlistId)
    fun observePlaylistTracks(playlistId: Long) = dao.observePlaylistTracks(playlistId)

    /** "Remove from my set": the track stays on the phone, it just never shows up again. */
    suspend fun hideTrack(id: String) = dao.hide(HiddenEntity(id))
    suspend fun unhideTrack(id: String) = dao.unhide(id)
    suspend fun clearHidden() = dao.clearHidden()

    suspend fun registerPlay(id: String) {
        dao.ensureStat(PlayStatEntity(id))
        dao.bumpStat(id, System.currentTimeMillis())
    }

    /** Forgets a row after its file is gone. */
    suspend fun forgetTrack(id: String) {
        dao.unfavorite(id)
        dao.deleteTrack(id)
    }

    /**
     * Deletes the real file. Android 11+ requires user confirmation for MediaStore items,
     * so we hand the IntentSender back to the activity instead of failing silently.
     */
    suspend fun requestFileDeletion(track: TrackEntity): IntentSender? {
        val uri = runCatching { Uri.parse(track.uri) }.getOrNull() ?: return null
        val resolver = context.contentResolver
        if (DocumentsContract.isDocumentUri(context, uri)) {
            runCatching { DocumentsContract.deleteDocument(resolver, uri) }
            forgetTrack(track.id)
            return null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return runCatching { MediaStore.createDeleteRequest(resolver, listOf(uri)).intentSender }.getOrNull()
        }
        runCatching { resolver.delete(uri, null, null) }
        forgetTrack(track.id)
        return null
    }

    suspend fun setTheme(theme: AppTheme) = settingsStore.setTheme(theme)
    suspend fun setDynamicAccent(value: Boolean) = settingsStore.setDynamicAccent(value)
    suspend fun setSkipSilence(value: Boolean) = settingsStore.setSkipSilence(value)
    suspend fun setEnrichFromNet(value: Boolean) = settingsStore.setEnrichFromNet(value)
    suspend fun setEnrichWifiOnly(value: Boolean) = settingsStore.setEnrichWifiOnly(value)
    suspend fun setLyricsFromNet(value: Boolean) = settingsStore.setLyricsFromNet(value)
    suspend fun setSortMode(value: SortMode) = settingsStore.setSortMode(value)
    /** Cheap, flow-free write: saving the position must never touch the library pipeline. */
    fun saveLastPosition(trackId: String, positionMs: Long) = playbackMemory.save(trackId, positionMs)
    fun lastTrackId(): String? = playbackMemory.lastTrackId()
    fun lastPositionMs(): Long = playbackMemory.lastPositionMs()
}
