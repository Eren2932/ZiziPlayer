package app.ziziplayer.data

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.net.URLEncoder

/**
 * ONE result of a network search: a track that is NOT on this phone.
 *
 * Deliberately a plain data class and NOT a Room entity. Nothing here is persisted by the search
 * itself: a search result is a rumour with a 30-minute shelf life (stream URLs are signed and
 * expire, hosts rotate), and writing rumours into `tracks` - the table the scanner owns and
 * REPLACEs on every rescan - is how a library grows ghost rows that point at dead URLs.
 *
 * [fullLength] is the whole honesty of this feature and is never guessed:
 *   true  - Audius / Jamendo: the artist published this track for free streaming. Whole track.
 *   false - iTunes / Deezer: a 30-second preview. Legal, public, keyless - and thirty seconds.
 * The UI must render the difference, always. A row that plays 30 s while looking like a full track
 * is the app lying to its user, and the user blames the app, not the licence.
 */
data class OnlineTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val streamUrl: String,
    val coverUrl: String?,
    val provider: String,
    val fullLength: Boolean
) {
    /**
     * The bridge to everything that already exists.
     *
     * PlayerController builds MediaItems from TrackEntity and takes `uri` and `artworkUri` as
     * strings - it never asks whether they are files. So an online track becomes a queue item,
     * a notification, a lock screen and a Bluetooth head unit for free: no new code in playback.
     *
     * The id is prefixed with the provider so it can never collide with a local id (a SHA-1 of
     * name+size, see TrackId) and so any layer can tell "this is not a file" with startsWith,
     * without a second table to consult. Everything keyed by track id - favourites, FX, play
     * stats - keeps working; the rows just belong to a track that lives on the internet.
     */
    fun asTrack(): TrackEntity = TrackEntity(
        id = id,
        uri = streamUrl,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        artworkUri = coverUrl,
        sourceFolder = providerLabel(provider),
        dateAdded = 0L
    )

    companion object {
        fun providerLabel(provider: String): String = when (provider) {
            "audius" -> "Audius"
            "jamendo" -> "Jamendo"
            "itunes" -> "iTunes · превью"
            "deezer" -> "Deezer · превью"
            else -> "Сеть"
        }
    }
}

/**
 * Search across catalogues that let a player stream them without a key and without pretending to
 * be a browser.
 *
 * WHAT THIS IS NOT. It is not a way to play any track that exists. Full-length streaming of
 * licensed music requires a licence - there is no keyless API for it and no honest way around it.
 * Two providers here publish full tracks because their artists chose to; two provide a 30-second
 * preview and are labelled as such in the UI. Anything beyond that (scraping a video site through
 * a public front-end) breaks the terms it depends on and stops working every few weeks, which is
 * worse for you than a feature that admits its limits.
 *
 * ORDER MATTERS. Full-length providers are asked first and their results sort first: a preview is
 * a consolation prize, not a peer.
 */
object OnlineCatalog {

    private const val APP_NAME = "ZiziPlayer"

    /* ------------------------------------------------------------- Audius host discovery */

    /**
     * Audius has no fixed API host: https://api.audius.co returns the list of currently healthy
     * discovery nodes, and any of them serves the whole API. Hard-coding one node means the
     * feature dies the day that node goes down - which for a community-run network is a matter of
     * when, not if.
     *
     * The chosen host is cached for the session and re-picked on failure, so a node that dies
     * mid-session costs one failed search, not the feature.
     */
    private val hostLock = Mutex()
    private var hosts: List<String> = emptyList()
    private var hostIndex = 0
    private var hostsFetchedAtMs = 0L
    private const val HOSTS_TTL_MS = 6 * 60 * 60 * 1000L

    private suspend fun host(): String? = hostLock.withLock {
        val fresh = hosts.isNotEmpty() &&
            System.currentTimeMillis() - hostsFetchedAtMs < HOSTS_TTL_MS
        if (!fresh) {
            val json = runCatching { RemoteMeta.fetchJson("https://api.audius.co") }.getOrNull()
            val array = json?.let { runCatching { JSONObject(it).optJSONArray("data") }.getOrNull() }
            val list = ArrayList<String>(8)
            if (array != null) {
                for (i in 0 until array.length()) {
                    array.optString(i)?.takeIf { it.startsWith("https://") }?.let { list.add(it) }
                }
            }
            if (list.isNotEmpty()) {
                hosts = list
                hostIndex = 0
                hostsFetchedAtMs = System.currentTimeMillis()
            }
        }
        hosts.getOrNull(hostIndex)
    }

    /** Called when a host answered badly: move to the next one, do not punish the user twice. */
    private suspend fun rotateHost() = hostLock.withLock {
        if (hosts.isNotEmpty()) hostIndex = (hostIndex + 1) % hosts.size
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    /* -------------------------------------------------------------------------- providers */

    /**
     * Audius: full tracks, no key, no registration. Its catalogue is where independent hip-hop and
     * electronic artists publish - which overlaps a Telegram-sourced rap library far better than
     * any "royalty-free" catalogue would.
     *
     * `is_streamable` is checked because a track can exist in the catalogue and refuse to stream
     * (artist-gated, premium, taken down). A row that cannot play must never reach the list.
     */
    suspend fun audius(query: String, limit: Int = 20): List<OnlineTrack> {
        val h = host() ?: return emptyList()
        val url = "$h/v1/tracks/search?query=${encode(query)}&limit=$limit&app_name=$APP_NAME"
        val json = runCatching { RemoteMeta.fetchJson(url) }.getOrElse { rotateHost(); return emptyList() }
            ?: return emptyList()
        val data = runCatching { JSONObject(json).optJSONArray("data") }.getOrNull() ?: return emptyList()
        val out = ArrayList<OnlineTrack>(data.length())
        for (i in 0 until data.length()) {
            val item = data.optJSONObject(i) ?: continue
            if (item.has("is_streamable") && !item.optBoolean("is_streamable", true)) continue
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
            val title = item.optString("title").takeIf { it.isNotBlank() } ?: continue
            val artist = item.optJSONObject("user")?.optString("name")?.takeIf { it.isNotBlank() }
                ?: item.optJSONObject("user")?.optString("handle")?.takeIf { it.isNotBlank() }
                ?: continue
            val art = item.optJSONObject("artwork")
            out.add(
                OnlineTrack(
                    id = "audius:$id",
                    title = title,
                    artist = artist,
                    album = item.optString("genre").orEmpty(),
                    durationMs = item.optLong("duration", 0L) * 1000L,
                    // The stream endpoint 302s to a CDN object. ExoPlayer follows it; we must not
                    // resolve it ourselves and cache the result - the redirect target is signed
                    // and expires, the endpoint is not.
                    streamUrl = "$h/v1/tracks/$id/stream?app_name=$APP_NAME",
                    coverUrl = art?.optString("480x480")?.takeIf { it.isNotBlank() }
                        ?: art?.optString("150x150")?.takeIf { it.isNotBlank() },
                    provider = "audius",
                    fullLength = true
                )
            )
        }
        return out
    }

    /**
     * Jamendo: full tracks, Creative Commons, but it DOES need a client_id (free, one form).
     * Therefore it is opt-in: empty id means the provider is simply not asked. No key is ever
     * baked into this source file - see the project rule about secrets.
     */
    suspend fun jamendo(query: String, clientId: String, limit: Int = 20): List<OnlineTrack> {
        if (clientId.isBlank()) return emptyList()
        val url = "https://api.jamendo.com/v3.0/tracks/?client_id=${encode(clientId)}" +
            "&format=json&limit=$limit&include=musicinfo&audioformat=mp32&search=${encode(query)}"
        val json = runCatching { RemoteMeta.fetchJson(url) }.getOrNull() ?: return emptyList()
        val data = runCatching { JSONObject(json).optJSONArray("results") }.getOrNull() ?: return emptyList()
        val out = ArrayList<OnlineTrack>(data.length())
        for (i in 0 until data.length()) {
            val item = data.optJSONObject(i) ?: continue
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
            val title = item.optString("name").takeIf { it.isNotBlank() } ?: continue
            val artist = item.optString("artist_name").takeIf { it.isNotBlank() } ?: continue
            val audio = item.optString("audio").takeIf { it.isNotBlank() } ?: continue
            out.add(
                OnlineTrack(
                    id = "jamendo:$id",
                    title = title,
                    artist = artist,
                    album = item.optString("album_name").orEmpty(),
                    durationMs = item.optLong("duration", 0L) * 1000L,
                    streamUrl = audio,
                    coverUrl = item.optString("image").takeIf { it.isNotBlank() },
                    provider = "jamendo",
                    fullLength = true
                )
            )
        }
        return out
    }

    /* ----------------------------------------------------------------------------- search */

    /**
     * One human query -> one ordered list.
     *
     * Providers are asked in sequence, not in parallel, on purpose: RemoteMeta throttles per host,
     * a phone on mobile data has one radio, and four simultaneous requests on a weak connection
     * finish later than four sequential ones while making the first result appear later. Audius
     * first because it is the only one that can answer with a whole track.
     *
     * Deduplication is by provider id only. Two providers offering "the same" song are not the
     * same row: one may be a remix, a live take or a different master, and collapsing them by
     * artist+title would silently hide the full-length version behind a preview.
     */
    suspend fun search(query: String, jamendoClientId: String = ""): List<OnlineTrack> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        val out = ArrayList<OnlineTrack>(40)
        out.addAll(runCatching { audius(q) }.getOrDefault(emptyList()))
        out.addAll(runCatching { jamendo(q, jamendoClientId) }.getOrDefault(emptyList()))
        val seen = HashSet<String>(out.size)
        return out
            // The contract of this function, enforced rather than documented: nothing that is not
            // a whole track reaches the list. A provider added later cannot quietly smuggle a
            // 30-second preview into the results by forgetting a flag.
            .filter { it.fullLength && it.streamUrl.startsWith("https://") && seen.add(it.id) }
            .sortedBy { it.provider }
    }

    /**
     * Small derivative of a cover, for the list.
     *
     * Audius serves fixed-size variants under their own names, so the 150 px one costs a string
     * edit. Anything else falls through to the 6.7 helper, which knows iTunes, Deezer and CAA and
     * returns unknown shapes untouched.
     */
    fun thumb(url: String): String =
        if (url.contains("480x480")) url.replace("480x480", "150x150") else RemoteMeta.thumbUrl(url)
}
