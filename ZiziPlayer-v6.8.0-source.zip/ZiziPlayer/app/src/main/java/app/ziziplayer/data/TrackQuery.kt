package app.ziziplayer.data

import kotlin.math.abs

/**
 * Turns a local file into something a music catalogue can actually be asked about, and decides
 * whether what came back is the same song.
 *
 * This file is the whole quality of the feature. A metadata fetcher is not hard to write - it is
 * hard to write one that does not confidently attach the wrong cover. Every rule below exists
 * because a real filename in a real Telegram-sourced library breaks the naive version:
 *
 *   "Грибы, Симптом - Копы"                  two artists in one field, comma separated
 *   "narim - Copines (TikTok Edit)"          a bracketed suffix no catalogue has
 *   "KXNO1X, TREVOLX - MONTAGEM..."          latin capitals with a zero for an O
 *   "SEM DEMORA - Slowed"                    a pitched edit of a real track
 *   "01. Naruto - Hero's Come back"          a track number
 *   "wharoxmane - WANNABE TE..."             truncated by the source, not by us
 *   "AUD-20240312-WA0007"                    no information at all - must not be searched
 */
object TrackQuery {

    /** One thing to ask a provider. [loose] queries drop bracketed suffixes and features. */
    data class Ask(val artist: String?, val title: String, val loose: Boolean) {
        val term: String get() = if (artist.isNullOrBlank()) title else "$artist $title"
    }

    private val UNKNOWN_ARTISTS = setOf(
        "", "<unknown>", "unknown", "unknown artist", "неизвестный артист",
        "неизвестен", "various artists", "va"
    )

    /**
     * Bracketed content that is noise for a catalogue search. `remix` is NOT here: a remix is a
     * different recording with its own cover, and throwing the word away is how you end up
     * showing the original single's artwork for a track that sounds nothing like it.
     */
    private val NOISE = listOf(
        "official video", "official audio", "official music video", "official lyric video",
        "official", "lyrics", "lyric video", "audio", "video", "clip", "hd", "hq",
        "tiktok edit", "tiktok", "sped up", "speed up", "slowed", "slowed reverb",
        "reverb", "nightcore", "8d audio", "bass boosted", "extended", "free download",
        "x-minus", "muzmo", "y2mate", "mp3"
    )

    private val JUNK_NAME = Regex("^(aud|rec|voice|audio|track|file|video)[-_ ]?\\d{3,}", RegexOption.IGNORE_CASE)

    /**
     * The queries to try, best first. Empty means "do not ask anyone about this file" - a random
     * recorder filename with no artist has nothing to match on, and asking produces a confident
     * wrong answer, which is worse than a note glyph.
     */
    fun asksFor(track: TrackEntity): List<Ask> {
        val knownArtist = track.artist.takeIf { !UNKNOWN_ARTISTS.contains(it.trim().lowercase()) }?.trim()
        val raw = cleanFileNoise(track.title)
        if (raw.isBlank()) return emptyList()

        val split = splitArtistTitle(raw)
        val artist = (knownArtist ?: split?.first)?.takeIf { it.isNotBlank() }
        val title = (split?.second ?: raw).trim()
        if (title.isBlank()) return emptyList()
        // Nothing to go on: no artist anywhere, and the name itself is a camera/recorder id.
        if (artist == null && JUNK_NAME.containsMatchIn(title)) return emptyList()
        // A one-token title with no artist ("0_0", "intro") matches half the catalogue. Skip.
        if (artist == null && title.length < 6) return emptyList()

        val strictTitle = title
        val looseTitle = stripNoise(title)
        val out = ArrayList<Ask>(3)
        out.add(Ask(artist, strictTitle, loose = false))
        if (looseTitle.isNotBlank() && !looseTitle.equals(strictTitle, ignoreCase = true)) {
            out.add(Ask(artist, looseTitle, loose = true))
        }
        // Last resort: title only. Helps when the "artist" part of the filename is actually the
        // uploader ("home4circus, 1NZZiDENT - ..." style credits are hit or miss in catalogues).
        if (artist != null && looseTitle.length >= 8) out.add(Ask(null, looseTitle, loose = true))
        return out
    }

    /** File-level noise: extension, track number, underscores, doubled spaces. */
    private fun cleanFileNoise(input: String): String {
        var s = input.trim()
        s = s.removeSuffix(".mp3").removeSuffix(".m4a").removeSuffix(".flac").removeSuffix(".ogg")
            .removeSuffix(".opus").removeSuffix(".wav").removeSuffix(".aac")
        s = s.replace('_', ' ')
        s = Regex("^\\s*\\d{1,3}\\s*[.)\\-]\\s+").replace(s, "")
        s = Regex("\\s{2,}").replace(s, " ")
        return s.trim()
    }

    /**
     * "Artist - Title". Only the FIRST separator splits, and only if both sides survive: a title
     * like "Amor Na Praia - Slowed - Extended" must not become artist "Amor Na Praia - Slowed".
     */
    private fun splitArtistTitle(input: String): Pair<String, String>? {
        val separators = listOf(" - ", " – ", " — ", " -- ")
        for (sep in separators) {
            val at = input.indexOf(sep)
            if (at <= 0) continue
            val left = input.substring(0, at).trim()
            val right = input.substring(at + sep.length).trim()
            if (left.length in 1..64 && right.isNotEmpty()) return left to right
        }
        return null
    }

    /** Drops bracketed noise, trailing "feat. X", and leftover empty brackets. */
    fun stripNoise(input: String): String {
        var s = input
        s = Regex("[\\[({][^\\])}]*[\\])}]").replace(s) { match ->
            val inner = match.value.trim('[', ']', '(', ')', '{', '}').trim().lowercase()
            if (NOISE.any { inner.contains(it) } || inner.startsWith("prod")) "" else match.value
        }
        s = Regex("\\s(feat\\.?|ft\\.?|featuring)\\s.*$", RegexOption.IGNORE_CASE).replace(s, "")
        NOISE.forEach { noise ->
            s = Regex("\\s*[-–—|]\\s*" + Regex.escape(noise) + "\\s*$", RegexOption.IGNORE_CASE).replace(s, "")
        }
        s = Regex("\\s{2,}").replace(s, " ")
        return s.trim().trim('-', '–', '—', '|', ',').trim()
    }

    /* ------------------------------------------------------------------ matching */

    /**
     * Comparison key: case folded, punctuation dropped, `ё` folded onto `е`, and the handful of
     * latin glyphs people substitute for cyrillic ones folded too, so "КОПЫ" and "KОПЫ" (with a
     * latin K) are the same word. Digits are kept - "0_0" and "808" are titles.
     */
    fun norm(input: String): String {
        val sb = StringBuilder(input.length)
        for (raw in input.lowercase()) {
            val c = when (raw) {
                'ё' -> 'е'
                'a' -> 'а'; 'e' -> 'е'; 'o' -> 'о'; 'p' -> 'р'; 'c' -> 'с'
                'x' -> 'х'; 'y' -> 'у'; 'k' -> 'к'; 'm' -> 'м'; 't' -> 'т'; 'h' -> 'н'
                else -> raw
            }
            if (c.isLetterOrDigit()) sb.append(c)
            else if (sb.isNotEmpty() && sb.last() != ' ') sb.append(' ')
        }
        return sb.toString().trim()
    }

    private fun tokens(input: String): List<String> =
        norm(input).split(' ').filter { it.isNotBlank() }

    /**
     * 0..1 similarity of two names. Token containment rather than plain Jaccard, because a
     * catalogue title is routinely LONGER than ours ("Копы" vs "Копы (feat. ...)"), and Jaccard
     * punishes that as hard as a real mismatch.
     */
    fun similarity(a: String, b: String): Float {
        val left = tokens(a)
        val right = tokens(b)
        if (left.isEmpty() || right.isEmpty()) return 0f
        val used = BooleanArray(right.size)
        var hits = 0f
        for (token in left) {
            var bestIndex = -1
            var best = 0f
            right.forEachIndexed { index, other ->
                if (used[index]) return@forEachIndexed
                val s = tokenScore(token, other)
                if (s > best) { best = s; bestIndex = index }
            }
            if (bestIndex >= 0 && best > 0.6f) { used[bestIndex] = true; hits += best }
        }
        // Denominator is the SHORTER side plus a quarter of the surplus: extra words in the
        // catalogue entry cost something, but not everything.
        val shorter = minOf(left.size, right.size).toFloat()
        val surplus = abs(left.size - right.size) * 0.25f
        return (hits / (shorter + surplus)).coerceIn(0f, 1f)
    }

    private fun tokenScore(a: String, b: String): Float {
        if (a == b) return 1f
        if (a.length >= 4 && b.length >= 4) {
            if (a.startsWith(b) || b.startsWith(a)) return 0.9f
            val distance = editDistance(a, b, 2)
            if (distance == 1) return 0.85f
            if (distance == 2 && minOf(a.length, b.length) >= 6) return 0.7f
        }
        return 0f
    }

    /** Bounded Levenshtein - bails out as soon as it cannot be within [limit]. */
    private fun editDistance(a: String, b: String, limit: Int): Int {
        if (abs(a.length - b.length) > limit) return limit + 1
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            var rowBest = current[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost)
                if (current[j] < rowBest) rowBest = current[j]
            }
            if (rowBest > limit) return limit + 1
            val swap = previous; previous = current; current = swap
        }
        return previous[b.length]
    }

    /**
     * Final verdict for one candidate, 0..1000.
     *
     * Duration is the honest tiebreaker: names lie constantly, length does not. A slowed edit is
     * 20-40 % longer than the original, which is exactly the case where the title matches
     * perfectly and the cover would be wrong - so a large duration gap can veto a perfect name
     * match, and a close duration can rescue a mangled one.
     */
    fun score(
        ask: Ask,
        localDurationMs: Long,
        candidateArtist: String,
        candidateTitle: String,
        candidateDurationMs: Long
    ): Int {
        val titleSim = similarity(ask.title, candidateTitle)
        if (titleSim < 0.45f) return 0
        val artistSim = if (ask.artist.isNullOrBlank()) -1f else similarity(ask.artist, candidateArtist)

        var value = when {
            artistSim < 0f -> titleSim * 0.72f          // title-only ask: capped, never a strong match
            else -> titleSim * 0.62f + artistSim * 0.38f
        }
        // Artist known on both sides and clearly different: almost certainly a cover version or a
        // same-titled song. Refuse.
        if (artistSim in 0f..0.35f) value *= 0.45f

        if (localDurationMs > 1000L && candidateDurationMs > 1000L) {
            val gap = abs(localDurationMs - candidateDurationMs)
            value += when {
                gap <= 2_000L -> 0.14f
                gap <= 5_000L -> 0.07f
                gap <= 12_000L -> 0f
                gap <= 30_000L -> -0.16f
                else -> -0.34f
            }
        } else {
            // No duration to check against: stay suspicious.
            value -= 0.04f
        }
        if (ask.loose) value -= 0.03f
        return (value.coerceIn(0f, 1f) * 1000).toInt()
    }

    /**
     * The bar a candidate has to clear. Set from the cost of being wrong, not from a wish for
     * coverage: a wrong cover on a track the user knows by heart reads as a broken app, while a
     * missing cover just reads as a file with no cover.
     */
    const val ACCEPT_SCORE = 640
}
