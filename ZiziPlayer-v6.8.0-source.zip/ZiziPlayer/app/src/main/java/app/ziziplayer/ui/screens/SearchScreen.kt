package app.ziziplayer.ui.screens

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.data.OnlineCatalog
import app.ziziplayer.data.OnlineTrack
import app.ziziplayer.data.RemoteMeta
import app.ziziplayer.ui.OnlineUiState
import app.ziziplayer.ui.SearchScope
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Search in the network (6.8).
 *
 * The one honest sentence about this screen: it only ever shows tracks that play in full. The
 * 30-second previews iTunes and Deezer hand out are not here at all - not greyed out, not at the
 * bottom of the list, not behind a flag. A shorter list where everything plays beats a longer list
 * where half the rows die at 0:30 and the user blames the app.
 *
 * Those two providers keep doing what they are good at: naming and illustrating the files that are
 * already on the phone (6.7). They are simply not a source of playback.
 */

/**
 * Where the text in the search field goes: our own files, or the catalogues.
 *
 * A fifth chip in the filter row was the obvious move and it is wrong: five equal weights inside
 * 360 dp forces "Плейлисты" to truncate, and a scrollable row was already tried and reverted in
 * 6.4 because nothing hints that a row of chips can be dragged. The scope belongs to the search
 * field anyway - it is a property of the query, not a section of the library.
 */
@Composable
internal fun SearchScopeRow(current: SearchScope, onPick: (SearchScope) -> Unit) {
    val p = LocalPalette.current
    val colors = remember(p.chip, p.text, p.accent, p.onAccent) {
        ChipColors(p.chip, p.text, p.accent, p.onAccent)
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        ScopeChip("В библиотеке", current == SearchScope.LIBRARY, colors, Modifier.weight(1f)) {
            onPick(SearchScope.LIBRARY)
        }
        ScopeChip("В сети", current == SearchScope.NET, colors, Modifier.weight(1f)) {
            onPick(SearchScope.NET)
        }
    }
}

@Composable
private fun ScopeChip(
    label: String,
    active: Boolean,
    colors: ChipColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(38.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(if (active) colors.activeBackground else colors.background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (active) colors.activeContent else colors.content,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

/**
 * The results list.
 *
 * SEARCH IS EXPLICIT, NOT PER-KEYSTROKE. The library search filters an in-memory list, so running
 * it on every character is free. This one costs a round trip to a discovery node per character,
 * and the 6.7 rule stands: fifteen requests per typed letter to public keyless APIs is how an app
 * gets its users rate-limited. So the query arrives here debounced from the field, and nothing
 * happens until the button is pressed - the button is also what tells the user that this list is
 * not their library and that asking has a cost.
 */
@Composable
internal fun OnlineSearchList(
    query: String,
    state: OnlineUiState,
    hasMiniPlayer: Boolean,
    onSearch: (String) -> Unit,
    onPlay: (OnlineTrack) -> Unit,
    onDownload: (OnlineTrack) -> Unit
) {
    val p = LocalPalette.current
    val trimmed = query.trim()
    val stale = trimmed.length >= 2 && trimmed != state.query

    Column(Modifier.fillMaxSize()) {
        if (stale || (trimmed.length >= 2 && state.results.isEmpty() && !state.loading && !state.asked)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .height(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.accent)
                    .clickable { onSearch(trimmed) }
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, null, tint = p.onAccent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Искать «$trimmed» в сети",
                    color = p.onAccent,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        when {
            state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = p.accent, strokeWidth = 3.dp)
                    Spacer(Modifier.height(14.dp))
                    Text("Спрашиваем каталоги…", color = p.subtext, fontSize = 14.sp)
                }
            }
            state.error != null -> CenterHint(state.error)
            trimmed.length < 2 -> CenterHint(
                "Здесь ищутся треки, которых нет на телефоне.\n" +
                    "Только полные версии — Audius и Jamendo.\nНайденное можно слушать и сохранить в Music."
            )
            state.asked && state.results.isEmpty() -> CenterHint(
                "Ничего не нашлось.\nВ этих каталогах публикуют сами артисты, " +
                    "поэтому мейнстрима здесь может не быть вовсе."
            )
            else -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    top = 4.dp,
                    bottom = if (hasMiniPlayer) 96.dp else 24.dp
                )
            ) {
                items(state.results, key = { it.id }) { track ->
                    OnlineRow(
                        track = track,
                        downloading = track.id in state.downloading,
                        downloaded = track.id in state.downloaded,
                        onPlay = { onPlay(track) },
                        onDownload = { onDownload(track) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CenterHint(text: String) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize().padding(horizontal = 34.dp), contentAlignment = Alignment.Center) {
        Text(text, color = p.subtext, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

/** 56 dp row, same geometry as the library list, so the two never feel like different apps. */
@Composable
private fun OnlineRow(
    track: OnlineTrack,
    downloading: Boolean,
    downloaded: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clickable(onClick = onPlay)
            .padding(start = 14.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteThumb(track.coverUrl, 48)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = p.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                // Provider and length on the same line on purpose: length is what tells a remix or
                // a live take from the version the user has in mind, and the provider is the answer
                // to "where is this coming from" that a streaming list owes its user.
                text = buildString {
                    append(track.artist)
                    if (track.durationMs > 0) append(" · ").append(formatTime(track.durationMs))
                    append(" · ").append(OnlineTrack.providerLabel(track.provider))
                },
                color = p.subtext,
                fontSize = 12.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        when {
            downloading -> Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = p.accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            }
            downloaded -> Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Check, null, tint = p.accent, modifier = Modifier.size(22.dp))
            }
            else -> RoundIconButton(
                icon = Icons.Filled.Download,
                tint = p.subtext,
                background = Color.Transparent,
                size = 44,
                iconSize = 22,
                onClick = onDownload
            )
        }
    }
}

/**
 * Cover for one result row.
 *
 * Memory only, 48 entries, and deliberately NOT the disk artwork cache the library draws from.
 * Same argument as the manual picker in 6.7: nothing has been chosen yet, and writing twenty
 * rejected search results into the cache the library reads means someone else's cover appearing
 * on a local file later. A search is not a decision.
 */
private val thumbs = LruCache<String, ImageBitmap>(48)

@Composable
private fun RemoteThumb(url: String?, size: Int) {
    val p = LocalPalette.current
    var image by remember(url) { mutableStateOf(url?.let { thumbs.get(it) }) }

    LaunchedEffect(url) {
        if (url == null || image != null) return@LaunchedEffect
        val bytes = runCatching { RemoteMeta.fetchImage(OnlineCatalog.thumb(url)) }.getOrNull()
            ?: return@LaunchedEffect
        val decoded = withContext(Dispatchers.Default) {
            runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull()
        } ?: return@LaunchedEffect
        thumbs.put(url, decoded)
        image = decoded
    }

    Box(
        Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(p.chip),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = image
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Filled.MusicNote, null, tint = p.subtext, modifier = Modifier.size((size / 2).dp))
        }
    }
}
