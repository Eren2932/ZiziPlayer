@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.ziziplayer.ui.screens

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.AppTheme
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.RemoteMatch
import app.ziziplayer.data.RemoteMeta
import app.ziziplayer.data.SortMode
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ARTWORK_ROW_PX
import app.ziziplayer.ui.components.ArtworkCache
import app.ziziplayer.ui.components.EqualizerBars
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.formatTime
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.basePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.withContext
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
private fun SheetTitle(text: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, bottom = 10.dp)) {
        Text(text, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (subtitle != null) Text(subtitle, color = p.subtext, fontSize = 13.sp, maxLines = 1)
    }
}

/**
 * [scrollable] exists for the queue. A LazyColumn nested inside a verticalScroll parent is the
 * classic Compose performance trap: the two scrollables fight over the same gesture and the lazy
 * list loses most of its item reuse, so a 100 track queue scrolled worse than the 3000 track
 * library. The queue passes false and drives its own LazyColumn.
 */
@Composable
private fun ZiziSheetScaffold(
    onDismiss: () -> Unit,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        contentColor = p.text,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        dragHandle = {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(p.subtext.copy(alpha = 0.45f)))
            }
        }
    ) {
        // Content scrolls: the settings sheet is taller than a phone screen in landscape and the
        // v5 version simply clipped the last rows away.
        Column(
            Modifier
                .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(bottom = 26.dp),
            content = content
        )
    }
}

/* ------------------------------------------------------------------ speed / pitch */

@Composable
fun FxSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var speed by remember(track.id) { mutableFloatStateOf(1f) }
    var semitones by remember(track.id) { mutableFloatStateOf(0f) }
    var reverb by remember(track.id) { mutableIntStateOf(0) }

    LaunchedEffect(track.id) {
        val fx = vm.loadFx(track.id)
        speed = fx.speed
        semitones = (12f * (kotlin.math.ln(fx.pitch.coerceAtLeast(0.01f)) / kotlin.math.ln(2f)))
        reverb = fx.reverb
    }

    fun apply() {
        val pitch = 2f.pow(semitones / 12f)
        vm.saveFx(track.id, speed, pitch, reverb)
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Скорость и тональность", track.title)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Скорость", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("×%.2f".format(speed), color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = speed,
                onValueChange = { speed = (it * 100).roundToInt() / 100f },
                onValueChangeFinished = { apply() },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тональность", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    (if (semitones >= 0) "+" else "") + "%.1f полутона".format(semitones),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = semitones,
                onValueChange = { semitones = (it * 2).roundToInt() / 2f },
                onValueChangeFinished = { apply() },
                valueRange = -7f..7f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Реверб", color = p.subtext, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$reverb%", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = reverb.toFloat(),
                onValueChange = { reverb = it.roundToInt() },
                onValueChangeFinished = { apply() },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.chip)
            )
            Spacer(Modifier.height(6.dp))
            Text("Пресеты", color = p.subtext, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                val presets = listOf(
                    Triple("Обычный", 1f, 0f),
                    Triple("Slowed", 0.85f, -1.5f),
                    Triple("Deep slow", 0.78f, -3f),
                    Triple("Daycore", 0.9f, -2f),
                    Triple("Nightcore", 1.25f, 3f),
                    Triple("Speed up", 1.35f, 0f)
                )
                presets.forEach { (name, presetSpeed, presetPitch) ->
                    val active = speed == presetSpeed && semitones == presetPitch
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (active) p.accent else p.chip)
                            .clickable {
                                speed = presetSpeed
                                semitones = presetPitch
                                if (name == "Обычный") reverb = 0
                                apply()
                            }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(name, color = if (active) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Настройки сохраняются для этого трека — в следующий раз он включится уже так.",
                color = p.subtext, fontSize = 12.sp
            )
        }
    }
}

/* ------------------------------------------------------------------ sleep timer */

/**
 * Seven identical rows with the same bedtime icon, one per duration, was a scroll to pick a
 * number. It is a keypad now: four across, two rows, the running one highlighted.
 */
@Composable
fun SleepSheet(current: Int?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val options = remember { listOf(10, 15, 20, 30, 45, 60, 90, 120) }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Таймер сна", if (current != null) "Осталось $current мин" else "Выключен")
        SheetCard {
            Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                options.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { minutes ->
                            // Highlights only the timer that is actually counting down: a running
                            // timer of 30 min shows "осталось 12", so an exact match is the honest
                            // test and nothing lights up once it has started ticking.
                            val active = current == minutes
                            Box(
                                Modifier
                                    .weight(1f)
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (active) p.accent else p.chip.copy(alpha = 0.45f))
                                    .clickable { onPick(minutes); onDismiss() }
                                    .padding(vertical = 14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "$minutes",
                                    color = if (active) p.onAccent else p.text,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Text("минут", color = p.subtext, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
            }
        }
        if (current != null) {
            SheetCard {
                SheetRow(
                    icon = Icons.Filled.Close,
                    label = "Выключить таймер",
                    subtitle = "Музыка не остановится сама",
                    tint = Color(0xFFFF6B6B),
                    onClick = { onPick(null); onDismiss() }
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ playlist picker */

@Composable
fun PlaylistPickerSheet(
    playlists: List<PlaylistEntity>,
    onPick: (Long) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var newName by remember { mutableStateOf("") }
    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Добавить в плейлист", if (playlists.isEmpty()) "Пока ни одного — создайте ниже" else null)
        if (playlists.isNotEmpty()) SheetCard {
            playlists.forEachIndexed { index, playlist ->
                if (index > 0) RowDivider()
                SheetRow(
                    icon = Icons.Filled.QueueMusic,
                    label = playlist.name,
                    chevron = true,
                    onClick = { onPick(playlist.id); onDismiss() }
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Новый плейлист", color = p.subtext) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip,
                    cursorColor = p.accent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (newName.isNotBlank()) { onCreate(newName); newName = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)
            ) { Text("Создать") }
        }
    }
}

/* ------------------------------------------------------------------ track menu */

/**
 * The sheet behind the three dots (rebuilt in 6.6).
 *
 * What was wrong with it, concretely:
 *   - eight rows of identical weight, so "В избранное" and "Удалить файл с устройства" looked the
 *     same and the two things people actually want were the hardest to hit;
 *   - the file's own facts (folder, length, plays) were dumped as one grey line BELOW the delete
 *     buttons, i.e. at the very bottom of the sheet, under the most dangerous controls;
 *   - the warning "Файл останется на устройстве..." floated between two rows belonging to neither,
 *     which is what made the whole sheet read as unfinished;
 *   - "Таймер сна" from the library did nothing at all - the callback only closed the sheet;
 *   - "Скорость и тональность" from the library did not open the FX sheet: it started the track
 *     and threw you into the player;
 *   - `plays` was hardcoded to 0 at both call sites, so the play counter never showed;
 *   - tapping the heart closed the sheet, so you never saw the state you had just changed.
 *
 * Now: identity at the top, four tiles for the frequent actions, queue and track sections as
 * cards, and destructive actions alone in their own card with their consequence written inside the
 * row instead of next to it.
 */
@Composable
fun TrackMenuSheet(
    track: TrackEntity,
    favorite: Boolean,
    plays: Int,
    lastPlayedAt: Long,
    sleepMinutesLeft: Int?,
    inPlaylist: PlaylistEntity?,
    /** Which catalogue the shown artist/cover came from, or null when it came from the file. */
    metaSource: String?,
    onDismiss: () -> Unit,
    onPlayNow: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onFx: () -> Unit,
    onSleep: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHide: () -> Unit,
    onDeleteFile: () -> Unit,
    onShare: () -> Unit,
    onLyrics: () -> Unit,
    onRefreshMeta: () -> Unit,
    onCatalogSearch: () -> Unit
) {
    val p = LocalPalette.current
    val danger = Color(0xFFFF6B6B)
    // Built once per track, not on every recomposition of the sheet (the heart toggle recomposes
    // it, and string building plus a joinToString is not something to repeat for a decoration).
    val meta = remember(track.id, plays) {
        buildList {
            add(track.sourceFolder)
            add(formatTime(track.durationMs))
            if (track.sizeBytes > 0L) add("%.1f МБ".format(track.sizeBytes / 1048576f))
            if (plays > 0) add(playsLabel(plays))
        }.joinToString(" · ")
    }

    ZiziSheetScaffold(onDismiss) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                glyphSize = 22,
                modifier = Modifier.size(60.dp).clip(RoundedCornerShape(15.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track.title,
                    color = p.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 19.sp,
                    // Two lines here on purpose: this is the one place in the app where the user
                    // asked "which track is this menu about?", and a truncated answer is no answer.
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(track.artist, color = p.subtext, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                Text(
                    meta,
                    color = p.subtext.copy(alpha = 0.72f),
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickAction(
                icon = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                label = if (favorite) "В избранном" else "Избранное",
                active = favorite,
                modifier = Modifier.weight(1f),
                onClick = onToggleFavorite
            )
            QuickAction(Icons.Filled.PlaylistAdd, "В плейлист", false, Modifier.weight(1f), onAddToPlaylist)
            QuickAction(Icons.Filled.Speed, "Скорость", false, Modifier.weight(1f), onFx)
            QuickAction(Icons.Filled.Share, "Поделиться", false, Modifier.weight(1f), onShare)
        }

        SheetCard("Воспроизведение") {
            SheetRow(
                icon = Icons.Filled.PlayArrow,
                label = "Слушать сейчас",
                subtitle = "Откроет плеер и начнёт с этого трека",
                onClick = onPlayNow
            )
            RowDivider()
            SheetRow(
                icon = Icons.Filled.PlaylistPlay,
                label = "Играть следующим",
                subtitle = "Встанет сразу после текущего трека",
                onClick = onPlayNext
            )
            RowDivider()
            SheetRow(
                icon = Icons.Filled.AddToQueue,
                label = "В конец очереди",
                onClick = onAddToQueue
            )
        }

        SheetCard("Трек") {
            SheetRow(
                icon = Icons.Filled.Bedtime,
                label = "Таймер сна",
                subtitle = if (sleepMinutesLeft != null) "Осталось $sleepMinutesLeft мин" else "Выключен",
                trailingText = sleepMinutesLeft?.let { "$it мин" },
                chevron = sleepMinutesLeft == null,
                onClick = onSleep
            )
            if (lastPlayedAt > 0L) {
                RowDivider()
                SheetRow(
                    icon = Icons.Filled.History,
                    label = "Последнее прослушивание",
                    subtitle = remember(lastPlayedAt) { relativeTime(lastPlayedAt) }
                )
            }
            RowDivider()
            SheetRow(
                icon = Icons.Filled.Article,
                label = "Текст песни",
                subtitle = "Синхронный, если он есть",
                chevron = true,
                onClick = onLyrics
            )
            RowDivider()
            // Shows where the current artist/cover came from, and offers to ask again.
            //
            // Naming the source is not decoration: it is the difference between "the app renamed my
            // track" and "Deezer thinks this is X". When the answer is wrong, the user can see who
            // to disbelieve.
            SheetRow(
                icon = Icons.Filled.CloudDownload,
                label = if (metaSource == null) "Найти обложку и артиста" else "Уточнить обложку и артиста",
                subtitle = if (metaSource == null) "Спросит iTunes, Deezer и MusicBrainz"
                else "Сейчас данные из ${sourceLabel(metaSource)}",
                onClick = onRefreshMeta
            )
            RowDivider()
            // The escape hatch for everything the automatic matcher refuses to guess at. Placed
            // right under it, because "нашлось не то" and "не нашлось" both end up here.
            SheetRow(
                icon = Icons.Filled.Search,
                label = "Искать в каталоге вручную",
                subtitle = "Показать все ответы и выбрать нужный самому",
                chevron = true,
                onClick = onCatalogSearch
            )
            if (inPlaylist != null) {
                RowDivider()
                SheetRow(
                    icon = Icons.Filled.PlaylistRemove,
                    label = "Убрать из «${inPlaylist.name}»",
                    subtitle = "Только из плейлиста — файл и библиотека не меняются",
                    onClick = onRemoveFromPlaylist
                )
            }
        }

        // Destructive actions live alone, in their own card, tinted, with the consequence written
        // inside the row. The old sheet put a loose paragraph between the two delete rows and left
        // the reader to guess which one it described.
        SheetCard("Удаление") {
            SheetRow(
                icon = Icons.Filled.VisibilityOff,
                label = "Скрыть из Zizi",
                subtitle = "Файл останется на устройстве, вернуть можно в настройках",
                tint = danger,
                onClick = onHide
            )
            RowDivider()
            SheetRow(
                icon = Icons.Filled.DeleteForever,
                label = "Удалить файл с устройства",
                subtitle = "Безвозвратно, вместе с самим файлом",
                tint = danger,
                onClick = onDeleteFile
            )
        }
    }
}

/** "сегодня" / "вчера" / "3 дня назад" / "12 марта" for the last-played line. */
private fun relativeTime(atMs: Long): String {
    val days = ((System.currentTimeMillis() - atMs) / 86_400_000L).toInt()
    return when {
        days <= 0 -> "сегодня"
        days == 1 -> "вчера"
        days < 7 -> "$days дн. назад"
        days < 31 -> "${days / 7} нед. назад"
        else -> java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale("ru")).format(java.util.Date(atMs))
    }
}

/* ------------------------------------------------------------------ queue */

@Composable
fun QueueSheet(
    tracks: List<TrackEntity>,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPick: (Int) -> Unit,
    onSaveAsPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Очередь", "${tracks.size} треков")
        Box(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.chip)
                .clickable(onClick = onSaveAsPlaylist)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Сохранить как плейлист", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(6.dp))
        // The queue opens straight at the track that is playing instead of at the top.
        val queueState = rememberLazyListState()
        // Same rule as the library list: while the finger moves, background indexing stands still.
        LaunchedEffect(queueState) {
            snapshotFlow { queueState.isScrollInProgress }.collectLatest { scrolling ->
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
        }
        LaunchedEffect(currentTrackId) {
            val index = tracks.indexOfFirst { it.id == currentTrackId }
            if (index > 1) queueState.scrollToItem((index - 1).coerceAtLeast(0))
        }
        LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = maxHeight),
            state = queueState
        ) {
            itemsIndexed(
                tracks,
                key = { _, item -> item.id },
                // A declared contentType lets the lazy layout reuse a row's whole subtree instead of
                // building a new one, and the fixed height below means no row is ever re-measured.
                contentType = { _, _ -> "queue" }
            ) { index, track ->
                val playing = track.id == currentTrackId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clickable { onPick(index) }
                        .background(if (playing) p.accent.copy(alpha = 0.10f) else Color.Transparent)
                        .padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        TrackArtwork(
                            track = track,
                            maxPx = ARTWORK_ROW_PX,
                            glyphSize = 16,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                        )
                        if (playing) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.48f)))
                            EqualizerBars(p.accent, isPlaying, Modifier.size(17.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            color = if (playing) p.accent else p.text,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(track.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(track.durationMs), color = p.subtext, fontSize = 12.sp)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ settings */

/**
 * ONE set of building blocks for every sheet in the app (6.6).
 *
 * Until now the settings sheet had cards, captions, icons in tinted squares and subtitles, while
 * the track menu - the sheet people actually open twenty times a day - was a flat stack of eight
 * identical rows with bare icons, a divider, and two paragraphs of loose grey text floating
 * between them. Same app, two different design languages, and the cheaper one was in front.
 * Everything below is now shared, so the two sheets cannot drift apart again.
 */
@Composable
private fun SheetSectionLabel(title: String) {
    val p = LocalPalette.current
    Text(
        text = title.uppercase(),
        color = p.subtext,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 26.dp, top = 16.dp, bottom = 8.dp)
    )
}

/** A titled card. [title] is optional so a card can also stand on its own. */
/**
 * Lyrics, synced to the audio when the source has timestamps.
 *
 * The parsing and the highlighting are the whole point: unsynced text in a bottom sheet is a
 * wall nobody reads, while a highlighted current line is the thing people open lyrics for.
 *
 * Two details that are easy to get wrong:
 *  - the current line is found by walking forward from the last known index, not by scanning the
 *    whole list on every tick. Playback ticks 4 times a second; an O(n) scan of 60 lines four
 *    times a second, recomposing as it goes, is exactly the kind of quiet waste that adds up.
 *  - auto-scroll only follows while the user is not touching the list. Yanking the text back
 *    under someone's finger because a line changed is the single most hated behaviour in every
 *    lyrics screen ever shipped.
 */
@Composable
fun LyricsSheet(vm: MainViewModel, track: TrackEntity, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var loading by remember(track.id) { mutableStateOf(true) }
    var lines by remember(track.id) { mutableStateOf<List<LyricLine>>(emptyList()) }
    var plain by remember(track.id) { mutableStateOf<String?>(null) }

    LaunchedEffect(track.id) {
        loading = true
        val row = vm.lyricsFor(track)
        lines = parseLrc(row?.synced)
        plain = row?.plain
        loading = false
    }

    val listState = rememberLazyListState()
    var active by remember(track.id) { mutableIntStateOf(-1) }

    // The position is collected inside an effect instead of with collectAsState, so a playback tick
    // four times a second does NOT recompose this sheet. Only an actual change of the current line
    // does - which is once every few seconds.
    LaunchedEffect(lines) {
        if (lines.isEmpty()) return@LaunchedEffect
        var cursor = -1
        vm.progress.collect { state ->
            val now = state.positionMs
            // Forward walk from where we were; only a seek backwards costs a rescan.
            if (cursor >= lines.size || (cursor >= 0 && lines[cursor].atMs > now)) cursor = -1
            if (cursor < 0) {
                cursor = lines.indexOfLast { it.atMs <= now }
            } else {
                while (cursor + 1 < lines.size && lines[cursor + 1].atMs <= now) cursor++
            }
            if (cursor != active) active = cursor
        }
    }

    LaunchedEffect(active) {
        if (active < 0 || lines.isEmpty()) return@LaunchedEffect
        if (listState.isScrollInProgress) return@LaunchedEffect
        // Two lines above the current one, so there is context rather than a line pinned to the top.
        listState.animateScrollToItem((active - 2).coerceAtLeast(0))
    }

    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Текст", track.title)
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 220.dp, max = (LocalConfiguration.current.screenHeightDp * 0.56f).dp)
        ) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = p.accent, strokeWidth = 2.5.dp)
                }
                lines.isNotEmpty() -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp)
                ) {
                    itemsIndexed(lines, key = { index, _ -> index }) { index, line ->
                        val current = index == active
                        Text(
                            line.text,
                            color = if (current) p.text else p.subtext.copy(alpha = 0.55f),
                            fontSize = if (current) 19.sp else 17.sp,
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                            lineHeight = 26.sp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        )
                    }
                }
                plain != null -> Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
                ) {
                    Text(
                        plain.orEmpty(),
                        color = p.text.copy(alpha = 0.86f),
                        fontSize = 16.sp,
                        lineHeight = 25.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Без синхронизации — источник не дал таймкоды",
                        color = p.subtext,
                        fontSize = 12.sp
                    )
                }
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Текста для этого трека не нашлось",
                        color = p.subtext,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Immutable
data class LyricLine(val atMs: Long, val text: String)

/**
 * LRC parser.
 *
 * Handles what the format actually contains in the wild, not what the spec says: several
 * timestamps on one line (a repeated chorus), `[mm:ss.xx]` and `[mm:ss.xxx]` and `[mm:ss]`,
 * metadata tags like `[ar: ...]` that must be skipped rather than parsed as time, and empty lines
 * that are real - they are the instrumental gaps and dropping them desynchronises everything after.
 */
internal fun parseLrc(raw: String?): List<LyricLine> {
    if (raw.isNullOrBlank()) return emptyList()
    val stamp = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
    val out = ArrayList<LyricLine>(64)
    raw.lineSequence().forEach { line ->
        val matches = stamp.findAll(line).toList()
        if (matches.isEmpty()) return@forEach
        val text = line.substring(matches.last().range.last + 1).trim()
        matches.forEach { match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: return@forEach
            val seconds = match.groupValues[2].toLongOrNull() ?: return@forEach
            val fraction = match.groupValues[3]
            val millis = when (fraction.length) {
                0 -> 0L
                1 -> (fraction.toLongOrNull() ?: 0L) * 100L
                2 -> (fraction.toLongOrNull() ?: 0L) * 10L
                else -> fraction.take(3).toLongOrNull() ?: 0L
            }
            out.add(LyricLine(minutes * 60_000L + seconds * 1_000L + millis, text))
        }
    }
    return out.sortedBy { it.atMs }
}

@Composable
private fun SheetCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    if (title != null) SheetSectionLabel(title)
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.chip.copy(alpha = 0.38f))
            .padding(vertical = 4.dp),
        content = content
    )
}

/**
 * Hairline between two rows of the same card, inset to start where the labels start.
 *
 * Without it a card of three rows reads as one grey slab with six lines of text in it: the eye has
 * nothing to separate "subtitle of row 1" from "label of row 2". Inset, not full width, because a
 * full-width rule would cut the icon column in half.
 */
@Composable
private fun RowDivider() {
    val p = LocalPalette.current
    HorizontalDivider(
        color = p.subtext.copy(alpha = 0.13f),
        thickness = 0.8.dp,
        modifier = Modifier.padding(start = 60.dp, end = 12.dp)
    )
}

/**
 * The one row type. An icon in a tinted square, a label, an optional subtitle that is allowed to
 * wrap to two tight lines, an optional trailing widget, an optional chevron.
 *
 * [tint] recolours label AND icon square together - a destructive row must not be a red word next
 * to an accent-coloured icon, which is exactly how the delete rows looked before.
 */
@Composable
private fun SheetRow(
    icon: ImageVector,
    label: String,
    subtitle: String? = null,
    trailingText: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: Color? = null,
    chevron: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val accent = tint ?: p.accent
    val labelColor = if (tint != null) tint else p.text
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = labelColor, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Spacer(Modifier.height(1.dp))
                Text(
                    subtitle,
                    color = p.subtext,
                    fontSize = 12.5.sp,
                    // Default line height on a 12.5 sp subtitle leaves a visible gap inside the
                    // row when it wraps, which is why the two-line subtitles looked detached from
                    // their own labels.
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailingText != null) {
            Spacer(Modifier.width(10.dp))
            Text(trailingText, color = p.subtext, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
        if (chevron) {
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = p.subtext.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SheetSwitch(icon: ImageVector, label: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    SheetRow(
        icon = icon,
        label = label,
        subtitle = subtitle,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                // The stock M3 switch is 52 dp wide and outweighed the row it belonged to.
                modifier = Modifier.scale(0.85f),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedTrackColor = p.chip,
                    uncheckedBorderColor = p.subtext.copy(alpha = 0.4f)
                )
            )
        }
    )
}

/**
 * Square tile for the four actions people came for. A tile carries its own state ([active]), which
 * a row cannot: "В избранном" is now visible without reading a sentence.
 */
@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val p = LocalPalette.current
    val content = if (active) p.onAccent else p.text
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (active) p.accent else p.chip.copy(alpha = 0.45f))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(7.dp))
        Text(
            label,
            color = content,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

/** "1 прослушивание" / "4 прослушивания" / "11 прослушиваний" - Russian plurals, done properly. */
private fun playsLabel(count: Int): String {
    val mod100 = count % 100
    val mod10 = count % 10
    val word = when {
        mod100 in 11..14 -> "прослушиваний"
        mod10 == 1 -> "прослушивание"
        mod10 in 2..4 -> "прослушивания"
        else -> "прослушиваний"
    }
    return "$count $word"
}

@Composable
fun SettingsSheet(vm: MainViewModel, state: LibraryUiState, onDismiss: () -> Unit, onPickFolder: () -> Unit) {
    val p = LocalPalette.current
    var sortOpen by remember { mutableStateOf(false) }
    val themeNames = remember {
        mapOf(
            AppTheme.GRAPHITE to "Графит",
            AppTheme.MIDNIGHT to "Полночь",
            AppTheme.AMOLED to "AMOLED",
            AppTheme.SUNSET to "Закат"
        )
    }
    val sortNames = remember {
        mapOf(
            SortMode.TITLE to "По названию",
            SortMode.ARTIST to "По исполнителю",
            SortMode.RECENT to "Сначала новые",
            SortMode.DURATION to "По длительности",
            SortMode.PLAYS to "Часто слушаю"
        )
    }

    ZiziSheetScaffold(onDismiss) {
        SheetTitle("Настройки", "${state.tracks.size} треков в библиотеке")

        SheetCard("Оформление") {
            // Four themes, four equal columns, no scroll.
            //
            // This was a horizontalScroll row of 76 dp cards: the fourth theme sat under the right
            // edge of the card, half visible, with nothing to say it could be dragged - it read as
            // a rendering bug. Four weighted columns always fit and always show all four.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppTheme.entries.forEach { theme ->
                    val active = state.settings.theme == theme
                    val preview = remember(theme) { basePalette(theme) }
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) p.accent.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable { vm.setTheme(theme) }
                            .padding(vertical = 7.dp, horizontal = 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(preview.background)
                                .then(
                                    if (active) Modifier.border(1.5.dp, p.accent, RoundedCornerShape(10.dp))
                                    else Modifier.border(1.dp, p.subtext.copy(alpha = 0.18f), RoundedCornerShape(10.dp))
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            themeNames[theme] ?: theme.name,
                            color = if (active) p.accent else p.subtext,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            RowDivider()
            SheetSwitch(
                icon = Icons.Filled.Palette,
                label = "Цвет из обложки",
                // Shortened so it stops wrapping next to the switch.
                subtitle = "Фон подхватывает оттенки обложки",
                checked = state.settings.accentFromArtwork,
                onChange = vm::setDynamicAccent
            )
        }

        // 6.7. Placed after "Оформление" and before "Библиотека" because it is the one section
        // that sends something off the device: it should be found on the way down, not hunted for.
        SheetCard("Интернет") {
            SheetSwitch(
                icon = Icons.Filled.CloudDownload,
                label = "Дополнять из интернета",
                subtitle = "Обложки и исполнители для треков без тегов — iTunes, Deezer, MusicBrainz",
                checked = state.settings.enrichFromNet,
                onChange = { vm.setEnrichFromNet(it) }
            )
            if (state.settings.enrichFromNet) {
                RowDivider()
                SheetSwitch(
                    icon = Icons.Filled.Wifi,
                    label = "Только по Wi-Fi",
                    subtitle = "Обложка весит 50–120 КБ, а их сотни",
                    checked = state.settings.enrichOnWifiOnly,
                    onChange = { vm.setEnrichWifiOnly(it) }
                )
                RowDivider()
                SheetSwitch(
                    icon = Icons.Filled.Article,
                    label = "Текст песен",
                    subtitle = "Загружается по запросу — когда открываешь текст",
                    checked = state.settings.lyricsFromNet,
                    onChange = { vm.setLyricsFromNet(it) }
                )
                RowDivider()
                val progress by vm.enrichProgress.collectAsStateWithLifecycle()
                SheetRow(
                    icon = if (progress.running) Icons.Filled.Sync else Icons.Filled.Search,
                    label = if (progress.running) "Ищу…" else "Найти сейчас",
                    subtitle = when {
                        progress.offline -> "Нет подходящего соединения"
                        progress.running -> "${progress.done} из ${progress.total} · нашлось ${progress.matched}"
                        progress.total > 0 -> "Проверено ${progress.total} · нашлось ${progress.matched}"
                        else -> "Пройдёт по трекам без обложки и исполнителя"
                    },
                    trailingText = if (progress.running) "стоп" else null,
                    onClick = { if (progress.running) vm.stopEnrichment() else vm.enrichNow() }
                )
                RowDivider()
                SheetRow(
                    icon = Icons.Filled.DeleteSweep,
                    label = "Очистить загруженное",
                    subtitle = "Вернёт исполнителей и обложки к тому, что в самих файлах",
                    onClick = { vm.clearMetaCache() }
                )
            }
        }

        SheetCard("Библиотека") {
            SheetRow(
                icon = Icons.Filled.SortByAlpha,
                label = "Сортировка",
                subtitle = sortNames[state.settings.sortMode],
                trailing = {
                    Icon(
                        if (sortOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = null,
                        tint = p.subtext,
                        modifier = Modifier.size(22.dp)
                    )
                },
                onClick = { sortOpen = !sortOpen }
            )
            if (sortOpen) {
                SortMode.entries.forEach { mode ->
                    val active = state.settings.sortMode == mode
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.setSortMode(mode) }
                            .padding(start = 60.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            sortNames[mode] ?: mode.name,
                            color = if (active) p.accent else p.text,
                            fontSize = 14.5.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (active) Icon(Icons.Filled.Check, null, tint = p.accent, modifier = Modifier.size(19.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
            RowDivider()
            SheetRow(
                icon = Icons.Filled.CreateNewFolder,
                label = "Папки с музыкой",
                subtitle = if (state.settings.folderUris.isEmpty()) "Ничего не подключено — Zizi видит только общую медиатеку"
                else "Подключено: ${state.settings.folderUris.size}",
                chevron = true,
                onClick = onPickFolder
            )
            state.settings.folderUris.forEach { uri ->
                // A connected folder is a chip with its own remove button, not a line of grey text
                // with a bare × floating at the end of it.
                Row(
                    Modifier.fillMaxWidth().padding(start = 60.dp, end = 12.dp, top = 1.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(p.chip.copy(alpha = 0.5f))
                            .padding(start = 9.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Folder, null, tint = p.subtext, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(
                            text = remember(uri) { prettyFolderName(uri) },
                            color = p.text.copy(alpha = 0.85f),
                            fontSize = 12.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Box(
                            Modifier
                                .size(26.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .clickable { vm.removeFolder(uri) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Close, null, tint = p.subtext, modifier = Modifier.size(14.dp)) }
                    }
                }
            }
            RowDivider()
            SheetRow(
                icon = Icons.Filled.Refresh,
                label = "Пересканировать",
                subtitle = if (state.scanning) "Идёт сканирование…" else "Найдено ${state.tracks.size} треков",
                onClick = vm::rescan
            )
            if (state.hiddenCount > 0) {
                RowDivider()
                SheetRow(
                    icon = Icons.Filled.Visibility,
                    label = "Вернуть скрытые треки",
                    subtitle = "Скрыто: ${state.hiddenCount}",
                    trailingText = "Вернуть",
                    onClick = vm::restoreAllHidden
                )
            }
        }

        SheetCard("Звук") {
            SheetSwitch(
                icon = Icons.Filled.GraphicEq,
                label = "Пропускать тишину",
                subtitle = "Убирает пустые паузы по краям трека",
                checked = state.settings.skipSilence,
                onChange = vm::setSkipSilence
            )
        }

        SheetCard("О приложении") {
            SheetRow(
                icon = Icons.Filled.Info,
                label = "ZiziPlayer ${app.ziziplayer.BuildConfig.VERSION_NAME}",
                subtitle = "Media3 · Compose · всё считается на устройстве"
            )
        }
        Spacer(Modifier.height(6.dp))
    }
}

/**
 * "content://com.android.externalstorage.documents/tree/primary%3AMusic%2FTelegram" is not a
 * folder name. substringAfterLast("/") returned the whole percent-encoded tree segment, so the
 * connected-folders list showed that entire string, clipped.
 */
private fun prettyFolderName(uri: String): String {
    val decoded = try { java.net.URLDecoder.decode(uri, "UTF-8") } catch (_: Exception) { uri }
    val tail = decoded.substringAfterLast(':').substringAfterLast('/')
    return tail.ifBlank { decoded }
}

/* ------------------------------------------------------------------ confirm */

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    title: String = "Переименовать",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.subtext,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.accent,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.chip
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Готово", color = p.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = p.text) } }
    )
}

/* ------------------------------------------------------------------ manual catalogue picker */

/**
 * Decoded thumbnails for the picker, shared across rows for as long as the process lives.
 *
 * Deliberately NOT the artwork disk cache: nothing here has been chosen yet, and writing fifteen
 * rejected covers into the cache that feeds the library would put wrong artwork on screen for
 * tracks the user never confirmed. This map is memory only, small, and cleared when it grows.
 */
private object CatalogThumbs {
    val cache = HashMap<String, ImageBitmap?>()
    /** Bounded by count rather than bytes: at 170 px a decoded entry is ~115 KB, so 40 is ~4.6 MB. */
    fun put(url: String, image: ImageBitmap?) {
        if (cache.size > 40) cache.clear()
        cache[url] = image
    }
}

@Composable
private fun CatalogThumb(url: String?, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    var image by remember(url) { mutableStateOf(url?.let { CatalogThumbs.cache[it] }) }
    LaunchedEffect(url) {
        if (url == null || CatalogThumbs.cache.containsKey(url)) return@LaunchedEffect
        // Rows are only composed while visible, so this fetches what is actually being looked at.
        // The small stagger keeps a fast scroll of the results from opening five sockets at once.
        delay(120)
        val decoded = withContext(Dispatchers.IO) {
            val bytes = runCatching { RemoteMeta.fetchImage(RemoteMeta.thumbUrl(url)) }.getOrNull()
            bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() }
        }
        CatalogThumbs.put(url, decoded)
        image = decoded
    }
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(p.chip.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = image
        if (bitmap != null) {
            Image(bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(
                if (url == null) Icons.Filled.MusicNote else Icons.Filled.CloudDownload,
                contentDescription = null,
                tint = p.subtext.copy(alpha = 0.55f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * "Искать в каталоге" - the human override for the automatic matcher.
 *
 * This screen exists because the automatic pass is deliberately conservative: it refuses weak
 * answers, and for a library of edits and rips that means a few hundred tracks it will never claim
 * to recognise. Refusing is right for a background job and useless for someone who knows exactly
 * what the track is. So here every answer is shown, weak ones included, sorted with covers first,
 * with the provider named on each row - and the user picks. Nothing is applied until a row is
 * tapped.
 *
 * The query is prefilled with the app's best reading of the file name rather than the raw title,
 * because "03_Artist - Title (Official Video).mp3" is not a search term, and making the user delete
 * the noise by hand on a phone keyboard is the kind of small cruelty that gets a feature abandoned.
 */
@Composable
fun CatalogSearchSheet(
    vm: MainViewModel,
    track: TrackEntity,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var query by remember(track.id) { mutableStateOf(vm.searchSeedFor(track)) }
    var results by remember(track.id) { mutableStateOf<List<RemoteMatch>?>(null) }
    var busy by remember(track.id) { mutableStateOf(false) }
    var offline by remember(track.id) { mutableStateOf(false) }
    var runs by remember(track.id) { mutableIntStateOf(0) }
    var chosen by remember(track.id) { mutableStateOf<String?>(null) }

    // Keyed on a counter, not on the text: searching on every keystroke is fifteen requests per
    // typed letter to three public APIs, one of which bans by IP for exactly that.
    LaunchedEffect(runs) {
        if (runs == 0) return@LaunchedEffect
        busy = true; offline = false
        val found = vm.searchCatalog(query, track.durationMs)
        offline = found == null
        results = found ?: emptyList()
        busy = false
    }

    ZiziSheetScaffold(onDismiss, scrollable = false) {
        SheetTitle("Искать в каталоге", track.title)

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Артист - название", color = p.subtext, fontSize = 14.sp) },
                textStyle = LocalTextStyle.current.copy(fontSize = 15.sp),
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { runs++ }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = p.accent,
                    focusedBorderColor = p.accent,
                    unfocusedBorderColor = p.subtext.copy(alpha = 0.35f)
                )
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.accent)
                    .clickable(enabled = !busy && query.trim().length >= 2) { runs++ },
                contentAlignment = Alignment.Center
            ) {
                if (busy) {
                    CircularProgressIndicator(color = p.onAccent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Filled.Search, contentDescription = "Искать", tint = p.onAccent, modifier = Modifier.size(22.dp))
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        val list = results
        when {
            offline -> CatalogHint("Нет соединения. Ответить может только интернет — включи сеть и попробуй снова.")
            list == null -> CatalogHint("Спросим iTunes, Deezer и MusicBrainz. Название можно поправить — так находится чаще.")
            busy -> CatalogHint("Ищем…")
            list.isEmpty() -> CatalogHint("Ничего не нашлось. Попробуй короче: только артист и одно слово из названия, без «slowed», «remix» и скобок.")
            else -> LazyColumn(
                // Bounded height on purpose: a LazyColumn needs a bound to stay lazy, and the sheet
                // must not grow past the screen on a phone in landscape.
                modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            ) {
                items(list, key = { "${it.source}|${it.artist}|${it.title}|${it.album}" }) { match ->
                    CatalogRow(
                        match = match,
                        picked = chosen == match.coverUrl.orEmpty() + match.title,
                        onClick = {
                            chosen = match.coverUrl.orEmpty() + match.title
                            vm.applyMatch(track, match)
                            onDismiss()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CatalogHint(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        color = p.subtext,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp)
    )
}

@Composable
private fun CatalogRow(match: RemoteMatch, picked: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (picked) p.accent.copy(alpha = 0.22f) else p.chip.copy(alpha = 0.34f))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CatalogThumb(match.coverUrl, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                match.title,
                color = p.text,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(match.artist, color = p.subtext, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(
                // Provider, album and length: the three things that let someone tell two nearly
                // identical answers apart. Length especially - it is how you spot the edit.
                buildList {
                    add(sourceLabel(match.source))
                    match.album?.takeIf { it.isNotBlank() }?.let { add(it) }
                    if (match.durationMs > 0L) add(formatTime(match.durationMs))
                }.joinToString(" · "),
                color = p.subtext.copy(alpha = 0.72f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (match.coverUrl == null) {
            Spacer(Modifier.width(8.dp))
            // Said out loud, because "why did nothing change?" after tapping a coverless answer is
            // a bug report the app can prevent with one word.
            Text("без обложки", color = p.subtext.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
        }
    }
}

/** Provider ids are internal; these are the names people know. */
internal fun sourceLabel(source: String): String = when (source) {
    "itunes" -> "iTunes"
    "deezer" -> "Deezer"
    "musicbrainz" -> "MusicBrainz"
    "lrclib" -> "lrclib"
    "" -> "из файла"
    else -> source
}
