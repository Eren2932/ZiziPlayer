package app.ziziplayer.ui

import android.view.KeyEvent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.Density
import androidx.test.platform.app.InstrumentationRegistry
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.screens.SearchTrackAction
import app.ziziplayer.ui.screens.SearchTrackMenuSheet
import kotlinx.coroutines.CompletableDeferred
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Real Compose/window tests. Must run on a device/emulator; portable checks do not run these. */
class SearchMenu6771UiTest {
    @get:Rule val compose = createComposeRule()
    private val track = RemoteTrack("dz", "1", "Unique song", "Artist")
    private fun actions() = (0..11).map { id ->
        SearchTrackAction("a$id", if (id == 11) "Сведения о треке" else "Action $id", ZiziIcons.Info) { }
    }
    private fun expandMenu() {
        compose.onNodeWithTag("search-track-menu-handle").performSemanticsAction(SemanticsActions.Expand) { it() }
        compose.waitForIdle()
    }
    private fun lastRowFullyVisible() {
        compose.onNodeWithTag("search-track-menu-actions").performScrollToNode(hasTestTag("search-track-action-a11"))
        compose.waitForIdle()
        compose.onNodeWithTag("search-track-action-a11").assertIsDisplayed()
        val row = compose.onNodeWithTag("search-track-action-a11").getUnclippedBoundsInRoot()
        val viewport = compose.onNodeWithTag("search-track-menu-actions").getUnclippedBoundsInRoot()
        val host = compose.onNodeWithTag("search-track-menu-host").getUnclippedBoundsInRoot()
        assertTrue("The entire last touch target must fit", row.height.value >= 58f - 1f)
        assertTrue("Last row top must be in the list", row.top.value >= viewport.top.value - 1f)
        assertTrue("Last row bottom must be in the list", row.bottom.value <= viewport.bottom.value + 1f)
        assertTrue("Viewport must end before system navigation", viewport.bottom.value <= host.bottom.value + 1f)
    }

    @Test fun completeMenuOpensWithoutPreparingAnything() {
        var preparations = 0
        compose.setContent {
            SearchTrackMenuSheet(track, actions(), onDismiss = {}, prepareAction = { action ->
                preparations++; action.run
            })
        }
        compose.waitForIdle()
        compose.onAllNodesWithTag("search-track-menu-host").assertCountEquals(1)
        compose.onNodeWithTag("search-track-action-a0").assertIsDisplayed()
        compose.onNodeWithText("Подготавливаем действия…").assertDoesNotExist()
        compose.runOnIdle { assertEquals(0, preparations) }
    }

    @Test fun slowPreparationKeepsOneWindowAndDoubleTapDispatchesOnce() {
        val gate = CompletableDeferred<Unit>()
        val open = mutableStateOf(true)
        var preparations = 0; var runs = 0; var dismisses = 0
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track,
                listOf(SearchTrackAction("a0", "Action", ZiziIcons.Info) { runs++ }),
                onDismiss = { dismisses++; open.value = false }, prepareAction = { action ->
                    preparations++; gate.await(); action.run
                })
        }
        compose.waitForIdle()
        val id = compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id
        compose.onNodeWithTag("search-track-action-a0").performTouchInput { click(); click() }
        compose.waitForIdle()
        compose.onAllNodesWithTag("search-track-menu-host").assertCountEquals(1)
        assertEquals(id, compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id)
        compose.runOnIdle { assertEquals(1, preparations); assertEquals(0, runs); assertEquals(0, dismisses); gate.complete(Unit) }
        compose.waitForIdle()
        compose.runOnIdle { assertEquals(1, runs); assertEquals(1, dismisses) }
        compose.onNodeWithTag("search-track-menu-host").assertDoesNotExist()
    }

    @Test fun failedPreparationStaysInSameMenuAndCanRetry() {
        val open = mutableStateOf(true)
        var preparations = 0; var runs = 0
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track,
                listOf(SearchTrackAction("a0", "Action", ZiziIcons.Info) { runs++ }),
                onDismiss = { open.value = false }, prepareAction = { action ->
                    preparations++
                    if (preparations == 1) throw IllegalStateException("Test database failure")
                    action.run
                })
        }
        compose.waitForIdle()
        val id = compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id
        compose.onNodeWithTag("search-track-action-a0").performClick()
        compose.onNodeWithTag("search-track-menu-error").assertIsDisplayed()
        assertEquals(id, compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id)
        compose.runOnIdle { assertEquals(0, runs) }
        compose.onNodeWithTag("search-track-menu-actions").performScrollToNode(hasTestTag("search-track-action-a0"))
        compose.onNodeWithTag("search-track-action-a0").performClick()
        compose.waitForIdle()
        compose.runOnIdle { assertEquals(2, preparations); assertEquals(1, runs) }
    }

    @Test fun backDuringPreparationCancelsWithoutRunningAction() {
        val gate = CompletableDeferred<Unit>()
        val open = mutableStateOf(true)
        var cancelled = false; var runs = 0; var dismisses = 0
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track,
                listOf(SearchTrackAction("a0", "Action", ZiziIcons.Info) { runs++ }),
                onDismiss = { dismisses++; open.value = false }, prepareAction = { action ->
                    try { gate.await(); action.run } finally { cancelled = !gate.isCompleted }
                })
        }
        compose.waitForIdle()
        compose.onNodeWithTag("search-track-action-a0").performClick()
        InstrumentationRegistry.getInstrumentation().sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
        compose.waitForIdle()
        compose.runOnIdle { assertTrue(cancelled); gate.complete(Unit); assertEquals(0, runs); assertEquals(1, dismisses) }
    }

    @Test fun lastRowFitsAtPartialAnchor() {
        compose.setContent { SearchTrackMenuSheet(track, actions(), onDismiss = {}) }
        compose.waitForIdle()
        val before = compose.onNodeWithTag("search-track-menu").fetchSemanticsNode().boundsInRoot.top
        lastRowFullyVisible()
        val after = compose.onNodeWithTag("search-track-menu").fetchSemanticsNode().boundsInRoot.top
        assertEquals(before, after, 1f)
    }

    @Test fun lastRowFitsAfterFullExpansion() {
        compose.setContent { SearchTrackMenuSheet(track, actions(), onDismiss = {}) }
        compose.waitForIdle()
        expandMenu()
        lastRowFullyVisible()
    }

    @Test fun largeTextScrollsHeaderAndKeepsLastActionReachable() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 2f)) {
                SearchTrackMenuSheet(track, actions(), onDismiss = {})
            }
        }
        compose.waitForIdle()
        expandMenu()
        lastRowFullyVisible()
        compose.onNodeWithTag("search-track-menu-header").assertIsNotDisplayed()
    }

    @Test fun liveActionUpdateDoesNotRemountOrResetExpandedList() {
        val changed = mutableStateOf(false)
        compose.setContent {
            SearchTrackMenuSheet(track, actions().map { action ->
                if (action.id == "a0") action.copy(label = if (changed.value) "Updated" else "Original") else action
            }, onDismiss = {})
        }
        compose.waitForIdle()
        expandMenu()
        lastRowFullyVisible()
        val id = compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id
        val top = compose.onNodeWithTag("search-track-action-a11").getUnclippedBoundsInRoot().top.value
        compose.runOnIdle { changed.value = true }
        compose.waitForIdle()
        assertEquals(id, compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().id)
        assertEquals(top, compose.onNodeWithTag("search-track-action-a11").getUnclippedBoundsInRoot().top.value, 1f)
    }

    @Test fun swipeDownDismissesExactlyOnce() {
        val open = mutableStateOf(true)
        var dismisses = 0
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track, actions(), onDismiss = { dismisses++; open.value = false })
        }
        compose.waitForIdle()
        expandMenu()
        val height = compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().boundsInRoot.height
        compose.onNodeWithTag("search-track-menu-handle").performTouchInput {
            swipe(center, Offset(center.x, center.y + height * 0.8f), durationMillis = 400)
        }
        compose.waitForIdle()
        compose.onNodeWithTag("search-track-menu-host").assertDoesNotExist()
        compose.runOnIdle { assertEquals(1, dismisses) }
    }
}
