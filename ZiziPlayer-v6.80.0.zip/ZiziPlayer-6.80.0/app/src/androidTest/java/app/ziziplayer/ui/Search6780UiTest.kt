package app.ziziplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.screens.SearchField
import app.ziziplayer.ui.screens.SuggestBody
import app.ziziplayer.ui.screens.SuggestRow
import app.ziziplayer.ui.screens.ZiziSheetScaffold
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import app.ziziplayer.ui.theme.ZiziModalSurface
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Actual Compose tests; require Android. Source contracts do not execute these tests. */
class Search6780UiTest {
    @get:Rule val compose = createComposeRule()
    private val track = RemoteTrack("dz", "1", "Montagem One", "Artist")
    private val album = RemoteCollection("dz", "album:2", RemoteKind.ALBUM, "Montagem Album", "Artist")

    @Test fun fillArrowDoesNotSubmitParentRow() {
        var fills = 0; var submits = 0
        compose.setContent { NeutralSurfaceTheme {
            SuggestRow(SearchSuggestionPolicy.Suggestion("montagem", false), "mon", { fills++ }, { submits++ })
        } }
        compose.onNodeWithContentDescription("Подставить запрос: montagem").performClick()
        compose.runOnIdle { assertEquals(1, fills); assertEquals(0, submits) }
        compose.onNodeWithText("montagem").performClick()
        compose.runOnIdle { assertEquals(1, fills); assertEquals(1, submits) }
    }

    @Test fun onlyGenuineHistoryHasRecentSemantics() {
        compose.setContent { NeutralSurfaceTheme { Column {
            SuggestRow(SearchSuggestionPolicy.Suggestion("montagem", false), "mon", {}, {})
            SuggestRow(SearchSuggestionPolicy.Suggestion("montagem ranhura", true), "mon", {}, {})
        } } }
        compose.onNodeWithTag("suggestion:montagem ranhura")
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Недавний запрос"))
        compose.onNodeWithTag("suggestion:montagem")
            .assert(SemanticsMatcher.keyNotDefined(SemanticsProperties.StateDescription))
    }

    @Test fun compactGlyphKeeps48dpTouchTargetAtLargeFont() {
        var density = 1f
        compose.setContent {
            density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 2f)) {
                NeutralSurfaceTheme { Box(Modifier.width(300.dp)) {
                    SuggestRow(SearchSuggestionPolicy.Suggestion("montagem long suggestion", true), "mon", {}, {})
                } }
            }
        }
        val target = compose.onNodeWithContentDescription("Подставить запрос: montagem long suggestion")
            .fetchSemanticsNode().boundsInRoot
        assertTrue(target.height >= 48f * density - 1f)
        assertTrue(target.width >= 48f * density - 1f)
    }

    @Test fun externalCompletionPlacesCursorAtEndWithoutSubmitting() {
        val text = mutableStateOf("mon"); var submits = 0
        compose.setContent { NeutralSurfaceTheme {
            SearchField(text.value, { text.value = it }, { submits++ }, { text.value = "" }, {}, {}, false, {})
        } }
        compose.runOnIdle { text.value = "montagem ranhura" }
        compose.onNodeWithTag("search-editor-input").assertTextEquals("montagem ranhura")
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.TextSelectionRange, TextRange("montagem ranhura".length)))
        compose.runOnIdle { assertEquals(0, submits) }
    }

    @Test fun movingSelectionDoesNotIssueANewQuery() {
        var changes = 0
        compose.setContent { NeutralSurfaceTheme {
            SearchField("montagem", { changes++ }, {}, {}, {}, {}, false, {})
        } }
        compose.onNodeWithTag("search-editor-input").performClick()
            .performTextInputSelection(TextRange(1, 3))
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.TextSelectionRange, TextRange(1, 3)))
        compose.runOnIdle { assertEquals(0, changes) }
    }

    @Test fun clearDoesNotSubmitAndKeepsEditorFocused() {
        val text = mutableStateOf("montagem"); var submits = 0
        compose.setContent { NeutralSurfaceTheme {
            SearchField(text.value, { text.value = it }, { submits++ }, { text.value = "" }, {}, {}, false, {})
        } }
        compose.onNodeWithContentDescription("Очистить запрос").performClick()
        compose.onNodeWithTag("search-editor-input").assertTextEquals("").assertIsFocused()
        compose.runOnIdle { assertEquals(0, submits) }
    }

    @Composable
    private fun Preview(height: Dp = 500.dp, onPlay: () -> Unit = {}, onMenu: () -> Unit = {},
                        onSave: () -> Unit = {}, onOpen: () -> Unit = {}, onImport: () -> Unit = {}) {
        NeutralSurfaceTheme { Box(Modifier.width(360.dp).height(height)) {
            SuggestBody(field = "mon", suggestions = listOf(SearchSuggestionPolicy.Suggestion("montagem", false)),
                preview = listOf(RemoteItem.Song(track), RemoteItem.Group(album)),
                loading = false, error = null, savedIds = emptySet(), currentTrackId = null, isPlaying = false,
                onFill = {}, onSave = { onSave() }, onUnsave = {}, onPick = {}, onPlay = { onPlay() },
                onTrackMenu = { onMenu() }, onOpen = { onOpen() }, importedKeys = emptySet(),
                importingKeys = emptySet(), onImport = { onImport() }, onRemove = {})
        } }
    }

    @Test fun livePreviewMenuAndSaveAreIndependentFromPlayback() {
        var plays = 0; var menus = 0; var saves = 0
        compose.setContent { Preview(onPlay = { plays++ }, onMenu = { menus++ }, onSave = { saves++ }) }
        compose.onNodeWithContentDescription("Действия с треком: Montagem One").performClick()
        compose.onNodeWithContentDescription("Добавить трек в медиатеку").performClick()
        compose.runOnIdle { assertEquals(1, menus); assertEquals(1, saves); assertEquals(0, plays) }
        compose.onNodeWithText("Montagem One").performClick()
        compose.runOnIdle { assertEquals(1, plays) }
    }

    @Test fun liveAlbumOpensAndImportsThroughSeparateControls() {
        var opens = 0; var imports = 0
        compose.setContent { Preview(onOpen = { opens++ }, onImport = { imports++ }) }
        compose.onNodeWithContentDescription("Добавить сборник в медиатеку").performClick()
        compose.runOnIdle { assertEquals(0, opens); assertEquals(1, imports) }
        compose.onNodeWithText("Montagem Album").performClick()
        compose.runOnIdle { assertEquals(1, opens); assertEquals(1, imports) }
    }

    @Test fun viewportResizeDoesNotReplaceSuggestionsOrResults() {
        // Exercises resizing like IME; real keyboard/Back behavior is also in CHECKLIST.
        val height = mutableStateOf(220.dp)
        compose.setContent { Preview(height.value) }
        compose.onNodeWithText("montagem").assertIsDisplayed()
        compose.runOnIdle { height.value = 500.dp }
        compose.onNodeWithText("montagem").assertIsDisplayed()
        compose.onNodeWithText("Montagem Album").assertIsDisplayed()
    }

    @Test fun modalBackgroundStaysMeasuredGreyAcrossArtworkChanges() {
        val palette = mutableStateOf(basePalette().copy(surface = Color.Red))
        compose.setContent {
            CompositionLocalProvider(LocalPalette provides palette.value) {
                ZiziTheme(palette.value) {
                    ZiziSheetScaffold(onDismiss = {}) {
                        Box(Modifier.width(240.dp).height(72.dp).testTag("modal-color-sample"))
                    }
                }
            }
        }
        fun sample() {
            val image = compose.onNodeWithTag("modal-color-sample").captureToImage().toPixelMap()
            val actual = image[image.width / 2, image.height / 2]
            assertEquals(ZiziModalSurface.red, actual.red, 1f / 255f)
            assertEquals(ZiziModalSurface.green, actual.green, 1f / 255f)
            assertEquals(ZiziModalSurface.blue, actual.blue, 1f / 255f)
        }
        sample()
        compose.runOnIdle { palette.value = palette.value.copy(surface = Color.Blue) }
        sample()
    }
}
