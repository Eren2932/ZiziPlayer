package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.components.FilterRailItem
import app.ziziplayer.ui.components.SelectionFilterRail
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.screens.ResultGroupRow
import app.ziziplayer.ui.screens.ResultTrackRow
import app.ziziplayer.ui.screens.SearchResultsPane
import app.ziziplayer.ui.screens.SearchTrackAction
import app.ziziplayer.ui.screens.SearchTrackMenuSheet
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Device tests: these are NOT executed by the portable Python runner. */
class Search6770UiTest {
    @get:Rule val compose = createComposeRule()
    private val track = RemoteTrack("dz", "1", "Unique song", "Artist")

    @Test fun moreAndSaveNeverBubbleToPlayback() {
        var plays = 0; var menus = 0; var saves = 0; var removes = 0
        val saved = mutableStateOf(false)
        compose.setContent {
            ResultTrackRow(track, saved.value, playing = false, current = false,
                onPlay = { plays++ }, onSave = { saves++; saved.value = true },
                onUnsave = { removes++; saved.value = false }, compactSearch = true, onMenu = { menus++ })
        }
        compose.onNodeWithContentDescription("Действия с треком: Unique song").performClick()
        compose.onNodeWithContentDescription("Добавить трек в медиатеку").performClick()
        compose.onNodeWithContentDescription("Убрать трек из медиатеки").performClick()
        compose.runOnIdle { assertEquals(1, menus); assertEquals(1, saves); assertEquals(1, removes); assertEquals(0, plays) }
        compose.onNodeWithText("Unique song").performClick()
        compose.runOnIdle { assertEquals(1, plays) }
    }

    @Test fun savedCollectionCheckRequestsRemovalNotNavigation() {
        var opens = 0; var adds = 0; var removes = 0
        compose.setContent {
            ResultGroupRow(RemoteCollection("dz", "album:1", RemoteKind.ALBUM, "Unique album"),
                imported = true, importing = false, onImport = { adds++ }, onRemove = { removes++ }, onClick = { opens++ })
        }
        compose.onNodeWithContentDescription("Убрать сборник из медиатеки").performClick()
        compose.runOnIdle { assertEquals(1, removes); assertEquals(0, opens); assertEquals(0, adds) }
        compose.onNodeWithText("Unique album").performClick()
        compose.runOnIdle { assertEquals(1, opens) }
    }

    @Test fun explicitSessionResetsLiveAndStoredTabsButBackKeepsPosition() {
        val session = mutableStateOf(1L)
        val tab = mutableStateOf(SearchTab.ALL)
        val editor = mutableStateOf(false)
        var visible: LazyListState? = null
        compose.setContent {
            val holder = key(session.value) { rememberSaveableStateHolder() }
            Column(Modifier.fillMaxSize()) {
                if (!editor.value) SearchResultsPane(session.value, tab.value, holder, { tab.value = it }) {
                    val list = rememberLazyListState()
                    visible = list
                    LazyColumn(Modifier.fillMaxSize().testTag("results"), state = list) {
                        items(150) { Text("row $it", Modifier.height(64.dp)) }
                    }
                }
            }
        }
        compose.onNodeWithTag("results").performScrollToIndex(40)
        compose.runOnIdle { editor.value = true }
        compose.runOnIdle { editor.value = false }
        compose.runOnIdle { assertEquals(40, visible!!.firstVisibleItemIndex); tab.value = SearchTab.TRACKS }
        compose.onNodeWithTag("results").performScrollToIndex(22)
        compose.runOnIdle { tab.value = SearchTab.ALL }
        compose.runOnIdle { assertEquals(40, visible!!.firstVisibleItemIndex); session.value++ }
        compose.runOnIdle { assertEquals(0, visible!!.firstVisibleItemIndex); tab.value = SearchTab.TRACKS }
        compose.runOnIdle { assertEquals(0, visible!!.firstVisibleItemIndex) }
    }

    @Test fun sharedRailSupportsNarrowHomeAndLibraryItems() {
        val selected = mutableStateOf<String?>(null)
        compose.setContent {
            Box(Modifier.width(280.dp)) {
                SelectionFilterRail(listOf(FilterRailItem("playlists", "Плейлисты"), FilterRailItem("folders", "Папки"),
                    FilterRailItem("artists", "Исполнители")), selected.value, { selected.value = it }, tag = "library-filter")
            }
        }
        compose.onNodeWithTag("library-filter-artists").performScrollTo().performClick()
        compose.onNodeWithTag("library-filter-artists").assertIsDisplayed()
        compose.onNodeWithTag("library-filter-reset").performClick()
        compose.onNodeWithTag("library-filter-folders").performScrollTo().performClick()
        compose.runOnIdle { assertEquals("folders", selected.value) }
        compose.onNodeWithTag("library-filter-folders").performClick()
        compose.runOnIdle { assertEquals(null, selected.value) }
    }

    @Test fun menuPeeksAtSixtyPercentExpandsAndDispatchesOnce() {
        var actions = 0; var dismisses = 0
        val open = mutableStateOf(true)
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track,
                (0..15).map { SearchTrackAction("a$it", "Action $it", ZiziIcons.Info) { actions++ } },
                onDismiss = { dismisses++; open.value = false })
        }
        compose.waitForIdle()
        val host = compose.onNodeWithTag("search-track-menu-host").fetchSemanticsNode().boundsInRoot
        val partial = compose.onNodeWithTag("search-track-menu").fetchSemanticsNode().boundsInRoot.top
        assertEquals(host.top + host.height * 0.4f, partial, 4f)
        compose.onNodeWithTag("search-track-menu-handle").performTouchInput {
            swipe(center, Offset(center.x, center.y - host.height * 0.5f), durationMillis = 500)
        }
        compose.waitForIdle()
        val expanded = compose.onNodeWithTag("search-track-menu").fetchSemanticsNode().boundsInRoot.top
        assertTrue(expanded < partial)
        assertTrue(expanded >= host.top + host.height * 0.065f)
        compose.onNodeWithTag("search-track-action-a0").performClick()
        compose.runOnIdle { assertEquals(1, actions); assertEquals(1, dismisses) }
    }
}
