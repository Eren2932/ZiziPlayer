package app.ziziplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import app.ziziplayer.lyrics.LrcTimeline
import app.ziziplayer.lyrics.LyricsDocument
import app.ziziplayer.ui.screens.InlineLyricsCaption
import app.ziziplayer.ui.screens.LyricsCursor
import app.ziziplayer.ui.screens.LyricsPreviewCard
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.ZiziTheme
import app.ziziplayer.ui.theme.basePalette
import app.ziziplayer.ui.theme.lyricsPalette
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import kotlin.math.abs

/** Real Compose rendering/input tests. Require Android; not executed by the offline runner. */
class LyricsPreview6800UiTest {
    @get:Rule val compose = createComposeRule()
    private val primary = Color(0xFF887043)
    private val doc = LyricsDocument(List(30) { index ->
        LrcTimeline.Line(1000L + index * 3000L,
            if (index == 3) "A longer current phrase that wraps across two or three lines" else "Repeated phrase")
    }, "", "test", 100_000L)

    @Composable private fun TestTheme(content: @Composable () -> Unit) {
        val p = basePalette().copy(artworkPrimary = primary)
        CompositionLocalProvider(LocalPalette provides p) { ZiziTheme(p, content) }
    }
    private fun node(tag: String) = compose.onNodeWithTag(tag, useUnmergedTree = true)
    private fun near(actual: Float, expected: Float, tolerance: Float = 2f) {
        assertTrue("$actual != $expected (+/- $tolerance)", abs(actual - expected) <= tolerance)
    }
    private fun assertAnchor(index: Int) {
        node("lyrics-preview-cue-$index").assertIsSelected()
        val viewport = node("lyrics-preview-viewport").fetchSemanticsNode().boundsInRoot
        val cue = node("lyrics-preview-cue-$index").fetchSemanticsNode().boundsInRoot
        near(cue.top, viewport.top + viewport.height * LyricsPreviewGeometry.ANCHOR, 3f)
        assertTrue(cue.bottom <= viewport.bottom)
    }

    @Test fun sharedGradientAndReferenceGeometry() {
        var density = 1f
        compose.setContent { TestTheme {
            density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 1f)) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Box(Modifier.width(360.dp)) { LyricsPreviewCard(doc, LyricsCursor(true, true, 3), {}) }
                }
            }
        } }
        val card = node("lyrics-preview-card").fetchSemanticsNode().boundsInRoot
        near(card.width / density, 330f, 1f)
        near(card.height / density, 1156f / 3f, 2f)
        assertAnchor(3)
        val image = node("lyrics-preview-card").captureToImage()
        val pixels = image.toPixelMap()
        val target = lyricsPalette(primary)
        for ((y, expected) in listOf(1 to target.top, image.height - 2 to target.bottom)) {
            val actual = pixels[image.width / 2, y].toArgb()
            for (shift in listOf(16, 8, 0))
                near(((actual ushr shift) and 255).toFloat(), ((expected.toArgb() ushr shift) and 255).toFloat(), 2f)
        }
    }

    @Test fun repeatedCueSeekAndAdvanceKeepCurrentAnchor() {
        val state = mutableStateOf(LyricsCursor(true, true, 3))
        compose.setContent { TestTheme { Box(Modifier.width(360.dp)) {
            LyricsPreviewCard(doc, state.value, {})
        } } }
        assertAnchor(3)
        // Identical text must not key/deduplicate the cue; forward/backward seeks snap to it.
        for (index in listOf(17, 2, 29, 0)) {
            compose.runOnIdle { state.value = LyricsCursor(true, true, index) }
            assertAnchor(index)
        }
        val media = 900L
        val shifted = LrcTimeline.activeIndex(doc.lines, media, 500L)
        compose.runOnIdle { state.value = LyricsCursor(true, true, shifted) }
        assertAnchor(0)
    }

    @Test fun oneCueAnimatesWithoutResizingCard() {
        val state = mutableStateOf(LyricsCursor(true, true, 5))
        compose.setContent { TestTheme { Box(Modifier.width(360.dp)) {
            LyricsPreviewCard(doc, state.value, {})
        } } }
        assertAnchor(5)
        val card = node("lyrics-preview-card").fetchSemanticsNode().boundsInRoot
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { state.value = LyricsCursor(true, true, 6) }
        compose.mainClock.advanceTimeByFrame()
        compose.mainClock.advanceTimeBy(96L)
        val moving = node("lyrics-preview-cue-6").fetchSemanticsNode().boundsInRoot
        val viewport = node("lyrics-preview-viewport").fetchSemanticsNode().boundsInRoot
        assertTrue(moving.top > viewport.top + viewport.height * LyricsPreviewGeometry.ANCHOR + 1f)
        compose.mainClock.advanceTimeBy(1500L)
        compose.mainClock.autoAdvance = true
        assertAnchor(6)
        val after = node("lyrics-preview-card").fetchSemanticsNode().boundsInRoot
        near(after.height, card.height, 1f)
    }

    @Test fun plainAndInvalidTimingHaveNoSelectedCue() {
        val document = mutableStateOf(doc)
        val state = mutableStateOf(LyricsCursor(true, false, 3))
        compose.setContent { TestTheme { Box(Modifier.width(360.dp)) {
            LyricsPreviewCard(document.value, state.value, {})
        } } }
        node("lyrics-preview-cue-0").assertIsNotSelected()
        compose.runOnIdle { state.value = LyricsCursor(false, true, 3) }
        node("lyrics-preview-cue-0").assertIsNotSelected()
        compose.runOnIdle {
            document.value = LyricsDocument(emptyList(), "Plain first\nPlain next", "test", 0, matchVerified = false)
            state.value = LyricsCursor(true, true, 0)
        }
        node("lyrics-preview-plain-0").assertIsDisplayed()
        compose.onAllNodes(isSelected(), useUnmergedTree = true).assertCountEquals(0)
        compose.runOnIdle { document.value = LyricsDocument(emptyList(), "", "test", 0, instrumental = true) }
        node("lyrics-preview-card").assertDoesNotExist()
    }

    @Test fun buttonHasIndependent48dpTargetAndCaptionIsReadOnly() {
        var opened = 0
        var density = 1f
        compose.setContent { TestTheme {
            density = LocalDensity.current.density
            Column(Modifier.width(360.dp).verticalScroll(rememberScrollState())) {
                InlineLyricsCaption(doc, LyricsCursor(true, true, 1), Modifier.height(80.dp).testTag("under-cover-caption"))
                LyricsPreviewCard(doc, LyricsCursor(true, true, 1), { opened++ })
            }
        } }
        node("under-cover-caption").assertHasNoClickAction().performTouchInput { click(center) }
        compose.runOnIdle { assertEquals(0, opened) }
        node("lyrics-preview-open").performScrollTo().performTouchInput { click(center) }
        compose.runOnIdle { assertEquals(1, opened) }
        val target = node("lyrics-preview-open").fetchSemanticsNode().boundsInRoot
        assertTrue(target.height >= 48f * density - 1f)
        assertTrue(target.width >= 48f * density - 1f)
    }

    @Test fun largeFontsGrowViewport() {
        val scale = mutableFloatStateOf(1f)
        var height = 0
        compose.setContent { TestTheme {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, scale.floatValue)) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Box(Modifier.width(320.dp)) {
                        LyricsPreviewCard(doc, LyricsCursor(true, true, 3), {}, Modifier.onSizeChanged { height = it.height })
                    }
                }
            }
        } }
        val baseline = compose.runOnIdle { height }
        compose.runOnIdle { scale.floatValue = 2f }
        compose.runOnIdle { assertTrue(height > baseline * 1.5f) }
        node("lyrics-preview-open").performScrollTo().assertIsDisplayed()
    }
}
