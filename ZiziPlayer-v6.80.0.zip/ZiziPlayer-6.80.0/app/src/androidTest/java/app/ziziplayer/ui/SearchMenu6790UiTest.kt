package app.ziziplayer.ui

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.screens.SearchTrackAction
import app.ziziplayer.ui.screens.SearchTrackMenuSheet
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Window/layout/action tests; NOT marked executed by the portable verifier. */
class SearchMenu6790UiTest {
    @get:Rule val compose = createComposeRule()
    private val track = RemoteTrack("dz", "1", "Menu song", "Artist")
    private fun actions() = (0..11).map { id ->
        SearchTrackAction("a$id", if (id == 11) "Сведения о треке" else "Action $id", ZiziIcons.Info) { }
    }
    private fun expandMenu() {
        compose.onNodeWithTag("search-track-menu-handle").performSemanticsAction(SemanticsActions.Expand) { it() }
        compose.waitForIdle()
    }
    private fun panelFitsHost() {
        val host = compose.onNodeWithTag("search-track-menu-host").getUnclippedBoundsInRoot()
        val panel = compose.onNodeWithTag("search-track-menu").getUnclippedBoundsInRoot()
        assertTrue(panel.top.value >= host.top.value)
        assertEquals("Panel must end at the actual window edge", host.bottom.value, panel.bottom.value, 1f)
    }
    private fun lastTouchTargetFits() {
        compose.onNodeWithTag("search-track-menu-actions").performScrollToNode(hasTestTag("search-track-action-a11"))
        compose.onNodeWithTag("search-track-action-a11").assertIsDisplayed()
        val row = compose.onNodeWithTag("search-track-action-a11").getUnclippedBoundsInRoot()
        val list = compose.onNodeWithTag("search-track-menu-actions").getUnclippedBoundsInRoot()
        assertTrue(row.top.value >= list.top.value - 1f)
        assertTrue(row.bottom.value <= list.bottom.value + 1f)
        assertTrue(row.height.value >= 58f - 1f)
        panelFitsHost()
    }

    @Test fun partialPanelHasNoOffscreenTail() {
        compose.setContent { SearchTrackMenuSheet(track, actions(), onDismiss = {}) }
        compose.waitForIdle()
        panelFitsHost()
        lastTouchTargetFits()
    }

    @Test fun expandedPanelHasNoOffscreenTail() {
        compose.setContent { SearchTrackMenuSheet(track, actions(), onDismiss = {}) }
        expandMenu()
        panelFitsHost()
        lastTouchTargetFits()
    }

    @Test fun intermediateCollapseFrameStaysWithinWindow() {
        compose.setContent { SearchTrackMenuSheet(track, actions(), onDismiss = {}) }
        expandMenu()
        val expanded = compose.onNodeWithTag("search-track-menu").getUnclippedBoundsInRoot().top.value
        compose.mainClock.autoAdvance = false
        compose.onNodeWithTag("search-track-menu-handle").performSemanticsAction(SemanticsActions.Collapse) { it() }
        compose.mainClock.advanceTimeBy(80)
        panelFitsHost()
        val moving = compose.onNodeWithTag("search-track-menu").getUnclippedBoundsInRoot().top.value
        assertTrue("Collapse must move down", moving > expanded)
        compose.mainClock.autoAdvance = true
        compose.waitForIdle()
        panelFitsHost()
    }

    @Test fun maximumFontKeepsTrackInfoCompletelyReachable() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 2f)) {
                SearchTrackMenuSheet(track, actions(), onDismiss = {})
            }
        }
        expandMenu()
        lastTouchTargetFits()
    }

    @Test fun outsideDismissCannotDispatchNonCooperativePreparation() {
        val open = mutableStateOf(true)
        val gate = CompletableDeferred<Unit>()
        var runs = 0; var dismisses = 0
        compose.setContent {
            if (open.value) SearchTrackMenuSheet(track,
                listOf(SearchTrackAction("a0", "Action", ZiziIcons.Info) { runs++ }),
                onDismiss = { dismisses++; open.value = false }, prepareAction = { action ->
                    withContext(NonCancellable) { gate.await() }; action.run
                })
        }
        compose.onNodeWithTag("search-track-action-a0").performClick()
        compose.onNodeWithTag("search-track-menu-outside").performClick()
        compose.waitForIdle()
        compose.runOnIdle { gate.complete(Unit) }
        compose.waitForIdle()
        compose.runOnIdle { assertEquals(0, runs); assertEquals(1, dismisses) }
        compose.onNodeWithTag("search-track-menu-host").assertDoesNotExist()
    }

    @Test fun disabledActionNeverStartsPreparationOrDismissal() {
        var preparations = 0; var runs = 0; var dismisses = 0
        compose.setContent { SearchTrackMenuSheet(track,
            listOf(SearchTrackAction("a0", "Disabled", ZiziIcons.Info, enabled = false) { runs++ }),
            onDismiss = { dismisses++ }, prepareAction = { action -> preparations++; action.run }) }
        compose.onNodeWithTag("search-track-action-a0").assertIsNotEnabled().performTouchInput { click() }
        compose.runOnIdle { assertEquals(0, preparations); assertEquals(0, runs); assertEquals(0, dismisses) }
    }
}
