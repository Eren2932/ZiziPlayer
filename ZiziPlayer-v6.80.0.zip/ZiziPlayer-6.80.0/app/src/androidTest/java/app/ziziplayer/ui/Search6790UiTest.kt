package app.ziziplayer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.remote.RemoteItem
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.ui.screens.SuggestBody
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Real Compose tests. Requires Android; source contracts do not execute this class. */
class Search6790UiTest {
    @get:Rule val compose = createComposeRule()
    private val songs = (0..7).map { RemoteItem.Song(RemoteTrack("dz", "$it", "Montagem song $it", "Artist")) }
    private val regular = (0..4).map { SearchSuggestionPolicy.Suggestion("montagem option $it", false) }
    private val recent = SearchSuggestionPolicy.Suggestion("montagem previous", true)

    @Composable
    private fun Preview(field: String = "mon", rows: List<SearchSuggestionPolicy.Suggestion> = regular + recent,
                        items: List<RemoteItem> = songs, pending: Boolean = false, height: Dp = 500.dp) {
        NeutralSurfaceTheme { Box(Modifier.width(360.dp).height(height)) {
            SuggestBody(field = field, suggestions = rows, preview = items, loading = pending,
                error = null, savedIds = emptySet(), currentTrackId = null, isPlaying = false,
                onFill = {}, onSave = {}, onUnsave = {}, onPick = {}, onPlay = {}, onTrackMenu = {},
                onOpen = {}, importedKeys = emptySet(), importingKeys = emptySet(), onImport = {}, onRemove = {})
        } }
    }

    @Test fun historyIsNotMountedBeforeCatalogFinishes() {
        compose.setContent { Preview(rows = listOf(recent), items = emptyList(), pending = true) }
        compose.onNodeWithTag("search-suggestion-history").assertDoesNotExist()
        compose.onNodeWithText("Ищу совпадения…").assertIsDisplayed()
    }

    @Test fun historyFollowsBothCompletionAndCatalogRows() {
        compose.setContent { Preview(rows = listOf(regular.first(), recent), items = songs.take(1)) }
        val completion = compose.onNodeWithTag("suggestion:montagem option 0").fetchSemanticsNode().boundsInRoot
        val song = compose.onNodeWithText("Montagem song 0").fetchSemanticsNode().boundsInRoot
        val history = compose.onNodeWithTag("suggestion:montagem previous").fetchSemanticsNode().boundsInRoot
        assertTrue(completion.bottom <= song.top)
        assertTrue(song.bottom <= history.top)
    }

    @Test fun lateCompletionsAppearAboveFirstTrackWithoutManualScroll() {
        val ready = mutableStateOf(false)
        compose.setContent { Preview(rows = if (ready.value) regular else listOf(recent),
            items = if (ready.value) songs else emptyList(), pending = !ready.value, height = 300.dp) }
        compose.runOnIdle { ready.value = true }
        compose.onNodeWithTag("suggestion:montagem option 0").assertIsDisplayed()
        val top = compose.onNodeWithTag("search-suggestions").fetchSemanticsNode().boundsInRoot.top
        val first = compose.onNodeWithTag("suggestion:montagem option 0").fetchSemanticsNode().boundsInRoot.top
        assertTrue(kotlin.math.abs(top - first) <= 1f)
    }

    @Test fun differentPrefixResetsScrolledListSynchronously() {
        val field = mutableStateOf("mon")
        compose.setContent { Preview(field = field.value, height = 220.dp) }
        compose.onNodeWithTag("search-suggestions").performScrollToNode(hasText("Montagem song 7"))
        compose.onNodeWithTag("suggestion:montagem option 0").assertIsNotDisplayed()
        compose.runOnIdle { field.value = "montag" }
        compose.onNodeWithTag("suggestion:montagem option 0").assertIsDisplayed()
    }

    @Test fun keyboardResizeKeepsCurrentQueryScrollState() {
        val height = mutableStateOf(220.dp)
        compose.setContent { Preview(height = height.value) }
        compose.onNodeWithTag("search-suggestions").performScrollToNode(hasText("Montagem song 7"))
        compose.runOnIdle { height.value = 400.dp }
        compose.onNodeWithText("Montagem song 7").assertIsDisplayed()
        compose.onNodeWithTag("suggestion:montagem option 0").assertIsNotDisplayed()
    }

    @Test fun catalogHistoryDuplicateDoesNotBecomeAClock() {
        val rows = SearchSuggestionPolicy.build("mon", listOf("Montagem"), listOf("MONTAGEM"), emptyList())
        compose.setContent { Preview(rows = rows, items = emptyList()) }
        compose.onNodeWithTag("suggestion:montagem").assertIsDisplayed()
            .assert(SemanticsMatcher.keyNotDefined(SemanticsProperties.StateDescription))
        compose.onNodeWithTag("search-suggestion-history").assertDoesNotExist()
    }
}
