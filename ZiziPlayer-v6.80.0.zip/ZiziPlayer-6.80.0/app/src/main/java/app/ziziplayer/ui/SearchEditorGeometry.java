package app.ziziplayer.ui;

/** Reference: 1080x2400, suggestion pitch 138px. Inferred density 138/48 = 2.875.
 * dp remains adaptive; font scaling and >=48dp hit targets are intentionally not disabled.
 */
public final class SearchEditorGeometry {
    private SearchEditorGeometry() {}
    public static final float HEADER_DP = 48f;
    public static final float FIELD_DP = 32f;
    public static final float ROW_DP = 48f;
    public static final float LEADING_DP = 24f;
    public static final float ICON_DP = 16f;
    public static final float TEXT_GAP_DP = 20f;
    public static final float FILL_ICON_DP = 18f;
    public static final float RESULT_GAP_DP = 8f;
    public static final int CHROME_ARGB = 0xFF1F1F1F;
    public static final int FIELD_ARGB = 0xFF363636;
    public static final int SECONDARY_ARGB = 0xFFB3B3B3;
}
