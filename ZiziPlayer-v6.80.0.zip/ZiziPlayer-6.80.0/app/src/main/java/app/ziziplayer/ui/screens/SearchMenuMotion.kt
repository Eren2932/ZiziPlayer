package app.ziziplayer.ui.screens

import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.AnchoredDraggableState
import androidx.compose.foundation.gestures.animateTo
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SheetValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp

/** Public Foundation 1.7 API, not Material's internal draggable state. */
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Stable
internal class SearchMenuMotionState(val drag: AnchoredDraggableState<SheetValue>) {
    val currentValue: SheetValue get() = drag.settledValue
    val isVisible: Boolean get() = drag.offset.isFinite() &&
        drag.offset < drag.anchors.positionOf(SheetValue.Hidden) - 0.5f
    val hasPartiallyExpandedState: Boolean get() = drag.anchors.hasAnchorFor(SheetValue.PartiallyExpanded)
    fun requireOffset(): Float = drag.requireOffset()
    suspend fun hideMenu() = drag.animateTo(SheetValue.Hidden)
    suspend fun expandMenu() = drag.animateTo(SheetValue.Expanded)
    suspend fun peekMenu() = drag.animateTo(SheetValue.PartiallyExpanded)
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
internal fun rememberSearchMenuMotionState(): SearchMenuMotionState {
    val density = LocalDensity.current
    val velocity by rememberUpdatedState(with(density) { 400.dp.toPx() })
    val snap = remember { spring<Float>(dampingRatio = 1f, stiffness = 650f) }
    val decay = remember { exponentialDecay<Float>(frictionMultiplier = 2f) }
    val position: (Float) -> Float = { distance -> distance * 0.5f }
    val speed: () -> Float = { velocity }
    val drag = rememberSaveable(saver = AnchoredDraggableState.Saver<SheetValue>(
        snapAnimationSpec = snap, decayAnimationSpec = decay,
        positionalThreshold = position, velocityThreshold = speed
    )) {
        AnchoredDraggableState(initialValue = SheetValue.Hidden,
            snapAnimationSpec = snap, decayAnimationSpec = decay,
            positionalThreshold = position, velocityThreshold = speed)
    }
    return remember(drag) { SearchMenuMotionState(drag) }
}

/** Up: expand panel before scrolling. Down: scroll list to top before collapsing panel. */
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
internal class SearchMenuNestedScroll(
    private val state: SearchMenuMotionState,
    private val enabled: () -> Boolean
) : NestedScrollConnection {
    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
        if (enabled() && source == NestedScrollSource.UserInput && available.y < 0f)
            Offset(0f, state.drag.dispatchRawDelta(available.y)) else Offset.Zero

    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
        if (enabled() && source == NestedScrollSource.UserInput)
            Offset(0f, state.drag.dispatchRawDelta(available.y)) else Offset.Zero

    override suspend fun onPreFling(available: Velocity): Velocity {
        if (enabled() && available.y < 0f &&
            state.requireOffset() > state.drag.anchors.positionOf(SheetValue.Expanded) + 0.5f) {
            state.drag.settle(available.y)
            return available
        }
        return Velocity.Zero
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        if (!enabled()) return Velocity.Zero
        state.drag.settle(available.y)
        return available
    }
}
