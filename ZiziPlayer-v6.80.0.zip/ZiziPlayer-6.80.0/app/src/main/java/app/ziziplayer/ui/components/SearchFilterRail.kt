package app.ziziplayer.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.SearchTab

private val FILTERS = listOf(SearchTab.ALBUMS, SearchTab.TRACKS, SearchTab.PLAYLISTS, SearchTab.ARTISTS)
    .map { FilterRailItem(it.name, it.label) }

/** Search adapter; motion and hit testing are shared with Home, Library and Settings. */
@Composable
internal fun SearchFilterRail(selectedTab: SearchTab, onTab: (SearchTab) -> Unit) {
    SelectionFilterRail(items = FILTERS, selectedId = selectedTab.takeUnless { it == SearchTab.ALL }?.name,
        onSelect = { onTab(it?.let(SearchTab::valueOf) ?: SearchTab.ALL) }, tag = "search-filter",
        edge = 17.dp, resetInset = (-9).dp, chipHeight = 31.dp, resetSize = 32.dp,
        chipPadding = 10.dp, chipVerticalPadding = 4.dp)
}
