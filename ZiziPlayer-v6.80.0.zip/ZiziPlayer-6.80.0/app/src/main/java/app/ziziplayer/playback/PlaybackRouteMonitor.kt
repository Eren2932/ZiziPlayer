package app.ziziplayer.playback

import android.os.Handler
import android.os.Looper
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.DefaultAudioSink

/** Observe tracks from Media3's DEFAULT provider; preserve DSP, buffer sizing and attributes. */
@UnstableApi
internal class PlaybackRouteMonitor {
    private val main = Handler(Looper.getMainLooper())
    // Attach jobs and close are both main-thread serialized. Late jobs cannot resurrect an owner.
    private var closed = false
    val provider = DefaultAudioSink.AudioTrackProvider { config, attributes, sessionId ->
        DefaultAudioSink.AudioTrackProvider.DEFAULT.getAudioTrack(config, attributes, sessionId).also { track ->
            main.post { if (!closed) AudioOutputs.attach(this, track) }
        }
    }
    fun close() {
        closed = true
        AudioOutputs.detach(this)
    }
}
