@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.ziziplayer.ui.screens

import app.ziziplayer.ui.theme.ZiziModalSurface

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.AudioOutputState
import app.ziziplayer.playback.AudioOutputs
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*

private val ConnectSurface = ZiziModalSurface
private val ConnectCard = Color(0xFF2A2A2A)
private val ConnectMuted = Color(0xFFB3B3B3)

@Composable
fun AudioOutputSheet(vm: MainViewModel, track: TrackEntity?, onDismiss: () -> Unit) {
    val state by vm.audioOutput.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var permission by remember { mutableStateOf(AudioOutputs.hasBluetoothPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permission = AudioOutputs.hasBluetoothPermission(context)
        AudioOutputs.refresh()
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permission = AudioOutputs.hasBluetoothPermission(context)
                AudioOutputs.refresh()
            }
        }
        lifecycle.addObserver(observer)
        AudioOutputs.refresh()
        onDispose { lifecycle.removeObserver(observer) }
    }
    AudioOutputDialog(state = state, track = track, onDismiss = onDismiss,
        requestNames = if (!permission && (state.active.isBluetooth || state.connected.any { it.isBluetooth })) ({
            if (Build.VERSION.SDK_INT >= 31) launcher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }) else null,
        onSystemOutput = { openAudioSettings(context, bluetooth = false) },
        onBluetooth = { openAudioSettings(context, bluetooth = true) })
}

@Composable
internal fun AudioOutputDialog(
    state: AudioOutputState, track: TrackEntity?, onDismiss: () -> Unit,
    requestNames: (() -> Unit)? = null, onSystemOutput: () -> Unit, onBluetooth: () -> Unit
) {
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current // re-read after rotation / multi-window resize
    val view = LocalView.current
    val rootHeight = with(density) { view.rootView.height.toDp() }
    val windowHeight = if (rootHeight.value > 0f) rootHeight else configuration.screenHeightDp.dp
    val sheetHeight = (windowHeight * 0.70f).coerceAtLeast(240.dp).coerceAtMost(windowHeight)
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
        containerColor = ConnectSurface, contentColor = Color.White,
        tonalElevation = 0.dp, scrimColor = Color.Black.copy(alpha = 0.64f),
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) }, dragHandle = null) {
        AudioOutputSheetContent(state = state, track = track,
            modifier = Modifier.fillMaxWidth().height(sheetHeight).navigationBarsPadding(),
            requestNames = requestNames,
            onSystemOutput = onSystemOutput, onBluetooth = onBluetooth)
    }
}

/** Same content used by the real dialog and the Compose interaction tests. */
@Composable
internal fun AudioOutputSheetContent(
    state: AudioOutputState,
    track: TrackEntity?,
    modifier: Modifier = Modifier,
    requestNames: (() -> Unit)? = null,
    onSystemOutput: () -> Unit,
    onBluetooth: () -> Unit
) {
    val active = state.active
    val others = state.connected.filter { it.id != active.id && !(it.isPhone && active.isPhone) }
    Column(modifier.background(ConnectSurface).testTag("connect-sheet")) {
        Box(Modifier.fillMaxWidth().height(28.dp), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.padding(top = 10.dp).size(36.dp, 4.dp)
                .clip(RoundedCornerShape(2.dp)).background(Color(0xFF666666)))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text("Connect", color = Color.White, fontSize = 22.sp, lineHeight = 28.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 8.dp))
            Row(Modifier.padding(horizontal = 8.dp).fillMaxWidth().heightIn(min = 88.dp)
                .clip(RoundedCornerShape(16.dp)).background(ConnectCard)
                .clickable(role = Role.Button, onClick = onSystemOutput).testTag("connect-active")
                .padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(active.name, color = Color.White, fontSize = 25.sp, lineHeight = 29.sp,
                            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        // This is a factual transport badge, not a fabricated Spotify quality tier.
                        Text(audioOutputTransport(active), color = ConnectMuted, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterVertically)
                                .clip(RoundedCornerShape(4.dp)).background(Color(0xFF3E3E3E))
                                .padding(horizontal = 3.dp, vertical = 2.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    MarqueeText(text = track?.let { "${it.title} — ${it.artist}" } ?: "Нет воспроизведения",
                        color = if (active.isKnown) ConnectedDeviceAccent else ConnectMuted,
                        fontSize = 13.sp, fontWeight = FontWeight.Medium,
                        resetKey = track?.id, gap = 24.dp)
                }
                Spacer(Modifier.width(10.dp))
                Icon(audioOutputIcon(active, large = true), active.name,
                    tint = if (active.isKnown) ConnectedDeviceAccent else ConnectMuted,
                    modifier = Modifier.size(48.dp).offset(y = (-3).dp))
            }
            Text(if (!active.isKnown) "Начни воспроизведение, чтобы определить выход звука"
                else if (others.isEmpty()) "Другие аудиоустройства не подключены"
                else "Подключённые аудиоустройства",
                color = ConnectMuted, fontSize = 13.sp, lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp))
            for (device in others) Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .heightIn(min = 56.dp).clip(RoundedCornerShape(8.dp))
                .clickable(role = Role.Button, onClick = onSystemOutput).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(audioOutputIcon(device, large = true), null, tint = ConnectMuted, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(device.name, color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${audioOutputTransport(device)} · выбор в системе", color = ConnectMuted, fontSize = 11.sp)
                }
            }
            if (requestNames != null) TextButton(onClick = requestNames, modifier = Modifier.padding(horizontal = 12.dp)) {
                Text("Разрешить имена Bluetooth-устройств", color = ConnectedDeviceAccent)
            }
        }
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp, top = 8.dp)
            .fillMaxWidth().heightIn(min = 68.dp).clip(RoundedCornerShape(6.dp)).background(ConnectCard)
            .clickable(role = Role.Button, onClick = onBluetooth).testTag("connect-bluetooth")
            .padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(ZiziIcons.BluetoothAudio, null, tint = Color.White, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(6.dp))
            Text("Найти Bluetooth-устройства", color = Color.White, fontSize = 12.sp,
                fontWeight = FontWeight.Medium, maxLines = 2)
        }
    }
}

private fun openAudioSettings(context: Context, bluetooth: Boolean) {
    // MEDIA_OUTPUT is not a public Settings.Panel action. Do not rely on a hidden OEM intent.
    val actions = if (bluetooth) listOf(Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS)
        else if (Build.VERSION.SDK_INT >= 29) listOf(Settings.Panel.ACTION_VOLUME, Settings.ACTION_SOUND_SETTINGS)
        else listOf(Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_SETTINGS)
    for (action in actions) {
        if (runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
    }
    Toast.makeText(context, "Не удалось открыть системные настройки", Toast.LENGTH_SHORT).show()
}
