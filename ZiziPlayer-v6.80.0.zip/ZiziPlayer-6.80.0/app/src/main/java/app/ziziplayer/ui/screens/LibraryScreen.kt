package app.ziziplayer.ui.screens

import app.ziziplayer.ui.theme.ZiziModalSurface

import app.ziziplayer.ui.theme.ZiziFontFamily
import android.net.Uri
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
// 6.41.2: MiniPlayer measures fontScale through LocalDensity. `androidx.compose.runtime.*`
// does NOT cover it: the composition local lives in androidx.compose.ui.platform, and the
// missing line is what broke build #406 (Unresolved reference at LibraryScreen.kt:1212).
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.ScanProgress
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.playback.PlaybackState
import app.ziziplayer.ui.FolderInfo
import app.ziziplayer.ui.LibraryFilter
import app.ziziplayer.ui.LibraryUiState
import app.ziziplayer.ui.MediaGeometry
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.*
import app.ziziplayer.ui.theme.LocalPalette
import app.ziziplayer.ui.theme.NeutralSurfaceTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import app.ziziplayer.ui.components.formatTotalTime
import app.ziziplayer.ui.components.trackCountLabel
import app.ziziplayer.ui.components.ZiziIcons
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import app.ziziplayer.ui.LibraryGeometry
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import app.ziziplayer.data.CollectionSort
import app.ziziplayer.data.LibraryView
import app.ziziplayer.data.SortMode
import app.ziziplayer.ui.ArtistInfo
import app.ziziplayer.ui.RECENT_ARTIST
import app.ziziplayer.ui.RECENT_FAVORITES
import app.ziziplayer.ui.RECENT_FOLDER
import app.ziziplayer.ui.RECENT_PLAYLIST
import app.ziziplayer.ui.RECENT_TRACKS
import app.ziziplayer.ui.components.EqualizerBars
import app.ziziplayer.ui.components.MiniEqualizerBars
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.FilterRailItem
import app.ziziplayer.ui.components.SelectionFilterRail
import app.ziziplayer.ui.components.ChipColors
import app.ziziplayer.ui.components.RoundIconButton
import app.ziziplayer.ui.components.TrackArtwork

/** 6.39.5: ordinary tracks use the same art, typography and row pitch as search. */
private val rowShape = RoundedCornerShape(8.dp)
private val artShape = RoundedCornerShape(6.dp)
private val ROW_HEIGHT = MediaDimensions.trackRow
private val ART_SIZE = MediaDimensions.trackArt
/**
 * 6.18.0 — фиксированная высота шапки.
 *
 * Дёрганье при входе в выбор было не «анимации не хватает», а честный скачок раскладки: обычная
 * шапка складывалась из кнопок 44 dp и отступов 10/6 (62 dp), шапка выбора — из кнопок 42 dp
 * (58 dp), и в момент подмены весь экран прыгал на 4 dp вверх, а следом на ~52 dp ещё раз, потому
 * что мгновенно исчезал ряд фильтров. Теперь высота шапки одна и та же всегда, содержимое внутри
 * меняется перекрёстным затуханием, а ряд фильтров не пропадает, а сворачивается по той же кривой.
 */
private val HEADER_HEIGHT = 62.dp
private const val SELECTION_MS = 190

/**
 * 6.18.1 — правый слот строки.
 *
 * Ширина ровно 38 + 34 = 72 dp, то есть сумма кнопок «сердце» и «⋮». Кружок выбора рисуется в
 * той же коробке 34 dp, что и «⋮», и прижат к правому краю, поэтому его центр совпадает с центром
 * «⋮» до пикселя: при входе в выбор ничего не переезжает по горизонтали.
 */
private val TRAILING_W = 72.dp
private val TRAILING_SLOT = 34.dp

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    state: LibraryUiState,
    playback: PlaybackState,
    currentTrack: TrackEntity?,
    onOpenPlayer: () -> Unit,
    onPickFolder: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onDeleteFile: (TrackEntity) -> Unit,
    /** 6.28.0: раздел «Звук» в настройках открывает эквалайзер — см. [SettingsSheet]. */
    onOpenEqualizer: () -> Unit,
    /** 6.50.0: экран аккаунта живёт в MainActivity — как эквалайзер, по той же причине. */
    accountGuest: Boolean,
    account: AccountLocalState,
    profile: AccountProfile,
    onOpenAccountMenu: () -> Unit,
    onOpenAccount: () -> Unit,
    onOpenSettings: (() -> Unit)? = null
) {
    val vault = vm.folderVault
    val gate by vault.state.collectAsStateWithLifecycle()
    val folderSelection by vm.selectedFolders.collectAsStateWithLifecycle()
    var authenticate by remember { mutableStateOf(false) }
    var pendingHide by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showVault by remember { mutableStateOf(false) }
    val folderHaptic = LocalHapticFeedback.current
    fun toggleFolder(name: String) { vm.selectFolders(if (name in folderSelection) folderSelection - name else folderSelection + name) }
    fun openVault() {
        if (gate.folders.isEmpty() || authenticate || showVault || pendingHide.isNotEmpty()) return
        if (gate.unlocked) showVault = true else { pendingHide = emptySet(); authenticate = true }
    }
    // Root ZiziApp owns Back and delegates folder selection to vm.handleBack().
    DisposableEffect(vm) { onDispose { vm.selectFolders(emptySet()) } }
    LaunchedEffect(state.filter, state.isDrilledIn) { vm.selectFolders(emptySet()) }
    LaunchedEffect(gate.unlocked) { if (!gate.unlocked) showVault = false }
    if (authenticate) VaultAuthDialog(vault, onSuccess = {
        authenticate = false
        if (pendingHide.isNotEmpty()) {
            vm.hideFolders(pendingHide); pendingHide = emptySet(); vm.selectFolders(emptySet())
        } else showVault = true
    }, onDismiss = { authenticate = false; pendingHide = emptySet() })
    if (showVault && gate.unlocked) {
        val palette = LocalPalette.current
        AlertDialog(
        tonalElevation = 0.dp,
        onDismissRequest = { showVault = false }, containerColor = ZiziModalSurface,
            title = { Text("Скрытые папки", color = palette.brand) },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(gate.folders.sorted(), key = { it }) { name ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = palette.text, modifier = Modifier.weight(1f).clickable {
                                showVault = false; vm.openFolder(name)
                            }.padding(vertical = 16.dp))
                            TextButton(onClick = { vm.restoreFolders(setOf(name)) }) { Text("Вернуть", color = palette.brand) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vault.lock(); showVault = false }) { Text("Заблокировать", color = palette.brand) } },
            dismissButton = { TextButton(onClick = { showVault = false }) { Text("Закрыть", color = palette.subtext) } })
    }
    var menuTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var fxTrack by remember { mutableStateOf<TrackEntity?>(null) }
    var showSleepTimer by rememberSaveable { mutableStateOf(false) }
    /* --------------------------------------------------------------------- 6.29.0 ----
     * Состояние ПОВЕРХНОСТИ медиатеки. Всё, что ниже, — про вид, а не про данные: данные приходят
     * готовыми из [state], и ни одна строка здесь их не пересобирает.
     */
    // Подрез активного разреза («Не пустые» у плейлистов, «5+ треков» у исполнителей). Хранится
    // именем, а не значением enum: rememberSaveable кладёт это в Bundle, а enum туда сам по себе
    // не ложится без Parcelable — строка честнее и дешевле.
    var sliceName by rememberSaveable(state.filter) { mutableStateOf<String?>(null) }
    var sortSheet by remember { mutableStateOf(false) }
    var creatingPlaylist by rememberSaveable { mutableStateOf(false) }
    var playlistMenu by remember { mutableStateOf<PlaylistEntity?>(null) }
    val activeSlice = remember(sliceName) {
        sliceName?.let { name -> runCatching { LibrarySlice.valueOf(name) }.getOrNull() }
    }
    // Смена разреза снимает подрез: «Не пустые» и «5+ треков» — про разные сущности, и перенести
    // один на другой значит показать фильтр, которого человек не ставил.

    var infoTrack by remember { mutableStateOf<TrackEntity?>(null) }
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<TrackEntity?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var renamePlaylistId by remember { mutableStateOf<Long?>(null) }
    // 6.15.0: обмен плейлистами.
    var sharePlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    // 6.17.0: множественный выбор, меню папки и подтверждение удаления плейлиста.
    // 6.19.0: id, а не сама сущность, и через rememberSaveable.
    //
    // PlaylistEntity не Parcelable, поэтому сохранить его нельзя в принципе — а `remember` теряет
    // состояние при повороте экрана и при возврате из системного диалога выбора папки. Диалог
    // «удалить плейлист?» просто исчезал, и человек оставался в неведении, удалилось ли что-то.
    // Long сохраняется как есть, а имя и счётчик всё равно берутся из свежего состояния.
    var confirmDeletePlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    // 6.19.0: см. onRemoveConnected у CollectionSurface (6.29.0).
    var confirmRemoveFolder by rememberSaveable { mutableStateOf<String?>(null) }
    var folderMenu by remember { mutableStateOf<String?>(null) }
    // 6.27.1: переименование и удаление папки.
    //
    // Оба состояния — rememberSaveable, и это не перестраховка. Удаление уходит в СИСТЕМНЫЙ
    // диалог (MediaStore.createDeleteRequest), то есть наша Activity на это время уходит на
    // задний план и может быть убита; переименование переживает поворот экрана. Обычный
    // remember в обоих случаях терял бы папку ровно в тот момент, когда она нужна: человек
    // подтвердил бы удаление в системе и вернулся бы в приложение, где удалять уже нечего.
    var renameFolder by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmDeleteFolder by rememberSaveable { mutableStateOf<String?>(null) }
    /** Папка, чьё удаление сейчас подтверждает система. Ответ приходит без указания цели. */
    var pendingFolderDeletion by rememberSaveable { mutableStateOf<String?>(null) }
    val folderDeleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val target = pendingFolderDeletion
        pendingFolderDeletion = null
        // RESULT_OK приходит только если человек нажал «Разрешить». Отказ — это не ошибка и не
        // повод что-то показывать: он уже видел диалог и уже ответил на него «нет».
        if (target != null && result.resultCode == android.app.Activity.RESULT_OK) {
            vm.onFolderDeleted(target)
        }
    }
    var selectionMenu by remember { mutableStateOf(false) }
    /** Не null — открыт выбор плейлиста для выделенного; true = переносим, false = копируем. */
    var selectionTarget by remember { mutableStateOf<Boolean?>(null) }
    val selected by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode = selected.isNotEmpty()
    LaunchedEffect(selectionMode, folderSelection.isNotEmpty()) {
        if (selectionMode || folderSelection.isNotEmpty()) vm.closeLibraryPanels()
    }
    var importSource by remember { mutableStateOf(false) }
    var pasting by remember { mutableStateOf(false) }
    // Системный выбор файла — путь, который работает всегда, в отличие от intent-filter: не всякий
    // провайдер отдаёт имя файла в пути, а значит не всякий .zizi долетит до нашего фильтра.
    val pickPlaylistFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.offerImportFile(uri)
    }

    val detailPage = state.isDrilledIn || state.filter == LibraryFilter.FAVORITES || state.filter == LibraryFilter.TRACKS
    val collectionGridState = rememberLazyGridState()
    val panels by vm.libraryPanels.collectAsStateWithLifecycle()
    val addExpanded = panels.addExpanded
    DisposableEffect(vm) { onDispose { vm.closeLibraryPanels() } }
    LaunchedEffect(collectionGridState) {
        snapshotFlow { collectionGridState.isScrollInProgress }.collectLatest { moving ->
            while (moving) { ArtworkCache.markBusy(); delay(120) }
        }
    }
    var lastRootFilter by rememberSaveable { mutableStateOf(state.filter.name) }
    LaunchedEffect(state.filter) {
        if (state.filter in CARD_FILTERS && !state.isDrilledIn) {
            if (lastRootFilter != state.filter.name) collectionGridState.scrollToItem(0)
            lastRootFilter = state.filter.name
        }
    }
    LaunchedEffect(state.query) {
        if (state.query.isNotBlank()) collectionGridState.scrollToItem(0)
    }
    val listState = rememberLazyListState()
    LaunchedEffect(state.filter, state.query, state.openPlaylist?.id, state.openFolder, state.openArtist) {
        listState.scrollToItem(0)
    }
    val context = LocalContext.current
    // Короткий отклик в момент входа в выбор. Долгое нажатие — единственный жест приложения без
    // видимого «нажалось»: без вибрации человек не понимает, сработало или он просто держит палец.
    val haptics = LocalHapticFeedback.current

    // Only the visible owner may signal scroll activity. Detail pages own their own observer.
    LaunchedEffect(listState, detailPage) {
        if (detailPage) return@LaunchedEffect
        snapshotFlow { listState.isScrollInProgress to listState.firstVisibleItemIndex }
            .collectLatest { (scrolling, first) ->
                ArtworkPrefetcher.focusOn(first)
                while (scrolling) {
                    ArtworkCache.markBusy()
                    delay(120)
                }
            }
    }

    // Covers are indexed in the background, once per file, and persisted to disk. This is what
    // makes the second launch instant and keeps MediaMetadataRetriever away from the scroll.
    // Keyed on ordered IDs: a favourite-only edit does not restart work, while a different
    // collection with the same size and first track must not reuse the previous pass.
    val prefetchKey = remember(state.visible) { state.visible.map { it.id } }
    LaunchedEffect(prefetchKey) {
        delay(450)
        ArtworkPrefetcher.submit(context, state.visible)
    }

    /* ------------------------------------------------------------------ 6.29.1 ----
     * Какая поверхность сейчас на экране. Считается ДО Column, а не внутри него: лист порядка
     * живёт за пределами колонки, и ему нужен ровно тот же ответ, что и полосе порядка.
     */
    val view = state.settings.libraryView
    // Keep the current surface mounted for an empty query: opening/clearing search must
    // not tear down the lazy list, its artwork or the sort row in the transition frame.
    val cardsSurface = !state.isDrilledIn && !selectionMode && state.filter in CARD_FILTERS
    val trackGrid = !cardsSurface && view == LibraryView.GRID && !selectionMode

    val connectedFolders = remember(state.settings.folderUris) { state.settings.folderUris.toList() }
    // «Играть всё» и «перемешать» появляются там, где список уже является подборкой: внутри
    // плейлиста, папки, исполнителя и в избранном. В общем списке медиатеки они не нужны —
    // эту роль там играет большая кнопка в шапке.
    val playAllHere = (state.isDrilledIn || state.filter == LibraryFilter.FAVORITES) && state.visible.isNotEmpty()
    val cardActions = CardActions(
        openFavorites = { vm.setFilter(LibraryFilter.FAVORITES) },
        openAllTracks = { vm.setFilter(LibraryFilter.TRACKS) },
        openPlaylist = vm::openPlaylist,
        playlistMenu = { playlistMenu = it },
        openFolder = { name -> if (folderSelection.isNotEmpty()) toggleFolder(name) else vm.openFolder(name) },
        selectFolder = { name ->
            if (folderSelection.isEmpty()) folderHaptic.performHapticFeedback(HapticFeedbackType.LongPress)
            toggleFolder(name)
        },
        selectedFolders = folderSelection,
        folderMenu = { folderMenu = it },
        openArtist = vm::openLocalArtist
    )
    // Карточки пересобираются только тогда, когда меняется то, из чего они собраны. Ключей много,
    // но каждый — это ровно одна причина, по которой набор или порядок карточек меняется.
    val cards = remember(
        state.playlists, state.playlistMeta, state.folders, state.artists, state.filter,
        state.favoriteIds, state.tracks, state.settings.collectionSort,
        state.settings.libraryRecents, activeSlice, state.query, folderSelection, gate
    ) { buildCards(state.copy(folders = state.folders.filterNot { it.name in gate.folders }), activeSlice, state.query, cardActions) }

    if (detailPage) {
        LocalCollectionScreen(
            vm = vm, state = state, playback = playback,
            selected = selected, downloads = downloads,
            onMenu = { menuTrack = it }, onSort = { sortSheet = true },
            onAdd = { importSource = true },
            selectionHeader = { toolbarHeight ->
                SelectionHeader(
                    height = toolbarHeight,
                    count = selected.size,
                    allSelected = state.visible.isNotEmpty() && selected.containsAll(state.visible.map { it.id }),
                    onClose = vm::clearSelection, onSelectAll = vm::toggleSelectAllVisible,
                    onPlay = vm::playSelected, onFavorite = vm::favoriteSelected,
                    onAdd = { selectionTarget = false }, onMore = { selectionMenu = true }
                )
            }
        )
    } else NeutralSurfaceTheme {
      Column(Modifier.fillMaxSize().background(Color.Black)) {
        // Neutral black root matches the library reference; detail pages retain their themes.
        Column(Modifier.fillMaxWidth().background(Color.Black).statusBarsPadding()) {
            // Шапка выбора ЗАМЕЩАЕТ обычную, а не встаёт над ней: экран не должен прыгать вниз на
            // 56 dp в момент, когда человек только что попал пальцем по строке.
            //
            // 6.18.0: обе шапки живут в контейнере постоянной высоты и меняются Crossfade'ом. Высота
            // не пересчитывается вообще, поэтому ни список, ни мини-плеер под ним не двигаются —
            // человек видит только смену содержимого, а не перестройку экрана.
            Box(Modifier.fillMaxWidth().height(HEADER_HEIGHT)) {
                if (folderSelection.isNotEmpty()) {
                    val palette = LocalPalette.current
                    Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RoundIconButton(ZiziIcons.Close, palette.text, androidx.compose.ui.graphics.Color.Transparent,
                            onClick = { vm.selectFolders(emptySet()) })
                        Text("${folderSelection.size}", color = palette.text)
                        TextButton(onClick = { vm.selectFolders(state.tracks.filter { !it.isRemote && it.sourceFolder !in gate.folders }.map { it.sourceFolder }.toSet()) }) {
                            Text("Все", color = palette.brand)
                        }
                        Spacer(Modifier.weight(1f))
                        if (folderSelection.size == 1) RoundIconButton(
                            ZiziIcons.More, palette.text, Color.Transparent,
                            onClick = { folderMenu = folderSelection.first() })
                        TextButton(onClick = {
                            pendingHide = folderSelection
                            if (vault.configured) { vm.hideFolders(pendingHide); pendingHide = emptySet(); vm.selectFolders(emptySet()) }
                            else authenticate = true
                        }) { Text("Скрыть папки", color = palette.brand) }
                    }
                } else Crossfade(
                    targetState = selectionMode,
                    animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
                    label = "library-header"
                ) { picking ->
                    if (picking) {
                        SelectionHeader(
                            count = selected.size,
                            allSelected = state.visible.isNotEmpty() && selected.containsAll(state.visible.map { it.id }),
                            onClose = vm::clearSelection,
                            onSelectAll = vm::toggleSelectAllVisible,
                            onPlay = vm::playSelected,
                            onFavorite = vm::favoriteSelected,
                            onAdd = { selectionTarget = false },
                            onMore = { selectionMenu = true }
                        )
                    } else {
                        LibraryHeader(
                            state = state, slice = activeSlice,
                            account = account, profile = profile,
                            onOpenAccount = onOpenAccountMenu,
                            onSettings = onOpenSettings ?: { showSettings = true },
                            onPick = vm::setFilter,
                            onSlice = { sliceName = it?.name }
                        )
                    }
                }
            }

            key(state.filter) {
                LibrarySearchBlock(
                    open = state.searchOpen, query = state.query,
                    hint = when (state.filter) {
                        LibraryFilter.PLAYLISTS -> "Поиск по плейлистам"
                        LibraryFilter.FOLDERS -> "Поиск по папкам"
                        LibraryFilter.ARTISTS -> "Поиск по исполнителям"
                        else -> "Поиск по медиатеке"
                    },
                    onQuery = vm::setQuery
                )
            }

        }
        Box(Modifier.weight(1f)) {
            when {
                state.loading -> CenterNote("Загружаем библиотеку…")
                cardsSurface -> VaultPullSurface(
                    enabled = gate.folders.isNotEmpty() && folderSelection.isEmpty() && !authenticate && !showVault &&
                        (state.filter == LibraryFilter.COLLECTION || state.filter == LibraryFilter.FOLDERS),
                    unlocked = gate.unlocked, onOpen = { openVault() }
                ) { CollectionSurface(
                    gridState = collectionGridState,
                    surfaceBar = {
                        LibraryToolbar(
                            sortLabel = collectionSortLabel(state.settings.collectionSort),
                            view = view, addExpanded = addExpanded,
                            searchOpen = state.searchOpen, shuffle = playback.shuffle,
                            shuffleEnabled = !state.loading && state.tracks.any { !gate.blocks(it) },
                            onView = vm::setLibraryView,
                            onSort = { vm.closeLibraryPanels(); sortSheet = true },
                            onSearch = { vm.setSearchOpen(!state.searchOpen) },
                            onShuffle = vm::shuffleLibrary,
                            onAdd = vm::toggleLibraryAddPanel
                        )
                    },
                    onCreatePlaylist = { if (vm.consumeLibraryAddAction()) creatingPlaylist = true },
                    onAddFolder = { if (vm.consumeLibraryAddAction()) onPickFolder() },
                    onImport = { if (vm.consumeLibraryAddAction()) importSource = true },
                    addExpanded = addExpanded,
                    cards = cards,
                    view = view,
                    connected = if (state.filter == LibraryFilter.FOLDERS && (gate.unlocked || gate.folders.isEmpty())) connectedFolders else emptyList(),
                    onRemoveConnected = { confirmRemoveFolder = it },
                    empty = cardsEmptyNote(state.filter, state.query)
                ) }
                trackGrid && state.visible.isNotEmpty() -> TrackGrid(
                    tracks = state.visible,
                    currentId = currentTrack?.id,
                    playing = playback.isPlaying,
                    onOpen = { track -> vm.play(track, state.visible) },
                    onLongPress = { track -> vm.startSelection(track.id) },
                    onMenu = { track -> menuTrack = track }
                )
                state.visible.isEmpty() -> CenterNote(
                    when {
                        state.query.isNotBlank() -> "Ничего не найдено"
                        state.filter == LibraryFilter.FAVORITES -> "Пока нет избранных треков"
                        else -> "Треков нет. Добавь папку через «Папки»"
                    }
                )
                else -> {
                    // These lambdas used to be allocated fresh on every recomposition, which made
                    // every single row unstable: one state change repainted the whole list.
                    val visible = state.visible
                    val onPlay = remember(visible) { { track: TrackEntity -> vm.play(track, visible) } }
                    val onMenu = remember { { track: TrackEntity -> menuTrack = track } }
                    TrackList(
                        listState = listState,
                        tracks = visible,
                        favoriteIds = state.favoriteIds,
                        currentTrackId = playback.currentTrackId,
                        isPlaying = playback.isPlaying,
                        hasMiniPlayer = true,
                        onPlay = onPlay,
                        onFavorite = vm::toggleFavorite,
                        onMenu = onMenu,
                        selected = selected,
                        selectionMode = selectionMode,
                        onToggleSelect = { track -> vm.toggleSelected(track.id) },
                        onLongPress = { track ->
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            vm.startSelection(track.id)
                        },
                        // Итог списка внизу, как в VK: цифра нужна ровно в тот момент, когда
                        // человек долистал плейлист до конца и спрашивает себя «а сколько тут».
                        footer = if (state.isDrilledIn || state.filter == LibraryFilter.FAVORITES)
                            trackCountLabel(visible.size) + " · " + formatTotalTime(state.visibleMs)
                        else null
                    )
                }
            }

            if (state.scanning) {
                // Collected here, not lifted into LibraryUiState: see MainViewModel.scanProgress.
                val progress by vm.scanProgress.collectAsStateWithLifecycle()
                ScanningBadge(progress, Modifier.align(Alignment.TopCenter))
            }
        }

        // The mini player and the tab bar used to be drawn here, at the bottom of the library.
        // They are now drawn once by the host (see ZiziApp) because they belong to the APP, not to
        // this screen: the moment there is a second destination, a bar owned by one of them either
        // disappears when you leave it or gets duplicated on the other. The parameters stay -
        // `currentTrack` still decides the list's bottom inset - so nothing else in this file moved.
      }
    }

    /* ---------------------------------------------------------------------- 6.29.0 ---- */

    if (sortSheet) {
        LibrarySortSheet(
            // У треков и у карточек разные порядки, и лист показывает ровно тот набор, который
            // применим к тому, что на экране. Одно перечисление на двоих дало бы пункт «по
            // длительности» для папки и «по размеру» для трека.
            tracks = !cardsSurface,
            sortMode = state.settings.sortMode,
            collectionSort = state.settings.collectionSort,
            onSortMode = { vm.setSortMode(it) },
            onCollectionSort = { vm.setCollectionSort(it) },
            onDismiss = { sortSheet = false }
        )
    }

    if (creatingPlaylist) {
        // 6.67.0: полноценный лист вместо голого AlertDialog — превью обложки, подсказки имени,
        // предупреждение о дубле, «Готово» на клавиатуре.
        PlaylistCreateSheet(
            existingNames = remember(state.playlists) { state.playlists.map { it.name } },
            onCreate = { name -> vm.createPlaylist(name) },
            onDismiss = { creatingPlaylist = false }
        )
    }

    playlistMenu?.let { playlist ->
        PlaylistActionsHost(vm, state, playlist.id,
            onOpen = { playlistMenu = null; vm.openPlaylist(playlist.id) },
            onDismiss = { playlistMenu = null })
    }

    menuTrack?.let { track ->
        val menuDownload = rememberMenuDownloadState(vm, track, downloads[track.id])
        TrackMenuSheet(
            favorite = state.favoriteIds.contains(track.id),
            sleepMinutesLeft = playback.sleepMinutesLeft,
            track = track,
            inPlaylist = state.openPlaylist,
            queueSize = playback.queueIds.size,
            download = menuDownload.status,
            downloadChecking = menuDownload.checking,
            onPlayNext = { vm.playNext(track); menuTrack = null },
            onAddToQueue = { vm.addToQueue(track); menuTrack = null },
            // Очередь живёт на экране плеера: открывать её поверх библиотеки значило бы завести
            // второй экземпляр того же листа и два места, где чинить одну и ту же вещь.
            onQueue = { menuTrack = null; vm.play(track, state.visible); onOpenPlayer() },
            onGoToArtist = { menuTrack = null; vm.openArtist(track.artist) },
            onDownload = { vm.download(track) },
            onCancelDownload = { vm.cancelDownload(track) },
            onRemoveDownload = { vm.removeDownload(track) },
            onInfo = { menuTrack = null; infoTrack = track },
            onDismiss = { menuTrack = null },
            onFx = { menuTrack = null; fxTrack = track },
            onSleep = { menuTrack = null; showSleepTimer = true },
            onAddToPlaylist = { menuTrack = null; playlistTarget = track },
            onRemoveFromPlaylist = {
                state.openPlaylist?.let { vm.removeFromPlaylist(it.id, track.id) }
                menuTrack = null
            },
            onToggleFavorite = { vm.toggleFavorite(track) },
            onHide = { vm.removeFromApp(track); menuTrack = null },
            onDeleteFile = { menuTrack = null; confirmDelete = track },
            onShare = { onShare(track); menuTrack = null }
        )
    }
    fxTrack?.let { track ->
        FxSheet(vm, track, onOpenEqualizer = { fxTrack = null; onOpenEqualizer() }, onDismiss = { fxTrack = null })
    }
    if (showSleepTimer) {
        SleepSheet(playback.sleepMinutesLeft, onPick = { vm.setSleepTimer(it); showSleepTimer = false },
            onDismiss = { showSleepTimer = false })
    }
    infoTrack?.let { track ->
        val infoDownload = rememberMenuDownloadState(vm, track, downloads[track.id])
        TrackInfoSheet(
            track = track,
            plays = state.stats[track.id]?.playCount ?: 0,
            downloaded = infoDownload.status == DownloadStatus.Done,
            downloadChecking = infoDownload.checking,
            streamLabel = vm.streamStatusLabel(),
            onDismiss = { infoTrack = null }
        )
    }
    playlistTarget?.let { track ->
        PlaylistPickerSheet(
            playlists = state.playlists,
            onPick = { vm.addToPlaylist(it, track.id); playlistTarget = null },
            onCreate = { vm.createPlaylist(it, listOf(track)); playlistTarget = null },
            onDismiss = { playlistTarget = null }
        )
    }
    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "Удалить файл?",
            message = "«${target.title}» будет удалён с устройства. Отменить это будет нельзя.",
            confirm = "Удалить",
            onConfirm = { confirmDelete = null; onDeleteFile(target) },
            onDismiss = { confirmDelete = null }
        )
    }
    if (showSettings) SettingsSheet(
        vm = vm,
        state = state,
        onDismiss = { showSettings = false },
        onPickFolder = onPickFolder,
        onOpenEqualizer = onOpenEqualizer,
        accountGuest = accountGuest,
        onOpenAccount = onOpenAccount
    )
    renamePlaylistId?.let { id ->
        val playlist = state.playlists.firstOrNull { it.id == id }
        if (playlist == null) renamePlaylistId = null
        else RenameDialog(
            initial = playlist.name,
            onConfirm = { vm.renamePlaylist(id, it); renamePlaylistId = null },
            onDismiss = { renamePlaylistId = null }
        )
    }
    sharePlaylist?.let { playlist ->
        PlaylistShareSheet(vm, playlist) { sharePlaylist = null }
    }
    if (importSource) ImportSourceDialog(
        // MIME берём широкий: половина файловых менеджеров отдаёт .zizi как octet-stream,
        // другая половина — как text/plain, и фильтр по типу отрезал бы половину пользователей.
        onFile = { pickPlaylistFile.launch(arrayOf("*/*")) },
        onPaste = { pasting = true },
        onDismiss = { importSource = false }
    )
    if (pasting) PastePlaylistDialog(
        onConfirm = { vm.offerImport(it) },
        onDismiss = { pasting = false }
    )

    /* ------------------------------------------------------------------ 6.17.0 ---- */

    confirmRemoveFolder?.let { folderUri ->
        ConfirmDialog(
            title = "Отключить папку?",
            message = "Треки из «" + Uri.decode(folderUri).substringAfterLast('/') + "» исчезнут из медиатеки. " +
                "Сами файлы останутся на месте, папку можно подключить снова.",
            confirm = "Отключить",
            onConfirm = { vm.removeFolder(folderUri); confirmRemoveFolder = null },
            onDismiss = { confirmRemoveFolder = null }
        )
    }

    confirmDeletePlaylistId?.let { playlistId ->
        // Плейлист мог исчезнуть, пока диалог был на экране (удалили с другого устройства, импорт
        // перезаписал). Тогда диалог нечего показывать — снимаем его, а не падаем на !!.
        // Писать в состояние прямо из композиции нельзя (это рекомпозиция внутри рекомпозиции),
        // поэтому просто ничего не рисуем: следующее действие пользователя снимет id.
        val playlist = state.playlists.firstOrNull { it.id == playlistId }
        if (playlist != null) {
            val count = state.playlistMeta[playlist.id]?.count ?: 0
            ConfirmDialog(
                title = "Удалить плейлист?",
                message = if (count == 0) "«${playlist.name}» пуст — удалить его?"
                else "«${playlist.name}» и ${trackCountLabel(count)} внутри. Сами треки останутся в медиатеке, но порядок и состав плейлиста вернуть будет нельзя.",
                confirm = "Удалить",
                onConfirm = { vm.deletePlaylist(playlist.id); confirmDeletePlaylistId = null },
                onDismiss = { confirmDeletePlaylistId = null }
            )
        }
    }

    folderMenu?.let { folder ->
        val tracks = remember(folder, state.tracks) { state.tracks.filter { it.sourceFolder == folder } }
        FolderMenuSheet(
            folder = folder,
            label = state.settings.folderLabels[folder] ?: folder,
            count = tracks.size,
            remote = tracks.isNotEmpty() && tracks.all { it.isRemote },
            onOpenSelection = {
                vm.openFolder(folder)
                tracks.firstOrNull()?.let { vm.startSelection(it.id) }
                folderMenu = null
            },
            onMoveAll = { vm.openFolder(folder); selectionTarget = true; folderMenu = null },
            onRename = { renameFolder = folder },
            onDelete = { confirmDeleteFolder = folder },
            onDismiss = { folderMenu = null }
        )
    }

    // 6.27.1: переименование папки. Начальное значение — текущее экранное имя, чтобы правка
    // начиналась с того, что человек видит, а не с имени на диске.
    renameFolder?.let { folder ->
        RenameDialog(
            initial = state.settings.folderLabels[folder] ?: folder,
            title = "Имя папки",
            onConfirm = { vm.renameFolder(folder, it); renameFolder = null },
            onDismiss = { renameFolder = null }
        )
    }

    // 6.27.1: удаление папки с устройства.
    //
    // Подтверждение называет число файлов, а не только имя папки: «Удалить папку?» и «Удалить
    // 348 файлов?» — это для человека два разных вопроса, и второй он читает внимательнее.
    confirmDeleteFolder?.let { folder ->
        val count = remember(folder, state.tracks) { state.tracks.count { it.sourceFolder == folder } }
        ConfirmDialog(
            title = "Удалить папку с устройства?",
            message = "Файлов внутри: $count. Они будут удалены с устройства насовсем — " +
                "не только из плеера. Отменить это нельзя.",
            confirm = "Удалить",
            danger = true,
            onConfirm = {
                val target = folder
                confirmDeleteFolder = null
                vm.requestFolderDeletion(target) { sender ->
                    // Часть файлов удаляется сразу (документы подключённого дерева — наш доступ),
                    // за остальные с Android 11 отвечает система: одно подтверждение на всю
                    // папку. Пустой sender означает, что спрашивать больше нечего.
                    if (sender != null) {
                        pendingFolderDeletion = target
                        runCatching {
                            folderDeleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                        }
                    }
                }
            },
            onDismiss = { confirmDeleteFolder = null }
        )
    }

    if (selectionMenu) {
        SelectionMenuSheet(
            count = selected.size,
            inPlaylist = state.openPlaylist,
            onMove = { selectionMenu = false; selectionTarget = true },
            onRemoveFromPlaylist = { selectionMenu = false; vm.removeSelectedFromPlaylist() },
            onUnsave = { selectionMenu = false; vm.unsaveSelected() },
            onHide = { selectionMenu = false; vm.hideSelected() },
            onDismiss = { selectionMenu = false }
        )
    }

    selectionTarget?.let { move ->
        // Один и тот же лист и для «добавить», и для «перенести»: разница только в подписи и в
        // том, что перенос убирает треки из источника.
        val fromFolder = state.openFolder
        val ids = remember(selected, state.visible, fromFolder) {
            if (selected.isNotEmpty()) state.visible.filter { selected.contains(it.id) }.map { it.id }
            else state.visible.map { it.id }
        }
        PlaylistPickerSheet(
            playlists = state.playlists,
            title = if (move) "Перенести в плейлист" else "Добавить в плейлист",
            subtitle = trackCountLabel(ids.size) +
                if (move && fromFolder != null) " · из папки «$fromFolder»" else "",
            defaultName = state.openPlaylist?.name ?: fromFolder.orEmpty(),
            onPick = { id ->
                vm.addTracksToPlaylist(id, ids, move, state.openPlaylist?.id)
                selectionTarget = null
            },
            onCreate = { name ->
                vm.createPlaylistWithTracks(name, ids, move, state.openPlaylist?.id)
                selectionTarget = null
            },
            onDismiss = { selectionTarget = null }
        )
    }
}

/**
 * Шапка режима выбора (6.17.0).
 *
 * Пять действий и ни одного скрытого: сыграть, в избранное, в плейлист, «ещё» (перенос и три вида
 * удаления) и выход. Всё, что удаляет, живёт под «ещё» намеренно — рядом с «в плейлист» им не
 * место, промах пальцем там стоит дороже одного лишнего тапа.
 */
@Composable
private fun SelectionHeader(
    count: Int,
    allSelected: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onAdd: () -> Unit,
    onMore: () -> Unit,
    height: Dp = HEADER_HEIGHT
) {
    val p = LocalPalette.current
    // Keep the outgoing count during the fade; never flash "0" on close.
    var lastCount by remember { mutableIntStateOf(count) }
    SideEffect { if (count > 0) lastCount = count }
    BoxWithConstraints(Modifier.fillMaxWidth().height(height)) {
        val button = if (maxWidth < 360.dp) 40.dp else 48.dp
        Row(Modifier.fillMaxSize().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionClose, "Закрыть выбор", tint = p.text, modifier = Modifier.size(22.dp))
            }
            Text("${if (count > 0) count else lastCount}", color = p.text, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).semantics { contentDescription = "Выбрано треков: $count" })
            IconButton(onClick = onSelectAll, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionAll, if (allSelected) "Снять выделение" else "Выбрать все",
                    tint = if (allSelected) p.brand else p.text, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onPlay, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionPlay, "Слушать выбранные", tint = p.text, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionFavorite, "Добавить выбранные в избранное", tint = p.brand, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onAdd, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionAdd, "Добавить выбранные в плейлист", tint = p.text, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onMore, modifier = Modifier.size(button)) {
                Icon(ZiziIcons.SelectionMore, "Действия с выбранными", tint = p.text, modifier = Modifier.size(22.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryHeader(
    state: LibraryUiState,
    slice: LibrarySlice?,
    account: AccountLocalState,
    profile: AccountProfile,
    onOpenAccount: () -> Unit,
    onSettings: () -> Unit,
    onPick: (LibraryFilter) -> Unit,
    onSlice: (LibrarySlice?) -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val edge = LibraryGeometry.edge(maxWidth.value).dp
        Row(Modifier.fillMaxSize().padding(horizontal = edge), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape)
                .semantics { contentDescription = "Меню аккаунта" }
                .combinedClickable(onClick = onOpenAccount, onLongClick = onSettings,
                    onLongClickLabel = "Настройки")) {
                AccountAvatar(account.userId.orEmpty(), profileName(account, profile), profile.avatar, 34.dp)
            }
            Spacer(Modifier.width(13.dp))
            LibraryFilterBar(current = state.filter, slice = slice, onPick = onPick, onSlice = onSlice,
                modifier = Modifier.weight(1f))
        }
    }
}


@Composable
private fun TrackList(
    listState: androidx.compose.foundation.lazy.LazyListState,
    tracks: List<TrackEntity>,
    favoriteIds: Set<String>,
    currentTrackId: String?,
    isPlaying: Boolean,
    hasMiniPlayer: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit,
    selected: Set<String> = emptySet(),
    selectionMode: Boolean = false,
    onToggleSelect: (TrackEntity) -> Unit = {},
    onLongPress: (TrackEntity) -> Unit = {},
    footer: String? = null
) {
    val p = LocalPalette.current
    // Вход в режим выбора анимируется ОДНИМ числом на весь список.
    //
    // В 6.18.0 у каждой строки был свой Crossfade: двенадцать видимых строк заводили двенадцать
    // переходов, держали по два поддерева и по три анимации каждая — и всё это в том самом кадре,
    // где палец только что отпустил долгое нажатие. Кадры не успевали, кружки «дёргались».
    // Теперь анимация одна, а строки читают её на фазе отрисовки слоя (graphicsLayer), то есть при
    // переходе не происходит ни одной рекомпозиции списка.
    val pick = animateFloatAsState(
        targetValue = if (selectionMode) 1f else 0f,
        animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
        label = "selection-progress"
    )
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = EDGE, end = 8.dp, top = 2.dp, bottom = LocalBottomChromeInset.current + 20.dp)
    ) {
        items(
            items = tracks,
            key = { it.id },
            contentType = { "track" }
        ) { track ->
            // Only primitives are passed down, so a row recomposes exclusively when ITS state changes.
            TrackRow(
                track = track,
                favorite = favoriteIds.contains(track.id),
                current = track.id == currentTrackId,
                playing = isPlaying && track.id == currentTrackId,
                onPlay = onPlay,
                onFavorite = onFavorite,
                onMenu = onMenu,
                selectionMode = selectionMode,
                pick = pick,
                selected = selected.contains(track.id),
                onToggleSelect = onToggleSelect,
                onLongPress = onLongPress
            )
        }
        if (footer != null) {
            item(key = "footer", contentType = "footer") {
                Text(
                    text = footer,
                    color = p.subtext,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp, start = 6.dp)
                )
            }
        }
    }
}

private val rowArtistStyle = TextStyle(fontFamily = ZiziFontFamily, fontSize = 14.sp, fontWeight = FontWeight.Normal)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    track: TrackEntity,
    favorite: Boolean,
    current: Boolean,
    playing: Boolean,
    onPlay: (TrackEntity) -> Unit,
    onFavorite: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit,
    selectionMode: Boolean = false,
    /** Общий на весь список прогресс входа в выбор: 0 — обычные кнопки, 1 — кружок. */
    pick: State<Float>,
    selected: Boolean = false,
    onToggleSelect: (TrackEntity) -> Unit = {},
    onLongPress: (TrackEntity) -> Unit = {}
) {
    val p = LocalPalette.current
    val accentColor = p.accent
    // Единственная анимация самой строки, и заводится она только когда меняется ЕЁ галочка.
    // Тем же числом рисуется и кружок: заливка, «щелчок» масштаба и цвет — одно значение.
    val mark = animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(SELECTION_MS, easing = FastOutSlowInEasing),
        label = "row-mark"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = ROW_HEIGHT)
            .clip(rowShape)
            // Долгое нажатие входит в выбор, обычное — играет; в режиме выбора обычное нажатие
            // переключает галочку. Ровно так ведёт себя любая галерея, и учить этому не нужно.
            .combinedClickable(
                onClick = { if (selectionMode) onToggleSelect(track) else onPlay(track) },
                onLongClick = { onLongPress(track) }
            )
            // Подсветка выбранной строки въезжает цветом, а не подменяется кадром: при быстром
            // проставлении галочек список перестаёт мигать. Читается в .drawBehind, то есть на
            // фазе отрисовки: строка НЕ рекомпозится 11 кадров подряд ради заливки фона.
            .drawBehind {
                val a = mark.value
                if (a > 0f) drawRect(color = accentColor, alpha = 0.16f * a)
            }
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // One clip for the whole tile instead of one per child (6.5). A rounded clip is a
        // graphics layer, and the playing row was paying for three of them - artwork, scrim and
        // the tile itself - on every frame of a scroll it appeared in.
        Box(Modifier.size(ART_SIZE).clip(artShape)) {
            TrackArtwork(
                track = track,
                maxPx = ARTWORK_ROW_PX,
                modifier = Modifier.fillMaxSize(),
                glyphSize = 18
            )
            // 6.14.0: тот же самый маркер, что в поиске и очереди, а не его копия. Раньше здесь
            // лежал свой затемняющий Box со своим эквалайзером — правило «строка показывает
            // состояние» жило в трёх местах и в одном из них разъехалось. Размер полосок оставлен
            // прежним (17.dp), чтобы строка медиатеки визуально не менялась.
            NowPlayingBadge(
                current = current,
                playing = playing,
                size = ART_SIZE,
                corner = 6.dp,
                barSize = 17.dp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            TrackTitle(
                title = track.title,
                /*
                 * 6.29.0: ФИРМЕННЫЙ ОРАНЖЕВЫЙ НА ИГРАЮЩЕЙ СТРОКЕ, КАК В ПОИСКЕ.
                 *
                 * Здесь стоял `p.accent` — тот самый динамический акцент, который при включённом
                 * «Цвете из обложки» берётся из обложки текущего трека. А обложка текущего трека
                 * лежит в этой же строке, в 12 dp слева. То есть имя красилось в цвет картинки,
                 * стоящей рядом: на тёмном арте оно уходило в фон, на пёстром — в кашу. В поиске
                 * этой ошибки не было (SearchScreen: `if (current) p.brand else p.text`), и
                 * получалось, что один и тот же трек в двух списках подписан по-разному.
                 *
                 * Ровно та же причина, по которой полоса мини-плеера стала оранжевой в 6.28.0:
                 * «что играет сейчас» — это показание, а не украшение обложки.
                 */
                color = if (current) p.brand else p.text,
                dim = if (current) p.brand.copy(alpha = 0.55f) else p.text.copy(alpha = 0.42f),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(1.dp))
            // Style hoisted to a file-level constant: passing fontSize/fontWeight makes Text
            // merge a fresh TextStyle on every composition, and this line exists 3000 times.
            Text(
                text = track.artist,
                color = p.subtext,
                style = rowArtistStyle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        // Правый край строки — слот постоянной ширины (6.18.1).
        //
        // Оба состояния лежат в раскладке ВСЕГДА и никогда не пересобираются: меняется только
        // альфа их слоёв. Ни Crossfade, ни появления/исчезновения узлов, ни рекомпозиции — поэтому
        // вход в выбор стоит ровно один кадр разметки и дальше едет на композиторе.
        //
        // Кружок стоит в коробке 34 dp у правого края — там же, где центр «⋮». Раньше он
        // центрировался по всему слоту (74 dp), то есть вылезал ровно между «сердцем» и «⋮», и
        // перекрёстное затухание двух картинок в разных точках читалось как рывок.
        Box(Modifier.width(TRAILING_W)) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .graphicsLayer { alpha = 1f - pick.value },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(
                    icon = ZiziIcons.HeartFilled,
                    // 6.27.1: сердце горит фирменным оранжевым. См. QuickAction в Sheets.kt —
                    // причина та же: акцент из обложки способен совпасть с фоном строки.
                    tint = if (favorite) p.brand else p.subtext,
                    background = Color.Transparent,
                    size = 38,
                    iconSize = 19,
                    onClick = { onFavorite(track) }
                )
                RoundIconButton(
                    icon = ZiziIcons.More,
                    tint = p.subtext,
                    background = Color.Transparent,
                    size = 34,
                    iconSize = 18,
                    onClick = { onMenu(track) }
                )
            }
            SelectDot(
                mark = mark,
                ring = p.subtext,
                accent = p.accent,
                onAccent = p.onAccent,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(TRAILING_SLOT)
                    .graphicsLayer { alpha = pick.value }
            )
            // В режиме выбора весь слот — одна большая мишень «переключить», и она же закрывает
            // невидимые «сердце» и «⋮»: попасть в чужое действие пальцем стало нечем. Узел
            // добавляется один раз на переключение режима, а не каждый кадр.
            if (selectionMode) {
                val slotTap = remember { MutableInteractionSource() }
                Spacer(
                    Modifier
                        .matchParentSize()
                        .clickable(
                            interactionSource = slotTap,
                            indication = null,
                            onClick = { onToggleSelect(track) }
                        )
                )
            }
        }
    }
}

/**
 * Кружок выбора — один Canvas вместо пары иконок Material.
 *
 * Почему не `RadioButtonUnchecked` → `CheckCircle`: это два разных рисунка, и подмена вектора
 * происходит мгновенно, посреди анимации масштаба. Глаз видит не «галочка щёлкнула», а «иконка
 * прыгнула и заменилась». Здесь кольцо и заливка — одна фигура: кольцо гаснет, диск проявляется и
 * подрастает с 0.9 до 1, галочка прочерчивается тем же числом. Всё в фазе отрисовки: пока палец
 * бежит по списку и щёлкает строки, ни одна из них не рекомпозится.
 */
@Composable
private fun SelectDot(
    mark: State<Float>,
    ring: Color,
    accent: Color,
    onAccent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val a = mark.value
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = 10.5.dp.toPx() * (0.9f + 0.1f * a)
        if (a < 1f) {
            drawCircle(color = ring, radius = r, center = c, alpha = 1f - a, style = Stroke(width = 1.8.dp.toPx()))
        }
        if (a > 0f) {
            drawCircle(color = accent, radius = r, center = c, alpha = a)
            // Галочка: три точки в долях радиуса, поэтому она не разъезжается ни при каком размере.
            val w = 2.0.dp.toPx()
            val p1 = Offset(c.x - 0.44f * r, c.y + 0.02f * r)
            val p2 = Offset(c.x - 0.12f * r, c.y + 0.34f * r)
            val p3 = Offset(c.x + 0.46f * r, c.y - 0.32f * r)
            drawLine(onAccent, p1, p2, strokeWidth = w, cap = StrokeCap.Round, alpha = a)
            drawLine(onAccent, p2, p3, strokeWidth = w, cap = StrokeCap.Round, alpha = a)
        }
    }
}



@Composable
fun MiniPlayer(vm: MainViewModel, track: TrackEntity, isPlaying: Boolean, onOpen: () -> Unit, animateTitle: Boolean = true) {
    val outputs by vm.audioOutput.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    val progress = vm.progress.collectAsStateWithLifecycle()
    var showOutput by rememberSaveable { mutableStateOf(false) }
    MiniPlayerCard(track = track, isPlaying = isPlaying, output = outputs.active,
        favorite = track.id in library.favoriteIds, onOpen = onOpen,
        onOutput = { showOutput = true }, onFavorite = { vm.toggleFavorite(track) },
        onPlayPause = vm::playPause, animateTitle = animateTitle,
        progress = {
            val value = progress.value
            MiniPlayerGeometry.progress(track.id, value.trackId, value.positionMs, value.durationMs)
        })
    if (showOutput) AudioOutputSheet(vm = vm, track = track, onDismiss = { showOutput = false })
}

@Composable
private fun ScanningBadge(progress: ScanProgress?, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    // "Сканируем…" with no end in sight is indistinguishable from a hang, and on a large folder the
    // wait used to be tens of seconds. The badge now says what is happening and how far it has got.
    val label = when {
        progress == null -> "Сканируем…"
        progress.total > 0 -> "${progress.label} · ${progress.done} / ${progress.total}"
        else -> progress.label
    }
    Row(
        modifier
            .padding(top = 8.dp)
            .clip(CircleShape)
            .background(p.accent)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = p.onAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CenterNote(text: String) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = p.subtext, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Обложка плейлиста (6.27.1).
 *
 * Три источника, строго по приоритету, и каждый выбран за конкретное поведение.
 *
 * 1. **Своя обложка** (`playlist.coverUri`). Ставится один раз — первым сборником, который в этот
 *    плейлист добавили, — и больше не меняется никогда. Добавили в плейлист второй альбом и
 *    третий — иконка остаётся от первого: ты просил именно это, и это правильно по сути. Обложка
 *    в списке работает как имя: она нужна, чтобы узнавать плейлист, а не чтобы отчитываться о
 *    последнем действии. Прыгающая на каждое добавление картинка не опознавательный знак, а шум.
 * 2. **Первый трек.** Плейлист собран руками из своих треков — обложкой становится начало.
 * 3. **Базовая обложка.** Плейлист пуст или у начала нет картинки: градиент с нотой, тот же, что
 *    у трека без обложки, с зерном по id плейлиста. Зерно по id, а не по имени: переименование
 *    не должно менять картинку, а два плейлиста с одинаковым именем обязаны отличаться.
 *
 * Отдельного «плейлист без обложки» в этом списке нет и быть не может — третий пункт всегда
 * даёт результат. До 6.27.1 у плейлистов не было ни одного из трёх.
 */
@Composable
private fun PlaylistCover(
    playlist: PlaylistEntity,
    first: TrackEntity?,
    modifier: Modifier = Modifier,
    maxPx: Int = 160,
    glyphSize: Int = 22
) {
    val seed = "playlist:" + playlist.id
    when {
        !playlist.coverUri.isNullOrBlank() ->
            RemoteArtwork(playlist.coverUri, seed, maxPx, modifier, glyphSize)
        first != null -> TrackArtwork(first, maxPx, modifier, glyphSize)
        else -> RemoteArtwork(null, seed, maxPx, modifier, glyphSize)
    }
}


/* ========================================================================================= */
/* 6.29.0: КОЛЛЕКЦИЯ                                                                         */
/*                                                                                           */
/* До этой версии медиатека была одним плоским списком треков с четырьмя чипами-разрезами.    */
/* Плоский список отвечает на вопрос «покажи всё», но человек, открывая медиатеку, почти      */
/* никогда не спрашивает «всё» — он идёт к своему плейлисту, к папке, которую вчера           */
/* подключил, к исполнителю, которого нашёл на выходных. Коллекция — это те самые входы,      */
/* карточками, в одном потоке, с порядком «последнее открытое сверху».                       */
/*                                                                                           */
/* 6.39.5: three columns use actual parent constraints, not physical display width.           */
/* Reference: 1080 px width, ~45 px outside/gaps, ~300 px tile, ~185 px collection artwork.     */
/* Track rows now share artwork/text metrics with search; collection rows remain larger.      */
/* ========================================================================================= */

/** Разрезы, которые показываются карточками, а не списком треков. */
private val CARD_FILTERS = setOf(
    LibraryFilter.COLLECTION, LibraryFilter.PLAYLISTS, LibraryFilter.FOLDERS, LibraryFilter.ARTISTS
)

/**
 * Порядок чипов. [LibraryFilter.COLLECTION] здесь нет намеренно: «коллекция» — это не выбранный
 * чип, а состояние «ни один не нажат». Отдельный чип «Всё» рядом с крестиком означал бы два
 * разных способа сделать одно и то же.
 */
private val FILTER_CHIPS = listOf(
    LibraryFilter.PLAYLISTS, LibraryFilter.FOLDERS, LibraryFilter.ARTISTS
)

private fun filterLabel(filter: LibraryFilter): String = when (filter) {
    LibraryFilter.COLLECTION -> "Коллекция"
    LibraryFilter.TRACKS -> "Треки"
    LibraryFilter.FAVORITES -> "Избранное"
    LibraryFilter.PLAYLISTS -> "Плейлисты"
    LibraryFilter.FOLDERS -> "Папки"
    LibraryFilter.ARTISTS -> "Исполнители"
}

/**
 * Подрез — второй чип, который появляется справа от активного (в референсе это «Мои плейлисты»
 * рядом с «Плейлисты»).
 *
 * Здесь их всего два, и оба про одно: спрятать шум. Пустой плейлист и исполнитель с одним
 * случайным треком занимают в сетке столько же места, сколько живые, и мешают ровно тем, у кого
 * их много. Подрезов «Скачанные» и «Из сети» здесь нет: это про треки, а треки в коллекции не
 * карточки — для них есть свой разрез со своей сортировкой.
 */
private enum class LibrarySlice(val label: String) {
    NON_EMPTY("Не пустые"),
    BIG("5+ треков")
}

private fun slicesFor(filter: LibraryFilter): List<LibrarySlice> = when (filter) {
    LibraryFilter.PLAYLISTS -> listOf(LibrarySlice.NON_EMPTY)
    LibraryFilter.ARTISTS -> listOf(LibrarySlice.BIG)
    else -> emptyList()
}

/** Чип медиатеки: 34.6 dp и полная пилюля — замер референса. См. PillChip. */
private val LIB_CHIP_HEIGHT = 34.dp
private val LIB_CHIP_RADIUS = 17.dp
private val CARD_ROW_HEIGHT = MediaDimensions.collectionRow
private val CARD_ART = MediaDimensions.collectionArt
private val SORT_ROW_HEIGHT = 64.dp
private val cardShape = RoundedCornerShape(10.dp)

/*
 * Размер декодирования выбирается по типу поверхности, не по порогу размера dp:
 * обложка новой тройной сетки меньше 120 dp, но ей всё равно нужна плиточная картинка.
 */
private const val CARD_ART_PX = 224
private const val CARD_TILE_PX = 384

private enum class CardKind { FAVORITES, TRACKS, PLAYLIST, FOLDER, ARTIST }

/**
 * Одна карточка коллекции — уже готовая к рисованию.
 *
 * Экран не знает, что внутри плейлист, папка или исполнитель: он рисует обложку, два текста и
 * при наличии — меню. Вся разница между сущностями решена один раз в [buildCards], а не в
 * четырёх ветках внутри верстки.
 */
private class LibraryCard(
    val key: String,
    val kind: CardKind,
    val title: String,
    /** Первая половина подписи: «Плейлист», «Папка», «Исполнитель». */
    val kindLabel: String,
    /** Вторая половина: «14 треков», «Создать». Пусто — значит подпись из одного слова. */
    val meta: String,
    val sortName: String,
    val addedAt: Long,
    val size: Int,
    val pinned: Boolean = false,
    val playlist: PlaylistEntity? = null,
    val cover: TrackEntity? = null,
    val icon: ImageVector? = null,
    /** Обложка «Избранного» — фирменный градиент, а не серый квадрат с иконкой. */
    val brandCover: Boolean = false,
    val onOpen: () -> Unit,
    val onMenu: (() -> Unit)? = null,
    val onLongPress: (() -> Unit)? = null,
    val selected: Boolean = false
)

/** Куда ведут нажатия по карточкам. Отдельным классом, чтобы [buildCards] не принимал 10 лямбд. */
private class CardActions(
    val openFavorites: () -> Unit,
    val openAllTracks: () -> Unit,
    val openPlaylist: (Long) -> Unit,
    val playlistMenu: (PlaylistEntity) -> Unit,
    val openFolder: (String) -> Unit,
    val selectFolder: (String) -> Unit,
    val selectedFolders: Set<String>,
    val folderMenu: (String) -> Unit,
    val openArtist: (String) -> Unit
)

/**
 * Собрать карточки для текущего разреза.
 *
 * Обычная функция, не composable: сюда приходят данные, отсюда уходит список — и это позволяет
 * держать её под `remember` с честным набором ключей вместо пересборки на каждый кадр.
 *
 * Порядок результата: закреплённые, затем отсортированные. Закреплённые
 * («Избранное», «Все треки») не участвуют в сортировке вообще — иначе «по алфавиту» увело бы
 * избранное в середину экрана, а это единственные две карточки, которые есть у всех и всегда.
 */
private fun buildCards(
    state: LibraryUiState,
    slice: LibrarySlice?,
    query: String,
    actions: CardActions
): List<LibraryCard> {
    val filter = state.filter
    val q = query.trim()
    // Поиск внутри коллекции ищет по КАРТОЧКАМ. Треки по этому же запросу уже отфильтрованы во
    // ViewModel — там своя выдача, и смешивать их в один список значило бы показать 200 строк
    // треков там, где человек искал плейлист.
    fun hit(name: String) = q.isEmpty() || name.contains(q, ignoreCase = true)
    val out = ArrayList<LibraryCard>(state.playlists.size + state.folders.size + state.artists.size + 4)

    if (filter == LibraryFilter.COLLECTION) {
        if (hit("Избранное")) out += LibraryCard(
            key = RECENT_FAVORITES,
            kind = CardKind.FAVORITES,
            title = "Избранное",
            kindLabel = "Плейлист",
            meta = trackCountLabel(state.favoriteIds.size),
            sortName = "избранное",
            addedAt = Long.MAX_VALUE,
            size = state.favoriteIds.size,
            pinned = true,
            icon = ZiziIcons.HeartFilled,
            brandCover = true,
            onOpen = actions.openFavorites
        )
        if (hit("Все треки")) out += LibraryCard(
            key = RECENT_TRACKS,
            kind = CardKind.TRACKS,
            title = "Все треки",
            kindLabel = "Медиатека",
            meta = trackCountLabel(state.tracks.size),
            sortName = "все треки",
            addedAt = Long.MAX_VALUE - 1,
            size = state.tracks.size,
            pinned = true,
            icon = ZiziIcons.Library,
            onOpen = actions.openAllTracks
        )
    }

    if (filter == LibraryFilter.COLLECTION || filter == LibraryFilter.PLAYLISTS) {
        state.playlists.forEach { playlist ->
            val meta = state.playlistMeta[playlist.id]
            val count = meta?.count ?: 0
            if (slice == LibrarySlice.NON_EMPTY && count == 0) return@forEach
            if (!hit(playlist.name)) return@forEach
            out += LibraryCard(
                key = RECENT_PLAYLIST + playlist.id,
                kind = CardKind.PLAYLIST,
                title = playlist.name,
                kindLabel = "Плейлист",
                meta = trackCountLabel(count),
                sortName = playlist.name.lowercase(),
                addedAt = playlist.createdAt,
                size = count,
                playlist = playlist,
                cover = meta?.cover,
                icon = ZiziIcons.Queue,
                onOpen = { actions.openPlaylist(playlist.id) },
                onMenu = { actions.playlistMenu(playlist) },
                onLongPress = { actions.playlistMenu(playlist) }
            )
        }
    }

    if (filter == LibraryFilter.COLLECTION || filter == LibraryFilter.FOLDERS) {
        state.folders.forEach { folder ->
            if (!hit(folder.label)) return@forEach
            out += LibraryCard(
                key = RECENT_FOLDER + folder.name,
                kind = CardKind.FOLDER,
                title = folder.label,
                kindLabel = "Папка",
                meta = trackCountLabel(folder.count),
                sortName = folder.label.lowercase(),
                addedAt = folder.addedAt,
                size = folder.count,
                icon = ZiziIcons.FolderMusic,
                onOpen = { actions.openFolder(folder.name) },
                onMenu = { actions.folderMenu(folder.name) },
                onLongPress = if (state.tracks.any { !it.isRemote && it.sourceFolder == folder.name })
                    ({ actions.selectFolder(folder.name) }) else null,
                selected = folder.name in actions.selectedFolders
            )
        }
    }

    if (filter == LibraryFilter.COLLECTION || filter == LibraryFilter.ARTISTS) {
        state.artists.forEach { artist ->
            if (slice == LibrarySlice.BIG && artist.count < 5) return@forEach
            if (!hit(artist.name)) return@forEach
            out += LibraryCard(
                key = RECENT_ARTIST + artist.name,
                kind = CardKind.ARTIST,
                title = artist.name,
                kindLabel = "Исполнитель",
                meta = trackCountLabel(artist.count),
                sortName = artist.name.lowercase(),
                addedAt = artist.addedAt,
                size = artist.count,
                cover = artist.cover,
                icon = ZiziIcons.Person,
                onOpen = { actions.openArtist(artist.name) }
            )
        }
    }

    // Creation/import actions live under the toolbar Plus, never among collection results.

    fun rank(key: String): Int {
        val index = state.settings.libraryRecents.indexOf(key)
        // Никогда не открытое — не «самое старое», а «неизвестно когда»: уходит в конец списка
        // недавних, но сохраняет свой алфавитный порядок внутри этого хвоста.
        return if (index < 0) Int.MAX_VALUE else index
    }
    val comparator: Comparator<LibraryCard> = when (state.settings.collectionSort) {
        CollectionSort.RECENT -> compareBy<LibraryCard>({ rank(it.key) }, { it.sortName })
        CollectionSort.ADDED -> compareByDescending<LibraryCard> { it.addedAt }.thenBy { it.sortName }
        CollectionSort.TITLE -> compareBy { it.sortName }
        CollectionSort.SIZE -> compareByDescending<LibraryCard> { it.size }.thenBy { it.sortName }
    }
    val pinned = out.filter { it.pinned }
    val body = out.filterNot { it.pinned }.sortedWith(comparator)
    return pinned + body
}

private fun cardsEmptyNote(filter: LibraryFilter, query: String): String = when {
    query.isNotBlank() -> "По запросу «" + query.trim() + "» в медиатеке ничего нет"
    filter == LibraryFilter.PLAYLISTS -> "Плейлистов пока нет. Создай первый через «+»"
    filter == LibraryFilter.FOLDERS -> "Папки не подключены. Добавь папку через «+»"
    filter == LibraryFilter.ARTISTS -> "Исполнители появятся вместе с треками"
    else -> "Медиатека пуста"
}

private fun collectionSortLabel(sort: CollectionSort): String = when (sort) {
    CollectionSort.RECENT -> "Недавние"
    CollectionSort.ADDED -> "По дате добавления"
    CollectionSort.TITLE -> "По алфавиту"
    CollectionSort.SIZE -> "По размеру"
}

private fun sortModeLabel(mode: SortMode): String = when (mode) {
    SortMode.TITLE -> "По алфавиту"
    SortMode.ARTIST -> "По исполнителю"
    SortMode.DURATION -> "По длительности"
    SortMode.RECENT -> "Недавние"
    SortMode.PLAYS -> "По прослушиваниям"
}

/**
 * Ряд чипов.
 *
 * Логика референса: пока не выбран ни один разрез — ряд из всех чипов; как только выбран —
 * ряд сворачивается в крестик + активный чип + его подрезы. Это не украшение: так на экране
 * всегда видно И что выбрано, И как это снять, не уводя палец к кнопке «назад».
 *
 * Активный чип — фирменный оранжевый, а не «цвет из обложки»: чип отвечает на вопрос «что я
 * нажал», и ответ не должен менять цвет от того, какой трек сейчас играет.
 */
@Composable
private fun LibraryFilterBar(
    current: LibraryFilter,
    slice: LibrarySlice?,
    onPick: (LibraryFilter) -> Unit,
    onSlice: (LibrarySlice?) -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalPalette.current
    val colors = remember(p.chip, p.text, p.brand, p.onAccent) {
        ChipColors(
            background = p.chip,
            content = p.text,
            activeBackground = p.brand,
            activeContent = p.onAccent
        )
    }
    val items = remember { FILTER_CHIPS.map { FilterRailItem(it.name, filterLabel(it)) } }
    SelectionFilterRail(items = items, selectedId = current.takeIf { it in FILTER_CHIPS }?.name,
        onSelect = { onPick(it?.let(LibraryFilter::valueOf) ?: LibraryFilter.COLLECTION) },
        modifier = modifier, tag = "library-filter", chipHeight = LIB_CHIP_HEIGHT,
        fontSize = 13.5.sp, fontWeight = FontWeight.Bold, chipGap = 9.dp, tailMinWidth = 57.dp,
        trailingContent = {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                slicesFor(current).forEach { item ->
                    LibraryFilterChip(item.label, slice == item, colors) { onSlice(if (slice == item) null else item) }
                }
            }
        })
}

@Composable
private fun LibraryFilterChip(label: String, active: Boolean, colors: ChipColors, onClick: () -> Unit) {
    Box(Modifier.height(LIB_CHIP_HEIGHT).clip(RoundedCornerShape(LIB_CHIP_RADIUS))
        .background(if (active) colors.activeBackground else colors.background)
        .semantics { selected = active }.clickable(onClick = onClick).padding(horizontal = 17.dp),
        contentAlignment = Alignment.Center) {
        Text(label, color = if (active) colors.activeContent else colors.content,
            fontSize = 13.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** A single keyed lazy grid owns all four modes, including one-column lists.
 * Changing column count keeps item identity and the first visible collection, not a row index.
 */
@Composable
private fun CollectionSurface(
    gridState: LazyGridState,
    surfaceBar: @Composable () -> Unit,
    cards: List<LibraryCard>,
    view: LibraryView,
    connected: List<String>,
    onRemoveConnected: (String) -> Unit,
    onCreatePlaylist: () -> Unit,
    onAddFolder: () -> Unit,
    onImport: () -> Unit,
    addExpanded: Boolean,
    empty: String
) {
    val shortcuts = remember(cards) { cards.filter { it.pinned } }
    val body = remember(cards) { cards.filterNot { it.pinned } }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val edge = LibraryGeometry.edge(maxWidth.value).dp
        val gap = LibraryGeometry.gap(maxWidth.value).dp
        val width = LibraryGeometry.tile(maxWidth.value, view.columns).dp
        val shortcutHeight = LibraryGeometry.shortcutHeight(maxWidth.value).dp
        LazyVerticalGrid(
            columns = GridCells.Fixed(view.columns), state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = edge, end = edge, bottom = LocalBottomChromeInset.current + 20.dp),
            horizontalArrangement = Arrangement.spacedBy(gap)
        ) {
            if (shortcuts.isNotEmpty()) item(key = "surface:shortcuts", span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    shortcuts.forEach { card -> LibraryShortcut(card, shortcutHeight, Modifier.weight(1f)) }
                }
            }
            item(key = "surface:sort", span = { GridItemSpan(maxLineSpan) }, contentType = "sort") { surfaceBar() }
            // Stable slot in every view; expanding actions never changes collection identity.
            item(key = "panel:add", span = { GridItemSpan(maxLineSpan) }) {
                AnimatedVisibility(addExpanded,
                    enter = expandVertically(tween(LIBRARY_ADD_MS, easing = FastOutSlowInEasing), expandFrom = Alignment.Top) +
                        fadeIn(tween(180)),
                    exit = shrinkVertically(tween(LIBRARY_ADD_MS, easing = FastOutSlowInEasing), shrinkTowards = Alignment.Top) +
                        fadeOut(tween(140))) {
                    LibraryAddPanel(enabled = addExpanded, onCreatePlaylist = onCreatePlaylist,
                        onAddFolder = onAddFolder, onImport = onImport)
                }
            }
            if (body.isEmpty()) item(key = "empty:collections", span = { GridItemSpan(maxLineSpan) }) {
                Text(empty, color = LocalPalette.current.subtext, modifier = Modifier.padding(vertical = 24.dp))
            }
            items(body, key = { it.key }, contentType = { if (view.columns == 1) "row" else "tile" }) { card ->
                if (view.columns == 1) LibraryCardRow(card, compact = view == LibraryView.COMPACT)
                else Box(Modifier.padding(bottom = 14.dp)) { LibraryCardTile(card, width) }
            }
            connectedBlock(connected, onRemoveConnected)
        }
    }
}

@Composable
private fun LibraryShortcut(card: LibraryCard, height: Dp, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    // Colour belongs to the cover only; the rest of both shortcuts is neutral graphite.
    Row(modifier.heightIn(min = height).clip(RoundedCornerShape(5.dp)).background(p.chip)
        .clickable(onClick = card.onOpen), verticalAlignment = Alignment.CenterVertically) {
        LibraryCardCover(card, height, shortcut = true)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(card.title, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(card.meta, color = p.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Список подключённых папок под сеткой (перенесён из FolderList, 6.19.0).
 *
 * Живёт отдельным блоком, потому что отвечает на другой вопрос: сетка показывает, ГДЕ музыка,
 * а этот список — ЧТО подключено, включая папки, из которых не удалось прочитать ни одного
 * файла. Без него отключить сломавшийся источник было бы нечем.
 */
private fun LazyGridScope.connectedBlock(folders: List<String>, onRemove: (String) -> Unit) {
    if (folders.isEmpty()) return
    item(key = "connected-title", span = { GridItemSpan(maxLineSpan) }) {
        val p = LocalPalette.current
        Text(
            "Подключённые папки",
            color = p.subtext,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 18.dp, bottom = 6.dp, start = 4.dp)
        )
    }
    items(folders, key = { "connected:$it" }, span = { GridItemSpan(maxLineSpan) }) { uri ->
        val p = LocalPalette.current
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(ZiziIcons.Link, null, tint = p.subtext, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                Uri.decode(uri).substringAfterLast('/'),
                color = p.subtext,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            RoundIconButton(
                ZiziIcons.Close, p.subtext, Color.Transparent,
                size = 34, iconSize = 16, onClick = { onRemove(uri) }
            )
        }
    }
}

/**
 * Строка коллекции: 72 dp, обложка 56 dp.
 *
 * Не 56 dp, как у трека, и не 86 dp, как в референсе. Полка — это вход в набор, и он должен
 * читаться крупнее строки трека; но 86 dp у референса стоят треть экрана, а платить их за
 * список из четырёх плейлистов незачем.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryCardRow(card: LibraryCard, compact: Boolean = false) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = if (compact) 52.dp else CARD_ROW_HEIGHT)
            .clip(rowShape)
            .background(if (card.selected) p.brand.copy(alpha = 0.22f) else Color.Transparent)
            .semantics {
                selected = card.selected
                card.onMenu?.let { menu -> customActions = listOf(CustomAccessibilityAction("Действия") { menu(); true }) }
            }
            .combinedClickable(onClick = card.onOpen, onLongClick = card.onLongPress ?: card.onMenu),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!compact) {
            LibraryCardCover(card, CARD_ART)
            Spacer(Modifier.width(14.dp))
        } else Spacer(Modifier.width(4.dp))
        Column(Modifier.weight(1f)) {
            Text(
                (if (card.selected) "✓ " else "") + card.title,
                color = p.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            LibraryCardSubtitle(card, if (compact) 12.sp else 14.sp, showPin = compact)
        }
        card.onMenu?.let { menu ->
            RoundIconButton(ZiziIcons.More, p.subtext, Color.Transparent, size = 38, iconSize = 19, onClick = menu)
        }
    }
}

/** Карточка коллекции: квадратная обложка в треть ширины сетки и подписи под ней. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryCardTile(card: LibraryCard, width: Dp) {
    val p = LocalPalette.current
    Column(
        Modifier
            .width(width)
            .clip(cardShape)
            .background(if (card.selected) p.brand.copy(alpha = 0.22f) else Color.Transparent)
            .semantics {
                selected = card.selected
                card.onMenu?.let { menu -> customActions = listOf(CustomAccessibilityAction("Действия") { menu(); true }) }
            }
            .combinedClickable(onClick = card.onOpen, onLongClick = card.onLongPress ?: card.onMenu)
    ) {
        Box(Modifier.size(width)) {
            LibraryCardCover(card, width, tile = true)

        }
        Spacer(Modifier.height(8.dp))
        Text(
            (if (card.selected) "✓ " else "") + card.title,
            color = p.text,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(2.dp))
        LibraryCardSubtitle(card, 12.sp, showPin = false)
        Spacer(Modifier.height(2.dp))
    }
}

/** Tiles use only counts; compact rows retain entity type because they have no cover. */
@Composable
private fun LibraryCardSubtitle(card: LibraryCard, size: TextUnit, showPin: Boolean = true) {
    val p = LocalPalette.current
    val text = when {
        !showPin -> card.meta
        card.kindLabel.isEmpty() -> card.meta
        card.meta.isEmpty() -> card.kindLabel
        else -> card.kindLabel + " · " + card.meta
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (showPin && card.pinned) {
            Icon(ZiziIcons.Pin, contentDescription = "Закреплено", tint = p.brand, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(
            text,
            color = p.subtext,
            fontSize = size,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Обложка карточки. Исполнитель — в круге, всё остальное — в квадрате с нашим радиусом 6 dp.
 *
 * Круг здесь несёт смысл, а не стиль: в одном потоке лежат сущности разной природы, и форма —
 * единственный признак, который читается до текста подписи.
 */
@Composable
private fun LibraryCardCover(card: LibraryCard, size: Dp, tile: Boolean = false, shortcut: Boolean = false) {
    val p = LocalPalette.current
    val shape = if (card.kind == CardKind.ARTIST) CircleShape else if (shortcut) RoundedCornerShape(0.dp) else artShape
    val px = if (tile) CARD_TILE_PX else CARD_ART_PX
    val glyph = (size.value / 3.4f).toInt()
    when {
        card.playlist != null -> PlaylistCover(
            playlist = card.playlist,
            first = card.cover,
            modifier = Modifier.size(size).clip(shape),
            maxPx = px,
            glyphSize = glyph
        )
        card.brandCover -> Box(
            Modifier
                .size(size)
                .clip(shape)
                .background(Brush.linearGradient(listOf(LibraryShortcutColors.favoritesTop, LibraryShortcutColors.favoritesBottom))),
            contentAlignment = Alignment.Center
        ) {
            Icon(ZiziIcons.HeartFilled, null, tint = LibraryShortcutColors.glyph, modifier = Modifier.size(size * if (shortcut) 0.28f else 0.38f))
        }
        card.kind == CardKind.TRACKS -> Box(
            Modifier.size(size).clip(shape).background(Brush.linearGradient(
                listOf(LibraryShortcutColors.tracksTop, LibraryShortcutColors.tracksBottom))),
            contentAlignment = Alignment.Center
        ) {
            Icon(ZiziIcons.Library, null, tint = LibraryShortcutColors.glyph, modifier = Modifier.size(size * if (shortcut) 0.36f else 0.38f))
        }
        card.cover != null -> TrackArtwork(
            card.cover, px,
            Modifier.size(size).clip(shape).background(p.chip),
            glyphSize = glyph
        )
        else -> Box(
            Modifier.size(size).clip(shape).background(p.chip),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                card.icon ?: ZiziIcons.Library,
                null,
                tint = p.subtext,
                modifier = Modifier.size(size / 3.4f)
            )
        }
    }
}

/**
 * Треки сеткой.
 *
 * Тот же ряд-из-двух, что у карточек, и те же жесты, что в списке: тап — играть, долгое
 * нажатие — начать выбор. Выбор, начавшись, возвращает список: отмечать галочками сетку
 * обложек можно, но пересчитывать выделение глазами по двум колонкам — нет.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackGrid(
    tracks: List<TrackEntity>,
    currentId: String?,
    playing: Boolean,
    // 6.32.0. Набор избранного здесь больше не нужен: метку с обложек убрали, а параметр,
    // который никто не показывает, — это не «задел на будущее», а мина для следующего чтения.
    // Заодно сетка перестала перерисовываться на каждое нажатие сердца в любом другом месте
    // приложения: раньше изменение множества избранного инвалидировало ВЕСЬ грид.
    onOpen: (TrackEntity) -> Unit,
    onLongPress: (TrackEntity) -> Unit,
    onMenu: (TrackEntity) -> Unit
) {
    val p = LocalPalette.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val edge = MediaGeometry.edge(maxWidth.value).dp
    val gap = edge
    val width = MediaGeometry.tile(maxWidth.value).dp
    val rows = remember(tracks) { tracks.chunked(MediaGeometry.COLUMNS) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = edge, end = edge, top = 4.dp, bottom = LocalBottomChromeInset.current + 20.dp),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        items(rows, key = { row -> row.first().id }) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                row.forEach { track ->
                    val current = track.id == currentId
                    Column(
                        Modifier
                            .width(width)
                            .clip(cardShape)
                            .combinedClickable(
                                onClick = { onOpen(track) },
                                onLongClick = { onLongPress(track) }
                            )
                    ) {
                        Box(Modifier.size(width)) {
                            TrackArtwork(
                                track, CARD_TILE_PX,
                                Modifier.size(width).clip(artShape).background(p.chip),
                                glyphSize = 38
                            )
                            if (current) {
                                Box(
                                    Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(8.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(p.brand)
                                        .padding(horizontal = 6.dp, vertical = 5.dp)
                                ) {
                                    EqualizerBars(
                                        color = p.onAccent,
                                        playing = playing,
                                        modifier = Modifier.size(13.dp, 9.dp)
                                    )
                                }
                            }
                            // 6.32.0. Метки «избранное» на обложке БОЛЬШЕ НЕТ.
                            //
                            // Сетка обложек — это единственное место в приложении, где картинка
                            // работает во всю площадь плитки, и любая накладка на ней спорит с
                            // самим артом. Кружок с сердцем в нижнем правом углу висел поверх
                            // изображения ровно там, где у половины обложек лежит подпись или
                            // лицо, и читался как элемент чужого дизайна. Информации он при этом
                            // не нёс: избранное видно в строке трека, в шторке и в плеере, а
                            // отдельный плейлист «Избранное» отвечает на тот же вопрос списком.
                            //
                            // Логика избранного не тронута: [favorites] по-прежнему приходит в
                            // этот композит и используется ниже. Убрано только отображение.
                            Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                                RoundIconButton(
                                    ZiziIcons.More, Color.White, Color.Black.copy(alpha = 0.45f),
                                    size = 30, iconSize = 16, onClick = { onMenu(track) }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            track.title,
                            // Оранжевый на играющем — как в поиске. Раньше здесь был «цвет из
                            // обложки», и на тёмной обложке имя трека сливалось с фоном.
                            color = if (current) p.brand else p.text,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            minLines = 2,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            track.artist,
                            color = p.subtext,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                    }
                }
                repeat(MediaGeometry.COLUMNS - row.size) { Spacer(Modifier.width(width)) }
            }
        }
    }
    }
}

/**
 * Лист сортировки. Шаг пункта 64 dp — замер референса (170 px).
 *
 * Галочка оранжевая и стоит справа, а не слева: слева её пришлось бы держать в отступе у всех
 * пунктов, включая невыбранные, и лист поехал бы вправо на ширину пустого места.
 */
@Composable
private fun LibrarySortSheet(
    tracks: Boolean,
    sortMode: SortMode,
    collectionSort: CollectionSort,
    onSortMode: (SortMode) -> Unit,
    onCollectionSort: (CollectionSort) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    ZiziSheetScaffold(onDismiss = onDismiss) {
        val exit = LocalSheetExit.current
        Text(
            "Сортировка",
            color = p.text,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 2.dp, bottom = 4.dp)
        )
        if (tracks) {
            SortRow("Недавние", sortMode == SortMode.RECENT) { exit { onSortMode(SortMode.RECENT) } }
            SortRow("По алфавиту", sortMode == SortMode.TITLE) { exit { onSortMode(SortMode.TITLE) } }
            SortRow("По исполнителю", sortMode == SortMode.ARTIST) { exit { onSortMode(SortMode.ARTIST) } }
            SortRow("По прослушиваниям", sortMode == SortMode.PLAYS) { exit { onSortMode(SortMode.PLAYS) } }
            SortRow("По длительности", sortMode == SortMode.DURATION) { exit { onSortMode(SortMode.DURATION) } }
        } else {
            SortRow("Недавние", collectionSort == CollectionSort.RECENT) { exit { onCollectionSort(CollectionSort.RECENT) } }
            SortRow("По дате добавления", collectionSort == CollectionSort.ADDED) { exit { onCollectionSort(CollectionSort.ADDED) } }
            SortRow("По алфавиту", collectionSort == CollectionSort.TITLE) { exit { onCollectionSort(CollectionSort.TITLE) } }
            SortRow("По размеру", collectionSort == CollectionSort.SIZE) { exit { onCollectionSort(CollectionSort.SIZE) } }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SortRow(label: String, checked: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(SORT_ROW_HEIGHT)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = p.text,
            fontSize = 15.5.sp,
            fontWeight = if (checked) FontWeight.Bold else FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (checked) Icon(ZiziIcons.Check, null, tint = p.brand, modifier = Modifier.size(20.dp))
    }
}

/**
 * Меню плейлиста (6.29.0).
 *
 * До этой версии переименование, обмен и удаление висели тремя иконками прямо в строке
 * плейлиста. На карточке для трёх иконок места нет, а главное — две из них разрушительные, и
 * держать их под пальцем рядом с «открыть» было ошибкой ещё в списке.
 */
@Composable
private fun PlaylistMenuSheet(
    playlist: PlaylistEntity,
    count: Int,
    onRename: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    ZiziSheetScaffold(onDismiss = onDismiss) {
        val exit = LocalSheetExit.current
        Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 8.dp)) {
            Text(
                playlist.name,
                color = p.text,
                fontSize = 16.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(trackCountLabel(count), color = p.subtext, fontSize = 12.5.sp)
        }
        MenuItem(ZiziIcons.Edit, "Переименовать", onClick = { exit(onRename) })
        MenuItem(ZiziIcons.Share, "Поделиться", onClick = { exit(onShare) })
        MenuItem(ZiziIcons.Trash, "Удалить плейлист", danger = true, onClick = { exit(onDelete) })
        Spacer(Modifier.height(6.dp))
    }
}
