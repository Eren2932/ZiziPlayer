package app.ziziplayer.data.remote;

import java.util.HashSet;
import java.util.Set;

/** Bounded paging, shared by the real importer and executable JVM regression tests. */
public final class CollectionImportGuard {
    public static final int MAX_PAGES = 200;
    public static final int MAX_TRACKS = 10000;
    private final Set<String> tokens = new HashSet<>();
    private int pages;
    private int received;
    private int unique;
    private int expected;

    public void accept(int count, int uniqueCount, Integer total, String next) {
        if (count < 0 || uniqueCount < unique || uniqueCount > received + count)
            throw new IllegalStateException("Некорректная страница сборника");
        int added = uniqueCount - unique;
        unique = uniqueCount;
        pages++;
        received += count;
        if (total != null) expected = Math.max(expected, total);
        if (uniqueCount > MAX_TRACKS || received > MAX_TRACKS || pages > MAX_PAGES)
            throw new IllegalStateException("Сборник слишком большой для быстрого добавления");
        if (next != null && !next.trim().isEmpty()) {
            if (count == 0 || added == 0 || !tokens.add(next))
                throw new IllegalStateException("Источник повторяет страницы сборника. Попробуй позже");
            if (pages >= MAX_PAGES)
                throw new IllegalStateException("Не удалось загрузить сборник целиком");
        } else if (received < expected) {
            throw new IllegalStateException("Источник вернул только " + received + " из " + expected + " треков. Сборник не сохранён");
        }
    }
}
