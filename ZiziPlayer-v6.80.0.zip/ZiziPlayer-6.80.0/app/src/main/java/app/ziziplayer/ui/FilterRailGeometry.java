package app.ziziplayer.ui;

/** Shared measured rail math, independent of any search/library domain enum. */
public final class FilterRailGeometry {
    private FilterRailGeometry() {}
    public static final int DURATION_MS = 280;
    private static float unit(float value) { return Math.max(0f, Math.min(1f, value)); }
    public static float filterX(float naturalX, float selectedNaturalX, float scroll,
                                float selectedViewportX, float progress) {
        return naturalX + (scroll + selectedViewportX - selectedNaturalX) * unit(progress);
    }
    public static float siblingAlpha(float progress) { return 1f - unit(progress / 0.55f); }
}
