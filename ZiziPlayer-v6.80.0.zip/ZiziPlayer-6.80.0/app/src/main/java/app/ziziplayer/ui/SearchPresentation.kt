package app.ziziplayer.ui

import app.ziziplayer.data.remote.RemoteItem

/** Platform-free rules shared by the ViewModel and collection screen. */
internal object SearchPresentation {
    fun matchesPreview(item: RemoteItem, query: String): Boolean {
        val fields = when (item) {
            is RemoteItem.Song -> listOf(item.track.title, item.track.artist,
                "${item.track.artist} ${item.track.title}", "${item.track.title} ${item.track.artist}")
            is RemoteItem.Group -> listOf(item.collection.title, item.collection.subtitle,
                "${item.collection.subtitle} ${item.collection.title}")
        }
        return fields.any { SearchSuggestionPolicy.matches(it, query) }
    }

    /** Keep source provenance; preview metadata never becomes a remote suggestion. */
    fun completions(query: String, remote: List<String>, history: List<String>, metadata: List<String>) =
        SearchSuggestionPolicy.build(query, remote, history, metadata)

    fun nextPage(next: String?, previous: String?, received: Int): String? =
        next?.takeIf { it.isNotBlank() && it != previous && received > 0 }

    fun durationMinutes(durations: List<Long>, complete: Boolean): Long? =
        if (!complete || durations.isEmpty() || durations.any { it <= 0L }) null
        else durations.sum() / 60000L
}
