package app.ziziplayer.data.remote

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Loads metadata only. The caller supplies a deadline; no writes until all pages succeed. */
internal suspend fun loadCompleteCollection(
    target: RemoteCollection,
    loadPage: suspend (RemoteCollection, String?) -> CollectionPage
): CollectionPage {
    require(target.kind == RemoteKind.ALBUM || target.kind == RemoteKind.PLAYLIST)
    val tracks = LinkedHashMap<String, RemoteTrack>()
    val guard = CollectionImportGuard()
    var token: String? = null
    var detail = target
    var total: Int? = null
    do {
        currentCoroutineContext().ensureActive()
        val page = loadPage(target, token)
        currentCoroutineContext().ensureActive()
        page.tracks.forEach { tracks.putIfAbsent(it.trackId, it) }
        val next = page.nextToken?.takeIf { it.isNotBlank() }
        guard.accept(page.tracks.size, tracks.size, page.total, next)
        detail = page.collection
        total = page.total ?: total
        token = next
    } while (token != null)
    if (tracks.isEmpty()) throw CatalogException(CatalogException.Reason.UNAVAILABLE, "В сборнике нет доступных треков")
    return CollectionPage(detail, tracks.values.toList(), total = total)
}
