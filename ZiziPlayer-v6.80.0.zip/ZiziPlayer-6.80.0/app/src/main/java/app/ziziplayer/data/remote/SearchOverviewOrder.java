package app.ziziplayer.data.remote;

import java.util.ArrayList;
import java.util.List;

/** Stable round-robin; preserves each provider's order without pretending to have relevance scores. */
public final class SearchOverviewOrder {
    private SearchOverviewOrder() {}
    public static <T> List<T> interleave(List<? extends List<? extends T>> buckets) {
        List<T> output = new ArrayList<>();
        for (int row = 0; ; row++) {
            boolean added = false;
            for (List<? extends T> bucket : buckets) {
                if (row < bucket.size()) {
                    output.add(bucket.get(row));
                    added = true;
                }
            }
            if (!added) return output;
        }
    }
}
