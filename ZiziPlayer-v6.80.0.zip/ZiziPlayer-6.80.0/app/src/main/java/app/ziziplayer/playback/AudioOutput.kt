package app.ziziplayer.playback

import android.Manifest
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRouting
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/** Transport, not a guess based on the Bluetooth adapter being enabled. */
enum class OutputKind { PHONE, WIRED, BLUETOOTH, BLUETOOTH_SPEAKER, BLUETOOTH_OTHER, USB, EXTERNAL, UNKNOWN }

data class AudioOutput(
    val kind: OutputKind,
    val name: String,
    val id: Int = 0,
    val genericName: Boolean = false
) {
    val isPhone: Boolean get() = kind == OutputKind.PHONE
    val isKnown: Boolean get() = kind != OutputKind.UNKNOWN
    val isBluetooth: Boolean get() = kind == OutputKind.BLUETOOTH ||
        kind == OutputKind.BLUETOOTH_SPEAKER || kind == OutputKind.BLUETOOTH_OTHER
}

data class AudioOutputState(
    val active: AudioOutput,
    /** Connected media sinks. This is NOT a list of paired or network devices. */
    val connected: List<AudioOutput> = emptyList()
)

/** One event-driven source for the mini player, full player and Connect sheet. */
object AudioOutputs {
    private val handler = Handler(Looper.getMainLooper())
    private val revision = MutableStateFlow(0L)
    private var track: AudioTrack? = null
    private var listener: AudioRouting.OnRoutingChangedListener? = null
    private var owner: Any? = null
    private var lastConfirmedId: Int? = null

    fun refresh() {
        if (Looper.myLooper() != Looper.getMainLooper()) handler.post { refresh() }
        else revision.value += 1L
    }

    /** Called on main by PlaybackRouteMonitor, never replaces/configures the audio sink. */
    internal fun attach(token: Any, next: AudioTrack) {
        detachListener()
        owner = token
        track = next
        val callback = AudioRouting.OnRoutingChangedListener { router ->
            if (track === next && owner === token) {
                runCatching { router.routedDevice }.getOrNull()?.let { lastConfirmedId = it.id }
                refresh()
            }
        }
        listener = callback
        runCatching { next.addOnRoutingChangedListener(callback, handler) }
        refresh()
    }

    private fun detachListener() {
        val old = track
        val callback = listener
        if (old != null && callback != null) runCatching { old.removeOnRoutingChangedListener(callback) }
        listener = null
        track = null
    }

    internal fun detach(token: Any) {
        if (owner !== token) return
        detachListener()
        owner = null
        lastConfirmedId = null
        refresh()
    }

    fun hasBluetoothPermission(context: Context): Boolean = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun current(context: Context): AudioOutputState {
        val app = context.applicationContext
        val am = app.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val devices = runCatching { am?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)?.filter { it.isSink } }
            .getOrNull().orEmpty()
        // AudioTrack is the actual Zizi media stream, including two devices of the SAME type.
        val actual = runCatching {
            track?.takeIf { it.playState == AudioTrack.PLAYSTATE_PLAYING }?.routedDevice
        }.getOrNull()
        if (actual != null) lastConfirmedId = actual.id
        // Public API added in 33, NOT 31. Useful while paused / before AudioTrack starts.
        val planned = if (Build.VERSION.SDK_INT >= 33) runCatching {
            am?.getAudioDevicesForAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())?.firstOrNull()
        }.getOrNull() else null
        val media = devices.filter { isMediaSink(it.type) || it.id == actual?.id }
        val ids = media.map { it.id }.toIntArray()
        val selected = AudioRoutePolicy.select(actual?.id ?: -1, planned?.id ?: -1,
            lastConfirmedId ?: -1, ids)
        val chosen = actual?.takeIf { it.id == selected }
            ?: planned?.takeIf { it.id == selected }
            ?: media.firstOrNull { it.id == selected }
        // Never claim that a connected headset must be the active route. On older Android,
        // until this AudioTrack has reported routing, mixed outputs are genuinely unknown.
        val external = media.any { kindOf(it.type) != OutputKind.PHONE }
        val active = chosen?.let { describe(app, it) } ?: if (!external)
            AudioOutput(OutputKind.PHONE, "Этот телефон") else
            AudioOutput(OutputKind.UNKNOWN, "Выход не определён")
        return AudioOutputState(active, media.map { describe(app, it) }
            .distinctBy { if (it.isPhone) "phone" else it.id.toString() })
    }

    fun flow(context: Context): Flow<AudioOutputState> = callbackFlow {
        val app = context.applicationContext
        val am = app.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        fun publish() { trySend(current(app)) }
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { publish() }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { publish() }
        }
        val registered = am != null && runCatching { am.registerAudioDeviceCallback(callback, handler) }.isSuccess
        // Also refresh after settings / permission changes / a Bluetooth device rename.
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { publish() }
        }
        val filter = IntentFilter().apply {
            addAction("android.bluetooth.device.action.NAME_CHANGED")
            addAction("android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED")
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        }
        val receiverRegistered = runCatching {
            ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        }.isSuccess
        val observer = launch { revision.collect { publish() } }
        publish()
        awaitClose {
            observer.cancel()
            if (registered) runCatching { am?.unregisterAudioDeviceCallback(callback) }
            if (receiverRegistered) runCatching { app.unregisterReceiver(receiver) }
        }
    }.distinctUntilChanged()

    private fun isMediaSink(type: Int): Boolean = type != AudioDeviceInfo.TYPE_TELEPHONY &&
        type != AudioDeviceInfo.TYPE_BUILTIN_EARPIECE && type != AudioDeviceInfo.TYPE_BLUETOOTH_SCO &&
        type != AudioDeviceInfo.TYPE_FM_TUNER && type != AudioDeviceInfo.TYPE_REMOTE_SUBMIX &&
        type != AudioDeviceInfo.TYPE_UNKNOWN

    private fun kindOf(type: Int): OutputKind = when (type) {
        AudioDeviceInfo.TYPE_BLE_HEADSET -> OutputKind.BLUETOOTH
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> OutputKind.BLUETOOTH_OTHER
        AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_BLE_BROADCAST -> OutputKind.BLUETOOTH_SPEAKER
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_AUX_LINE -> OutputKind.WIRED
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> OutputKind.USB
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_SPEAKER_SAFE,
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> OutputKind.PHONE
        else -> OutputKind.EXTERNAL
    }

    private fun describe(context: Context, device: AudioDeviceInfo): AudioOutput {
        var kind = kindOf(device.type)
        var product = runCatching { device.productName?.toString()?.trim() }.getOrNull().orEmpty()
        if (kind == OutputKind.BLUETOOTH_OTHER || kind == OutputKind.BLUETOOTH || kind == OutputKind.BLUETOOTH_SPEAKER) {
            if (hasBluetoothPermission(context)) runCatching {
                val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
                // Match the actual AudioDeviceInfo ADDRESS. No bondedDevices.first() shortcut.
                val address = if (Build.VERSION.SDK_INT >= 28) device.address else ""
                val bt = address.takeIf { android.bluetooth.BluetoothAdapter.checkBluetoothAddress(it) }
                    ?.let { adapter?.getRemoteDevice(it) }
                bt?.name?.trim()?.takeIf { it.isNotEmpty() }?.let { product = it }
                if (kind == OutputKind.BLUETOOTH_OTHER) kind = when (bt?.bluetoothClass?.deviceClass) {
                    BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES,
                    BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET,
                    BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE -> OutputKind.BLUETOOTH
                    BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER -> OutputKind.BLUETOOTH_SPEAKER
                    else -> OutputKind.BLUETOOTH_OTHER
                }
            }
        }
        val fallback = when (kind) {
            OutputKind.PHONE -> "Этот телефон"
            OutputKind.WIRED -> "Проводные наушники"
            OutputKind.BLUETOOTH -> "Bluetooth-наушники"
            OutputKind.BLUETOOTH_SPEAKER -> "Bluetooth-колонка"
            OutputKind.BLUETOOTH_OTHER -> "Bluetooth-устройство"
            OutputKind.USB -> "USB-аудиоустройство"
            OutputKind.EXTERNAL -> "Внешний аудиовыход"
            OutputKind.UNKNOWN -> "Выход не определён"
        }
        val generic = product.isBlank() || product.equals("null", true) ||
            product.equals(Build.MODEL, true) || product.equals(Build.DEVICE, true)
        return AudioOutput(kind, if (kind == OutputKind.PHONE || generic) fallback else product, device.id, generic)
    }
}
