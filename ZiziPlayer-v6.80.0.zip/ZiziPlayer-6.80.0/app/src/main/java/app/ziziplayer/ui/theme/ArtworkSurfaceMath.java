package app.ziziplayer.ui.theme;

/**
 * 6.74: separate surface roles; original accent/lyrics swatches remain unmodified.
 * Vivid art retains the established role mapping. Moderately saturated artwork keeps its
 * actual colour instead of being forced into the vivid branch (which crushed muted blues).
 * A bright primary can defer to a related, independently sampled matte body. Both brightness
 * and angular evidence are required; grey/noisy/rival hues never repaint the surface.
 * All transitions are smooth. This is a calibrated policy, not Spotify's private algorithm.
 */
public final class ArtworkSurfaceMath {
    private static final float[] RAMP = {1f, .90f, .72f, .54f, .36f, .18f, 0f};
    private static final int BOTTOM = 0xff111111;
    public static final int SECONDARY_INK = 0xffe0e0e0;
    public static final int PLAYER_HEADER_INK = 0xfff6f7f8;
    private ArtworkSurfaceMath() {}

    public static int[] playerBackdrop(int primary, int deep) {
        return playerBackdrop(primary, deep, primary);
    }

    public static int[] playerBackdrop(int primary, int deep, int body) {
        int top = playerTop(primary, deep, body);
        int[] out = new int[RAMP.length];
        for (int i = 0; i < out.length; i++) out[i] = ArtworkColorMath.mix(BOTTOM, top, RAMP[i]);
        return out;
    }

    public static int playerTop(int primary, int deep) {
        return playerTop(primary, deep, primary);
    }

    public static int playerTop(int primary, int deep, int body) {
        float[] s = reading(primary, deep);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float q = hueLuminance(s[0]);
        float neutral = hsv(ArtworkColorMath.coverTop(grey(primary)))[2];
        float value = lerp(neutral, .175f + .56f * q, gate);
        float saturation = gate * (s[1] + .20f * (1f - s[1]));
        return adapt(primary, body, visiblePlayerTop(s[0], saturation, value), 0);
    }

    /** Not a modal sheet colour and NOT a fraction of an already darkened player backdrop. */
    public static int miniPlayer(int primary, int deep) {
        return miniPlayer(primary, deep, primary);
    }

    public static int miniPlayer(int primary, int deep, int body) {
        float[] s = reading(primary, deep);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float q = hueLuminance(s[0]);
        float neutral = .14f + .067f * hsv(primary)[2];
        float value = lerp(neutral, .10f + .56f * q, gate);
        float boost = .22f + .66f * (1f - q) * (1f - q);
        float saturation = gate * (s[1] + boost * (1f - s[1]));
        return adapt(primary, body, bounded(s[0], saturation, value, .125), 1);
    }

    /** Brighter cover header, not the dim listening canvas. Greys retain the previous tone. */
    public static int collectionTop(int primary) {
        return collectionTop(primary, primary);
    }

    public static int collectionTop(int primary, int body) {
        float[] s = hsv(primary);
        float gate = chromaticGate(s[1]) * smooth(.025f, .14f, s[1] * s[2]);
        float oldValue = hsv(ArtworkColorMath.coverTop(primary))[2];
        float value = oldValue * (1f + .15f * gate);
        float saturation = gate * (s[1] + .60f * (1f - s[1]));
        return adapt(primary, body, bounded(s[0], saturation, Math.min(value, .80f), .125), 2);
    }

    /** Chips remain subdued UI surfaces, independent of the mini-player and modal panels. */
    public static int chip(int primary, int deep) {
        return chip(primary, deep, primary);
    }

    public static int chip(int primary, int deep, int body) {
        return ArtworkColorMath.mix(0xff1b1b1b, miniPlayer(primary, deep, body), .32f);
    }

    /** role 0=player, 1=capsule, 2=collection; interpolations use the short hue arc. */
    private static int adapt(int primary, int body, int vivid, int role) {
        float[] p = hsv(primary), b = hsv(body), out = hsv(vivid);
        float coloured = chromaticGate(p[1]) * smooth(.025f, .14f, p[1] * p[2]);
        // A moderate-saturation seed describes a matte surface, not a weak neon accent.
        float gap = Math.abs((b[0] - p[0] + 540f) % 360f - 180f);
        float matchingBody = (1f - smooth(6f, 16f, gap)) * chromaticGate(b[1]);
        float[] matte = blendHsv(p, b, matchingBody);
        float muted = (1f - smooth(.60f, .72f, p[1])) * coloured * smooth(.18f, .45f, matte[2]);
        // Compress sample-size/highlight variation, not hue: role lightness follows the body
        // with a gentle slope. This avoids row/full decoding choosing different neon tones.
        out = blendHsv(out, new float[]{matte[0], matte[1] * (role == 1 ? .96f : .90f),
                (role == 1 ? .24f : .39f) + .44f * matte[2]}, muted);
        float glare = smooth(.68f, .76f, (float) Math.cbrt(ArtworkColorMath.luminance(primary)))
                * smooth(12f, 28f, gap) * (1f - smooth(55f, 80f, gap))
                * chromaticGate(b[1]) * smooth(.025f, .11f, b[1] * b[2]) * coloured;
        // Only an actually sampled body can redirect a glare-dominated cover. No hue tables.
        float scale = role == 1 ? .40f : role == 2 ? .75f : .78f;
        out = blendHsv(out, new float[]{b[0], b[1] * .96f, b[2] * scale}, glare);
        return role == 0 ? visiblePlayerTop(out[0], out[1], out[2], .165)
                : bounded(out[0], out[1], out[2], .125);
    }
    private static float[] blendHsv(float[] a, float[] b, float t) {
        float delta = (b[0] - a[0] + 540f) % 360f - 180f;
        return new float[]{(a[0] + delta * t + 360f) % 360f,
                lerp(a[1], b[1], t), lerp(a[2], b[2], t)};
    }

    private static float[] reading(int primary, int deep) {
        float[] p = hsv(primary), d = hsv(deep);
        float delta = (d[0] - p[0] + 540f) % 360f - 180f;
        float confidence = .80f * (1f - smooth(8f, 20f, Math.abs(delta)))
                * chromaticGate(d[1]) * smooth(.06f, .18f, d[2]) * chromaticGate(p[1]);
        return new float[]{(p[0] + delta * confidence + 360f) % 360f,
                lerp(p[1], d[1], confidence), p[2]};
    }
    private static float hueLuminance(float hue) {
        return (float) ArtworkColorMath.luminance(rgb(hue, 1f, 1f));
    }
    private static float chromaticGate(float saturation) { return smooth(.08f, .22f, saturation); }
    private static float smooth(float a, float b, float x) {
        float t = clamp((x - a) / (b - a), 0f, 1f);
        return t * t * (3f - 2f * t);
    }
    private static int grey(int primary) {
        int v = Math.round(hsv(primary)[2] * 255f);
        return 0xff000000 | (v << 16) | (v << 8) | v;
    }
    private static int visiblePlayerTop(float h, float s, float v) {
        return visiblePlayerTop(h, s, v, .125);
    }
    private static int visiblePlayerTop(float h, float s, float v, double ceiling) {
        int top = bounded(h, s, v, ceiling);
        if (ArtworkColorMath.luminance(top) >= .012) return top;
        float lo = v, hi = 1f;
        for (int i = 0; i < 16; i++) {
            float mid = (lo + hi) * .5f;
            if (ArtworkColorMath.luminance(rgb(h, s, mid)) < .012) lo = mid; else hi = mid;
        }
        return rgb(h, s, hi);
    }
    private static int bounded(float h, float s, float v, double ceiling) {
        int result = rgb(h, s, v);
        if (ArtworkColorMath.luminance(result) <= ceiling) return result;
        float lo = 0, hi = v;
        for (int i = 0; i < 16; i++) {
            float mid = (lo + hi) * .5f;
            if (ArtworkColorMath.luminance(rgb(h, s, mid)) <= ceiling) lo = mid; else hi = mid;
        }
        return rgb(h, s, lo);
    }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }
    private static float[] hsv(int rgb) {
        float r = ((rgb >>> 16) & 255) / 255f, g = ((rgb >>> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), delta = max - min;
        float h = 0f;
        if (delta > 0f) {
            h = max == r ? (g - b) / delta : max == g ? (b - r) / delta + 2f : (r - g) / delta + 4f;
            h = (h * 60f + 360f) % 360f;
        }
        return new float[]{h, max == 0 ? 0 : delta / max, max};
    }
    private static int rgb(float hue, float sat, float value) {
        float h = ((hue % 360f) + 360f) % 360f / 60f;
        float v = clamp(value, 0f, 1f), c = v * clamp(sat, 0f, 1f), x = c * (1f - Math.abs(h % 2f - 1f)), m = v - c;
        float r = 0, g = 0, b = 0;
        if (h < 1) { r = c; g = x; } else if (h < 2) { r = x; g = c; }
        else if (h < 3) { g = c; b = x; } else if (h < 4) { g = x; b = c; }
        else if (h < 5) { r = x; b = c; } else { r = c; b = x; }
        return 0xff000000 | (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }
}
