package app.ziziplayer.ui.theme;

/**
 * 6.74: an additional midtone/body swatch, NOT a replacement for the accent/lyrics seed.
 * Population counts, perceptual lightness and moderate saturation identify a usable matte
 * region rather than rewarding specular highlights with V squared. Called on the SAME bounded
 * pixel sample as ArtworkColorMath, off the main thread. No decoder, network or track identity.
 * A body swatch is evidence only; ArtworkSurfaceMath decides whether it is relevant to a role.
 */
public final class ArtworkSurfaceSampler {
    private static final int BINS = 24;
    private ArtworkSurfaceSampler() {}

    public static int body(int[] pixels, int fallback) {
        if (pixels == null || pixels.length == 0) return fallback;
        if (pixels.length > ArtworkColorMath.SAMPLE_SIDE * ArtworkColorMath.SAMPLE_SIDE)
            throw new IllegalArgumentException("Artwork sample exceeds 64 x 64");
        double[] weights = new double[BINS], xs = new double[BINS], ys = new double[BINS];
        double[] sats = new double[BINS], vals = new double[BINS], counts = new double[BINS];
        int opaque = 0;
        for (int pixel : pixels) {
            if ((pixel >>> 24) < 192) continue;
            opaque++;
            double r = ((pixel >>> 16) & 255) / 255.0;
            double g = ((pixel >>> 8) & 255) / 255.0;
            double b = (pixel & 255) / 255.0;
            double v = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
            double delta = v - min, s = v == 0 ? 0 : delta / v;
            if (s < .12 || v < .08) continue;
            double h = v == r ? (g - b) / delta : v == g ? (b - r) / delta + 2 : (r - g) / delta + 4;
            h = (h * 60 + 360) % 360;
            double lr = linear(r), lg = linear(g), lb = linear(b);
            double lightness = .2104542553 * Math.cbrt(.4122214708 * lr + .5363325363 * lg + .0514459929 * lb)
                    + .7936177850 * Math.cbrt(.2119034982 * lr + .6806995451 * lg + .1073969566 * lb)
                    - .0040720468 * Math.cbrt(.0883024619 * lr + .2817188376 * lg + .6299787005 * lb);
            double light = (lightness - .47) / .16, sat = (s - .45) / .22;
            double w = Math.exp(-light * light - sat * sat);
            int bin = Math.min(BINS - 1, (int) (h / 360 * BINS));
            double rad = Math.toRadians(h);
            weights[bin] += w; xs[bin] += Math.cos(rad) * w; ys[bin] += Math.sin(rad) * w;
            sats[bin] += s * w; vals[bin] += v * w; counts[bin]++;
        }
        int best = -1;
        double score = 0;
        double primaryHue = hue(fallback);
        double glare = smooth(.68, .76, Math.cbrt(ArtworkColorMath.luminance(fallback)));
        for (int i = 0; i < BINS; i++) {
            if (weights[i] <= 0 || sum(i, counts) < Math.max(1, Math.ceil(opaque * .025))) continue;
            double candidateHue = (Math.toDegrees(Math.atan2(sum(i, ys), sum(i, xs))) + 360) % 360;
            double gap = Math.abs((candidateHue - primaryHue + 540) % 360 - 180);
            double related = smooth(12, 28, gap) * (1 - smooth(55, 80, gap));
            double rank = sum(i, weights) * (1 + 3 * glare * related);
            if (rank > score) { best = i; score = rank; }
        }
        if (best < 0) return fallback;
        score = sum(best, weights);
        double h = (Math.toDegrees(Math.atan2(sum(best, ys), sum(best, xs))) + 360) % 360;
        return rgb(h, sum(best, sats) / score, sum(best, vals) / score);
    }
    private static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }
    private static double hue(int rgb) {
        double r = (rgb >>> 16) & 255, g = (rgb >>> 8) & 255, b = rgb & 255;
        double max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        if (d == 0) return 0;
        double h = max == r ? (g - b) / d : max == g ? (b - r) / d + 2 : (r - g) / d + 4;
        return (h * 60 + 360) % 360;
    }
    private static double sum(int i, double[] v) { return v[(i + BINS - 1) % BINS] + v[i] + v[(i + 1) % BINS]; }
    private static double linear(double v) { return v <= .04045 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }
    private static int rgb(double h, double s, double v) {
        h /= 60; double c = v * s, x = c * (1 - Math.abs(h % 2 - 1)), m = v - c;
        double r = 0, g = 0, b = 0;
        if (h < 1) { r = c; g = x; } else if (h < 2) { r = x; g = c; }
        else if (h < 3) { g = c; b = x; } else if (h < 4) { g = x; b = c; }
        else if (h < 5) { r = x; b = c; } else { r = c; b = x; }
        return 0xff000000 | ((int) Math.round((r + m) * 255) << 16)
                | ((int) Math.round((g + m) * 255) << 8) | (int) Math.round((b + m) * 255);
    }
}
