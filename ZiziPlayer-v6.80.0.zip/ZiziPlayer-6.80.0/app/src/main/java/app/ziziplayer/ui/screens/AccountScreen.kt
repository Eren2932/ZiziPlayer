@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package app.ziziplayer.ui.screens

import app.ziziplayer.ui.theme.ZiziModalSurface

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.account.AccountLocalState
import app.ziziplayer.account.AccountProfile
import app.ziziplayer.data.PlaylistEntity
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.profileKey
import app.ziziplayer.library.LibrarySync
import app.ziziplayer.ui.ProfileGeometry
import app.ziziplayer.ui.ProfilePresentation
import app.ziziplayer.ui.components.AccountAvatar
import app.ziziplayer.ui.components.LocalBottomChromeInset
import app.ziziplayer.ui.components.ProfileBackdrop
import app.ziziplayer.ui.components.RemoteArtwork
import app.ziziplayer.ui.components.TrackArtwork
import app.ziziplayer.ui.components.accountColor
import app.ziziplayer.ui.components.surfaceInputBoundary
import app.ziziplayer.ui.components.ZiziIcons
import app.ziziplayer.ui.theme.LocalPalette
import kotlinx.coroutines.launch

/** Existing drawer/editor geometry remains unchanged. */
@Composable
internal fun accountScale(): Float = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp / 360f).coerceAtMost(1.6f)

internal fun profileName(state: AccountLocalState, profile: AccountProfile): String =
    profile.name.ifBlank { state.displayName?.substringBefore('@')?.ifBlank { null } ?: "ZiziPlayer" }

@Composable
fun AccountScreen(
    state: AccountLocalState,
    profile: AccountProfile,
    signInOffered: Boolean,
    playlists: List<PlaylistEntity>,
    playlistMeta: Map<Long, app.ziziplayer.data.PlaylistMeta>,
    onPlaylist: (Long) -> Unit,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onSignOutAll: () -> Unit,
    onClose: () -> Unit,
    onOpenLibrary: () -> Unit,
    onSettings: () -> Unit,
    onEdit: () -> Unit,
    onRefresh: () -> Unit,
    onTrackPlay: (TrackEntity, List<TrackEntity>) -> Unit,
    onToggleFavorite: (TrackEntity) -> Unit,
    onPlayNext: (TrackEntity) -> Unit,
    onAddToQueue: (TrackEntity) -> Unit,
    hiddenPlaylists: Set<String> = emptySet(),
    onManagePlaylists: () -> Unit = {},
    onPlaylistMenu: (Long) -> Unit = {}
) {
    val visiblePlaylists = remember(playlists, hiddenPlaylists) {
        playlists.filterNot { it.profileKey in hiddenPlaylists }
    }
    val p = LocalPalette.current
    val scale = ProfileGeometry.scale(androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.toFloat())
    val inset = (ProfileGeometry.INSET * scale).dp
    val name = if (state.isGuest) "Гостевой режим" else profileName(state, profile)
    val avatar = profile.avatar.takeIf { !state.isGuest && profile.userId == state.userId }.orEmpty()
    val color = accountColor(state.userId.orEmpty())
    var menu by remember { mutableStateOf(false) }
    var preview by remember(avatar) { mutableStateOf(false) }
    var logoutAll by remember { mutableStateOf<Boolean?>(null) }
    var tab by rememberSaveable(state.userId) { mutableStateOf(ProfileTab.PLAYLISTS) }
    var refreshLibrary by remember { mutableIntStateOf(0) }
    var menuTrackId by rememberSaveable(state.userId) { mutableStateOf<String?>(null) }
    val library = rememberProfileLibrary(tab, state.userId, refreshLibrary)
    val context = LocalContext.current
    val sync = remember(context) { LibrarySync.get(context) }
    val syncState by sync.state.collectAsStateWithLifecycle()
    val cloud = profileCloudLabel(state, syncState)
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val heroTop = ((ProfileGeometry.AVATAR_TOP * scale).dp - statusTop).coerceAtLeast(56.dp)
    val toolbarPx = with(density) { 56.dp.toPx() }
    var heroPx by remember { mutableIntStateOf(0) }
    var avatarRowPx by remember { mutableIntStateOf(0) }
    var nameHeightPx by remember { mutableIntStateOf(0) }
    val nameBottomPx = with(density) { (heroTop + (16 * scale).dp).toPx() } + avatarRowPx + nameHeightPx
    val bottom = LocalBottomChromeInset.current
    val coveredScrollPx = with(density) { (ProfileGeometry.BACKDROP_HEIGHT * scale).dp.toPx() }
    val scroll: () -> Float = remember(list, heroPx, coveredScrollPx) {
        { if (list.firstVisibleItemIndex > 0) maxOf(heroPx.toFloat(), coveredScrollPx) else list.firstVisibleItemScrollOffset.toFloat() }
    }
    val progress: () -> Float = remember(list, toolbarPx, nameBottomPx, nameHeightPx) {
        { if (list.firstVisibleItemIndex > 0) 1f else if (nameHeightPx == 0) 0f else
            ProfileGeometry.collapse(list.firstVisibleItemScrollOffset.toFloat(), nameBottomPx, toolbarPx) }
    }
    Box(Modifier.fillMaxSize().background(p.surface)) {
        ProfileBackdrop(avatar, color, p.surface, scale, scroll)
        LazyColumn(state = list, modifier = Modifier.fillMaxSize().statusBarsPadding().testTag("profile-list"),
            contentPadding = PaddingValues(bottom = bottom + 24.dp)) {
            item(key = "profile:hero", contentType = "hero") {
                Column(Modifier.fillMaxWidth().onSizeChanged { heroPx = it.height }.testTag("profile-hero")) {
                    Spacer(Modifier.height(heroTop))
                    Row(Modifier.fillMaxWidth().padding(horizontal = inset).onSizeChanged { avatarRowPx = it.height },
                        verticalAlignment = Alignment.Bottom) {
                        AccountAvatar(state.userId.orEmpty(), name, avatar, (ProfileGeometry.AVATAR_SIZE * scale).dp,
                            Modifier.testTag("profile-avatar").semantics { contentDescription = "Аватарка профиля" }
                                .combinedClickable(enabled = avatar.isNotBlank(),
                                    onClickLabel = "Просмотреть аватарку", onLongClickLabel = "Просмотреть аватарку",
                                    onClick = { preview = true }, onLongClick = { preview = true }))
                        Spacer(Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onOpenLibrary, modifier = Modifier.size(48.dp)) {
                                Box(Modifier.size((40 * scale).dp).border(1.dp, p.subtext.copy(alpha = .5f), CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Icon(if (cloud.confirmed) ZiziIcons.CloudCheck else ZiziIcons.Cloud,
                                        "Облачная библиотека: ${cloud.text}",
                                        tint = if (cloud.confirmed) ProfileSavedColor else p.subtext,
                                        modifier = Modifier.size(24.dp))
                                }
                            }
                            Spacer(Modifier.width((6 * scale).dp))
                            OutlinedButton(onClick = if (state.isGuest) onSignIn else onEdit,
                                enabled = if (state.isGuest) signInOffered else profile.loaded && !profile.busy,
                                modifier = Modifier.widthIn(min = (104 * scale).dp).heightIn(min = (40 * scale).dp),
                                shape = CircleShape,
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFF262626), contentColor = p.text),
                                border = androidx.compose.foundation.BorderStroke(1.dp, p.subtext.copy(alpha = .55f)),
                                contentPadding = PaddingValues(horizontal = (16 * scale).dp, vertical = (8 * scale).dp)) {
                                Text(if (state.isGuest) "Войти" else "Изменить", fontSize = (14 * scale).sp,
                                    lineHeight = (20 * scale).sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height((16 * scale).dp))
                    Column(Modifier.fillMaxWidth().padding(horizontal = inset)) {
                        Text(name, color = p.text, fontSize = (32 * scale).sp, lineHeight = (38 * scale).sp,
                            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth().onSizeChanged { nameHeightPx = it.height }.testTag("profile-name"))
                        Text(cloud.text, color = if (cloud.confirmed) ProfileSavedColor else p.subtext,
                            fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp,
                            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenLibrary))
                        Spacer(Modifier.height((10 * scale).dp))
                        ProfileStats(visiblePlaylists.size, library.favorites.size, library.durationMs, library.loading, scale)
                        Spacer(Modifier.height((7 * scale).dp))
                    }
                }
            }
            item(key = "profile:tabs", contentType = "tabs") {
                ProfileTabs(tab, scale) { next ->
                    if (tab != next) {
                        tab = next; menuTrackId = null
                        // Only list membership changes. Keep the same header offset, never jump to top.
                        if (list.firstVisibleItemIndex > 0) scope.launch {
                            list.scrollToItem(0, (heroPx - toolbarPx).toInt().coerceAtLeast(0))
                        }
                    }
                }
            }
            item(key = "profile:state", contentType = "state") {
                Column(Modifier.fillMaxWidth().background(p.surface).padding(horizontal = inset)) {
                    Spacer(Modifier.height((6 * scale).dp))
                    if (profile.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (profile.error.isNotBlank()) {
                        Text(profile.error, color = p.subtext, fontSize = 13.sp)
                        TextButton(onClick = onRefresh, enabled = !profile.busy) { Text("Повторить") }
                    }
                    if (library.error.isNotBlank()) TextButton(onClick = { refreshLibrary++ }) { Text(library.error) }
                    if (tab != ProfileTab.PLAYLISTS && library.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            when (tab) {
                ProfileTab.PLAYLISTS -> {
                    if (visiblePlaylists.isEmpty()) item("profile:empty-playlists") {
                        ProfileEmpty(if (playlists.isEmpty()) "Плейлистов пока нет. Создай первый в медиатеке."
                            else "Плейлисты скрыты. Верни их через меню аккаунта → Плейлисты в профиле.", inset)
                    }
                    items(visiblePlaylists, key = { "profile:playlist:${it.id}" }, contentType = { "playlist" }) { playlist ->
                        Row(Modifier.fillMaxWidth().background(p.surface).clickable { onPlaylist(playlist.id) }
                            .padding(horizontal = inset, vertical = (7 * scale).dp), verticalAlignment = Alignment.CenterVertically) {
                            val artModifier = Modifier.size((ProfileGeometry.COVER_SIZE * scale).dp).clip(RoundedCornerShape((7 * scale).dp))
                            if (!playlist.coverUri.isNullOrBlank()) RemoteArtwork(playlist.coverUri, playlist.name, 160, artModifier)
                            else TrackArtwork(playlistMeta[playlist.id]?.cover, 160, artModifier, glyphSize = 24)
                            Spacer(Modifier.width((14 * scale).dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.name, color = p.text, fontSize = (17 * scale).sp, lineHeight = (22 * scale).sp,
                                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height((3 * scale).dp))
                                Text("Плейлист · ${ProfilePresentation.tracks(playlistMeta[playlist.id]?.count ?: 0)}",
                                    color = p.subtext, fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onPlaylistMenu(playlist.id) }, modifier = Modifier.size(48.dp)) {
                                Icon(ZiziIcons.More, "Меню плейлиста ${playlist.name}", tint = p.subtext)
                            }
                        }
                    }
                }
                ProfileTab.FAVORITES, ProfileTab.DOWNLOADS -> {
                    val tracks = if (tab == ProfileTab.FAVORITES) library.favorites else library.downloads
                    if (!library.loading && tracks.isEmpty() && library.error.isBlank()) item("profile:empty-tracks") {
                        ProfileEmpty(if (tab == ProfileTab.FAVORITES) "Избранных треков пока нет." else "Скачанных треков пока нет.", inset)
                    }
                    items(tracks, key = { "profile:${tab.name}:${it.id}" }, contentType = { "track" }) { track ->
                        ProfileTrackRow(track, track.title, track.artist, scale,
                            onPlay = { onTrackPlay(track, tracks) }, onMenu = { menuTrackId = track.id })
                    }
                }
                ProfileTab.RECENT -> {
                    if (!library.loading && library.recent.isEmpty() && library.error.isBlank()) item("profile:empty-recent") {
                        ProfileEmpty("Недавних прослушиваний пока нет.", inset)
                    }
                    items(library.recent, key = { "profile:recent:${it.session.trackId}" }, contentType = { "track" }) { recent ->
                        ProfileTrackRow(recent.track, recent.session.title,
                            if (recent.track == null) "Трек недоступен" else recent.session.artist, scale,
                            onPlay = { recent.track?.let { onTrackPlay(it, library.recent.mapNotNull { row -> row.track }) } },
                            onMenu = { menuTrackId = recent.track?.id })
                    }
                }
            }
            item(key = "profile:cloud", contentType = "cloud") {
                Column(Modifier.fillMaxWidth().background(p.surface).padding(horizontal = inset)) {
                    Spacer(Modifier.height(24.dp))
                    if (tab == ProfileTab.PLAYLISTS) AccountMenuRow(ZiziIcons.Edit, "Плейлисты в профиле",
                        "Выбрать, какие показывать", onManagePlaylists)
                    AccountMenuRow(ZiziIcons.Cloud, "Библиотека и облачное сохранение",
                        libraryRowSubtitle("Статус, экспорт и восстановление"), onOpenLibrary)
                    Text("Сам вход ещё не означает, что данные отправлены. До подтверждения сохранения данные остаются только на телефоне.",
                        color = p.subtext, fontSize = 12.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
        ProfilePinnedHeader(name, progress, onClose, onSettings, onMenu = { menu = true })
    }
    if (preview) AccountPhotoPreview(avatar, onDismiss = { preview = false })
    if (menu) ZiziSheetScaffold(onDismiss = { menu = false }) {
        val exit = LocalSheetExit.current
        SheetTitle("Аккаунт")
        MenuItem(ZiziIcons.Edit, "Плейлисты в профиле", onClick = { exit(onManagePlaylists) })
        MenuItem(ZiziIcons.Cloud, "Облачная библиотека", onClick = { exit(onOpenLibrary) })
        if (!state.isGuest) {
            MenuItem(ZiziIcons.Refresh, "Обновить профиль", onClick = { exit(onRefresh) })
            MenuItem(ZiziIcons.ArrowBack, "Выйти", onClick = { exit { logoutAll = false } })
            MenuItem(ZiziIcons.Phone, "Выйти на всех устройствах", danger = true, onClick = { exit { logoutAll = true } })
        }
    }
    val menuTrack = menuTrackId?.let { id ->
        (library.favorites.asSequence() + library.downloads.asSequence() +
            library.recent.asSequence().mapNotNull { it.track }).firstOrNull { it.id == id }
    }
    menuTrack?.let { track ->
        ZiziSheetScaffold(onDismiss = { menuTrackId = null }) {
            val exit = LocalSheetExit.current
            SheetTitle(track.title, track.artist)
            val favorite = library.favorites.any { it.id == track.id }
            MenuItem(if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart,
                if (favorite) "Убрать из избранного" else "В избранное", onClick = { exit { onToggleFavorite(track) } })
            MenuItem(ZiziIcons.PlayNext, "Играть следующим", onClick = { exit { onPlayNext(track) } })
            MenuItem(ZiziIcons.QueueAdd, "Добавить в очередь", onClick = { exit { onAddToQueue(track) } })
        }
    }
    logoutAll?.let { all -> AlertDialog(
        containerColor = ZiziModalSurface,
        tonalElevation = 0.dp,
        onDismissRequest = { logoutAll = null },
        title = { Text(if (all) "Выйти на всех устройствах?" else "Выйти из аккаунта?") },
        text = { Text("Локальная библиотека останется на телефоне. Перед выходом проверьте сохранение в облаке. Данные другого аккаунта не загружаются без отдельного выбора.") },
        confirmButton = { TextButton(onClick = { logoutAll = null; if (all) onSignOutAll() else onSignOut() }) { Text("Выйти") } },
        dismissButton = { TextButton(onClick = { logoutAll = null }) { Text("Отмена") } }) }
}

@Composable
private fun ProfileEmpty(text: String, inset: androidx.compose.ui.unit.Dp) {
    Text(text, color = LocalPalette.current.subtext,
        modifier = Modifier.fillMaxWidth().background(LocalPalette.current.surface).padding(horizontal = inset, vertical = 16.dp))
}

@Composable
private fun ProfileTrackRow(track: TrackEntity?, title: String, subtitle: String, scale: Float,
    onPlay: () -> Unit, onMenu: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().background(p.surface).combinedClickable(enabled = track != null,
        onClick = onPlay, onLongClick = onMenu).padding(horizontal = (20 * scale).dp, vertical = (7 * scale).dp),
        verticalAlignment = Alignment.CenterVertically) {
        TrackArtwork(track, 160, Modifier.size((52 * scale).dp).clip(RoundedCornerShape((7 * scale).dp)), glyphSize = 24)
        Spacer(Modifier.width((14 * scale).dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = (17 * scale).sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = p.subtext, fontSize = (14 * scale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onMenu, enabled = track != null) { Icon(ZiziIcons.More, "Меню трека $title", tint = p.subtext) }
    }
}

/**
 * 6.68.0. Окно выбора копии больше не выскакивает само — поэтому развилка обязана быть видна
 * здесь, в том месте, куда человек и так пойдёт за библиотекой.
 */
@Composable
private fun libraryRowSubtitle(normal: String): String {
    val context = androidx.compose.ui.platform.LocalContext.current
    val sync = androidx.compose.runtime.remember { app.ziziplayer.library.LibrarySync.get(context) }
    val state by sync.state.collectAsStateWithLifecycle()
    return if (state.needsChoice) "Нужно выбрать копию — данные не удалены" else normal
}

@Composable
internal fun AccountMenuRow(icon: ImageVector, title: String, subtitle: String = "", onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().heightIn(min = 58.dp).clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = p.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotEmpty()) { Spacer(Modifier.height(5.dp)); Text(subtitle, color = p.subtext, fontSize = 13.sp) }
        }
    }
}

@Composable
fun AccountDrawer(state: AccountLocalState, profile: AccountProfile,
    onProfile: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit, onLibrary: () -> Unit) {
    val p = LocalPalette.current
    val scale = accountScale()
        // Width and movement belong exclusively to AccountDrawerHost.
        Column(Modifier.fillMaxSize().background(Color(0xFF202020))
            .surfaceInputBoundary().statusBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = (15.3f*scale).dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                AccountAvatar(state.userId.orEmpty(), profileName(state, profile), profile.avatar, (46*scale).dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(profileName(state, profile), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("Посмотреть профиль", color = p.subtext, fontSize = 14.sp)
                }
            }
            HorizontalDivider(color = Color(0xFF383838))
            Column(Modifier.padding(horizontal = (15.3f*scale).dp)) {
                AccountMenuRow(ZiziIcons.History, "Недавние", onClick = onHistory)
                AccountMenuRow(ZiziIcons.Cloud, "Облачная библиотека", libraryRowSubtitle("Сохранение и восстановление"), onLibrary)
                AccountMenuRow(ZiziIcons.AccountGear, "Настройки", onClick = onSettings)
            }
        }
}
