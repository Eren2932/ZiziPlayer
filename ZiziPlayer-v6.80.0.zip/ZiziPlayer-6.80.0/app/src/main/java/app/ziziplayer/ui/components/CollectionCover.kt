package app.ziziplayer.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.ui.theme.ArtworkSurfaceMath
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

internal const val COLLECTION_COVER_FADE_MS = 180

/** Image and tint come from ONE decoded artwork, never from the playback queue. */
@Immutable
internal data class CollectionCover(val art: Art?, val tint: Color, val smooth: Boolean = false)

/** Keep the previous image AND its colour until the new source resolves. Null after resolution
 * is a real missing/failed cover and must replace the old one. Source changes cancel the reader;
 * a detached network fetch may finish its cache write but cannot publish a stale result here.
 */
@Composable
internal fun rememberRetainedCollectionArt(sourceKey: Any?, cached: Art?, load: suspend () -> Art?): Art? {
    var displayed by remember { mutableStateOf(cached) }
    LaunchedEffect(sourceKey) {
        if (cached != null) displayed = cached
        val resolved = load()
        currentCoroutineContext().ensureActive()
        displayed = resolved ?: cached
    }
    return displayed
}

@Composable
private fun rememberResolvedCollectionArt(track: TrackEntity?, url: String?): Art? {
    val context = LocalContext.current
    val useUrl = !url.isNullOrBlank()
    val sourceKey = if (useUrl) listOf("url", url) else listOf("track", track?.id, track?.artworkUri)
    val cached = if (useUrl) ArtworkCache.peekUrl(url, 640) else ArtworkCache.peek(track, 640)
    return rememberRetainedCollectionArt(sourceKey, cached) {
        when {
            useUrl -> ArtworkCache.loadUrl(url, 640)
            track == null || ArtworkCache.hasNoArt(track) -> null
            else -> ArtworkCache.loadDetached(context, track, 640, allowSlow = true)
        }
    }
}

@Composable
internal fun rememberCollectionCover(track: TrackEntity? = null, url: String? = null,
    smooth: Boolean = false): CollectionCover {
    val art = if (smooth) rememberResolvedCollectionArt(track, url)
        else if (!url.isNullOrBlank()) rememberUrlArtwork(url, 640)
        else rememberArtwork(track, 640, allowSlow = true)
    return collectionCoverForArt(art, smooth)
}

@Composable
internal fun collectionCoverForArt(art: Art?, smooth: Boolean): CollectionCover {
    val targetTint = art?.swatches?.let { Color(ArtworkSurfaceMath.collectionTop(it.primary.toArgb(), it.body.toArgb())) }
        ?: Color(0xFF292929)
    if (!smooth) return CollectionCover(art, targetTint)
    // Same target publication, duration and easing as the image. No grey intermediate frame.
    val tint by animateColorAsState(targetTint, tween(COLLECTION_COVER_FADE_MS), label = "collection-tint")
    return CollectionCover(art, tint, smooth = true)
}

@Composable
internal fun CollectionCoverImage(cover: CollectionCover, modifier: Modifier = Modifier) {
    Box(modifier.background(Color(0xFF292929)), contentAlignment = Alignment.Center) {
        if (cover.smooth) Crossfade(targetState = cover.art,
            animationSpec = tween(COLLECTION_COVER_FADE_MS), label = "collection-art",
            modifier = Modifier.fillMaxSize()) { art -> CollectionCoverPixels(art) }
        else CollectionCoverPixels(cover.art)
    }
}

@Composable
private fun CollectionCoverPixels(art: Art?) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (art != null) Image(bitmap = art.image, contentDescription = null,
            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(ZiziIcons.Queue, null, tint = Color(0xFF8C8C8C), modifier = Modifier.size(48.dp))
    }
}
