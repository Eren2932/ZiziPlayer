package app.ziziplayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.stopScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.ziziplayer.ui.FilterRailGeometry
import app.ziziplayer.ui.theme.LocalPalette
import kotlin.math.roundToInt

internal data class FilterRailItem(val id: String, val label: String)

/** One measured identity per chip on every surface. Null means no filter.
 * Keep content width constant during motion so horizontal scroll cannot clamp mid-flight.
 * The selected chip stays anchored; optional secondary filters have their own scroll viewport.
 */
@Composable
internal fun SelectionFilterRail(
    items: List<FilterRailItem>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
    tag: String = "selection-filter",
    defaultId: String? = null,
    edge: Dp = 0.dp,
    resetInset: Dp = 0.dp,
    chipHeight: Dp = 34.dp,
    resetSize: Dp = 34.dp,
    chipVerticalPadding: Dp = 5.dp,
    chipPadding: Dp = 17.dp,
    chipGap: Dp = 8.dp,
    tailMinWidth: Dp = 0.dp,
    fontSize: TextUnit = 14.sp,
    fontWeight: FontWeight = FontWeight.Medium,
    trailingContent: @Composable () -> Unit = {}
) {
    val palette = LocalPalette.current
    val scroll = rememberScrollState()
    val tailScroll = rememberScrollState()
    val selection = selectedId?.takeIf { id -> items.any { it.id == id } }
    var movingId by remember { mutableStateOf(selection) }
    val progress = remember { Animatable(if (selection == null) 0f else 1f) }
    LaunchedEffect(selection) {
        // Stop a fling, but never reset its position: it is also the return destination.
        scroll.stopScroll()
        if (selection != null) movingId = selection
        progress.animateTo(if (selection == null) 0f else 1f,
            tween(FilterRailGeometry.DURATION_MS, easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)))
    }
    BoxWithConstraints(modifier.fillMaxWidth().clipToBounds().testTag("$tag-rail")) {
        val viewport = maxWidth
        val expanded = selection == null && progress.value == 0f
        val settled = selection != null && progress.value == 1f
        Layout(
            modifier = Modifier.horizontalScroll(scroll, enabled = expanded),
            content = {
                val canReset = selection != null
                Box(Modifier.size(48.dp)
                    .then(if (canReset) Modifier else Modifier.clearAndSetSemantics { })
                    .clip(CircleShape).clickable(enabled = canReset, role = Role.Button,
                        onClickLabel = "Сбросить фильтр") { onSelect(null) }
                    .testTag("$tag-reset"), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(resetSize.coerceAtMost(40.dp)).clip(CircleShape)
                        .background(palette.chip), contentAlignment = Alignment.Center) {
                        Icon(ZiziIcons.Close, "Сбросить фильтр", tint = palette.text, modifier = Modifier.size(19.dp))
                    }
                }
                items.forEach { item -> key(item.id) {
                    val enabled = expanded || selection == item.id
                    val amount = when {
                        movingId == item.id -> progress.value
                        defaultId == item.id -> 1f - progress.value
                        else -> 0f
                    }
                    Box(Modifier.heightIn(min = 48.dp)
                        .then(if (enabled) Modifier else Modifier.clearAndSetSemantics { })
                        .clickable(enabled = enabled, role = Role.Tab) {
                            onSelect(if (selection == item.id || defaultId == item.id) null else item.id)
                        }
                        .semantics { selected = selection == item.id || (selection == null && defaultId == item.id) }
                        .testTag("$tag-${item.id}"), contentAlignment = Alignment.Center) {
                        Box(Modifier.heightIn(min = chipHeight).clip(CircleShape)
                            .background(lerp(palette.chip, palette.brand, amount))
                            .padding(horizontal = chipPadding, vertical = chipVerticalPadding), contentAlignment = Alignment.Center) {
                            Text(item.label, fontSize = fontSize, fontWeight = fontWeight,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = lerp(palette.text, palette.onBrand, amount))
                        }
                    }
                } }
                // Secondary controls cannot receive invisible taps or accessibility focus.
                Box(Modifier.horizontalScroll(tailScroll)) { if (settled) trailingContent() }
            }
        ) { measurables, constraints ->
            val resetStart = (edge + resetInset).toPx()
            val reset = measurables[0].measure(Constraints(maxWidth = viewport.roundToPx(), maxHeight = constraints.maxHeight))
            val target = resetStart + reset.width + 2.dp.toPx()
            val maxChipWidth = (viewport.toPx() - target - edge.toPx() - tailMinWidth.toPx()).roundToInt().coerceAtLeast(0)
            val childConstraints = Constraints(maxWidth = maxChipWidth, maxHeight = constraints.maxHeight)
            val chips = measurables.drop(1).take(items.size).map { it.measure(childConstraints) }
            val gap = chipGap.roundToPx()
            var cursor = edge.toPx()
            val natural = chips.map { child -> cursor.also { cursor += child.width + gap } }
            val activeIndex = items.indexOfFirst { it.id == movingId }.coerceAtLeast(0)
            val origin = natural.getOrElse(activeIndex) { 0f }
            val tailStart = target + (chips.getOrNull(activeIndex)?.width ?: 0) + gap
            val tail = measurables.last().measure(Constraints(
                maxWidth = (viewport.toPx() - tailStart - edge.toPx()).roundToInt().coerceAtLeast(0),
                maxHeight = constraints.maxHeight))
            val contentWidth = maxOf(viewport.roundToPx(), (cursor - gap + edge.toPx()).roundToInt())
            val height = maxOf(reset.height, chips.maxOfOrNull { it.height } ?: 0, tail.height)
            layout(contentWidth, height) {
                val amount = progress.value
                if (amount > 0f) reset.placeRelativeWithLayer(
                    (scroll.value + resetStart - 8.dp.toPx() * (1f - amount)).roundToInt(),
                    (height - reset.height) / 2) { alpha = amount }
                chips.forEachIndexed { index, child ->
                    val alpha = if (index == activeIndex) 1f else FilterRailGeometry.siblingAlpha(amount)
                    if (alpha > 0f) child.placeRelativeWithLayer(
                        FilterRailGeometry.filterX(natural[index], origin, scroll.value.toFloat(), target, amount).roundToInt(),
                        (height - child.height) / 2) { this.alpha = alpha }
                }
                if (settled) tail.placeRelative((scroll.value + tailStart).roundToInt(), (height - tail.height) / 2)
            }
        }
    }
}
