package app.ziziplayer.playback;

/** Platform-free route identity rule. Never infer routing from a type-priority list. */
public final class AudioRoutePolicy {
    private AudioRoutePolicy() {}
    public static int select(int actual, int planned, int lastConfirmed, int[] connected) {
        if (actual >= 0) return actual; // AudioTrack can precede the inventory callback.
        if (planned >= 0) return planned;
        if (connected != null) for (int id : connected) if (id == lastConfirmed) return id;
        return -1;
    }
}
