package app.ziziplayer.ui;

/**
 * Mini lyrics reference: 1080px wide, card x=45..1035, height=1156px.
 * Units are dp in production, reference pixels in the measurement tests.
 * Font scaling is applied by Compose, not baked into these width ratios.
 */
public final class LyricsPreviewGeometry {
    public static final float REFERENCE_WIDTH = 1080f;
    public static final float CARD_WIDTH = 990f;
    public static final float CORNER = 48f;
    public static final float INSET = 46f;
    public static final float HEADER_FONT = 48f;
    public static final float HEADER_LINE = 60f;
    public static final float HEADER_GAP = 52f;
    public static final float VIEWPORT = 772f;
    public static final float BODY_FONT = 68f;
    public static final float BODY_LINE = 84f;
    public static final float CUE_GAP = 64f;
    public static final float BUTTON_GAP = 64f;
    public static final float BUTTON_HEIGHT = 92f;
    public static final float BUTTON_FONT = 38f;
    public static final float BUTTON_LINE = 46f;
    public static final float BOTTOM = 70f;
    public static final float ANCHOR = .375f;
    public static final float FADE_TOP = .12f;
    public static final float FADE_BOTTOM = .86f;
    public static final float INACTIVE_SCALE = .84f;
    public static final int SCROLL_MS = 420;
    public static final int INK_MS = 240;
    public static final int MAX_CUE_LINES = 4;

    private LyricsPreviewGeometry() {}

    /** Cap physical card width on tablets/landscape, not system font scale. */
    public static float unit(float availableWidthDp) {
        if (!Float.isFinite(availableWidthDp) || availableWidthDp <= 0f) return 0f;
        return Math.min(availableWidthDp, 480f) / REFERENCE_WIDTH;
    }

    /** Never claim that a wrong track, duration, or unverified plain fallback is singing. */
    public static int activeIndex(boolean sameTrack, boolean durationMatches, boolean verified,
                                  int cursor, int count) {
        return sameTrack && durationMatches && verified && cursor >= 0 && cursor < count ? cursor : -1;
    }

    /** A seek/track entry snaps; adjacent cues move. No timer or guessed word timings. */
    public static boolean shouldAnimate(int previous, int next) {
        return previous >= 0 && next >= 0 && previous != next && Math.abs((long) next - previous) <= 2;
    }

    /** This mask affects text only; the artwork-derived backdrop stays fully opaque. */
    public static float edgeAlpha(float fraction) {
        if (!Float.isFinite(fraction) || fraction <= 0f || fraction >= 1f) return 0f;
        if (fraction < FADE_TOP) return fraction / FADE_TOP;
        if (fraction > FADE_BOTTOM) return (1f - fraction) / (1f - FADE_BOTTOM);
        return 1f;
    }
}
