package app.ziziplayer.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.ziziplayer.data.TrackEntity
import app.ziziplayer.data.remote.RemoteCollection
import app.ziziplayer.data.remote.RemoteKind
import app.ziziplayer.data.remote.RemoteTrack
import app.ziziplayer.data.remote.toEntity
import androidx.compose.ui.graphics.vector.ImageVector
import app.ziziplayer.playback.DownloadStatus
import app.ziziplayer.ui.MainViewModel
import app.ziziplayer.ui.components.ZiziIcons

/** Uses the existing queue, favourites, sharing, playlist, FX and download implementations.
 * Opening is memory-only: metadata is ensured only after an action is selected.
 * The complete action list exists in the first frame; preparation never replaces the dialog.
 * Follow-up sheets are owned outside the menu, so hide-before-action cannot destroy them.
 */
@Composable
internal fun SearchTrackActionsHost(
    remote: RemoteTrack?,
    vm: MainViewModel,
    onDismiss: () -> Unit,
    onShare: (TrackEntity) -> Unit,
    onOpenCollection: (RemoteCollection) -> Unit,
    onFindArtist: (String) -> Unit,
    onOpenEqualizer: () -> Unit
) {
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var infoTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var fxTarget by remember { mutableStateOf<TrackEntity?>(null) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    if (remote == null && playlistTarget == null && infoTarget == null && fxTarget == null &&
        !showSleep && !showQueue) return
    val library by vm.library.collectAsStateWithLifecycle()
    val playback by vm.playback.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()

    if (remote != null) key(remote.trackId) {
        // RemoteTrack already contains everything required to draw the menu. A database
        // round-trip must not gate presentation or insert/remove a loading-only sheet.
        val preview = remember(remote) { remote.toEntity() }
        var prepared by remember { mutableStateOf<TrackEntity?>(null) }
        val favorite = remote.trackId in library.favoriteIds
        val download = rememberMenuDownloadState(vm, preview, downloads[remote.trackId])
        fun trackAction(id: String, label: String, icon: ImageVector,
                        enabled: Boolean = true, run: (TrackEntity) -> Unit): SearchTrackAction =
            SearchTrackAction(id, label, icon, enabled) { run(checkNotNull(prepared)) }
        val actions = buildList {
            add(trackAction("share", "Поделиться", ZiziIcons.Share) { track -> onShare(track) })
            add(trackAction("favorite", if (favorite) "Убрать из избранного" else "Добавить в избранное",
                if (favorite) ZiziIcons.HeartFilled else ZiziIcons.Heart) { track -> vm.toggleFavorite(track) })
            add(trackAction("playlist", "Добавить в плейлист", ZiziIcons.Plus) { track -> playlistTarget = track })
            add(trackAction("enqueue", "Добавить в очередь", ZiziIcons.QueueAdd) { track -> vm.addToQueue(track) })
            add(trackAction("queue", "Очередь", ZiziIcons.Queue) { showQueue = true })
            remote.relatedCollection(RemoteKind.ALBUM)?.let { album ->
                add(trackAction("album", "Перейти к альбому", ZiziIcons.FolderMusic) { onOpenCollection(album) })
            }
            if (remote.artist.isNotBlank() && remote.artist != "—") {
                val artist = remote.relatedCollection(RemoteKind.ARTIST)
                add(trackAction("artist", if (artist != null) "Перейти к исполнителю" else "Найти исполнителя",
                    ZiziIcons.Person) { if (artist != null) onOpenCollection(artist) else onFindArtist(remote.artist) })
            }
            add(trackAction("next", "Играть следующим", ZiziIcons.PlayNext) { track -> vm.playNext(track) })
            val cancel = download.status is DownloadStatus.Running || download.status == DownloadStatus.Queued
            val done = download.status == DownloadStatus.Done
            // Keep the row in place even while the offline index is being read. Never shift
            // every subsequent action down by inserting a late download row.
            add(trackAction("download", when { cancel -> "Отменить загрузку"; done -> "Удалить скачанную копию"; else -> "Скачать" },
                ZiziIcons.Download, enabled = !download.checking) { track ->
                when { cancel -> vm.cancelDownload(track); done -> vm.removeDownload(track); else -> vm.download(track) }
            })
            add(trackAction("fx", "Скорость и эффекты", ZiziIcons.Speed) { track -> fxTarget = track })
            add(trackAction("sleep", "Таймер сна", ZiziIcons.Moon) { showSleep = true })
            add(trackAction("info", "Сведения о треке", ZiziIcons.Info) { track -> infoTarget = track })
        }
        SearchTrackMenuSheet(track = remote, actions = actions, onDismiss = onDismiss,
            prepareAction = { action ->
                // Await the authoritative row before executing queue/FK-backed operations.
                // The existing dialog stays mounted; closing it cancels this preparation.
                if (prepared == null) prepared = vm.prepareRemoteTrack(remote)
                action.run
            })
    }

    playlistTarget?.let { track ->
        PlaylistPickerSheet(playlists = library.playlists,
            onPick = { vm.addToPlaylist(it, track.id); playlistTarget = null },
            onCreate = { vm.createPlaylist(it, listOf(track)); playlistTarget = null },
            onDismiss = { playlistTarget = null })
    }
    infoTarget?.let { track ->
        val download = rememberMenuDownloadState(vm, track, downloads[track.id])
        TrackInfoSheet(track = track, plays = library.stats[track.id]?.playCount ?: 0,
            downloaded = download.status == DownloadStatus.Done, downloadChecking = download.checking,
            streamLabel = if (playback.currentTrackId == track.id) vm.streamStatusLabel() else null, onDismiss = { infoTarget = null })
    }
    fxTarget?.let { track ->
        FxSheet(vm = vm, track = track, onOpenEqualizer = { fxTarget = null; onOpenEqualizer() },
            onDismiss = { fxTarget = null })
    }
    if (showSleep) SleepSheet(playback.sleepMinutesLeft,
        onPick = { vm.setSleepTimer(it); showSleep = false }, onDismiss = { showSleep = false })
    if (showQueue) {
        val entries by vm.queueEntries.collectAsStateWithLifecycle()
        QueueSheet(entries = entries, currentEntryKey = playback.currentQueueEntryKey, isPlaying = playback.isPlaying,
            onPick = vm::playQueueEntry, onReorder = { before, after -> vm.reorderQueue(before, after) },
            onSaveAsPlaylist = { vm.saveQueueAsPlaylist("Очередь ${entries.size}"); showQueue = false },
            onDismiss = { showQueue = false })
    }
}

/** Only authoritative provider ids permit a direct album/artist destination. */
internal fun RemoteTrack.relatedCollection(kind: RemoteKind): RemoteCollection? {
    val catalogProvider = if (provider == "mix") remoteId.substringBefore(':') else provider
    if (catalogProvider != "dz") return null
    val id = when (kind) { RemoteKind.ALBUM -> catalogAlbumId; RemoteKind.ARTIST -> catalogArtistId; else -> null }
        ?.takeIf { value -> value.isNotBlank() && value.all { it in '0'..'9' } && value != "0" } ?: return null
    return RemoteCollection(provider = catalogProvider,
        remoteId = "${kind.name.lowercase(java.util.Locale.ROOT)}:$id", kind = kind,
        title = if (kind == RemoteKind.ALBUM) album.ifBlank { title } else artist,
        subtitle = if (kind == RemoteKind.ALBUM) artist else "",
        artworkUrl = if (kind == RemoteKind.ALBUM) artworkUrl else null)
}
