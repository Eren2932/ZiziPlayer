package app.ziziplayer.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.saveable.SaveableStateHolder
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.ziziplayer.ui.SearchTab
import app.ziziplayer.ui.components.SearchFilterRail

/** Session owns BOTH live composition and saved tab scroll. New holder alone is not enough:
 * rememberLazyListState can survive in the active composition when ALL is submitted again.
 * Tab switches/editor-back keep the holder; only an explicit submit creates a new session.
 */
@Composable
internal fun SearchResultsPane(
    session: Long,
    tab: SearchTab,
    scrollHolder: SaveableStateHolder,
    onTab: (SearchTab) -> Unit,
    content: @Composable () -> Unit
) {
    key(session) {
        Spacer(Modifier.height(8.dp))
        SearchFilterRail(selectedTab = tab, onTab = onTab)
        scrollHolder.SaveableStateProvider(tab.name) { content() }
    }
}
