package app.ziziplayer.data.remote

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

private data class PreviewEvent(
    val index: Int,
    val items: List<RemoteItem>? = null,
    val finished: Boolean = false,
    val failure: CatalogException? = null
)

/** Publish each completed lane immediately. Only the receiving coroutine mutates snapshots.
 * Slow albums/providers cannot hold tracks hostage; cancellation reaches all HTTP children.
 * A failed lane cannot erase an earlier successful lane. An all-lane failure remains an error.
 */
internal fun progressivePreview(
    sources: List<Flow<List<RemoteItem>>>,
    merge: (List<List<RemoteItem>>) -> List<RemoteItem>
): Flow<List<RemoteItem>> = channelFlow {
    if (sources.isEmpty()) { send(emptyList()); return@channelFlow }
    val events = Channel<PreviewEvent>(Channel.BUFFERED)
    sources.forEachIndexed { index, source ->
        launch {
            try {
                source.collect { events.send(PreviewEvent(index, items = it)) }
                events.send(PreviewEvent(index, finished = true))
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                events.send(PreviewEvent(index, finished = true, failure =
                    if (e is CatalogException) e else CatalogException(
                        CatalogException.Reason.PROTOCOL, "Не удалось прочитать каталог", e)))
            }
        }
    }
    val snapshots = MutableList(sources.size) { emptyList<RemoteItem>() }
    var finished = 0
    var failure: CatalogException? = null
    while (finished < sources.size) {
        val event = events.receive()
        if (event.finished) finished++
        event.failure?.let { failure = it }
        event.items?.let {
            snapshots[event.index] = it
            val items = merge(snapshots)
            if (items.isNotEmpty()) send(items)
        }
    }
    val final = merge(snapshots)
    if (final.isEmpty()) failure?.let { throw it }
    send(final)
}.distinctUntilChanged()
