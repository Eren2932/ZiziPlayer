package app.ziziplayer.ui;

import java.util.LinkedHashMap;
import java.util.Map;

/** Small in-memory, exact-query cache. Clock is monotonic and injected by the caller. */
public final class SearchPreviewCache<T> {
    private static final class Entry<T> {
        final T value;
        final long written;
        Entry(T value, long written) { this.value = value; this.written = written; }
    }
    private final int capacity;
    private final long ttl;
    private final Map<String, Entry<T>> entries = new LinkedHashMap<>(16, .75f, true);
    public SearchPreviewCache(int capacity, long ttl) {
        if (capacity < 1 || ttl < 1) throw new IllegalArgumentException("Positive bounds required");
        this.capacity = capacity; this.ttl = ttl;
    }
    public T get(String key, long now) {
        Entry<T> entry = entries.get(key);
        if (entry == null) return null;
        if (now < entry.written || now - entry.written >= ttl) {
            entries.remove(key); return null;
        }
        return entry.value;
    }
    public void put(String key, T value, long now) {
        entries.put(key, new Entry<>(value, now));
        while (entries.size() > capacity) entries.remove(entries.keySet().iterator().next());
    }
    public void clear() { entries.clear(); }
    public int size() { return entries.size(); }
}
