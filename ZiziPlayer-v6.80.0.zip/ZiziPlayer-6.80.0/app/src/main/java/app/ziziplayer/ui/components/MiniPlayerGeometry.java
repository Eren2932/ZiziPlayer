package app.ziziplayer.ui.components;

/** Reference raster: 1080 px; inferred density 2.875 px/dp (not read from the device). */
public final class MiniPlayerGeometry {
    private MiniPlayerGeometry() {}
    public static final float HEIGHT = 56f;
    public static final float EDGE = 8f;
    public static final float RADIUS = 8f;
    public static final float ART = 40f;
    public static final float CONTROL = 40f;
    // Existing Zizi tabs are 46 dp. This gap places the card at y=2075 on the reference window.
    public static final float DOCK_GAP = 11f;
    public static float height(float fontScale) {
        return HEIGHT + 32f * Math.max(0f, fontScale - 1f);
    }
    public static float progress(String shown, String owner, long position, long duration) {
        if (shown == null || !shown.equals(owner) || duration <= 0) return 0f;
        return Math.max(0f, Math.min(1f, (float) ((double) position / duration)));
    }
}
