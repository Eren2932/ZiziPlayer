package app.ziziplayer.ui;

/** Search-only metrics. Do not change the library, collection rows or search editor. */
public final class SearchResultGeometry {
    private SearchResultGeometry() {}
    public static final float EDGE_DP = 16.5f;
    public static final float ART_DP = 48f;
    public static final float ROW_DP = 64f;
    public static final float TEXT_GAP_DP = 12f;
    public static final float CHIP_DP = 30f;
    public static final float TOUCH_DP = 48f;
    // Measured at 1080×2400: reference mark ~42px, row artwork ~136px. 42/136*48 ≈ 15dp.
    public static final float SAVE_MARK_DP = 15f;
    public static final float SAVE_GLYPH_DP = 10f;
    public static final float MORE_ICON_DP = 20f;
    public static final float MENU_PEEK_FRACTION = 0.60f;
    public static final float MENU_TOP_FRACTION = 0.07f;
    public static final float MENU_ROW_DP = 58f;
    public static final int FILTER_DURATION_MS = FilterRailGeometry.DURATION_MS;

    /** Coordinates are in the scrolling content; subtract scroll only when drawing on screen. */
    public static float filterX(float naturalX, float selectedNaturalX, float scroll,
                                float selectedViewportX, float progress) {
        return FilterRailGeometry.filterX(naturalX, selectedNaturalX, scroll, selectedViewportX, progress);
    }
    public static float siblingAlpha(float progress) { return FilterRailGeometry.siblingAlpha(progress); }
    public static boolean nearEnd(int lastVisible, int layoutItems) {
        return lastVisible >= 0 && layoutItems > 0 && lastVisible >= Math.max(0, layoutItems - 4);
    }
}
