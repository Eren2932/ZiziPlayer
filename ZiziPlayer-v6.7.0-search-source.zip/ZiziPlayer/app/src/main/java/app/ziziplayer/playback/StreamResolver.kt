package app.ziziplayer.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import app.ziziplayer.data.remote.CatalogException
import app.ziziplayer.data.remote.ZiziHttp
import java.io.IOException
import kotlinx.coroutines.runBlocking

/**
 * Turns `zizi://provider/id` into a real, currently valid HTTP address - at the last possible
 * moment, on the thread that is about to read bytes.
 *
 * `runBlocking` here is correct rather than a shortcut. Media3 calls `resolveDataSpec` on its own
 * loader thread, whose entire job is blocking I/O; the alternative (resolving earlier, somewhere
 * with a coroutine scope) is exactly the design [RemoteUri] exists to avoid. What must never happen
 * is this being called on the main thread, and it cannot be: the only caller is the loader.
 *
 * Everything is reported as IOException because that is the language ExoPlayer's error handling
 * speaks - and [RemoteLoadErrorPolicy] is what decides which of those get a second chance.
 */
@UnstableApi
class StreamResolver(private val context: Context) : ResolvingDataSource.Resolver {

    @Throws(IOException::class)
    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val uri = dataSpec.uri
        if (!RemoteUri.isRemote(uri)) return dataSpec

        val (providerId, remoteId) = RemoteUri.parse(uri)
            ?: throw IOException("Некорректный адрес трека: $uri")

        if (RemoteRuntime.wifiOnly && RemoteRuntime.isMetered(context)) {
            // Not retryable, and it must not look like a network failure: the user asked for this.
            throw HttpDataSource.HttpDataSourceException(
                IOException("Включено «только Wi-Fi»"),
                dataSpec,
                HttpDataSource.HttpDataSourceException.TYPE_OPEN
            )
        }

        val catalog = RemoteRuntime.registry.byId(providerId)
            ?: throw IOException("Источник «$providerId» не подключён")

        val info = try {
            runBlocking { catalog.resolveStream(remoteId, RemoteRuntime.effectiveQuality(context)) }
        } catch (e: CatalogException) {
            throw IOException("${catalog.label}: ${e.message}", e)
        } catch (e: InterruptedException) {
            // The user skipped while we were resolving. Not an error worth reporting.
            throw IOException("Отменено", e)
        }

        // Only the URI and the request headers change. Position, length and flags belong to the
        // caller, and rebuilding them by hand is how range requests quietly turn into full
        // downloads.
        //
        // The user agent is attached HERE, per request, and not on the factory. Two reasons, and
        // the second one is why 6.6.0-fix1 could not have worked:
        //
        //  1. a googlevideo URL is bound to the client identity that minted it, so the UA that
        //     fetches it has to be the one the catalogue used - and that is a property of this one
        //     stream, not of the app;
        //  2. `OkHttpDataSource.Factory.setUserAgent` writes the header AFTER merging the
        //     DataSpec's own headers, so a factory-level agent silently wins over a per-request
        //     one. The factory no longer sets it at all (see ZiziDataSources) precisely so that
        //     this line is the only thing deciding.
        val headers = HashMap(dataSpec.httpRequestHeaders)
        headers["User-Agent"] = info.userAgent ?: ZiziHttp.USER_AGENT
        return dataSpec.buildUpon()
            .setUri(Uri.parse(info.url))
            .setKey(dataSpec.key ?: uri.toString())
            .setHttpRequestHeaders(headers)
            .build()
    }

    /**
     * Keeps the reported URI as our own scheme.
     *
     * Media3 hands the reported URI to listeners and to the cache accounting. Reporting the
     * resolved googlevideo address would make every playback look like a brand new resource.
     */
    override fun resolveReportedUri(uri: Uri): Uri = uri
}
