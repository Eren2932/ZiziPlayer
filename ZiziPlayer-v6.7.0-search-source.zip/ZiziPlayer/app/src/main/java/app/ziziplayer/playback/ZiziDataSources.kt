package app.ziziplayer.playback

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import app.ziziplayer.data.remote.ZiziHttp

/**
 * How bytes reach the decoder. The order of the wrappers is the design.
 *
 *   DefaultDataSource            file:// and content:// are handled locally, exactly as before -
 *        │                       a local track never touches any of the network machinery
 *        ▼  (unknown scheme, i.e. zizi://)
 *   CacheDataSource              keys by zizi://, so an entry survives the address changing
 *        │
 *        ▼
 *   ResolvingDataSource          zizi:// -> https://..., resolved now, not earlier
 *        │
 *        ▼
 *   OkHttpDataSource             on the SAME OkHttp client the catalogue uses: one connection pool,
 *                                so the stream reuses the TLS session the search just opened
 *
 * If cache and resolver were swapped, the cache would key entries by the expiring googlevideo URL
 * and every replay would download the track again. That single line of ordering is the difference
 * between a cache and a decoration.
 */
@UnstableApi
object ZiziDataSources {

    fun mediaSourceFactory(context: Context): MediaSource.Factory =
        DefaultMediaSourceFactory(dataSourceFactory(context))
            .setLoadErrorHandlingPolicy(RemoteLoadErrorPolicy())

    fun dataSourceFactory(context: Context): DataSource.Factory {
        // Cross-protocol redirects (https -> http on a CDN hand-off) are NOT configured here on
        // purpose: unlike DefaultHttpDataSource.Factory, the OkHttp-backed factory has no such
        // setter, because it does not do redirects itself - OkHttp does, and ZiziHttp.client
        // already has followRedirects/followSslRedirects on. Calling the Media3 setter here was a
        // compile error, and reaching for it again would be a redundant one.
        // No .setUserAgent here, ON PURPOSE. The factory-level agent is applied after the
        // DataSpec's own headers are merged in, so setting it would quietly override the
        // per-stream agent that StreamResolver attaches - and a YouTube URL fetched with the
        // wrong agent is a 403. Every zizi:// request passes through the resolver, and the
        // resolver always sets a UA, so nothing is left agent-less.
        val http: HttpDataSource.Factory = OkHttpDataSource.Factory(ZiziHttp.client)

        val resolving = ResolvingDataSource.Factory(http, StreamResolver(context))

        val upstream: DataSource.Factory = if (RemoteRuntime.cacheEnabled) {
            CacheDataSource.Factory()
                .setCache(StreamCache.get(context))
                .setUpstreamDataSourceFactory(resolving)
                // Read from cache, write to cache, but never let a cache write failure kill
                // playback: a full disk must degrade to streaming, not to silence.
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        } else {
            resolving
        }

        return DefaultDataSource.Factory(context, upstream)
    }

    /**
     * Buffering tuned for a mobile connection.
     *
     * The defaults (50 s of buffer, 2.5 s before playback starts) are written for video on wifi.
     * For audio on LTE a deeper buffer is nearly free - a 128 kbps track is 16 KB/s, so 90 s costs
     * about 1.4 MB - and it is what carries playback through a lift, a tunnel or a dead cell.
     * The start thresholds stay low so tapping a track still feels immediate.
     */
    fun loadControl(): LoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            /* minBufferMs = */ 20_000,
            /* maxBufferMs = */ 90_000,
            /* bufferForPlaybackMs = */ 1_500,
            /* bufferForPlaybackAfterRebufferMs = */ 3_000
        )
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()
}

/**
 * Gives an expired stream URL exactly one second chance.
 *
 * The default policy treats HTTP 403 as fatal, which is right for a normal server and wrong for
 * this one: 403 is precisely what a stale, IP-bound YouTube link returns, and the fix is to ask
 * again - the retry re-enters [StreamResolver] and gets a fresh address. Without this override the
 * six-hour link expiry shows up as "трек просто перестал играть" halfway through a long queue.
 *
 * One retry, not three: if a freshly resolved URL also 403s, the track really is gone and grinding
 * on it only delays skipping to the next one.
 */
@UnstableApi
class RemoteLoadErrorPolicy : DefaultLoadErrorHandlingPolicy() {

    override fun getRetryDelayMsFor(info: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
        val exception = info.exception
        val code = (exception as? HttpDataSource.InvalidResponseCodeException)?.responseCode
            ?: (exception.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
        if ((code == 403 || code == 401) && info.errorCount <= 1) return 400L
        return super.getRetryDelayMsFor(info)
    }
}
